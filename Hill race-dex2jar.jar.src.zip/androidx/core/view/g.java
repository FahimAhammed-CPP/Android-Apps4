package androidx.core.view;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class g {
  private static final AtomicInteger a = new AtomicInteger(1);
  
  private static WeakHashMap<View, String> b;
  
  private static WeakHashMap<View, Object> c = null;
  
  private static boolean d = false;
  
  private static final int[] e = new int[] { 
      f.b.a, f.b.b, f.b.m, f.b.x, f.b.A, f.b.B, f.b.C, f.b.D, f.b.E, f.b.F, 
      f.b.c, f.b.d, f.b.e, f.b.f, f.b.g, f.b.h, f.b.i, f.b.j, f.b.k, f.b.l, 
      f.b.n, f.b.o, f.b.p, f.b.q, f.b.r, f.b.s, f.b.t, f.b.u, f.b.v, f.b.w, 
      f.b.y, f.b.z };
  
  private static final e f = f.a;
  
  private static final b g = new b();
  
  static boolean a(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : k.a(paramView).b(paramView, paramKeyEvent);
  }
  
  static boolean b(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : k.a(paramView).f(paramKeyEvent);
  }
  
  public static int c(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? e.a(paramView) : 0;
  }
  
  public static CharSequence d(View paramView) {
    return k().d(paramView);
  }
  
  public static int e(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? d.c(paramView) : 0;
  }
  
  public static k f(View paramView) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 23) ? h.a(paramView) : ((i >= 21) ? g.j(paramView) : null);
  }
  
  public static String g(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return g.k(paramView); 
    WeakHashMap<View, String> weakHashMap = b;
    return (weakHashMap == null) ? null : weakHashMap.get(paramView);
  }
  
  public static boolean h(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? d.h(paramView) : true;
  }
  
  public static boolean i(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? e.b(paramView) : ((paramView.getWindowToken() != null));
  }
  
  static void j(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (d(paramView) != null && paramView.isShown() && paramView.getWindowVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = c(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      e.g(accessibilityEvent, paramInt);
      if (bool) {
        accessibilityEvent.getText().add(d(paramView));
        p(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      e.g(accessibilityEvent1, paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(d(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null) {
      ViewParent viewParent = paramView.getParent();
      try {
        e.e(viewParent, paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      } 
    } 
  }
  
  private static c<CharSequence> k() {
    return new a(f.b.G, CharSequence.class, 8, 28);
  }
  
  public static void l(View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      f.c(paramView);
      return;
    } 
    if (i >= 16)
      d.p(paramView); 
  }
  
  public static void m(View paramView, Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 16) {
      d.q(paramView, paramDrawable);
      return;
    } 
    paramView.setBackgroundDrawable(paramDrawable);
  }
  
  public static void n(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      d.s(paramView, paramInt);
      return;
    } 
    if (i >= 16) {
      i = paramInt;
      if (paramInt == 4)
        i = 2; 
      d.s(paramView, i);
    } 
  }
  
  public static void o(View paramView, String paramString) {
    if (Build.VERSION.SDK_INT >= 21) {
      g.v(paramView, paramString);
      return;
    } 
    if (b == null)
      b = new WeakHashMap<View, String>(); 
    b.put(paramView, paramString);
  }
  
  private static void p(View paramView) {
    if (e(paramView) == 0)
      n(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (e((View)viewParent) == 4) {
        n(paramView, 2);
        return;
      } 
    } 
  }
  
  class a extends c<CharSequence> {
    a(g this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence e(View param1View) {
      return g.i.b(param1View);
    }
  }
  
  static class b implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private final WeakHashMap<View, Boolean> b = new WeakHashMap<View, Boolean>();
    
    private void a(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b1;
        if (bool) {
          b1 = 16;
        } else {
          b1 = 32;
        } 
        g.j(param1View, b1);
        this.b.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    private void b(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.b.entrySet())
          a((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      b(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  static abstract class c<T> {
    private final int a;
    
    private final Class<T> b;
    
    private final int c;
    
    private final int d;
    
    c(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.d = param1Int2;
      this.c = param1Int3;
    }
    
    private boolean a() {
      return (Build.VERSION.SDK_INT >= 19);
    }
    
    private boolean b() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    abstract T c(View param1View);
    
    T d(View param1View) {
      if (b())
        return c(param1View); 
      if (a()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
  }
  
  static class d {
    static AccessibilityNodeProvider a(View param1View) {
      return param1View.getAccessibilityNodeProvider();
    }
    
    static boolean b(View param1View) {
      return param1View.getFitsSystemWindows();
    }
    
    static int c(View param1View) {
      return param1View.getImportantForAccessibility();
    }
    
    static int d(View param1View) {
      return param1View.getMinimumHeight();
    }
    
    static int e(View param1View) {
      return param1View.getMinimumWidth();
    }
    
    static ViewParent f(View param1View) {
      return param1View.getParentForAccessibility();
    }
    
    static int g(View param1View) {
      return param1View.getWindowSystemUiVisibility();
    }
    
    static boolean h(View param1View) {
      return param1View.hasOverlappingRendering();
    }
    
    static boolean i(View param1View) {
      return param1View.hasTransientState();
    }
    
    static boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      return param1View.performAccessibilityAction(param1Int, param1Bundle);
    }
    
    static void k(View param1View) {
      param1View.postInvalidateOnAnimation();
    }
    
    static void l(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateOnAnimation(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void m(View param1View, Runnable param1Runnable) {
      param1View.postOnAnimation(param1Runnable);
    }
    
    static void n(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postOnAnimationDelayed(param1Runnable, param1Long);
    }
    
    static void o(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
    
    static void p(View param1View) {
      param1View.requestFitSystemWindows();
    }
    
    static void q(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    static void r(View param1View, boolean param1Boolean) {
      param1View.setHasTransientState(param1Boolean);
    }
    
    static void s(View param1View, int param1Int) {
      param1View.setImportantForAccessibility(param1Int);
    }
  }
  
  static class e {
    static int a(View param1View) {
      return param1View.getAccessibilityLiveRegion();
    }
    
    static boolean b(View param1View) {
      return param1View.isAttachedToWindow();
    }
    
    static boolean c(View param1View) {
      return param1View.isLaidOut();
    }
    
    static boolean d(View param1View) {
      return param1View.isLayoutDirectionResolved();
    }
    
    static void e(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.notifySubtreeAccessibilityStateChanged(param1View1, param1View2, param1Int);
    }
    
    static void f(View param1View, int param1Int) {
      param1View.setAccessibilityLiveRegion(param1Int);
    }
    
    static void g(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
  
  static class f {
    static WindowInsets a(View param1View, WindowInsets param1WindowInsets) {
      return param1View.dispatchApplyWindowInsets(param1WindowInsets);
    }
    
    static WindowInsets b(View param1View, WindowInsets param1WindowInsets) {
      return param1View.onApplyWindowInsets(param1WindowInsets);
    }
    
    static void c(View param1View) {
      param1View.requestApplyInsets();
    }
  }
  
  private static class g {
    static void a(WindowInsets param1WindowInsets, View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(f.b.L);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    static k b(View param1View, k param1k, Rect param1Rect) {
      WindowInsets windowInsets = param1k.l();
      if (windowInsets != null)
        return k.n(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1k;
    }
    
    static boolean c(View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1View.dispatchNestedFling(param1Float1, param1Float2, param1Boolean);
    }
    
    static boolean d(View param1View, float param1Float1, float param1Float2) {
      return param1View.dispatchNestedPreFling(param1Float1, param1Float2);
    }
    
    static boolean e(View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      return param1View.dispatchNestedPreScroll(param1Int1, param1Int2, param1ArrayOfint1, param1ArrayOfint2);
    }
    
    static boolean f(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int[] param1ArrayOfint) {
      return param1View.dispatchNestedScroll(param1Int1, param1Int2, param1Int3, param1Int4, param1ArrayOfint);
    }
    
    static ColorStateList g(View param1View) {
      return param1View.getBackgroundTintList();
    }
    
    static PorterDuff.Mode h(View param1View) {
      return param1View.getBackgroundTintMode();
    }
    
    static float i(View param1View) {
      return param1View.getElevation();
    }
    
    public static k j(View param1View) {
      return k.a.a(param1View);
    }
    
    static String k(View param1View) {
      return param1View.getTransitionName();
    }
    
    static float l(View param1View) {
      return param1View.getTranslationZ();
    }
    
    static float m(View param1View) {
      return param1View.getZ();
    }
    
    static boolean n(View param1View) {
      return param1View.hasNestedScrollingParent();
    }
    
    static boolean o(View param1View) {
      return param1View.isImportantForAccessibility();
    }
    
    static boolean p(View param1View) {
      return param1View.isNestedScrollingEnabled();
    }
    
    static void q(View param1View, ColorStateList param1ColorStateList) {
      param1View.setBackgroundTintList(param1ColorStateList);
    }
    
    static void r(View param1View, PorterDuff.Mode param1Mode) {
      param1View.setBackgroundTintMode(param1Mode);
    }
    
    static void s(View param1View, float param1Float) {
      param1View.setElevation(param1Float);
    }
    
    static void t(View param1View, boolean param1Boolean) {
      param1View.setNestedScrollingEnabled(param1Boolean);
    }
    
    static void u(View param1View, d param1d) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(f.b.H, param1d); 
      if (param1d == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(f.b.L));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1d));
    }
    
    static void v(View param1View, String param1String) {
      param1View.setTransitionName(param1String);
    }
    
    static void w(View param1View, float param1Float) {
      param1View.setTranslationZ(param1Float);
    }
    
    static void x(View param1View, float param1Float) {
      param1View.setZ(param1Float);
    }
    
    static boolean y(View param1View, int param1Int) {
      return param1View.startNestedScroll(param1Int);
    }
    
    static void z(View param1View) {
      param1View.stopNestedScroll();
    }
    
    class a implements View.OnApplyWindowInsetsListener {
      k a = null;
      
      a(g.g this$0, d param2d) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        k k2 = k.n(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          g.g.a(param2WindowInsets, this.b);
          if (k2.equals(this.a))
            return this.c.a(param2View, k2).l(); 
        } 
        this.a = k2;
        k k1 = this.c.a(param2View, k2);
        if (i >= 30)
          return k1.l(); 
        g.l(param2View);
        return k1.l();
      }
    }
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    k a = null;
    
    a(g this$0, d param1d) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      k k2 = k.n(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        g.g.a(param1WindowInsets, this.b);
        if (k2.equals(this.a))
          return this.c.a(param1View, k2).l(); 
      } 
      this.a = k2;
      k k1 = this.c.a(param1View, k2);
      if (i >= 30)
        return k1.l(); 
      g.l(param1View);
      return k1.l();
    }
  }
  
  private static class h {
    public static k a(View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      k k = k.m(windowInsets);
      k.j(k);
      k.d(param1View.getRootView());
      return k;
    }
    
    static int b(View param1View) {
      return param1View.getScrollIndicators();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setScrollIndicators(param1Int);
    }
    
    static void d(View param1View, int param1Int1, int param1Int2) {
      param1View.setScrollIndicators(param1Int1, param1Int2);
    }
  }
  
  static class i {
    static void a(View param1View, g.j param1j) {
      int k = f.b.K;
      androidx.collection.f f2 = (androidx.collection.f)param1View.getTag(k);
      androidx.collection.f f1 = f2;
      if (f2 == null) {
        f1 = new androidx.collection.f();
        param1View.setTag(k, f1);
      } 
      Objects.requireNonNull(param1j);
      h h = new h(param1j);
      f1.put(param1j, h);
      param1View.addOnUnhandledKeyEventListener(h);
    }
    
    static CharSequence b(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
    
    static boolean c(View param1View) {
      return param1View.isAccessibilityHeading();
    }
    
    static boolean d(View param1View) {
      return param1View.isScreenReaderFocusable();
    }
    
    static void e(View param1View, g.j param1j) {
      androidx.collection.f f = (androidx.collection.f)param1View.getTag(f.b.K);
      if (f == null)
        return; 
      View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)f.get(param1j);
      if (onUnhandledKeyEventListener != null)
        param1View.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener); 
    }
    
    static <T> T f(View param1View, int param1Int) {
      return (T)param1View.requireViewById(param1Int);
    }
    
    static void g(View param1View, boolean param1Boolean) {
      param1View.setAccessibilityHeading(param1Boolean);
    }
    
    static void h(View param1View, CharSequence param1CharSequence) {
      param1View.setAccessibilityPaneTitle(param1CharSequence);
    }
    
    static void i(View param1View, boolean param1Boolean) {
      param1View.setScreenReaderFocusable(param1Boolean);
    }
  }
  
  public static interface j {
    boolean onUnhandledKeyEvent(View param1View, KeyEvent param1KeyEvent);
  }
  
  static class k {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static k a(View param1View) {
      int i = f.b.J;
      k k2 = (k)param1View.getTag(i);
      k k1 = k2;
      if (k2 == null) {
        k1 = new k();
        param1View.setTag(i, k1);
      } 
      return k1;
    }
    
    private View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private boolean e(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<g.j> arrayList = (ArrayList)param1View.getTag(f.b.K);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((g.j)arrayList.get(i)).onUnhandledKeyEvent(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic androidx/core/view/g$k.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic androidx/core/view/g$k.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 149
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 149
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: aload_2
      //   148: athrow
      //   149: iload_1
      //   150: iconst_1
      //   151: isub
      //   152: istore_1
      //   153: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
    
    boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && g.i(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\view\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */