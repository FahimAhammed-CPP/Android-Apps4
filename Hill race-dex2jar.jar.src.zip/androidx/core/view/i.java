package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import f.b;

public final class i {
  public static boolean a(ViewGroup paramViewGroup) {
    if (Build.VERSION.SDK_INT >= 21)
      return a.b(paramViewGroup); 
    Boolean bool = (Boolean)paramViewGroup.getTag(b.I);
    return ((bool != null && bool.booleanValue()) || paramViewGroup.getBackground() != null || g.g((View)paramViewGroup) != null);
  }
  
  static class a {
    static int a(ViewGroup param1ViewGroup) {
      return param1ViewGroup.getNestedScrollAxes();
    }
    
    static boolean b(ViewGroup param1ViewGroup) {
      return param1ViewGroup.isTransitionGroup();
    }
    
    static void c(ViewGroup param1ViewGroup, boolean param1Boolean) {
      param1ViewGroup.setTransitionGroup(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\view\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */