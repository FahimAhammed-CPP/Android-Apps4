package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.collection.f;
import androidx.core.view.b;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.t;

public class d extends Activity implements j, b.a {
  private f<Class<Object>, Object> b = new f();
  
  private k c = new k(this);
  
  public boolean b(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : b.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public f getLifecycle() {
    return (f)this.c;
  }
  
  @SuppressLint({"RestrictedApi"})
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    t.g(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.c.j(f.c.d);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */