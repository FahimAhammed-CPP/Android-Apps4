package androidx.core.app;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import androidx.core.graphics.drawable.IconCompat;
import java.lang.reflect.Field;
import java.util.List;

class h {
  private static final Object a = new Object();
  
  private static Field b;
  
  private static boolean c;
  
  private static final Object d = new Object();
  
  public static SparseArray<Bundle> a(List<Bundle> paramList) {
    int j = paramList.size();
    SparseArray<Bundle> sparseArray = null;
    int i = 0;
    while (i < j) {
      Bundle bundle = paramList.get(i);
      SparseArray<Bundle> sparseArray1 = sparseArray;
      if (bundle != null) {
        sparseArray1 = sparseArray;
        if (sparseArray == null)
          sparseArray1 = new SparseArray(); 
        sparseArray1.put(i, bundle);
      } 
      i++;
      sparseArray = sparseArray1;
    } 
    return sparseArray;
  }
  
  static Bundle b(f.a parama) {
    boolean bool;
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = parama.e();
    if (iconCompat != null) {
      bool = iconCompat.h();
    } else {
      bool = false;
    } 
    bundle2.putInt("icon", bool);
    bundle2.putCharSequence("title", parama.i());
    bundle2.putParcelable("actionIntent", (Parcelable)parama.a());
    if (parama.d() != null) {
      bundle1 = new Bundle(parama.d());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", parama.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])e(parama.f()));
    bundle2.putBoolean("showsUserInterface", parama.h());
    bundle2.putInt("semanticAction", parama.g());
    return bundle2;
  }
  
  public static Bundle c(Notification paramNotification) {
    synchronized (a) {
      if (c)
        return null; 
      try {
        if (b == null) {
          Field field = Notification.class.getDeclaredField("extras");
          if (!Bundle.class.isAssignableFrom(field.getType())) {
            Log.e("NotificationCompat", "Notification.extras field is not of type Bundle");
            c = true;
            return null;
          } 
          field.setAccessible(true);
          b = field;
        } 
        Bundle bundle2 = (Bundle)b.get(paramNotification);
        Bundle bundle1 = bundle2;
        if (bundle2 == null) {
          bundle1 = new Bundle();
          b.set(paramNotification, bundle1);
        } 
        return bundle1;
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("NotificationCompat", "Unable to access notification extras", illegalAccessException);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("NotificationCompat", "Unable to access notification extras", noSuchFieldException);
      } 
      c = true;
      return null;
    } 
  }
  
  private static Bundle d(k paramk) {
    new Bundle();
    throw null;
  }
  
  private static Bundle[] e(k[] paramArrayOfk) {
    if (paramArrayOfk == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfk.length];
    for (int i = 0; i < paramArrayOfk.length; i++)
      arrayOfBundle[i] = d(paramArrayOfk[i]); 
    return arrayOfBundle;
  }
  
  public static Bundle f(Notification.Builder paramBuilder, f.a parama) {
    boolean bool;
    IconCompat iconCompat = parama.e();
    if (iconCompat != null) {
      bool = iconCompat.h();
    } else {
      bool = false;
    } 
    paramBuilder.addAction(bool, parama.i(), parama.a());
    Bundle bundle = new Bundle(parama.d());
    if (parama.f() != null)
      bundle.putParcelableArray("android.support.remoteInputs", (Parcelable[])e(parama.f())); 
    if (parama.c() != null)
      bundle.putParcelableArray("android.support.dataRemoteInputs", (Parcelable[])e(parama.c())); 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */