package androidx.core.app;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.util.HashSet;
import java.util.Set;

public final class i {
  private static final Object c = new Object();
  
  private static Set<String> d = new HashSet<String>();
  
  private static final Object e = new Object();
  
  private final Context a;
  
  private final NotificationManager b;
  
  private i(Context paramContext) {
    this.a = paramContext;
    this.b = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  public static i b(Context paramContext) {
    return new i(paramContext);
  }
  
  public boolean a() {
    int j = Build.VERSION.SDK_INT;
    if (j >= 24)
      return this.b.areNotificationsEnabled(); 
    boolean bool = true;
    if (j >= 19) {
      AppOpsManager appOpsManager = (AppOpsManager)this.a.getSystemService("appops");
      ApplicationInfo applicationInfo = this.a.getApplicationInfo();
      String str = this.a.getApplicationContext().getPackageName();
      j = applicationInfo.uid;
      try {
        Class<?> clazz = Class.forName(AppOpsManager.class.getName());
        Class<int> clazz1 = int.class;
        j = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(j), str })).intValue();
        return (j == 0);
      } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
        return true;
      } 
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */