package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.collection.b;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class g implements e {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final f.d c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  g(f.d paramd) {
    boolean bool;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = paramd;
    this.a = paramd.a;
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      this.b = new Notification.Builder(paramd.a, paramd.K);
    } else {
      this.b = new Notification.Builder(paramd.a);
    } 
    Notification notification = paramd.S;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramd.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramd.e).setContentText(paramd.f).setContentInfo(paramd.k).setContentIntent(paramd.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramd.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramd.j).setNumber(paramd.l).setProgress(paramd.t, paramd.u, paramd.v);
    if (i < 21)
      this.b.setSound(notification.sound, notification.audioStreamType); 
    if (i >= 16) {
      this.b.setSubText(paramd.q).setUsesChronometer(paramd.o).setPriority(paramd.m);
      Iterator<f.a> iterator = paramd.b.iterator();
      while (iterator.hasNext())
        b(iterator.next()); 
      Bundle bundle = paramd.D;
      if (bundle != null)
        this.g.putAll(bundle); 
      if (Build.VERSION.SDK_INT < 20) {
        if (paramd.z)
          this.g.putBoolean("android.support.localOnly", true); 
        String str = paramd.w;
        if (str != null) {
          this.g.putString("android.support.groupKey", str);
          if (paramd.x) {
            this.g.putBoolean("android.support.isGroupSummary", true);
          } else {
            this.g.putBoolean("android.support.useSideChannel", true);
          } 
        } 
        str = paramd.y;
        if (str != null)
          this.g.putString("android.support.sortKey", str); 
      } 
      this.d = paramd.H;
      this.e = paramd.I;
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 17)
      this.b.setShowWhen(paramd.n); 
    if (i >= 19 && i < 21) {
      List<String> list = e(f(paramd.c), paramd.V);
      if (list != null && !list.isEmpty())
        this.g.putStringArray("android.people", list.<String>toArray(new String[list.size()])); 
    } 
    if (i >= 20) {
      this.b.setLocalOnly(paramd.z).setGroup(paramd.w).setGroupSummary(paramd.x).setSortKey(paramd.y);
      this.h = paramd.O;
    } 
    if (i >= 21) {
      List<String> list;
      this.b.setCategory(paramd.C).setColor(paramd.E).setVisibility(paramd.F).setPublicVersion(paramd.G).setSound(notification.sound, notification.audioAttributes);
      if (i < 28) {
        list = e(f(paramd.c), paramd.V);
      } else {
        list = paramd.V;
      } 
      if (list != null && !list.isEmpty())
        for (String str : list)
          this.b.addPerson(str);  
      this.i = paramd.J;
      if (paramd.d.size() > 0) {
        Bundle bundle2 = paramd.c().getBundle("android.car.EXTENSIONS");
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle2 = new Bundle(bundle1);
        Bundle bundle3 = new Bundle();
        for (i = 0; i < paramd.d.size(); i++)
          bundle3.putBundle(Integer.toString(i), h.b(paramd.d.get(i))); 
        bundle1.putBundle("invisible_actions", bundle3);
        bundle2.putBundle("invisible_actions", bundle3);
        paramd.c().putBundle("android.car.EXTENSIONS", bundle1);
        this.g.putBundle("android.car.EXTENSIONS", bundle2);
      } 
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Icon icon = paramd.U;
      if (icon != null)
        this.b.setSmallIcon(icon); 
    } 
    if (i >= 24) {
      this.b.setExtras(paramd.D).setRemoteInputHistory(paramd.s);
      RemoteViews remoteViews = paramd.H;
      if (remoteViews != null)
        this.b.setCustomContentView(remoteViews); 
      remoteViews = paramd.I;
      if (remoteViews != null)
        this.b.setCustomBigContentView(remoteViews); 
      remoteViews = paramd.J;
      if (remoteViews != null)
        this.b.setCustomHeadsUpContentView(remoteViews); 
    } 
    if (i >= 26) {
      this.b.setBadgeIconType(paramd.L).setSettingsText(paramd.r).setShortcutId(paramd.M).setTimeoutAfter(paramd.N).setGroupAlertBehavior(paramd.O);
      if (paramd.B)
        this.b.setColorized(paramd.A); 
      if (!TextUtils.isEmpty(paramd.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (j j : paramd.c)
        this.b.addPerson(j.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      this.b.setAllowSystemGeneratedContextualActions(paramd.Q);
      this.b.setBubbleMetadata(f.c.a(paramd.R));
    } 
    if (i >= 31) {
      int j = paramd.P;
      if (j != 0)
        this.b.setForegroundServiceBehavior(j); 
    } 
    if (paramd.T) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE;
      notification.defaults = j;
      j &= 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          this.b.setGroup("silent"); 
        this.b.setGroupAlertBehavior(this.h);
      } 
    } 
  }
  
  private void b(f.a parama) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      Notification.Action.Builder builder;
      Bundle bundle;
      IconCompat iconCompat = parama.e();
      boolean bool = false;
      if (i >= 23) {
        if (iconCompat != null) {
          Icon icon = iconCompat.o();
        } else {
          iconCompat = null;
        } 
        builder = new Notification.Action.Builder((Icon)iconCompat, parama.i(), parama.a());
      } else {
        if (builder != null) {
          i = builder.h();
        } else {
          i = 0;
        } 
        builder = new Notification.Action.Builder(i, parama.i(), parama.a());
      } 
      if (parama.f() != null) {
        RemoteInput[] arrayOfRemoteInput = k.b(parama.f());
        int j = arrayOfRemoteInput.length;
        for (i = bool; i < j; i++)
          builder.addRemoteInput(arrayOfRemoteInput[i]); 
      } 
      if (parama.d() != null) {
        bundle = new Bundle(parama.d());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
      i = Build.VERSION.SDK_INT;
      if (i >= 24)
        builder.setAllowGeneratedReplies(parama.b()); 
      bundle.putInt("android.support.action.semanticAction", parama.g());
      if (i >= 28)
        builder.setSemanticAction(parama.g()); 
      if (i >= 29)
        builder.setContextual(parama.k()); 
      if (i >= 31)
        builder.setAuthenticationRequired(parama.j()); 
      bundle.putBoolean("android.support.action.showsUserInterface", parama.h());
      builder.addExtras(bundle);
      this.b.addAction(builder.build());
      return;
    } 
    if (i >= 16)
      this.f.add(h.f(this.b, parama)); 
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    b b = new b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> f(List<j> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<j> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((j)iterator.next()).g()); 
    return arrayList;
  }
  
  private void g(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    int i = paramNotification.defaults & 0xFFFFFFFE;
    paramNotification.defaults = i;
    paramNotification.defaults = i & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    RemoteViews remoteViews;
    f.e e1 = this.c.p;
    if (e1 != null)
      e1.b(this); 
    if (e1 != null) {
      remoteViews = e1.e(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = d();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.c.H;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    int i = Build.VERSION.SDK_INT;
    if (i >= 16 && e1 != null) {
      remoteViews = e1.d(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (i >= 21 && e1 != null) {
      remoteViews = this.c.p.f(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (i >= 16 && e1 != null) {
      Bundle bundle = f.a(notification);
      if (bundle != null)
        e1.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.b.build(); 
    if (i >= 24) {
      Notification notification = this.b.build();
      if (this.h != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 21) {
      this.b.setExtras(this.g);
      Notification notification = this.b.build();
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      remoteViews = this.i;
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
      if (this.h != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 20) {
      this.b.setExtras(this.g);
      Notification notification = this.b.build();
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      if (this.h != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 19) {
      SparseArray<Bundle> sparseArray = h.a(this.f);
      if (sparseArray != null)
        this.g.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      this.b.setExtras(this.g);
      Notification notification = this.b.build();
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    if (i >= 16) {
      Notification notification = this.b.build();
      Bundle bundle1 = f.a(notification);
      Bundle bundle2 = new Bundle(this.g);
      for (String str : this.g.keySet()) {
        if (bundle1.containsKey(str))
          bundle2.remove(str); 
      } 
      bundle1.putAll(bundle2);
      SparseArray<Bundle> sparseArray = h.a(this.f);
      if (sparseArray != null)
        f.a(notification).putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    return this.b.getNotification();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */