package androidx.core.util;

import android.util.Log;
import java.io.Writer;

@Deprecated
public class c extends Writer {
  private final String b;
  
  private StringBuilder c = new StringBuilder(128);
  
  public c(String paramString) {
    this.b = paramString;
  }
  
  private void d() {
    if (this.c.length() > 0) {
      Log.d(this.b, this.c.toString());
      StringBuilder stringBuilder = this.c;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    d();
  }
  
  public void flush() {
    d();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c1 = paramArrayOfchar[paramInt1 + i];
      if (c1 == '\n') {
        d();
      } else {
        this.c.append(c1);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\cor\\util\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */