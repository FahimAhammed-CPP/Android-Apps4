package androidx.core.util;

import java.util.Objects;

public final class f {
  public static <T> T a(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T b(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\cor\\util\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */