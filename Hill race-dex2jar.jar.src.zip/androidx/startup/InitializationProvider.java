package androidx.startup;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import o.c;

public class InitializationProvider extends ContentProvider {
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final boolean onCreate() {
    Context context = getContext();
    if (context != null) {
      if (context.getApplicationContext() != null)
        a.e(context).a(); 
      return true;
    } 
    throw new c("Context cannot be null");
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */