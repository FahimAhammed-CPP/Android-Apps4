package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import java.util.Collections;
import java.util.List;
import t.i;

@SuppressLint({"AddedAbstractMethod"})
public abstract class v {
  public static v d(Context paramContext) {
    return (v)i.k(paramContext);
  }
  
  public static void e(Context paramContext, b paramb) {
    i.e(paramContext, paramb);
  }
  
  public abstract o a(String paramString);
  
  public final o b(w paramw) {
    return c(Collections.singletonList(paramw));
  }
  
  public abstract o c(List<? extends w> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */