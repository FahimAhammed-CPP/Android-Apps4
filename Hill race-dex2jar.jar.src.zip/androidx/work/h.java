package androidx.work;

import android.content.Context;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.UUID;

public interface h {
  ListenableFuture<Void> a(Context paramContext, UUID paramUUID, g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */