package androidx.work;

import android.content.Context;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.UUID;

public interface q {
  ListenableFuture<Void> a(Context paramContext, UUID paramUUID, e parame);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */