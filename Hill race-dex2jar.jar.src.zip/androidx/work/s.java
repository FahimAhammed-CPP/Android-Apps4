package androidx.work;

public interface s {
  void a(long paramLong, Runnable paramRunnable);
  
  void b(Runnable paramRunnable);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */