package androidx.work;

public enum m {
  b, c, d, e, f, g;
  
  static {
    m m1 = new m("NOT_REQUIRED", 0);
    b = m1;
    m m2 = new m("CONNECTED", 1);
    c = m2;
    m m3 = new m("UNMETERED", 2);
    d = m3;
    m m4 = new m("NOT_ROAMING", 3);
    e = m4;
    m m5 = new m("METERED", 4);
    f = m5;
    m m6 = new m("TEMPORARILY_UNMETERED", 5);
    g = m6;
    h = new m[] { m1, m2, m3, m4, m5, m6 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */