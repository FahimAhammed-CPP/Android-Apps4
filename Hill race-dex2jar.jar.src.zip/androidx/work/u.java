package androidx.work;

public enum u {
  b, c, d, e, f, g;
  
  static {
    u u1 = new u("ENQUEUED", 0);
    b = u1;
    u u2 = new u("RUNNING", 1);
    c = u2;
    u u3 = new u("SUCCEEDED", 2);
    d = u3;
    u u4 = new u("FAILED", 3);
    e = u4;
    u u5 = new u("BLOCKED", 4);
    f = u5;
    u u6 = new u("CANCELLED", 5);
    g = u6;
    h = new u[] { u1, u2, u3, u4, u5, u6 };
  }
  
  public boolean b() {
    return (this == d || this == e || this == g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\wor\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */