package androidx.work;

import android.os.Build;

public final class n extends w {
  n(a parama) {
    super(parama.b, parama.c, parama.d);
  }
  
  public static n d(Class<? extends ListenableWorker> paramClass) {
    return (new a(paramClass)).b();
  }
  
  public static final class a extends w.a<a, n> {
    public a(Class<? extends ListenableWorker> param1Class) {
      super(param1Class);
      this.c.d = OverwritingInputMerger.class.getName();
    }
    
    n g() {
      if (!this.a || Build.VERSION.SDK_INT < 23 || !this.c.j.h())
        return new n(this); 
      throw new IllegalArgumentException("Cannot set backoff criteria on an idle mode job");
    }
    
    a h() {
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */