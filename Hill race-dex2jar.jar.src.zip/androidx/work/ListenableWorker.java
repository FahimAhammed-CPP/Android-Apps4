package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
  private Context mAppContext;
  
  private boolean mRunInForeground;
  
  private volatile boolean mStopped;
  
  private boolean mUsed;
  
  private WorkerParameters mWorkerParams;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.mAppContext = paramContext;
        this.mWorkerParams = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.mAppContext;
  }
  
  public Executor getBackgroundExecutor() {
    return this.mWorkerParams.a();
  }
  
  public ListenableFuture<g> getForegroundInfoAsync() {
    c c = c.s();
    c.p(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (ListenableFuture<g>)c;
  }
  
  public final UUID getId() {
    return this.mWorkerParams.c();
  }
  
  public final e getInputData() {
    return this.mWorkerParams.d();
  }
  
  public final Network getNetwork() {
    return this.mWorkerParams.e();
  }
  
  public final int getRunAttemptCount() {
    return this.mWorkerParams.g();
  }
  
  public final Set<String> getTags() {
    return this.mWorkerParams.h();
  }
  
  public c0.a getTaskExecutor() {
    return this.mWorkerParams.i();
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return this.mWorkerParams.j();
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return this.mWorkerParams.k();
  }
  
  public x getWorkerFactory() {
    return this.mWorkerParams.l();
  }
  
  public boolean isRunInForeground() {
    return this.mRunInForeground;
  }
  
  public final boolean isStopped() {
    return this.mStopped;
  }
  
  public final boolean isUsed() {
    return this.mUsed;
  }
  
  public void onStopped() {}
  
  public final ListenableFuture<Void> setForegroundAsync(g paramg) {
    this.mRunInForeground = true;
    return this.mWorkerParams.b().a(getApplicationContext(), getId(), paramg);
  }
  
  public ListenableFuture<Void> setProgressAsync(e parame) {
    return this.mWorkerParams.f().a(getApplicationContext(), getId(), parame);
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.mRunInForeground = paramBoolean;
  }
  
  public final void setUsed() {
    this.mUsed = true;
  }
  
  public abstract ListenableFuture<a> startWork();
  
  public final void stop() {
    this.mStopped = true;
    onStopped();
  }
  
  public static abstract class a {
    public static a a() {
      return new a();
    }
    
    public static a b() {
      return new b();
    }
    
    public static a c() {
      return new c();
    }
    
    public static a d(e param1e) {
      return new c(param1e);
    }
    
    public static final class a extends a {
      private final e a;
      
      public a() {
        this(e.c);
      }
      
      public a(e param2e) {
        this.a = param2e;
      }
      
      public e e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || a.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((a)param2Object).a);
      }
      
      public int hashCode() {
        return a.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failure {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    public static final class b extends a {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && b.class == param2Object.getClass()));
      }
      
      public int hashCode() {
        return b.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    public static final class c extends a {
      private final e a;
      
      public c() {
        this(e.c);
      }
      
      public c(e param2e) {
        this.a = param2e;
      }
      
      public e e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || c.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((c)param2Object).a);
      }
      
      public int hashCode() {
        return c.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Success {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  public static final class a extends a {
    private final e a;
    
    public a() {
      this(e.c);
    }
    
    public a(e param1e) {
      this.a = param1e;
    }
    
    public e e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || a.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((a)param1Object).a);
    }
    
    public int hashCode() {
      return a.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failure {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends a {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && b.class == param1Object.getClass()));
    }
    
    public int hashCode() {
      return b.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  public static final class c extends a {
    private final e a;
    
    public c() {
      this(e.c);
    }
    
    public c(e param1e) {
      this.a = param1e;
    }
    
    public e e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || c.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      return c.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Success {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */