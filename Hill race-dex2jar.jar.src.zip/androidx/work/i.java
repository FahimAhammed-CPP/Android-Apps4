package androidx.work;

public interface i {
  void a(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */