package androidx.work;

public enum a {
  b, c;
  
  static {
    a a1 = new a("EXPONENTIAL", 0);
    b = a1;
    a a2 = new a("LINEAR", 1);
    c = a2;
    d = new a[] { a1, a2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */