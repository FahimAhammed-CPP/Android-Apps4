package androidx.work;

import android.content.Context;

public abstract class x {
  private static final String a = l.f("WorkerFactory");
  
  public static x c() {
    return new a();
  }
  
  public abstract ListenableWorker a(Context paramContext, String paramString, WorkerParameters paramWorkerParameters);
  
  public final ListenableWorker b(Context paramContext, String paramString, WorkerParameters paramWorkerParameters) {
    ListenableWorker listenableWorker2 = a(paramContext, paramString, paramWorkerParameters);
    ListenableWorker listenableWorker1 = listenableWorker2;
    if (listenableWorker2 == null) {
      Class<? extends ListenableWorker> clazz = null;
      try {
      
      } finally {
        listenableWorker1 = null;
        l l = l.c();
        String str = a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid class: ");
        stringBuilder.append(paramString);
      } 
      listenableWorker1 = listenableWorker2;
      if (clazz != null)
        try {
          listenableWorker1 = clazz.getDeclaredConstructor(new Class[] { Context.class, WorkerParameters.class }).newInstance(new Object[] { paramContext, paramWorkerParameters });
        } finally {
          paramContext = null;
          l l = l.c();
          String str = a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Could not instantiate ");
          stringBuilder.append(paramString);
          l.b(str, stringBuilder.toString(), new Throwable[] { (Throwable)paramContext });
        }  
    } 
    if (listenableWorker1 != null) {
      if (!listenableWorker1.isUsed())
        return listenableWorker1; 
      throw new IllegalStateException(String.format("WorkerFactory (%s) returned an instance of a ListenableWorker (%s) which has already been invoked. createWorker() must always return a new instance of a ListenableWorker.", new Object[] { getClass().getName(), paramString }));
    } 
    return listenableWorker1;
  }
  
  class a extends x {
    public ListenableWorker a(Context param1Context, String param1String, WorkerParameters param1WorkerParameters) {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */