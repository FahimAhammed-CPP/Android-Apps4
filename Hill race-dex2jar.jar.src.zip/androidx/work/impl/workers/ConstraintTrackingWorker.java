package androidx.work.impl.workers;

import a0.p;
import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.utils.futures.c;
import androidx.work.l;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Collections;
import java.util.List;
import t.i;
import w.c;
import w.d;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  private static final String g = l.f("ConstraintTrkngWrkr");
  
  private WorkerParameters b;
  
  final Object c;
  
  volatile boolean d;
  
  c<ListenableWorker.a> e;
  
  private ListenableWorker f;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.b = paramWorkerParameters;
    this.c = new Object();
    this.d = false;
    this.e = c.s();
  }
  
  public WorkDatabase a() {
    return i.k(getApplicationContext()).o();
  }
  
  public void b(List<String> paramList) {
    l.c().a(g, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.c) {
      this.d = true;
      return;
    } 
  }
  
  void c() {
    this.e.o(ListenableWorker.a.a());
  }
  
  void d() {
    this.e.o(ListenableWorker.a.b());
  }
  
  void e() {
    String str = getInputData().i("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
    if (TextUtils.isEmpty(str)) {
      l.c().b(g, "No worker to delegate to.", new Throwable[0]);
      c();
      return;
    } 
    ListenableWorker listenableWorker = getWorkerFactory().b(getApplicationContext(), str, this.b);
    this.f = listenableWorker;
    if (listenableWorker == null) {
      l.c().a(g, "No worker to delegate to.", new Throwable[0]);
      c();
      return;
    } 
    p p = a().B().n(getId().toString());
    if (p == null) {
      c();
      return;
    } 
    d d = new d(getApplicationContext(), getTaskExecutor(), this);
    d.d(Collections.singletonList(p));
    if (d.c(getId().toString())) {
      l.c().a(g, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
      try {
        return;
      } finally {
        d = null;
        l l = l.c();
        null = g;
        l.a(null, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)d });
      } 
    } 
    l.c().a(g, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
    d();
  }
  
  public void f(List<String> paramList) {}
  
  public c0.a getTaskExecutor() {
    return i.k(getApplicationContext()).p();
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.f;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.f;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.f.stop(); 
  }
  
  public ListenableFuture<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (ListenableFuture<ListenableWorker.a>)this.e;
  }
  
  class a implements Runnable {
    a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      this.b.e();
    }
  }
  
  class b implements Runnable {
    b(ConstraintTrackingWorker this$0, ListenableFuture param1ListenableFuture) {}
    
    public void run() {
      synchronized (this.c.c) {
        if (this.c.d) {
          this.c.d();
        } else {
          this.c.e.q(this.b);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */