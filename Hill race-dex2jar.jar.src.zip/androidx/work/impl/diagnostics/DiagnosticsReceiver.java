package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import androidx.work.l;
import androidx.work.n;
import androidx.work.v;
import androidx.work.w;

public class DiagnosticsReceiver extends BroadcastReceiver {
  private static final String a = l.f("DiagnosticsRcvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    l.c().a(a, "Requesting diagnostics", new Throwable[0]);
    try {
      v.d(paramContext).b((w)n.d(DiagnosticsWorker.class));
      return;
    } catch (IllegalStateException illegalStateException) {
      l.c().b(a, "WorkManager is not initialized", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */