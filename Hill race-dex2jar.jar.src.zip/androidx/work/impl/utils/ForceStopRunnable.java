package androidx.work.impl.utils;

import a0.n;
import a0.p;
import a0.q;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.ApplicationExitInfo;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.os.Build;
import android.text.TextUtils;
import androidx.core.os.a;
import androidx.work.b;
import androidx.work.i;
import androidx.work.impl.WorkDatabase;
import androidx.work.l;
import androidx.work.u;
import b0.f;
import java.util.List;
import java.util.concurrent.TimeUnit;
import t.f;
import t.h;
import t.i;
import v.b;

public class ForceStopRunnable implements Runnable {
  private static final String e = l.f("ForceStopRunnable");
  
  private static final long f = TimeUnit.DAYS.toMillis(3650L);
  
  private final Context b;
  
  private final i c;
  
  private int d;
  
  public ForceStopRunnable(Context paramContext, i parami) {
    this.b = paramContext.getApplicationContext();
    this.c = parami;
    this.d = 0;
  }
  
  static Intent d(Context paramContext) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return intent;
  }
  
  private static PendingIntent e(Context paramContext, int paramInt) {
    return PendingIntent.getBroadcast(paramContext, -1, d(paramContext), paramInt);
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  static void h(Context paramContext) {
    int j;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (a.b()) {
      j = 167772160;
    } else {
      j = 134217728;
    } 
    PendingIntent pendingIntent = e(paramContext, j);
    long l = System.currentTimeMillis() + f;
    if (alarmManager != null) {
      if (Build.VERSION.SDK_INT >= 19) {
        alarmManager.setExact(0, l, pendingIntent);
        return;
      } 
      alarmManager.set(0, l, pendingIntent);
    } 
  }
  
  public boolean b() {
    boolean bool1;
    int j = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    if (j >= 23) {
      bool1 = b.i(this.b, this.c);
    } else {
      bool1 = false;
    } 
    WorkDatabase workDatabase = this.c.o();
    null = workDatabase.B();
    n n = workDatabase.A();
    workDatabase.c();
    try {
      List list = null.j();
      if (list != null && !list.isEmpty()) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 0)
        for (p p : list) {
          null.c(u.b, new String[] { p.a });
          null.d(p.a, -1L);
        }  
      n.c();
      workDatabase.r();
      workDatabase.g();
      return bool2;
    } finally {
      workDatabase.g();
    } 
  }
  
  public void c() {
    boolean bool = b();
    if (i()) {
      l.c().a(e, "Rescheduling Workers.", new Throwable[0]);
      this.c.s();
      this.c.l().c(false);
      return;
    } 
    if (f()) {
      l.c().a(e, "Application was force-stopped, rescheduling.", new Throwable[0]);
      this.c.s();
      return;
    } 
    if (bool) {
      l.c().a(e, "Found unfinished work, scheduling it.", new Throwable[0]);
      f.b(this.c.i(), this.c.o(), this.c.n());
    } 
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  public boolean f() {
    int j = 536870912;
    try {
      List<ApplicationExitInfo> list;
      if (a.b())
        j = 570425344; 
      PendingIntent pendingIntent = e(this.b, j);
      if (Build.VERSION.SDK_INT >= 30) {
        if (pendingIntent != null)
          pendingIntent.cancel(); 
        list = ((ActivityManager)this.b.getSystemService("activity")).getHistoricalProcessExitReasons(null, 0, 0);
        if (list != null && !list.isEmpty())
          for (j = 0;; j++) {
            if (j < list.size()) {
              if (((ApplicationExitInfo)list.get(j)).getReason() == 10)
                return true; 
            } else {
              return false;
            } 
          }  
      } else if (list == null) {
        h(this.b);
        return true;
      } 
      return false;
    } catch (SecurityException securityException) {
    
    } catch (IllegalArgumentException illegalArgumentException) {}
    l.c().h(e, "Ignoring exception", new Throwable[] { illegalArgumentException });
    return true;
  }
  
  public boolean g() {
    b b = this.c.i();
    if (TextUtils.isEmpty(b.c())) {
      l.c().a(e, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = f.b(this.b, b);
    l.c().a(e, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  boolean i() {
    return this.c.l().a();
  }
  
  public void j(long paramLong) {
    try {
      Thread.sleep(paramLong);
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public void run() {
    try {
      boolean bool = g();
      if (!bool)
        return; 
      while (true) {
        h.e(this.b);
        l.c().a(e, "Performing cleanup operations.", new Throwable[0]);
        try {
          c();
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
          IllegalStateException illegalStateException;
          int j = this.d + 1;
          this.d = j;
          if (j >= 3) {
            l l = l.c();
            String str = e;
            l.b(str, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { (Throwable)sQLiteCantOpenDatabaseException });
            illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)sQLiteCantOpenDatabaseException);
            i i1 = this.c.i().d();
            if (i1 != null) {
              l.c().a(str, "Routing exception to the specified exception handler", new Throwable[] { illegalStateException });
              i1.a(illegalStateException);
            } else {
              throw illegalStateException;
            } 
          } else {
            long l = j;
            l.c().a(e, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { illegalStateException });
            j(this.d * 300L);
            continue;
          } 
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        return;
      } 
    } finally {
      this.c.r();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    private static final String a = l.f("ForceStopRunnable$Rcvr");
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        l.c().g(a, "Rescheduling alarm that keeps track of force-stops.", new Throwable[0]);
        ForceStopRunnable.h(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */