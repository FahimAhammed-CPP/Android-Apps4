package androidx.work.impl.utils.futures;

import com.google.common.util.concurrent.ListenableFuture;

public final class c<V> extends a<V> {
  public static <V> c<V> s() {
    return new c<V>();
  }
  
  public boolean o(V paramV) {
    return super.o(paramV);
  }
  
  public boolean p(Throwable paramThrowable) {
    return super.p(paramThrowable);
  }
  
  public boolean q(ListenableFuture<? extends V> paramListenableFuture) {
    return super.q(paramListenableFuture);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\imp\\utils\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */