package androidx.work.impl.utils.futures;

import java.util.concurrent.Executor;

enum b implements Executor {
  b;
  
  static {
    b b1 = new b("INSTANCE", 0);
    b = b1;
    c = new b[] { b1 };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\imp\\utils\futures\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */