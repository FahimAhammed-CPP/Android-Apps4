package androidx.work.impl.background.systemalarm;

import a0.p;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.work.l;
import b0.j;
import b0.n;
import java.util.Collections;
import java.util.List;
import t.b;
import w.c;

public class d implements c, b, n.b {
  private static final String k = l.f("DelayMetCommandHandler");
  
  private final Context b;
  
  private final int c;
  
  private final String d;
  
  private final e e;
  
  private final w.d f;
  
  private final Object g;
  
  private int h;
  
  private PowerManager.WakeLock i;
  
  private boolean j;
  
  d(Context paramContext, int paramInt, String paramString, e parame) {
    this.b = paramContext;
    this.c = paramInt;
    this.e = parame;
    this.d = paramString;
    this.f = new w.d(paramContext, parame.f(), this);
    this.j = false;
    this.h = 0;
    this.g = new Object();
  }
  
  private void d() {
    synchronized (this.g) {
      this.f.e();
      this.e.h().c(this.d);
      PowerManager.WakeLock wakeLock = this.i;
      if (wakeLock != null && wakeLock.isHeld()) {
        l.c().a(k, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.i, this.d }), new Throwable[0]);
        this.i.release();
      } 
      return;
    } 
  }
  
  private void g() {
    synchronized (this.g) {
      if (this.h < 2) {
        Intent intent1;
        this.h = 2;
        l l = l.c();
        String str = k;
        l.a(str, String.format("Stopping work for WorkSpec %s", new Object[] { this.d }), new Throwable[0]);
        Intent intent2 = b.g(this.b, this.d);
        e e1 = this.e;
        e1.k(new e.b(e1, intent2, this.c));
        if (this.e.e().g(this.d)) {
          l.c().a(str, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.d }), new Throwable[0]);
          intent1 = b.f(this.b, this.d);
          e e2 = this.e;
          e2.k(new e.b(e2, intent1, this.c));
        } else {
          l.c().a((String)intent1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.d }), new Throwable[0]);
        } 
      } else {
        l.c().a(k, String.format("Already stopped work for %s", new Object[] { this.d }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public void a(String paramString) {
    l.c().a(k, String.format("Exceeded time limits on execution for %s", new Object[] { paramString }), new Throwable[0]);
    g();
  }
  
  public void b(List<String> paramList) {
    g();
  }
  
  public void c(String paramString, boolean paramBoolean) {
    l.c().a(k, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    d();
    if (paramBoolean) {
      Intent intent = b.f(this.b, this.d);
      e e1 = this.e;
      e1.k(new e.b(e1, intent, this.c));
    } 
    if (this.j) {
      Intent intent = b.a(this.b);
      e e1 = this.e;
      e1.k(new e.b(e1, intent, this.c));
    } 
  }
  
  void e() {
    this.i = j.b(this.b, String.format("%s (%s)", new Object[] { this.d, Integer.valueOf(this.c) }));
    l l = l.c();
    String str = k;
    l.a(str, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.i, this.d }), new Throwable[0]);
    this.i.acquire();
    p p = this.e.g().o().B().n(this.d);
    if (p == null) {
      g();
      return;
    } 
    boolean bool = p.b();
    this.j = bool;
    if (!bool) {
      l.c().a(str, String.format("No constraints for %s", new Object[] { this.d }), new Throwable[0]);
      f(Collections.singletonList(this.d));
      return;
    } 
    this.f.d(Collections.singletonList(p));
  }
  
  public void f(List<String> paramList) {
    if (!paramList.contains(this.d))
      return; 
    synchronized (this.g) {
      if (this.h == 0) {
        this.h = 1;
        l.c().a(k, String.format("onAllConstraintsMet for %s", new Object[] { this.d }), new Throwable[0]);
        if (this.e.e().j(this.d)) {
          this.e.h().b(this.d, 600000L, this);
        } else {
          d();
        } 
      } else {
        l.c().a(k, String.format("Already started work for %s", new Object[] { this.d }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */