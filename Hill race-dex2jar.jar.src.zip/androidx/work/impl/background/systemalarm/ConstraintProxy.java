package androidx.work.impl.background.systemalarm;

import a0.p;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.c;
import androidx.work.l;
import androidx.work.m;
import java.util.Iterator;
import java.util.List;

abstract class ConstraintProxy extends BroadcastReceiver {
  private static final String a = l.f("ConstraintProxy");
  
  static void a(Context paramContext, List<p> paramList) {
    boolean bool4;
    int j;
    boolean bool5;
    boolean bool6;
    Iterator<p> iterator = paramList.iterator();
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    int i = 0;
    while (true) {
      bool4 = bool3;
      bool5 = bool2;
      bool6 = bool1;
      j = i;
      if (iterator.hasNext()) {
        byte b;
        c c = ((p)iterator.next()).j;
        bool4 = bool3 | c.f();
        bool5 = bool2 | c.g();
        bool6 = bool1 | c.i();
        if (c.b() != m.b) {
          b = 1;
        } else {
          b = 0;
        } 
        j = i | b;
        bool3 = bool4;
        bool2 = bool5;
        bool1 = bool6;
        i = j;
        if (bool4) {
          bool3 = bool4;
          bool2 = bool5;
          bool1 = bool6;
          i = j;
          if (bool5) {
            bool3 = bool4;
            bool2 = bool5;
            bool1 = bool6;
            i = j;
            if (bool6) {
              bool3 = bool4;
              bool2 = bool5;
              bool1 = bool6;
              i = j;
              if (j != 0)
                break; 
            } 
          } 
        } 
        continue;
      } 
      break;
    } 
    paramContext.sendBroadcast(ConstraintProxyUpdateReceiver.a(paramContext, bool4, bool5, bool6, j));
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    l.c().a(a, String.format("onReceive : %s", new Object[] { paramIntent }), new Throwable[0]);
    paramContext.startService(b.a(paramContext));
  }
  
  public static class BatteryChargingProxy extends ConstraintProxy {}
  
  public static class BatteryNotLowProxy extends ConstraintProxy {}
  
  public static class NetworkStateProxy extends ConstraintProxy {}
  
  public static class StorageNotLowProxy extends ConstraintProxy {}
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */