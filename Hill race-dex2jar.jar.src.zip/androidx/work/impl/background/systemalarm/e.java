package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import androidx.work.l;
import b0.g;
import b0.j;
import b0.n;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import t.b;
import t.i;

public class e implements b {
  static final String l = l.f("SystemAlarmDispatcher");
  
  final Context b;
  
  private final c0.a c;
  
  private final n d;
  
  private final t.d e;
  
  private final i f;
  
  final b g;
  
  private final Handler h;
  
  final List<Intent> i;
  
  Intent j;
  
  private c k;
  
  e(Context paramContext) {
    this(paramContext, null, null);
  }
  
  e(Context paramContext, t.d paramd, i parami) {
    Context context = paramContext.getApplicationContext();
    this.b = context;
    this.g = new b(context);
    this.d = new n();
    if (parami == null)
      parami = i.k(paramContext); 
    this.f = parami;
    if (paramd == null)
      paramd = parami.m(); 
    this.e = paramd;
    this.c = parami.p();
    paramd.d(this);
    this.i = new ArrayList<Intent>();
    this.j = null;
    this.h = new Handler(Looper.getMainLooper());
  }
  
  private void b() {
    if (this.h.getLooper().getThread() == Thread.currentThread())
      return; 
    throw new IllegalStateException("Needs to be invoked on the main thread.");
  }
  
  private boolean i(String paramString) {
    b();
    synchronized (this.i) {
      Iterator<Intent> iterator = this.i.iterator();
      while (iterator.hasNext()) {
        if (paramString.equals(((Intent)iterator.next()).getAction()))
          return true; 
      } 
      return false;
    } 
  }
  
  private void l() {
    b();
    PowerManager.WakeLock wakeLock = j.b(this.b, "ProcessCommand");
    try {
      wakeLock.acquire();
      this.f.p().b(new a(this));
      return;
    } finally {
      wakeLock.release();
    } 
  }
  
  public boolean a(Intent paramIntent, int paramInt) {
    // Byte code:
    //   0: invokestatic c : ()Landroidx/work/l;
    //   3: astore #5
    //   5: getstatic androidx/work/impl/background/systemalarm/e.l : Ljava/lang/String;
    //   8: astore #4
    //   10: iconst_0
    //   11: istore_3
    //   12: aload #5
    //   14: aload #4
    //   16: ldc 'Adding command %s (%s)'
    //   18: iconst_2
    //   19: anewarray java/lang/Object
    //   22: dup
    //   23: iconst_0
    //   24: aload_1
    //   25: aastore
    //   26: dup
    //   27: iconst_1
    //   28: iload_2
    //   29: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   32: aastore
    //   33: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   36: iconst_0
    //   37: anewarray java/lang/Throwable
    //   40: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   43: aload_0
    //   44: invokespecial b : ()V
    //   47: aload_1
    //   48: invokevirtual getAction : ()Ljava/lang/String;
    //   51: astore #5
    //   53: aload #5
    //   55: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   58: ifeq -> 77
    //   61: invokestatic c : ()Landroidx/work/l;
    //   64: aload #4
    //   66: ldc 'Unknown command. Ignoring'
    //   68: iconst_0
    //   69: anewarray java/lang/Throwable
    //   72: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   75: iconst_0
    //   76: ireturn
    //   77: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   79: aload #5
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: ifeq -> 98
    //   87: aload_0
    //   88: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   90: invokespecial i : (Ljava/lang/String;)Z
    //   93: ifeq -> 98
    //   96: iconst_0
    //   97: ireturn
    //   98: aload_1
    //   99: ldc 'KEY_START_ID'
    //   101: iload_2
    //   102: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   105: pop
    //   106: aload_0
    //   107: getfield i : Ljava/util/List;
    //   110: astore #4
    //   112: aload #4
    //   114: monitorenter
    //   115: iload_3
    //   116: istore_2
    //   117: aload_0
    //   118: getfield i : Ljava/util/List;
    //   121: invokeinterface isEmpty : ()Z
    //   126: ifne -> 131
    //   129: iconst_1
    //   130: istore_2
    //   131: aload_0
    //   132: getfield i : Ljava/util/List;
    //   135: aload_1
    //   136: invokeinterface add : (Ljava/lang/Object;)Z
    //   141: pop
    //   142: iload_2
    //   143: ifne -> 150
    //   146: aload_0
    //   147: invokespecial l : ()V
    //   150: aload #4
    //   152: monitorexit
    //   153: iconst_1
    //   154: ireturn
    //   155: astore_1
    //   156: aload #4
    //   158: monitorexit
    //   159: aload_1
    //   160: athrow
    // Exception table:
    //   from	to	target	type
    //   117	129	155	finally
    //   131	142	155	finally
    //   146	150	155	finally
    //   150	153	155	finally
    //   156	159	155	finally
  }
  
  public void c(String paramString, boolean paramBoolean) {
    k(new b(this, b.d(this.b, paramString, paramBoolean), 0));
  }
  
  void d() {
    l l = l.c();
    null = l;
    l.a(null, "Checking if commands are complete.", new Throwable[0]);
    b();
    synchronized (this.i) {
      if (this.j != null) {
        l.c().a(null, String.format("Removing command %s", new Object[] { this.j }), new Throwable[0]);
        if (((Intent)this.i.remove(0)).equals(this.j)) {
          this.j = null;
        } else {
          throw new IllegalStateException("Dequeue-d command is not the first.");
        } 
      } 
      g g = this.c.getBackgroundExecutor();
      if (!this.g.o() && this.i.isEmpty() && !g.a()) {
        l.c().a(null, "No more commands & intents.", new Throwable[0]);
        c c1 = this.k;
        if (c1 != null)
          c1.a(); 
      } else if (!this.i.isEmpty()) {
        l();
      } 
      return;
    } 
  }
  
  t.d e() {
    return this.e;
  }
  
  c0.a f() {
    return this.c;
  }
  
  i g() {
    return this.f;
  }
  
  n h() {
    return this.d;
  }
  
  void j() {
    l.c().a(l, "Destroying SystemAlarmDispatcher", new Throwable[0]);
    this.e.i(this);
    this.d.a();
    this.k = null;
  }
  
  void k(Runnable paramRunnable) {
    this.h.post(paramRunnable);
  }
  
  void m(c paramc) {
    if (this.k != null) {
      l.c().b(l, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    this.k = paramc;
  }
  
  class a implements Runnable {
    a(e this$0) {}
    
    public void run() {
      List<Intent> list;
      e e1;
      synchronized (this.b.i) {
        e.d d;
        e e2 = this.b;
        e2.j = e2.i.get(0);
        Intent intent = this.b.j;
        if (intent != null) {
          String str1 = intent.getAction();
          int i = this.b.j.getIntExtra("KEY_START_ID", 0);
          l l = l.c();
          String str2 = e.l;
          l.a(str2, String.format("Processing command %s, %s", new Object[] { this.b.j, Integer.valueOf(i) }), new Throwable[0]);
          PowerManager.WakeLock wakeLock = j.b(this.b.b, String.format("%s (%s)", new Object[] { str1, Integer.valueOf(i) }));
          try {
            l.c().a(str2, String.format("Acquiring operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.acquire();
            e e3 = this.b;
            e3.g.p(e3.j, i, e3);
            l.c().a(str2, String.format("Releasing operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.release();
            e1 = this.b;
          } finally {
            str2 = null;
          } 
        } else {
          return;
        } 
        e1.k(d);
        return;
      } 
    }
  }
  
  static class b implements Runnable {
    private final e b;
    
    private final Intent c;
    
    private final int d;
    
    b(e param1e, Intent param1Intent, int param1Int) {
      this.b = param1e;
      this.c = param1Intent;
      this.d = param1Int;
    }
    
    public void run() {
      this.b.a(this.c, this.d);
    }
  }
  
  static interface c {
    void a();
  }
  
  static class d implements Runnable {
    private final e b;
    
    d(e param1e) {
      this.b = param1e;
    }
    
    public void run() {
      this.b.d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */