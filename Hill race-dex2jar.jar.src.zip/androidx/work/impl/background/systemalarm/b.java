package androidx.work.impl.background.systemalarm;

import a0.p;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import androidx.work.l;
import java.util.HashMap;
import java.util.Map;
import t.b;

public class b implements b {
  private static final String e = l.f("CommandHandler");
  
  private final Context b;
  
  private final Map<String, b> c;
  
  private final Object d;
  
  b(Context paramContext) {
    this.b = paramContext;
    this.c = new HashMap<String, b>();
    this.d = new Object();
  }
  
  static Intent a(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_CONSTRAINTS_CHANGED");
    return intent;
  }
  
  static Intent b(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_DELAY_MET");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  static Intent d(Context paramContext, String paramString, boolean paramBoolean) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_EXECUTION_COMPLETED");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NEEDS_RESCHEDULE", paramBoolean);
    return intent;
  }
  
  static Intent e(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_RESCHEDULE");
    return intent;
  }
  
  static Intent f(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_SCHEDULE_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  static Intent g(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_STOP_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  private void h(Intent paramIntent, int paramInt, e parame) {
    l.c().a(e, String.format("Handling constraints changed %s", new Object[] { paramIntent }), new Throwable[0]);
    (new c(this.b, paramInt, parame)).a();
  }
  
  private void i(Intent paramIntent, int paramInt, e parame) {
    Bundle bundle = paramIntent.getExtras();
    synchronized (this.d) {
      String str1 = bundle.getString("KEY_WORKSPEC_ID");
      l l = l.c();
      String str2 = e;
      l.a(str2, String.format("Handing delay met for %s", new Object[] { str1 }), new Throwable[0]);
      if (!this.c.containsKey(str1)) {
        d d = new d(this.b, paramInt, str1, parame);
        this.c.put(str1, d);
        d.e();
      } else {
        l.c().a(str2, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", new Object[] { str1 }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  private void j(Intent paramIntent, int paramInt) {
    Bundle bundle = paramIntent.getExtras();
    String str = bundle.getString("KEY_WORKSPEC_ID");
    boolean bool = bundle.getBoolean("KEY_NEEDS_RESCHEDULE");
    l.c().a(e, String.format("Handling onExecutionCompleted %s, %s", new Object[] { paramIntent, Integer.valueOf(paramInt) }), new Throwable[0]);
    c(str, bool);
  }
  
  private void k(Intent paramIntent, int paramInt, e parame) {
    l.c().a(e, String.format("Handling reschedule %s, %s", new Object[] { paramIntent, Integer.valueOf(paramInt) }), new Throwable[0]);
    parame.g().s();
  }
  
  private void l(Intent paramIntent, int paramInt, e parame) {
    null = paramIntent.getExtras().getString("KEY_WORKSPEC_ID");
    l l = l.c();
    String str = e;
    l.a(str, String.format("Handling schedule work for %s", new Object[] { null }), new Throwable[0]);
    WorkDatabase workDatabase = parame.g().o();
    workDatabase.c();
    try {
      l l1;
      StringBuilder stringBuilder;
      p p = workDatabase.B().n(null);
      if (p == null) {
        l1 = l.c();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping scheduling ");
        stringBuilder.append(null);
        stringBuilder.append(" because it's no longer in the DB");
        l1.h(str, stringBuilder.toString(), new Throwable[0]);
        return;
      } 
      if (((p)stringBuilder).b.b()) {
        l1 = l.c();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping scheduling ");
        stringBuilder.append(null);
        stringBuilder.append("because it is finished.");
        l1.h(str, stringBuilder.toString(), new Throwable[0]);
        return;
      } 
      long l2 = stringBuilder.a();
      if (!stringBuilder.b()) {
        l.c().a(str, String.format("Setting up Alarms for %s at %s", new Object[] { null, Long.valueOf(l2) }), new Throwable[0]);
        a.c(this.b, l1.g(), null, l2);
      } else {
        l.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", new Object[] { null, Long.valueOf(l2) }), new Throwable[0]);
        a.c(this.b, l1.g(), null, l2);
        l1.k(new e.b((e)l1, a(this.b), paramInt));
      } 
      workDatabase.r();
      return;
    } finally {
      workDatabase.g();
    } 
  }
  
  private void m(Intent paramIntent, e parame) {
    String str = paramIntent.getExtras().getString("KEY_WORKSPEC_ID");
    l.c().a(e, String.format("Handing stopWork work for %s", new Object[] { str }), new Throwable[0]);
    parame.g().x(str);
    a.a(this.b, parame.g(), str);
    parame.c(str, false);
  }
  
  private static boolean n(Bundle paramBundle, String... paramVarArgs) {
    if (paramBundle != null) {
      if (paramBundle.isEmpty())
        return false; 
      int j = paramVarArgs.length;
      for (int i = 0; i < j; i++) {
        if (paramBundle.get(paramVarArgs[i]) == null)
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public void c(String paramString, boolean paramBoolean) {
    synchronized (this.d) {
      b b1 = this.c.remove(paramString);
      if (b1 != null)
        b1.c(paramString, paramBoolean); 
      return;
    } 
  }
  
  boolean o() {
    synchronized (this.d) {
      if (!this.c.isEmpty())
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  void p(Intent paramIntent, int paramInt, e parame) {
    String str = paramIntent.getAction();
    if ("ACTION_CONSTRAINTS_CHANGED".equals(str)) {
      h(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_RESCHEDULE".equals(str)) {
      k(paramIntent, paramInt, parame);
      return;
    } 
    if (!n(paramIntent.getExtras(), new String[] { "KEY_WORKSPEC_ID" })) {
      l.c().b(e, String.format("Invalid request for %s, requires %s.", new Object[] { str, "KEY_WORKSPEC_ID" }), new Throwable[0]);
      return;
    } 
    if ("ACTION_SCHEDULE_WORK".equals(str)) {
      l(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_DELAY_MET".equals(str)) {
      i(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_STOP_WORK".equals(str)) {
      m(paramIntent, parame);
      return;
    } 
    if ("ACTION_EXECUTION_COMPLETED".equals(str)) {
      j(paramIntent, paramInt);
      return;
    } 
    l.c().h(e, String.format("Ignoring intent %s", new Object[] { paramIntent }), new Throwable[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */