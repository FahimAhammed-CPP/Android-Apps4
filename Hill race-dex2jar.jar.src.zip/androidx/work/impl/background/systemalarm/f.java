package androidx.work.impl.background.systemalarm;

import a0.p;
import android.content.Context;
import android.content.Intent;
import androidx.work.l;
import t.e;

public class f implements e {
  private static final String c = l.f("SystemAlarmScheduler");
  
  private final Context b;
  
  public f(Context paramContext) {
    this.b = paramContext.getApplicationContext();
  }
  
  private void b(p paramp) {
    l.c().a(c, String.format("Scheduling work with workSpecId %s", new Object[] { paramp.a }), new Throwable[0]);
    Intent intent = b.f(this.b, paramp.a);
    this.b.startService(intent);
  }
  
  public boolean a() {
    return true;
  }
  
  public void d(String paramString) {
    Intent intent = b.g(this.b, paramString);
    this.b.startService(intent);
  }
  
  public void e(p... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++)
      b(paramVarArgs[i]); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */