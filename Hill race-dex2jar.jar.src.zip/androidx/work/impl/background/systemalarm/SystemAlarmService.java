package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import androidx.lifecycle.m;
import androidx.work.l;
import b0.j;

public class SystemAlarmService extends m implements e.c {
  private static final String e = l.f("SystemAlarmService");
  
  private e c;
  
  private boolean d;
  
  private void e() {
    e e1 = new e((Context)this);
    this.c = e1;
    e1.m(this);
  }
  
  public void a() {
    this.d = true;
    l.c().a(e, "All commands completed in dispatcher", new Throwable[0]);
    j.a();
    stopSelf();
  }
  
  public void onCreate() {
    super.onCreate();
    e();
    this.d = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.d = true;
    this.c.j();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.d) {
      l.c().d(e, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.c.j();
      e();
      this.d = false;
    } 
    if (paramIntent != null)
      this.c.a(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */