package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import androidx.work.l;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import t.b;
import t.i;

public class SystemJobService extends JobService implements b {
  private static final String d = l.f("SystemJobService");
  
  private i b;
  
  private final Map<String, JobParameters> c = new HashMap<String, JobParameters>();
  
  private static String a(JobParameters paramJobParameters) {
    try {
      PersistableBundle persistableBundle = paramJobParameters.getExtras();
      if (persistableBundle != null && persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
        return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
    } catch (NullPointerException nullPointerException) {}
    return null;
  }
  
  public void c(String paramString, boolean paramBoolean) {
    l.c().a(d, String.format("%s executed on JobScheduler", new Object[] { paramString }), new Throwable[0]);
    synchronized (this.c) {
      JobParameters jobParameters = this.c.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    try {
      i i1 = i.k(getApplicationContext());
      this.b = i1;
      i1.m().d(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        l.c().h(d, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public void onDestroy() {
    super.onDestroy();
    i i1 = this.b;
    if (i1 != null)
      i1.m().i(this); 
  }
  
  public boolean onStartJob(JobParameters paramJobParameters) {
    Map<String, JobParameters> map;
    WorkerParameters.a a;
    if (this.b == null) {
      l.c().a(d, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      jobFinished(paramJobParameters, true);
      return false;
    } 
    String str = a(paramJobParameters);
    if (TextUtils.isEmpty(str)) {
      l.c().b(d, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    synchronized (this.c) {
      if (this.c.containsKey(str)) {
        l.c().a(d, String.format("Job is already being executed by SystemJobService: %s", new Object[] { str }), new Throwable[0]);
        return false;
      } 
      l.c().a(d, String.format("onStartJob for %s", new Object[] { str }), new Throwable[0]);
      this.c.put(str, paramJobParameters);
      map = null;
      int j = Build.VERSION.SDK_INT;
      if (j >= 24) {
        WorkerParameters.a a1 = new WorkerParameters.a();
        if (paramJobParameters.getTriggeredContentUris() != null)
          a1.b = Arrays.asList(paramJobParameters.getTriggeredContentUris()); 
        if (paramJobParameters.getTriggeredContentAuthorities() != null)
          a1.a = Arrays.asList(paramJobParameters.getTriggeredContentAuthorities()); 
        a = a1;
        if (j >= 28) {
          a1.c = paramJobParameters.getNetwork();
          a = a1;
        } 
      } 
      this.b.v(str, a);
      return true;
    } 
  }
  
  public boolean onStopJob(JobParameters paramJobParameters) {
    if (this.b == null) {
      l.c().a(d, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      return true;
    } 
    null = a(paramJobParameters);
    if (TextUtils.isEmpty(null)) {
      l.c().b(d, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    l.c().a(d, String.format("onStopJob for %s", new Object[] { null }), new Throwable[0]);
    synchronized (this.c) {
      this.c.remove(null);
      this.b.x(null);
      return this.b.m().f(null) ^ true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */