package androidx.work.impl;

import android.content.Context;
import android.os.Build;

public class a {
  public static k.a a = new a(1, 2);
  
  public static k.a b = new b(3, 4);
  
  public static k.a c = new c(4, 5);
  
  public static k.a d = new d(6, 7);
  
  public static k.a e = new e(7, 8);
  
  public static k.a f = new f(8, 9);
  
  public static k.a g = new g(11, 12);
  
  class a extends k.a {
    a(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.F("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
      param1b.F("DROP TABLE IF EXISTS alarmInfo");
      param1b.F("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
    }
  }
  
  class b extends k.a {
    b(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      if (Build.VERSION.SDK_INT >= 23)
        param1b.F("UPDATE workspec SET schedule_requested_at=0 WHERE state NOT IN (2, 3, 5) AND schedule_requested_at=-1 AND interval_duration<>0"); 
    }
  }
  
  class c extends k.a {
    c(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
      param1b.F("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
    }
  }
  
  class d extends k.a {
    d(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
    }
  }
  
  class e extends k.a {
    e(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)");
    }
  }
  
  class f extends k.a {
    f(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  class g extends k.a {
    g(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(m.b param1b) {
      param1b.F("ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  public static class h extends k.a {
    final Context c;
    
    public h(Context param1Context, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = param1Context;
    }
    
    public void a(m.b param1b) {
      if (this.b >= 10) {
        param1b.S("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Integer.valueOf(1) });
        return;
      } 
      this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
    }
  }
  
  public static class i extends k.a {
    final Context c;
    
    public i(Context param1Context) {
      super(9, 10);
      this.c = param1Context;
    }
    
    public void a(m.b param1b) {
      param1b.F("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
      b0.e.b(this.c, param1b);
      b0.c.a(this.c, param1b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */