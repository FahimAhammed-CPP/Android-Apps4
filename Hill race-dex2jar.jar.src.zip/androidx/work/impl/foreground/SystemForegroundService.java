package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.m;
import androidx.work.l;

public class SystemForegroundService extends m implements a.b {
  private static final String g = l.f("SystemFgService");
  
  private static SystemForegroundService h = null;
  
  private Handler c;
  
  private boolean d;
  
  a e;
  
  NotificationManager f;
  
  private void e() {
    this.c = new Handler(Looper.getMainLooper());
    this.f = (NotificationManager)getApplicationContext().getSystemService("notification");
    a a1 = new a(getApplicationContext());
    this.e = a1;
    a1.m(this);
  }
  
  public void b(int paramInt1, int paramInt2, Notification paramNotification) {
    this.c.post(new a(this, paramInt1, paramNotification, paramInt2));
  }
  
  public void c(int paramInt, Notification paramNotification) {
    this.c.post(new b(this, paramInt, paramNotification));
  }
  
  public void d(int paramInt) {
    this.c.post(new c(this, paramInt));
  }
  
  public void onCreate() {
    super.onCreate();
    h = this;
    e();
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.e.k();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.d) {
      l.c().d(g, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
      this.e.k();
      e();
      this.d = false;
    } 
    if (paramIntent != null)
      this.e.l(paramIntent); 
    return 3;
  }
  
  public void stop() {
    this.d = true;
    l.c().a(g, "All commands completed.", new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 26)
      stopForeground(true); 
    h = null;
    stopSelf();
  }
  
  class a implements Runnable {
    a(SystemForegroundService this$0, int param1Int1, Notification param1Notification, int param1Int2) {}
    
    public void run() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.e.startForeground(this.b, this.c, this.d);
        return;
      } 
      this.e.startForeground(this.b, this.c);
    }
  }
  
  class b implements Runnable {
    b(SystemForegroundService this$0, int param1Int, Notification param1Notification) {}
    
    public void run() {
      this.d.f.notify(this.b, this.c);
    }
  }
  
  class c implements Runnable {
    c(SystemForegroundService this$0, int param1Int) {}
    
    public void run() {
      this.c.f.cancel(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */