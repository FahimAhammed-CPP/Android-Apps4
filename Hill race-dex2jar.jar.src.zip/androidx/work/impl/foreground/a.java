package androidx.work.impl.foreground;

import a0.p;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.work.g;
import androidx.work.impl.WorkDatabase;
import androidx.work.l;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import t.b;
import t.i;
import w.c;
import w.d;

public class a implements c, b {
  static final String l = l.f("SystemFgDispatcher");
  
  private Context b;
  
  private i c;
  
  private final c0.a d;
  
  final Object e;
  
  String f;
  
  final Map<String, g> g;
  
  final Map<String, p> h;
  
  final Set<p> i;
  
  final d j;
  
  private b k;
  
  a(Context paramContext) {
    this.b = paramContext;
    this.e = new Object();
    i i1 = i.k(paramContext);
    this.c = i1;
    c0.a a1 = i1.p();
    this.d = a1;
    this.f = null;
    this.g = new LinkedHashMap<String, g>();
    this.i = new HashSet<p>();
    this.h = new HashMap<String, p>();
    this.j = new d(this.b, a1, this);
    this.c.m().d(this);
  }
  
  public static Intent a(Context paramContext, String paramString, g paramg) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_NOTIFY");
    intent.putExtra("KEY_NOTIFICATION_ID", paramg.c());
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramg.a());
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramg.b());
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent d(Context paramContext, String paramString, g paramg) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_START_FOREGROUND");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NOTIFICATION_ID", paramg.c());
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramg.a());
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramg.b());
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent e(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_STOP_FOREGROUND");
    return intent;
  }
  
  private void g(Intent paramIntent) {
    l.c().d(l, String.format("Stopping foreground work for %s", new Object[] { paramIntent }), new Throwable[0]);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    if (str != null && !TextUtils.isEmpty(str))
      this.c.f(UUID.fromString(str)); 
  }
  
  private void h(Intent paramIntent) {
    int j = 0;
    int k = paramIntent.getIntExtra("KEY_NOTIFICATION_ID", 0);
    int m = paramIntent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    Notification notification = (Notification)paramIntent.getParcelableExtra("KEY_NOTIFICATION");
    l.c().a(l, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", new Object[] { Integer.valueOf(k), str, Integer.valueOf(m) }), new Throwable[0]);
    if (notification != null && this.k != null) {
      g g = new g(k, notification, m);
      this.g.put(str, g);
      if (TextUtils.isEmpty(this.f)) {
        this.f = str;
        this.k.b(k, m, notification);
        return;
      } 
      this.k.c(k, notification);
      if (m != 0 && Build.VERSION.SDK_INT >= 29) {
        Iterator<Map.Entry> iterator = this.g.entrySet().iterator();
        while (iterator.hasNext())
          j |= ((g)((Map.Entry)iterator.next()).getValue()).a(); 
        g g1 = this.g.get(this.f);
        if (g1 != null)
          this.k.b(g1.c(), j, g1.b()); 
      } 
    } 
  }
  
  private void i(Intent paramIntent) {
    l.c().d(l, String.format("Started foreground service %s", new Object[] { paramIntent }), new Throwable[0]);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    WorkDatabase workDatabase = this.c.o();
    this.d.b(new a(this, workDatabase, str));
  }
  
  public void b(List<String> paramList) {
    if (!paramList.isEmpty())
      for (String str : paramList) {
        l.c().a(l, String.format("Constraints unmet for WorkSpec %s", new Object[] { str }), new Throwable[0]);
        this.c.w(str);
      }  
  }
  
  public void c(String paramString, boolean paramBoolean) {
    synchronized (this.e) {
      p p = this.h.remove(paramString);
      if (p != null) {
        paramBoolean = this.i.remove(p);
      } else {
        paramBoolean = false;
      } 
      if (paramBoolean)
        this.j.d(this.i); 
      g g = this.g.remove(paramString);
      if (paramString.equals(this.f) && this.g.size() > 0) {
        Iterator<Map.Entry> iterator = this.g.entrySet().iterator();
        for (null = iterator.next(); iterator.hasNext(); null = iterator.next());
        this.f = (String)null.getKey();
        if (this.k != null) {
          null = null.getValue();
          this.k.b(null.c(), null.a(), null.b());
          this.k.d(null.c());
        } 
      } 
      null = this.k;
      if (g != null && null != null) {
        l.c().a(l, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", new Object[] { Integer.valueOf(g.c()), paramString, Integer.valueOf(g.a()) }), new Throwable[0]);
        null.d(g.c());
      } 
      return;
    } 
  }
  
  public void f(List<String> paramList) {}
  
  void j(Intent paramIntent) {
    l.c().d(l, "Stopping foreground service", new Throwable[0]);
    b b1 = this.k;
    if (b1 != null)
      b1.stop(); 
  }
  
  void k() {
    this.k = null;
    synchronized (this.e) {
      this.j.e();
      this.c.m().i(this);
      return;
    } 
  }
  
  void l(Intent paramIntent) {
    String str = paramIntent.getAction();
    if ("ACTION_START_FOREGROUND".equals(str)) {
      i(paramIntent);
      h(paramIntent);
      return;
    } 
    if ("ACTION_NOTIFY".equals(str)) {
      h(paramIntent);
      return;
    } 
    if ("ACTION_CANCEL_WORK".equals(str)) {
      g(paramIntent);
      return;
    } 
    if ("ACTION_STOP_FOREGROUND".equals(str))
      j(paramIntent); 
  }
  
  void m(b paramb) {
    if (this.k != null) {
      l.c().b(l, "A callback already exists.", new Throwable[0]);
      return;
    } 
    this.k = paramb;
  }
  
  class a implements Runnable {
    a(a this$0, WorkDatabase param1WorkDatabase, String param1String) {}
    
    public void run() {
      p p = this.b.B().n(this.c);
      if (p != null && p.b())
        synchronized (this.d.e) {
          this.d.h.put(this.c, p);
          this.d.i.add(p);
          a a1 = this.d;
          a1.j.d(a1.i);
          return;
        }  
    }
  }
  
  static interface b {
    void b(int param1Int1, int param1Int2, Notification param1Notification);
    
    void c(int param1Int, Notification param1Notification);
    
    void d(int param1Int);
    
    void stop();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\foreground\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */