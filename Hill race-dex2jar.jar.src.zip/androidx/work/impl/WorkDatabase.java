package androidx.work.impl;

import a0.e;
import a0.h;
import a0.k;
import a0.n;
import a0.q;
import a0.t;
import android.content.Context;
import androidx.room.g;
import androidx.room.h;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import m.c;
import n.c;
import t.h;

public abstract class WorkDatabase extends h {
  private static final long l = TimeUnit.DAYS.toMillis(1L);
  
  public static WorkDatabase s(Context paramContext, Executor paramExecutor, boolean paramBoolean) {
    h.a a;
    if (paramBoolean) {
      a = g.c(paramContext, WorkDatabase.class).c();
    } else {
      a = g.a(paramContext, WorkDatabase.class, h.d());
      a.f(new a(paramContext));
    } 
    return (WorkDatabase)a.g(paramExecutor).a(u()).b(new k.a[] { a.a }).b(new k.a[] { new a.h(paramContext, 2, 3) }).b(new k.a[] { a.b }).b(new k.a[] { a.c }).b(new k.a[] { new a.h(paramContext, 5, 6) }).b(new k.a[] { a.d }).b(new k.a[] { a.e }).b(new k.a[] { a.f }).b(new k.a[] { new a.i(paramContext) }).b(new k.a[] { new a.h(paramContext, 10, 11) }).b(new k.a[] { a.g }).e().d();
  }
  
  static h.b u() {
    return new b();
  }
  
  static long v() {
    return System.currentTimeMillis() - l;
  }
  
  static String w() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DELETE FROM workspec WHERE state IN (2, 3, 5) AND (period_start_time + minimum_retention_duration) < ");
    stringBuilder.append(v());
    stringBuilder.append(" AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))");
    return stringBuilder.toString();
  }
  
  public abstract n A();
  
  public abstract q B();
  
  public abstract t C();
  
  public abstract a0.b t();
  
  public abstract e x();
  
  public abstract h y();
  
  public abstract k z();
  
  class a implements c.c {
    a(WorkDatabase this$0) {}
    
    public c a(c.b param1b) {
      c.b.a a1 = c.b.a(this.a);
      a1.c(param1b.b).b(param1b.c).d(true);
      return (new c()).a(a1.a());
    }
  }
  
  class b extends h.b {
    public void c(m.b param1b) {
      super.c(param1b);
      param1b.D();
      try {
        param1b.F(WorkDatabase.w());
        param1b.Q();
        return;
      } finally {
        param1b.Y();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */