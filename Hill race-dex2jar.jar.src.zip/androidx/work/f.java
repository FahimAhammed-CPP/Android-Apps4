package androidx.work;

public enum f {
  b, c, d, e;
  
  static {
    f f1 = new f("REPLACE", 0);
    b = f1;
    f f2 = new f("KEEP", 1);
    c = f2;
    f f3 = new f("APPEND", 2);
    d = f3;
    f f4 = new f("APPEND_OR_REPLACE", 3);
    e = f4;
    f = new f[] { f1, f2, f3, f4 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */