package androidx.work;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class OverwritingInputMerger extends j {
  public e b(List<e> paramList) {
    e.a a = new e.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<e> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(((e)iterator.next()).h()); 
    a.d((Map)hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */