package androidx.work;

import java.util.List;

public abstract class j {
  private static final String a = l.f("InputMerger");
  
  public static j a(String paramString) {
    try {
      return (j)Class.forName(paramString).newInstance();
    } catch (Exception exception) {
      l l = l.c();
      String str = a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Trouble instantiating + ");
      stringBuilder.append(paramString);
      l.b(str, stringBuilder.toString(), new Throwable[] { exception });
      return null;
    } 
  }
  
  public abstract e b(List<e> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */