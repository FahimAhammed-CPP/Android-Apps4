package androidx.work;

import android.net.Network;
import android.net.Uri;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters {
  private UUID a;
  
  private e b;
  
  private Set<String> c;
  
  private a d;
  
  private int e;
  
  private Executor f;
  
  private c0.a g;
  
  private x h;
  
  private q i;
  
  private h j;
  
  public WorkerParameters(UUID paramUUID, e parame, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, c0.a parama1, x paramx, q paramq, h paramh) {
    this.a = paramUUID;
    this.b = parame;
    this.c = new HashSet<String>(paramCollection);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutor;
    this.g = parama1;
    this.h = paramx;
    this.i = paramq;
    this.j = paramh;
  }
  
  public Executor a() {
    return this.f;
  }
  
  public h b() {
    return this.j;
  }
  
  public UUID c() {
    return this.a;
  }
  
  public e d() {
    return this.b;
  }
  
  public Network e() {
    return this.d.c;
  }
  
  public q f() {
    return this.i;
  }
  
  public int g() {
    return this.e;
  }
  
  public Set<String> h() {
    return this.c;
  }
  
  public c0.a i() {
    return this.g;
  }
  
  public List<String> j() {
    return this.d.a;
  }
  
  public List<Uri> k() {
    return this.d.b;
  }
  
  public x l() {
    return this.h;
  }
  
  public static class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */