package androidx.work;

import a0.p;
import android.os.Build;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public abstract class w {
  private UUID a;
  
  private p b;
  
  private Set<String> c;
  
  protected w(UUID paramUUID, p paramp, Set<String> paramSet) {
    this.a = paramUUID;
    this.b = paramp;
    this.c = paramSet;
  }
  
  public String a() {
    return this.a.toString();
  }
  
  public Set<String> b() {
    return this.c;
  }
  
  public p c() {
    return this.b;
  }
  
  public static abstract class a<B extends a<?, ?>, W extends w> {
    boolean a = false;
    
    UUID b = UUID.randomUUID();
    
    p c;
    
    Set<String> d = new HashSet<String>();
    
    Class<? extends ListenableWorker> e;
    
    a(Class<? extends ListenableWorker> param1Class) {
      this.e = param1Class;
      this.c = new p(this.b.toString(), param1Class.getName());
      a(param1Class.getName());
    }
    
    public final B a(String param1String) {
      this.d.add(param1String);
      return d();
    }
    
    public final W b() {
      W w = c();
      c c = this.c.j;
      int i = Build.VERSION.SDK_INT;
      if ((i >= 24 && c.e()) || c.f() || c.g() || (i >= 23 && c.h())) {
        i = 1;
      } else {
        i = 0;
      } 
      if (!this.c.q || i == 0) {
        this.b = UUID.randomUUID();
        p p1 = new p(this.c);
        this.c = p1;
        p1.a = this.b.toString();
        return w;
      } 
      throw new IllegalArgumentException("Expedited jobs only support network and storage constraints");
    }
    
    abstract W c();
    
    abstract B d();
    
    public final B e(c param1c) {
      this.c.j = param1c;
      return d();
    }
    
    public final B f(e param1e) {
      this.c.e = param1e;
      return d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */