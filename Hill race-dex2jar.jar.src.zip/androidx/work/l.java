package androidx.work;

import android.util.Log;

public abstract class l {
  private static l a;
  
  private static final int b = 20;
  
  public l(int paramInt) {}
  
  public static l c() {
    // Byte code:
    //   0: ldc androidx/work/l
    //   2: monitorenter
    //   3: getstatic androidx/work/l.a : Landroidx/work/l;
    //   6: ifnonnull -> 20
    //   9: new androidx/work/l$a
    //   12: dup
    //   13: iconst_3
    //   14: invokespecial <init> : (I)V
    //   17: putstatic androidx/work/l.a : Landroidx/work/l;
    //   20: getstatic androidx/work/l.a : Landroidx/work/l;
    //   23: astore_0
    //   24: ldc androidx/work/l
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc androidx/work/l
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	24	29	finally
  }
  
  public static void e(l paraml) {
    // Byte code:
    //   0: ldc androidx/work/l
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic androidx/work/l.a : Landroidx/work/l;
    //   7: ldc androidx/work/l
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc androidx/work/l
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static String f(String paramString) {
    int i = paramString.length();
    StringBuilder stringBuilder = new StringBuilder(23);
    stringBuilder.append("WM-");
    int j = b;
    if (i >= j) {
      stringBuilder.append(paramString.substring(0, j));
    } else {
      stringBuilder.append(paramString);
    } 
    return stringBuilder.toString();
  }
  
  public abstract void a(String paramString1, String paramString2, Throwable... paramVarArgs);
  
  public abstract void b(String paramString1, String paramString2, Throwable... paramVarArgs);
  
  public abstract void d(String paramString1, String paramString2, Throwable... paramVarArgs);
  
  public abstract void g(String paramString1, String paramString2, Throwable... paramVarArgs);
  
  public abstract void h(String paramString1, String paramString2, Throwable... paramVarArgs);
  
  public static class a extends l {
    private int c;
    
    public a(int param1Int) {
      super(param1Int);
      this.c = param1Int;
    }
    
    public void a(String param1String1, String param1String2, Throwable... param1VarArgs) {
      if (this.c <= 3) {
        if (param1VarArgs != null && param1VarArgs.length >= 1) {
          Log.d(param1String1, param1String2, param1VarArgs[0]);
          return;
        } 
        Log.d(param1String1, param1String2);
      } 
    }
    
    public void b(String param1String1, String param1String2, Throwable... param1VarArgs) {
      if (this.c <= 6) {
        if (param1VarArgs != null && param1VarArgs.length >= 1) {
          Log.e(param1String1, param1String2, param1VarArgs[0]);
          return;
        } 
        Log.e(param1String1, param1String2);
      } 
    }
    
    public void d(String param1String1, String param1String2, Throwable... param1VarArgs) {
      if (this.c <= 4) {
        if (param1VarArgs != null && param1VarArgs.length >= 1) {
          Log.i(param1String1, param1String2, param1VarArgs[0]);
          return;
        } 
        Log.i(param1String1, param1String2);
      } 
    }
    
    public void g(String param1String1, String param1String2, Throwable... param1VarArgs) {
      if (this.c <= 2) {
        if (param1VarArgs != null && param1VarArgs.length >= 1) {
          Log.v(param1String1, param1String2, param1VarArgs[0]);
          return;
        } 
        Log.v(param1String1, param1String2);
      } 
    }
    
    public void h(String param1String1, String param1String2, Throwable... param1VarArgs) {
      if (this.c <= 5) {
        if (param1VarArgs != null && param1VarArgs.length >= 1) {
          Log.w(param1String1, param1String2, param1VarArgs[0]);
          return;
        } 
        Log.w(param1String1, param1String2);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */