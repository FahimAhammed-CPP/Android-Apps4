package androidx.work;

import android.os.Build;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class b {
  final Executor a;
  
  final Executor b;
  
  final x c;
  
  final k d;
  
  final s e;
  
  final i f;
  
  final String g;
  
  final int h;
  
  final int i;
  
  final int j;
  
  final int k;
  
  private final boolean l;
  
  b(b paramb) {
    Executor executor = paramb.a;
    if (executor == null) {
      this.a = a(false);
    } else {
      this.a = executor;
    } 
    executor = paramb.d;
    if (executor == null) {
      this.l = true;
      this.b = a(true);
    } else {
      this.l = false;
      this.b = executor;
    } 
    x x1 = paramb.b;
    if (x1 == null) {
      this.c = x.c();
    } else {
      this.c = x1;
    } 
    k k1 = paramb.c;
    if (k1 == null) {
      this.d = k.c();
    } else {
      this.d = k1;
    } 
    s s1 = paramb.e;
    if (s1 == null) {
      this.e = (s)new t.a();
    } else {
      this.e = s1;
    } 
    this.h = paramb.h;
    this.i = paramb.i;
    this.j = paramb.j;
    this.k = paramb.k;
    this.f = paramb.f;
    this.g = paramb.g;
  }
  
  private Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), b(paramBoolean));
  }
  
  private ThreadFactory b(boolean paramBoolean) {
    return new a(this, paramBoolean);
  }
  
  public String c() {
    return this.g;
  }
  
  public i d() {
    return this.f;
  }
  
  public Executor e() {
    return this.a;
  }
  
  public k f() {
    return this.d;
  }
  
  public int g() {
    return this.j;
  }
  
  public int h() {
    return (Build.VERSION.SDK_INT == 23) ? (this.k / 2) : this.k;
  }
  
  public int i() {
    return this.i;
  }
  
  public int j() {
    return this.h;
  }
  
  public s k() {
    return this.e;
  }
  
  public Executor l() {
    return this.b;
  }
  
  public x m() {
    return this.c;
  }
  
  class a implements ThreadFactory {
    private final AtomicInteger a = new AtomicInteger(0);
    
    a(b this$0, boolean param1Boolean) {}
    
    public Thread newThread(Runnable param1Runnable) {
      String str;
      if (this.b) {
        str = "WM.task-";
      } else {
        str = "androidx.work-";
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(this.a.incrementAndGet());
      return new Thread(param1Runnable, stringBuilder.toString());
    }
  }
  
  public static final class b {
    Executor a;
    
    x b;
    
    k c;
    
    Executor d;
    
    s e;
    
    i f;
    
    String g;
    
    int h = 4;
    
    int i = 0;
    
    int j = Integer.MAX_VALUE;
    
    int k = 20;
    
    public b a() {
      return new b(this);
    }
  }
  
  public static interface c {
    b a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */