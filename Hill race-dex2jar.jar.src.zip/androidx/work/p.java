package androidx.work;

public enum p {
  b, c;
  
  static {
    p p1 = new p("RUN_AS_NON_EXPEDITED_WORK_REQUEST", 0);
    b = p1;
    p p2 = new p("DROP_WORK_REQUEST", 1);
    c = p2;
    d = new p[] { p1, p2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */