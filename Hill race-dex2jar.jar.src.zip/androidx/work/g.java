package androidx.work;

import android.app.Notification;

public final class g {
  private final int a;
  
  private final int b;
  
  private final Notification c;
  
  public g(int paramInt1, Notification paramNotification, int paramInt2) {
    this.a = paramInt1;
    this.c = paramNotification;
    this.b = paramInt2;
  }
  
  public int a() {
    return this.b;
  }
  
  public Notification b() {
    return this.c;
  }
  
  public int c() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (g.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.a != ((g)paramObject).a) ? false : ((this.b != ((g)paramObject).b) ? false : this.c.equals(((g)paramObject).c));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.a * 31 + this.b) * 31 + this.c.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("ForegroundInfo{");
    stringBuilder.append("mNotificationId=");
    stringBuilder.append(this.a);
    stringBuilder.append(", mForegroundServiceType=");
    stringBuilder.append(this.b);
    stringBuilder.append(", mNotification=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */