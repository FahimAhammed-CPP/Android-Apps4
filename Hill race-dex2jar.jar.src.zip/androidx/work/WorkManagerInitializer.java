package androidx.work;

import android.content.Context;
import java.util.Collections;
import java.util.List;
import o.a;

public final class WorkManagerInitializer implements a<v> {
  private static final String a = l.f("WrkMgrInitializer");
  
  public v a(Context paramContext) {
    l.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    v.e(paramContext, (new b.b()).a());
    return v.d(paramContext);
  }
  
  public List<Class<? extends a<?>>> dependencies() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */