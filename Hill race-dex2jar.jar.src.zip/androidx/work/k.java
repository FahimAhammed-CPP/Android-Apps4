package androidx.work;

public abstract class k {
  public static k c() {
    return new a();
  }
  
  public abstract j a(String paramString);
  
  public final j b(String paramString) {
    j j2 = a(paramString);
    j j1 = j2;
    if (j2 == null)
      j1 = j.a(paramString); 
    return j1;
  }
  
  class a extends k {
    public j a(String param1String) {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */