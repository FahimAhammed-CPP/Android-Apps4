package androidx.work;

import android.os.Build;

public final class c {
  public static final c i = (new a()).a();
  
  private m a;
  
  private boolean b;
  
  private boolean c;
  
  private boolean d;
  
  private boolean e;
  
  private long f;
  
  private long g;
  
  private d h;
  
  public c() {
    this.a = m.b;
    this.f = -1L;
    this.g = -1L;
    this.h = new d();
  }
  
  c(a parama) {
    boolean bool;
    this.a = m.b;
    this.f = -1L;
    this.g = -1L;
    this.h = new d();
    this.b = parama.a;
    int i = Build.VERSION.SDK_INT;
    if (i >= 23 && parama.b) {
      bool = true;
    } else {
      bool = false;
    } 
    this.c = bool;
    this.a = parama.c;
    this.d = parama.d;
    this.e = parama.e;
    if (i >= 24) {
      this.h = parama.h;
      this.f = parama.f;
      this.g = parama.g;
    } 
  }
  
  public c(c paramc) {
    this.a = m.b;
    this.f = -1L;
    this.g = -1L;
    this.h = new d();
    this.b = paramc.b;
    this.c = paramc.c;
    this.a = paramc.a;
    this.d = paramc.d;
    this.e = paramc.e;
    this.h = paramc.h;
  }
  
  public d a() {
    return this.h;
  }
  
  public m b() {
    return this.a;
  }
  
  public long c() {
    return this.f;
  }
  
  public long d() {
    return this.g;
  }
  
  public boolean e() {
    return (this.h.c() > 0);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (c.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b != ((c)paramObject).b) ? false : ((this.c != ((c)paramObject).c) ? false : ((this.d != ((c)paramObject).d) ? false : ((this.e != ((c)paramObject).e) ? false : ((this.f != ((c)paramObject).f) ? false : ((this.g != ((c)paramObject).g) ? false : ((this.a != ((c)paramObject).a) ? false : this.h.equals(((c)paramObject).h)))))));
    } 
    return false;
  }
  
  public boolean f() {
    return this.d;
  }
  
  public boolean g() {
    return this.b;
  }
  
  public boolean h() {
    return this.c;
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public boolean i() {
    return this.e;
  }
  
  public void j(d paramd) {
    this.h = paramd;
  }
  
  public void k(m paramm) {
    this.a = paramm;
  }
  
  public void l(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  public void m(boolean paramBoolean) {
    this.b = paramBoolean;
  }
  
  public void n(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public void o(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void p(long paramLong) {
    this.f = paramLong;
  }
  
  public void q(long paramLong) {
    this.g = paramLong;
  }
  
  public static final class a {
    boolean a = false;
    
    boolean b = false;
    
    m c = m.b;
    
    boolean d = false;
    
    boolean e = false;
    
    long f = -1L;
    
    long g = -1L;
    
    d h = new d();
    
    public c a() {
      return new c(this);
    }
    
    public a b(m param1m) {
      this.c = param1m;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\work\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */