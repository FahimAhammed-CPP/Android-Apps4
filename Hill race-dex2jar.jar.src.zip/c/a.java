package c;

import java.util.HashMap;
import java.util.Map;

public class a<K, V> extends b<K, V> {
  private HashMap<K, b.c<K, V>> f = new HashMap<K, b.c<K, V>>();
  
  public boolean contains(K paramK) {
    return this.f.containsKey(paramK);
  }
  
  protected b.c<K, V> e(K paramK) {
    return this.f.get(paramK);
  }
  
  public V i(K paramK, V paramV) {
    b.c<K, V> c = e(paramK);
    if (c != null)
      return c.c; 
    this.f.put(paramK, h(paramK, paramV));
    return null;
  }
  
  public V j(K paramK) {
    V v = super.j(paramK);
    this.f.remove(paramK);
    return v;
  }
  
  public Map.Entry<K, V> k(K paramK) {
    return contains(paramK) ? ((b.c)this.f.get(paramK)).e : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */