package c;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b<K, V> implements Iterable<Map.Entry<K, V>> {
  c<K, V> b;
  
  private c<K, V> c;
  
  private WeakHashMap<f<K, V>, Boolean> d = new WeakHashMap<f<K, V>, Boolean>();
  
  private int e = 0;
  
  public Map.Entry<K, V> d() {
    return this.b;
  }
  
  public Iterator<Map.Entry<K, V>> descendingIterator() {
    b<K, V> b1 = new b<K, V>(this.c, this.b);
    this.d.put(b1, Boolean.FALSE);
    return b1;
  }
  
  protected c<K, V> e(K paramK) {
    c<K, V> c1;
    for (c1 = this.b; c1 != null; c1 = c1.d) {
      if (c1.b.equals(paramK))
        return c1; 
    } 
    return c1;
  }
  
  public boolean equals(Object<Map.Entry<K, V>> paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    b b1 = (b)paramObject;
    if (size() != b1.size())
      return false; 
    paramObject = (Object<Map.Entry<K, V>>)iterator();
    Iterator<Object> iterator = b1.iterator();
    while (paramObject.hasNext() && iterator.hasNext()) {
      Map.Entry entry = paramObject.next();
      Object object = iterator.next();
      if ((entry == null && object != null) || (entry != null && !entry.equals(object)))
        return false; 
    } 
    return (!paramObject.hasNext() && !iterator.hasNext());
  }
  
  public d f() {
    d d = new d(this);
    this.d.put(d, Boolean.FALSE);
    return d;
  }
  
  public Map.Entry<K, V> g() {
    return this.c;
  }
  
  protected c<K, V> h(K paramK, V paramV) {
    c<K, V> c1 = new c<K, V>(paramK, paramV);
    this.e++;
    c<K, V> c2 = this.c;
    if (c2 == null) {
      this.b = c1;
      this.c = c1;
      return c1;
    } 
    c2.d = c1;
    c1.e = c2;
    this.c = c1;
    return c1;
  }
  
  public int hashCode() {
    Iterator<Map.Entry<K, V>> iterator = iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += ((Map.Entry)iterator.next()).hashCode());
    return i;
  }
  
  public V i(K paramK, V paramV) {
    c<K, V> c1 = e(paramK);
    if (c1 != null)
      return c1.c; 
    h(paramK, paramV);
    return null;
  }
  
  public Iterator<Map.Entry<K, V>> iterator() {
    a<K, V> a = new a<K, V>(this.b, this.c);
    this.d.put(a, Boolean.FALSE);
    return a;
  }
  
  public V j(K paramK) {
    c<K, V> c1 = e(paramK);
    if (c1 == null)
      return null; 
    this.e--;
    if (!this.d.isEmpty()) {
      Iterator<f<K, V>> iterator = this.d.keySet().iterator();
      while (iterator.hasNext())
        ((f<K, V>)iterator.next()).a(c1); 
    } 
    c<K, V> c2 = c1.e;
    if (c2 != null) {
      c2.d = c1.d;
    } else {
      this.b = c1.d;
    } 
    c<K, V> c3 = c1.d;
    if (c3 != null) {
      c3.e = c2;
    } else {
      this.c = c2;
    } 
    c1.d = null;
    c1.e = null;
    return c1.c;
  }
  
  public int size() {
    return this.e;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(((Map.Entry)iterator.next()).toString());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static class a<K, V> extends e<K, V> {
    a(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    b.c<K, V> b(b.c<K, V> param1c) {
      return param1c.e;
    }
    
    b.c<K, V> c(b.c<K, V> param1c) {
      return param1c.d;
    }
  }
  
  private static class b<K, V> extends e<K, V> {
    b(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    b.c<K, V> b(b.c<K, V> param1c) {
      return param1c.d;
    }
    
    b.c<K, V> c(b.c<K, V> param1c) {
      return param1c.e;
    }
  }
  
  static class c<K, V> implements Map.Entry<K, V> {
    final K b;
    
    final V c;
    
    c<K, V> d;
    
    c<K, V> e;
    
    c(K param1K, V param1V) {
      this.b = param1K;
      this.c = param1V;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof c))
        return false; 
      param1Object = param1Object;
      return (this.b.equals(((c)param1Object).b) && this.c.equals(((c)param1Object).c));
    }
    
    public K getKey() {
      return this.b;
    }
    
    public V getValue() {
      return this.c;
    }
    
    public int hashCode() {
      return this.b.hashCode() ^ this.c.hashCode();
    }
    
    public V setValue(V param1V) {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.b);
      stringBuilder.append("=");
      stringBuilder.append(this.c);
      return stringBuilder.toString();
    }
  }
  
  private class d implements Iterator<Map.Entry<K, V>>, f<K, V> {
    private b.c<K, V> b;
    
    private boolean c = true;
    
    d(b this$0) {}
    
    public void a(b.c<K, V> param1c) {
      b.c<K, V> c1 = this.b;
      if (param1c == c1) {
        boolean bool;
        param1c = c1.e;
        this.b = param1c;
        if (param1c == null) {
          bool = true;
        } else {
          bool = false;
        } 
        this.c = bool;
      } 
    }
    
    public Map.Entry<K, V> b() {
      if (this.c) {
        this.c = false;
        this.b = this.d.b;
      } else {
        b.c<K, V> c1 = this.b;
        if (c1 != null) {
          c1 = c1.d;
        } else {
          c1 = null;
        } 
        this.b = c1;
      } 
      return this.b;
    }
    
    public boolean hasNext() {
      if (this.c)
        return (this.d.b != null); 
      b.c<K, V> c1 = this.b;
      return (c1 != null && c1.d != null);
    }
  }
  
  private static abstract class e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {
    b.c<K, V> b;
    
    b.c<K, V> c;
    
    e(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      this.b = param1c2;
      this.c = param1c1;
    }
    
    private b.c<K, V> e() {
      b.c<K, V> c1 = this.c;
      b.c<K, V> c2 = this.b;
      return (c1 == c2 || c2 == null) ? null : c(c1);
    }
    
    public void a(b.c<K, V> param1c) {
      if (this.b == param1c && param1c == this.c) {
        this.c = null;
        this.b = null;
      } 
      b.c<K, V> c1 = this.b;
      if (c1 == param1c)
        this.b = b(c1); 
      if (this.c == param1c)
        this.c = e(); 
    }
    
    abstract b.c<K, V> b(b.c<K, V> param1c);
    
    abstract b.c<K, V> c(b.c<K, V> param1c);
    
    public Map.Entry<K, V> d() {
      b.c<K, V> c1 = this.c;
      this.c = e();
      return c1;
    }
    
    public boolean hasNext() {
      return (this.c != null);
    }
  }
  
  static interface f<K, V> {
    void a(b.c<K, V> param1c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */