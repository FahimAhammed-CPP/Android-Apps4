package com.android.billingclient.api;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import com.google.android.apps.common.proguard.UsedByReflection;

@UsedByReflection("PlatformActivityProxy")
public class ProxyBillingActivity extends Activity {
  public ResultReceiver 怖;
  
  public boolean 恐;
  
  public ResultReceiver 淋;
  
  public boolean 痛;
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: iload_2
    //   3: aload_3
    //   4: invokespecial onActivityResult : (IILandroid/content/Intent;)V
    //   7: aconst_null
    //   8: astore #7
    //   10: aconst_null
    //   11: astore #6
    //   13: iload_1
    //   14: bipush #100
    //   16: if_icmpeq -> 113
    //   19: iload_1
    //   20: bipush #110
    //   22: if_icmpne -> 28
    //   25: goto -> 113
    //   28: iload_1
    //   29: bipush #101
    //   31: if_icmpne -> 106
    //   34: getstatic y/zk0.硬 : I
    //   37: istore_1
    //   38: aload_3
    //   39: ifnonnull -> 45
    //   42: goto -> 56
    //   45: aload_3
    //   46: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   49: astore #7
    //   51: aload #7
    //   53: ifnonnull -> 61
    //   56: iconst_0
    //   57: istore_1
    //   58: goto -> 70
    //   61: aload #7
    //   63: ldc 'IN_APP_MESSAGE_RESPONSE_CODE'
    //   65: iconst_0
    //   66: invokevirtual getInt : (Ljava/lang/String;I)I
    //   69: istore_1
    //   70: aload_0
    //   71: getfield 怖 : Landroid/os/ResultReceiver;
    //   74: astore #7
    //   76: aload #7
    //   78: ifnull -> 318
    //   81: aload_3
    //   82: ifnonnull -> 91
    //   85: aload #6
    //   87: astore_3
    //   88: goto -> 96
    //   91: aload_3
    //   92: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   95: astore_3
    //   96: aload #7
    //   98: iload_1
    //   99: aload_3
    //   100: invokevirtual send : (ILandroid/os/Bundle;)V
    //   103: goto -> 318
    //   106: getstatic y/zk0.硬 : I
    //   109: istore_1
    //   110: goto -> 318
    //   113: aload_3
    //   114: ldc 'ProxyBillingActivity'
    //   116: invokestatic 熱 : (Landroid/content/Intent;Ljava/lang/String;)Ly/難;
    //   119: getfield 堅 : I
    //   122: istore #5
    //   124: iload #5
    //   126: istore #4
    //   128: iload_2
    //   129: iconst_m1
    //   130: if_icmpne -> 148
    //   133: iload #5
    //   135: ifeq -> 145
    //   138: iload #5
    //   140: istore #4
    //   142: goto -> 148
    //   145: iconst_0
    //   146: istore #4
    //   148: aload_0
    //   149: getfield 淋 : Landroid/os/ResultReceiver;
    //   152: astore #6
    //   154: aload #6
    //   156: ifnull -> 185
    //   159: aload_3
    //   160: ifnonnull -> 169
    //   163: aload #7
    //   165: astore_3
    //   166: goto -> 174
    //   169: aload_3
    //   170: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   173: astore_3
    //   174: aload #6
    //   176: iload #4
    //   178: aload_3
    //   179: invokevirtual send : (ILandroid/os/Bundle;)V
    //   182: goto -> 318
    //   185: aload_3
    //   186: ifnull -> 294
    //   189: aload_3
    //   190: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   193: ifnull -> 268
    //   196: aload_3
    //   197: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   200: ldc 'ALTERNATIVE_BILLING_USER_CHOICE_DATA'
    //   202: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   205: astore #6
    //   207: aload #6
    //   209: ifnull -> 246
    //   212: new android/content/Intent
    //   215: dup
    //   216: ldc 'com.android.vending.billing.ALTERNATIVE_BILLING'
    //   218: invokespecial <init> : (Ljava/lang/String;)V
    //   221: astore_3
    //   222: aload_3
    //   223: aload_0
    //   224: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   227: invokevirtual getPackageName : ()Ljava/lang/String;
    //   230: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   233: pop
    //   234: aload_3
    //   235: ldc 'ALTERNATIVE_BILLING_USER_CHOICE_DATA'
    //   237: aload #6
    //   239: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   242: pop
    //   243: goto -> 299
    //   246: aload_0
    //   247: invokevirtual 硬 : ()Landroid/content/Intent;
    //   250: astore #6
    //   252: aload #6
    //   254: aload_3
    //   255: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   258: invokevirtual putExtras : (Landroid/os/Bundle;)Landroid/content/Intent;
    //   261: pop
    //   262: aload #6
    //   264: astore_3
    //   265: goto -> 299
    //   268: aload_0
    //   269: invokevirtual 硬 : ()Landroid/content/Intent;
    //   272: astore_3
    //   273: aload_3
    //   274: ldc 'RESPONSE_CODE'
    //   276: bipush #6
    //   278: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   281: pop
    //   282: aload_3
    //   283: ldc 'DEBUG_MESSAGE'
    //   285: ldc 'An internal error occurred.'
    //   287: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   290: pop
    //   291: goto -> 299
    //   294: aload_0
    //   295: invokevirtual 硬 : ()Landroid/content/Intent;
    //   298: astore_3
    //   299: iload_1
    //   300: bipush #110
    //   302: if_icmpne -> 313
    //   305: aload_3
    //   306: ldc 'IS_FIRST_PARTY_PURCHASE'
    //   308: iconst_1
    //   309: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   312: pop
    //   313: aload_0
    //   314: aload_3
    //   315: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   318: aload_0
    //   319: iconst_0
    //   320: putfield 恐 : Z
    //   323: aload_0
    //   324: invokevirtual finish : ()V
    //   327: return
  }
  
  public final void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_1
    //   6: ifnonnull -> 301
    //   9: ldc 'ProxyBillingActivity'
    //   11: ldc 'Launching Play Store billing flow'
    //   13: invokestatic 冷 : (Ljava/lang/String;Ljava/lang/String;)V
    //   16: aload_0
    //   17: invokevirtual getIntent : ()Landroid/content/Intent;
    //   20: ldc 'BUY_INTENT'
    //   22: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   25: ifeq -> 83
    //   28: aload_0
    //   29: invokevirtual getIntent : ()Landroid/content/Intent;
    //   32: ldc 'BUY_INTENT'
    //   34: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   37: checkcast android/app/PendingIntent
    //   40: astore_3
    //   41: aload_3
    //   42: astore_1
    //   43: aload_0
    //   44: invokevirtual getIntent : ()Landroid/content/Intent;
    //   47: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   49: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   52: ifeq -> 124
    //   55: aload_3
    //   56: astore_1
    //   57: aload_0
    //   58: invokevirtual getIntent : ()Landroid/content/Intent;
    //   61: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   63: iconst_0
    //   64: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   67: ifeq -> 124
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield 痛 : Z
    //   75: bipush #110
    //   77: istore_2
    //   78: aload_3
    //   79: astore_1
    //   80: goto -> 182
    //   83: aload_0
    //   84: invokevirtual getIntent : ()Landroid/content/Intent;
    //   87: ldc 'SUBS_MANAGEMENT_INTENT'
    //   89: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   92: ifeq -> 130
    //   95: aload_0
    //   96: invokevirtual getIntent : ()Landroid/content/Intent;
    //   99: ldc 'SUBS_MANAGEMENT_INTENT'
    //   101: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   104: checkcast android/app/PendingIntent
    //   107: astore_1
    //   108: aload_0
    //   109: aload_0
    //   110: invokevirtual getIntent : ()Landroid/content/Intent;
    //   113: ldc 'result_receiver'
    //   115: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   118: checkcast android/os/ResultReceiver
    //   121: putfield 淋 : Landroid/os/ResultReceiver;
    //   124: bipush #100
    //   126: istore_2
    //   127: goto -> 182
    //   130: aload_0
    //   131: invokevirtual getIntent : ()Landroid/content/Intent;
    //   134: ldc 'IN_APP_MESSAGE_INTENT'
    //   136: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   139: ifeq -> 177
    //   142: aload_0
    //   143: invokevirtual getIntent : ()Landroid/content/Intent;
    //   146: ldc 'IN_APP_MESSAGE_INTENT'
    //   148: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   151: checkcast android/app/PendingIntent
    //   154: astore_1
    //   155: aload_0
    //   156: aload_0
    //   157: invokevirtual getIntent : ()Landroid/content/Intent;
    //   160: ldc 'in_app_message_result_receiver'
    //   162: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   165: checkcast android/os/ResultReceiver
    //   168: putfield 怖 : Landroid/os/ResultReceiver;
    //   171: bipush #101
    //   173: istore_2
    //   174: goto -> 182
    //   177: aconst_null
    //   178: astore_1
    //   179: goto -> 124
    //   182: aload_0
    //   183: iconst_1
    //   184: putfield 恐 : Z
    //   187: aload_0
    //   188: aload_1
    //   189: invokevirtual getIntentSender : ()Landroid/content/IntentSender;
    //   192: iload_2
    //   193: new android/content/Intent
    //   196: dup
    //   197: invokespecial <init> : ()V
    //   200: iconst_0
    //   201: iconst_0
    //   202: iconst_0
    //   203: invokevirtual startIntentSenderForResult : (Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    //   206: return
    //   207: getstatic y/zk0.硬 : I
    //   210: istore_2
    //   211: aload_0
    //   212: getfield 淋 : Landroid/os/ResultReceiver;
    //   215: astore_1
    //   216: aload_1
    //   217: ifnull -> 230
    //   220: aload_1
    //   221: bipush #6
    //   223: aconst_null
    //   224: invokevirtual send : (ILandroid/os/Bundle;)V
    //   227: goto -> 291
    //   230: aload_0
    //   231: getfield 怖 : Landroid/os/ResultReceiver;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnull -> 248
    //   239: aload_1
    //   240: iconst_0
    //   241: aconst_null
    //   242: invokevirtual send : (ILandroid/os/Bundle;)V
    //   245: goto -> 291
    //   248: aload_0
    //   249: invokevirtual 硬 : ()Landroid/content/Intent;
    //   252: astore_1
    //   253: aload_0
    //   254: getfield 痛 : Z
    //   257: ifeq -> 268
    //   260: aload_1
    //   261: ldc 'IS_FIRST_PARTY_PURCHASE'
    //   263: iconst_1
    //   264: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   267: pop
    //   268: aload_1
    //   269: ldc 'RESPONSE_CODE'
    //   271: bipush #6
    //   273: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   276: pop
    //   277: aload_1
    //   278: ldc 'DEBUG_MESSAGE'
    //   280: ldc 'An internal error occurred.'
    //   282: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   285: pop
    //   286: aload_0
    //   287: aload_1
    //   288: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   291: aload_0
    //   292: iconst_0
    //   293: putfield 恐 : Z
    //   296: aload_0
    //   297: invokevirtual finish : ()V
    //   300: return
    //   301: ldc 'ProxyBillingActivity'
    //   303: ldc 'Launching Play Store billing flow from savedInstanceState'
    //   305: invokestatic 冷 : (Ljava/lang/String;Ljava/lang/String;)V
    //   308: aload_0
    //   309: aload_1
    //   310: ldc 'send_cancelled_broadcast_if_finished'
    //   312: iconst_0
    //   313: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   316: putfield 恐 : Z
    //   319: aload_1
    //   320: ldc 'result_receiver'
    //   322: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   325: ifeq -> 344
    //   328: aload_0
    //   329: aload_1
    //   330: ldc 'result_receiver'
    //   332: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   335: checkcast android/os/ResultReceiver
    //   338: putfield 淋 : Landroid/os/ResultReceiver;
    //   341: goto -> 366
    //   344: aload_1
    //   345: ldc 'in_app_message_result_receiver'
    //   347: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   350: ifeq -> 366
    //   353: aload_0
    //   354: aload_1
    //   355: ldc 'in_app_message_result_receiver'
    //   357: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   360: checkcast android/os/ResultReceiver
    //   363: putfield 怖 : Landroid/os/ResultReceiver;
    //   366: aload_0
    //   367: aload_1
    //   368: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   370: iconst_0
    //   371: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   374: putfield 痛 : Z
    //   377: return
    //   378: astore_1
    //   379: goto -> 207
    // Exception table:
    //   from	to	target	type
    //   182	206	378	android/content/IntentSender$SendIntentException
  }
  
  public final void onDestroy() {
    super.onDestroy();
    if (!isFinishing())
      return; 
    if (!this.恐)
      return; 
    Intent intent = 硬();
    intent.putExtra("RESPONSE_CODE", 1);
    intent.putExtra("DEBUG_MESSAGE", "Billing dialog closed.");
    sendBroadcast(intent);
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    ResultReceiver resultReceiver = this.淋;
    if (resultReceiver != null)
      paramBundle.putParcelable("result_receiver", (Parcelable)resultReceiver); 
    resultReceiver = this.怖;
    if (resultReceiver != null)
      paramBundle.putParcelable("in_app_message_result_receiver", (Parcelable)resultReceiver); 
    paramBundle.putBoolean("send_cancelled_broadcast_if_finished", this.恐);
    paramBundle.putBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", this.痛);
  }
  
  public final Intent 硬() {
    Intent intent = new Intent("com.android.vending.billing.PURCHASES_UPDATED");
    intent.setPackage(getApplicationContext().getPackageName());
    return intent;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\android\billingclient\api\ProxyBillingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */