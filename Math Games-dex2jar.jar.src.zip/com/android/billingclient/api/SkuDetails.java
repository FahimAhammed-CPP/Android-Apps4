package com.android.billingclient.api;

import android.text.TextUtils;
import org.json.JSONObject;

public final class SkuDetails {
  public final JSONObject 堅;
  
  public final String 硬;
  
  public SkuDetails(String paramString) {
    this.硬 = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.堅 = jSONObject;
    if (!TextUtils.isEmpty(jSONObject.optString("productId"))) {
      if (!TextUtils.isEmpty(jSONObject.optString("type")))
        return; 
      throw new IllegalArgumentException("SkuType cannot be empty.");
    } 
    throw new IllegalArgumentException("SKU cannot be empty.");
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SkuDetails))
      return false; 
    paramObject = paramObject;
    return TextUtils.equals(this.硬, ((SkuDetails)paramObject).硬);
  }
  
  public final int hashCode() {
    return this.硬.hashCode();
  }
  
  public final String toString() {
    return "SkuDetails: ".concat(String.valueOf(this.硬));
  }
  
  public final String 硬() {
    return this.堅.optString("type");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\android\billingclient\api\SkuDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */