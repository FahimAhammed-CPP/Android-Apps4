package com.android.billingclient.api;

import android.text.TextUtils;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public final class Purchase {
  public final String 堅;
  
  public final JSONObject 熱;
  
  public final String 硬;
  
  public Purchase(String paramString1, String paramString2) {
    this.硬 = paramString1;
    this.堅 = paramString2;
    this.熱 = new JSONObject(paramString1);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Purchase))
      return false; 
    paramObject = paramObject;
    String str = ((Purchase)paramObject).硬;
    return (TextUtils.equals(this.硬, str) && TextUtils.equals(this.堅, ((Purchase)paramObject).堅));
  }
  
  public final int hashCode() {
    return this.硬.hashCode();
  }
  
  public final String toString() {
    return "Purchase. Json: ".concat(String.valueOf(this.硬));
  }
  
  public final ArrayList 硬() {
    JSONArray jSONArray;
    ArrayList<String> arrayList = new ArrayList();
    JSONObject jSONObject = this.熱;
    if (jSONObject.has("productIds")) {
      jSONArray = jSONObject.optJSONArray("productIds");
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.optString(i));  
    } else if (jSONArray.has("productId")) {
      arrayList.add(jSONArray.optString("productId"));
    } 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\android\billingclient\api\Purchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */