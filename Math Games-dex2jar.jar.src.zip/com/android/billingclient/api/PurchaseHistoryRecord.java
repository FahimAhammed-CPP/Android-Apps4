package com.android.billingclient.api;

import android.text.TextUtils;
import org.json.JSONObject;

public final class PurchaseHistoryRecord {
  public final String 堅;
  
  public final JSONObject 熱;
  
  public final String 硬;
  
  public PurchaseHistoryRecord(String paramString1, String paramString2) {
    this.硬 = paramString1;
    this.堅 = paramString2;
    this.熱 = new JSONObject(paramString1);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PurchaseHistoryRecord))
      return false; 
    paramObject = paramObject;
    String str = ((PurchaseHistoryRecord)paramObject).硬;
    return (TextUtils.equals(this.硬, str) && TextUtils.equals(this.堅, ((PurchaseHistoryRecord)paramObject).堅));
  }
  
  public final int hashCode() {
    return this.硬.hashCode();
  }
  
  public final String toString() {
    return "PurchaseHistoryRecord. Json: ".concat(String.valueOf(this.硬));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\android\billingclient\api\PurchaseHistoryRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */