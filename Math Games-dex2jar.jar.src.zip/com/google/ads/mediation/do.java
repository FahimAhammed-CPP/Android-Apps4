package com.google.ads.mediation;

import android.os.RemoteException;
import y.d11;
import y.k2;
import y.oy0;
import y.rr1;
import y.vx0;
import y.we1;
import y.ば;
import y.婦;
import y.年;
import y.歯;
import y.麦;

public final class do extends 歯 {
  public final AbstractAdViewAdapter 태;
  
  public final k2 택;
  
  public do(AbstractAdViewAdapter paramAbstractAdViewAdapter, k2 paramk2) {
    this.태 = paramAbstractAdViewAdapter;
    this.택 = paramk2;
  }
  
  public final void 噛(ば paramば) {
    ((d11)this.택).熱((麦)paramば);
  }
  
  public final void 触(Object paramObject) {
    paramObject = paramObject;
    AbstractAdViewAdapter abstractAdViewAdapter = this.태;
    abstractAdViewAdapter.mInterstitialAd = (婦)paramObject;
    k2 k21 = this.택;
    paramObject.堅((oy0)new we1(abstractAdViewAdapter, k21));
    paramObject = k21;
    paramObject.getClass();
    年.暑("#008 Must be called on the main UI thread.");
    rr1.暑("Adapter called onAdLoaded.");
    try {
      ((vx0)((d11)paramObject).怖).悲();
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\ads\mediation\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */