package com.google.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import java.util.Date;
import java.util.Set;
import y.bw0;
import y.e2;
import y.e5;
import y.fq1;
import y.i2;
import y.jl0;
import y.k2;
import y.m2;
import y.nj0;
import y.pw0;
import y.rr1;
import y.s51;
import y.ym1;
import y.シ;
import y.ス;
import y.内;
import y.婦;
import y.果;
import y.茎;
import y.豆;
import y.野;
import y.飯;
import y.함;

public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {
  public static final String AD_UNIT_ID_PARAMETER = "pubid";
  
  private 豆 adLoader;
  
  protected 飯 mAdView;
  
  protected 婦 mInterstitialAd;
  
  public シ buildAdRequest(Context paramContext, e2 parame2, Bundle paramBundle1, Bundle paramBundle2) {
    함 함 = new 함(9);
    Date date = parame2.堅();
    Object object = 함.怖;
    if (date != null)
      ((fq1)object).美 = date; 
    int i = parame2.寒();
    if (i != 0)
      ((fq1)object).不 = i; 
    Set set = parame2.暑();
    if (set != null)
      for (String str : set)
        ((fq1)object).硬.add(str);  
    if (parame2.熱()) {
      s51 s51 = nj0.寒.硬;
      String str = s51.嬉(paramContext);
      ((fq1)object).暑.add(str);
    } 
    if (parame2.冷() != -1) {
      int j = parame2.冷();
      i = 1;
      if (j != 1)
        i = 0; 
      ((fq1)object).ぱ = i;
    } 
    boolean bool = parame2.硬();
    ((fq1)object).苦 = bool;
    함.旨(buildExtrasBundle(paramBundle1, paramBundle2));
    return new シ(함);
  }
  
  public abstract Bundle buildExtrasBundle(Bundle paramBundle1, Bundle paramBundle2);
  
  public String getAdUnitId(Bundle paramBundle) {
    return paramBundle.getString("pubid");
  }
  
  public View getBannerView() {
    return (View)this.mAdView;
  }
  
  public 婦 getInterstitialAd() {
    return this.mInterstitialAd;
  }
  
  public ym1 getVideoController() {
    飯 飯1 = this.mAdView;
    if (飯1 != null) {
      null = ((内)飯1).淋.熱;
      synchronized (null.怖) {
        return (ym1)null.恐;
      } 
    } 
    return null;
  }
  
  public 果 newAdLoader(Context paramContext, String paramString) {
    return new 果(paramContext, paramString);
  }
  
  public void onDestroy() {
    飯 飯1 = this.mAdView;
    if (飯1 != null) {
      飯1.硬();
      this.mAdView = null;
    } 
    if (this.mInterstitialAd != null)
      this.mInterstitialAd = null; 
    if (this.adLoader != null)
      this.adLoader = null; 
  }
  
  public void onImmersiveModeUpdated(boolean paramBoolean) {
    婦 婦1 = this.mInterstitialAd;
    if (婦1 != null) {
      bw0 bw0 = (bw0)婦1;
      try {
        pw0 pw0 = bw0.熱;
        if (pw0 != null) {
          pw0.血(paramBoolean);
          return;
        } 
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      } 
    } 
  }
  
  public void onPause() {
    飯 飯1 = this.mAdView;
    if (飯1 != null)
      飯1.熱(); 
  }
  
  public void onResume() {
    飯 飯1 = this.mAdView;
    if (飯1 != null)
      飯1.暑(); 
  }
  
  public void requestBannerAd(Context paramContext, i2 parami2, Bundle paramBundle1, ス paramス, e2 parame2, Bundle paramBundle2) {
    飯 飯1 = new 飯(paramContext);
    this.mAdView = 飯1;
    飯1.setAdSize(new ス(paramス.硬, paramス.堅));
    this.mAdView.setAdUnitId(getAdUnitId(paramBundle1));
    this.mAdView.setAdListener((野)new jl0(this, parami2));
    this.mAdView.堅(buildAdRequest(paramContext, parame2, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, k2 paramk2, Bundle paramBundle1, e2 parame2, Bundle paramBundle2) {
    婦.硬(paramContext, getAdUnitId(paramBundle1), buildAdRequest(paramContext, parame2, paramBundle2, paramBundle1), new do(this, paramk2));
  }
  
  public void requestNativeAd(Context paramContext, m2 paramm2, Bundle paramBundle1, e5 parame5, Bundle paramBundle2) {
    // Byte code:
    //   0: new y/wr1
    //   3: dup
    //   4: aload_0
    //   5: aload_2
    //   6: invokespecial <init> : (Lcom/google/ads/mediation/AbstractAdViewAdapter;Ly/m2;)V
    //   9: astore #10
    //   11: aload_0
    //   12: aload_1
    //   13: aload_3
    //   14: ldc 'pubid'
    //   16: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   19: invokevirtual newAdLoader : (Landroid/content/Context;Ljava/lang/String;)Ly/果;
    //   22: astore #11
    //   24: aload #11
    //   26: invokevirtual getClass : ()Ljava/lang/Class;
    //   29: pop
    //   30: aload #11
    //   32: getfield 堅 : Ly/qu0;
    //   35: new y/re2
    //   38: dup
    //   39: aload #10
    //   41: invokespecial <init> : (Ly/野;)V
    //   44: invokeinterface 髪 : (Ly/bp0;)V
    //   49: goto -> 56
    //   52: getstatic y/rr1.硬 : Ly/df1;
    //   55: astore_2
    //   56: aload #11
    //   58: getfield 堅 : Ly/qu0;
    //   61: astore #12
    //   63: aload #4
    //   65: checkcast y/ly0
    //   68: astore #13
    //   70: aload #13
    //   72: invokevirtual getClass : ()Ljava/lang/Class;
    //   75: pop
    //   76: new y/c5
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore_2
    //   84: aload #13
    //   86: getfield 寒 : Ly/xr0;
    //   89: astore #9
    //   91: aload #9
    //   93: ifnonnull -> 108
    //   96: new y/c5
    //   99: dup
    //   100: aload_2
    //   101: invokespecial <init> : (Ly/c5;)V
    //   104: astore_2
    //   105: goto -> 224
    //   108: aload #9
    //   110: getfield 淋 : I
    //   113: istore #6
    //   115: iload #6
    //   117: iconst_2
    //   118: if_icmpeq -> 179
    //   121: iload #6
    //   123: iconst_3
    //   124: if_icmpeq -> 154
    //   127: iload #6
    //   129: iconst_4
    //   130: if_icmpeq -> 136
    //   133: goto -> 188
    //   136: aload_2
    //   137: aload #9
    //   139: getfield 起 : Z
    //   142: putfield 美 : Z
    //   145: aload_2
    //   146: aload #9
    //   148: getfield 興 : I
    //   151: putfield 熱 : I
    //   154: aload #9
    //   156: getfield 臭 : Ly/s72;
    //   159: astore #14
    //   161: aload #14
    //   163: ifnull -> 179
    //   166: aload_2
    //   167: new y/sv
    //   170: dup
    //   171: aload #14
    //   173: invokespecial <init> : (Ly/s72;)V
    //   176: putfield 寒 : Ljava/lang/Object;
    //   179: aload_2
    //   180: aload #9
    //   182: getfield 痒 : I
    //   185: putfield 冷 : I
    //   188: aload_2
    //   189: aload #9
    //   191: getfield 怖 : Z
    //   194: putfield 硬 : Z
    //   197: aload_2
    //   198: aload #9
    //   200: getfield 恐 : I
    //   203: putfield 堅 : I
    //   206: aload_2
    //   207: aload #9
    //   209: getfield 痛 : Z
    //   212: putfield 暑 : Z
    //   215: new y/c5
    //   218: dup
    //   219: aload_2
    //   220: invokespecial <init> : (Ly/c5;)V
    //   223: astore_2
    //   224: aload #12
    //   226: new y/xr0
    //   229: dup
    //   230: aload_2
    //   231: invokespecial <init> : (Ly/c5;)V
    //   234: invokeinterface 腕 : (Ly/xr0;)V
    //   239: goto -> 246
    //   242: getstatic y/rr1.硬 : Ly/df1;
    //   245: astore_2
    //   246: new y/b5
    //   249: dup
    //   250: invokespecial <init> : ()V
    //   253: astore_2
    //   254: aload #13
    //   256: getfield 寒 : Ly/xr0;
    //   259: astore #9
    //   261: aload #9
    //   263: ifnonnull -> 278
    //   266: new y/b5
    //   269: dup
    //   270: aload_2
    //   271: invokespecial <init> : (Ly/b5;)V
    //   274: astore_2
    //   275: goto -> 403
    //   278: aload #9
    //   280: getfield 淋 : I
    //   283: istore #6
    //   285: iload #6
    //   287: iconst_2
    //   288: if_icmpeq -> 367
    //   291: iload #6
    //   293: iconst_3
    //   294: if_icmpeq -> 342
    //   297: iload #6
    //   299: iconst_4
    //   300: if_icmpeq -> 306
    //   303: goto -> 376
    //   306: aload_2
    //   307: aload #9
    //   309: getfield 起 : Z
    //   312: putfield 寒 : Z
    //   315: aload_2
    //   316: aload #9
    //   318: getfield 興 : I
    //   321: putfield 堅 : I
    //   324: aload_2
    //   325: aload #9
    //   327: getfield 死 : Z
    //   330: putfield 美 : Z
    //   333: aload_2
    //   334: aload #9
    //   336: getfield 産 : I
    //   339: putfield 旨 : I
    //   342: aload #9
    //   344: getfield 臭 : Ly/s72;
    //   347: astore #14
    //   349: aload #14
    //   351: ifnull -> 367
    //   354: aload_2
    //   355: new y/sv
    //   358: dup
    //   359: aload #14
    //   361: invokespecial <init> : (Ly/s72;)V
    //   364: putfield 冷 : Ly/sv;
    //   367: aload_2
    //   368: aload #9
    //   370: getfield 痒 : I
    //   373: putfield 暑 : I
    //   376: aload_2
    //   377: aload #9
    //   379: getfield 怖 : Z
    //   382: putfield 硬 : Z
    //   385: aload_2
    //   386: aload #9
    //   388: getfield 痛 : Z
    //   391: putfield 熱 : Z
    //   394: new y/b5
    //   397: dup
    //   398: aload_2
    //   399: invokespecial <init> : (Ly/b5;)V
    //   402: astore_2
    //   403: aload_2
    //   404: getfield 硬 : Z
    //   407: istore #7
    //   409: aload_2
    //   410: getfield 熱 : Z
    //   413: istore #8
    //   415: aload_2
    //   416: getfield 暑 : I
    //   419: istore #6
    //   421: aload_2
    //   422: getfield 冷 : Ly/sv;
    //   425: astore #9
    //   427: aload #9
    //   429: ifnull -> 777
    //   432: new y/s72
    //   435: dup
    //   436: aload #9
    //   438: invokespecial <init> : (Ly/sv;)V
    //   441: astore #9
    //   443: goto -> 446
    //   446: aload #12
    //   448: new y/xr0
    //   451: dup
    //   452: iconst_4
    //   453: iload #7
    //   455: iconst_m1
    //   456: iload #8
    //   458: iload #6
    //   460: aload #9
    //   462: aload_2
    //   463: getfield 寒 : Z
    //   466: aload_2
    //   467: getfield 堅 : I
    //   470: aload_2
    //   471: getfield 旨 : I
    //   474: aload_2
    //   475: getfield 美 : Z
    //   478: invokespecial <init> : (IZIZILy/s72;ZIIZ)V
    //   481: invokeinterface 腕 : (Ly/xr0;)V
    //   486: goto -> 493
    //   489: getstatic y/rr1.硬 : Ly/df1;
    //   492: astore_2
    //   493: aload #13
    //   495: getfield 美 : Ljava/util/ArrayList;
    //   498: astore_2
    //   499: aload_2
    //   500: ldc_w '6'
    //   503: invokevirtual contains : (Ljava/lang/Object;)Z
    //   506: ifeq -> 534
    //   509: aload #12
    //   511: new y/wz0
    //   514: dup
    //   515: iconst_1
    //   516: aload #10
    //   518: invokespecial <init> : (ILjava/lang/Object;)V
    //   521: invokeinterface ぜ : (Ly/lt0;)V
    //   526: goto -> 534
    //   529: getstatic y/rr1.硬 : Ly/df1;
    //   532: astore #9
    //   534: aload_2
    //   535: ldc_w '3'
    //   538: invokevirtual contains : (Ljava/lang/Object;)Z
    //   541: ifeq -> 677
    //   544: aload #13
    //   546: getfield 不 : Ljava/util/HashMap;
    //   549: astore #9
    //   551: aload #9
    //   553: invokevirtual keySet : ()Ljava/util/Set;
    //   556: invokeinterface iterator : ()Ljava/util/Iterator;
    //   561: astore #13
    //   563: aload #13
    //   565: invokeinterface hasNext : ()Z
    //   570: ifeq -> 677
    //   573: aload #13
    //   575: invokeinterface next : ()Ljava/lang/Object;
    //   580: checkcast java/lang/String
    //   583: astore #14
    //   585: iconst_1
    //   586: aload #9
    //   588: aload #14
    //   590: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   593: checkcast java/lang/Boolean
    //   596: invokevirtual booleanValue : ()Z
    //   599: if_icmpeq -> 607
    //   602: aconst_null
    //   603: astore_2
    //   604: goto -> 610
    //   607: aload #10
    //   609: astore_2
    //   610: new y/f72
    //   613: dup
    //   614: aload #10
    //   616: aload_2
    //   617: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   620: astore_2
    //   621: new y/yt0
    //   624: dup
    //   625: aload_2
    //   626: invokespecial <init> : (Ly/f72;)V
    //   629: astore #15
    //   631: aload_2
    //   632: getfield 怖 : Ljava/lang/Object;
    //   635: checkcast y/wr1
    //   638: ifnonnull -> 646
    //   641: aconst_null
    //   642: astore_2
    //   643: goto -> 655
    //   646: new y/xt0
    //   649: dup
    //   650: aload_2
    //   651: invokespecial <init> : (Ly/f72;)V
    //   654: astore_2
    //   655: aload #12
    //   657: aload #14
    //   659: aload #15
    //   661: aload_2
    //   662: invokeinterface 築 : (Ljava/lang/String;Ly/ft0;Ly/dt0;)V
    //   667: goto -> 563
    //   670: getstatic y/rr1.硬 : Ly/df1;
    //   673: astore_2
    //   674: goto -> 563
    //   677: aload #11
    //   679: getfield 硬 : Landroid/content/Context;
    //   682: astore #9
    //   684: new y/豆
    //   687: dup
    //   688: aload #9
    //   690: aload #12
    //   692: invokeinterface 堅 : ()Ly/ss0;
    //   697: invokespecial <init> : (Landroid/content/Context;Ly/ss0;)V
    //   700: astore_2
    //   701: goto -> 732
    //   704: getstatic y/rr1.硬 : Ly/df1;
    //   707: astore_2
    //   708: new y/豆
    //   711: dup
    //   712: aload #9
    //   714: new y/q02
    //   717: dup
    //   718: new y/e12
    //   721: dup
    //   722: invokespecial <init> : ()V
    //   725: invokespecial <init> : (Ly/e12;)V
    //   728: invokespecial <init> : (Landroid/content/Context;Ly/ss0;)V
    //   731: astore_2
    //   732: aload_0
    //   733: aload_2
    //   734: putfield adLoader : Ly/豆;
    //   737: aload_2
    //   738: aload_0
    //   739: aload_1
    //   740: aload #4
    //   742: aload #5
    //   744: aload_3
    //   745: invokevirtual buildAdRequest : (Landroid/content/Context;Ly/e2;Landroid/os/Bundle;Landroid/os/Bundle;)Ly/シ;
    //   748: invokevirtual 硬 : (Ly/シ;)V
    //   751: return
    //   752: astore_2
    //   753: goto -> 52
    //   756: astore_2
    //   757: goto -> 242
    //   760: astore_2
    //   761: goto -> 489
    //   764: astore #9
    //   766: goto -> 529
    //   769: astore_2
    //   770: goto -> 670
    //   773: astore_2
    //   774: goto -> 704
    //   777: aconst_null
    //   778: astore #9
    //   780: goto -> 446
    // Exception table:
    //   from	to	target	type
    //   30	49	752	android/os/RemoteException
    //   224	239	756	android/os/RemoteException
    //   403	427	760	android/os/RemoteException
    //   432	443	760	android/os/RemoteException
    //   446	486	760	android/os/RemoteException
    //   509	526	764	android/os/RemoteException
    //   621	641	769	android/os/RemoteException
    //   646	655	769	android/os/RemoteException
    //   655	667	769	android/os/RemoteException
    //   684	701	773	android/os/RemoteException
  }
  
  public void showInterstitial() {
    婦 婦1 = this.mInterstitialAd;
    if (婦1 != null)
      婦1.熱(null); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\ads\mediation\AbstractAdViewAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */