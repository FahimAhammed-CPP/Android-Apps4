package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;
import y.bm;
import y.ik;
import y.jv2;
import y.transient;
import y.畳;
import y.꽃;
import y.찌;

public final class Status extends transient implements ReflectedParcelable {
  public static final Parcelable.Creator<Status> CREATOR = (Parcelable.Creator<Status>)new jv2(5);
  
  public final int 怖;
  
  public final String 恐;
  
  public final int 淋;
  
  public final 찌 痒;
  
  public final PendingIntent 痛;
  
  public Status(int paramInt1, int paramInt2, String paramString, PendingIntent paramPendingIntent, 찌 param찌) {
    this.淋 = paramInt1;
    this.怖 = paramInt2;
    this.恐 = paramString;
    this.痛 = paramPendingIntent;
    this.痒 = param찌;
  }
  
  public Status(String paramString, int paramInt) {
    this(1, paramInt, paramString, null, null);
  }
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof Status))
      return false; 
    paramObject = paramObject;
    int i = ((Status)paramObject).淋;
    return (this.淋 == i && this.怖 == ((Status)paramObject).怖 && 꽃.興(this.恐, ((Status)paramObject).恐) && 꽃.興(this.痛, ((Status)paramObject).痛) && 꽃.興(this.痒, ((Status)paramObject).痒));
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.淋), Integer.valueOf(this.怖), this.恐, this.痛, this.痒 });
  }
  
  public final String toString() {
    畳 畳 = new 畳(this);
    String str = this.恐;
    if (str == null) {
      int i = this.怖;
      switch (i) {
        default:
          str = bm.熱("unknown status code: ", i);
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 22:
          str = "RECONNECTION_TIMED_OUT";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 21:
          str = "RECONNECTION_TIMED_OUT_DURING_UPDATE";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 20:
          str = "CONNECTION_SUSPENDED_DURING_CALL";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 19:
          str = "REMOTE_EXCEPTION";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 18:
          str = "DEAD_CLIENT";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 17:
          str = "API_NOT_CONNECTED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 16:
          str = "CANCELED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 15:
          str = "TIMEOUT";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 14:
          str = "INTERRUPTED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 13:
          str = "ERROR";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 10:
          str = "DEVELOPER_ERROR";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 8:
          str = "INTERNAL_ERROR";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 7:
          str = "NETWORK_ERROR";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 6:
          str = "RESOLUTION_REQUIRED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 5:
          str = "INVALID_ACCOUNT";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 4:
          str = "SIGN_IN_REQUIRED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 3:
          str = "SERVICE_DISABLED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 2:
          str = "SERVICE_VERSION_UPDATE_REQUIRED";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case 0:
          str = "SUCCESS";
          畳.熱(str, "statusCode");
          畳.熱(this.痛, "resolution");
          return 畳.toString();
        case -1:
          break;
      } 
      str = "SUCCESS_CACHE";
    } 
    畳.熱(str, "statusCode");
    畳.熱(this.痛, "resolution");
    return 畳.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = ik.俺(paramParcel, 20293);
    ik.퉁(paramParcel, 1, this.怖);
    ik.し(paramParcel, 2, this.恐);
    ik.た(paramParcel, 3, (Parcelable)this.痛, paramInt);
    ik.た(paramParcel, 4, (Parcelable)this.痒, paramInt);
    ik.퉁(paramParcel, 1000, this.淋);
    ik.看(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\api\Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */