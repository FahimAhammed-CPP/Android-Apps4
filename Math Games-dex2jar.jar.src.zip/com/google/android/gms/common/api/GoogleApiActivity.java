package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import com.google.android.gms.common.annotation.KeepName;
import y.bc2;
import y.年;
import y.찌;
import y.향;
import y.헤;

@KeepName
public class GoogleApiActivity extends Activity implements DialogInterface.OnCancelListener {
  public int 淋 = 0;
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    bc2 bc2;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 1) {
      boolean bool = getIntent().getBooleanExtra("notify_manager", true);
      this.淋 = 0;
      setResult(paramInt2, paramIntent);
      if (bool) {
        헤 헤 = 헤.冷((Context)this);
        if (paramInt2 != -1) {
          if (paramInt2 == 0)
            헤.寒(new 찌(13, null), getIntent().getIntExtra("failing_client_id", -1)); 
        } else {
          bc2 = 헤.返;
          bc2.sendMessage(bc2.obtainMessage(3));
        } 
      } 
    } else if (paramInt1 == 2) {
      this.淋 = 0;
      setResult(paramInt2, (Intent)bc2);
    } 
    finish();
  }
  
  public final void onCancel(DialogInterface paramDialogInterface) {
    this.淋 = 0;
    setResult(0);
    finish();
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (paramBundle != null)
      this.淋 = paramBundle.getInt("resolution"); 
    if (this.淋 != 1) {
      paramBundle = getIntent().getExtras();
      if (paramBundle == null) {
        finish();
        return;
      } 
      PendingIntent pendingIntent = (PendingIntent)paramBundle.get("pending_intent");
      Integer integer = (Integer)paramBundle.get("error_code");
      if (pendingIntent != null || integer != null) {
        if (pendingIntent != null)
          try {
            startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
            this.淋 = 1;
            return;
          } catch (ActivityNotFoundException activityNotFoundException) {
            if (paramBundle.getBoolean("notify_manager", true)) {
              헤.冷((Context)this).寒(new 찌(22, null), getIntent().getIntExtra("failing_client_id", -1));
            } else {
              String str = pendingIntent.toString();
              StringBuilder stringBuilder = new StringBuilder(str.length() + 36);
              stringBuilder.append("Activity not found while launching ");
              stringBuilder.append(str);
              stringBuilder.append(".");
              str = stringBuilder.toString();
              if (Build.FINGERPRINT.contains("generic"))
                str.concat(" This may occur when resolving Google Play services connection issues on emulators with Google APIs but not Google Play Store."); 
            } 
            this.淋 = 1;
            finish();
            return;
          } catch (android.content.IntentSender.SendIntentException sendIntentException) {
            finish();
            return;
          }  
        年.旨(activityNotFoundException);
        int i = activityNotFoundException.intValue();
        향.暑.冷(this, i, this);
        this.淋 = 1;
        return;
      } 
      finish();
      return;
    } 
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    paramBundle.putInt("resolution", this.淋);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\api\GoogleApiActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */