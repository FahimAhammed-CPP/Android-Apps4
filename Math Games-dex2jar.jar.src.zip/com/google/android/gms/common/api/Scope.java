package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import y.ik;
import y.jv2;
import y.transient;
import y.年;

public final class Scope extends transient implements ReflectedParcelable {
  public static final Parcelable.Creator<Scope> CREATOR = (Parcelable.Creator<Scope>)new jv2(4);
  
  public final String 怖;
  
  public final int 淋;
  
  public Scope(String paramString, int paramInt) {
    年.寒("scopeUri must not be null or empty", paramString);
    this.淋 = paramInt;
    this.怖 = paramString;
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Scope))
      return false; 
    paramObject = ((Scope)paramObject).怖;
    return this.怖.equals(paramObject);
  }
  
  public final int hashCode() {
    return this.怖.hashCode();
  }
  
  public final String toString() {
    return this.怖;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = ik.俺(paramParcel, 20293);
    ik.퉁(paramParcel, 1, this.淋);
    ik.し(paramParcel, 2, this.怖);
    ik.看(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\api\Scope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */