package com.google.android.gms.common.api.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Keep;
import y.ろ;
import y.肝;

public class LifecycleCallback {
  @Keep
  private static ろ getChimeraLifecycleFragmentImpl(肝 param肝) {
    throw new IllegalStateException("Method not available in SDK.");
  }
  
  public void 冷(Bundle paramBundle) {}
  
  public void 堅(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  public void 寒() {}
  
  public void 暑() {}
  
  public void 熱(Bundle paramBundle) {}
  
  public final Activity 硬() {
    throw null;
  }
  
  public void 美() {}
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\api\internal\LifecycleCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */