package com.google.android.gms.common;

import com.google.android.gms.common.annotation.KeepName;

@KeepName
public abstract class GooglePlayServicesManifestException extends IllegalStateException {
  public GooglePlayServicesManifestException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\GooglePlayServicesManifestException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */