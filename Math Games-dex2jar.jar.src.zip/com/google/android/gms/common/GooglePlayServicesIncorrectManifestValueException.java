package com.google.android.gms.common;

import com.google.android.gms.common.annotation.KeepName;

@KeepName
public final class GooglePlayServicesIncorrectManifestValueException extends GooglePlayServicesManifestException {
  public GooglePlayServicesIncorrectManifestValueException(int paramInt) {
    super(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\common\GooglePlayServicesIncorrectManifestValueException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */