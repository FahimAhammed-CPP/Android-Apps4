package com.google.android.gms.dynamite.descriptors.com.google.android.gms.ads.dynamite;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class ModuleDescriptor {
  public static final String MODULE_ID = "com.google.android.gms.ads.dynamite";
  
  public static final int MODULE_VERSION = 224400003;
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\dynamite\descriptors\com\google\android\gms\ads\dynamite\ModuleDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */