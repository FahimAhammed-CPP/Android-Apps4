package com.google.android.gms.internal.ads;

import java.io.IOException;
import y.dp2;
import y.dr2;
import y.fp2;
import y.fr2;
import y.jq2;
import y.kp2;
import y.lf0;
import y.lp2;
import y.nr2;
import y.or2;
import y.qp2;

public final class while extends 草 {
  private static final while zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private String zzf = "";
  
  private long zzg;
  
  private long zzh;
  
  private long zzi;
  
  static {
    while while1 = new while();
    zzb = while1;
    草.寂(while.class, while1);
  }
  
  public static lf0 壊() {
    return (lf0)zzb.痛();
  }
  
  public static while 歩(dp2 paramdp2) {
    while while1 = zzb;
    qp2 qp2 = qp2.堅;
    kp2 kp2 = paramdp2.怖();
    草 草1 = while1.辛();
    try {
      nr2 nr2 = dr2.熱.硬(草1.getClass());
      lp2 lp2 = kp2.堅;
      if (lp2 == null)
        lp2 = new lp2(kp2); 
      nr2.暑(草1, lp2, qp2);
      nr2.熱(草1);
      try {
        kp2.死(0);
        草.臭(草1);
        草.臭(草1);
        return (while)草1;
      } catch (jq2 jq2) {
        throw jq2;
      } 
    } catch (jq2 jq22) {
      jq2 jq21 = jq22;
      if (jq22.淋)
        jq21 = new jq2((IOException)jq22); 
      throw jq21;
    } catch (or2 or2) {
      throw new jq2(or2.getMessage());
    } catch (IOException iOException) {
      if (iOException.getCause() instanceof jq2)
        throw (jq2)iOException.getCause(); 
      throw new jq2(iOException);
    } catch (RuntimeException runtimeException) {
      if (runtimeException.getCause() instanceof jq2)
        throw (jq2)runtimeException.getCause(); 
      throw runtimeException;
    } 
  }
  
  public static while 泳(dp2 paramdp2, qp2 paramqp2) {
    return (while)草.ぱ(zzb, (fp2)paramdp2, paramqp2);
  }
  
  public static while 返() {
    return zzb;
  }
  
  public final String 寝() {
    return this.zze;
  }
  
  public final long 死() {
    return this.zzi;
  }
  
  public final long 産() {
    return this.zzg;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new lf0()) : new while()) : new fr2(zzb, "\001\005\000\001\001\005\005\000\000\000\001ဈ\000\002ဈ\001\003ဃ\002\004ဃ\003\005ဃ\004", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", "zzi" })) : Byte.valueOf((byte)1);
  }
  
  public final long 興() {
    return this.zzh;
  }
  
  public final String 踊() {
    return this.zzf;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\while.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */