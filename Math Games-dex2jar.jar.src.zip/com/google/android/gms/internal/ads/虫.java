package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.nm2;
import y.qp2;

public final class 虫 extends 草 {
  private static final 虫 zzb;
  
  private int zzd;
  
  private 蝶 zze;
  
  static {
    虫 虫1 = new 虫();
    zzb = 虫1;
    草.寂(虫.class, 虫1);
  }
  
  public static 虫 壊(fp2 paramfp2, qp2 paramqp2) {
    return (虫)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static nm2 産() {
    return (nm2)zzb.痛();
  }
  
  public final 蝶 帰() {
    蝶 蝶2 = this.zze;
    蝶 蝶1 = 蝶2;
    if (蝶2 == null)
      蝶1 = 蝶.壊(); 
    return 蝶1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new nm2()) : new 虫()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\013\002\t", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\虫.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */