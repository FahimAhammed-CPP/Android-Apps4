package com.google.android.gms.internal.ads;

import java.io.IOException;
import java.io.InputStream;
import y.dr2;
import y.er2;
import y.fr2;
import y.gq2;
import y.jp2;
import y.jq2;
import y.kp2;
import y.lp2;
import y.nr2;
import y.or2;
import y.qp2;
import y.xo2;
import y.yn2;

public final class ズ extends 草 {
  private static final ズ zzb;
  
  private int zzd;
  
  private gq2 zze = (gq2)er2.痛;
  
  static {
    ズ ズ1 = new ズ();
    zzb = ズ1;
    草.寂(ズ.class, ズ1);
  }
  
  public static ズ 帰(InputStream paramInputStream, qp2 paramqp2) {
    ズ ズ1 = zzb;
    jp2 jp2 = new jp2(paramInputStream);
    草 草1 = ズ1.辛();
    try {
      nr2 nr2 = dr2.熱.硬(草1.getClass());
      lp2 lp2 = ((kp2)jp2).堅;
      if (lp2 == null)
        lp2 = new lp2((kp2)jp2); 
      nr2.暑(草1, lp2, paramqp2);
      nr2.熱(草1);
      草.臭(草1);
      return (ズ)草1;
    } catch (jq2 jq22) {
      jq2 jq21 = jq22;
      if (jq22.淋)
        jq21 = new jq2((IOException)jq22); 
      throw jq21;
    } catch (or2 or2) {
      throw new jq2(or2.getMessage());
    } catch (IOException iOException) {
      if (iOException.getCause() instanceof jq2)
        throw (jq2)iOException.getCause(); 
      throw new jq2(iOException);
    } catch (RuntimeException runtimeException) {
      if (runtimeException.getCause() instanceof jq2)
        throw (jq2)runtimeException.getCause(); 
      throw runtimeException;
    } 
  }
  
  public static yn2 死() {
    return (yn2)zzb.痛();
  }
  
  public static void 踊(ズ paramズ, 蝓 param蝓) {
    gq2 gq21 = paramズ.zze;
    if (!((xo2)gq21).淋)
      paramズ.zze = 草.苦(gq21); 
    paramズ.zze.add(param蝓);
  }
  
  public static ズ 返(byte[] paramArrayOfbyte, qp2 paramqp2) {
    草 草1 = 草.起(zzb, paramArrayOfbyte, paramArrayOfbyte.length, paramqp2);
    草.臭(草1);
    return (ズ)草1;
  }
  
  public final gq2 歩() {
    return this.zze;
  }
  
  public final int 産() {
    return this.zzd;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new yn2()) : new ズ()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\001\000\001\013\002\033", new Object[] { "zzd", "zze", 蝓.class })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zze.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ズ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */