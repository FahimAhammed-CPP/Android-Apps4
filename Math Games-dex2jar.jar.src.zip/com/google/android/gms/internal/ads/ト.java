package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.qp2;
import y.tm2;

public final class ト extends 草 {
  private static final ト zzb;
  
  private ボ zzd;
  
  private int zze;
  
  static {
    ト ト1 = new ト();
    zzb = ト1;
    草.寂(ト.class, ト1);
  }
  
  public static ト 壊() {
    return zzb;
  }
  
  public static ト 帰(fp2 paramfp2, qp2 paramqp2) {
    return (ト)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static tm2 産() {
    return (tm2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new tm2()) : new ト()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\t\002\013", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zze;
  }
  
  public final ボ 返() {
    ボ ボ2 = this.zzd;
    ボ ボ1 = ボ2;
    if (ボ2 == null)
      ボ1 = ボ.壊(); 
    return ボ1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ト.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */