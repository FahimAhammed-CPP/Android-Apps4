package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.qp2;
import y.zm2;

public final class ッ extends 草 {
  private static final ッ zzb;
  
  private int zzd;
  
  private fp2 zze = (fp2)fp2.怖;
  
  static {
    ッ ッ1 = new ッ();
    zzb = ッ1;
    草.寂(ッ.class, ッ1);
  }
  
  public static ッ 壊(fp2 paramfp2, qp2 paramqp2) {
    return (ッ)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static zm2 産() {
    return (zm2)zzb.痛();
  }
  
  public final fp2 帰() {
    return this.zze;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new zm2()) : new ッ()) : new fr2(zzb, "\000\002\000\000\001\003\002\000\000\000\001\013\003\n", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ッ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */