package com.google.android.gms.internal.ads;

import y.ao2;
import y.er2;
import y.fr2;
import y.gq2;
import y.xo2;

public final class 蚓 extends 草 {
  private static final 蚓 zzb;
  
  private int zzd;
  
  private gq2 zze = (gq2)er2.痛;
  
  static {
    蚓 蚓1 = new 蚓();
    zzb = 蚓1;
    草.寂(蚓.class, 蚓1);
  }
  
  public static void 壊(蚓 param蚓, 蚯 param蚯) {
    gq2 gq21 = param蚓.zze;
    if (!((xo2)gq21).淋)
      param蚓.zze = 草.苦(gq21); 
    param蚓.zze.add(param蚯);
  }
  
  public static ao2 興() {
    return (ao2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new ao2()) : new 蚓()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\001\000\001\013\002\033", new Object[] { "zzd", "zze", 蚯.class })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蚓.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */