package com.google.android.gms.internal.ads;

import y.dp2;
import y.er2;
import y.fp2;
import y.fr2;
import y.gq2;
import y.wc0;
import y.xo2;
import y.yc0;
import y.zc0;

public final class super extends 草 {
  private static final super zzb;
  
  private int zzd;
  
  private gq2 zze = (gq2)er2.痛;
  
  private fp2 zzf = (fp2)fp2.怖;
  
  private int zzg = 1;
  
  private int zzh = 1;
  
  static {
    super super1 = new super();
    zzb = super1;
    草.寂(super.class, super1);
  }
  
  public static void 死(super paramsuper, dp2 paramdp2) {
    gq2 gq21 = paramsuper.zze;
    if (!((xo2)gq21).淋)
      paramsuper.zze = 草.苦(gq21); 
    paramsuper.zze.add(paramdp2);
  }
  
  public static zc0 興() {
    return (zc0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new zc0()) : new super(); 
      yc0 yc0 = yc0.硬;
      wc0 wc0 = wc0.硬;
      return new fr2(zzb, "\001\004\000\001\001\004\004\000\001\000\001\034\002ည\000\003ဌ\001\004ဌ\002", new Object[] { "zzd", "zze", "zzf", "zzg", yc0, "zzh", wc0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\super.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */