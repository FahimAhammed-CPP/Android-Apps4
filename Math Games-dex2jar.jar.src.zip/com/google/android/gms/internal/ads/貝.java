package com.google.android.gms.internal.ads;

import y.co2;
import y.fp2;
import y.fr2;
import y.qp2;

public final class 貝 extends 草 {
  private static final 貝 zzb;
  
  private int zzd;
  
  private 殻 zze;
  
  static {
    貝 貝1 = new 貝();
    zzb = 貝1;
    草.寂(貝.class, 貝1);
  }
  
  public static 貝 壊(fp2 paramfp2, qp2 paramqp2) {
    return (貝)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static co2 産() {
    return (co2)zzb.痛();
  }
  
  public final 殻 帰() {
    殻 殻2 = this.zze;
    殻 殻1 = 殻2;
    if (殻2 == null)
      殻1 = 殻.産(); 
    return 殻1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new co2()) : new 貝()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\013\002\t", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\貝.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */