package com.google.android.gms.internal.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import y.d11;
import y.e2;
import y.i51;
import y.iq0;
import y.iz0;
import y.k2;
import y.ml0;
import y.o01;
import y.px2;
import y.qw0;
import y.rr1;
import y.sp0;
import y.t13;
import y.tp0;
import y.u03;
import y.vx0;
import y.x51;
import y.xp0;
import y.年;
import y.畳;
import y.귀;

public final class zzbyi implements MediationInterstitialAdapter {
  public k2 堅;
  
  public Uri 熱;
  
  public Activity 硬;
  
  public final void onDestroy() {
    rr1.暑("Destroying AdMobCustomTabsAdapter adapter.");
  }
  
  public final void onPause() {
    rr1.暑("Pausing AdMobCustomTabsAdapter adapter.");
  }
  
  public final void onResume() {
    rr1.暑("Resuming AdMobCustomTabsAdapter adapter.");
  }
  
  public final void requestInterstitialAd(Context paramContext, k2 paramk2, Bundle paramBundle1, e2 parame2, Bundle paramBundle2) {
    this.堅 = paramk2;
    if (paramk2 == null) {
      rr1.美("Listener not set for mediation. Returning.");
      return;
    } 
    if (paramContext instanceof Activity) {
      if (!iq0.硬(paramContext)) {
        rr1.美("Default browser does not support custom tabs. Bailing out.");
        ((d11)this.堅).硬();
        return;
      } 
      String str = paramBundle1.getString("tab_url");
      if (TextUtils.isEmpty(str)) {
        rr1.美("The tab_url retrieved from mediation metadata is empty. Bailing out.");
        ((d11)this.堅).硬();
        return;
      } 
      this.硬 = (Activity)paramContext;
      this.熱 = Uri.parse(str);
      d11 d11 = (d11)this.堅;
      d11.getClass();
      年.暑("#008 Must be called on the main UI thread.");
      rr1.暑("Adapter called onAdLoaded.");
      try {
        ((vx0)d11.怖).悲();
        return;
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
        return;
      } 
    } 
    rr1.美("AdMobCustomTabs can only work with Activity context. Bailing out.");
    ((d11)this.堅).硬();
  }
  
  public final void showInterstitial() {
    畳 畳 = (new 귀()).硬();
    ((Intent)畳.怖).setData(this.熱);
    AdOverlayInfoParcel adOverlayInfoParcel = new AdOverlayInfoParcel(new o01((Intent)畳.怖, null), null, (px2)new iz0(this), null, new x51(0, 0, false, false), null, null);
    u03.不.post((Runnable)new qw0(this, adOverlayInfoParcel, 13));
    t13 t13 = t13.帰;
    null = t13.美.ぱ;
    null.getClass();
    t13.辛.getClass();
    long l = System.currentTimeMillis();
    synchronized (null.硬) {
      if (null.熱 == 3) {
        long l1 = null.堅;
        sp0 sp0 = xp0.バ;
        if (l1 + ((Long)ml0.暑.熱.硬((tp0)sp0)).longValue() <= l)
          null.熱 = 1; 
      } 
      t13.辛.getClass();
      l = System.currentTimeMillis();
      synchronized (null.硬) {
        if (null.熱 != 2)
          return; 
        null.熱 = 3;
        if (null.熱 == 3)
          null.堅 = l; 
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\zzbyi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */