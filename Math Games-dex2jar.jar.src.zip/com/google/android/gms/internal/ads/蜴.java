package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gq2;
import y.op0;

public final class 蜴 extends 草 {
  private static final 蜴 zzb;
  
  private String zzd = "";
  
  private gq2 zze = (gq2)er2.痛;
  
  static {
    蜴 蜴1 = new 蜴();
    zzb = 蜴1;
    草.寂(蜴.class, 蜴1);
  }
  
  public static 蜴 産() {
    return zzb;
  }
  
  public final gq2 死() {
    return this.zze;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(null)) : new 蜴()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\001\000\001Ȉ\002\033", new Object[] { "zzd", "zze", 蛞.class })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蜴.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */