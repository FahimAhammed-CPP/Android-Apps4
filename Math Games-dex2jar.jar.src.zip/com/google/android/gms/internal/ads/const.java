package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.gc0;

public final class const extends 草 {
  private static final const zzb;
  
  private int zzd;
  
  private long zze;
  
  private String zzf = "";
  
  private fp2 zzg = (fp2)fp2.怖;
  
  static {
    const const1 = new const();
    zzb = const1;
    草.寂(const.class, const1);
  }
  
  public static const 死() {
    return zzb;
  }
  
  public final boolean 壊() {
    return ((this.zzd & 0x1) != 0);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(10, 0)) : new const()) : new fr2(zzb, "\001\003\000\001\001\004\003\000\000\000\001ဂ\000\003ဈ\001\004ည\002", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
  
  public final long 興() {
    return this.zze;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\const.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */