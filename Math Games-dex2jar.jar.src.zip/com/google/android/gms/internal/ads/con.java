package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;

public final class con extends 草 {
  private static final con zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  static {
    con con1 = new con();
    zzb = con1;
    草.寂(con.class, con1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(25, null)) : new con()) : new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001င\000\002င\001", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\con.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */