package com.google.android.gms.internal.ads;

import y.fr2;
import y.sn2;

public final class ツ extends 草 {
  private static final ツ zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  static {
    ツ ツ1 = new ツ();
    zzb = ツ1;
    草.寂(ツ.class, ツ1);
  }
  
  public static ツ 死() {
    return zzb;
  }
  
  public static sn2 興() {
    return (sn2)zzb.痛();
  }
  
  public final int 壊() {
    int i = this.zzf;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            b = 0;
          } else {
            b = 5;
          } 
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
  
  public final int 帰() {
    int i = this.zze;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            b = 0;
          } else {
            b = 5;
          } 
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new sn2()) : new ツ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\f\002\f\003\f", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 返() {
    int i = this.zzd;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              b = 0;
            } else {
              b = 6;
            } 
          } else {
            b = 5;
          } 
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ツ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */