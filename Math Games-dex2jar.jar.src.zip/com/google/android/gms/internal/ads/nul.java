package com.google.android.gms.internal.ads;

import y.fr2;
import y.gp0;

public final class nul extends 草 {
  private static final nul zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  private int zzg;
  
  static {
    nul nul1 = new nul();
    zzb = nul1;
    草.寂(nul.class, nul1);
  }
  
  public static gp0 興() {
    return (gp0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gp0()) : new nul()) : new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001င\000\002င\001\003င\002", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\nul.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */