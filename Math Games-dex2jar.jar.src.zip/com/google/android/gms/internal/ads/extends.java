package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gc0;
import y.gq2;

public final class extends extends 草 {
  private static final extends zzb;
  
  private int zzd;
  
  private int zze;
  
  private con zzf;
  
  private con zzg;
  
  private con zzh;
  
  private gq2 zzi = (gq2)er2.痛;
  
  private int zzj;
  
  static {
    extends extends1 = new extends();
    zzb = extends1;
    草.寂(extends.class, extends1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(15, null)) : new extends()) : new fr2(zzb, "\001\006\000\001\001\006\006\000\001\000\001င\000\002ဉ\001\003ဉ\002\004ဉ\003\005\033\006င\004", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", "zzi", con.class, "zzj" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\extends.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */