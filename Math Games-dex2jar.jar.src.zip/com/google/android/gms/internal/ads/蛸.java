package com.google.android.gms.internal.ads;

import y.fr2;
import y.gb2;
import y.hb2;

public final class 蛸 extends 草 {
  private static final 蛸 zzb;
  
  private int zzd;
  
  private int zze;
  
  private String zzf = "";
  
  private String zzg = "";
  
  private コ zzh;
  
  static {
    蛸 蛸1 = new 蛸();
    zzb = 蛸1;
    草.寂(蛸.class, 蛸1);
  }
  
  public static gb2 興() {
    return (gb2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gb2()) : new 蛸(); 
      hb2 hb2 = hb2.硬;
      return new fr2(zzb, "\001\004\000\001\001\004\004\000\000\000\001ဌ\000\002ဈ\001\003ဈ\002\004ဉ\003", new Object[] { "zzd", "zze", hb2, "zzf", "zzg", "zzh" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蛸.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */