package com.google.android.gms.internal.ads;

import y.do2;
import y.fp2;
import y.fr2;
import y.qp2;

public final class ゲ extends 草 {
  private static final ゲ zzb;
  
  private int zzd;
  
  private 蜥 zze;
  
  static {
    ゲ ゲ1 = new ゲ();
    zzb = ゲ1;
    草.寂(ゲ.class, ゲ1);
  }
  
  public static ゲ 壊(fp2 paramfp2, qp2 paramqp2) {
    return (ゲ)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static do2 産() {
    return (do2)zzb.痛();
  }
  
  public final 蜥 帰() {
    蜥 蜥2 = this.zze;
    蜥 蜥1 = 蜥2;
    if (蜥2 == null)
      蜥1 = 蜥.産(); 
    return 蜥1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new do2()) : new ゲ()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\013\002\t", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ゲ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */