package com.google.android.gms.internal.ads;

import y.fr2;
import y.jn2;

public final class ハ extends 草 {
  private static final ハ zzb;
  
  private 蚊 zzd;
  
  private ル zze;
  
  private int zzf;
  
  static {
    ハ ハ1 = new ハ();
    zzb = ハ1;
    草.寂(ハ.class, ハ1);
  }
  
  public static ハ 壊() {
    return zzb;
  }
  
  public static jn2 産() {
    return (jn2)zzb.痛();
  }
  
  public static void 踊(ハ paramハ, int paramInt) {
    if (paramInt != 1) {
      paramハ.zzf = paramInt - 2;
      return;
    } 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  public final 蚊 帰() {
    蚊 蚊2 = this.zzd;
    蚊 蚊1 = 蚊2;
    if (蚊2 == null)
      蚊1 = 蚊.死(); 
    return 蚊1;
  }
  
  public final int 泳() {
    int i = this.zzf;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            b = 0;
          } else {
            b = 5;
          } 
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new jn2()) : new ハ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\t\002\t\003\f", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final ル 興() {
    ル ル2 = this.zze;
    ル ル1 = ル2;
    if (ル2 == null)
      ル1 = ル.死(); 
    return ル1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ハ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */