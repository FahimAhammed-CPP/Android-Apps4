package com.google.android.gms.internal.ads;

import y.fr2;
import y.pp0;

public final class 鰺 extends 草 {
  private static final 鰺 zzb;
  
  private int zzd;
  
  private boolean zze;
  
  private int zzf;
  
  static {
    鰺 鰺1 = new 鰺();
    zzb = 鰺1;
    草.寂(鰺.class, 鰺1);
  }
  
  public static pp0 興() {
    return (pp0)zzb.痛();
  }
  
  public final boolean 帰() {
    return this.zze;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new pp0()) : new 鰺()) : new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001ဇ\000\002င\001", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\鰺.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */