package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.uo0;

public final class aux extends 草 {
  private static final aux zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private int zzf;
  
  private con zzg;
  
  static {
    aux aux1 = new aux();
    zzb = aux1;
    草.寂(aux.class, aux1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(24, null)) : new aux(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001ဈ\000\002ဌ\001\003ဉ\002", new Object[] { "zzd", "zze", "zzf", uo0, "zzg" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\aux.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */