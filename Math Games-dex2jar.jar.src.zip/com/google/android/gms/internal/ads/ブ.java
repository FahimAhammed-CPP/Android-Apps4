package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.on2;
import y.qp2;

public final class ブ extends 草 {
  private static final ブ zzb;
  
  private 蜚 zzd;
  
  private int zze;
  
  private int zzf;
  
  static {
    ブ ブ1 = new ブ();
    zzb = ブ1;
    草.寂(ブ.class, ブ1);
  }
  
  public static ブ 壊() {
    return zzb;
  }
  
  public static ブ 帰(fp2 paramfp2, qp2 paramqp2) {
    return (ブ)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static on2 産() {
    return (on2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new on2()) : new ブ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\t\002\013\003\013", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zze;
  }
  
  public final 蜚 返() {
    蜚 蜚2 = this.zzd;
    蜚 蜚1 = 蜚2;
    if (蜚2 == null)
      蜚1 = 蜚.壊(); 
    return 蜚1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ブ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */