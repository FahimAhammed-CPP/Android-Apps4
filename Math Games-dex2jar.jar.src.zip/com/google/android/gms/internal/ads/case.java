package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.nc0;

public final class case extends 草 {
  private static final case zzb;
  
  private int zzd;
  
  private int zze;
  
  private long zzf = -1L;
  
  static {
    case case1 = new case();
    zzb = case1;
    草.寂(case.class, case1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(7, 0)) : new case(); 
      nc0 nc0 = nc0.硬;
      return new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001ဌ\000\002ဂ\001", new Object[] { "zzd", "zze", nc0, "zzf" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\case.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */