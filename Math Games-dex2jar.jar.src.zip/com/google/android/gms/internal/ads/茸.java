package com.google.android.gms.internal.ads;

import y.as2;
import y.cq2;
import y.dq2;
import y.er2;
import y.fr2;
import y.gq2;
import y.no2;
import y.op0;
import y.xr2;
import y.zp2;
import y.zr2;

public final class 茸 extends 草 {
  private static final dq2 zzb = (dq2)new no2(7, 0);
  
  private static final 茸 zzd;
  
  private int zze;
  
  private int zzf;
  
  private boolean zzg;
  
  private String zzh = "";
  
  private gq2 zzi;
  
  private int zzj;
  
  private boolean zzk;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private String zzn;
  
  private int zzo;
  
  private int zzp;
  
  private int zzq;
  
  private boolean zzr;
  
  private gq2 zzs;
  
  private boolean zzt;
  
  private long zzu;
  
  private cq2 zzv;
  
  private boolean zzw;
  
  static {
    茸 茸1 = new 茸();
    zzd = 茸1;
    草.寂(茸.class, 茸1);
  }
  
  public 茸() {
    er2 er2 = er2.痛;
    this.zzi = (gq2)er2;
    this.zzn = "";
    this.zzs = (gq2)er2;
    this.zzv = (cq2)zp2.痛;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzd) : new op0(11, 0)) : new 茸(); 
      as2 as2 = as2.硬;
      zr2 zr2 = zr2.硬;
      xr2 xr2 = xr2.硬;
      return new fr2(zzd, "\001\022\000\001\001\022\022\000\003\000\001ဌ\000\002ဇ\001\003ဈ\002\004\032\005ဌ\003\006ဇ\004\007ဇ\005\bဇ\006\tဈ\007\nင\b\013င\t\fင\n\rဇ\013\016\033\017ဇ\f\020ဂ\r\021,\022ဇ\016", new Object[] { 
            "zze", "zzf", as2, "zzg", "zzh", "zzi", "zzj", zr2, "zzk", "zzl", 
            "zzm", "zzn", "zzo", "zzp", "zzq", "zzr", "zzs", 茎.class, "zzt", "zzu", 
            "zzv", xr2, "zzw" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\茸.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */