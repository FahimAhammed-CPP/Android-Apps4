package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.nv0;
import y.xn2;

public final class メ extends 草 {
  private static final メ zzb;
  
  private String zzd = "";
  
  private fp2 zze = (fp2)fp2.怖;
  
  private int zzf;
  
  static {
    メ メ1 = new メ();
    zzb = メ1;
    草.寂(メ.class, メ1);
  }
  
  public static メ 死() {
    return zzb;
  }
  
  public static xn2 興() {
    return (xn2)zzb.痛();
  }
  
  public final int 壊() {
    int j = nv0.堅(this.zzf);
    int i = j;
    if (j == 0)
      i = 6; 
    return i;
  }
  
  public final fp2 帰() {
    return this.zze;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new xn2()) : new メ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001Ȉ\002\n\003\f", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final String 返() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\メ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */