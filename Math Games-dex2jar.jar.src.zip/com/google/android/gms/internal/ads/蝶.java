package com.google.android.gms.internal.ads;

import y.fr2;
import y.om2;

public final class 蝶 extends 草 {
  private static final 蝶 zzb;
  
  private int zzd;
  
  static {
    蝶 蝶1 = new 蝶();
    zzb = 蝶1;
    草.寂(蝶.class, 蝶1);
  }
  
  public static 蝶 壊() {
    return zzb;
  }
  
  public static om2 産() {
    return (om2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new om2()) : new 蝶()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\000\000\001\013", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蝶.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */