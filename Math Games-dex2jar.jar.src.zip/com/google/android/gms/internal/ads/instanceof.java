package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;

public final class instanceof extends 草 {
  private static final instanceof zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  static {
    instanceof instanceof1 = new instanceof();
    zzb = instanceof1;
    草.寂(instanceof.class, instanceof1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(22, null)) : new instanceof()) : new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001င\000\002င\001", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\instanceof.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */