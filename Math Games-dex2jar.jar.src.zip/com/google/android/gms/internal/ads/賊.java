package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gq2;
import y.l92;
import y.xo2;

public final class 賊 extends 草 {
  private static final 賊 zzb;
  
  private gq2 zzd = (gq2)er2.痛;
  
  static {
    賊 賊1 = new 賊();
    zzb = 賊1;
    草.寂(賊.class, 賊1);
  }
  
  public static void 壊(賊 param賊) {
    param賊.zzd = (gq2)er2.痛;
  }
  
  public static void 帰(賊 param賊, イ paramイ) {
    gq2 gq21 = param賊.zzd;
    if (!((xo2)gq21).淋)
      param賊.zzd = 草.苦(gq21); 
    param賊.zzd.add(paramイ);
  }
  
  public static l92 産() {
    return (l92)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new l92()) : new 賊()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\001\000\001\033", new Object[] { "zzd", イ.class })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\賊.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */