package com.google.android.gms.internal.ads;

import y.fr2;
import y.k92;

public final class 鯖 extends 草 {
  private static final 鯖 zzb;
  
  private int zzd;
  
  private boolean zze;
  
  private long zzf;
  
  private int zzg;
  
  private String zzh = "";
  
  private String zzi = "";
  
  private String zzj = "";
  
  private int zzk;
  
  private int zzl;
  
  private int zzm;
  
  private long zzn;
  
  private int zzo;
  
  private String zzp = "";
  
  private String zzq = "";
  
  private String zzr = "";
  
  private String zzs = "";
  
  private String zzt = "";
  
  private String zzu = "";
  
  private String zzv = "";
  
  private String zzw = "";
  
  static {
    鯖 鯖1 = new 鯖();
    zzb = 鯖1;
    草.寂(鯖.class, 鯖1);
  }
  
  public static k92 興() {
    return (k92)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new k92()) : new 鯖()) : new fr2(zzb, "\000\024\000\000\001\024\024\000\000\000\001\f\002\007\003\002\004\f\005Ȉ\006Ȉ\007Ȉ\b\004\t\f\n\004\013\002\f\f\rȈ\016Ȉ\017Ȉ\020Ȉ\021Ȉ\022Ȉ\023Ȉ\024Ȉ", new Object[] { 
          "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", "zzl", "zzm", 
          "zzn", "zzo", "zzp", "zzq", "zzr", "zzs", "zzt", "zzu", "zzv", "zzw" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\鯖.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */