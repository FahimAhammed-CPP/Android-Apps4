package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gc0;
import y.gq2;
import y.uo0;

public final class strictfp extends 草 {
  private static final strictfp zzb;
  
  private int zzd;
  
  private abstract zze;
  
  private gq2 zzf = (gq2)er2.痛;
  
  private int zzg;
  
  private con zzh;
  
  static {
    strictfp strictfp1 = new strictfp();
    zzb = strictfp1;
    草.寂(strictfp.class, strictfp1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(19, null)) : new strictfp(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\004\000\001\001\004\004\000\001\000\001ဉ\000\002\033\003ဌ\001\004ဉ\002", new Object[] { "zzd", "zze", "zzf", aux.class, "zzg", uo0, "zzh" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\strictfp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */