package com.google.android.gms.internal.ads;

import y.cn2;
import y.fp2;
import y.fr2;
import y.qp2;

public final class ク extends 草 {
  private static final ク zzb;
  
  private int zzd;
  
  private int zze;
  
  static {
    ク ク1 = new ク();
    zzb = ク1;
    草.寂(ク.class, ク1);
  }
  
  public static ク 壊(fp2 paramfp2, qp2 paramqp2) {
    return (ク)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static cn2 産() {
    return (cn2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new cn2()) : new ク()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\013\002\013", new Object[] { "zze", "zzd" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ク.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */