package com.google.android.gms.internal.ads;

import y.an2;
import y.fp2;
import y.fr2;
import y.qp2;

public final class 飛 extends 草 {
  private static final 飛 zzb;
  
  private int zzd;
  
  private int zze;
  
  static {
    飛 飛1 = new 飛();
    zzb = 飛1;
    草.寂(飛.class, 飛1);
  }
  
  public static 飛 壊(fp2 paramfp2, qp2 paramqp2) {
    return (飛)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static an2 産() {
    return (an2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new an2()) : new 飛()) : new fr2(zzb, "\000\002\000\000\002\003\002\000\000\000\002\013\003\013", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\飛.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */