package com.google.android.gms.internal.ads;

import y.cq2;
import y.er2;
import y.fp2;
import y.fr2;
import y.gq2;
import y.op0;
import y.zp2;

public final class 林 extends 草 {
  private static final 林 zzb;
  
  private int zzd;
  
  private int zze;
  
  private String zzf = "";
  
  private cq2 zzg = (cq2)zp2.痛;
  
  private int zzh;
  
  private gq2 zzi = (gq2)er2.痛;
  
  private fp2 zzj = (fp2)fp2.怖;
  
  static {
    林 林1 = new 林();
    zzb = 林1;
    草.寂(林.class, 林1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(21, 0)) : new 林()) : new fr2(zzb, "\001\006\000\001\001\007\006\000\002\000\001င\000\002ဈ\001\003\026\005င\002\006\033\007ည\003", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", "zzi", 参.class, "zzj" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\林.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */