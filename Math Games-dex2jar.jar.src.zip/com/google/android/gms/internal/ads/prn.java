package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;

public final class prn extends 草 {
  private static final prn zzb;
  
  private int zzd;
  
  private ぐ zze;
  
  private 鰹 zzf;
  
  private 秋 zzg;
  
  private 刀 zzh;
  
  private 海 zzi;
  
  private 鮪 zzj;
  
  private 鰯 zzk;
  
  private int zzl;
  
  private int zzm;
  
  private con zzn;
  
  private int zzo;
  
  private int zzp;
  
  private int zzq;
  
  private int zzr;
  
  private int zzs;
  
  private long zzt;
  
  static {
    prn prn1 = new prn();
    zzb = prn1;
    草.寂(prn.class, prn1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(26, null)) : new prn()) : new fr2(zzb, "\001\020\000\001\005\024\020\000\000\000\005ဉ\000\006ဉ\001\007ဉ\002\bဉ\003\tဉ\004\nဉ\005\013ဉ\006\fင\007\rင\b\016ဉ\t\017င\n\020င\013\021င\f\022င\r\023င\016\024ဃ\017", new Object[] { 
          "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", "zzl", "zzm", 
          "zzn", "zzo", "zzp", "zzq", "zzr", "zzs", "zzt" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\prn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */