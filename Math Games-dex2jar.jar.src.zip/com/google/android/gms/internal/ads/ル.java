package com.google.android.gms.internal.ads;

import y.fr2;
import y.hn2;

public final class ル extends 草 {
  private static final ル zzb;
  
  private メ zzd;
  
  static {
    ル ル1 = new ル();
    zzb = ル1;
    草.寂(ル.class, ル1);
  }
  
  public static ル 死() {
    return zzb;
  }
  
  public static hn2 興() {
    return (hn2)zzb.痛();
  }
  
  public final メ 壊() {
    メ メ2 = this.zzd;
    メ メ1 = メ2;
    if (メ2 == null)
      メ1 = メ.死(); 
    return メ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new hn2()) : new ル()) : new fr2(zzb, "\000\001\000\000\002\002\001\000\000\000\002\t", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ル.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */