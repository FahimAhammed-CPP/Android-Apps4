package com.google.android.gms.internal.ads;

import y.fr2;
import y.op0;

public final class 檎 extends 草 {
  private static final 檎 zzb;
  
  private int zzd;
  
  private String zze = "";
  
  static {
    檎 檎1 = new 檎();
    zzb = 檎1;
    草.寂(檎.class, 檎1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(23, 0)) : new 檎()) : new fr2(zzb, "\001\001\000\001\001\001\001\000\000\000\001ဈ\000", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\檎.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */