package com.google.android.gms.internal.ads;

import y.dn2;
import y.dp2;
import y.fp2;
import y.fr2;
import y.qp2;

public final class モ extends 草 {
  private static final モ zzb;
  
  private int zzd;
  
  private fp2 zze = (fp2)fp2.怖;
  
  static {
    モ モ1 = new モ();
    zzb = モ1;
    草.寂(モ.class, モ1);
  }
  
  public static モ 壊(fp2 paramfp2, qp2 paramqp2) {
    return (モ)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static dn2 産() {
    return (dn2)zzb.痛();
  }
  
  public final fp2 帰() {
    return this.zze;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new dn2()) : new モ()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\013\002\n", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\モ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */