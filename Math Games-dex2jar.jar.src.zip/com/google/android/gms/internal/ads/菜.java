package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.is2;
import y.js2;

public final class 菜 extends 草 {
  private static final 菜 zzb;
  
  private int zzd;
  
  private int zze;
  
  private String zzf = "";
  
  private fp2 zzg;
  
  private fp2 zzh;
  
  static {
    菜 菜1 = new 菜();
    zzb = 菜1;
    草.寂(菜.class, 菜1);
  }
  
  public 菜() {
    dp2 dp2 = fp2.怖;
    this.zzg = (fp2)dp2;
    this.zzh = (fp2)dp2;
  }
  
  public static is2 興() {
    return (is2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new is2()) : new 菜(); 
      js2 js2 = js2.硬;
      return new fr2(zzb, "\001\004\000\001\001\004\004\000\000\000\001ဌ\000\002ဈ\001\003ည\002\004ည\003", new Object[] { "zzd", "zze", js2, "zzf", "zzg", "zzh" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\菜.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */