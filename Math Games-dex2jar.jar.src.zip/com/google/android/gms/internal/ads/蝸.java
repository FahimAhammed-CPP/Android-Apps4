package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.qp2;
import y.un2;

public final class 蝸 extends 草 {
  private static final 蝸 zzb;
  
  private int zzd;
  
  private ツ zze;
  
  private fp2 zzf = (fp2)fp2.怖;
  
  static {
    蝸 蝸1 = new 蝸();
    zzb = 蝸1;
    草.寂(蝸.class, 蝸1);
  }
  
  public static 蝸 帰() {
    return zzb;
  }
  
  public static un2 死() {
    return (un2)zzb.痛();
  }
  
  public static 蝸 返(fp2 paramfp2, qp2 paramqp2) {
    return (蝸)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public final boolean 噛() {
    return (this.zze != null);
  }
  
  public final fp2 歩() {
    return this.zzf;
  }
  
  public final ツ 産() {
    ツ ツ2 = this.zze;
    ツ ツ1 = ツ2;
    if (ツ2 == null)
      ツ1 = ツ.死(); 
    return ツ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new un2()) : new 蝸()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\013\002\t\003\n", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蝸.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */