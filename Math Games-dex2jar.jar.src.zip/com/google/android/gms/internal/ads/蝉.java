package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.qp2;
import y.sm2;

public final class 蝉 extends 草 {
  private static final 蝉 zzb;
  
  private int zzd;
  
  private ボ zze;
  
  private fp2 zzf = (fp2)fp2.怖;
  
  static {
    蝉 蝉1 = new 蝉();
    zzb = 蝉1;
    草.寂(蝉.class, 蝉1);
  }
  
  public static 蝉 壊() {
    return zzb;
  }
  
  public static 蝉 帰(fp2 paramfp2, qp2 paramqp2) {
    return (蝉)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static sm2 産() {
    return (sm2)zzb.痛();
  }
  
  public final fp2 歩() {
    return this.zzf;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new sm2()) : new 蝉()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\013\002\t\003\n", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
  
  public final ボ 返() {
    ボ ボ2 = this.zze;
    ボ ボ1 = ボ2;
    if (ボ2 == null)
      ボ1 = ボ.壊(); 
    return ボ1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蝉.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */