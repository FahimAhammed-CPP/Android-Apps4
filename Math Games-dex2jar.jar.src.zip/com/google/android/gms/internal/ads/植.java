package com.google.android.gms.internal.ads;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Logger;
import y.bm;
import y.dp2;
import y.fp2;
import y.gq2;
import y.hq2;
import y.mp2;
import y.nr2;
import y.op2;

public abstract class 植 {
  protected int zza = 0;
  
  public static void 暑(ArrayList paramArrayList, gq2<Charset> paramgq2) {
    Charset charset = hq2.硬;
    paramArrayList.getClass();
    if (paramgq2 instanceof ArrayList) {
      ArrayList arrayList = (ArrayList)paramgq2;
      int j = paramgq2.size();
      arrayList.ensureCapacity(paramArrayList.size() + j);
    } 
    int i = paramgq2.size();
    Iterator<Charset> iterator = paramArrayList.iterator();
    while (iterator.hasNext()) {
      charset = iterator.next();
      if (charset == null) {
        int j = paramgq2.size();
        StringBuilder stringBuilder = new StringBuilder("Element at index ");
        stringBuilder.append(j - i);
        stringBuilder.append(" is null.");
        String str = stringBuilder.toString();
        j = paramgq2.size();
        while (true) {
          if (--j >= i) {
            paramgq2.remove(j);
            continue;
          } 
          throw new NullPointerException(str);
        } 
      } 
      paramgq2.add(charset);
    } 
  }
  
  public final byte[] 冷() {
    try {
      int i = 寒();
      byte[] arrayOfByte = new byte[i];
      Logger logger = op2.恐;
      mp2 mp2 = new mp2(arrayOfByte, i);
      硬((op2)mp2);
      if (i - mp2.起 == 0)
        return arrayOfByte; 
      throw new IllegalStateException("Did not write as much data as expected.");
    } catch (IOException iOException) {
      throw new RuntimeException(bm.痛("Serializing ", getClass().getName(), " to a byte array threw an IOException (should never happen)."), iOException);
    } 
  }
  
  public abstract int 堅(nr2 paramnr2);
  
  public abstract int 寒();
  
  public final dp2 熱() {
    try {
      int i = 寒();
      dp2 dp2 = fp2.怖;
      byte[] arrayOfByte = new byte[i];
      Logger logger = op2.恐;
      mp2 mp2 = new mp2(arrayOfByte, i);
      硬((op2)mp2);
      if (i - mp2.起 == 0)
        return new dp2(arrayOfByte); 
      throw new IllegalStateException("Did not write as much data as expected.");
    } catch (IOException iOException) {
      throw new RuntimeException(bm.痛("Serializing ", getClass().getName(), " to a ByteString threw an IOException (should never happen)."), iOException);
    } 
  }
  
  public abstract void 硬(op2 paramop2);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\植.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */