package com.google.android.gms.internal.ads;

import y.fr2;
import y.op0;

public final class 参 extends 草 {
  private static final 参 zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private String zzf = "";
  
  static {
    参 参1 = new 参();
    zzb = 参1;
    草.寂(参.class, 参1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(20, 0)) : new 参()) : new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001ဈ\000\002ဈ\001", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\参.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */