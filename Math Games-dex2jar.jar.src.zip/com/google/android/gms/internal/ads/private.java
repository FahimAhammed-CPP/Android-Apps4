package com.google.android.gms.internal.ads;

import java.util.ArrayList;
import java.util.Arrays;
import y.fq2;
import y.fr2;
import y.gq2;
import y.rq2;
import y.uo0;
import y.vo0;
import y.xo2;

public final class private extends 草 {
  private static final private zzb;
  
  private int zzd;
  
  private int zze;
  
  private String zzf = "";
  
  private int zzg;
  
  private int zzh = 1000;
  
  private nul zzi;
  
  private fq2 zzj = (fq2)rq2.痛;
  
  private finally zzk;
  
  private package zzl;
  
  private volatile zzm;
  
  private import zzn;
  
  private transient zzo;
  
  private 鰺 zzp;
  
  private static zzq;
  
  static {
    private private1 = new private();
    zzb = private1;
    草.寂(private.class, private1);
  }
  
  public static void 歩(private paramprivate, ArrayList paramArrayList) {
    fq2 fq21 = paramprivate.zzj;
    if (!((xo2)fq21).淋) {
      int i = fq21.size();
      if (i == 0) {
        i = 10;
      } else {
        i += i;
      } 
      rq2 rq2 = (rq2)fq21;
      if (i >= rq2.恐) {
        paramprivate.zzj = (fq2)new rq2(Arrays.copyOf(rq2.怖, i), rq2.恐);
      } else {
        throw new IllegalArgumentException();
      } 
    } 
    植.暑(paramArrayList, (gq2)paramprivate.zzj);
  }
  
  public static vo0 死() {
    return (vo0)zzb.痛();
  }
  
  public static void 泳(private paramprivate) {
    paramprivate.zzj = (fq2)rq2.痛;
  }
  
  public final String 帰() {
    return this.zzf;
  }
  
  public final finally 産() {
    finally finally2 = this.zzk;
    finally finally1 = finally2;
    if (finally2 == null)
      finally1 = finally.産(); 
    return finally1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new vo0()) : new private(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\r\000\001\t\025\r\000\001\000\tင\000\nဈ\001\013ဋ\002\fဌ\003\rဉ\004\016\025\017ဉ\005\020ဉ\006\021ဉ\007\022ဉ\b\023ဉ\t\024ဉ\n\025ဉ\013", new Object[] { 
            "zzd", "zze", "zzf", "zzg", "zzh", uo0, "zzi", "zzj", "zzk", "zzl", 
            "zzm", "zzn", "zzo", "zzp", "zzq" });
    } 
    return Byte.valueOf((byte)1);
  }
  
  public final import 興() {
    import import2 = this.zzn;
    import import1 = import2;
    if (import2 == null)
      import1 = import.産(); 
    return import1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\private.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */