package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.op0;
import y.qp2;

public final class 蜥 extends 草 {
  private static final 蜥 zzb;
  
  private String zzd = "";
  
  private メ zze;
  
  static {
    蜥 蜥1 = new 蜥();
    zzb = 蜥1;
    草.寂(蜥.class, 蜥1);
  }
  
  public static 蜥 死(fp2 paramfp2, qp2 paramqp2) {
    return (蜥)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static 蜥 産() {
    return zzb;
  }
  
  public final String 壊() {
    return this.zzd;
  }
  
  public final boolean 帰() {
    return (this.zze != null);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(null)) : new 蜥()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001Ȉ\002\t", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蜥.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */