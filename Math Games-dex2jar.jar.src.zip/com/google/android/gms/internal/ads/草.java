package com.google.android.gms.internal.ads;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import y.bm;
import y.dr2;
import y.fp2;
import y.g92;
import y.gq2;
import y.jq2;
import y.kp2;
import y.lp2;
import y.nr2;
import y.op2;
import y.or2;
import y.pr2;
import y.qp2;
import y.ub0;
import y.ur2;
import y.xp2;

public abstract class 草 extends 植 {
  private static final Map zzb = new ConcurrentHashMap<Object, Object>();
  
  protected pr2 zzc = pr2.寒;
  
  private int zzd = -1;
  
  public static 草 ぱ(草 param草, fp2 paramfp2, qp2 paramqp2) {
    kp2 kp2 = paramfp2.怖();
    草 草1 = param草.辛();
    try {
      nr2 nr2 = dr2.熱.硬(草1.getClass());
      lp2 lp2 = kp2.堅;
      if (lp2 == null)
        lp2 = new lp2(kp2); 
      nr2.暑(草1, lp2, paramqp2);
      nr2.熱(草1);
      try {
        kp2.死(0);
        臭(草1);
        return 草1;
      } catch (jq2 jq2) {
        throw jq2;
      } 
    } catch (jq2 jq22) {
      jq2 jq21 = jq22;
      if (jq22.淋)
        jq21 = new jq2((IOException)jq22); 
      throw jq21;
    } catch (or2 or2) {
      throw new jq2(or2.getMessage());
    } catch (IOException iOException) {
      if (iOException.getCause() instanceof jq2)
        throw (jq2)iOException.getCause(); 
      throw new jq2(iOException);
    } catch (RuntimeException runtimeException) {
      if (runtimeException.getCause() instanceof jq2)
        throw (jq2)runtimeException.getCause(); 
      throw runtimeException;
    } 
  }
  
  public static 草 不(Class paramClass) {
    Map<ClassNotFoundException, 草> map = zzb;
    草 草2 = (草)map.get(paramClass);
    草 草1 = 草2;
    if (草2 == null)
      try {
        Class.forName(paramClass.getName(), true, paramClass.getClassLoader());
        草1 = (草)map.get(paramClass);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new IllegalStateException("Class initialization cannot fail.", classNotFoundException);
      }  
    if (草1 == null) {
      草1 = (草)((草)ur2.ぱ((Class)classNotFoundException)).痒(null, 6);
      if (草1 != null) {
        map.put(classNotFoundException, 草1);
        return 草1;
      } 
      throw new IllegalStateException();
    } 
    return 草1;
  }
  
  public static Object 嬉(Object paramObject, Method paramMethod, Object... paramVarArgs) {
    try {
      return paramMethod.invoke(paramObject, paramVarArgs);
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getCause();
      if (!(throwable instanceof RuntimeException)) {
        if (throwable instanceof Error)
          throw (Error)throwable; 
        throw new RuntimeException("Unexpected exception thrown by generated accessor method.", throwable);
      } 
      throw (RuntimeException)throwable;
    } 
  }
  
  public static void 寂(Class<?> paramClass, 草 param草) {
    param草.悲();
    zzb.put(paramClass, param草);
  }
  
  public static void 臭(草 param草) {
    if (param草.怖())
      return; 
    throw new jq2((new or2()).getMessage());
  }
  
  public static gq2 苦(gq2 paramgq2) {
    int i = paramgq2.size();
    if (i == 0) {
      i = 10;
    } else {
      i += i;
    } 
    return paramgq2.暑(i);
  }
  
  public static 草 起(草 param草, byte[] paramArrayOfbyte, int paramInt, qp2 paramqp2) {
    param草 = param草.辛();
    try {
      nr2 nr2 = dr2.熱.硬(param草.getClass());
      nr2.冷(param草, paramArrayOfbyte, 0, paramInt, new ub0(paramqp2));
      nr2.熱(param草);
      return param草;
    } catch (jq2 jq22) {
      jq2 jq21 = jq22;
      if (jq22.淋)
        jq21 = new jq2((IOException)jq22); 
      throw jq21;
    } catch (or2 or2) {
      throw new jq2(or2.getMessage());
    } catch (IOException iOException) {
      if (iOException.getCause() instanceof jq2)
        throw (jq2)iOException.getCause(); 
      throw new jq2(iOException);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      throw jq2.寒();
    } 
  }
  
  public final boolean equals(Object paramObject) {
    return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : dr2.熱.硬(getClass()).寒(this, paramObject)));
  }
  
  public final int hashCode() {
    if (!恐()) {
      int j = this.zza;
      int i = j;
      if (j == 0) {
        i = dr2.熱.硬(getClass()).美(this);
        this.zza = i;
      } 
      return i;
    } 
    return dr2.熱.硬(getClass()).美(this);
  }
  
  public final String toString() {
    String str = super.toString();
    char[] arrayOfChar = 花.硬;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("# ");
    stringBuilder.append(str);
    花.熱(this, stringBuilder, 0);
    return stringBuilder.toString();
  }
  
  public final int 堅(nr2 paramnr2) {
    if (恐()) {
      int j = 美(paramnr2);
      if (j >= 0)
        return j; 
      throw new IllegalStateException(bm.熱("serialized size must be non-negative, was ", j));
    } 
    int i = this.zzd & Integer.MAX_VALUE;
    if (i != Integer.MAX_VALUE)
      return i; 
    i = 美(paramnr2);
    if (i >= 0) {
      this.zzd = this.zzd & Integer.MIN_VALUE | i;
      return i;
    } 
    throw new IllegalStateException(bm.熱("serialized size must be non-negative, was ", i));
  }
  
  public final int 寒() {
    if (恐()) {
      int j = 美(null);
      if (j >= 0)
        return j; 
      throw new IllegalStateException(bm.熱("serialized size must be non-negative, was ", j));
    } 
    int i = this.zzd & Integer.MAX_VALUE;
    if (i != Integer.MAX_VALUE)
      return i; 
    i = 美(null);
    if (i >= 0) {
      this.zzd = this.zzd & Integer.MIN_VALUE | i;
      return i;
    } 
    throw new IllegalStateException(bm.熱("serialized size must be non-negative, was ", i));
  }
  
  public final boolean 怖() {
    草 草1 = null;
    byte b = ((Byte)痒(null, 1)).byteValue();
    if (b == 1)
      return true; 
    if (b == 0)
      return false; 
    boolean bool = dr2.熱.硬(getClass()).辛(this);
    if (true == bool)
      草1 = this; 
    痒(草1, 2);
    return bool;
  }
  
  public final boolean 恐() {
    return ((this.zzd & Integer.MIN_VALUE) != 0);
  }
  
  public final void 悲() {
    this.zzd &= Integer.MAX_VALUE;
  }
  
  public final xp2 旨() {
    xp2 xp2 = (xp2)痒(null, 5);
    xp2.硬(this);
    return xp2;
  }
  
  public final void 淋() {
    this.zzd = this.zzd & Integer.MIN_VALUE | Integer.MAX_VALUE;
  }
  
  public abstract Object 痒(草 param草, int paramInt);
  
  public final xp2 痛() {
    return (xp2)痒(null, 5);
  }
  
  public final void 硬(op2 paramop2) {
    g92 g921;
    nr2 nr2 = dr2.熱.硬(getClass());
    g92 g922 = paramop2.怖;
    if (g922 != null) {
      g921 = g922;
    } else {
      g921 = new g92((op2)g921);
    } 
    nr2.不(this, g921);
  }
  
  public final int 美(nr2 paramnr2) {
    return (paramnr2 == null) ? dr2.熱.硬(getClass()).旨(this) : paramnr2.旨(this);
  }
  
  public final 草 辛() {
    return (草)痒(null, 4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\草.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */