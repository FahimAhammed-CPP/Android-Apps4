package com.google.android.gms.internal.ads;

import y.fr2;
import y.uc0;

public final class this extends 草 {
  private static final this zzb;
  
  private int zzd;
  
  private long zze = -1L;
  
  private long zzf = -1L;
  
  private long zzg = -1L;
  
  private long zzh = -1L;
  
  private long zzi = -1L;
  
  private long zzj = -1L;
  
  private long zzk = -1L;
  
  private long zzl = -1L;
  
  static {
    this this1 = new this();
    zzb = this1;
    草.寂(this.class, this1);
  }
  
  public static uc0 興() {
    return (uc0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new uc0()) : new this()) : new fr2(zzb, "\001\b\000\001\001\b\b\000\000\000\001ဂ\000\002ဂ\001\003ဂ\002\004ဂ\003\005ဂ\004\006ဂ\005\007ဂ\006\bဂ\007", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", "zzl" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\this.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */