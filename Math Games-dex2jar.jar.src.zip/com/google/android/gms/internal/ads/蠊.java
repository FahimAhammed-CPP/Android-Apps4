package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.qp2;
import y.rn2;

public final class 蠊 extends 草 {
  private static final 蠊 zzb;
  
  private ツ zzd;
  
  static {
    蠊 蠊1 = new 蠊();
    zzb = 蠊1;
    草.寂(蠊.class, 蠊1);
  }
  
  public static 蠊 死(fp2 paramfp2, qp2 paramqp2) {
    return (蠊)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static rn2 興() {
    return (rn2)zzb.痛();
  }
  
  public final ツ 壊() {
    ツ ツ2 = this.zzd;
    ツ ツ1 = ツ2;
    if (ツ2 == null)
      ツ1 = ツ.死(); 
    return ツ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new rn2()) : new 蠊()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\000\000\001\t", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蠊.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */