package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.uo0;

public final class implements extends 草 {
  private static final implements zzb;
  
  private int zzd;
  
  private int zze = 1000;
  
  private int zzf = 1000;
  
  private int zzg;
  
  private int zzh;
  
  private int zzi;
  
  private int zzj;
  
  private int zzk;
  
  private int zzl;
  
  private int zzm;
  
  private int zzn;
  
  private instanceof zzo;
  
  static {
    implements implements1 = new implements();
    zzb = implements1;
    草.寂(implements.class, implements1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(21, null)) : new implements(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\013\000\001\001\013\013\000\000\000\001ဌ\000\002ဌ\001\003င\002\004င\003\005င\004\006င\005\007င\006\bင\007\tင\b\nင\t\013ဉ\n", new Object[] { 
            "zzd", "zze", uo0, "zzf", uo0, "zzg", "zzh", "zzi", "zzj", "zzk", 
            "zzl", "zzm", "zzn", "zzo" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\implements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */