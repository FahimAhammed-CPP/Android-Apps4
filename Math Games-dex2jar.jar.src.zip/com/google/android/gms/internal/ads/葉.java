package com.google.android.gms.internal.ads;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import y.bq2;
import y.fp2;
import y.g92;
import y.nq2;
import y.nr2;
import y.op2;
import y.pr2;
import y.rq2;
import y.zp2;

public abstract class 葉 {
  public static final 根 堅 = 興(false);
  
  public static final 根 暑;
  
  public static final 根 熱 = 興(true);
  
  public static final Class 硬;
  
  static {
    暑 = new 根();
  }
  
  public static int あ(List paramList) {
    rq2<Long> rq2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof rq2) {
      rq2 = (rq2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          rq2.旨(j);
          m += op2.痒(rq2.怖[j]);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += op2.痒(((Long)rq2.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static int か(int paramInt, nr2 paramnr2, Object paramObject) {
    paramObject = paramObject;
    paramInt = op2.痛(paramInt << 3);
    int i = paramObject.堅(paramnr2);
    return op2.痛(i) + i + paramInt;
  }
  
  public static int ち(int paramInt, List<植> paramList, nr2 paramnr2) {
    int k = paramList.size();
    int j = 0;
    if (k == 0)
      return 0; 
    int i = op2.恐(paramInt) * k;
    for (paramInt = j; paramInt < k; paramInt++) {
      j = ((植)paramList.get(paramInt)).堅(paramnr2);
      i += op2.痛(j) + j;
    } 
    return i;
  }
  
  public static void ぱ(int paramInt, List paramList, g92 paramg92, nr2 paramnr2) {
    if (paramList != null && !paramList.isEmpty()) {
      int i;
      for (i = 0; i < paramList.size(); i++)
        paramg92.淋(paramInt, paramnr2, paramList.get(i)); 
    } 
  }
  
  public static int も(List paramList) {
    rq2<Long> rq2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof rq2) {
      rq2 = (rq2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          rq2.旨(j);
          long l = rq2.怖[j];
          m += op2.痒(l >> 63L ^ l + l);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          long l = ((Long)rq2.get(j)).longValue();
          m += op2.痒(l >> 63L ^ l + l);
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static int ゃ(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = 赤(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static int わ(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = も(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static void 不(int paramInt, List<Long> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Long)paramList.get(paramInt)).longValue();
          i += 8;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.返(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).帰(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void 冷(int paramInt, List<fp2> paramList, g92 paramg92) {
    if (paramList != null && !paramList.isEmpty()) {
      paramg92.getClass();
      for (int i = 0; i < paramList.size(); i++)
        ((op2)paramg92.淋).産(paramInt, paramList.get(i)); 
    } 
  }
  
  public static int 噛(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = 触(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static void 堅(根 param根, Object paramObject1, Object paramObject2) {
    param根.getClass();
    paramObject1 = paramObject1;
    pr2 pr21 = ((草)paramObject1).zzc;
    paramObject2 = ((草)paramObject2).zzc;
    pr2 pr22 = pr2.寒;
    if (!pr22.equals(paramObject2)) {
      int[] arrayOfInt;
      if (pr22.equals(pr21)) {
        int i = pr21.硬 + ((pr2)paramObject2).硬;
        arrayOfInt = Arrays.copyOf(pr21.堅, i);
        System.arraycopy(((pr2)paramObject2).堅, 0, arrayOfInt, pr21.硬, ((pr2)paramObject2).硬);
        Object[] arrayOfObject = Arrays.copyOf(pr21.熱, i);
        System.arraycopy(((pr2)paramObject2).熱, 0, arrayOfObject, pr21.硬, ((pr2)paramObject2).硬);
        pr21 = new pr2(i, arrayOfInt, arrayOfObject, true);
      } else {
        pr21.getClass();
        if (!paramObject2.equals(arrayOfInt))
          if (pr21.冷) {
            int i = pr21.硬 + ((pr2)paramObject2).硬;
            pr21.冷(i);
            System.arraycopy(((pr2)paramObject2).堅, 0, pr21.堅, pr21.硬, ((pr2)paramObject2).硬);
            System.arraycopy(((pr2)paramObject2).熱, 0, pr21.熱, pr21.硬, ((pr2)paramObject2).硬);
            pr21.硬 = i;
          } else {
            throw new UnsupportedOperationException();
          }  
      } 
    } 
    ((草)paramObject1).zzc = pr21;
  }
  
  public static int 壊(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = 帰(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static void 嬉(int paramInt, List<Long> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          i += op2.痒(((Long)paramList.get(paramInt)).longValue());
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.か(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).あ(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void 寂(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Integer)paramList.get(paramInt)).intValue();
          i += 4;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.壊(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).死(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void 寒(int paramInt, List<Double> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Double)paramList.get(paramInt)).doubleValue();
          i += 8;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.返(Double.doubleToRawLongBits(((Double)paramList.get(paramInt)).doubleValue())); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).帰(paramInt, Double.doubleToRawLongBits(((Double)paramList.get(i)).doubleValue()));
          i++;
        } 
      } 
    } 
  }
  
  public static int 寝(int paramInt, List<植> paramList, nr2 paramnr2) {
    int j = paramList.size();
    int i = 0;
    if (j != 0) {
      int k = 0;
      while (i < j) {
        k += op2.ち(paramInt, paramList.get(i), paramnr2);
        i++;
      } 
      return k;
    } 
    return 0;
  }
  
  public static int 帰(List paramList) {
    zp2<Integer> zp2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof zp2) {
      zp2 = (zp2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          zp2.旨(j);
          m += op2.ゃ(zp2.怖[j]);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += op2.ゃ(((Integer)zp2.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void 怖(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      int j = 0;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          int k = ((Integer)paramList.get(paramInt)).intValue();
          i += op2.痛(k >> 31 ^ k + k);
          paramInt++;
        } 
        object.投(i);
        for (paramInt = j; paramInt < paramList.size(); paramInt++) {
          i = ((Integer)paramList.get(paramInt)).intValue();
          object.投(i >> 31 ^ i + i);
        } 
      } else {
        while (i < paramList.size()) {
          op2 op2 = (op2)object;
          j = ((Integer)paramList.get(i)).intValue();
          op2.触(paramInt, j >> 31 ^ j + j);
          i++;
        } 
      } 
    } 
  }
  
  public static void 恐(int paramInt, List<Long> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          long l = ((Long)paramList.get(paramInt)).longValue();
          i += op2.痒(l >> 63L ^ l + l);
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++) {
          long l = ((Long)paramList.get(paramInt)).longValue();
          object.か(l >> 63L ^ l + l);
        } 
      } else {
        while (i < paramList.size()) {
          op2 op2 = (op2)object;
          long l = ((Long)paramList.get(i)).longValue();
          op2.あ(paramInt, l >> 63L ^ l + l);
          i++;
        } 
      } 
    } 
  }
  
  public static void 悲(int paramInt, List paramList, g92 paramg92, nr2 paramnr2) {
    if (paramList != null && !paramList.isEmpty()) {
      int i;
      for (i = 0; i < paramList.size(); i++)
        paramg92.痛(paramInt, paramnr2, paramList.get(i)); 
    } 
  }
  
  public static int 投(int paramInt, List paramList) {
    if (paramList.size() == 0)
      return 0; 
    int i = あ(paramList);
    int j = paramList.size();
    return op2.恐(paramInt) * j + i;
  }
  
  public static void 旨(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Integer)paramList.get(paramInt)).intValue();
          i += 4;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.壊(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).死(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void 暑(int paramInt, List paramList, g92 paramg92, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static int 歩(List paramList) {
    return paramList.size() * 4;
  }
  
  public static int 死(int paramInt, List<fp2> paramList) {
    int i = paramList.size();
    int j = 0;
    if (i == 0)
      return 0; 
    i = op2.恐(paramInt) * i;
    for (paramInt = j; paramInt < paramList.size(); paramInt++) {
      j = ((fp2)paramList.get(paramInt)).辛();
      i += op2.痛(j) + j;
    } 
    return i;
  }
  
  public static int 泳(int paramInt, List paramList) {
    int i = paramList.size();
    return (i == 0) ? 0 : ((op2.痛(paramInt << 3) + 8) * i);
  }
  
  public static void 淋(int paramInt, List<Long> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Long)paramList.get(paramInt)).longValue();
          i += 8;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.返(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).帰(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static boolean 熱(Object paramObject1, Object paramObject2) {
    boolean bool = true;
    if (paramObject1 != paramObject2) {
      if (paramObject1 != null)
        return paramObject1.equals(paramObject2); 
      bool = false;
    } 
    return bool;
  }
  
  public static int 産(List paramList) {
    return paramList.size();
  }
  
  public static void 痒(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          i += op2.痛(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.投(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).触(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void 痛(int paramInt, List<String> paramList, g92 paramg92) {
    if (paramList != null && !paramList.isEmpty()) {
      paramg92.getClass();
      boolean bool = paramList instanceof nq2;
      int i = 0;
      byte b = 0;
      Object object = paramg92.淋;
      if (bool) {
        nq2 nq2 = (nq2)paramList;
        for (i = b; i < paramList.size(); i++) {
          Object object1 = nq2.あ(i);
          if (object1 instanceof String) {
            ((op2)object).寝((String)object1, paramInt);
          } else {
            ((op2)object).産(paramInt, (fp2)object1);
          } 
        } 
      } else {
        while (i < paramList.size()) {
          ((op2)object).寝(paramList.get(i), paramInt);
          i++;
        } 
      } 
    } 
  }
  
  public static Object 硬(Object paramObject1, int paramInt, List<Integer> paramList, bq2 parambq2, Object paramObject2, 根 param根) {
    if (parambq2 == null)
      return paramObject2; 
    if (paramList instanceof java.util.RandomAccess) {
      int k = paramList.size();
      int i = 0;
      int j = 0;
      while (i < k) {
        int m = ((Integer)paramList.get(i)).intValue();
        if (parambq2.硬(m)) {
          if (i != j)
            paramList.set(j, Integer.valueOf(m)); 
          j++;
        } else {
          Object object = paramObject2;
          if (paramObject2 == null) {
            param根.getClass();
            object = 根.堅(paramObject1);
          } 
          long l = m;
          param根.getClass();
          ((pr2)object).熱(paramInt << 3, Long.valueOf(l));
          paramObject2 = object;
        } 
        i++;
      } 
      if (j == k)
        return paramObject2; 
      paramList.subList(j, k).clear();
      return paramObject2;
    } 
    Iterator<Integer> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      int i = ((Integer)iterator.next()).intValue();
      if (!parambq2.硬(i)) {
        Object object = paramObject2;
        if (paramObject2 == null) {
          param根.getClass();
          object = 根.堅(paramObject1);
        } 
        long l = i;
        param根.getClass();
        ((pr2)object).熱(paramInt << 3, Long.valueOf(l));
        iterator.remove();
        paramObject2 = object;
      } 
    } 
    return paramObject2;
  }
  
  public static void 美(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          i += op2.ゃ(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.泳(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).歩(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int 臭(int paramInt, List paramList) {
    int i = paramList.size();
    return (i == 0) ? 0 : ((op2.痛(paramInt << 3) + 1) * i);
  }
  
  public static 根 興(boolean paramBoolean) {
    Exception exception;
    try {
      Class<?> clazz = Class.forName("com.google.protobuf.UnknownFieldSetSchema");
    } finally {
      exception = null;
    } 
    try {
      return exception.getConstructor(new Class[] { boolean.class }).newInstance(new Object[] { Boolean.valueOf(paramBoolean) });
    } finally {
      exception = null;
    } 
  }
  
  public static int 若(int paramInt, List paramList) {
    nq2<Object> nq2;
    int k = paramList.size();
    int i = 0;
    byte b = 0;
    if (k == 0)
      return 0; 
    int j = op2.恐(paramInt) * k;
    paramInt = j;
    if (paramList instanceof nq2) {
      nq2 = (nq2)paramList;
      paramInt = j;
      i = b;
      while (true) {
        j = paramInt;
        if (i < k) {
          Object object = nq2.あ(i);
          if (object instanceof fp2) {
            j = ((fp2)object).辛();
            j = op2.痛(j) + j;
          } else {
            j = op2.怖((String)object);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } else {
      while (true) {
        j = paramInt;
        if (i < k) {
          fp2 fp2 = (fp2)nq2.get(i);
          if (fp2 instanceof fp2) {
            j = ((fp2)fp2).辛();
            j = op2.痛(j) + j;
          } else {
            j = op2.怖((String)fp2);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  public static void 苦(int paramInt, List<Integer> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          i += op2.ゃ(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.泳(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).歩(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int 触(List paramList) {
    zp2<Integer> zp2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof zp2) {
      zp2 = (zp2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          zp2.旨(j);
          m += op2.ゃ(zp2.怖[j]);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += op2.ゃ(((Integer)zp2.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static int 赤(List paramList) {
    zp2<Integer> zp2;
    int k = paramList.size();
    int j = 0;
    int i = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof zp2) {
      zp2 = (zp2)paramList;
      int m = 0;
      while (true) {
        j = m;
        if (i < k) {
          zp2.旨(i);
          j = zp2.怖[i];
          m += op2.痛(j >> 31 ^ j + j);
          i++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      i = j;
      while (true) {
        j = m;
        if (i < k) {
          j = ((Integer)zp2.get(i)).intValue();
          m += op2.痛(j >> 31 ^ j + j);
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  public static void 起(int paramInt, List<Long> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          i += op2.痒(((Long)paramList.get(paramInt)).longValue());
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.か(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).あ(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int 踊(List paramList) {
    return paramList.size() * 8;
  }
  
  public static void 辛(int paramInt, List<Float> paramList, g92 paramg92, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty()) {
      Object object = paramg92.淋;
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        object = object;
        object.噛(paramInt, 2);
        paramInt = 0;
        i = 0;
        while (paramInt < paramList.size()) {
          ((Float)paramList.get(paramInt)).floatValue();
          i += 4;
          paramInt++;
        } 
        object.投(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          object.壊(Float.floatToRawIntBits(((Float)paramList.get(paramInt)).floatValue())); 
      } else {
        while (i < paramList.size()) {
          ((op2)object).死(paramInt, Float.floatToRawIntBits(((Float)paramList.get(i)).floatValue()));
          i++;
        } 
      } 
    } 
  }
  
  public static int 返(int paramInt, List paramList) {
    int i = paramList.size();
    return (i == 0) ? 0 : ((op2.痛(paramInt << 3) + 4) * i);
  }
  
  public static int 코(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = 쾌(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static int 쾌(List paramList) {
    zp2<Integer> zp2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof zp2) {
      zp2 = (zp2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          zp2.旨(j);
          m += op2.痛(zp2.怖[j]);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += op2.痛(((Integer)zp2.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static int 크(int paramInt, List paramList) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = 큰(paramList);
    return op2.恐(paramInt) * i + j;
  }
  
  public static int 큰(List paramList) {
    rq2<Long> rq2;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof rq2) {
      rq2 = (rq2)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          rq2.旨(j);
          m += op2.痒(rq2.怖[j]);
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += op2.痒(((Long)rq2.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static {
    Exception exception;
    try {
      Class<?> clazz = Class.forName("com.google.protobuf.GeneratedMessage");
    } finally {
      exception = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\葉.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */