package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gq2;
import y.io0;
import y.xo2;

public final class static extends 草 {
  private static final static zzb;
  
  private gq2 zzd = (gq2)er2.痛;
  
  static {
    static static1 = new static();
    zzb = static1;
    草.寂(static.class, static1);
  }
  
  public static void 死(static paramstatic, native paramnative) {
    gq2 gq21 = paramstatic.zzd;
    if (!((xo2)gq21).淋)
      paramstatic.zzd = 草.苦(gq21); 
    paramstatic.zzd.add(paramnative);
  }
  
  public static io0 興() {
    return (io0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new io0()) : new static()) : new fr2(zzb, "\001\001\000\000\001\001\001\000\001\000\001\033", new Object[] { "zzd", native.class })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\static.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */