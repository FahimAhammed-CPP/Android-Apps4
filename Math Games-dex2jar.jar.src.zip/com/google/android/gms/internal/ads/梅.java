package com.google.android.gms.internal.ads;

import y.es2;
import y.fr2;
import y.fs2;
import y.op0;

public final class 梅 extends 草 {
  private static final 梅 zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  private boolean zzg;
  
  private long zzh;
  
  static {
    梅 梅1 = new 梅();
    zzb = 梅1;
    草.寂(梅.class, 梅1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(15, 0)) : new 梅(); 
      fs2 fs2 = fs2.硬;
      es2 es2 = es2.硬;
      return new fr2(zzb, "\001\004\000\001\001\004\004\000\000\000\001ဌ\000\002ဌ\001\003ဇ\002\004ဂ\003", new Object[] { "zzd", "zze", fs2, "zzf", es2, "zzg", "zzh" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\梅.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */