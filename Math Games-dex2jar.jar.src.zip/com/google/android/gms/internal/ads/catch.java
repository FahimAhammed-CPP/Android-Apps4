package com.google.android.gms.internal.ads;

import y.cq2;
import y.fr2;
import y.gc0;
import y.zp2;

public final class catch extends 草 {
  private static final catch zzb;
  
  private int zzd;
  
  private long zze;
  
  private int zzf;
  
  private boolean zzg;
  
  private cq2 zzh = (cq2)zp2.痛;
  
  private long zzi;
  
  static {
    catch catch1 = new catch();
    zzb = catch1;
    草.寂(catch.class, catch1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(9, 0)) : new catch()) : new fr2(zzb, "\001\005\000\001\001\005\005\000\001\000\001ဂ\000\002င\001\003ဇ\002\004\026\005ဃ\003", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", "zzi" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\catch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */