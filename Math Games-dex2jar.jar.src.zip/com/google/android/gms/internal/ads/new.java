package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.xc0;

public final class new extends 草 {
  private static final new zzb;
  
  private int zzd;
  
  private long zze = -1L;
  
  private int zzf = 1000;
  
  private int zzg = 1000;
  
  static {
    new new1 = new new();
    zzb = new1;
    草.寂(new.class, new1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(5, 0)) : new new(); 
      xc0 xc0 = xc0.硬;
      return new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001ဂ\000\002ဌ\001\003ဌ\002", new Object[] { "zzd", "zze", "zzf", xc0, "zzg", xc0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\new.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */