package com.google.android.gms.internal.ads;

import y.fr2;
import y.op0;

public final class 蛞 extends 草 {
  private static final 蛞 zzb;
  
  private String zzd = "";
  
  private String zze = "";
  
  private int zzf;
  
  private boolean zzg;
  
  private String zzh = "";
  
  static {
    蛞 蛞1 = new 蛞();
    zzb = 蛞1;
    草.寂(蛞.class, 蛞1);
  }
  
  public final String 壊() {
    return this.zze;
  }
  
  public final String 死() {
    return this.zzd;
  }
  
  public final String 産() {
    return this.zzh;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(null)) : new 蛞()) : new fr2(zzb, "\000\005\000\000\001\005\005\000\000\000\001Ȉ\002Ȉ\003\013\004\007\005Ȉ", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蛞.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */