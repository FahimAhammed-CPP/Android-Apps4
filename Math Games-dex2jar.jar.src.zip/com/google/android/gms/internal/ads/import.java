package com.google.android.gms.internal.ads;

import y.eo0;
import y.er2;
import y.fo0;
import y.fr2;
import y.go0;
import y.gq2;
import y.uo0;

public final class import extends 草 {
  private static final import zzb;
  
  private int zzd;
  
  private int zze;
  
  private int zzf = 1000;
  
  private throws zzg;
  
  private default zzh;
  
  private gq2 zzi;
  
  private extends zzj;
  
  private implements zzk;
  
  private interface zzl;
  
  private continue zzm;
  
  private strictfp zzn;
  
  private gq2 zzo;
  
  static {
    import import1 = new import();
    zzb = import1;
    草.寂(import.class, import1);
  }
  
  public import() {
    er2 er2 = er2.痛;
    this.zzi = (gq2)er2;
    this.zzo = (gq2)er2;
  }
  
  public static void 壊(import paramimport, fo0 paramfo0) {
    paramimport.zze = paramfo0.淋;
    paramimport.zzd |= 0x1;
  }
  
  public static import 産() {
    return zzb;
  }
  
  public final default 死() {
    default default2 = this.zzh;
    default default1 = default2;
    if (default2 == null)
      default1 = default.産(); 
    return default1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new go0()) : new import(); 
      eo0 eo0 = eo0.硬;
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\013\000\001\007\021\013\000\002\000\007ဌ\000\bဌ\001\tဉ\002\nဉ\003\013\033\fဉ\004\rဉ\005\016ဉ\006\017ဉ\007\020ဉ\b\021\033", new Object[] { 
            "zzd", "zze", eo0, "zzf", uo0, "zzg", "zzh", "zzi", switch.class, "zzj", 
            "zzk", "zzl", "zzm", "zzn", "zzo", prn.class });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\import.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */