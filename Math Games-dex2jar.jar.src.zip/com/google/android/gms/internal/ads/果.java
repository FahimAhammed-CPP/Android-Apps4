package com.google.android.gms.internal.ads;

import y.cq2;
import y.er2;
import y.fr2;
import y.gq2;
import y.ls2;
import y.ms2;
import y.xo2;
import y.zp2;

public final class 果 extends 草 {
  private static final 果 zzb;
  
  private int zzd;
  
  private int zze;
  
  private String zzf = "";
  
  private 麦 zzg;
  
  private 野 zzh;
  
  private int zzi;
  
  private cq2 zzj = (cq2)zp2.痛;
  
  private String zzk = "";
  
  private int zzl;
  
  private gq2 zzm = (gq2)er2.痛;
  
  private byte zzn = 2;
  
  static {
    果 果1 = new 果();
    zzb = 果1;
    草.寂(果.class, 果1);
  }
  
  public static void 泳(果 param果, String paramString) {
    paramString.getClass();
    gq2 gq21 = param果.zzm;
    if (!((xo2)gq21).淋)
      param果.zzm = 草.苦(gq21); 
    param果.zzm.add(paramString);
  }
  
  public static ms2 産() {
    return (ms2)zzb.痛();
  }
  
  public final String 壊() {
    return this.zzf;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      boolean bool = false;
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            if (paramInt != 5) {
              if (param草 != null)
                bool = true; 
              this.zzn = bool;
              return null;
            } 
            return zzb;
          } 
          return new ms2();
        } 
        return new 果();
      } 
      ls2 ls2 = ls2.硬;
      return new fr2(zzb, "\001\t\000\001\001\t\t\000\002\003\001ᔄ\000\002ဈ\001\003ᐉ\002\004ᐉ\003\005င\004\006\026\007ဈ\005\bဌ\006\t\032", new Object[] { 
            "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", "zzl", ls2, 
            "zzm" });
    } 
    return Byte.valueOf(this.zzn);
  }
  
  public final int 興() {
    return this.zzm.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\果.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */