package com.google.android.gms.internal.ads;

import y.fr2;
import y.ns2;
import y.os2;

public final class 芋 extends 草 {
  private static final 芋 zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private long zzf;
  
  private boolean zzg;
  
  private int zzh;
  
  private String zzi = "";
  
  private String zzj = "";
  
  static {
    芋 芋1 = new 芋();
    zzb = 芋1;
    草.寂(芋.class, 芋1);
  }
  
  public static ns2 興() {
    return (ns2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new ns2()) : new 芋(); 
      os2 os2 = os2.硬;
      return new fr2(zzb, "\001\006\000\001\001\006\006\000\000\000\001ဈ\000\002ဂ\001\003ဇ\002\004ဌ\003\005ဈ\004\006ဈ\005", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh", os2, "zzi", "zzj" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\芋.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */