package com.google.android.gms.internal.ads;

import y.fr2;
import y.m92;

public final class イ extends 草 {
  private static final イ zzb;
  
  private 鯖 zzd;
  
  static {
    イ イ1 = new イ();
    zzb = イ1;
    草.寂(イ.class, イ1);
  }
  
  public static m92 興() {
    return (m92)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new m92()) : new イ()) : new fr2(zzb, "\000\001\000\000\006\006\001\000\000\000\006\t", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\イ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */