package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.op0;

public final class 稲 extends 草 {
  private static final 稲 zzb;
  
  private int zzd;
  
  private fp2 zze;
  
  private fp2 zzf;
  
  private fp2 zzg;
  
  static {
    稲 稲1 = new 稲();
    zzb = 稲1;
    草.寂(稲.class, 稲1);
  }
  
  public 稲() {
    dp2 dp2 = fp2.怖;
    this.zze = (fp2)dp2;
    this.zzf = (fp2)dp2;
    this.zzg = (fp2)dp2;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(16, 0)) : new 稲()) : new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001ည\000\002ည\001\003ည\002", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\稲.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */