package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.ln2;
import y.qp2;

public final class 蠅 extends 草 {
  private static final 蠅 zzb;
  
  private int zzd;
  
  private ハ zze;
  
  private fp2 zzf;
  
  private fp2 zzg;
  
  static {
    蠅 蠅1 = new 蠅();
    zzb = 蠅1;
    草.寂(蠅.class, 蠅1);
  }
  
  public 蠅() {
    dp2 dp2 = fp2.怖;
    this.zzf = (fp2)dp2;
    this.zzg = (fp2)dp2;
  }
  
  public static 蠅 帰() {
    return zzb;
  }
  
  public static ln2 死() {
    return (ln2)zzb.痛();
  }
  
  public static 蠅 返(fp2 paramfp2, qp2 paramqp2) {
    return (蠅)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public final fp2 歩() {
    return this.zzf;
  }
  
  public final fp2 泳() {
    return this.zzg;
  }
  
  public final ハ 産() {
    ハ ハ2 = this.zze;
    ハ ハ1 = ハ2;
    if (ハ2 == null)
      ハ1 = ハ.壊(); 
    return ハ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new ln2()) : new 蠅()) : new fr2(zzb, "\000\004\000\000\001\004\004\000\000\000\001\013\002\t\003\n\004\n", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蠅.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */