package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.op0;
import y.qp2;

public final class 熊 extends 草 {
  private static final 熊 zzb;
  
  private int zzd;
  
  static {
    熊 熊1 = new 熊();
    zzb = 熊1;
    草.寂(熊.class, 熊1);
  }
  
  public static 熊 死(fp2 paramfp2, qp2 paramqp2) {
    return (熊)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static 熊 産() {
    return zzb;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(null)) : new 熊()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\000\000\001\013", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\熊.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */