package com.google.android.gms.internal.ads;

import y.fp2;
import y.g92;
import y.iq2;
import y.jq2;
import y.kp2;
import y.lp2;
import y.pr2;

public final class 根 {
  public static boolean 冷(Object paramObject, lp2 paramlp2) {
    fp2 fp2;
    pr2 pr2;
    int j = paramlp2.堅;
    int i = j >>> 3;
    j &= 0x7;
    null = false;
    kp2 kp2 = paramlp2.硬;
    if (j != 0) {
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j != 4) {
              if (j == 5) {
                paramlp2.怖(5);
                j = kp2.ぱ();
                ((pr2)paramObject).熱(i << 3 | 0x5, Integer.valueOf(j));
              } else {
                i = jq2.怖;
                throw new iq2();
              } 
            } else {
              return null;
            } 
          } else {
            pr2 = pr2.堅();
            i <<= 3;
            do {
            
            } while (paramlp2.痒() != Integer.MAX_VALUE && 冷(pr2, paramlp2));
            if ((i | 0x4) == paramlp2.堅) {
              pr2.冷 = false;
              ((pr2)paramObject).熱(i | 0x3, pr2);
            } else {
              throw new jq2("Protocol message end-group tag did not match expected tag.");
            } 
          } 
        } else {
          fp2 = paramlp2.臭();
          ((pr2)paramObject).熱(i << 3 | 0x2, fp2);
        } 
      } else {
        fp2.怖(1);
        long l = pr2.怖();
        ((pr2)paramObject).熱(i << 3 | 0x1, Long.valueOf(l));
      } 
    } else {
      fp2.怖(0);
      long l = pr2.恐();
      ((pr2)paramObject).熱(i << 3, Long.valueOf(l));
    } 
    return true;
  }
  
  public static void 寒(pr2 parampr2, g92 paramg92) {
    parampr2.暑(paramg92);
  }
  
  public static void 暑(Object paramObject) {
    ((草)paramObject).zzc.冷 = false;
  }
  
  public static pr2 熱(Object paramObject) {
    return ((草)paramObject).zzc;
  }
  
  public static int 硬(pr2 parampr2) {
    return parampr2.硬();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\根.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */