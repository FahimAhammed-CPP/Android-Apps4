package com.google.android.gms.internal.ads;

import java.util.ArrayList;
import y.bs2;
import y.cs2;
import y.er2;
import y.fp2;
import y.fr2;
import y.gq2;
import y.ks2;
import y.xo2;

public final class 大 extends 草 {
  private static final 大 zzb;
  
  private gq2 zzA;
  
  private 松 zzB;
  
  private String zzC;
  
  private 茸 zzD;
  
  private gq2 zzE;
  
  private byte zzF = 2;
  
  private int zzd;
  
  private int zze;
  
  private int zzf;
  
  private String zzg = "";
  
  private String zzh = "";
  
  private String zzi = "";
  
  private 菊 zzj;
  
  private gq2 zzk;
  
  private gq2 zzl;
  
  private String zzm;
  
  private 菜 zzn;
  
  private boolean zzo;
  
  private gq2 zzp;
  
  private String zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private fp2 zzt;
  
  private 芋 zzu;
  
  private boolean zzv;
  
  private String zzw;
  
  private gq2 zzx;
  
  private gq2 zzy;
  
  private 豆 zzz;
  
  static {
    大 大1 = new 大();
    zzb = 大1;
    草.寂(大.class, 大1);
  }
  
  public 大() {
    er2 er2 = er2.痛;
    this.zzk = (gq2)er2;
    this.zzl = (gq2)er2;
    this.zzm = "";
    this.zzp = (gq2)er2;
    this.zzq = "";
    this.zzt = (fp2)fp2.怖;
    this.zzw = "";
    this.zzx = (gq2)er2;
    this.zzy = (gq2)er2;
    this.zzA = (gq2)er2;
    this.zzC = "";
    this.zzE = (gq2)er2;
  }
  
  public static void あ(大 param大, ArrayList paramArrayList) {
    gq2 gq21 = param大.zzx;
    if (!((xo2)gq21).淋)
      param大.zzx = 草.苦(gq21); 
    植.暑(paramArrayList, param大.zzx);
  }
  
  public static void か(大 param大, ArrayList paramArrayList) {
    gq2 gq21 = param大.zzy;
    if (!((xo2)gq21).淋)
      param大.zzy = 草.苦(gq21); 
    植.暑(paramArrayList, param大.zzy);
  }
  
  public static cs2 興() {
    return (cs2)zzb.痛();
  }
  
  public static void 踊(大 param大, 果 param果) {
    gq2 gq21 = param大.zzk;
    if (!((xo2)gq21).淋)
      param大.zzk = 草.苦(gq21); 
    param大.zzk.add(param果);
  }
  
  public final String 壊() {
    return this.zzg;
  }
  
  public final gq2 帰() {
    return this.zzk;
  }
  
  public final String 死() {
    return this.zzm;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      boolean bool = false;
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            if (paramInt != 5) {
              if (param草 != null)
                bool = true; 
              this.zzF = bool;
              return null;
            } 
            return zzb;
          } 
          return new cs2();
        } 
        return new 大();
      } 
      ks2 ks2 = ks2.硬;
      bs2 bs2 = bs2.硬;
      return new fr2(zzb, "\001\033\000\001\001\033\033\000\007\001\001ဈ\002\002ဈ\003\003ဈ\004\004Л\005ဇ\b\006\032\007ဈ\t\bဇ\n\tဇ\013\nဌ\000\013ဌ\001\fဉ\005\rဈ\006\016ဉ\007\017ည\f\020\033\021ဉ\r\022ဇ\016\023ဈ\017\024\032\025\032\026ဉ\020\027\033\030ဉ\021\031ဈ\022\032ဉ\023\033\033", new Object[] { 
            "zzd", "zzg", "zzh", "zzi", "zzk", 果.class, "zzo", "zzp", "zzq", "zzr", 
            "zzs", "zze", ks2, "zzf", bs2, "zzj", "zzm", "zzn", "zzt", "zzl", 
            林.class, "zzu", "zzv", "zzw", "zzx", "zzy", "zzz", "zzA", 蜜.class, "zzB", 
            "zzC", "zzD", "zzE", 梅.class });
    } 
    return Byte.valueOf(this.zzF);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\大.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */