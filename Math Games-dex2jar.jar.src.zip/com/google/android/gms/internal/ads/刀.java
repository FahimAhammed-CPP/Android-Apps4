package com.google.android.gms.internal.ads;

import y.fr2;
import y.op0;
import y.uo0;

public final class 刀 extends 草 {
  private static final 刀 zzb;
  
  private int zzd;
  
  private int zze = 1000;
  
  private 老 zzf;
  
  static {
    刀 刀1 = new 刀();
    zzb = 刀1;
    草.寂(刀.class, 刀1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(4)) : new 刀(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001ဌ\000\002ဉ\001", new Object[] { "zzd", "zze", uo0, "zzf" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\刀.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */