package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.nv0;
import y.vn2;

public final class ナ extends 草 {
  private static final ナ zzb;
  
  private String zzd = "";
  
  private fp2 zze = (fp2)fp2.怖;
  
  private int zzf;
  
  static {
    ナ ナ1 = new ナ();
    zzb = ナ1;
    草.寂(ナ.class, ナ1);
  }
  
  public static ナ 壊() {
    return zzb;
  }
  
  public static vn2 興() {
    return (vn2)zzb.痛();
  }
  
  public static void 踊(ナ paramナ, int paramInt) {
    if (paramInt != 6) {
      paramナ.zzf = nv0.寒(paramInt);
      return;
    } 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  public final fp2 帰() {
    return this.zze;
  }
  
  public final int 産() {
    int i = this.zzf;
    byte b = 1;
    if (i != 0)
      if (i != 1) {
        b = 3;
        if (i != 2)
          if (i != 3) {
            if (i != 4) {
              b = 0;
            } else {
              b = 5;
            } 
          } else {
            b = 4;
          }  
      } else {
        b = 2;
      }  
    i = b;
    if (b == 0)
      i = 6; 
    return i;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new vn2()) : new ナ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001Ȉ\002\n\003\f", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final String 返() {
    return this.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ナ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */