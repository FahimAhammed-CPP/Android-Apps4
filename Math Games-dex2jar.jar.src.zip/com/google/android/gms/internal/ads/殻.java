package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.op0;
import y.qp2;

public final class 殻 extends 草 {
  private static final 殻 zzb;
  
  private String zzd = "";
  
  static {
    殻 殻1 = new 殻();
    zzb = 殻1;
    草.寂(殻.class, 殻1);
  }
  
  public static 殻 死(fp2 paramfp2, qp2 paramqp2) {
    return (殻)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static 殻 産() {
    return zzb;
  }
  
  public final String 壊() {
    return this.zzd;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(null)) : new 殻()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\000\000\001Ȉ", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\殻.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */