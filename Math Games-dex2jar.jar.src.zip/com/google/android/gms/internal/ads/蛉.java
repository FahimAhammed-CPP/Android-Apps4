package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.qp2;
import y.wm2;

public final class 蛉 extends 草 {
  private static final 蛉 zzb;
  
  private バ zzd;
  
  private int zze;
  
  static {
    蛉 蛉1 = new 蛉();
    zzb = 蛉1;
    草.寂(蛉.class, 蛉1);
  }
  
  public static 蛉 壊(fp2 paramfp2, qp2 paramqp2) {
    return (蛉)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static wm2 産() {
    return (wm2)zzb.痛();
  }
  
  public final バ 帰() {
    バ バ2 = this.zzd;
    バ バ1 = バ2;
    if (バ2 == null)
      バ1 = バ.壊(); 
    return バ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new wm2()) : new 蛉()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\t\002\013", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zze;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蛉.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */