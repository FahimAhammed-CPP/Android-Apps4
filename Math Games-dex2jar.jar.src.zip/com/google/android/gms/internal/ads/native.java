package com.google.android.gms.internal.ads;

import y.fr2;
import y.ho0;
import y.jo0;

public final class native extends 草 {
  private static final native zzb;
  
  private int zzd;
  
  private int zze;
  
  private public zzf;
  
  private return zzg;
  
  static {
    native native1 = new native();
    zzb = native1;
    草.寂(native.class, native1);
  }
  
  public static ho0 興() {
    return (ho0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new ho0()) : new native(); 
      jo0 jo0 = jo0.硬;
      return new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001ဌ\000\002ဉ\001\003ဉ\002", new Object[] { "zzd", "zze", jo0, "zzf", "zzg" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\native.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */