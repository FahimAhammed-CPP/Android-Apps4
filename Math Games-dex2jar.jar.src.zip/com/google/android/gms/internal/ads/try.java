package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;

public final class try extends 草 {
  private static final try zzb;
  
  private int zzd;
  
  private long zze = -1L;
  
  static {
    try try1 = new try();
    zzb = try1;
    草.寂(try.class, try1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(6, 0)) : new try()) : new fr2(zzb, "\001\001\000\001\001\001\001\000\000\000\001ဂ\000", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\try.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */