package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.gs2;

public final class 米 extends 草 {
  private static final 米 zzb;
  
  private int zzd;
  
  private fp2 zze;
  
  private fp2 zzf;
  
  private byte zzg = 2;
  
  static {
    米 米1 = new 米();
    zzb = 米1;
    草.寂(米.class, 米1);
  }
  
  public 米() {
    dp2 dp2 = fp2.怖;
    this.zze = (fp2)dp2;
    this.zzf = (fp2)dp2;
  }
  
  public static gs2 興() {
    return (gs2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      boolean bool = false;
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            if (paramInt != 5) {
              if (param草 != null)
                bool = true; 
              this.zzg = bool;
              return null;
            } 
            return zzb;
          } 
          return new gs2();
        } 
        return new 米();
      } 
      return new fr2(zzb, "\001\002\000\001\001\002\002\000\000\001\001ᔊ\000\002ည\001", new Object[] { "zzd", "zze", "zzf" });
    } 
    return Byte.valueOf(this.zzg);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\米.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */