package com.google.android.gms.internal.ads;

import java.util.Arrays;
import y.cq2;
import y.dq2;
import y.eb2;
import y.fb2;
import y.fr2;
import y.xo2;
import y.zp2;
import y.獅;

public final class コ extends 草 {
  private static final dq2 zzb = (dq2)new 獅(13);
  
  private static final コ zzd;
  
  private int zze;
  
  private cq2 zzf = (cq2)zp2.痛;
  
  private String zzg = "";
  
  private String zzh = "";
  
  private String zzi = "";
  
  static {
    コ コ1 = new コ();
    zzd = コ1;
    草.寂(コ.class, コ1);
  }
  
  public static void 壊(コ paramコ) {
    cq2 cq21 = paramコ.zzf;
    if (!((xo2)cq21).淋) {
      int i = cq21.size();
      if (i == 0) {
        i = 10;
      } else {
        i += i;
      } 
      zp2 zp2 = (zp2)cq21;
      if (i >= zp2.恐) {
        paramコ.zzf = (cq2)new zp2(Arrays.copyOf(zp2.怖, i), zp2.恐);
      } else {
        throw new IllegalArgumentException();
      } 
    } 
    ((zp2)paramコ.zzf).美(2);
  }
  
  public static fb2 興() {
    return (fb2)zzd.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzd) : new fb2()) : new コ(); 
      eb2 eb2 = eb2.硬;
      return new fr2(zzd, "\001\004\000\001\001\004\004\000\001\000\001\036\002ဈ\000\003ဈ\001\004ဈ\002", new Object[] { "zze", "zzf", eb2, "zzg", "zzh", "zzi" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\コ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */