package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.qp2;
import y.rm2;

public final class 蛾 extends 草 {
  private static final 蛾 zzb;
  
  private ト zzd;
  
  private ブ zze;
  
  static {
    蛾 蛾1 = new 蛾();
    zzb = 蛾1;
    草.寂(蛾.class, 蛾1);
  }
  
  public static 蛾 死(fp2 paramfp2, qp2 paramqp2) {
    return (蛾)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static rm2 興() {
    return (rm2)zzb.痛();
  }
  
  public final ト 壊() {
    ト ト2 = this.zzd;
    ト ト1 = ト2;
    if (ト2 == null)
      ト1 = ト.壊(); 
    return ト1;
  }
  
  public final ブ 帰() {
    ブ ブ2 = this.zze;
    ブ ブ1 = ブ2;
    if (ブ2 == null)
      ブ1 = ブ.壊(); 
    return ブ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new rm2()) : new 蛾()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\t\002\t", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蛾.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */