package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.qp2;
import y.vc0;

public final class class extends 草 {
  private static final class zzb;
  
  private int zzd;
  
  private fp2 zze;
  
  private fp2 zzf;
  
  private fp2 zzg;
  
  private fp2 zzh;
  
  static {
    class class1 = new class();
    zzb = class1;
    草.寂(class.class, class1);
  }
  
  public class() {
    dp2 dp2 = fp2.怖;
    this.zze = (fp2)dp2;
    this.zzf = (fp2)dp2;
    this.zzg = (fp2)dp2;
    this.zzh = (fp2)dp2;
  }
  
  public static class 死(byte[] paramArrayOfbyte, qp2 paramqp2) {
    草 草1 = 草.起(zzb, paramArrayOfbyte, paramArrayOfbyte.length, paramqp2);
    草.臭(草1);
    return (class)草1;
  }
  
  public static vc0 興() {
    return (vc0)zzb.痛();
  }
  
  public final fp2 壊() {
    return this.zze;
  }
  
  public final fp2 帰() {
    return this.zzf;
  }
  
  public final fp2 歩() {
    return this.zzg;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new vc0()) : new class()) : new fr2(zzb, "\001\004\000\001\001\004\004\000\000\000\001ည\000\002ည\001\003ည\002\004ည\003", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh" })) : Byte.valueOf((byte)1);
  }
  
  public final fp2 返() {
    return this.zzh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\class.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */