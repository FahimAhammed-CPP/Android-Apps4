package com.google.android.gms.internal.ads;

import y.bo2;
import y.fr2;
import y.nv0;

public final class 蚯 extends 草 {
  private static final 蚯 zzb;
  
  private String zzd = "";
  
  private int zze;
  
  private int zzf;
  
  private int zzg;
  
  static {
    蚯 蚯1 = new 蚯();
    zzb = 蚯1;
    草.寂(蚯.class, 蚯1);
  }
  
  public static bo2 興() {
    return (bo2)zzb.痛();
  }
  
  public static void 返(蚯 param蚯, int paramInt) {
    if (paramInt != 1) {
      param蚯.zze = paramInt - 2;
      return;
    } 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new bo2()) : new 蚯()) : new fr2(zzb, "\000\004\000\000\001\004\004\000\000\000\001Ȉ\002\f\003\013\004\f", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蚯.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */