package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.in2;
import y.qp2;

public final class 蛍 extends 草 {
  private static final 蛍 zzb;
  
  private ハ zzd;
  
  static {
    蛍 蛍1 = new 蛍();
    zzb = 蛍1;
    草.寂(蛍.class, 蛍1);
  }
  
  public static 蛍 死(fp2 paramfp2, qp2 paramqp2) {
    return (蛍)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static in2 興() {
    return (in2)zzb.痛();
  }
  
  public final ハ 壊() {
    ハ ハ2 = this.zzd;
    ハ ハ1 = ハ2;
    if (ハ2 == null)
      ハ1 = ハ.壊(); 
    return ハ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new in2()) : new 蛍()) : new fr2(zzb, "\000\001\000\000\001\001\001\000\000\000\001\t", new Object[] { "zzd" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蛍.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */