package com.google.android.gms.internal.ads;

import y.dp2;
import y.er2;
import y.fp2;
import y.fr2;
import y.gq2;
import y.hs2;
import y.xo2;

public final class 麦 extends 草 {
  private static final 麦 zzb;
  
  private int zzd;
  
  private 稲 zze;
  
  private gq2 zzf = (gq2)er2.痛;
  
  private fp2 zzg;
  
  private fp2 zzh;
  
  private int zzi;
  
  private byte zzj = 2;
  
  static {
    麦 麦1 = new 麦();
    zzb = 麦1;
    草.寂(麦.class, 麦1);
  }
  
  public 麦() {
    dp2 dp2 = fp2.怖;
    this.zzg = (fp2)dp2;
    this.zzh = (fp2)dp2;
  }
  
  public static void 死(麦 param麦, 米 param米) {
    gq2 gq21 = param麦.zzf;
    if (!((xo2)gq21).淋)
      param麦.zzf = 草.苦(gq21); 
    param麦.zzf.add(param米);
  }
  
  public static hs2 興() {
    return (hs2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      boolean bool = false;
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            if (paramInt != 5) {
              if (param草 != null)
                bool = true; 
              this.zzj = bool;
              return null;
            } 
            return zzb;
          } 
          return new hs2();
        } 
        return new 麦();
      } 
      return new fr2(zzb, "\001\005\000\001\001\005\005\000\001\001\001ဉ\000\002Л\003ည\001\004ည\002\005င\003", new Object[] { "zzd", "zze", "zzf", 米.class, "zzg", "zzh", "zzi" });
    } 
    return Byte.valueOf(this.zzj);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\麦.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */