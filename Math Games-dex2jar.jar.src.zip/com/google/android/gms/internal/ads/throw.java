package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.gc0;
import y.qp2;

public final class throw extends 草 {
  private static final throw zzb;
  
  private int zzd;
  
  private while zze;
  
  private fp2 zzf;
  
  private fp2 zzg;
  
  static {
    throw throw1 = new throw();
    zzb = throw1;
    草.寂(throw.class, throw1);
  }
  
  public throw() {
    dp2 dp2 = fp2.怖;
    this.zzf = (fp2)dp2;
    this.zzg = (fp2)dp2;
  }
  
  public static throw 産(dp2 paramdp2, qp2 paramqp2) {
    return (throw)草.ぱ(zzb, (fp2)paramdp2, paramqp2);
  }
  
  public final fp2 壊() {
    return this.zzg;
  }
  
  public final fp2 帰() {
    return this.zzf;
  }
  
  public final while 死() {
    while while2 = this.zze;
    while while1 = while2;
    if (while2 == null)
      while1 = while.返(); 
    return while1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(null)) : new throw()) : new fr2(zzb, "\001\003\000\001\001\003\003\000\000\000\001ဉ\000\002ည\001\003ည\002", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\throw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */