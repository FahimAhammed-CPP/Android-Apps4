package com.google.android.gms.internal.ads;

import y.bm;
import y.fp2;
import y.g92;
import y.lp2;
import y.nr2;
import y.op2;
import y.pr2;
import y.qp2;
import y.rp2;
import y.ub0;
import y.xp2;

public final class 木 implements nr2 {
  public final 根 堅;
  
  public final rp2 熱;
  
  public final 植 硬;
  
  public 木(根 param根, rp2 paramrp2, 植 param植) {
    this.堅 = param根;
    this.熱 = paramrp2;
    this.硬 = param植;
  }
  
  public final void 不(Object paramObject, g92 paramg92) {
    this.熱.getClass();
    bm.悲(paramObject);
    throw null;
  }
  
  public final void 冷(Object paramObject, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ub0 paramub0) {
    草 草 = (草)paramObject;
    if (草.zzc == pr2.寒)
      草.zzc = pr2.堅(); 
    bm.悲(paramObject);
    throw null;
  }
  
  public final 草 堅() {
    植 植1 = this.硬;
    return (植1 instanceof 草) ? ((草)植1).辛() : ((xp2)((草)植1).痒(null, 5)).暑();
  }
  
  public final boolean 寒(Object paramObject1, Object paramObject2) {
    根 根1 = this.堅;
    根1.getClass();
    paramObject1 = ((草)paramObject1).zzc;
    根1.getClass();
    return !!paramObject1.equals(((草)paramObject2).zzc);
  }
  
  public final int 旨(Object paramObject) {
    this.堅.getClass();
    paramObject = ((草)paramObject).zzc;
    int j = ((pr2)paramObject).暑;
    int i = j;
    if (j == -1) {
      j = 0;
      i = 0;
      while (j < ((pr2)paramObject).硬) {
        int i1 = ((pr2)paramObject).堅[j];
        fp2 fp2 = (fp2)((pr2)paramObject).熱[j];
        int k = op2.痛(8);
        int m = fp2.辛();
        int n = op2.痛(16);
        i1 = op2.痛(i1 >>> 3);
        int i2 = op2.痛(24);
        i += op2.痛(m) + m + i2 + i1 + n + k + k;
        j++;
      } 
      ((pr2)paramObject).暑 = i;
    } 
    return i;
  }
  
  public final void 暑(Object paramObject, lp2 paramlp2, qp2 paramqp2) {
    this.堅.getClass();
    根.堅(paramObject);
    this.熱.getClass();
    bm.悲(paramObject);
    throw null;
  }
  
  public final void 熱(Object paramObject) {
    this.堅.getClass();
    根.暑(paramObject);
    this.熱.getClass();
    bm.悲(paramObject);
    throw null;
  }
  
  public final void 硬(Object paramObject1, Object paramObject2) {
    葉.堅(this.堅, paramObject1, paramObject2);
  }
  
  public final int 美(Object paramObject) {
    this.堅.getClass();
    return ((草)paramObject).zzc.hashCode();
  }
  
  public final boolean 辛(Object paramObject) {
    this.熱.getClass();
    bm.悲(paramObject);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\木.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */