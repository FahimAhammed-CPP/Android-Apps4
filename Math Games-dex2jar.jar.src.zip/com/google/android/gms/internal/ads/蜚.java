package com.google.android.gms.internal.ads;

import y.fr2;
import y.p31;
import y.qn2;

public final class 蜚 extends 草 {
  private static final 蜚 zzb;
  
  private int zzd;
  
  private int zze;
  
  static {
    蜚 蜚1 = new 蜚();
    zzb = 蜚1;
    草.寂(蜚.class, 蜚1);
  }
  
  public static 蜚 壊() {
    return zzb;
  }
  
  public static qn2 産() {
    return (qn2)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new qn2()) : new 蜚()) : new fr2(zzb, "\000\002\000\000\001\002\002\000\000\000\001\f\002\013", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zze;
  }
  
  public final int 返() {
    int i = this.zzd;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          b = 5;
          if (i != 3)
            if (i != 4) {
              if (i != 5) {
                b = 0;
              } else {
                b = 7;
              } 
            } else {
              b = 6;
            }  
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蜚.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */