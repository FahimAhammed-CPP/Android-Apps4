package com.google.android.gms.internal.ads;

import y.er2;
import y.fr2;
import y.gq2;
import y.op0;
import y.ps2;
import y.qs2;

public final class 蜜 extends 草 {
  private static final 蜜 zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private String zzf = "";
  
  private int zzg = 4;
  
  private gq2 zzh;
  
  private String zzi;
  
  private String zzj;
  
  private boolean zzk;
  
  private double zzl;
  
  private gq2 zzm;
  
  private int zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  static {
    蜜 蜜1 = new 蜜();
    zzb = 蜜1;
    草.寂(蜜.class, 蜜1);
  }
  
  public 蜜() {
    er2 er2 = er2.痛;
    this.zzh = (gq2)er2;
    this.zzi = "";
    this.zzj = "";
    this.zzm = (gq2)er2;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(22, 0)) : new 蜜(); 
      qs2 qs2 = qs2.硬;
      ps2 ps2 = ps2.硬;
      return new fr2(zzb, "\001\016\000\001\001\016\016\000\002\000\001ဈ\000\002ဌ\002\003\032\004ဈ\003\005ဈ\004\006ဇ\005\007က\006\b\033\tဈ\001\nဌ\007\013ဇ\b\fဇ\t\rဇ\n\016ဇ\013", new Object[] { 
            "zzd", "zze", "zzg", qs2, "zzh", "zzi", "zzj", "zzk", "zzl", "zzm", 
            檎.class, "zzf", "zzn", ps2, "zzo", "zzp", "zzq", "zzr" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蜜.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */