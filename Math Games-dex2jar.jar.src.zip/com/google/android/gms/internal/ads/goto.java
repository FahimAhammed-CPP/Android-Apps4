package com.google.android.gms.internal.ads;

import y.fr2;
import y.tc0;
import y.xc0;

public final class goto extends 草 {
  private static final goto zzb;
  
  private int zzd;
  
  private long zze = -1L;
  
  private long zzf = -1L;
  
  private long zzg = -1L;
  
  private long zzh = -1L;
  
  private long zzi = -1L;
  
  private long zzj = -1L;
  
  private int zzk = 1000;
  
  private long zzl = -1L;
  
  private long zzm = -1L;
  
  private long zzn = -1L;
  
  private int zzo = 1000;
  
  private long zzp = -1L;
  
  private long zzq = -1L;
  
  private long zzr = -1L;
  
  private long zzs = -1L;
  
  private long zzt;
  
  private long zzu;
  
  private long zzv = -1L;
  
  private long zzw = -1L;
  
  private long zzx = -1L;
  
  private long zzy = -1L;
  
  static {
    goto goto1 = new goto();
    zzb = goto1;
    草.寂(goto.class, goto1);
  }
  
  public static tc0 興() {
    return (tc0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new tc0()) : new goto(); 
      xc0 xc0 = xc0.硬;
      return new fr2(zzb, "\001\025\000\001\001\025\025\000\000\000\001ဂ\000\002ဂ\001\003ဂ\002\004ဂ\003\005ဂ\004\006ဂ\005\007ဌ\006\bဂ\007\tဂ\b\nဂ\t\013ဌ\n\fဂ\013\rဂ\f\016ဂ\r\017ဂ\016\020ဂ\017\021ဂ\020\022ဂ\021\023ဂ\022\024ဂ\023\025ဂ\024", new Object[] { 
            "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", xc0, "zzl", 
            "zzm", "zzn", "zzo", xc0, "zzp", "zzq", "zzr", "zzs", "zzt", "zzu", 
            "zzv", "zzw", "zzx", "zzy" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\goto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */