package com.google.android.gms.internal.ads;

import y.fr2;
import y.so0;
import y.uo0;

public final class finally extends 草 {
  private static final finally zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private con zzf;
  
  private int zzg;
  
  private nul zzh;
  
  private int zzi;
  
  private int zzj = 1000;
  
  private int zzk = 1000;
  
  private int zzl = 1000;
  
  static {
    finally finally1 = new finally();
    zzb = finally1;
    草.寂(finally.class, finally1);
  }
  
  public static finally 産() {
    return zzb;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new so0()) : new finally(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\b\000\001\001\b\b\000\000\000\001ဈ\000\002ဉ\001\003င\002\004ဉ\003\005င\004\006ဌ\005\007ဌ\006\bဌ\007", new Object[] { 
            "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", uo0, "zzk", uo0, 
            "zzl", uo0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\finally.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */