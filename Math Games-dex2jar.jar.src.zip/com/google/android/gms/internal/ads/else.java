package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.xc0;

public final class else extends 草 {
  private static final else zzb;
  
  private int zzd;
  
  private long zze = -1L;
  
  private int zzf = 1000;
  
  static {
    else else1 = new else();
    zzb = else1;
    草.寂(else.class, else1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(8, 0)) : new else(); 
      xc0 xc0 = xc0.硬;
      return new fr2(zzb, "\001\002\000\001\001\002\002\000\000\000\001ဂ\000\002ဌ\001", new Object[] { "zzd", "zze", "zzf", xc0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\else.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */