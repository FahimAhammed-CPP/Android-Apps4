package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.mn2;
import y.p31;

public final class 蚊 extends 草 {
  private static final 蚊 zzb;
  
  private int zzd;
  
  private int zze;
  
  private fp2 zzf = (fp2)fp2.怖;
  
  static {
    蚊 蚊1 = new 蚊();
    zzb = 蚊1;
    草.寂(蚊.class, 蚊1);
  }
  
  public static 蚊 死() {
    return zzb;
  }
  
  public static void 泳(蚊 param蚊) {
    param蚊.zzd = 2;
  }
  
  public static mn2 興() {
    return (mn2)zzb.痛();
  }
  
  public final fp2 壊() {
    return this.zzf;
  }
  
  public final int 歩() {
    int i = this.zze;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          b = 5;
          if (i != 3)
            if (i != 4) {
              if (i != 5) {
                b = 0;
              } else {
                b = 7;
              } 
            } else {
              b = 6;
            }  
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new mn2()) : new 蚊()) : new fr2(zzb, "\000\003\000\000\001\013\003\000\000\000\001\f\002\f\013\n", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 返() {
    int i = this.zzd;
    byte b = 2;
    if (i != 0)
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              b = 0;
            } else {
              b = 7;
            } 
          } else {
            b = 6;
          } 
        } else {
          b = 5;
        } 
      } else {
        b = 4;
      }  
    return (b == 0) ? 1 : b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蚊.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */