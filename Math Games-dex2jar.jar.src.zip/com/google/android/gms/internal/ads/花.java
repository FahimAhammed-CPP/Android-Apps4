package com.google.android.gms.internal.ads;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import y.dp2;
import y.fp2;
import y.hq2;
import y.pr2;
import y.꽃;

public abstract class 花 {
  public static final char[] 硬;
  
  static {
    char[] arrayOfChar = new char[80];
    硬 = arrayOfChar;
    Arrays.fill(arrayOfChar, ' ');
  }
  
  public static void 堅(int paramInt, StringBuilder paramStringBuilder) {
    while (paramInt > 0) {
      int i = 80;
      if (paramInt <= 80)
        i = paramInt; 
      paramStringBuilder.append(硬, 0, i);
      paramInt -= i;
    } 
  }
  
  public static void 熱(植 param植, StringBuilder paramStringBuilder, int paramInt) {
    Method method;
    HashSet<String> hashSet = new HashSet();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    Method[] arrayOfMethod = param植.getClass().getDeclaredMethods();
    int j = arrayOfMethod.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      method = arrayOfMethod[i];
      if (!Modifier.isStatic(method.getModifiers()) && method.getName().length() >= 3)
        if (method.getName().startsWith("set")) {
          hashSet.add(method.getName());
        } else if (Modifier.isPublic(method.getModifiers()) && (method.getParameterTypes()).length == 0) {
          if (method.getName().startsWith("has")) {
            hashMap.put(method.getName(), method);
          } else if (method.getName().startsWith("get")) {
            treeMap.put(method.getName(), method);
          } 
        }  
    } 
    for (Map.Entry<Object, Object> entry : treeMap.entrySet()) {
      String str = ((String)entry.getKey()).substring(3);
      if (str.endsWith("List") && !str.endsWith("OrBuilderList") && !str.equals("List")) {
        Method method1 = (Method)entry.getValue();
        if (method1 != null && method1.getReturnType().equals(List.class)) {
          硬(paramStringBuilder, paramInt, str.substring(0, str.length() - 4), 草.嬉(param植, method1, new Object[0]));
          continue;
        } 
      } 
      if (str.endsWith("Map") && !str.equals("Map")) {
        Method method1 = (Method)entry.getValue();
        if (method1 != null && method1.getReturnType().equals(Map.class) && !method1.isAnnotationPresent((Class)Deprecated.class) && Modifier.isPublic(method1.getModifiers())) {
          硬(paramStringBuilder, paramInt, str.substring(0, str.length() - 3), 草.嬉(param植, method1, new Object[0]));
          continue;
        } 
      } 
      if (hashSet.contains("set".concat(str)) && (!str.endsWith("Bytes") || !treeMap.containsKey("get".concat(String.valueOf(str.substring(0, str.length() - 5)))))) {
        Method method2 = (Method)entry.getValue();
        Method method1 = (Method)hashMap.get("has".concat(str));
        if (method2 != null) {
          Object object = 草.嬉(param植, method2, new Object[0]);
          if (method1 == null) {
            boolean bool1;
            if (object instanceof Boolean) {
              if (((Boolean)object).booleanValue())
                continue; 
              continue;
            } 
            if (object instanceof Integer) {
              if (((Integer)object).intValue() != 0)
                continue; 
              continue;
            } 
            if (object instanceof Float) {
              if (Float.floatToRawIntBits(((Float)object).floatValue()) != 0)
                continue; 
              continue;
            } 
            if (object instanceof Double) {
              if (Double.doubleToRawLongBits(((Double)object).doubleValue()) != 0L)
                continue; 
              continue;
            } 
            if (object instanceof String) {
              bool1 = object.equals("");
            } else if (object instanceof fp2) {
              bool1 = object.equals(fp2.怖);
            } else {
              if ((object instanceof 植) ? (object != (草)((草)object).痒(null, 6)) : (!(object instanceof Enum) || ((Enum)object).ordinal() != 0))
                continue; 
              continue;
            } 
            if (!bool1)
              continue; 
            continue;
          } 
          if (((Boolean)草.嬉(param植, method1, new Object[0])).booleanValue())
            continue; 
        } 
      } 
      continue;
      硬(paramStringBuilder, paramInt, (String)method, SYNTHETIC_LOCAL_VARIABLE_13);
    } 
    pr2 pr2 = ((草)param植).zzc;
    if (pr2 != null)
      for (i = bool; i < pr2.硬; i++)
        硬(paramStringBuilder, paramInt, String.valueOf(pr2.堅[i] >>> 3), pr2.熱[i]);  
  }
  
  public static void 硬(StringBuilder paramStringBuilder, int paramInt, String paramString, Object paramObject) {
    if (paramObject instanceof List) {
      paramObject = ((List)paramObject).iterator();
      while (paramObject.hasNext())
        硬(paramStringBuilder, paramInt, paramString, paramObject.next()); 
      return;
    } 
    if (paramObject instanceof Map) {
      paramObject = ((Map)paramObject).entrySet().iterator();
      while (paramObject.hasNext())
        硬(paramStringBuilder, paramInt, paramString, paramObject.next()); 
      return;
    } 
    paramStringBuilder.append('\n');
    堅(paramInt, paramStringBuilder);
    String str = paramString;
    if (!paramString.isEmpty()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Character.toLowerCase(paramString.charAt(0)));
      int i;
      for (i = 1; i < paramString.length(); i++) {
        char c = paramString.charAt(i);
        if (Character.isUpperCase(c))
          stringBuilder.append("_"); 
        stringBuilder.append(Character.toLowerCase(c));
      } 
      str = stringBuilder.toString();
    } 
    paramStringBuilder.append(str);
    if (paramObject instanceof String) {
      paramStringBuilder.append(": \"");
      paramString = (String)paramObject;
      paramObject = fp2.怖;
      paramStringBuilder.append(꽃.탑((fp2)new dp2(paramString.getBytes(hq2.硬))));
      paramStringBuilder.append('"');
      return;
    } 
    if (paramObject instanceof fp2) {
      paramStringBuilder.append(": \"");
      paramStringBuilder.append(꽃.탑((fp2)paramObject));
      paramStringBuilder.append('"');
      return;
    } 
    if (paramObject instanceof 草) {
      paramStringBuilder.append(" {");
      熱((草)paramObject, paramStringBuilder, paramInt + 2);
      paramStringBuilder.append("\n");
      堅(paramInt, paramStringBuilder);
      paramStringBuilder.append("}");
      return;
    } 
    if (paramObject instanceof Map.Entry) {
      paramStringBuilder.append(" {");
      Map.Entry entry = (Map.Entry)paramObject;
      int i = paramInt + 2;
      硬(paramStringBuilder, i, "key", entry.getKey());
      硬(paramStringBuilder, i, "value", entry.getValue());
      paramStringBuilder.append("\n");
      堅(paramInt, paramStringBuilder);
      paramStringBuilder.append("}");
      return;
    } 
    paramStringBuilder.append(": ");
    paramStringBuilder.append(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\花.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */