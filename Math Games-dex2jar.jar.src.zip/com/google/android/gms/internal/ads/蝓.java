package com.google.android.gms.internal.ads;

import y.fr2;
import y.nv0;
import y.zn2;

public final class 蝓 extends 草 {
  private static final 蝓 zzb;
  
  private ナ zzd;
  
  private int zze;
  
  private int zzf;
  
  private int zzg;
  
  static {
    蝓 蝓1 = new 蝓();
    zzb = 蝓1;
    草.寂(蝓.class, 蝓1);
  }
  
  public static void 噛(蝓 param蝓, int paramInt) {
    if (paramInt != 1) {
      param蝓.zze = paramInt - 2;
      return;
    } 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  public static zn2 死() {
    return (zn2)zzb.痛();
  }
  
  public final int 寝() {
    int i = this.zze;
    byte b = 2;
    if (i != 0)
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            b = 0;
          } else {
            b = 5;
          } 
        } else {
          b = 4;
        } 
      } else {
        b = 3;
      }  
    return (b == 0) ? 1 : b;
  }
  
  public final int 帰() {
    int j = nv0.堅(this.zzg);
    int i = j;
    if (j == 0)
      i = 6; 
    return i;
  }
  
  public final ナ 産() {
    ナ ナ2 = this.zzd;
    ナ ナ1 = ナ2;
    if (ナ2 == null)
      ナ1 = ナ.壊(); 
    return ナ1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new zn2()) : new 蝓()) : new fr2(zzb, "\000\004\000\000\001\004\004\000\000\000\001\t\002\f\003\013\004\f", new Object[] { "zzd", "zze", "zzf", "zzg" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzf;
  }
  
  public final boolean 踊() {
    return (this.zzd != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\蝓.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */