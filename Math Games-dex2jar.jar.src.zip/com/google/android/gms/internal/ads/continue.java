package com.google.android.gms.internal.ads;

import y.cq2;
import y.fr2;
import y.gc0;
import y.uo0;
import y.zp2;

public final class continue extends 草 {
  private static final continue zzb;
  
  private int zzd;
  
  private int zze;
  
  private cq2 zzf = (cq2)zp2.痛;
  
  static {
    continue continue1 = new continue();
    zzb = continue1;
    草.寂(continue.class, continue1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(18, null)) : new continue(); 
      uo0 uo0 = uo0.硬;
      return new fr2(zzb, "\001\002\000\001\001\002\002\000\001\000\001ဌ\000\002\026", new Object[] { "zzd", "zze", uo0, "zzf" });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\continue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */