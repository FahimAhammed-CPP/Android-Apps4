package com.google.android.gms.internal.ads;

import y.er2;
import y.fc0;
import y.fr2;
import y.gq2;
import y.kc0;

public final class if extends 草 {
  private static final if zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private long zzf;
  
  private String zzg = "";
  
  private String zzh = "";
  
  private String zzi = "";
  
  private long zzj;
  
  private long zzk;
  
  private String zzl = "";
  
  private long zzm;
  
  private String zzn = "";
  
  private String zzo = "";
  
  private gq2 zzp = (gq2)er2.痛;
  
  private int zzq;
  
  static {
    if if1 = new if();
    zzb = if1;
    草.寂(if.class, if1);
  }
  
  public static fc0 興() {
    return (fc0)zzb.痛();
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new fc0()) : new if(); 
      kc0 kc0 = kc0.硬;
      return new fr2(zzb, "\001\r\000\001\001\r\r\000\001\000\001ဈ\000\002ဂ\001\003ဈ\002\004ဈ\003\005ဈ\004\006ဂ\005\007ဂ\006\bဈ\007\tဂ\b\nဈ\t\013ဈ\n\f\033\rဌ\013", new Object[] { 
            "zzd", "zze", "zzf", "zzg", "zzh", "zzi", "zzj", "zzk", "zzl", "zzm", 
            "zzn", "zzo", "zzp", do.class, "zzq", kc0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */