package com.google.android.gms.internal.ads;

import y.dp2;
import y.fp2;
import y.fr2;
import y.mm2;
import y.qp2;

public final class 章 extends 草 {
  private static final 章 zzb;
  
  private int zzd;
  
  private fp2 zze = (fp2)fp2.怖;
  
  private 蝶 zzf;
  
  static {
    章 章1 = new 章();
    zzb = 章1;
    草.寂(章.class, 章1);
  }
  
  public static 章 壊(fp2 paramfp2, qp2 paramqp2) {
    return (章)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static mm2 産() {
    return (mm2)zzb.痛();
  }
  
  public final 蝶 帰() {
    蝶 蝶2 = this.zzf;
    蝶 蝶1 = 蝶2;
    if (蝶2 == null)
      蝶1 = 蝶.壊(); 
    return 蝶1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new mm2()) : new 章()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\013\002\n\003\t", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
  
  public final fp2 返() {
    return this.zze;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\章.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */