package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;

public final class final extends 草 {
  private static final final zzb;
  
  private int zzd;
  
  private String zze = "";
  
  static {
    final final1 = new final();
    zzb = final1;
    草.寂(final.class, final1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(11, 0)) : new final()) : new fr2(zzb, "\001\001\000\001\001\001\001\000\000\000\001ဈ\000", new Object[] { "zzd", "zze" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\final.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */