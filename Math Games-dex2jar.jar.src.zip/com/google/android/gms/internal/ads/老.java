package com.google.android.gms.internal.ads;

import y.fr2;
import y.gc0;
import y.kp0;

public final class 老 extends 草 {
  private static final 老 zzb;
  
  private int zzd;
  
  private int zze;
  
  static {
    老 老1 = new 老();
    zzb = 老1;
    草.寂(老.class, 老1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new gc0(28, null)) : new 老(); 
      kp0 kp0 = kp0.硬;
      return new fr2(zzb, "\001\001\000\001\001\001\001\000\000\000\001ဌ\000", new Object[] { "zzd", "zze", kp0 });
    } 
    return Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\老.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */