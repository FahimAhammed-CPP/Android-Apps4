package com.google.android.gms.internal.ads;

import y.fp2;
import y.fr2;
import y.qm2;
import y.qp2;

public final class ガ extends 草 {
  private static final ガ zzb;
  
  private int zzd;
  
  private 蝉 zze;
  
  private ゴ zzf;
  
  static {
    ガ ガ1 = new ガ();
    zzb = ガ1;
    草.寂(ガ.class, ガ1);
  }
  
  public static ガ 壊(fp2 paramfp2, qp2 paramqp2) {
    return (ガ)草.ぱ(zzb, paramfp2, paramqp2);
  }
  
  public static qm2 産() {
    return (qm2)zzb.痛();
  }
  
  public final 蝉 帰() {
    蝉 蝉2 = this.zze;
    蝉 蝉1 = 蝉2;
    if (蝉2 == null)
      蝉1 = 蝉.壊(); 
    return 蝉1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new qm2()) : new ガ()) : new fr2(zzb, "\000\003\000\000\001\003\003\000\000\000\001\013\002\t\003\t", new Object[] { "zzd", "zze", "zzf" })) : Byte.valueOf((byte)1);
  }
  
  public final int 興() {
    return this.zzd;
  }
  
  public final ゴ 返() {
    ゴ ゴ2 = this.zzf;
    ゴ ゴ1 = ゴ2;
    if (ゴ2 == null)
      ゴ1 = ゴ.壊(); 
    return ゴ1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\ガ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */