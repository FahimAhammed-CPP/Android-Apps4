package com.google.android.gms.internal.ads;

import y.fr2;
import y.op0;

public final class 松 extends 草 {
  private static final 松 zzb;
  
  private int zzd;
  
  private String zze = "";
  
  private 桜 zzf;
  
  private long zzg;
  
  private String zzh = "";
  
  static {
    松 松1 = new 松();
    zzb = 松1;
    草.寂(松.class, 松1);
  }
  
  public final Object 痒(草 param草, int paramInt) {
    return (--paramInt != 0) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzb) : new op0(13, 0)) : new 松()) : new fr2(zzb, "\001\004\000\001\001\004\004\000\000\000\001ဈ\000\002ဉ\001\003ဂ\002\004ဈ\003", new Object[] { "zzd", "zze", "zzf", "zzg", "zzh" })) : Byte.valueOf((byte)1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\松.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */