package com.google.android.gms.internal.ads;

import java.util.ArrayList;
import java.util.Arrays;
import y.cp0;
import y.cq2;
import y.dq2;
import y.ep0;
import y.eq2;
import y.fp0;
import y.fr2;
import y.mo0;
import y.no0;
import y.qp2;
import y.td;
import y.uo0;
import y.xo2;
import y.zp2;
import y.デ;

public final class protected extends 草 {
  private static final dq2 zzb = (dq2)new デ(22);
  
  private static final protected zzd;
  
  private int zze;
  
  private long zzf;
  
  private int zzg;
  
  private long zzh;
  
  private long zzi;
  
  private cq2 zzj = (cq2)zp2.痛;
  
  private volatile zzk;
  
  private int zzl;
  
  private int zzm;
  
  private int zzn;
  
  private int zzo;
  
  private int zzp;
  
  private int zzq;
  
  private long zzr;
  
  static {
    protected protected1 = new protected();
    zzd = protected1;
    草.寂(protected.class, protected1);
  }
  
  public static void も(protected paramprotected, fp0 paramfp0) {
    paramprotected.zzq = paramfp0.淋;
    paramprotected.zze |= 0x400;
  }
  
  public static void ゃ(protected paramprotected, ArrayList paramArrayList) {
    cq2 cq21 = paramprotected.zzj;
    if (!((xo2)cq21).淋) {
      int i = cq21.size();
      if (i == 0) {
        i = 10;
      } else {
        i += i;
      } 
      zp2 zp2 = (zp2)cq21;
      if (i >= zp2.恐) {
        paramprotected.zzj = (cq2)new zp2(Arrays.copyOf(zp2.怖, i), zp2.恐);
      } else {
        throw new IllegalArgumentException();
      } 
    } 
    for (no0 no0 : paramArrayList) {
      cq2 cq22 = paramprotected.zzj;
      int i = no0.淋;
      ((zp2)cq22).美(i);
    } 
  }
  
  public static protected 噛(byte[] paramArrayOfbyte) {
    草 草1 = 草.起(zzd, paramArrayOfbyte, paramArrayOfbyte.length, qp2.堅);
    草.臭(草1);
    return (protected)草1;
  }
  
  public static cp0 踊() {
    return (cp0)zzd.痛();
  }
  
  public final int 壊() {
    return this.zzo;
  }
  
  public final long 帰() {
    return this.zzi;
  }
  
  public final eq2 投() {
    return new eq2(this.zzj);
  }
  
  public final long 歩() {
    return this.zzf;
  }
  
  public final volatile 泳() {
    volatile volatile2 = this.zzk;
    volatile volatile1 = volatile2;
    if (volatile2 == null)
      volatile1 = volatile.死(); 
    return volatile1;
  }
  
  public final Object 痒(草 param草, int paramInt) {
    if (--paramInt != 0) {
      if (paramInt != 2)
        return (paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : zzd) : new cp0()) : new protected(); 
      uo0 uo0 = uo0.硬;
      mo0 mo0 = mo0.硬;
      ep0 ep0 = ep0.硬;
      return new fr2(zzd, "\001\r\000\001\001\r\r\000\001\000\001ဂ\000\002ဌ\001\003ဂ\002\004ဂ\003\005\036\006ဉ\004\007ဌ\005\bဌ\006\tဌ\007\nင\b\013ဌ\t\fဌ\n\rဂ\013", new Object[] { 
            "zze", "zzf", "zzg", uo0, "zzh", "zzi", "zzj", mo0, "zzk", "zzl", 
            uo0, "zzm", uo0, "zzn", uo0, "zzo", "zzp", uo0, "zzq", ep0, 
            "zzr" });
    } 
    return Byte.valueOf((byte)1);
  }
  
  public final fp0 触() {
    fp0 fp02 = fp0.硬(this.zzq);
    fp0 fp01 = fp02;
    if (fp02 == null)
      fp01 = fp0.怖; 
    return fp01;
  }
  
  public final long 返() {
    return this.zzh;
  }
  
  public final int 코() {
    int j = td.키(this.zzm);
    int i = j;
    if (j == 0)
      i = 1; 
    return i;
  }
  
  public final int 쾌() {
    int j = td.키(this.zzn);
    int i = j;
    if (j == 0)
      i = 1; 
    return i;
  }
  
  public final int 크() {
    int j = td.키(this.zzp);
    int i = j;
    if (j == 0)
      i = 1; 
    return i;
  }
  
  public final int 큰() {
    int j = td.키(this.zzg);
    int i = j;
    if (j == 0)
      i = 1; 
    return i;
  }
  
  public final int 키() {
    int j = td.키(this.zzl);
    int i = j;
    if (j == 0)
      i = 1; 
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\internal\ads\protected.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */