package com.google.android.gms.ads.internal.client;

import android.content.Context;
import y.c71;
import y.nx0;
import y.qx0;
import y.zx1;

public class LiteSdkInfo extends c71 {
  public LiteSdkInfo(Context paramContext) {}
  
  public qx0 getAdapterCreator() {
    return (qx0)new nx0();
  }
  
  public zx1 getLiteSdkVersion() {
    return new zx1(224400003, 224400000, "21.5.0");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\internal\client\LiteSdkInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */