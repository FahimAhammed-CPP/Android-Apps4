package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import y.a51;
import y.ac;
import y.b02;
import y.b52;
import y.d31;
import y.dz2;
import y.e01;
import y.e02;
import y.ga1;
import y.i53;
import y.il0;
import y.kj1;
import y.ks0;
import y.kt2;
import y.l91;
import y.ml0;
import y.o50;
import y.pw0;
import y.q10;
import y.qn1;
import y.qu0;
import y.qx0;
import y.r6;
import y.s4;
import y.sp0;
import y.tp0;
import y.u21;
import y.x03;
import y.x51;
import y.xa1;
import y.xp0;
import y.yz0;
import y.zz1;
import y.類;

public class ClientApi extends u21 {
  public final d31 す(類 param類, String paramString, qx0 paramqx0, int paramInt) {
    Context context = (Context)r6.ㅌ(param類);
    xa1 xa1 = ga1.堅(context, paramqx0, paramInt);
    context.getClass();
    return (d31)((kt2)(new ac(xa1.熱, context, paramString)).辛).暑();
  }
  
  public final pw0 ぞ(類 param類, dz2 paramdz2, String paramString, int paramInt) {
    return (pw0)new x03((Context)r6.ㅌ(param類), paramdz2, paramString, new x51(paramInt, false));
  }
  
  public final yz0 で(類 param類, qx0 paramqx0, int paramInt) {
    return (yz0)(ga1.堅((Context)r6.ㅌ(param類), paramqx0, paramInt)).触.暑();
  }
  
  public final kj1 ジ(類 param類, qx0 paramqx0, int paramInt) {
    return (kj1)(ga1.堅((Context)r6.ㅌ(param類), paramqx0, paramInt)).起.暑();
  }
  
  public final a51 唇(類 param類, qx0 paramqx0, int paramInt) {
    return (a51)(ga1.堅((Context)r6.ㅌ(param類), paramqx0, paramInt)).寝.暑();
  }
  
  public final ks0 父(類 param類1, 類 param類2) {
    return (ks0)new qn1((FrameLayout)r6.ㅌ(param類1), (FrameLayout)r6.ㅌ(param類2));
  }
  
  public final pw0 胸(類 param類, dz2 paramdz2, String paramString, qx0 paramqx0, int paramInt) {
    Context context = (Context)r6.ㅌ(param類);
    xa1 xa1 = ga1.堅(context, paramqx0, paramInt);
    context.getClass();
    paramdz2.getClass();
    paramString.getClass();
    return (pw0)((kt2)(new q10(xa1.熱, context, paramString, paramdz2)).産).暑();
  }
  
  public final pw0 腿(類 param類, dz2 paramdz2, String paramString, qx0 paramqx0, int paramInt) {
    Context context = (Context)r6.ㅌ(param類);
    xa1 xa1 = ga1.堅(context, paramqx0, paramInt);
    context.getClass();
    paramdz2.getClass();
    paramString.getClass();
    s4 s4 = new s4(xa1.熱, context, paramString, paramdz2);
    context = (Context)s4.硬;
    paramdz2 = (dz2)s4.堅;
    paramString = (String)s4.熱;
    b52 b52 = (b52)((kt2)s4.ぱ).暑();
    e02 e02 = (e02)((kt2)s4.旨).暑();
    x51 x51 = ((xa1)s4.暑).堅.硬;
    il0.死(x51);
    return (pw0)new b02(context, paramdz2, paramString, b52, e02, x51);
  }
  
  public final pw0 護(類 param類, dz2 paramdz2, String paramString, qx0 paramqx0, int paramInt) {
    Context context = (Context)r6.ㅌ(param類);
    xa1 xa1 = ga1.堅(context, paramqx0, paramInt);
    paramString.getClass();
    context.getClass();
    s4 s4 = new s4(xa1.熱, context, paramString);
    sp0 sp0 = xp0.鷲;
    return (pw0)((paramInt >= ((Integer)ml0.暑.熱.硬((tp0)sp0)).intValue()) ? ((kt2)s4.ぱ).暑() : ((kt2)s4.旨).暑());
  }
  
  public final qu0 顔(類 param類, String paramString, qx0 paramqx0, int paramInt) {
    Context context = (Context)r6.ㅌ(param類);
    return (qu0)new zz1(ga1.堅(context, paramqx0, paramInt), context, paramString);
  }
  
  public final l91 택(類 param類, int paramInt) {
    return (l91)(ga1.堅((Context)r6.ㅌ(param類), null, paramInt)).産.暑();
  }
  
  public final e01 퇴(類 param類) {
    Activity activity = (Activity)r6.ㅌ(param類);
    Intent intent = activity.getIntent();
    try {
      Bundle bundle = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
      bundle.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
      AdOverlayInfoParcel adOverlayInfoParcel = (AdOverlayInfoParcel)bundle.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
    } catch (Exception exception) {
      exception = null;
    } 
    if (exception == null)
      return (e01)new o50(activity, 4); 
    int i = ((AdOverlayInfoParcel)exception).壊;
    return (e01)((i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? new o50(activity, 4) : new o50(activity, 0)) : new i53(activity, (AdOverlayInfoParcel)exception)) : new o50(activity, 2)) : new o50(activity, 1)) : new o50(activity, 3));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\internal\ClientApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */