package com.google.android.gms.ads.internal.overlay;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import y.at1;
import y.au0;
import y.bl1;
import y.bu0;
import y.dv0;
import y.e91;
import y.g91;
import y.hr1;
import y.ih1;
import y.ik;
import y.ml0;
import y.mu2;
import y.o01;
import y.ow1;
import y.px2;
import y.q30;
import y.r6;
import y.s53;
import y.sp0;
import y.tp0;
import y.transient;
import y.ul1;
import y.v82;
import y.x51;
import y.xp0;
import y.花;

public final class AdOverlayInfoParcel extends transient implements ReflectedParcelable {
  public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = (Parcelable.Creator<AdOverlayInfoParcel>)new 花(28);
  
  public final dv0 あ;
  
  public final String か;
  
  public final String ち;
  
  public final ih1 ゃ;
  
  public final ow1 噛;
  
  public final int 壊;
  
  public final String 寝;
  
  public final String 帰;
  
  public final q30 怖;
  
  public final px2 恐;
  
  public final v82 投;
  
  public final String 歩;
  
  public final int 死;
  
  public final mu2 泳;
  
  public final o01 淋;
  
  public final s53 産;
  
  public final bu0 痒;
  
  public final e91 痛;
  
  public final String 臭;
  
  public final String 興;
  
  public final hr1 触;
  
  public final bl1 赤;
  
  public final boolean 起;
  
  public final au0 踊;
  
  public final x51 返;
  
  public AdOverlayInfoParcel(at1 paramat1, e91 parame91, x51 paramx51) {
    this.恐 = (px2)paramat1;
    this.痛 = parame91;
    this.死 = 1;
    this.返 = paramx51;
    this.淋 = null;
    this.怖 = null;
    this.踊 = null;
    this.痒 = null;
    this.臭 = null;
    this.起 = false;
    this.興 = null;
    this.産 = null;
    this.壊 = 1;
    this.帰 = null;
    this.歩 = null;
    this.泳 = null;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = null;
    this.ゃ = null;
    this.赤 = null;
  }
  
  public AdOverlayInfoParcel(e91 parame91, x51 paramx51, dv0 paramdv0, ow1 paramow1, hr1 paramhr1, v82 paramv82, String paramString1, String paramString2) {
    this.淋 = null;
    this.怖 = null;
    this.恐 = null;
    this.痛 = parame91;
    this.踊 = null;
    this.痒 = null;
    this.臭 = null;
    this.起 = false;
    this.興 = null;
    this.産 = null;
    this.死 = 14;
    this.壊 = 5;
    this.帰 = null;
    this.返 = paramx51;
    this.歩 = null;
    this.泳 = null;
    this.寝 = paramString1;
    this.か = paramString2;
    this.噛 = paramow1;
    this.触 = paramhr1;
    this.投 = paramv82;
    this.あ = paramdv0;
    this.ち = null;
    this.ゃ = null;
    this.赤 = null;
  }
  
  public AdOverlayInfoParcel(o01 paramo01, IBinder paramIBinder1, IBinder paramIBinder2, IBinder paramIBinder3, IBinder paramIBinder4, String paramString1, boolean paramBoolean, String paramString2, IBinder paramIBinder5, int paramInt1, int paramInt2, String paramString3, x51 paramx51, String paramString4, mu2 parammu2, IBinder paramIBinder6, String paramString5, IBinder paramIBinder7, IBinder paramIBinder8, IBinder paramIBinder9, IBinder paramIBinder10, String paramString6, String paramString7, IBinder paramIBinder11, IBinder paramIBinder12) {
    this.淋 = paramo01;
    this.怖 = (q30)r6.ㅌ(r6.あ(paramIBinder1));
    this.恐 = (px2)r6.ㅌ(r6.あ(paramIBinder2));
    this.痛 = (e91)r6.ㅌ(r6.あ(paramIBinder3));
    this.踊 = (au0)r6.ㅌ(r6.あ(paramIBinder6));
    this.痒 = (bu0)r6.ㅌ(r6.あ(paramIBinder4));
    this.臭 = paramString1;
    this.起 = paramBoolean;
    this.興 = paramString2;
    this.産 = (s53)r6.ㅌ(r6.あ(paramIBinder5));
    this.死 = paramInt1;
    this.壊 = paramInt2;
    this.帰 = paramString3;
    this.返 = paramx51;
    this.歩 = paramString4;
    this.泳 = parammu2;
    this.寝 = paramString5;
    this.か = paramString6;
    this.噛 = (ow1)r6.ㅌ(r6.あ(paramIBinder7));
    this.触 = (hr1)r6.ㅌ(r6.あ(paramIBinder8));
    this.投 = (v82)r6.ㅌ(r6.あ(paramIBinder9));
    this.あ = (dv0)r6.ㅌ(r6.あ(paramIBinder10));
    this.ち = paramString7;
    this.ゃ = (ih1)r6.ㅌ(r6.あ(paramIBinder11));
    this.赤 = (bl1)r6.ㅌ(r6.あ(paramIBinder12));
  }
  
  public AdOverlayInfoParcel(o01 paramo01, q30 paramq30, px2 parampx2, s53 params53, x51 paramx51, e91 parame91, bl1 parambl1) {
    this.淋 = paramo01;
    this.怖 = paramq30;
    this.恐 = parampx2;
    this.痛 = parame91;
    this.踊 = null;
    this.痒 = null;
    this.臭 = null;
    this.起 = false;
    this.興 = null;
    this.産 = params53;
    this.死 = -1;
    this.壊 = 4;
    this.帰 = null;
    this.返 = paramx51;
    this.歩 = null;
    this.泳 = null;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = null;
    this.ゃ = null;
    this.赤 = parambl1;
  }
  
  public AdOverlayInfoParcel(q30 paramq30, g91 paramg91, au0 paramau0, bu0 parambu0, s53 params53, e91 parame91, boolean paramBoolean, int paramInt, String paramString1, String paramString2, x51 paramx51, bl1 parambl1) {
    this.淋 = null;
    this.怖 = paramq30;
    this.恐 = (px2)paramg91;
    this.痛 = parame91;
    this.踊 = paramau0;
    this.痒 = parambu0;
    this.臭 = paramString2;
    this.起 = paramBoolean;
    this.興 = paramString1;
    this.産 = params53;
    this.死 = paramInt;
    this.壊 = 3;
    this.帰 = null;
    this.返 = paramx51;
    this.歩 = null;
    this.泳 = null;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = null;
    this.ゃ = null;
    this.赤 = parambl1;
  }
  
  public AdOverlayInfoParcel(q30 paramq30, g91 paramg91, au0 paramau0, bu0 parambu0, s53 params53, e91 parame91, boolean paramBoolean, int paramInt, String paramString, x51 paramx51, bl1 parambl1) {
    this.淋 = null;
    this.怖 = paramq30;
    this.恐 = (px2)paramg91;
    this.痛 = parame91;
    this.踊 = paramau0;
    this.痒 = parambu0;
    this.臭 = null;
    this.起 = paramBoolean;
    this.興 = null;
    this.産 = params53;
    this.死 = paramInt;
    this.壊 = 3;
    this.帰 = paramString;
    this.返 = paramx51;
    this.歩 = null;
    this.泳 = null;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = null;
    this.ゃ = null;
    this.赤 = parambl1;
  }
  
  public AdOverlayInfoParcel(q30 paramq30, px2 parampx2, s53 params53, e91 parame91, boolean paramBoolean, int paramInt, x51 paramx51, bl1 parambl1) {
    this.淋 = null;
    this.怖 = paramq30;
    this.恐 = parampx2;
    this.痛 = parame91;
    this.踊 = null;
    this.痒 = null;
    this.臭 = null;
    this.起 = paramBoolean;
    this.興 = null;
    this.産 = params53;
    this.死 = paramInt;
    this.壊 = 2;
    this.帰 = null;
    this.返 = paramx51;
    this.歩 = null;
    this.泳 = null;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = null;
    this.ゃ = null;
    this.赤 = parambl1;
  }
  
  public AdOverlayInfoParcel(ul1 paramul1, e91 parame91, int paramInt, x51 paramx51, String paramString1, mu2 parammu2, String paramString2, String paramString3, String paramString4, ih1 paramih1) {
    this.淋 = null;
    this.怖 = null;
    this.恐 = (px2)paramul1;
    this.痛 = parame91;
    this.踊 = null;
    this.痒 = null;
    this.起 = false;
    sp0 sp0 = xp0.僕;
    if (((Boolean)ml0.暑.熱.硬((tp0)sp0)).booleanValue()) {
      this.臭 = null;
      this.興 = null;
    } else {
      this.臭 = paramString2;
      this.興 = paramString3;
    } 
    this.産 = null;
    this.死 = paramInt;
    this.壊 = 1;
    this.帰 = null;
    this.返 = paramx51;
    this.歩 = paramString1;
    this.泳 = parammu2;
    this.寝 = null;
    this.か = null;
    this.噛 = null;
    this.触 = null;
    this.投 = null;
    this.あ = null;
    this.ち = paramString4;
    this.ゃ = paramih1;
    this.赤 = null;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = ik.俺(paramParcel, 20293);
    ik.た(paramParcel, 2, (Parcelable)this.淋, paramInt);
    ik.투(paramParcel, 3, (IBinder)new r6(this.怖));
    ik.투(paramParcel, 4, (IBinder)new r6(this.恐));
    ik.투(paramParcel, 5, (IBinder)new r6(this.痛));
    ik.투(paramParcel, 6, (IBinder)new r6(this.痒));
    ik.し(paramParcel, 7, this.臭);
    ik.톨(paramParcel, 8, this.起);
    ik.し(paramParcel, 9, this.興);
    ik.투(paramParcel, 10, (IBinder)new r6(this.産));
    ik.퉁(paramParcel, 11, this.死);
    ik.퉁(paramParcel, 12, this.壊);
    ik.し(paramParcel, 13, this.帰);
    ik.た(paramParcel, 14, (Parcelable)this.返, paramInt);
    ik.し(paramParcel, 16, this.歩);
    ik.た(paramParcel, 17, (Parcelable)this.泳, paramInt);
    ik.투(paramParcel, 18, (IBinder)new r6(this.踊));
    ik.し(paramParcel, 19, this.寝);
    ik.투(paramParcel, 20, (IBinder)new r6(this.噛));
    ik.투(paramParcel, 21, (IBinder)new r6(this.触));
    ik.투(paramParcel, 22, (IBinder)new r6(this.投));
    ik.투(paramParcel, 23, (IBinder)new r6(this.あ));
    ik.し(paramParcel, 24, this.か);
    ik.し(paramParcel, 25, this.ち);
    ik.투(paramParcel, 26, (IBinder)new r6(this.ゃ));
    ik.투(paramParcel, 27, (IBinder)new r6(this.赤));
    ik.看(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\AdOverlayInfoParcel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */