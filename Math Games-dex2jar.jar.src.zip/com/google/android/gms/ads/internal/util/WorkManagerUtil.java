package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.os.Parcel;
import com.google.android.apps.common.proguard.UsedByReflection;
import com.google.android.gms.ads.internal.offline.buffering.OfflineNotificationPoster;
import com.google.android.gms.ads.internal.offline.buffering.OfflinePingSender;
import java.util.Collections;
import java.util.HashMap;
import y.df1;
import y.dv0;
import y.f10;
import y.i10;
import y.nf0;
import y.r6;
import y.rr1;
import y.v5;
import y.v7;
import y.w7;
import y.yw0;
import y.z00;
import y.寝;
import y.茎;
import y.類;
import y.급;
import y.징;
import y.치;
import y.칙;

public class WorkManagerUtil extends nf0 implements dv0 {
  @UsedByReflection("This class must be instantiated reflectively so that the default class loader can be used.")
  public WorkManagerUtil() {
    super("com.google.android.gms.ads.internal.util.IWorkManagerUtil");
  }
  
  public final void zze(類 param類) {
    Context context = (Context)r6.ㅌ(param類);
    try {
      z00.ア(context.getApplicationContext(), new 징(new yw0()));
    } catch (IllegalStateException illegalStateException) {}
    try {
      z00 z00 = z00.ニ(context);
      寝 寝 = new 寝(z00, "offline_ping_sender_work", 1);
      ((茎)z00.噛).不((Runnable)寝);
      치 치 = new 치();
      치.硬 = v5.怖;
      칙 칙 = new 칙(치);
      v7 v7 = new v7(OfflinePingSender.class);
      ((f10)v7).堅.辛 = 칙;
      ((f10)v7).熱.add("offline_ping_sender_work");
      z00.ン(Collections.singletonList(v7.硬()));
      return;
    } catch (IllegalStateException illegalStateException) {
      df1 df1 = rr1.硬;
    } 
  }
  
  public final boolean zzf(類 param類, String paramString1, String paramString2) {
    Context context = (Context)r6.ㅌ(param類);
    try {
      z00.ア(context.getApplicationContext(), new 징(new yw0()));
    } catch (IllegalStateException illegalStateException) {}
    치 치 = new 치();
    치.硬 = v5.怖;
    칙 칙 = new 칙(치);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("uri", paramString1);
    hashMap.put("gws_query_id", paramString2);
    급 급 = new 급(hashMap);
    급.堅(급);
    v7 v7 = new v7(OfflineNotificationPoster.class);
    i10 i10 = ((f10)v7).堅;
    i10.辛 = 칙;
    i10.冷 = 급;
    ((f10)v7).熱.add("offline_notification_work");
    w7 w7 = v7.硬();
    try {
      z00 z00 = z00.ニ(context);
      z00.ン(Collections.singletonList(w7));
      return true;
    } catch (IllegalStateException illegalStateException) {}
    df1 df1 = rr1.硬;
    return false;
  }
  
  public final boolean ー(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\interna\\util\WorkManagerUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */