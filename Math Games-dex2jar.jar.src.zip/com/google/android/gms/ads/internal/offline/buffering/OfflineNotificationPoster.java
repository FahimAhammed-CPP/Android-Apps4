package com.google.android.gms.ads.internal.offline.buffering;

import android.content.Context;
import android.os.RemoteException;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import y.ci0;
import y.l80;
import y.nj0;
import y.nx0;
import y.r6;
import y.yz0;
import y.そ;
import y.弟;
import y.祖;
import y.類;
import y.급;

public class OfflineNotificationPoster extends Worker {
  public final yz0 起;
  
  public OfflineNotificationPoster(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    ci0 ci0 = nj0.寒.堅;
    nx0 nx0 = new nx0();
    ci0.getClass();
    this.起 = (yz0)(new l80(paramContext, nx0)).暑(paramContext, false);
  }
  
  public final 祖 doWork() {
    Object object1 = (getInputData()).硬.get("uri");
    boolean bool = object1 instanceof String;
    String str = null;
    if (bool) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    Object object2 = (getInputData()).硬.get("gws_query_id");
    if (object2 instanceof String)
      str = (String)object2; 
    try {
      this.起.尻((類)new r6(getApplicationContext()), (String)object1, str);
      return (祖)new そ(급.堅);
    } catch (RemoteException remoteException) {
      return (祖)new 弟();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\internal\offline\buffering\OfflineNotificationPoster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */