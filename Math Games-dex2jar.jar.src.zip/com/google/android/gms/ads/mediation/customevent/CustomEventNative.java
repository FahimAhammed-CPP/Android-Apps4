package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import y.e5;
import y.군;
import y.궁;

@Deprecated
public interface CustomEventNative extends 군 {
  void requestNativeAd(Context paramContext, 궁 param궁, String paramString, e5 parame5, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */