package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.common.annotation.KeepName;
import y.d11;
import y.e2;
import y.e5;
import y.i2;
import y.k2;
import y.m2;
import y.rr1;
import y.ス;
import y.畳;
import y.茎;
import y.麦;
import y.굴;
import y.굿;
import y.궁;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {
  public static final 麦 暑 = new 麦(0, "Could not instantiate custom event adapter", "com.google.android.gms.ads");
  
  public CustomEventInterstitial 堅;
  
  public CustomEventNative 熱;
  
  public CustomEventBanner 硬;
  
  public static Object 硬(Class<Class<?>> paramClass, String paramString) {
    paramString.getClass();
    try {
      return paramClass.cast(Class.forName(paramString).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
    } finally {
      paramClass = null;
      String str = paramClass.getMessage();
      StringBuilder stringBuilder = new StringBuilder("Could not instantiate custom event adapter: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      rr1.美(stringBuilder.toString());
    } 
  }
  
  public View getBannerView() {
    return null;
  }
  
  public void onDestroy() {
    CustomEventBanner customEventBanner = this.硬;
    if (customEventBanner != null)
      customEventBanner.onDestroy(); 
    CustomEventInterstitial customEventInterstitial = this.堅;
    if (customEventInterstitial != null)
      customEventInterstitial.onDestroy(); 
    CustomEventNative customEventNative = this.熱;
    if (customEventNative != null)
      customEventNative.onDestroy(); 
  }
  
  public void onPause() {
    CustomEventBanner customEventBanner = this.硬;
    if (customEventBanner != null)
      customEventBanner.onPause(); 
    CustomEventInterstitial customEventInterstitial = this.堅;
    if (customEventInterstitial != null)
      customEventInterstitial.onPause(); 
    CustomEventNative customEventNative = this.熱;
    if (customEventNative != null)
      customEventNative.onPause(); 
  }
  
  public void onResume() {
    CustomEventBanner customEventBanner = this.硬;
    if (customEventBanner != null)
      customEventBanner.onResume(); 
    CustomEventInterstitial customEventInterstitial = this.堅;
    if (customEventInterstitial != null)
      customEventInterstitial.onResume(); 
    CustomEventNative customEventNative = this.熱;
    if (customEventNative != null)
      customEventNative.onResume(); 
  }
  
  public void requestBannerAd(Context paramContext, i2 parami2, Bundle paramBundle1, ス paramス, e2 parame2, Bundle paramBundle2) {
    麦 麦1;
    CustomEventBanner customEventBanner = (CustomEventBanner)硬(CustomEventBanner.class, paramBundle1.getString("class_name"));
    this.硬 = customEventBanner;
    if (customEventBanner == null) {
      麦1 = 暑;
      ((d11)parami2).堅(麦1);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventBanner = this.硬;
    customEventBanner.getClass();
    customEventBanner.requestBannerAd((Context)麦1, (굴)new 畳(this, 15, parami2), paramBundle1.getString("parameter"), paramス, parame2, paramBundle2);
  }
  
  public void requestInterstitialAd(Context paramContext, k2 paramk2, Bundle paramBundle1, e2 parame2, Bundle paramBundle2) {
    麦 麦1;
    CustomEventInterstitial customEventInterstitial = (CustomEventInterstitial)硬(CustomEventInterstitial.class, paramBundle1.getString("class_name"));
    this.堅 = customEventInterstitial;
    if (customEventInterstitial == null) {
      麦1 = 暑;
      ((d11)paramk2).熱(麦1);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventInterstitial = this.堅;
    customEventInterstitial.getClass();
    customEventInterstitial.requestInterstitialAd((Context)麦1, (굿)new 茎(this, this, paramk2, 17), paramBundle1.getString("parameter"), parame2, paramBundle2);
  }
  
  public void requestNativeAd(Context paramContext, m2 paramm2, Bundle paramBundle1, e5 parame5, Bundle paramBundle2) {
    麦 麦1;
    CustomEventNative customEventNative = (CustomEventNative)硬(CustomEventNative.class, paramBundle1.getString("class_name"));
    this.熱 = customEventNative;
    if (customEventNative == null) {
      麦1 = 暑;
      ((d11)paramm2).暑(麦1);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventNative = this.熱;
    customEventNative.getClass();
    customEventNative.requestNativeAd((Context)麦1, (궁)new 畳(this, 16, paramm2), paramBundle1.getString("parameter"), parame5, paramBundle2);
  }
  
  public void showInterstitial() {
    CustomEventInterstitial customEventInterstitial = this.堅;
    if (customEventInterstitial != null)
      customEventInterstitial.showInterstitial(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */