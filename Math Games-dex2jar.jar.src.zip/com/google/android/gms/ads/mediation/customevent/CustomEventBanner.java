package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import y.e2;
import y.ス;
import y.군;
import y.굴;

@Deprecated
public interface CustomEventBanner extends 군 {
  void requestBannerAd(Context paramContext, 굴 param굴, String paramString, ス paramス, e2 parame2, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventBanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */