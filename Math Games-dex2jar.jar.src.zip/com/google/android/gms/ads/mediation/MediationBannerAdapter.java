package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import y.e2;
import y.f2;
import y.i2;
import y.ス;

@Deprecated
public interface MediationBannerAdapter extends f2 {
  View getBannerView();
  
  void requestBannerAd(Context paramContext, i2 parami2, Bundle paramBundle1, ス paramス, e2 parame2, Bundle paramBundle2);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationBannerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */