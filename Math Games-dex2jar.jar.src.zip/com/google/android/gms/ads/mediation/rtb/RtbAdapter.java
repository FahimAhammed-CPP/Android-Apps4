package com.google.android.gms.ads.mediation.rtb;

import javax.annotation.ParametersAreNonnullByDefault;
import y.d2;
import y.g2;
import y.h2;
import y.j2;
import y.ji;
import y.l2;
import y.ml;
import y.n2;
import y.味;
import y.麦;

@ParametersAreNonnullByDefault
public abstract class RtbAdapter extends 味 {
  public abstract void collectSignals(ji paramji, ml paramml);
  
  public void loadRtbAppOpenAd(g2 paramg2, d2 paramd2) {
    loadAppOpenAd(paramg2, paramd2);
  }
  
  public void loadRtbBannerAd(h2 paramh2, d2 paramd2) {
    loadBannerAd(paramh2, paramd2);
  }
  
  public void loadRtbInterscrollerAd(h2 paramh2, d2 paramd2) {
    paramd2.淋(new 麦(7, getClass().getSimpleName().concat(" does not support interscroller ads."), "com.google.android.gms.ads"));
  }
  
  public void loadRtbInterstitialAd(j2 paramj2, d2 paramd2) {
    loadInterstitialAd(paramj2, paramd2);
  }
  
  public void loadRtbNativeAd(l2 paraml2, d2 paramd2) {
    loadNativeAd(paraml2, paramd2);
  }
  
  public void loadRtbRewardedAd(n2 paramn2, d2 paramd2) {
    loadRewardedAd(paramn2, paramd2);
  }
  
  public void loadRtbRewardedInterstitialAd(n2 paramn2, d2 paramd2) {
    loadRewardedInterstitialAd(paramn2, paramd2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\rtb\RtbAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */