package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import y.e5;
import y.f2;
import y.m2;

@Deprecated
public interface MediationNativeAdapter extends f2 {
  void requestNativeAd(Context paramContext, m2 paramm2, Bundle paramBundle1, e5 parame5, Bundle paramBundle2);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationNativeAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */