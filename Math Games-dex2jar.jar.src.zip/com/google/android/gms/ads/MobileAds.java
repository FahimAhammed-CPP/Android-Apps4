package com.google.android.gms.ads;

import android.os.RemoteException;
import y.df1;
import y.ew1;
import y.rr1;
import y.年;
import y.銅;

public class MobileAds {
  private static void setPlugin(String paramString) {
    ew1 ew1 = ew1.堅();
    synchronized (ew1.冷) {
      boolean bool;
      if (ew1.寒 != null) {
        bool = true;
      } else {
        bool = false;
      } 
      年.辛("MobileAds.initialize() must be called prior to setting the plugin.", bool);
      try {
        ew1.寒.ね(paramString);
      } catch (RemoteException remoteException) {
        df1 df1 = rr1.硬;
      } 
      return;
    } 
  }
  
  public static void 硬(銅 param銅) {
    // Byte code:
    //   0: invokestatic 堅 : ()Ly/ew1;
    //   3: astore_2
    //   4: aload_2
    //   5: getfield 硬 : Ljava/lang/Object;
    //   8: astore_3
    //   9: aload_3
    //   10: monitorenter
    //   11: aload_2
    //   12: getfield 熱 : Z
    //   15: ifeq -> 21
    //   18: aload_3
    //   19: monitorexit
    //   20: return
    //   21: aload_2
    //   22: getfield 暑 : Z
    //   25: ifeq -> 31
    //   28: aload_3
    //   29: monitorexit
    //   30: return
    //   31: aload_2
    //   32: iconst_1
    //   33: putfield 熱 : Z
    //   36: aload_3
    //   37: monitorexit
    //   38: aload_0
    //   39: ifnull -> 297
    //   42: aload_2
    //   43: getfield 冷 : Ljava/lang/Object;
    //   46: astore_3
    //   47: aload_3
    //   48: monitorenter
    //   49: aload_2
    //   50: aload_0
    //   51: invokevirtual 硬 : (Ly/銅;)V
    //   54: aload_2
    //   55: getfield 寒 : Ly/l91;
    //   58: new y/qv1
    //   61: dup
    //   62: aload_2
    //   63: invokespecial <init> : (Ly/ew1;)V
    //   66: invokeinterface 人 : (Ly/tv0;)V
    //   71: aload_2
    //   72: getfield 寒 : Ly/l91;
    //   75: new y/nx0
    //   78: dup
    //   79: invokespecial <init> : ()V
    //   82: invokeinterface 士 : (Ly/qx0;)V
    //   87: aload_2
    //   88: getfield 美 : Ly/zf;
    //   91: astore #4
    //   93: aload #4
    //   95: getfield 硬 : I
    //   98: iconst_m1
    //   99: if_icmpne -> 113
    //   102: aload #4
    //   104: getfield 堅 : I
    //   107: istore_1
    //   108: iload_1
    //   109: iconst_m1
    //   110: if_icmpeq -> 151
    //   113: aload_2
    //   114: getfield 寒 : Ly/l91;
    //   117: new y/d52
    //   120: dup
    //   121: aload #4
    //   123: invokespecial <init> : (Ly/zf;)V
    //   126: invokeinterface 消 : (Ly/d52;)V
    //   131: goto -> 151
    //   134: astore_0
    //   135: goto -> 293
    //   138: getstatic y/rr1.硬 : Ly/df1;
    //   141: astore #4
    //   143: goto -> 151
    //   146: getstatic y/rr1.硬 : Ly/df1;
    //   149: astore #4
    //   151: aload_0
    //   152: invokestatic 堅 : (Landroid/content/Context;)V
    //   155: getstatic y/xq0.硬 : Ly/lq0;
    //   158: invokevirtual 嬉 : ()Ljava/lang/Object;
    //   161: checkcast java/lang/Boolean
    //   164: invokevirtual booleanValue : ()Z
    //   167: ifeq -> 219
    //   170: getstatic y/xp0.報 : Ly/sp0;
    //   173: astore #4
    //   175: getstatic y/ml0.暑 : Ly/ml0;
    //   178: getfield 熱 : Ly/vp0;
    //   181: aload #4
    //   183: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   186: checkcast java/lang/Boolean
    //   189: invokevirtual booleanValue : ()Z
    //   192: ifeq -> 219
    //   195: ldc 'Initializing on bg thread'
    //   197: invokestatic 暑 : (Ljava/lang/String;)V
    //   200: getstatic y/q51.硬 : Ljava/util/concurrent/ThreadPoolExecutor;
    //   203: new y/vs1
    //   206: dup
    //   207: aload_2
    //   208: aload_0
    //   209: iconst_0
    //   210: invokespecial <init> : (Ly/ew1;Ly/銅;I)V
    //   213: invokevirtual execute : (Ljava/lang/Runnable;)V
    //   216: goto -> 290
    //   219: getstatic y/xq0.堅 : Ly/lq0;
    //   222: invokevirtual 嬉 : ()Ljava/lang/Object;
    //   225: checkcast java/lang/Boolean
    //   228: invokevirtual booleanValue : ()Z
    //   231: ifeq -> 280
    //   234: getstatic y/xp0.報 : Ly/sp0;
    //   237: astore #4
    //   239: getstatic y/ml0.暑 : Ly/ml0;
    //   242: getfield 熱 : Ly/vp0;
    //   245: aload #4
    //   247: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   250: checkcast java/lang/Boolean
    //   253: invokevirtual booleanValue : ()Z
    //   256: ifeq -> 280
    //   259: getstatic y/q51.堅 : Ljava/util/concurrent/ExecutorService;
    //   262: new y/vs1
    //   265: dup
    //   266: aload_2
    //   267: aload_0
    //   268: iconst_1
    //   269: invokespecial <init> : (Ly/ew1;Ly/銅;I)V
    //   272: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   277: goto -> 290
    //   280: ldc 'Initializing on calling thread'
    //   282: invokestatic 暑 : (Ljava/lang/String;)V
    //   285: aload_2
    //   286: aload_0
    //   287: invokevirtual 暑 : (Landroid/content/Context;)V
    //   290: aload_3
    //   291: monitorexit
    //   292: return
    //   293: aload_3
    //   294: monitorexit
    //   295: aload_0
    //   296: athrow
    //   297: new java/lang/IllegalArgumentException
    //   300: dup
    //   301: ldc 'Context cannot be null.'
    //   303: invokespecial <init> : (Ljava/lang/String;)V
    //   306: athrow
    //   307: astore_0
    //   308: aload_3
    //   309: monitorexit
    //   310: aload_0
    //   311: athrow
    //   312: astore #4
    //   314: goto -> 146
    //   317: astore #4
    //   319: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   11	20	307	finally
    //   21	30	307	finally
    //   31	38	307	finally
    //   49	108	312	android/os/RemoteException
    //   49	108	134	finally
    //   113	131	317	android/os/RemoteException
    //   113	131	134	finally
    //   138	143	312	android/os/RemoteException
    //   138	143	134	finally
    //   146	151	134	finally
    //   151	216	134	finally
    //   219	277	134	finally
    //   280	290	134	finally
    //   290	292	134	finally
    //   293	295	134	finally
    //   308	310	307	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\MobileAds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */