package com.google.android.gms.ads;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import y.ci0;
import y.l80;
import y.nj0;
import y.nx0;
import y.rr1;
import y.yz0;

public class AdService extends IntentService {
  public AdService() {
    super("AdService");
  }
  
  public final void onHandleIntent(Intent paramIntent) {
    try {
      ci0 ci0 = nj0.寒.堅;
      nx0 nx0 = new nx0();
      ci0.getClass();
      ((yz0)(new l80((Context)this, nx0)).暑((Context)this, false)).し(paramIntent);
      return;
    } catch (RemoteException remoteException) {
      rr1.冷("RemoteException calling handleNotificationIntent: ".concat(remoteException.toString()));
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\AdService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */