package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.widget.LinearLayout;
import y.ci0;
import y.kj1;
import y.n50;
import y.nj0;
import y.nx0;
import y.r6;
import y.類;

public final class OutOfContextTestingActivity extends Activity {
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ci0 ci0 = nj0.寒.堅;
    nx0 nx0 = new nx0();
    ci0.getClass();
    kj1 kj1 = (kj1)(new n50((Context)this, nx0)).暑((Context)this, false);
    if (kj1 == null) {
      finish();
      return;
    } 
    setContentView(2131427385);
    LinearLayout linearLayout = (LinearLayout)findViewById(2131231117);
    Intent intent = getIntent();
    if (intent == null) {
      finish();
      return;
    } 
    String str = intent.getStringExtra("adUnit");
    if (str == null) {
      finish();
      return;
    } 
    try {
      kj1.俺(str, (類)new r6(this), (類)new r6(linearLayout));
      return;
    } catch (RemoteException remoteException) {
      finish();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\OutOfContextTestingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */