package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import y.ci0;
import y.e01;
import y.nj0;
import y.r6;
import y.rr1;
import y.w30;
import y.類;

public final class AdActivity extends Activity {
  public e01 淋;
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.祖(paramInt1, paramInt2, paramIntent); 
    } catch (Exception exception) {
      rr1.旨("#007 Could not call remote method.", exception);
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public final void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Ly/e01;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokeinterface わ : ()Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifeq -> 49
    //   20: goto -> 30
    //   23: astore_2
    //   24: ldc '#007 Could not call remote method.'
    //   26: aload_2
    //   27: invokestatic 旨 : (Ljava/lang/String;Ljava/lang/Exception;)V
    //   30: aload_0
    //   31: invokespecial onBackPressed : ()V
    //   34: aload_0
    //   35: getfield 淋 : Ly/e01;
    //   38: astore_2
    //   39: aload_2
    //   40: ifnull -> 49
    //   43: aload_2
    //   44: invokeinterface 壊 : ()V
    //   49: return
    //   50: astore_2
    //   51: ldc '#007 Could not call remote method.'
    //   53: aload_2
    //   54: invokestatic 旨 : (Ljava/lang/String;Ljava/lang/Exception;)V
    //   57: return
    // Exception table:
    //   from	to	target	type
    //   0	5	23	android/os/RemoteException
    //   9	16	23	android/os/RemoteException
    //   34	39	50	android/os/RemoteException
    //   43	49	50	android/os/RemoteException
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.쾌((類)new r6(paramConfiguration)); 
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      return;
    } 
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ci0 ci0 = nj0.寒.堅;
    ci0.getClass();
    w30 w30 = new w30(ci0, this);
    Intent intent = getIntent();
    boolean bool2 = intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar");
    boolean bool1 = false;
    if (!bool2) {
      rr1.冷("useClientJar flag not found in activity intent extras.");
    } else {
      bool1 = intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
    } 
    e01 e011 = (e01)w30.暑((Context)this, bool1);
    this.淋 = e011;
    if (e011 != null)
      try {
        e011.髭(paramBundle);
        return;
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
        finish();
        return;
      }  
    rr1.旨("#007 Could not call remote method.", null);
    finish();
  }
  
  public final void onDestroy() {
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.寂(); 
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
    } 
    super.onDestroy();
  }
  
  public final void onPause() {
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.嬉(); 
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
    } 
    super.onPause();
  }
  
  public final void onRestart() {
    super.onRestart();
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.悲(); 
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onResume() {
    super.onResume();
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.ぱ(); 
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.伯(paramBundle); 
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
    } 
    super.onSaveInstanceState(paramBundle);
  }
  
  public final void onStart() {
    super.onStart();
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.臭(); 
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onStop() {
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.토(); 
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      finish();
    } 
    super.onStop();
  }
  
  public final void onUserLeaveHint() {
    super.onUserLeaveHint();
    try {
      e01 e011 = this.淋;
      if (e011 != null)
        e011.産(); 
      return;
    } catch (RemoteException remoteException) {
      rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      return;
    } 
  }
  
  public final void setContentView(int paramInt) {
    super.setContentView(paramInt);
    e01 e011 = this.淋;
    if (e011 != null)
      try {
        e011.痒();
        return;
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      }  
  }
  
  public final void setContentView(View paramView) {
    super.setContentView(paramView);
    e01 e011 = this.淋;
    if (e011 != null)
      try {
        e011.痒();
        return;
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      }  
  }
  
  public final void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
    e01 e011 = this.淋;
    if (e011 != null)
      try {
        e011.痒();
        return;
      } catch (RemoteException remoteException) {
        rr1.旨("#007 Could not call remote method.", (Exception)remoteException);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\ads\AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */