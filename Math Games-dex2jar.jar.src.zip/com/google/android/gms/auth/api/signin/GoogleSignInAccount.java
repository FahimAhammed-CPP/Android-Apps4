package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import y.bm;
import y.ik;
import y.jv2;
import y.transient;
import y.年;

public class GoogleSignInAccount extends transient implements ReflectedParcelable {
  public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = (Parcelable.Creator<GoogleSignInAccount>)new jv2(3);
  
  public final String 壊;
  
  public final String 帰;
  
  public final String 怖;
  
  public final String 恐;
  
  public final List 死;
  
  public final int 淋;
  
  public final String 産;
  
  public final String 痒;
  
  public final String 痛;
  
  public final Uri 臭;
  
  public final long 興;
  
  public String 起;
  
  public final HashSet 返 = new HashSet();
  
  public GoogleSignInAccount(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, Uri paramUri, String paramString5, long paramLong, String paramString6, ArrayList paramArrayList, String paramString7, String paramString8) {
    this.淋 = paramInt;
    this.怖 = paramString1;
    this.恐 = paramString2;
    this.痛 = paramString3;
    this.痒 = paramString4;
    this.臭 = paramUri;
    this.起 = paramString5;
    this.興 = paramLong;
    this.産 = paramString6;
    this.死 = paramArrayList;
    this.壊 = paramString7;
    this.帰 = paramString8;
  }
  
  public static GoogleSignInAccount 堅(String paramString) {
    String str1;
    String str2;
    String str3;
    String str4;
    if (TextUtils.isEmpty(paramString))
      return null; 
    JSONObject jSONObject = new JSONObject(paramString);
    paramString = jSONObject.optString("photoUrl");
    if (!TextUtils.isEmpty(paramString)) {
      Uri uri = Uri.parse(paramString);
    } else {
      paramString = null;
    } 
    long l = Long.parseLong(jSONObject.getString("expirationTime"));
    HashSet<Scope> hashSet = new HashSet();
    JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
    int j = jSONArray.length();
    for (int i = 0; i < j; i++)
      hashSet.add(new Scope(jSONArray.getString(i), 1)); 
    String str5 = jSONObject.optString("id");
    if (jSONObject.has("tokenId")) {
      String str = jSONObject.optString("tokenId");
    } else {
      jSONArray = null;
    } 
    if (jSONObject.has("email")) {
      str1 = jSONObject.optString("email");
    } else {
      str1 = null;
    } 
    if (jSONObject.has("displayName")) {
      str2 = jSONObject.optString("displayName");
    } else {
      str2 = null;
    } 
    if (jSONObject.has("givenName")) {
      str3 = jSONObject.optString("givenName");
    } else {
      str3 = null;
    } 
    if (jSONObject.has("familyName")) {
      str4 = jSONObject.optString("familyName");
    } else {
      str4 = null;
    } 
    String str6 = jSONObject.getString("obfuscatedIdentifier");
    l = Long.valueOf(l).longValue();
    年.冷(str6);
    GoogleSignInAccount googleSignInAccount = new GoogleSignInAccount(3, str5, (String)jSONArray, str1, str2, (Uri)paramString, null, l, str6, new ArrayList<Scope>(hashSet), str3, str4);
    if (jSONObject.has("serverAuthCode")) {
      paramString = jSONObject.optString("serverAuthCode");
    } else {
      paramString = null;
    } 
    googleSignInAccount.起 = paramString;
    return googleSignInAccount;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof GoogleSignInAccount))
      return false; 
    GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount)paramObject;
    if (googleSignInAccount.産.equals(this.産)) {
      paramObject = new HashSet(googleSignInAccount.死);
      paramObject.addAll(googleSignInAccount.返);
      HashSet hashSet = new HashSet(this.死);
      hashSet.addAll(this.返);
      if (paramObject.equals(hashSet))
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    int i = bm.堅(this.産, 527, 31);
    HashSet hashSet = new HashSet(this.死);
    hashSet.addAll(this.返);
    return hashSet.hashCode() + i;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = ik.俺(paramParcel, 20293);
    ik.퉁(paramParcel, 1, this.淋);
    ik.し(paramParcel, 2, this.怖);
    ik.し(paramParcel, 3, this.恐);
    ik.し(paramParcel, 4, this.痛);
    ik.し(paramParcel, 5, this.痒);
    ik.た(paramParcel, 6, (Parcelable)this.臭, paramInt);
    ik.し(paramParcel, 7, this.起);
    ik.者(paramParcel, 8, this.興);
    ik.し(paramParcel, 9, this.産);
    ik.僕(paramParcel, 10, this.死);
    ik.し(paramParcel, 11, this.壊);
    ik.し(paramParcel, 12, this.帰);
    ik.看(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\gms\auth\api\signin\GoogleSignInAccount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */