package com.google.android.material.datepicker;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Calendar;
import y.ef;
import y.g4;
import y.h4;
import y.he;
import y.m0;
import y.qe;
import y.r0;
import y.tu;
import y.死;
import y.男;

public final class for extends he {
  public final int 冷;
  
  public final 男 暑;
  
  public final 死 熱;
  
  public for(ContextThemeWrapper paramContextThemeWrapper, 死 param死, 男 param男) {
    Calendar calendar = param死.淋.淋;
    g4 g4 = param死.痛;
    if (calendar.compareTo(g4.淋) <= 0) {
      if (g4.淋.compareTo(param死.怖.淋) <= 0) {
        int j = h4.痛;
        int i = m0.し;
        int k = paramContextThemeWrapper.getResources().getDimensionPixelSize(2131100199);
        if (r0.わ((Context)paramContextThemeWrapper)) {
          i = paramContextThemeWrapper.getResources().getDimensionPixelSize(2131100199);
        } else {
          i = 0;
        } 
        this.冷 = k * j + i;
        this.熱 = param死;
        this.暑 = param男;
        if (!this.硬.硬()) {
          this.堅 = true;
          return;
        } 
        throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
      } 
      throw new IllegalArgumentException("currentPage cannot be after lastPage");
    } 
    throw new IllegalArgumentException("firstPage cannot be after currentPage");
  }
  
  public final long 堅(int paramInt) {
    Calendar calendar = tu.硬(this.熱.淋.淋);
    calendar.add(2, paramInt);
    return (new g4(calendar)).淋.getTimeInMillis();
  }
  
  public final ef 暑(RecyclerView paramRecyclerView) {
    LinearLayout linearLayout = (LinearLayout)LayoutInflater.from(paramRecyclerView.getContext()).inflate(2131427449, (ViewGroup)paramRecyclerView, false);
    if (r0.わ(paramRecyclerView.getContext())) {
      linearLayout.setLayoutParams((ViewGroup.LayoutParams)new qe(-1, this.冷));
      return new if(linearLayout, true);
    } 
    return new if(linearLayout, false);
  }
  
  public final void 熱(ef paramef, int paramInt) {
    if if = (if)paramef;
    死 死1 = this.熱;
    Calendar calendar = tu.硬(死1.淋.淋);
    calendar.add(2, paramInt);
    g4 g4 = new g4(calendar);
    if.痒.setText(g4.冷());
    MaterialCalendarGridView materialCalendarGridView = (MaterialCalendarGridView)if.臭.findViewById(2131231160);
    if (materialCalendarGridView.硬() != null && g4.equals((materialCalendarGridView.硬()).淋)) {
      materialCalendarGridView.invalidate();
      materialCalendarGridView.硬().getClass();
      throw null;
    } 
    new h4(g4, 死1);
    throw null;
  }
  
  public final int 硬() {
    return this.熱.臭;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\datepicker\for.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */