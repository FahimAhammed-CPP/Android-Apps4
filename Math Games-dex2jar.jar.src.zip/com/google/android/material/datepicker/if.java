package com.google.android.material.datepicker;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.WeakHashMap;
import y.ef;
import y.rw;
import y.wv;

public final class if extends ef {
  public final TextView 痒;
  
  public final MaterialCalendarGridView 臭;
  
  public if(LinearLayout paramLinearLayout, boolean paramBoolean) {
    super((View)paramLinearLayout);
    TextView textView = (TextView)paramLinearLayout.findViewById(2131231165);
    this.痒 = textView;
    WeakHashMap weakHashMap = rw.硬;
    (new wv(2131231336, 3)).熱((View)textView, Boolean.TRUE);
    this.臭 = (MaterialCalendarGridView)paramLinearLayout.findViewById(2131231160);
    if (!paramBoolean)
      textView.setVisibility(8); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\datepicker\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */