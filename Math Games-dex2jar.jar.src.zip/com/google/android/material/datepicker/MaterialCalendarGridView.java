package com.google.android.material.datepicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Adapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import y.g4;
import y.h0;
import y.h4;
import y.nul;
import y.r0;
import y.rw;
import y.tu;

final class MaterialCalendarGridView extends GridView {
  public final boolean 淋;
  
  public MaterialCalendarGridView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    tu.熱(null);
    if (r0.わ(getContext())) {
      setNextFocusLeftId(2131230950);
      setNextFocusRightId(2131230986);
    } 
    this.淋 = r0.も(getContext(), 2130903796);
    rw.帰((View)this, (nul)new h0(2, this));
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    硬().notifyDataSetChanged();
  }
  
  public final void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    h4 h4 = 硬();
    h4.getClass();
    int i = Math.max(h4.硬(), getFirstVisiblePosition());
    g4 g4 = h4.淋;
    int j = Math.min(g4.暑() + g4.痒 - 1, getLastVisiblePosition());
    h4.堅(i);
    h4.堅(j);
    throw null;
  }
  
  public final void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    g4 g4;
    if (paramBoolean) {
      if (paramInt == 33) {
        g4 = (硬()).淋;
        setSelection(g4.暑() + g4.痒 - 1);
        return;
      } 
      if (paramInt == 130) {
        setSelection(硬().硬());
        return;
      } 
      super.onFocusChanged(true, paramInt, (Rect)g4);
      return;
    } 
    super.onFocusChanged(false, paramInt, (Rect)g4);
  }
  
  public final boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (!super.onKeyDown(paramInt, paramKeyEvent))
      return false; 
    if (getSelectedItemPosition() != -1) {
      if (getSelectedItemPosition() >= 硬().硬())
        return true; 
      if (19 == paramInt) {
        setSelection(硬().硬());
        return true;
      } 
      return false;
    } 
    return true;
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    if (this.淋) {
      super.onMeasure(paramInt1, View.MeasureSpec.makeMeasureSpec(16777215, -2147483648));
      (getLayoutParams()).height = getMeasuredHeight();
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public final void setAdapter(ListAdapter paramListAdapter) {
    if (paramListAdapter instanceof h4) {
      super.setAdapter(paramListAdapter);
      return;
    } 
    throw new IllegalArgumentException(String.format("%1$s must have its Adapter set to a %2$s", new Object[] { MaterialCalendarGridView.class.getCanonicalName(), h4.class.getCanonicalName() }));
  }
  
  public final void setSelection(int paramInt) {
    if (paramInt < 硬().硬()) {
      super.setSelection(硬().硬());
      return;
    } 
    super.setSelection(paramInt);
  }
  
  public final h4 硬() {
    return (h4)super.getAdapter();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\datepicker\MaterialCalendarGridView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */