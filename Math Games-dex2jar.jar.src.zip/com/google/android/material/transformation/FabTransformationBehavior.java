package com.google.android.material.transformation;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import y.투;

@Deprecated
public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {
  public FabTransformationBehavior() {
    new Rect();
    new RectF();
    new RectF();
  }
  
  public FabTransformationBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    new Rect();
    new RectF();
    new RectF();
  }
  
  public final void 堅(View paramView) {
    if (paramView.getVisibility() != 8)
      return; 
    throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
  }
  
  public final void 熱(투 param투) {
    if (param투.旨 == 0)
      param투.旨 = 80; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\transformation\FabTransformationBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */