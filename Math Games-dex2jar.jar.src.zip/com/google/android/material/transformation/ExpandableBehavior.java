package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.ArrayList;
import y.bm;
import y.rw;
import y.톨;

@Deprecated
public abstract class ExpandableBehavior extends 톨 {
  public ExpandableBehavior() {}
  
  public ExpandableBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(0);
  }
  
  public abstract void 堅(View paramView);
  
  public final boolean 暑(View paramView1, View paramView2) {
    bm.悲(paramView2);
    throw null;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    if (!rw.寂(paramView)) {
      ArrayList<View> arrayList = paramCoordinatorLayout.辛(paramView);
      int i = arrayList.size();
      for (paramInt = 0; paramInt < i; paramInt++) {
        View view = arrayList.get(paramInt);
        堅(paramView);
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\transformation\ExpandableBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */