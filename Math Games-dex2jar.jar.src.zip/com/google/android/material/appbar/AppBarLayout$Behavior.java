package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;

public class AppBarLayout$Behavior extends AppBarLayout$BaseBehavior<Object> {
  public AppBarLayout$Behavior() {}
  
  public AppBarLayout$Behavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\appbar\AppBarLayout$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */