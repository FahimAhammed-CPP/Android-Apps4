package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import y.oy0;
import y.rw;
import y.td;
import y.u0;
import y.年;
import y.트;

public class MaterialToolbar extends Toolbar {
  public static final ImageView.ScaleType[] 톨 = new ImageView.ScaleType[] { ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE };
  
  public Integer 탱;
  
  public boolean 터;
  
  public boolean 테;
  
  public ImageView.ScaleType 토;
  
  public Boolean 톤;
  
  public MaterialToolbar(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    paramContext = getContext();
    TypedArray typedArray = td.淋(paramContext, paramAttributeSet, 年.返, 2130904094, 2131756100, new int[0]);
    if (typedArray.hasValue(2))
      setNavigationIconTint(typedArray.getColor(2, -1)); 
    this.터 = typedArray.getBoolean(4, false);
    this.테 = typedArray.getBoolean(3, false);
    int j = typedArray.getInt(1, -1);
    if (j >= 0) {
      ImageView.ScaleType[] arrayOfScaleType = 톨;
      if (j < arrayOfScaleType.length)
        this.토 = arrayOfScaleType[j]; 
    } 
    if (typedArray.hasValue(0))
      this.톤 = Boolean.valueOf(typedArray.getBoolean(0, false)); 
    typedArray.recycle();
    Drawable drawable = getBackground();
    if (drawable != null && !(drawable instanceof ColorDrawable))
      return; 
    u0 u0 = new u0();
    if (drawable != null)
      i = ((ColorDrawable)drawable).getColor(); 
    u0.辛(ColorStateList.valueOf(i));
    u0.旨(paramContext);
    u0.不(rw.冷((View)this));
    rw.歩((View)this, (Drawable)u0);
  }
  
  public ImageView.ScaleType getLogoScaleType() {
    return this.토;
  }
  
  public Integer getNavigationIconTint() {
    return this.탱;
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    Drawable drawable = getBackground();
    if (drawable instanceof u0)
      年.赤((View)this, (u0)drawable); 
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ImageView imageView;
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramBoolean = this.터;
    boolean bool = false;
    View view = null;
    if (paramBoolean || this.테) {
      TextView textView1;
      TextView textView2;
      ArrayList<? extends TextView> arrayList1 = oy0.触(this, getTitle());
      paramBoolean = arrayList1.isEmpty();
      트 트 = oy0.苦;
      if (paramBoolean) {
        arrayList1 = null;
      } else {
        textView1 = Collections.<TextView>min(arrayList1, (Comparator<? super TextView>)트);
      } 
      ArrayList<? extends TextView> arrayList2 = oy0.触(this, getSubtitle());
      if (arrayList2.isEmpty()) {
        트 = null;
      } else {
        textView2 = Collections.<TextView>max(arrayList2, (Comparator<? super TextView>)트);
      } 
      if (textView1 != null || textView2 != null) {
        paramInt2 = getMeasuredWidth();
        int i = paramInt2 / 2;
        paramInt1 = getPaddingLeft();
        paramInt4 = paramInt2 - getPaddingRight();
        paramInt3 = 0;
        while (paramInt3 < getChildCount()) {
          View view1 = getChildAt(paramInt3);
          int j = paramInt1;
          int k = paramInt4;
          if (view1.getVisibility() != 8) {
            j = paramInt1;
            k = paramInt4;
            if (view1 != textView1) {
              j = paramInt1;
              k = paramInt4;
              if (view1 != textView2) {
                paramInt2 = paramInt1;
                if (view1.getRight() < i) {
                  paramInt2 = paramInt1;
                  if (view1.getRight() > paramInt1)
                    paramInt2 = view1.getRight(); 
                } 
                j = paramInt2;
                k = paramInt4;
                if (view1.getLeft() > i) {
                  j = paramInt2;
                  k = paramInt4;
                  if (view1.getLeft() < paramInt4) {
                    k = view1.getLeft();
                    j = paramInt2;
                  } 
                } 
              } 
            } 
          } 
          paramInt3++;
          paramInt1 = j;
          paramInt4 = k;
        } 
        Pair pair = new Pair(Integer.valueOf(paramInt1), Integer.valueOf(paramInt4));
        if (this.터 && textView1 != null)
          痛(textView1, pair); 
        if (this.테 && textView2 != null)
          痛(textView2, pair); 
      } 
    } 
    Drawable drawable = getLogo();
    paramInt1 = bool;
    if (drawable == null) {
      View view1 = view;
    } else {
      while (true) {
        View view1 = view;
        if (paramInt1 < getChildCount()) {
          view1 = getChildAt(paramInt1);
          if (view1 instanceof ImageView) {
            imageView = (ImageView)view1;
            Drawable drawable1 = imageView.getDrawable();
            if (drawable1 != null && drawable1.getConstantState() != null && drawable1.getConstantState().equals(drawable.getConstantState()))
              break; 
          } 
          paramInt1++;
          continue;
        } 
        break;
      } 
    } 
    if (imageView != null) {
      Boolean bool1 = this.톤;
      if (bool1 != null)
        imageView.setAdjustViewBounds(bool1.booleanValue()); 
      ImageView.ScaleType scaleType = this.토;
      if (scaleType != null)
        imageView.setScaleType(scaleType); 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    Drawable drawable = getBackground();
    if (drawable instanceof u0)
      ((u0)drawable).不(paramFloat); 
  }
  
  public void setLogoAdjustViewBounds(boolean paramBoolean) {
    Boolean bool = this.톤;
    if (bool == null || bool.booleanValue() != paramBoolean) {
      this.톤 = Boolean.valueOf(paramBoolean);
      requestLayout();
    } 
  }
  
  public void setLogoScaleType(ImageView.ScaleType paramScaleType) {
    if (this.토 != paramScaleType) {
      this.토 = paramScaleType;
      requestLayout();
    } 
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    Drawable drawable = paramDrawable;
    if (paramDrawable != null) {
      drawable = paramDrawable;
      if (this.탱 != null) {
        drawable = td.帰(paramDrawable.mutate());
        td.起(drawable, this.탱.intValue());
      } 
    } 
    super.setNavigationIcon(drawable);
  }
  
  public void setNavigationIconTint(int paramInt) {
    this.탱 = Integer.valueOf(paramInt);
    Drawable drawable = getNavigationIcon();
    if (drawable != null)
      setNavigationIcon(drawable); 
  }
  
  public void setSubtitleCentered(boolean paramBoolean) {
    if (this.테 != paramBoolean) {
      this.테 = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setTitleCentered(boolean paramBoolean) {
    if (this.터 != paramBoolean) {
      this.터 = paramBoolean;
      requestLayout();
    } 
  }
  
  public final void 痛(TextView paramTextView, Pair paramPair) {
    int j = getMeasuredWidth();
    int i = paramTextView.getMeasuredWidth();
    int k = j / 2 - i / 2;
    int m = i + k;
    int n = Math.max(Math.max(((Integer)paramPair.first).intValue() - k, 0), Math.max(m - ((Integer)paramPair.second).intValue(), 0));
    j = k;
    i = m;
    if (n > 0) {
      j = k + n;
      i = m - n;
      paramTextView.measure(View.MeasureSpec.makeMeasureSpec(i - j, 1073741824), paramTextView.getMeasuredHeightAndState());
    } 
    paramTextView.layout(j, paramTextView.getTop(), i, paramTextView.getBottom());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\appbar\MaterialToolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */