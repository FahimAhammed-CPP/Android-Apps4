package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.ArrayList;
import y.sx;
import y.年;

public class AppBarLayout$ScrollingViewBehavior extends sx {
  public int 熱;
  
  public AppBarLayout$ScrollingViewBehavior() {
    new Rect();
    new Rect();
  }
  
  public AppBarLayout$ScrollingViewBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(0);
    new Rect();
    new Rect();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, 年.泳);
    this.熱 = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
  }
  
  public static void 痛(ArrayList<View> paramArrayList) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++)
      View view = paramArrayList.get(i); 
  }
  
  public final void 恐(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    痛(paramCoordinatorLayout.辛(paramView));
    paramCoordinatorLayout.淋(paramView, paramInt);
  }
  
  public final boolean 旨(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramInt1 = (paramView.getLayoutParams()).height;
    if (paramInt1 == -1 || paramInt1 == -2)
      痛(paramCoordinatorLayout.辛(paramView)); 
    return false;
  }
  
  public final boolean 暑(View paramView1, View paramView2) {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast y/투
    //   7: getfield 硬 : Ly/톨;
    //   10: astore #7
    //   12: aload #7
    //   14: instanceof com/google/android/material/appbar/AppBarLayout$BaseBehavior
    //   17: ifeq -> 101
    //   20: aload #7
    //   22: checkcast com/google/android/material/appbar/AppBarLayout$BaseBehavior
    //   25: astore #7
    //   27: aload_2
    //   28: invokevirtual getBottom : ()I
    //   31: istore #5
    //   33: aload_1
    //   34: invokevirtual getTop : ()I
    //   37: istore #6
    //   39: aload #7
    //   41: invokevirtual getClass : ()Ljava/lang/Class;
    //   44: pop
    //   45: aload_0
    //   46: getfield 熱 : I
    //   49: istore_3
    //   50: iload_3
    //   51: ifne -> 57
    //   54: goto -> 69
    //   57: iload_3
    //   58: i2f
    //   59: fconst_0
    //   60: fmul
    //   61: f2i
    //   62: istore #4
    //   64: iload #4
    //   66: ifge -> 74
    //   69: iconst_0
    //   70: istore_3
    //   71: goto -> 86
    //   74: iload #4
    //   76: iload_3
    //   77: if_icmple -> 83
    //   80: goto -> 86
    //   83: iload #4
    //   85: istore_3
    //   86: aload_1
    //   87: iload #5
    //   89: iload #6
    //   91: isub
    //   92: iconst_0
    //   93: iadd
    //   94: iconst_0
    //   95: iadd
    //   96: iload_3
    //   97: isub
    //   98: invokestatic 恐 : (Landroid/view/View;I)V
    //   101: iconst_0
    //   102: ireturn
  }
  
  public final void 苦(CoordinatorLayout paramCoordinatorLayout, View paramView) {
    痛(paramCoordinatorLayout.辛(paramView));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\appbar\AppBarLayout$ScrollingViewBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */