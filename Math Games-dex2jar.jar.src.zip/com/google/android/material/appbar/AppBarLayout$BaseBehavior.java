package com.google.android.material.appbar;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import y.bm;
import y.훼;

public class AppBarLayout$BaseBehavior<T> extends 훼 {
  public AppBarLayout$BaseBehavior() {}
  
  public AppBarLayout$BaseBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(0);
  }
  
  public final void ぱ(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    bm.臭(paramView);
    throw null;
  }
  
  public final void 嬉(View paramView, Parcelable paramParcelable) {
    bm.臭(paramView);
    throw null;
  }
  
  public final boolean 寂(View paramView, int paramInt1, int paramInt2) {
    bm.臭(paramView);
    throw null;
  }
  
  public final Parcelable 悲(View paramView) {
    bm.臭(paramView);
    throw null;
  }
  
  public final boolean 旨(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    bm.臭(paramView);
    throw null;
  }
  
  public final void 淋(View paramView1, View paramView2, int paramInt) {
    bm.臭(paramView1);
    throw null;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    bm.臭(paramView);
    throw null;
  }
  
  public final void 辛(View paramView1, View paramView2, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    bm.臭(paramView1);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\appbar\AppBarLayout$BaseBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */