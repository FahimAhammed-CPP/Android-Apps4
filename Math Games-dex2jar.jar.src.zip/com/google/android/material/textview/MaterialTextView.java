package com.google.android.material.textview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import y.年;
import y.服;
import y.꽃;

public class MaterialTextView extends 服 {
  public MaterialTextView(Context paramContext, AttributeSet paramAttributeSet) {
    super(年.크(paramContext, paramAttributeSet, 16842884, 0), paramAttributeSet, 16842884);
    int i;
    paramContext = getContext();
    TypedValue typedValue = 꽃.크(paramContext, 2130904017);
    boolean bool = true;
    if (typedValue == null || typedValue.type != 18 || typedValue.data != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      Resources.Theme theme = paramContext.getTheme();
      int[] arrayOfInt = 年.帰;
      TypedArray typedArray = theme.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 16842884, 0);
      i = 興(paramContext, typedArray, new int[] { 1, 2 });
      typedArray.recycle();
      if (i != -1) {
        i = bool;
      } else {
        i = 0;
      } 
      if (i == 0) {
        TypedArray typedArray1 = theme.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 16842884, 0);
        i = typedArray1.getResourceId(0, -1);
        typedArray1.recycle();
        if (i != -1)
          起(i, theme); 
      } 
    } 
  }
  
  public static int 興(Context paramContext, TypedArray paramTypedArray, int... paramVarArgs) {
    int j = 0;
    int i = -1;
    while (j < paramVarArgs.length && i < 0) {
      i = paramVarArgs[j];
      TypedValue typedValue = new TypedValue();
      if (!paramTypedArray.getValue(i, typedValue) || typedValue.type != 2) {
        i = paramTypedArray.getDimensionPixelSize(i, -1);
      } else {
        TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(new int[] { typedValue.data });
        i = typedArray.getDimensionPixelSize(0, -1);
        typedArray.recycle();
      } 
      j++;
    } 
    return i;
  }
  
  public final void setTextAppearance(Context paramContext, int paramInt) {
    boolean bool;
    super.setTextAppearance(paramContext, paramInt);
    TypedValue typedValue = 꽃.크(paramContext, 2130904017);
    if (typedValue == null || typedValue.type != 18 || typedValue.data != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      起(paramInt, paramContext.getTheme()); 
  }
  
  public final void 起(int paramInt, Resources.Theme paramTheme) {
    TypedArray typedArray = paramTheme.obtainStyledAttributes(paramInt, 年.壊);
    paramInt = 興(getContext(), typedArray, new int[] { 1, 2 });
    typedArray.recycle();
    if (paramInt >= 0)
      setLineHeight(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\textview\MaterialTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */