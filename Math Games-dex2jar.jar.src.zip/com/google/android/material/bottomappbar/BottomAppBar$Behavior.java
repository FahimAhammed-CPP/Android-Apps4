package com.google.android.material.bottomappbar;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import y.bm;
import y.xj;

public class BottomAppBar$Behavior extends HideBottomViewOnScrollBehavior<Object> {
  public BottomAppBar$Behavior() {
    new xj(1, this);
    new Rect();
  }
  
  public BottomAppBar$Behavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    new xj(1, this);
    new Rect();
  }
  
  public final boolean 寂(View paramView, int paramInt1, int paramInt2) {
    bm.臭(paramView);
    throw null;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    bm.臭(paramView);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\bottomappbar\BottomAppBar$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */