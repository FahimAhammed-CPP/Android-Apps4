package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import y.ik;
import y.lg;
import y.nul;
import y.q3;
import y.rw;
import y.sg;
import y.td;
import y.x2;
import y.属;
import y.年;
import y.皮;
import y.슬;

public class NavigationMenuItemView extends 슬 implements q3 {
  public static final int[] 큰 = new int[] { 16842912 };
  
  public int か;
  
  public boolean ち;
  
  public x2 も;
  
  public boolean ゃ;
  
  public FrameLayout わ;
  
  public ColorStateList 若;
  
  public final CheckedTextView 赤;
  
  public boolean 코;
  
  public Drawable 쾌;
  
  public final 属 크;
  
  public NavigationMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    属 属1 = new 属(3, this);
    this.크 = 属1;
    setOrientation(0);
    LayoutInflater.from(paramContext).inflate(2131427401, (ViewGroup)this, true);
    setIconSize(paramContext.getResources().getDimensionPixelSize(2131099804));
    CheckedTextView checkedTextView = (CheckedTextView)findViewById(2131231011);
    this.赤 = checkedTextView;
    checkedTextView.setDuplicateParentStateEnabled(true);
    rw.帰((View)checkedTextView, (nul)属1);
  }
  
  private void setActionView(View paramView) {
    if (paramView != null) {
      if (this.わ == null)
        this.わ = (FrameLayout)((ViewStub)findViewById(2131231010)).inflate(); 
      this.わ.removeAllViews();
      this.わ.addView(paramView);
    } 
  }
  
  public x2 getItemData() {
    return this.も;
  }
  
  public final int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    x2 x21 = this.も;
    if (x21 != null && x21.isCheckable() && this.も.isChecked())
      View.mergeDrawableStates(arrayOfInt, 큰); 
    return arrayOfInt;
  }
  
  public void setCheckable(boolean paramBoolean) {
    refreshDrawableState();
    if (this.ゃ != paramBoolean) {
      this.ゃ = paramBoolean;
      CheckedTextView checkedTextView = this.赤;
      this.크.旨((View)checkedTextView, 2048);
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    refreshDrawableState();
    this.赤.setChecked(paramBoolean);
  }
  
  public void setHorizontalPadding(int paramInt) {
    setPadding(paramInt, getPaddingTop(), paramInt, getPaddingBottom());
  }
  
  public void setIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      Drawable drawable = paramDrawable;
      if (this.코) {
        Drawable.ConstantState constantState = paramDrawable.getConstantState();
        if (constantState != null)
          paramDrawable = constantState.newDrawable(); 
        drawable = td.帰(paramDrawable).mutate();
        td.興(drawable, this.若);
      } 
      int i = this.か;
      drawable.setBounds(0, 0, i, i);
      paramDrawable = drawable;
    } else if (this.ち) {
      if (this.쾌 == null) {
        Resources resources = getResources();
        Resources.Theme theme = getContext().getTheme();
        ThreadLocal threadLocal = sg.硬;
        int i = Build.VERSION.SDK_INT;
        Drawable drawable = lg.硬(resources, 2131165460, theme);
        this.쾌 = drawable;
        if (drawable != null) {
          i = this.か;
          drawable.setBounds(0, 0, i, i);
        } 
      } 
      paramDrawable = this.쾌;
    } 
    年.か((TextView)this.赤, paramDrawable, null, null, null);
  }
  
  public void setIconPadding(int paramInt) {
    this.赤.setCompoundDrawablePadding(paramInt);
  }
  
  public void setIconSize(int paramInt) {
    this.か = paramInt;
  }
  
  public void setIconTintList(ColorStateList paramColorStateList) {
    boolean bool;
    this.若 = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.코 = bool;
    x2 x21 = this.も;
    if (x21 != null)
      setIcon(x21.getIcon()); 
  }
  
  public void setMaxLines(int paramInt) {
    this.赤.setMaxLines(paramInt);
  }
  
  public void setNeedsEmptyIcon(boolean paramBoolean) {
    this.ち = paramBoolean;
  }
  
  public void setTextAppearance(int paramInt) {
    年.わ((TextView)this.赤, paramInt);
  }
  
  public void setTextColor(ColorStateList paramColorStateList) {
    this.赤.setTextColor(paramColorStateList);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.赤.setText(paramCharSequence);
  }
  
  public final void 熱(x2 paramx2) {
    皮 皮;
    this.も = paramx2;
    int i = paramx2.硬;
    if (i > 0)
      setId(i); 
    if (paramx2.isVisible()) {
      i = 0;
    } else {
      i = 8;
    } 
    setVisibility(i);
    Drawable drawable = getBackground();
    i = 1;
    if (drawable == null) {
      TypedValue typedValue = new TypedValue();
      if (getContext().getTheme().resolveAttribute(2130903268, typedValue, true)) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(큰, (Drawable)new ColorDrawable(typedValue.data));
        stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, (Drawable)new ColorDrawable(0));
      } else {
        drawable = null;
      } 
      rw.歩((View)this, drawable);
    } 
    setCheckable(paramx2.isCheckable());
    setChecked(paramx2.isChecked());
    setEnabled(paramx2.isEnabled());
    setTitle(paramx2.冷);
    setIcon(paramx2.getIcon());
    setActionView(paramx2.getActionView());
    setContentDescription(paramx2.怖);
    ik.태((View)this, paramx2.恐);
    paramx2 = this.も;
    if (paramx2.冷 != null || paramx2.getIcon() != null || this.も.getActionView() == null)
      i = 0; 
    CheckedTextView checkedTextView = this.赤;
    if (i != 0) {
      checkedTextView.setVisibility(8);
      FrameLayout frameLayout = this.わ;
      if (frameLayout != null) {
        皮 = (皮)frameLayout.getLayoutParams();
        ((LinearLayout.LayoutParams)皮).width = -1;
        this.わ.setLayoutParams((ViewGroup.LayoutParams)皮);
        return;
      } 
    } else {
      皮.setVisibility(0);
      FrameLayout frameLayout = this.わ;
      if (frameLayout != null) {
        皮 皮1 = (皮)frameLayout.getLayoutParams();
        ((LinearLayout.LayoutParams)皮1).width = -2;
        this.わ.setLayoutParams((ViewGroup.LayoutParams)皮1);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\internal\NavigationMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */