package com.google.android.material.internal;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import y.pe;
import y.r2;
import y.r3;

public class NavigationMenuView extends RecyclerView implements r3 {
  public NavigationMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    setLayoutManager((pe)new LinearLayoutManager(1));
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public final void 堅(r2 paramr2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\internal\NavigationMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */