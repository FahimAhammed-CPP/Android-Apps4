package com.google.android.material.internal;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Checkable;
import y.for;
import y.nul;
import y.rw;
import y.属;
import y.扉;
import y.決;

public class CheckableImageButton extends 扉 implements Checkable {
  public static final int[] 起 = new int[] { 16842912 };
  
  public boolean 痒 = true;
  
  public boolean 痛;
  
  public boolean 臭 = true;
  
  public CheckableImageButton(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903540);
    rw.帰((View)this, (nul)new 属(2, this));
  }
  
  public final boolean isChecked() {
    return this.痛;
  }
  
  public final int[] onCreateDrawableState(int paramInt) {
    return this.痛 ? View.mergeDrawableStates(super.onCreateDrawableState(paramInt + 1), 起) : super.onCreateDrawableState(paramInt);
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof 決)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    決 決 = (決)paramParcelable;
    super.onRestoreInstanceState(((for)決).淋);
    setChecked(決.恐);
  }
  
  public final Parcelable onSaveInstanceState() {
    決 決 = new 決(super.onSaveInstanceState());
    決.恐 = this.痛;
    return (Parcelable)決;
  }
  
  public void setCheckable(boolean paramBoolean) {
    if (this.痒 != paramBoolean) {
      this.痒 = paramBoolean;
      sendAccessibilityEvent(0);
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    if (this.痒 && this.痛 != paramBoolean) {
      this.痛 = paramBoolean;
      refreshDrawableState();
      sendAccessibilityEvent(2048);
    } 
  }
  
  public void setPressable(boolean paramBoolean) {
    this.臭 = paramBoolean;
  }
  
  public void setPressed(boolean paramBoolean) {
    if (this.臭)
      super.setPressed(paramBoolean); 
  }
  
  public final void toggle() {
    setChecked(this.痛 ^ true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\internal\CheckableImageButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */