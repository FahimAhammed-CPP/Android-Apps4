package com.google.android.material.snackbar;

import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.SwipeDismissBehavior;
import y.bm;
import y.ts;
import y.홀;

public class BaseTransientBottomBar$Behavior extends SwipeDismissBehavior<View> {
  public final 홀 旨 = new 홀(this);
  
  public final boolean 寒(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    홀 홀1 = this.旨;
    홀1.getClass();
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i == 1 || i == 3) {
        if (ts.寒 == null)
          ts.寒 = new ts(11); 
        ts ts = ts.寒;
        bm.悲(홀1.淋);
        synchronized (ts.硬) {
          bm.悲(ts.熱);
        } 
      } 
    } else if (paramCoordinatorLayout.悲(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) {
      if (ts.寒 == null)
        ts.寒 = new ts(11); 
      ts ts = ts.寒;
      bm.悲(홀1.淋);
      ts.起();
    } 
    return super.寒(paramCoordinatorLayout, paramView, paramMotionEvent);
  }
  
  public final boolean 恐(View paramView) {
    this.旨.getClass();
    return paramView instanceof y.在;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\snackbar\BaseTransientBottomBar$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */