package com.google.android.material.snackbar;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.WeakHashMap;
import y.bw;
import y.rw;

public class SnackbarContentLayout extends LinearLayout {
  public Button 怖;
  
  public int 恐;
  
  public TextView 淋;
  
  public SnackbarContentLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public Button getActionView() {
    return this.怖;
  }
  
  public TextView getMessageView() {
    return this.淋;
  }
  
  public final void onFinishInflate() {
    super.onFinishInflate();
    this.淋 = (TextView)findViewById(2131231306);
    this.怖 = (Button)findViewById(2131231305);
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: iload_2
    //   3: invokespecial onMeasure : (II)V
    //   6: aload_0
    //   7: invokevirtual getOrientation : ()I
    //   10: istore_3
    //   11: iconst_1
    //   12: istore #4
    //   14: iload_3
    //   15: iconst_1
    //   16: if_icmpne -> 20
    //   19: return
    //   20: aload_0
    //   21: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   24: ldc 2131099820
    //   26: invokevirtual getDimensionPixelSize : (I)I
    //   29: istore #5
    //   31: aload_0
    //   32: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   35: ldc 2131099819
    //   37: invokevirtual getDimensionPixelSize : (I)I
    //   40: istore #6
    //   42: aload_0
    //   43: getfield 淋 : Landroid/widget/TextView;
    //   46: invokevirtual getLayout : ()Landroid/text/Layout;
    //   49: invokevirtual getLineCount : ()I
    //   52: iconst_1
    //   53: if_icmple -> 61
    //   56: iconst_1
    //   57: istore_3
    //   58: goto -> 63
    //   61: iconst_0
    //   62: istore_3
    //   63: iload_3
    //   64: ifeq -> 109
    //   67: aload_0
    //   68: getfield 恐 : I
    //   71: ifle -> 109
    //   74: aload_0
    //   75: getfield 怖 : Landroid/widget/Button;
    //   78: invokevirtual getMeasuredWidth : ()I
    //   81: aload_0
    //   82: getfield 恐 : I
    //   85: if_icmple -> 109
    //   88: aload_0
    //   89: iconst_1
    //   90: iload #5
    //   92: iload #5
    //   94: iload #6
    //   96: isub
    //   97: invokevirtual 硬 : (III)Z
    //   100: ifeq -> 138
    //   103: iload #4
    //   105: istore_3
    //   106: goto -> 140
    //   109: iload_3
    //   110: ifeq -> 119
    //   113: iload #5
    //   115: istore_3
    //   116: goto -> 122
    //   119: iload #6
    //   121: istore_3
    //   122: aload_0
    //   123: iconst_0
    //   124: iload_3
    //   125: iload_3
    //   126: invokevirtual 硬 : (III)Z
    //   129: ifeq -> 138
    //   132: iload #4
    //   134: istore_3
    //   135: goto -> 140
    //   138: iconst_0
    //   139: istore_3
    //   140: iload_3
    //   141: ifeq -> 150
    //   144: aload_0
    //   145: iload_1
    //   146: iload_2
    //   147: invokespecial onMeasure : (II)V
    //   150: return
  }
  
  public void setMaxInlineActionWidth(int paramInt) {
    this.恐 = paramInt;
  }
  
  public final boolean 硬(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool;
    if (paramInt1 != getOrientation()) {
      setOrientation(paramInt1);
      bool = true;
    } else {
      bool = false;
    } 
    if (this.淋.getPaddingTop() != paramInt2 || this.淋.getPaddingBottom() != paramInt3) {
      TextView textView = this.淋;
      WeakHashMap weakHashMap = rw.硬;
      paramInt1 = Build.VERSION.SDK_INT;
      if (bw.美((View)textView)) {
        rw.寝((View)textView, rw.苦((View)textView), paramInt2, rw.ぱ((View)textView), paramInt3);
        return true;
      } 
      textView.setPadding(textView.getPaddingLeft(), paramInt2, textView.getPaddingRight(), paramInt3);
      return true;
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\snackbar\SnackbarContentLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */