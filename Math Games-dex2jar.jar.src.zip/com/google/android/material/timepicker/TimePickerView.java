package com.google.android.material.timepicker;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;
import java.util.HashMap;
import y.rw;
import y.tr;
import y.최;
import y.추;
import y.춤;

class TimePickerView extends ConstraintLayout {
  public final MaterialButtonToggleGroup 寝;
  
  public TimePickerView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    new new = new new(this);
    LayoutInflater.from(paramContext).inflate(2131427430, (ViewGroup)this);
    ClockFaceView clockFaceView = (ClockFaceView)findViewById(2131231138);
    MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup)findViewById(2131231142);
    this.寝 = materialButtonToggleGroup;
    try try = new try(this);
    materialButtonToggleGroup.恐.add(try);
    Chip chip1 = (Chip)findViewById(2131231147);
    Chip chip2 = (Chip)findViewById(2131231144);
    ClockHandView clockHandView = (ClockHandView)findViewById(2131231139);
    tr tr = new tr(new GestureDetector(getContext(), (GestureDetector.OnGestureListener)new case(this)));
    chip1.setOnTouchListener((View.OnTouchListener)tr);
    chip2.setOnTouchListener((View.OnTouchListener)tr);
    chip1.setTag(2131231294, Integer.valueOf(12));
    chip2.setTag(2131231294, Integer.valueOf(10));
    chip1.setOnClickListener(new);
    chip2.setOnClickListener(new);
    chip1.setAccessibilityClassName("android.view.View");
    chip2.setAccessibilityClassName("android.view.View");
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    嬉();
  }
  
  public final void onVisibilityChanged(View paramView, int paramInt) {
    super.onVisibilityChanged(paramView, paramInt);
    if (paramView == this && paramInt == 0)
      嬉(); 
  }
  
  public final void 嬉() {
    if (this.寝.getVisibility() == 0) {
      춤 춤 = new 춤();
      춤.堅(this);
      int i = rw.不((View)this);
      byte b = 1;
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0)
        b = 2; 
      HashMap hashMap = 춤.熱;
      if (hashMap.containsKey(Integer.valueOf(2131231137))) {
        최 최 = (최)hashMap.get(Integer.valueOf(2131231137));
        if (최 != null) {
          추 추 = 최.暑;
          switch (b) {
            default:
              throw new IllegalArgumentException("unknown constraint");
            case 8:
              추.返 = -1.0F;
              추.帰 = -1;
              추.壊 = -1;
              break;
            case 7:
              추.臭 = -1;
              추.起 = -1;
              추.あ = 0;
              추.若 = Integer.MIN_VALUE;
              break;
            case 6:
              추.痛 = -1;
              추.痒 = -1;
              추.か = 0;
              추.코 = Integer.MIN_VALUE;
              break;
            case 5:
              추.淋 = -1;
              추.怖 = -1;
              추.恐 = -1;
              추.ち = 0;
              추.쾌 = Integer.MIN_VALUE;
              break;
            case 4:
              추.悲 = -1;
              추.寂 = -1;
              추.投 = 0;
              추.も = Integer.MIN_VALUE;
              break;
            case 3:
              추.嬉 = -1;
              추.苦 = -1;
              추.触 = 0;
              추.赤 = Integer.MIN_VALUE;
              break;
            case 2:
              추.ぱ = -1;
              추.辛 = -1;
              추.噛 = -1;
              추.わ = Integer.MIN_VALUE;
              break;
            case 1:
              추.不 = -1;
              추.旨 = -1;
              추.寝 = -1;
              추.ゃ = Integer.MIN_VALUE;
              break;
          } 
        } 
      } 
      춤.硬(this);
      setConstraintSet(null);
      requestLayout();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\TimePickerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */