package com.google.android.material.timepicker;

import android.view.ViewTreeObserver;

public final class if implements ViewTreeObserver.OnPreDrawListener {
  public if(ClockFaceView paramClockFaceView) {}
  
  public final boolean onPreDraw() {
    ClockFaceView clockFaceView = this.淋;
    if (!clockFaceView.isShown())
      return true; 
    clockFaceView.getViewTreeObserver().removeOnPreDrawListener(this);
    int i = clockFaceView.getHeight() / 2 - clockFaceView.投.怖 - clockFaceView.も;
    if (i != clockFaceView.噛) {
      clockFaceView.噛 = i;
      clockFaceView.嬉();
      i = clockFaceView.噛;
      ClockHandView clockHandView = clockFaceView.投;
      clockHandView.死 = i;
      clockHandView.invalidate();
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */