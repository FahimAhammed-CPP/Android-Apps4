package com.google.android.material.timepicker;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import y.nul;
import y.イ;
import y.コ;
import y.賊;
import y.鰹;

public final class for extends nul {
  public for(ClockFaceView paramClockFaceView) {}
  
  public final void 暑(View paramView, コ paramコ) {
    View.AccessibilityDelegate accessibilityDelegate = this.硬;
    AccessibilityNodeInfo accessibilityNodeInfo = paramコ.硬;
    accessibilityDelegate.onInitializeAccessibilityNodeInfo(paramView, accessibilityNodeInfo);
    int i = ((Integer)paramView.getTag(2131231155)).intValue();
    if (i > 0) {
      View view = (View)this.暑.ち.get(i - 1);
      if (Build.VERSION.SDK_INT >= 22)
        鰹.硬(view, accessibilityNodeInfo); 
    } 
    paramコ.旨(賊.起(0, 1, i, 1, paramView.isSelected()));
    accessibilityNodeInfo.setClickable(true);
    paramコ.堅(イ.冷);
  }
  
  public final boolean 美(View paramView, int paramInt, Bundle paramBundle) {
    ClockFaceView clockFaceView;
    if (paramInt == 16) {
      long l = SystemClock.uptimeMillis();
      float f1 = paramView.getX() + paramView.getWidth() / 2.0F;
      float f2 = paramView.getY();
      f2 = paramView.getHeight() / 2.0F + f2;
      clockFaceView = this.暑;
      clockFaceView.投.onTouchEvent(MotionEvent.obtain(l, l, 0, f1, f2, 0));
      clockFaceView.投.onTouchEvent(MotionEvent.obtain(l, l, 1, f1, f2, 0));
      return true;
    } 
    return super.美((View)clockFaceView, paramInt, paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\for.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */