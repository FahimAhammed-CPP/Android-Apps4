package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.TextInputLayout;
import y.鯖;
import y.정;

class ChipTextInputComboView extends FrameLayout implements Checkable {
  public final EditText 怖;
  
  public final Chip 淋;
  
  public ChipTextInputComboView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    LayoutInflater layoutInflater = LayoutInflater.from(paramContext);
    Chip chip = (Chip)layoutInflater.inflate(2131427428, (ViewGroup)this, false);
    this.淋 = chip;
    chip.setAccessibilityClassName("android.view.View");
    TextInputLayout textInputLayout = (TextInputLayout)layoutInflater.inflate(2131427429, (ViewGroup)this, false);
    EditText editText = textInputLayout.getEditText();
    this.怖 = editText;
    editText.setVisibility(4);
    editText.addTextChangedListener((TextWatcher)new do(this));
    if (Build.VERSION.SDK_INT >= 24)
      鯖.臭(editText, 鯖.旨(getContext().getResources().getConfiguration())); 
    addView((View)chip);
    addView((View)textInputLayout);
    TextView textView = (TextView)findViewById(2131231145);
    editText.setSaveEnabled(false);
    editText.setLongClickable(false);
  }
  
  public static String 硬(ChipTextInputComboView paramChipTextInputComboView, CharSequence paramCharSequence) {
    return String.format((paramChipTextInputComboView.getResources().getConfiguration()).locale, "%02d", new Object[] { Integer.valueOf(Integer.parseInt(String.valueOf(paramCharSequence))) });
  }
  
  public final boolean isChecked() {
    return this.淋.isChecked();
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (Build.VERSION.SDK_INT >= 24) {
      LocaleList localeList = 鯖.旨(getContext().getResources().getConfiguration());
      鯖.臭(this.怖, localeList);
    } 
  }
  
  public final void setChecked(boolean paramBoolean) {
    Chip chip = this.淋;
    chip.setChecked(paramBoolean);
    boolean bool = false;
    if (paramBoolean) {
      b = 0;
    } else {
      b = 4;
    } 
    EditText editText = this.怖;
    editText.setVisibility(b);
    byte b = bool;
    if (paramBoolean)
      b = 8; 
    chip.setVisibility(b);
    if (isChecked()) {
      editText.requestFocus();
      editText.post((Runnable)new 정(28, editText));
      if (!TextUtils.isEmpty((CharSequence)editText.getText()))
        editText.setSelection(editText.getText().length()); 
    } 
  }
  
  public final void setOnClickListener(View.OnClickListener paramOnClickListener) {
    this.淋.setOnClickListener(paramOnClickListener);
  }
  
  public final void setTag(int paramInt, Object paramObject) {
    this.淋.setTag(paramInt, paramObject);
  }
  
  public final void toggle() {
    this.淋.toggle();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\ChipTextInputComboView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */