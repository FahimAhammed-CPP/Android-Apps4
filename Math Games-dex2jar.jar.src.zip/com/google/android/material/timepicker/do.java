package com.google.android.material.timepicker;

import android.text.Editable;
import android.text.TextUtils;
import y.lr;

public final class do extends lr {
  public do(ChipTextInputComboView paramChipTextInputComboView) {}
  
  public final void afterTextChanged(Editable paramEditable) {
    boolean bool = TextUtils.isEmpty((CharSequence)paramEditable);
    ChipTextInputComboView chipTextInputComboView = this.淋;
    if (bool) {
      chipTextInputComboView.淋.setText(ChipTextInputComboView.硬(chipTextInputComboView, "00"));
      return;
    } 
    chipTextInputComboView.淋.setText(ChipTextInputComboView.硬(chipTextInputComboView, (CharSequence)paramEditable));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */