package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import java.util.Arrays;
import y.rw;
import y.vd;
import y.年;
import y.知;

class ClockFaceView extends vd implements 知 {
  public final Rect あ = new Rect();
  
  public final RectF か = new RectF();
  
  public final SparseArray ち;
  
  public final int も;
  
  public final for ゃ;
  
  public final float[] わ;
  
  public final ClockHandView 投;
  
  public final int 若;
  
  public final int[] 赤;
  
  public final int 코;
  
  public final int 쾌;
  
  public String[] 크;
  
  public float 큰;
  
  public final ColorStateList 키;
  
  public ClockFaceView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    SparseArray sparseArray = new SparseArray();
    this.ち = sparseArray;
    this.わ = new float[] { 0.0F, 0.9F, 1.0F };
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, 年.苦, 2130903726, 2131756092);
    Resources resources = getResources();
    ColorStateList colorStateList2 = 年.怖(paramContext, typedArray, 1);
    this.키 = colorStateList2;
    LayoutInflater.from(paramContext).inflate(2131427425, (ViewGroup)this, true);
    ClockHandView clockHandView = (ClockHandView)findViewById(2131231139);
    this.投 = clockHandView;
    this.も = resources.getDimensionPixelSize(2131100083);
    int i = colorStateList2.getDefaultColor();
    i = colorStateList2.getColorForState(new int[] { 16842913 }, i);
    this.赤 = new int[] { i, i, colorStateList2.getDefaultColor() };
    clockHandView.淋.add(this);
    i = 年.淋(paramContext, 2131034780).getDefaultColor();
    ColorStateList colorStateList1 = 年.怖(paramContext, typedArray, 0);
    if (colorStateList1 != null)
      i = colorStateList1.getDefaultColor(); 
    setBackgroundColor(i);
    getViewTreeObserver().addOnPreDrawListener(new if(this));
    setFocusable(true);
    typedArray.recycle();
    this.ゃ = new for(this);
    String[] arrayOfString = new String[12];
    Arrays.fill((Object[])arrayOfString, "");
    this.크 = arrayOfString;
    LayoutInflater layoutInflater = LayoutInflater.from(getContext());
    int j = sparseArray.size();
    for (i = 0; i < Math.max(this.크.length, j); i++) {
      TextView textView = (TextView)sparseArray.get(i);
      if (i >= this.크.length) {
        removeView((View)textView);
        sparseArray.remove(i);
      } else {
        TextView textView1 = textView;
        if (textView == null) {
          textView1 = (TextView)layoutInflater.inflate(2131427424, (ViewGroup)this, false);
          sparseArray.put(i, textView1);
          addView((View)textView1);
        } 
        textView1.setVisibility(0);
        textView1.setText(this.크[i]);
        textView1.setTag(2131231155, Integer.valueOf(i));
        rw.帰((View)textView1, this.ゃ);
        textView1.setTextColor(this.키);
      } 
    } 
    this.若 = resources.getDimensionPixelSize(2131100116);
    this.코 = resources.getDimensionPixelSize(2131100117);
    this.쾌 = resources.getDimensionPixelSize(2131100090);
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    int i = this.크.length;
    int j = Build.VERSION.SDK_INT;
    paramAccessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(1, i, false, 1));
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    悲();
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    float f1 = displayMetrics.heightPixels;
    float f2 = displayMetrics.widthPixels;
    paramInt1 = (int)(this.쾌 / Math.max(Math.max(this.若 / f1, this.코 / f2), 1.0F));
    paramInt2 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
    setMeasuredDimension(paramInt1, paramInt1);
    super.onMeasure(paramInt2, paramInt2);
  }
  
  public final void 悲() {
    RectF rectF = this.投.痒;
    int i = 0;
    while (true) {
      SparseArray sparseArray = this.ち;
      if (i < sparseArray.size()) {
        TextView textView = (TextView)sparseArray.get(i);
        if (textView != null) {
          RadialGradient radialGradient;
          Rect rect = this.あ;
          textView.getDrawingRect(rect);
          offsetDescendantRectToMyCoords((View)textView, rect);
          textView.setSelected(rectF.contains(rect.centerX(), rect.centerY()));
          RectF rectF1 = this.か;
          rectF1.set(rect);
          rectF1.offset(textView.getPaddingLeft(), textView.getPaddingTop());
          if (!RectF.intersects(rectF, rectF1)) {
            rect = null;
          } else {
            radialGradient = new RadialGradient(rectF.centerX() - rectF1.left, rectF.centerY() - rectF1.top, 0.5F * rectF.width(), this.赤, this.わ, Shader.TileMode.CLAMP);
          } 
          textView.getPaint().setShader((Shader)radialGradient);
          textView.invalidate();
        } 
        i++;
        continue;
      } 
      break;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\ClockFaceView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */