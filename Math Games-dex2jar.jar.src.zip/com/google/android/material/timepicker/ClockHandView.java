package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.ArrayList;
import y.rw;
import y.年;

class ClockHandView extends View {
  public final int 怖;
  
  public final float 恐;
  
  public int 死;
  
  public final ArrayList 淋 = new ArrayList();
  
  public double 産;
  
  public final RectF 痒;
  
  public final Paint 痛;
  
  public final int 臭;
  
  public boolean 興;
  
  public float 起;
  
  public ClockHandView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903726);
    Paint paint = new Paint();
    this.痛 = paint;
    this.痒 = new RectF();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, 年.嬉, 2130903726, 2131756092);
    this.死 = typedArray.getDimensionPixelSize(1, 0);
    this.怖 = typedArray.getDimensionPixelSize(2, 0);
    Resources resources = getResources();
    this.臭 = resources.getDimensionPixelSize(2131100084);
    this.恐 = resources.getDimensionPixelSize(2131100082);
    int i = typedArray.getColor(0, 0);
    paint.setAntiAlias(true);
    paint.setColor(i);
    硬(0.0F);
    ViewConfiguration.get(paramContext).getScaledTouchSlop();
    rw.踊(this, 2);
    typedArray.recycle();
  }
  
  public final void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    int i = getHeight() / 2;
    int j = getWidth() / 2;
    float f1 = j;
    float f3 = this.死;
    float f4 = (float)Math.cos(this.産);
    float f2 = i;
    float f5 = this.死;
    float f6 = (float)Math.sin(this.産);
    Paint paint = this.痛;
    paint.setStrokeWidth(0.0F);
    int k = this.怖;
    paramCanvas.drawCircle(f3 * f4 + f1, f5 * f6 + f2, k, paint);
    double d1 = Math.sin(this.産);
    double d2 = Math.cos(this.産);
    double d3 = (this.死 - k);
    f3 = (j + (int)(d2 * d3));
    f4 = (i + (int)(d3 * d1));
    paint.setStrokeWidth(this.臭);
    paramCanvas.drawLine(f1, f2, f3, f4, paint);
    paramCanvas.drawCircle(f1, f2, this.恐, paint);
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    硬(this.起);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #6
    //   6: aload_1
    //   7: invokevirtual getX : ()F
    //   10: fstore #4
    //   12: aload_1
    //   13: invokevirtual getY : ()F
    //   16: fstore #5
    //   18: iconst_0
    //   19: istore #8
    //   21: iload #6
    //   23: ifeq -> 56
    //   26: iload #6
    //   28: iconst_1
    //   29: if_icmpeq -> 44
    //   32: iload #6
    //   34: iconst_2
    //   35: if_icmpeq -> 44
    //   38: iconst_0
    //   39: istore #10
    //   41: goto -> 50
    //   44: aload_0
    //   45: getfield 興 : Z
    //   48: istore #10
    //   50: iconst_0
    //   51: istore #6
    //   53: goto -> 67
    //   56: aload_0
    //   57: iconst_0
    //   58: putfield 興 : Z
    //   61: iconst_0
    //   62: istore #10
    //   64: iconst_1
    //   65: istore #6
    //   67: aload_0
    //   68: getfield 興 : Z
    //   71: istore #11
    //   73: aload_0
    //   74: invokevirtual getWidth : ()I
    //   77: iconst_2
    //   78: idiv
    //   79: istore #7
    //   81: aload_0
    //   82: invokevirtual getHeight : ()I
    //   85: iconst_2
    //   86: idiv
    //   87: istore #9
    //   89: fload #4
    //   91: iload #7
    //   93: i2f
    //   94: fsub
    //   95: f2d
    //   96: dstore_2
    //   97: fload #5
    //   99: iload #9
    //   101: i2f
    //   102: fsub
    //   103: f2d
    //   104: dload_2
    //   105: invokestatic atan2 : (DD)D
    //   108: invokestatic toDegrees : (D)D
    //   111: d2i
    //   112: bipush #90
    //   114: iadd
    //   115: istore #9
    //   117: iload #9
    //   119: istore #7
    //   121: iload #9
    //   123: ifge -> 134
    //   126: iload #9
    //   128: sipush #360
    //   131: iadd
    //   132: istore #7
    //   134: aload_0
    //   135: getfield 起 : F
    //   138: fstore #4
    //   140: iload #7
    //   142: i2f
    //   143: fstore #5
    //   145: fload #4
    //   147: fload #5
    //   149: fcmpl
    //   150: ifeq -> 159
    //   153: iconst_1
    //   154: istore #7
    //   156: goto -> 162
    //   159: iconst_0
    //   160: istore #7
    //   162: iload #6
    //   164: ifeq -> 175
    //   167: iload #7
    //   169: ifeq -> 175
    //   172: goto -> 195
    //   175: iload #7
    //   177: ifne -> 189
    //   180: iload #8
    //   182: istore #6
    //   184: iload #10
    //   186: ifeq -> 198
    //   189: aload_0
    //   190: fload #5
    //   192: invokevirtual 硬 : (F)V
    //   195: iconst_1
    //   196: istore #6
    //   198: aload_0
    //   199: iload #11
    //   201: iload #6
    //   203: ior
    //   204: putfield 興 : Z
    //   207: iconst_1
    //   208: ireturn
  }
  
  public final void 堅(float paramFloat) {
    paramFloat %= 360.0F;
    this.起 = paramFloat;
    this.産 = Math.toRadians((paramFloat - 90.0F));
    int i = getHeight() / 2;
    float f1 = (getWidth() / 2);
    f1 = this.死 * (float)Math.cos(this.産) + f1;
    float f2 = i;
    f2 = this.死 * (float)Math.sin(this.産) + f2;
    float f3 = this.怖;
    this.痒.set(f1 - f3, f2 - f3, f1 + f3, f2 + f3);
    for (ClockFaceView clockFaceView : this.淋) {
      if (Math.abs(clockFaceView.큰 - paramFloat) > 0.001F) {
        clockFaceView.큰 = paramFloat;
        clockFaceView.悲();
      } 
    } 
    invalidate();
  }
  
  public final void 硬(float paramFloat) {
    堅(paramFloat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\timepicker\ClockHandView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */