package com.google.android.material.button;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import com.google.android.material.timepicker.try;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;
import y.ba;
import y.bw;
import y.d0;
import y.g0;
import y.ik;
import y.new;
import y.nul;
import y.rw;
import y.t;
import y.td;
import y.vk;
import y.wk;
import y.属;
import y.年;
import y.특;
import y.함;

public class MaterialButtonToggleGroup extends LinearLayout {
  public final 함 怖 = new 함(this);
  
  public final LinkedHashSet 恐 = new LinkedHashSet();
  
  public HashSet 死 = new HashSet();
  
  public final ArrayList 淋 = new ArrayList();
  
  public final int 産;
  
  public Integer[] 痒;
  
  public final ba 痛 = new ba(1, this);
  
  public boolean 臭 = false;
  
  public boolean 興;
  
  public boolean 起;
  
  public MaterialButtonToggleGroup(Context paramContext, AttributeSet paramAttributeSet) {
    super(年.크(paramContext, paramAttributeSet, 2130903705, 2131756033), paramAttributeSet, 2130903705);
    TypedArray typedArray = td.淋(getContext(), paramAttributeSet, 年.痒, 2130903705, 2131756033, new int[0]);
    setSingleSelection(typedArray.getBoolean(2, false));
    this.産 = typedArray.getResourceId(0, -1);
    this.興 = typedArray.getBoolean(1, false);
    setChildrenDrawingOrderEnabled(true);
    typedArray.recycle();
    rw.踊((View)this, 1);
  }
  
  private int getFirstVisibleChildIndex() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      if (暑(i))
        return i; 
    } 
    return -1;
  }
  
  private int getLastVisibleChildIndex() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      if (暑(i))
        return i; 
    } 
    return -1;
  }
  
  private int getVisibleButtonCount() {
    int i = 0;
    int j;
    for (j = 0; i < getChildCount(); j = k) {
      int k = j;
      if (getChildAt(i) instanceof MaterialButton) {
        k = j;
        if (暑(i))
          k = j + 1; 
      } 
      i++;
    } 
    return j;
  }
  
  private void setGeneratedIdIfNeeded(MaterialButton paramMaterialButton) {
    if (paramMaterialButton.getId() == -1) {
      WeakHashMap weakHashMap = rw.硬;
      int i = Build.VERSION.SDK_INT;
      paramMaterialButton.setId(bw.硬());
    } 
  }
  
  private void setupButtonChild(MaterialButton paramMaterialButton) {
    paramMaterialButton.setMaxLines(1);
    paramMaterialButton.setEllipsize(TextUtils.TruncateAt.END);
    paramMaterialButton.setCheckable(true);
    paramMaterialButton.setOnPressedChangeListenerInternal((d0)this.怖);
    paramMaterialButton.setShouldDrawSurfaceColorStroke(true);
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (!(paramView instanceof MaterialButton))
      return; 
    super.addView(paramView, paramInt, paramLayoutParams);
    MaterialButton materialButton = (MaterialButton)paramView;
    setGeneratedIdIfNeeded(materialButton);
    setupButtonChild(materialButton);
    堅(materialButton.getId(), materialButton.isChecked());
    wk wk = materialButton.getShapeAppearanceModel();
    ArrayList<g0> arrayList = this.淋;
    특 특1 = wk.冷;
    특 특2 = wk.寒;
    특 특3 = wk.美;
    arrayList.add(new g0(특1, wk.旨, 특2, 특3));
    rw.帰((View)materialButton, (nul)new 属(1, this));
  }
  
  public final void dispatchDraw(Canvas paramCanvas) {
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>((Comparator<?>)this.痛);
    int j = getChildCount();
    for (int i = 0; i < j; i++)
      treeMap.put(熱(i), Integer.valueOf(i)); 
    this.痒 = (Integer[])treeMap.values().toArray((Object[])new Integer[0]);
    super.dispatchDraw(paramCanvas);
  }
  
  public int getCheckedButtonId() {
    return (this.起 && !this.死.isEmpty()) ? ((Integer)this.死.iterator().next()).intValue() : -1;
  }
  
  public List<Integer> getCheckedButtonIds() {
    ArrayList<Integer> arrayList = new ArrayList();
    for (int i = 0; i < getChildCount(); i++) {
      int j = 熱(i).getId();
      if (this.死.contains(Integer.valueOf(j)))
        arrayList.add(Integer.valueOf(j)); 
    } 
    return arrayList;
  }
  
  public final int getChildDrawingOrder(int paramInt1, int paramInt2) {
    Integer[] arrayOfInteger = this.痒;
    return (arrayOfInteger != null) ? ((paramInt2 >= arrayOfInteger.length) ? paramInt2 : arrayOfInteger[paramInt2].intValue()) : paramInt2;
  }
  
  public final void onFinishInflate() {
    super.onFinishInflate();
    int i = this.産;
    if (i != -1)
      冷(Collections.singleton(Integer.valueOf(i))); 
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    byte b;
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    int i = getVisibleButtonCount();
    if (this.起) {
      b = 1;
    } else {
      b = 2;
    } 
    int j = Build.VERSION.SDK_INT;
    paramAccessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(1, i, false, b));
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    寒();
    硬();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public final void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    if (paramView instanceof MaterialButton)
      ((MaterialButton)paramView).setOnPressedChangeListenerInternal(null); 
    int i = indexOfChild(paramView);
    if (i >= 0)
      this.淋.remove(i); 
    寒();
    硬();
  }
  
  public void setSelectionRequired(boolean paramBoolean) {
    this.興 = paramBoolean;
  }
  
  public void setSingleSelection(int paramInt) {
    setSingleSelection(getResources().getBoolean(paramInt));
  }
  
  public void setSingleSelection(boolean paramBoolean) {
    if (this.起 != paramBoolean) {
      this.起 = paramBoolean;
      冷(new HashSet());
    } 
  }
  
  public final void 冷(Set<?> paramSet) {
    HashSet hashSet = this.死;
    this.死 = new HashSet(paramSet);
    for (int i = 0; i < getChildCount(); i++) {
      int j = 熱(i).getId();
      boolean bool = paramSet.contains(Integer.valueOf(j));
      View view = findViewById(j);
      if (view instanceof MaterialButton) {
        this.臭 = true;
        ((MaterialButton)view).setChecked(bool);
        this.臭 = false;
      } 
      if (hashSet.contains(Integer.valueOf(j)) != paramSet.contains(Integer.valueOf(j))) {
        paramSet.contains(Integer.valueOf(j));
        Iterator<try> iterator = this.恐.iterator();
        while (iterator.hasNext())
          ((try)iterator.next()).硬(); 
      } 
    } 
    invalidate();
  }
  
  public final void 堅(int paramInt, boolean paramBoolean) {
    if (paramInt == -1)
      return; 
    HashSet<Integer> hashSet = new HashSet(this.死);
    if (paramBoolean && !hashSet.contains(Integer.valueOf(paramInt))) {
      if (this.起 && !hashSet.isEmpty())
        hashSet.clear(); 
      hashSet.add(Integer.valueOf(paramInt));
    } else if (!paramBoolean && hashSet.contains(Integer.valueOf(paramInt))) {
      if (!this.興 || hashSet.size() > 1)
        hashSet.remove(Integer.valueOf(paramInt)); 
    } else {
      return;
    } 
    冷(hashSet);
  }
  
  public final void 寒() {
    int j = getChildCount();
    int k = getFirstVisibleChildIndex();
    int m = getLastVisibleChildIndex();
    for (int i = 0; i < j; i++) {
      MaterialButton materialButton = 熱(i);
      if (materialButton.getVisibility() != 8) {
        wk wk = materialButton.getShapeAppearanceModel();
        wk.getClass();
        vk vk = new vk(wk);
        g0 g0 = this.淋.get(i);
        if (k != m) {
          boolean bool;
          if (getOrientation() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          new new = g0.冷;
          if (i == k) {
            if (bool) {
              if (ik.ゃ((View)this)) {
                g0 = new g0((특)new, (특)new, g0.堅, g0.熱);
              } else {
                g0 = new g0(g0.硬, g0.暑, (특)new, (특)new);
              } 
            } else {
              g0 = new g0(g0.硬, (특)new, g0.堅, (특)new);
            } 
          } else if (i == m) {
            if (bool) {
              if (ik.ゃ((View)this)) {
                g0 = new g0(g0.硬, g0.暑, (특)new, (특)new);
              } else {
                g0 = new g0((특)new, (특)new, g0.堅, g0.熱);
              } 
            } else {
              g0 = new g0((특)new, g0.暑, (특)new, g0.熱);
            } 
          } else {
            g0 = null;
          } 
        } 
        if (g0 == null) {
          vk.冷 = new new(0.0F);
          vk.寒 = new new(0.0F);
          vk.美 = new new(0.0F);
          vk.旨 = new new(0.0F);
        } else {
          vk.冷 = g0.硬;
          vk.旨 = g0.暑;
          vk.寒 = g0.堅;
          vk.美 = g0.熱;
        } 
        materialButton.setShapeAppearanceModel(new wk(vk));
      } 
    } 
  }
  
  public final boolean 暑(int paramInt) {
    return (getChildAt(paramInt).getVisibility() != 8);
  }
  
  public final MaterialButton 熱(int paramInt) {
    return (MaterialButton)getChildAt(paramInt);
  }
  
  public final void 硬() {
    int j = getFirstVisibleChildIndex();
    if (j == -1)
      return; 
    int i;
    for (i = j + 1; i < getChildCount(); i++) {
      LinearLayout.LayoutParams layoutParams;
      MaterialButton materialButton2 = 熱(i);
      MaterialButton materialButton1 = 熱(i - 1);
      int k = Math.min(materialButton2.getStrokeWidth(), materialButton1.getStrokeWidth());
      ViewGroup.LayoutParams layoutParams1 = materialButton2.getLayoutParams();
      if (layoutParams1 instanceof LinearLayout.LayoutParams) {
        layoutParams = (LinearLayout.LayoutParams)layoutParams1;
      } else {
        layoutParams = new LinearLayout.LayoutParams(((ViewGroup.LayoutParams)layoutParams).width, ((ViewGroup.LayoutParams)layoutParams).height);
      } 
      if (getOrientation() == 0) {
        int m = Build.VERSION.SDK_INT;
        t.美((ViewGroup.MarginLayoutParams)layoutParams, 0);
        ik.탕((ViewGroup.MarginLayoutParams)layoutParams, -k);
        layoutParams.topMargin = 0;
      } else {
        layoutParams.bottomMargin = 0;
        layoutParams.topMargin = -k;
        ik.탕((ViewGroup.MarginLayoutParams)layoutParams, 0);
      } 
      materialButton2.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (getChildCount() != 0) {
      if (j == -1)
        return; 
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)熱(j).getLayoutParams();
      if (getOrientation() == 1) {
        layoutParams.topMargin = 0;
        layoutParams.bottomMargin = 0;
        return;
      } 
      i = Build.VERSION.SDK_INT;
      t.美((ViewGroup.MarginLayoutParams)layoutParams, 0);
      ik.탕((ViewGroup.MarginLayoutParams)layoutParams, 0);
      layoutParams.leftMargin = 0;
      layoutParams.rightMargin = 0;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\button\MaterialButtonToggleGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */