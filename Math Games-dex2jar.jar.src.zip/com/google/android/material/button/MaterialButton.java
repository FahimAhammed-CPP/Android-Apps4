package com.google.android.material.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import y.bm;
import y.d0;
import y.e0;
import y.f0;
import y.fh;
import y.for;
import y.gh;
import y.hl;
import y.ik;
import y.new;
import y.rw;
import y.td;
import y.vk;
import y.wk;
import y.グ;
import y.年;
import y.함;

public class MaterialButton extends グ implements Checkable, hl {
  public static final int[] 噛;
  
  public static final int[] 寝 = new int[] { 16842911 };
  
  public int 壊;
  
  public int 帰;
  
  public boolean 歩;
  
  public int 死;
  
  public boolean 泳;
  
  public Drawable 産;
  
  public final LinkedHashSet 痒 = new LinkedHashSet();
  
  public final f0 痛;
  
  public d0 臭;
  
  public ColorStateList 興;
  
  public PorterDuff.Mode 起;
  
  public int 踊;
  
  public int 返;
  
  static {
    噛 = new int[] { 16842912 };
  }
  
  public MaterialButton(Context paramContext, AttributeSet paramAttributeSet) {
    super(年.크(paramContext, paramAttributeSet, 2130903704, 2131756001), paramAttributeSet, 2130903704);
    boolean bool = false;
    this.歩 = false;
    this.泳 = false;
    Context context = getContext();
    TypedArray typedArray = td.淋(context, paramAttributeSet, 年.痛, 2130903704, 2131756001, new int[0]);
    this.返 = typedArray.getDimensionPixelSize(12, 0);
    this.起 = ik.큰(typedArray.getInt(15, -1), PorterDuff.Mode.SRC_IN);
    this.興 = 年.怖(getContext(), typedArray, 14);
    this.産 = 年.痒(getContext(), typedArray, 10);
    this.踊 = typedArray.getInteger(11, 1);
    this.死 = typedArray.getDimensionPixelSize(13, 0);
    f0 f01 = new f0(this, new wk(wk.堅(context, paramAttributeSet, 2130903704, 2131756001)));
    this.痛 = f01;
    f01.熱 = typedArray.getDimensionPixelOffset(1, 0);
    f01.暑 = typedArray.getDimensionPixelOffset(2, 0);
    f01.冷 = typedArray.getDimensionPixelOffset(3, 0);
    f01.寒 = typedArray.getDimensionPixelOffset(4, 0);
    if (typedArray.hasValue(8)) {
      int n = typedArray.getDimensionPixelSize(8, -1);
      f01.美 = n;
      wk wk = f01.堅;
      float f = n;
      wk.getClass();
      vk vk = new vk(wk);
      vk.冷 = new new(f);
      vk.寒 = new new(f);
      vk.美 = new new(f);
      vk.旨 = new new(f);
      f01.熱(new wk(vk));
      f01.淋 = true;
    } 
    f01.旨 = typedArray.getDimensionPixelSize(20, 0);
    f01.不 = ik.큰(typedArray.getInt(7, -1), PorterDuff.Mode.SRC_IN);
    f01.辛 = 年.怖(getContext(), typedArray, 6);
    f01.ぱ = 年.怖(getContext(), typedArray, 19);
    f01.苦 = 年.怖(getContext(), typedArray, 16);
    f01.怖 = typedArray.getBoolean(5, false);
    f01.痛 = typedArray.getDimensionPixelSize(9, 0);
    int i = rw.苦((View)this);
    int j = getPaddingTop();
    int k = rw.ぱ((View)this);
    int m = getPaddingBottom();
    if (typedArray.hasValue(0)) {
      f01.寂 = true;
      setSupportBackgroundTintList(f01.辛);
      setSupportBackgroundTintMode(f01.不);
    } else {
      f01.冷();
    } 
    rw.寝((View)this, i + f01.熱, j + f01.冷, k + f01.暑, m + f01.寒);
    typedArray.recycle();
    setCompoundDrawablePadding(this.返);
    if (this.産 != null)
      bool = true; 
    熱(bool);
  }
  
  private String getA11yClassName() {
    boolean bool;
    Class<Button> clazz;
    f0 f01 = this.痛;
    if (f01 != null && f01.怖) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      Class<CompoundButton> clazz1 = CompoundButton.class;
    } else {
      clazz = Button.class;
    } 
    return clazz.getName();
  }
  
  private Layout.Alignment getActualTextAlignment() {
    int i = Build.VERSION.SDK_INT;
    i = getTextAlignment();
    return (i != 1) ? ((i != 6 && i != 3) ? ((i != 4) ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER) : Layout.Alignment.ALIGN_OPPOSITE) : getGravityTextAlignment();
  }
  
  private Layout.Alignment getGravityTextAlignment() {
    int i = getGravity() & 0x800007;
    return (i != 1) ? ((i != 5 && i != 8388613) ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_OPPOSITE) : Layout.Alignment.ALIGN_CENTER;
  }
  
  private int getTextHeight() {
    TextPaint textPaint = getPaint();
    String str2 = getText().toString();
    String str1 = str2;
    if (getTransformationMethod() != null)
      str1 = getTransformationMethod().getTransformation(str2, (View)this).toString(); 
    Rect rect = new Rect();
    textPaint.getTextBounds(str1, 0, str1.length(), rect);
    return Math.min(rect.height(), getLayout().getHeight());
  }
  
  private int getTextWidth() {
    TextPaint textPaint = getPaint();
    String str2 = getText().toString();
    String str1 = str2;
    if (getTransformationMethod() != null)
      str1 = getTransformationMethod().getTransformation(str2, (View)this).toString(); 
    return Math.min((int)textPaint.measureText(str1), getLayout().getEllipsizedWidth());
  }
  
  public ColorStateList getBackgroundTintList() {
    return getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getBackgroundTintMode() {
    return getSupportBackgroundTintMode();
  }
  
  public int getCornerRadius() {
    return 硬() ? this.痛.美 : 0;
  }
  
  public Drawable getIcon() {
    return this.産;
  }
  
  public int getIconGravity() {
    return this.踊;
  }
  
  public int getIconPadding() {
    return this.返;
  }
  
  public int getIconSize() {
    return this.死;
  }
  
  public ColorStateList getIconTint() {
    return this.興;
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.起;
  }
  
  public int getInsetBottom() {
    return this.痛.寒;
  }
  
  public int getInsetTop() {
    return this.痛.冷;
  }
  
  public ColorStateList getRippleColor() {
    return 硬() ? this.痛.苦 : null;
  }
  
  public wk getShapeAppearanceModel() {
    if (硬())
      return this.痛.堅; 
    throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
  }
  
  public ColorStateList getStrokeColor() {
    return 硬() ? this.痛.ぱ : null;
  }
  
  public int getStrokeWidth() {
    return 硬() ? this.痛.旨 : 0;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    return 硬() ? this.痛.辛 : super.getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    return 硬() ? this.痛.不 : super.getSupportBackgroundTintMode();
  }
  
  public final boolean isChecked() {
    return this.歩;
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (硬())
      年.赤((View)this, this.痛.堅(false)); 
  }
  
  public final int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 2);
    f0 f01 = this.痛;
    if (f01 != null && f01.怖) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt != 0)
      View.mergeDrawableStates(arrayOfInt, 寝); 
    if (isChecked())
      View.mergeDrawableStates(arrayOfInt, 噛); 
    return arrayOfInt;
  }
  
  public final void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(getA11yClassName());
    paramAccessibilityEvent.setChecked(isChecked());
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    boolean bool;
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(getA11yClassName());
    f0 f01 = this.痛;
    if (f01 != null && f01.怖) {
      bool = true;
    } else {
      bool = false;
    } 
    paramAccessibilityNodeInfo.setCheckable(bool);
    paramAccessibilityNodeInfo.setChecked(isChecked());
    paramAccessibilityNodeInfo.setClickable(isClickable());
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (Build.VERSION.SDK_INT == 21) {
      f0 f01 = this.痛;
      if (f01 != null) {
        Drawable drawable = f01.嬉;
        if (drawable != null)
          drawable.setBounds(f01.熱, f01.冷, paramInt3 - paramInt1 - f01.暑, paramInt4 - paramInt2 - f01.寒); 
      } 
    } 
    暑(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof e0)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    e0 e0 = (e0)paramParcelable;
    super.onRestoreInstanceState(((for)e0).淋);
    setChecked(e0.恐);
  }
  
  public final Parcelable onSaveInstanceState() {
    e0 e0 = new e0(super.onSaveInstanceState());
    e0.恐 = this.歩;
    return (Parcelable)e0;
  }
  
  public final void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    暑(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public final boolean performClick() {
    toggle();
    return super.performClick();
  }
  
  public final void refreshDrawableState() {
    super.refreshDrawableState();
    if (this.産 != null) {
      int[] arrayOfInt = getDrawableState();
      if (this.産.setState(arrayOfInt))
        invalidate(); 
    } 
  }
  
  public void setBackground(Drawable paramDrawable) {
    setBackgroundDrawable(paramDrawable);
  }
  
  public void setBackgroundColor(int paramInt) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.堅(false) != null) {
        f01.堅(false).setTint(paramInt);
        return;
      } 
    } else {
      super.setBackgroundColor(paramInt);
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    if (硬()) {
      if (paramDrawable != getBackground()) {
        f0 f01 = this.痛;
        f01.寂 = true;
        ColorStateList colorStateList = f01.辛;
        MaterialButton materialButton = f01.硬;
        materialButton.setSupportBackgroundTintList(colorStateList);
        materialButton.setSupportBackgroundTintMode(f01.不);
        super.setBackgroundDrawable(paramDrawable);
        return;
      } 
      getBackground().setState(paramDrawable.getState());
      return;
    } 
    super.setBackgroundDrawable(paramDrawable);
  }
  
  public void setBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setBackgroundDrawable(drawable);
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList) {
    setSupportBackgroundTintList(paramColorStateList);
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode) {
    setSupportBackgroundTintMode(paramMode);
  }
  
  public void setCheckable(boolean paramBoolean) {
    if (硬())
      this.痛.怖 = paramBoolean; 
  }
  
  public void setChecked(boolean paramBoolean) {
    boolean bool;
    f0 f01 = this.痛;
    if (f01 != null && f01.怖) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && isEnabled() && this.歩 != paramBoolean) {
      this.歩 = paramBoolean;
      refreshDrawableState();
      if (getParent() instanceof MaterialButtonToggleGroup) {
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup)getParent();
        paramBoolean = this.歩;
        if (!materialButtonToggleGroup.臭)
          materialButtonToggleGroup.堅(getId(), paramBoolean); 
      } 
      if (this.泳)
        return; 
      this.泳 = true;
      Iterator iterator = this.痒.iterator();
      if (!iterator.hasNext()) {
        this.泳 = false;
        return;
      } 
      bm.悲(iterator.next());
      throw null;
    } 
  }
  
  public void setCornerRadius(int paramInt) {
    if (硬()) {
      f0 f01 = this.痛;
      if (!f01.淋 || f01.美 != paramInt) {
        f01.美 = paramInt;
        f01.淋 = true;
        wk wk = f01.堅;
        float f = paramInt;
        wk.getClass();
        vk vk = new vk(wk);
        vk.冷 = new new(f);
        vk.寒 = new new(f);
        vk.美 = new new(f);
        vk.旨 = new new(f);
        f01.熱(new wk(vk));
      } 
    } 
  }
  
  public void setCornerRadiusResource(int paramInt) {
    if (硬())
      setCornerRadius(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    if (硬())
      this.痛.堅(false).不(paramFloat); 
  }
  
  public void setIcon(Drawable paramDrawable) {
    if (this.産 != paramDrawable) {
      this.産 = paramDrawable;
      熱(true);
      暑(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void setIconGravity(int paramInt) {
    if (this.踊 != paramInt) {
      this.踊 = paramInt;
      暑(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void setIconPadding(int paramInt) {
    if (this.返 != paramInt) {
      this.返 = paramInt;
      setCompoundDrawablePadding(paramInt);
    } 
  }
  
  public void setIconResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIconSize(int paramInt) {
    if (paramInt >= 0) {
      if (this.死 != paramInt) {
        this.死 = paramInt;
        熱(true);
      } 
      return;
    } 
    throw new IllegalArgumentException("iconSize cannot be less than 0");
  }
  
  public void setIconTint(ColorStateList paramColorStateList) {
    if (this.興 != paramColorStateList) {
      this.興 = paramColorStateList;
      熱(false);
    } 
  }
  
  public void setIconTintMode(PorterDuff.Mode paramMode) {
    if (this.起 != paramMode) {
      this.起 = paramMode;
      熱(false);
    } 
  }
  
  public void setIconTintResource(int paramInt) {
    setIconTint(年.淋(getContext(), paramInt));
  }
  
  public void setInsetBottom(int paramInt) {
    f0 f01 = this.痛;
    f01.暑(f01.冷, paramInt);
  }
  
  public void setInsetTop(int paramInt) {
    f0 f01 = this.痛;
    f01.暑(paramInt, f01.寒);
  }
  
  public void setInternalBackground(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
  }
  
  public void setOnPressedChangeListenerInternal(d0 paramd0) {
    this.臭 = paramd0;
  }
  
  public void setPressed(boolean paramBoolean) {
    d0 d01 = this.臭;
    if (d01 != null)
      ((MaterialButtonToggleGroup)((함)d01).怖).invalidate(); 
    super.setPressed(paramBoolean);
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.苦 != paramColorStateList) {
        f01.苦 = paramColorStateList;
        boolean bool = f0.痒;
        MaterialButton materialButton = f01.硬;
        if (bool && materialButton.getBackground() instanceof RippleDrawable) {
          ((RippleDrawable)materialButton.getBackground()).setColor(gh.硬(paramColorStateList));
          return;
        } 
        if (!bool && materialButton.getBackground() instanceof fh)
          ((fh)materialButton.getBackground()).setTintList(gh.硬(paramColorStateList)); 
      } 
    } 
  }
  
  public void setRippleColorResource(int paramInt) {
    if (硬())
      setRippleColor(年.淋(getContext(), paramInt)); 
  }
  
  public void setShapeAppearanceModel(wk paramwk) {
    if (硬()) {
      this.痛.熱(paramwk);
      return;
    } 
    throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
  }
  
  public void setShouldDrawSurfaceColorStroke(boolean paramBoolean) {
    if (硬()) {
      f0 f01 = this.痛;
      f01.悲 = paramBoolean;
      f01.寒();
    } 
  }
  
  public void setStrokeColor(ColorStateList paramColorStateList) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.ぱ != paramColorStateList) {
        f01.ぱ = paramColorStateList;
        f01.寒();
      } 
    } 
  }
  
  public void setStrokeColorResource(int paramInt) {
    if (硬())
      setStrokeColor(年.淋(getContext(), paramInt)); 
  }
  
  public void setStrokeWidth(int paramInt) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.旨 != paramInt) {
        f01.旨 = paramInt;
        f01.寒();
      } 
    } 
  }
  
  public void setStrokeWidthResource(int paramInt) {
    if (硬())
      setStrokeWidth(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.辛 != paramColorStateList) {
        f01.辛 = paramColorStateList;
        if (f01.堅(false) != null) {
          td.興((Drawable)f01.堅(false), f01.辛);
          return;
        } 
      } 
    } else {
      super.setSupportBackgroundTintList(paramColorStateList);
    } 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    if (硬()) {
      f0 f01 = this.痛;
      if (f01.不 != paramMode) {
        f01.不 = paramMode;
        if (f01.堅(false) != null && f01.不 != null) {
          td.産((Drawable)f01.堅(false), f01.不);
          return;
        } 
      } 
    } else {
      super.setSupportBackgroundTintMode(paramMode);
    } 
  }
  
  public void setTextAlignment(int paramInt) {
    super.setTextAlignment(paramInt);
    暑(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public final void toggle() {
    setChecked(this.歩 ^ true);
  }
  
  public final void 堅() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 踊 : I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: iconst_1
    //   9: if_icmpeq -> 25
    //   12: iload_3
    //   13: iconst_2
    //   14: if_icmpne -> 20
    //   17: goto -> 25
    //   20: iconst_0
    //   21: istore_1
    //   22: goto -> 27
    //   25: iconst_1
    //   26: istore_1
    //   27: iload_1
    //   28: ifeq -> 43
    //   31: aload_0
    //   32: aload_0
    //   33: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   36: aconst_null
    //   37: aconst_null
    //   38: aconst_null
    //   39: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   42: return
    //   43: iload_3
    //   44: iconst_3
    //   45: if_icmpeq -> 61
    //   48: iload_3
    //   49: iconst_4
    //   50: if_icmpne -> 56
    //   53: goto -> 61
    //   56: iconst_0
    //   57: istore_1
    //   58: goto -> 63
    //   61: iconst_1
    //   62: istore_1
    //   63: iload_1
    //   64: ifeq -> 79
    //   67: aload_0
    //   68: aconst_null
    //   69: aconst_null
    //   70: aload_0
    //   71: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   74: aconst_null
    //   75: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   78: return
    //   79: iload_3
    //   80: bipush #16
    //   82: if_icmpeq -> 93
    //   85: iload_2
    //   86: istore_1
    //   87: iload_3
    //   88: bipush #32
    //   90: if_icmpne -> 95
    //   93: iconst_1
    //   94: istore_1
    //   95: iload_1
    //   96: ifeq -> 110
    //   99: aload_0
    //   100: aconst_null
    //   101: aload_0
    //   102: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   105: aconst_null
    //   106: aconst_null
    //   107: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   110: return
  }
  
  public final void 暑(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   4: ifnull -> 384
    //   7: aload_0
    //   8: invokevirtual getLayout : ()Landroid/text/Layout;
    //   11: ifnonnull -> 15
    //   14: return
    //   15: aload_0
    //   16: getfield 踊 : I
    //   19: istore #6
    //   21: iconst_1
    //   22: istore #4
    //   24: iconst_1
    //   25: istore #5
    //   27: iload #6
    //   29: iconst_1
    //   30: if_icmpeq -> 47
    //   33: iload #6
    //   35: iconst_2
    //   36: if_icmpne -> 42
    //   39: goto -> 47
    //   42: iconst_0
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_1
    //   48: istore_3
    //   49: iload_3
    //   50: ifne -> 198
    //   53: iload #6
    //   55: iconst_3
    //   56: if_icmpeq -> 73
    //   59: iload #6
    //   61: iconst_4
    //   62: if_icmpne -> 68
    //   65: goto -> 73
    //   68: iconst_0
    //   69: istore_3
    //   70: goto -> 75
    //   73: iconst_1
    //   74: istore_3
    //   75: iload_3
    //   76: ifeq -> 82
    //   79: goto -> 198
    //   82: iload #5
    //   84: istore_1
    //   85: iload #6
    //   87: bipush #16
    //   89: if_icmpeq -> 107
    //   92: iload #6
    //   94: bipush #32
    //   96: if_icmpne -> 105
    //   99: iload #5
    //   101: istore_1
    //   102: goto -> 107
    //   105: iconst_0
    //   106: istore_1
    //   107: iload_1
    //   108: ifeq -> 373
    //   111: aload_0
    //   112: iconst_0
    //   113: putfield 壊 : I
    //   116: iload #6
    //   118: bipush #16
    //   120: if_icmpne -> 134
    //   123: aload_0
    //   124: iconst_0
    //   125: putfield 帰 : I
    //   128: aload_0
    //   129: iconst_0
    //   130: invokevirtual 熱 : (Z)V
    //   133: return
    //   134: aload_0
    //   135: getfield 死 : I
    //   138: istore_3
    //   139: iload_3
    //   140: istore_1
    //   141: iload_3
    //   142: ifne -> 153
    //   145: aload_0
    //   146: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   149: invokevirtual getIntrinsicHeight : ()I
    //   152: istore_1
    //   153: iload_2
    //   154: aload_0
    //   155: invokespecial getTextHeight : ()I
    //   158: isub
    //   159: aload_0
    //   160: invokevirtual getPaddingTop : ()I
    //   163: isub
    //   164: iload_1
    //   165: isub
    //   166: aload_0
    //   167: getfield 返 : I
    //   170: isub
    //   171: aload_0
    //   172: invokevirtual getPaddingBottom : ()I
    //   175: isub
    //   176: iconst_2
    //   177: idiv
    //   178: istore_1
    //   179: aload_0
    //   180: getfield 帰 : I
    //   183: iload_1
    //   184: if_icmpeq -> 373
    //   187: aload_0
    //   188: iload_1
    //   189: putfield 帰 : I
    //   192: aload_0
    //   193: iconst_0
    //   194: invokevirtual 熱 : (Z)V
    //   197: return
    //   198: aload_0
    //   199: iconst_0
    //   200: putfield 帰 : I
    //   203: aload_0
    //   204: invokespecial getActualTextAlignment : ()Landroid/text/Layout$Alignment;
    //   207: astore #7
    //   209: aload_0
    //   210: getfield 踊 : I
    //   213: istore_2
    //   214: iload_2
    //   215: iconst_1
    //   216: if_icmpeq -> 374
    //   219: iload_2
    //   220: iconst_3
    //   221: if_icmpeq -> 374
    //   224: iload_2
    //   225: iconst_2
    //   226: if_icmpne -> 237
    //   229: aload #7
    //   231: getstatic android/text/Layout$Alignment.ALIGN_NORMAL : Landroid/text/Layout$Alignment;
    //   234: if_acmpeq -> 374
    //   237: iload_2
    //   238: iconst_4
    //   239: if_icmpne -> 253
    //   242: aload #7
    //   244: getstatic android/text/Layout$Alignment.ALIGN_OPPOSITE : Landroid/text/Layout$Alignment;
    //   247: if_acmpne -> 253
    //   250: goto -> 374
    //   253: aload_0
    //   254: getfield 死 : I
    //   257: istore_3
    //   258: iload_3
    //   259: istore_2
    //   260: iload_3
    //   261: ifne -> 272
    //   264: aload_0
    //   265: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   268: invokevirtual getIntrinsicWidth : ()I
    //   271: istore_2
    //   272: iload_1
    //   273: aload_0
    //   274: invokespecial getTextWidth : ()I
    //   277: isub
    //   278: aload_0
    //   279: invokestatic ぱ : (Landroid/view/View;)I
    //   282: isub
    //   283: iload_2
    //   284: isub
    //   285: aload_0
    //   286: getfield 返 : I
    //   289: isub
    //   290: aload_0
    //   291: invokestatic 苦 : (Landroid/view/View;)I
    //   294: isub
    //   295: istore_2
    //   296: iload_2
    //   297: istore_1
    //   298: aload #7
    //   300: getstatic android/text/Layout$Alignment.ALIGN_CENTER : Landroid/text/Layout$Alignment;
    //   303: if_acmpne -> 310
    //   306: iload_2
    //   307: iconst_2
    //   308: idiv
    //   309: istore_1
    //   310: aload_0
    //   311: invokestatic 不 : (Landroid/view/View;)I
    //   314: iconst_1
    //   315: if_icmpne -> 323
    //   318: iconst_1
    //   319: istore_2
    //   320: goto -> 325
    //   323: iconst_0
    //   324: istore_2
    //   325: aload_0
    //   326: getfield 踊 : I
    //   329: iconst_4
    //   330: if_icmpne -> 339
    //   333: iload #4
    //   335: istore_3
    //   336: goto -> 341
    //   339: iconst_0
    //   340: istore_3
    //   341: iload_1
    //   342: istore #4
    //   344: iload_2
    //   345: iload_3
    //   346: if_icmpeq -> 353
    //   349: iload_1
    //   350: ineg
    //   351: istore #4
    //   353: aload_0
    //   354: getfield 壊 : I
    //   357: iload #4
    //   359: if_icmpeq -> 373
    //   362: aload_0
    //   363: iload #4
    //   365: putfield 壊 : I
    //   368: aload_0
    //   369: iconst_0
    //   370: invokevirtual 熱 : (Z)V
    //   373: return
    //   374: aload_0
    //   375: iconst_0
    //   376: putfield 壊 : I
    //   379: aload_0
    //   380: iconst_0
    //   381: invokevirtual 熱 : (Z)V
    //   384: return
  }
  
  public final void 熱(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   4: astore #7
    //   6: iconst_1
    //   7: istore #4
    //   9: aload #7
    //   11: ifnull -> 144
    //   14: aload #7
    //   16: invokestatic 帰 : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   19: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   22: astore #7
    //   24: aload_0
    //   25: aload #7
    //   27: putfield 産 : Landroid/graphics/drawable/Drawable;
    //   30: aload #7
    //   32: aload_0
    //   33: getfield 興 : Landroid/content/res/ColorStateList;
    //   36: invokestatic 興 : (Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V
    //   39: aload_0
    //   40: getfield 起 : Landroid/graphics/PorterDuff$Mode;
    //   43: astore #7
    //   45: aload #7
    //   47: ifnull -> 59
    //   50: aload_0
    //   51: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   54: aload #7
    //   56: invokestatic 産 : (Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V
    //   59: aload_0
    //   60: getfield 死 : I
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 71
    //   68: goto -> 79
    //   71: aload_0
    //   72: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   75: invokevirtual getIntrinsicWidth : ()I
    //   78: istore_2
    //   79: aload_0
    //   80: getfield 死 : I
    //   83: istore_3
    //   84: iload_3
    //   85: ifeq -> 91
    //   88: goto -> 99
    //   91: aload_0
    //   92: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   95: invokevirtual getIntrinsicHeight : ()I
    //   98: istore_3
    //   99: aload_0
    //   100: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   103: astore #7
    //   105: aload_0
    //   106: getfield 壊 : I
    //   109: istore #5
    //   111: aload_0
    //   112: getfield 帰 : I
    //   115: istore #6
    //   117: aload #7
    //   119: iload #5
    //   121: iload #6
    //   123: iload_2
    //   124: iload #5
    //   126: iadd
    //   127: iload_3
    //   128: iload #6
    //   130: iadd
    //   131: invokevirtual setBounds : (IIII)V
    //   134: aload_0
    //   135: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   138: iconst_1
    //   139: iload_1
    //   140: invokevirtual setVisible : (ZZ)Z
    //   143: pop
    //   144: iload_1
    //   145: ifeq -> 153
    //   148: aload_0
    //   149: invokevirtual 堅 : ()V
    //   152: return
    //   153: getstatic android/os/Build$VERSION.SDK_INT : I
    //   156: istore_2
    //   157: aload_0
    //   158: invokestatic 硬 : (Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    //   161: astore #9
    //   163: aload #9
    //   165: iconst_0
    //   166: aaload
    //   167: astore #7
    //   169: aload #9
    //   171: iconst_1
    //   172: aaload
    //   173: astore #8
    //   175: aload #9
    //   177: iconst_2
    //   178: aaload
    //   179: astore #9
    //   181: aload_0
    //   182: getfield 踊 : I
    //   185: istore_3
    //   186: iload_3
    //   187: iconst_1
    //   188: if_icmpeq -> 204
    //   191: iload_3
    //   192: iconst_2
    //   193: if_icmpne -> 199
    //   196: goto -> 204
    //   199: iconst_0
    //   200: istore_2
    //   201: goto -> 206
    //   204: iconst_1
    //   205: istore_2
    //   206: iload_2
    //   207: ifeq -> 222
    //   210: iload #4
    //   212: istore_2
    //   213: aload #7
    //   215: aload_0
    //   216: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   219: if_acmpne -> 301
    //   222: iload_3
    //   223: iconst_3
    //   224: if_icmpeq -> 240
    //   227: iload_3
    //   228: iconst_4
    //   229: if_icmpne -> 235
    //   232: goto -> 240
    //   235: iconst_0
    //   236: istore_2
    //   237: goto -> 242
    //   240: iconst_1
    //   241: istore_2
    //   242: iload_2
    //   243: ifeq -> 258
    //   246: iload #4
    //   248: istore_2
    //   249: aload #9
    //   251: aload_0
    //   252: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   255: if_acmpne -> 301
    //   258: iload_3
    //   259: bipush #16
    //   261: if_icmpeq -> 278
    //   264: iload_3
    //   265: bipush #32
    //   267: if_icmpne -> 273
    //   270: goto -> 278
    //   273: iconst_0
    //   274: istore_2
    //   275: goto -> 280
    //   278: iconst_1
    //   279: istore_2
    //   280: iload_2
    //   281: ifeq -> 299
    //   284: aload #8
    //   286: aload_0
    //   287: getfield 産 : Landroid/graphics/drawable/Drawable;
    //   290: if_acmpeq -> 299
    //   293: iload #4
    //   295: istore_2
    //   296: goto -> 301
    //   299: iconst_0
    //   300: istore_2
    //   301: iload_2
    //   302: ifeq -> 309
    //   305: aload_0
    //   306: invokevirtual 堅 : ()V
    //   309: return
  }
  
  public final boolean 硬() {
    f0 f01 = this.痛;
    return (f01 != null && !f01.寂);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\button\MaterialButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */