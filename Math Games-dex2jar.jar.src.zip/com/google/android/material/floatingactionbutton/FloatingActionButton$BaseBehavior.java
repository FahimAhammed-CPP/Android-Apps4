package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import y.bm;
import y.年;
import y.톨;
import y.투;

public class FloatingActionButton$BaseBehavior<T> extends 톨 {
  public FloatingActionButton$BaseBehavior() {}
  
  public FloatingActionButton$BaseBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(0);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, 年.寂);
    typedArray.getBoolean(0, true);
    typedArray.recycle();
  }
  
  public final boolean 暑(View paramView1, View paramView2) {
    bm.臭(paramView1);
    throw null;
  }
  
  public final void 熱(투 param투) {
    if (param투.旨 == 0)
      param투.旨 = 80; 
  }
  
  public final boolean 硬(View paramView) {
    bm.臭(paramView);
    throw null;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    bm.臭(paramView);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\floatingactionbutton\FloatingActionButton$BaseBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */