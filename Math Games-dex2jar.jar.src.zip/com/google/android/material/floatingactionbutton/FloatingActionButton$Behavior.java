package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.util.AttributeSet;

public class FloatingActionButton$Behavior extends FloatingActionButton$BaseBehavior<Object> {
  public FloatingActionButton$Behavior() {}
  
  public FloatingActionButton$Behavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\floatingactionbutton\FloatingActionButton$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */