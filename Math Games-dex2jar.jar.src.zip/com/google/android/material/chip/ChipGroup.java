package com.google.android.material.chip;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import y.p0;
import y.rw;
import y.t41;
import y.td;
import y.取;
import y.年;
import y.採;
import y.撮;
import y.畳;
import y.置;
import y.세;
import y.홀;

public class ChipGroup extends 세 {
  public final 置 死;
  
  public final int 産;
  
  public int 痒;
  
  public int 臭;
  
  public final t41 興;
  
  public 採 起;
  
  public ChipGroup(Context paramContext, AttributeSet paramAttributeSet) {
    super(年.크(paramContext, paramAttributeSet, 2130903212, 2131756019), paramAttributeSet);
    t41 t411 = new t41(2);
    this.興 = t411;
    置 置1 = new 置(this);
    this.死 = 置1;
    TypedArray typedArray = td.淋(getContext(), paramAttributeSet, 年.ぱ, 2130903212, 2131756019, new int[0]);
    int i = typedArray.getDimensionPixelOffset(1, 0);
    setChipSpacingHorizontal(typedArray.getDimensionPixelOffset(2, i));
    setChipSpacingVertical(typedArray.getDimensionPixelOffset(3, i));
    setSingleLine(typedArray.getBoolean(5, false));
    setSingleSelection(typedArray.getBoolean(6, false));
    setSelectionRequired(typedArray.getBoolean(4, false));
    this.産 = typedArray.getResourceId(0, -1);
    typedArray.recycle();
    t411.痒 = new 홀(this);
    super.setOnHierarchyChangeListener((ViewGroup.OnHierarchyChangeListener)置1);
    rw.踊((View)this, 1);
  }
  
  private int getChipCount() {
    int i = 0;
    int j;
    for (j = 0; i < getChildCount(); j = k) {
      int k = j;
      if (getChildAt(i) instanceof Chip)
        k = j + 1; 
      i++;
    } 
    return j;
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof 取);
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new 取();
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new 取(getContext(), paramAttributeSet);
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new 取(paramLayoutParams);
  }
  
  public int getCheckedChipId() {
    return this.興.熱();
  }
  
  public List<Integer> getCheckedChipIds() {
    return this.興.堅((ViewGroup)this);
  }
  
  public int getChipSpacingHorizontal() {
    return this.痒;
  }
  
  public int getChipSpacingVertical() {
    return this.臭;
  }
  
  public final void onFinishInflate() {
    super.onFinishInflate();
    int i = this.産;
    if (i != -1) {
      t41 t411 = this.興;
      p0 p0 = (p0)((Map)t411.痛).get(Integer.valueOf(i));
      if (p0 == null)
        return; 
      if (t411.硬(p0))
        t411.暑(); 
    } 
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    byte b;
    byte b1;
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    if (this.恐) {
      b = getChipCount();
    } else {
      b = -1;
    } 
    int i = getRowCount();
    if (this.興.淋) {
      b1 = 1;
    } else {
      b1 = 2;
    } 
    int j = Build.VERSION.SDK_INT;
    paramAccessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(i, b, false, b1));
  }
  
  public void setChipSpacing(int paramInt) {
    setChipSpacingHorizontal(paramInt);
    setChipSpacingVertical(paramInt);
  }
  
  public void setChipSpacingHorizontal(int paramInt) {
    if (this.痒 != paramInt) {
      this.痒 = paramInt;
      setItemSpacing(paramInt);
      requestLayout();
    } 
  }
  
  public void setChipSpacingHorizontalResource(int paramInt) {
    setChipSpacingHorizontal(getResources().getDimensionPixelOffset(paramInt));
  }
  
  public void setChipSpacingResource(int paramInt) {
    setChipSpacing(getResources().getDimensionPixelOffset(paramInt));
  }
  
  public void setChipSpacingVertical(int paramInt) {
    if (this.臭 != paramInt) {
      this.臭 = paramInt;
      setLineSpacing(paramInt);
      requestLayout();
    } 
  }
  
  public void setChipSpacingVerticalResource(int paramInt) {
    setChipSpacingVertical(getResources().getDimensionPixelOffset(paramInt));
  }
  
  @Deprecated
  public void setDividerDrawableHorizontal(Drawable paramDrawable) {
    throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
  }
  
  @Deprecated
  public void setDividerDrawableVertical(Drawable paramDrawable) {
    throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
  }
  
  @Deprecated
  public void setFlexWrap(int paramInt) {
    throw new UnsupportedOperationException("Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead.");
  }
  
  @Deprecated
  public void setOnCheckedChangeListener(撮 param撮) {
    if (param撮 == null) {
      setOnCheckedStateChangeListener(null);
      return;
    } 
    setOnCheckedStateChangeListener((採)new 畳(this, param撮, 28));
  }
  
  public void setOnCheckedStateChangeListener(採 param採) {
    this.起 = param採;
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.死.淋 = paramOnHierarchyChangeListener;
  }
  
  public void setSelectionRequired(boolean paramBoolean) {
    this.興.怖 = paramBoolean;
  }
  
  @Deprecated
  public void setShowDividerHorizontal(int paramInt) {
    throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
  }
  
  @Deprecated
  public void setShowDividerVertical(int paramInt) {
    throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
  }
  
  public void setSingleLine(int paramInt) {
    setSingleLine(getResources().getBoolean(paramInt));
  }
  
  public void setSingleLine(boolean paramBoolean) {
    super.setSingleLine(paramBoolean);
  }
  
  public void setSingleSelection(int paramInt) {
    setSingleSelection(getResources().getBoolean(paramInt));
  }
  
  public void setSingleSelection(boolean paramBoolean) {
    t41 t411 = this.興;
    if (t411.淋 != paramBoolean) {
      t411.淋 = paramBoolean;
      paramBoolean = ((Set)t411.恐).isEmpty();
      Iterator<p0> iterator = ((Map)t411.痛).values().iterator();
      while (iterator.hasNext())
        t411.冷(iterator.next(), false); 
      if ((paramBoolean ^ true) != 0)
        t411.暑(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\chip\ChipGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */