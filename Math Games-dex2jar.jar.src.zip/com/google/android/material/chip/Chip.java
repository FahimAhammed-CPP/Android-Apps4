package com.google.android.material.chip;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Locale;
import y.cr;
import y.dr;
import y.gh;
import y.hl;
import y.j4;
import y.nul;
import y.o0;
import y.p0;
import y.qq;
import y.rw;
import y.t10;
import y.td;
import y.u0;
import y.wk;
import y.セ;
import y.使;
import y.創;
import y.安;
import y.年;
import y.捨;
import y.直;
import y.鯖;

public class Chip extends セ implements 直, hl, p0 {
  public static final Rect ゃ = new Rect();
  
  public static final int[] わ;
  
  public static final int[] 赤 = new int[] { 16842913 };
  
  public final Rect あ;
  
  public final RectF か;
  
  public final 使 ち;
  
  public CharSequence 噛;
  
  public boolean 壊;
  
  public int 寝;
  
  public boolean 帰;
  
  public boolean 投;
  
  public boolean 歩;
  
  public o0 死;
  
  public boolean 泳;
  
  public CompoundButton.OnCheckedChangeListener 産;
  
  public 捨 痒;
  
  public InsetDrawable 臭;
  
  public View.OnClickListener 興;
  
  public final 創 触;
  
  public RippleDrawable 起;
  
  public int 踊;
  
  public boolean 返;
  
  static {
    わ = new int[] { 16842911 };
  }
  
  public Chip(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130903227
    //   5: ldc 2131756015
    //   7: invokestatic 크 : (Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;
    //   10: aload_2
    //   11: ldc 2130903227
    //   13: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   16: aload_0
    //   17: new android/graphics/Rect
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: putfield あ : Landroid/graphics/Rect;
    //   27: aload_0
    //   28: new android/graphics/RectF
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield か : Landroid/graphics/RectF;
    //   38: aload_0
    //   39: new y/使
    //   42: dup
    //   43: iconst_0
    //   44: aload_0
    //   45: invokespecial <init> : (ILjava/lang/Object;)V
    //   48: putfield ち : Ly/使;
    //   51: aload_0
    //   52: invokevirtual getContext : ()Landroid/content/Context;
    //   55: astore #8
    //   57: aload_2
    //   58: ifnonnull -> 64
    //   61: goto -> 199
    //   64: aload_2
    //   65: ldc 'http://schemas.android.com/apk/res/android'
    //   67: ldc 'background'
    //   69: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   74: pop
    //   75: aload_2
    //   76: ldc 'http://schemas.android.com/apk/res/android'
    //   78: ldc 'drawableLeft'
    //   80: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   85: ifnonnull -> 1559
    //   88: aload_2
    //   89: ldc 'http://schemas.android.com/apk/res/android'
    //   91: ldc 'drawableStart'
    //   93: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   98: ifnonnull -> 1548
    //   101: aload_2
    //   102: ldc 'http://schemas.android.com/apk/res/android'
    //   104: ldc 'drawableEnd'
    //   106: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   111: ifnonnull -> 1537
    //   114: aload_2
    //   115: ldc 'http://schemas.android.com/apk/res/android'
    //   117: ldc 'drawableRight'
    //   119: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   124: ifnonnull -> 1526
    //   127: aload_2
    //   128: ldc 'http://schemas.android.com/apk/res/android'
    //   130: ldc 'singleLine'
    //   132: iconst_1
    //   133: invokeinterface getAttributeBooleanValue : (Ljava/lang/String;Ljava/lang/String;Z)Z
    //   138: ifeq -> 1515
    //   141: aload_2
    //   142: ldc 'http://schemas.android.com/apk/res/android'
    //   144: ldc 'lines'
    //   146: iconst_1
    //   147: invokeinterface getAttributeIntValue : (Ljava/lang/String;Ljava/lang/String;I)I
    //   152: iconst_1
    //   153: if_icmpne -> 1515
    //   156: aload_2
    //   157: ldc 'http://schemas.android.com/apk/res/android'
    //   159: ldc 'minLines'
    //   161: iconst_1
    //   162: invokeinterface getAttributeIntValue : (Ljava/lang/String;Ljava/lang/String;I)I
    //   167: iconst_1
    //   168: if_icmpne -> 1515
    //   171: aload_2
    //   172: ldc 'http://schemas.android.com/apk/res/android'
    //   174: ldc 'maxLines'
    //   176: iconst_1
    //   177: invokeinterface getAttributeIntValue : (Ljava/lang/String;Ljava/lang/String;I)I
    //   182: iconst_1
    //   183: if_icmpne -> 1515
    //   186: aload_2
    //   187: ldc 'http://schemas.android.com/apk/res/android'
    //   189: ldc 'gravity'
    //   191: ldc 8388627
    //   193: invokeinterface getAttributeIntValue : (Ljava/lang/String;Ljava/lang/String;I)I
    //   198: pop
    //   199: new y/捨
    //   202: dup
    //   203: aload #8
    //   205: aload_2
    //   206: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   209: astore #9
    //   211: aload #9
    //   213: getfield 私 : Landroid/content/Context;
    //   216: astore_1
    //   217: getstatic y/年.辛 : [I
    //   220: astore #10
    //   222: aload_1
    //   223: aload_2
    //   224: aload #10
    //   226: ldc 2130903227
    //   228: ldc 2131756015
    //   230: iconst_0
    //   231: newarray int
    //   233: invokestatic 淋 : (Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;
    //   236: astore #11
    //   238: aload #9
    //   240: aload #11
    //   242: bipush #37
    //   244: invokevirtual hasValue : (I)Z
    //   247: putfield 士 : Z
    //   250: aload #9
    //   252: getfield 私 : Landroid/content/Context;
    //   255: astore #12
    //   257: aload #12
    //   259: aload #11
    //   261: bipush #24
    //   263: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   266: astore_1
    //   267: aload #9
    //   269: getfield ゃ : Landroid/content/res/ColorStateList;
    //   272: aload_1
    //   273: if_acmpeq -> 293
    //   276: aload #9
    //   278: aload_1
    //   279: putfield ゃ : Landroid/content/res/ColorStateList;
    //   282: aload #9
    //   284: aload #9
    //   286: invokevirtual getState : ()[I
    //   289: invokevirtual onStateChange : ([I)Z
    //   292: pop
    //   293: aload #12
    //   295: aload #11
    //   297: bipush #11
    //   299: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   302: astore_1
    //   303: aload #9
    //   305: getfield 赤 : Landroid/content/res/ColorStateList;
    //   308: aload_1
    //   309: if_acmpeq -> 329
    //   312: aload #9
    //   314: aload_1
    //   315: putfield 赤 : Landroid/content/res/ColorStateList;
    //   318: aload #9
    //   320: aload #9
    //   322: invokevirtual getState : ()[I
    //   325: invokevirtual onStateChange : ([I)Z
    //   328: pop
    //   329: aload #11
    //   331: bipush #19
    //   333: fconst_0
    //   334: invokevirtual getDimension : (IF)F
    //   337: fstore_3
    //   338: aload #9
    //   340: getfield わ : F
    //   343: fload_3
    //   344: fcmpl
    //   345: ifeq -> 364
    //   348: aload #9
    //   350: fload_3
    //   351: putfield わ : F
    //   354: aload #9
    //   356: invokevirtual invalidateSelf : ()V
    //   359: aload #9
    //   361: invokevirtual 臭 : ()V
    //   364: aload #11
    //   366: bipush #12
    //   368: invokevirtual hasValue : (I)Z
    //   371: ifeq -> 387
    //   374: aload #9
    //   376: aload #11
    //   378: bipush #12
    //   380: fconst_0
    //   381: invokevirtual getDimension : (IF)F
    //   384: invokevirtual 帰 : (F)V
    //   387: aload #9
    //   389: aload #12
    //   391: aload #11
    //   393: bipush #22
    //   395: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   398: invokevirtual 寝 : (Landroid/content/res/ColorStateList;)V
    //   401: aload #9
    //   403: aload #11
    //   405: bipush #23
    //   407: fconst_0
    //   408: invokevirtual getDimension : (IF)F
    //   411: invokevirtual 噛 : (F)V
    //   414: aload #9
    //   416: aload #12
    //   418: aload #11
    //   420: bipush #36
    //   422: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   425: invokevirtual も : (Landroid/content/res/ColorStateList;)V
    //   428: aload #11
    //   430: iconst_5
    //   431: invokevirtual getText : (I)Ljava/lang/CharSequence;
    //   434: astore #7
    //   436: aload #7
    //   438: astore_1
    //   439: aload #7
    //   441: ifnonnull -> 447
    //   444: ldc ''
    //   446: astore_1
    //   447: aload #9
    //   449: getfield 크 : Ljava/lang/CharSequence;
    //   452: aload_1
    //   453: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   456: ifne -> 484
    //   459: aload #9
    //   461: aload_1
    //   462: putfield 크 : Ljava/lang/CharSequence;
    //   465: aload #9
    //   467: getfield ょ : Ly/wq;
    //   470: iconst_1
    //   471: putfield 暑 : Z
    //   474: aload #9
    //   476: invokevirtual invalidateSelf : ()V
    //   479: aload #9
    //   481: invokevirtual 臭 : ()V
    //   484: aload #11
    //   486: iconst_0
    //   487: invokevirtual hasValue : (I)Z
    //   490: ifeq -> 522
    //   493: aload #11
    //   495: iconst_0
    //   496: iconst_0
    //   497: invokevirtual getResourceId : (II)I
    //   500: istore #4
    //   502: iload #4
    //   504: ifeq -> 522
    //   507: new y/qq
    //   510: dup
    //   511: aload #12
    //   513: iload #4
    //   515: invokespecial <init> : (Landroid/content/Context;I)V
    //   518: astore_1
    //   519: goto -> 524
    //   522: aconst_null
    //   523: astore_1
    //   524: aload_1
    //   525: aload #11
    //   527: iconst_1
    //   528: aload_1
    //   529: getfield ぱ : F
    //   532: invokevirtual getDimension : (IF)F
    //   535: putfield ぱ : F
    //   538: getstatic android/os/Build$VERSION.SDK_INT : I
    //   541: istore #4
    //   543: iload #4
    //   545: bipush #23
    //   547: if_icmpge -> 562
    //   550: aload_1
    //   551: aload #12
    //   553: aload #11
    //   555: iconst_2
    //   556: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   559: putfield 辛 : Landroid/content/res/ColorStateList;
    //   562: aload #9
    //   564: aload_1
    //   565: invokevirtual 若 : (Ly/qq;)V
    //   568: aload #11
    //   570: iconst_3
    //   571: iconst_0
    //   572: invokevirtual getInt : (II)I
    //   575: istore #5
    //   577: iload #5
    //   579: iconst_1
    //   580: if_icmpeq -> 620
    //   583: iload #5
    //   585: iconst_2
    //   586: if_icmpeq -> 609
    //   589: iload #5
    //   591: iconst_3
    //   592: if_icmpeq -> 598
    //   595: goto -> 628
    //   598: aload #9
    //   600: getstatic android/text/TextUtils$TruncateAt.END : Landroid/text/TextUtils$TruncateAt;
    //   603: putfield 家 : Landroid/text/TextUtils$TruncateAt;
    //   606: goto -> 628
    //   609: aload #9
    //   611: getstatic android/text/TextUtils$TruncateAt.MIDDLE : Landroid/text/TextUtils$TruncateAt;
    //   614: putfield 家 : Landroid/text/TextUtils$TruncateAt;
    //   617: goto -> 628
    //   620: aload #9
    //   622: getstatic android/text/TextUtils$TruncateAt.START : Landroid/text/TextUtils$TruncateAt;
    //   625: putfield 家 : Landroid/text/TextUtils$TruncateAt;
    //   628: aload #9
    //   630: aload #11
    //   632: bipush #18
    //   634: iconst_0
    //   635: invokevirtual getBoolean : (IZ)Z
    //   638: invokevirtual 踊 : (Z)V
    //   641: aload_2
    //   642: ifnull -> 688
    //   645: aload_2
    //   646: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   649: ldc_w 'chipIconEnabled'
    //   652: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   657: ifnull -> 688
    //   660: aload_2
    //   661: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   664: ldc_w 'chipIconVisible'
    //   667: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   672: ifnonnull -> 688
    //   675: aload #9
    //   677: aload #11
    //   679: bipush #15
    //   681: iconst_0
    //   682: invokevirtual getBoolean : (IZ)Z
    //   685: invokevirtual 踊 : (Z)V
    //   688: aload #9
    //   690: aload #12
    //   692: aload #11
    //   694: bipush #14
    //   696: invokestatic 痒 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;
    //   699: invokevirtual 返 : (Landroid/graphics/drawable/Drawable;)V
    //   702: aload #11
    //   704: bipush #17
    //   706: invokevirtual hasValue : (I)Z
    //   709: ifeq -> 726
    //   712: aload #9
    //   714: aload #12
    //   716: aload #11
    //   718: bipush #17
    //   720: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   723: invokevirtual 泳 : (Landroid/content/res/ColorStateList;)V
    //   726: aload #9
    //   728: aload #11
    //   730: bipush #16
    //   732: ldc_w -1.0
    //   735: invokevirtual getDimension : (IF)F
    //   738: invokevirtual 歩 : (F)V
    //   741: aload #9
    //   743: aload #11
    //   745: bipush #31
    //   747: iconst_0
    //   748: invokevirtual getBoolean : (IZ)Z
    //   751: invokevirtual ゃ : (Z)V
    //   754: aload_2
    //   755: ifnull -> 801
    //   758: aload_2
    //   759: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   762: ldc_w 'closeIconEnabled'
    //   765: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   770: ifnull -> 801
    //   773: aload_2
    //   774: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   777: ldc_w 'closeIconVisible'
    //   780: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   785: ifnonnull -> 801
    //   788: aload #9
    //   790: aload #11
    //   792: bipush #26
    //   794: iconst_0
    //   795: invokevirtual getBoolean : (IZ)Z
    //   798: invokevirtual ゃ : (Z)V
    //   801: aload #9
    //   803: aload #12
    //   805: aload #11
    //   807: bipush #25
    //   809: invokestatic 痒 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;
    //   812: invokevirtual 触 : (Landroid/graphics/drawable/Drawable;)V
    //   815: aload #9
    //   817: aload #12
    //   819: aload #11
    //   821: bipush #30
    //   823: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   826: invokevirtual ち : (Landroid/content/res/ColorStateList;)V
    //   829: aload #9
    //   831: aload #11
    //   833: bipush #28
    //   835: fconst_0
    //   836: invokevirtual getDimension : (IF)F
    //   839: invokevirtual あ : (F)V
    //   842: aload #9
    //   844: aload #11
    //   846: bipush #6
    //   848: iconst_0
    //   849: invokevirtual getBoolean : (IZ)Z
    //   852: invokevirtual 興 : (Z)V
    //   855: aload #9
    //   857: aload #11
    //   859: bipush #10
    //   861: iconst_0
    //   862: invokevirtual getBoolean : (IZ)Z
    //   865: invokevirtual 壊 : (Z)V
    //   868: aload_2
    //   869: ifnull -> 915
    //   872: aload_2
    //   873: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   876: ldc_w 'checkedIconEnabled'
    //   879: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   884: ifnull -> 915
    //   887: aload_2
    //   888: ldc_w 'http://schemas.android.com/apk/res-auto'
    //   891: ldc_w 'checkedIconVisible'
    //   894: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   899: ifnonnull -> 915
    //   902: aload #9
    //   904: aload #11
    //   906: bipush #8
    //   908: iconst_0
    //   909: invokevirtual getBoolean : (IZ)Z
    //   912: invokevirtual 壊 : (Z)V
    //   915: aload #9
    //   917: aload #12
    //   919: aload #11
    //   921: bipush #7
    //   923: invokestatic 痒 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;
    //   926: invokevirtual 産 : (Landroid/graphics/drawable/Drawable;)V
    //   929: aload #11
    //   931: bipush #9
    //   933: invokevirtual hasValue : (I)Z
    //   936: ifeq -> 953
    //   939: aload #9
    //   941: aload #12
    //   943: aload #11
    //   945: bipush #9
    //   947: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   950: invokevirtual 死 : (Landroid/content/res/ColorStateList;)V
    //   953: aload #11
    //   955: bipush #39
    //   957: invokevirtual hasValue : (I)Z
    //   960: ifeq -> 989
    //   963: aload #11
    //   965: bipush #39
    //   967: iconst_0
    //   968: invokevirtual getResourceId : (II)I
    //   971: istore #5
    //   973: iload #5
    //   975: ifeq -> 989
    //   978: aload #12
    //   980: iload #5
    //   982: invokestatic 硬 : (Landroid/content/Context;I)Ly/j4;
    //   985: astore_1
    //   986: goto -> 991
    //   989: aconst_null
    //   990: astore_1
    //   991: aload #9
    //   993: aload_1
    //   994: putfield 토 : Ly/j4;
    //   997: aload #11
    //   999: bipush #33
    //   1001: invokevirtual hasValue : (I)Z
    //   1004: ifeq -> 1033
    //   1007: aload #11
    //   1009: bipush #33
    //   1011: iconst_0
    //   1012: invokevirtual getResourceId : (II)I
    //   1015: istore #5
    //   1017: iload #5
    //   1019: ifeq -> 1033
    //   1022: aload #12
    //   1024: iload #5
    //   1026: invokestatic 硬 : (Landroid/content/Context;I)Ly/j4;
    //   1029: astore_1
    //   1030: goto -> 1035
    //   1033: aconst_null
    //   1034: astore_1
    //   1035: aload #9
    //   1037: aload_1
    //   1038: putfield 톤 : Ly/j4;
    //   1041: aload #11
    //   1043: bipush #21
    //   1045: fconst_0
    //   1046: invokevirtual getDimension : (IF)F
    //   1049: fstore_3
    //   1050: aload #9
    //   1052: getfield 톨 : F
    //   1055: fload_3
    //   1056: fcmpl
    //   1057: ifeq -> 1076
    //   1060: aload #9
    //   1062: fload_3
    //   1063: putfield 톨 : F
    //   1066: aload #9
    //   1068: invokevirtual invalidateSelf : ()V
    //   1071: aload #9
    //   1073: invokevirtual 臭 : ()V
    //   1076: aload #9
    //   1078: aload #11
    //   1080: bipush #35
    //   1082: fconst_0
    //   1083: invokevirtual getDimension : (IF)F
    //   1086: invokevirtual わ : (F)V
    //   1089: aload #9
    //   1091: aload #11
    //   1093: bipush #34
    //   1095: fconst_0
    //   1096: invokevirtual getDimension : (IF)F
    //   1099: invokevirtual 赤 : (F)V
    //   1102: aload #11
    //   1104: bipush #41
    //   1106: fconst_0
    //   1107: invokevirtual getDimension : (IF)F
    //   1110: fstore_3
    //   1111: aload #9
    //   1113: getfield 투 : F
    //   1116: fload_3
    //   1117: fcmpl
    //   1118: ifeq -> 1137
    //   1121: aload #9
    //   1123: fload_3
    //   1124: putfield 투 : F
    //   1127: aload #9
    //   1129: invokevirtual invalidateSelf : ()V
    //   1132: aload #9
    //   1134: invokevirtual 臭 : ()V
    //   1137: aload #11
    //   1139: bipush #40
    //   1141: fconst_0
    //   1142: invokevirtual getDimension : (IF)F
    //   1145: fstore_3
    //   1146: aload #9
    //   1148: getfield 퉁 : F
    //   1151: fload_3
    //   1152: fcmpl
    //   1153: ifeq -> 1172
    //   1156: aload #9
    //   1158: fload_3
    //   1159: putfield 퉁 : F
    //   1162: aload #9
    //   1164: invokevirtual invalidateSelf : ()V
    //   1167: aload #9
    //   1169: invokevirtual 臭 : ()V
    //   1172: aload #9
    //   1174: aload #11
    //   1176: bipush #29
    //   1178: fconst_0
    //   1179: invokevirtual getDimension : (IF)F
    //   1182: invokevirtual か : (F)V
    //   1185: aload #9
    //   1187: aload #11
    //   1189: bipush #27
    //   1191: fconst_0
    //   1192: invokevirtual getDimension : (IF)F
    //   1195: invokevirtual 投 : (F)V
    //   1198: aload #11
    //   1200: bipush #13
    //   1202: fconst_0
    //   1203: invokevirtual getDimension : (IF)F
    //   1206: fstore_3
    //   1207: aload #9
    //   1209: getfield し : F
    //   1212: fload_3
    //   1213: fcmpl
    //   1214: ifeq -> 1233
    //   1217: aload #9
    //   1219: fload_3
    //   1220: putfield し : F
    //   1223: aload #9
    //   1225: invokevirtual invalidateSelf : ()V
    //   1228: aload #9
    //   1230: invokevirtual 臭 : ()V
    //   1233: aload #9
    //   1235: aload #11
    //   1237: iconst_4
    //   1238: ldc_w 2147483647
    //   1241: invokevirtual getDimensionPixelSize : (II)I
    //   1244: putfield 弁 : I
    //   1247: aload #11
    //   1249: invokevirtual recycle : ()V
    //   1252: aload #8
    //   1254: aload_2
    //   1255: aload #10
    //   1257: ldc 2130903227
    //   1259: ldc 2131756015
    //   1261: iconst_0
    //   1262: newarray int
    //   1264: invokestatic 淋 : (Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;
    //   1267: astore_1
    //   1268: aload_0
    //   1269: aload_1
    //   1270: bipush #32
    //   1272: iconst_0
    //   1273: invokevirtual getBoolean : (IZ)Z
    //   1276: putfield 泳 : Z
    //   1279: aload_0
    //   1280: invokevirtual getContext : ()Landroid/content/Context;
    //   1283: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1286: astore #7
    //   1288: aload_0
    //   1289: aload_1
    //   1290: bipush #20
    //   1292: iconst_1
    //   1293: bipush #48
    //   1295: i2f
    //   1296: aload #7
    //   1298: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   1301: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1304: f2d
    //   1305: invokestatic ceil : (D)D
    //   1308: d2f
    //   1309: invokevirtual getDimension : (IF)F
    //   1312: f2d
    //   1313: invokestatic ceil : (D)D
    //   1316: d2i
    //   1317: putfield 寝 : I
    //   1320: aload_1
    //   1321: invokevirtual recycle : ()V
    //   1324: aload_0
    //   1325: aload #9
    //   1327: invokevirtual setChipDrawable : (Ly/捨;)V
    //   1330: aload #9
    //   1332: aload_0
    //   1333: invokestatic 冷 : (Landroid/view/View;)F
    //   1336: invokevirtual 不 : (F)V
    //   1339: aload #8
    //   1341: aload_2
    //   1342: aload #10
    //   1344: ldc 2130903227
    //   1346: ldc 2131756015
    //   1348: iconst_0
    //   1349: newarray int
    //   1351: invokestatic 淋 : (Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;
    //   1354: astore_1
    //   1355: iload #4
    //   1357: bipush #23
    //   1359: if_icmpge -> 1373
    //   1362: aload_0
    //   1363: aload #8
    //   1365: aload_1
    //   1366: iconst_2
    //   1367: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   1370: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   1373: aload_1
    //   1374: bipush #37
    //   1376: invokevirtual hasValue : (I)Z
    //   1379: istore #6
    //   1381: aload_1
    //   1382: invokevirtual recycle : ()V
    //   1385: aload_0
    //   1386: new y/創
    //   1389: dup
    //   1390: aload_0
    //   1391: aload_0
    //   1392: invokespecial <init> : (Lcom/google/android/material/chip/Chip;Lcom/google/android/material/chip/Chip;)V
    //   1395: putfield 触 : Ly/創;
    //   1398: aload_0
    //   1399: invokevirtual 暑 : ()V
    //   1402: iload #6
    //   1404: ifne -> 1419
    //   1407: aload_0
    //   1408: new y/造
    //   1411: dup
    //   1412: aload_0
    //   1413: invokespecial <init> : (Lcom/google/android/material/chip/Chip;)V
    //   1416: invokevirtual setOutlineProvider : (Landroid/view/ViewOutlineProvider;)V
    //   1419: aload_0
    //   1420: aload_0
    //   1421: getfield 壊 : Z
    //   1424: invokevirtual setChecked : (Z)V
    //   1427: aload_0
    //   1428: aload #9
    //   1430: getfield 크 : Ljava/lang/CharSequence;
    //   1433: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1436: aload_0
    //   1437: aload #9
    //   1439: getfield 家 : Landroid/text/TextUtils$TruncateAt;
    //   1442: invokevirtual setEllipsize : (Landroid/text/TextUtils$TruncateAt;)V
    //   1445: aload_0
    //   1446: invokevirtual 旨 : ()V
    //   1449: aload_0
    //   1450: getfield 痒 : Ly/捨;
    //   1453: getfield べ : Z
    //   1456: ifne -> 1469
    //   1459: aload_0
    //   1460: iconst_1
    //   1461: invokevirtual setLines : (I)V
    //   1464: aload_0
    //   1465: iconst_1
    //   1466: invokevirtual setHorizontallyScrolling : (Z)V
    //   1469: aload_0
    //   1470: ldc 8388627
    //   1472: invokevirtual setGravity : (I)V
    //   1475: aload_0
    //   1476: invokevirtual 美 : ()V
    //   1479: aload_0
    //   1480: getfield 泳 : Z
    //   1483: ifeq -> 1494
    //   1486: aload_0
    //   1487: aload_0
    //   1488: getfield 寝 : I
    //   1491: invokevirtual setMinHeight : (I)V
    //   1494: aload_0
    //   1495: aload_0
    //   1496: invokestatic 不 : (Landroid/view/View;)I
    //   1499: putfield 踊 : I
    //   1502: aload_0
    //   1503: new y/作
    //   1506: dup
    //   1507: aload_0
    //   1508: invokespecial <init> : (Lcom/google/android/material/chip/Chip;)V
    //   1511: invokespecial setOnCheckedChangeListener : (Landroid/widget/CompoundButton$OnCheckedChangeListener;)V
    //   1514: return
    //   1515: new java/lang/UnsupportedOperationException
    //   1518: dup
    //   1519: ldc_w 'Chip does not support multi-line text'
    //   1522: invokespecial <init> : (Ljava/lang/String;)V
    //   1525: athrow
    //   1526: new java/lang/UnsupportedOperationException
    //   1529: dup
    //   1530: ldc_w 'Please set end drawable using R.attr#closeIcon.'
    //   1533: invokespecial <init> : (Ljava/lang/String;)V
    //   1536: athrow
    //   1537: new java/lang/UnsupportedOperationException
    //   1540: dup
    //   1541: ldc_w 'Please set end drawable using R.attr#closeIcon.'
    //   1544: invokespecial <init> : (Ljava/lang/String;)V
    //   1547: athrow
    //   1548: new java/lang/UnsupportedOperationException
    //   1551: dup
    //   1552: ldc_w 'Please set start drawable using R.attr#chipIcon.'
    //   1555: invokespecial <init> : (Ljava/lang/String;)V
    //   1558: athrow
    //   1559: new java/lang/UnsupportedOperationException
    //   1562: dup
    //   1563: ldc_w 'Please set left drawable using R.attr#chipIcon.'
    //   1566: invokespecial <init> : (Ljava/lang/String;)V
    //   1569: athrow
  }
  
  private RectF getCloseIconTouchBounds() {
    RectF rectF = this.か;
    rectF.setEmpty();
    if (熱() && this.興 != null) {
      捨 捨1 = this.痒;
      Rect rect = 捨1.getBounds();
      rectF.setEmpty();
      if (捨1.크()) {
        float f = 捨1.し + 捨1.た + 捨1.탕 + 捨1.者 + 捨1.퉁;
        if (td.不((Drawable)捨1) == 0) {
          float f1 = rect.right;
          rectF.right = f1;
          rectF.left = f1 - f;
        } else {
          float f1 = rect.left;
          rectF.left = f1;
          rectF.right = f1 + f;
        } 
        rectF.top = rect.top;
        rectF.bottom = rect.bottom;
      } 
    } 
    return rectF;
  }
  
  private Rect getCloseIconTouchBoundsInt() {
    RectF rectF = getCloseIconTouchBounds();
    int i = (int)rectF.left;
    int j = (int)rectF.top;
    int k = (int)rectF.right;
    int m = (int)rectF.bottom;
    Rect rect = this.あ;
    rect.set(i, j, k, m);
    return rect;
  }
  
  private qq getTextAppearance() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.ょ.寒 : null;
  }
  
  private void setCloseIconHovered(boolean paramBoolean) {
    if (this.返 != paramBoolean) {
      this.返 = paramBoolean;
      refreshDrawableState();
    } 
  }
  
  private void setCloseIconPressed(boolean paramBoolean) {
    if (this.帰 != paramBoolean) {
      this.帰 = paramBoolean;
      refreshDrawableState();
    } 
  }
  
  public final boolean dispatchHoverEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 投 : Z
    //   4: ifne -> 13
    //   7: aload_0
    //   8: aload_1
    //   9: invokespecial dispatchHoverEvent : (Landroid/view/MotionEvent;)Z
    //   12: ireturn
    //   13: aload_0
    //   14: getfield 触 : Ly/創;
    //   17: astore #8
    //   19: aload #8
    //   21: getfield 旨 : Landroid/view/accessibility/AccessibilityManager;
    //   24: astore #9
    //   26: aload #9
    //   28: invokevirtual isEnabled : ()Z
    //   31: istore #7
    //   33: iconst_0
    //   34: istore #6
    //   36: iload #7
    //   38: ifeq -> 245
    //   41: aload #9
    //   43: invokevirtual isTouchExplorationEnabled : ()Z
    //   46: ifne -> 52
    //   49: goto -> 245
    //   52: aload_1
    //   53: invokevirtual getAction : ()I
    //   56: istore #4
    //   58: iload #4
    //   60: bipush #7
    //   62: if_icmpeq -> 140
    //   65: iload #4
    //   67: bipush #9
    //   69: if_icmpeq -> 140
    //   72: iload #4
    //   74: bipush #10
    //   76: if_icmpeq -> 82
    //   79: goto -> 245
    //   82: aload #8
    //   84: getfield 嬉 : I
    //   87: istore #4
    //   89: iload #4
    //   91: ldc_w -2147483648
    //   94: if_icmpeq -> 245
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpne -> 108
    //   105: goto -> 239
    //   108: aload #8
    //   110: ldc_w -2147483648
    //   113: putfield 嬉 : I
    //   116: aload #8
    //   118: ldc_w -2147483648
    //   121: sipush #128
    //   124: invokevirtual 怖 : (II)V
    //   127: aload #8
    //   129: iload #4
    //   131: sipush #256
    //   134: invokevirtual 怖 : (II)V
    //   137: goto -> 239
    //   140: aload_1
    //   141: invokevirtual getX : ()F
    //   144: fstore_2
    //   145: aload_1
    //   146: invokevirtual getY : ()F
    //   149: fstore_3
    //   150: aload #8
    //   152: getfield 悲 : Lcom/google/android/material/chip/Chip;
    //   155: astore #9
    //   157: aload #9
    //   159: invokevirtual 熱 : ()Z
    //   162: ifeq -> 184
    //   165: aload #9
    //   167: invokespecial getCloseIconTouchBounds : ()Landroid/graphics/RectF;
    //   170: fload_2
    //   171: fload_3
    //   172: invokevirtual contains : (FF)Z
    //   175: ifeq -> 184
    //   178: iconst_1
    //   179: istore #4
    //   181: goto -> 187
    //   184: iconst_0
    //   185: istore #4
    //   187: aload #8
    //   189: getfield 嬉 : I
    //   192: istore #5
    //   194: iload #5
    //   196: iload #4
    //   198: if_icmpne -> 204
    //   201: goto -> 231
    //   204: aload #8
    //   206: iload #4
    //   208: putfield 嬉 : I
    //   211: aload #8
    //   213: iload #4
    //   215: sipush #128
    //   218: invokevirtual 怖 : (II)V
    //   221: aload #8
    //   223: iload #5
    //   225: sipush #256
    //   228: invokevirtual 怖 : (II)V
    //   231: iload #4
    //   233: ldc_w -2147483648
    //   236: if_icmpeq -> 245
    //   239: iconst_1
    //   240: istore #4
    //   242: goto -> 248
    //   245: iconst_0
    //   246: istore #4
    //   248: iload #4
    //   250: ifne -> 261
    //   253: aload_0
    //   254: aload_1
    //   255: invokespecial dispatchHoverEvent : (Landroid/view/MotionEvent;)Z
    //   258: ifeq -> 264
    //   261: iconst_1
    //   262: istore #6
    //   264: iload #6
    //   266: ireturn
  }
  
  public final boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    if (!this.投)
      return super.dispatchKeyEvent(paramKeyEvent); 
    創 創1 = this.触;
    創1.getClass();
    int i = paramKeyEvent.getAction();
    boolean bool2 = false;
    int j = 0;
    boolean bool1 = bool2;
    if (i != 1) {
      int k = paramKeyEvent.getKeyCode();
      if (k != 61) {
        i = 66;
        if (k != 66) {
          switch (k) {
            default:
              bool1 = bool2;
              break;
            case 19:
            case 20:
            case 21:
            case 22:
              bool1 = bool2;
              if (paramKeyEvent.hasNoModifiers()) {
                if (k != 19) {
                  if (k != 21) {
                    if (k != 22)
                      i = 130; 
                  } else {
                    i = 17;
                  } 
                } else {
                  i = 33;
                } 
                k = paramKeyEvent.getRepeatCount();
                for (bool1 = false; j < k + 1 && 創1.嬉(i, null); bool1 = true)
                  j++; 
              } 
              break;
            case 23:
              bool1 = bool2;
              if (paramKeyEvent.hasNoModifiers()) {
                bool1 = bool2;
                if (paramKeyEvent.getRepeatCount() == 0) {
                  i = 創1.苦;
                  if (i != Integer.MIN_VALUE) {
                    Chip chip = 創1.悲;
                    if (i == 0) {
                      chip.performClick();
                    } else if (i == 1) {
                      chip.playSoundEffect(0);
                      View.OnClickListener onClickListener = chip.興;
                      if (onClickListener != null)
                        onClickListener.onClick((View)chip); 
                      if (chip.投)
                        chip.触.怖(1, 1); 
                    } 
                  } 
                  bool1 = true;
                } 
              } 
              break;
          } 
        } else {
        
        } 
      } else if (paramKeyEvent.hasNoModifiers()) {
        bool1 = 創1.嬉(2, null);
      } else {
        bool1 = bool2;
        if (paramKeyEvent.hasModifiers(1))
          bool1 = 創1.嬉(1, null); 
      } 
    } 
    return (bool1 && 創1.苦 != Integer.MIN_VALUE) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public final void drawableStateChanged() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public CharSequence getAccessibilityClassName() {
    boolean bool;
    if (!TextUtils.isEmpty(this.噛))
      return this.噛; 
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.택) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      ViewParent viewParent = getParent();
      return (viewParent instanceof ChipGroup && ((ChipGroup)viewParent).興.淋) ? "android.widget.RadioButton" : "android.widget.CompoundButton";
    } 
    return isClickable() ? "android.widget.Button" : "android.view.View";
  }
  
  public Drawable getBackgroundDrawable() {
    捨 捨1;
    InsetDrawable insetDrawable2 = this.臭;
    InsetDrawable insetDrawable1 = insetDrawable2;
    if (insetDrawable2 == null)
      捨1 = this.痒; 
    return (Drawable)捨1;
  }
  
  public Drawable getCheckedIcon() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.터 : null;
  }
  
  public ColorStateList getCheckedIconTint() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.테 : null;
  }
  
  public ColorStateList getChipBackgroundColor() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.赤 : null;
  }
  
  public float getChipCornerRadius() {
    捨 捨1 = this.痒;
    float f = 0.0F;
    if (捨1 != null)
      f = Math.max(0.0F, 捨1.恐()); 
    return f;
  }
  
  public Drawable getChipDrawable() {
    return (Drawable)this.痒;
  }
  
  public float getChipEndPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.し : 0.0F;
  }
  
  public Drawable getChipIcon() {
    捨 捨1 = this.痒;
    Drawable drawable2 = null;
    Drawable drawable1 = drawable2;
    if (捨1 != null) {
      Drawable drawable = 捨1.키;
      drawable1 = drawable2;
      if (drawable != null) {
        drawable1 = drawable;
        if (drawable instanceof y.s10)
          drawable1 = ((t10)drawable).臭; 
      } 
    } 
    return drawable1;
  }
  
  public float getChipIconSize() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.타 : 0.0F;
  }
  
  public ColorStateList getChipIconTint() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.ㅌ : null;
  }
  
  public float getChipMinHeight() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.わ : 0.0F;
  }
  
  public float getChipStartPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.톨 : 0.0F;
  }
  
  public ColorStateList getChipStrokeColor() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.若 : null;
  }
  
  public float getChipStrokeWidth() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.코 : 0.0F;
  }
  
  @Deprecated
  public CharSequence getChipText() {
    return getText();
  }
  
  public Drawable getCloseIcon() {
    捨 捨1 = this.痒;
    Drawable drawable2 = null;
    Drawable drawable1 = drawable2;
    if (捨1 != null) {
      Drawable drawable = 捨1.탈;
      drawable1 = drawable2;
      if (drawable != null) {
        drawable1 = drawable;
        if (drawable instanceof y.s10)
          drawable1 = ((t10)drawable).臭; 
      } 
    } 
    return drawable1;
  }
  
  public CharSequence getCloseIconContentDescription() {
    捨 捨1 = this.痒;
    return (CharSequence)((捨1 != null) ? 捨1.태 : null);
  }
  
  public float getCloseIconEndPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.た : 0.0F;
  }
  
  public float getCloseIconSize() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.탕 : 0.0F;
  }
  
  public float getCloseIconStartPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.者 : 0.0F;
  }
  
  public ColorStateList getCloseIconTint() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.탑 : null;
  }
  
  public TextUtils.TruncateAt getEllipsize() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.家 : null;
  }
  
  public final void getFocusedRect(Rect paramRect) {
    if (this.投) {
      創 創1 = this.触;
      if (創1.苦 == 1 || 創1.ぱ == 1) {
        paramRect.set(getCloseIconTouchBoundsInt());
        return;
      } 
    } 
    super.getFocusedRect(paramRect);
  }
  
  public j4 getHideMotionSpec() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.톤 : null;
  }
  
  public float getIconEndPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.퇴 : 0.0F;
  }
  
  public float getIconStartPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.통 : 0.0F;
  }
  
  public ColorStateList getRippleColor() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.쾌 : null;
  }
  
  public wk getShapeAppearanceModel() {
    return ((u0)this.痒).淋.硬;
  }
  
  public j4 getShowMotionSpec() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.토 : null;
  }
  
  public float getTextEndPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.퉁 : 0.0F;
  }
  
  public float getTextStartPadding() {
    捨 捨1 = this.痒;
    return (捨1 != null) ? 捨1.투 : 0.0F;
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    年.赤((View)this, (u0)this.痒);
  }
  
  public final int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 2);
    if (isChecked())
      View.mergeDrawableStates(arrayOfInt, 赤); 
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.택) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt != 0)
      View.mergeDrawableStates(arrayOfInt, わ); 
    return arrayOfInt;
  }
  
  public final void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    super.onFocusChanged(paramBoolean, paramInt, paramRect);
    if (this.投) {
      創 創1 = this.触;
      int i = 創1.苦;
      if (i != Integer.MIN_VALUE)
        創1.辛(i); 
      if (paramBoolean)
        創1.嬉(paramInt, paramRect); 
    } 
  }
  
  public final boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i != 7) {
      if (i == 10)
        setCloseIconHovered(false); 
    } else {
      setCloseIconHovered(getCloseIconTouchBounds().contains(paramMotionEvent.getX(), paramMotionEvent.getY()));
    } 
    return super.onHoverEvent(paramMotionEvent);
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onInitializeAccessibilityNodeInfo : (Landroid/view/accessibility/AccessibilityNodeInfo;)V
    //   5: aload_1
    //   6: aload_0
    //   7: invokevirtual getAccessibilityClassName : ()Ljava/lang/CharSequence;
    //   10: invokevirtual setClassName : (Ljava/lang/CharSequence;)V
    //   13: aload_0
    //   14: getfield 痒 : Ly/捨;
    //   17: astore #7
    //   19: iconst_0
    //   20: istore_3
    //   21: aload #7
    //   23: ifnull -> 40
    //   26: aload #7
    //   28: getfield 택 : Z
    //   31: ifeq -> 40
    //   34: iconst_1
    //   35: istore #6
    //   37: goto -> 43
    //   40: iconst_0
    //   41: istore #6
    //   43: aload_1
    //   44: iload #6
    //   46: invokevirtual setCheckable : (Z)V
    //   49: aload_1
    //   50: aload_0
    //   51: invokevirtual isClickable : ()Z
    //   54: invokevirtual setClickable : (Z)V
    //   57: aload_0
    //   58: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   61: instanceof com/google/android/material/chip/ChipGroup
    //   64: ifeq -> 211
    //   67: aload_0
    //   68: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   71: checkcast com/google/android/material/chip/ChipGroup
    //   74: astore #7
    //   76: aload #7
    //   78: getfield 恐 : Z
    //   81: istore #6
    //   83: iconst_m1
    //   84: istore #5
    //   86: iload #6
    //   88: ifeq -> 148
    //   91: iconst_0
    //   92: istore_2
    //   93: iload_3
    //   94: aload #7
    //   96: invokevirtual getChildCount : ()I
    //   99: if_icmpge -> 148
    //   102: iload_2
    //   103: istore #4
    //   105: aload #7
    //   107: iload_3
    //   108: invokevirtual getChildAt : (I)Landroid/view/View;
    //   111: instanceof com/google/android/material/chip/Chip
    //   114: ifeq -> 138
    //   117: aload #7
    //   119: iload_3
    //   120: invokevirtual getChildAt : (I)Landroid/view/View;
    //   123: checkcast com/google/android/material/chip/Chip
    //   126: aload_0
    //   127: if_acmpne -> 133
    //   130: goto -> 150
    //   133: iload_2
    //   134: iconst_1
    //   135: iadd
    //   136: istore #4
    //   138: iload_3
    //   139: iconst_1
    //   140: iadd
    //   141: istore_3
    //   142: iload #4
    //   144: istore_2
    //   145: goto -> 93
    //   148: iconst_m1
    //   149: istore_2
    //   150: aload_0
    //   151: ldc_w 2131231254
    //   154: invokevirtual getTag : (I)Ljava/lang/Object;
    //   157: astore #7
    //   159: aload #7
    //   161: instanceof java/lang/Integer
    //   164: ifne -> 173
    //   167: iload #5
    //   169: istore_3
    //   170: goto -> 182
    //   173: aload #7
    //   175: checkcast java/lang/Integer
    //   178: invokevirtual intValue : ()I
    //   181: istore_3
    //   182: iload_3
    //   183: iconst_1
    //   184: iload_2
    //   185: iconst_1
    //   186: aload_0
    //   187: invokevirtual isChecked : ()Z
    //   190: invokestatic 起 : (IIIIZ)Ly/賊;
    //   193: astore #7
    //   195: getstatic android/os/Build$VERSION.SDK_INT : I
    //   198: istore_2
    //   199: aload_1
    //   200: aload #7
    //   202: getfield 淋 : Ljava/lang/Object;
    //   205: checkcast android/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo
    //   208: invokevirtual setCollectionItemInfo : (Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    //   211: return
  }
  
  public final PointerIcon onResolvePointerIcon(MotionEvent paramMotionEvent, int paramInt) {
    return (getCloseIconTouchBounds().contains(paramMotionEvent.getX(), paramMotionEvent.getY()) && isEnabled()) ? 鯖.ぱ(getContext()) : null;
  }
  
  public final void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    if (this.踊 != paramInt) {
      this.踊 = paramInt;
      美();
    } 
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: invokespecial getCloseIconTouchBounds : ()Landroid/graphics/RectF;
    //   9: aload_1
    //   10: invokevirtual getX : ()F
    //   13: aload_1
    //   14: invokevirtual getY : ()F
    //   17: invokevirtual contains : (FF)Z
    //   20: istore #4
    //   22: iconst_1
    //   23: istore_3
    //   24: iload_2
    //   25: ifeq -> 128
    //   28: iload_2
    //   29: iconst_1
    //   30: if_icmpeq -> 66
    //   33: iload_2
    //   34: iconst_2
    //   35: if_icmpeq -> 46
    //   38: iload_2
    //   39: iconst_3
    //   40: if_icmpeq -> 118
    //   43: goto -> 143
    //   46: aload_0
    //   47: getfield 帰 : Z
    //   50: ifeq -> 143
    //   53: iload #4
    //   55: ifne -> 138
    //   58: aload_0
    //   59: iconst_0
    //   60: invokespecial setCloseIconPressed : (Z)V
    //   63: goto -> 138
    //   66: aload_0
    //   67: getfield 帰 : Z
    //   70: ifeq -> 118
    //   73: aload_0
    //   74: iconst_0
    //   75: invokevirtual playSoundEffect : (I)V
    //   78: aload_0
    //   79: getfield 興 : Landroid/view/View$OnClickListener;
    //   82: astore #5
    //   84: aload #5
    //   86: ifnull -> 97
    //   89: aload #5
    //   91: aload_0
    //   92: invokeinterface onClick : (Landroid/view/View;)V
    //   97: aload_0
    //   98: getfield 投 : Z
    //   101: ifeq -> 113
    //   104: aload_0
    //   105: getfield 触 : Ly/創;
    //   108: iconst_1
    //   109: iconst_1
    //   110: invokevirtual 怖 : (II)V
    //   113: iconst_1
    //   114: istore_2
    //   115: goto -> 120
    //   118: iconst_0
    //   119: istore_2
    //   120: aload_0
    //   121: iconst_0
    //   122: invokespecial setCloseIconPressed : (Z)V
    //   125: goto -> 145
    //   128: iload #4
    //   130: ifeq -> 143
    //   133: aload_0
    //   134: iconst_1
    //   135: invokespecial setCloseIconPressed : (Z)V
    //   138: iconst_1
    //   139: istore_2
    //   140: goto -> 145
    //   143: iconst_0
    //   144: istore_2
    //   145: iload_2
    //   146: ifne -> 161
    //   149: aload_0
    //   150: aload_1
    //   151: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   154: ifeq -> 159
    //   157: iconst_1
    //   158: ireturn
    //   159: iconst_0
    //   160: istore_3
    //   161: iload_3
    //   162: ireturn
  }
  
  public void setAccessibilityClassName(CharSequence paramCharSequence) {
    this.噛 = paramCharSequence;
  }
  
  public void setBackground(Drawable paramDrawable) {
    if (paramDrawable != getBackgroundDrawable() && paramDrawable != this.起)
      return; 
    super.setBackground(paramDrawable);
  }
  
  public void setBackgroundColor(int paramInt) {}
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    if (paramDrawable != getBackgroundDrawable() && paramDrawable != this.起)
      return; 
    super.setBackgroundDrawable(paramDrawable);
  }
  
  public void setBackgroundResource(int paramInt) {}
  
  public void setBackgroundTintList(ColorStateList paramColorStateList) {}
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode) {}
  
  public void setCheckable(boolean paramBoolean) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.興(paramBoolean); 
  }
  
  public void setCheckableResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.興(捨1.私.getResources().getBoolean(paramInt)); 
  }
  
  public void setChecked(boolean paramBoolean) {
    捨 捨1 = this.痒;
    if (捨1 == null) {
      this.壊 = paramBoolean;
      return;
    } 
    if (捨1.택)
      super.setChecked(paramBoolean); 
  }
  
  public void setCheckedIcon(Drawable paramDrawable) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.産(paramDrawable); 
  }
  
  @Deprecated
  public void setCheckedIconEnabled(boolean paramBoolean) {
    setCheckedIconVisible(paramBoolean);
  }
  
  @Deprecated
  public void setCheckedIconEnabledResource(int paramInt) {
    setCheckedIconVisible(paramInt);
  }
  
  public void setCheckedIconResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.産(年.痛(捨1.私, paramInt)); 
  }
  
  public void setCheckedIconTint(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.死(paramColorStateList); 
  }
  
  public void setCheckedIconTintResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.死(年.淋(捨1.私, paramInt)); 
  }
  
  public void setCheckedIconVisible(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.壊(捨1.私.getResources().getBoolean(paramInt)); 
  }
  
  public void setCheckedIconVisible(boolean paramBoolean) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.壊(paramBoolean); 
  }
  
  public void setChipBackgroundColor(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.赤 != paramColorStateList) {
      捨1.赤 = paramColorStateList;
      捨1.onStateChange(捨1.getState());
    } 
  }
  
  public void setChipBackgroundColorResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      ColorStateList colorStateList = 年.淋(捨1.私, paramInt);
      if (捨1.赤 != colorStateList) {
        捨1.赤 = colorStateList;
        捨1.onStateChange(捨1.getState());
      } 
    } 
  }
  
  @Deprecated
  public void setChipCornerRadius(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.帰(paramFloat); 
  }
  
  @Deprecated
  public void setChipCornerRadiusResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.帰(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setChipDrawable(捨 param捨) {
    捨 捨1 = this.痒;
    if (捨1 != param捨) {
      if (捨1 != null)
        捨1.治 = new WeakReference(null); 
      this.痒 = param捨;
      param捨.べ = false;
      param捨.治 = new WeakReference<Chip>(this);
      堅(this.寝);
    } 
  }
  
  public void setChipEndPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.し != paramFloat) {
      捨1.し = paramFloat;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setChipEndPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      float f = 捨1.私.getResources().getDimension(paramInt);
      if (捨1.し != f) {
        捨1.し = f;
        捨1.invalidateSelf();
        捨1.臭();
      } 
    } 
  }
  
  public void setChipIcon(Drawable paramDrawable) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.返(paramDrawable); 
  }
  
  @Deprecated
  public void setChipIconEnabled(boolean paramBoolean) {
    setChipIconVisible(paramBoolean);
  }
  
  @Deprecated
  public void setChipIconEnabledResource(int paramInt) {
    setChipIconVisible(paramInt);
  }
  
  public void setChipIconResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.返(年.痛(捨1.私, paramInt)); 
  }
  
  public void setChipIconSize(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.歩(paramFloat); 
  }
  
  public void setChipIconSizeResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.歩(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setChipIconTint(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.泳(paramColorStateList); 
  }
  
  public void setChipIconTintResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.泳(年.淋(捨1.私, paramInt)); 
  }
  
  public void setChipIconVisible(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.踊(捨1.私.getResources().getBoolean(paramInt)); 
  }
  
  public void setChipIconVisible(boolean paramBoolean) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.踊(paramBoolean); 
  }
  
  public void setChipMinHeight(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.わ != paramFloat) {
      捨1.わ = paramFloat;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setChipMinHeightResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      float f = 捨1.私.getResources().getDimension(paramInt);
      if (捨1.わ != f) {
        捨1.わ = f;
        捨1.invalidateSelf();
        捨1.臭();
      } 
    } 
  }
  
  public void setChipStartPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.톨 != paramFloat) {
      捨1.톨 = paramFloat;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setChipStartPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      float f = 捨1.私.getResources().getDimension(paramInt);
      if (捨1.톨 != f) {
        捨1.톨 = f;
        捨1.invalidateSelf();
        捨1.臭();
      } 
    } 
  }
  
  public void setChipStrokeColor(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.寝(paramColorStateList); 
  }
  
  public void setChipStrokeColorResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.寝(年.淋(捨1.私, paramInt)); 
  }
  
  public void setChipStrokeWidth(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.噛(paramFloat); 
  }
  
  public void setChipStrokeWidthResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.噛(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  @Deprecated
  public void setChipText(CharSequence paramCharSequence) {
    setText(paramCharSequence);
  }
  
  @Deprecated
  public void setChipTextResource(int paramInt) {
    setText(getResources().getString(paramInt));
  }
  
  public void setCloseIcon(Drawable paramDrawable) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.触(paramDrawable); 
    暑();
  }
  
  public void setCloseIconContentDescription(CharSequence paramCharSequence) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.태 != paramCharSequence) {
      安 安;
      String str = 安.暑;
      Locale locale = Locale.getDefault();
      int i = dr.硬;
      i = Build.VERSION.SDK_INT;
      int j = cr.硬(locale);
      i = 1;
      if (j != 1)
        i = 0; 
      if (i != 0) {
        安 = 安.美;
      } else {
        安 = 安.寒;
      } 
      捨1.태 = 安.熱(paramCharSequence, 安.熱);
      捨1.invalidateSelf();
    } 
  }
  
  @Deprecated
  public void setCloseIconEnabled(boolean paramBoolean) {
    setCloseIconVisible(paramBoolean);
  }
  
  @Deprecated
  public void setCloseIconEnabledResource(int paramInt) {
    setCloseIconVisible(paramInt);
  }
  
  public void setCloseIconEndPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.投(paramFloat); 
  }
  
  public void setCloseIconEndPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.投(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setCloseIconResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.触(年.痛(捨1.私, paramInt)); 
    暑();
  }
  
  public void setCloseIconSize(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.あ(paramFloat); 
  }
  
  public void setCloseIconSizeResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.あ(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setCloseIconStartPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.か(paramFloat); 
  }
  
  public void setCloseIconStartPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.か(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setCloseIconTint(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.ち(paramColorStateList); 
  }
  
  public void setCloseIconTintResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.ち(年.淋(捨1.私, paramInt)); 
  }
  
  public void setCloseIconVisible(int paramInt) {
    setCloseIconVisible(getResources().getBoolean(paramInt));
  }
  
  public void setCloseIconVisible(boolean paramBoolean) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.ゃ(paramBoolean); 
    暑();
  }
  
  public final void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    if (paramDrawable1 == null) {
      if (paramDrawable3 == null) {
        super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
        return;
      } 
      throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
  }
  
  public final void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    if (paramDrawable1 == null) {
      if (paramDrawable3 == null) {
        super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
        return;
      } 
      throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
  }
  
  public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 == 0) {
      if (paramInt3 == 0) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } 
      throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
  }
  
  public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    if (paramDrawable1 == null) {
      if (paramDrawable3 == null) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
        return;
      } 
      throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
  }
  
  public final void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 == 0) {
      if (paramInt3 == 0) {
        super.setCompoundDrawablesWithIntrinsicBounds(paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } 
      throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
  }
  
  public final void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    if (paramDrawable1 == null) {
      if (paramDrawable3 == null) {
        super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
        return;
      } 
      throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
    } 
    throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.不(paramFloat); 
  }
  
  public void setEllipsize(TextUtils.TruncateAt paramTruncateAt) {
    if (this.痒 == null)
      return; 
    if (paramTruncateAt != TextUtils.TruncateAt.MARQUEE) {
      super.setEllipsize(paramTruncateAt);
      捨 捨1 = this.痒;
      if (捨1 != null)
        捨1.家 = paramTruncateAt; 
      return;
    } 
    throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
  }
  
  public void setEnsureMinTouchTargetSize(boolean paramBoolean) {
    this.泳 = paramBoolean;
    堅(this.寝);
  }
  
  public void setGravity(int paramInt) {
    if (paramInt != 8388627)
      return; 
    super.setGravity(paramInt);
  }
  
  public void setHideMotionSpec(j4 paramj4) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.톤 = paramj4; 
  }
  
  public void setHideMotionSpecResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.톤 = j4.硬(捨1.私, paramInt); 
  }
  
  public void setIconEndPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.赤(paramFloat); 
  }
  
  public void setIconEndPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.赤(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setIconStartPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.わ(paramFloat); 
  }
  
  public void setIconStartPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.わ(捨1.私.getResources().getDimension(paramInt)); 
  }
  
  public void setInternalOnCheckedChangeListener(o0 paramo0) {
    this.死 = paramo0;
  }
  
  public void setLayoutDirection(int paramInt) {
    if (this.痒 == null)
      return; 
    int i = Build.VERSION.SDK_INT;
    super.setLayoutDirection(paramInt);
  }
  
  public void setLines(int paramInt) {
    if (paramInt <= 1) {
      super.setLines(paramInt);
      return;
    } 
    throw new UnsupportedOperationException("Chip does not support multi-line text");
  }
  
  public void setMaxLines(int paramInt) {
    if (paramInt <= 1) {
      super.setMaxLines(paramInt);
      return;
    } 
    throw new UnsupportedOperationException("Chip does not support multi-line text");
  }
  
  public void setMaxWidth(int paramInt) {
    super.setMaxWidth(paramInt);
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.弁 = paramInt; 
  }
  
  public void setMinLines(int paramInt) {
    if (paramInt <= 1) {
      super.setMinLines(paramInt);
      return;
    } 
    throw new UnsupportedOperationException("Chip does not support multi-line text");
  }
  
  public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener paramOnCheckedChangeListener) {
    this.産 = paramOnCheckedChangeListener;
  }
  
  public void setOnCloseIconClickListener(View.OnClickListener paramOnClickListener) {
    this.興 = paramOnClickListener;
    暑();
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.も(paramColorStateList); 
    if (!this.痒.せ)
      寒(); 
  }
  
  public void setRippleColorResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      捨1.も(年.淋(捨1.私, paramInt));
      if (!this.痒.せ)
        寒(); 
    } 
  }
  
  public void setShapeAppearanceModel(wk paramwk) {
    this.痒.setShapeAppearanceModel(paramwk);
  }
  
  public void setShowMotionSpec(j4 paramj4) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.토 = paramj4; 
  }
  
  public void setShowMotionSpecResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.토 = j4.硬(捨1.私, paramInt); 
  }
  
  public void setSingleLine(boolean paramBoolean) {
    if (paramBoolean) {
      super.setSingleLine(paramBoolean);
      return;
    } 
    throw new UnsupportedOperationException("Chip does not support multi-line text");
  }
  
  public final void setText(CharSequence paramCharSequence, TextView.BufferType paramBufferType) {
    捨 捨2 = this.痒;
    if (捨2 == null)
      return; 
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence == null)
      charSequence = ""; 
    if (捨2.べ) {
      paramCharSequence = null;
    } else {
      paramCharSequence = charSequence;
    } 
    super.setText(paramCharSequence, paramBufferType);
    捨 捨1 = this.痒;
    if (捨1 != null && !TextUtils.equals(捨1.크, charSequence)) {
      捨1.크 = charSequence;
      捨1.ょ.暑 = true;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setTextAppearance(int paramInt) {
    super.setTextAppearance(paramInt);
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.若(new qq(捨1.私, paramInt)); 
    旨();
  }
  
  public final void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.若(new qq(捨1.私, paramInt)); 
    旨();
  }
  
  public void setTextAppearance(qq paramqq) {
    捨 捨1 = this.痒;
    if (捨1 != null)
      捨1.若(paramqq); 
    旨();
  }
  
  public void setTextAppearanceResource(int paramInt) {
    setTextAppearance(getContext(), paramInt);
  }
  
  public void setTextEndPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.퉁 != paramFloat) {
      捨1.퉁 = paramFloat;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setTextEndPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      float f = 捨1.私.getResources().getDimension(paramInt);
      if (捨1.퉁 != f) {
        捨1.퉁 = f;
        捨1.invalidateSelf();
        捨1.臭();
      } 
    } 
  }
  
  public void setTextStartPadding(float paramFloat) {
    捨 捨1 = this.痒;
    if (捨1 != null && 捨1.투 != paramFloat) {
      捨1.투 = paramFloat;
      捨1.invalidateSelf();
      捨1.臭();
    } 
  }
  
  public void setTextStartPaddingResource(int paramInt) {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      float f = 捨1.私.getResources().getDimension(paramInt);
      if (捨1.투 != f) {
        捨1.투 = f;
        捨1.invalidateSelf();
        捨1.臭();
      } 
    } 
  }
  
  public final void 冷() {
    if (gh.硬) {
      寒();
      return;
    } 
    捨 捨1 = this.痒;
    if (捨1.せ != true) {
      捨1.せ = true;
      捨1.政 = gh.硬(捨1.쾌);
      捨1.onStateChange(捨1.getState());
    } 
    rw.歩((View)this, getBackgroundDrawable());
    美();
    if (getBackgroundDrawable() == this.臭 && this.痒.getCallback() == null)
      this.痒.setCallback((Drawable.Callback)this.臭); 
  }
  
  public final void 堅(int paramInt) {
    this.寝 = paramInt;
    if (!this.泳) {
      InsetDrawable insetDrawable = this.臭;
      if (insetDrawable != null) {
        if (insetDrawable != null) {
          this.臭 = null;
          setMinWidth(0);
          setMinHeight((int)getChipMinHeight());
          冷();
          return;
        } 
      } else {
        冷();
      } 
      return;
    } 
    int j = Math.max(0, paramInt - (int)this.痒.わ);
    int i = Math.max(0, paramInt - this.痒.getIntrinsicWidth());
    if (i <= 0 && j <= 0) {
      InsetDrawable insetDrawable = this.臭;
      if (insetDrawable != null) {
        if (insetDrawable != null) {
          this.臭 = null;
          setMinWidth(0);
          setMinHeight((int)getChipMinHeight());
          冷();
          return;
        } 
      } else {
        冷();
      } 
      return;
    } 
    if (i > 0) {
      i /= 2;
    } else {
      i = 0;
    } 
    if (j > 0) {
      j /= 2;
    } else {
      j = 0;
    } 
    if (this.臭 != null) {
      Rect rect = new Rect();
      this.臭.getPadding(rect);
      if (rect.top == j && rect.bottom == j && rect.left == i && rect.right == i) {
        冷();
        return;
      } 
    } 
    int k = Build.VERSION.SDK_INT;
    if (getMinHeight() != paramInt)
      setMinHeight(paramInt); 
    if (getMinWidth() != paramInt)
      setMinWidth(paramInt); 
    this.臭 = new InsetDrawable((Drawable)this.痒, i, j, i, j);
    冷();
  }
  
  public final void 寒() {
    this.起 = new RippleDrawable(gh.硬(this.痒.쾌), getBackgroundDrawable(), null);
    捨 捨1 = this.痒;
    if (捨1.せ) {
      捨1.せ = false;
      捨1.政 = null;
      捨1.onStateChange(捨1.getState());
    } 
    rw.歩((View)this, (Drawable)this.起);
    美();
  }
  
  public final void 旨() {
    TextPaint textPaint = getPaint();
    捨 捨1 = this.痒;
    if (捨1 != null)
      textPaint.drawableState = 捨1.getState(); 
    qq qq = getTextAppearance();
    if (qq != null)
      qq.冷(getContext(), textPaint, (年)this.ち); 
  }
  
  public final void 暑() {
    if (熱()) {
      boolean bool;
      捨 捨1 = this.痒;
      if (捨1 != null && 捨1.탄) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.興 != null) {
        rw.帰((View)this, (nul)this.触);
        this.投 = true;
        return;
      } 
    } 
    rw.帰((View)this, null);
    this.投 = false;
  }
  
  public final boolean 熱() {
    捨 捨1 = this.痒;
    if (捨1 != null) {
      Drawable drawable = 捨1.탈;
      if (drawable != null) {
        Drawable drawable1 = drawable;
        if (drawable instanceof y.s10)
          drawable1 = ((t10)drawable).臭; 
      } else {
        捨1 = null;
      } 
      if (捨1 != null)
        return true; 
    } 
    return false;
  }
  
  public final void 美() {
    if (!TextUtils.isEmpty(getText())) {
      捨 捨1 = this.痒;
      if (捨1 == null)
        return; 
      float f1 = 捨1.し;
      float f2 = 捨1.퉁;
      int k = (int)(捨1.怖() + f1 + f2);
      捨1 = this.痒;
      f1 = 捨1.톨;
      f2 = 捨1.투;
      int m = (int)(捨1.淋() + f1 + f2);
      int j = k;
      int i = m;
      if (this.臭 != null) {
        Rect rect = new Rect();
        this.臭.getPadding(rect);
        i = m + rect.left;
        j = k + rect.right;
      } 
      rw.寝((View)this, i, getPaddingTop(), j, getPaddingBottom());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\chip\Chip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */