package com.google.android.material.textfield;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.util.Locale;
import y.bm;
import y.td;
import y.年;
import y.椅;

public class TextInputEditText extends 椅 {
  public boolean 興;
  
  public final Rect 起 = new Rect();
  
  public TextInputEditText(Context paramContext, AttributeSet paramAttributeSet) {
    super(年.크(paramContext, paramAttributeSet, 2130903404, 0), paramAttributeSet);
    TypedArray typedArray = td.淋(paramContext, paramAttributeSet, 年.触, 2130903404, 2131755842, new int[0]);
    setTextInputLayoutFocusedRectEnabled(typedArray.getBoolean(0, false));
    typedArray.recycle();
  }
  
  private CharSequence getHintFromLayout() {
    TextInputLayout textInputLayout = getTextInputLayout();
    return (textInputLayout != null) ? textInputLayout.getHint() : null;
  }
  
  private TextInputLayout getTextInputLayout() {
    for (ViewParent viewParent = getParent(); viewParent instanceof android.view.View; viewParent = viewParent.getParent()) {
      if (viewParent instanceof TextInputLayout)
        return (TextInputLayout)viewParent; 
    } 
    return null;
  }
  
  public final void getFocusedRect(Rect paramRect) {
    boolean bool;
    super.getFocusedRect(paramRect);
    TextInputLayout textInputLayout = getTextInputLayout();
    if (textInputLayout != null && this.興) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && paramRect != null) {
      Rect rect = this.起;
      textInputLayout.getFocusedRect(rect);
      paramRect.bottom = rect.bottom;
    } 
  }
  
  public final boolean getGlobalVisibleRect(Rect paramRect, Point paramPoint) {
    boolean bool;
    TextInputLayout textInputLayout = getTextInputLayout();
    if (textInputLayout != null && this.興) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? textInputLayout.getGlobalVisibleRect(paramRect, paramPoint) : super.getGlobalVisibleRect(paramRect, paramPoint);
  }
  
  public CharSequence getHint() {
    TextInputLayout textInputLayout = getTextInputLayout();
    return (textInputLayout != null && textInputLayout.크) ? textInputLayout.getHint() : super.getHint();
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    TextInputLayout textInputLayout = getTextInputLayout();
    if (textInputLayout != null && textInputLayout.크 && super.getHint() == null && Build.MANUFACTURER.toLowerCase(Locale.ENGLISH).equals("meizu"))
      setHint(""); 
  }
  
  public final InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    if (inputConnection != null && paramEditorInfo.hintText == null)
      paramEditorInfo.hintText = getHintFromLayout(); 
    return inputConnection;
  }
  
  public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    TextInputLayout textInputLayout = getTextInputLayout();
    if (Build.VERSION.SDK_INT < 23 && textInputLayout != null) {
      Editable editable = getText();
      CharSequence charSequence1 = textInputLayout.getHint();
      boolean bool1 = TextUtils.isEmpty((CharSequence)editable);
      boolean bool2 = TextUtils.isEmpty(charSequence1);
      CharSequence charSequence2 = "";
      if ((bool2 ^ true) != 0) {
        charSequence1 = charSequence1.toString();
      } else {
        charSequence1 = "";
      } 
      if ((bool1 ^ true) != 0) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(editable);
        if (!TextUtils.isEmpty(charSequence1))
          charSequence2 = bm.恐(", ", (String)charSequence1); 
        stringBuilder.append((String)charSequence2);
        charSequence2 = stringBuilder.toString();
      } else if (!TextUtils.isEmpty(charSequence1)) {
        charSequence2 = charSequence1;
      } 
      paramAccessibilityNodeInfo.setText(charSequence2);
    } 
  }
  
  public final boolean requestRectangleOnScreen(Rect paramRect) {
    int i;
    TextInputLayout textInputLayout = getTextInputLayout();
    if (textInputLayout != null && this.興) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && paramRect != null) {
      i = textInputLayout.getHeight();
      int j = getHeight();
      int k = paramRect.left;
      int m = paramRect.top;
      int n = paramRect.right;
      int i1 = paramRect.bottom;
      paramRect = this.起;
      paramRect.set(k, m, n, i1 + i - j);
      return super.requestRectangleOnScreen(paramRect);
    } 
    return super.requestRectangleOnScreen(paramRect);
  }
  
  public void setTextInputLayoutFocusedRectEnabled(boolean paramBoolean) {
    this.興 = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\textfield\TextInputEditText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */