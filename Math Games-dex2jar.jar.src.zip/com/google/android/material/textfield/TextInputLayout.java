package com.google.android.material.textfield;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.LinearInterpolator;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import y.br;
import y.cr;
import y.dr;
import y.dt;
import y.dw;
import y.for;
import y.gt;
import y.ik;
import y.new;
import y.nul;
import y.oy0;
import y.qq;
import y.rw;
import y.u0;
import y.uj;
import y.vk;
import y.wk;
import y.xq;
import y.ym;
import y.yq;
import y.zv;
import y.ぱ;
import y.も;
import y.ブ;
import y.代;
import y.働;
import y.前;
import y.安;
import y.年;
import y.投;
import y.折;
import y.服;
import y.殻;
import y.海;
import y.男;
import y.老;
import y.若;
import y.買;
import y.그;
import y.동;
import y.렴;
import y.록;
import y.민;
import y.부;
import y.특;
import y.혹;

public class TextInputLayout extends LinearLayout {
  public ColorStateList あ;
  
  public ColorStateList う;
  
  public int か;
  
  public ColorDrawable く;
  
  public int ご;
  
  public ColorStateList し;
  
  public final 働 せ;
  
  public final LinkedHashSet た;
  
  public 부 ち;
  
  public ColorStateList ね;
  
  public boolean は;
  
  public int ふ;
  
  public boolean べ;
  
  public int ぼ;
  
  public CharSequence も;
  
  public 부 ゃ;
  
  public final CheckableImageButton ょ;
  
  public View.OnLongClickListener れ;
  
  public ColorStateList わ;
  
  public u0 ㅌ;
  
  public View.OnLongClickListener 俺;
  
  public Drawable 僕;
  
  public int 医;
  
  public CharSequence 噛;
  
  public final 若 壊;
  
  public int 婦;
  
  public ValueAnimator 家;
  
  public int 寝;
  
  public PorterDuff.Mode 少;
  
  public int 師;
  
  public boolean 帰;
  
  public ColorStateList 年;
  
  public boolean 弁;
  
  public final ym 怖;
  
  public final LinearLayout 恐;
  
  public 服 投;
  
  public boolean 政;
  
  public boolean 歩;
  
  public int 歯;
  
  public int 死;
  
  public boolean 治;
  
  public 服 泳;
  
  public final FrameLayout 淋;
  
  public int 産;
  
  public EditText 痒;
  
  public final FrameLayout 痛;
  
  public int 看;
  
  public PorterDuff.Mode 私;
  
  public int 科;
  
  public final CheckableImageButton 者;
  
  public CharSequence 臭;
  
  public int 興;
  
  public final 服 若;
  
  public boolean 触;
  
  public ColorStateList 護;
  
  public ColorStateList 赤;
  
  public int 起;
  
  public int 踊;
  
  public int 返;
  
  public boolean 코;
  
  public CharSequence 쾌;
  
  public boolean 크;
  
  public u0 큰;
  
  public u0 키;
  
  public wk 타;
  
  public boolean 탁;
  
  public final int 탄;
  
  public int 탈;
  
  public int 탐;
  
  public int 탑;
  
  public int 탕;
  
  public int 태;
  
  public int 택;
  
  public int 탱;
  
  public final Rect 터;
  
  public final Rect 테;
  
  public final RectF 토;
  
  public Typeface 톤;
  
  public ColorDrawable 톨;
  
  public int 통;
  
  public final LinkedHashSet 퇴;
  
  public int 투;
  
  public final SparseArray 퉁;
  
  public TextInputLayout(Context paramContext, AttributeSet paramAttributeSet) {}
  
  private 민 getEndIconDelegate() {
    SparseArray sparseArray = this.퉁;
    민 민 = (민)sparseArray.get(this.투);
    return (민 != null) ? 민 : (민)sparseArray.get(0);
  }
  
  private CheckableImageButton getEndIconToUpdateDummyDrawable() {
    boolean bool;
    CheckableImageButton checkableImageButton = this.ょ;
    if (checkableImageButton.getVisibility() == 0)
      return checkableImageButton; 
    if (this.투 != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool && 美()) ? this.者 : null;
  }
  
  private void setEditText(EditText paramEditText) {
    if (this.痒 == null) {
      if (this.투 != 3)
        boolean bool = paramEditText instanceof TextInputEditText; 
      this.痒 = paramEditText;
      int i = this.起;
      if (i != -1) {
        setMinEms(i);
      } else {
        setMinWidth(this.産);
      } 
      i = this.興;
      if (i != -1) {
        setMaxEms(i);
      } else {
        setMaxWidth(this.死);
      } 
      旨();
      setTextInputAccessibilityDelegate(new yq(this));
      Typeface typeface = this.痒.getTypeface();
      働 働1 = this.せ;
      働1.悲(typeface);
      float f = this.痒.getTextSize();
      if (働1.不 != f) {
        働1.不 = f;
        働1.不(false);
      } 
      i = Build.VERSION.SDK_INT;
      f = this.痒.getLetterSpacing();
      if (働1.큰 != f) {
        働1.큰 = f;
        働1.不(false);
      } 
      i = this.痒.getGravity();
      int j = i & 0xFFFFFF8F | 0x30;
      if (働1.旨 != j) {
        働1.旨 = j;
        働1.不(false);
      } 
      if (働1.美 != i) {
        働1.美 = i;
        働1.不(false);
      } 
      this.痒.addTextChangedListener((TextWatcher)new uj(2, this));
      if (this.ね == null)
        this.ね = this.痒.getHintTextColors(); 
      if (this.코) {
        if (TextUtils.isEmpty(this.쾌)) {
          CharSequence charSequence = this.痒.getHint();
          this.臭 = charSequence;
          setHint(charSequence);
          this.痒.setHint(null);
        } 
        this.크 = true;
      } 
      if (this.泳 != null)
        嬉(this.痒.getText().length()); 
      淋();
      this.壊.堅();
      this.怖.bringToFront();
      this.恐.bringToFront();
      this.痛.bringToFront();
      this.ょ.bringToFront();
      Iterator<折> iterator = this.퇴.iterator();
      while (iterator.hasNext())
        ((折)iterator.next()).硬(this); 
      興();
      if (!isEnabled())
        paramEditText.setEnabled(false); 
      痒(false, true);
      return;
    } 
    throw new IllegalArgumentException("We already have an EditText, can only have one");
  }
  
  private void setHintInternal(CharSequence paramCharSequence) {
    if (!TextUtils.equals(paramCharSequence, this.쾌)) {
      this.쾌 = paramCharSequence;
      働 働1 = this.せ;
      if (paramCharSequence == null || !TextUtils.equals(働1.帰, paramCharSequence)) {
        働1.帰 = paramCharSequence;
        働1.返 = null;
        Bitmap bitmap = 働1.泳;
        if (bitmap != null) {
          bitmap.recycle();
          働1.泳 = null;
        } 
        働1.不(false);
      } 
      if (!this.は)
        不(); 
    } 
  }
  
  private void setPlaceholderTextEnabled(boolean paramBoolean) {
    if (this.触 == paramBoolean)
      return; 
    if (paramBoolean) {
      服 服1 = this.投;
      if (服1 != null) {
        this.淋.addView((View)服1);
        this.投.setVisibility(0);
      } 
    } else {
      服 服1 = this.投;
      if (服1 != null)
        服1.setVisibility(8); 
      this.投 = null;
    } 
    this.触 = paramBoolean;
  }
  
  public static void ぱ(CheckableImageButton paramCheckableImageButton, View.OnLongClickListener paramOnLongClickListener) {
    boolean bool1;
    WeakHashMap weakHashMap = rw.硬;
    int i = Build.VERSION.SDK_INT;
    boolean bool = zv.硬((View)paramCheckableImageButton);
    boolean bool2 = false;
    i = 1;
    if (paramOnLongClickListener != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool || bool1)
      bool2 = true; 
    paramCheckableImageButton.setFocusable(bool2);
    paramCheckableImageButton.setClickable(bool);
    paramCheckableImageButton.setPressable(bool);
    paramCheckableImageButton.setLongClickable(bool1);
    if (!bool2)
      i = 2; 
    rw.踊((View)paramCheckableImageButton, i);
  }
  
  public static void 辛(ViewGroup paramViewGroup, boolean paramBoolean) {
    int j = paramViewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = paramViewGroup.getChildAt(i);
      view.setEnabled(paramBoolean);
      if (view instanceof ViewGroup)
        辛((ViewGroup)view, paramBoolean); 
    } 
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (paramView instanceof EditText) {
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(paramLayoutParams);
      layoutParams.gravity = layoutParams.gravity & 0xFFFFFF8F | 0x10;
      FrameLayout frameLayout = this.淋;
      frameLayout.addView(paramView, (ViewGroup.LayoutParams)layoutParams);
      frameLayout.setLayoutParams(paramLayoutParams);
      痛();
      setEditText((EditText)paramView);
      return;
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public final void dispatchProvideAutofillStructure(ViewStructure paramViewStructure, int paramInt) {
    EditText editText = this.痒;
    if (editText == null) {
      super.dispatchProvideAutofillStructure(paramViewStructure, paramInt);
      return;
    } 
    CharSequence charSequence = this.臭;
    int i = 0;
    if (charSequence != null) {
      boolean bool = this.크;
      this.크 = false;
      CharSequence charSequence1 = editText.getHint();
      this.痒.setHint(this.臭);
      try {
        super.dispatchProvideAutofillStructure(paramViewStructure, paramInt);
        return;
      } finally {
        this.痒.setHint(charSequence1);
        this.크 = bool;
      } 
    } 
    paramViewStructure.setAutofillId(getAutofillId());
    onProvideAutofillStructure(paramViewStructure, paramInt);
    onProvideAutofillVirtualStructure(paramViewStructure, paramInt);
    FrameLayout frameLayout = this.淋;
    paramViewStructure.setChildCount(frameLayout.getChildCount());
    while (i < frameLayout.getChildCount()) {
      View view = frameLayout.getChildAt(i);
      ViewStructure viewStructure = paramViewStructure.newChild(i);
      view.dispatchProvideAutofillStructure(viewStructure, paramInt);
      if (view == this.痒)
        viewStructure.setHint(getHint()); 
      i++;
    } 
  }
  
  public final void dispatchRestoreInstanceState(SparseArray paramSparseArray) {
    this.弁 = true;
    super.dispatchRestoreInstanceState(paramSparseArray);
    this.弁 = false;
  }
  
  public final void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    boolean bool = this.코;
    働 働1 = this.せ;
    if (bool) {
      働1.getClass();
      int i = paramCanvas.save();
      if (働1.返 != null && 働1.堅) {
        働1.ち.setTextSize(働1.寝);
        float f1 = 働1.怖;
        float f2 = 働1.恐;
        float f3 = 働1.踊;
        if (f3 != 1.0F)
          paramCanvas.scale(f3, f3, f1, f2); 
        paramCanvas.translate(f1, f2);
        働1.ㅌ.draw(paramCanvas);
        paramCanvas.restoreToCount(i);
      } 
    } 
    if (this.ㅌ != null) {
      u0 u01 = this.키;
      if (u01 != null) {
        u01.draw(paramCanvas);
        if (this.痒.isFocused()) {
          Rect rect1 = this.ㅌ.getBounds();
          Rect rect2 = this.키.getBounds();
          float f = 働1.熱;
          int i = rect2.centerX();
          int j = rect2.left;
          LinearInterpolator linearInterpolator = 前.硬;
          rect1.left = Math.round((j - i) * f) + i;
          rect1.right = Math.round(f * (rect2.right - i)) + i;
          this.ㅌ.draw(paramCanvas);
        } 
      } 
    } 
  }
  
  public final void drawableStateChanged() {
    // Byte code:
    //   0: aload_0
    //   1: getfield べ : Z
    //   4: ifeq -> 8
    //   7: return
    //   8: iconst_1
    //   9: istore_2
    //   10: aload_0
    //   11: iconst_1
    //   12: putfield べ : Z
    //   15: aload_0
    //   16: invokespecial drawableStateChanged : ()V
    //   19: aload_0
    //   20: invokevirtual getDrawableState : ()[I
    //   23: astore #4
    //   25: aload_0
    //   26: getfield せ : Ly/働;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnull -> 108
    //   34: aload_3
    //   35: aload #4
    //   37: putfield あ : [I
    //   40: aload_3
    //   41: getfield 苦 : Landroid/content/res/ColorStateList;
    //   44: astore #4
    //   46: aload #4
    //   48: ifnull -> 59
    //   51: aload #4
    //   53: invokevirtual isStateful : ()Z
    //   56: ifne -> 78
    //   59: aload_3
    //   60: getfield ぱ : Landroid/content/res/ColorStateList;
    //   63: astore #4
    //   65: aload #4
    //   67: ifnull -> 83
    //   70: aload #4
    //   72: invokevirtual isStateful : ()Z
    //   75: ifeq -> 83
    //   78: iconst_1
    //   79: istore_1
    //   80: goto -> 85
    //   83: iconst_0
    //   84: istore_1
    //   85: iload_1
    //   86: ifeq -> 99
    //   89: aload_3
    //   90: iconst_0
    //   91: invokevirtual 不 : (Z)V
    //   94: iconst_1
    //   95: istore_1
    //   96: goto -> 101
    //   99: iconst_0
    //   100: istore_1
    //   101: iload_1
    //   102: iconst_0
    //   103: ior
    //   104: istore_1
    //   105: goto -> 110
    //   108: iconst_0
    //   109: istore_1
    //   110: aload_0
    //   111: getfield 痒 : Landroid/widget/EditText;
    //   114: ifnull -> 142
    //   117: aload_0
    //   118: invokestatic 寂 : (Landroid/view/View;)Z
    //   121: ifeq -> 134
    //   124: aload_0
    //   125: invokevirtual isEnabled : ()Z
    //   128: ifeq -> 134
    //   131: goto -> 136
    //   134: iconst_0
    //   135: istore_2
    //   136: aload_0
    //   137: iload_2
    //   138: iconst_0
    //   139: invokevirtual 痒 : (ZZ)V
    //   142: aload_0
    //   143: invokevirtual 淋 : ()V
    //   146: aload_0
    //   147: invokevirtual 死 : ()V
    //   150: iload_1
    //   151: ifeq -> 158
    //   154: aload_0
    //   155: invokevirtual invalidate : ()V
    //   158: aload_0
    //   159: iconst_0
    //   160: putfield べ : Z
    //   163: return
  }
  
  public int getBaseline() {
    EditText editText = this.痒;
    if (editText != null) {
      int i = editText.getBaseline();
      int j = getPaddingTop();
      return 熱() + j + i;
    } 
    return super.getBaseline();
  }
  
  public u0 getBoxBackground() {
    int i = this.탈;
    if (i == 1 || i == 2)
      return this.큰; 
    throw new IllegalStateException();
  }
  
  public int getBoxBackgroundColor() {
    return this.탱;
  }
  
  public int getBoxBackgroundMode() {
    return this.탈;
  }
  
  public int getBoxCollapsedPaddingTop() {
    return this.탐;
  }
  
  public float getBoxCornerRadiusBottomEnd() {
    boolean bool = ik.ゃ((View)this);
    RectF rectF = this.토;
    return bool ? this.타.旨.硬(rectF) : this.타.美.硬(rectF);
  }
  
  public float getBoxCornerRadiusBottomStart() {
    boolean bool = ik.ゃ((View)this);
    RectF rectF = this.토;
    return bool ? this.타.美.硬(rectF) : this.타.旨.硬(rectF);
  }
  
  public float getBoxCornerRadiusTopEnd() {
    boolean bool = ik.ゃ((View)this);
    RectF rectF = this.토;
    return bool ? this.타.冷.硬(rectF) : this.타.寒.硬(rectF);
  }
  
  public float getBoxCornerRadiusTopStart() {
    boolean bool = ik.ゃ((View)this);
    RectF rectF = this.토;
    return bool ? this.타.寒.硬(rectF) : this.타.冷.硬(rectF);
  }
  
  public int getBoxStrokeColor() {
    return this.看;
  }
  
  public ColorStateList getBoxStrokeErrorColor() {
    return this.護;
  }
  
  public int getBoxStrokeWidth() {
    return this.탕;
  }
  
  public int getBoxStrokeWidthFocused() {
    return this.태;
  }
  
  public int getCounterMaxLength() {
    return this.返;
  }
  
  public CharSequence getCounterOverflowDescription() {
    if (this.帰 && this.歩) {
      服 服1 = this.泳;
      if (服1 != null)
        return 服1.getContentDescription(); 
    } 
    return null;
  }
  
  public ColorStateList getCounterOverflowTextColor() {
    return this.赤;
  }
  
  public ColorStateList getCounterTextColor() {
    return this.赤;
  }
  
  public ColorStateList getDefaultHintTextColor() {
    return this.ね;
  }
  
  public EditText getEditText() {
    return this.痒;
  }
  
  public CharSequence getEndIconContentDescription() {
    return this.者.getContentDescription();
  }
  
  public Drawable getEndIconDrawable() {
    return this.者.getDrawable();
  }
  
  public int getEndIconMode() {
    return this.투;
  }
  
  public CheckableImageButton getEndIconView() {
    return this.者;
  }
  
  public CharSequence getError() {
    若 若1 = this.壊;
    return 若1.ぱ ? 若1.辛 : null;
  }
  
  public CharSequence getErrorContentDescription() {
    return this.壊.嬉;
  }
  
  public int getErrorCurrentTextColors() {
    return this.壊.美();
  }
  
  public Drawable getErrorIconDrawable() {
    return this.ょ.getDrawable();
  }
  
  public final int getErrorTextCurrentColor() {
    return this.壊.美();
  }
  
  public CharSequence getHelperText() {
    若 若1 = this.壊;
    return 若1.怖 ? 若1.淋 : null;
  }
  
  public int getHelperTextCurrentTextColor() {
    服 服1 = this.壊.恐;
    return (服1 != null) ? 服1.getCurrentTextColor() : -1;
  }
  
  public CharSequence getHint() {
    return this.코 ? this.쾌 : null;
  }
  
  public final float getHintCollapsedTextHeight() {
    return this.せ.暑();
  }
  
  public final int getHintCurrentCollapsedTextColor() {
    働 働1 = this.せ;
    return 働1.冷(働1.苦);
  }
  
  public ColorStateList getHintTextColor() {
    return this.年;
  }
  
  public int getMaxEms() {
    return this.興;
  }
  
  public int getMaxWidth() {
    return this.死;
  }
  
  public int getMinEms() {
    return this.起;
  }
  
  public int getMinWidth() {
    return this.産;
  }
  
  @Deprecated
  public CharSequence getPasswordVisibilityToggleContentDescription() {
    return this.者.getContentDescription();
  }
  
  @Deprecated
  public Drawable getPasswordVisibilityToggleDrawable() {
    return this.者.getDrawable();
  }
  
  public CharSequence getPlaceholderText() {
    return this.触 ? this.噛 : null;
  }
  
  public int getPlaceholderTextAppearance() {
    return this.か;
  }
  
  public ColorStateList getPlaceholderTextColor() {
    return this.あ;
  }
  
  public CharSequence getPrefixText() {
    return this.怖.恐;
  }
  
  public ColorStateList getPrefixTextColor() {
    return this.怖.怖.getTextColors();
  }
  
  public TextView getPrefixTextView() {
    return (TextView)this.怖.怖;
  }
  
  public CharSequence getStartIconContentDescription() {
    return this.怖.痛.getContentDescription();
  }
  
  public Drawable getStartIconDrawable() {
    return this.怖.痛.getDrawable();
  }
  
  public CharSequence getSuffixText() {
    return this.も;
  }
  
  public ColorStateList getSuffixTextColor() {
    return this.若.getTextColors();
  }
  
  public TextView getSuffixTextView() {
    return (TextView)this.若;
  }
  
  public Typeface getTypeface() {
    return this.톤;
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.せ.美(paramConfiguration);
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    EditText editText = this.痒;
    if (editText != null) {
      ThreadLocal threadLocal = 동.硬;
      paramInt1 = editText.getWidth();
      paramInt2 = editText.getHeight();
      Rect rect = this.터;
      rect.set(0, 0, paramInt1, paramInt2);
      ThreadLocal<Matrix> threadLocal1 = 동.硬;
      Matrix matrix = threadLocal1.get();
      if (matrix == null) {
        matrix = new Matrix();
        threadLocal1.set(matrix);
      } else {
        matrix.reset();
      } 
      동.硬((ViewParent)this, (View)editText, matrix);
      ThreadLocal<RectF> threadLocal2 = 동.堅;
      RectF rectF2 = threadLocal2.get();
      RectF rectF1 = rectF2;
      if (rectF2 == null) {
        rectF1 = new RectF();
        threadLocal2.set(rectF1);
      } 
      rectF1.set(rect);
      matrix.mapRect(rectF1);
      rect.set((int)(rectF1.left + 0.5F), (int)(rectF1.top + 0.5F), (int)(rectF1.right + 0.5F), (int)(rectF1.bottom + 0.5F));
      u0 u01 = this.키;
      if (u01 != null) {
        paramInt1 = rect.bottom;
        paramInt2 = this.탕;
        u01.setBounds(rect.left, paramInt1 - paramInt2, rect.right, paramInt1);
      } 
      u01 = this.ㅌ;
      if (u01 != null) {
        paramInt1 = rect.bottom;
        paramInt2 = this.태;
        u01.setBounds(rect.left, paramInt1 - paramInt2, rect.right, paramInt1);
      } 
      if (this.코) {
        float f = this.痒.getTextSize();
        働 働1 = this.せ;
        if (働1.不 != f) {
          働1.不 = f;
          働1.不(false);
        } 
        paramInt1 = this.痒.getGravity();
        paramInt2 = paramInt1 & 0xFFFFFF8F | 0x30;
        if (働1.旨 != paramInt2) {
          働1.旨 = paramInt2;
          働1.不(false);
        } 
        if (働1.美 != paramInt1) {
          働1.美 = paramInt1;
          働1.不(false);
        } 
        if (this.痒 != null) {
          paramBoolean = ik.ゃ((View)this);
          paramInt1 = rect.bottom;
          Rect rect1 = this.테;
          rect1.bottom = paramInt1;
          paramInt1 = this.탈;
          if (paramInt1 != 1) {
            if (paramInt1 != 2) {
              rect1.left = 冷(rect.left, paramBoolean);
              rect1.top = getPaddingTop();
              rect1.right = 寒(rect.right, paramBoolean);
            } else {
              paramInt1 = rect.left;
              rect1.left = this.痒.getPaddingLeft() + paramInt1;
              rect.top -= 熱();
              rect.right -= this.痒.getPaddingRight();
            } 
          } else {
            rect1.left = 冷(rect.left, paramBoolean);
            rect.top += this.탐;
            rect1.right = 寒(rect.right, paramBoolean);
          } 
          paramInt2 = rect1.left;
          paramInt3 = rect1.top;
          paramInt4 = rect1.right;
          int i = rect1.bottom;
          Rect rect2 = 働1.冷;
          if (rect2.left == paramInt2 && rect2.top == paramInt3 && rect2.right == paramInt4 && rect2.bottom == i) {
            paramInt1 = 1;
          } else {
            paramInt1 = 0;
          } 
          if (paramInt1 == 0) {
            rect2.set(paramInt2, paramInt3, paramInt4, i);
            働1.か = true;
            働1.旨();
          } 
          if (this.痒 != null) {
            TextPaint textPaint = 働1.ゃ;
            textPaint.setTextSize(働1.不);
            textPaint.setTypeface(働1.起);
            paramInt1 = Build.VERSION.SDK_INT;
            textPaint.setLetterSpacing(働1.큰);
            f = -textPaint.ascent();
            paramInt1 = rect.left;
            rect1.left = this.痒.getCompoundPaddingLeft() + paramInt1;
            if (this.탈 == 1 && this.痒.getMinLines() <= 1) {
              paramInt1 = 1;
            } else {
              paramInt1 = 0;
            } 
            if (paramInt1 != 0) {
              paramInt1 = (int)(rect.centerY() - f / 2.0F);
            } else {
              paramInt1 = rect.top + this.痒.getCompoundPaddingTop();
            } 
            rect1.top = paramInt1;
            rect.right -= this.痒.getCompoundPaddingRight();
            if (this.탈 == 1 && this.痒.getMinLines() <= 1) {
              paramInt1 = 1;
            } else {
              paramInt1 = 0;
            } 
            if (paramInt1 != 0) {
              paramInt1 = (int)(rect1.top + f);
            } else {
              paramInt1 = rect.bottom - this.痒.getCompoundPaddingBottom();
            } 
            rect1.bottom = paramInt1;
            paramInt3 = rect1.left;
            paramInt4 = rect1.top;
            i = rect1.right;
            rect1 = 働1.暑;
            if (rect1.left == paramInt3 && rect1.top == paramInt4 && rect1.right == i && rect1.bottom == paramInt1) {
              paramInt2 = 1;
            } else {
              paramInt2 = 0;
            } 
            if (paramInt2 == 0) {
              rect1.set(paramInt3, paramInt4, i, paramInt1);
              働1.か = true;
              働1.旨();
            } 
            働1.不(false);
            if (暑() && !this.は) {
              不();
              return;
            } 
          } else {
            throw new IllegalStateException();
          } 
        } else {
          throw new IllegalStateException();
        } 
      } 
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: iload_2
    //   3: invokespecial onMeasure : (II)V
    //   6: aload_0
    //   7: getfield 痒 : Landroid/widget/EditText;
    //   10: ifnonnull -> 16
    //   13: goto -> 58
    //   16: aload_0
    //   17: getfield 恐 : Landroid/widget/LinearLayout;
    //   20: invokevirtual getMeasuredHeight : ()I
    //   23: aload_0
    //   24: getfield 怖 : Ly/ym;
    //   27: invokevirtual getMeasuredHeight : ()I
    //   30: invokestatic max : (II)I
    //   33: istore_1
    //   34: aload_0
    //   35: getfield 痒 : Landroid/widget/EditText;
    //   38: invokevirtual getMeasuredHeight : ()I
    //   41: iload_1
    //   42: if_icmpge -> 58
    //   45: aload_0
    //   46: getfield 痒 : Landroid/widget/EditText;
    //   49: iload_1
    //   50: invokevirtual setMinimumHeight : (I)V
    //   53: iconst_1
    //   54: istore_1
    //   55: goto -> 60
    //   58: iconst_0
    //   59: istore_1
    //   60: aload_0
    //   61: invokevirtual 寂 : ()Z
    //   64: istore_3
    //   65: iload_1
    //   66: ifne -> 73
    //   69: iload_3
    //   70: ifeq -> 90
    //   73: aload_0
    //   74: getfield 痒 : Landroid/widget/EditText;
    //   77: new y/xq
    //   80: dup
    //   81: aload_0
    //   82: iconst_1
    //   83: invokespecial <init> : (Lcom/google/android/material/textfield/TextInputLayout;I)V
    //   86: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   89: pop
    //   90: aload_0
    //   91: getfield 投 : Ly/服;
    //   94: ifnull -> 157
    //   97: aload_0
    //   98: getfield 痒 : Landroid/widget/EditText;
    //   101: astore #4
    //   103: aload #4
    //   105: ifnull -> 157
    //   108: aload #4
    //   110: invokevirtual getGravity : ()I
    //   113: istore_1
    //   114: aload_0
    //   115: getfield 投 : Ly/服;
    //   118: iload_1
    //   119: invokevirtual setGravity : (I)V
    //   122: aload_0
    //   123: getfield 投 : Ly/服;
    //   126: aload_0
    //   127: getfield 痒 : Landroid/widget/EditText;
    //   130: invokevirtual getCompoundPaddingLeft : ()I
    //   133: aload_0
    //   134: getfield 痒 : Landroid/widget/EditText;
    //   137: invokevirtual getCompoundPaddingTop : ()I
    //   140: aload_0
    //   141: getfield 痒 : Landroid/widget/EditText;
    //   144: invokevirtual getCompoundPaddingRight : ()I
    //   147: aload_0
    //   148: getfield 痒 : Landroid/widget/EditText;
    //   151: invokevirtual getCompoundPaddingBottom : ()I
    //   154: invokevirtual setPadding : (IIII)V
    //   157: aload_0
    //   158: invokevirtual 興 : ()V
    //   161: return
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof br)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    br br = (br)paramParcelable;
    super.onRestoreInstanceState(((for)br).淋);
    setError(br.恐);
    if (br.痛) {
      xq xq = new xq(this, 0);
      this.者.post((Runnable)xq);
    } 
    setHint(br.痒);
    setHelperText(br.臭);
    setPlaceholderText(br.起);
    requestLayout();
  }
  
  public final void onRtlPropertiesChanged(int paramInt) {
    float f1;
    float f2;
    float f3;
    float f4;
    boolean bool1;
    super.onRtlPropertiesChanged(paramInt);
    boolean bool = false;
    if (paramInt == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    boolean bool2 = this.탁;
    if (bool1 != bool2) {
      paramInt = bool;
      if (bool1) {
        paramInt = bool;
        if (!bool2)
          paramInt = 1; 
      } 
      특 특 = this.타.冷;
      RectF rectF = this.토;
      f3 = 특.硬(rectF);
      f2 = this.타.寒.硬(rectF);
      float f = this.타.旨.硬(rectF);
      f4 = this.타.美.硬(rectF);
      if (paramInt != 0) {
        f1 = f3;
      } else {
        f1 = f2;
      } 
      if (paramInt != 0)
        f3 = f2; 
      if (paramInt != 0) {
        f2 = f;
      } else {
        f2 = f4;
      } 
      if (paramInt != 0)
        f = f4; 
      bool1 = ik.ゃ((View)this);
      this.탁 = bool1;
      if (bool1) {
        f4 = f3;
      } else {
        f4 = f1;
      } 
      if (!bool1)
        f1 = f3; 
      if (bool1) {
        f3 = f;
      } else {
        f3 = f2;
      } 
      if (!bool1)
        f2 = f; 
      u0 u01 = this.큰;
      if (u01 != null && u01.淋.硬.冷.硬(u01.美()) == f4) {
        u01 = this.큰;
        if (u01.淋.硬.寒.硬(u01.美()) == f1) {
          u01 = this.큰;
          if (u01.淋.硬.旨.硬(u01.美()) == f3) {
            u01 = this.큰;
            if (u01.淋.硬.美.硬(u01.美()) != f2) {
              wk wk2 = this.타;
              wk2.getClass();
              vk vk1 = new vk(wk2);
              vk1.冷 = new new(f4);
              vk1.寒 = new new(f1);
              vk1.旨 = new new(f3);
              vk1.美 = new new(f2);
              this.타 = new wk(vk1);
              堅();
              return;
            } 
            return;
          } 
        } 
      } 
    } else {
      return;
    } 
    wk wk1 = this.타;
    wk1.getClass();
    vk vk = new vk(wk1);
    vk.冷 = new new(f4);
    vk.寒 = new new(f1);
    vk.旨 = new new(f3);
    vk.美 = new new(f2);
    this.타 = new wk(vk);
    堅();
  }
  
  public final Parcelable onSaveInstanceState() {
    br br = new br(super.onSaveInstanceState());
    if (this.壊.冷())
      br.恐 = getError(); 
    int i = this.투;
    boolean bool = true;
    if (i != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0 || !this.者.isChecked())
      bool = false; 
    br.痛 = bool;
    br.痒 = getHint();
    br.臭 = getHelperText();
    br.起 = getPlaceholderText();
    return (Parcelable)br;
  }
  
  public void setBoxBackgroundColor(int paramInt) {
    if (this.탱 != paramInt) {
      this.탱 = paramInt;
      this.師 = paramInt;
      this.婦 = paramInt;
      this.歯 = paramInt;
      堅();
    } 
  }
  
  public void setBoxBackgroundColorResource(int paramInt) {
    setBoxBackgroundColor(殻.堅(getContext(), paramInt));
  }
  
  public void setBoxBackgroundColorStateList(ColorStateList paramColorStateList) {
    int i = paramColorStateList.getDefaultColor();
    this.師 = i;
    this.탱 = i;
    this.ふ = paramColorStateList.getColorForState(new int[] { -16842910 }, -1);
    this.婦 = paramColorStateList.getColorForState(new int[] { 16842908, 16842910 }, -1);
    this.歯 = paramColorStateList.getColorForState(new int[] { 16843623, 16842910 }, -1);
    堅();
  }
  
  public void setBoxBackgroundMode(int paramInt) {
    if (paramInt == this.탈)
      return; 
    this.탈 = paramInt;
    if (this.痒 != null)
      旨(); 
  }
  
  public void setBoxCollapsedPaddingTop(int paramInt) {
    this.탐 = paramInt;
  }
  
  public void setBoxStrokeColor(int paramInt) {
    if (this.看 != paramInt) {
      this.看 = paramInt;
      死();
    } 
  }
  
  public void setBoxStrokeColorStateList(ColorStateList paramColorStateList) {
    if (paramColorStateList.isStateful()) {
      this.医 = paramColorStateList.getDefaultColor();
      this.科 = paramColorStateList.getColorForState(new int[] { -16842910 }, -1);
      this.ご = paramColorStateList.getColorForState(new int[] { 16843623, 16842910 }, -1);
      this.看 = paramColorStateList.getColorForState(new int[] { 16842908, 16842910 }, -1);
    } else if (this.看 != paramColorStateList.getDefaultColor()) {
      this.看 = paramColorStateList.getDefaultColor();
    } 
    死();
  }
  
  public void setBoxStrokeErrorColor(ColorStateList paramColorStateList) {
    if (this.護 != paramColorStateList) {
      this.護 = paramColorStateList;
      死();
    } 
  }
  
  public void setBoxStrokeWidth(int paramInt) {
    this.탕 = paramInt;
    死();
  }
  
  public void setBoxStrokeWidthFocused(int paramInt) {
    this.태 = paramInt;
    死();
  }
  
  public void setBoxStrokeWidthFocusedResource(int paramInt) {
    setBoxStrokeWidthFocused(getResources().getDimensionPixelSize(paramInt));
  }
  
  public void setBoxStrokeWidthResource(int paramInt) {
    setBoxStrokeWidth(getResources().getDimensionPixelSize(paramInt));
  }
  
  public void setCounterEnabled(boolean paramBoolean) {
    if (this.帰 != paramBoolean) {
      EditText editText;
      若 若1 = this.壊;
      if (paramBoolean) {
        服 服1 = new 服(getContext(), null);
        this.泳 = 服1;
        服1.setId(2131231361);
        Typeface typeface = this.톤;
        if (typeface != null)
          this.泳.setTypeface(typeface); 
        this.泳.setMaxLines(1);
        若1.硬((TextView)this.泳, 2);
        ik.탕((ViewGroup.MarginLayoutParams)this.泳.getLayoutParams(), getResources().getDimensionPixelOffset(2131100333));
        悲();
        if (this.泳 != null) {
          int i;
          editText = this.痒;
          if (editText == null) {
            i = 0;
          } else {
            i = editText.getText().length();
          } 
          嬉(i);
        } 
      } else {
        editText.不((TextView)this.泳, 2);
        this.泳 = null;
      } 
      this.帰 = paramBoolean;
    } 
  }
  
  public void setCounterMaxLength(int paramInt) {
    if (this.返 != paramInt) {
      if (paramInt > 0) {
        this.返 = paramInt;
      } else {
        this.返 = -1;
      } 
      if (this.帰 && this.泳 != null) {
        EditText editText = this.痒;
        if (editText == null) {
          paramInt = 0;
        } else {
          paramInt = editText.getText().length();
        } 
        嬉(paramInt);
      } 
    } 
  }
  
  public void setCounterOverflowTextAppearance(int paramInt) {
    if (this.踊 != paramInt) {
      this.踊 = paramInt;
      悲();
    } 
  }
  
  public void setCounterOverflowTextColor(ColorStateList paramColorStateList) {
    if (this.わ != paramColorStateList) {
      this.わ = paramColorStateList;
      悲();
    } 
  }
  
  public void setCounterTextAppearance(int paramInt) {
    if (this.寝 != paramInt) {
      this.寝 = paramInt;
      悲();
    } 
  }
  
  public void setCounterTextColor(ColorStateList paramColorStateList) {
    if (this.赤 != paramColorStateList) {
      this.赤 = paramColorStateList;
      悲();
    } 
  }
  
  public void setDefaultHintTextColor(ColorStateList paramColorStateList) {
    this.ね = paramColorStateList;
    this.年 = paramColorStateList;
    if (this.痒 != null)
      痒(false, false); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    辛((ViewGroup)this, paramBoolean);
    super.setEnabled(paramBoolean);
  }
  
  public void setEndIconActivated(boolean paramBoolean) {
    this.者.setActivated(paramBoolean);
  }
  
  public void setEndIconCheckable(boolean paramBoolean) {
    this.者.setCheckable(paramBoolean);
  }
  
  public void setEndIconContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getResources().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setEndIconContentDescription(charSequence);
  }
  
  public void setEndIconContentDescription(CharSequence paramCharSequence) {
    if (getEndIconContentDescription() != paramCharSequence)
      this.者.setContentDescription(paramCharSequence); 
  }
  
  public void setEndIconDrawable(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setEndIconDrawable(drawable);
  }
  
  public void setEndIconDrawable(Drawable paramDrawable) {
    CheckableImageButton checkableImageButton = this.者;
    checkableImageButton.setImageDrawable(paramDrawable);
    if (paramDrawable != null) {
      oy0.堅(this, checkableImageButton, this.し, this.私);
      oy0.탕(this, checkableImageButton, this.し);
    } 
  }
  
  public void setEndIconMode(int paramInt) {
    int i = this.투;
    if (i == paramInt)
      return; 
    this.투 = paramInt;
    Iterator<買> iterator = this.た.iterator();
    while (true) {
      boolean bool1 = iterator.hasNext();
      boolean bool = true;
      if (bool1) {
        AccessibilityManager accessibilityManager;
        CheckableImageButton checkableImageButton;
        男 男;
        AutoCompleteTextView autoCompleteTextView;
        EditText editText2;
        買 買 = iterator.next();
        int j = 買.硬;
        민 민 = 買.堅;
        switch (j) {
          case 1:
            autoCompleteTextView = (AutoCompleteTextView)getEditText();
            if (autoCompleteTextView != null && i == 3) {
              autoCompleteTextView.post((Runnable)new 렴(買, 1, autoCompleteTextView));
              if (autoCompleteTextView.getOnFocusChangeListener() == ((록)민).寒)
                autoCompleteTextView.setOnFocusChangeListener(null); 
              autoCompleteTextView.setOnTouchListener(null);
              if (록.痒)
                autoCompleteTextView.setOnDismissListener(null); 
            } 
            if (i == 3) {
              록 록 = (록)민;
              removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)록.辛);
              accessibilityManager = 록.怖;
              if (accessibilityManager != null) {
                男 = 록.ぱ;
                j = Build.VERSION.SDK_INT;
                海.堅(accessibilityManager, (老)男);
              } 
            } 
            continue;
          case 0:
            editText2 = getEditText();
            if (editText2 != null && i == 2) {
              editText2.post((Runnable)new ブ(accessibilityManager, 29, editText2));
              View.OnFocusChangeListener onFocusChangeListener = editText2.getOnFocusChangeListener();
              代 代 = (代)男;
              if (onFocusChangeListener == 代.寒)
                editText2.setOnFocusChangeListener(null); 
              checkableImageButton = ((민)代).熱;
              if (checkableImageButton.getOnFocusChangeListener() == 代.寒)
                checkableImageButton.setOnFocusChangeListener(null); 
            } 
            continue;
        } 
        EditText editText1 = getEditText();
        if (editText1 != null && i == 1) {
          editText1.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
          editText1.post((Runnable)new 렴(checkableImageButton, 2, editText1));
        } 
        continue;
      } 
      if (paramInt == 0)
        bool = false; 
      setEndIconVisible(bool);
      if (getEndIconDelegate().堅(this.탈)) {
        getEndIconDelegate().硬();
        ColorStateList colorStateList = this.し;
        PorterDuff.Mode mode = this.私;
        oy0.堅(this, this.者, colorStateList, mode);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder("The current box background mode ");
      stringBuilder.append(this.탈);
      stringBuilder.append(" is not supported by the end icon mode ");
      stringBuilder.append(paramInt);
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public void setEndIconOnClickListener(View.OnClickListener paramOnClickListener) {
    View.OnLongClickListener onLongClickListener = this.れ;
    CheckableImageButton checkableImageButton = this.者;
    checkableImageButton.setOnClickListener(paramOnClickListener);
    ぱ(checkableImageButton, onLongClickListener);
  }
  
  public void setEndIconOnLongClickListener(View.OnLongClickListener paramOnLongClickListener) {
    this.れ = paramOnLongClickListener;
    CheckableImageButton checkableImageButton = this.者;
    checkableImageButton.setOnLongClickListener(paramOnLongClickListener);
    ぱ(checkableImageButton, paramOnLongClickListener);
  }
  
  public void setEndIconTintList(ColorStateList paramColorStateList) {
    if (this.し != paramColorStateList) {
      this.し = paramColorStateList;
      oy0.堅(this, this.者, paramColorStateList, this.私);
    } 
  }
  
  public void setEndIconTintMode(PorterDuff.Mode paramMode) {
    if (this.私 != paramMode) {
      this.私 = paramMode;
      oy0.堅(this, this.者, this.し, paramMode);
    } 
  }
  
  public void setEndIconVisible(boolean paramBoolean) {
    if (美() != paramBoolean) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      this.者.setVisibility(b);
      怖();
      興();
      寂();
    } 
  }
  
  public void setError(CharSequence paramCharSequence) {
    若 若1 = this.壊;
    if (!若1.ぱ) {
      if (TextUtils.isEmpty(paramCharSequence))
        return; 
      setErrorEnabled(true);
    } 
    if (!TextUtils.isEmpty(paramCharSequence)) {
      若1.熱();
      若1.辛 = paramCharSequence;
      若1.苦.setText(paramCharSequence);
      int i = 若1.旨;
      if (i != 1)
        若1.不 = 1; 
      若1.ぱ(i, 若1.不, 若1.辛((TextView)若1.苦, paramCharSequence));
      return;
    } 
    若1.旨();
  }
  
  public void setErrorContentDescription(CharSequence paramCharSequence) {
    若 若1 = this.壊;
    若1.嬉 = paramCharSequence;
    服 服1 = 若1.苦;
    if (服1 != null)
      服1.setContentDescription(paramCharSequence); 
  }
  
  public void setErrorEnabled(boolean paramBoolean) {
    CharSequence charSequence;
    若 若1 = this.壊;
    if (若1.ぱ == paramBoolean)
      return; 
    若1.熱();
    TextInputLayout textInputLayout = 若1.堅;
    if (paramBoolean) {
      服 服2 = new 服(若1.硬, null);
      若1.苦 = 服2;
      服2.setId(2131231362);
      int i = Build.VERSION.SDK_INT;
      若1.苦.setTextAlignment(5);
      Typeface typeface = 若1.臭;
      if (typeface != null)
        若1.苦.setTypeface(typeface); 
      i = 若1.悲;
      若1.悲 = i;
      服 服1 = 若1.苦;
      if (服1 != null)
        textInputLayout.苦((TextView)服1, i); 
      ColorStateList colorStateList = 若1.寂;
      若1.寂 = colorStateList;
      服1 = 若1.苦;
      if (服1 != null && colorStateList != null)
        服1.setTextColor(colorStateList); 
      charSequence = 若1.嬉;
      若1.嬉 = charSequence;
      服1 = 若1.苦;
      if (服1 != null)
        服1.setContentDescription(charSequence); 
      若1.苦.setVisibility(4);
      dw.寒((View)若1.苦, 1);
      若1.硬((TextView)若1.苦, 0);
    } else {
      若1.旨();
      若1.不((TextView)若1.苦, 0);
      若1.苦 = null;
      charSequence.淋();
      charSequence.死();
    } 
    若1.ぱ = paramBoolean;
  }
  
  public void setErrorIconDrawable(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setErrorIconDrawable(drawable);
    oy0.탕(this, this.ょ, this.う);
  }
  
  public void setErrorIconDrawable(Drawable paramDrawable) {
    CheckableImageButton checkableImageButton = this.ょ;
    checkableImageButton.setImageDrawable(paramDrawable);
    恐();
    oy0.堅(this, checkableImageButton, this.う, this.少);
  }
  
  public void setErrorIconOnClickListener(View.OnClickListener paramOnClickListener) {
    View.OnLongClickListener onLongClickListener = this.俺;
    CheckableImageButton checkableImageButton = this.ょ;
    checkableImageButton.setOnClickListener(paramOnClickListener);
    ぱ(checkableImageButton, onLongClickListener);
  }
  
  public void setErrorIconOnLongClickListener(View.OnLongClickListener paramOnLongClickListener) {
    this.俺 = paramOnLongClickListener;
    CheckableImageButton checkableImageButton = this.ょ;
    checkableImageButton.setOnLongClickListener(paramOnLongClickListener);
    ぱ(checkableImageButton, paramOnLongClickListener);
  }
  
  public void setErrorIconTintList(ColorStateList paramColorStateList) {
    if (this.う != paramColorStateList) {
      this.う = paramColorStateList;
      oy0.堅(this, this.ょ, paramColorStateList, this.少);
    } 
  }
  
  public void setErrorIconTintMode(PorterDuff.Mode paramMode) {
    if (this.少 != paramMode) {
      this.少 = paramMode;
      oy0.堅(this, this.ょ, this.う, paramMode);
    } 
  }
  
  public void setErrorTextAppearance(int paramInt) {
    若 若1 = this.壊;
    若1.悲 = paramInt;
    服 服1 = 若1.苦;
    if (服1 != null)
      若1.堅.苦((TextView)服1, paramInt); 
  }
  
  public void setErrorTextColor(ColorStateList paramColorStateList) {
    若 若1 = this.壊;
    若1.寂 = paramColorStateList;
    服 服1 = 若1.苦;
    if (服1 != null && paramColorStateList != null)
      服1.setTextColor(paramColorStateList); 
  }
  
  public void setExpandedHintEnabled(boolean paramBoolean) {
    if (this.政 != paramBoolean) {
      this.政 = paramBoolean;
      痒(false, false);
    } 
  }
  
  public void setHelperText(CharSequence paramCharSequence) {
    boolean bool = TextUtils.isEmpty(paramCharSequence);
    若 若1 = this.壊;
    if (bool) {
      if (若1.怖) {
        setHelperTextEnabled(false);
        return;
      } 
    } else {
      if (!若1.怖)
        setHelperTextEnabled(true); 
      若1.熱();
      若1.淋 = paramCharSequence;
      若1.恐.setText(paramCharSequence);
      int i = 若1.旨;
      if (i != 2)
        若1.不 = 2; 
      若1.ぱ(i, 若1.不, 若1.辛((TextView)若1.恐, paramCharSequence));
    } 
  }
  
  public void setHelperTextColor(ColorStateList paramColorStateList) {
    若 若1 = this.壊;
    若1.痒 = paramColorStateList;
    服 服1 = 若1.恐;
    if (服1 != null && paramColorStateList != null)
      服1.setTextColor(paramColorStateList); 
  }
  
  public void setHelperTextEnabled(boolean paramBoolean) {
    若 若1 = this.壊;
    if (若1.怖 == paramBoolean)
      return; 
    若1.熱();
    if (paramBoolean) {
      服 服2 = new 服(若1.硬, null);
      若1.恐 = 服2;
      服2.setId(2131231363);
      int i = Build.VERSION.SDK_INT;
      若1.恐.setTextAlignment(5);
      Typeface typeface = 若1.臭;
      if (typeface != null)
        若1.恐.setTypeface(typeface); 
      若1.恐.setVisibility(4);
      dw.寒((View)若1.恐, 1);
      i = 若1.痛;
      若1.痛 = i;
      服 服1 = 若1.恐;
      if (服1 != null)
        年.わ((TextView)服1, i); 
      ColorStateList colorStateList = 若1.痒;
      若1.痒 = colorStateList;
      服 服3 = 若1.恐;
      if (服3 != null && colorStateList != null)
        服3.setTextColor(colorStateList); 
      若1.硬((TextView)若1.恐, 1);
      若1.恐.setAccessibilityDelegate((View.AccessibilityDelegate)new も(若1));
    } else {
      若1.熱();
      int i = 若1.旨;
      if (i == 2)
        若1.不 = 0; 
      若1.ぱ(i, 若1.不, 若1.辛((TextView)若1.恐, ""));
      若1.不((TextView)若1.恐, 1);
      若1.恐 = null;
      TextInputLayout textInputLayout = 若1.堅;
      textInputLayout.淋();
      textInputLayout.死();
    } 
    若1.怖 = paramBoolean;
  }
  
  public void setHelperTextTextAppearance(int paramInt) {
    若 若1 = this.壊;
    若1.痛 = paramInt;
    服 服1 = 若1.恐;
    if (服1 != null)
      年.わ((TextView)服1, paramInt); 
  }
  
  public void setHint(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getResources().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setHint(charSequence);
  }
  
  public void setHint(CharSequence paramCharSequence) {
    if (this.코) {
      setHintInternal(paramCharSequence);
      sendAccessibilityEvent(2048);
    } 
  }
  
  public void setHintAnimationEnabled(boolean paramBoolean) {
    this.治 = paramBoolean;
  }
  
  public void setHintEnabled(boolean paramBoolean) {
    if (paramBoolean != this.코) {
      this.코 = paramBoolean;
      if (!paramBoolean) {
        this.크 = false;
        if (!TextUtils.isEmpty(this.쾌) && TextUtils.isEmpty(this.痒.getHint()))
          this.痒.setHint(this.쾌); 
        setHintInternal(null);
      } else {
        CharSequence charSequence = this.痒.getHint();
        if (!TextUtils.isEmpty(charSequence)) {
          if (TextUtils.isEmpty(this.쾌))
            setHint(charSequence); 
          this.痒.setHint(null);
        } 
        this.크 = true;
      } 
      if (this.痒 != null)
        痛(); 
    } 
  }
  
  public void setHintTextAppearance(int paramInt) {
    働 働1 = this.せ;
    View view = 働1.硬;
    qq qq = new qq(view.getContext(), paramInt);
    ColorStateList colorStateList = qq.辛;
    if (colorStateList != null)
      働1.苦 = colorStateList; 
    float f = qq.ぱ;
    if (f != 0.0F)
      働1.辛 = f; 
    colorStateList = qq.硬;
    if (colorStateList != null)
      働1.쾌 = colorStateList; 
    働1.若 = qq.冷;
    働1.코 = qq.寒;
    働1.も = qq.美;
    働1.크 = qq.不;
    投 投 = 働1.壊;
    if (投 != null)
      投.탱 = true; 
    혹 혹 = new 혹(13, 働1);
    qq.硬();
    働1.壊 = new 投(혹, qq.悲);
    qq.熱(view.getContext(), (年)働1.壊);
    働1.不(false);
    this.年 = 働1.苦;
    if (this.痒 != null) {
      痒(false, false);
      痛();
    } 
  }
  
  public void setHintTextColor(ColorStateList paramColorStateList) {
    if (this.年 != paramColorStateList) {
      if (this.ね == null)
        this.せ.辛(paramColorStateList); 
      this.年 = paramColorStateList;
      if (this.痒 != null)
        痒(false, false); 
    } 
  }
  
  public void setMaxEms(int paramInt) {
    this.興 = paramInt;
    EditText editText = this.痒;
    if (editText != null && paramInt != -1)
      editText.setMaxEms(paramInt); 
  }
  
  public void setMaxWidth(int paramInt) {
    this.死 = paramInt;
    EditText editText = this.痒;
    if (editText != null && paramInt != -1)
      editText.setMaxWidth(paramInt); 
  }
  
  public void setMaxWidthResource(int paramInt) {
    setMaxWidth(getContext().getResources().getDimensionPixelSize(paramInt));
  }
  
  public void setMinEms(int paramInt) {
    this.起 = paramInt;
    EditText editText = this.痒;
    if (editText != null && paramInt != -1)
      editText.setMinEms(paramInt); 
  }
  
  public void setMinWidth(int paramInt) {
    this.産 = paramInt;
    EditText editText = this.痒;
    if (editText != null && paramInt != -1)
      editText.setMinWidth(paramInt); 
  }
  
  public void setMinWidthResource(int paramInt) {
    setMinWidth(getContext().getResources().getDimensionPixelSize(paramInt));
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getResources().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setPasswordVisibilityToggleContentDescription(charSequence);
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleContentDescription(CharSequence paramCharSequence) {
    this.者.setContentDescription(paramCharSequence);
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleDrawable(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setPasswordVisibilityToggleDrawable(drawable);
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleDrawable(Drawable paramDrawable) {
    this.者.setImageDrawable(paramDrawable);
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleEnabled(boolean paramBoolean) {
    if (paramBoolean && this.투 != 1) {
      setEndIconMode(1);
      return;
    } 
    if (!paramBoolean)
      setEndIconMode(0); 
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleTintList(ColorStateList paramColorStateList) {
    this.し = paramColorStateList;
    oy0.堅(this, this.者, paramColorStateList, this.私);
  }
  
  @Deprecated
  public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode paramMode) {
    this.私 = paramMode;
    oy0.堅(this, this.者, this.し, paramMode);
  }
  
  public void setPlaceholderText(CharSequence paramCharSequence) {
    if (this.投 == null) {
      服 服1 = new 服(getContext(), null);
      this.投 = 服1;
      服1.setId(2131231364);
      rw.踊((View)this.投, 2);
      부 부1 = new 부();
      ((dt)부1).恐 = 87L;
      LinearInterpolator linearInterpolator = 前.硬;
      ((dt)부1).痛 = (TimeInterpolator)linearInterpolator;
      this.ち = 부1;
      ((dt)부1).怖 = 67L;
      부1 = new 부();
      ((dt)부1).恐 = 87L;
      ((dt)부1).痛 = (TimeInterpolator)linearInterpolator;
      this.ゃ = 부1;
      setPlaceholderTextAppearance(this.か);
      setPlaceholderTextColor(this.あ);
    } 
    boolean bool = TextUtils.isEmpty(paramCharSequence);
    int i = 0;
    if (bool) {
      setPlaceholderTextEnabled(false);
    } else {
      if (!this.触)
        setPlaceholderTextEnabled(true); 
      this.噛 = paramCharSequence;
    } 
    EditText editText = this.痒;
    if (editText != null)
      i = editText.getText().length(); 
    臭(i);
  }
  
  public void setPlaceholderTextAppearance(int paramInt) {
    this.か = paramInt;
    服 服1 = this.投;
    if (服1 != null)
      年.わ((TextView)服1, paramInt); 
  }
  
  public void setPlaceholderTextColor(ColorStateList paramColorStateList) {
    if (this.あ != paramColorStateList) {
      this.あ = paramColorStateList;
      服 服1 = this.投;
      if (服1 != null && paramColorStateList != null)
        服1.setTextColor(paramColorStateList); 
    } 
  }
  
  public void setPrefixText(CharSequence paramCharSequence) {
    CharSequence charSequence;
    ym ym1 = this.怖;
    ym1.getClass();
    if (TextUtils.isEmpty(paramCharSequence)) {
      charSequence = null;
    } else {
      charSequence = paramCharSequence;
    } 
    ym1.恐 = charSequence;
    ym1.怖.setText(paramCharSequence);
    ym1.暑();
  }
  
  public void setPrefixTextAppearance(int paramInt) {
    年.わ((TextView)this.怖.怖, paramInt);
  }
  
  public void setPrefixTextColor(ColorStateList paramColorStateList) {
    this.怖.怖.setTextColor(paramColorStateList);
  }
  
  public void setStartIconCheckable(boolean paramBoolean) {
    this.怖.痛.setCheckable(paramBoolean);
  }
  
  public void setStartIconContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getResources().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setStartIconContentDescription(charSequence);
  }
  
  public void setStartIconContentDescription(CharSequence paramCharSequence) {
    CheckableImageButton checkableImageButton = this.怖.痛;
    if (checkableImageButton.getContentDescription() != paramCharSequence)
      checkableImageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setStartIconDrawable(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = 年.痛(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStartIconDrawable(drawable);
  }
  
  public void setStartIconDrawable(Drawable paramDrawable) {
    this.怖.硬(paramDrawable);
  }
  
  public void setStartIconOnClickListener(View.OnClickListener paramOnClickListener) {
    ym ym1 = this.怖;
    View.OnLongClickListener onLongClickListener = ym1.起;
    CheckableImageButton checkableImageButton = ym1.痛;
    checkableImageButton.setOnClickListener(paramOnClickListener);
    oy0.테(checkableImageButton, onLongClickListener);
  }
  
  public void setStartIconOnLongClickListener(View.OnLongClickListener paramOnLongClickListener) {
    ym ym1 = this.怖;
    ym1.起 = paramOnLongClickListener;
    CheckableImageButton checkableImageButton = ym1.痛;
    checkableImageButton.setOnLongClickListener(paramOnLongClickListener);
    oy0.테(checkableImageButton, paramOnLongClickListener);
  }
  
  public void setStartIconTintList(ColorStateList paramColorStateList) {
    ym ym1 = this.怖;
    if (ym1.痒 != paramColorStateList) {
      ym1.痒 = paramColorStateList;
      PorterDuff.Mode mode = ym1.臭;
      oy0.堅(ym1.淋, ym1.痛, paramColorStateList, mode);
    } 
  }
  
  public void setStartIconTintMode(PorterDuff.Mode paramMode) {
    ym ym1 = this.怖;
    if (ym1.臭 != paramMode) {
      ym1.臭 = paramMode;
      ColorStateList colorStateList = ym1.痒;
      oy0.堅(ym1.淋, ym1.痛, colorStateList, paramMode);
    } 
  }
  
  public void setStartIconVisible(boolean paramBoolean) {
    this.怖.堅(paramBoolean);
  }
  
  public void setSuffixText(CharSequence paramCharSequence) {
    CharSequence charSequence;
    if (TextUtils.isEmpty(paramCharSequence)) {
      charSequence = null;
    } else {
      charSequence = paramCharSequence;
    } 
    this.も = charSequence;
    this.若.setText(paramCharSequence);
    産();
  }
  
  public void setSuffixTextAppearance(int paramInt) {
    年.わ((TextView)this.若, paramInt);
  }
  
  public void setSuffixTextColor(ColorStateList paramColorStateList) {
    this.若.setTextColor(paramColorStateList);
  }
  
  public void setTextInputAccessibilityDelegate(yq paramyq) {
    EditText editText = this.痒;
    if (editText != null)
      rw.帰((View)editText, (nul)paramyq); 
  }
  
  public void setTypeface(Typeface paramTypeface) {
    if (paramTypeface != this.톤) {
      this.톤 = paramTypeface;
      this.せ.悲(paramTypeface);
      若 若1 = this.壊;
      if (paramTypeface != 若1.臭) {
        若1.臭 = paramTypeface;
        服 服3 = 若1.苦;
        if (服3 != null)
          服3.setTypeface(paramTypeface); 
        服 服2 = 若1.恐;
        if (服2 != null)
          服2.setTypeface(paramTypeface); 
      } 
      服 服1 = this.泳;
      if (服1 != null)
        服1.setTypeface(paramTypeface); 
    } 
  }
  
  public final void 不() {
    float f1;
    float f2;
    if (!暑())
      return; 
    int i = this.痒.getWidth();
    int j = this.痒.getGravity();
    働 働1 = this.せ;
    boolean bool = 働1.堅(働1.帰);
    働1.歩 = bool;
    Rect rect = 働1.冷;
    if (j == 17 || (j & 0x7) == 1) {
      f1 = i / 2.0F;
      f2 = 働1.타 / 2.0F;
    } else {
      int k;
      if ((j & 0x800005) == 8388613 || (j & 0x5) == 5) {
        if (bool) {
          k = rect.left;
        } else {
          float f = rect.right;
          f2 = 働1.타;
          f -= f2;
        } 
      } else {
        float f;
        if (bool) {
          f = rect.right;
          f2 = 働1.타;
        } else {
          k = rect.left;
          f = k;
        } 
        f -= f2;
      } 
      f1 = k;
    } 
    f1 -= f2;
  }
  
  public final int 冷(int paramInt, boolean paramBoolean) {
    int i = this.痒.getCompoundPaddingLeft() + paramInt;
    paramInt = i;
    if (getPrefixText() != null) {
      paramInt = i;
      if (!paramBoolean)
        paramInt = i - getPrefixTextView().getMeasuredWidth() + getPrefixTextView().getPaddingLeft(); 
    } 
    return paramInt;
  }
  
  public final void 堅() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 큰 : Ly/u0;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #4
    //   14: getfield 淋 : Ly/t0;
    //   17: getfield 硬 : Ly/wk;
    //   20: astore #5
    //   22: aload_0
    //   23: getfield 타 : Ly/wk;
    //   26: astore #6
    //   28: iconst_0
    //   29: istore_3
    //   30: aload #5
    //   32: aload #6
    //   34: if_acmpeq -> 140
    //   37: aload #4
    //   39: aload #6
    //   41: invokevirtual setShapeAppearanceModel : (Ly/wk;)V
    //   44: aload_0
    //   45: getfield 투 : I
    //   48: iconst_3
    //   49: if_icmpne -> 140
    //   52: aload_0
    //   53: getfield 탈 : I
    //   56: iconst_2
    //   57: if_icmpne -> 140
    //   60: aload_0
    //   61: getfield 퉁 : Landroid/util/SparseArray;
    //   64: iconst_3
    //   65: invokevirtual get : (I)Ljava/lang/Object;
    //   68: checkcast y/록
    //   71: astore #4
    //   73: aload_0
    //   74: getfield 痒 : Landroid/widget/EditText;
    //   77: checkcast android/widget/AutoCompleteTextView
    //   80: astore #5
    //   82: aload #4
    //   84: invokevirtual getClass : ()Ljava/lang/Class;
    //   87: pop
    //   88: aload #5
    //   90: invokevirtual getKeyListener : ()Landroid/text/method/KeyListener;
    //   93: ifnull -> 101
    //   96: iconst_1
    //   97: istore_2
    //   98: goto -> 103
    //   101: iconst_0
    //   102: istore_2
    //   103: iload_2
    //   104: ifne -> 140
    //   107: aload #4
    //   109: getfield 硬 : Lcom/google/android/material/textfield/TextInputLayout;
    //   112: invokevirtual getBoxBackgroundMode : ()I
    //   115: iconst_2
    //   116: if_icmpne -> 140
    //   119: aload #5
    //   121: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   124: instanceof android/graphics/drawable/LayerDrawable
    //   127: ifne -> 133
    //   130: goto -> 140
    //   133: aload #4
    //   135: aload #5
    //   137: invokevirtual 冷 : (Landroid/widget/AutoCompleteTextView;)V
    //   140: aload_0
    //   141: getfield 탈 : I
    //   144: iconst_2
    //   145: if_icmpne -> 179
    //   148: aload_0
    //   149: getfield 탑 : I
    //   152: iconst_m1
    //   153: if_icmple -> 168
    //   156: aload_0
    //   157: getfield 택 : I
    //   160: ifeq -> 168
    //   163: iconst_1
    //   164: istore_2
    //   165: goto -> 170
    //   168: iconst_0
    //   169: istore_2
    //   170: iload_2
    //   171: ifeq -> 179
    //   174: iconst_1
    //   175: istore_2
    //   176: goto -> 181
    //   179: iconst_0
    //   180: istore_2
    //   181: iload_2
    //   182: ifeq -> 257
    //   185: aload_0
    //   186: getfield 큰 : Ly/u0;
    //   189: astore #4
    //   191: aload_0
    //   192: getfield 탑 : I
    //   195: i2f
    //   196: fstore_1
    //   197: aload_0
    //   198: getfield 택 : I
    //   201: istore_2
    //   202: aload #4
    //   204: getfield 淋 : Ly/t0;
    //   207: fload_1
    //   208: putfield ぱ : F
    //   211: aload #4
    //   213: invokevirtual invalidateSelf : ()V
    //   216: iload_2
    //   217: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   220: astore #5
    //   222: aload #4
    //   224: getfield 淋 : Ly/t0;
    //   227: astore #6
    //   229: aload #6
    //   231: getfield 暑 : Landroid/content/res/ColorStateList;
    //   234: aload #5
    //   236: if_acmpeq -> 257
    //   239: aload #6
    //   241: aload #5
    //   243: putfield 暑 : Landroid/content/res/ColorStateList;
    //   246: aload #4
    //   248: aload #4
    //   250: invokevirtual getState : ()[I
    //   253: invokevirtual onStateChange : ([I)Z
    //   256: pop
    //   257: aload_0
    //   258: getfield 탱 : I
    //   261: istore_2
    //   262: aload_0
    //   263: getfield 탈 : I
    //   266: iconst_1
    //   267: if_icmpne -> 291
    //   270: aload_0
    //   271: invokevirtual getContext : ()Landroid/content/Context;
    //   274: ldc_w 2130903297
    //   277: iconst_0
    //   278: invokestatic 帰 : (Landroid/content/Context;II)I
    //   281: istore_2
    //   282: aload_0
    //   283: getfield 탱 : I
    //   286: iload_2
    //   287: invokestatic 堅 : (II)I
    //   290: istore_2
    //   291: aload_0
    //   292: iload_2
    //   293: putfield 탱 : I
    //   296: aload_0
    //   297: getfield 큰 : Ly/u0;
    //   300: iload_2
    //   301: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   304: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   307: aload_0
    //   308: getfield 투 : I
    //   311: iconst_3
    //   312: if_icmpne -> 325
    //   315: aload_0
    //   316: getfield 痒 : Landroid/widget/EditText;
    //   319: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   322: invokevirtual invalidateSelf : ()V
    //   325: aload_0
    //   326: getfield 키 : Ly/u0;
    //   329: astore #5
    //   331: aload #5
    //   333: ifnull -> 427
    //   336: aload_0
    //   337: getfield ㅌ : Ly/u0;
    //   340: ifnonnull -> 346
    //   343: goto -> 427
    //   346: iload_3
    //   347: istore_2
    //   348: aload_0
    //   349: getfield 탑 : I
    //   352: iconst_m1
    //   353: if_icmple -> 367
    //   356: iload_3
    //   357: istore_2
    //   358: aload_0
    //   359: getfield 택 : I
    //   362: ifeq -> 367
    //   365: iconst_1
    //   366: istore_2
    //   367: iload_2
    //   368: ifeq -> 423
    //   371: aload_0
    //   372: getfield 痒 : Landroid/widget/EditText;
    //   375: invokevirtual isFocused : ()Z
    //   378: ifeq -> 393
    //   381: aload_0
    //   382: getfield 医 : I
    //   385: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   388: astore #4
    //   390: goto -> 402
    //   393: aload_0
    //   394: getfield 택 : I
    //   397: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   400: astore #4
    //   402: aload #5
    //   404: aload #4
    //   406: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   409: aload_0
    //   410: getfield ㅌ : Ly/u0;
    //   413: aload_0
    //   414: getfield 택 : I
    //   417: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   420: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   423: aload_0
    //   424: invokevirtual invalidate : ()V
    //   427: aload_0
    //   428: invokevirtual invalidate : ()V
    //   431: return
  }
  
  public final void 嬉(int paramInt) {
    boolean bool = this.歩;
    int i = this.返;
    安 安 = null;
    if (i == -1) {
      this.泳.setText(String.valueOf(paramInt));
      this.泳.setContentDescription(null);
      this.歩 = false;
    } else {
      boolean bool1;
      安 安1;
      String str1;
      if (paramInt > i) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.歩 = bool1;
      Context context = getContext();
      服 服1 = this.泳;
      int j = this.返;
      if (this.歩) {
        i = 2131689529;
      } else {
        i = 2131689528;
      } 
      服1.setContentDescription(context.getString(i, new Object[] { Integer.valueOf(paramInt), Integer.valueOf(j) }));
      if (bool != this.歩)
        悲(); 
      String str2 = 安.暑;
      Locale locale = Locale.getDefault();
      i = dr.硬;
      i = Build.VERSION.SDK_INT;
      if (cr.硬(locale) == 1) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        安1 = 安.美;
      } else {
        安1 = 安.寒;
      } 
      服1 = this.泳;
      String str3 = getContext().getString(2131689530, new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.返) });
      if (str3 == null) {
        安1.getClass();
        安1 = 安;
      } else {
        str1 = 安1.熱(str3, 安1.熱).toString();
      } 
      服1.setText(str1);
    } 
    if (this.痒 != null && bool != this.歩) {
      痒(false, false);
      死();
      淋();
    } 
  }
  
  public final boolean 寂() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 痒 : Landroid/widget/EditText;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: invokevirtual getStartIconDrawable : ()Landroid/graphics/drawable/Drawable;
    //   13: astore #7
    //   15: iconst_1
    //   16: istore #5
    //   18: iconst_1
    //   19: istore #6
    //   21: aload_0
    //   22: getfield 怖 : Ly/ym;
    //   25: astore #8
    //   27: aload #7
    //   29: ifnonnull -> 49
    //   32: aload_0
    //   33: invokevirtual getPrefixText : ()Ljava/lang/CharSequence;
    //   36: ifnull -> 62
    //   39: aload_0
    //   40: invokevirtual getPrefixTextView : ()Landroid/widget/TextView;
    //   43: invokevirtual getVisibility : ()I
    //   46: ifne -> 62
    //   49: aload #8
    //   51: invokevirtual getMeasuredWidth : ()I
    //   54: ifle -> 62
    //   57: iconst_1
    //   58: istore_1
    //   59: goto -> 64
    //   62: iconst_0
    //   63: istore_1
    //   64: iload_1
    //   65: ifeq -> 186
    //   68: aload #8
    //   70: invokevirtual getMeasuredWidth : ()I
    //   73: aload_0
    //   74: getfield 痒 : Landroid/widget/EditText;
    //   77: invokevirtual getPaddingLeft : ()I
    //   80: isub
    //   81: istore_1
    //   82: aload_0
    //   83: getfield 톨 : Landroid/graphics/drawable/ColorDrawable;
    //   86: ifnull -> 97
    //   89: aload_0
    //   90: getfield 통 : I
    //   93: iload_1
    //   94: if_icmpeq -> 126
    //   97: new android/graphics/drawable/ColorDrawable
    //   100: dup
    //   101: invokespecial <init> : ()V
    //   104: astore #7
    //   106: aload_0
    //   107: aload #7
    //   109: putfield 톨 : Landroid/graphics/drawable/ColorDrawable;
    //   112: aload_0
    //   113: iload_1
    //   114: putfield 통 : I
    //   117: aload #7
    //   119: iconst_0
    //   120: iconst_0
    //   121: iload_1
    //   122: iconst_1
    //   123: invokevirtual setBounds : (IIII)V
    //   126: aload_0
    //   127: getfield 痒 : Landroid/widget/EditText;
    //   130: astore #7
    //   132: getstatic android/os/Build$VERSION.SDK_INT : I
    //   135: istore_1
    //   136: aload #7
    //   138: invokestatic 硬 : (Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    //   141: astore #7
    //   143: aload #7
    //   145: iconst_0
    //   146: aaload
    //   147: astore #8
    //   149: aload_0
    //   150: getfield 톨 : Landroid/graphics/drawable/ColorDrawable;
    //   153: astore #9
    //   155: aload #8
    //   157: aload #9
    //   159: if_acmpeq -> 241
    //   162: aload_0
    //   163: getfield 痒 : Landroid/widget/EditText;
    //   166: aload #9
    //   168: aload #7
    //   170: iconst_1
    //   171: aaload
    //   172: aload #7
    //   174: iconst_2
    //   175: aaload
    //   176: aload #7
    //   178: iconst_3
    //   179: aaload
    //   180: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   183: goto -> 235
    //   186: aload_0
    //   187: getfield 톨 : Landroid/graphics/drawable/ColorDrawable;
    //   190: ifnull -> 241
    //   193: aload_0
    //   194: getfield 痒 : Landroid/widget/EditText;
    //   197: astore #7
    //   199: getstatic android/os/Build$VERSION.SDK_INT : I
    //   202: istore_1
    //   203: aload #7
    //   205: invokestatic 硬 : (Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    //   208: astore #7
    //   210: aload_0
    //   211: getfield 痒 : Landroid/widget/EditText;
    //   214: aconst_null
    //   215: aload #7
    //   217: iconst_1
    //   218: aaload
    //   219: aload #7
    //   221: iconst_2
    //   222: aaload
    //   223: aload #7
    //   225: iconst_3
    //   226: aaload
    //   227: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   230: aload_0
    //   231: aconst_null
    //   232: putfield 톨 : Landroid/graphics/drawable/ColorDrawable;
    //   235: iconst_1
    //   236: istore #4
    //   238: goto -> 244
    //   241: iconst_0
    //   242: istore #4
    //   244: aload_0
    //   245: getfield ょ : Lcom/google/android/material/internal/CheckableImageButton;
    //   248: invokevirtual getVisibility : ()I
    //   251: ifeq -> 286
    //   254: aload_0
    //   255: getfield 투 : I
    //   258: ifeq -> 266
    //   261: iconst_1
    //   262: istore_1
    //   263: goto -> 268
    //   266: iconst_0
    //   267: istore_1
    //   268: iload_1
    //   269: ifeq -> 279
    //   272: aload_0
    //   273: invokevirtual 美 : ()Z
    //   276: ifne -> 286
    //   279: aload_0
    //   280: getfield も : Ljava/lang/CharSequence;
    //   283: ifnull -> 301
    //   286: aload_0
    //   287: getfield 恐 : Landroid/widget/LinearLayout;
    //   290: invokevirtual getMeasuredWidth : ()I
    //   293: ifle -> 301
    //   296: iconst_1
    //   297: istore_1
    //   298: goto -> 303
    //   301: iconst_0
    //   302: istore_1
    //   303: iload_1
    //   304: ifeq -> 536
    //   307: aload_0
    //   308: getfield 若 : Ly/服;
    //   311: invokevirtual getMeasuredWidth : ()I
    //   314: aload_0
    //   315: getfield 痒 : Landroid/widget/EditText;
    //   318: invokevirtual getPaddingRight : ()I
    //   321: isub
    //   322: istore_2
    //   323: aload_0
    //   324: invokespecial getEndIconToUpdateDummyDrawable : ()Lcom/google/android/material/internal/CheckableImageButton;
    //   327: astore #7
    //   329: iload_2
    //   330: istore_1
    //   331: aload #7
    //   333: ifnull -> 366
    //   336: aload #7
    //   338: invokevirtual getMeasuredWidth : ()I
    //   341: istore_1
    //   342: aload #7
    //   344: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   347: checkcast android/view/ViewGroup$MarginLayoutParams
    //   350: astore #7
    //   352: getstatic android/os/Build$VERSION.SDK_INT : I
    //   355: istore_3
    //   356: aload #7
    //   358: invokestatic 熱 : (Landroid/view/ViewGroup$MarginLayoutParams;)I
    //   361: iload_1
    //   362: iload_2
    //   363: iadd
    //   364: iadd
    //   365: istore_1
    //   366: aload_0
    //   367: getfield 痒 : Landroid/widget/EditText;
    //   370: astore #7
    //   372: getstatic android/os/Build$VERSION.SDK_INT : I
    //   375: istore_2
    //   376: aload #7
    //   378: invokestatic 硬 : (Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    //   381: astore #7
    //   383: aload_0
    //   384: getfield く : Landroid/graphics/drawable/ColorDrawable;
    //   387: astore #8
    //   389: aload #8
    //   391: ifnull -> 446
    //   394: aload_0
    //   395: getfield ぼ : I
    //   398: iload_1
    //   399: if_icmpeq -> 446
    //   402: aload_0
    //   403: iload_1
    //   404: putfield ぼ : I
    //   407: aload #8
    //   409: iconst_0
    //   410: iconst_0
    //   411: iload_1
    //   412: iconst_1
    //   413: invokevirtual setBounds : (IIII)V
    //   416: aload_0
    //   417: getfield 痒 : Landroid/widget/EditText;
    //   420: aload #7
    //   422: iconst_0
    //   423: aaload
    //   424: aload #7
    //   426: iconst_1
    //   427: aaload
    //   428: aload_0
    //   429: getfield く : Landroid/graphics/drawable/ColorDrawable;
    //   432: aload #7
    //   434: iconst_3
    //   435: aaload
    //   436: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   439: iload #5
    //   441: istore #4
    //   443: goto -> 610
    //   446: aload #8
    //   448: ifnonnull -> 480
    //   451: new android/graphics/drawable/ColorDrawable
    //   454: dup
    //   455: invokespecial <init> : ()V
    //   458: astore #8
    //   460: aload_0
    //   461: aload #8
    //   463: putfield く : Landroid/graphics/drawable/ColorDrawable;
    //   466: aload_0
    //   467: iload_1
    //   468: putfield ぼ : I
    //   471: aload #8
    //   473: iconst_0
    //   474: iconst_0
    //   475: iload_1
    //   476: iconst_1
    //   477: invokevirtual setBounds : (IIII)V
    //   480: aload #7
    //   482: iconst_2
    //   483: aaload
    //   484: astore #8
    //   486: aload_0
    //   487: getfield く : Landroid/graphics/drawable/ColorDrawable;
    //   490: astore #9
    //   492: aload #8
    //   494: aload #9
    //   496: if_acmpeq -> 533
    //   499: aload_0
    //   500: aload #8
    //   502: putfield 僕 : Landroid/graphics/drawable/Drawable;
    //   505: aload_0
    //   506: getfield 痒 : Landroid/widget/EditText;
    //   509: aload #7
    //   511: iconst_0
    //   512: aaload
    //   513: aload #7
    //   515: iconst_1
    //   516: aaload
    //   517: aload #9
    //   519: aload #7
    //   521: iconst_3
    //   522: aaload
    //   523: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   526: iload #5
    //   528: istore #4
    //   530: goto -> 610
    //   533: goto -> 610
    //   536: iload #4
    //   538: istore #5
    //   540: aload_0
    //   541: getfield く : Landroid/graphics/drawable/ColorDrawable;
    //   544: ifnull -> 614
    //   547: aload_0
    //   548: getfield 痒 : Landroid/widget/EditText;
    //   551: astore #7
    //   553: getstatic android/os/Build$VERSION.SDK_INT : I
    //   556: istore_1
    //   557: aload #7
    //   559: invokestatic 硬 : (Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    //   562: astore #7
    //   564: aload #7
    //   566: iconst_2
    //   567: aaload
    //   568: aload_0
    //   569: getfield く : Landroid/graphics/drawable/ColorDrawable;
    //   572: if_acmpne -> 605
    //   575: aload_0
    //   576: getfield 痒 : Landroid/widget/EditText;
    //   579: aload #7
    //   581: iconst_0
    //   582: aaload
    //   583: aload #7
    //   585: iconst_1
    //   586: aaload
    //   587: aload_0
    //   588: getfield 僕 : Landroid/graphics/drawable/Drawable;
    //   591: aload #7
    //   593: iconst_3
    //   594: aaload
    //   595: invokestatic か : (Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   598: iload #6
    //   600: istore #4
    //   602: goto -> 605
    //   605: aload_0
    //   606: aconst_null
    //   607: putfield く : Landroid/graphics/drawable/ColorDrawable;
    //   610: iload #4
    //   612: istore #5
    //   614: iload #5
    //   616: ireturn
  }
  
  public final int 寒(int paramInt, boolean paramBoolean) {
    int i = paramInt - this.痒.getCompoundPaddingRight();
    paramInt = i;
    if (getPrefixText() != null) {
      paramInt = i;
      if (paramBoolean)
        paramInt = i + getPrefixTextView().getMeasuredWidth() - getPrefixTextView().getPaddingRight(); 
    } 
    return paramInt;
  }
  
  public final void 怖() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 者 : Lcom/google/android/material/internal/CheckableImageButton;
    //   4: invokevirtual getVisibility : ()I
    //   7: istore_1
    //   8: aload_0
    //   9: getfield ょ : Lcom/google/android/material/internal/CheckableImageButton;
    //   12: astore #6
    //   14: iconst_1
    //   15: istore #5
    //   17: iconst_0
    //   18: istore #4
    //   20: iload_1
    //   21: ifne -> 48
    //   24: aload #6
    //   26: invokevirtual getVisibility : ()I
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifne -> 48
    //   43: iconst_0
    //   44: istore_1
    //   45: goto -> 51
    //   48: bipush #8
    //   50: istore_1
    //   51: aload_0
    //   52: getfield 痛 : Landroid/widget/FrameLayout;
    //   55: iload_1
    //   56: invokevirtual setVisibility : (I)V
    //   59: aload_0
    //   60: getfield も : Ljava/lang/CharSequence;
    //   63: ifnull -> 78
    //   66: aload_0
    //   67: getfield は : Z
    //   70: ifne -> 78
    //   73: iconst_0
    //   74: istore_1
    //   75: goto -> 81
    //   78: bipush #8
    //   80: istore_1
    //   81: iload #5
    //   83: istore_3
    //   84: aload_0
    //   85: invokevirtual 美 : ()Z
    //   88: ifne -> 125
    //   91: aload #6
    //   93: invokevirtual getVisibility : ()I
    //   96: ifne -> 104
    //   99: iconst_1
    //   100: istore_2
    //   101: goto -> 106
    //   104: iconst_0
    //   105: istore_2
    //   106: iload #5
    //   108: istore_3
    //   109: iload_2
    //   110: ifne -> 125
    //   113: iload_1
    //   114: ifne -> 123
    //   117: iload #5
    //   119: istore_3
    //   120: goto -> 125
    //   123: iconst_0
    //   124: istore_3
    //   125: iload_3
    //   126: ifeq -> 135
    //   129: iload #4
    //   131: istore_1
    //   132: goto -> 138
    //   135: bipush #8
    //   137: istore_1
    //   138: aload_0
    //   139: getfield 恐 : Landroid/widget/LinearLayout;
    //   142: iload_1
    //   143: invokevirtual setVisibility : (I)V
    //   146: return
  }
  
  public final void 恐() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getErrorIconDrawable : ()Landroid/graphics/drawable/Drawable;
    //   4: astore_3
    //   5: iconst_1
    //   6: istore_2
    //   7: aload_3
    //   8: ifnull -> 35
    //   11: aload_0
    //   12: getfield 壊 : Ly/若;
    //   15: astore_3
    //   16: aload_3
    //   17: getfield ぱ : Z
    //   20: ifeq -> 35
    //   23: aload_3
    //   24: invokevirtual 冷 : ()Z
    //   27: ifeq -> 35
    //   30: iconst_1
    //   31: istore_1
    //   32: goto -> 37
    //   35: iconst_0
    //   36: istore_1
    //   37: iload_1
    //   38: ifeq -> 46
    //   41: iconst_0
    //   42: istore_1
    //   43: goto -> 49
    //   46: bipush #8
    //   48: istore_1
    //   49: aload_0
    //   50: getfield ょ : Lcom/google/android/material/internal/CheckableImageButton;
    //   53: iload_1
    //   54: invokevirtual setVisibility : (I)V
    //   57: aload_0
    //   58: invokevirtual 怖 : ()V
    //   61: aload_0
    //   62: invokevirtual 興 : ()V
    //   65: aload_0
    //   66: getfield 투 : I
    //   69: ifeq -> 77
    //   72: iload_2
    //   73: istore_1
    //   74: goto -> 79
    //   77: iconst_0
    //   78: istore_1
    //   79: iload_1
    //   80: ifne -> 88
    //   83: aload_0
    //   84: invokevirtual 寂 : ()Z
    //   87: pop
    //   88: return
  }
  
  public final void 悲() {
    服 服1 = this.泳;
    if (服1 != null) {
      int i;
      if (this.歩) {
        i = this.踊;
      } else {
        i = this.寝;
      } 
      苦((TextView)服1, i);
      if (!this.歩) {
        ColorStateList colorStateList = this.赤;
        if (colorStateList != null)
          this.泳.setTextColor(colorStateList); 
      } 
      if (this.歩) {
        ColorStateList colorStateList = this.わ;
        if (colorStateList != null)
          this.泳.setTextColor(colorStateList); 
      } 
    } 
  }
  
  public final void 旨() {
    int i = this.탈;
    boolean bool = true;
    if (i != 0) {
      if (i != 1) {
        if (i == 2) {
          if (this.코 && !(this.큰 instanceof 그)) {
            this.큰 = (u0)new 그(this.타);
          } else {
            this.큰 = new u0(this.타);
          } 
          this.키 = null;
          this.ㅌ = null;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(this.탈);
          stringBuilder.append(" is illegal; only @BoxBackgroundMode constants are supported.");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        this.큰 = new u0(this.타);
        this.키 = new u0();
        this.ㅌ = new u0();
      } 
    } else {
      this.큰 = null;
      this.키 = null;
      this.ㅌ = null;
    } 
    EditText editText = this.痒;
    if (editText != null && this.큰 != null && editText.getBackground() == null && this.탈 != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0)
      rw.歩((View)this.痒, (Drawable)this.큰); 
    死();
    if (this.탈 == 1) {
      if ((getContext().getResources().getConfiguration()).fontScale >= 2.0F) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        this.탐 = getResources().getDimensionPixelSize(2131100104);
      } else if (年.壊(getContext())) {
        this.탐 = getResources().getDimensionPixelSize(2131100103);
      } 
    } 
    if (this.痒 != null && this.탈 == 1) {
      if ((getContext().getResources().getConfiguration()).fontScale >= 2.0F) {
        i = bool;
      } else {
        i = 0;
      } 
      if (i != 0) {
        editText = this.痒;
        rw.寝((View)editText, rw.苦((View)editText), getResources().getDimensionPixelSize(2131100102), rw.ぱ((View)this.痒), getResources().getDimensionPixelSize(2131100101));
      } else if (年.壊(getContext())) {
        editText = this.痒;
        rw.寝((View)editText, rw.苦((View)editText), getResources().getDimensionPixelSize(2131100100), rw.ぱ((View)this.痒), getResources().getDimensionPixelSize(2131100099));
      } 
    } 
    if (this.탈 != 0)
      痛(); 
  }
  
  public final boolean 暑() {
    return (this.코 && !TextUtils.isEmpty(this.쾌) && this.큰 instanceof 그);
  }
  
  public final void 死() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 큰 : Ly/u0;
    //   4: ifnull -> 549
    //   7: aload_0
    //   8: getfield 탈 : I
    //   11: ifne -> 15
    //   14: return
    //   15: aload_0
    //   16: invokevirtual isFocused : ()Z
    //   19: istore_2
    //   20: iconst_0
    //   21: istore #4
    //   23: iload_2
    //   24: ifne -> 54
    //   27: aload_0
    //   28: getfield 痒 : Landroid/widget/EditText;
    //   31: astore #5
    //   33: aload #5
    //   35: ifnull -> 49
    //   38: aload #5
    //   40: invokevirtual hasFocus : ()Z
    //   43: ifeq -> 49
    //   46: goto -> 54
    //   49: iconst_0
    //   50: istore_2
    //   51: goto -> 56
    //   54: iconst_1
    //   55: istore_2
    //   56: aload_0
    //   57: invokevirtual isHovered : ()Z
    //   60: ifne -> 88
    //   63: aload_0
    //   64: getfield 痒 : Landroid/widget/EditText;
    //   67: astore #5
    //   69: iload #4
    //   71: istore_3
    //   72: aload #5
    //   74: ifnull -> 90
    //   77: iload #4
    //   79: istore_3
    //   80: aload #5
    //   82: invokevirtual isHovered : ()Z
    //   85: ifeq -> 90
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_0
    //   91: invokevirtual isEnabled : ()Z
    //   94: istore #4
    //   96: aload_0
    //   97: getfield 壊 : Ly/若;
    //   100: astore #5
    //   102: iload #4
    //   104: ifne -> 118
    //   107: aload_0
    //   108: aload_0
    //   109: getfield 科 : I
    //   112: putfield 택 : I
    //   115: goto -> 238
    //   118: aload #5
    //   120: invokevirtual 冷 : ()Z
    //   123: ifeq -> 154
    //   126: aload_0
    //   127: getfield 護 : Landroid/content/res/ColorStateList;
    //   130: ifnull -> 142
    //   133: aload_0
    //   134: iload_2
    //   135: iload_3
    //   136: invokevirtual 起 : (ZZ)V
    //   139: goto -> 238
    //   142: aload_0
    //   143: aload #5
    //   145: invokevirtual 美 : ()I
    //   148: putfield 택 : I
    //   151: goto -> 238
    //   154: aload_0
    //   155: getfield 歩 : Z
    //   158: ifeq -> 200
    //   161: aload_0
    //   162: getfield 泳 : Ly/服;
    //   165: astore #6
    //   167: aload #6
    //   169: ifnull -> 200
    //   172: aload_0
    //   173: getfield 護 : Landroid/content/res/ColorStateList;
    //   176: ifnull -> 188
    //   179: aload_0
    //   180: iload_2
    //   181: iload_3
    //   182: invokevirtual 起 : (ZZ)V
    //   185: goto -> 238
    //   188: aload_0
    //   189: aload #6
    //   191: invokevirtual getCurrentTextColor : ()I
    //   194: putfield 택 : I
    //   197: goto -> 238
    //   200: iload_2
    //   201: ifeq -> 215
    //   204: aload_0
    //   205: aload_0
    //   206: getfield 看 : I
    //   209: putfield 택 : I
    //   212: goto -> 238
    //   215: iload_3
    //   216: ifeq -> 230
    //   219: aload_0
    //   220: aload_0
    //   221: getfield ご : I
    //   224: putfield 택 : I
    //   227: goto -> 238
    //   230: aload_0
    //   231: aload_0
    //   232: getfield 医 : I
    //   235: putfield 택 : I
    //   238: aload_0
    //   239: invokevirtual 恐 : ()V
    //   242: aload_0
    //   243: aload_0
    //   244: getfield ょ : Lcom/google/android/material/internal/CheckableImageButton;
    //   247: aload_0
    //   248: getfield う : Landroid/content/res/ColorStateList;
    //   251: invokestatic 탕 : (Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V
    //   254: aload_0
    //   255: getfield 怖 : Ly/ym;
    //   258: astore #6
    //   260: aload #6
    //   262: getfield 痛 : Lcom/google/android/material/internal/CheckableImageButton;
    //   265: astore #7
    //   267: aload #6
    //   269: getfield 痒 : Landroid/content/res/ColorStateList;
    //   272: astore #8
    //   274: aload #6
    //   276: getfield 淋 : Lcom/google/android/material/textfield/TextInputLayout;
    //   279: aload #7
    //   281: aload #8
    //   283: invokestatic 탕 : (Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V
    //   286: aload_0
    //   287: getfield し : Landroid/content/res/ColorStateList;
    //   290: astore #7
    //   292: aload_0
    //   293: getfield 者 : Lcom/google/android/material/internal/CheckableImageButton;
    //   296: astore #6
    //   298: aload_0
    //   299: aload #6
    //   301: aload #7
    //   303: invokestatic 탕 : (Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V
    //   306: aload_0
    //   307: invokespecial getEndIconDelegate : ()Ly/민;
    //   310: astore #7
    //   312: aload #7
    //   314: invokevirtual getClass : ()Ljava/lang/Class;
    //   317: pop
    //   318: aload #7
    //   320: instanceof y/록
    //   323: ifeq -> 387
    //   326: aload #5
    //   328: invokevirtual 冷 : ()Z
    //   331: ifeq -> 373
    //   334: aload_0
    //   335: invokevirtual getEndIconDrawable : ()Landroid/graphics/drawable/Drawable;
    //   338: ifnull -> 373
    //   341: aload_0
    //   342: invokevirtual getEndIconDrawable : ()Landroid/graphics/drawable/Drawable;
    //   345: invokestatic 帰 : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   348: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   351: astore #7
    //   353: aload #7
    //   355: aload #5
    //   357: invokevirtual 美 : ()I
    //   360: invokestatic 起 : (Landroid/graphics/drawable/Drawable;I)V
    //   363: aload #6
    //   365: aload #7
    //   367: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   370: goto -> 387
    //   373: aload_0
    //   374: aload #6
    //   376: aload_0
    //   377: getfield し : Landroid/content/res/ColorStateList;
    //   380: aload_0
    //   381: getfield 私 : Landroid/graphics/PorterDuff$Mode;
    //   384: invokestatic 堅 : (Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)V
    //   387: aload_0
    //   388: getfield 탈 : I
    //   391: iconst_2
    //   392: if_icmpne -> 477
    //   395: aload_0
    //   396: getfield 탑 : I
    //   399: istore_1
    //   400: iload_2
    //   401: ifeq -> 422
    //   404: aload_0
    //   405: invokevirtual isEnabled : ()Z
    //   408: ifeq -> 422
    //   411: aload_0
    //   412: aload_0
    //   413: getfield 태 : I
    //   416: putfield 탑 : I
    //   419: goto -> 430
    //   422: aload_0
    //   423: aload_0
    //   424: getfield 탕 : I
    //   427: putfield 탑 : I
    //   430: aload_0
    //   431: getfield 탑 : I
    //   434: iload_1
    //   435: if_icmpeq -> 477
    //   438: aload_0
    //   439: invokevirtual 暑 : ()Z
    //   442: ifeq -> 477
    //   445: aload_0
    //   446: getfield は : Z
    //   449: ifne -> 477
    //   452: aload_0
    //   453: invokevirtual 暑 : ()Z
    //   456: ifeq -> 473
    //   459: aload_0
    //   460: getfield 큰 : Ly/u0;
    //   463: checkcast y/그
    //   466: fconst_0
    //   467: fconst_0
    //   468: fconst_0
    //   469: fconst_0
    //   470: invokevirtual 悲 : (FFFF)V
    //   473: aload_0
    //   474: invokevirtual 不 : ()V
    //   477: aload_0
    //   478: getfield 탈 : I
    //   481: iconst_1
    //   482: if_icmpne -> 545
    //   485: aload_0
    //   486: invokevirtual isEnabled : ()Z
    //   489: ifne -> 503
    //   492: aload_0
    //   493: aload_0
    //   494: getfield ふ : I
    //   497: putfield 탱 : I
    //   500: goto -> 545
    //   503: iload_3
    //   504: ifeq -> 522
    //   507: iload_2
    //   508: ifne -> 522
    //   511: aload_0
    //   512: aload_0
    //   513: getfield 歯 : I
    //   516: putfield 탱 : I
    //   519: goto -> 545
    //   522: iload_2
    //   523: ifeq -> 537
    //   526: aload_0
    //   527: aload_0
    //   528: getfield 婦 : I
    //   531: putfield 탱 : I
    //   534: goto -> 545
    //   537: aload_0
    //   538: aload_0
    //   539: getfield 師 : I
    //   542: putfield 탱 : I
    //   545: aload_0
    //   546: invokevirtual 堅 : ()V
    //   549: return
  }
  
  public final void 淋() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 痒 : Landroid/widget/EditText;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 135
    //   9: aload_0
    //   10: getfield 탈 : I
    //   13: ifeq -> 17
    //   16: return
    //   17: aload_2
    //   18: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   21: astore_2
    //   22: aload_2
    //   23: ifnonnull -> 27
    //   26: return
    //   27: getstatic y/량.硬 : [I
    //   30: astore_3
    //   31: getstatic android/os/Build$VERSION.SDK_INT : I
    //   34: istore_1
    //   35: aload_2
    //   36: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   39: astore_2
    //   40: aload_0
    //   41: getfield 壊 : Ly/若;
    //   44: astore_3
    //   45: aload_3
    //   46: invokevirtual 冷 : ()Z
    //   49: ifeq -> 93
    //   52: aload_3
    //   53: invokevirtual 美 : ()I
    //   56: istore_1
    //   57: getstatic android/graphics/PorterDuff$Mode.SRC_IN : Landroid/graphics/PorterDuff$Mode;
    //   60: astore_3
    //   61: getstatic y/符.堅 : Landroid/graphics/PorterDuff$Mode;
    //   64: astore #4
    //   66: ldc_w y/符
    //   69: monitorenter
    //   70: iload_1
    //   71: aload_3
    //   72: invokestatic 旨 : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   75: astore_3
    //   76: ldc_w y/符
    //   79: monitorexit
    //   80: aload_2
    //   81: aload_3
    //   82: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   85: return
    //   86: astore_2
    //   87: ldc_w y/符
    //   90: monitorexit
    //   91: aload_2
    //   92: athrow
    //   93: aload_0
    //   94: getfield 歩 : Z
    //   97: ifeq -> 124
    //   100: aload_0
    //   101: getfield 泳 : Ly/服;
    //   104: astore_3
    //   105: aload_3
    //   106: ifnull -> 124
    //   109: aload_2
    //   110: aload_3
    //   111: invokevirtual getCurrentTextColor : ()I
    //   114: getstatic android/graphics/PorterDuff$Mode.SRC_IN : Landroid/graphics/PorterDuff$Mode;
    //   117: invokestatic 熱 : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   120: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   123: return
    //   124: aload_2
    //   125: invokestatic 寒 : (Landroid/graphics/drawable/Drawable;)V
    //   128: aload_0
    //   129: getfield 痒 : Landroid/widget/EditText;
    //   132: invokevirtual refreshDrawableState : ()V
    //   135: return
    // Exception table:
    //   from	to	target	type
    //   70	76	86	finally
  }
  
  public final int 熱() {
    if (!this.코)
      return 0; 
    int i = this.탈;
    働 働1 = this.せ;
    if (i != 0) {
      if (i != 2)
        return 0; 
      float f1 = 働1.暑() / 2.0F;
      return (int)f1;
    } 
    float f = 働1.暑();
    return (int)f;
  }
  
  public final void 産() {
    byte b;
    服 服1 = this.若;
    int i = 服1.getVisibility();
    CharSequence charSequence = this.も;
    boolean bool = false;
    if (charSequence != null && !this.は) {
      b = 0;
    } else {
      b = 8;
    } 
    if (i != b) {
      민 민 = getEndIconDelegate();
      if (b == 0)
        bool = true; 
      민.熱(bool);
    } 
    怖();
    服1.setVisibility(b);
    寂();
  }
  
  public final void 痒(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isEnabled : ()Z
    //   4: istore #6
    //   6: aload_0
    //   7: getfield 痒 : Landroid/widget/EditText;
    //   10: astore #8
    //   12: aload #8
    //   14: ifnull -> 33
    //   17: aload #8
    //   19: invokevirtual getText : ()Landroid/text/Editable;
    //   22: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   25: ifne -> 33
    //   28: iconst_1
    //   29: istore_3
    //   30: goto -> 35
    //   33: iconst_0
    //   34: istore_3
    //   35: aload_0
    //   36: getfield 痒 : Landroid/widget/EditText;
    //   39: astore #8
    //   41: aload #8
    //   43: ifnull -> 60
    //   46: aload #8
    //   48: invokevirtual hasFocus : ()Z
    //   51: ifeq -> 60
    //   54: iconst_1
    //   55: istore #4
    //   57: goto -> 63
    //   60: iconst_0
    //   61: istore #4
    //   63: aload_0
    //   64: getfield 壊 : Ly/若;
    //   67: astore #8
    //   69: aload #8
    //   71: invokevirtual 冷 : ()Z
    //   74: istore #7
    //   76: aload_0
    //   77: getfield ね : Landroid/content/res/ColorStateList;
    //   80: astore #10
    //   82: aload_0
    //   83: getfield せ : Ly/働;
    //   86: astore #9
    //   88: aload #10
    //   90: ifnull -> 129
    //   93: aload #9
    //   95: aload #10
    //   97: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   100: aload_0
    //   101: getfield ね : Landroid/content/res/ColorStateList;
    //   104: astore #10
    //   106: aload #9
    //   108: getfield ぱ : Landroid/content/res/ColorStateList;
    //   111: aload #10
    //   113: if_acmpeq -> 129
    //   116: aload #9
    //   118: aload #10
    //   120: putfield ぱ : Landroid/content/res/ColorStateList;
    //   123: aload #9
    //   125: iconst_0
    //   126: invokevirtual 不 : (Z)V
    //   129: iload #6
    //   131: ifne -> 221
    //   134: aload_0
    //   135: getfield ね : Landroid/content/res/ColorStateList;
    //   138: astore #8
    //   140: aload #8
    //   142: ifnull -> 172
    //   145: aload_0
    //   146: getfield 科 : I
    //   149: istore #5
    //   151: aload #8
    //   153: iconst_1
    //   154: newarray int
    //   156: dup
    //   157: iconst_0
    //   158: ldc_w -16842910
    //   161: iastore
    //   162: iload #5
    //   164: invokevirtual getColorForState : ([II)I
    //   167: istore #5
    //   169: goto -> 178
    //   172: aload_0
    //   173: getfield 科 : I
    //   176: istore #5
    //   178: aload #9
    //   180: iload #5
    //   182: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   185: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   188: iload #5
    //   190: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   193: astore #8
    //   195: aload #9
    //   197: getfield ぱ : Landroid/content/res/ColorStateList;
    //   200: aload #8
    //   202: if_acmpeq -> 315
    //   205: aload #9
    //   207: aload #8
    //   209: putfield ぱ : Landroid/content/res/ColorStateList;
    //   212: aload #9
    //   214: iconst_0
    //   215: invokevirtual 不 : (Z)V
    //   218: goto -> 315
    //   221: iload #7
    //   223: ifeq -> 261
    //   226: aload #8
    //   228: getfield 苦 : Ly/服;
    //   231: astore #8
    //   233: aload #8
    //   235: ifnull -> 248
    //   238: aload #8
    //   240: invokevirtual getTextColors : ()Landroid/content/res/ColorStateList;
    //   243: astore #8
    //   245: goto -> 251
    //   248: aconst_null
    //   249: astore #8
    //   251: aload #9
    //   253: aload #8
    //   255: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   258: goto -> 315
    //   261: aload_0
    //   262: getfield 歩 : Z
    //   265: ifeq -> 292
    //   268: aload_0
    //   269: getfield 泳 : Ly/服;
    //   272: astore #8
    //   274: aload #8
    //   276: ifnull -> 292
    //   279: aload #9
    //   281: aload #8
    //   283: invokevirtual getTextColors : ()Landroid/content/res/ColorStateList;
    //   286: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   289: goto -> 315
    //   292: iload #4
    //   294: ifeq -> 315
    //   297: aload_0
    //   298: getfield 年 : Landroid/content/res/ColorStateList;
    //   301: astore #8
    //   303: aload #8
    //   305: ifnull -> 315
    //   308: aload #9
    //   310: aload #8
    //   312: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   315: aload_0
    //   316: getfield 怖 : Ly/ym;
    //   319: astore #8
    //   321: iload_3
    //   322: ifne -> 519
    //   325: aload_0
    //   326: getfield 政 : Z
    //   329: ifeq -> 519
    //   332: aload_0
    //   333: invokevirtual isEnabled : ()Z
    //   336: ifeq -> 347
    //   339: iload #4
    //   341: ifeq -> 347
    //   344: goto -> 519
    //   347: iload_2
    //   348: ifne -> 358
    //   351: aload_0
    //   352: getfield は : Z
    //   355: ifne -> 644
    //   358: aload_0
    //   359: getfield 家 : Landroid/animation/ValueAnimator;
    //   362: astore #10
    //   364: aload #10
    //   366: ifnull -> 384
    //   369: aload #10
    //   371: invokevirtual isRunning : ()Z
    //   374: ifeq -> 384
    //   377: aload_0
    //   378: getfield 家 : Landroid/animation/ValueAnimator;
    //   381: invokevirtual cancel : ()V
    //   384: iload_1
    //   385: ifeq -> 403
    //   388: aload_0
    //   389: getfield 治 : Z
    //   392: ifeq -> 403
    //   395: aload_0
    //   396: fconst_0
    //   397: invokevirtual 硬 : (F)V
    //   400: goto -> 409
    //   403: aload #9
    //   405: fconst_0
    //   406: invokevirtual 苦 : (F)V
    //   409: aload_0
    //   410: invokevirtual 暑 : ()Z
    //   413: ifeq -> 455
    //   416: aload_0
    //   417: getfield 큰 : Ly/u0;
    //   420: checkcast y/그
    //   423: getfield ゃ : Landroid/graphics/RectF;
    //   426: invokevirtual isEmpty : ()Z
    //   429: iconst_1
    //   430: ixor
    //   431: ifeq -> 455
    //   434: aload_0
    //   435: invokevirtual 暑 : ()Z
    //   438: ifeq -> 455
    //   441: aload_0
    //   442: getfield 큰 : Ly/u0;
    //   445: checkcast y/그
    //   448: fconst_0
    //   449: fconst_0
    //   450: fconst_0
    //   451: fconst_0
    //   452: invokevirtual 悲 : (FFFF)V
    //   455: aload_0
    //   456: iconst_1
    //   457: putfield は : Z
    //   460: aload_0
    //   461: getfield 投 : Ly/服;
    //   464: astore #9
    //   466: aload #9
    //   468: ifnull -> 503
    //   471: aload_0
    //   472: getfield 触 : Z
    //   475: ifeq -> 503
    //   478: aload #9
    //   480: aconst_null
    //   481: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   484: aload_0
    //   485: getfield 淋 : Landroid/widget/FrameLayout;
    //   488: aload_0
    //   489: getfield ゃ : Ly/부;
    //   492: invokestatic 硬 : (Landroid/view/ViewGroup;Ly/dt;)V
    //   495: aload_0
    //   496: getfield 投 : Ly/服;
    //   499: iconst_4
    //   500: invokevirtual setVisibility : (I)V
    //   503: aload #8
    //   505: iconst_1
    //   506: putfield 興 : Z
    //   509: aload #8
    //   511: invokevirtual 暑 : ()V
    //   514: aload_0
    //   515: invokevirtual 産 : ()V
    //   518: return
    //   519: iload_2
    //   520: ifne -> 530
    //   523: aload_0
    //   524: getfield は : Z
    //   527: ifeq -> 644
    //   530: aload_0
    //   531: getfield 家 : Landroid/animation/ValueAnimator;
    //   534: astore #10
    //   536: aload #10
    //   538: ifnull -> 556
    //   541: aload #10
    //   543: invokevirtual isRunning : ()Z
    //   546: ifeq -> 556
    //   549: aload_0
    //   550: getfield 家 : Landroid/animation/ValueAnimator;
    //   553: invokevirtual cancel : ()V
    //   556: iload_1
    //   557: ifeq -> 575
    //   560: aload_0
    //   561: getfield 治 : Z
    //   564: ifeq -> 575
    //   567: aload_0
    //   568: fconst_1
    //   569: invokevirtual 硬 : (F)V
    //   572: goto -> 581
    //   575: aload #9
    //   577: fconst_1
    //   578: invokevirtual 苦 : (F)V
    //   581: aload_0
    //   582: iconst_0
    //   583: putfield は : Z
    //   586: aload_0
    //   587: invokevirtual 暑 : ()Z
    //   590: ifeq -> 597
    //   593: aload_0
    //   594: invokevirtual 不 : ()V
    //   597: aload_0
    //   598: getfield 痒 : Landroid/widget/EditText;
    //   601: astore #9
    //   603: aload #9
    //   605: ifnonnull -> 613
    //   608: iconst_0
    //   609: istore_3
    //   610: goto -> 624
    //   613: aload #9
    //   615: invokevirtual getText : ()Landroid/text/Editable;
    //   618: invokeinterface length : ()I
    //   623: istore_3
    //   624: aload_0
    //   625: iload_3
    //   626: invokevirtual 臭 : (I)V
    //   629: aload #8
    //   631: iconst_0
    //   632: putfield 興 : Z
    //   635: aload #8
    //   637: invokevirtual 暑 : ()V
    //   640: aload_0
    //   641: invokevirtual 産 : ()V
    //   644: return
  }
  
  public final void 痛() {
    if (this.탈 != 1) {
      FrameLayout frameLayout = this.淋;
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)frameLayout.getLayoutParams();
      int i = 熱();
      if (i != layoutParams.topMargin) {
        layoutParams.topMargin = i;
        frameLayout.requestLayout();
      } 
    } 
  }
  
  public final void 硬(float paramFloat) {
    働 働1 = this.せ;
    if (働1.熱 == paramFloat)
      return; 
    if (this.家 == null) {
      ValueAnimator valueAnimator = new ValueAnimator();
      this.家 = valueAnimator;
      valueAnimator.setInterpolator((TimeInterpolator)前.堅);
      this.家.setDuration(167L);
      this.家.addUpdateListener((ValueAnimator.AnimatorUpdateListener)new ぱ(2, this));
    } 
    this.家.setFloatValues(new float[] { 働1.熱, paramFloat });
    this.家.start();
  }
  
  public final boolean 美() {
    return (this.痛.getVisibility() == 0 && this.者.getVisibility() == 0);
  }
  
  public final void 臭(int paramInt) {
    FrameLayout frameLayout = this.淋;
    if (paramInt == 0 && !this.は) {
      if (this.投 != null && this.触 && !TextUtils.isEmpty(this.噛)) {
        this.投.setText(this.噛);
        gt.硬((ViewGroup)frameLayout, (dt)this.ち);
        this.投.setVisibility(0);
        this.投.bringToFront();
        paramInt = Build.VERSION.SDK_INT;
        announceForAccessibility(this.噛);
        return;
      } 
    } else {
      服 服1 = this.投;
      if (服1 != null && this.触) {
        服1.setText(null);
        gt.硬((ViewGroup)frameLayout, (dt)this.ゃ);
        this.投.setVisibility(4);
      } 
    } 
  }
  
  public final void 興() {
    if (this.痒 == null)
      return; 
    boolean bool = 美();
    int j = 0;
    int i = j;
    if (!bool) {
      if (this.ょ.getVisibility() == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        i = j;
      } else {
        i = rw.ぱ((View)this.痒);
      } 
    } 
    j = getContext().getResources().getDimensionPixelSize(2131100108);
    int k = this.痒.getPaddingTop();
    int m = this.痒.getPaddingBottom();
    rw.寝((View)this.若, j, k, i, m);
  }
  
  public final void 苦(TextView paramTextView, int paramInt) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_1
    //   3: iload_2
    //   4: invokestatic わ : (Landroid/widget/TextView;I)V
    //   7: getstatic android/os/Build$VERSION.SDK_INT : I
    //   10: bipush #23
    //   12: if_icmplt -> 35
    //   15: aload_1
    //   16: invokevirtual getTextColors : ()Landroid/content/res/ColorStateList;
    //   19: invokevirtual getDefaultColor : ()I
    //   22: istore_2
    //   23: iload_2
    //   24: ldc_w -65281
    //   27: if_icmpne -> 35
    //   30: iload_3
    //   31: istore_2
    //   32: goto -> 40
    //   35: iconst_0
    //   36: istore_2
    //   37: goto -> 40
    //   40: iload_2
    //   41: ifeq -> 65
    //   44: aload_1
    //   45: ldc_w 2131755439
    //   48: invokestatic わ : (Landroid/widget/TextView;I)V
    //   51: aload_1
    //   52: aload_0
    //   53: invokevirtual getContext : ()Landroid/content/Context;
    //   56: ldc_w 2131034261
    //   59: invokestatic 堅 : (Landroid/content/Context;I)I
    //   62: invokevirtual setTextColor : (I)V
    //   65: return
    //   66: astore #4
    //   68: iload_3
    //   69: istore_2
    //   70: goto -> 40
    // Exception table:
    //   from	to	target	type
    //   2	23	66	java/lang/Exception
  }
  
  public final void 起(boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.護.getDefaultColor();
    int j = this.護.getColorForState(new int[] { 16843623, 16842910 }, i);
    int k = this.護.getColorForState(new int[] { 16843518, 16842910 }, i);
    if (paramBoolean1) {
      this.택 = k;
      return;
    } 
    if (paramBoolean2) {
      this.택 = j;
      return;
    } 
    this.택 = i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\textfield\TextInputLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */