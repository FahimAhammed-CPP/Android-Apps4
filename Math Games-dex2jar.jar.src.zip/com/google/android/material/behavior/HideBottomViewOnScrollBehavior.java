package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import y.前;
import y.蛛;
import y.鷲;
import y.톨;

public class HideBottomViewOnScrollBehavior<V extends View> extends 톨 {
  public int 堅 = 2;
  
  public ViewPropertyAnimator 熱;
  
  public int 硬 = 0;
  
  public HideBottomViewOnScrollBehavior() {}
  
  public HideBottomViewOnScrollBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(0);
  }
  
  public final void ぱ(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    paramInt2 = 0;
    if (paramInt1 > 0) {
      if (this.堅 == 1) {
        paramInt1 = 1;
      } else {
        paramInt1 = 0;
      } 
      if (paramInt1 != 0)
        return; 
      ViewPropertyAnimator viewPropertyAnimator = this.熱;
      if (viewPropertyAnimator != null) {
        viewPropertyAnimator.cancel();
        paramView.clearAnimation();
      } 
      this.堅 = 1;
      恐(paramView, this.硬 + 0, 175L, (鷲)前.熱);
      return;
    } 
    if (paramInt1 < 0) {
      paramInt1 = paramInt2;
      if (this.堅 == 2)
        paramInt1 = 1; 
      if (paramInt1 != 0)
        return; 
      ViewPropertyAnimator viewPropertyAnimator = this.熱;
      if (viewPropertyAnimator != null) {
        viewPropertyAnimator.cancel();
        paramView.clearAnimation();
      } 
      this.堅 = 2;
      恐(paramView, 0, 225L, (鷲)前.暑);
    } 
  }
  
  public boolean 寂(View paramView, int paramInt1, int paramInt2) {
    return (paramInt1 == 2);
  }
  
  public final void 恐(View paramView, int paramInt, long paramLong, 鷲 param鷲) {
    this.熱 = paramView.animate().translationY(paramInt).setInterpolator((TimeInterpolator)param鷲).setDuration(paramLong).setListener((Animator.AnimatorListener)new 蛛(3, this));
  }
  
  public boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    this.硬 = paramView.getMeasuredHeight() + marginLayoutParams.bottomMargin;
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\behavior\HideBottomViewOnScrollBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */