package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import y.gp;
import y.rw;
import y.ww;
import y.xw;
import y.イ;
import y.ッ;
import y.톨;
import y.혹;

public class SwipeDismissBehavior<V extends View> extends 톨 {
  public float 冷 = 0.0F;
  
  public boolean 堅;
  
  public float 寒 = 0.5F;
  
  public final float 暑 = 0.5F;
  
  public int 熱 = 2;
  
  public xw 硬;
  
  public final gp 美 = new gp(this);
  
  public boolean 寒(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    boolean bool = this.堅;
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i == 1 || i == 3)
        this.堅 = false; 
    } else {
      bool = paramCoordinatorLayout.悲(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      this.堅 = bool;
    } 
    if (bool) {
      if (this.硬 == null)
        this.硬 = new xw(paramCoordinatorLayout.getContext(), (ViewGroup)paramCoordinatorLayout, (ww)this.美); 
      return this.硬.怖(paramMotionEvent);
    } 
    return false;
  }
  
  public final boolean 怖(View paramView, MotionEvent paramMotionEvent) {
    xw xw1 = this.硬;
    if (xw1 != null) {
      xw1.辛(paramMotionEvent);
      return true;
    } 
    return false;
  }
  
  public boolean 恐(View paramView) {
    return true;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    if (rw.旨(paramView) == 0) {
      rw.踊(paramView, 1);
      rw.起(paramView, 1048576);
      if (恐(paramView))
        rw.産(paramView, イ.辛, (ッ)new 혹(12, this)); 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\behavior\SwipeDismissBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */