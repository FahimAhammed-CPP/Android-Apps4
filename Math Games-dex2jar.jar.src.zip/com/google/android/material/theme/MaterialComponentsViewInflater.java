package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import y.c0;
import y.n0;
import y.s0;
import y.グ;
import y.セ;
import y.ベ;
import y.服;
import y.眼;
import y.銀;

public class MaterialComponentsViewInflater extends 眼 {
  public final 服 冷(Context paramContext, AttributeSet paramAttributeSet) {
    return (服)new MaterialTextView(paramContext, paramAttributeSet);
  }
  
  public final グ 堅(Context paramContext, AttributeSet paramAttributeSet) {
    return (グ)new MaterialButton(paramContext, paramAttributeSet);
  }
  
  public final ベ 暑(Context paramContext, AttributeSet paramAttributeSet) {
    return (ベ)new s0(paramContext, paramAttributeSet);
  }
  
  public final セ 熱(Context paramContext, AttributeSet paramAttributeSet) {
    return (セ)new n0(paramContext, paramAttributeSet);
  }
  
  public final 銀 硬(Context paramContext, AttributeSet paramAttributeSet) {
    return (銀)new c0(paramContext, paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\theme\MaterialComponentsViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */