package com.google.android.material.bottomsheet;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.WeakHashMap;
import y.ai1;
import y.aux;
import y.bm;
import y.fy;
import y.gq;
import y.gw;
import y.le;
import y.nul;
import y.r32;
import y.rw;
import y.t0;
import y.u0;
import y.wk;
import y.ww;
import y.xw;
import y.z6;
import y.イ;
import y.ッ;
import y.嬉;
import y.畳;
import y.苦;
import y.제;
import y.톨;
import y.투;

public class BottomSheetBehavior<V extends View> extends 톨 {
  public int あ = 4;
  
  public xw か;
  
  public boolean ち;
  
  public int ぱ = -1;
  
  public int も;
  
  public int ゃ;
  
  public int わ;
  
  public int ㅌ;
  
  public final ColorStateList 不;
  
  public boolean 冷;
  
  public boolean 噛;
  
  public boolean 堅 = true;
  
  public ValueAnimator 壊;
  
  public boolean 嬉;
  
  public final boolean 寂;
  
  public int 寒;
  
  public final float 寝 = -1.0F;
  
  public int 帰;
  
  public final boolean 怖;
  
  public final boolean 恐;
  
  public final boolean 悲;
  
  public boolean 投 = true;
  
  public u0 旨;
  
  public int 暑;
  
  public int 歩;
  
  public final gq 死 = new gq(this);
  
  public float 泳 = 0.5F;
  
  public final boolean 淋;
  
  public final float 熱;
  
  public boolean 産;
  
  public final boolean 痒;
  
  public final boolean 痛;
  
  public int 硬 = 0;
  
  public final int 美;
  
  public int 臭;
  
  public final wk 興;
  
  public int 若;
  
  public int 苦;
  
  public boolean 触;
  
  public boolean 赤;
  
  public int 起;
  
  public int 踊;
  
  public int 辛 = -1;
  
  public int 返;
  
  public WeakReference 코;
  
  public WeakReference 쾌;
  
  public final ArrayList 크 = new ArrayList();
  
  public VelocityTracker 큰;
  
  public int 키;
  
  public boolean 타;
  
  public HashMap 탁;
  
  public int 탄 = -1;
  
  public final 苦 탈 = new 苦(this);
  
  public BottomSheetBehavior() {}
  
  public BottomSheetBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: invokespecial <init> : (I)V
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield 硬 : I
    //   10: aload_0
    //   11: iconst_1
    //   12: putfield 堅 : Z
    //   15: aload_0
    //   16: iconst_m1
    //   17: putfield 辛 : I
    //   20: aload_0
    //   21: iconst_m1
    //   22: putfield ぱ : I
    //   25: aload_0
    //   26: new y/gq
    //   29: dup
    //   30: aload_0
    //   31: invokespecial <init> : (Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    //   34: putfield 死 : Ly/gq;
    //   37: aload_0
    //   38: ldc 0.5
    //   40: putfield 泳 : F
    //   43: aload_0
    //   44: ldc -1.0
    //   46: putfield 寝 : F
    //   49: aload_0
    //   50: iconst_1
    //   51: putfield 投 : Z
    //   54: aload_0
    //   55: iconst_4
    //   56: putfield あ : I
    //   59: aload_0
    //   60: new java/util/ArrayList
    //   63: dup
    //   64: invokespecial <init> : ()V
    //   67: putfield 크 : Ljava/util/ArrayList;
    //   70: aload_0
    //   71: iconst_m1
    //   72: putfield 탄 : I
    //   75: aload_0
    //   76: new y/苦
    //   79: dup
    //   80: aload_0
    //   81: invokespecial <init> : (Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    //   84: putfield 탈 : Ly/苦;
    //   87: aload_0
    //   88: aload_1
    //   89: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   92: ldc 2131100276
    //   94: invokevirtual getDimensionPixelSize : (I)I
    //   97: putfield 美 : I
    //   100: aload_1
    //   101: aload_2
    //   102: getstatic y/年.不 : [I
    //   105: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   108: astore #7
    //   110: iconst_3
    //   111: istore #4
    //   113: aload #7
    //   115: iconst_3
    //   116: invokevirtual hasValue : (I)Z
    //   119: ifeq -> 133
    //   122: aload_0
    //   123: aload_1
    //   124: aload #7
    //   126: iconst_3
    //   127: invokestatic 怖 : (Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    //   130: putfield 不 : Landroid/content/res/ColorStateList;
    //   133: aload #7
    //   135: bipush #20
    //   137: invokevirtual hasValue : (I)Z
    //   140: ifeq -> 163
    //   143: aload_0
    //   144: new y/wk
    //   147: dup
    //   148: aload_1
    //   149: aload_2
    //   150: ldc 2130903148
    //   152: ldc 2131755835
    //   154: invokestatic 堅 : (Landroid/content/Context;Landroid/util/AttributeSet;II)Ly/vk;
    //   157: invokespecial <init> : (Ly/vk;)V
    //   160: putfield 興 : Ly/wk;
    //   163: aload_0
    //   164: getfield 興 : Ly/wk;
    //   167: astore_2
    //   168: aload_2
    //   169: ifnonnull -> 175
    //   172: goto -> 245
    //   175: new y/u0
    //   178: dup
    //   179: aload_2
    //   180: invokespecial <init> : (Ly/wk;)V
    //   183: astore_2
    //   184: aload_0
    //   185: aload_2
    //   186: putfield 旨 : Ly/u0;
    //   189: aload_2
    //   190: aload_1
    //   191: invokevirtual 旨 : (Landroid/content/Context;)V
    //   194: aload_0
    //   195: getfield 不 : Landroid/content/res/ColorStateList;
    //   198: astore_2
    //   199: aload_2
    //   200: ifnull -> 214
    //   203: aload_0
    //   204: getfield 旨 : Ly/u0;
    //   207: aload_2
    //   208: invokevirtual 辛 : (Landroid/content/res/ColorStateList;)V
    //   211: goto -> 245
    //   214: new android/util/TypedValue
    //   217: dup
    //   218: invokespecial <init> : ()V
    //   221: astore_2
    //   222: aload_1
    //   223: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   226: ldc 16842801
    //   228: aload_2
    //   229: iconst_1
    //   230: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   233: pop
    //   234: aload_0
    //   235: getfield 旨 : Ly/u0;
    //   238: aload_2
    //   239: getfield data : I
    //   242: invokevirtual setTint : (I)V
    //   245: iconst_2
    //   246: newarray float
    //   248: dup
    //   249: iconst_0
    //   250: fconst_0
    //   251: fastore
    //   252: dup
    //   253: iconst_1
    //   254: fconst_1
    //   255: fastore
    //   256: invokestatic ofFloat : ([F)Landroid/animation/ValueAnimator;
    //   259: astore_2
    //   260: aload_0
    //   261: aload_2
    //   262: putfield 壊 : Landroid/animation/ValueAnimator;
    //   265: aload_2
    //   266: ldc2_w 500
    //   269: invokevirtual setDuration : (J)Landroid/animation/ValueAnimator;
    //   272: pop
    //   273: aload_0
    //   274: getfield 壊 : Landroid/animation/ValueAnimator;
    //   277: new y/ぱ
    //   280: dup
    //   281: iconst_0
    //   282: aload_0
    //   283: invokespecial <init> : (ILjava/lang/Object;)V
    //   286: invokevirtual addUpdateListener : (Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V
    //   289: getstatic android/os/Build$VERSION.SDK_INT : I
    //   292: istore #5
    //   294: aload_0
    //   295: aload #7
    //   297: iconst_2
    //   298: ldc -1.0
    //   300: invokevirtual getDimension : (IF)F
    //   303: putfield 寝 : F
    //   306: aload #7
    //   308: iconst_0
    //   309: invokevirtual hasValue : (I)Z
    //   312: ifeq -> 326
    //   315: aload_0
    //   316: aload #7
    //   318: iconst_0
    //   319: iconst_m1
    //   320: invokevirtual getDimensionPixelSize : (II)I
    //   323: putfield 辛 : I
    //   326: aload #7
    //   328: iconst_1
    //   329: invokevirtual hasValue : (I)Z
    //   332: ifeq -> 346
    //   335: aload_0
    //   336: aload #7
    //   338: iconst_1
    //   339: iconst_m1
    //   340: invokevirtual getDimensionPixelSize : (II)I
    //   343: putfield ぱ : I
    //   346: aload #7
    //   348: bipush #9
    //   350: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   353: astore_2
    //   354: aload_2
    //   355: ifnull -> 379
    //   358: aload_2
    //   359: getfield data : I
    //   362: istore #5
    //   364: iload #5
    //   366: iconst_m1
    //   367: if_icmpne -> 379
    //   370: aload_0
    //   371: iload #5
    //   373: invokevirtual 死 : (I)V
    //   376: goto -> 391
    //   379: aload_0
    //   380: aload #7
    //   382: bipush #9
    //   384: iconst_m1
    //   385: invokevirtual getDimensionPixelSize : (II)I
    //   388: invokevirtual 死 : (I)V
    //   391: aload #7
    //   393: bipush #8
    //   395: iconst_0
    //   396: invokevirtual getBoolean : (IZ)Z
    //   399: istore #6
    //   401: aload_0
    //   402: getfield 噛 : Z
    //   405: iload #6
    //   407: if_icmpeq -> 438
    //   410: aload_0
    //   411: iload #6
    //   413: putfield 噛 : Z
    //   416: iload #6
    //   418: ifne -> 434
    //   421: aload_0
    //   422: getfield あ : I
    //   425: iconst_5
    //   426: if_icmpne -> 434
    //   429: aload_0
    //   430: iconst_4
    //   431: invokevirtual 壊 : (I)V
    //   434: aload_0
    //   435: invokevirtual 泳 : ()V
    //   438: aload_0
    //   439: aload #7
    //   441: bipush #12
    //   443: iconst_0
    //   444: invokevirtual getBoolean : (IZ)Z
    //   447: putfield 嬉 : Z
    //   450: aload #7
    //   452: bipush #6
    //   454: iconst_1
    //   455: invokevirtual getBoolean : (IZ)Z
    //   458: istore #6
    //   460: aload_0
    //   461: getfield 堅 : Z
    //   464: iload #6
    //   466: if_icmpne -> 472
    //   469: goto -> 524
    //   472: aload_0
    //   473: iload #6
    //   475: putfield 堅 : Z
    //   478: aload_0
    //   479: getfield 코 : Ljava/lang/ref/WeakReference;
    //   482: ifnull -> 489
    //   485: aload_0
    //   486: invokevirtual 恐 : ()V
    //   489: aload_0
    //   490: getfield 堅 : Z
    //   493: ifeq -> 508
    //   496: aload_0
    //   497: getfield あ : I
    //   500: bipush #6
    //   502: if_icmpne -> 508
    //   505: goto -> 514
    //   508: aload_0
    //   509: getfield あ : I
    //   512: istore #4
    //   514: aload_0
    //   515: iload #4
    //   517: invokevirtual 帰 : (I)V
    //   520: aload_0
    //   521: invokevirtual 泳 : ()V
    //   524: aload_0
    //   525: aload #7
    //   527: bipush #11
    //   529: iconst_0
    //   530: invokevirtual getBoolean : (IZ)Z
    //   533: putfield 触 : Z
    //   536: aload_0
    //   537: aload #7
    //   539: iconst_4
    //   540: iconst_1
    //   541: invokevirtual getBoolean : (IZ)Z
    //   544: putfield 投 : Z
    //   547: aload_0
    //   548: aload #7
    //   550: bipush #10
    //   552: iconst_0
    //   553: invokevirtual getInt : (II)I
    //   556: putfield 硬 : I
    //   559: aload #7
    //   561: bipush #7
    //   563: ldc 0.5
    //   565: invokevirtual getFloat : (IF)F
    //   568: fstore_3
    //   569: fload_3
    //   570: fconst_0
    //   571: fcmpg
    //   572: ifle -> 791
    //   575: fload_3
    //   576: fconst_1
    //   577: fcmpl
    //   578: ifge -> 791
    //   581: aload_0
    //   582: fload_3
    //   583: putfield 泳 : F
    //   586: aload_0
    //   587: getfield 코 : Ljava/lang/ref/WeakReference;
    //   590: ifnull -> 607
    //   593: aload_0
    //   594: fconst_1
    //   595: fload_3
    //   596: fsub
    //   597: aload_0
    //   598: getfield 若 : I
    //   601: i2f
    //   602: fmul
    //   603: f2i
    //   604: putfield 歩 : I
    //   607: aload #7
    //   609: iconst_5
    //   610: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   613: astore_2
    //   614: aload_2
    //   615: ifnull -> 658
    //   618: aload_2
    //   619: getfield type : I
    //   622: bipush #16
    //   624: if_icmpne -> 658
    //   627: aload_2
    //   628: getfield data : I
    //   631: istore #4
    //   633: iload #4
    //   635: iflt -> 647
    //   638: aload_0
    //   639: iload #4
    //   641: putfield 帰 : I
    //   644: goto -> 678
    //   647: new java/lang/IllegalArgumentException
    //   650: dup
    //   651: ldc_w 'offset must be greater than or equal to 0'
    //   654: invokespecial <init> : (Ljava/lang/String;)V
    //   657: athrow
    //   658: aload #7
    //   660: iconst_5
    //   661: iconst_0
    //   662: invokevirtual getDimensionPixelOffset : (II)I
    //   665: istore #4
    //   667: iload #4
    //   669: iflt -> 780
    //   672: aload_0
    //   673: iload #4
    //   675: putfield 帰 : I
    //   678: aload_0
    //   679: aload #7
    //   681: bipush #16
    //   683: iconst_0
    //   684: invokevirtual getBoolean : (IZ)Z
    //   687: putfield 悲 : Z
    //   690: aload_0
    //   691: aload #7
    //   693: bipush #17
    //   695: iconst_0
    //   696: invokevirtual getBoolean : (IZ)Z
    //   699: putfield 寂 : Z
    //   702: aload_0
    //   703: aload #7
    //   705: bipush #18
    //   707: iconst_0
    //   708: invokevirtual getBoolean : (IZ)Z
    //   711: putfield 淋 : Z
    //   714: aload_0
    //   715: aload #7
    //   717: bipush #19
    //   719: iconst_1
    //   720: invokevirtual getBoolean : (IZ)Z
    //   723: putfield 怖 : Z
    //   726: aload_0
    //   727: aload #7
    //   729: bipush #13
    //   731: iconst_0
    //   732: invokevirtual getBoolean : (IZ)Z
    //   735: putfield 恐 : Z
    //   738: aload_0
    //   739: aload #7
    //   741: bipush #14
    //   743: iconst_0
    //   744: invokevirtual getBoolean : (IZ)Z
    //   747: putfield 痛 : Z
    //   750: aload_0
    //   751: aload #7
    //   753: bipush #15
    //   755: iconst_0
    //   756: invokevirtual getBoolean : (IZ)Z
    //   759: putfield 痒 : Z
    //   762: aload #7
    //   764: invokevirtual recycle : ()V
    //   767: aload_0
    //   768: aload_1
    //   769: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   772: invokevirtual getScaledMaximumFlingVelocity : ()I
    //   775: i2f
    //   776: putfield 熱 : F
    //   779: return
    //   780: new java/lang/IllegalArgumentException
    //   783: dup
    //   784: ldc_w 'offset must be greater than or equal to 0'
    //   787: invokespecial <init> : (Ljava/lang/String;)V
    //   790: athrow
    //   791: new java/lang/IllegalArgumentException
    //   794: dup
    //   795: ldc_w 'ratio must be a float value between 0 and 1'
    //   798: invokespecial <init> : (Ljava/lang/String;)V
    //   801: athrow
  }
  
  public static View 臭(View paramView) {
    WeakHashMap weakHashMap = rw.硬;
    int i = Build.VERSION.SDK_INT;
    if (gw.淋(paramView))
      return paramView; 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (i = 0; i < j; i++) {
        View view = 臭(viewGroup.getChildAt(i));
        if (view != null)
          return view; 
      } 
    } 
    return null;
  }
  
  public static int 起(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt1, paramInt2, paramInt4);
    if (paramInt3 == -1)
      return paramInt2; 
    paramInt1 = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (paramInt1 != 1073741824) {
      if (paramInt2 != 0)
        paramInt3 = Math.min(paramInt2, paramInt3); 
      return View.MeasureSpec.makeMeasureSpec(paramInt3, -2147483648);
    } 
    return View.MeasureSpec.makeMeasureSpec(Math.min(paramInt2, paramInt3), 1073741824);
  }
  
  public final void ぱ(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {}
  
  public final boolean 不(View paramView) {
    WeakReference<View> weakReference = this.쾌;
    return !(weakReference == null || paramView != weakReference.get() || this.あ == 3);
  }
  
  public final void 冷() {
    this.코 = null;
    this.か = null;
  }
  
  public final void 噛() {
    if (this.코 != null) {
      恐();
      if (this.あ == 4) {
        View view = this.코.get();
        if (view != null)
          view.requestLayout(); 
      } 
    } 
  }
  
  public final void 壊(int paramInt) {
    int i;
    boolean bool = true;
    if (paramInt == 1 || paramInt == 2) {
      String str;
      StringBuilder stringBuilder = new StringBuilder("STATE_");
      if (paramInt == 1) {
        str = "DRAGGING";
      } else {
        str = "SETTLING";
      } 
      throw new IllegalArgumentException(bm.旨(stringBuilder, str, " should not be set externally."));
    } 
    if (!this.噛 && paramInt == 5)
      return; 
    if (paramInt == 6 && this.堅 && 産(paramInt) <= this.返) {
      i = 3;
    } else {
      i = paramInt;
    } 
    WeakReference weakReference = this.코;
    if (weakReference == null || weakReference.get() == null) {
      帰(paramInt);
      return;
    } 
    View view = this.코.get();
    제 제 = new 제(this, view, i, 8, 0);
    ViewParent viewParent = view.getParent();
    if (viewParent != null && viewParent.isLayoutRequested() && rw.悲(view)) {
      paramInt = bool;
    } else {
      paramInt = 0;
    } 
    if (paramInt != 0) {
      view.post((Runnable)제);
      return;
    } 
    제.run();
  }
  
  public final void 嬉(View paramView, Parcelable paramParcelable) {
    嬉 嬉 = (嬉)paramParcelable;
    int i = this.硬;
    if (i != 0) {
      if (i == -1 || (i & 0x1) == 1)
        this.暑 = 嬉.痛; 
      if (i == -1 || (i & 0x2) == 2)
        this.堅 = 嬉.痒; 
      if (i == -1 || (i & 0x4) == 4)
        this.噛 = 嬉.臭; 
      if (i == -1 || (i & 0x8) == 8)
        this.触 = 嬉.起; 
    } 
    i = 嬉.恐;
    if (i == 1 || i == 2) {
      this.あ = 4;
      return;
    } 
    this.あ = i;
  }
  
  public final boolean 寂(View paramView, int paramInt1, int paramInt2) {
    boolean bool = false;
    this.ゃ = 0;
    this.赤 = false;
    if ((paramInt1 & 0x2) != 0)
      bool = true; 
    return bool;
  }
  
  public final boolean 寒(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    boolean bool = paramView.isShown();
    boolean bool1 = false;
    if (!bool || !this.投) {
      this.ち = true;
      return false;
    } 
    int i = paramMotionEvent.getActionMasked();
    View view = null;
    if (i == 0) {
      this.키 = -1;
      VelocityTracker velocityTracker = this.큰;
      if (velocityTracker != null) {
        velocityTracker.recycle();
        this.큰 = null;
      } 
    } 
    if (this.큰 == null)
      this.큰 = VelocityTracker.obtain(); 
    this.큰.addMovement(paramMotionEvent);
    if (i != 0) {
      if (i == 1 || i == 3) {
        this.타 = false;
        this.키 = -1;
        if (this.ち) {
          this.ち = false;
          return false;
        } 
      } 
    } else {
      int j = (int)paramMotionEvent.getX();
      this.ㅌ = (int)paramMotionEvent.getY();
      if (this.あ != 2) {
        WeakReference<View> weakReference1 = this.쾌;
        if (weakReference1 != null) {
          View view1 = weakReference1.get();
        } else {
          weakReference1 = null;
        } 
        if (weakReference1 != null && paramCoordinatorLayout.悲((View)weakReference1, j, this.ㅌ)) {
          this.키 = paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex());
          this.타 = true;
        } 
      } 
      if (this.키 == -1 && !paramCoordinatorLayout.悲(paramView, j, this.ㅌ)) {
        bool = true;
      } else {
        bool = false;
      } 
      this.ち = bool;
    } 
    if (!this.ち) {
      xw xw1 = this.か;
      if (xw1 != null && xw1.怖(paramMotionEvent))
        return true; 
    } 
    WeakReference<View> weakReference = this.쾌;
    paramView = view;
    if (weakReference != null)
      paramView = weakReference.get(); 
    bool = bool1;
    if (i == 2) {
      bool = bool1;
      if (paramView != null) {
        bool = bool1;
        if (!this.ち) {
          bool = bool1;
          if (this.あ != 1) {
            bool = bool1;
            if (!paramCoordinatorLayout.悲(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) {
              bool = bool1;
              if (this.か != null) {
                bool = bool1;
                if (Math.abs(this.ㅌ - paramMotionEvent.getY()) > this.か.堅)
                  bool = true; 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool;
  }
  
  public final void 寝(boolean paramBoolean) {
    WeakReference<View> weakReference = this.코;
    if (weakReference == null)
      return; 
    ViewParent viewParent = ((View)weakReference.get()).getParent();
    if (!(viewParent instanceof CoordinatorLayout))
      return; 
    CoordinatorLayout coordinatorLayout = (CoordinatorLayout)viewParent;
    int j = coordinatorLayout.getChildCount();
    int i = Build.VERSION.SDK_INT;
    if (paramBoolean)
      if (this.탁 == null) {
        this.탁 = new HashMap<Object, Object>(j);
      } else {
        return;
      }  
    for (i = 0; i < j; i++) {
      View view = coordinatorLayout.getChildAt(i);
      if (view != this.코.get() && paramBoolean) {
        int k = Build.VERSION.SDK_INT;
        this.탁.put(view, Integer.valueOf(view.getImportantForAccessibility()));
      } 
    } 
    if (!paramBoolean)
      this.탁 = null; 
  }
  
  public final void 帰(int paramInt) {
    if (this.あ == paramInt)
      return; 
    this.あ = paramInt;
    WeakReference<View> weakReference = this.코;
    if (weakReference == null)
      return; 
    if ((View)weakReference.get() == null)
      return; 
    if (paramInt == 3) {
      寝(true);
    } else if (paramInt == 6 || paramInt == 5 || paramInt == 4) {
      寝(false);
    } 
    踊(paramInt);
    ArrayList arrayList = this.크;
    if (arrayList.size() <= 0) {
      泳();
      return;
    } 
    bm.悲(arrayList.get(0));
    throw null;
  }
  
  public final boolean 怖(View paramView, MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual isShown : ()Z
    //   4: istore #7
    //   6: iconst_0
    //   7: istore #5
    //   9: iload #7
    //   11: ifne -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_2
    //   17: invokevirtual getActionMasked : ()I
    //   20: istore #6
    //   22: aload_0
    //   23: getfield あ : I
    //   26: istore #4
    //   28: iload #4
    //   30: iconst_1
    //   31: if_icmpne -> 41
    //   34: iload #6
    //   36: ifne -> 41
    //   39: iconst_1
    //   40: ireturn
    //   41: aload_0
    //   42: getfield か : Ly/xw;
    //   45: astore #8
    //   47: aload #8
    //   49: ifnull -> 71
    //   52: aload_0
    //   53: getfield 投 : Z
    //   56: ifne -> 65
    //   59: iload #4
    //   61: iconst_1
    //   62: if_icmpne -> 71
    //   65: iconst_1
    //   66: istore #4
    //   68: goto -> 74
    //   71: iconst_0
    //   72: istore #4
    //   74: iload #4
    //   76: ifeq -> 85
    //   79: aload #8
    //   81: aload_2
    //   82: invokevirtual 辛 : (Landroid/view/MotionEvent;)V
    //   85: iload #6
    //   87: ifne -> 116
    //   90: aload_0
    //   91: iconst_m1
    //   92: putfield 키 : I
    //   95: aload_0
    //   96: getfield 큰 : Landroid/view/VelocityTracker;
    //   99: astore #8
    //   101: aload #8
    //   103: ifnull -> 116
    //   106: aload #8
    //   108: invokevirtual recycle : ()V
    //   111: aload_0
    //   112: aconst_null
    //   113: putfield 큰 : Landroid/view/VelocityTracker;
    //   116: aload_0
    //   117: getfield 큰 : Landroid/view/VelocityTracker;
    //   120: ifnonnull -> 130
    //   123: aload_0
    //   124: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   127: putfield 큰 : Landroid/view/VelocityTracker;
    //   130: aload_0
    //   131: getfield 큰 : Landroid/view/VelocityTracker;
    //   134: aload_2
    //   135: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   138: iload #5
    //   140: istore #4
    //   142: aload_0
    //   143: getfield か : Ly/xw;
    //   146: ifnull -> 171
    //   149: aload_0
    //   150: getfield 投 : Z
    //   153: ifne -> 168
    //   156: iload #5
    //   158: istore #4
    //   160: aload_0
    //   161: getfield あ : I
    //   164: iconst_1
    //   165: if_icmpne -> 171
    //   168: iconst_1
    //   169: istore #4
    //   171: iload #4
    //   173: ifeq -> 234
    //   176: iload #6
    //   178: iconst_2
    //   179: if_icmpne -> 234
    //   182: aload_0
    //   183: getfield ち : Z
    //   186: ifne -> 234
    //   189: aload_0
    //   190: getfield ㅌ : I
    //   193: i2f
    //   194: aload_2
    //   195: invokevirtual getY : ()F
    //   198: fsub
    //   199: invokestatic abs : (F)F
    //   202: fstore_3
    //   203: aload_0
    //   204: getfield か : Ly/xw;
    //   207: astore #8
    //   209: fload_3
    //   210: aload #8
    //   212: getfield 堅 : I
    //   215: i2f
    //   216: fcmpl
    //   217: ifle -> 234
    //   220: aload #8
    //   222: aload_1
    //   223: aload_2
    //   224: aload_2
    //   225: invokevirtual getActionIndex : ()I
    //   228: invokevirtual getPointerId : (I)I
    //   231: invokevirtual 堅 : (Landroid/view/View;I)V
    //   234: aload_0
    //   235: getfield ち : Z
    //   238: iconst_1
    //   239: ixor
    //   240: ireturn
  }
  
  public final void 恐() {
    int i = 痛();
    if (this.堅) {
      this.踊 = Math.max(this.若 - i, this.返);
      return;
    } 
    this.踊 = this.若 - i;
  }
  
  public final Parcelable 悲(View paramView) {
    return (Parcelable)new 嬉(View.BaseSavedState.EMPTY_STATE, this);
  }
  
  public final boolean 旨(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = paramCoordinatorLayout.getPaddingLeft();
    paramInt1 = 起(paramInt1, paramCoordinatorLayout.getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, this.辛, marginLayoutParams.width);
    paramInt2 = paramCoordinatorLayout.getPaddingTop();
    paramView.measure(paramInt1, 起(paramInt3, paramCoordinatorLayout.getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + 0, this.ぱ, marginLayoutParams.height));
    return true;
  }
  
  public final void 歩(int paramInt, View paramView, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokevirtual 産 : (I)I
    //   5: istore #6
    //   7: aload_0
    //   8: getfield か : Ly/xw;
    //   11: astore #7
    //   13: iconst_0
    //   14: istore #5
    //   16: iload #5
    //   18: istore #4
    //   20: aload #7
    //   22: ifnull -> 117
    //   25: iload_3
    //   26: ifeq -> 50
    //   29: iload #5
    //   31: istore #4
    //   33: aload #7
    //   35: aload_2
    //   36: invokevirtual getLeft : ()I
    //   39: iload #6
    //   41: invokevirtual 淋 : (II)Z
    //   44: ifeq -> 117
    //   47: goto -> 114
    //   50: aload_2
    //   51: invokevirtual getLeft : ()I
    //   54: istore #4
    //   56: aload #7
    //   58: aload_2
    //   59: putfield 恐 : Landroid/view/View;
    //   62: aload #7
    //   64: iconst_m1
    //   65: putfield 熱 : I
    //   68: aload #7
    //   70: iload #4
    //   72: iload #6
    //   74: iconst_0
    //   75: iconst_0
    //   76: invokevirtual 不 : (IIII)Z
    //   79: istore_3
    //   80: iload_3
    //   81: ifne -> 106
    //   84: aload #7
    //   86: getfield 硬 : I
    //   89: ifne -> 106
    //   92: aload #7
    //   94: getfield 恐 : Landroid/view/View;
    //   97: ifnull -> 106
    //   100: aload #7
    //   102: aconst_null
    //   103: putfield 恐 : Landroid/view/View;
    //   106: iload #5
    //   108: istore #4
    //   110: iload_3
    //   111: ifeq -> 117
    //   114: iconst_1
    //   115: istore #4
    //   117: iload #4
    //   119: ifeq -> 141
    //   122: aload_0
    //   123: iconst_2
    //   124: invokevirtual 帰 : (I)V
    //   127: aload_0
    //   128: iload_1
    //   129: invokevirtual 踊 : (I)V
    //   132: aload_0
    //   133: getfield 死 : Ly/gq;
    //   136: iload_1
    //   137: invokevirtual 硬 : (I)V
    //   140: return
    //   141: aload_0
    //   142: iload_1
    //   143: invokevirtual 帰 : (I)V
    //   146: return
  }
  
  public final void 死(int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_1
    //   3: iconst_m1
    //   4: if_icmpne -> 22
    //   7: aload_0
    //   8: getfield 冷 : Z
    //   11: ifne -> 53
    //   14: aload_0
    //   15: iconst_1
    //   16: putfield 冷 : Z
    //   19: goto -> 51
    //   22: aload_0
    //   23: getfield 冷 : Z
    //   26: ifne -> 37
    //   29: aload_0
    //   30: getfield 暑 : I
    //   33: iload_1
    //   34: if_icmpeq -> 53
    //   37: aload_0
    //   38: iconst_0
    //   39: putfield 冷 : Z
    //   42: aload_0
    //   43: iconst_0
    //   44: iload_1
    //   45: invokestatic max : (II)I
    //   48: putfield 暑 : I
    //   51: iconst_1
    //   52: istore_2
    //   53: iload_2
    //   54: ifeq -> 61
    //   57: aload_0
    //   58: invokevirtual 噛 : ()V
    //   61: return
  }
  
  public final void 泳() {
    WeakReference<View> weakReference = this.코;
    if (weakReference == null)
      return; 
    View view = weakReference.get();
    if (view == null)
      return; 
    rw.起(view, 524288);
    rw.起(view, 262144);
    rw.起(view, 1048576);
    int i = this.탄;
    if (i != -1)
      rw.起(view, i); 
    boolean bool = this.堅;
    byte b = 6;
    if (!bool && this.あ != 6) {
      String str = view.getResources().getString(2131689518);
      r32 r32 = new r32(this, 6, 14);
      ArrayList<イ> arrayList = rw.暑(view);
      for (i = 0; i < arrayList.size(); i++) {
        if (TextUtils.equals(str, ((イ)arrayList.get(i)).堅())) {
          i = ((イ)arrayList.get(i)).硬();
          break label71;
        } 
      } 
      i = -1;
      int j = 0;
      label71: while (true) {
        int[] arrayOfInt = rw.冷;
        if (j < arrayOfInt.length && i == -1) {
          int n = arrayOfInt[j];
          int m = 0;
          int k = 1;
          while (m < arrayList.size()) {
            byte b1;
            if (((イ)arrayList.get(m)).硬() != n) {
              b1 = 1;
            } else {
              b1 = 0;
            } 
            k &= b1;
            m++;
          } 
          if (k != 0)
            i = n; 
          j++;
          continue;
        } 
        break;
      } 
      if (i != -1) {
        nul nul1;
        イ イ = new イ(null, i, str, (ッ)r32, null);
        j = Build.VERSION.SDK_INT;
        View.AccessibilityDelegate accessibilityDelegate = rw.熱(view);
        if (accessibilityDelegate == null) {
          accessibilityDelegate = null;
        } else if (accessibilityDelegate instanceof aux) {
          nul1 = ((aux)accessibilityDelegate).硬;
        } else {
          nul1 = new nul((View.AccessibilityDelegate)nul1);
        } 
        nul nul2 = nul1;
        if (nul1 == null)
          nul2 = new nul(); 
        rw.帰(view, nul2);
        rw.興(view, イ.硬());
        rw.暑(view).add(イ);
        rw.淋(view, 0);
      } 
      this.탄 = i;
    } 
    if (this.噛 && this.あ != 5)
      rw.産(view, イ.辛, (ッ)new r32(this, 5, 14)); 
    i = this.あ;
    if (i != 3) {
      if (i != 4) {
        if (i != 6)
          return; 
        rw.産(view, イ.不, (ッ)new r32(this, 4, 14));
        rw.産(view, イ.旨, (ッ)new r32(this, 3, 14));
        return;
      } 
      if (this.堅)
        b = 3; 
      rw.産(view, イ.旨, (ッ)new r32(this, b, 14));
      return;
    } 
    if (this.堅)
      b = 4; 
    rw.産(view, イ.不, (ッ)new r32(this, b, 14));
  }
  
  public final void 淋(View paramView1, View paramView2, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getTop : ()I
    //   4: istore #5
    //   6: aload_0
    //   7: invokevirtual 興 : ()I
    //   10: istore #6
    //   12: iconst_3
    //   13: istore_3
    //   14: iload #5
    //   16: iload #6
    //   18: if_icmpne -> 27
    //   21: aload_0
    //   22: iconst_3
    //   23: invokevirtual 帰 : (I)V
    //   26: return
    //   27: aload_0
    //   28: getfield 쾌 : Ljava/lang/ref/WeakReference;
    //   31: astore #7
    //   33: aload #7
    //   35: ifnull -> 304
    //   38: aload_2
    //   39: aload #7
    //   41: invokevirtual get : ()Ljava/lang/Object;
    //   44: if_acmpne -> 304
    //   47: aload_0
    //   48: getfield 赤 : Z
    //   51: ifne -> 55
    //   54: return
    //   55: aload_0
    //   56: getfield ゃ : I
    //   59: ifle -> 86
    //   62: aload_0
    //   63: getfield 堅 : Z
    //   66: ifeq -> 72
    //   69: goto -> 292
    //   72: aload_1
    //   73: invokevirtual getTop : ()I
    //   76: aload_0
    //   77: getfield 歩 : I
    //   80: if_icmple -> 292
    //   83: goto -> 284
    //   86: aload_0
    //   87: getfield 噛 : Z
    //   90: ifeq -> 147
    //   93: aload_0
    //   94: getfield 큰 : Landroid/view/VelocityTracker;
    //   97: astore_2
    //   98: aload_2
    //   99: ifnonnull -> 108
    //   102: fconst_0
    //   103: fstore #4
    //   105: goto -> 132
    //   108: aload_2
    //   109: sipush #1000
    //   112: aload_0
    //   113: getfield 熱 : F
    //   116: invokevirtual computeCurrentVelocity : (IF)V
    //   119: aload_0
    //   120: getfield 큰 : Landroid/view/VelocityTracker;
    //   123: aload_0
    //   124: getfield 키 : I
    //   127: invokevirtual getYVelocity : (I)F
    //   130: fstore #4
    //   132: aload_0
    //   133: aload_1
    //   134: fload #4
    //   136: invokevirtual 返 : (Landroid/view/View;F)Z
    //   139: ifeq -> 147
    //   142: iconst_5
    //   143: istore_3
    //   144: goto -> 292
    //   147: aload_0
    //   148: getfield ゃ : I
    //   151: ifne -> 248
    //   154: aload_1
    //   155: invokevirtual getTop : ()I
    //   158: istore #5
    //   160: aload_0
    //   161: getfield 堅 : Z
    //   164: ifeq -> 193
    //   167: iload #5
    //   169: aload_0
    //   170: getfield 返 : I
    //   173: isub
    //   174: invokestatic abs : (I)I
    //   177: iload #5
    //   179: aload_0
    //   180: getfield 踊 : I
    //   183: isub
    //   184: invokestatic abs : (I)I
    //   187: if_icmpge -> 290
    //   190: goto -> 292
    //   193: aload_0
    //   194: getfield 歩 : I
    //   197: istore #6
    //   199: iload #5
    //   201: iload #6
    //   203: if_icmpge -> 224
    //   206: iload #5
    //   208: iload #5
    //   210: aload_0
    //   211: getfield 踊 : I
    //   214: isub
    //   215: invokestatic abs : (I)I
    //   218: if_icmpge -> 284
    //   221: goto -> 292
    //   224: iload #5
    //   226: iload #6
    //   228: isub
    //   229: invokestatic abs : (I)I
    //   232: iload #5
    //   234: aload_0
    //   235: getfield 踊 : I
    //   238: isub
    //   239: invokestatic abs : (I)I
    //   242: if_icmpge -> 290
    //   245: goto -> 284
    //   248: aload_0
    //   249: getfield 堅 : Z
    //   252: ifeq -> 258
    //   255: goto -> 290
    //   258: aload_1
    //   259: invokevirtual getTop : ()I
    //   262: istore_3
    //   263: iload_3
    //   264: aload_0
    //   265: getfield 歩 : I
    //   268: isub
    //   269: invokestatic abs : (I)I
    //   272: iload_3
    //   273: aload_0
    //   274: getfield 踊 : I
    //   277: isub
    //   278: invokestatic abs : (I)I
    //   281: if_icmpge -> 290
    //   284: bipush #6
    //   286: istore_3
    //   287: goto -> 292
    //   290: iconst_4
    //   291: istore_3
    //   292: aload_0
    //   293: iload_3
    //   294: aload_1
    //   295: iconst_0
    //   296: invokevirtual 歩 : (ILandroid/view/View;Z)V
    //   299: aload_0
    //   300: iconst_0
    //   301: putfield 赤 : Z
    //   304: return
  }
  
  public final void 熱(투 param투) {
    this.코 = null;
    this.か = null;
  }
  
  public final int 産(int paramInt) {
    if (paramInt != 3) {
      if (paramInt != 4) {
        if (paramInt != 5) {
          if (paramInt == 6)
            return this.歩; 
          throw new IllegalArgumentException(bm.熱("Invalid state to get top offset: ", paramInt));
        } 
        return this.若;
      } 
      return this.踊;
    } 
    return 興();
  }
  
  public final void 痒(int paramInt) {
    if ((View)this.코.get() != null) {
      ArrayList arrayList = this.크;
      if (!arrayList.isEmpty()) {
        int i = this.踊;
        if (paramInt <= i && i != 興())
          興(); 
        if (arrayList.size() <= 0)
          return; 
        bm.悲(arrayList.get(0));
        throw null;
      } 
    } 
  }
  
  public final int 痛() {
    if (this.冷)
      return Math.min(Math.max(this.寒, this.若 - this.も * 9 / 16), this.わ) + this.臭; 
    if (!this.嬉 && !this.悲) {
      int i = this.苦;
      if (i > 0)
        return Math.max(this.暑, i + this.美); 
    } 
    return this.暑 + this.臭;
  }
  
  public final boolean 美(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    if (rw.美((View)paramCoordinatorLayout) && !rw.美(paramView))
      paramView.setFitsSystemWindows(true); 
    if (this.코 == null) {
      boolean bool;
      this.寒 = paramCoordinatorLayout.getResources().getDimensionPixelSize(2131099794);
      if (Build.VERSION.SDK_INT >= 29 && !this.嬉 && !this.冷) {
        bool = true;
      } else {
        bool = false;
      } 
      if (this.悲 || this.寂 || this.淋 || this.恐 || this.痛 || this.痒 || bool) {
        gw.臭(paramView, (z6)new 畳(new ai1(this, bool), 29, new le(rw.苦(paramView), paramView.getPaddingTop(), rw.ぱ(paramView), paramView.getPaddingBottom(), 2)));
        if (rw.悲(paramView)) {
          rw.死(paramView);
        } else {
          paramView.addOnAttachStateChangeListener((View.OnAttachStateChangeListener)new fy());
        } 
      } 
      this.코 = new WeakReference<View>(paramView);
      u0 u01 = this.旨;
      if (u01 != null) {
        rw.歩(paramView, (Drawable)u01);
        u01 = this.旨;
        float f2 = this.寝;
        float f1 = f2;
        if (f2 == -1.0F)
          f1 = rw.冷(paramView); 
        u01.不(f1);
        if (this.あ == 3) {
          bool = true;
        } else {
          bool = false;
        } 
        this.産 = bool;
        u01 = this.旨;
        if (bool) {
          f1 = 0.0F;
        } else {
          f1 = 1.0F;
        } 
        t0 t0 = u01.淋;
        if (t0.辛 != f1) {
          t0.辛 = f1;
          u01.痒 = true;
          u01.invalidateSelf();
        } 
      } else {
        ColorStateList colorStateList = this.不;
        if (colorStateList != null)
          rw.泳(paramView, colorStateList); 
      } 
      泳();
      if (rw.旨(paramView) == 0)
        rw.踊(paramView, 1); 
    } 
    if (this.か == null)
      this.か = new xw(paramCoordinatorLayout.getContext(), (ViewGroup)paramCoordinatorLayout, (ww)this.탈); 
    int i = paramView.getTop();
    paramCoordinatorLayout.淋(paramView, paramInt);
    this.も = paramCoordinatorLayout.getWidth();
    this.若 = paramCoordinatorLayout.getHeight();
    paramInt = paramView.getHeight();
    this.わ = paramInt;
    int j = this.若;
    int k = this.起;
    if (j - paramInt < k)
      if (this.怖) {
        this.わ = j;
      } else {
        this.わ = j - k;
      }  
    this.返 = Math.max(0, j - this.わ);
    float f = this.若;
    this.歩 = (int)((1.0F - this.泳) * f);
    恐();
    paramInt = this.あ;
    if (paramInt == 3) {
      rw.恐(paramView, 興());
    } else if (paramInt == 6) {
      rw.恐(paramView, this.歩);
    } else if (this.噛 && paramInt == 5) {
      rw.恐(paramView, this.若);
    } else if (paramInt == 4) {
      rw.恐(paramView, this.踊);
    } else if (paramInt == 1 || paramInt == 2) {
      rw.恐(paramView, i - paramView.getTop());
    } 
    this.쾌 = new WeakReference<View>(臭(paramView));
    ArrayList arrayList = this.크;
    if (arrayList.size() <= 0)
      return true; 
    bm.悲(arrayList.get(0));
    throw null;
  }
  
  public final int 興() {
    int i;
    if (this.堅)
      return this.返; 
    int j = this.帰;
    if (this.怖) {
      i = 0;
    } else {
      i = this.起;
    } 
    return Math.max(j, i);
  }
  
  public final void 踊(int paramInt) {
    boolean bool;
    if (paramInt == 2)
      return; 
    if (paramInt == 3) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.産 != bool) {
      this.産 = bool;
      if (this.旨 != null) {
        ValueAnimator valueAnimator = this.壊;
        if (valueAnimator != null) {
          float f;
          if (valueAnimator.isRunning()) {
            this.壊.reverse();
            return;
          } 
          if (bool) {
            f = 0.0F;
          } else {
            f = 1.0F;
          } 
          this.壊.setFloatValues(new float[] { 1.0F - f, f });
          this.壊.start();
        } 
      } 
    } 
  }
  
  public final void 辛(View paramView1, View paramView2, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    if (paramInt2 == 1)
      return; 
    WeakReference<View> weakReference = this.쾌;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (paramView2 != weakReference)
      return; 
    paramInt2 = paramView1.getTop();
    int i = paramInt2 - paramInt1;
    if (paramInt1 > 0) {
      if (i < 興()) {
        paramInt2 -= 興();
        paramArrayOfint[1] = paramInt2;
        rw.恐(paramView1, -paramInt2);
        帰(3);
      } else {
        if (!this.投)
          return; 
        paramArrayOfint[1] = paramInt1;
        rw.恐(paramView1, -paramInt1);
        帰(1);
      } 
    } else if (paramInt1 < 0 && !paramView2.canScrollVertically(-1)) {
      int j = this.踊;
      if (i <= j || this.噛) {
        if (!this.投)
          return; 
        paramArrayOfint[1] = paramInt1;
        rw.恐(paramView1, -paramInt1);
        帰(1);
      } else {
        paramInt2 -= j;
        paramArrayOfint[1] = paramInt2;
        rw.恐(paramView1, -paramInt2);
        帰(4);
      } 
    } 
    痒(paramView1.getTop());
    this.ゃ = paramInt1;
    this.赤 = true;
  }
  
  public final boolean 返(View paramView, float paramFloat) {
    if (this.触)
      return true; 
    if (paramView.getTop() < this.踊)
      return false; 
    int i = 痛();
    return (Math.abs(paramFloat * 0.1F + paramView.getTop() - this.踊) / i > 0.5F);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\android\material\bottomsheet\BottomSheetBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */