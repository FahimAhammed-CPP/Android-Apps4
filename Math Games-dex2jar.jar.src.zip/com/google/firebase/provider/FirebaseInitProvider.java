package com.google.firebase.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import java.util.concurrent.atomic.AtomicBoolean;
import y.強;

public class FirebaseInitProvider extends ContentProvider {
  public static final AtomicBoolean 怖;
  
  public static final 強 淋 = new 強(System.currentTimeMillis(), SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
  
  static {
    怖 = new AtomicBoolean(false);
  }
  
  public final void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    if (paramProviderInfo != null) {
      if (!"com.google.firebase.firebaseinitprovider".equals(paramProviderInfo.authority)) {
        super.attachInfo(paramContext, paramProviderInfo);
        return;
      } 
      throw new IllegalStateException("Incorrect provider authority in manifest. Most likely due to a missing applicationId variable in application's build.gradle.");
    } 
    throw new NullPointerException("FirebaseInitProvider ProviderInfo cannot be null.");
  }
  
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public final String getType(Uri paramUri) {
    return null;
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public final boolean onCreate() {
    try {
      null = 怖;
      null.set(true);
      Context context = getContext();
    } finally {
      怖.set(false);
    } 
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    return null;
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\provider\FirebaseInitProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */