package com.google.firebase;

import android.content.Context;
import android.os.Build;
import com.google.firebase.components.ComponentRegistrar;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import y.eb;
import y.instanceof;
import y.qe1;
import y.二;
import y.勉;
import y.鼻;
import y.난;
import y.남;
import y.눈;
import y.댁;
import y.색;
import y.적;
import y.전;
import y.휘;
import y.휴;
import y.휼;

public class FirebaseCommonRegistrar implements ComponentRegistrar {
  public static String 硬(String paramString) {
    return paramString.replace(' ', '_').replace('/', '_');
  }
  
  public final List getComponents() {
    ArrayList<전> arrayList = new ArrayList();
    적 적1 = new 적(눈.class, new Class[0]);
    적1.硬(new 댁(2, 0, 勉.class));
    적1.美 = new instanceof(6);
    arrayList.add(적1.堅());
    eb eb = new eb(二.class, Executor.class);
    적 적2 = new 적(남.class, new Class[] { 휴.class, 휼.class });
    적2.硬(댁.硬(Context.class));
    적2.硬(댁.硬(색.class));
    적2.硬(new 댁(2, 0, 휘.class));
    적2.硬(new 댁(1, 1, 눈.class));
    적2.硬(new 댁(eb, 1, 0));
    적2.美 = new 난(eb, 0);
    arrayList.add(적2.堅());
    arrayList.add(qe1.暑("fire-android", String.valueOf(Build.VERSION.SDK_INT)));
    arrayList.add(qe1.暑("fire-core", "20.3.0"));
    arrayList.add(qe1.暑("device-name", 硬(Build.PRODUCT)));
    arrayList.add(qe1.暑("device-model", 硬(Build.DEVICE)));
    arrayList.add(qe1.暑("device-brand", 硬(Build.BRAND)));
    arrayList.add(qe1.寒("android-target-sdk", new instanceof(0)));
    arrayList.add(qe1.寒("android-min-sdk", new instanceof(1)));
    arrayList.add(qe1.寒("android-platform", new instanceof(2)));
    arrayList.add(qe1.寒("android-installer", new instanceof(3)));
    try {
      鼻.怖.getClass();
      String str = "1.8.10";
    } catch (NoClassDefFoundError noClassDefFoundError) {
      noClassDefFoundError = null;
    } 
    if (noClassDefFoundError != null)
      arrayList.add(qe1.暑("kotlin", (String)noClassDefFoundError)); 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\FirebaseCommonRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */