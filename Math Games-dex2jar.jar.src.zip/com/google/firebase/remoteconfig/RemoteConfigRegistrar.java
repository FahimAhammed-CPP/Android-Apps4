package com.google.firebase.remoteconfig;

import android.content.Context;
import androidx.annotation.Keep;
import com.google.firebase.components.ComponentRegistrar;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;
import y.eb;
import y.implements;
import y.ps;
import y.qe1;
import y.qf;
import y.レ;
import y.旨;
import y.난;
import y.댁;
import y.삼;
import y.색;
import y.석;
import y.적;
import y.전;
import y.종;

@Keep
public class RemoteConfigRegistrar implements ComponentRegistrar {
  private static final String LIBRARY_NAME = "fire-rc";
  
  private static qf lambda$getComponents$0(eb parameb, 종 param종) {
    Context context = (Context)param종.硬(Context.class);
    Executor executor = (Executor)param종.熱(parameb);
    색 색 = (색)param종.硬(색.class);
    석 석 = (석)param종.硬(석.class);
    synchronized ((implements)param종.硬(implements.class)) {
      if (!null.硬.containsKey("frc"))
        null.硬.put("frc", new 삼()); 
      삼 삼 = (삼)null.硬.get("frc");
      return new qf(context, executor, 색, 석, 삼, param종.冷(レ.class));
    } 
  }
  
  public List<전> getComponents() {
    boolean bool;
    eb eb = new eb(旨.class, Executor.class);
    적 적 = new 적(qf.class, new Class[0]);
    적.熱 = "fire-rc";
    적.硬(댁.硬(Context.class));
    적.硬(new 댁(eb, 1, 0));
    적.硬(댁.硬(색.class));
    적.硬(댁.硬(석.class));
    적.硬(댁.硬(implements.class));
    적.硬(new 댁(0, 1, レ.class));
    적.美 = new 난(eb, 1);
    if (적.硬 == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      적.硬 = 2;
      return Arrays.asList(new 전[] { 적.堅(), qe1.暑("fire-rc", "21.2.1") });
    } 
    throw new IllegalStateException("Instantiation type has already been set.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\remoteconfig\RemoteConfigRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */