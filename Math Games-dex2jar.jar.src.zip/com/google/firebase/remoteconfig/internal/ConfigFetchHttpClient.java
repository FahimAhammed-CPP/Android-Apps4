package com.google.firebase.remoteconfig.internal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.Keep;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;
import y.m8;
import y.섬;
import y.지;

public class ConfigFetchHttpClient {
  public static final Pattern 寒 = Pattern.compile("^[^:]+:([0-9]+):(android|ios|web):([0-9a-f]+)");
  
  public final long 冷;
  
  public final String 堅;
  
  public final long 暑;
  
  public final String 熱;
  
  public final Context 硬;
  
  public ConfigFetchHttpClient(Context paramContext, String paramString1, String paramString2, long paramLong1, long paramLong2) {
    this.硬 = paramContext;
    this.堅 = paramString1;
    this.熱 = paramString2;
    Matcher matcher = 寒.matcher(paramString1);
    if (matcher.matches())
      matcher.group(1); 
    this.暑 = paramLong1;
    this.冷 = paramLong2;
  }
  
  public static JSONObject 堅(URLConnection paramURLConnection) {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramURLConnection.getInputStream(), "utf-8"));
    StringBuilder stringBuilder = new StringBuilder();
    while (true) {
      int i = bufferedReader.read();
      if (i != -1) {
        stringBuilder.append((char)i);
        continue;
      } 
      return new JSONObject(stringBuilder.toString());
    } 
  }
  
  public static void 熱(HttpURLConnection paramHttpURLConnection, byte[] paramArrayOfbyte) {
    paramHttpURLConnection.setFixedLengthStreamingMode(paramArrayOfbyte.length);
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramHttpURLConnection.getOutputStream());
    bufferedOutputStream.write(paramArrayOfbyte);
    bufferedOutputStream.flush();
    bufferedOutputStream.close();
  }
  
  @Keep
  public 지 fetch(HttpURLConnection paramHttpURLConnection, String paramString1, String paramString2, Map<String, String> paramMap1, String paramString3, Map<String, String> paramMap2, Long paramLong, Date paramDate) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #10
    //   3: aload_1
    //   4: iconst_1
    //   5: invokevirtual setDoOutput : (Z)V
    //   8: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   11: astore #14
    //   13: aload_1
    //   14: aload #14
    //   16: aload_0
    //   17: getfield 暑 : J
    //   20: invokevirtual toMillis : (J)J
    //   23: l2i
    //   24: invokevirtual setConnectTimeout : (I)V
    //   27: aload_1
    //   28: aload #14
    //   30: aload_0
    //   31: getfield 冷 : J
    //   34: invokevirtual toMillis : (J)J
    //   37: l2i
    //   38: invokevirtual setReadTimeout : (I)V
    //   41: aload_1
    //   42: ldc 'If-None-Match'
    //   44: aload #5
    //   46: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   49: aload_1
    //   50: ldc 'X-Goog-Api-Key'
    //   52: aload_0
    //   53: getfield 熱 : Ljava/lang/String;
    //   56: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   59: aload_0
    //   60: getfield 硬 : Landroid/content/Context;
    //   63: astore #16
    //   65: aload_1
    //   66: ldc 'X-Android-Package'
    //   68: aload #16
    //   70: invokevirtual getPackageName : ()Ljava/lang/String;
    //   73: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   76: aconst_null
    //   77: astore #14
    //   79: aload #16
    //   81: invokevirtual getPackageName : ()Ljava/lang/String;
    //   84: astore #5
    //   86: aload #16
    //   88: invokestatic 硬 : (Landroid/content/Context;)Ly/男;
    //   91: aload #5
    //   93: bipush #64
    //   95: invokevirtual 悲 : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   98: astore #17
    //   100: aload #17
    //   102: getfield signatures : [Landroid/content/pm/Signature;
    //   105: astore #5
    //   107: iconst_0
    //   108: istore #11
    //   110: aload #5
    //   112: ifnull -> 767
    //   115: aload #5
    //   117: arraylength
    //   118: iconst_1
    //   119: if_icmpne -> 767
    //   122: iconst_0
    //   123: istore #9
    //   125: iload #9
    //   127: iconst_2
    //   128: if_icmpge -> 156
    //   131: ldc 'SHA1'
    //   133: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   136: astore #15
    //   138: aload #15
    //   140: astore #5
    //   142: aload #15
    //   144: ifnonnull -> 159
    //   147: iload #9
    //   149: iconst_1
    //   150: iadd
    //   151: istore #9
    //   153: goto -> 125
    //   156: aconst_null
    //   157: astore #5
    //   159: aload #5
    //   161: ifnonnull -> 167
    //   164: goto -> 767
    //   167: aload #5
    //   169: aload #17
    //   171: getfield signatures : [Landroid/content/pm/Signature;
    //   174: iconst_0
    //   175: aaload
    //   176: invokevirtual toByteArray : ()[B
    //   179: invokevirtual digest : ([B)[B
    //   182: astore #5
    //   184: goto -> 187
    //   187: aload #5
    //   189: ifnonnull -> 201
    //   192: aload #16
    //   194: invokevirtual getPackageName : ()Ljava/lang/String;
    //   197: pop
    //   198: goto -> 298
    //   201: aload #5
    //   203: arraylength
    //   204: istore #12
    //   206: new java/lang/StringBuilder
    //   209: dup
    //   210: iload #12
    //   212: iload #12
    //   214: iadd
    //   215: invokespecial <init> : (I)V
    //   218: astore #15
    //   220: iload #11
    //   222: istore #9
    //   224: iload #9
    //   226: iload #12
    //   228: if_icmpge -> 282
    //   231: getstatic y/p31.熱 : [C
    //   234: astore #17
    //   236: aload #15
    //   238: aload #17
    //   240: aload #5
    //   242: iload #9
    //   244: baload
    //   245: sipush #240
    //   248: iand
    //   249: iconst_4
    //   250: iushr
    //   251: caload
    //   252: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   255: pop
    //   256: aload #15
    //   258: aload #17
    //   260: aload #5
    //   262: iload #9
    //   264: baload
    //   265: bipush #15
    //   267: iand
    //   268: caload
    //   269: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   272: pop
    //   273: iload #9
    //   275: iconst_1
    //   276: iadd
    //   277: istore #9
    //   279: goto -> 224
    //   282: aload #15
    //   284: invokevirtual toString : ()Ljava/lang/String;
    //   287: astore #5
    //   289: goto -> 301
    //   292: aload #16
    //   294: invokevirtual getPackageName : ()Ljava/lang/String;
    //   297: pop
    //   298: aconst_null
    //   299: astore #5
    //   301: aload_1
    //   302: ldc 'X-Android-Cert'
    //   304: aload #5
    //   306: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   309: aload_1
    //   310: ldc 'X-Google-GFE-Can-Retry'
    //   312: ldc 'yes'
    //   314: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   317: aload_1
    //   318: ldc 'X-Goog-Firebase-Installations-Auth'
    //   320: aload_3
    //   321: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   324: aload_1
    //   325: ldc 'Content-Type'
    //   327: ldc 'application/json'
    //   329: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   332: aload_1
    //   333: ldc 'Accept'
    //   335: ldc 'application/json'
    //   337: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   340: aload #6
    //   342: invokeinterface entrySet : ()Ljava/util/Set;
    //   347: invokeinterface iterator : ()Ljava/util/Iterator;
    //   352: astore #5
    //   354: aload #5
    //   356: invokeinterface hasNext : ()Z
    //   361: ifeq -> 403
    //   364: aload #5
    //   366: invokeinterface next : ()Ljava/lang/Object;
    //   371: checkcast java/util/Map$Entry
    //   374: astore #6
    //   376: aload_1
    //   377: aload #6
    //   379: invokeinterface getKey : ()Ljava/lang/Object;
    //   384: checkcast java/lang/String
    //   387: aload #6
    //   389: invokeinterface getValue : ()Ljava/lang/Object;
    //   394: checkcast java/lang/String
    //   397: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   400: goto -> 354
    //   403: aload_1
    //   404: aload_0
    //   405: aload_2
    //   406: aload_3
    //   407: aload #4
    //   409: aload #7
    //   411: invokevirtual 硬 : (Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Long;)Lorg/json/JSONObject;
    //   414: invokevirtual toString : ()Ljava/lang/String;
    //   417: ldc 'utf-8'
    //   419: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   422: invokestatic 熱 : (Ljava/net/HttpURLConnection;[B)V
    //   425: aload_1
    //   426: invokevirtual connect : ()V
    //   429: aload_1
    //   430: invokevirtual getResponseCode : ()I
    //   433: sipush #200
    //   436: if_icmpne -> 671
    //   439: aload_1
    //   440: ldc_w 'ETag'
    //   443: invokevirtual getHeaderField : (Ljava/lang/String;)Ljava/lang/String;
    //   446: pop
    //   447: aload_1
    //   448: invokestatic 堅 : (Ljava/net/URLConnection;)Lorg/json/JSONObject;
    //   451: astore_2
    //   452: aload_1
    //   453: invokevirtual disconnect : ()V
    //   456: aload_1
    //   457: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   460: invokevirtual close : ()V
    //   463: aload_2
    //   464: ldc_w 'state'
    //   467: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   470: ldc_w 'NO_CHANGE'
    //   473: invokevirtual equals : (Ljava/lang/Object;)Z
    //   476: istore #13
    //   478: iconst_1
    //   479: iload #13
    //   481: ixor
    //   482: istore #9
    //   484: goto -> 487
    //   487: iload #9
    //   489: ifne -> 500
    //   492: new y/지
    //   495: dup
    //   496: invokespecial <init> : ()V
    //   499: areturn
    //   500: getstatic y/증.堅 : Ljava/util/Date;
    //   503: astore_1
    //   504: new y/ts
    //   507: dup
    //   508: bipush #13
    //   510: invokespecial <init> : (I)V
    //   513: astore_3
    //   514: aload_3
    //   515: aload #8
    //   517: putfield 堅 : Ljava/lang/Object;
    //   520: aload_2
    //   521: ldc_w 'entries'
    //   524: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   527: astore_1
    //   528: goto -> 533
    //   531: aconst_null
    //   532: astore_1
    //   533: aload_1
    //   534: ifnull -> 552
    //   537: aload_3
    //   538: new org/json/JSONObject
    //   541: dup
    //   542: aload_1
    //   543: invokevirtual toString : ()Ljava/lang/String;
    //   546: invokespecial <init> : (Ljava/lang/String;)V
    //   549: putfield 硬 : Ljava/lang/Object;
    //   552: aload_2
    //   553: ldc_w 'experimentDescriptions'
    //   556: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   559: astore_1
    //   560: goto -> 565
    //   563: aconst_null
    //   564: astore_1
    //   565: aload_1
    //   566: ifnull -> 584
    //   569: aload_3
    //   570: new org/json/JSONArray
    //   573: dup
    //   574: aload_1
    //   575: invokevirtual toString : ()Ljava/lang/String;
    //   578: invokespecial <init> : (Ljava/lang/String;)V
    //   581: putfield 熱 : Ljava/lang/Object;
    //   584: aload_2
    //   585: ldc_w 'personalizationMetadata'
    //   588: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   591: astore_1
    //   592: goto -> 595
    //   595: aload_1
    //   596: ifnull -> 614
    //   599: aload_3
    //   600: new org/json/JSONObject
    //   603: dup
    //   604: aload_1
    //   605: invokevirtual toString : ()Ljava/lang/String;
    //   608: invokespecial <init> : (Ljava/lang/String;)V
    //   611: putfield 暑 : Ljava/lang/Object;
    //   614: new y/증
    //   617: dup
    //   618: aload_3
    //   619: getfield 硬 : Ljava/lang/Object;
    //   622: checkcast org/json/JSONObject
    //   625: aload_3
    //   626: getfield 堅 : Ljava/lang/Object;
    //   629: checkcast java/util/Date
    //   632: aload_3
    //   633: getfield 熱 : Ljava/lang/Object;
    //   636: checkcast org/json/JSONArray
    //   639: aload_3
    //   640: getfield 暑 : Ljava/lang/Object;
    //   643: checkcast org/json/JSONObject
    //   646: invokespecial <init> : (Lorg/json/JSONObject;Ljava/util/Date;Lorg/json/JSONArray;Lorg/json/JSONObject;)V
    //   649: pop
    //   650: new y/지
    //   653: dup
    //   654: invokespecial <init> : ()V
    //   657: areturn
    //   658: astore_1
    //   659: new y/섬
    //   662: dup
    //   663: ldc_w 'Fetch failed: fetch response could not be parsed.'
    //   666: aload_1
    //   667: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Exception;)V
    //   670: athrow
    //   671: new y/섬
    //   674: dup
    //   675: aload_1
    //   676: invokevirtual getResponseMessage : ()Ljava/lang/String;
    //   679: invokespecial <init> : (Ljava/lang/String;)V
    //   682: athrow
    //   683: astore_2
    //   684: goto -> 688
    //   687: astore_2
    //   688: new y/섬
    //   691: dup
    //   692: ldc_w 'The client had an error while calling the backend!'
    //   695: aload_2
    //   696: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Exception;)V
    //   699: athrow
    //   700: astore_2
    //   701: aload_1
    //   702: invokevirtual disconnect : ()V
    //   705: aload_1
    //   706: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   709: invokevirtual close : ()V
    //   712: aload_2
    //   713: athrow
    //   714: astore #5
    //   716: goto -> 292
    //   719: astore #5
    //   721: goto -> 147
    //   724: astore_1
    //   725: goto -> 463
    //   728: astore_1
    //   729: iload #10
    //   731: istore #9
    //   733: goto -> 487
    //   736: astore_1
    //   737: goto -> 531
    //   740: astore_1
    //   741: goto -> 552
    //   744: astore_1
    //   745: goto -> 563
    //   748: astore_1
    //   749: goto -> 584
    //   752: astore_1
    //   753: aload #14
    //   755: astore_1
    //   756: goto -> 595
    //   759: astore_1
    //   760: goto -> 614
    //   763: astore_1
    //   764: goto -> 712
    //   767: aconst_null
    //   768: astore #5
    //   770: goto -> 187
    // Exception table:
    //   from	to	target	type
    //   79	107	714	android/content/pm/PackageManager$NameNotFoundException
    //   115	122	714	android/content/pm/PackageManager$NameNotFoundException
    //   131	138	719	java/security/NoSuchAlgorithmException
    //   131	138	714	android/content/pm/PackageManager$NameNotFoundException
    //   167	184	714	android/content/pm/PackageManager$NameNotFoundException
    //   192	198	714	android/content/pm/PackageManager$NameNotFoundException
    //   201	220	714	android/content/pm/PackageManager$NameNotFoundException
    //   231	273	714	android/content/pm/PackageManager$NameNotFoundException
    //   282	289	714	android/content/pm/PackageManager$NameNotFoundException
    //   403	452	687	java/io/IOException
    //   403	452	683	org/json/JSONException
    //   403	452	700	finally
    //   456	463	724	java/io/IOException
    //   463	478	728	org/json/JSONException
    //   500	520	658	org/json/JSONException
    //   520	528	736	org/json/JSONException
    //   537	552	740	org/json/JSONException
    //   552	560	744	org/json/JSONException
    //   569	584	748	org/json/JSONException
    //   584	592	752	org/json/JSONException
    //   599	614	759	org/json/JSONException
    //   614	650	658	org/json/JSONException
    //   671	683	687	java/io/IOException
    //   671	683	683	org/json/JSONException
    //   671	683	700	finally
    //   688	700	700	finally
    //   705	712	763	java/io/IOException
  }
  
  public final JSONObject 硬(String paramString1, String paramString2, Map paramMap, Long paramLong) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramString1 != null) {
      hashMap.put("appInstanceId", paramString1);
      hashMap.put("appInstanceIdToken", paramString2);
      hashMap.put("appId", this.堅);
      Context context = this.硬;
      Locale locale = (context.getResources().getConfiguration()).locale;
      hashMap.put("countryCode", locale.getCountry());
      int i = Build.VERSION.SDK_INT;
      hashMap.put("languageCode", locale.toLanguageTag());
      hashMap.put("platformVersion", Integer.toString(i));
      hashMap.put("timeZone", TimeZone.getDefault().getID());
      try {
        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        if (packageInfo != null) {
          long l;
          hashMap.put("appVersion", packageInfo.versionName);
          if (i >= 28) {
            l = m8.堅(packageInfo);
          } else {
            l = packageInfo.versionCode;
          } 
          hashMap.put("appBuild", Long.toString(l));
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
      hashMap.put("packageName", context.getPackageName());
      hashMap.put("sdkVersion", "21.2.1");
      hashMap.put("analyticsUserProperties", new JSONObject(paramMap));
      if (paramLong != null) {
        long l = paramLong.longValue();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        hashMap.put("firstOpenTime", simpleDateFormat.format(Long.valueOf(l)));
      } 
      return new JSONObject(hashMap);
    } 
    throw new 섬();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\remoteconfig\internal\ConfigFetchHttpClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */