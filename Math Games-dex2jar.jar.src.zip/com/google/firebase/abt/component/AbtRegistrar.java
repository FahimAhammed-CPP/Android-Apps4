package com.google.firebase.abt.component;

import android.content.Context;
import androidx.annotation.Keep;
import com.google.firebase.components.ComponentRegistrar;
import java.util.Arrays;
import java.util.List;
import y.implements;
import y.instanceof;
import y.ps;
import y.qe1;
import y.レ;
import y.댁;
import y.적;
import y.전;
import y.종;

@Keep
public class AbtRegistrar implements ComponentRegistrar {
  private static final String LIBRARY_NAME = "fire-abt";
  
  public List<전> getComponents() {
    적 적 = new 적(implements.class, new Class[0]);
    적.熱 = "fire-abt";
    적.硬(댁.硬(Context.class));
    적.硬(new 댁(0, 1, レ.class));
    적.美 = new instanceof(0);
    return Arrays.asList(new 전[] { 적.堅(), qe1.暑("fire-abt", "21.1.0") });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\abt\component\AbtRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */