package com.google.firebase.components;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class ComponentDiscoveryService extends Service {
  public final IBinder onBind(Intent paramIntent) {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\components\ComponentDiscoveryService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */