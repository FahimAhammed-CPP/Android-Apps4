package com.google.firebase.components;

import java.util.List;

public interface ComponentRegistrar {
  List getComponents();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\components\ComponentRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */