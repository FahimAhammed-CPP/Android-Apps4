package com.google.firebase.concurrent;

import android.annotation.SuppressLint;
import com.google.firebase.components.ComponentRegistrar;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import y.cu;
import y.eb;
import y.instanceof;
import y.la;
import y.だ;
import y.二;
import y.旨;
import y.耳;
import y.전;
import y.주;
import y.줄;

@SuppressLint({"ThreadPoolCreation"})
public class ExecutorsRegistrar implements ComponentRegistrar {
  public static final 耳 堅;
  
  public static final 耳 暑;
  
  public static final 耳 熱;
  
  public static final 耳 硬 = new 耳((la)new 줄(2));
  
  static {
    堅 = new 耳((la)new 줄(3));
    熱 = new 耳((la)new 줄(4));
    暑 = new 耳((la)new 줄(5));
  }
  
  public final List getComponents() {
    eb eb1 = new eb(二.class, ScheduledExecutorService.class);
    eb[] arrayOfEb1 = new eb[2];
    arrayOfEb1[0] = new eb(二.class, ExecutorService.class);
    arrayOfEb1[1] = new eb(二.class, Executor.class);
    HashSet<eb> hashSet = new HashSet();
    HashSet<?> hashSet1 = new HashSet();
    HashSet<?> hashSet2 = new HashSet();
    hashSet.add(eb1);
    int j = arrayOfEb1.length;
    int i = 0;
    while (i < j) {
      if (arrayOfEb1[i] != null) {
        i++;
        continue;
      } 
      throw new NullPointerException("Null interface");
    } 
    Collections.addAll(hashSet, arrayOfEb1);
    instanceof instanceof1 = new instanceof(1);
    전 전1 = new 전(null, new HashSet<eb>(hashSet), new HashSet(hashSet1), 0, 0, (주)instanceof1, hashSet2);
    eb eb2 = new eb(旨.class, ScheduledExecutorService.class);
    eb[] arrayOfEb2 = new eb[2];
    arrayOfEb2[0] = new eb(旨.class, ExecutorService.class);
    arrayOfEb2[1] = new eb(旨.class, Executor.class);
    hashSet1 = new HashSet();
    hashSet2 = new HashSet();
    HashSet<?> hashSet3 = new HashSet();
    hashSet1.add(eb2);
    j = arrayOfEb2.length;
    i = 0;
    while (i < j) {
      if (arrayOfEb2[i] != null) {
        i++;
        continue;
      } 
      throw new NullPointerException("Null interface");
    } 
    Collections.addAll(hashSet1, (Object[])arrayOfEb2);
    instanceof instanceof2 = new instanceof(2);
    전 전2 = new 전(null, new HashSet(hashSet1), new HashSet(hashSet2), 0, 0, (주)instanceof2, hashSet3);
    eb eb3 = new eb(だ.class, ScheduledExecutorService.class);
    eb[] arrayOfEb3 = new eb[2];
    arrayOfEb3[0] = new eb(だ.class, ExecutorService.class);
    arrayOfEb3[1] = new eb(だ.class, Executor.class);
    hashSet2 = new HashSet();
    hashSet3 = new HashSet();
    HashSet<?> hashSet4 = new HashSet();
    hashSet2.add(eb3);
    j = arrayOfEb3.length;
    i = 0;
    while (i < j) {
      if (arrayOfEb3[i] != null) {
        i++;
        continue;
      } 
      throw new NullPointerException("Null interface");
    } 
    Collections.addAll(hashSet2, (Object[])arrayOfEb3);
    instanceof instanceof3 = new instanceof(3);
    전 전3 = new 전(null, new HashSet(hashSet2), new HashSet(hashSet3), 0, 0, (주)instanceof3, hashSet4);
    eb eb4 = new eb(cu.class, Executor.class);
    hashSet3 = new HashSet();
    hashSet4 = new HashSet();
    HashSet hashSet5 = new HashSet();
    hashSet3.add(eb4);
    Collections.addAll(hashSet3, (Object[])new eb[0]);
    instanceof instanceof4 = new instanceof(4);
    return Arrays.asList(new 전[] { 전1, 전2, 전3, new 전(null, new HashSet(hashSet3), new HashSet(hashSet4), 0, 0, (주)instanceof4, hashSet5) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\concurrent\ExecutorsRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */