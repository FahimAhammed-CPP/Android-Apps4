package com.google.firebase.installations;

import androidx.annotation.Keep;
import com.google.firebase.components.ComponentRegistrar;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import y.eb;
import y.instanceof;
import y.mk;
import y.ps;
import y.qe1;
import y.二;
import y.旨;
import y.댁;
import y.색;
import y.서;
import y.석;
import y.저;
import y.적;
import y.전;
import y.종;
import y.주;
import y.휘;
import y.휴;

@Keep
public class FirebaseInstallationsRegistrar implements ComponentRegistrar {
  private static final String LIBRARY_NAME = "fire-installations";
  
  private static 석 lambda$getComponents$0(종 param종) {
    색 색 = (색)param종.硬(색.class);
    param종.冷(휴.class);
    ExecutorService executorService = (ExecutorService)param종.熱(new eb(二.class, ExecutorService.class));
    new mk((Executor)param종.熱(new eb(旨.class, Executor.class)));
    return (석)new 서(색);
  }
  
  public List<전> getComponents() {
    적 적 = new 적(석.class, new Class[0]);
    적.熱 = "fire-installations";
    적.硬(댁.硬(색.class));
    적.硬(new 댁(0, 1, 휴.class));
    적.硬(new 댁(new eb(二.class, ExecutorService.class), 1, 0));
    적.硬(new 댁(new eb(旨.class, Executor.class), 1, 0));
    적.美 = new instanceof(5);
    전 전 = 적.堅();
    휘 휘 = new 휘(0, null);
    HashSet<eb> hashSet = new HashSet();
    HashSet<?> hashSet1 = new HashSet();
    HashSet hashSet2 = new HashSet();
    hashSet.add(eb.硬(휘.class));
    저 저 = new 저(1, 휘);
    return Arrays.asList(new 전[] { 전, new 전(null, new HashSet<eb>(hashSet), new HashSet(hashSet1), 0, 1, (주)저, hashSet2), qe1.暑("fire-installations", "17.1.2") });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\google\firebase\installations\FirebaseInstallationsRegistrar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */