package com.squareup.picasso;

import y.범;

public final class RemoteException extends 범 {
  public RemoteException() {
    super(null);
  }
  
  public final String getLocalizedMessage() {
    return "Picasso config init failed";
  }
  
  public final Throwable initCause(Throwable paramThrowable) {
    return super.initCause(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\com\squareup\picasso\RemoteException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */