package ocos.mathset.ui;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.activity.do;
import androidx.lifecycle.for;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import y.a0;
import y.a1;
import y.ab;
import y.bb;
import y.ci0;
import y.eq0;
import y.h;
import y.i00;
import y.ik;
import y.jf;
import y.ks;
import y.kx;
import y.nf;
import y.oy0;
import y.sb;
import y.sd;
import y.u;
import y.v;
import y.v1;
import y.wn;
import y.z;
import y.z0;
import y.ア;
import y.密;
import y.役;
import y.殻;
import y.男;
import y.腕;
import y.行;
import y.足;
import y.辞;
import y.遊;
import y.鏡;
import y.鼠;
import y.각;
import y.개;
import y.꽃;
import y.년;
import y.뚜;
import y.본;
import y.융;
import y.채;
import y.팔;
import y.퍼;

public final class MatchGameActivity extends ab {
  public eq0 師;
  
  public final kx 護;
  
  public MatchGameActivity() {
    行 行 = 行.ゃ;
    this.護 = new kx(jf.硬(bb.class), new ア((do)this, 3), 行, new 足((do)this, 1));
  }
  
  public final void う() {
    eq0 eq02 = this.師;
    eq0 eq04 = null;
    if (eq02 == null) {
      eq03 = null;
    } else {
      eq03 = eq02;
    } 
    this.퉁 = (RelativeLayout)eq03.怖;
    eq0 eq03 = eq02;
    if (eq02 == null)
      eq03 = null; 
    Button button = (Button)eq03.辛;
    ArrayList<Button> arrayList = this.투;
    arrayList.add(button);
    eq03 = this.師;
    eq0 eq01 = eq03;
    if (eq03 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.嬉);
    eq03 = this.師;
    eq01 = eq03;
    if (eq03 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.苦);
    eq03 = this.師;
    eq01 = eq03;
    if (eq03 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.不);
    eq03 = this.師;
    eq01 = eq03;
    if (eq03 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.旨);
    eq01 = this.師;
    if (eq01 == null)
      eq01 = eq04; 
    arrayList.add((Button)eq01.ぱ);
  }
  
  public final int か() {
    int i = 腕.怖;
    return 0;
  }
  
  public final void く(int paramInt1, int paramInt2, int paramInt3) {
    for (Button button : this.퇴) {
      z0 z0 = new z0();
      this.う.add(z0);
      z0.硬 = new 본(button, 타());
      ((Button)(z0.硬()).硬).setVisibility(0);
      あ(z0);
    } 
  }
  
  public final void し() {
    int i = nf.硬;
    this.ぼ = null;
    this.僕 = null;
    僕();
  }
  
  public final void た() {
    // Byte code:
    //   0: aload_0
    //   1: getfield ょ : Ljava/util/ArrayList;
    //   4: invokevirtual iterator : ()Ljava/util/Iterator;
    //   7: astore_2
    //   8: aload_2
    //   9: invokeinterface hasNext : ()Z
    //   14: ifeq -> 37
    //   17: aload_2
    //   18: invokeinterface next : ()Ljava/lang/Object;
    //   23: checkcast y/z0
    //   26: getfield 暑 : Z
    //   29: ifne -> 8
    //   32: iconst_0
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_1
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 47
    //   43: aload_0
    //   44: invokevirtual 者 : ()V
    //   47: return
  }
  
  public final int ち() {
    int i = 腕.怖;
    return 0;
  }
  
  public final void ぼ() {
    this.ぼ.熱();
    this.ぼ = null;
  }
  
  public final void ょ() {
    RelativeLayout relativeLayout;
    View view = getLayoutInflater().inflate(2131427369, null, false);
    int i = 2131230801;
    Button button = (Button)꽃.産(view, 2131230801);
    if (button != null) {
      i = 2131230802;
      Button button1 = (Button)꽃.産(view, 2131230802);
      if (button1 != null) {
        i = 2131230803;
        Button button2 = (Button)꽃.産(view, 2131230803);
        if (button2 != null) {
          i = 2131230804;
          Button button3 = (Button)꽃.産(view, 2131230804);
          if (button3 != null) {
            i = 2131230805;
            Button button4 = (Button)꽃.産(view, 2131230805);
            if (button4 != null) {
              i = 2131230806;
              Button button5 = (Button)꽃.産(view, 2131230806);
              if (button5 != null) {
                i = 2131231058;
                Button button6 = (Button)꽃.産(view, 2131231058);
                if (button6 != null) {
                  i = 2131231059;
                  Button button7 = (Button)꽃.産(view, 2131231059);
                  if (button7 != null) {
                    i = 2131231060;
                    Button button8 = (Button)꽃.産(view, 2131231060);
                    if (button8 != null) {
                      i = 2131231061;
                      Button button9 = (Button)꽃.産(view, 2131231061);
                      if (button9 != null) {
                        i = 2131231062;
                        Button button10 = (Button)꽃.産(view, 2131231062);
                        if (button10 != null) {
                          i = 2131231063;
                          Button button11 = (Button)꽃.産(view, 2131231063);
                          if (button11 != null) {
                            i = 2131231077;
                            RelativeLayout relativeLayout1 = (RelativeLayout)꽃.産(view, 2131231077);
                            if (relativeLayout1 != null) {
                              i = 2131231128;
                              View view1 = 꽃.産(view, 2131231128);
                              if (view1 != null) {
                                役 役 = new 役(17, view1);
                                View view2 = 꽃.産(view, 2131231129);
                                if (view2 != null) {
                                  男 男 = new 男(17, view2);
                                  RelativeLayout relativeLayout2 = (RelativeLayout)꽃.産(view, 2131231241);
                                  if (relativeLayout2 != null) {
                                    ImageView imageView = (ImageView)꽃.産(view, 2131231260);
                                    if (imageView != null) {
                                      RelativeLayout relativeLayout3 = (RelativeLayout)view;
                                      View view3 = 꽃.産(view, 2131231376);
                                      if (view3 != null) {
                                        eq0 eq01 = new eq0(relativeLayout3, (View)button, (TextView)button1, button2, button3, button4, button5, button6, button7, button8, (View)button9, button10, button11, (View)relativeLayout1, 役, 男, (View)relativeLayout2, (View)imageView, (View)relativeLayout3, ks.堅(view3), 2);
                                        this.師 = eq01;
                                        switch (2) {
                                          case 2:
                                            relativeLayout = (RelativeLayout)eq01.硬;
                                            setContentView((View)relativeLayout);
                                            return;
                                        } 
                                        relativeLayout = (RelativeLayout)((eq0)relativeLayout).硬;
                                      } else {
                                        i = 2131231376;
                                        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                                      } 
                                    } else {
                                      i = 2131231260;
                                      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                                    } 
                                  } else {
                                    i = 2131231241;
                                    throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                                  } 
                                } else {
                                  i = 2131231129;
                                  throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                                } 
                              } else {
                                throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                              } 
                            } else {
                              throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                            } 
                          } else {
                            throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                          } 
                        } else {
                          throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                        } 
                      } else {
                        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                      } 
                    } else {
                      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                    } 
                  } else {
                    throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                  } 
                } else {
                  throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
                } 
              } else {
                throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
              } 
            } else {
              throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
            } 
          } else {
            throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
          } 
        } else {
          throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
        } 
      } else {
        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
      } 
    } else {
      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
    } 
    setContentView((View)relativeLayout);
  }
  
  public final boolean わ(z0 paramz0) {
    return (paramz0.寒 == null && !paramz0.暑);
  }
  
  public final void 俺() {
    ci0 ci0 = 테();
    遊 遊 = new 遊((a0)토());
    ((i00)ci0.怖).熱((개)遊);
  }
  
  public final void 僕() {
    for (z0 z0 : this.ょ) {
      z0.熱();
      z0.硬().美();
      z0.暑 = false;
    } 
    for (z0 z0 : this.う) {
      z0.硬().美();
      z0.暑 = false;
    } 
  }
  
  public final void 医(MotionEvent paramMotionEvent) {
    if (!若())
      return; 
    if (this.ぼ == null)
      int i = nf.硬; 
  }
  
  public final void 投(z0 paramz0) {
    if (((密)this).크.淋().booleanValue())
      return; 
    if (ik.熱(paramz0, this.ぼ)) {
      int i = nf.硬;
      return;
    } 
    z0 z01 = this.ぼ;
    if (z01 == null) {
      this.ぼ = paramz0;
      int i = nf.硬;
    } else if ((퇴(z01) && !퇴(paramz0)) || (!퇴(z01) && 퇴(paramz0))) {
      z01.寒 = paramz0;
      int i = nf.硬;
    } else {
      int i = nf.硬;
      z01.硬().美();
      z01.熱();
      z01.暑 = false;
      this.ぼ = paramz0;
    } 
    ((a1)(paramz0.硬()).堅).硬();
    if (통())
      크(paramz0, this.ぼ); 
  }
  
  public final void 私() {
    z0 z01 = this.ぼ;
    z01.暑 = false;
    z01.硬().旨();
    z0 z02 = z01.寒;
    z02.暑 = false;
    z02.硬().旨();
    泳().getClass();
    鏡 鏡 = 鏡.硬;
    噛(鏡.터);
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new v(this, z01, z02, null), 2);
  }
  
  public final boolean 若() {
    boolean bool = ((密)this).크.淋().booleanValue();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      boolean bool3;
      z0 z0 = this.ぼ;
      if (z0 != null && !z0.暑) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      bool1 = bool2;
      if (bool3)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final void 触() {
    eq0 eq04 = this.師;
    eq0 eq03 = null;
    eq0 eq02 = eq04;
    if (eq04 == null)
      eq02 = null; 
    Button button = (Button)eq02.暑;
    ArrayList<Button> arrayList = this.퇴;
    arrayList.add(button);
    eq04 = this.師;
    eq0 eq01 = eq04;
    if (eq04 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.美);
    eq04 = this.師;
    eq01 = eq04;
    if (eq04 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.寒);
    eq04 = this.師;
    eq01 = eq04;
    if (eq04 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.熱);
    eq04 = this.師;
    eq01 = eq04;
    if (eq04 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.堅);
    eq01 = this.師;
    if (eq01 == null)
      eq01 = eq03; 
    arrayList.add((Button)eq01.冷);
  }
  
  public final void 赤() {
    男 男 = this.톨;
    if (男.淋().booleanValue())
      return; 
    int i = nf.硬;
    ゃ();
    for (View view : this.투) {
      z0 z0 = new z0();
      this.ょ.add(z0);
      z0.硬 = new 본((Button)view, 타());
      ((Button)(z0.硬()).硬).setVisibility(0);
      あ(z0);
    } 
    i = 탁() + 0;
    腕.硬(i);
    int j = 탁();
    く(this.く, j, i);
    男.怖();
    ((for)(테()).起).寒(Boolean.TRUE);
  }
  
  public final void 크(z0 paramz01, z0 paramz02) {
    z0 z01;
    int i = nf.硬;
    if (퇴(paramz01)) {
      z01 = paramz02;
    } else {
      z01 = paramz01;
      paramz01 = paramz02;
    } 
    wn wn = new wn(태().硬(), Long.valueOf(paramz01.冷), Integer.valueOf(z01.冷));
    ㅌ().悲((각)wn);
  }
  
  public final String 큰() {
    String str = v1.硬;
    return v1.寒;
  }
  
  public final a1 타() {
    int i = 殻.堅((Context)this, 2131034671);
    int j = 殻.堅((Context)this, 2131034676);
    본 본1 = new 본(Integer.valueOf(殻.堅((Context)this, 2131034667)), Integer.valueOf(殻.堅((Context)this, 2131034677)));
    본 본2 = new 본(Integer.valueOf(2131165303), Integer.valueOf(2131165304));
    Integer integer1 = Integer.valueOf(殻.堅((Context)this, 2131034674));
    본 본3 = new 본(integer1, integer1);
    Integer integer2 = Integer.valueOf(2131165302);
    return (a1)new z(i, j, 본1, 본2, 본3, new 본(integer2, integer2));
  }
  
  public final int 탄(int paramInt) {
    paramInt += 0;
    腕.硬(paramInt);
    return paramInt;
  }
  
  public final int 탑() {
    int i = 腕.怖;
    return 0;
  }
  
  public final sd 터() {
    return sd.痛;
  }
  
  public final bb 토() {
    return (bb)this.護.getValue();
  }
  
  public final void 톨() {
    int i = nf.硬;
    List list = ik.택((탕()).堅);
    Iterator<sb> iterator = list.iterator();
    i = 0;
    while (true) {
      辞 辞;
      boolean bool = iterator.hasNext();
      ArrayList arrayList = this.ょ;
      if (bool) {
        sb sb = iterator.next();
        ((z0)arrayList.get(i)).冷 = (int)sb.熱;
        辞 = ((sb)list.get(i)).硬;
        ((TextView)this.투.get(i)).setText(辞.堅());
        i++;
        continue;
      } 
      ArrayList<채> arrayList1 = new ArrayList();
      Iterator<z0> iterator1 = list.iterator();
      while (iterator1.hasNext())
        arrayList1.add(new 채(Integer.valueOf((int)((sb)iterator1.next()).硬.硬().硬().doubleValue()))); 
      Collections.shuffle(arrayList1);
      톤(arrayList1);
      iterator1 = 辞.iterator();
      while (iterator1.hasNext())
        ((z0)iterator1.next()).硬().美(); 
      iterator1 = this.う.iterator();
      while (iterator1.hasNext())
        ((z0)iterator1.next()).硬().美(); 
      탈().setVisibility(0);
      return;
    } 
  }
  
  public final boolean 통() {
    z0 z0 = this.ぼ;
    return (z0 != null && z0.寒 != null);
  }
  
  public final void 투(z0 paramz0, int paramInt1, int paramInt2) {}
  
  public final void 퉁() {
    z0 z01 = this.ぼ;
    z01.暑 = true;
    z01.硬().寒();
    z0 z02 = z01.寒;
    z02.暑 = true;
    z02.硬().寒();
    泳().getClass();
    噛(鏡.태);
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new u(this, z01, z02, null), 2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\MatchGameActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */