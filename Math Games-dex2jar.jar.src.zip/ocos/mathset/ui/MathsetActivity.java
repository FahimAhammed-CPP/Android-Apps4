package ocos.mathset.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import y.ab;
import y.nf;
import y.of;
import y.qs;
import y.t1;
import y.u1;
import y.yo1;
import y.z1;
import y.停;
import y.密;
import y.男;
import y.稲;
import y.銅;
import y.鼠;
import y.꽃;
import y.미;
import y.용;
import y.유;
import y.프;
import y.피;

public final class MathsetActivity extends 停 implements 프, 稲 {
  public yo1 태;
  
  public static final void 触(MathsetActivity paramMathsetActivity, Class paramClass) {
    paramMathsetActivity.getClass();
    Intent intent = new Intent((Context)paramMathsetActivity, paramClass);
    intent.putExtra(ab.看, ((Boolean)((피)(paramMathsetActivity.泳()).冷).恐.get()).booleanValue());
    paramMathsetActivity.startActivity(intent);
  }
  
  public final void onCreate(Bundle paramBundle) {
    RelativeLayout relativeLayout;
    super.onCreate(paramBundle);
    View view = getLayoutInflater().inflate(2131427373, null, false);
    int i = 2131230902;
    Button button = (Button)꽃.産(view, 2131230902);
    if (button != null) {
      i = 2131230903;
      Button button1 = (Button)꽃.産(view, 2131230903);
      if (button1 != null) {
        i = 2131230905;
        Button button2 = (Button)꽃.産(view, 2131230905);
        if (button2 != null) {
          i = 2131230906;
          Button button3 = (Button)꽃.産(view, 2131230906);
          if (button3 != null) {
            i = 2131230907;
            Button button4 = (Button)꽃.産(view, 2131230907);
            if (button4 != null) {
              i = 2131230908;
              Button button5 = (Button)꽃.産(view, 2131230908);
              if (button5 != null) {
                i = 2131230931;
                ImageView imageView = (ImageView)꽃.産(view, 2131230931);
                if (imageView != null) {
                  i = 2131230934;
                  ImageView imageView1 = (ImageView)꽃.産(view, 2131230934);
                  if (imageView1 != null) {
                    i = 2131230937;
                    ImageView imageView2 = (ImageView)꽃.産(view, 2131230937);
                    if (imageView2 != null) {
                      i = 2131231130;
                      LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131231130);
                      if (linearLayout != null) {
                        i = 2131231260;
                        ImageView imageView3 = (ImageView)꽃.産(view, 2131231260);
                        if (imageView3 != null) {
                          i = 2131231376;
                          View view1 = 꽃.産(view, 2131231376);
                          if (view1 != null) {
                            TextView textView;
                            i = 2131230890;
                            ImageView imageView4 = (ImageView)꽃.産(view1, 2131230890);
                            if (imageView4 != null) {
                              ImageView imageView5 = (ImageView)꽃.産(view1, 2131230936);
                              if (imageView5 != null) {
                                if ((TextView)꽃.産(view1, 2131231377) != null) {
                                  ConstraintLayout constraintLayout = (ConstraintLayout)view1;
                                  z1 z1 = new z1(imageView4, imageView5);
                                  i = 2131231394;
                                  TextView textView1 = (TextView)꽃.産(view, 2131231394);
                                  if (textView1 != null) {
                                    i = 2131231395;
                                    textView = (TextView)꽃.産(view, 2131231395);
                                    if (textView != null) {
                                      i = 2131231397;
                                      TextView textView2 = (TextView)꽃.産(view, 2131231397);
                                      if (textView2 != null) {
                                        relativeLayout = (RelativeLayout)view;
                                        this.태 = new yo1(relativeLayout, button, button1, button2, button3, button4, button5, imageView, imageView1, imageView2, linearLayout, imageView3, z1, textView1, textView, textView2);
                                        setContentView((View)relativeLayout);
                                        踊();
                                        寝();
                                        yo1 yo14 = this.태;
                                        yo1 yo12 = yo14;
                                        if (yo14 == null)
                                          yo12 = null; 
                                        Button button6 = (Button)yo12.暑;
                                        u1 u1 = new u1(this, 0);
                                        男 男 = ((密)this).크;
                                        꽃.触((TextView)button6, 男, (용)u1);
                                        yo1 yo13 = this.태;
                                        yo1 yo11 = yo13;
                                        if (yo13 == null)
                                          yo11 = null; 
                                        꽃.触((TextView)yo11.美, 男, (용)new u1(this, 1));
                                        yo13 = this.태;
                                        yo11 = yo13;
                                        if (yo13 == null)
                                          yo11 = null; 
                                        꽃.触((TextView)yo11.寒, 男, (용)new u1(this, 2));
                                        yo13 = this.태;
                                        yo11 = yo13;
                                        if (yo13 == null)
                                          yo11 = null; 
                                        꽃.触((TextView)yo11.熱, 男, (용)new u1(this, 3));
                                        yo13 = this.태;
                                        yo11 = yo13;
                                        if (yo13 == null)
                                          yo11 = null; 
                                        꽃.触((TextView)yo11.堅, 男, (용)new u1(this, 4));
                                        yo13 = this.태;
                                        yo11 = yo13;
                                        if (yo13 == null)
                                          yo11 = null; 
                                        꽃.触((TextView)yo11.冷, 男, (용)new u1(this, 5));
                                        return;
                                      } 
                                    } 
                                  } 
                                } else {
                                  i = 2131231377;
                                  throw new NullPointerException("Missing required view with ID: ".concat(textView.getResources().getResourceName(i)));
                                } 
                              } else {
                                i = 2131230936;
                                throw new NullPointerException("Missing required view with ID: ".concat(textView.getResources().getResourceName(i)));
                              } 
                            } else {
                              throw new NullPointerException("Missing required view with ID: ".concat(textView.getResources().getResourceName(i)));
                            } 
                          } 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout.getResources().getResourceName(i)));
  }
  
  public final void onResume() {
    super.onResume();
    ((密)this).크.起();
    yo1 yo13 = this.태;
    yo1 yo12 = null;
    yo1 yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.暑).setText(返(qs.触, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.美).setText(返(qs.投, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.寒).setText(返(qs.あ, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.熱).setText(返(qs.か, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.堅).setText(返(qs.ゃ, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((Button)yo11.冷).setText(返(qs.ち, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((TextView)yo11.悲).setText(返(qs.産, new Object[0]));
    yo13 = this.태;
    yo11 = yo13;
    if (yo13 == null)
      yo11 = null; 
    ((TextView)yo11.寂).setText(返(qs.興, new Object[0]));
    yo11 = this.태;
    if (yo11 == null)
      yo11 = yo12; 
    ((TextView)yo11.淋).setText(返(qs.起, new Object[0]));
    String str = 返(qs.泳, new Object[0]);
    ((鼠)this).탕.setText(str);
    if ((((Boolean)미.硬.get()).booleanValue() ^ true) != 0)
      미.硬(); 
  }
  
  public final 銅 ぱ() {
    return (銅)this;
  }
  
  public final 유 嬉() {
    return (유)new t1(this);
  }
  
  public final boolean 痛() {
    return false;
  }
  
  public final of 美() {
    return (of)((鼠)this).ㅌ.getValue();
  }
  
  public final void 苦() {
    int i = nf.硬;
  }
  
  public final void 辛() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\MathsetActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */