package ocos.mathset.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.activity.do;
import java.util.List;
import y.a1;
import y.ab;
import y.bb;
import y.ci0;
import y.di2;
import y.h;
import y.hx;
import y.i00;
import y.ik;
import y.il0;
import y.jf;
import y.ks;
import y.kx;
import y.la0;
import y.nf;
import y.oy0;
import y.pw1;
import y.sb;
import y.sd;
import y.v1;
import y.z0;
import y.ア;
import y.エ;
import y.ニ;
import y.ン;
import y.密;
import y.役;
import y.男;
import y.腕;
import y.行;
import y.赤;
import y.足;
import y.遊;
import y.鏡;
import y.頭;
import y.鼠;
import y.개;
import y.꽃;
import y.년;
import y.뚜;
import y.용;
import y.융;
import y.팔;
import y.퍼;

public final class KeypadActivity extends ab {
  public la0 ふ;
  
  public final pw1 師;
  
  public final kx 護;
  
  public KeypadActivity() {
    行 行 = 行.ち;
    this.護 = new kx(jf.硬(bb.class), new ア((do)this, 1), 行, new 足((do)this, 0));
    this.師 = new pw1(10);
  }
  
  public final void う() {
    la0 la01 = this.ふ;
    if (la01 == null) {
      la02 = null;
    } else {
      la02 = la01;
    } 
    this.퉁 = (RelativeLayout)la02.不;
    la0 la02 = la01;
    if (la01 == null)
      la02 = null; 
    la01 = (la0)la02.冷;
    ik.臭((View)la01.堅, (용)new ニ(this, 3));
    ImageButton imageButton = (ImageButton)la01.熱;
    imageButton.setOnClickListener((View.OnClickListener)new hx(1, this));
    imageButton.setOnLongClickListener((View.OnLongClickListener)new エ((密)this, 0));
    ik.臭((View)la01.暑, (용)new ニ(this, 4));
    ik.臭((View)la01.冷, (용)new ニ(this, 5));
    ik.臭((View)la01.寒, (용)new ニ(this, 6));
    ik.臭((View)la01.美, (용)new ニ(this, 7));
    ik.臭((View)la01.旨, (용)new ニ(this, 8));
    ik.臭((View)la01.不, (용)new ニ(this, 9));
    ik.臭((View)la01.辛, (용)new ニ(this, 10));
    ik.臭((View)la01.ぱ, (용)new ニ(this, 0));
    ik.臭((View)la01.苦, (용)new ニ(this, 1));
    ik.臭((View)la01.嬉, (용)new ニ(this, 2));
  }
  
  public final int か() {
    int i = 腕.怖;
    return 0;
  }
  
  public final void ご(il0 paramil0) {
    if (((密)this).크.淋().booleanValue())
      return; 
    pw1 pw11 = this.師;
    pw11.硬(paramil0);
    String str = pw11.暑;
    la0 la02 = this.ふ;
    la0 la01 = la02;
    if (la02 == null)
      la01 = null; 
    ((EditText)la01.寒).setText(str);
  }
  
  public final void し() {
    ぼ();
  }
  
  public final void た() {
    if (!(탱()).冷) {
      톨();
      return;
    } 
    者();
  }
  
  public final int ち() {
    int i = 腕.怖;
    return 0;
  }
  
  public final void ぼ() {
    la0 la03 = this.ふ;
    la0 la02 = null;
    la0 la01 = la03;
    if (la03 == null)
      la01 = null; 
    ((TextView)la01.堅).setBackgroundResource(2131165321);
    la01 = this.ふ;
    if (la01 == null)
      la01 = la02; 
    ((EditText)la01.寒).setText("");
  }
  
  public final void ょ() {
    la0 la01;
    View view = getLayoutInflater().inflate(2131427365, null, false);
    int i = 2131230821;
    TextView textView = (TextView)꽃.産(view, 2131230821);
    if (textView != null) {
      i = 2131230822;
      RelativeLayout relativeLayout = (RelativeLayout)꽃.産(view, 2131230822);
      if (relativeLayout != null) {
        i = 2131231077;
        RelativeLayout relativeLayout1 = (RelativeLayout)꽃.産(view, 2131231077);
        if (relativeLayout1 != null) {
          i = 2131231113;
          View view1 = 꽃.産(view, 2131231113);
          if (view1 != null) {
            la0 la02;
            i = 2131230836;
            ImageButton imageButton = (ImageButton)꽃.産(view1, 2131230836);
            if (imageButton != null) {
              i = 2131230919;
              ImageButton imageButton1 = (ImageButton)꽃.産(view1, 2131230919);
              if (imageButton1 != null) {
                i = 2131230920;
                Button button = (Button)꽃.産(view1, 2131230920);
                if (button != null) {
                  i = 2131230921;
                  Button button1 = (Button)꽃.産(view1, 2131230921);
                  if (button1 != null) {
                    i = 2131230922;
                    Button button2 = (Button)꽃.産(view1, 2131230922);
                    if (button2 != null) {
                      i = 2131230923;
                      Button button3 = (Button)꽃.産(view1, 2131230923);
                      if (button3 != null) {
                        i = 2131230924;
                        Button button4 = (Button)꽃.産(view1, 2131230924);
                        if (button4 != null) {
                          i = 2131230925;
                          Button button5 = (Button)꽃.産(view1, 2131230925);
                          if (button5 != null) {
                            i = 2131230926;
                            Button button6 = (Button)꽃.産(view1, 2131230926);
                            if (button6 != null) {
                              i = 2131230927;
                              Button button7 = (Button)꽃.産(view1, 2131230927);
                              if (button7 != null) {
                                i = 2131230928;
                                Button button8 = (Button)꽃.産(view1, 2131230928);
                                if (button8 != null) {
                                  i = 2131230929;
                                  Button button9 = (Button)꽃.産(view1, 2131230929);
                                  if (button9 != null) {
                                    la02 = new la0((ViewGroup)view1, (View)imageButton, (View)imageButton1, (View)button, button1, (TextView)button2, button3, button4, (View)button5, (View)button6, (View)button7, (View)button8, button9);
                                    EditText editText = (EditText)꽃.産(view, 2131231114);
                                    if (editText != null) {
                                      View view2 = 꽃.産(view, 2131231128);
                                      if (view2 != null) {
                                        役 役 = 役.暑(view2);
                                        View view3 = 꽃.産(view, 2131231129);
                                        if (view3 != null) {
                                          男 男 = 男.暑(view3);
                                          RelativeLayout relativeLayout2 = (RelativeLayout)꽃.産(view, 2131231241);
                                          if (relativeLayout2 != null) {
                                            LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131231243);
                                            if (linearLayout != null) {
                                              ImageView imageView = (ImageView)꽃.産(view, 2131231260);
                                              if (imageView != null) {
                                                RelativeLayout relativeLayout3 = (RelativeLayout)view;
                                                View view4 = 꽃.産(view, 2131231376);
                                                if (view4 != null) {
                                                  la01 = new la0((ViewGroup)relativeLayout3, (View)textView, (View)relativeLayout, (View)relativeLayout1, la02, (TextView)editText, 役, 男, (View)relativeLayout2, (View)linearLayout, (View)imageView, (View)relativeLayout3, ks.堅(view4));
                                                  this.ふ = la01;
                                                  setContentView((View)la01.硬);
                                                  return;
                                                } 
                                                i = 2131231376;
                                              } else {
                                                i = 2131231260;
                                              } 
                                            } else {
                                              i = 2131231243;
                                            } 
                                          } else {
                                            i = 2131231241;
                                          } 
                                        } else {
                                          i = 2131231129;
                                        } 
                                      } else {
                                        i = 2131231128;
                                      } 
                                    } else {
                                      i = 2131231114;
                                    } 
                                  } else {
                                    throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                                  } 
                                } else {
                                  throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                                } 
                              } else {
                                throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                              } 
                            } else {
                              throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                            } 
                          } else {
                            throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                          } 
                        } else {
                          throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                        } 
                      } else {
                        throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                      } 
                    } else {
                      throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                    } 
                  } else {
                    throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                  } 
                } else {
                  throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
                } 
              } else {
                throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
              } 
            } else {
              throw new NullPointerException("Missing required view with ID: ".concat(la02.getResources().getResourceName(i)));
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(la01.getResources().getResourceName(i)));
  }
  
  public final void 俺() {
    ci0 ci0 = 테();
    遊 遊 = new 遊((頭)토());
    ((i00)ci0.怖).熱((개)遊);
  }
  
  public final void 私() {
    la0 la02 = this.ふ;
    la0 la01 = la02;
    if (la02 == null)
      la01 = null; 
    ((TextView)la01.堅).setBackgroundResource(2131165318);
    泳().getClass();
    噛(鏡.택);
  }
  
  public final void 触() {}
  
  public final void 쾌() {}
  
  public final void 크(z0 paramz01, z0 paramz02) {}
  
  public final String 큰() {
    String str = v1.硬;
    return v1.旨;
  }
  
  public final a1 타() {
    throw new di2();
  }
  
  public final int 탑() {
    int i = 腕.怖;
    return 0;
  }
  
  public final sd 터() {
    return sd.臭;
  }
  
  public final bb 토() {
    return (bb)this.護.getValue();
  }
  
  public final void 톨() {
    int i = nf.硬;
    i = (탱()).堅;
    List<sb> list = (탕()).堅;
    int j = 赤.怖;
    sb sb = list.get(Integer.valueOf(i).intValue());
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new ン(this, sb, null), 2);
  }
  
  public final void 퉁() {
    la0 la02 = this.ふ;
    la0 la01 = la02;
    if (la02 == null)
      la01 = null; 
    ((TextView)la01.堅).setBackgroundResource(2131165317);
    泳().getClass();
    噛(鏡.태);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\KeypadActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */