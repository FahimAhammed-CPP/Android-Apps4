package ocos.mathset.ui;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.activity.do;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import y.a1;
import y.ab;
import y.bb;
import y.ci0;
import y.eo;
import y.eq0;
import y.h;
import y.i00;
import y.ik;
import y.jf;
import y.ks;
import y.kx;
import y.l6;
import y.nf;
import y.oy0;
import y.q6;
import y.sb;
import y.sd;
import y.u9;
import y.v1;
import y.z;
import y.z0;
import y.ア;
import y.別;
import y.役;
import y.殻;
import y.男;
import y.腕;
import y.行;
import y.赤;
import y.足;
import y.遊;
import y.鏡;
import y.鼠;
import y.각;
import y.개;
import y.꽃;
import y.년;
import y.뚜;
import y.융;
import y.팔;
import y.퍼;

public final class NumberPuzzleActivity extends ab {
  public eq0 師;
  
  public final kx 護;
  
  public NumberPuzzleActivity() {
    行 行 = 行.わ;
    this.護 = new kx(jf.硬(bb.class), new ア((do)this, 7), 行, new 足((do)this, 3));
  }
  
  public final void う() {
    eq0 eq02 = this.師;
    eq0 eq04 = null;
    if (eq02 == null) {
      eq03 = null;
    } else {
      eq03 = eq02;
    } 
    this.퉁 = (RelativeLayout)eq03.寂;
    eq0 eq03 = eq02;
    if (eq02 == null)
      eq03 = null; 
    Button button = (Button)eq03.辛;
    ArrayList<Button> arrayList = this.투;
    arrayList.add(button);
    eq03 = this.師;
    eq0 eq01 = eq03;
    if (eq03 == null)
      eq01 = null; 
    arrayList.add((Button)eq01.悲);
    eq01 = this.師;
    if (eq01 == null)
      eq01 = eq04; 
    arrayList.add((Button)eq01.痛);
  }
  
  public final void し() {
    int i = nf.硬;
    ぼ();
  }
  
  public final void ぼ() {
    eq0 eq02 = this.師;
    eq0 eq01 = eq02;
    if (eq02 == null)
      eq01 = null; 
    ((TextView)eq01.熱).setBackgroundResource(2131165321);
    僕();
  }
  
  public final void ょ() {
    RelativeLayout relativeLayout1;
    View view = getLayoutInflater().inflate(2131427379, null, false);
    int i = 2131230822;
    RelativeLayout relativeLayout2 = (RelativeLayout)꽃.産(view, 2131230822);
    if (relativeLayout2 != null) {
      i = 2131230823;
      TextView textView = (TextView)꽃.産(view, 2131230823);
      if (textView != null) {
        i = 2131230898;
        Button button = (Button)꽃.産(view, 2131230898);
        if (button != null) {
          i = 2131230899;
          Button button1 = (Button)꽃.産(view, 2131230899);
          if (button1 != null) {
            i = 2131230932;
            Button button2 = (Button)꽃.産(view, 2131230932);
            if (button2 != null) {
              i = 2131230939;
              Button button3 = (Button)꽃.産(view, 2131230939);
              if (button3 != null) {
                i = 2131230943;
                Button button4 = (Button)꽃.産(view, 2131230943);
                if (button4 != null) {
                  i = 2131230946;
                  Button button5 = (Button)꽃.産(view, 2131230946);
                  if (button5 != null) {
                    i = 2131231057;
                    Button button6 = (Button)꽃.産(view, 2131231057);
                    if (button6 != null) {
                      i = 2131231077;
                      RelativeLayout relativeLayout = (RelativeLayout)꽃.産(view, 2131231077);
                      if (relativeLayout != null) {
                        i = 2131231128;
                        View view1 = 꽃.産(view, 2131231128);
                        if (view1 != null) {
                          役 役 = new 役(17, view1);
                          View view2 = 꽃.産(view, 2131231129);
                          if (view2 != null) {
                            男 男 = new 男(17, view2);
                            Button button7 = (Button)꽃.産(view, 2131231216);
                            if (button7 != null) {
                              RelativeLayout relativeLayout3 = (RelativeLayout)꽃.産(view, 2131231241);
                              if (relativeLayout3 != null) {
                                RelativeLayout relativeLayout4 = (RelativeLayout)꽃.産(view, 2131231243);
                                if (relativeLayout4 != null) {
                                  ImageView imageView = (ImageView)꽃.産(view, 2131231260);
                                  if (imageView != null) {
                                    RelativeLayout relativeLayout5 = (RelativeLayout)view;
                                    Button button8 = (Button)꽃.産(view, 2131231286);
                                    if (button8 != null) {
                                      View view3 = 꽃.産(view, 2131231376);
                                      if (view3 != null) {
                                        eq0 eq01 = new eq0(relativeLayout5, (View)relativeLayout2, textView, button, button1, button2, button3, button4, button5, button6, (View)relativeLayout, 役, 男, (View)button7, relativeLayout3, relativeLayout4, (View)imageView, (View)relativeLayout5, (View)button8, ks.堅(view3), 3);
                                        this.師 = eq01;
                                        switch (3) {
                                          case 2:
                                            relativeLayout1 = (RelativeLayout)eq01.硬;
                                            setContentView((View)relativeLayout1);
                                            return;
                                        } 
                                        relativeLayout1 = (RelativeLayout)((eq0)relativeLayout1).硬;
                                      } else {
                                        i = 2131231376;
                                        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                                      } 
                                    } else {
                                      i = 2131231286;
                                      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                                    } 
                                  } else {
                                    i = 2131231260;
                                    throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                                  } 
                                } else {
                                  i = 2131231243;
                                  throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                                } 
                              } else {
                                i = 2131231241;
                                throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                              } 
                            } else {
                              i = 2131231216;
                              throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                            } 
                          } else {
                            i = 2131231129;
                            throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                          } 
                        } else {
                          throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                        } 
                      } else {
                        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                      } 
                    } else {
                      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                    } 
                  } else {
                    throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                  } 
                } else {
                  throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
                } 
              } else {
                throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
              } 
            } else {
              throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
            } 
          } else {
            throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
          } 
        } else {
          throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
        } 
      } else {
        throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
      } 
    } else {
      throw new NullPointerException("Missing required view with ID: ".concat(relativeLayout1.getResources().getResourceName(i)));
    } 
    setContentView((View)relativeLayout1);
  }
  
  public final void 俺() {
    ci0 ci0 = 테();
    遊 遊 = new 遊((q6)토());
    ((i00)ci0.怖).熱((개)遊);
  }
  
  public final void 私() {
    eq0 eq02 = this.師;
    eq0 eq01 = eq02;
    if (eq02 == null)
      eq01 = null; 
    ((TextView)eq01.熱).setBackgroundResource(2131165323);
    泳().getClass();
    噛(鏡.택);
  }
  
  public final void 코(z0 paramz0) {
    int i = nf.硬;
    paramz0 = paramz0.寒;
    if (paramz0 != null) {
      paramz0.熱();
      Button button = (Button)(paramz0.硬()).硬;
      u9 u9 = paramz0.熱;
      ik.코((View)button, u9.硬, u9.堅);
      paramz0.硬().美();
    } 
  }
  
  public final void 크(z0 paramz01, z0 paramz02) {
    this.僕 = paramz02;
    int i = nf.硬;
    String str = 태().硬();
    i = (탱()).堅;
    ArrayList arrayList = this.ょ;
    int j = ((z0)別.家(arrayList)).寒.冷;
    if (!arrayList.isEmpty()) {
      eo eo = new eo(Integer.valueOf(j), Integer.valueOf(((z0)arrayList.get(arrayList.size() - 1)).寒.冷), str, new 赤(i));
      ㅌ().悲((각)eo);
      return;
    } 
    throw new NoSuchElementException("List is empty.");
  }
  
  public final String 큰() {
    String str = v1.硬;
    return v1.暑;
  }
  
  public final a1 타() {
    return (a1)new z(殻.堅((Context)this, 2131034876), 殻.堅((Context)this, 2131034872));
  }
  
  public final int 탑() {
    eq0 eq02 = this.師;
    eq0 eq01 = eq02;
    if (eq02 == null)
      eq01 = null; 
    int i = ((RelativeLayout)eq01.淋).getBottom();
    腕.硬(i);
    return i;
  }
  
  public final sd 터() {
    return sd.怖;
  }
  
  public final bb 토() {
    return (bb)this.護.getValue();
  }
  
  public final void 톨() {
    int i = nf.硬;
    i = (탱()).堅;
    List<sb> list = (탕()).堅;
    int j = 赤.怖;
    sb sb = list.get(Integer.valueOf(i).intValue());
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new l6(this, sb, null), 2);
  }
  
  public final void 퉁() {
    eq0 eq02 = this.師;
    eq0 eq01 = eq02;
    if (eq02 == null)
      eq01 = null; 
    ((TextView)eq01.熱).setBackgroundResource(2131165322);
    泳().getClass();
    噛(鏡.태);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\NumberPuzzleActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */