package ocos.mathset.ui;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import java.util.ArrayList;
import java.util.Iterator;
import y.a1;
import y.ab;
import y.ax;
import y.bb;
import y.di2;
import y.h;
import y.j6;
import y.k6;
import y.ks;
import y.n5;
import y.nf;
import y.oy0;
import y.qs;
import y.sd;
import y.v1;
import y.wd;
import y.z0;
import y.唇;
import y.師;
import y.役;
import y.殻;
import y.熊;
import y.男;
import y.腕;
import y.鏡;
import y.鼠;
import y.꽃;
import y.년;
import y.뚜;
import y.본;
import y.융;
import y.팔;
import y.퍼;

public final class NumberGameActivity extends ab {
  public 熊 ふ;
  
  public 師 師;
  
  public final ArrayList 護 = new ArrayList();
  
  public final void う() {
    熊 熊2 = this.ふ;
    熊 熊1 = 熊2;
    if (熊2 == null)
      熊1 = null; 
    this.퉁 = 熊1.硬;
    寝();
    qs qs = qs.寝;
    int i = 0;
    String str = 返(qs, new Object[0]);
    ((鼠)this).탕.setText(str);
    ax<Button> ax = new ax(0, 탈());
    while (ax.hasNext()) {
      Button button = ax.next();
      z0 z0 = new z0();
      z0.硬 = new 본(button, 타());
      this.護.add(z0);
      button.setOnClickListener((View.OnClickListener)new j6(this, z0));
    } 
    탈().setVisibility(0);
    ax = new ax(0, 탈());
    while (ax.hasNext()) {
      ax.next();
      if (++i >= 0)
        continue; 
      throw new ArithmeticException("Count overflow has happened.");
    } 
    this.師 = new 師((wd)((鼠)this).키.getValue(), i);
    ご();
    this.톨.怖();
  }
  
  public final void ご() {
    int m;
    int n;
    師 師3 = this.師;
    n5 n52 = null;
    師 師1 = 師3;
    if (師3 == null)
      師1 = null; 
    wd wd = (wd)師1.恐;
    int i = 師1.淋;
    唇 唇 = (唇)wd;
    int j = 0;
    師1.怖 = 唇.硬(0, i);
    i = 0;
    while (true) {
      m = ((唇)師1.恐).硬(0, 9);
      n = ((唇)師1.恐).硬(0, 9);
      if (n == m) {
        int i1 = i + 1;
        i = i1;
        if (i1 >= 20)
          break; 
        continue;
      } 
      break;
    } 
    i = nf.硬;
    師1.痛 = new n5(m, n, 6);
    師1 = this.師;
    if (師1 == null) {
      唇 = null;
    } else {
      師2 = 師1;
    } 
    int k = 師2.怖;
    師 師2 = 師1;
    if (師1 == null)
      師2 = null; 
    n5 n51 = (n5)師2.痛;
    if (n51 == null)
      n51 = n52; 
    Iterator<z0> iterator = this.護.iterator();
    for (i = j; iterator.hasNext(); i++) {
      z0 z0 = iterator.next();
      if (i == k) {
        j = n51.淋;
      } else {
        j = n51.怖;
      } 
      ((Button)(z0.硬()).硬).setText(String.valueOf(j));
      z0.冷 = i;
    } 
  }
  
  public final void し() {}
  
  public final void ね() {}
  
  public final void ぼ() {}
  
  public final void ょ() {
    View view = getLayoutInflater().inflate(2131427377, null, false);
    int i = 2131230837;
    if ((Button)꽃.産(view, 2131230837) != null) {
      i = 2131230838;
      if ((Button)꽃.産(view, 2131230838) != null) {
        i = 2131230839;
        if ((Button)꽃.産(view, 2131230839) != null) {
          i = 2131230840;
          if ((Button)꽃.産(view, 2131230840) != null) {
            i = 2131230841;
            if ((Button)꽃.産(view, 2131230841) != null) {
              i = 2131230842;
              if ((Button)꽃.産(view, 2131230842) != null) {
                i = 2131230843;
                if ((Button)꽃.産(view, 2131230843) != null) {
                  i = 2131230844;
                  if ((Button)꽃.産(view, 2131230844) != null) {
                    i = 2131230845;
                    if ((Button)꽃.産(view, 2131230845) != null) {
                      i = 2131230846;
                      if ((Button)꽃.産(view, 2131230846) != null) {
                        i = 2131230847;
                        if ((Button)꽃.産(view, 2131230847) != null) {
                          i = 2131230848;
                          if ((Button)꽃.産(view, 2131230848) != null) {
                            i = 2131230849;
                            if ((Button)꽃.産(view, 2131230849) != null) {
                              i = 2131230850;
                              if ((Button)꽃.産(view, 2131230850) != null) {
                                i = 2131230851;
                                if ((Button)꽃.産(view, 2131230851) != null) {
                                  i = 2131230852;
                                  if ((Button)꽃.産(view, 2131230852) != null) {
                                    i = 2131230853;
                                    if ((Button)꽃.産(view, 2131230853) != null) {
                                      i = 2131230854;
                                      if ((Button)꽃.産(view, 2131230854) != null) {
                                        i = 2131230855;
                                        if ((Button)꽃.産(view, 2131230855) != null) {
                                          i = 2131230856;
                                          if ((Button)꽃.産(view, 2131230856) != null) {
                                            i = 2131230857;
                                            if ((Button)꽃.産(view, 2131230857) != null) {
                                              i = 2131230858;
                                              if ((Button)꽃.産(view, 2131230858) != null) {
                                                i = 2131230859;
                                                if ((Button)꽃.産(view, 2131230859) != null) {
                                                  i = 2131230860;
                                                  if ((Button)꽃.産(view, 2131230860) != null) {
                                                    i = 2131230861;
                                                    if ((Button)꽃.産(view, 2131230861) != null) {
                                                      i = 2131230862;
                                                      if ((Button)꽃.産(view, 2131230862) != null) {
                                                        i = 2131230863;
                                                        if ((Button)꽃.産(view, 2131230863) != null) {
                                                          i = 2131230864;
                                                          if ((Button)꽃.産(view, 2131230864) != null) {
                                                            i = 2131230865;
                                                            if ((Button)꽃.産(view, 2131230865) != null) {
                                                              i = 2131230866;
                                                              if ((Button)꽃.産(view, 2131230866) != null) {
                                                                i = 2131230867;
                                                                if ((Button)꽃.産(view, 2131230867) != null) {
                                                                  i = 2131230868;
                                                                  if ((Button)꽃.産(view, 2131230868) != null) {
                                                                    i = 2131230869;
                                                                    if ((Button)꽃.産(view, 2131230869) != null) {
                                                                      i = 2131230870;
                                                                      if ((Button)꽃.産(view, 2131230870) != null) {
                                                                        i = 2131230871;
                                                                        if ((Button)꽃.産(view, 2131230871) != null) {
                                                                          i = 2131230872;
                                                                          if ((Button)꽃.産(view, 2131230872) != null) {
                                                                            i = 2131230873;
                                                                            if ((Button)꽃.産(view, 2131230873) != null) {
                                                                              i = 2131230874;
                                                                              if ((Button)꽃.産(view, 2131230874) != null) {
                                                                                i = 2131230875;
                                                                                if ((Button)꽃.産(view, 2131230875) != null) {
                                                                                  i = 2131230876;
                                                                                  if ((Button)꽃.産(view, 2131230876) != null) {
                                                                                    i = 2131230877;
                                                                                    if ((Button)꽃.産(view, 2131230877) != null) {
                                                                                      i = 2131230878;
                                                                                      if ((Button)꽃.産(view, 2131230878) != null) {
                                                                                        i = 2131230879;
                                                                                        if ((Button)꽃.産(view, 2131230879) != null) {
                                                                                          i = 2131230880;
                                                                                          if ((Button)꽃.産(view, 2131230880) != null) {
                                                                                            i = 2131230881;
                                                                                            if ((Button)꽃.産(view, 2131230881) != null) {
                                                                                              i = 2131230882;
                                                                                              if ((Button)꽃.産(view, 2131230882) != null) {
                                                                                                i = 2131230883;
                                                                                                if ((Button)꽃.産(view, 2131230883) != null) {
                                                                                                  i = 2131230884;
                                                                                                  if ((Button)꽃.産(view, 2131230884) != null) {
                                                                                                    i = 2131230885;
                                                                                                    if ((Button)꽃.産(view, 2131230885) != null) {
                                                                                                      i = 2131231077;
                                                                                                      if ((RelativeLayout)꽃.産(view, 2131231077) != null) {
                                                                                                        i = 2131231128;
                                                                                                        View view1 = 꽃.産(view, 2131231128);
                                                                                                        if (view1 != null) {
                                                                                                          役.暑(view1);
                                                                                                          i = 2131231129;
                                                                                                          view1 = 꽃.産(view, 2131231129);
                                                                                                          if (view1 != null) {
                                                                                                            男.暑(view1);
                                                                                                            i = 2131231241;
                                                                                                            RelativeLayout relativeLayout = (RelativeLayout)꽃.産(view, 2131231241);
                                                                                                            if (relativeLayout != null) {
                                                                                                              i = 2131231260;
                                                                                                              if ((ImageView)꽃.産(view, 2131231260) != null) {
                                                                                                                RelativeLayout relativeLayout1 = (RelativeLayout)view;
                                                                                                                View view2 = 꽃.産(view, 2131231376);
                                                                                                                if (view2 != null) {
                                                                                                                  ks.堅(view2);
                                                                                                                  this.ふ = new 熊(relativeLayout1, relativeLayout);
                                                                                                                  setContentView((View)relativeLayout1);
                                                                                                                  return;
                                                                                                                } 
                                                                                                                i = 2131231376;
                                                                                                              } 
                                                                                                            } 
                                                                                                          } 
                                                                                                        } 
                                                                                                      } 
                                                                                                    } 
                                                                                                  } 
                                                                                                } 
                                                                                              } 
                                                                                            } 
                                                                                          } 
                                                                                        } 
                                                                                      } 
                                                                                    } 
                                                                                  } 
                                                                                } 
                                                                              } 
                                                                            } 
                                                                          } 
                                                                        } 
                                                                      } 
                                                                    } 
                                                                  } 
                                                                } 
                                                              } 
                                                            } 
                                                          } 
                                                        } 
                                                      } 
                                                    } 
                                                  } 
                                                } 
                                              } 
                                            } 
                                          } 
                                        } 
                                      } 
                                    } 
                                  } 
                                } 
                              } 
                            } 
                          } 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
  }
  
  public final void れ() {}
  
  public final void 俺() {}
  
  public final void 少() {}
  
  public final void 投(z0 paramz0) {
    boolean bool;
    int i = nf.硬;
    if (this.ぼ != null)
      return; 
    this.ぼ = paramz0;
    i = paramz0.冷;
    師 師2 = this.師;
    師 師1 = 師2;
    if (師2 == null)
      師1 = null; 
    if (i == 師1.怖) {
      bool = true;
    } else {
      bool = false;
    } 
    臭(bool);
  }
  
  public final void 私() {
    this.ぼ.硬().旨();
    泳().getClass();
    噛(鏡.택);
  }
  
  public final void 臭(boolean paramBoolean) {
    if (paramBoolean) {
      퉁();
    } else {
      私();
    } 
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new k6(this, paramBoolean, null), 2);
  }
  
  public final void 触() {}
  
  public final void 赤() {}
  
  public final void 크(z0 paramz01, z0 paramz02) {}
  
  public final String 큰() {
    String str = v1.硬;
    return v1.美;
  }
  
  public final a1 타() {
    return new a1(new 본(Integer.valueOf(殻.堅((Context)this, 2131034867)), Integer.valueOf(殻.堅((Context)this, 2131034870))), new 본(Integer.valueOf(2131165315), Integer.valueOf(2131165316)), new 본(Integer.valueOf(殻.堅((Context)this, 2131034865)), Integer.valueOf(殻.堅((Context)this, 2131034865))), new 본(Integer.valueOf(2131034864), Integer.valueOf(2131034864)));
  }
  
  public final int 탑() {
    int i = 腕.怖;
    return 0;
  }
  
  public final sd 터() {
    return sd.痒;
  }
  
  public final bb 토() {
    throw new di2("An operation is not implemented: not implemented");
  }
  
  public final void 톨() {}
  
  public final void 퉁() {
    this.ぼ.硬().寒();
    泳().getClass();
    噛(鏡.태);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\NumberGameActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */