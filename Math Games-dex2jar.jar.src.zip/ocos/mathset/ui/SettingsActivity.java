package ocos.mathset.ui;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import ocos.app.MyApplication;
import y.hp;
import y.ik;
import y.j7;
import y.ks;
import y.nf;
import y.of;
import y.qs;
import y.s4;
import y.sk;
import y.tc;
import y.tk;
import y.yi;
import y.停;
import y.目;
import y.銅;
import y.鏡;
import y.鼠;
import y.꽃;
import y.본;
import y.용;
import y.유;
import y.프;
import y.피;

public final class SettingsActivity extends 停 implements j7, 프 {
  public s4 태;
  
  public final hp 택 = new hp((용)new tk(this, 1));
  
  public final hp 탱 = new hp((용)new tk(this, 0));
  
  public final void onCreate(Bundle paramBundle) {
    s4 s41;
    super.onCreate(paramBundle);
    View view = getLayoutInflater().inflate(2131427375, null, false);
    int i = 2131230894;
    ImageView imageView = (ImageView)꽃.産(view, 2131230894);
    if (imageView != null) {
      i = 2131230895;
      TextView textView = (TextView)꽃.産(view, 2131230895);
      if (textView != null) {
        i = 2131230896;
        ImageView imageView1 = (ImageView)꽃.産(view, 2131230896);
        if (imageView1 != null) {
          i = 2131230897;
          TextView textView1 = (TextView)꽃.産(view, 2131230897);
          if (textView1 != null) {
            i = 2131230900;
            ImageView imageView2 = (ImageView)꽃.産(view, 2131230900);
            if (imageView2 != null) {
              i = 2131230901;
              TextView textView2 = (TextView)꽃.産(view, 2131230901);
              if (textView2 != null) {
                i = 2131230969;
                LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131230969);
                if (linearLayout != null) {
                  i = 2131231260;
                  ImageView imageView3 = (ImageView)꽃.産(view, 2131231260);
                  if (imageView3 != null) {
                    RelativeLayout relativeLayout = (RelativeLayout)view;
                    i = 2131231376;
                    View view1 = 꽃.産(view, 2131231376);
                    if (view1 != null) {
                      s41 = new s4((ViewGroup)relativeLayout, (View)imageView, textView, imageView1, (View)textView1, imageView2, (View)textView2, (View)linearLayout, (View)imageView3, (ViewGroup)relativeLayout, ks.堅(view1), 7);
                      this.태 = s41;
                      setContentView((View)s41.硬);
                      ((피)this.탱.getValue()).旨(this);
                      触();
                      return;
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(s41.getResources().getResourceName(i)));
  }
  
  public final void onDestroy() {
    ((피)this.탱.getValue()).暑();
    super.onDestroy();
  }
  
  public final 銅 ぱ() {
    return (銅)this;
  }
  
  public final void 堅(目 param目) {
    int i = nf.硬;
    (泳()).熱.堅(param目);
    触();
  }
  
  public final 유 嬉() {
    return (유)yi.起;
  }
  
  public final boolean 痛() {
    return false;
  }
  
  public final of 美() {
    return (of)((MyApplication)this.택.getValue()).硬().硬();
  }
  
  public final void 苦() {
    int i = nf.硬;
    s4 s44 = this.태;
    s4 s43 = null;
    s4 s42 = null;
    s4 s41 = s44;
    if (s44 == null)
      s41 = null; 
    ((TextView)s41.美).setText(返(Integer.valueOf(2131689708), new Object[0]));
    if (((피)this.탱.getValue()).冷()) {
      s43 = this.태;
      s41 = s43;
      if (s43 == null)
        s41 = null; 
      ((TextView)s41.美).setVisibility(0);
      s43 = this.태;
      s41 = s43;
      if (s43 == null)
        s41 = null; 
      ((ImageView)s41.寒).setVisibility(0);
      s41 = this.태;
      if (s41 == null)
        s41 = s42; 
      ((ImageView)s41.寒).setOnClickListener((View.OnClickListener)new sk(this, 0));
      return;
    } 
    s42 = this.태;
    s41 = s42;
    if (s42 == null)
      s41 = null; 
    ((TextView)s41.美).setVisibility(4);
    s41 = this.태;
    if (s41 == null)
      s41 = s43; 
    ((ImageView)s41.寒).setVisibility(4);
  }
  
  public final void 触() {
    boolean bool;
    踊();
    泳().getClass();
    if (鏡.테.size() > 1) {
      bool = true;
    } else {
      bool = false;
    } 
    s4 s42 = null;
    if (bool) {
      s4 s46 = this.태;
      s4 s45 = s46;
      if (s46 == null)
        s45 = null; 
      TextView textView = (TextView)s45.熱;
      textView.setVisibility(0);
      textView.setText(返(Integer.valueOf(2131689570), new Object[0]));
      s46 = this.태;
      s4 s44 = s46;
      if (s46 == null)
        s44 = null; 
      ImageView imageView = (ImageView)s44.堅;
      imageView.setVisibility(0);
      imageView.setOnClickListener((View.OnClickListener)new sk(this, 1));
    } else {
      s4 s45 = this.태;
      s4 s44 = s45;
      if (s45 == null)
        s44 = null; 
      ik.泳((View)s44.旨);
    } 
    s4 s43 = this.태;
    s4 s41 = s43;
    if (s43 == null)
      s41 = null; 
    ((TextView)s41.冷).setText(返(Integer.valueOf(2131689693), new Object[0]));
    본 본1 = 鏡.も;
    본 본2 = new 본(帰(), 鏡.ち);
    s43 = this.태;
    s41 = s43;
    if (s43 == null)
      s41 = null; 
    new tc(본1, 본2, (ImageView)s41.暑, new 본(Integer.valueOf(2131165426), Integer.valueOf(2131165425)));
    s41 = this.태;
    if (s41 == null)
      s41 = s42; 
    ((TextView)s41.美).setText(返(Integer.valueOf(2131689708), new Object[0]));
    寝();
    String str = 返(qs.怖, new Object[0]);
    ((鼠)this).탕.setText(str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\SettingsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */