package ocos.mathset.ui;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.activity.do;
import androidx.lifecycle.for;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import y.a1;
import y.ab;
import y.ao;
import y.bb;
import y.c1;
import y.ci0;
import y.gc;
import y.h;
import y.h1;
import y.i00;
import y.ik;
import y.jf;
import y.ks;
import y.kx;
import y.nf;
import y.oy0;
import y.sb;
import y.sd;
import y.v1;
import y.z0;
import y.ア;
import y.密;
import y.役;
import y.殻;
import y.男;
import y.腕;
import y.蛇;
import y.行;
import y.足;
import y.辞;
import y.遊;
import y.鏡;
import y.鼠;
import y.각;
import y.개;
import y.꽃;
import y.년;
import y.뚜;
import y.복;
import y.본;
import y.융;
import y.팔;
import y.퍼;

public final class MathPuzzleActivity extends ab {
  public 蛇 師;
  
  public final kx 護;
  
  public MathPuzzleActivity() {
    行 行 = 行.赤;
    this.護 = new kx(jf.硬(bb.class), new ア((do)this, 5), 行, new 足((do)this, 2));
  }
  
  public static void ご(辞 param辞, Button paramButton1, Button paramButton2, Button paramButton3) {
    복 복 = ab.年(param辞);
    paramButton1.setText(복.硬);
    paramButton2.setText(복.堅);
    paramButton3.setText(복.熱);
  }
  
  public final void う() {
    蛇 蛇2 = this.師;
    蛇 蛇4 = null;
    if (蛇2 == null) {
      蛇3 = null;
    } else {
      蛇3 = 蛇2;
    } 
    this.퉁 = 蛇3.嬉;
    蛇 蛇3 = 蛇2;
    if (蛇2 == null)
      蛇3 = null; 
    Button button = 蛇3.堅;
    ArrayList<Button> arrayList = this.투;
    arrayList.add(button);
    蛇3 = this.師;
    蛇 蛇1 = 蛇3;
    if (蛇3 == null)
      蛇1 = null; 
    arrayList.add(蛇1.暑);
    蛇3 = this.師;
    蛇1 = 蛇3;
    if (蛇3 == null)
      蛇1 = null; 
    arrayList.add(蛇1.熱);
    蛇1 = this.師;
    if (蛇1 == null)
      蛇1 = 蛇4; 
    arrayList.add(蛇1.硬);
  }
  
  public final void し() {
    int i = nf.硬;
    僕();
  }
  
  public final void た() {
    ArrayList arrayList2 = this.ょ;
    ArrayList arrayList1 = new ArrayList();
    Iterator<Object> iterator = arrayList2.iterator();
    while (true) {
      boolean bool1 = iterator.hasNext();
      boolean bool = true;
      if (bool1) {
        Object object = iterator.next();
        if ((true ^ ((z0)object).暑) != 0)
          arrayList1.add(object); 
        continue;
      } 
      int i = arrayList1.size();
      int j = nf.硬;
      if (i != 0)
        bool = false; 
      if (bool)
        者(); 
      return;
    } 
  }
  
  public final void ぼ() {}
  
  public final boolean も() {
    return false;
  }
  
  public final int ゃ() {
    int i = Integer.valueOf(탐()).intValue();
    return Integer.valueOf(탐()).intValue() * i * -1;
  }
  
  public final void ょ() {
    View view = getLayoutInflater().inflate(2131427371, null, false);
    int i = 2131230802;
    Button button = (Button)꽃.産(view, 2131230802);
    if (button != null) {
      i = 2131230803;
      Button button1 = (Button)꽃.産(view, 2131230803);
      if (button1 != null) {
        i = 2131230805;
        Button button2 = (Button)꽃.産(view, 2131230805);
        if (button2 != null) {
          i = 2131230806;
          Button button3 = (Button)꽃.産(view, 2131230806);
          if (button3 != null) {
            i = 2131230898;
            if ((Button)꽃.産(view, 2131230898) != null) {
              i = 2131230899;
              if ((Button)꽃.産(view, 2131230899) != null) {
                i = 2131230932;
                if ((Button)꽃.産(view, 2131230932) != null) {
                  i = 2131230939;
                  if ((Button)꽃.産(view, 2131230939) != null) {
                    i = 2131230943;
                    if ((Button)꽃.産(view, 2131230943) != null) {
                      i = 2131230946;
                      if ((Button)꽃.産(view, 2131230946) != null) {
                        i = 2131231044;
                        if ((Button)꽃.産(view, 2131231044) != null) {
                          i = 2131231045;
                          if ((Button)꽃.産(view, 2131231045) != null) {
                            i = 2131231046;
                            if ((Button)꽃.産(view, 2131231046) != null) {
                              i = 2131231047;
                              if ((Button)꽃.産(view, 2131231047) != null) {
                                i = 2131231059;
                                Button button4 = (Button)꽃.産(view, 2131231059);
                                if (button4 != null) {
                                  i = 2131231060;
                                  Button button5 = (Button)꽃.産(view, 2131231060);
                                  if (button5 != null) {
                                    i = 2131231062;
                                    Button button6 = (Button)꽃.産(view, 2131231062);
                                    if (button6 != null) {
                                      i = 2131231063;
                                      Button button7 = (Button)꽃.産(view, 2131231063);
                                      if (button7 != null) {
                                        i = 2131231077;
                                        if ((RelativeLayout)꽃.産(view, 2131231077) != null) {
                                          i = 2131231128;
                                          View view1 = 꽃.産(view, 2131231128);
                                          if (view1 != null) {
                                            役.暑(view1);
                                            i = 2131231129;
                                            view1 = 꽃.産(view, 2131231129);
                                            if (view1 != null) {
                                              男.暑(view1);
                                              i = 2131231212;
                                              Button button8 = (Button)꽃.産(view, 2131231212);
                                              if (button8 != null) {
                                                i = 2131231213;
                                                Button button9 = (Button)꽃.産(view, 2131231213);
                                                if (button9 != null) {
                                                  i = 2131231214;
                                                  Button button10 = (Button)꽃.産(view, 2131231214);
                                                  if (button10 != null) {
                                                    i = 2131231215;
                                                    Button button11 = (Button)꽃.産(view, 2131231215);
                                                    if (button11 != null) {
                                                      i = 2131231241;
                                                      RelativeLayout relativeLayout = (RelativeLayout)꽃.産(view, 2131231241);
                                                      if (relativeLayout != null) {
                                                        i = 2131231243;
                                                        RelativeLayout relativeLayout1 = (RelativeLayout)꽃.産(view, 2131231243);
                                                        if (relativeLayout1 != null) {
                                                          i = 2131231260;
                                                          if ((ImageView)꽃.産(view, 2131231260) != null) {
                                                            RelativeLayout relativeLayout2 = (RelativeLayout)view;
                                                            Button button12 = (Button)꽃.産(view, 2131231287);
                                                            if (button12 != null) {
                                                              Button button13 = (Button)꽃.産(view, 2131231288);
                                                              if (button13 != null) {
                                                                Button button14 = (Button)꽃.産(view, 2131231289);
                                                                if (button14 != null) {
                                                                  Button button15 = (Button)꽃.産(view, 2131231290);
                                                                  if (button15 != null) {
                                                                    View view2 = 꽃.産(view, 2131231376);
                                                                    if (view2 != null) {
                                                                      ks.堅(view2);
                                                                      this.師 = new 蛇(relativeLayout2, button, button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, relativeLayout, relativeLayout1, button12, button13, button14, button15, 0);
                                                                      setContentView((View)relativeLayout2);
                                                                      return;
                                                                    } 
                                                                    i = 2131231376;
                                                                  } else {
                                                                    i = 2131231290;
                                                                  } 
                                                                } else {
                                                                  i = 2131231289;
                                                                } 
                                                              } else {
                                                                i = 2131231288;
                                                              } 
                                                            } else {
                                                              i = 2131231287;
                                                            } 
                                                          } 
                                                        } 
                                                      } 
                                                    } 
                                                  } 
                                                } 
                                              } 
                                            } 
                                          } 
                                        } 
                                      } 
                                    } 
                                  } 
                                } 
                              } 
                            } 
                          } 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
  }
  
  public final boolean わ(z0 paramz0) {
    return (paramz0.寒 == null && !paramz0.暑);
  }
  
  public final void 俺() {
    ci0 ci0 = 테();
    遊 遊 = new 遊((h1)토());
    ((i00)ci0.怖).熱((개)遊);
  }
  
  public final void 私() {
    z0 z0 = this.僕;
    z0.硬().旨();
    泳().getClass();
    噛(鏡.택);
    퍼 퍼 = ((鼠)this).탐;
    년 년 = 뚜.硬;
    oy0.ち(퍼, (팔)h.硬, (융)new c1(this, z0, null), 2);
  }
  
  public final void 赤() {
    男 男 = this.톨;
    if (男.淋().booleanValue())
      return; 
    int i = nf.硬;
    ゃ();
    for (View view : this.투) {
      z0 z0 = new z0();
      this.ょ.add(z0);
      i = nf.硬;
      z0.堅(view.getLeft(), view.getTop());
      view.setVisibility(0);
    } 
    i = 탄(탁());
    int j = 탁();
    く(this.く, j, i);
    男.怖();
    ((for)(테()).起).寒(Boolean.TRUE);
  }
  
  public final void 크(z0 paramz01, z0 paramz02) {
    z0 z01;
    this.僕 = paramz02;
    int i = nf.硬;
    if (퇴(paramz01)) {
      z01 = paramz02;
    } else {
      z01 = paramz01;
      paramz01 = paramz02;
    } 
    ao ao = new ao(태().硬(), Long.valueOf(paramz01.冷), Integer.valueOf(z01.冷));
    ㅌ().悲((각)ao);
  }
  
  public final String 큰() {
    String str = v1.硬;
    return v1.冷;
  }
  
  public final a1 타() {
    return new a1(new 본(Integer.valueOf(殻.堅((Context)this, 2131034797)), Integer.valueOf(殻.堅((Context)this, 2131034803))), new 본(Integer.valueOf(2131165309), Integer.valueOf(2131165310)), new 본(Integer.valueOf(殻.堅((Context)this, 2131034800)), Integer.valueOf(殻.堅((Context)this, 2131034800))), new 본(Integer.valueOf(2131165311), Integer.valueOf(2131165311)));
  }
  
  public final int 탄(int paramInt) {
    int i = 탑();
    paramInt /= 2;
    腕.硬(paramInt);
    paramInt += i;
    腕.硬(paramInt);
    return paramInt;
  }
  
  public final int 탑() {
    蛇 蛇2 = this.師;
    蛇 蛇1 = 蛇2;
    if (蛇2 == null)
      蛇1 = null; 
    int i = 蛇1.悲.getBottom();
    腕.硬(i);
    return i;
  }
  
  public final sd 터() {
    return sd.恐;
  }
  
  public final bb 토() {
    return (bb)this.護.getValue();
  }
  
  public final void 톨() {
    int i = nf.硬;
    gc gc = 탕();
    톤(gc.暑);
    List list = ik.택(gc.堅);
    Iterator<sb> iterator = list.iterator();
    for (i = 0; iterator.hasNext(); i++) {
      sb sb = iterator.next();
      ((z0)this.ょ.get(i)).冷 = (int)sb.熱;
    } 
    辞 辞4 = ((sb)list.get(0)).硬;
    辞 辞3 = ((sb)list.get(1)).硬;
    辞 辞2 = ((sb)list.get(2)).硬;
    辞 辞1 = ((sb)list.get(3)).硬;
    蛇 蛇1 = this.師;
    蛇 蛇3 = null;
    if (蛇1 == null) {
      iterator = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button5 = 蛇2.寒;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button6 = 蛇2.辛;
    蛇 蛇2 = 蛇1;
    if (蛇1 == null)
      蛇2 = null; 
    ご(辞4, button5, button6, 蛇2.淋);
    蛇1 = this.師;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button4 = 蛇2.旨;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    button5 = 蛇2.苦;
    蛇2 = 蛇1;
    if (蛇1 == null)
      蛇2 = null; 
    ご(辞3, button4, button5, 蛇2.恐);
    蛇1 = this.師;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button3 = 蛇2.美;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    button4 = 蛇2.ぱ;
    蛇2 = 蛇1;
    if (蛇1 == null)
      蛇2 = null; 
    ご(辞2, button3, button4, 蛇2.怖);
    蛇1 = this.師;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button2 = 蛇2.冷;
    if (蛇1 == null) {
      蛇2 = null;
    } else {
      蛇2 = 蛇1;
    } 
    Button button1 = 蛇2.不;
    if (蛇1 == null)
      蛇1 = 蛇3; 
    ご(辞1, button2, button1, 蛇1.寂);
    탈().setVisibility(0);
  }
  
  public final boolean 통() {
    for (z0 z0 : this.ょ) {
      if (z0.寒 != null && !z0.暑)
        return true; 
    } 
    return false;
  }
  
  public final void 퉁() {
    z0 z0 = this.僕;
    z0.暑 = true;
    z0.寒.暑 = true;
    z0.硬().寒();
    泳().getClass();
    噛(鏡.태);
    ((密)this).크.起();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\mathse\\ui\MathPuzzleActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */