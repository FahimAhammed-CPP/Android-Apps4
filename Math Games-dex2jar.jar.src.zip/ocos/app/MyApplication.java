package ocos.app;

import android.content.ComponentCallbacks;
import java.util.List;
import y.d4;
import y.hp;
import y.ik;
import y.nf;
import y.ts;
import y.y4;
import y.zi;
import y.デ;
import y.年;
import y.秘;
import y.路;
import y.韓;
import y.髪;
import y.용;
import y.유;

public final class MyApplication extends 韓 {
  public final d4 寝 = 年.寝((유)new y4(this, 1));
  
  public final 髪 歩 = ik.赤(new 秘((ComponentCallbacks)this, null, 10));
  
  public final hp 泳 = new hp((용)new zi(3, this));
  
  public final d4 踊 = 年.寝((유)new y4(this, 0));
  
  public final 髪 返 = ik.赤(new 秘((ComponentCallbacks)this, null, 9));
  
  public final void onCreate() {
    super.onCreate();
    List list = ik.わ((Object[])new d4[] { this.踊, this.寝 });
    デ デ = デ.恐;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{y/デ}, name=null} */
    try {
      ts ts = デ.痛;
      if (ts != null) {
        ts.痛(list, true);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{y/デ}, name=null} */
        int i = nf.硬;
        return;
      } 
    } finally {}
    throw new IllegalStateException("KoinApplication has not been started".toString());
  }
  
  public final 路 硬() {
    return (路)this.泳.getValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\MyApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */