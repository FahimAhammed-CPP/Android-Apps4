package ocos.app.db.room;

import y.ac;
import y.gd;
import y.kh;
import y.mc;
import y.tc;
import y.vc;
import y.デ;

public abstract class QuizRoomDatabase extends kh {
  public static final デ 嬉 = new デ();
  
  public static volatile QuizRoomDatabase 悲;
  
  public abstract ac 恐();
  
  public abstract tc 痒();
  
  public abstract mc 痛();
  
  public abstract vc 臭();
  
  public abstract gd 起();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\room\QuizRoomDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */