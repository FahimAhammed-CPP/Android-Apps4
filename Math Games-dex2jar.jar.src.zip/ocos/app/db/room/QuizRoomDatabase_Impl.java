package ocos.app.db.room;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import y.ac;
import y.bp;
import y.ci0;
import y.gd;
import y.mc;
import y.nh;
import y.q10;
import y.t00;
import y.tc;
import y.vc;
import y.zo;
import y.政;
import y.茄;
import y.긴;

public final class QuizRoomDatabase_Impl extends QuizRoomDatabase {
  public volatile ci0 寂;
  
  public volatile q10 怖;
  
  public volatile tc 恐;
  
  public volatile ac 淋;
  
  public volatile tc 痛;
  
  public final Map 不() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put(gd.class, Collections.emptyList());
    hashMap.put(ac.class, Collections.emptyList());
    hashMap.put(vc.class, Collections.emptyList());
    hashMap.put(tc.class, Collections.emptyList());
    hashMap.put(mc.class, Collections.emptyList());
    return hashMap;
  }
  
  public final bp 冷(긴 param긴) {
    nh nh = new nh(param긴, new t00(this, 2, 1), "5310c5baad53d6f4d0f331e92c12af2c", "edfd58efe32dc7425e6331b886f42c0d");
    zo zo = new zo(param긴.硬, param긴.堅, (茄)nh, false);
    return param긴.熱.堅(zo);
  }
  
  public final ac 恐() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Ly/ac;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield 淋 : Ly/ac;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 淋 : Ly/ac;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new y/ac
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Locos/app/db/room/QuizRoomDatabase;)V
    //   30: putfield 淋 : Ly/ac;
    //   33: aload_0
    //   34: getfield 淋 : Ly/ac;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final Set 旨() {
    return new HashSet();
  }
  
  public final 政 暑() {
    return new 政(this, new HashMap<Object, Object>(0), new HashMap<Object, Object>(0), new String[] { "math_puzzle_quiz", "math_puzzle_question", "math_puzzle_option", "math_puzzle_quiz_state", "math_puzzle_level" });
  }
  
  public final tc 痒() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 恐 : Ly/tc;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield 恐 : Ly/tc;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 恐 : Ly/tc;
    //   18: ifnonnull -> 34
    //   21: aload_0
    //   22: new y/tc
    //   25: dup
    //   26: aload_0
    //   27: iconst_0
    //   28: invokespecial <init> : (Ly/kh;I)V
    //   31: putfield 恐 : Ly/tc;
    //   34: aload_0
    //   35: getfield 恐 : Ly/tc;
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: areturn
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   14	34	43	finally
    //   34	41	43	finally
    //   44	46	43	finally
  }
  
  public final mc 痛() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 痛 : Ly/tc;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield 痛 : Ly/tc;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 痛 : Ly/tc;
    //   18: ifnonnull -> 35
    //   21: aload_0
    //   22: new y/tc
    //   25: dup
    //   26: aload_0
    //   27: bipush #6
    //   29: invokespecial <init> : (Ly/kh;I)V
    //   32: putfield 痛 : Ly/tc;
    //   35: aload_0
    //   36: getfield 痛 : Ly/tc;
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: areturn
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   14	35	44	finally
    //   35	42	44	finally
    //   45	47	44	finally
  }
  
  public final List 美() {
    return Arrays.asList(new y.b4[0]);
  }
  
  public final vc 臭() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 怖 : Ly/q10;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield 怖 : Ly/q10;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 怖 : Ly/q10;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new y/q10
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Ly/kh;)V
    //   30: putfield 怖 : Ly/q10;
    //   33: aload_0
    //   34: getfield 怖 : Ly/q10;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final gd 起() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 寂 : Ly/ci0;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield 寂 : Ly/ci0;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 寂 : Ly/ci0;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new y/ci0
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Locos/app/db/room/QuizRoomDatabase;)V
    //   30: putfield 寂 : Ly/ci0;
    //   33: aload_0
    //   34: getfield 寂 : Ly/ci0;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\room\QuizRoomDatabase_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */