package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.util.ArrayList;
import java.util.List;
import y.break;
import y.ia;
import y.mm;
import y.の;
import y.글;

public class QuestionDao extends break {
  public static final String TABLENAME = "QUESTION";
  
  public String 不;
  
  public final DaoSession 旨;
  
  public QuestionDao(글 param글) {
    super(param글, null);
  }
  
  public QuestionDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
    this.旨 = paramDaoSession;
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'QUESTION' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT ,'DIFFICULTY' REAL NOT NULL ,'SEQUENCE' INTEGER NOT NULL ,'UNORDERED' INTEGER NOT NULL ,'TYPE' INTEGER NOT NULL ,'RESOURCE_PATH' TEXT,'LEVEL_ID' INTEGER NOT NULL );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'QUESTION'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public Long getKey(Question paramQuestion) {
    return (paramQuestion != null) ? paramQuestion.getId() : null;
  }
  
  public List<Question> loadAllDeepFromCursor(Cursor paramCursor) {
    int i = paramCursor.getCount();
    ArrayList<Question> arrayList = new ArrayList(i);
    if (paramCursor.moveToFirst()) {
      の の = this.熱;
      if (の != null) {
        の.lock();
        の.冷(i);
      } 
      try {
        while (true) {
          arrayList.add(恐(paramCursor, false));
          boolean bool = paramCursor.moveToNext();
          if (!bool) {
            if (の != null)
              return arrayList; 
            break;
          } 
        } 
      } finally {
        if (の != null)
          の.unlock(); 
      } 
    } 
    return arrayList;
  }
  
  public Question loadDeep(Long paramLong) {
    硬();
    if (paramLong == null)
      return null; 
    StringBuilder stringBuilder = new StringBuilder(怖());
    stringBuilder.append("WHERE ");
    mm.堅(stringBuilder, "T", getPkColumns());
    null = stringBuilder.toString();
    String str = paramLong.toString();
    Cursor cursor = this.硬.rawQuery(null, new String[] { str });
    try {
      boolean bool = cursor.moveToFirst();
      if (!bool)
        return null; 
      if (cursor.isLast())
        return 恐(cursor, true); 
      StringBuilder stringBuilder1 = new StringBuilder("Expected unique result, but count was ");
      stringBuilder1.append(cursor.getCount());
      throw new IllegalStateException(stringBuilder1.toString());
    } finally {
      cursor.close();
    } 
  }
  
  public List<Question> queryDeep(String paramString, String... paramVarArgs) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(怖());
    stringBuilder.append(paramString);
    paramString = stringBuilder.toString();
    Cursor cursor = this.硬.rawQuery(paramString, paramVarArgs);
    try {
      return loadAllDeepFromCursor(cursor);
    } finally {
      cursor.close();
    } 
  }
  
  public Question readEntity(Cursor paramCursor, int paramInt) {
    boolean bool;
    Long long_;
    String str;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    double d = paramCursor.getDouble(paramInt + 1);
    int i = paramCursor.getInt(paramInt + 2);
    if (paramCursor.getShort(paramInt + 3) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int j = paramCursor.getInt(paramInt + 4);
    int k = paramInt + 5;
    if (paramCursor.isNull(k)) {
      str = null;
    } else {
      str = paramCursor.getString(k);
    } 
    return new Question(long_, d, i, bool, j, str, paramCursor.getLong(paramInt + 6));
  }
  
  public void readEntity(Cursor paramCursor, Question paramQuestion, int paramInt) {
    Long long_1;
    String str;
    boolean bool = paramCursor.isNull(paramInt);
    Long long_2 = null;
    if (bool) {
      long_1 = null;
    } else {
      long_1 = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramQuestion.setId(long_1);
    paramQuestion.setDifficulty(paramCursor.getDouble(paramInt + 1));
    paramQuestion.setSequence(paramCursor.getInt(paramInt + 2));
    if (paramCursor.getShort(paramInt + 3) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    paramQuestion.setUnordered(bool);
    paramQuestion.setType(paramCursor.getInt(paramInt + 4));
    int i = paramInt + 5;
    if (paramCursor.isNull(i)) {
      long_1 = long_2;
    } else {
      str = paramCursor.getString(i);
    } 
    paramQuestion.setResourcePath(str);
    paramQuestion.setLevelId(paramCursor.getLong(paramInt + 6));
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 堅(Object paramObject) {
    ((Question)paramObject).__setDaoSession(this.旨);
  }
  
  public final String 怖() {
    if (this.不 == null) {
      StringBuilder stringBuilder = new StringBuilder("SELECT ");
      mm.硬(stringBuilder, "T", getAllColumns());
      stringBuilder.append(',');
      mm.硬(stringBuilder, "T0", this.旨.getQuestionDao().getAllColumns());
      stringBuilder.append(" FROM QUESTION T");
      stringBuilder.append(" LEFT JOIN QUESTION T0 ON T.'LEVEL_ID'=T0.'_id'");
      stringBuilder.append(' ');
      this.不 = stringBuilder.toString();
    } 
    return this.不;
  }
  
  public final Question 恐(Cursor paramCursor, boolean paramBoolean) {
    Question question2 = (Question)嬉(paramCursor, 0, paramBoolean);
    int i = (getAllColumns()).length;
    Question question1 = (Question)this.旨.getQuestionDao().嬉(paramCursor, i, true);
    if (question1 != null)
      question2.setQuestion(question1); 
    return question2;
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    long l;
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    Long long_ = paramObject.getId();
    if (long_ != null)
      paramSQLiteStatement.bindLong(1, long_.longValue()); 
    paramSQLiteStatement.bindDouble(2, paramObject.getDifficulty());
    paramSQLiteStatement.bindLong(3, paramObject.getSequence());
    if (paramObject.getUnordered()) {
      l = 1L;
    } else {
      l = 0L;
    } 
    paramSQLiteStatement.bindLong(4, l);
    paramSQLiteStatement.bindLong(5, paramObject.getType());
    String str = paramObject.getResourcePath();
    if (str != null)
      paramSQLiteStatement.bindString(6, str); 
    paramSQLiteStatement.bindLong(7, paramObject.getLevelId());
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Question)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Difficulty = new ia(1, double.class, "difficulty", false, "DIFFICULTY");
    
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
    
    public static final ia LevelId;
    
    public static final ia ResourcePath;
    
    public static final ia Sequence;
    
    public static final ia Type;
    
    public static final ia Unordered = new ia(3, boolean.class, "unordered", false, "UNORDERED");
    
    static {
      Type = new ia(4, clazz, "type", false, "TYPE");
      ResourcePath = new ia(5, String.class, "resourcePath", false, "RESOURCE_PATH");
      LevelId = new ia(6, long.class, "levelId", false, "LEVEL_ID");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\QuestionDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */