package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import y.break;
import y.ia;
import y.글;

public class CategoryDao extends break {
  public static final String TABLENAME = "CATEGORY";
  
  public CategoryDao(글 param글) {
    super(param글, null);
  }
  
  public CategoryDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'CATEGORY' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'CATEGORY'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public Long getKey(Category paramCategory) {
    return (paramCategory != null) ? paramCategory.getId() : null;
  }
  
  public Category readEntity(Cursor paramCursor, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      paramCursor = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    return new Category(long_);
  }
  
  public void readEntity(Cursor paramCursor, Category paramCategory, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      paramCursor = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramCategory.setId(long_);
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    paramObject = paramObject.getId();
    if (paramObject != null)
      paramSQLiteStatement.bindLong(1, paramObject.longValue()); 
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Category)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\CategoryDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */