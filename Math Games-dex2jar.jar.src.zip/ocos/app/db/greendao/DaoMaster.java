package ocos.app.db.greendao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.HashMap;
import y.break;
import y.catch;
import y.class;
import y.な;
import y.글;

public class DaoMaster extends catch {
  public static final int SCHEMA_VERSION = 1001;
  
  public DaoMaster(SQLiteDatabase paramSQLiteDatabase) {
    super(paramSQLiteDatabase);
    硬(LanguageDao.class);
    硬(CategoryDao.class);
    硬(LevelDao.class);
    硬(ScoreDao.class);
    硬(QuestionDao.class);
    硬(OptionDao.class);
    硬(TranslationDao.class);
  }
  
  public static void createAllTables(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    LanguageDao.createTable(paramSQLiteDatabase, paramBoolean);
    CategoryDao.createTable(paramSQLiteDatabase, paramBoolean);
    LevelDao.createTable(paramSQLiteDatabase, paramBoolean);
    ScoreDao.createTable(paramSQLiteDatabase, paramBoolean);
    QuestionDao.createTable(paramSQLiteDatabase, paramBoolean);
    OptionDao.createTable(paramSQLiteDatabase, paramBoolean);
    TranslationDao.createTable(paramSQLiteDatabase, paramBoolean);
  }
  
  public static void dropAllTables(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    LanguageDao.dropTable(paramSQLiteDatabase, paramBoolean);
    CategoryDao.dropTable(paramSQLiteDatabase, paramBoolean);
    LevelDao.dropTable(paramSQLiteDatabase, paramBoolean);
    ScoreDao.dropTable(paramSQLiteDatabase, paramBoolean);
    QuestionDao.dropTable(paramSQLiteDatabase, paramBoolean);
    OptionDao.dropTable(paramSQLiteDatabase, paramBoolean);
    TranslationDao.dropTable(paramSQLiteDatabase, paramBoolean);
  }
  
  public DaoSession newSession() {
    な な = な.淋;
    HashMap<Class<? extends break>, 글> hashMap = this.熱;
    return new DaoSession(this.硬, な, hashMap);
  }
  
  public DaoSession newSession(な paramな) {
    HashMap<Class<? extends break>, 글> hashMap = this.熱;
    return new DaoSession(this.硬, paramな, hashMap);
  }
  
  public static class DevOpenHelper extends OpenHelper {
    public DevOpenHelper(Context param1Context, String param1String, SQLiteDatabase.CursorFactory param1CursorFactory) {
      super(param1Context, param1String, param1CursorFactory);
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      DaoMaster.dropAllTables(param1SQLiteDatabase, true);
      onCreate(param1SQLiteDatabase);
    }
  }
  
  public static abstract class OpenHelper extends SQLiteOpenHelper {
    public OpenHelper(Context param1Context, String param1String, SQLiteDatabase.CursorFactory param1CursorFactory) {
      super(param1Context, param1String, param1CursorFactory, 1001);
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      DaoMaster.createAllTables(param1SQLiteDatabase, false);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\DaoMaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */