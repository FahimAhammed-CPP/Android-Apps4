package ocos.app.db.greendao;

import java.util.Date;
import y.금;

public class Score {
  public transient DaoSession 冷;
  
  public double 堅;
  
  public transient ScoreDao 寒;
  
  public Long 旨;
  
  public long 暑;
  
  public Date 熱;
  
  public Long 硬;
  
  public Level 美;
  
  public Score() {}
  
  public Score(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public Score(Long paramLong, double paramDouble, Date paramDate, long paramLong1) {
    this.硬 = paramLong;
    this.堅 = paramDouble;
    this.熱 = paramDate;
    this.暑 = paramLong1;
  }
  
  public void __setDaoSession(DaoSession paramDaoSession) {
    this.冷 = paramDaoSession;
    if (paramDaoSession != null) {
      ScoreDao scoreDao = paramDaoSession.getScoreDao();
    } else {
      paramDaoSession = null;
    } 
    this.寒 = (ScoreDao)paramDaoSession;
  }
  
  public void delete() {
    ScoreDao scoreDao = this.寒;
    if (scoreDao != null) {
      scoreDao.delete(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public Date getDate() {
    return this.熱;
  }
  
  public Long getId() {
    return this.硬;
  }
  
  public Level getLevel() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 暑 : J
    //   4: lstore_1
    //   5: aload_0
    //   6: getfield 旨 : Ljava/lang/Long;
    //   9: astore_3
    //   10: aload_3
    //   11: ifnull -> 25
    //   14: aload_3
    //   15: lload_1
    //   16: invokestatic valueOf : (J)Ljava/lang/Long;
    //   19: invokevirtual equals : (Ljava/lang/Object;)Z
    //   22: ifne -> 66
    //   25: aload_0
    //   26: getfield 冷 : Locos/app/db/greendao/DaoSession;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnull -> 76
    //   34: aload_3
    //   35: invokevirtual getLevelDao : ()Locos/app/db/greendao/LevelDao;
    //   38: lload_1
    //   39: invokestatic valueOf : (J)Ljava/lang/Long;
    //   42: invokevirtual load : (Ljava/lang/Object;)Ljava/lang/Object;
    //   45: checkcast ocos/app/db/greendao/Level
    //   48: astore_3
    //   49: aload_0
    //   50: monitorenter
    //   51: aload_0
    //   52: aload_3
    //   53: putfield 美 : Locos/app/db/greendao/Level;
    //   56: aload_0
    //   57: lload_1
    //   58: invokestatic valueOf : (J)Ljava/lang/Long;
    //   61: putfield 旨 : Ljava/lang/Long;
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_0
    //   67: getfield 美 : Locos/app/db/greendao/Level;
    //   70: areturn
    //   71: astore_3
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    //   76: new y/금
    //   79: dup
    //   80: ldc 'Entity is detached from DAO context'
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   51	66	71	finally
    //   72	74	71	finally
  }
  
  public long getLevelId() {
    return this.暑;
  }
  
  public double getScore() {
    return this.堅;
  }
  
  public void refresh() {
    ScoreDao scoreDao = this.寒;
    if (scoreDao != null) {
      scoreDao.refresh(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public void setDate(Date paramDate) {
    this.熱 = paramDate;
  }
  
  public void setId(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public void setLevel(Level paramLevel) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 40
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_1
    //   8: putfield 美 : Locos/app/db/greendao/Level;
    //   11: aload_1
    //   12: invokevirtual getId : ()Ljava/lang/Long;
    //   15: invokevirtual longValue : ()J
    //   18: lstore_2
    //   19: aload_0
    //   20: lload_2
    //   21: putfield 暑 : J
    //   24: aload_0
    //   25: lload_2
    //   26: invokestatic valueOf : (J)Ljava/lang/Long;
    //   29: putfield 旨 : Ljava/lang/Long;
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    //   40: new y/금
    //   43: dup
    //   44: ldc 'To-one property 'levelId' has not-null constraint; cannot set to-one to null'
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   6	34	35	finally
    //   36	38	35	finally
  }
  
  public void setLevelId(long paramLong) {
    this.暑 = paramLong;
  }
  
  public void setScore(double paramDouble) {
    this.堅 = paramDouble;
  }
  
  public void update() {
    ScoreDao scoreDao = this.寒;
    if (scoreDao != null) {
      scoreDao.update(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\Score.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */