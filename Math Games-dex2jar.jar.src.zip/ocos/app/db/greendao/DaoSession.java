package ocos.app.db.greendao;

import android.database.sqlite.SQLiteDatabase;
import java.util.Map;
import y.break;
import y.class;
import y.な;
import y.글;

public class DaoSession extends class {
  public final CategoryDao ぱ;
  
  public final 글 不;
  
  public final 글 冷;
  
  public final ScoreDao 嬉;
  
  public final OptionDao 寂;
  
  public final 글 寒;
  
  public final QuestionDao 悲;
  
  public final 글 旨;
  
  public final 글 暑;
  
  public final TranslationDao 淋;
  
  public final 글 熱;
  
  public final 글 美;
  
  public final LevelDao 苦;
  
  public final LanguageDao 辛;
  
  public DaoSession(SQLiteDatabase paramSQLiteDatabase, な paramな, Map<Class<? extends break>, 글> paramMap) {
    super(paramSQLiteDatabase);
    글 글1 = paramMap.get(LanguageDao.class);
    글1.getClass();
    글1 = new 글(글1);
    this.熱 = 글1;
    글1.硬(paramな);
    글 글3 = paramMap.get(CategoryDao.class);
    글3.getClass();
    글3 = new 글(글3);
    this.暑 = 글3;
    글3.硬(paramな);
    글 글4 = paramMap.get(LevelDao.class);
    글4.getClass();
    글4 = new 글(글4);
    this.冷 = 글4;
    글4.硬(paramな);
    글 글5 = paramMap.get(ScoreDao.class);
    글5.getClass();
    글5 = new 글(글5);
    this.寒 = 글5;
    글5.硬(paramな);
    글 글6 = paramMap.get(QuestionDao.class);
    글6.getClass();
    글6 = new 글(글6);
    this.美 = 글6;
    글6.硬(paramな);
    글 글7 = paramMap.get(OptionDao.class);
    글7.getClass();
    글7 = new 글(글7);
    this.旨 = 글7;
    글7.硬(paramな);
    글 글2 = paramMap.get(TranslationDao.class);
    글2.getClass();
    글2 = new 글(글2);
    this.不 = 글2;
    글2.硬(paramな);
    LanguageDao languageDao = new LanguageDao(글1, this);
    this.辛 = languageDao;
    CategoryDao categoryDao = new CategoryDao(글3, this);
    this.ぱ = categoryDao;
    LevelDao levelDao = new LevelDao(글4, this);
    this.苦 = levelDao;
    ScoreDao scoreDao = new ScoreDao(글5, this);
    this.嬉 = scoreDao;
    QuestionDao questionDao = new QuestionDao(글6, this);
    this.悲 = questionDao;
    OptionDao optionDao = new OptionDao(글7, this);
    this.寂 = optionDao;
    TranslationDao translationDao = new TranslationDao(글2, this);
    this.淋 = translationDao;
    硬(Language.class, languageDao);
    硬(Category.class, categoryDao);
    硬(Level.class, levelDao);
    硬(Score.class, scoreDao);
    硬(Question.class, questionDao);
    硬(Option.class, optionDao);
    硬(Translation.class, translationDao);
  }
  
  public void clear() {
    this.熱.死.clear();
    this.暑.死.clear();
    this.冷.死.clear();
    this.寒.死.clear();
    this.美.死.clear();
    this.旨.死.clear();
    this.不.死.clear();
  }
  
  public CategoryDao getCategoryDao() {
    return this.ぱ;
  }
  
  public LanguageDao getLanguageDao() {
    return this.辛;
  }
  
  public LevelDao getLevelDao() {
    return this.苦;
  }
  
  public OptionDao getOptionDao() {
    return this.寂;
  }
  
  public QuestionDao getQuestionDao() {
    return this.悲;
  }
  
  public ScoreDao getScoreDao() {
    return this.嬉;
  }
  
  public TranslationDao getTranslationDao() {
    return this.淋;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\DaoSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */