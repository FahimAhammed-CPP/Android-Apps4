package ocos.app.db.greendao;

public class Language {
  public String 堅;
  
  public Long 硬;
  
  public Language() {}
  
  public Language(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public Language(Long paramLong, String paramString) {
    this.硬 = paramLong;
    this.堅 = paramString;
  }
  
  public Long getId() {
    return this.硬;
  }
  
  public String getLabel() {
    return this.堅;
  }
  
  public void setId(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public void setLabel(String paramString) {
    this.堅 = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\Language.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */