package ocos.app.db.greendao;

import java.util.List;
import y.금;

public class Translation {
  public long 冷;
  
  public String 堅;
  
  public transient DaoSession 寒;
  
  public List 旨;
  
  public long 暑;
  
  public int 熱;
  
  public Long 硬;
  
  public transient TranslationDao 美;
  
  public Translation() {}
  
  public Translation(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public Translation(Long paramLong, String paramString, int paramInt, long paramLong1, long paramLong2) {
    this.硬 = paramLong;
    this.堅 = paramString;
    this.熱 = paramInt;
    this.暑 = paramLong1;
    this.冷 = paramLong2;
  }
  
  public void __setDaoSession(DaoSession paramDaoSession) {
    this.寒 = paramDaoSession;
    if (paramDaoSession != null) {
      TranslationDao translationDao = paramDaoSession.getTranslationDao();
    } else {
      paramDaoSession = null;
    } 
    this.美 = (TranslationDao)paramDaoSession;
  }
  
  public void delete() {
    TranslationDao translationDao = this.美;
    if (translationDao != null) {
      translationDao.delete(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public Long getId() {
    return this.硬;
  }
  
  public long getLanguageId() {
    return this.冷;
  }
  
  public String getText() {
    return this.堅;
  }
  
  public List<Translation> getTranslationList() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 旨 : Ljava/util/List;
    //   4: ifnonnull -> 65
    //   7: aload_0
    //   8: getfield 寒 : Locos/app/db/greendao/DaoSession;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 55
    //   16: aload_1
    //   17: invokevirtual getTranslationDao : ()Locos/app/db/greendao/TranslationDao;
    //   20: aload_0
    //   21: getfield 硬 : Ljava/lang/Long;
    //   24: invokevirtual longValue : ()J
    //   27: invokevirtual _queryTranslation_TranslationList : (J)Ljava/util/List;
    //   30: astore_1
    //   31: aload_0
    //   32: monitorenter
    //   33: aload_0
    //   34: getfield 旨 : Ljava/util/List;
    //   37: ifnonnull -> 45
    //   40: aload_0
    //   41: aload_1
    //   42: putfield 旨 : Ljava/util/List;
    //   45: aload_0
    //   46: monitorexit
    //   47: goto -> 65
    //   50: astore_1
    //   51: aload_0
    //   52: monitorexit
    //   53: aload_1
    //   54: athrow
    //   55: new y/금
    //   58: dup
    //   59: ldc 'Entity is detached from DAO context'
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: athrow
    //   65: aload_0
    //   66: getfield 旨 : Ljava/util/List;
    //   69: areturn
    // Exception table:
    //   from	to	target	type
    //   33	45	50	finally
    //   45	47	50	finally
    //   51	53	50	finally
  }
  
  public int getType() {
    return this.熱;
  }
  
  public long getTypeId() {
    return this.暑;
  }
  
  public void refresh() {
    TranslationDao translationDao = this.美;
    if (translationDao != null) {
      translationDao.refresh(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public void resetTranslationList() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aconst_null
    //   4: putfield 旨 : Ljava/util/List;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public void setId(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public void setLanguageId(long paramLong) {
    this.冷 = paramLong;
  }
  
  public void setText(String paramString) {
    this.堅 = paramString;
  }
  
  public void setType(int paramInt) {
    this.熱 = paramInt;
  }
  
  public void setTypeId(long paramLong) {
    this.暑 = paramLong;
  }
  
  public void update() {
    TranslationDao translationDao = this.美;
    if (translationDao != null) {
      translationDao.update(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\Translation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */