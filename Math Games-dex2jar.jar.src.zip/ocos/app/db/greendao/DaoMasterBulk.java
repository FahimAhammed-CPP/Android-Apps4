package ocos.app.db.greendao;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.IOException;
import y.nf;
import y.td;
import y.ㄲ;

public final class DaoMasterBulk extends DaoMaster {
  public DaoMasterBulk(SQLiteDatabase paramSQLiteDatabase) {
    super(paramSQLiteDatabase);
  }
  
  public static final class DevOpenHelper extends OpenHelper {
    public DevOpenHelper(Context param1Context, ㄲ param1ㄲ, SQLiteDatabase.CursorFactory param1CursorFactory) {
      super(param1Context, param1ㄲ, param1CursorFactory);
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      param1Int1 = nf.硬;
      LanguageDao.dropTable(param1SQLiteDatabase, true);
      CategoryDao.dropTable(param1SQLiteDatabase, true);
      LevelDao.dropTable(param1SQLiteDatabase, true);
      QuestionDao.dropTable(param1SQLiteDatabase, true);
      OptionDao.dropTable(param1SQLiteDatabase, true);
      TranslationDao.dropTable(param1SQLiteDatabase, true);
      onCreate(param1SQLiteDatabase);
    }
  }
  
  public static abstract class OpenHelper extends SQLiteOpenHelper {
    public final ㄲ 怖;
    
    public final Context 淋;
    
    public OpenHelper(Context param1Context, ㄲ param1ㄲ, SQLiteDatabase.CursorFactory param1CursorFactory) {
      super(param1Context, param1ㄲ.硬, param1CursorFactory, 1002);
      this.淋 = param1Context;
      this.怖 = param1ㄲ;
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      int i = nf.硬;
      DaoMaster.createAllTables(param1SQLiteDatabase, false);
      Context context1 = this.淋;
      String str = this.怖.堅;
      try {
      
      } catch (SQLException sQLException) {
      
      } catch (IOException iOException3) {
        param1SQLiteDatabase = null;
        SQLiteDatabase sQLiteDatabase1 = param1SQLiteDatabase;
        SQLiteDatabase sQLiteDatabase3 = param1SQLiteDatabase;
        SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase1;
        td.怖(iOException3);
        sQLiteDatabase3 = param1SQLiteDatabase;
        sQLiteDatabase2 = sQLiteDatabase1;
        throw null;
      } finally {
        param1SQLiteDatabase = null;
        Context context = null;
        context1 = context;
        if (context1 != null)
          try {
            context1.close();
            if (context != null)
              try {
                context.close();
                throw param1SQLiteDatabase;
              } catch (IOException null) {
                td.怖(iOException1);
                throw null;
              }  
            throw iOException1;
          } catch (IOException null) {
            td.怖(iOException1);
            throw null;
          }  
        if (context != null)
          try {
            context.close();
            throw iOException1;
          } catch (IOException iOException1) {
            td.怖(iOException1);
            throw null;
          }  
      } 
      IOException iOException2 = iOException1;
      Context context2 = context1;
      td.怖(iOException3);
      iOException2 = iOException1;
      context2 = context1;
      throw null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\DaoMasterBulk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */