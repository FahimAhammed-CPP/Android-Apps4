package ocos.app.db.greendao;

import y.금;

public class Question {
  public Long ぱ;
  
  public transient QuestionDao 不;
  
  public int 冷;
  
  public double 堅;
  
  public String 寒;
  
  public transient DaoSession 旨;
  
  public boolean 暑;
  
  public int 熱;
  
  public Long 硬;
  
  public long 美;
  
  public Question 辛;
  
  public Question() {}
  
  public Question(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public Question(Long paramLong, double paramDouble, int paramInt1, boolean paramBoolean, int paramInt2, String paramString, long paramLong1) {
    this.硬 = paramLong;
    this.堅 = paramDouble;
    this.熱 = paramInt1;
    this.暑 = paramBoolean;
    this.冷 = paramInt2;
    this.寒 = paramString;
    this.美 = paramLong1;
  }
  
  public void __setDaoSession(DaoSession paramDaoSession) {
    this.旨 = paramDaoSession;
    if (paramDaoSession != null) {
      QuestionDao questionDao = paramDaoSession.getQuestionDao();
    } else {
      paramDaoSession = null;
    } 
    this.不 = (QuestionDao)paramDaoSession;
  }
  
  public void delete() {
    QuestionDao questionDao = this.不;
    if (questionDao != null) {
      questionDao.delete(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public double getDifficulty() {
    return this.堅;
  }
  
  public Long getId() {
    return this.硬;
  }
  
  public long getLevelId() {
    return this.美;
  }
  
  public Question getQuestion() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 美 : J
    //   4: lstore_1
    //   5: aload_0
    //   6: getfield ぱ : Ljava/lang/Long;
    //   9: astore_3
    //   10: aload_3
    //   11: ifnull -> 25
    //   14: aload_3
    //   15: lload_1
    //   16: invokestatic valueOf : (J)Ljava/lang/Long;
    //   19: invokevirtual equals : (Ljava/lang/Object;)Z
    //   22: ifne -> 66
    //   25: aload_0
    //   26: getfield 旨 : Locos/app/db/greendao/DaoSession;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnull -> 76
    //   34: aload_3
    //   35: invokevirtual getQuestionDao : ()Locos/app/db/greendao/QuestionDao;
    //   38: lload_1
    //   39: invokestatic valueOf : (J)Ljava/lang/Long;
    //   42: invokevirtual load : (Ljava/lang/Object;)Ljava/lang/Object;
    //   45: checkcast ocos/app/db/greendao/Question
    //   48: astore_3
    //   49: aload_0
    //   50: monitorenter
    //   51: aload_0
    //   52: aload_3
    //   53: putfield 辛 : Locos/app/db/greendao/Question;
    //   56: aload_0
    //   57: lload_1
    //   58: invokestatic valueOf : (J)Ljava/lang/Long;
    //   61: putfield ぱ : Ljava/lang/Long;
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_0
    //   67: getfield 辛 : Locos/app/db/greendao/Question;
    //   70: areturn
    //   71: astore_3
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    //   76: new y/금
    //   79: dup
    //   80: ldc 'Entity is detached from DAO context'
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   51	66	71	finally
    //   72	74	71	finally
  }
  
  public String getResourcePath() {
    return this.寒;
  }
  
  public int getSequence() {
    return this.熱;
  }
  
  public int getType() {
    return this.冷;
  }
  
  public boolean getUnordered() {
    return this.暑;
  }
  
  public void refresh() {
    QuestionDao questionDao = this.不;
    if (questionDao != null) {
      questionDao.refresh(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public void setDifficulty(double paramDouble) {
    this.堅 = paramDouble;
  }
  
  public void setId(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public void setLevelId(long paramLong) {
    this.美 = paramLong;
  }
  
  public void setQuestion(Question paramQuestion) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 40
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_1
    //   8: putfield 辛 : Locos/app/db/greendao/Question;
    //   11: aload_1
    //   12: invokevirtual getId : ()Ljava/lang/Long;
    //   15: invokevirtual longValue : ()J
    //   18: lstore_2
    //   19: aload_0
    //   20: lload_2
    //   21: putfield 美 : J
    //   24: aload_0
    //   25: lload_2
    //   26: invokestatic valueOf : (J)Ljava/lang/Long;
    //   29: putfield ぱ : Ljava/lang/Long;
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    //   40: new y/금
    //   43: dup
    //   44: ldc 'To-one property 'levelId' has not-null constraint; cannot set to-one to null'
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   6	34	35	finally
    //   36	38	35	finally
  }
  
  public void setResourcePath(String paramString) {
    this.寒 = paramString;
  }
  
  public void setSequence(int paramInt) {
    this.熱 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.冷 = paramInt;
  }
  
  public void setUnordered(boolean paramBoolean) {
    this.暑 = paramBoolean;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Question{id=");
    stringBuilder.append(this.硬);
    stringBuilder.append(", difficulty=");
    stringBuilder.append(this.堅);
    stringBuilder.append(", sequence=");
    stringBuilder.append(this.熱);
    stringBuilder.append(", unordered=");
    stringBuilder.append(this.暑);
    stringBuilder.append(", type=");
    stringBuilder.append(this.冷);
    stringBuilder.append(", resourcePath='");
    stringBuilder.append(this.寒);
    stringBuilder.append("', levelId=");
    stringBuilder.append(this.美);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void update() {
    QuestionDao questionDao = this.不;
    if (questionDao != null) {
      questionDao.update(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\Question.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */