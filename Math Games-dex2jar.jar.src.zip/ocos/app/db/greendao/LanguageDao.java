package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import y.break;
import y.ia;
import y.글;

public class LanguageDao extends break {
  public static final String TABLENAME = "LANGUAGE";
  
  public LanguageDao(글 param글) {
    super(param글, null);
  }
  
  public LanguageDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'LANGUAGE' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT ,'LABEL' TEXT NOT NULL );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'LANGUAGE'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public Long getKey(Language paramLanguage) {
    return (paramLanguage != null) ? paramLanguage.getId() : null;
  }
  
  public Language readEntity(Cursor paramCursor, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    return new Language(long_, paramCursor.getString(paramInt + 1));
  }
  
  public void readEntity(Cursor paramCursor, Language paramLanguage, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramLanguage.setId(long_);
    paramLanguage.setLabel(paramCursor.getString(paramInt + 1));
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    Long long_ = paramObject.getId();
    if (long_ != null)
      paramSQLiteStatement.bindLong(1, long_.longValue()); 
    paramSQLiteStatement.bindString(2, paramObject.getLabel());
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Language)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
    
    public static final ia Label = new ia(1, String.class, "label", false, "LABEL");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\LanguageDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */