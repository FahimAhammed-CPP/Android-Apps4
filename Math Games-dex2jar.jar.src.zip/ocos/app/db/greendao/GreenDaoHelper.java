package ocos.app.db.greendao;

import android.content.Context;
import y.ㄲ;

public final class GreenDaoHelper {
  public final ㄲ 堅;
  
  public DaoSession 熱;
  
  public final Context 硬;
  
  public GreenDaoHelper(Context paramContext, ㄲ paramㄲ) {
    this.硬 = paramContext;
    this.堅 = paramㄲ;
  }
  
  public final DaoSession getDaoSession() {
    if (this.熱 == null) {
      ㄲ ㄲ1 = this.堅;
      this.熱 = (new DaoMaster((new DaoMasterBulk.DevOpenHelper(this.硬, ㄲ1, null)).getWritableDatabase())).newSession();
    } 
    return this.熱;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\GreenDaoHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */