package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.util.List;
import y.break;
import y.hb;
import y.ia;
import y.글;

public class TranslationDao extends break {
  public static final String TABLENAME = "TRANSLATION";
  
  public hb 不;
  
  public final DaoSession 旨;
  
  public TranslationDao(글 param글) {
    super(param글, null);
  }
  
  public TranslationDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
    this.旨 = paramDaoSession;
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'TRANSLATION' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT ,'TEXT' TEXT NOT NULL ,'TYPE' INTEGER NOT NULL ,'TYPE_ID' INTEGER NOT NULL ,'LANGUAGE_ID' INTEGER NOT NULL );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'TRANSLATION'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public List<Translation> _queryTranslation_TranslationList(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 不 : Ly/hb;
    //   6: ifnonnull -> 57
    //   9: aload_0
    //   10: invokevirtual queryBuilder : ()Ly/ib;
    //   13: astore #4
    //   15: getstatic ocos/app/db/greendao/TranslationDao$Properties.LanguageId : Ly/ia;
    //   18: astore #5
    //   20: aload #5
    //   22: invokevirtual getClass : ()Ljava/lang/Class;
    //   25: pop
    //   26: aload #4
    //   28: new y/xy
    //   31: dup
    //   32: aload #5
    //   34: aconst_null
    //   35: invokespecial <init> : (Ly/ia;Ljava/lang/Long;)V
    //   38: iconst_0
    //   39: anewarray y/wy
    //   42: invokevirtual 熱 : (Ly/xy;[Ly/wy;)V
    //   45: aload_0
    //   46: aload #4
    //   48: invokevirtual 硬 : ()Ly/hb;
    //   51: putfield 不 : Ly/hb;
    //   54: goto -> 57
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_0
    //   60: getfield 不 : Ly/hb;
    //   63: astore #4
    //   65: aload #4
    //   67: getfield 旨 : Ly/촉;
    //   70: astore #5
    //   72: aload #5
    //   74: invokevirtual getClass : ()Ljava/lang/Class;
    //   77: pop
    //   78: invokestatic currentThread : ()Ljava/lang/Thread;
    //   81: aload #4
    //   83: getfield 冷 : Ljava/lang/Thread;
    //   86: if_acmpne -> 119
    //   89: aload #5
    //   91: getfield 寒 : Ljava/lang/Object;
    //   94: checkcast [Ljava/lang/String;
    //   97: astore #5
    //   99: aload #5
    //   101: arraylength
    //   102: istore_3
    //   103: aload #5
    //   105: iconst_0
    //   106: aload #4
    //   108: getfield 暑 : [Ljava/lang/String;
    //   111: iconst_0
    //   112: iload_3
    //   113: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   116: goto -> 126
    //   119: aload #5
    //   121: invokevirtual 硬 : ()Ly/finally;
    //   124: astore #4
    //   126: aload #4
    //   128: checkcast y/hb
    //   131: astore #5
    //   133: lload_1
    //   134: invokestatic valueOf : (J)Ljava/lang/Long;
    //   137: astore #4
    //   139: aload #5
    //   141: getfield 寒 : I
    //   144: ifeq -> 299
    //   147: aload #5
    //   149: getfield 美 : I
    //   152: ifeq -> 299
    //   155: invokestatic currentThread : ()Ljava/lang/Thread;
    //   158: aload #5
    //   160: getfield 冷 : Ljava/lang/Thread;
    //   163: if_acmpne -> 289
    //   166: aload #5
    //   168: getfield 暑 : [Ljava/lang/String;
    //   171: astore #6
    //   173: aload #4
    //   175: ifnull -> 190
    //   178: aload #6
    //   180: iconst_0
    //   181: aload #4
    //   183: invokevirtual toString : ()Ljava/lang/String;
    //   186: aastore
    //   187: goto -> 195
    //   190: aload #6
    //   192: iconst_0
    //   193: aconst_null
    //   194: aastore
    //   195: invokestatic currentThread : ()Ljava/lang/Thread;
    //   198: aload #5
    //   200: getfield 冷 : Ljava/lang/Thread;
    //   203: if_acmpne -> 279
    //   206: aload #5
    //   208: getfield 硬 : Ly/break;
    //   211: invokevirtual getDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   214: aload #5
    //   216: getfield 熱 : Ljava/lang/String;
    //   219: aload #5
    //   221: getfield 暑 : [Ljava/lang/String;
    //   224: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   227: astore #4
    //   229: aload #5
    //   231: getfield 堅 : Ly/男;
    //   234: getfield 怖 : Ljava/lang/Object;
    //   237: checkcast y/break
    //   240: astore #5
    //   242: aload #5
    //   244: invokevirtual getClass : ()Ljava/lang/Class;
    //   247: pop
    //   248: aload #5
    //   250: aload #4
    //   252: invokevirtual ぱ : (Landroid/database/Cursor;)Ljava/util/List;
    //   255: astore #5
    //   257: aload #4
    //   259: invokeinterface close : ()V
    //   264: aload #5
    //   266: areturn
    //   267: astore #5
    //   269: aload #4
    //   271: invokeinterface close : ()V
    //   276: aload #5
    //   278: athrow
    //   279: new y/금
    //   282: dup
    //   283: ldc 'Method may be called only in owner thread, use forCurrentThread to get an instance for this thread'
    //   285: invokespecial <init> : (Ljava/lang/String;)V
    //   288: athrow
    //   289: new y/금
    //   292: dup
    //   293: ldc 'Method may be called only in owner thread, use forCurrentThread to get an instance for this thread'
    //   295: invokespecial <init> : (Ljava/lang/String;)V
    //   298: athrow
    //   299: new java/lang/IllegalArgumentException
    //   302: dup
    //   303: ldc 'Illegal parameter index: 0'
    //   305: invokespecial <init> : (Ljava/lang/String;)V
    //   308: athrow
    //   309: aload_0
    //   310: monitorexit
    //   311: aload #4
    //   313: athrow
    //   314: astore #4
    //   316: goto -> 309
    // Exception table:
    //   from	to	target	type
    //   2	54	314	finally
    //   57	59	314	finally
    //   248	257	267	finally
    //   309	311	314	finally
  }
  
  public Long getKey(Translation paramTranslation) {
    return (paramTranslation != null) ? paramTranslation.getId() : null;
  }
  
  public Translation readEntity(Cursor paramCursor, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    return new Translation(long_, paramCursor.getString(paramInt + 1), paramCursor.getInt(paramInt + 2), paramCursor.getLong(paramInt + 3), paramCursor.getLong(paramInt + 4));
  }
  
  public void readEntity(Cursor paramCursor, Translation paramTranslation, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramTranslation.setId(long_);
    paramTranslation.setText(paramCursor.getString(paramInt + 1));
    paramTranslation.setType(paramCursor.getInt(paramInt + 2));
    paramTranslation.setTypeId(paramCursor.getLong(paramInt + 3));
    paramTranslation.setLanguageId(paramCursor.getLong(paramInt + 4));
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 堅(Object paramObject) {
    ((Translation)paramObject).__setDaoSession(this.旨);
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    Long long_ = paramObject.getId();
    if (long_ != null)
      paramSQLiteStatement.bindLong(1, long_.longValue()); 
    paramSQLiteStatement.bindString(2, paramObject.getText());
    paramSQLiteStatement.bindLong(3, paramObject.getType());
    paramSQLiteStatement.bindLong(4, paramObject.getTypeId());
    paramSQLiteStatement.bindLong(5, paramObject.getLanguageId());
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Translation)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
    
    public static final ia LanguageId;
    
    public static final ia Text = new ia(1, String.class, "text", false, "TEXT");
    
    public static final ia Type = new ia(2, int.class, "type", false, "TYPE");
    
    public static final ia TypeId;
    
    static {
      Class<long> clazz = long.class;
      TypeId = new ia(3, clazz, "typeId", false, "TYPE_ID");
      LanguageId = new ia(4, clazz, "languageId", false, "LANGUAGE_ID");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\TranslationDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */