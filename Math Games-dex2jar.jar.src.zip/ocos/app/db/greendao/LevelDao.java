package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.util.ArrayList;
import java.util.List;
import y.break;
import y.ia;
import y.mm;
import y.の;
import y.글;

public class LevelDao extends break {
  public static final String TABLENAME = "LEVEL";
  
  public String 不;
  
  public final DaoSession 旨;
  
  public LevelDao(글 param글) {
    super(param글, null);
  }
  
  public LevelDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
    this.旨 = paramDaoSession;
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'LEVEL' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT ,'POINT' INTEGER NOT NULL ,'LABEL' TEXT,'CATEGORY' INTEGER NOT NULL ,'FINISHED' INTEGER,'PREMIUM' INTEGER,'CATEGORY_ID' INTEGER NOT NULL );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'LEVEL'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public Long getKey(Level paramLevel) {
    return (paramLevel != null) ? paramLevel.getId() : null;
  }
  
  public List<Level> loadAllDeepFromCursor(Cursor paramCursor) {
    int i = paramCursor.getCount();
    ArrayList<Level> arrayList = new ArrayList(i);
    if (paramCursor.moveToFirst()) {
      の の = this.熱;
      if (の != null) {
        の.lock();
        の.冷(i);
      } 
      try {
        while (true) {
          arrayList.add(恐(paramCursor, false));
          boolean bool = paramCursor.moveToNext();
          if (!bool) {
            if (の != null)
              return arrayList; 
            break;
          } 
        } 
      } finally {
        if (の != null)
          の.unlock(); 
      } 
    } 
    return arrayList;
  }
  
  public Level loadDeep(Long paramLong) {
    硬();
    if (paramLong == null)
      return null; 
    StringBuilder stringBuilder = new StringBuilder(怖());
    stringBuilder.append("WHERE ");
    mm.堅(stringBuilder, "T", getPkColumns());
    null = stringBuilder.toString();
    String str = paramLong.toString();
    Cursor cursor = this.硬.rawQuery(null, new String[] { str });
    try {
      boolean bool = cursor.moveToFirst();
      if (!bool)
        return null; 
      if (cursor.isLast())
        return 恐(cursor, true); 
      StringBuilder stringBuilder1 = new StringBuilder("Expected unique result, but count was ");
      stringBuilder1.append(cursor.getCount());
      throw new IllegalStateException(stringBuilder1.toString());
    } finally {
      cursor.close();
    } 
  }
  
  public List<Level> queryDeep(String paramString, String... paramVarArgs) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(怖());
    stringBuilder.append(paramString);
    paramString = stringBuilder.toString();
    Cursor cursor = this.硬.rawQuery(paramString, paramVarArgs);
    try {
      return loadAllDeepFromCursor(cursor);
    } finally {
      cursor.close();
    } 
  }
  
  public Level readEntity(Cursor paramCursor, int paramInt) {
    Long long_;
    String str;
    Boolean bool2;
    Boolean bool3;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    long l1 = paramCursor.getLong(paramInt + 1);
    int i = paramInt + 2;
    if (paramCursor.isNull(i)) {
      str = null;
    } else {
      str = paramCursor.getString(i);
    } 
    long l2 = paramCursor.getLong(paramInt + 3);
    i = paramInt + 4;
    boolean bool = paramCursor.isNull(i);
    boolean bool1 = false;
    if (bool) {
      bool2 = null;
    } else {
      if (paramCursor.getShort(i) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      bool2 = Boolean.valueOf(bool);
    } 
    i = paramInt + 5;
    if (paramCursor.isNull(i)) {
      bool3 = null;
    } else {
      bool = bool1;
      if (paramCursor.getShort(i) != 0)
        bool = true; 
      bool3 = Boolean.valueOf(bool);
    } 
    return new Level(long_, l1, str, l2, bool2, bool3, paramCursor.getLong(paramInt + 6));
  }
  
  public void readEntity(Cursor paramCursor, Level paramLevel, int paramInt) {
    Long long_;
    String str;
    Boolean bool2;
    boolean bool = paramCursor.isNull(paramInt);
    Boolean bool3 = null;
    if (bool) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramLevel.setId(long_);
    paramLevel.setPoint(paramCursor.getLong(paramInt + 1));
    int i = paramInt + 2;
    if (paramCursor.isNull(i)) {
      long_ = null;
    } else {
      str = paramCursor.getString(i);
    } 
    paramLevel.setLabel(str);
    paramLevel.setCategory(paramCursor.getLong(paramInt + 3));
    i = paramInt + 4;
    bool = paramCursor.isNull(i);
    boolean bool1 = false;
    if (bool) {
      str = null;
    } else {
      if (paramCursor.getShort(i) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      bool2 = Boolean.valueOf(bool);
    } 
    paramLevel.setFinished(bool2);
    i = paramInt + 5;
    if (paramCursor.isNull(i)) {
      bool2 = bool3;
    } else {
      bool = bool1;
      if (paramCursor.getShort(i) != 0)
        bool = true; 
      bool2 = Boolean.valueOf(bool);
    } 
    paramLevel.setPremium(bool2);
    paramLevel.setCategoryId(paramCursor.getLong(paramInt + 6));
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 堅(Object paramObject) {
    ((Level)paramObject).__setDaoSession(this.旨);
  }
  
  public final String 怖() {
    if (this.不 == null) {
      StringBuilder stringBuilder = new StringBuilder("SELECT ");
      mm.硬(stringBuilder, "T", getAllColumns());
      stringBuilder.append(',');
      mm.硬(stringBuilder, "T0", this.旨.getLevelDao().getAllColumns());
      stringBuilder.append(" FROM LEVEL T");
      stringBuilder.append(" LEFT JOIN LEVEL T0 ON T.'CATEGORY_ID'=T0.'_id'");
      stringBuilder.append(' ');
      this.不 = stringBuilder.toString();
    } 
    return this.不;
  }
  
  public final Level 恐(Cursor paramCursor, boolean paramBoolean) {
    Level level2 = (Level)嬉(paramCursor, 0, paramBoolean);
    int i = (getAllColumns()).length;
    Level level1 = (Level)this.旨.getLevelDao().嬉(paramCursor, i, true);
    if (level1 != null)
      level2.setLevel(level1); 
    return level2;
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    Long long_ = paramObject.getId();
    if (long_ != null)
      paramSQLiteStatement.bindLong(1, long_.longValue()); 
    paramSQLiteStatement.bindLong(2, paramObject.getPoint());
    String str = paramObject.getLabel();
    if (str != null)
      paramSQLiteStatement.bindString(3, str); 
    paramSQLiteStatement.bindLong(4, paramObject.getCategory());
    Boolean bool = paramObject.getFinished();
    long l = 1L;
    if (bool != null) {
      long l1;
      if (bool.booleanValue()) {
        l1 = 1L;
      } else {
        l1 = 0L;
      } 
      paramSQLiteStatement.bindLong(5, l1);
    } 
    bool = paramObject.getPremium();
    if (bool != null) {
      long l1;
      if (bool.booleanValue()) {
        l1 = l;
      } else {
        l1 = 0L;
      } 
      paramSQLiteStatement.bindLong(6, l1);
    } 
    paramSQLiteStatement.bindLong(7, paramObject.getCategoryId());
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Level)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Category;
    
    public static final ia CategoryId;
    
    public static final ia Finished;
    
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
    
    public static final ia Label;
    
    public static final ia Point;
    
    public static final ia Premium;
    
    static {
      Class<long> clazz = long.class;
      Point = new ia(1, clazz, "point", false, "POINT");
      Label = new ia(2, String.class, "label", false, "LABEL");
      Category = new ia(3, clazz, "category", false, "CATEGORY");
      Finished = new ia(4, Boolean.class, "finished", false, "FINISHED");
      Premium = new ia(5, Boolean.class, "premium", false, "PREMIUM");
      CategoryId = new ia(6, clazz, "categoryId", false, "CATEGORY_ID");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\LevelDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */