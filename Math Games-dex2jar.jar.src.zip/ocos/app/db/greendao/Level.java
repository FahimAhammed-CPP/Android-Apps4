package ocos.app.db.greendao;

import y.금;

public class Level {
  public Long ぱ;
  
  public transient LevelDao 不;
  
  public Boolean 冷;
  
  public long 堅;
  
  public Boolean 寒;
  
  public transient DaoSession 旨;
  
  public long 暑;
  
  public String 熱;
  
  public Long 硬;
  
  public long 美;
  
  public Level 辛;
  
  public Level() {}
  
  public Level(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public Level(Long paramLong, long paramLong1, String paramString, long paramLong2, Boolean paramBoolean1, Boolean paramBoolean2, long paramLong3) {
    this.硬 = paramLong;
    this.堅 = paramLong1;
    this.熱 = paramString;
    this.暑 = paramLong2;
    this.冷 = paramBoolean1;
    this.寒 = paramBoolean2;
    this.美 = paramLong3;
  }
  
  public void __setDaoSession(DaoSession paramDaoSession) {
    this.旨 = paramDaoSession;
    if (paramDaoSession != null) {
      LevelDao levelDao = paramDaoSession.getLevelDao();
    } else {
      paramDaoSession = null;
    } 
    this.不 = (LevelDao)paramDaoSession;
  }
  
  public void delete() {
    LevelDao levelDao = this.不;
    if (levelDao != null) {
      levelDao.delete(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public long getCategory() {
    return this.暑;
  }
  
  public long getCategoryId() {
    return this.美;
  }
  
  public Boolean getFinished() {
    return this.冷;
  }
  
  public Long getId() {
    return this.硬;
  }
  
  public String getLabel() {
    return this.熱;
  }
  
  public Level getLevel() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 美 : J
    //   4: lstore_1
    //   5: aload_0
    //   6: getfield ぱ : Ljava/lang/Long;
    //   9: astore_3
    //   10: aload_3
    //   11: ifnull -> 25
    //   14: aload_3
    //   15: lload_1
    //   16: invokestatic valueOf : (J)Ljava/lang/Long;
    //   19: invokevirtual equals : (Ljava/lang/Object;)Z
    //   22: ifne -> 66
    //   25: aload_0
    //   26: getfield 旨 : Locos/app/db/greendao/DaoSession;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnull -> 76
    //   34: aload_3
    //   35: invokevirtual getLevelDao : ()Locos/app/db/greendao/LevelDao;
    //   38: lload_1
    //   39: invokestatic valueOf : (J)Ljava/lang/Long;
    //   42: invokevirtual load : (Ljava/lang/Object;)Ljava/lang/Object;
    //   45: checkcast ocos/app/db/greendao/Level
    //   48: astore_3
    //   49: aload_0
    //   50: monitorenter
    //   51: aload_0
    //   52: aload_3
    //   53: putfield 辛 : Locos/app/db/greendao/Level;
    //   56: aload_0
    //   57: lload_1
    //   58: invokestatic valueOf : (J)Ljava/lang/Long;
    //   61: putfield ぱ : Ljava/lang/Long;
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_0
    //   67: getfield 辛 : Locos/app/db/greendao/Level;
    //   70: areturn
    //   71: astore_3
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    //   76: new y/금
    //   79: dup
    //   80: ldc 'Entity is detached from DAO context'
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   51	66	71	finally
    //   72	74	71	finally
  }
  
  public long getPoint() {
    return this.堅;
  }
  
  public Boolean getPremium() {
    return this.寒;
  }
  
  public void refresh() {
    LevelDao levelDao = this.不;
    if (levelDao != null) {
      levelDao.refresh(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
  
  public void setCategory(long paramLong) {
    this.暑 = paramLong;
  }
  
  public void setCategoryId(long paramLong) {
    this.美 = paramLong;
  }
  
  public void setFinished(Boolean paramBoolean) {
    this.冷 = paramBoolean;
  }
  
  public void setId(Long paramLong) {
    this.硬 = paramLong;
  }
  
  public void setLabel(String paramString) {
    this.熱 = paramString;
  }
  
  public void setLevel(Level paramLevel) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 40
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_1
    //   8: putfield 辛 : Locos/app/db/greendao/Level;
    //   11: aload_1
    //   12: invokevirtual getId : ()Ljava/lang/Long;
    //   15: invokevirtual longValue : ()J
    //   18: lstore_2
    //   19: aload_0
    //   20: lload_2
    //   21: putfield 美 : J
    //   24: aload_0
    //   25: lload_2
    //   26: invokestatic valueOf : (J)Ljava/lang/Long;
    //   29: putfield ぱ : Ljava/lang/Long;
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    //   40: new y/금
    //   43: dup
    //   44: ldc 'To-one property 'categoryId' has not-null constraint; cannot set to-one to null'
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   6	34	35	finally
    //   36	38	35	finally
  }
  
  public void setPoint(long paramLong) {
    this.堅 = paramLong;
  }
  
  public void setPremium(Boolean paramBoolean) {
    this.寒 = paramBoolean;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Level{id=");
    stringBuilder.append(this.硬);
    stringBuilder.append(", point=");
    stringBuilder.append(this.堅);
    stringBuilder.append(", label='");
    stringBuilder.append(this.熱);
    stringBuilder.append("', category=");
    stringBuilder.append(this.暑);
    stringBuilder.append(", finished=");
    stringBuilder.append(this.冷);
    stringBuilder.append(", premium=");
    stringBuilder.append(this.寒);
    stringBuilder.append(", categoryId=");
    stringBuilder.append(this.美);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void update() {
    LevelDao levelDao = this.不;
    if (levelDao != null) {
      levelDao.update(this);
      return;
    } 
    throw new 금("Entity is detached from DAO context");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\Level.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */