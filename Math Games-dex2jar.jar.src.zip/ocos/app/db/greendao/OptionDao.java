package ocos.app.db.greendao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.util.ArrayList;
import java.util.List;
import y.break;
import y.ia;
import y.mm;
import y.の;
import y.글;

public class OptionDao extends break {
  public static final String TABLENAME = "OPTION";
  
  public String 不;
  
  public final DaoSession 旨;
  
  public OptionDao(글 param글) {
    super(param글, null);
  }
  
  public OptionDao(글 param글, DaoSession paramDaoSession) {
    super(param글, paramDaoSession);
    this.旨 = paramDaoSession;
  }
  
  public static void createTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    if (paramBoolean) {
      str = "IF NOT EXISTS ";
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
    stringBuilder.append(str);
    stringBuilder.append("'OPTION' ('_id' INTEGER PRIMARY KEY AUTOINCREMENT ,'ANSWER' INTEGER NOT NULL ,'RESOURCE_PATH' TEXT NOT NULL ,'QUESTION_ID' INTEGER NOT NULL );");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public static void dropTable(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    String str;
    StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
    if (paramBoolean) {
      str = "IF EXISTS ";
    } else {
      str = "";
    } 
    stringBuilder.append(str);
    stringBuilder.append("'OPTION'");
    paramSQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  public Long getKey(Option paramOption) {
    return (paramOption != null) ? paramOption.getId() : null;
  }
  
  public List<Option> loadAllDeepFromCursor(Cursor paramCursor) {
    int i = paramCursor.getCount();
    ArrayList<Option> arrayList = new ArrayList(i);
    if (paramCursor.moveToFirst()) {
      の の = this.熱;
      if (の != null) {
        の.lock();
        の.冷(i);
      } 
      try {
        while (true) {
          arrayList.add(恐(paramCursor, false));
          boolean bool = paramCursor.moveToNext();
          if (!bool) {
            if (の != null)
              return arrayList; 
            break;
          } 
        } 
      } finally {
        if (の != null)
          の.unlock(); 
      } 
    } 
    return arrayList;
  }
  
  public Option loadDeep(Long paramLong) {
    硬();
    if (paramLong == null)
      return null; 
    StringBuilder stringBuilder = new StringBuilder(怖());
    stringBuilder.append("WHERE ");
    mm.堅(stringBuilder, "T", getPkColumns());
    null = stringBuilder.toString();
    String str = paramLong.toString();
    Cursor cursor = this.硬.rawQuery(null, new String[] { str });
    try {
      boolean bool = cursor.moveToFirst();
      if (!bool)
        return null; 
      if (cursor.isLast())
        return 恐(cursor, true); 
      StringBuilder stringBuilder1 = new StringBuilder("Expected unique result, but count was ");
      stringBuilder1.append(cursor.getCount());
      throw new IllegalStateException(stringBuilder1.toString());
    } finally {
      cursor.close();
    } 
  }
  
  public List<Option> queryDeep(String paramString, String... paramVarArgs) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(怖());
    stringBuilder.append(paramString);
    paramString = stringBuilder.toString();
    Cursor cursor = this.硬.rawQuery(paramString, paramVarArgs);
    try {
      return loadAllDeepFromCursor(cursor);
    } finally {
      cursor.close();
    } 
  }
  
  public Option readEntity(Cursor paramCursor, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    return new Option(long_, paramCursor.getLong(paramInt + 1), paramCursor.getString(paramInt + 2), paramCursor.getLong(paramInt + 3));
  }
  
  public void readEntity(Cursor paramCursor, Option paramOption, int paramInt) {
    Long long_;
    if (paramCursor.isNull(paramInt)) {
      long_ = null;
    } else {
      long_ = Long.valueOf(paramCursor.getLong(paramInt));
    } 
    paramOption.setId(long_);
    paramOption.setAnswer(paramCursor.getLong(paramInt + 1));
    paramOption.setResourcePath(paramCursor.getString(paramInt + 2));
    paramOption.setQuestionId(paramCursor.getLong(paramInt + 3));
  }
  
  public Long readKey(Cursor paramCursor, int paramInt) {
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public final void 堅(Object paramObject) {
    ((Option)paramObject).__setDaoSession(this.旨);
  }
  
  public final String 怖() {
    if (this.不 == null) {
      StringBuilder stringBuilder = new StringBuilder("SELECT ");
      mm.硬(stringBuilder, "T", getAllColumns());
      stringBuilder.append(',');
      mm.硬(stringBuilder, "T0", this.旨.getOptionDao().getAllColumns());
      stringBuilder.append(" FROM OPTION T");
      stringBuilder.append(" LEFT JOIN OPTION T0 ON T.'QUESTION_ID'=T0.'_id'");
      stringBuilder.append(' ');
      this.不 = stringBuilder.toString();
    } 
    return this.不;
  }
  
  public final Option 恐(Cursor paramCursor, boolean paramBoolean) {
    Option option2 = (Option)嬉(paramCursor, 0, paramBoolean);
    int i = (getAllColumns()).length;
    Option option1 = (Option)this.旨.getOptionDao().嬉(paramCursor, i, true);
    if (option1 != null)
      option2.setOption(option1); 
    return option2;
  }
  
  public final void 暑(SQLiteStatement paramSQLiteStatement, Object paramObject) {
    paramObject = paramObject;
    paramSQLiteStatement.clearBindings();
    Long long_ = paramObject.getId();
    if (long_ != null)
      paramSQLiteStatement.bindLong(1, long_.longValue()); 
    paramSQLiteStatement.bindLong(2, paramObject.getAnswer());
    paramSQLiteStatement.bindString(3, paramObject.getResourcePath());
    paramSQLiteStatement.bindLong(4, paramObject.getQuestionId());
  }
  
  public final Long 淋(long paramLong, Object paramObject) {
    ((Option)paramObject).setId(Long.valueOf(paramLong));
    return Long.valueOf(paramLong);
  }
  
  public final void 辛() {}
  
  public static class Properties {
    public static final ia Answer;
    
    public static final ia Id = new ia(0, Long.class, "id", true, "_id");
    
    public static final ia QuestionId;
    
    public static final ia ResourcePath = new ia(2, String.class, "resourcePath", false, "RESOURCE_PATH");
    
    static {
      QuestionId = new ia(3, clazz, "questionId", false, "QUESTION_ID");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\app\db\greendao\OptionDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */