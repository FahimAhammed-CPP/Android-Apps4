package ocos.quizmath.ui;

import android.content.ServiceConnection;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicReference;
import y.b;
import y.bm;
import y.c;
import y.d;
import y.ee0;
import y.es;
import y.fb;
import y.hp;
import y.ik;
import y.jf;
import y.lf;
import y.mp;
import y.nf;
import y.nj;
import y.of;
import y.pj;
import y.rt;
import y.tc;
import y.tl;
import y.ts;
import y.xi0;
import y.yw0;
import y.zk0;
import y.ず;
import y.デ;
import y.古;
import y.密;
import y.年;
import y.男;
import y.重;
import y.銅;
import y.鏡;
import y.閉;
import y.규;
import y.꽃;
import y.롱;
import y.용;
import y.유;
import y.풍;
import y.프;
import y.피;
import y.혐;

public class MainActivity extends ず implements 프 {
  public 규 탐;
  
  public final hp 탑 = new hp((용)new c(this, 0));
  
  public final List 탕 = ik.わ((Object[])new Long[] { Long.valueOf(1L), Long.valueOf(2L), Long.valueOf(3L), Long.valueOf(4L), Long.valueOf(5L), Long.valueOf(6L), Long.valueOf(7L) });
  
  public final 男 태 = new 男(18);
  
  public 규 택;
  
  public final void onCreate(Bundle paramBundle) {
    ImageView imageView;
    super.onCreate(paramBundle);
    View view = getLayoutInflater().inflate(2131427367, null, false);
    int i = 2131230953;
    LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131230953);
    if (linearLayout != null) {
      i = 2131231131;
      LinearLayout linearLayout1 = (LinearLayout)꽃.産(view, 2131231131);
      if (linearLayout1 != null) {
        ConstraintLayout constraintLayout = (ConstraintLayout)view;
        i = 2131231376;
        View view1 = 꽃.産(view, 2131231376);
        if (view1 != null) {
          i = 2131230904;
          imageView = (ImageView)꽃.産(view1, 2131230904);
          if (imageView != null) {
            i = 2131230918;
            ImageView imageView1 = (ImageView)꽃.産(view1, 2131230918);
            if (imageView1 != null) {
              i = 2131230930;
              ImageView imageView2 = (ImageView)꽃.産(view1, 2131230930);
              if (imageView2 != null) {
                i = 2131230936;
                ImageView imageView3 = (ImageView)꽃.産(view1, 2131230936);
                if (imageView3 != null) {
                  i = 2131231377;
                  TextView textView = (TextView)꽃.産(view1, 2131231377);
                  if (textView != null) {
                    this.탐 = new 규(constraintLayout, linearLayout, (View)linearLayout1, constraintLayout, new tc(view1, imageView, imageView1, imageView2, imageView3, textView, 5), 4);
                    setContentView(2131427366);
                    年.も((용)new c(this, 1));
                    return;
                  } 
                } 
              } 
            } 
          } 
          throw new NullPointerException("Missing required view with ID: ".concat(view1.getResources().getResourceName(i)));
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(imageView.getResources().getResourceName(i)));
  }
  
  public final void onDestroy() {
    古 古 = 泳();
    古.getClass();
    int i = nf.硬;
    AtomicReference<Boolean> atomicReference2 = 古.不;
    Boolean bool2 = Boolean.FALSE;
    atomicReference2.set(bool2);
    古.辛.set(bool2);
    lf lf = tl.怖;
    es es = 古.暑;
    Toast toast = es.堅;
    if (toast != null)
      toast.cancel(); 
    es.堅 = null;
    혐 혐 = 古.ぱ;
    if (혐 != null) {
      重 重 = 혐.暑;
      if (重 != null && 重.硬() == true) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        重 重1 = 혐.暑;
        try {
          重1.暑.怖();
          if (重1.美 != null) {
            null = 重1.美;
            synchronized (null.硬) {
              null.熱 = null;
              null.堅 = true;
            } 
          } 
          if (重1.美 != null && 重1.寒 != null) {
            zk0.冷("BillingClient", "Unbinding from service.");
            重1.冷.unbindService((ServiceConnection)重1.美);
            重1.美 = null;
          } 
          重1.寒 = null;
          ExecutorService executorService = 重1.痛;
          if (executorService != null) {
            executorService.shutdownNow();
            重1.痛 = null;
          } 
        } catch (Exception exception) {
          i = zk0.硬;
        } finally {
          重1.硬 = 3;
        } 
      } 
    } 
    古.ぱ = null;
    古.嬉 = null;
    古.苦 = null;
    AtomicReference<Boolean> atomicReference1 = 古.美;
    Boolean bool1 = Boolean.FALSE;
    atomicReference1.set(bool1);
    古.寒.set(bool1);
    古.旨.set(bool1);
    古.不.set(bool1);
    古.辛.set(bool1);
    ((피)触()).暑();
    super.onDestroy();
  }
  
  public final void onResume() {
    super.onResume();
    this.태.起();
  }
  
  public final 銅 ぱ() {
    return (銅)this;
  }
  
  public final void 冷() {
    int i = nf.硬;
    ik.토((View)(噛()).痛, false);
  }
  
  public final 규 噛() {
    규 규1 = this.탐;
    return (규1 != null) ? 규1 : null;
  }
  
  public final 유 嬉() {
    return (유)new d(0, this);
  }
  
  public final void 恐() {
    ((피)触()).getClass();
    int i = nf.硬;
  }
  
  public final void 熱() {
    ((피)触()).getClass();
    int i = nf.硬;
  }
  
  public final boolean 痛() {
    return 泳().暑();
  }
  
  public final of 美() {
    return (of)踊().硬().硬();
  }
  
  public final void 苦() {
    int i = nf.硬;
    boolean bool = 痛();
    ik.토((View)(噛()).痛, bool ^ true);
    ts ts = デ.痛;
    if (ts != null) {
      鏡 鏡 = 鏡.硬;
      String str = 鏡.旨;
      rt rt = new rt(jf.硬(閉.class));
      nj nj2 = (nj)((pj)ts.硬).熱.get(str);
      nj nj1 = nj2;
      if (nj2 == null) {
        pj pj = (pj)ts.硬;
        ts ts1 = pj.硬;
        yw0 yw0 = (yw0)ts1.暑;
        rt.toString();
        yw0.寒(1);
        HashSet<rt> hashSet = pj.堅;
        if (!hashSet.contains(rt)) {
          yw0 yw01 = (yw0)ts1.暑;
          rt.toString();
          yw01.寒(3);
          hashSet.add(rt);
        } 
        ConcurrentHashMap<String, nj> concurrentHashMap = pj.熱;
        if (!concurrentHashMap.containsKey(str)) {
          nj1 = new nj((fb)rt, str, false, ts1);
          nj nj = pj.暑;
          nj1.冷.addAll(Arrays.asList(new nj[] { nj }));
          concurrentHashMap.put(str, nj1);
        } else {
          throw new xi0(bm.痛("Scope with id '", str, "' is already created"), 6);
        } 
      } 
      if ((閉)nj1.堅(null, jf.硬(閉.class), null) == null) {
        long l = 美().堅(鏡.큰.堅);
        mp mp = (mp)((密)this).ゃ.getValue();
        롱.堅(l);
        synchronized (new b(nj1, new 閉(mp, l))) {
          null.旨();
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{y/nj}, name=null} */
          return;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("KoinApplication has not been started".toString());
  }
  
  public final 풍 触() {
    return (풍)this.탑.getValue();
  }
  
  public final void 辛() {
    ((피)触()).旨(this);
    ((피)触()).不();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */