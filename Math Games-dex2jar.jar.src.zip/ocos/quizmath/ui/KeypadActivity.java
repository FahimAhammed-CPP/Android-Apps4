package ocos.quizmath.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.for;
import java.util.ArrayList;
import y.hx;
import y.ik;
import y.il0;
import y.nf;
import y.ou;
import y.pu;
import y.pw1;
import y.s4;
import y.tc;
import y.ts;
import y.va1;
import y.エ;
import y.ジ;
import y.密;
import y.殻;
import y.西;
import y.鏡;
import y.겸;
import y.꽃;
import y.본;
import y.싶;
import y.용;
import y.잡;

public final class KeypadActivity extends 겸 {
  public final pw1 く = new pw1(5);
  
  public final 본 ぼ;
  
  public final String れ;
  
  public s4 俺;
  
  public final 본 僕;
  
  public KeypadActivity() {
    ou ou = ou.硬;
    this.ぼ = new 본(ou, ou.熱);
    this.僕 = new 본(ou, ou.堅);
    this.れ = "";
  }
  
  public final int か() {
    return 2131165366;
  }
  
  public final void ゃ() {
    ts ts1;
    s4 s42 = this.俺;
    va1 va12 = null;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    ((ConstraintLayout)((tc)s41.ぱ).痒).setBackgroundResource(2131165477);
    s42 = this.俺;
    s41 = s42;
    if (s42 == null)
      s41 = null; 
    va1 va11 = (va1)s41.暑;
    ik.臭((View)va11.堅, (용)new ジ(this, 3));
    ImageButton imageButton = (ImageButton)va11.寂;
    imageButton.setOnClickListener((View.OnClickListener)new hx(4, this));
    imageButton.setOnLongClickListener((View.OnLongClickListener)new エ((密)this, 2));
    ik.臭((View)va11.熱, (용)new ジ(this, 4));
    ik.臭((View)va11.暑, (용)new ジ(this, 5));
    ik.臭((View)va11.冷, (용)new ジ(this, 6));
    ik.臭((View)va11.寒, (용)new ジ(this, 7));
    ik.臭((View)va11.美, (용)new ジ(this, 8));
    ik.臭((View)va11.旨, (용)new ジ(this, 9));
    ik.臭((View)va11.不, (용)new ジ(this, 10));
    ik.臭((View)va11.辛, (용)new ジ(this, 0));
    ik.臭((View)va11.ぱ, (용)new ジ(this, 1));
    ik.臭((View)va11.苦, (용)new ジ(this, 2));
    ts ts2 = this.し;
    va11 = va12;
    if (ts2 != null)
      ts1 = ts2; 
    ((for)ts1.熱).寒(Boolean.TRUE);
  }
  
  public final void わ() {
    ConstraintLayout constraintLayout;
    View view = getLayoutInflater().inflate(2131427360, null, false);
    int i = 2131230952;
    LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131230952);
    if (linearLayout != null) {
      i = 2131230954;
      View view1 = 꽃.産(view, 2131230954);
      if (view1 != null) {
        va1 va1 = va1.硬(view1);
        i = 2131231113;
        View view2 = 꽃.産(view, 2131231113);
        if (view2 != null) {
          ConstraintLayout constraintLayout1;
          i = 2131230836;
          ImageButton imageButton = (ImageButton)꽃.産(view2, 2131230836);
          if (imageButton != null) {
            i = 2131230919;
            ImageButton imageButton1 = (ImageButton)꽃.産(view2, 2131230919);
            if (imageButton1 != null) {
              i = 2131230920;
              Button button = (Button)꽃.産(view2, 2131230920);
              if (button != null) {
                i = 2131230921;
                Button button1 = (Button)꽃.産(view2, 2131230921);
                if (button1 != null) {
                  i = 2131230922;
                  Button button2 = (Button)꽃.産(view2, 2131230922);
                  if (button2 != null) {
                    i = 2131230923;
                    Button button3 = (Button)꽃.産(view2, 2131230923);
                    if (button3 != null) {
                      i = 2131230924;
                      Button button4 = (Button)꽃.産(view2, 2131230924);
                      if (button4 != null) {
                        i = 2131230925;
                        Button button5 = (Button)꽃.産(view2, 2131230925);
                        if (button5 != null) {
                          i = 2131230926;
                          Button button6 = (Button)꽃.産(view2, 2131230926);
                          if (button6 != null) {
                            i = 2131230927;
                            Button button7 = (Button)꽃.産(view2, 2131230927);
                            if (button7 != null) {
                              i = 2131230928;
                              Button button8 = (Button)꽃.産(view2, 2131230928);
                              if (button8 != null) {
                                i = 2131230929;
                                Button button9 = (Button)꽃.産(view2, 2131230929);
                                if (button9 != null) {
                                  constraintLayout1 = (ConstraintLayout)view2;
                                  va1 va11 = new va1((ViewGroup)constraintLayout1, (View)imageButton, (View)imageButton1, (View)button, (View)button1, (View)button2, (View)button3, (View)button4, (View)button5, (View)button6, (View)button7, button8, button9, (View)constraintLayout1, 5);
                                  EditText editText = (EditText)꽃.産(view, 2131231114);
                                  if (editText != null) {
                                    TextView textView = (TextView)꽃.産(view, 2131231115);
                                    if (textView != null) {
                                      LinearLayout linearLayout1 = (LinearLayout)꽃.産(view, 2131231129);
                                      if (linearLayout1 != null) {
                                        TextView textView1 = (TextView)꽃.産(view, 2131231242);
                                        if (textView1 != null) {
                                          TextView textView2 = (TextView)꽃.産(view, 2131231244);
                                          if (textView2 != null) {
                                            ConstraintLayout constraintLayout2 = (ConstraintLayout)view;
                                            View view3 = 꽃.産(view, 2131231376);
                                            if (view3 != null) {
                                              s4 s41 = new s4((ViewGroup)constraintLayout2, (View)linearLayout, va1, va11, (View)editText, textView, (View)linearLayout1, (View)textView1, (View)textView2, (ViewGroup)constraintLayout2, tc.堅(view3), 6);
                                              this.俺 = s41;
                                              switch (6) {
                                                case 5:
                                                  constraintLayout = (ConstraintLayout)s41.硬;
                                                  setContentView((View)constraintLayout);
                                                  return;
                                              } 
                                              constraintLayout = (ConstraintLayout)((s4)constraintLayout).硬;
                                            } else {
                                              i = 2131231376;
                                              throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                            } 
                                          } else {
                                            i = 2131231244;
                                            throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                          } 
                                        } else {
                                          i = 2131231242;
                                          throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                        } 
                                      } else {
                                        i = 2131231129;
                                        throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                      } 
                                    } else {
                                      i = 2131231115;
                                      throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                    } 
                                  } else {
                                    i = 2131231114;
                                    throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                                  } 
                                } else {
                                  throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                                } 
                              } else {
                                throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                              } 
                            } else {
                              throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                            } 
                          } else {
                            throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                          } 
                        } else {
                          throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                        } 
                      } else {
                        throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                      } 
                    } else {
                      throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                    } 
                  } else {
                    throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                  } 
                } else {
                  throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
                } 
              } else {
                throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
              } 
            } else {
              throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
            } 
          } else {
            throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout1.getResources().getResourceName(i)));
          } 
        } else {
          throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
        } 
      } else {
        throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
      } 
    } else {
      throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
    } 
    setContentView((View)constraintLayout);
  }
  
  public final int 投() {
    return 殻.堅((Context)this, 2131034284);
  }
  
  public final void 淋() {
    long l1;
    boolean bool;
    int i = nf.硬;
    pw1 pw11 = this.く;
    pw11.getClass();
    try {
      l1 = Long.parseLong(pw11.暑);
    } catch (NumberFormatException numberFormatException) {
      l1 = pw11.熱;
    } 
    i = nf.硬;
    long l2 = (あ()).堅.旨;
    잡 잡 = (あ()).堅;
    잡.getClass();
    if (잡.旨 == l1) {
      bool = true;
    } else {
      bool = false;
    } 
    코(bool, l2, this.僕);
  }
  
  public final void 若(ArrayList paramArrayList) {
    int i = 殻.堅((Context)this, 2131034298);
    s4 s44 = this.俺;
    s4 s43 = null;
    s4 s42 = s44;
    if (s44 == null)
      s42 = null; 
    EditText editText = (EditText)s42.冷;
    String str = this.れ;
    editText.setText(str);
    s44 = this.俺;
    s4 s41 = s44;
    if (s44 == null)
      s41 = null; 
    ((EditText)s41.冷).setTextColor(i);
    s41 = this.俺;
    if (s41 == null)
      s41 = s43; 
    ((TextView)s41.寒).setText(str);
  }
  
  public final 西 触() {
    鏡.硬.getClass();
    return 鏡.怖;
  }
  
  public final void 코(boolean paramBoolean, long paramLong, 본 param본) {
    pu pu = (pu)param본.不(paramBoolean);
    boolean bool = ik.熱(pu, ou.熱);
    s4 s42 = null;
    if (bool) {
      i = 2131034287;
    } else if (ik.熱(pu, ou.堅)) {
      i = 2131034286;
    } else if (ik.熱(pu, ou.硬)) {
      i = 2131034285;
    } else {
      throw new 싶(null);
    } 
    int i = 殻.堅((Context)this, i);
    s4 s43 = this.俺;
    s4 s41 = s43;
    if (s43 == null)
      s41 = null; 
    ((EditText)s41.冷).setText(String.valueOf(paramLong));
    s41 = this.俺;
    if (s41 == null)
      s41 = s42; 
    ((EditText)s41.冷).setTextColor(i);
    pw1 pw11 = this.く;
    pw11.getClass();
    i = nf.硬;
    pw11.暑 = pw11.堅;
    ((密)this).크.怖();
    あ().美(paramBoolean, pu);
  }
  
  public final void 쾌(il0 paramil0) {
    if (((密)this).크.淋().booleanValue())
      return; 
    pw1 pw11 = this.く;
    pw11.硬(paramil0);
    String str = pw11.暑;
    int i = nf.硬;
    s4 s42 = this.俺;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    ((EditText)s41.冷).setText(str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\KeypadActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */