package ocos.quizmath.ui;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.for;
import java.util.ArrayList;
import java.util.List;
import y.ik;
import y.tc;
import y.ts;
import y.va1;
import y.vk;
import y.向;
import y.密;
import y.寒;
import y.師;
import y.殻;
import y.西;
import y.鏡;
import y.겸;
import y.꽃;

public final class GameActivity extends 겸 {
  public 向 く;
  
  public vk ぼ;
  
  public final int か() {
    return 2131165365;
  }
  
  public final void ゃ() {
    ts ts1;
    vk vk2 = this.ぼ;
    List list2 = null;
    vk vk1 = vk2;
    if (vk2 == null)
      vk1 = null; 
    ((ConstraintLayout)((tc)vk1.苦).痒).setBackgroundResource(2131165478);
    師 師 = 鏡.死;
    vk2 = this.ぼ;
    vk1 = vk2;
    if (vk2 == null)
      vk1 = null; 
    List list1 = ik.わ((Object[])new TextView[] { (TextView)vk1.堅, (TextView)vk1.熱, (TextView)vk1.暑, (TextView)vk1.冷 });
    寒 寒 = new 寒(1, this);
    this.く = new 向(((密)this).크, 師, list1, 寒);
    ts ts2 = this.し;
    list1 = list2;
    if (ts2 != null)
      ts1 = ts2; 
    ((for)ts1.熱).寒(Boolean.TRUE);
  }
  
  public final void わ() {
    vk vk1;
    View view = getLayoutInflater().inflate(2131427361, null, false);
    int i = 2131230886;
    TextView textView = (TextView)꽃.産(view, 2131230886);
    if (textView != null) {
      i = 2131230887;
      TextView textView1 = (TextView)꽃.産(view, 2131230887);
      if (textView1 != null) {
        i = 2131230888;
        TextView textView2 = (TextView)꽃.産(view, 2131230888);
        if (textView2 != null) {
          i = 2131230889;
          TextView textView3 = (TextView)꽃.産(view, 2131230889);
          if (textView3 != null) {
            i = 2131230952;
            LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131230952);
            if (linearLayout != null) {
              i = 2131230954;
              View view1 = 꽃.産(view, 2131230954);
              if (view1 != null) {
                va1 va1 = va1.硬(view1);
                i = 2131231129;
                LinearLayout linearLayout1 = (LinearLayout)꽃.産(view, 2131231129);
                if (linearLayout1 != null) {
                  i = 2131231242;
                  TextView textView4 = (TextView)꽃.産(view, 2131231242);
                  if (textView4 != null) {
                    i = 2131231244;
                    TextView textView5 = (TextView)꽃.産(view, 2131231244);
                    if (textView5 != null) {
                      ConstraintLayout constraintLayout = (ConstraintLayout)view;
                      i = 2131231376;
                      View view2 = 꽃.産(view, 2131231376);
                      if (view2 != null) {
                        vk1 = new vk(constraintLayout, textView, textView1, textView2, textView3, linearLayout, va1, linearLayout1, textView4, textView5, constraintLayout, tc.堅(view2));
                        this.ぼ = vk1;
                        setContentView((View)vk1.硬);
                        return;
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(vk1.getResources().getResourceName(i)));
  }
  
  public final int 投() {
    return 殻.堅((Context)this, 2131034782);
  }
  
  public final void 若(ArrayList paramArrayList) {
    向 向2 = this.く;
    向 向1 = 向2;
    if (向2 == null)
      向1 = null; 
    向1.硬(paramArrayList, (あ()).堅.旨);
  }
  
  public final 西 触() {
    鏡.硬.getClass();
    return 鏡.淋;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\GameActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */