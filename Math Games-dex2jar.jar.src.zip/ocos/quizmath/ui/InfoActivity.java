package ocos.quizmath.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Group;
import y.hp;
import y.ik;
import y.ks;
import y.nf;
import y.of;
import y.va1;
import y.yi;
import y.ず;
import y.者;
import y.蜜;
import y.銅;
import y.꽃;
import y.용;
import y.유;
import y.프;
import y.피;

public final class InfoActivity extends ず implements 프 {
  public va1 탐;
  
  public final hp 탑 = new hp((용)new 蜜(1, this));
  
  public final void onCreate(Bundle paramBundle) {
    va1 va11;
    super.onCreate(paramBundle);
    LayoutInflater layoutInflater = getLayoutInflater();
    va1 va12 = null;
    View view = layoutInflater.inflate(2131427363, null, false);
    int i = 2131230900;
    ImageView imageView = (ImageView)꽃.産(view, 2131230900);
    if (imageView != null) {
      i = 2131230901;
      TextView textView = (TextView)꽃.産(view, 2131230901);
      if (textView != null) {
        i = 2131230910;
        TextView textView1 = (TextView)꽃.産(view, 2131230910);
        if (textView1 != null) {
          i = 2131230911;
          ImageView imageView1 = (ImageView)꽃.産(view, 2131230911);
          if (imageView1 != null) {
            i = 2131230917;
            ImageView imageView2 = (ImageView)꽃.産(view, 2131230917);
            if (imageView2 != null) {
              i = 2131230934;
              TextView textView2 = (TextView)꽃.産(view, 2131230934);
              if (textView2 != null) {
                i = 2131230935;
                ImageView imageView3 = (ImageView)꽃.産(view, 2131230935);
                if (imageView3 != null) {
                  i = 2131230937;
                  TextView textView3 = (TextView)꽃.産(view, 2131230937);
                  if (textView3 != null) {
                    i = 2131230938;
                    ImageView imageView4 = (ImageView)꽃.産(view, 2131230938);
                    if (imageView4 != null) {
                      i = 2131231086;
                      Group group = (Group)꽃.産(view, 2131231086);
                      if (group != null) {
                        ConstraintLayout constraintLayout = (ConstraintLayout)view;
                        View view1 = 꽃.産(view, 2131231376);
                        if (view1 != null) {
                          ks ks = ks.硬(view1);
                          TextView textView4 = (TextView)꽃.産(view, 2131231393);
                          if (textView4 != null) {
                            this.탐 = new va1((ViewGroup)constraintLayout, (View)imageView, (View)textView, (View)textView1, (View)imageView1, (View)imageView2, (View)textView2, (View)imageView3, (View)textView3, (View)imageView4, (View)group, constraintLayout, ks, (View)textView4, 2);
                            switch (2) {
                            
                            } 
                            setContentView((View)constraintLayout);
                            寝(返(Integer.valueOf(2131689567), new Object[0]));
                            va1 va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((TextView)va11.熱).setText(返(Integer.valueOf(2131689696), new Object[0]));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((ImageView)va11.暑).setOnClickListener((View.OnClickListener)new 者(this, 2));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((TextView)va11.旨).setText(返(Integer.valueOf(2131689691), new Object[0]));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((ImageView)va11.不).setOnClickListener((View.OnClickListener)new 者(this, 3));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((TextView)va11.寒).setText(返(Integer.valueOf(2131689676), new Object[0]));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((ImageView)va11.美).setOnClickListener((View.OnClickListener)new 者(this, 4));
                            va13 = this.탐;
                            va11 = va13;
                            if (va13 == null)
                              va11 = null; 
                            ((ImageView)va11.冷).setOnClickListener((View.OnClickListener)new 者(this, 5));
                            va11 = this.탐;
                            if (va11 == null)
                              va11 = va12; 
                            ((ks)va11.苦).硬.setOnClickListener((View.OnClickListener)new 者(this, 1));
                            return;
                          } 
                          i = 2131231393;
                        } else {
                          i = 2131231376;
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(va11.getResources().getResourceName(i)));
  }
  
  public final void onDestroy() {
    ((피)this.탑.getValue()).暑();
    super.onDestroy();
  }
  
  public final 銅 ぱ() {
    return (銅)this;
  }
  
  public final void 冷() {
    噛();
  }
  
  public final void 噛() {
    String str;
    va1 va13 = this.탐;
    va1 va12 = null;
    va1 va11 = va13;
    if (va13 == null)
      va11 = null; 
    ik.토((View)va11.辛, 痛() ^ true);
    boolean bool = 痛();
    va11 = this.탐;
    if (va11 == null)
      va11 = va12; 
    TextView textView = (TextView)va11.嬉;
    if (bool) {
      str = 返(Integer.valueOf(2131689679), new Object[0]);
    } else {
      str = 返(Integer.valueOf(2131689677), new Object[0]);
    } 
    textView.setText(str);
  }
  
  public final 유 嬉() {
    return (유)yi.興;
  }
  
  public final boolean 痛() {
    return 泳().暑();
  }
  
  public final of 美() {
    return (of)踊().硬().硬();
  }
  
  public final void 苦() {
    int i = nf.硬;
    va1 va11 = this.탐;
    if (va11 == null) {
      va12 = null;
    } else {
      va12 = va11;
    } 
    ImageView imageView = (ImageView)va12.堅;
    va1 va12 = va11;
    if (va11 == null)
      va12 = null; 
    TextView textView = (TextView)va12.寂;
    textView.setText(返(Integer.valueOf(2131689708), new Object[0]));
    if (((피)this.탑.getValue()).冷()) {
      textView.setVisibility(0);
      imageView.setVisibility(0);
      imageView.setOnClickListener((View.OnClickListener)new 者(this, 0));
    } else {
      textView.setVisibility(4);
      imageView.setVisibility(4);
    } 
    噛();
  }
  
  public final void 辛() {
    hp hp1 = this.탑;
    ((피)hp1.getValue()).旨(this);
    ((피)hp1.getValue()).不();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\InfoActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */