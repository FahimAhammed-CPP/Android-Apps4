package ocos.quizmath.ui;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import y.dm;
import y.il0;
import y.j7;
import y.r32;
import y.rk;
import y.tc;
import y.ty;
import y.ub;
import y.va1;
import y.vl;
import y.wl;
import y.xl;
import y.y9;
import y.yl;
import y.z1;
import y.ご;
import y.ず;
import y.密;
import y.目;
import y.護;
import y.赤;
import y.鏡;
import y.雷;
import y.鬚;
import y.꽃;
import y.본;

public final class SettingsActivity extends ず implements j7 {
  public va1 탐;
  
  public final void onCreate(Bundle paramBundle) {
    va1 va11;
    super.onCreate(paramBundle);
    View view = getLayoutInflater().inflate(2131427382, null, false);
    int i = 2131230894;
    ImageView imageView = (ImageView)꽃.産(view, 2131230894);
    if (imageView != null) {
      i = 2131230895;
      TextView textView = (TextView)꽃.産(view, 2131230895);
      if (textView != null) {
        i = 2131230896;
        ImageView imageView1 = (ImageView)꽃.産(view, 2131230896);
        if (imageView1 != null) {
          i = 2131230897;
          TextView textView1 = (TextView)꽃.産(view, 2131230897);
          if (textView1 != null) {
            i = 2131230944;
            ImageView imageView2 = (ImageView)꽃.産(view, 2131230944);
            if (imageView2 != null) {
              i = 2131230945;
              TextView textView2 = (TextView)꽃.産(view, 2131230945);
              if (textView2 != null) {
                ConstraintLayout constraintLayout = (ConstraintLayout)view;
                SeekBar seekBar = (SeekBar)꽃.産(view, 2131231368);
                if (seekBar != null) {
                  TextView textView3 = (TextView)꽃.産(view, 2131231369);
                  if (textView3 != null) {
                    ImageView imageView3 = (ImageView)꽃.産(view, 2131231371);
                    if (imageView3 != null) {
                      View view1 = 꽃.産(view, 2131231376);
                      if (view1 != null) {
                        SeekBar seekBar1;
                        i = 2131230890;
                        ImageView imageView4 = (ImageView)꽃.産(view1, 2131230890);
                        if (imageView4 != null) {
                          i = 2131230918;
                          ImageView imageView5 = (ImageView)꽃.産(view1, 2131230918);
                          if (imageView5 != null) {
                            i = 2131231377;
                            if ((TextView)꽃.産(view1, 2131231377) != null) {
                              ConstraintLayout constraintLayout1 = (ConstraintLayout)view1;
                              z1 z1 = new z1(imageView4, imageView5);
                              imageView5 = (ImageView)꽃.産(view, 2131231412);
                              if (imageView5 != null) {
                                seekBar1 = (SeekBar)꽃.産(view, 2131231413);
                                if (seekBar1 != null) {
                                  this.탐 = new va1((ViewGroup)constraintLayout, (View)imageView, (View)textView, (View)imageView1, (View)textView1, (View)imageView2, (View)textView2, (View)constraintLayout, (View)seekBar, (View)textView3, (View)imageView3, z1, imageView5, (View)seekBar1, 3);
                                  switch (3) {
                                  
                                  } 
                                  setContentView((View)constraintLayout);
                                  va1 va18 = this.탐;
                                  va1 va14 = va18;
                                  if (va18 == null)
                                    va14 = null; 
                                  ((z1)va14.ぱ).硬.setOnClickListener((View.OnClickListener)new rk(this, 0));
                                  va18 = this.탐;
                                  va14 = va18;
                                  if (va18 == null)
                                    va14 = null; 
                                  ((z1)va14.ぱ).堅.setOnClickListener((View.OnClickListener)new rk(this, 1));
                                  寝(返(Integer.valueOf(2131689690), new Object[0]));
                                  va18 = this.탐;
                                  va14 = va18;
                                  if (va18 == null)
                                    va14 = null; 
                                  vl vl3 = new vl((SeekBar)va14.嬉, 鏡.泳);
                                  va18 = this.탐;
                                  va14 = va18;
                                  if (va18 == null)
                                    va14 = null; 
                                  vl vl2 = new vl(vl3, new yl[] { (yl)new vl((ImageView)va14.苦, 鏡.寝) });
                                  y9 y92 = 鏡.噛;
                                  vl3.熱 = new xl(vl2, (wl)new ty(帰(), y92, 鏡.踊, (dm)((密)this).코.getValue()));
                                  i = ((雷)帰()).堅(y92);
                                  赤.硬(i);
                                  vl2.硬(i);
                                  va1 va17 = this.탐;
                                  va1 va13 = va17;
                                  if (va17 == null)
                                    va13 = null; 
                                  SeekBar seekBar2 = (SeekBar)va13.旨;
                                  r32 r32 = 鏡.帰;
                                  vl3 = new vl(seekBar2, r32);
                                  ArrayList<String> arrayList = new ArrayList();
                                  護 護 = (護)r32.恐;
                                  int j = ((ご)護).淋;
                                  int k = ((ご)護).怖;
                                  if (j <= k)
                                    while (true) {
                                      int m = j + 1;
                                      long l = m * 30000L;
                                      if (l > -1L) {
                                        i = 1;
                                      } else {
                                        i = 0;
                                      } 
                                      if (i != 0) {
                                        String str;
                                        if (l == 0L) {
                                          str = "0";
                                        } else {
                                          StringBuilder stringBuilder = new StringBuilder();
                                          il0.暑(il0.暑(il0.暑(il0.暑(il0.暑(il0.暑(il0.暑(il0.暑(l, 31104000000L, "y", stringBuilder), 2592000000L, "M", stringBuilder), 604800000L, "w", stringBuilder), 86400000L, "d", stringBuilder), 3600000L, "h", stringBuilder), 60000L, "m", stringBuilder), 1000L, "s", stringBuilder), 1L, "ms", stringBuilder);
                                          str = stringBuilder.toString();
                                          int n = str.length() - 1;
                                          i = 0;
                                          boolean bool = false;
                                          while (i <= n) {
                                            if (!bool) {
                                              i1 = i;
                                            } else {
                                              i1 = n;
                                            } 
                                            int i1 = str.charAt(i1);
                                            if (i1 < 32) {
                                              i1 = -1;
                                            } else if (i1 == 32) {
                                              i1 = 0;
                                            } else {
                                              i1 = 1;
                                            } 
                                            if (i1 <= 0) {
                                              i1 = 1;
                                            } else {
                                              i1 = 0;
                                            } 
                                            if (!bool) {
                                              if (i1 == 0) {
                                                bool = true;
                                                continue;
                                              } 
                                              i++;
                                              continue;
                                            } 
                                            if (i1 == 0)
                                              break; 
                                            n--;
                                          } 
                                          str = str.subSequence(i, n + 1).toString();
                                        } 
                                        arrayList.add(str);
                                        if (j != k) {
                                          j = m;
                                          continue;
                                        } 
                                        break;
                                      } 
                                      throw new IllegalArgumentException("Failed requirement.".toString());
                                    }  
                                  va1 va12 = this.탐;
                                  if (va12 == null) {
                                    seekBar2 = null;
                                  } else {
                                    va16 = va12;
                                  } 
                                  vl vl4 = new vl((TextView)va16.不, arrayList);
                                  va1 va16 = va12;
                                  if (va12 == null)
                                    va16 = null; 
                                  vl vl1 = new vl(vl3, new yl[] { (yl)vl4, (yl)new vl((ImageView)va16.辛, 鏡.返) });
                                  y9 y91 = 鏡.歩;
                                  vl3.熱 = new xl(vl1, (wl)new ub(帰(), y91));
                                  i = ((雷)帰()).堅(y91);
                                  赤.硬(i);
                                  vl1.硬(i);
                                  va1 va15 = this.탐;
                                  va11 = va15;
                                  if (va15 == null)
                                    va11 = null; 
                                  ((TextView)va11.暑).setText(返(Integer.valueOf(2131689693), new Object[0]));
                                  본 본1 = 鏡.も;
                                  본 본2 = new 본(帰(), 鏡.ち);
                                  va15 = this.탐;
                                  va11 = va15;
                                  if (va15 == null)
                                    va11 = null; 
                                  new tc(본1, 본2, (ImageView)va11.熱, new 본(Integer.valueOf(2131165400), Integer.valueOf(2131165399)));
                                  va15 = this.탐;
                                  va11 = va15;
                                  if (va15 == null)
                                    va11 = null; 
                                  ((TextView)va11.寒).setText(返(Integer.valueOf(2131689694), new Object[0]));
                                  본1 = 鏡.赤;
                                  본2 = new 본(帰(), 鏡.ゃ);
                                  va15 = this.탐;
                                  va11 = va15;
                                  if (va15 == null)
                                    va11 = null; 
                                  new tc(본1, 본2, (ImageView)va11.冷, new 본(Integer.valueOf(2131165419), Integer.valueOf(2131165420)));
                                  return;
                                } 
                                i = 2131231413;
                              } else {
                                i = 2131231412;
                              } 
                            } else {
                              throw new NullPointerException("Missing required view with ID: ".concat(seekBar1.getResources().getResourceName(i)));
                            } 
                          } else {
                            throw new NullPointerException("Missing required view with ID: ".concat(seekBar1.getResources().getResourceName(i)));
                          } 
                        } else {
                          throw new NullPointerException("Missing required view with ID: ".concat(seekBar1.getResources().getResourceName(i)));
                        } 
                      } else {
                        i = 2131231376;
                      } 
                    } else {
                      i = 2131231371;
                    } 
                  } else {
                    i = 2131231369;
                  } 
                } else {
                  i = 2131231368;
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    throw new NullPointerException("Missing required view with ID: ".concat(va11.getResources().getResourceName(i)));
  }
  
  public final void 堅(目 param目) {
    ((鬚)((密)this).若.getValue()).堅(param目);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\SettingsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */