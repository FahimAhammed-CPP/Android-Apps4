package ocos.quizmath.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.for;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import y.ik;
import y.nf;
import y.rr;
import y.s4;
import y.tc;
import y.ts;
import y.uf;
import y.va1;
import y.ず;
import y.向;
import y.密;
import y.寒;
import y.師;
import y.書;
import y.殻;
import y.虎;
import y.行;
import y.西;
import y.鏡;
import y.겸;
import y.꽃;
import y.롱;
import y.용;

public final class BlitzActivity extends 겸 {
  public long く;
  
  public double ぼ;
  
  public s4 れ;
  
  public 向 僕;
  
  public BlitzActivity() {
    long l = ((Number)鏡.크.硬).longValue();
    this.く = l;
    double d = l / 1000.0D;
    int i = nf.硬;
    this.ぼ = d;
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    行 行 = 行.臭;
    ((ず)this).탁.硬((용)行);
  }
  
  public final int か() {
    return 2131165367;
  }
  
  public final void も() {
    rr rr = ち();
    long l = this.く;
    롱.堅(l);
    rr.堅(l);
  }
  
  public final void ゃ() {
    ts ts1;
    s4 s42 = this.れ;
    虎 虎2 = null;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    ((ConstraintLayout)((tc)s41.ぱ).痒).setBackgroundResource(2131165478);
    師 師 = 鏡.死;
    s42 = this.れ;
    s41 = s42;
    if (s42 == null)
      s41 = null; 
    List list = ik.わ((Object[])new TextView[] { (TextView)s41.熱, (TextView)s41.暑 });
    寒 寒 = new 寒(0, this);
    this.僕 = new 向(((密)this).크, 師, list, 寒);
    虎 虎1 = 踊().硬().硬();
    uf uf = 鏡.크;
    long l = 虎1.堅(uf.堅);
    if (l < 4000L) {
      Number number = (Number)uf.硬;
      number.longValue();
      int j = nf.硬;
      l = number.longValue();
    } 
    this.く = l;
    double d = l / 1000.0D;
    int i = nf.硬;
    this.ぼ = d;
    ts ts2 = this.し;
    虎1 = 虎2;
    if (ts2 != null)
      ts1 = ts2; 
    ((for)ts1.熱).寒(Boolean.TRUE);
  }
  
  public final void わ() {
    ConstraintLayout constraintLayout;
    View view = getLayoutInflater().inflate(2131427357, null, false);
    int i = 2131230824;
    ProgressBar progressBar = (ProgressBar)꽃.産(view, 2131230824);
    if (progressBar != null) {
      i = 2131230886;
      TextView textView = (TextView)꽃.産(view, 2131230886);
      if (textView != null) {
        i = 2131230887;
        TextView textView1 = (TextView)꽃.産(view, 2131230887);
        if (textView1 != null) {
          i = 2131230952;
          LinearLayout linearLayout = (LinearLayout)꽃.産(view, 2131230952);
          if (linearLayout != null) {
            i = 2131230954;
            View view1 = 꽃.産(view, 2131230954);
            if (view1 != null) {
              va1 va1 = va1.硬(view1);
              i = 2131231129;
              LinearLayout linearLayout1 = (LinearLayout)꽃.産(view, 2131231129);
              if (linearLayout1 != null) {
                i = 2131231242;
                TextView textView2 = (TextView)꽃.産(view, 2131231242);
                if (textView2 != null) {
                  i = 2131231244;
                  TextView textView3 = (TextView)꽃.産(view, 2131231244);
                  if (textView3 != null) {
                    ConstraintLayout constraintLayout1 = (ConstraintLayout)view;
                    i = 2131231376;
                    View view2 = 꽃.産(view, 2131231376);
                    if (view2 != null) {
                      s4 s41 = new s4((ViewGroup)constraintLayout1, (View)progressBar, textView, textView1, (View)linearLayout, va1, (View)linearLayout1, (View)textView2, (View)textView3, (ViewGroup)constraintLayout1, tc.堅(view2), 5);
                      this.れ = s41;
                      switch (5) {
                        case 5:
                          constraintLayout = (ConstraintLayout)s41.硬;
                          setContentView((View)constraintLayout);
                          return;
                      } 
                      constraintLayout = (ConstraintLayout)((s4)constraintLayout).硬;
                    } else {
                      throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                    } 
                  } else {
                    throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                  } 
                } else {
                  throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
                } 
              } else {
                throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
              } 
            } else {
              throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
            } 
          } else {
            throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
          } 
        } else {
          throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
        } 
      } else {
        throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
      } 
    } else {
      throw new NullPointerException("Missing required view with ID: ".concat(constraintLayout.getResources().getResourceName(i)));
    } 
    setContentView((View)constraintLayout);
  }
  
  public final void 怖(long paramLong) {
    super.怖(paramLong);
    double d1 = true;
    int i = 롱.痛;
    double d2 = Long.valueOf(paramLong).longValue() / this.ぼ;
    s4 s42 = this.れ;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    ((ProgressBar)s41.堅).setProgress((int)(d2 + d1));
  }
  
  public final int 投() {
    return 殻.堅((Context)this, 2131034782);
  }
  
  public final boolean 歩() {
    return false;
  }
  
  public final void 若(ArrayList paramArrayList) {
    long l = (あ()).堅.旨;
    Iterator<Number> iterator = paramArrayList.iterator();
    while (iterator.hasNext()) {
      boolean bool;
      Number number = iterator.next();
      if (number.longValue() != l) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        List list = ik.택(new ArrayList((Collection<?>)new 書((Object[])new Long[] { Long.valueOf(l), Long.valueOf(number.longValue()) }, true)));
        向 向2 = this.僕;
        向 向1 = 向2;
        if (向2 == null)
          向1 = null; 
        向1.硬(list, l);
        return;
      } 
    } 
    throw new NoSuchElementException("Collection contains no element matching the predicate.");
  }
  
  public final 西 触() {
    鏡.硬.getClass();
    return 鏡.恐;
  }
  
  public final void 赤() {
    super.赤();
    行 行 = 行.痒;
    ((ず)this).탁.硬((용)行);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\BlitzActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */