package ocos.quizmath.ui;

import android.content.ComponentCallbacks;
import android.os.Bundle;
import y.ik;
import y.ず;
import y.秘;
import y.髪;
import y.규;

public final class GraphActivity extends ず {
  public final 髪 탐 = ik.赤(new 秘((ComponentCallbacks)this, null, 19));
  
  public 규 탑;
  
  public final void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: invokevirtual getLayoutInflater : ()Landroid/view/LayoutInflater;
    //   9: ldc 2131427362
    //   11: aconst_null
    //   12: iconst_0
    //   13: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   16: astore_1
    //   17: ldc 2131231083
    //   19: istore #4
    //   21: aload_1
    //   22: ldc 2131231083
    //   24: invokestatic 産 : (Landroid/view/View;I)Landroid/view/View;
    //   27: checkcast android/widget/LinearLayout
    //   30: astore #7
    //   32: aload #7
    //   34: ifnull -> 831
    //   37: ldc 2131231084
    //   39: istore #4
    //   41: aload_1
    //   42: ldc 2131231084
    //   44: invokestatic 産 : (Landroid/view/View;I)Landroid/view/View;
    //   47: checkcast android/widget/TextView
    //   50: astore #8
    //   52: aload #8
    //   54: ifnull -> 831
    //   57: aload_1
    //   58: checkcast androidx/constraintlayout/widget/ConstraintLayout
    //   61: astore #9
    //   63: ldc 2131231376
    //   65: istore #4
    //   67: aload_1
    //   68: ldc 2131231376
    //   70: invokestatic 産 : (Landroid/view/View;I)Landroid/view/View;
    //   73: astore #10
    //   75: aload #10
    //   77: ifnull -> 831
    //   80: new y/규
    //   83: dup
    //   84: aload #9
    //   86: aload #7
    //   88: aload #8
    //   90: aload #9
    //   92: aload #10
    //   94: invokestatic 硬 : (Landroid/view/View;)Ly/ks;
    //   97: iconst_3
    //   98: invokespecial <init> : (Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Landroid/view/View;Landroidx/constraintlayout/widget/ConstraintLayout;Ljava/lang/Object;I)V
    //   101: astore_1
    //   102: aload_0
    //   103: aload_1
    //   104: putfield 탑 : Ly/규;
    //   107: iconst_3
    //   108: tableswitch default -> 128, 3 -> 131
    //   128: goto -> 142
    //   131: aload_1
    //   132: getfield 怖 : Ljava/lang/Object;
    //   135: checkcast androidx/constraintlayout/widget/ConstraintLayout
    //   138: astore_1
    //   139: goto -> 150
    //   142: aload_1
    //   143: getfield 怖 : Ljava/lang/Object;
    //   146: checkcast androidx/constraintlayout/widget/ConstraintLayout
    //   149: astore_1
    //   150: aload_0
    //   151: aload_1
    //   152: invokevirtual setContentView : (Landroid/view/View;)V
    //   155: aload_0
    //   156: getfield 탑 : Ly/규;
    //   159: astore #7
    //   161: aload #7
    //   163: astore_1
    //   164: aload #7
    //   166: ifnonnull -> 171
    //   169: aconst_null
    //   170: astore_1
    //   171: aload_1
    //   172: getfield 臭 : Ljava/lang/Object;
    //   175: checkcast y/ks
    //   178: getfield 硬 : Landroid/widget/ImageView;
    //   181: new y/hx
    //   184: dup
    //   185: iconst_3
    //   186: aload_0
    //   187: invokespecial <init> : (ILjava/lang/Object;)V
    //   190: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   193: aload_0
    //   194: aload_0
    //   195: ldc 2131689696
    //   197: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   200: iconst_0
    //   201: anewarray java/lang/Object
    //   204: invokevirtual 返 : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/String;
    //   207: invokevirtual 寝 : (Ljava/lang/String;)V
    //   210: bipush #10
    //   212: invokestatic 硬 : (I)V
    //   215: aload_0
    //   216: ldc 2131689519
    //   218: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   221: iconst_0
    //   222: anewarray java/lang/Object
    //   225: invokevirtual 返 : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/String;
    //   228: astore #8
    //   230: aload_0
    //   231: ldc 2131689656
    //   233: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   236: iconst_0
    //   237: anewarray java/lang/Object
    //   240: invokevirtual 返 : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/String;
    //   243: astore #9
    //   245: aload_0
    //   246: getfield 탑 : Ly/규;
    //   249: astore_1
    //   250: aload_1
    //   251: ifnonnull -> 260
    //   254: aconst_null
    //   255: astore #7
    //   257: goto -> 263
    //   260: aload_1
    //   261: astore #7
    //   263: aload #7
    //   265: getfield 痛 : Ljava/lang/Object;
    //   268: checkcast android/widget/TextView
    //   271: astore #10
    //   273: aload_1
    //   274: astore #7
    //   276: aload_1
    //   277: ifnonnull -> 283
    //   280: aconst_null
    //   281: astore #7
    //   283: aload #7
    //   285: getfield 恐 : Ljava/lang/Object;
    //   288: checkcast android/widget/LinearLayout
    //   291: astore #7
    //   293: aload_0
    //   294: getfield 탐 : Ly/髪;
    //   297: invokeinterface getValue : ()Ljava/lang/Object;
    //   302: checkcast y/회
    //   305: getfield 硬 : Locos/app/db/greendao/GreenDaoHelper;
    //   308: invokevirtual getDaoSession : ()Locos/app/db/greendao/DaoSession;
    //   311: invokevirtual getScoreDao : ()Locos/app/db/greendao/ScoreDao;
    //   314: invokevirtual loadAll : ()Ljava/util/List;
    //   317: checkcast java/lang/Iterable
    //   320: astore_1
    //   321: new java/util/ArrayList
    //   324: dup
    //   325: aload_1
    //   326: invokestatic 政 : (Ljava/lang/Iterable;)I
    //   329: invokespecial <init> : (I)V
    //   332: astore #11
    //   334: aload_1
    //   335: invokeinterface iterator : ()Ljava/util/Iterator;
    //   340: astore_1
    //   341: aload_1
    //   342: invokeinterface hasNext : ()Z
    //   347: ifeq -> 378
    //   350: aload #11
    //   352: new y/혼
    //   355: dup
    //   356: aload_1
    //   357: invokeinterface next : ()Ljava/lang/Object;
    //   362: checkcast ocos/app/db/greendao/Score
    //   365: invokevirtual getScore : ()D
    //   368: invokespecial <init> : (D)V
    //   371: invokevirtual add : (Ljava/lang/Object;)Z
    //   374: pop
    //   375: goto -> 341
    //   378: aload #11
    //   380: invokevirtual isEmpty : ()Z
    //   383: iconst_1
    //   384: ixor
    //   385: ifeq -> 805
    //   388: aload #11
    //   390: invokevirtual isEmpty : ()Z
    //   393: iconst_1
    //   394: ixor
    //   395: ifeq -> 791
    //   398: aload #11
    //   400: invokevirtual size : ()I
    //   403: iconst_1
    //   404: iadd
    //   405: anewarray y/홍
    //   408: astore #12
    //   410: aload #12
    //   412: iconst_0
    //   413: new y/홍
    //   416: dup
    //   417: iconst_0
    //   418: i2d
    //   419: dconst_0
    //   420: invokespecial <init> : (DD)V
    //   423: aastore
    //   424: aload #11
    //   426: invokevirtual iterator : ()Ljava/util/Iterator;
    //   429: astore_1
    //   430: iconst_1
    //   431: istore #4
    //   433: aload_1
    //   434: invokeinterface hasNext : ()Z
    //   439: ifeq -> 482
    //   442: aload_1
    //   443: invokeinterface next : ()Ljava/lang/Object;
    //   448: checkcast y/혼
    //   451: astore #13
    //   453: aload #12
    //   455: iload #4
    //   457: new y/홍
    //   460: dup
    //   461: iload #4
    //   463: i2d
    //   464: aload #13
    //   466: getfield 硬 : D
    //   469: invokespecial <init> : (DD)V
    //   472: aastore
    //   473: iload #4
    //   475: iconst_1
    //   476: iadd
    //   477: istore #4
    //   479: goto -> 433
    //   482: new y/활
    //   485: dup
    //   486: aload #12
    //   488: invokespecial <init> : ([Ly/홍;)V
    //   491: astore_1
    //   492: aload #11
    //   494: invokevirtual size : ()I
    //   497: istore #5
    //   499: new y/膚
    //   502: dup
    //   503: aload_0
    //   504: invokespecial <init> : (Landroid/content/Context;)V
    //   507: astore #12
    //   509: aload_1
    //   510: getfield 熱 : Ljava/util/ArrayList;
    //   513: aload #12
    //   515: invokevirtual add : (Ljava/lang/Object;)Z
    //   518: pop
    //   519: aload #12
    //   521: getfield 返 : Ljava/util/ArrayList;
    //   524: aload_1
    //   525: invokevirtual add : (Ljava/lang/Object;)Z
    //   528: pop
    //   529: aload #12
    //   531: invokevirtual 寒 : ()V
    //   534: getstatic y/赤.怖 : I
    //   537: istore #4
    //   539: bipush #10
    //   541: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   544: invokevirtual intValue : ()I
    //   547: istore #6
    //   549: iload #5
    //   551: istore #4
    //   553: iload #5
    //   555: iload #6
    //   557: if_icmple -> 696
    //   560: iload #6
    //   562: i2d
    //   563: dstore_2
    //   564: dload_2
    //   565: dconst_0
    //   566: dcmpg
    //   567: iflt -> 685
    //   570: aload #12
    //   572: ldc2_w 2.0
    //   575: putfield 起 : D
    //   578: aload #12
    //   580: dload_2
    //   581: putfield 興 : D
    //   584: aload #12
    //   586: iconst_1
    //   587: invokevirtual setScrollable : (Z)V
    //   590: aload #12
    //   592: getfield 痒 : Z
    //   595: ifeq -> 674
    //   598: aload #12
    //   600: aload #12
    //   602: iconst_1
    //   603: invokevirtual 暑 : (Z)D
    //   606: aload #12
    //   608: getfield 興 : D
    //   611: dsub
    //   612: putfield 起 : D
    //   615: aload #12
    //   617: getfield 若 : Z
    //   620: ifne -> 632
    //   623: aload #12
    //   625: aconst_null
    //   626: putfield 恐 : [Ljava/lang/String;
    //   629: goto -> 632
    //   632: aload #12
    //   634: getfield も : Z
    //   637: ifne -> 646
    //   640: aload #12
    //   642: aconst_null
    //   643: putfield 怖 : [Ljava/lang/String;
    //   646: aload #12
    //   648: invokevirtual invalidate : ()V
    //   651: aload #12
    //   653: getfield 産 : Ly/확;
    //   656: invokevirtual invalidate : ()V
    //   659: aload #12
    //   661: getfield か : Ly/홉;
    //   664: invokevirtual invalidate : ()V
    //   667: iload #6
    //   669: istore #4
    //   671: goto -> 696
    //   674: new java/lang/IllegalStateException
    //   677: dup
    //   678: ldc_w 'This GraphView is not scrollable.'
    //   681: invokespecial <init> : (Ljava/lang/String;)V
    //   684: athrow
    //   685: new java/lang/IllegalArgumentException
    //   688: dup
    //   689: ldc_w 'Viewport size must be greater than 0!'
    //   692: invokespecial <init> : (Ljava/lang/String;)V
    //   695: athrow
    //   696: aload #12
    //   698: invokevirtual getGraphViewStyle : ()Ly/황;
    //   701: ldc_w -7829368
    //   704: putfield 熱 : I
    //   707: aload #12
    //   709: invokevirtual getGraphViewStyle : ()Ly/황;
    //   712: ldc_w -65281
    //   715: putfield 堅 : I
    //   718: aload #12
    //   720: invokevirtual getGraphViewStyle : ()Ly/황;
    //   723: ldc_w -65536
    //   726: putfield 硬 : I
    //   729: aload #12
    //   731: invokevirtual getGraphViewStyle : ()Ly/황;
    //   734: aload_0
    //   735: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   738: ldc_w 2131099846
    //   741: invokevirtual getDimension : (I)F
    //   744: putfield 暑 : F
    //   747: aload #12
    //   749: invokevirtual getGraphViewStyle : ()Ly/황;
    //   752: iconst_5
    //   753: putfield 冷 : I
    //   756: aload #12
    //   758: invokevirtual getGraphViewStyle : ()Ly/황;
    //   761: iload #4
    //   763: putfield 寒 : I
    //   766: aload #12
    //   768: iconst_1
    //   769: anewarray java/lang/String
    //   772: dup
    //   773: iconst_0
    //   774: ldc_w ''
    //   777: aastore
    //   778: invokevirtual setHorizontalLabels : ([Ljava/lang/String;)V
    //   781: aload #7
    //   783: aload #12
    //   785: invokevirtual addView : (Landroid/view/View;)V
    //   788: goto -> 805
    //   791: new java/lang/IllegalArgumentException
    //   794: dup
    //   795: ldc_w 'Failed requirement.'
    //   798: invokevirtual toString : ()Ljava/lang/String;
    //   801: invokespecial <init> : (Ljava/lang/String;)V
    //   804: athrow
    //   805: aload #11
    //   807: invokevirtual isEmpty : ()Z
    //   810: iconst_1
    //   811: ixor
    //   812: ifeq -> 821
    //   815: aload #8
    //   817: astore_1
    //   818: goto -> 824
    //   821: aload #9
    //   823: astore_1
    //   824: aload #10
    //   826: aload_1
    //   827: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   830: return
    //   831: new java/lang/NullPointerException
    //   834: dup
    //   835: ldc_w 'Missing required view with ID: '
    //   838: aload_1
    //   839: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   842: iload #4
    //   844: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   847: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   850: invokespecial <init> : (Ljava/lang/String;)V
    //   853: athrow
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\ocos\quizmat\\ui\GraphActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */