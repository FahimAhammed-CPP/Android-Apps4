package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import y.d7;
import y.ej;
import y.f7;
import y.fj;
import y.gj;
import y.h7;
import y.hj;
import y.j9;
import y.l7;
import y.n7;
import y.p31;
import y.qx;
import y.rx;
import y.s7;
import y.t2;
import y.v4;
import y.w4;
import y.xf;
import y.ぞ;
import y.デ;
import y.心;
import y.桜;
import y.背;
import y.腰;
import y.茎;
import y.광;
import y.꽃;
import y.쌍;
import y.알;
import y.절;
import y.점;
import y.접;
import y.정;
import y.조;
import y.족;
import y.존;
import y.졸;
import y.침;
import y.탁;
import y.훤;

public abstract class do extends 졸 implements rx, 훤, hj, d7, 桜, f7, s7, l7, n7, t2 {
  public final CopyOnWriteArrayList 壊;
  
  public final CopyOnWriteArrayList 帰;
  
  public final 탁 怖 = new 탁();
  
  public final 茎 恐 = new 茎((Runnable)new 절(0, this));
  
  public boolean 歩;
  
  public final CopyOnWriteArrayList 死;
  
  public boolean 泳;
  
  public final CopyOnWriteArrayList 産;
  
  public final gj 痒;
  
  public final 背 痛;
  
  public qx 臭;
  
  public final 조 興;
  
  public final if 起;
  
  public final CopyOnWriteArrayList 返;
  
  public do() {
    背 背1 = new 背((腰)this);
    this.痛 = 背1;
    gj gj1 = new gj(this);
    this.痒 = gj1;
    this.起 = new if((Runnable)new 정(0, this));
    new AtomicInteger();
    쌍 쌍 = (쌍)this;
    this.興 = new 조(쌍);
    this.産 = new CopyOnWriteArrayList();
    this.死 = new CopyOnWriteArrayList();
    this.壊 = new CopyOnWriteArrayList();
    this.帰 = new CopyOnWriteArrayList();
    this.返 = new CopyOnWriteArrayList();
    this.歩 = false;
    this.泳 = false;
    int i = Build.VERSION.SDK_INT;
    背1.硬((心)new ComponentActivity$3(쌍));
    背1.硬((心)new ComponentActivity$4(쌍));
    背1.硬((心)new ComponentActivity$5(쌍));
    gj1.硬();
    p31.暑(this);
    if (i <= 23)
      背1.硬((心)new ImmLeaksCleaner(쌍)); 
    점 점 = new 점(0, this);
    gj1.堅.熱("android:support:activity-result", (ej)점);
    興((h7)new 접(쌍, 0));
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.興.硬(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<침> iterator = this.産.iterator();
    while (iterator.hasNext())
      ((침)iterator.next()).accept(paramConfiguration); 
  }
  
  public void onCreate(Bundle paramBundle) {
    this.痒.堅(paramBundle);
    탁 탁1 = this.怖;
    탁1.淋 = this;
    Iterator<h7> iterator = ((Set)탁1.怖).iterator();
    while (iterator.hasNext())
      ((h7)iterator.next()).硬(); 
    super.onCreate(paramBundle);
    xf.熱((Activity)this);
    if (p31.淋()) {
      if if1 = this.起;
      if1.冷 = 족.硬((Activity)this);
      if1.熱();
    } 
  }
  
  public final boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      getMenuInflater();
      Iterator iterator = ((CopyOnWriteArrayList)this.恐.恐).iterator();
      while (iterator.hasNext())
        ((알)iterator.next()).硬.ぱ(); 
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.恐.寂() : false);
  }
  
  public final void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.歩)
      return; 
    Iterator<침> iterator = this.帰.iterator();
    while (iterator.hasNext())
      ((침)iterator.next()).accept(new v4(paramBoolean)); 
  }
  
  public final void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.歩 = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.歩 = false;
      Iterator<침> iterator = this.帰.iterator();
      return;
    } finally {
      this.歩 = false;
    } 
  }
  
  public final void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<침> iterator = this.壊.iterator();
    while (iterator.hasNext())
      ((침)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    Iterator iterator = ((CopyOnWriteArrayList)this.恐.恐).iterator();
    while (iterator.hasNext())
      ((알)iterator.next()).硬.怖(); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public final void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.泳)
      return; 
    Iterator<침> iterator = this.返.iterator();
    while (iterator.hasNext())
      ((침)iterator.next()).accept(new j9(paramBoolean)); 
  }
  
  public final void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.泳 = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.泳 = false;
      Iterator<침> iterator = this.返.iterator();
      return;
    } finally {
      this.泳 = false;
    } 
  }
  
  public final boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      Iterator iterator = ((CopyOnWriteArrayList)this.恐.恐).iterator();
      while (iterator.hasNext())
        ((알)iterator.next()).硬.痒(); 
    } 
    return true;
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    Intent intent = (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint);
    if (!this.興.硬(paramInt, -1, intent) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    qx qx2 = this.臭;
    qx qx1 = qx2;
    if (qx2 == null) {
      존 존1 = (존)getLastNonConfigurationInstance();
      qx1 = qx2;
      if (존1 != null)
        qx1 = 존1.硬; 
    } 
    if (qx1 == null)
      return null; 
    존 존 = new 존();
    존.硬 = qx1;
    return 존;
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    背 背1 = this.痛;
    if (背1 instanceof 背) {
      ぞ ぞ = ぞ.恐;
      背1.士("setCurrentState");
      背1.防(ぞ);
    } 
    super.onSaveInstanceState(paramBundle);
    this.痒.熱(paramBundle);
  }
  
  public final void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<침> iterator = this.死.iterator();
    while (iterator.hasNext())
      ((침)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public final void reportFullyDrawn() {
    try {
      if (꽃.噛()) {
        int j = Build.VERSION.SDK_INT;
        Trace.beginSection("reportFullyDrawn() for ComponentActivity");
      } 
      int i = Build.VERSION.SDK_INT;
      super.reportFullyDrawn();
      return;
    } finally {
      꽃.起();
    } 
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    getWindow().getDecorView().setTag(2131231406, this);
    getWindow().getDecorView().setTag(2131231409, this);
    getWindow().getDecorView().setTag(2131231408, this);
    getWindow().getDecorView().setTag(2131231407, this);
    super.setContentView(paramView);
  }
  
  public final void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public final void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public final void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public final void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public final qx 悲() {
    if (getApplication() != null) {
      if (this.臭 == null) {
        존 존 = (존)getLastNonConfigurationInstance();
        if (존 != null)
          this.臭 = 존.硬; 
        if (this.臭 == null)
          this.臭 = new qx(); 
      } 
      return this.臭;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final w4 旨() {
    w4 w4 = new w4();
    if (getApplication() != null)
      w4.硬((광)デ.起, getApplication()); 
    w4.硬((광)p31.辛, this);
    w4.硬((광)p31.ぱ, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      w4.硬((광)p31.苦, getIntent().getExtras()); 
    return w4;
  }
  
  public final 背 痒() {
    return this.痛;
  }
  
  public final fj 硬() {
    return this.痒.堅;
  }
  
  public final void 興(h7 paramh7) {
    탁 탁1 = this.怖;
    if ((Context)탁1.淋 != null)
      paramh7.硬(); 
    ((Set<h7>)탁1.怖).add(paramh7);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */