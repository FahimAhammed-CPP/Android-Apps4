package androidx.activity;

import java.util.ArrayDeque;
import y.c7;
import y.p31;
import y.尻;
import y.心;
import y.持;
import y.肉;
import y.腰;
import y.안;
import y.침;

class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements 肉, 持 {
  public final 안 怖;
  
  public c7 恐;
  
  public final p31 淋;
  
  public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(if paramif, p31 paramp31, 안 param안) {
    this.淋 = paramp31;
    this.怖 = param안;
    paramp31.硬((心)this);
  }
  
  public final void cancel() {
    this.淋.興((心)this);
    this.怖.堅.remove(this);
    c7 c71 = this.恐;
    if (c71 != null) {
      c71.cancel();
      this.恐 = null;
    } 
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    안 안1;
    if (param尻 == 尻.ON_START) {
      if if1 = this.痛;
      ArrayDeque<안> arrayDeque = if1.堅;
      안1 = this.怖;
      arrayDeque.add(안1);
      c7 c71 = new c7(if1, 안1);
      안1.堅.add(c71);
      if (p31.淋()) {
        if1.熱();
        안1.熱 = (침)if1.熱;
      } 
      this.恐 = c71;
      return;
    } 
    if (안1 == 尻.ON_STOP) {
      c7 c71 = this.恐;
      if (c71 != null) {
        c71.cancel();
        return;
      } 
    } else if (안1 == 尻.ON_DESTROY) {
      cancel();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher$LifecycleOnBackPressedCancellable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */