package androidx.activity;

import android.view.View;
import android.view.Window;
import y.尻;
import y.肉;
import y.腰;
import y.쌍;

class ComponentActivity$3 implements 肉 {
  public ComponentActivity$3(쌍 param쌍) {}
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 == 尻.ON_STOP) {
      Window window = this.淋.getWindow();
      if (window != null) {
        View view = window.peekDecorView();
      } else {
        window = null;
      } 
      if (window != null)
        window.cancelPendingInputEvents(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\ComponentActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */