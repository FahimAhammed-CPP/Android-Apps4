package androidx.activity;

import y.尻;
import y.肉;
import y.腰;
import y.쌍;

class ComponentActivity$4 implements 肉 {
  public ComponentActivity$4(쌍 param쌍) {}
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 == 尻.ON_DESTROY) {
      this.淋.怖.淋 = null;
      if (!this.淋.isChangingConfigurations())
        this.淋.悲().硬(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\ComponentActivity$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */