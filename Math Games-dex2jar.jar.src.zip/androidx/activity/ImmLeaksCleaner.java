package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import java.lang.reflect.Field;
import y.尻;
import y.肉;
import y.腰;
import y.쌍;

final class ImmLeaksCleaner implements 肉 {
  public static int 怖;
  
  public static Field 恐;
  
  public static Field 痒;
  
  public static Field 痛;
  
  public final Activity 淋;
  
  public ImmLeaksCleaner(쌍 param쌍) {
    this.淋 = (Activity)param쌍;
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 != 尻.ON_DESTROY)
      return; 
    if (怖 == 0)
      try {
        怖 = 2;
        Field field = InputMethodManager.class.getDeclaredField("mServedView");
        痛 = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mNextServedView");
        痒 = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mH");
        恐 = field;
        field.setAccessible(true);
        怖 = 1;
      } catch (NoSuchFieldException noSuchFieldException) {} 
    if (怖 == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.淋.getSystemService("input_method");
      try {
        Object object = 恐.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)痛.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            痒.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */