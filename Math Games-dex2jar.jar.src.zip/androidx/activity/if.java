package androidx.activity;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.ArrayDeque;
import java.util.Iterator;
import y.b7;
import y.p31;
import y.ぞ;
import y.ㅆ;
import y.背;
import y.腰;
import y.안;
import y.앵;
import y.절;
import y.침;

public final class if {
  public OnBackInvokedDispatcher 冷;
  
  public final ArrayDeque 堅 = new ArrayDeque();
  
  public boolean 寒 = false;
  
  public final OnBackInvokedCallback 暑;
  
  public final ㅆ 熱;
  
  public final Runnable 硬;
  
  public if(Runnable paramRunnable) {
    this.硬 = paramRunnable;
    if (p31.淋()) {
      this.熱 = new ㅆ(2, this);
      this.暑 = b7.硬((Runnable)new 절(2, this));
    } 
  }
  
  public final void 堅() {
    Iterator<안> iterator = this.堅.descendingIterator();
    while (iterator.hasNext()) {
      안 안 = iterator.next();
      if (안.硬) {
        앵 앵 = 안.暑;
        앵.死(true);
        if (앵.旨.硬) {
          앵.わ();
          return;
        } 
        앵.美.堅();
        return;
      } 
    } 
    Runnable runnable = this.硬;
    if (runnable != null)
      runnable.run(); 
  }
  
  public final void 熱() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 堅 : Ljava/util/ArrayDeque;
    //   4: invokevirtual descendingIterator : ()Ljava/util/Iterator;
    //   7: astore_2
    //   8: aload_2
    //   9: invokeinterface hasNext : ()Z
    //   14: ifeq -> 37
    //   17: aload_2
    //   18: invokeinterface next : ()Ljava/lang/Object;
    //   23: checkcast y/안
    //   26: getfield 硬 : Z
    //   29: ifeq -> 8
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: aload_0
    //   40: getfield 冷 : Landroid/window/OnBackInvokedDispatcher;
    //   43: astore_2
    //   44: aload_2
    //   45: ifnull -> 97
    //   48: aload_0
    //   49: getfield 暑 : Landroid/window/OnBackInvokedCallback;
    //   52: astore_3
    //   53: iload_1
    //   54: ifeq -> 76
    //   57: aload_0
    //   58: getfield 寒 : Z
    //   61: ifne -> 76
    //   64: aload_2
    //   65: iconst_0
    //   66: aload_3
    //   67: invokestatic 堅 : (Ljava/lang/Object;ILjava/lang/Object;)V
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield 寒 : Z
    //   75: return
    //   76: iload_1
    //   77: ifne -> 97
    //   80: aload_0
    //   81: getfield 寒 : Z
    //   84: ifeq -> 97
    //   87: aload_2
    //   88: aload_3
    //   89: invokestatic 熱 : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   92: aload_0
    //   93: iconst_0
    //   94: putfield 寒 : Z
    //   97: return
  }
  
  public final void 硬(腰 param腰, 안 param안) {
    背 背 = param腰.痒();
    if (背.興 == ぞ.淋)
      return; 
    OnBackPressedDispatcher$LifecycleOnBackPressedCancellable onBackPressedDispatcher$LifecycleOnBackPressedCancellable = new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(this, (p31)背, param안);
    param안.堅.add(onBackPressedDispatcher$LifecycleOnBackPressedCancellable);
    if (p31.淋()) {
      熱();
      param안.熱 = (침)this.熱;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */