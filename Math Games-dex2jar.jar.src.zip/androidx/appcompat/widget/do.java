package androidx.appcompat.widget;

import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;

public final class do implements View.OnClickListener {
  public do(SearchView paramSearchView) {}
  
  public final void onClick(View paramView) {
    View.OnClickListener onClickListener;
    SearchView searchView = this.淋;
    ImageView imageView = searchView.投;
    SearchView.SearchAutoComplete searchAutoComplete = searchView.踊;
    if (paramView == imageView) {
      searchView.興(false);
      searchAutoComplete.requestFocus();
      searchAutoComplete.setImeVisibility(true);
      onClickListener = searchView.탈;
      if (onClickListener != null) {
        onClickListener.onClick((View)searchView);
        return;
      } 
    } else {
      if (onClickListener == searchView.か) {
        searchView.嬉();
        return;
      } 
      if (onClickListener == searchView.あ) {
        searchView.怖();
        return;
      } 
      if (onClickListener == searchView.ち) {
        SearchableInfo searchableInfo = searchView.퇴;
        if (searchableInfo == null)
          return; 
        try {
          String str;
          if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
            Intent intent = new Intent(searchView.ㅌ);
            ComponentName componentName = searchableInfo.getSearchActivity();
            if (componentName == null) {
              componentName = null;
            } else {
              str = componentName.flattenToShortString();
            } 
            intent.putExtra("calling_package", str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          if (str.getVoiceSearchLaunchRecognizer()) {
            Intent intent = searchView.ぱ(searchView.타, (SearchableInfo)str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          return;
        } 
      } 
      if (activityNotFoundException == searchAutoComplete)
        searchView.苦(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */