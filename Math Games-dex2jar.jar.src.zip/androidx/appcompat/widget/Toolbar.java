package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import y.aw;
import y.dk;
import y.for;
import y.fs;
import y.gs;
import y.hs;
import y.ik;
import y.is;
import y.js;
import y.ki;
import y.ls;
import y.p2;
import y.p31;
import y.r2;
import y.rw;
import y.t;
import y.t2;
import y.td;
import y.wo;
import y.x2;
import y.ク;
import y.ツ;
import y.ナ;
import y.乳;
import y.布;
import y.年;
import y.扉;
import y.服;
import y.男;
import y.茎;
import y.꾸;
import y.알;
import y.정;
import y.홀;

public class Toolbar extends ViewGroup implements t2 {
  public int あ;
  
  public int か;
  
  public final int ち = 8388627;
  
  public ColorStateList も;
  
  public CharSequence ゃ;
  
  public ColorStateList わ;
  
  public ArrayList ㅌ = new ArrayList();
  
  public int 噛;
  
  public int 壊;
  
  public int 寝;
  
  public int 帰;
  
  public 服 怖;
  
  public 服 恐;
  
  public ki 投;
  
  public final int 歩;
  
  public Context 死;
  
  public final int 泳;
  
  public ActionMenuView 淋;
  
  public View 産;
  
  public 布 痒;
  
  public 扉 痛;
  
  public final Drawable 臭;
  
  public 扉 興;
  
  public boolean 若;
  
  public int 触;
  
  public CharSequence 赤;
  
  public final CharSequence 起;
  
  public int 踊;
  
  public int 返;
  
  public boolean 코;
  
  public final ArrayList 쾌 = new ArrayList();
  
  public final ArrayList 크 = new ArrayList();
  
  public final int[] 큰 = new int[2];
  
  public final 茎 키 = new 茎((Runnable)new fs(this, 0));
  
  public final 홀 타 = new 홀(this);
  
  public ls 탁;
  
  public ツ 탄;
  
  public try 탈;
  
  public boolean 탐;
  
  public OnBackInvokedCallback 탑;
  
  public OnBackInvokedDispatcher 탕;
  
  public boolean 태;
  
  public final 정 택 = new 정(3, this);
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, 2130904094);
    Context context = getContext();
    int[] arrayOfInt = td.탄;
    dk dk = dk.嬉(context, paramAttributeSet, arrayOfInt, 2130904094);
    Object object = dk.堅;
    rw.壊((View)this, paramContext, arrayOfInt, paramAttributeSet, (TypedArray)object, 2130904094);
    this.帰 = dk.不(28, 0);
    this.返 = dk.不(19, 0);
    this.ち = ((TypedArray)object).getInteger(0, 8388627);
    this.歩 = ((TypedArray)object).getInteger(2, 48);
    int i = dk.熱(22, 0);
    paramInt = i;
    if (dk.苦(27))
      paramInt = dk.熱(27, i); 
    this.触 = paramInt;
    this.噛 = paramInt;
    this.寝 = paramInt;
    this.踊 = paramInt;
    paramInt = dk.熱(25, -1);
    if (paramInt >= 0)
      this.踊 = paramInt; 
    paramInt = dk.熱(24, -1);
    if (paramInt >= 0)
      this.寝 = paramInt; 
    paramInt = dk.熱(26, -1);
    if (paramInt >= 0)
      this.噛 = paramInt; 
    paramInt = dk.熱(23, -1);
    if (paramInt >= 0)
      this.触 = paramInt; 
    this.泳 = dk.暑(13, -1);
    paramInt = dk.熱(9, -2147483648);
    i = dk.熱(5, -2147483648);
    int j = dk.暑(7, 0);
    int k = dk.暑(8, 0);
    if (this.投 == null)
      this.投 = new ki(); 
    ki ki1 = this.投;
    ki1.旨 = false;
    if (j != Integer.MIN_VALUE) {
      ki1.冷 = j;
      ki1.硬 = j;
    } 
    if (k != Integer.MIN_VALUE) {
      ki1.寒 = k;
      ki1.堅 = k;
    } 
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      ki1.硬(paramInt, i); 
    this.あ = dk.熱(10, -2147483648);
    this.か = dk.熱(6, -2147483648);
    this.臭 = dk.冷(4);
    this.起 = dk.ぱ(3);
    CharSequence charSequence3 = dk.ぱ(21);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = dk.ぱ(18);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.死 = getContext();
    setPopupTheme(dk.不(17, 0));
    Drawable drawable2 = dk.冷(16);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = dk.ぱ(15);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = dk.冷(11);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = dk.ぱ(12);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (dk.苦(29))
      setTitleTextColor(dk.堅(29)); 
    if (dk.苦(20))
      setSubtitleTextColor(dk.堅(20)); 
    if (dk.苦(14)) {
      paramInt = dk.不(14, 0);
      getMenuInflater().inflate(paramInt, getMenu());
    } 
    dk.寂();
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new wo(getContext());
  }
  
  public static int 不(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = Build.VERSION.SDK_INT;
    i = t.熱(marginLayoutParams);
    return t.堅(marginLayoutParams) + i;
  }
  
  public static hs 美(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof hs) ? new hs((hs)paramLayoutParams) : ((paramLayoutParams instanceof ク) ? new hs((ク)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new hs((ViewGroup.MarginLayoutParams)paramLayoutParams) : new hs(paramLayoutParams)));
  }
  
  public static int 辛(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof hs);
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new hs();
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new hs(getContext(), paramAttributeSet);
  }
  
  public CharSequence getCollapseContentDescription() {
    扉 扉1 = this.興;
    return (扉1 != null) ? 扉1.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    扉 扉1 = this.興;
    return (扉1 != null) ? 扉1.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    ki ki1 = this.投;
    return (ki1 != null) ? (ki1.美 ? ki1.硬 : ki1.堅) : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.か;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    ki ki1 = this.投;
    return (ki1 != null) ? ki1.硬 : 0;
  }
  
  public int getContentInsetRight() {
    ki ki1 = this.投;
    return (ki1 != null) ? ki1.堅 : 0;
  }
  
  public int getContentInsetStart() {
    ki ki1 = this.投;
    return (ki1 != null) ? (ki1.美 ? ki1.堅 : ki1.硬) : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.あ;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: getfield 踊 : Ly/r2;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield か : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (rw.不((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (rw.不((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.あ, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    布 布1 = this.痒;
    return (布1 != null) ? 布1.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    布 布1 = this.痒;
    return (布1 != null) ? 布1.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    暑();
    return this.淋.getMenu();
  }
  
  public View getNavButtonView() {
    return (View)this.痛;
  }
  
  public CharSequence getNavigationContentDescription() {
    扉 扉1 = this.痛;
    return (扉1 != null) ? 扉1.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    扉 扉1 = this.痛;
    return (扉1 != null) ? 扉1.getDrawable() : null;
  }
  
  public ツ getOuterActionMenuPresenter() {
    return this.탄;
  }
  
  public Drawable getOverflowIcon() {
    暑();
    return this.淋.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.死;
  }
  
  public int getPopupTheme() {
    return this.壊;
  }
  
  public CharSequence getSubtitle() {
    return this.赤;
  }
  
  public final TextView getSubtitleTextView() {
    return (TextView)this.恐;
  }
  
  public CharSequence getTitle() {
    return this.ゃ;
  }
  
  public int getTitleMarginBottom() {
    return this.触;
  }
  
  public int getTitleMarginEnd() {
    return this.寝;
  }
  
  public int getTitleMarginStart() {
    return this.踊;
  }
  
  public int getTitleMarginTop() {
    return this.噛;
  }
  
  public final TextView getTitleTextView() {
    return (TextView)this.怖;
  }
  
  public 꾸 getWrapper() {
    if (this.탁 == null)
      this.탁 = new ls(this); 
    return (꾸)this.탁;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    恐();
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks((Runnable)this.택);
    恐();
  }
  
  public final boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.코 = false; 
    if (!this.코) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.코 = true; 
    } 
    if (i == 10 || i == 3)
      this.코 = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (rw.不((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int i1 = getWidth();
    int i4 = getHeight();
    paramInt3 = getPaddingLeft();
    int i2 = getPaddingRight();
    int i3 = getPaddingTop();
    int i5 = getPaddingBottom();
    int m = i1 - i2;
    int[] arrayOfInt = this.큰;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = Build.VERSION.SDK_INT;
    paramInt1 = aw.暑((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (怖((View)this.痛)) {
      if (k) {
        j = 悲((View)this.痛, m, paramInt4, arrayOfInt);
        i = paramInt3;
      } else {
        i = 嬉((View)this.痛, paramInt3, paramInt4, arrayOfInt);
        j = m;
      } 
    } else {
      i = paramInt3;
      j = m;
    } 
    paramInt1 = i;
    paramInt2 = j;
    if (怖((View)this.興))
      if (k) {
        paramInt2 = 悲((View)this.興, j, paramInt4, arrayOfInt);
        paramInt1 = i;
      } else {
        paramInt1 = 嬉((View)this.興, i, paramInt4, arrayOfInt);
        paramInt2 = j;
      }  
    int j = paramInt1;
    int i = paramInt2;
    if (怖((View)this.淋))
      if (k) {
        j = 嬉((View)this.淋, paramInt1, paramInt4, arrayOfInt);
        i = paramInt2;
      } else {
        i = 悲((View)this.淋, paramInt2, paramInt4, arrayOfInt);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - i);
    j = Math.max(j, paramInt2);
    i = Math.min(i, m - paramInt1);
    paramInt1 = j;
    paramInt2 = i;
    if (怖(this.産))
      if (k) {
        paramInt2 = 悲(this.産, i, paramInt4, arrayOfInt);
        paramInt1 = j;
      } else {
        paramInt1 = 嬉(this.産, j, paramInt4, arrayOfInt);
        paramInt2 = i;
      }  
    i = paramInt1;
    j = paramInt2;
    if (怖((View)this.痒))
      if (k) {
        j = 悲((View)this.痒, paramInt2, paramInt4, arrayOfInt);
        i = paramInt1;
      } else {
        i = 嬉((View)this.痒, paramInt1, paramInt4, arrayOfInt);
        j = paramInt2;
      }  
    paramBoolean = 怖((View)this.怖);
    boolean bool = 怖((View)this.恐);
    if (paramBoolean) {
      hs hs = (hs)this.怖.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)hs).topMargin;
      paramInt1 = this.怖.getMeasuredHeight() + paramInt1 + ((ViewGroup.MarginLayoutParams)hs).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      hs hs = (hs)this.恐.getLayoutParams();
      paramInt2 = ((ViewGroup.MarginLayoutParams)hs).topMargin;
      paramInt1 += this.恐.getMeasuredHeight() + paramInt2 + ((ViewGroup.MarginLayoutParams)hs).bottomMargin;
    } 
    if (paramBoolean || bool) {
      服 服1;
      服 服2;
      if (paramBoolean) {
        服1 = this.怖;
      } else {
        服1 = this.恐;
      } 
      if (bool) {
        服2 = this.恐;
      } else {
        服2 = this.怖;
      } 
      hs hs1 = (hs)服1.getLayoutParams();
      hs hs2 = (hs)服2.getLayoutParams();
      if ((paramBoolean && this.怖.getMeasuredWidth() > 0) || (bool && this.恐.getMeasuredWidth() > 0)) {
        m = 1;
      } else {
        m = 0;
      } 
      paramInt2 = this.ち & 0x70;
      if (paramInt2 != 48) {
        if (paramInt2 != 80) {
          paramInt2 = (i4 - i3 - i5 - paramInt1) / 2;
          int i6 = ((ViewGroup.MarginLayoutParams)hs1).topMargin + this.噛;
          if (paramInt2 < i6) {
            paramInt1 = i6;
          } else {
            i6 = i4 - i5 - paramInt1 - paramInt2 - i3;
            i4 = ((ViewGroup.MarginLayoutParams)hs1).bottomMargin;
            i5 = this.触;
            paramInt1 = paramInt2;
            if (i6 < i4 + i5)
              paramInt1 = Math.max(0, paramInt2 - ((ViewGroup.MarginLayoutParams)hs2).bottomMargin + i5 - i6); 
          } 
          paramInt1 = i3 + paramInt1;
        } else {
          paramInt1 = i4 - i5 - ((ViewGroup.MarginLayoutParams)hs2).bottomMargin - this.触 - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)hs1).topMargin + this.噛;
      } 
      if (k) {
        int i6;
        if (m != 0) {
          paramInt2 = this.踊;
        } else {
          paramInt2 = 0;
        } 
        paramInt2 -= arrayOfInt[1];
        j -= Math.max(0, paramInt2);
        arrayOfInt[1] = Math.max(0, -paramInt2);
        if (paramBoolean) {
          hs1 = (hs)this.怖.getLayoutParams();
          k = j - this.怖.getMeasuredWidth();
          paramInt2 = this.怖.getMeasuredHeight() + paramInt1;
          this.怖.layout(k, paramInt1, j, paramInt2);
          k -= this.寝;
          paramInt1 = paramInt2 + ((ViewGroup.MarginLayoutParams)hs1).bottomMargin;
        } else {
          k = j;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.恐.getLayoutParams()).topMargin;
          paramInt2 = this.恐.getMeasuredWidth();
          i6 = this.恐.getMeasuredHeight();
          this.恐.layout(j - paramInt2, paramInt1, j, i6 + paramInt1);
          i6 = j - this.寝;
        } else {
          i6 = j;
        } 
        paramInt2 = i;
        paramInt1 = j;
        if (m != 0) {
          paramInt1 = Math.min(k, i6);
          paramInt2 = i;
        } 
      } else {
        if (m != 0) {
          paramInt2 = this.踊;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[0];
        paramInt2 = i + Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          hs1 = (hs)this.怖.getLayoutParams();
          i = this.怖.getMeasuredWidth() + paramInt2;
          k = this.怖.getMeasuredHeight() + paramInt1;
          this.怖.layout(paramInt2, paramInt1, i, k);
          i += this.寝;
          paramInt1 = k + ((ViewGroup.MarginLayoutParams)hs1).bottomMargin;
        } else {
          i = paramInt2;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.恐.getLayoutParams()).topMargin;
          k = this.恐.getMeasuredWidth() + paramInt2;
          int i6 = this.恐.getMeasuredHeight();
          this.恐.layout(paramInt2, paramInt1, k, i6 + paramInt1);
          k += this.寝;
        } else {
          k = paramInt2;
        } 
        paramInt1 = j;
        if (m != 0) {
          paramInt2 = Math.max(i, k);
          paramInt1 = j;
        } 
      } 
    } else {
      paramInt2 = i;
      paramInt1 = j;
    } 
    int k = paramInt4;
    m = paramInt3;
    ArrayList<View> arrayList = this.쾌;
    硬(3, arrayList);
    paramInt4 = arrayList.size();
    for (paramInt3 = 0; paramInt3 < paramInt4; paramInt3++)
      paramInt2 = 嬉(arrayList.get(paramInt3), paramInt2, k, arrayOfInt); 
    硬(5, arrayList);
    paramInt4 = arrayList.size();
    for (paramInt3 = 0; paramInt3 < paramInt4; paramInt3++)
      paramInt1 = 悲(arrayList.get(paramInt3), paramInt1, k, arrayOfInt); 
    硬(1, arrayList);
    j = arrayOfInt[0];
    i = arrayOfInt[1];
    int n = arrayList.size();
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt4 < n) {
      View view = arrayList.get(paramInt4);
      hs hs = (hs)view.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)hs).leftMargin - j;
      i = ((ViewGroup.MarginLayoutParams)hs).rightMargin - i;
      i3 = Math.max(0, j);
      i4 = Math.max(0, i);
      j = Math.max(0, -j);
      i = Math.max(0, -i);
      paramInt3 += view.getMeasuredWidth() + i3 + i4;
      paramInt4++;
    } 
    paramInt4 = 0;
    i = (i1 - m - i2) / 2 + m - paramInt3 / 2;
    paramInt3 += i;
    if (i < paramInt2) {
      paramInt1 = paramInt2;
    } else if (paramInt3 > paramInt1) {
      paramInt1 = i - paramInt3 - paramInt1;
    } else {
      paramInt1 = i;
    } 
    paramInt3 = arrayList.size();
    for (paramInt2 = paramInt4; paramInt2 < paramInt3; paramInt2++)
      paramInt1 = 嬉(arrayList.get(paramInt2), paramInt1, k, arrayOfInt); 
    arrayList.clear();
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof js)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    js js = (js)paramParcelable;
    super.onRestoreInstanceState(((for)js).淋);
    ActionMenuView actionMenuView = this.淋;
    if (actionMenuView != null) {
      r2 r2 = actionMenuView.踊;
    } else {
      actionMenuView = null;
    } 
    int i = js.恐;
    if (i != 0 && this.탈 != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (js.痛) {
      정 정1 = this.택;
      removeCallbacks((Runnable)정1);
      post((Runnable)정1);
    } 
  }
  
  public final void onRtlPropertiesChanged(int paramInt) {
    int i = Build.VERSION.SDK_INT;
    super.onRtlPropertiesChanged(paramInt);
    if (this.投 == null)
      this.投 = new ki(); 
    ki ki1 = this.投;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    if (bool == ki1.美)
      return; 
    ki1.美 = bool;
    if (ki1.旨) {
      if (bool) {
        paramInt = ki1.暑;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = ki1.冷; 
        ki1.硬 = paramInt;
        paramInt = ki1.熱;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = ki1.寒; 
        ki1.堅 = paramInt;
        return;
      } 
      paramInt = ki1.熱;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = ki1.冷; 
      ki1.硬 = paramInt;
      paramInt = ki1.暑;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = ki1.寒; 
      ki1.堅 = paramInt;
      return;
    } 
    ki1.硬 = ki1.冷;
    ki1.堅 = ki1.寒;
  }
  
  public final Parcelable onSaveInstanceState() {
    js js = new js(super.onSaveInstanceState());
    try try1 = this.탈;
    if (try1 != null) {
      x2 x2 = try1.怖;
      if (x2 != null)
        js.恐 = x2.硬; 
    } 
    ActionMenuView actionMenuView = this.淋;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (actionMenuView != null) {
      boolean bool;
      ツ ツ1 = actionMenuView.投;
      if (ツ1 != null && ツ1.寒()) {
        bool = true;
      } else {
        bool = false;
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    js.痛 = bool1;
    return (Parcelable)js;
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.若 = false; 
    if (!this.若) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.若 = true; 
    } 
    if (i == 1 || i == 3)
      this.若 = false; 
    return true;
  }
  
  public void setBackInvokedCallbackEnabled(boolean paramBoolean) {
    if (this.태 != paramBoolean) {
      this.태 = paramBoolean;
      恐();
    } 
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      熱(); 
    扉 扉1 = this.興;
    if (扉1 != null)
      扉1.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(年.痛(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      熱();
      this.興.setImageDrawable(paramDrawable);
      return;
    } 
    扉 扉1 = this.興;
    if (扉1 != null)
      扉1.setImageDrawable(this.臭); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.탐 = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.か) {
      this.か = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.あ) {
      this.あ = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(年.痛(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      if (this.痒 == null)
        this.痒 = new 布(getContext(), null, 0); 
      if (!苦((View)this.痒))
        堅((View)this.痒, true); 
    } else {
      布 布2 = this.痒;
      if (布2 != null && 苦((View)布2)) {
        removeView((View)this.痒);
        this.크.remove(this.痒);
      } 
    } 
    布 布1 = this.痒;
    if (布1 != null)
      布1.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence) && this.痒 == null)
      this.痒 = new 布(getContext(), null, 0); 
    布 布1 = this.痒;
    if (布1 != null)
      布1.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      寒(); 
    扉 扉1 = this.痛;
    if (扉1 != null) {
      扉1.setContentDescription(paramCharSequence);
      ik.태((View)this.痛, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(年.痛(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      寒();
      if (!苦((View)this.痛))
        堅((View)this.痛, true); 
    } else {
      扉 扉2 = this.痛;
      if (扉2 != null && 苦((View)扉2)) {
        removeView((View)this.痛);
        this.크.remove(this.痛);
      } 
    } 
    扉 扉1 = this.痛;
    if (扉1 != null)
      扉1.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    寒();
    this.痛.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(is paramis) {}
  
  public void setOverflowIcon(Drawable paramDrawable) {
    暑();
    this.淋.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.壊 != paramInt) {
      this.壊 = paramInt;
      if (paramInt == 0) {
        this.死 = getContext();
        return;
      } 
      this.死 = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.恐 == null) {
        Context context = getContext();
        服 服2 = new 服(context, null);
        this.恐 = 服2;
        服2.setSingleLine();
        this.恐.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.返;
        if (i != 0)
          this.恐.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.も;
        if (colorStateList != null)
          this.恐.setTextColor(colorStateList); 
      } 
      if (!苦((View)this.恐))
        堅((View)this.恐, true); 
    } else {
      服 服2 = this.恐;
      if (服2 != null && 苦((View)服2)) {
        removeView((View)this.恐);
        this.크.remove(this.恐);
      } 
    } 
    服 服1 = this.恐;
    if (服1 != null)
      服1.setText(paramCharSequence); 
    this.赤 = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.も = paramColorStateList;
    服 服1 = this.恐;
    if (服1 != null)
      服1.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.怖 == null) {
        Context context = getContext();
        服 服2 = new 服(context, null);
        this.怖 = 服2;
        服2.setSingleLine();
        this.怖.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.帰;
        if (i != 0)
          this.怖.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.わ;
        if (colorStateList != null)
          this.怖.setTextColor(colorStateList); 
      } 
      if (!苦((View)this.怖))
        堅((View)this.怖, true); 
    } else {
      服 服2 = this.怖;
      if (服2 != null && 苦((View)服2)) {
        removeView((View)this.怖);
        this.크.remove(this.怖);
      } 
    } 
    服 服1 = this.怖;
    if (服1 != null)
      服1.setText(paramCharSequence); 
    this.ゃ = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.触 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.寝 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.踊 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.噛 = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.わ = paramColorStateList;
    服 服1 = this.怖;
    if (服1 != null)
      服1.setTextColor(paramColorStateList); 
  }
  
  public final void ぱ() {
    for (MenuItem menuItem : this.ㅌ)
      getMenu().removeItem(menuItem.getItemId()); 
    getMenu();
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    getMenuInflater();
    Iterator iterator = ((CopyOnWriteArrayList)this.키.恐).iterator();
    while (iterator.hasNext())
      ((알)iterator.next()).硬.ぱ(); 
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.ㅌ = arrayList2;
  }
  
  public final void 冷() {
    if (this.淋 == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
      this.淋 = actionMenuView;
      actionMenuView.setPopupTheme(this.壊);
      this.淋.setOnMenuItemClickListener((ナ)this.타);
      actionMenuView = this.淋;
      男 男 = new 男(3, this);
      actionMenuView.あ = null;
      actionMenuView.か = (p2)男;
      hs hs = new hs();
      ((ク)hs).硬 = this.歩 & 0x70 | 0x800005;
      this.淋.setLayoutParams((ViewGroup.LayoutParams)hs);
      堅((View)this.淋, false);
    } 
  }
  
  public final void 堅(View paramView, boolean paramBoolean) {
    hs hs;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      hs = new hs();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)hs)) {
      hs = 美((ViewGroup.LayoutParams)hs);
    } else {
      hs = hs;
    } 
    hs.堅 = 1;
    if (paramBoolean && this.産 != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)hs);
      this.크.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)hs);
  }
  
  public final int 嬉(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    hs hs = (hs)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)hs).leftMargin - paramArrayOfint[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = 旨(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return i + ((ViewGroup.MarginLayoutParams)hs).rightMargin + paramInt1;
  }
  
  public final int 寂(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j);
    i = Math.max(0, k) + i;
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    j = getPaddingLeft();
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + j + i + paramInt2, marginLayoutParams.width);
    paramInt2 = getPaddingTop();
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  public final void 寒() {
    if (this.痛 == null) {
      this.痛 = new 扉(getContext(), null, 2130904093);
      hs hs = new hs();
      ((ク)hs).硬 = this.歩 & 0x70 | 0x800003;
      this.痛.setLayoutParams((ViewGroup.LayoutParams)hs);
    } 
  }
  
  public final boolean 怖(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  final void 恐() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool1;
      OnBackInvokedDispatcher onBackInvokedDispatcher = gs.硬((View)this);
      try try1 = this.탈;
      boolean bool3 = false;
      if (try1 != null && try1.怖 != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      boolean bool2 = bool3;
      if (bool1) {
        bool2 = bool3;
        if (onBackInvokedDispatcher != null) {
          bool2 = bool3;
          if (rw.悲((View)this)) {
            bool2 = bool3;
            if (this.태)
              bool2 = true; 
          } 
        } 
      } 
      if (bool2 && this.탕 == null) {
        if (this.탑 == null)
          this.탑 = gs.堅((Runnable)new fs(this, 1)); 
        gs.熱(onBackInvokedDispatcher, this.탑);
        this.탕 = onBackInvokedDispatcher;
        return;
      } 
      if (!bool2) {
        onBackInvokedDispatcher = this.탕;
        if (onBackInvokedDispatcher != null) {
          gs.暑(onBackInvokedDispatcher, this.탑);
          this.탕 = null;
        } 
      } 
    } 
  }
  
  public final int 悲(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    hs hs = (hs)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)hs).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = 旨(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)hs).leftMargin;
  }
  
  public final int 旨(View paramView, int paramInt) {
    hs hs = (hs)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int j = ((ク)hs).硬 & 0x70;
    int i = j;
    if (j != 16) {
      i = j;
      if (j != 48) {
        i = j;
        if (j != 80)
          i = this.ち & 0x70; 
      } 
    } 
    if (i != 48) {
      if (i != 80) {
        j = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - j - m - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)hs).topMargin;
        if (i >= paramInt) {
          k = n - m - k - i - j;
          m = ((ViewGroup.MarginLayoutParams)hs).bottomMargin;
          paramInt = i;
          if (k < m)
            paramInt = Math.max(0, i - m - k); 
        } 
        return j + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)hs).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  public final void 暑() {
    冷();
    ActionMenuView actionMenuView = this.淋;
    if (actionMenuView.踊 == null) {
      r2 r2 = (r2)actionMenuView.getMenu();
      if (this.탈 == null)
        this.탈 = new try(this); 
      this.淋.setExpandedActionViewsExclusive(true);
      r2.堅(this.탈, this.死);
      恐();
    } 
  }
  
  public final void 淋(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getPaddingLeft();
    i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt1 = getPaddingTop();
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt1 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + 0, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt4 >= 0) {
        paramInt1 = paramInt4;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt4); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  public final void 熱() {
    if (this.興 == null) {
      扉 扉1 = new 扉(getContext(), null, 2130904093);
      this.興 = 扉1;
      扉1.setImageDrawable(this.臭);
      this.興.setContentDescription(this.起);
      hs hs = new hs();
      ((ク)hs).硬 = this.歩 & 0x70 | 0x800003;
      hs.堅 = 2;
      this.興.setLayoutParams((ViewGroup.LayoutParams)hs);
      this.興.setOnClickListener((View.OnClickListener)new 乳(1, this));
    } 
  }
  
  public final void 硬(int paramInt, ArrayList<View> paramArrayList) {
    int j = rw.不((View)this);
    int i = 0;
    if (j == 1) {
      j = 1;
    } else {
      j = 0;
    } 
    int m = getChildCount();
    int k = p31.美(paramInt, rw.不((View)this));
    paramArrayList.clear();
    if (j != 0) {
      for (i = m - 1; i >= 0; i--) {
        View view = getChildAt(i);
        hs hs = (hs)view.getLayoutParams();
        if (hs.堅 == 0 && 怖(view)) {
          paramInt = ((ク)hs).硬;
          m = rw.不((View)this);
          j = p31.美(paramInt, m) & 0x7;
          paramInt = j;
          if (j != 1) {
            paramInt = j;
            if (j != 3) {
              paramInt = j;
              if (j != 5)
                if (m == 1) {
                  paramInt = 5;
                } else {
                  paramInt = 3;
                }  
            } 
          } 
          if (paramInt == k)
            paramArrayList.add(view); 
        } 
      } 
    } else {
      while (i < m) {
        View view = getChildAt(i);
        hs hs = (hs)view.getLayoutParams();
        if (hs.堅 == 0 && 怖(view)) {
          paramInt = ((ク)hs).硬;
          int n = rw.不((View)this);
          j = p31.美(paramInt, n) & 0x7;
          paramInt = j;
          if (j != 1) {
            paramInt = j;
            if (j != 3) {
              paramInt = j;
              if (j != 5)
                if (n == 1) {
                  paramInt = 5;
                } else {
                  paramInt = 3;
                }  
            } 
          } 
          if (paramInt == k)
            paramArrayList.add(view); 
        } 
        i++;
      } 
    } 
  }
  
  public final boolean 苦(View paramView) {
    return (paramView.getParent() == this || this.크.contains(paramView));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */