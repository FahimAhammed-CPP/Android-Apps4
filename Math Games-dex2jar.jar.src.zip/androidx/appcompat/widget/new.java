package androidx.appcompat.widget;

import android.view.View;
import android.view.inputmethod.InputMethodManager;

public final class new implements Runnable {
  public new(SearchView.SearchAutoComplete paramSearchAutoComplete) {}
  
  public final void run() {
    SearchView.SearchAutoComplete searchAutoComplete = this.淋;
    if (searchAutoComplete.起) {
      ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
      searchAutoComplete.起 = false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\new.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */