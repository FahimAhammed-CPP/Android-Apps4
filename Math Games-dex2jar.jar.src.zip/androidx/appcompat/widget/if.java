package androidx.appcompat.widget;

import android.app.SearchableInfo;
import android.content.Intent;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;

public final class if implements View.OnKeyListener {
  public if(SearchView paramSearchView) {}
  
  public final boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool1;
    SearchView searchView = this.淋;
    SearchableInfo searchableInfo = searchView.퇴;
    boolean bool2 = false;
    if (searchableInfo == null)
      return false; 
    SearchView.SearchAutoComplete searchAutoComplete = searchView.踊;
    if (searchAutoComplete.isPopupShowing() && searchAutoComplete.getListSelection() != -1) {
      if (searchView.퇴 == null)
        return false; 
      if (searchView.탕 == null)
        return false; 
      boolean bool = bool2;
      if (paramKeyEvent.getAction() == 0) {
        bool = bool2;
        if (paramKeyEvent.hasNoModifiers()) {
          if (paramInt == 66 || paramInt == 84 || paramInt == 61) {
            searchView.悲(searchAutoComplete.getListSelection());
          } else if (paramInt == 21 || paramInt == 22) {
            if (paramInt == 21) {
              paramInt = 0;
            } else {
              paramInt = searchAutoComplete.length();
            } 
            searchAutoComplete.setSelection(paramInt);
            searchAutoComplete.setListSelection(0);
            searchAutoComplete.clearListSelection();
            searchAutoComplete.硬();
          } else {
            bool = bool2;
            if (paramInt == 19) {
              searchAutoComplete.getListSelection();
              return false;
            } 
            return bool;
          } 
          bool = true;
        } 
      } 
      return bool;
    } 
    if (TextUtils.getTrimmedLength((CharSequence)searchAutoComplete.getText()) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (!bool1 && paramKeyEvent.hasNoModifiers() && paramKeyEvent.getAction() == 1 && paramInt == 66) {
      paramView.cancelLongPress();
      Intent intent = searchView.辛("android.intent.action.SEARCH", null, null, searchAutoComplete.getText().toString());
      searchView.getContext().startActivity(intent);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */