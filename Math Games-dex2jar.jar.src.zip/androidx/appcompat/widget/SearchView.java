package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import y.ak;
import y.bk;
import y.ck;
import y.dk;
import y.fk;
import y.for;
import y.gk;
import y.ik;
import y.oo;
import y.rw;
import y.td;
import y.uj;
import y.vj;
import y.wj;
import y.xj;
import y.yj;
import y.zj;
import y.ほ;
import y.掛;
import y.親;
import y.銀;
import y.굉;

public class SearchView extends ほ implements 掛 {
  public static final dk し;
  
  public final ImageView あ;
  
  public final ImageView か;
  
  public final WeakHashMap た = new WeakHashMap<Object, Object>();
  
  public final ImageView ち;
  
  public final Rect も = new Rect();
  
  public final View ゃ;
  
  public final Rect わ = new Rect();
  
  public final Intent ㅌ;
  
  public final View 噛;
  
  public final View 寝;
  
  public final ImageView 投;
  
  public final vj 者 = new vj(this, 1);
  
  public final int[] 若 = new int[2];
  
  public final View 触;
  
  public gk 赤;
  
  public final SearchAutoComplete 踊;
  
  public final int[] 코 = new int[2];
  
  public final ImageView 쾌;
  
  public final Drawable 크;
  
  public final int 큰;
  
  public final int 키;
  
  public final Intent 타;
  
  public final CharSequence 탁;
  
  public View.OnFocusChangeListener 탄;
  
  public View.OnClickListener 탈;
  
  public boolean 탐;
  
  public boolean 탑;
  
  public 굉 탕;
  
  public boolean 태;
  
  public CharSequence 택;
  
  public boolean 탱;
  
  public boolean 터;
  
  public int 테;
  
  public boolean 토;
  
  public CharSequence 톤;
  
  public boolean 톨;
  
  public int 통;
  
  public SearchableInfo 퇴;
  
  public Bundle 투;
  
  public final vj 퉁 = new vj(this, 0);
  
  static {
    dk dk1;
    if (Build.VERSION.SDK_INT < 29) {
      dk1 = new dk();
    } else {
      dk1 = null;
    } 
    し = dk1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903881);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    do do = new do(this);
    if if = new if(this);
    yj yj = new yj(this);
    zj zj = new zj((View)this, 0);
    親 親 = new 親(1, this);
    uj uj = new uj(0, this);
    int[] arrayOfInt = td.ㅌ;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt, 0);
    dk dk1 = new dk(paramContext, typedArray);
    rw.壊((View)this, paramContext, arrayOfInt, paramAttributeSet, typedArray, paramInt);
    LayoutInflater.from(paramContext).inflate(dk1.不(9, 2131427353), (ViewGroup)this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(2131231284);
    this.踊 = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.寝 = findViewById(2131231280);
    View view2 = findViewById(2131231283);
    this.噛 = view2;
    View view3 = findViewById(2131231331);
    this.触 = view3;
    ImageView imageView1 = (ImageView)findViewById(2131231278);
    this.投 = imageView1;
    ImageView imageView2 = (ImageView)findViewById(2131231281);
    this.あ = imageView2;
    ImageView imageView3 = (ImageView)findViewById(2131231279);
    this.か = imageView3;
    ImageView imageView4 = (ImageView)findViewById(2131231285);
    this.ち = imageView4;
    ImageView imageView5 = (ImageView)findViewById(2131231282);
    this.쾌 = imageView5;
    rw.歩(view2, dk1.冷(10));
    rw.歩(view3, dk1.冷(14));
    imageView1.setImageDrawable(dk1.冷(13));
    imageView2.setImageDrawable(dk1.冷(7));
    imageView3.setImageDrawable(dk1.冷(4));
    imageView4.setImageDrawable(dk1.冷(16));
    imageView5.setImageDrawable(dk1.冷(13));
    this.크 = dk1.冷(12);
    ik.태((View)imageView1, getResources().getString(2131689493));
    this.큰 = dk1.不(15, 2131427352);
    this.키 = dk1.不(5, 0);
    imageView1.setOnClickListener(do);
    imageView3.setOnClickListener(do);
    imageView2.setOnClickListener(do);
    imageView4.setOnClickListener(do);
    searchAutoComplete.setOnClickListener(do);
    searchAutoComplete.addTextChangedListener((TextWatcher)uj);
    searchAutoComplete.setOnEditorActionListener((TextView.OnEditorActionListener)yj);
    searchAutoComplete.setOnItemClickListener((AdapterView.OnItemClickListener)zj);
    searchAutoComplete.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)親);
    searchAutoComplete.setOnKeyListener(if);
    searchAutoComplete.setOnFocusChangeListener((View.OnFocusChangeListener)new wj(0, this));
    setIconifiedByDefault(dk1.硬(8, true));
    paramInt = dk1.暑(1, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.탁 = dk1.ぱ(6);
    this.택 = dk1.ぱ(11);
    paramInt = dk1.旨(3, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = dk1.旨(2, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(dk1.硬(0, true));
    dk1.寂();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.ㅌ = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.타 = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.ゃ = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener((View.OnLayoutChangeListener)new xj(0, this)); 
    興(this.탐);
    痒();
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(2131099702);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(2131099703);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    SearchAutoComplete searchAutoComplete = this.踊;
    searchAutoComplete.setText(paramCharSequence);
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  public final void clearFocus() {
    this.터 = true;
    super.clearFocus();
    SearchAutoComplete searchAutoComplete = this.踊;
    searchAutoComplete.clearFocus();
    searchAutoComplete.setImeVisibility(false);
    this.터 = false;
  }
  
  public int getImeOptions() {
    return this.踊.getImeOptions();
  }
  
  public int getInputType() {
    return this.踊.getInputType();
  }
  
  public int getMaxWidth() {
    return this.테;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.踊.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.택;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.퇴;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.퇴.getHintId()) : this.탁;
  }
  
  public int getSuggestionCommitIconResId() {
    return this.키;
  }
  
  public int getSuggestionRowLayout() {
    return this.큰;
  }
  
  public 굉 getSuggestionsAdapter() {
    return this.탕;
  }
  
  public final void onActionViewCollapsed() {
    SearchAutoComplete searchAutoComplete = this.踊;
    searchAutoComplete.setText("");
    searchAutoComplete.setSelection(searchAutoComplete.length());
    this.톤 = "";
    clearFocus();
    興(true);
    searchAutoComplete.setImeOptions(this.통);
    this.톨 = false;
  }
  
  public final void onActionViewExpanded() {
    if (this.톨)
      return; 
    this.톨 = true;
    SearchAutoComplete searchAutoComplete = this.踊;
    int i = searchAutoComplete.getImeOptions();
    this.통 = i;
    searchAutoComplete.setImeOptions(i | 0x2000000);
    searchAutoComplete.setText("");
    setIconified(false);
  }
  
  public final void onDetachedFromWindow() {
    removeCallbacks((Runnable)this.퉁);
    post((Runnable)this.者);
    super.onDetachedFromWindow();
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      SearchAutoComplete searchAutoComplete = this.踊;
      int[] arrayOfInt1 = this.若;
      searchAutoComplete.getLocationInWindow(arrayOfInt1);
      int[] arrayOfInt2 = this.코;
      getLocationInWindow(arrayOfInt2);
      paramInt1 = arrayOfInt1[1] - arrayOfInt2[1];
      paramInt3 = arrayOfInt1[0] - arrayOfInt2[0];
      int i = searchAutoComplete.getWidth();
      int j = searchAutoComplete.getHeight();
      Rect rect2 = this.わ;
      rect2.set(paramInt3, paramInt1, i + paramInt3, j + paramInt1);
      paramInt1 = rect2.left;
      paramInt3 = rect2.right;
      Rect rect3 = this.も;
      rect3.set(paramInt1, 0, paramInt3, paramInt4 - paramInt2);
      gk gk1 = this.赤;
      if (gk1 == null) {
        gk gk2 = new gk(rect3, rect2, searchAutoComplete);
        this.赤 = gk2;
        setTouchDelegate((TouchDelegate)gk2);
        return;
      } 
      gk1.堅.set(rect3);
      Rect rect1 = gk1.暑;
      rect1.set(rect3);
      paramInt1 = -gk1.冷;
      rect1.inset(paramInt1, paramInt1);
      gk1.熱.set(rect2);
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    if (this.탑) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.테;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.테;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.테;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof fk)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    fk fk = (fk)paramParcelable;
    super.onRestoreInstanceState(((for)fk).淋);
    興(fk.恐);
    requestLayout();
  }
  
  public final Parcelable onSaveInstanceState() {
    fk fk = new fk(super.onSaveInstanceState());
    fk.恐 = this.탑;
    return (Parcelable)fk;
  }
  
  public final void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    post((Runnable)this.퉁);
  }
  
  public final boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.터)
      return false; 
    if (!isFocusable())
      return false; 
    if (!this.탑) {
      boolean bool = this.踊.requestFocus(paramInt, paramRect);
      if (bool)
        興(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.투 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      嬉();
      return;
    } 
    興(false);
    SearchAutoComplete searchAutoComplete = this.踊;
    searchAutoComplete.requestFocus();
    searchAutoComplete.setImeVisibility(true);
    View.OnClickListener onClickListener = this.탈;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.탐 == paramBoolean)
      return; 
    this.탐 = paramBoolean;
    興(paramBoolean);
    痒();
  }
  
  public void setImeOptions(int paramInt) {
    this.踊.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.踊.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.테 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(ak paramak) {}
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.탄 = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(bk parambk) {}
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.탈 = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(ck paramck) {}
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.택 = paramCharSequence;
    痒();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.탱 = paramBoolean;
    굉 굉1 = this.탕;
    if (굉1 instanceof oo) {
      boolean bool;
      oo oo = (oo)굉1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      oo.踊 = bool;
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield 퇴 : Landroid/app/SearchableInfo;
    //   5: aload_0
    //   6: getfield 踊 : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   9: astore #6
    //   11: iconst_1
    //   12: istore #4
    //   14: aconst_null
    //   15: astore #5
    //   17: aload_1
    //   18: ifnull -> 181
    //   21: aload #6
    //   23: aload_1
    //   24: invokevirtual getSuggestThreshold : ()I
    //   27: invokevirtual setThreshold : (I)V
    //   30: aload #6
    //   32: aload_0
    //   33: getfield 퇴 : Landroid/app/SearchableInfo;
    //   36: invokevirtual getImeOptions : ()I
    //   39: invokevirtual setImeOptions : (I)V
    //   42: aload_0
    //   43: getfield 퇴 : Landroid/app/SearchableInfo;
    //   46: invokevirtual getInputType : ()I
    //   49: istore_3
    //   50: iload_3
    //   51: istore_2
    //   52: iload_3
    //   53: bipush #15
    //   55: iand
    //   56: iconst_1
    //   57: if_icmpne -> 88
    //   60: iload_3
    //   61: ldc_w -65537
    //   64: iand
    //   65: istore_3
    //   66: iload_3
    //   67: istore_2
    //   68: aload_0
    //   69: getfield 퇴 : Landroid/app/SearchableInfo;
    //   72: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   75: ifnull -> 88
    //   78: iload_3
    //   79: ldc_w 65536
    //   82: ior
    //   83: ldc_w 524288
    //   86: ior
    //   87: istore_2
    //   88: aload #6
    //   90: iload_2
    //   91: invokevirtual setInputType : (I)V
    //   94: aload_0
    //   95: getfield 탕 : Ly/굉;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_1
    //   104: aconst_null
    //   105: invokevirtual 堅 : (Landroid/database/Cursor;)V
    //   108: aload_0
    //   109: getfield 퇴 : Landroid/app/SearchableInfo;
    //   112: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   115: ifnull -> 177
    //   118: new y/oo
    //   121: dup
    //   122: aload_0
    //   123: invokevirtual getContext : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_0
    //   128: getfield 퇴 : Landroid/app/SearchableInfo;
    //   131: aload_0
    //   132: getfield た : Ljava/util/WeakHashMap;
    //   135: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V
    //   138: astore_1
    //   139: aload_0
    //   140: aload_1
    //   141: putfield 탕 : Ly/굉;
    //   144: aload #6
    //   146: aload_1
    //   147: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   150: aload_0
    //   151: getfield 탕 : Ly/굉;
    //   154: checkcast y/oo
    //   157: astore_1
    //   158: aload_0
    //   159: getfield 탱 : Z
    //   162: ifeq -> 170
    //   165: iconst_2
    //   166: istore_2
    //   167: goto -> 172
    //   170: iconst_1
    //   171: istore_2
    //   172: aload_1
    //   173: iload_2
    //   174: putfield 踊 : I
    //   177: aload_0
    //   178: invokevirtual 痒 : ()V
    //   181: aload_0
    //   182: getfield 퇴 : Landroid/app/SearchableInfo;
    //   185: astore_1
    //   186: aload_1
    //   187: ifnull -> 257
    //   190: aload_1
    //   191: invokevirtual getVoiceSearchEnabled : ()Z
    //   194: ifeq -> 257
    //   197: aload_0
    //   198: getfield 퇴 : Landroid/app/SearchableInfo;
    //   201: invokevirtual getVoiceSearchLaunchWebSearch : ()Z
    //   204: ifeq -> 215
    //   207: aload_0
    //   208: getfield ㅌ : Landroid/content/Intent;
    //   211: astore_1
    //   212: goto -> 233
    //   215: aload #5
    //   217: astore_1
    //   218: aload_0
    //   219: getfield 퇴 : Landroid/app/SearchableInfo;
    //   222: invokevirtual getVoiceSearchLaunchRecognizer : ()Z
    //   225: ifeq -> 233
    //   228: aload_0
    //   229: getfield 타 : Landroid/content/Intent;
    //   232: astore_1
    //   233: aload_1
    //   234: ifnull -> 257
    //   237: aload_0
    //   238: invokevirtual getContext : ()Landroid/content/Context;
    //   241: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   244: aload_1
    //   245: ldc_w 65536
    //   248: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   251: ifnull -> 257
    //   254: goto -> 260
    //   257: iconst_0
    //   258: istore #4
    //   260: aload_0
    //   261: iload #4
    //   263: putfield 토 : Z
    //   266: iload #4
    //   268: ifeq -> 279
    //   271: aload #6
    //   273: ldc_w 'nm'
    //   276: invokevirtual setPrivateImeOptions : (Ljava/lang/String;)V
    //   279: aload_0
    //   280: aload_0
    //   281: getfield 탑 : Z
    //   284: invokevirtual 興 : (Z)V
    //   287: return
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.태 = paramBoolean;
    興(this.탑);
  }
  
  public void setSuggestionsAdapter(굉 param굉) {
    this.탕 = param굉;
    this.踊.setAdapter((ListAdapter)param굉);
  }
  
  public final Intent ぱ(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1107296256);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.투;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int i = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (i != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0) {
      i = paramSearchableInfo.getVoiceMaxResults();
    } else {
      i = 1;
    } 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  public final void 嬉() {
    SearchAutoComplete searchAutoComplete = this.踊;
    if (TextUtils.isEmpty((CharSequence)searchAutoComplete.getText())) {
      if (this.탐) {
        clearFocus();
        興(true);
        return;
      } 
    } else {
      searchAutoComplete.setText("");
      searchAutoComplete.requestFocus();
      searchAutoComplete.setImeVisibility(true);
    } 
  }
  
  public final void 寂(int paramInt) {
    Editable editable = this.踊.getText();
    Cursor cursor = this.탕.恐;
    if (cursor == null)
      return; 
    if (cursor.moveToPosition(paramInt)) {
      String str = this.탕.熱(cursor);
      if (str != null) {
        setQuery(str);
        return;
      } 
      setQuery((CharSequence)editable);
      return;
    } 
    setQuery((CharSequence)editable);
  }
  
  public final void 怖() {
    SearchAutoComplete searchAutoComplete = this.踊;
    Editable editable = searchAutoComplete.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      if (this.퇴 != null) {
        Intent intent = 辛("android.intent.action.SEARCH", null, null, editable.toString());
        getContext().startActivity(intent);
      } 
      searchAutoComplete.setImeVisibility(false);
      searchAutoComplete.dismissDropDown();
    } 
  }
  
  public final void 恐() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.踊.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.탐 && !this.톨) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    ImageView imageView = this.か;
    imageView.setVisibility(b1);
    Drawable drawable = imageView.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  public final void 悲(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 탕 : Ly/굉;
    //   4: getfield 恐 : Landroid/database/Cursor;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 263
    //   14: aload #6
    //   16: iload_1
    //   17: invokeinterface moveToPosition : (I)Z
    //   22: ifeq -> 263
    //   25: aconst_null
    //   26: astore #5
    //   28: getstatic y/oo.ゃ : I
    //   31: istore_1
    //   32: aload #6
    //   34: aload #6
    //   36: ldc_w 'suggest_intent_action'
    //   39: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   44: invokestatic 怖 : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   47: astore_3
    //   48: aload_3
    //   49: astore_2
    //   50: aload_3
    //   51: ifnonnull -> 293
    //   54: aload_0
    //   55: getfield 퇴 : Landroid/app/SearchableInfo;
    //   58: invokevirtual getSuggestIntentAction : ()Ljava/lang/String;
    //   61: astore_2
    //   62: goto -> 293
    //   65: aload #6
    //   67: aload #6
    //   69: ldc_w 'suggest_intent_data'
    //   72: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   77: invokestatic 怖 : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   80: astore #4
    //   82: aload #4
    //   84: astore_2
    //   85: aload #4
    //   87: ifnonnull -> 98
    //   90: aload_0
    //   91: getfield 퇴 : Landroid/app/SearchableInfo;
    //   94: invokevirtual getSuggestIntentData : ()Ljava/lang/String;
    //   97: astore_2
    //   98: aload_2
    //   99: astore #4
    //   101: aload_2
    //   102: ifnull -> 306
    //   105: aload #6
    //   107: aload #6
    //   109: ldc_w 'suggest_intent_data_id'
    //   112: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   117: invokestatic 怖 : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   120: astore #7
    //   122: aload_2
    //   123: astore #4
    //   125: aload #7
    //   127: ifnull -> 306
    //   130: new java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: astore #4
    //   139: aload #4
    //   141: aload_2
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: aload #4
    //   148: ldc_w '/'
    //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: aload #4
    //   157: aload #7
    //   159: invokestatic encode : (Ljava/lang/String;)Ljava/lang/String;
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload #4
    //   168: invokevirtual toString : ()Ljava/lang/String;
    //   171: astore #4
    //   173: goto -> 306
    //   176: aload #4
    //   178: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   181: astore_2
    //   182: aload #6
    //   184: aload #6
    //   186: ldc_w 'suggest_intent_query'
    //   189: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   194: invokestatic 怖 : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   197: astore #4
    //   199: aload_0
    //   200: aload_3
    //   201: aload_2
    //   202: aload #6
    //   204: aload #6
    //   206: ldc_w 'suggest_intent_extra_data'
    //   209: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   214: invokestatic 怖 : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   217: aload #4
    //   219: invokevirtual 辛 : (Ljava/lang/String;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   222: astore_2
    //   223: goto -> 240
    //   226: aload #6
    //   228: invokeinterface getPosition : ()I
    //   233: pop
    //   234: aload #5
    //   236: astore_2
    //   237: goto -> 240
    //   240: aload_2
    //   241: ifnonnull -> 247
    //   244: goto -> 263
    //   247: aload_0
    //   248: invokevirtual getContext : ()Landroid/content/Context;
    //   251: aload_2
    //   252: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   255: goto -> 263
    //   258: aload_2
    //   259: invokevirtual toString : ()Ljava/lang/String;
    //   262: pop
    //   263: aload_0
    //   264: getfield 踊 : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   267: astore_2
    //   268: aload_2
    //   269: iconst_0
    //   270: invokevirtual setImeVisibility : (Z)V
    //   273: aload_2
    //   274: invokevirtual dismissDropDown : ()V
    //   277: return
    //   278: astore_2
    //   279: goto -> 226
    //   282: astore_2
    //   283: aload #5
    //   285: astore_2
    //   286: goto -> 240
    //   289: astore_3
    //   290: goto -> 258
    //   293: aload_2
    //   294: astore_3
    //   295: aload_2
    //   296: ifnonnull -> 65
    //   299: ldc_w 'android.intent.action.SEARCH'
    //   302: astore_3
    //   303: goto -> 65
    //   306: aload #4
    //   308: ifnonnull -> 176
    //   311: aconst_null
    //   312: astore_2
    //   313: goto -> 182
    // Exception table:
    //   from	to	target	type
    //   28	48	278	java/lang/RuntimeException
    //   54	62	278	java/lang/RuntimeException
    //   65	82	278	java/lang/RuntimeException
    //   90	98	278	java/lang/RuntimeException
    //   105	122	278	java/lang/RuntimeException
    //   130	173	278	java/lang/RuntimeException
    //   176	182	278	java/lang/RuntimeException
    //   182	223	278	java/lang/RuntimeException
    //   226	234	282	java/lang/RuntimeException
    //   247	255	289	java/lang/RuntimeException
  }
  
  public final void 淋(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public final void 痒() {
    SpannableStringBuilder spannableStringBuilder;
    CharSequence charSequence2 = getQueryHint();
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    boolean bool = this.탐;
    SearchAutoComplete searchAutoComplete = this.踊;
    charSequence2 = charSequence1;
    if (bool) {
      Drawable drawable = this.크;
      if (drawable == null) {
        charSequence2 = charSequence1;
      } else {
        int i = (int)(searchAutoComplete.getTextSize() * 1.25D);
        drawable.setBounds(0, 0, i, i);
        spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
        spannableStringBuilder.append(charSequence1);
      } 
    } 
    searchAutoComplete.setHint((CharSequence)spannableStringBuilder);
  }
  
  public final void 痛() {
    int[] arrayOfInt;
    if (this.踊.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.噛.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.触.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public final void 臭() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 태 : Z
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield 토 : Z
    //   15: ifeq -> 30
    //   18: aload_0
    //   19: getfield 탑 : Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 63
    //   36: iload_2
    //   37: istore_1
    //   38: aload_0
    //   39: getfield あ : Landroid/widget/ImageView;
    //   42: invokevirtual getVisibility : ()I
    //   45: ifeq -> 66
    //   48: aload_0
    //   49: getfield ち : Landroid/widget/ImageView;
    //   52: invokevirtual getVisibility : ()I
    //   55: ifne -> 63
    //   58: iload_2
    //   59: istore_1
    //   60: goto -> 66
    //   63: bipush #8
    //   65: istore_1
    //   66: aload_0
    //   67: getfield 触 : Landroid/view/View;
    //   70: iload_1
    //   71: invokevirtual setVisibility : (I)V
    //   74: return
  }
  
  public final void 興(boolean paramBoolean) {
    this.탑 = paramBoolean;
    byte b2 = 8;
    if (paramBoolean) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    int i = TextUtils.isEmpty((CharSequence)this.踊.getText()) ^ true;
    this.投.setVisibility(b1);
    起(i);
    if (paramBoolean) {
      b1 = 8;
    } else {
      b1 = 0;
    } 
    this.寝.setVisibility(b1);
    ImageView imageView = this.쾌;
    if (imageView.getDrawable() == null || this.탐) {
      b1 = 8;
    } else {
      b1 = 0;
    } 
    imageView.setVisibility(b1);
    恐();
    byte b1 = b2;
    if (this.토) {
      b1 = b2;
      if (!this.탑) {
        b1 = b2;
        if ((i ^ 0x1) != 0) {
          this.あ.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.ち.setVisibility(b1);
    臭();
  }
  
  public final void 苦() {
    int i = Build.VERSION.SDK_INT;
    SearchAutoComplete searchAutoComplete = this.踊;
    if (i >= 29) {
      for.硬((AutoCompleteTextView)searchAutoComplete);
      return;
    } 
    dk dk1 = し;
    dk1.getClass();
    dk.悲();
    Object object2 = dk1.硬;
    if ((Method)object2 != null)
      try {
        ((Method)object2).invoke(searchAutoComplete, new Object[0]);
      } catch (Exception exception) {} 
    dk1.getClass();
    dk.悲();
    Object object1 = dk1.堅;
    if ((Method)object1 != null)
      try {
        ((Method)object1).invoke(searchAutoComplete, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public final void 起(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 태 : Z
    //   4: istore #4
    //   6: iload #4
    //   8: ifeq -> 68
    //   11: iconst_0
    //   12: istore_3
    //   13: iload #4
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield 토 : Z
    //   22: ifeq -> 37
    //   25: aload_0
    //   26: getfield 탑 : Z
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: ifeq -> 68
    //   43: aload_0
    //   44: invokevirtual hasFocus : ()Z
    //   47: ifeq -> 68
    //   50: iload_3
    //   51: istore_2
    //   52: iload_1
    //   53: ifne -> 71
    //   56: aload_0
    //   57: getfield 토 : Z
    //   60: ifne -> 68
    //   63: iload_3
    //   64: istore_2
    //   65: goto -> 71
    //   68: bipush #8
    //   70: istore_2
    //   71: aload_0
    //   72: getfield あ : Landroid/widget/ImageView;
    //   75: iload_2
    //   76: invokevirtual setVisibility : (I)V
    //   79: return
  }
  
  public final Intent 辛(String paramString1, Uri paramUri, String paramString2, String paramString3) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.톤);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.투;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    intent.setComponent(this.퇴.getSearchActivity());
    return intent;
  }
  
  public static class SearchAutoComplete extends 銀 {
    public int 痒 = getThreshold();
    
    public SearchView 臭;
    
    public final new 興 = new new(this);
    
    public boolean 起;
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    public final boolean enoughToFilter() {
      return (this.痒 <= 0 || super.enoughToFilter());
    }
    
    public final InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.起) {
        new new1 = this.興;
        removeCallbacks(new1);
        post(new1);
      } 
      return inputConnection;
    }
    
    public final void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    public final void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      SearchView searchView = this.臭;
      searchView.興(searchView.탑);
      searchView.post((Runnable)searchView.퉁);
      if (searchView.踊.hasFocus())
        searchView.苦(); 
    }
    
    public final boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.臭.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public final void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.臭.hasFocus() && getVisibility() == 0) {
        boolean bool = true;
        this.起 = true;
        Context context = getContext();
        dk dk = SearchView.し;
        if ((context.getResources().getConfiguration()).orientation != 2)
          bool = false; 
        if (bool)
          硬(); 
      } 
    }
    
    public final void performCompletion() {}
    
    public final void replaceText(CharSequence param1CharSequence) {}
    
    public void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      new new1 = this.興;
      if (!param1Boolean) {
        this.起 = false;
        removeCallbacks(new1);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.起 = false;
        removeCallbacks(new1);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.起 = true;
    }
    
    public void setSearchView(SearchView param1SearchView) {
      this.臭 = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.痒 = param1Int;
    }
    
    public final void 硬() {
      if (Build.VERSION.SDK_INT >= 29) {
        for.堅(this, 1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        dk dk = SearchView.し;
        dk.getClass();
        dk.悲();
        Object object = dk.熱;
        if ((Method)object != null)
          try {
            ((Method)object).invoke(this, new Object[] { Boolean.TRUE });
            return;
          } catch (Exception exception) {
            return;
          }  
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */