package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import y.rw;
import y.td;

public class ButtonBarLayout extends LinearLayout {
  public boolean 怖;
  
  public int 恐 = -1;
  
  public boolean 淋;
  
  public ButtonBarLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    int[] arrayOfInt = td.ゃ;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt);
    rw.壊((View)this, paramContext, arrayOfInt, paramAttributeSet, typedArray, 0);
    this.淋 = typedArray.getBoolean(0, true);
    typedArray.recycle();
    if (getOrientation() == 1)
      setStacked(this.淋); 
  }
  
  private void setStacked(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getSize : (I)I
    //   4: istore_3
    //   5: aload_0
    //   6: getfield 淋 : Z
    //   9: istore #8
    //   11: iconst_0
    //   12: istore #6
    //   14: iload #8
    //   16: ifeq -> 44
    //   19: iload_3
    //   20: aload_0
    //   21: getfield 恐 : I
    //   24: if_icmple -> 39
    //   27: aload_0
    //   28: getfield 怖 : Z
    //   31: ifeq -> 39
    //   34: aload_0
    //   35: iconst_0
    //   36: invokespecial setStacked : (Z)V
    //   39: aload_0
    //   40: iload_3
    //   41: putfield 恐 : I
    //   44: aload_0
    //   45: getfield 怖 : Z
    //   48: ifne -> 73
    //   51: iload_1
    //   52: invokestatic getMode : (I)I
    //   55: ldc 1073741824
    //   57: if_icmpne -> 73
    //   60: iload_3
    //   61: ldc -2147483648
    //   63: invokestatic makeMeasureSpec : (II)I
    //   66: istore #4
    //   68: iconst_1
    //   69: istore_3
    //   70: goto -> 78
    //   73: iload_1
    //   74: istore #4
    //   76: iconst_0
    //   77: istore_3
    //   78: aload_0
    //   79: iload #4
    //   81: iload_2
    //   82: invokespecial onMeasure : (II)V
    //   85: iload_3
    //   86: istore #5
    //   88: aload_0
    //   89: getfield 淋 : Z
    //   92: ifeq -> 142
    //   95: iload_3
    //   96: istore #5
    //   98: aload_0
    //   99: getfield 怖 : Z
    //   102: ifne -> 142
    //   105: aload_0
    //   106: invokevirtual getMeasuredWidthAndState : ()I
    //   109: ldc -16777216
    //   111: iand
    //   112: ldc 16777216
    //   114: if_icmpne -> 123
    //   117: iconst_1
    //   118: istore #4
    //   120: goto -> 126
    //   123: iconst_0
    //   124: istore #4
    //   126: iload_3
    //   127: istore #5
    //   129: iload #4
    //   131: ifeq -> 142
    //   134: aload_0
    //   135: iconst_1
    //   136: invokespecial setStacked : (Z)V
    //   139: iconst_1
    //   140: istore #5
    //   142: iload #5
    //   144: ifeq -> 153
    //   147: aload_0
    //   148: iload_1
    //   149: iload_2
    //   150: invokespecial onMeasure : (II)V
    //   153: aload_0
    //   154: invokevirtual getChildCount : ()I
    //   157: istore #4
    //   159: iconst_0
    //   160: istore_3
    //   161: iconst_m1
    //   162: istore #5
    //   164: iload_3
    //   165: iload #4
    //   167: if_icmpge -> 194
    //   170: aload_0
    //   171: iload_3
    //   172: invokevirtual getChildAt : (I)Landroid/view/View;
    //   175: invokevirtual getVisibility : ()I
    //   178: ifne -> 187
    //   181: iload_3
    //   182: istore #4
    //   184: goto -> 197
    //   187: iload_3
    //   188: iconst_1
    //   189: iadd
    //   190: istore_3
    //   191: goto -> 161
    //   194: iconst_m1
    //   195: istore #4
    //   197: iload #6
    //   199: istore_3
    //   200: iload #4
    //   202: iflt -> 349
    //   205: aload_0
    //   206: iload #4
    //   208: invokevirtual getChildAt : (I)Landroid/view/View;
    //   211: astore #9
    //   213: aload #9
    //   215: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   218: checkcast android/widget/LinearLayout$LayoutParams
    //   221: astore #10
    //   223: aload_0
    //   224: invokevirtual getPaddingTop : ()I
    //   227: istore_3
    //   228: iconst_0
    //   229: aload #9
    //   231: invokevirtual getMeasuredHeight : ()I
    //   234: iload_3
    //   235: iadd
    //   236: aload #10
    //   238: getfield topMargin : I
    //   241: iadd
    //   242: aload #10
    //   244: getfield bottomMargin : I
    //   247: iadd
    //   248: iadd
    //   249: istore #6
    //   251: aload_0
    //   252: getfield 怖 : Z
    //   255: ifeq -> 339
    //   258: iload #4
    //   260: iconst_1
    //   261: iadd
    //   262: istore_3
    //   263: aload_0
    //   264: invokevirtual getChildCount : ()I
    //   267: istore #7
    //   269: iload #5
    //   271: istore #4
    //   273: iload_3
    //   274: iload #7
    //   276: if_icmpge -> 303
    //   279: aload_0
    //   280: iload_3
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: invokevirtual getVisibility : ()I
    //   287: ifne -> 296
    //   290: iload_3
    //   291: istore #4
    //   293: goto -> 303
    //   296: iload_3
    //   297: iconst_1
    //   298: iadd
    //   299: istore_3
    //   300: goto -> 269
    //   303: iload #6
    //   305: istore_3
    //   306: iload #4
    //   308: iflt -> 349
    //   311: aload_0
    //   312: iload #4
    //   314: invokevirtual getChildAt : (I)Landroid/view/View;
    //   317: invokevirtual getPaddingTop : ()I
    //   320: aload_0
    //   321: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   324: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   327: getfield density : F
    //   330: ldc 16.0
    //   332: fmul
    //   333: f2i
    //   334: iadd
    //   335: istore_3
    //   336: goto -> 344
    //   339: aload_0
    //   340: invokevirtual getPaddingBottom : ()I
    //   343: istore_3
    //   344: iload #6
    //   346: iload_3
    //   347: iadd
    //   348: istore_3
    //   349: getstatic y/rw.硬 : Ljava/util/WeakHashMap;
    //   352: astore #9
    //   354: getstatic android/os/Build$VERSION.SDK_INT : I
    //   357: istore #4
    //   359: aload_0
    //   360: invokestatic 暑 : (Landroid/view/View;)I
    //   363: iload_3
    //   364: if_icmpeq -> 382
    //   367: aload_0
    //   368: iload_3
    //   369: invokevirtual setMinimumHeight : (I)V
    //   372: iload_2
    //   373: ifne -> 382
    //   376: aload_0
    //   377: iload_1
    //   378: iload_2
    //   379: invokespecial onMeasure : (II)V
    //   382: return
  }
  
  public void setAllowStacking(boolean paramBoolean) {
    if (this.淋 != paramBoolean) {
      this.淋 = paramBoolean;
      if (!paramBoolean && this.怖)
        setStacked(false); 
      requestLayout();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ButtonBarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */