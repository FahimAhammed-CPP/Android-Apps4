package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import y.cy;
import y.do;
import y.h3;
import y.hy;
import y.p3;
import y.r2;
import y.r3;
import y.rw;
import y.td;
import y.yx;
import y.ツ;
import y.蚊;
import y.蛞;
import y.蜘;

public class ActionBarContextView extends ViewGroup {
  public final int 噛;
  
  public View 壊;
  
  public final int 寝;
  
  public View 帰;
  
  public final Context 怖;
  
  public ActionMenuView 恐;
  
  public final int 投;
  
  public LinearLayout 歩;
  
  public CharSequence 死;
  
  public TextView 泳;
  
  public final do 淋;
  
  public CharSequence 産;
  
  public int 痒;
  
  public ツ 痛;
  
  public yx 臭;
  
  public boolean 興;
  
  public boolean 触;
  
  public boolean 起;
  
  public TextView 踊;
  
  public View 返;
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130903070
    //   5: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   8: aload_0
    //   9: new y/do
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Landroidx/appcompat/widget/ActionBarContextView;)V
    //   17: putfield 淋 : Ly/do;
    //   20: new android/util/TypedValue
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #4
    //   29: aload_1
    //   30: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   33: ldc 2130903044
    //   35: aload #4
    //   37: iconst_1
    //   38: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   41: ifeq -> 72
    //   44: aload #4
    //   46: getfield resourceId : I
    //   49: ifeq -> 72
    //   52: aload_0
    //   53: new android/view/ContextThemeWrapper
    //   56: dup
    //   57: aload_1
    //   58: aload #4
    //   60: getfield resourceId : I
    //   63: invokespecial <init> : (Landroid/content/Context;I)V
    //   66: putfield 怖 : Landroid/content/Context;
    //   69: goto -> 77
    //   72: aload_0
    //   73: aload_1
    //   74: putfield 怖 : Landroid/content/Context;
    //   77: aload_1
    //   78: aload_2
    //   79: getstatic y/td.寝 : [I
    //   82: ldc 2130903070
    //   84: iconst_0
    //   85: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   88: astore_2
    //   89: aload_2
    //   90: iconst_0
    //   91: invokevirtual hasValue : (I)Z
    //   94: ifeq -> 117
    //   97: aload_2
    //   98: iconst_0
    //   99: iconst_0
    //   100: invokevirtual getResourceId : (II)I
    //   103: istore_3
    //   104: iload_3
    //   105: ifeq -> 117
    //   108: aload_1
    //   109: iload_3
    //   110: invokestatic 痛 : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   113: astore_1
    //   114: goto -> 123
    //   117: aload_2
    //   118: iconst_0
    //   119: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   122: astore_1
    //   123: aload_0
    //   124: aload_1
    //   125: invokestatic 歩 : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   128: aload_0
    //   129: aload_2
    //   130: iconst_5
    //   131: iconst_0
    //   132: invokevirtual getResourceId : (II)I
    //   135: putfield 寝 : I
    //   138: aload_0
    //   139: aload_2
    //   140: iconst_4
    //   141: iconst_0
    //   142: invokevirtual getResourceId : (II)I
    //   145: putfield 噛 : I
    //   148: aload_0
    //   149: aload_2
    //   150: iconst_3
    //   151: iconst_0
    //   152: invokevirtual getLayoutDimension : (II)I
    //   155: putfield 痒 : I
    //   158: aload_0
    //   159: aload_2
    //   160: iconst_2
    //   161: ldc 2131427333
    //   163: invokevirtual getResourceId : (II)I
    //   166: putfield 投 : I
    //   169: aload_2
    //   170: invokevirtual recycle : ()V
    //   173: return
  }
  
  public static int 寒(View paramView, int paramInt1, int paramInt2) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - 0);
  }
  
  public static int 辛(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 = (paramInt3 - j) / 2 + paramInt2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public int getAnimatedVisibility() {
    return (this.臭 != null) ? this.淋.堅 : getVisibility();
  }
  
  public int getContentHeight() {
    return this.痒;
  }
  
  public CharSequence getSubtitle() {
    return this.死;
  }
  
  public CharSequence getTitle() {
    return this.産;
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    ツ ツ1 = this.痛;
    if (ツ1 != null) {
      ツ1.暑();
      蚊 蚊 = this.痛.投;
      if (蚊 != null && 蚊.堅())
        ((h3)蚊).辛.dismiss(); 
    } 
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = hy.硬((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.壊;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.壊.getLayoutParams();
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.rightMargin;
        } else {
          paramInt4 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.leftMargin;
        } else {
          paramInt2 = marginLayoutParams.rightMargin;
        } 
        if (paramBoolean) {
          paramInt4 = i - paramInt4;
        } else {
          paramInt4 = i + paramInt4;
        } 
        paramInt4 = 辛(this.壊, paramInt4, j, k, paramBoolean) + paramInt4;
        if (paramBoolean) {
          paramInt2 = paramInt4 - paramInt2;
        } else {
          paramInt2 = paramInt4 + paramInt2;
        } 
      } 
    } 
    LinearLayout linearLayout = this.歩;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.返 == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + 辛((View)this.歩, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.返;
    if (view1 != null)
      辛(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.恐;
    if (actionMenuView != null)
      辛((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.痒;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        paramInt1 = getPaddingTop();
        int i1 = getPaddingBottom() + paramInt1;
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.壊;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = 寒(view2, paramInt1, k);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.壊.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.恐;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = 寒((View)this.恐, paramInt2, k); 
        } 
        LinearLayout linearLayout = this.歩;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.返 == null)
            if (this.触) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.歩.measure(paramInt2, k);
              int i2 = this.歩.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.歩;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = 寒((View)linearLayout, paramInt1, k);
            }  
        } 
        View view1 = this.返;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.返.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.痒 <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
    } 
    throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
  }
  
  public void setContentHeight(int paramInt) {
    this.痒 = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.返;
    if (view != null)
      removeView(view); 
    this.返 = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.歩;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.歩 = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.死 = paramCharSequence;
    暑();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.産 = paramCharSequence;
    暑();
    rw.返((View)this, paramCharSequence);
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.触)
      requestLayout(); 
    this.触 = paramBoolean;
  }
  
  public final boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public final void ぱ(int paramInt) {
    if (paramInt != getVisibility()) {
      yx yx1 = this.臭;
      if (yx1 != null)
        yx1.堅(); 
      super.setVisibility(paramInt);
    } 
  }
  
  public final boolean 不(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.起 = false; 
    if (!this.起) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.起 = true; 
    } 
    if (i == 1 || i == 3)
      this.起 = false; 
    return true;
  }
  
  public final void 冷() {
    removeAllViews();
    this.返 = null;
    this.恐 = null;
    this.痛 = null;
    View view = this.帰;
    if (view != null)
      view.setOnClickListener(null); 
  }
  
  public final boolean 旨(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.興 = false; 
    if (!this.興) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.興 = true; 
    } 
    if (i == 10 || i == 3)
      this.興 = false; 
    return true;
  }
  
  public final void 暑() {
    if (this.歩 == null) {
      LayoutInflater.from(getContext()).inflate(2131427328, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.歩 = linearLayout1;
      this.泳 = (TextView)linearLayout1.findViewById(2131230777);
      this.踊 = (TextView)this.歩.findViewById(2131230776);
      b = this.寝;
      if (b != 0)
        this.泳.setTextAppearance(getContext(), b); 
      b = this.噛;
      if (b != 0)
        this.踊.setTextAppearance(getContext(), b); 
    } 
    this.泳.setText(this.産);
    this.踊.setText(this.死);
    boolean bool1 = TextUtils.isEmpty(this.産);
    int i = TextUtils.isEmpty(this.死) ^ true;
    TextView textView = this.踊;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.歩;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.歩.getParent() == null)
      addView((View)this.歩); 
  }
  
  public final void 熱(蛞 param蛞) {
    View view = this.壊;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.投, this, false);
      this.壊 = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.壊);
    } 
    view = this.壊.findViewById(2131230786);
    this.帰 = view;
    view.setOnClickListener((View.OnClickListener)new 蜘(this, param蛞));
    r2 r2 = param蛞.熱();
    ツ ツ1 = this.痛;
    if (ツ1 != null) {
      ツ1.暑();
      蚊 蚊 = ツ1.投;
      if (蚊 != null && 蚊.堅())
        ((h3)蚊).辛.dismiss(); 
    } 
    ツ1 = new ツ(getContext());
    this.痛 = ツ1;
    ツ1.帰 = true;
    ツ1.返 = true;
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    r2.堅((p3)this.痛, this.怖);
    ツ ツ2 = this.痛;
    r3 r31 = ツ2.興;
    if (r31 == null) {
      r3 r3 = (r3)ツ2.痛.inflate(ツ2.臭, this, false);
      ツ2.興 = r3;
      r3.堅(ツ2.恐);
      ツ2.冷();
    } 
    r3 r32 = ツ2.興;
    if (r31 != r32)
      ((ActionMenuView)r32).setPresenter(ツ2); 
    ActionMenuView actionMenuView = (ActionMenuView)r32;
    this.恐 = actionMenuView;
    rw.歩((View)actionMenuView, null);
    addView((View)this.恐, layoutParams);
  }
  
  public final void 美(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, td.歩, 2130903047, 0);
    setContentHeight(typedArray.getLayoutDimension(13, 0));
    typedArray.recycle();
    ツ ツ1 = this.痛;
    if (ツ1 != null) {
      Configuration configuration = ツ1.怖.getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      if (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) {
        i = 5;
      } else if (i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) {
        i = 4;
      } else if (i >= 360) {
        i = 3;
      } else {
        i = 2;
      } 
      ツ1.踊 = i;
      r2 r2 = ツ1.恐;
      if (r2 != null)
        r2.淋(true); 
    } 
  }
  
  public final yx 苦(int paramInt, long paramLong) {
    yx yx1 = this.臭;
    if (yx1 != null)
      yx1.堅(); 
    do do1 = this.淋;
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      yx yx3 = rw.硬((View)this);
      yx3.硬(1.0F);
      yx3.熱(paramLong);
      do1.熱.臭 = yx3;
      do1.堅 = paramInt;
      yx3.暑((cy)do1);
      return yx3;
    } 
    yx yx2 = rw.硬((View)this);
    yx2.硬(0.0F);
    yx2.熱(paramLong);
    do1.熱.臭 = yx2;
    do1.堅 = paramInt;
    yx2.暑((cy)do1);
    return yx2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */