package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import y.q2;
import y.q3;
import y.r2;
import y.td;
import y.x2;
import y.ム;
import y.服;
import y.蝿;
import y.蠅;

public class ActionMenuItemView extends 服 implements q3, View.OnClickListener, ム {
  public final int 噛;
  
  public q2 壊;
  
  public int 寝;
  
  public 蝿 帰;
  
  public boolean 歩;
  
  public Drawable 死;
  
  public boolean 泳;
  
  public CharSequence 産;
  
  public x2 興;
  
  public final int 踊;
  
  public 蠅 返;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    Resources resources = paramContext.getResources();
    this.歩 = 興();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, td.踊, 0, 0);
    this.踊 = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
    this.噛 = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.寝 = -1;
    setSaveEnabled(false);
  }
  
  public CharSequence getAccessibilityClassName() {
    return Button.class.getName();
  }
  
  public x2 getItemData() {
    return this.興;
  }
  
  public final void onClick(View paramView) {
    q2 q21 = this.壊;
    if (q21 != null)
      q21.硬(this.興); 
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.歩 = 興();
    産();
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = 起();
    if (bool) {
      int m = this.寝;
      if (m >= 0)
        super.setPadding(m, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int j = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int k = getMeasuredWidth();
    int i = this.踊;
    if (j == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, i);
    } else {
      paramInt1 = i;
    } 
    if (j != 1073741824 && i > 0 && k < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.死 != null)
      super.setPadding((getMeasuredWidth() - this.死.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.興.hasSubMenu()) {
      蝿 蝿1 = this.帰;
      if (蝿1 != null && 蝿1.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.泳 != paramBoolean) {
      this.泳 = paramBoolean;
      x2 x21 = this.興;
      if (x21 != null) {
        r2 r2 = x21.悲;
        r2.ぱ = true;
        r2.淋(true);
      } 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.死 = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.噛;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    産();
  }
  
  public void setItemInvoker(q2 paramq2) {
    this.壊 = paramq2;
  }
  
  public final void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.寝 = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(蠅 param蠅) {
    this.返 = param蠅;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.産 = paramCharSequence;
    産();
  }
  
  public final boolean 堅() {
    return (起() && this.興.getIcon() == null);
  }
  
  public final void 熱(x2 paramx2) {
    byte b;
    this.興 = paramx2;
    setIcon(paramx2.getIcon());
    setTitle(paramx2.getTitleCondensed());
    setId(paramx2.硬);
    if (paramx2.isVisible()) {
      b = 0;
    } else {
      b = 8;
    } 
    setVisibility(b);
    setEnabled(paramx2.isEnabled());
    if (paramx2.hasSubMenu() && this.帰 == null)
      this.帰 = new 蝿(this); 
  }
  
  public final void 産() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 産 : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield 死 : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 66
    //   19: aload_0
    //   20: getfield 興 : Ly/x2;
    //   23: getfield 死 : I
    //   26: iconst_4
    //   27: iand
    //   28: iconst_4
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 64
    //   43: iload_2
    //   44: istore_1
    //   45: aload_0
    //   46: getfield 歩 : Z
    //   49: ifne -> 66
    //   52: aload_0
    //   53: getfield 泳 : Z
    //   56: ifeq -> 64
    //   59: iload_2
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_3
    //   67: iconst_1
    //   68: ixor
    //   69: iload_1
    //   70: iand
    //   71: istore_1
    //   72: aconst_null
    //   73: astore #5
    //   75: iload_1
    //   76: ifeq -> 88
    //   79: aload_0
    //   80: getfield 産 : Ljava/lang/CharSequence;
    //   83: astore #4
    //   85: goto -> 91
    //   88: aconst_null
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   97: aload_0
    //   98: getfield 興 : Ly/x2;
    //   101: getfield 怖 : Ljava/lang/CharSequence;
    //   104: astore #4
    //   106: aload #4
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifeq -> 142
    //   114: iload_1
    //   115: ifeq -> 124
    //   118: aconst_null
    //   119: astore #4
    //   121: goto -> 133
    //   124: aload_0
    //   125: getfield 興 : Ly/x2;
    //   128: getfield 冷 : Ljava/lang/CharSequence;
    //   131: astore #4
    //   133: aload_0
    //   134: aload #4
    //   136: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   139: goto -> 148
    //   142: aload_0
    //   143: aload #4
    //   145: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   148: aload_0
    //   149: getfield 興 : Ly/x2;
    //   152: getfield 恐 : Ljava/lang/CharSequence;
    //   155: astore #4
    //   157: aload #4
    //   159: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   162: ifeq -> 192
    //   165: iload_1
    //   166: ifeq -> 176
    //   169: aload #5
    //   171: astore #4
    //   173: goto -> 185
    //   176: aload_0
    //   177: getfield 興 : Ly/x2;
    //   180: getfield 冷 : Ljava/lang/CharSequence;
    //   183: astore #4
    //   185: aload_0
    //   186: aload #4
    //   188: invokestatic 태 : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   191: return
    //   192: aload_0
    //   193: aload #4
    //   195: invokestatic 태 : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   198: return
  }
  
  public final boolean 硬() {
    return 起();
  }
  
  public final boolean 興() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  public final boolean 起() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */