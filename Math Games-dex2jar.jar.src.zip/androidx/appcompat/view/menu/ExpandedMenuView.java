package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import y.dk;
import y.q2;
import y.r2;
import y.r3;
import y.x2;

public final class ExpandedMenuView extends ListView implements q2, r3, AdapterView.OnItemClickListener {
  public static final int[] 怖 = new int[] { 16842964, 16843049 };
  
  public r2 淋;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    dk dk = new dk(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, 怖, 16842868, 0));
    if (dk.苦(0))
      setBackgroundDrawable(dk.冷(0)); 
    if (dk.苦(1))
      setDivider(dk.冷(1)); 
    dk.寂();
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    硬((x2)getAdapter().getItem(paramInt));
  }
  
  public final void 堅(r2 paramr2) {
    this.淋 = paramr2;
  }
  
  public final boolean 硬(x2 paramx2) {
    return this.淋.怖((MenuItem)paramx2, null, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */