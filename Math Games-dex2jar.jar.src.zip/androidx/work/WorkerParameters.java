package androidx.work;

import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import y.d10;
import y.ha;
import y.iq;
import y.o10;
import y.p10;
import y.x00;
import y.茎;
import y.급;
import y.습;

public final class WorkerParameters {
  public final ha 不;
  
  public final int 冷;
  
  public final 급 堅;
  
  public final Executor 寒;
  
  public final p10 旨;
  
  public final 茎 暑;
  
  public final HashSet 熱;
  
  public final UUID 硬;
  
  public final iq 美;
  
  public final 습 辛;
  
  public WorkerParameters(UUID paramUUID, 급 param급, List<?> paramList, 茎 param茎, int paramInt, ExecutorService paramExecutorService, iq paramiq, o10 paramo10, d10 paramd10, x00 paramx00) {
    this.硬 = paramUUID;
    this.堅 = param급;
    this.熱 = new HashSet(paramList);
    this.暑 = param茎;
    this.冷 = paramInt;
    this.寒 = paramExecutorService;
    this.美 = paramiq;
    this.旨 = (p10)paramo10;
    this.不 = (ha)paramd10;
    this.辛 = (습)paramx00;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */