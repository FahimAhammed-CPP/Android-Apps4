package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import java.util.HashMap;
import java.util.WeakHashMap;
import y.jp;
import y.kp;
import y.uy;
import y.中;
import y.獅;

public class SystemAlarmService extends 中 implements jp {
  public kp 怖;
  
  public boolean 恐;
  
  static {
    獅.苦("SystemAlarmService");
  }
  
  public final void onCreate() {
    super.onCreate();
    堅();
    this.恐 = false;
  }
  
  public final void onDestroy() {
    super.onDestroy();
    this.恐 = true;
    this.怖.冷();
  }
  
  public final int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.恐) {
      獅.辛().ぱ(new Throwable[0]);
      this.怖.冷();
      堅();
      this.恐 = false;
    } 
    if (paramIntent != null)
      this.怖.堅(paramIntent, paramInt2); 
    return 3;
  }
  
  public final void 堅() {
    kp kp1 = new kp((Context)this);
    this.怖 = kp1;
    if (kp1.死 != null) {
      獅.辛().不(new Throwable[0]);
      return;
    } 
    kp1.死 = this;
  }
  
  public final void 熱() {
    this.恐 = true;
    獅.辛().寒(new Throwable[0]);
    WeakHashMap weakHashMap = uy.硬;
    null = new HashMap<Object, Object>();
    synchronized (uy.硬) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          獅 獅 = 獅.辛();
          WeakHashMap weakHashMap1 = uy.硬;
          獅.嬉(new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */