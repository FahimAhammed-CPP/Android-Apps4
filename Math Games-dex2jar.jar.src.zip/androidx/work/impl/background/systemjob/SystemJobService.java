package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.HashMap;
import y.z00;
import y.獅;
import y.법;

public class SystemJobService extends JobService implements 법 {
  public final HashMap 怖 = new HashMap<Object, Object>();
  
  public z00 淋;
  
  static {
    獅.苦("SystemJobService");
  }
  
  public final void onCreate() {
    super.onCreate();
    try {
      z00 z001 = z00.ニ(getApplicationContext());
      this.淋 = z001;
      z001.投.堅(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        獅.辛().嬉(new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public final void onDestroy() {
    super.onDestroy();
    z00 z001 = this.淋;
    if (z001 != null)
      z001.投.寒(this); 
  }
  
  public final boolean onStartJob(JobParameters paramJobParameters) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Ly/z00;
    //   4: ifnonnull -> 25
    //   7: invokestatic 辛 : ()Ly/獅;
    //   10: iconst_0
    //   11: anewarray java/lang/Throwable
    //   14: invokevirtual 寒 : ([Ljava/lang/Throwable;)V
    //   17: aload_0
    //   18: aload_1
    //   19: iconst_1
    //   20: invokevirtual jobFinished : (Landroid/app/job/JobParameters;Z)V
    //   23: iconst_0
    //   24: ireturn
    //   25: aconst_null
    //   26: astore #4
    //   28: aload_1
    //   29: invokevirtual getExtras : ()Landroid/os/PersistableBundle;
    //   32: astore_3
    //   33: aload_3
    //   34: ifnull -> 56
    //   37: aload_3
    //   38: ldc 'EXTRA_WORK_SPEC_ID'
    //   40: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   43: ifeq -> 56
    //   46: aload_3
    //   47: ldc 'EXTRA_WORK_SPEC_ID'
    //   49: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   52: astore_3
    //   53: goto -> 58
    //   56: aconst_null
    //   57: astore_3
    //   58: aload_3
    //   59: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   62: ifeq -> 77
    //   65: invokestatic 辛 : ()Ly/獅;
    //   68: iconst_0
    //   69: anewarray java/lang/Throwable
    //   72: invokevirtual 不 : ([Ljava/lang/Throwable;)V
    //   75: iconst_0
    //   76: ireturn
    //   77: aload_0
    //   78: getfield 怖 : Ljava/util/HashMap;
    //   81: astore #5
    //   83: aload #5
    //   85: monitorenter
    //   86: aload_0
    //   87: getfield 怖 : Ljava/util/HashMap;
    //   90: aload_3
    //   91: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   94: ifeq -> 128
    //   97: invokestatic 辛 : ()Ly/獅;
    //   100: astore_1
    //   101: ldc 'Job is already being executed by SystemJobService: %s'
    //   103: iconst_1
    //   104: anewarray java/lang/Object
    //   107: dup
    //   108: iconst_0
    //   109: aload_3
    //   110: aastore
    //   111: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   114: pop
    //   115: aload_1
    //   116: iconst_0
    //   117: anewarray java/lang/Throwable
    //   120: invokevirtual 寒 : ([Ljava/lang/Throwable;)V
    //   123: aload #5
    //   125: monitorexit
    //   126: iconst_0
    //   127: ireturn
    //   128: invokestatic 辛 : ()Ly/獅;
    //   131: astore #6
    //   133: ldc 'onStartJob for %s'
    //   135: iconst_1
    //   136: anewarray java/lang/Object
    //   139: dup
    //   140: iconst_0
    //   141: aload_3
    //   142: aastore
    //   143: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   146: pop
    //   147: aload #6
    //   149: iconst_0
    //   150: anewarray java/lang/Throwable
    //   153: invokevirtual 寒 : ([Ljava/lang/Throwable;)V
    //   156: aload_0
    //   157: getfield 怖 : Ljava/util/HashMap;
    //   160: aload_3
    //   161: aload_1
    //   162: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   165: pop
    //   166: aload #5
    //   168: monitorexit
    //   169: getstatic android/os/Build$VERSION.SDK_INT : I
    //   172: istore_2
    //   173: iload_2
    //   174: bipush #24
    //   176: if_icmplt -> 251
    //   179: new y/茎
    //   182: dup
    //   183: bipush #10
    //   185: invokespecial <init> : (I)V
    //   188: astore #5
    //   190: aload_1
    //   191: invokestatic 壊 : (Landroid/app/job/JobParameters;)[Landroid/net/Uri;
    //   194: ifnull -> 209
    //   197: aload #5
    //   199: aload_1
    //   200: invokestatic 壊 : (Landroid/app/job/JobParameters;)[Landroid/net/Uri;
    //   203: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   206: putfield 恐 : Ljava/lang/Object;
    //   209: aload_1
    //   210: invokestatic 帰 : (Landroid/app/job/JobParameters;)[Ljava/lang/String;
    //   213: ifnull -> 228
    //   216: aload #5
    //   218: aload_1
    //   219: invokestatic 帰 : (Landroid/app/job/JobParameters;)[Ljava/lang/String;
    //   222: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   225: putfield 怖 : Ljava/lang/Object;
    //   228: aload #5
    //   230: astore #4
    //   232: iload_2
    //   233: bipush #28
    //   235: if_icmplt -> 251
    //   238: aload #5
    //   240: aload_1
    //   241: invokestatic 美 : (Landroid/app/job/JobParameters;)Landroid/net/Network;
    //   244: putfield 痛 : Ljava/lang/Object;
    //   247: aload #5
    //   249: astore #4
    //   251: aload_0
    //   252: getfield 淋 : Ly/z00;
    //   255: aload_3
    //   256: aload #4
    //   258: invokevirtual 踵 : (Ljava/lang/String;Ly/茎;)V
    //   261: iconst_1
    //   262: ireturn
    //   263: astore_1
    //   264: aload #5
    //   266: monitorexit
    //   267: aload_1
    //   268: athrow
    //   269: astore_3
    //   270: goto -> 56
    // Exception table:
    //   from	to	target	type
    //   28	33	269	java/lang/NullPointerException
    //   37	53	269	java/lang/NullPointerException
    //   86	126	263	finally
    //   128	169	263	finally
    //   264	267	263	finally
  }
  
  public final boolean onStopJob(JobParameters paramJobParameters) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Ly/z00;
    //   4: ifnonnull -> 19
    //   7: invokestatic 辛 : ()Ly/獅;
    //   10: iconst_0
    //   11: anewarray java/lang/Throwable
    //   14: invokevirtual 寒 : ([Ljava/lang/Throwable;)V
    //   17: iconst_1
    //   18: ireturn
    //   19: aload_1
    //   20: invokevirtual getExtras : ()Landroid/os/PersistableBundle;
    //   23: astore_1
    //   24: aload_1
    //   25: ifnull -> 47
    //   28: aload_1
    //   29: ldc 'EXTRA_WORK_SPEC_ID'
    //   31: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   34: ifeq -> 47
    //   37: aload_1
    //   38: ldc 'EXTRA_WORK_SPEC_ID'
    //   40: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   43: astore_1
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_1
    //   49: aload_1
    //   50: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   53: ifeq -> 68
    //   56: invokestatic 辛 : ()Ly/獅;
    //   59: iconst_0
    //   60: anewarray java/lang/Throwable
    //   63: invokevirtual 不 : ([Ljava/lang/Throwable;)V
    //   66: iconst_0
    //   67: ireturn
    //   68: invokestatic 辛 : ()Ly/獅;
    //   71: astore_2
    //   72: ldc 'onStopJob for %s'
    //   74: iconst_1
    //   75: anewarray java/lang/Object
    //   78: dup
    //   79: iconst_0
    //   80: aload_1
    //   81: aastore
    //   82: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   85: pop
    //   86: aload_2
    //   87: iconst_0
    //   88: anewarray java/lang/Throwable
    //   91: invokevirtual 寒 : ([Ljava/lang/Throwable;)V
    //   94: aload_0
    //   95: getfield 怖 : Ljava/util/HashMap;
    //   98: astore_2
    //   99: aload_2
    //   100: monitorenter
    //   101: aload_0
    //   102: getfield 怖 : Ljava/util/HashMap;
    //   105: aload_1
    //   106: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   109: pop
    //   110: aload_2
    //   111: monitorexit
    //   112: aload_0
    //   113: getfield 淋 : Ly/z00;
    //   116: aload_1
    //   117: invokevirtual す : (Ljava/lang/String;)V
    //   120: aload_0
    //   121: getfield 淋 : Ly/z00;
    //   124: getfield 投 : Ly/ga;
    //   127: aload_1
    //   128: invokevirtual 暑 : (Ljava/lang/String;)Z
    //   131: iconst_1
    //   132: ixor
    //   133: ireturn
    //   134: astore_1
    //   135: aload_2
    //   136: monitorexit
    //   137: aload_1
    //   138: athrow
    //   139: astore_1
    //   140: goto -> 47
    // Exception table:
    //   from	to	target	type
    //   19	24	139	java/lang/NullPointerException
    //   28	44	139	java/lang/NullPointerException
    //   101	112	134	finally
    //   135	137	134	finally
  }
  
  public final void 硬(String paramString, boolean paramBoolean) {
    獅 獅 = 獅.辛();
    String.format("%s executed on JobScheduler", new Object[] { paramString });
    獅.寒(new Throwable[0]);
    synchronized (this.怖) {
      JobParameters jobParameters = (JobParameters)this.怖.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */