package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import java.util.Collections;
import y.v7;
import y.z00;
import y.獅;

public class DiagnosticsReceiver extends BroadcastReceiver {
  static {
    獅.苦("DiagnosticsRcvr");
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    獅.辛().寒(new Throwable[0]);
    try {
      z00.ニ(paramContext).ン(Collections.singletonList((new v7(DiagnosticsWorker.class)).硬()));
      return;
    } catch (IllegalStateException illegalStateException) {
      獅.辛().不(new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */