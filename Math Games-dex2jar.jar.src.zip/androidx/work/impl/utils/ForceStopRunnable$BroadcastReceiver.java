package androidx.work.impl.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import y.獅;
import y.쉬;

public class ForceStopRunnable$BroadcastReceiver extends BroadcastReceiver {
  static {
    獅.苦("ForceStopRunnable$Rcvr");
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(paramIntent.getAction())) {
      int i = (獅.辛()).淋;
      쉬.熱(paramContext);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable$BroadcastReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */