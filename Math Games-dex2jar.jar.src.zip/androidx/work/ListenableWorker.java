package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import y.d10;
import y.ha;
import y.iq;
import y.p10;
import y.qk;
import y.w00;
import y.x00;
import y.姉;
import y.茎;
import y.走;
import y.급;
import y.스;
import y.습;

public abstract class ListenableWorker {
  public final WorkerParameters 怖;
  
  public volatile boolean 恐;
  
  public final Context 淋;
  
  public boolean 痒;
  
  public boolean 痛;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.淋 = paramContext;
        this.怖 = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.淋;
  }
  
  public Executor getBackgroundExecutor() {
    return this.怖.寒;
  }
  
  public 姉 getForegroundInfoAsync() {
    qk qk = new qk();
    qk.ぱ(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (姉)qk;
  }
  
  public final UUID getId() {
    return this.怖.硬;
  }
  
  public final 급 getInputData() {
    return this.怖.堅;
  }
  
  public final Network getNetwork() {
    return (Network)this.怖.暑.痛;
  }
  
  public final int getRunAttemptCount() {
    return this.怖.冷;
  }
  
  public final Set<String> getTags() {
    return this.怖.熱;
  }
  
  public iq getTaskExecutor() {
    return this.怖.美;
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return (List<String>)this.怖.暑.怖;
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return (List<Uri>)this.怖.暑.恐;
  }
  
  public p10 getWorkerFactory() {
    return this.怖.旨;
  }
  
  public boolean isRunInForeground() {
    return this.痒;
  }
  
  public final boolean isStopped() {
    return this.恐;
  }
  
  public final boolean isUsed() {
    return this.痛;
  }
  
  public void onStopped() {}
  
  public final 姉 setForegroundAsync(스 param스) {
    this.痒 = true;
    습 습 = this.怖.辛;
    Context context = getApplicationContext();
    UUID uUID = getId();
    x00 x00 = (x00)습;
    x00.getClass();
    qk qk = new qk();
    w00 w00 = new w00(x00, qk, uUID, param스, context);
    ((茎)x00.硬).不((Runnable)w00);
    return (姉)qk;
  }
  
  public 姉 setProgressAsync(급 param급) {
    ha ha = this.怖.不;
    getApplicationContext();
    UUID uUID = getId();
    d10 d10 = (d10)ha;
    d10.getClass();
    qk qk = new qk();
    走 走 = new 走(d10, uUID, param급, qk, 3);
    ((茎)d10.堅).不((Runnable)走);
    return (姉)qk;
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.痒 = paramBoolean;
  }
  
  public final void setUsed() {
    this.痛 = true;
  }
  
  public abstract 姉 startWork();
  
  public final void stop() {
    this.恐 = true;
    onStopped();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */