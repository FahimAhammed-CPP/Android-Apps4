package androidx.work;

import android.content.Context;
import java.util.Collections;
import java.util.List;
import y.yw0;
import y.z00;
import y.し;
import y.獅;
import y.징;

public final class WorkManagerInitializer implements し {
  static {
    獅.苦("WrkMgrInitializer");
  }
  
  public final Object 堅(Context paramContext) {
    獅.辛().寒(new Throwable[0]);
    z00.ア(paramContext, new 징(new yw0()));
    return z00.ニ(paramContext);
  }
  
  public final List 硬() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */