package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import y.체;

public class Guideline extends View {
  public boolean 淋 = true;
  
  public Guideline(Context paramContext) {
    super(paramContext);
    super.setVisibility(8);
  }
  
  public Guideline(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    super.setVisibility(8);
  }
  
  public final void draw(Canvas paramCanvas) {}
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void setFilterRedundantCalls(boolean paramBoolean) {
    this.淋 = paramBoolean;
  }
  
  public void setGuidelineBegin(int paramInt) {
    체 체 = (체)getLayoutParams();
    if (this.淋 && 체.硬 == paramInt)
      return; 
    체.硬 = paramInt;
    setLayoutParams((ViewGroup.LayoutParams)체);
  }
  
  public void setGuidelineEnd(int paramInt) {
    체 체 = (체)getLayoutParams();
    if (this.淋 && 체.堅 == paramInt)
      return; 
    체.堅 = paramInt;
    setLayoutParams((ViewGroup.LayoutParams)체);
  }
  
  public void setGuidelinePercent(float paramFloat) {
    체 체 = (체)getLayoutParams();
    if (this.淋 && 체.熱 == paramFloat)
      return; 
    체.熱 = paramFloat;
    setLayoutParams((ViewGroup.LayoutParams)체);
  }
  
  public void setVisibility(int paramInt) {}
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\constraintlayout\widget\Guideline.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */