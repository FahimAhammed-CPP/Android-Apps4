package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import y.aw;
import y.bf;
import y.cf;
import y.df;
import y.dx;
import y.ef;
import y.ex;
import y.fe;
import y.for;
import y.ge;
import y.gf;
import y.gw;
import y.h9;
import y.he;
import y.iw;
import y.je;
import y.k5;
import y.ke;
import y.le;
import y.me;
import y.ne;
import y.nul;
import y.pe;
import y.prn;
import y.qe;
import y.re;
import y.rw;
import y.se;
import y.ss;
import y.sw;
import y.te;
import y.ue;
import y.uw;
import y.ve;
import y.vw;
import y.we;
import y.xe;
import y.ye;
import y.ㅂ;
import y.噌;
import y.料;
import y.烏;
import y.話;
import y.邪;
import y.꽃;
import y.녀;
import y.표;
import y.품;

public class RecyclerView extends ViewGroup {
  static {
    if (Build.VERSION.SDK_INT >= 23) {
      bool = true;
    } else {
      bool = false;
    } 
    ご = bool;
    看 = true;
    Class<int> clazz = int.class;
    護 = new Class[] { Context.class, AttributeSet.class, clazz, clazz };
    師 = new vw(1);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903863);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    StringBuilder stringBuilder;
    float f;
    표 표1;
    this.淋 = new h9(this);
    this.怖 = new we(this);
    this.臭 = new ex(0);
    this.興 = new Rect();
    this.産 = new Rect();
    this.死 = new RectF();
    this.返 = new ArrayList();
    this.歩 = new ArrayList();
    this.触 = 0;
    this.赤 = false;
    this.わ = false;
    this.も = 0;
    this.若 = 0;
    this.코 = new ke();
    this.ㅌ = (me)new 녀();
    this.타 = 0;
    this.탁 = -1;
    this.테 = Float.MIN_VALUE;
    this.토 = Float.MIN_VALUE;
    this.톤 = true;
    this.톨 = new df(this);
    if (看) {
      표1 = new 표(0);
    } else {
      표1 = null;
    } 
    this.퇴 = 표1;
    this.투 = new bf();
    this.た = false;
    this.し = false;
    ge ge1 = new ge(this);
    this.私 = ge1;
    this.く = false;
    this.僕 = new int[2];
    this.俺 = new int[2];
    this.ょ = new int[2];
    this.う = new int[2];
    this.少 = new ArrayList();
    this.ね = new fe(this);
    this.年 = new ge(this);
    setScrollContainer(true);
    setFocusableInTouchMode(true);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.태 = viewConfiguration.getScaledTouchSlop();
    Method method = uw.硬;
    int j = Build.VERSION.SDK_INT;
    if (j >= 26) {
      f = sw.硬(viewConfiguration);
    } else {
      f = uw.硬(viewConfiguration, paramContext);
    } 
    this.테 = f;
    if (j >= 26) {
      f = sw.堅(viewConfiguration);
    } else {
      f = uw.硬(viewConfiguration, paramContext);
    } 
    this.토 = f;
    this.탱 = viewConfiguration.getScaledMinimumFlingVelocity();
    this.터 = viewConfiguration.getScaledMaximumFlingVelocity();
    if (getOverScrollMode() == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    this.ㅌ.硬 = ge1;
    this.痛 = new 料(new ge(this));
    this.痒 = new 話(new ge(this));
    WeakHashMap weakHashMap = rw.硬;
    if (j >= 26) {
      i = iw.堅((View)this);
    } else {
      i = 0;
    } 
    if (!i && j >= 26)
      iw.苦((View)this, 8); 
    if (rw.旨((View)this) == 0)
      rw.踊((View)this, 1); 
    this.ゃ = (AccessibilityManager)getContext().getSystemService("accessibility");
    setAccessibilityDelegateCompat(new gf(this));
    int[] arrayOfInt2 = 꽃.冷;
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt2, paramInt, 0);
    if (j >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt2, paramAttributeSet, typedArray1, paramInt, 0); 
    String str = typedArray1.getString(8);
    if (typedArray1.getInt(2, -1) == -1)
      setDescendantFocusability(262144); 
    this.起 = typedArray1.getBoolean(1, true);
    if (typedArray1.getBoolean(3, false)) {
      StateListDrawable stateListDrawable1 = (StateListDrawable)typedArray1.getDrawable(6);
      Drawable drawable1 = typedArray1.getDrawable(7);
      StateListDrawable stateListDrawable2 = (StateListDrawable)typedArray1.getDrawable(4);
      Drawable drawable2 = typedArray1.getDrawable(5);
      if (stateListDrawable1 != null && drawable1 != null && stateListDrawable2 != null && drawable2 != null) {
        Resources resources = getContext().getResources();
        new ㅂ(this, stateListDrawable1, drawable1, stateListDrawable2, drawable2, resources.getDimensionPixelSize(2131099829), resources.getDimensionPixelSize(2131099831), resources.getDimensionPixelOffset(2131099830));
      } else {
        stringBuilder = new StringBuilder("Trying to set fast scroller without both required drawables.");
        stringBuilder.append(死());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    typedArray1.recycle();
    if (str != null) {
      String str1 = str.trim();
      if (!str1.isEmpty()) {
        if (str1.charAt(0) == '.') {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(stringBuilder.getPackageName());
          stringBuilder1.append(str1);
          str1 = stringBuilder1.toString();
        } else if (!str1.contains(".")) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(RecyclerView.class.getPackage().getName());
          stringBuilder1.append('.');
          stringBuilder1.append(str1);
          str1 = stringBuilder1.toString();
        } 
        try {
          ClassLoader classLoader;
          StringBuilder stringBuilder1;
          if (isInEditMode()) {
            classLoader = getClass().getClassLoader();
          } else {
            classLoader = stringBuilder.getClassLoader();
          } 
          Class<? extends pe> clazz = Class.forName(str1, false, classLoader).asSubclass(pe.class);
          try {
            Constructor<? extends pe> constructor = clazz.getConstructor(護);
            Object[] arrayOfObject = { stringBuilder, paramAttributeSet, Integer.valueOf(paramInt), Integer.valueOf(0) };
          } catch (NoSuchMethodException noSuchMethodException) {
            try {
              Constructor<? extends pe> constructor = clazz.getConstructor(new Class[0]);
              noSuchMethodException = null;
              constructor.setAccessible(true);
              setLayoutManager(constructor.newInstance((Object[])noSuchMethodException));
            } catch (NoSuchMethodException noSuchMethodException1) {
              noSuchMethodException1.initCause(noSuchMethodException);
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(paramAttributeSet.getPositionDescription());
              stringBuilder1.append(": Error creating LayoutManager ");
              stringBuilder1.append(str1);
              throw new IllegalStateException(stringBuilder1.toString(), noSuchMethodException1);
            } 
          } 
          stringBuilder1.setAccessible(true);
          setLayoutManager(stringBuilder1.newInstance((Object[])noSuchMethodException));
        } catch (ClassNotFoundException classNotFoundException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Unable to find LayoutManager ");
          stringBuilder1.append(str1);
          throw new IllegalStateException(stringBuilder1.toString(), classNotFoundException);
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Could not instantiate the LayoutManager: ");
          stringBuilder1.append(str1);
          throw new IllegalStateException(stringBuilder1.toString(), invocationTargetException);
        } catch (InstantiationException instantiationException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Could not instantiate the LayoutManager: ");
          stringBuilder1.append(str1);
          throw new IllegalStateException(stringBuilder1.toString(), instantiationException);
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Cannot access non-public constructor ");
          stringBuilder1.append(str1);
          throw new IllegalStateException(stringBuilder1.toString(), illegalAccessException);
        } catch (ClassCastException classCastException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Class is not a LayoutManager ");
          stringBuilder1.append(str1);
          throw new IllegalStateException(stringBuilder1.toString(), classCastException);
        } 
      } 
    } 
    int i = Build.VERSION.SDK_INT;
    int[] arrayOfInt1 = 医;
    TypedArray typedArray2 = classCastException.obtainStyledAttributes(paramAttributeSet, arrayOfInt1, paramInt, 0);
    if (i >= 29)
      saveAttributeDataForStyleable((Context)classCastException, arrayOfInt1, paramAttributeSet, typedArray2, paramInt, 0); 
    boolean bool = typedArray2.getBoolean(0, true);
    typedArray2.recycle();
    setNestedScrollingEnabled(bool);
  }
  
  private k5 getScrollingChildHelper() {
    if (this.れ == null)
      this.れ = new k5((View)this); 
    return this.れ;
  }
  
  public static ef 投(View paramView) {
    return (paramView == null) ? null : ((qe)paramView.getLayoutParams()).硬;
  }
  
  public static RecyclerView 泳(View paramView) {
    if (!(paramView instanceof ViewGroup))
      return null; 
    if (paramView instanceof RecyclerView)
      return (RecyclerView)paramView; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      RecyclerView recyclerView = 泳(viewGroup.getChildAt(i));
      if (recyclerView != null)
        return recyclerView; 
    } 
    return null;
  }
  
  public static void 辛(ef paramef) {
    WeakReference<View> weakReference = paramef.堅;
    if (weakReference != null) {
      View view = weakReference.get();
      while (view != null) {
        if (view == paramef.硬)
          return; 
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
          View view1 = (View)viewParent;
          continue;
        } 
        viewParent = null;
      } 
      paramef.堅 = null;
    } 
  }
  
  public final void addFocusables(ArrayList paramArrayList, int paramInt1, int paramInt2) {
    pe pe1 = this.帰;
    if (pe1 != null)
      pe1.getClass(); 
    super.addFocusables(paramArrayList, paramInt1, paramInt2);
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof qe && this.帰.寒((qe)paramLayoutParams));
  }
  
  public final int computeHorizontalScrollExtent() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.暑())
      i = this.帰.辛(this.투); 
    return i;
  }
  
  public final int computeHorizontalScrollOffset() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.暑())
      i = this.帰.ぱ(this.투); 
    return i;
  }
  
  public final int computeHorizontalScrollRange() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.暑())
      i = this.帰.苦(this.투); 
    return i;
  }
  
  public final int computeVerticalScrollExtent() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.冷())
      i = this.帰.嬉(this.투); 
    return i;
  }
  
  public final int computeVerticalScrollOffset() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.冷())
      i = this.帰.悲(this.투); 
    return i;
  }
  
  public final int computeVerticalScrollRange() {
    pe pe1 = this.帰;
    int i = 0;
    if (pe1 == null)
      return 0; 
    if (pe1.冷())
      i = this.帰.寂(this.투); 
    return i;
  }
  
  public final boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return getScrollingChildHelper().硬(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public final boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return getScrollingChildHelper().堅(paramFloat1, paramFloat2);
  }
  
  public final boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return getScrollingChildHelper().熱(paramInt1, paramInt2, 0, paramArrayOfint1, paramArrayOfint2);
  }
  
  public final boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return getScrollingChildHelper().冷(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, 0, null);
  }
  
  public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    onPopulateAccessibilityEvent(paramAccessibilityEvent);
    return true;
  }
  
  public final void dispatchRestoreInstanceState(SparseArray paramSparseArray) {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  public final void dispatchSaveInstanceState(SparseArray paramSparseArray) {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  public final void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    ArrayList<ne> arrayList = this.返;
    int j = arrayList.size();
    boolean bool1 = false;
    int i;
    for (i = 0; i < j; i++)
      ((ne)arrayList.get(i)).堅(paramCanvas); 
    EdgeEffect edgeEffect = this.쾌;
    boolean bool2 = true;
    if (edgeEffect != null && !edgeEffect.isFinished()) {
      int k = paramCanvas.save();
      if (this.起) {
        i = getPaddingBottom();
      } else {
        i = 0;
      } 
      paramCanvas.rotate(270.0F);
      paramCanvas.translate((-getHeight() + i), 0.0F);
      edgeEffect = this.쾌;
      if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
        j = 1;
      } else {
        j = 0;
      } 
      paramCanvas.restoreToCount(k);
    } else {
      j = 0;
    } 
    edgeEffect = this.크;
    i = j;
    if (edgeEffect != null) {
      i = j;
      if (!edgeEffect.isFinished()) {
        int k = paramCanvas.save();
        if (this.起)
          paramCanvas.translate(getPaddingLeft(), getPaddingTop()); 
        edgeEffect = this.크;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i = 1;
        } else {
          i = 0;
        } 
        i = j | i;
        paramCanvas.restoreToCount(k);
      } 
    } 
    edgeEffect = this.큰;
    j = i;
    if (edgeEffect != null) {
      j = i;
      if (!edgeEffect.isFinished()) {
        int k = paramCanvas.save();
        int m = getWidth();
        if (this.起) {
          j = getPaddingTop();
        } else {
          j = 0;
        } 
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-j, -m);
        edgeEffect = this.큰;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          j = 1;
        } else {
          j = 0;
        } 
        j = i | j;
        paramCanvas.restoreToCount(k);
      } 
    } 
    edgeEffect = this.키;
    i = j;
    if (edgeEffect != null) {
      i = j;
      if (!edgeEffect.isFinished()) {
        int k = paramCanvas.save();
        paramCanvas.rotate(180.0F);
        if (this.起) {
          i = -getWidth();
          float f = (getPaddingRight() + i);
          i = -getHeight();
          paramCanvas.translate(f, (getPaddingBottom() + i));
        } else {
          paramCanvas.translate(-getWidth(), -getHeight());
        } 
        edgeEffect = this.키;
        i = bool1;
        if (edgeEffect != null) {
          i = bool1;
          if (edgeEffect.draw(paramCanvas))
            i = 1; 
        } 
        i = j | i;
        paramCanvas.restoreToCount(k);
      } 
    } 
    if (i == 0 && this.ㅌ != null && arrayList.size() > 0 && this.ㅌ.寒())
      i = bool2; 
    if (i != 0)
      rw.痒((View)this); 
  }
  
  public final boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public final View focusSearch(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 帰 : Ly/pe;
    //   4: invokevirtual getClass : ()Ljava/lang/Class;
    //   7: pop
    //   8: aload_0
    //   9: getfield 壊 : Ly/he;
    //   12: astore #9
    //   14: iconst_0
    //   15: istore #5
    //   17: aload #9
    //   19: ifnull -> 48
    //   22: aload_0
    //   23: getfield 帰 : Ly/pe;
    //   26: ifnull -> 48
    //   29: aload_0
    //   30: invokevirtual か : ()Z
    //   33: ifne -> 48
    //   36: aload_0
    //   37: getfield あ : Z
    //   40: ifne -> 48
    //   43: iconst_1
    //   44: istore_3
    //   45: goto -> 50
    //   48: iconst_0
    //   49: istore_3
    //   50: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   53: astore #9
    //   55: aload_0
    //   56: getfield 투 : Ly/bf;
    //   59: astore #10
    //   61: aload_0
    //   62: getfield 怖 : Ly/we;
    //   65: astore #11
    //   67: iload_3
    //   68: ifeq -> 270
    //   71: iload_2
    //   72: iconst_2
    //   73: if_icmpeq -> 81
    //   76: iload_2
    //   77: iconst_1
    //   78: if_icmpne -> 270
    //   81: aload_0
    //   82: getfield 帰 : Ly/pe;
    //   85: invokevirtual 冷 : ()Z
    //   88: ifeq -> 122
    //   91: iload_2
    //   92: iconst_2
    //   93: if_icmpne -> 103
    //   96: sipush #130
    //   99: istore_3
    //   100: goto -> 106
    //   103: bipush #33
    //   105: istore_3
    //   106: aload #9
    //   108: aload_0
    //   109: aload_1
    //   110: iload_3
    //   111: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   114: ifnonnull -> 122
    //   117: iconst_1
    //   118: istore_3
    //   119: goto -> 124
    //   122: iconst_0
    //   123: istore_3
    //   124: iload_3
    //   125: istore #4
    //   127: iload_3
    //   128: ifne -> 215
    //   131: iload_3
    //   132: istore #4
    //   134: aload_0
    //   135: getfield 帰 : Ly/pe;
    //   138: invokevirtual 暑 : ()Z
    //   141: ifeq -> 215
    //   144: aload_0
    //   145: getfield 帰 : Ly/pe;
    //   148: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   151: invokestatic 不 : (Landroid/view/View;)I
    //   154: iconst_1
    //   155: if_icmpne -> 163
    //   158: iconst_1
    //   159: istore_3
    //   160: goto -> 165
    //   163: iconst_0
    //   164: istore_3
    //   165: iload_2
    //   166: iconst_2
    //   167: if_icmpne -> 176
    //   170: iconst_1
    //   171: istore #4
    //   173: goto -> 179
    //   176: iconst_0
    //   177: istore #4
    //   179: iload_3
    //   180: iload #4
    //   182: ixor
    //   183: ifeq -> 192
    //   186: bipush #66
    //   188: istore_3
    //   189: goto -> 195
    //   192: bipush #17
    //   194: istore_3
    //   195: aload #9
    //   197: aload_0
    //   198: aload_1
    //   199: iload_3
    //   200: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   203: ifnonnull -> 212
    //   206: iconst_1
    //   207: istore #4
    //   209: goto -> 215
    //   212: iconst_0
    //   213: istore #4
    //   215: iload #4
    //   217: ifeq -> 257
    //   220: aload_0
    //   221: invokevirtual 嬉 : ()V
    //   224: aload_0
    //   225: aload_1
    //   226: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   229: ifnonnull -> 234
    //   232: aconst_null
    //   233: areturn
    //   234: aload_0
    //   235: invokevirtual 탐 : ()V
    //   238: aload_0
    //   239: getfield 帰 : Ly/pe;
    //   242: aload_1
    //   243: iload_2
    //   244: aload #11
    //   246: aload #10
    //   248: invokevirtual 赤 : (Landroid/view/View;ILy/we;Ly/bf;)Landroid/view/View;
    //   251: pop
    //   252: aload_0
    //   253: iconst_0
    //   254: invokevirtual 탑 : (Z)V
    //   257: aload #9
    //   259: aload_0
    //   260: aload_1
    //   261: iload_2
    //   262: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   265: astore #9
    //   267: goto -> 330
    //   270: aload #9
    //   272: aload_0
    //   273: aload_1
    //   274: iload_2
    //   275: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   278: astore #9
    //   280: aload #9
    //   282: ifnonnull -> 330
    //   285: iload_3
    //   286: ifeq -> 330
    //   289: aload_0
    //   290: invokevirtual 嬉 : ()V
    //   293: aload_0
    //   294: aload_1
    //   295: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   298: ifnonnull -> 303
    //   301: aconst_null
    //   302: areturn
    //   303: aload_0
    //   304: invokevirtual 탐 : ()V
    //   307: aload_0
    //   308: getfield 帰 : Ly/pe;
    //   311: aload_1
    //   312: iload_2
    //   313: aload #11
    //   315: aload #10
    //   317: invokevirtual 赤 : (Landroid/view/View;ILy/we;Ly/bf;)Landroid/view/View;
    //   320: astore #9
    //   322: aload_0
    //   323: iconst_0
    //   324: invokevirtual 탑 : (Z)V
    //   327: goto -> 330
    //   330: aload #9
    //   332: ifnull -> 366
    //   335: aload #9
    //   337: invokevirtual hasFocusable : ()Z
    //   340: ifne -> 366
    //   343: aload_0
    //   344: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   347: ifnonnull -> 357
    //   350: aload_0
    //   351: aload_1
    //   352: iload_2
    //   353: invokespecial focusSearch : (Landroid/view/View;I)Landroid/view/View;
    //   356: areturn
    //   357: aload_0
    //   358: aload #9
    //   360: aconst_null
    //   361: invokevirtual 키 : (Landroid/view/View;Landroid/view/View;)V
    //   364: aload_1
    //   365: areturn
    //   366: aload #9
    //   368: ifnull -> 833
    //   371: aload #9
    //   373: aload_0
    //   374: if_acmpne -> 380
    //   377: goto -> 833
    //   380: aload_0
    //   381: aload #9
    //   383: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   386: ifnonnull -> 395
    //   389: iload #5
    //   391: istore_3
    //   392: goto -> 835
    //   395: aload_1
    //   396: ifnonnull -> 402
    //   399: goto -> 828
    //   402: aload_0
    //   403: aload_1
    //   404: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   407: ifnonnull -> 413
    //   410: goto -> 828
    //   413: aload_1
    //   414: invokevirtual getWidth : ()I
    //   417: istore_3
    //   418: aload_1
    //   419: invokevirtual getHeight : ()I
    //   422: istore #4
    //   424: aload_0
    //   425: getfield 興 : Landroid/graphics/Rect;
    //   428: astore #10
    //   430: aload #10
    //   432: iconst_0
    //   433: iconst_0
    //   434: iload_3
    //   435: iload #4
    //   437: invokevirtual set : (IIII)V
    //   440: aload #9
    //   442: invokevirtual getWidth : ()I
    //   445: istore_3
    //   446: aload #9
    //   448: invokevirtual getHeight : ()I
    //   451: istore #4
    //   453: aload_0
    //   454: getfield 産 : Landroid/graphics/Rect;
    //   457: astore #11
    //   459: aload #11
    //   461: iconst_0
    //   462: iconst_0
    //   463: iload_3
    //   464: iload #4
    //   466: invokevirtual set : (IIII)V
    //   469: aload_0
    //   470: aload_1
    //   471: aload #10
    //   473: invokevirtual offsetDescendantRectToMyCoords : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   476: aload_0
    //   477: aload #9
    //   479: aload #11
    //   481: invokevirtual offsetDescendantRectToMyCoords : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   484: aload_0
    //   485: getfield 帰 : Ly/pe;
    //   488: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   491: invokestatic 不 : (Landroid/view/View;)I
    //   494: iconst_1
    //   495: if_icmpne -> 504
    //   498: iconst_m1
    //   499: istore #5
    //   501: goto -> 507
    //   504: iconst_1
    //   505: istore #5
    //   507: aload #10
    //   509: getfield left : I
    //   512: istore_3
    //   513: aload #11
    //   515: getfield left : I
    //   518: istore #4
    //   520: iload_3
    //   521: iload #4
    //   523: if_icmplt -> 536
    //   526: aload #10
    //   528: getfield right : I
    //   531: iload #4
    //   533: if_icmpgt -> 554
    //   536: aload #10
    //   538: getfield right : I
    //   541: aload #11
    //   543: getfield right : I
    //   546: if_icmpge -> 554
    //   549: iconst_1
    //   550: istore_3
    //   551: goto -> 594
    //   554: aload #10
    //   556: getfield right : I
    //   559: istore #6
    //   561: aload #11
    //   563: getfield right : I
    //   566: istore #7
    //   568: iload #6
    //   570: iload #7
    //   572: if_icmpgt -> 581
    //   575: iload_3
    //   576: iload #7
    //   578: if_icmplt -> 592
    //   581: iload_3
    //   582: iload #4
    //   584: if_icmple -> 592
    //   587: iconst_m1
    //   588: istore_3
    //   589: goto -> 594
    //   592: iconst_0
    //   593: istore_3
    //   594: aload #10
    //   596: getfield top : I
    //   599: istore #4
    //   601: aload #11
    //   603: getfield top : I
    //   606: istore #6
    //   608: iload #4
    //   610: iload #6
    //   612: if_icmplt -> 625
    //   615: aload #10
    //   617: getfield bottom : I
    //   620: iload #6
    //   622: if_icmpgt -> 644
    //   625: aload #10
    //   627: getfield bottom : I
    //   630: aload #11
    //   632: getfield bottom : I
    //   635: if_icmpge -> 644
    //   638: iconst_1
    //   639: istore #4
    //   641: goto -> 688
    //   644: aload #10
    //   646: getfield bottom : I
    //   649: istore #7
    //   651: aload #11
    //   653: getfield bottom : I
    //   656: istore #8
    //   658: iload #7
    //   660: iload #8
    //   662: if_icmpgt -> 672
    //   665: iload #4
    //   667: iload #8
    //   669: if_icmplt -> 685
    //   672: iload #4
    //   674: iload #6
    //   676: if_icmple -> 685
    //   679: iconst_m1
    //   680: istore #4
    //   682: goto -> 688
    //   685: iconst_0
    //   686: istore #4
    //   688: iload_2
    //   689: iconst_1
    //   690: if_icmpeq -> 811
    //   693: iload_2
    //   694: iconst_2
    //   695: if_icmpeq -> 791
    //   698: iload_2
    //   699: bipush #17
    //   701: if_icmpeq -> 784
    //   704: iload_2
    //   705: bipush #33
    //   707: if_icmpeq -> 776
    //   710: iload_2
    //   711: bipush #66
    //   713: if_icmpeq -> 769
    //   716: iload_2
    //   717: sipush #130
    //   720: if_icmpne -> 731
    //   723: iload #4
    //   725: ifle -> 833
    //   728: goto -> 828
    //   731: new java/lang/StringBuilder
    //   734: dup
    //   735: ldc_w 'Invalid direction: '
    //   738: invokespecial <init> : (Ljava/lang/String;)V
    //   741: astore_1
    //   742: aload_1
    //   743: iload_2
    //   744: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   747: pop
    //   748: aload_1
    //   749: aload_0
    //   750: invokevirtual 死 : ()Ljava/lang/String;
    //   753: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   756: pop
    //   757: new java/lang/IllegalArgumentException
    //   760: dup
    //   761: aload_1
    //   762: invokevirtual toString : ()Ljava/lang/String;
    //   765: invokespecial <init> : (Ljava/lang/String;)V
    //   768: athrow
    //   769: iload_3
    //   770: ifle -> 833
    //   773: goto -> 828
    //   776: iload #4
    //   778: ifge -> 833
    //   781: goto -> 828
    //   784: iload_3
    //   785: ifge -> 833
    //   788: goto -> 828
    //   791: iload #4
    //   793: ifgt -> 828
    //   796: iload #4
    //   798: ifne -> 833
    //   801: iload_3
    //   802: iload #5
    //   804: imul
    //   805: iflt -> 833
    //   808: goto -> 828
    //   811: iload #4
    //   813: iflt -> 828
    //   816: iload #4
    //   818: ifne -> 833
    //   821: iload_3
    //   822: iload #5
    //   824: imul
    //   825: ifgt -> 833
    //   828: iconst_1
    //   829: istore_3
    //   830: goto -> 835
    //   833: iconst_0
    //   834: istore_3
    //   835: iload_3
    //   836: ifeq -> 842
    //   839: aload #9
    //   841: areturn
    //   842: aload_0
    //   843: aload_1
    //   844: iload_2
    //   845: invokespecial focusSearch : (Landroid/view/View;I)Landroid/view/View;
    //   848: areturn
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    pe pe1 = this.帰;
    if (pe1 != null)
      return (ViewGroup.LayoutParams)pe1.恐(); 
    StringBuilder stringBuilder = new StringBuilder("RecyclerView has no LayoutManager");
    stringBuilder.append(死());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    pe pe1 = this.帰;
    if (pe1 != null)
      return (ViewGroup.LayoutParams)pe1.痛(getContext(), paramAttributeSet); 
    StringBuilder stringBuilder = new StringBuilder("RecyclerView has no LayoutManager");
    stringBuilder.append(死());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    pe pe1 = this.帰;
    if (pe1 != null)
      return (ViewGroup.LayoutParams)pe1.痒(paramLayoutParams); 
    StringBuilder stringBuilder = new StringBuilder("RecyclerView has no LayoutManager");
    stringBuilder.append(死());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public CharSequence getAccessibilityClassName() {
    return "androidx.recyclerview.widget.RecyclerView";
  }
  
  public he getAdapter() {
    return this.壊;
  }
  
  public int getBaseline() {
    pe pe1 = this.帰;
    if (pe1 != null) {
      pe1.getClass();
      return -1;
    } 
    return super.getBaseline();
  }
  
  public final int getChildDrawingOrder(int paramInt1, int paramInt2) {
    return super.getChildDrawingOrder(paramInt1, paramInt2);
  }
  
  public boolean getClipToPadding() {
    return this.起;
  }
  
  public gf getCompatAccessibilityDelegate() {
    return this.ぼ;
  }
  
  public ke getEdgeEffectFactory() {
    return this.코;
  }
  
  public me getItemAnimator() {
    return this.ㅌ;
  }
  
  public int getItemDecorationCount() {
    return this.返.size();
  }
  
  public pe getLayoutManager() {
    return this.帰;
  }
  
  public int getMaxFlingVelocity() {
    return this.터;
  }
  
  public int getMinFlingVelocity() {
    return this.탱;
  }
  
  public long getNanoTime() {
    return 看 ? System.nanoTime() : 0L;
  }
  
  public re getOnFlingListener() {
    return this.택;
  }
  
  public boolean getPreserveFocusAfterLayout() {
    return this.톤;
  }
  
  public ve getRecycledViewPool() {
    return this.怖.熱();
  }
  
  public int getScrollState() {
    return this.타;
  }
  
  public final boolean hasNestedScrollingParent() {
    k5 k51 = getScrollingChildHelper();
    boolean bool = false;
    if (k51.寒(0) != null)
      bool = true; 
    return bool;
  }
  
  public final boolean isAttachedToWindow() {
    return this.踊;
  }
  
  public final boolean isLayoutSuppressed() {
    return this.あ;
  }
  
  public final boolean isNestedScrollingEnabled() {
    return (getScrollingChildHelper()).暑;
  }
  
  public final void onAttachedToWindow() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onAttachedToWindow : ()V
    //   4: aload_0
    //   5: iconst_0
    //   6: putfield も : I
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield 踊 : Z
    //   14: aload_0
    //   15: getfield 噛 : Z
    //   18: ifeq -> 33
    //   21: aload_0
    //   22: invokevirtual isLayoutRequested : ()Z
    //   25: ifne -> 33
    //   28: iconst_1
    //   29: istore_3
    //   30: goto -> 35
    //   33: iconst_0
    //   34: istore_3
    //   35: aload_0
    //   36: iload_3
    //   37: putfield 噛 : Z
    //   40: aload_0
    //   41: getfield 帰 : Ly/pe;
    //   44: astore #4
    //   46: aload #4
    //   48: ifnull -> 57
    //   51: aload #4
    //   53: iconst_1
    //   54: putfield 美 : Z
    //   57: aload_0
    //   58: iconst_0
    //   59: putfield く : Z
    //   62: getstatic androidx/recyclerview/widget/RecyclerView.看 : Z
    //   65: ifeq -> 189
    //   68: getstatic y/품.痒 : Ljava/lang/ThreadLocal;
    //   71: astore #4
    //   73: aload #4
    //   75: invokevirtual get : ()Ljava/lang/Object;
    //   78: checkcast y/품
    //   81: astore #5
    //   83: aload_0
    //   84: aload #5
    //   86: putfield 통 : Ly/품;
    //   89: aload #5
    //   91: ifnonnull -> 177
    //   94: aload_0
    //   95: new y/품
    //   98: dup
    //   99: invokespecial <init> : ()V
    //   102: putfield 통 : Ly/품;
    //   105: getstatic y/rw.硬 : Ljava/util/WeakHashMap;
    //   108: astore #5
    //   110: getstatic android/os/Build$VERSION.SDK_INT : I
    //   113: istore_2
    //   114: aload_0
    //   115: invokestatic 堅 : (Landroid/view/View;)Landroid/view/Display;
    //   118: astore #5
    //   120: aload_0
    //   121: invokevirtual isInEditMode : ()Z
    //   124: ifne -> 149
    //   127: aload #5
    //   129: ifnull -> 149
    //   132: aload #5
    //   134: invokevirtual getRefreshRate : ()F
    //   137: fstore_1
    //   138: fload_1
    //   139: ldc_w 30.0
    //   142: fcmpl
    //   143: iflt -> 149
    //   146: goto -> 153
    //   149: ldc_w 60.0
    //   152: fstore_1
    //   153: aload_0
    //   154: getfield 통 : Ly/품;
    //   157: astore #5
    //   159: aload #5
    //   161: ldc_w 1.0E9
    //   164: fload_1
    //   165: fdiv
    //   166: f2l
    //   167: putfield 恐 : J
    //   170: aload #4
    //   172: aload #5
    //   174: invokevirtual set : (Ljava/lang/Object;)V
    //   177: aload_0
    //   178: getfield 통 : Ly/품;
    //   181: getfield 淋 : Ljava/util/ArrayList;
    //   184: aload_0
    //   185: invokevirtual add : (Ljava/lang/Object;)Z
    //   188: pop
    //   189: return
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    me me1 = this.ㅌ;
    if (me1 != null)
      me1.冷(); 
    setScrollState(0);
    df df1 = this.톨;
    df1.起.removeCallbacks((Runnable)df1);
    df1.恐.abortAnimation();
    pe pe1 = this.帰;
    if (pe1 != null) {
      邪 邪 = pe1.冷;
      if (邪 != null)
        邪.寒(); 
    } 
    this.踊 = false;
    pe1 = this.帰;
    if (pe1 != null) {
      pe1.美 = false;
      pe1.ゃ(this);
    } 
    this.少.clear();
    removeCallbacks((Runnable)this.ね);
    this.臭.getClass();
    while (dx.暑.硬() != null);
    if (看) {
      품 품1 = this.통;
      if (품1 != null) {
        품1.淋.remove(this);
        this.통 = null;
      } 
    } 
  }
  
  public final void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    ArrayList<ne> arrayList = this.返;
    int j = arrayList.size();
    for (int i = 0; i < j; i++)
      ((ne)arrayList.get(i)).硬(this); 
  }
  
  public final boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 帰 : Ly/pe;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: getfield あ : Z
    //   13: ifeq -> 18
    //   16: iconst_0
    //   17: ireturn
    //   18: aload_1
    //   19: invokevirtual getAction : ()I
    //   22: bipush #8
    //   24: if_icmpne -> 172
    //   27: aload_1
    //   28: invokevirtual getSource : ()I
    //   31: iconst_2
    //   32: iand
    //   33: ifeq -> 87
    //   36: aload_0
    //   37: getfield 帰 : Ly/pe;
    //   40: invokevirtual 冷 : ()Z
    //   43: ifeq -> 57
    //   46: aload_1
    //   47: bipush #9
    //   49: invokevirtual getAxisValue : (I)F
    //   52: fneg
    //   53: fstore_3
    //   54: goto -> 59
    //   57: fconst_0
    //   58: fstore_3
    //   59: fload_3
    //   60: fstore_2
    //   61: aload_0
    //   62: getfield 帰 : Ly/pe;
    //   65: invokevirtual 暑 : ()Z
    //   68: ifeq -> 138
    //   71: aload_1
    //   72: bipush #10
    //   74: invokevirtual getAxisValue : (I)F
    //   77: fstore #4
    //   79: fload_3
    //   80: fstore_2
    //   81: fload #4
    //   83: fstore_3
    //   84: goto -> 140
    //   87: aload_1
    //   88: invokevirtual getSource : ()I
    //   91: ldc_w 4194304
    //   94: iand
    //   95: ifeq -> 136
    //   98: aload_1
    //   99: bipush #26
    //   101: invokevirtual getAxisValue : (I)F
    //   104: fstore_3
    //   105: aload_0
    //   106: getfield 帰 : Ly/pe;
    //   109: invokevirtual 冷 : ()Z
    //   112: ifeq -> 121
    //   115: fload_3
    //   116: fneg
    //   117: fstore_2
    //   118: goto -> 138
    //   121: aload_0
    //   122: getfield 帰 : Ly/pe;
    //   125: invokevirtual 暑 : ()Z
    //   128: ifeq -> 136
    //   131: fconst_0
    //   132: fstore_2
    //   133: goto -> 140
    //   136: fconst_0
    //   137: fstore_2
    //   138: fconst_0
    //   139: fstore_3
    //   140: fload_2
    //   141: fconst_0
    //   142: fcmpl
    //   143: ifne -> 152
    //   146: fload_3
    //   147: fconst_0
    //   148: fcmpl
    //   149: ifeq -> 172
    //   152: aload_0
    //   153: fload_3
    //   154: aload_0
    //   155: getfield 테 : F
    //   158: fmul
    //   159: f2i
    //   160: fload_2
    //   161: aload_0
    //   162: getfield 토 : F
    //   165: fmul
    //   166: f2i
    //   167: aload_1
    //   168: invokevirtual 타 : (IILandroid/view/MotionEvent;)Z
    //   171: pop
    //   172: iconst_0
    //   173: ireturn
  }
  
  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ss.硬("RV OnLayout");
    寂();
    ss.堅();
    this.噛 = true;
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    pe pe1 = this.帰;
    if (pe1 == null) {
      悲(paramInt1, paramInt2);
      return;
    } 
    boolean bool1 = pe1.触();
    boolean bool = false;
    bf bf1 = this.투;
    if (bool1) {
      int i = View.MeasureSpec.getMode(paramInt1);
      int j = View.MeasureSpec.getMode(paramInt2);
      this.帰.堅.悲(paramInt1, paramInt2);
      boolean bool2 = bool;
      if (i == 1073741824) {
        bool2 = bool;
        if (j == 1073741824)
          bool2 = true; 
      } 
      if (!bool2) {
        if (this.壊 == null)
          return; 
        if (bf1.暑 == 1)
          淋(); 
        this.帰.톨(paramInt1, paramInt2);
        bf1.不 = true;
        怖();
        this.帰.퇴(paramInt1, paramInt2);
        if (this.帰.者()) {
          this.帰.톨(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
          bf1.不 = true;
          怖();
          this.帰.퇴(paramInt1, paramInt2);
          return;
        } 
      } else {
        return;
      } 
    } else {
      if (this.寝) {
        this.帰.堅.悲(paramInt1, paramInt2);
        return;
      } 
      if (bf1.ぱ) {
        setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
        return;
      } 
      he he1 = this.壊;
      if (he1 != null) {
        bf1.冷 = he1.硬();
      } else {
        bf1.冷 = 0;
      } 
      탐();
      this.帰.堅.悲(paramInt1, paramInt2);
      탑(false);
      bf1.美 = false;
    } 
  }
  
  public final boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    return か() ? false : super.onRequestFocusInDescendants(paramInt, paramRect);
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof ye)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    ye ye1 = (ye)paramParcelable;
    this.恐 = ye1;
    super.onRestoreInstanceState(((for)ye1).淋);
    pe pe1 = this.帰;
    if (pe1 != null) {
      Parcelable parcelable = this.恐.恐;
      if (parcelable != null)
        pe1.탁(parcelable); 
    } 
  }
  
  public final Parcelable onSaveInstanceState() {
    ye ye1 = new ye(super.onSaveInstanceState());
    ye ye2 = this.恐;
    if (ye2 != null) {
      ye1.恐 = ye2.恐;
      return (Parcelable)ye1;
    } 
    pe pe1 = this.帰;
    if (pe1 != null) {
      ye1.恐 = pe1.탄();
      return (Parcelable)ye1;
    } 
    ye1.恐 = null;
    return (Parcelable)ye1;
  }
  
  public final void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3 || paramInt2 != paramInt4) {
      this.키 = null;
      this.크 = null;
      this.큰 = null;
      this.쾌 = null;
    } 
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void removeDetachedView(View paramView, boolean paramBoolean) {
    StringBuilder stringBuilder;
    ef ef = 投(paramView);
    if (ef != null)
      if (ef.ぱ()) {
        ef.辛 &= 0xFFFFFEFF;
      } else if (!ef.寂()) {
        stringBuilder = new StringBuilder("Called removeDetachedView with a view which is not flagged as tmp detached.");
        stringBuilder.append(ef);
        stringBuilder.append(死());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    stringBuilder.clearAnimation();
    投((View)stringBuilder);
    super.removeDetachedView((View)stringBuilder, paramBoolean);
  }
  
  public final void requestChildFocus(View paramView1, View paramView2) {
    boolean bool1;
    邪 邪 = this.帰.冷;
    boolean bool3 = true;
    if (邪 != null && 邪.冷) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    boolean bool2 = bool3;
    if (!bool1)
      if (か()) {
        bool2 = bool3;
      } else {
        bool2 = false;
      }  
    if (!bool2 && paramView2 != null)
      키(paramView1, paramView2); 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public final boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    return this.帰.택(this, paramView, paramRect, paramBoolean, false);
  }
  
  public final void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    ArrayList<se> arrayList = this.歩;
    int j = arrayList.size();
    for (int i = 0; i < j; i++)
      ((se)arrayList.get(i)).getClass(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public final void requestLayout() {
    if (this.触 == 0 && !this.あ) {
      super.requestLayout();
      return;
    } 
    this.投 = true;
  }
  
  public final void scrollBy(int paramInt1, int paramInt2) {
    pe pe1 = this.帰;
    if (pe1 == null)
      return; 
    if (this.あ)
      return; 
    boolean bool1 = pe1.暑();
    boolean bool2 = this.帰.冷();
    if (bool1 || bool2) {
      if (!bool1)
        paramInt1 = 0; 
      if (!bool2)
        paramInt2 = 0; 
      타(paramInt1, paramInt2, null);
    } 
  }
  
  public final void scrollTo(int paramInt1, int paramInt2) {}
  
  public final void sendAccessibilityEventUnchecked(AccessibilityEvent paramAccessibilityEvent) {
    boolean bool1 = か();
    int i = 0;
    boolean bool = false;
    if (bool1) {
      if (paramAccessibilityEvent != null) {
        i = Build.VERSION.SDK_INT;
        i = prn.硬(paramAccessibilityEvent);
      } else {
        i = 0;
      } 
      if (i == 0)
        i = bool; 
      this.ち |= i;
      i = 1;
    } 
    if (i != 0)
      return; 
    super.sendAccessibilityEventUnchecked(paramAccessibilityEvent);
  }
  
  public void setAccessibilityDelegateCompat(gf paramgf) {
    this.ぼ = paramgf;
    rw.帰((View)this, (nul)paramgf);
  }
  
  public void setAdapter(he paramhe) {
    setLayoutFrozen(false);
    he he1 = this.壊;
    h9 h91 = this.淋;
    if (he1 != null) {
      he1.硬.unregisterObserver(h91);
      this.壊.getClass();
    } 
    me me1 = this.ㅌ;
    if (me1 != null)
      me1.冷(); 
    pe pe1 = this.帰;
    we we1 = this.怖;
    if (pe1 != null) {
      pe1.탐(we1);
      this.帰.탑(we1);
    } 
    we1.硬.clear();
    we1.暑();
    料 料1 = this.痛;
    料1.苦(料1.堅);
    料1.苦(料1.熱);
    he he2 = this.壊;
    this.壊 = paramhe;
    if (paramhe != null)
      paramhe.硬.registerObserver(h91); 
    paramhe = this.壊;
    we1.硬.clear();
    we1.暑();
    ve ve = we1.熱();
    if (he2 != null)
      ve.堅--; 
    if (ve.堅 == 0) {
      int i = 0;
      while (true) {
        SparseArray sparseArray = ve.硬;
        if (i < sparseArray.size()) {
          ((ue)sparseArray.valueAt(i)).硬.clear();
          i++;
          continue;
        } 
        break;
      } 
    } 
    if (paramhe != null)
      ve.堅++; 
    this.투.寒 = true;
    크(false);
    requestLayout();
  }
  
  public void setChildDrawingOrderCallback(je paramje) {
    if (paramje == null)
      return; 
    setChildrenDrawingOrderEnabled(false);
  }
  
  public void setClipToPadding(boolean paramBoolean) {
    if (paramBoolean != this.起) {
      this.키 = null;
      this.크 = null;
      this.큰 = null;
      this.쾌 = null;
    } 
    this.起 = paramBoolean;
    super.setClipToPadding(paramBoolean);
    if (this.噛)
      requestLayout(); 
  }
  
  public void setEdgeEffectFactory(ke paramke) {
    paramke.getClass();
    this.코 = paramke;
    this.키 = null;
    this.크 = null;
    this.큰 = null;
    this.쾌 = null;
  }
  
  public void setHasFixedSize(boolean paramBoolean) {
    this.寝 = paramBoolean;
  }
  
  public void setItemAnimator(me paramme) {
    me me1 = this.ㅌ;
    if (me1 != null) {
      me1.冷();
      this.ㅌ.硬 = null;
    } 
    this.ㅌ = paramme;
    if (paramme != null)
      paramme.硬 = this.私; 
  }
  
  public void setItemViewCacheSize(int paramInt) {
    we we1 = this.怖;
    we1.冷 = paramInt;
    we1.ぱ();
  }
  
  @Deprecated
  public void setLayoutFrozen(boolean paramBoolean) {
    suppressLayout(paramBoolean);
  }
  
  public void setLayoutManager(pe parampe) {
    if (parampe == this.帰)
      return; 
    boolean bool = false;
    setScrollState(0);
    df df1 = this.톨;
    df1.起.removeCallbacks((Runnable)df1);
    df1.恐.abortAnimation();
    pe pe1 = this.帰;
    if (pe1 != null) {
      邪 邪 = pe1.冷;
      if (邪 != null)
        邪.寒(); 
    } 
    pe pe2 = this.帰;
    we we1 = this.怖;
    if (pe2 != null) {
      me me1 = this.ㅌ;
      if (me1 != null)
        me1.冷(); 
      this.帰.탐(we1);
      this.帰.탑(we1);
      we1.硬.clear();
      we1.暑();
      if (this.踊) {
        pe pe3 = this.帰;
        pe3.美 = false;
        pe3.ゃ(this);
      } 
      this.帰.투(null);
      this.帰 = null;
    } else {
      we1.硬.clear();
      we1.暑();
    } 
    話 話1 = this.痒;
    話1.堅.美();
    ArrayList<View> arrayList = 話1.熱;
    int i = arrayList.size();
    while (true) {
      RecyclerView recyclerView;
      i--;
      ge ge1 = 話1.硬;
      if (i >= 0) {
        View view = arrayList.get(i);
        ge1.getClass();
        ef ef = 投(view);
        if (ef != null) {
          int k = ef.淋;
          recyclerView = ge1.硬;
          if (recyclerView.か()) {
            ef.怖 = k;
            recyclerView.少.add(ef);
          } else {
            rw.踊(ef.硬, k);
          } 
          ef.淋 = 0;
        } 
        arrayList.remove(i);
        continue;
      } 
      int j = recyclerView.熱();
      i = bool;
      while (true) {
        StringBuilder stringBuilder;
        he he1;
        RecyclerView recyclerView1 = ((ge)recyclerView).硬;
        if (i < j) {
          View view = recyclerView1.getChildAt(i);
          recyclerView1.getClass();
          投(view);
          he1 = recyclerView1.壊;
          view.clearAnimation();
          i++;
          continue;
        } 
        he1.removeAllViews();
        this.帰 = parampe;
        if (parampe != null)
          if (parampe.堅 == null) {
            parampe.투(this);
            if (this.踊)
              this.帰.美 = true; 
          } else {
            stringBuilder = new StringBuilder("LayoutManager ");
            stringBuilder.append(parampe);
            stringBuilder.append(" is already attached to a RecyclerView:");
            stringBuilder.append(parampe.堅.死());
            throw new IllegalArgumentException(stringBuilder.toString());
          }  
        stringBuilder.ぱ();
        requestLayout();
        return;
      } 
      break;
    } 
  }
  
  @Deprecated
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    int i = Build.VERSION.SDK_INT;
    if (paramLayoutTransition == null) {
      super.setLayoutTransition(null);
      return;
    } 
    throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    k5 k51 = getScrollingChildHelper();
    if (k51.暑) {
      WeakHashMap weakHashMap = rw.硬;
      int i = Build.VERSION.SDK_INT;
      gw.壊(k51.熱);
    } 
    k51.暑 = paramBoolean;
  }
  
  public void setOnFlingListener(re paramre) {
    this.택 = paramre;
  }
  
  @Deprecated
  public void setOnScrollListener(te paramte) {
    this.퉁 = paramte;
  }
  
  public void setPreserveFocusAfterLayout(boolean paramBoolean) {
    this.톤 = paramBoolean;
  }
  
  public void setRecycledViewPool(ve paramve) {
    we we1 = this.怖;
    ve ve1 = we1.美;
    if (ve1 != null)
      ve1.堅--; 
    we1.美 = paramve;
    if (paramve != null && we1.旨.getAdapter() != null) {
      paramve = we1.美;
      paramve.堅++;
    } 
  }
  
  public void setRecyclerListener(xe paramxe) {}
  
  public void setScrollState(int paramInt) {
    if (paramInt == this.타)
      return; 
    this.타 = paramInt;
    if (paramInt != 2) {
      df df1 = this.톨;
      df1.起.removeCallbacks((Runnable)df1);
      df1.恐.abortAnimation();
      pe pe2 = this.帰;
      if (pe2 != null) {
        邪 邪 = pe2.冷;
        if (邪 != null)
          邪.寒(); 
      } 
    } 
    pe pe1 = this.帰;
    if (pe1 != null)
      pe1.탈(paramInt); 
    te te1 = this.퉁;
    if (te1 != null)
      te1.硬(this, paramInt); 
    ArrayList arrayList = this.者;
    if (arrayList != null) {
      int i = arrayList.size();
      while (true) {
        if (--i >= 0) {
          ((te)this.者.get(i)).硬(this, paramInt);
          continue;
        } 
        break;
      } 
    } 
  }
  
  public void setScrollingTouchSlop(int paramInt) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    if (paramInt != 1) {
      this.태 = viewConfiguration.getScaledTouchSlop();
      return;
    } 
    this.태 = viewConfiguration.getScaledPagingTouchSlop();
  }
  
  public void setViewCacheExtension(cf paramcf) {
    this.怖.getClass();
  }
  
  public final boolean startNestedScroll(int paramInt) {
    return getScrollingChildHelper().美(paramInt, 0);
  }
  
  public final void stopNestedScroll() {
    getScrollingChildHelper().旨(0);
  }
  
  public final void suppressLayout(boolean paramBoolean) {
    if (paramBoolean != this.あ) {
      不("Do not suppressLayout in layout or scroll");
      if (!paramBoolean) {
        this.あ = false;
        if (this.投 && this.帰 != null && this.壊 != null)
          requestLayout(); 
        this.投 = false;
        return;
      } 
      long l = SystemClock.uptimeMillis();
      onTouchEvent(MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0));
      this.あ = true;
      this.か = true;
      setScrollState(0);
      df df1 = this.톨;
      df1.起.removeCallbacks((Runnable)df1);
      df1.恐.abortAnimation();
      pe pe1 = this.帰;
      if (pe1 != null) {
        邪 邪 = pe1.冷;
        if (邪 != null)
          邪.寒(); 
      } 
    } 
  }
  
  public final Rect あ(View paramView) {
    qe qe = (qe)paramView.getLayoutParams();
    boolean bool = qe.熱;
    Rect rect = qe.堅;
    if (!bool)
      return rect; 
    if (this.투.美 && (qe.堅() || qe.硬.美()))
      return rect; 
    rect.set(0, 0, 0, 0);
    ArrayList<ne> arrayList = this.返;
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      Rect rect1 = this.興;
      rect1.set(0, 0, 0, 0);
      ((ne)arrayList.get(i)).getClass();
      ((qe)paramView.getLayoutParams()).硬();
      rect1.set(0, 0, 0, 0);
      rect.left += rect1.left;
      rect.top += rect1.top;
      rect.right += rect1.right;
      rect.bottom += rect1.bottom;
    } 
    qe.熱 = false;
    return rect;
  }
  
  public final boolean か() {
    return (this.も > 0);
  }
  
  public final void ち(int paramInt) {
    if (this.帰 == null)
      return; 
    setScrollState(2);
    this.帰.테(paramInt);
    awakenScrollBars();
  }
  
  public final void ぱ() {
    int j = this.痒.旨();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      ef ef = 投(this.痒.美(i));
      if (!ef.寂()) {
        ef.暑 = -1;
        ef.美 = -1;
      } 
    } 
    we we1 = this.怖;
    ArrayList<ef> arrayList = we1.熱;
    j = arrayList.size();
    for (i = 0; i < j; i++) {
      ef ef = arrayList.get(i);
      ef.暑 = -1;
      ef.美 = -1;
    } 
    arrayList = we1.硬;
    j = arrayList.size();
    for (i = 0; i < j; i++) {
      ef ef = arrayList.get(i);
      ef.暑 = -1;
      ef.美 = -1;
    } 
    arrayList = we1.堅;
    if (arrayList != null) {
      j = arrayList.size();
      for (i = bool; i < j; i++) {
        ef ef = we1.堅.get(i);
        ef.暑 = -1;
        ef.美 = -1;
      } 
    } 
  }
  
  public final void も(boolean paramBoolean) {
    int j = this.も;
    int i = 1;
    this.も = --j;
    if (j < 1) {
      this.も = 0;
      if (paramBoolean) {
        j = this.ち;
        this.ち = 0;
        if (j != 0) {
          AccessibilityManager accessibilityManager = this.ゃ;
          if (accessibilityManager == null || !accessibilityManager.isEnabled())
            i = 0; 
          if (i) {
            AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain();
            accessibilityEvent.setEventType(2048);
            i = Build.VERSION.SDK_INT;
            prn.堅(accessibilityEvent, j);
            sendAccessibilityEventUnchecked(accessibilityEvent);
          } 
        } 
        ArrayList<ef> arrayList = this.少;
        for (i = arrayList.size() - 1; i >= 0; i--) {
          ef ef = arrayList.get(i);
          if (ef.硬.getParent() == this && !ef.寂()) {
            j = ef.怖;
            if (j != -1) {
              rw.踊(ef.硬, j);
              ef.怖 = -1;
            } 
          } 
        } 
        arrayList.clear();
      } 
    } 
  }
  
  public final void ゃ() {
    int j = this.痒.旨();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      ((qe)this.痒.美(i).getLayoutParams()).熱 = true; 
    ArrayList arrayList = this.怖.熱;
    j = arrayList.size();
    for (i = bool; i < j; i++) {
      qe qe = (qe)((ef)arrayList.get(i)).硬.getLayoutParams();
      if (qe != null)
        qe.熱 = true; 
    } 
  }
  
  public final void わ() {
    this.も++;
  }
  
  public final void ㅌ() {
    VelocityTracker velocityTracker = this.탄;
    if (velocityTracker != null)
      velocityTracker.clear(); 
    boolean bool2 = false;
    탕(0);
    EdgeEffect edgeEffect = this.쾌;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = this.쾌.isFinished();
    } 
    edgeEffect = this.크;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.크.isFinished();
    } 
    edgeEffect = this.큰;
    bool2 = bool1;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = bool1 | this.큰.isFinished();
    } 
    edgeEffect = this.키;
    bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.키.isFinished();
    } 
    if (bool1)
      rw.痒((View)this); 
  }
  
  public final void 不(String paramString) {
    if (か()) {
      StringBuilder stringBuilder;
      if (paramString == null) {
        stringBuilder = new StringBuilder("Cannot call this method while RecyclerView is computing a layout or scrolling");
        stringBuilder.append(死());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      throw new IllegalStateException(stringBuilder);
    } 
    if (this.若 > 0) {
      StringBuilder stringBuilder = new StringBuilder("");
      stringBuilder.append(死());
      new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public final long 噛(ef paramef) {
    return this.壊.堅 ? paramef.冷 : paramef.熱;
  }
  
  public final void 壊(bf parambf) {
    if (getScrollState() == 2) {
      OverScroller overScroller = this.톨.恐;
      overScroller.getFinalX();
      overScroller.getCurrX();
      parambf.getClass();
      overScroller.getFinalY();
      overScroller.getCurrY();
      return;
    } 
    parambf.getClass();
  }
  
  public final void 嬉() {
    if (!this.噛 || this.赤) {
      ss.硬("RV FullInvalidate");
      寂();
      ss.堅();
      return;
    } 
    if (!this.痛.美())
      return; 
    this.痛.getClass();
    if (this.痛.美()) {
      ss.硬("RV FullInvalidate");
      寂();
      ss.堅();
    } 
  }
  
  public final void 寂() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 壊 : Ly/he;
    //   4: ifnonnull -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield 帰 : Ly/pe;
    //   12: ifnonnull -> 16
    //   15: return
    //   16: aload_0
    //   17: getfield 투 : Ly/bf;
    //   20: astore #11
    //   22: aload #11
    //   24: iconst_0
    //   25: putfield 不 : Z
    //   28: aload #11
    //   30: getfield 暑 : I
    //   33: iconst_1
    //   34: if_icmpne -> 56
    //   37: aload_0
    //   38: invokevirtual 淋 : ()V
    //   41: aload_0
    //   42: getfield 帰 : Ly/pe;
    //   45: aload_0
    //   46: invokevirtual 톤 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   49: aload_0
    //   50: invokevirtual 怖 : ()V
    //   53: goto -> 149
    //   56: aload_0
    //   57: getfield 痛 : Ly/料;
    //   60: astore #7
    //   62: aload #7
    //   64: getfield 熱 : Ljava/util/ArrayList;
    //   67: invokevirtual isEmpty : ()Z
    //   70: ifne -> 89
    //   73: aload #7
    //   75: getfield 堅 : Ljava/util/ArrayList;
    //   78: invokevirtual isEmpty : ()Z
    //   81: ifne -> 89
    //   84: iconst_1
    //   85: istore_1
    //   86: goto -> 91
    //   89: iconst_0
    //   90: istore_1
    //   91: iload_1
    //   92: ifne -> 137
    //   95: aload_0
    //   96: getfield 帰 : Ly/pe;
    //   99: getfield 悲 : I
    //   102: aload_0
    //   103: invokevirtual getWidth : ()I
    //   106: if_icmpne -> 137
    //   109: aload_0
    //   110: getfield 帰 : Ly/pe;
    //   113: getfield 寂 : I
    //   116: aload_0
    //   117: invokevirtual getHeight : ()I
    //   120: if_icmpeq -> 126
    //   123: goto -> 137
    //   126: aload_0
    //   127: getfield 帰 : Ly/pe;
    //   130: aload_0
    //   131: invokevirtual 톤 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   134: goto -> 149
    //   137: aload_0
    //   138: getfield 帰 : Ly/pe;
    //   141: aload_0
    //   142: invokevirtual 톤 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   145: aload_0
    //   146: invokevirtual 怖 : ()V
    //   149: aload #11
    //   151: iconst_4
    //   152: invokevirtual 硬 : (I)V
    //   155: aload_0
    //   156: invokevirtual 탐 : ()V
    //   159: aload_0
    //   160: invokevirtual わ : ()V
    //   163: aload #11
    //   165: iconst_1
    //   166: putfield 暑 : I
    //   169: aload #11
    //   171: getfield 辛 : Z
    //   174: istore #4
    //   176: aconst_null
    //   177: astore #10
    //   179: aload_0
    //   180: getfield 怖 : Ly/we;
    //   183: astore #7
    //   185: aload_0
    //   186: getfield 臭 : Ly/ex;
    //   189: astore #8
    //   191: iload #4
    //   193: ifeq -> 1206
    //   196: aload_0
    //   197: getfield 痒 : Ly/話;
    //   200: invokevirtual 冷 : ()I
    //   203: iconst_1
    //   204: isub
    //   205: istore_1
    //   206: iload_1
    //   207: iflt -> 762
    //   210: aload_0
    //   211: getfield 痒 : Ly/話;
    //   214: iload_1
    //   215: invokevirtual 暑 : (I)Landroid/view/View;
    //   218: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   221: astore #9
    //   223: aload #9
    //   225: invokevirtual 寂 : ()Z
    //   228: ifeq -> 234
    //   231: goto -> 755
    //   234: aload_0
    //   235: aload #9
    //   237: invokevirtual 噛 : (Ly/ef;)J
    //   240: lstore #5
    //   242: aload_0
    //   243: getfield ㅌ : Ly/me;
    //   246: invokevirtual getClass : ()Ljava/lang/Class;
    //   249: pop
    //   250: new y/le
    //   253: dup
    //   254: iconst_0
    //   255: invokespecial <init> : (I)V
    //   258: astore #13
    //   260: aload #13
    //   262: aload #9
    //   264: invokevirtual 硬 : (Ly/ef;)V
    //   267: aload #8
    //   269: getfield 熱 : Ljava/lang/Object;
    //   272: checkcast y/烏
    //   275: lload #5
    //   277: aconst_null
    //   278: invokevirtual 冷 : (JLjava/lang/Long;)Ljava/lang/Object;
    //   281: checkcast y/ef
    //   284: astore #12
    //   286: aload #12
    //   288: ifnull -> 746
    //   291: aload #12
    //   293: invokevirtual 寂 : ()Z
    //   296: ifne -> 746
    //   299: aload #8
    //   301: getfield 堅 : Ljava/lang/Object;
    //   304: checkcast y/ol
    //   307: aload #12
    //   309: aconst_null
    //   310: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   313: checkcast y/dx
    //   316: astore #14
    //   318: aload #14
    //   320: ifnull -> 338
    //   323: aload #14
    //   325: getfield 硬 : I
    //   328: iconst_1
    //   329: iand
    //   330: ifeq -> 338
    //   333: iconst_1
    //   334: istore_2
    //   335: goto -> 340
    //   338: iconst_0
    //   339: istore_2
    //   340: aload #8
    //   342: getfield 堅 : Ljava/lang/Object;
    //   345: checkcast y/ol
    //   348: aload #9
    //   350: aconst_null
    //   351: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   354: checkcast y/dx
    //   357: astore #14
    //   359: aload #14
    //   361: ifnull -> 379
    //   364: iconst_1
    //   365: aload #14
    //   367: getfield 硬 : I
    //   370: iand
    //   371: ifeq -> 379
    //   374: iconst_1
    //   375: istore_3
    //   376: goto -> 381
    //   379: iconst_0
    //   380: istore_3
    //   381: iload_2
    //   382: ifeq -> 404
    //   385: aload #12
    //   387: aload #9
    //   389: if_acmpne -> 404
    //   392: aload #8
    //   394: aload #9
    //   396: aload #13
    //   398: invokevirtual 堅 : (Ly/ef;Ly/le;)V
    //   401: goto -> 755
    //   404: aload #8
    //   406: aload #12
    //   408: iconst_4
    //   409: invokevirtual ぱ : (Ly/ef;I)Ly/le;
    //   412: astore #14
    //   414: aload #8
    //   416: aload #9
    //   418: aload #13
    //   420: invokevirtual 堅 : (Ly/ef;Ly/le;)V
    //   423: aload #8
    //   425: aload #9
    //   427: bipush #8
    //   429: invokevirtual ぱ : (Ly/ef;I)Ly/le;
    //   432: astore #13
    //   434: aload #14
    //   436: ifnonnull -> 655
    //   439: aload_0
    //   440: getfield 痒 : Ly/話;
    //   443: invokevirtual 冷 : ()I
    //   446: istore_3
    //   447: iconst_0
    //   448: istore_2
    //   449: iload_2
    //   450: iload_3
    //   451: if_icmpge -> 635
    //   454: aload_0
    //   455: getfield 痒 : Ly/話;
    //   458: iload_2
    //   459: invokevirtual 暑 : (I)Landroid/view/View;
    //   462: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   465: astore #13
    //   467: aload #13
    //   469: aload #9
    //   471: if_acmpne -> 477
    //   474: goto -> 628
    //   477: aload_0
    //   478: aload #13
    //   480: invokevirtual 噛 : (Ly/ef;)J
    //   483: lload #5
    //   485: lcmp
    //   486: ifne -> 628
    //   489: aload_0
    //   490: getfield 壊 : Ly/he;
    //   493: astore #7
    //   495: aload #7
    //   497: ifnull -> 568
    //   500: aload #7
    //   502: getfield 堅 : Z
    //   505: ifeq -> 568
    //   508: new java/lang/StringBuilder
    //   511: dup
    //   512: ldc_w 'Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\\n ViewHolder 1:'
    //   515: invokespecial <init> : (Ljava/lang/String;)V
    //   518: astore #7
    //   520: aload #7
    //   522: aload #13
    //   524: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   527: pop
    //   528: aload #7
    //   530: ldc_w ' \\n View Holder 2:'
    //   533: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   536: pop
    //   537: aload #7
    //   539: aload #9
    //   541: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   544: pop
    //   545: aload #7
    //   547: aload_0
    //   548: invokevirtual 死 : ()Ljava/lang/String;
    //   551: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   554: pop
    //   555: new java/lang/IllegalStateException
    //   558: dup
    //   559: aload #7
    //   561: invokevirtual toString : ()Ljava/lang/String;
    //   564: invokespecial <init> : (Ljava/lang/String;)V
    //   567: athrow
    //   568: new java/lang/StringBuilder
    //   571: dup
    //   572: ldc_w 'Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\\n ViewHolder 1:'
    //   575: invokespecial <init> : (Ljava/lang/String;)V
    //   578: astore #7
    //   580: aload #7
    //   582: aload #13
    //   584: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   587: pop
    //   588: aload #7
    //   590: ldc_w ' \\n View Holder 2:'
    //   593: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   596: pop
    //   597: aload #7
    //   599: aload #9
    //   601: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   604: pop
    //   605: aload #7
    //   607: aload_0
    //   608: invokevirtual 死 : ()Ljava/lang/String;
    //   611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   614: pop
    //   615: new java/lang/IllegalStateException
    //   618: dup
    //   619: aload #7
    //   621: invokevirtual toString : ()Ljava/lang/String;
    //   624: invokespecial <init> : (Ljava/lang/String;)V
    //   627: athrow
    //   628: iload_2
    //   629: iconst_1
    //   630: iadd
    //   631: istore_2
    //   632: goto -> 449
    //   635: aload #12
    //   637: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   640: pop
    //   641: aload #9
    //   643: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   646: pop
    //   647: aload_0
    //   648: invokevirtual 死 : ()Ljava/lang/String;
    //   651: pop
    //   652: goto -> 755
    //   655: aload #12
    //   657: iconst_0
    //   658: invokevirtual 悲 : (Z)V
    //   661: iload_2
    //   662: ifeq -> 671
    //   665: aload_0
    //   666: aload #12
    //   668: invokevirtual 寒 : (Ly/ef;)V
    //   671: aload #12
    //   673: aload #9
    //   675: if_acmpeq -> 721
    //   678: iload_3
    //   679: ifeq -> 688
    //   682: aload_0
    //   683: aload #9
    //   685: invokevirtual 寒 : (Ly/ef;)V
    //   688: aload #12
    //   690: aload #9
    //   692: putfield 旨 : Ly/ef;
    //   695: aload_0
    //   696: aload #12
    //   698: invokevirtual 寒 : (Ly/ef;)V
    //   701: aload #7
    //   703: aload #12
    //   705: invokevirtual 辛 : (Ly/ef;)V
    //   708: aload #9
    //   710: iconst_0
    //   711: invokevirtual 悲 : (Z)V
    //   714: aload #9
    //   716: aload #12
    //   718: putfield 不 : Ly/ef;
    //   721: aload_0
    //   722: getfield ㅌ : Ly/me;
    //   725: aload #12
    //   727: aload #9
    //   729: aload #14
    //   731: aload #13
    //   733: invokevirtual 硬 : (Ly/ef;Ly/ef;Ly/le;Ly/le;)Z
    //   736: ifeq -> 755
    //   739: aload_0
    //   740: invokevirtual 코 : ()V
    //   743: goto -> 755
    //   746: aload #8
    //   748: aload #9
    //   750: aload #13
    //   752: invokevirtual 堅 : (Ly/ef;Ly/le;)V
    //   755: iload_1
    //   756: iconst_1
    //   757: isub
    //   758: istore_1
    //   759: goto -> 206
    //   762: aload #8
    //   764: getfield 堅 : Ljava/lang/Object;
    //   767: checkcast y/ol
    //   770: getfield 恐 : I
    //   773: iconst_1
    //   774: isub
    //   775: istore_1
    //   776: iload_1
    //   777: iflt -> 1206
    //   780: aload #8
    //   782: getfield 堅 : Ljava/lang/Object;
    //   785: checkcast y/ol
    //   788: iload_1
    //   789: invokevirtual 旨 : (I)Ljava/lang/Object;
    //   792: checkcast y/ef
    //   795: astore #9
    //   797: aload #8
    //   799: getfield 堅 : Ljava/lang/Object;
    //   802: checkcast y/ol
    //   805: iload_1
    //   806: invokevirtual 不 : (I)Ljava/lang/Object;
    //   809: checkcast y/dx
    //   812: astore #12
    //   814: aload #12
    //   816: getfield 硬 : I
    //   819: istore_2
    //   820: aload_0
    //   821: getfield 年 : Ly/ge;
    //   824: astore #15
    //   826: iload_2
    //   827: iconst_3
    //   828: iand
    //   829: iconst_3
    //   830: if_icmpne -> 861
    //   833: aload #15
    //   835: getfield 硬 : Landroidx/recyclerview/widget/RecyclerView;
    //   838: astore #13
    //   840: aload #13
    //   842: getfield 帰 : Ly/pe;
    //   845: aload #9
    //   847: getfield 硬 : Landroid/view/View;
    //   850: aload #13
    //   852: getfield 怖 : Ly/we;
    //   855: invokevirtual 탕 : (Landroid/view/View;Ly/we;)V
    //   858: goto -> 1172
    //   861: iload_2
    //   862: iconst_1
    //   863: iand
    //   864: ifeq -> 924
    //   867: aload #12
    //   869: getfield 堅 : Ly/le;
    //   872: astore #13
    //   874: aload #13
    //   876: ifnonnull -> 907
    //   879: aload #15
    //   881: getfield 硬 : Landroidx/recyclerview/widget/RecyclerView;
    //   884: astore #13
    //   886: aload #13
    //   888: getfield 帰 : Ly/pe;
    //   891: aload #9
    //   893: getfield 硬 : Landroid/view/View;
    //   896: aload #13
    //   898: getfield 怖 : Ly/we;
    //   901: invokevirtual 탕 : (Landroid/view/View;Ly/we;)V
    //   904: goto -> 1172
    //   907: aload #15
    //   909: aload #9
    //   911: aload #13
    //   913: aload #12
    //   915: getfield 熱 : Ly/le;
    //   918: invokevirtual 旨 : (Ly/ef;Ly/le;Ly/le;)V
    //   921: goto -> 1172
    //   924: iload_2
    //   925: bipush #14
    //   927: iand
    //   928: bipush #14
    //   930: if_icmpne -> 953
    //   933: aload #15
    //   935: aload #9
    //   937: aload #12
    //   939: getfield 堅 : Ly/le;
    //   942: aload #12
    //   944: getfield 熱 : Ly/le;
    //   947: invokevirtual 美 : (Ly/ef;Ly/le;Ly/le;)V
    //   950: goto -> 1172
    //   953: iload_2
    //   954: bipush #12
    //   956: iand
    //   957: bipush #12
    //   959: if_icmpne -> 1126
    //   962: aload #12
    //   964: getfield 堅 : Ly/le;
    //   967: astore #13
    //   969: aload #12
    //   971: getfield 熱 : Ly/le;
    //   974: astore #14
    //   976: aload #15
    //   978: invokevirtual getClass : ()Ljava/lang/Class;
    //   981: pop
    //   982: aload #9
    //   984: iconst_0
    //   985: invokevirtual 悲 : (Z)V
    //   988: aload #15
    //   990: getfield 硬 : Landroidx/recyclerview/widget/RecyclerView;
    //   993: astore #15
    //   995: aload #15
    //   997: getfield 赤 : Z
    //   1000: ifeq -> 1030
    //   1003: aload #15
    //   1005: getfield ㅌ : Ly/me;
    //   1008: aload #9
    //   1010: aload #9
    //   1012: aload #13
    //   1014: aload #14
    //   1016: invokevirtual 硬 : (Ly/ef;Ly/ef;Ly/le;Ly/le;)Z
    //   1019: ifeq -> 1172
    //   1022: aload #15
    //   1024: invokevirtual 코 : ()V
    //   1027: goto -> 1172
    //   1030: aload #15
    //   1032: getfield ㅌ : Ly/me;
    //   1035: checkcast y/녀
    //   1038: astore #16
    //   1040: aload #16
    //   1042: invokevirtual getClass : ()Ljava/lang/Class;
    //   1045: pop
    //   1046: aload #13
    //   1048: getfield 堅 : I
    //   1051: istore_2
    //   1052: aload #14
    //   1054: getfield 堅 : I
    //   1057: istore_3
    //   1058: iload_2
    //   1059: iload_3
    //   1060: if_icmpne -> 1092
    //   1063: aload #13
    //   1065: getfield 熱 : I
    //   1068: aload #14
    //   1070: getfield 熱 : I
    //   1073: if_icmpeq -> 1079
    //   1076: goto -> 1092
    //   1079: aload #16
    //   1081: aload #9
    //   1083: invokevirtual 熱 : (Ly/ef;)V
    //   1086: iconst_0
    //   1087: istore #4
    //   1089: goto -> 1113
    //   1092: aload #16
    //   1094: aload #9
    //   1096: iload_2
    //   1097: aload #13
    //   1099: getfield 熱 : I
    //   1102: iload_3
    //   1103: aload #14
    //   1105: getfield 熱 : I
    //   1108: invokevirtual 美 : (Ly/ef;IIII)Z
    //   1111: istore #4
    //   1113: iload #4
    //   1115: ifeq -> 1172
    //   1118: aload #15
    //   1120: invokevirtual 코 : ()V
    //   1123: goto -> 1172
    //   1126: iload_2
    //   1127: iconst_4
    //   1128: iand
    //   1129: ifeq -> 1148
    //   1132: aload #15
    //   1134: aload #9
    //   1136: aload #12
    //   1138: getfield 堅 : Ly/le;
    //   1141: aconst_null
    //   1142: invokevirtual 旨 : (Ly/ef;Ly/le;Ly/le;)V
    //   1145: goto -> 1172
    //   1148: iload_2
    //   1149: bipush #8
    //   1151: iand
    //   1152: ifeq -> 1172
    //   1155: aload #15
    //   1157: aload #9
    //   1159: aload #12
    //   1161: getfield 堅 : Ly/le;
    //   1164: aload #12
    //   1166: getfield 熱 : Ly/le;
    //   1169: invokevirtual 美 : (Ly/ef;Ly/le;Ly/le;)V
    //   1172: aload #12
    //   1174: iconst_0
    //   1175: putfield 硬 : I
    //   1178: aload #12
    //   1180: aconst_null
    //   1181: putfield 堅 : Ly/le;
    //   1184: aload #12
    //   1186: aconst_null
    //   1187: putfield 熱 : Ly/le;
    //   1190: getstatic y/dx.暑 : Ly/q9;
    //   1193: aload #12
    //   1195: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   1198: pop
    //   1199: iload_1
    //   1200: iconst_1
    //   1201: isub
    //   1202: istore_1
    //   1203: goto -> 776
    //   1206: aload_0
    //   1207: getfield 帰 : Ly/pe;
    //   1210: aload #7
    //   1212: invokevirtual 탑 : (Ly/we;)V
    //   1215: aload #11
    //   1217: aload #11
    //   1219: getfield 冷 : I
    //   1222: putfield 堅 : I
    //   1225: iconst_0
    //   1226: istore_2
    //   1227: aload_0
    //   1228: iconst_0
    //   1229: putfield 赤 : Z
    //   1232: aload_0
    //   1233: iconst_0
    //   1234: putfield わ : Z
    //   1237: aload #11
    //   1239: iconst_0
    //   1240: putfield 辛 : Z
    //   1243: aload #11
    //   1245: iconst_0
    //   1246: putfield ぱ : Z
    //   1249: aload_0
    //   1250: getfield 帰 : Ly/pe;
    //   1253: iconst_0
    //   1254: putfield 寒 : Z
    //   1257: aload #7
    //   1259: getfield 堅 : Ljava/util/ArrayList;
    //   1262: astore #9
    //   1264: aload #9
    //   1266: ifnull -> 1274
    //   1269: aload #9
    //   1271: invokevirtual clear : ()V
    //   1274: aload_0
    //   1275: getfield 帰 : Ly/pe;
    //   1278: astore #9
    //   1280: aload #9
    //   1282: getfield ぱ : Z
    //   1285: ifeq -> 1305
    //   1288: aload #9
    //   1290: iconst_0
    //   1291: putfield 辛 : I
    //   1294: aload #9
    //   1296: iconst_0
    //   1297: putfield ぱ : Z
    //   1300: aload #7
    //   1302: invokevirtual ぱ : ()V
    //   1305: aload_0
    //   1306: getfield 帰 : Ly/pe;
    //   1309: aload #11
    //   1311: invokevirtual 타 : (Ly/bf;)V
    //   1314: aload_0
    //   1315: iconst_1
    //   1316: invokevirtual も : (Z)V
    //   1319: aload_0
    //   1320: iconst_0
    //   1321: invokevirtual 탑 : (Z)V
    //   1324: aload #8
    //   1326: invokevirtual 暑 : ()V
    //   1329: aload_0
    //   1330: getfield 僕 : [I
    //   1333: astore #7
    //   1335: aload #7
    //   1337: iconst_0
    //   1338: iaload
    //   1339: istore_1
    //   1340: aload #7
    //   1342: iconst_1
    //   1343: iaload
    //   1344: istore_3
    //   1345: aload_0
    //   1346: aload #7
    //   1348: invokevirtual 歩 : ([I)V
    //   1351: aload #7
    //   1353: iconst_0
    //   1354: iaload
    //   1355: iload_1
    //   1356: if_icmpne -> 1375
    //   1359: aload #7
    //   1361: iconst_1
    //   1362: iaload
    //   1363: iload_3
    //   1364: if_icmpeq -> 1370
    //   1367: goto -> 1375
    //   1370: iconst_0
    //   1371: istore_1
    //   1372: goto -> 1377
    //   1375: iconst_1
    //   1376: istore_1
    //   1377: iload_1
    //   1378: ifeq -> 1387
    //   1381: aload_0
    //   1382: iconst_0
    //   1383: iconst_0
    //   1384: invokevirtual 痒 : (II)V
    //   1387: aload_0
    //   1388: getfield 톤 : Z
    //   1391: ifeq -> 1861
    //   1394: aload_0
    //   1395: getfield 壊 : Ly/he;
    //   1398: ifnull -> 1861
    //   1401: aload_0
    //   1402: invokevirtual hasFocus : ()Z
    //   1405: ifeq -> 1861
    //   1408: aload_0
    //   1409: invokevirtual getDescendantFocusability : ()I
    //   1412: ldc_w 393216
    //   1415: if_icmpeq -> 1861
    //   1418: aload_0
    //   1419: invokevirtual getDescendantFocusability : ()I
    //   1422: ldc_w 131072
    //   1425: if_icmpne -> 1438
    //   1428: aload_0
    //   1429: invokevirtual isFocused : ()Z
    //   1432: ifeq -> 1438
    //   1435: goto -> 1861
    //   1438: aload_0
    //   1439: invokevirtual isFocused : ()Z
    //   1442: ifne -> 1466
    //   1445: aload_0
    //   1446: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   1449: astore #7
    //   1451: aload_0
    //   1452: getfield 痒 : Ly/話;
    //   1455: aload #7
    //   1457: invokevirtual 辛 : (Landroid/view/View;)Z
    //   1460: ifne -> 1466
    //   1463: goto -> 1861
    //   1466: aload #11
    //   1468: getfield 嬉 : J
    //   1471: lstore #5
    //   1473: lload #5
    //   1475: ldc2_w -1
    //   1478: lcmp
    //   1479: ifeq -> 1619
    //   1482: aload_0
    //   1483: getfield 壊 : Ly/he;
    //   1486: getfield 堅 : Z
    //   1489: istore #4
    //   1491: iload #4
    //   1493: ifeq -> 1619
    //   1496: iload #4
    //   1498: ifne -> 1507
    //   1501: aconst_null
    //   1502: astore #8
    //   1504: goto -> 1612
    //   1507: aload_0
    //   1508: getfield 痒 : Ly/話;
    //   1511: invokevirtual 旨 : ()I
    //   1514: istore_3
    //   1515: iconst_0
    //   1516: istore_1
    //   1517: aconst_null
    //   1518: astore #7
    //   1520: aload #7
    //   1522: astore #8
    //   1524: iload_1
    //   1525: iload_3
    //   1526: if_icmpge -> 1612
    //   1529: aload_0
    //   1530: getfield 痒 : Ly/話;
    //   1533: iload_1
    //   1534: invokevirtual 美 : (I)Landroid/view/View;
    //   1537: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   1540: astore #8
    //   1542: aload #7
    //   1544: astore #9
    //   1546: aload #8
    //   1548: ifnull -> 1601
    //   1551: aload #7
    //   1553: astore #9
    //   1555: aload #8
    //   1557: invokevirtual 不 : ()Z
    //   1560: ifne -> 1601
    //   1563: aload #7
    //   1565: astore #9
    //   1567: aload #8
    //   1569: getfield 冷 : J
    //   1572: lload #5
    //   1574: lcmp
    //   1575: ifne -> 1601
    //   1578: aload #8
    //   1580: astore #7
    //   1582: aload_0
    //   1583: getfield 痒 : Ly/話;
    //   1586: aload #8
    //   1588: getfield 硬 : Landroid/view/View;
    //   1591: invokevirtual 辛 : (Landroid/view/View;)Z
    //   1594: ifeq -> 1622
    //   1597: aload #8
    //   1599: astore #9
    //   1601: iload_1
    //   1602: iconst_1
    //   1603: iadd
    //   1604: istore_1
    //   1605: aload #9
    //   1607: astore #7
    //   1609: goto -> 1520
    //   1612: aload #8
    //   1614: astore #7
    //   1616: goto -> 1622
    //   1619: aconst_null
    //   1620: astore #7
    //   1622: aload #7
    //   1624: ifnull -> 1664
    //   1627: aload_0
    //   1628: getfield 痒 : Ly/話;
    //   1631: astore #8
    //   1633: aload #7
    //   1635: getfield 硬 : Landroid/view/View;
    //   1638: astore #7
    //   1640: aload #8
    //   1642: aload #7
    //   1644: invokevirtual 辛 : (Landroid/view/View;)Z
    //   1647: ifne -> 1664
    //   1650: aload #7
    //   1652: invokevirtual hasFocusable : ()Z
    //   1655: ifne -> 1661
    //   1658: goto -> 1664
    //   1661: goto -> 1798
    //   1664: aload #10
    //   1666: astore #7
    //   1668: aload_0
    //   1669: getfield 痒 : Ly/話;
    //   1672: invokevirtual 冷 : ()I
    //   1675: ifle -> 1798
    //   1678: aload #11
    //   1680: getfield 苦 : I
    //   1683: istore_3
    //   1684: iload_2
    //   1685: istore_1
    //   1686: iload_3
    //   1687: iconst_m1
    //   1688: if_icmpeq -> 1693
    //   1691: iload_3
    //   1692: istore_1
    //   1693: aload #11
    //   1695: invokevirtual 堅 : ()I
    //   1698: istore_3
    //   1699: iload_1
    //   1700: istore_2
    //   1701: iload_2
    //   1702: iload_3
    //   1703: if_icmpge -> 1746
    //   1706: aload_0
    //   1707: iload_2
    //   1708: invokevirtual 踊 : (I)Ly/ef;
    //   1711: astore #7
    //   1713: aload #7
    //   1715: ifnonnull -> 1721
    //   1718: goto -> 1746
    //   1721: aload #7
    //   1723: getfield 硬 : Landroid/view/View;
    //   1726: astore #7
    //   1728: aload #7
    //   1730: invokevirtual hasFocusable : ()Z
    //   1733: ifeq -> 1739
    //   1736: goto -> 1798
    //   1739: iload_2
    //   1740: iconst_1
    //   1741: iadd
    //   1742: istore_2
    //   1743: goto -> 1701
    //   1746: iload_3
    //   1747: iload_1
    //   1748: invokestatic min : (II)I
    //   1751: istore_1
    //   1752: iload_1
    //   1753: iconst_1
    //   1754: isub
    //   1755: istore_1
    //   1756: aload #10
    //   1758: astore #7
    //   1760: iload_1
    //   1761: iflt -> 1798
    //   1764: aload_0
    //   1765: iload_1
    //   1766: invokevirtual 踊 : (I)Ly/ef;
    //   1769: astore #7
    //   1771: aload #7
    //   1773: ifnonnull -> 1783
    //   1776: aload #10
    //   1778: astore #7
    //   1780: goto -> 1798
    //   1783: aload #7
    //   1785: getfield 硬 : Landroid/view/View;
    //   1788: astore #7
    //   1790: aload #7
    //   1792: invokevirtual hasFocusable : ()Z
    //   1795: ifeq -> 1752
    //   1798: aload #7
    //   1800: ifnull -> 1861
    //   1803: aload #11
    //   1805: getfield 悲 : I
    //   1808: istore_1
    //   1809: aload #7
    //   1811: astore #8
    //   1813: iload_1
    //   1814: i2l
    //   1815: ldc2_w -1
    //   1818: lcmp
    //   1819: ifeq -> 1855
    //   1822: aload #7
    //   1824: iload_1
    //   1825: invokevirtual findViewById : (I)Landroid/view/View;
    //   1828: astore #9
    //   1830: aload #7
    //   1832: astore #8
    //   1834: aload #9
    //   1836: ifnull -> 1855
    //   1839: aload #7
    //   1841: astore #8
    //   1843: aload #9
    //   1845: invokevirtual isFocusable : ()Z
    //   1848: ifeq -> 1855
    //   1851: aload #9
    //   1853: astore #8
    //   1855: aload #8
    //   1857: invokevirtual requestFocus : ()Z
    //   1860: pop
    //   1861: aload #11
    //   1863: ldc2_w -1
    //   1866: putfield 嬉 : J
    //   1869: aload #11
    //   1871: iconst_m1
    //   1872: putfield 苦 : I
    //   1875: aload #11
    //   1877: iconst_m1
    //   1878: putfield 悲 : I
    //   1881: return
  }
  
  public final void 寒(ef paramef) {
    View view = paramef.硬;
    if (view.getParent() == this) {
      i = 1;
    } else {
      i = 0;
    } 
    this.怖.辛(触(view));
    if (paramef.ぱ()) {
      this.痒.堅(view, -1, view.getLayoutParams(), true);
      return;
    } 
    if (!i) {
      this.痒.硬(-1, view, true);
      return;
    } 
    話 話1 = this.痒;
    int i = 話1.硬.硬.indexOfChild(view);
    if (i >= 0) {
      話1.堅.旨(i);
      話1.不(view);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("view is not a child, cannot hide ");
    stringBuilder.append(view);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final int 寝(ef paramef) {
    int i = paramef.辛;
    int k = 0;
    if ((i & 0x20C) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0 || !paramef.寒())
      return -1; 
    料 料1 = this.痛;
    int j = paramef.熱;
    ArrayList<噌> arrayList = 料1.堅;
    int m = arrayList.size();
    while (true) {
      i = j;
      if (k < m) {
        噌 噌 = arrayList.get(k);
        i = 噌.硬;
        if (i != 1) {
          if (i != 2) {
            if (i != 8) {
              i = j;
            } else {
              i = 噌.堅;
              if (i == j) {
                i = 噌.暑;
              } else {
                int n = j;
                if (i < j)
                  n = j - 1; 
                i = n;
                if (噌.暑 <= n)
                  i = n + 1; 
              } 
            } 
          } else {
            int n = 噌.堅;
            i = j;
            if (n <= j) {
              i = 噌.暑;
              if (n + i > j)
                continue; 
              i = j - i;
            } 
          } 
        } else {
          i = j;
          if (噌.堅 <= j)
            i = j + 噌.暑; 
        } 
        k++;
        j = i;
        continue;
      } 
      break;
    } 
    return i;
  }
  
  public final View 帰(View paramView) {
    ViewParent viewParent2 = paramView.getParent();
    View view = paramView;
    ViewParent viewParent1;
    for (viewParent1 = viewParent2; viewParent1 != null && viewParent1 != this && viewParent1 instanceof View; viewParent1 = view.getParent())
      view = (View)viewParent1; 
    return (viewParent1 == this) ? view : null;
  }
  
  public final void 怖() {
    boolean bool;
    탐();
    わ();
    bf bf1 = this.투;
    bf1.硬(6);
    this.痛.熱();
    bf1.冷 = this.壊.硬();
    bf1.熱 = 0;
    bf1.美 = false;
    this.帰.ㅌ(this.怖, bf1);
    bf1.寒 = false;
    this.恐 = null;
    if (bf1.辛 && this.ㅌ != null) {
      bool = true;
    } else {
      bool = false;
    } 
    bf1.辛 = bool;
    bf1.暑 = 4;
    も(true);
    탑(false);
  }
  
  public final boolean 恐(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return getScrollingChildHelper().熱(paramInt1, paramInt2, paramInt3, paramArrayOfint1, paramArrayOfint2);
  }
  
  public final void 悲(int paramInt1, int paramInt2) {
    int i = getPaddingLeft();
    int j = getPaddingRight();
    WeakHashMap weakHashMap = rw.硬;
    int k = Build.VERSION.SDK_INT;
    paramInt1 = pe.美(paramInt1, j + i, aw.冷((View)this));
    i = getPaddingTop();
    setMeasuredDimension(paramInt1, pe.美(paramInt2, getPaddingBottom() + i, aw.暑((View)this)));
  }
  
  public final void 旨(te paramte) {
    if (this.者 == null)
      this.者 = new ArrayList(); 
    this.者.add(paramte);
  }
  
  public final void 歩(int[] paramArrayOfint) {
    int m = this.痒.冷();
    if (m == 0) {
      paramArrayOfint[0] = -1;
      paramArrayOfint[1] = -1;
      return;
    } 
    int i = Integer.MAX_VALUE;
    int k = Integer.MIN_VALUE;
    int j = 0;
    while (j < m) {
      int n;
      ef ef = 投(this.痒.暑(j));
      if (ef.寂()) {
        n = k;
      } else {
        int i2 = ef.熱();
        int i1 = i;
        if (i2 < i)
          i1 = i2; 
        i = i1;
        n = k;
        if (i2 > k) {
          n = i2;
          i = i1;
        } 
      } 
      j++;
      k = n;
    } 
    paramArrayOfint[0] = i;
    paramArrayOfint[1] = k;
  }
  
  public final String 死() {
    StringBuilder stringBuilder = new StringBuilder(" ");
    stringBuilder.append(toString());
    stringBuilder.append(", adapter:");
    stringBuilder.append(this.壊);
    stringBuilder.append(", layout:");
    stringBuilder.append(this.帰);
    stringBuilder.append(", context:");
    stringBuilder.append(getContext());
    return stringBuilder.toString();
  }
  
  public final void 淋() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 투 : Ly/bf;
    //   4: astore #9
    //   6: aload #9
    //   8: iconst_1
    //   9: invokevirtual 硬 : (I)V
    //   12: aload_0
    //   13: aload #9
    //   15: invokevirtual 壊 : (Ly/bf;)V
    //   18: aload #9
    //   20: iconst_0
    //   21: putfield 不 : Z
    //   24: aload_0
    //   25: invokevirtual 탐 : ()V
    //   28: aload_0
    //   29: getfield 臭 : Ly/ex;
    //   32: astore #10
    //   34: aload #10
    //   36: invokevirtual 暑 : ()V
    //   39: aload_0
    //   40: invokevirtual わ : ()V
    //   43: aload_0
    //   44: invokevirtual 쾌 : ()V
    //   47: aload_0
    //   48: getfield 톤 : Z
    //   51: ifeq -> 77
    //   54: aload_0
    //   55: invokevirtual hasFocus : ()Z
    //   58: ifeq -> 77
    //   61: aload_0
    //   62: getfield 壊 : Ly/he;
    //   65: ifnull -> 77
    //   68: aload_0
    //   69: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   72: astore #7
    //   74: goto -> 80
    //   77: aconst_null
    //   78: astore #7
    //   80: aload #7
    //   82: ifnonnull -> 88
    //   85: goto -> 101
    //   88: aload_0
    //   89: aload #7
    //   91: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   94: astore #7
    //   96: aload #7
    //   98: ifnonnull -> 107
    //   101: aconst_null
    //   102: astore #7
    //   104: goto -> 115
    //   107: aload_0
    //   108: aload #7
    //   110: invokevirtual 触 : (Landroid/view/View;)Ly/ef;
    //   113: astore #7
    //   115: ldc2_w -1
    //   118: lstore #4
    //   120: aload #7
    //   122: ifnonnull -> 148
    //   125: aload #9
    //   127: ldc2_w -1
    //   130: putfield 嬉 : J
    //   133: aload #9
    //   135: iconst_m1
    //   136: putfield 苦 : I
    //   139: aload #9
    //   141: iconst_m1
    //   142: putfield 悲 : I
    //   145: goto -> 309
    //   148: aload_0
    //   149: getfield 壊 : Ly/he;
    //   152: getfield 堅 : Z
    //   155: ifeq -> 165
    //   158: aload #7
    //   160: getfield 冷 : J
    //   163: lstore #4
    //   165: aload #9
    //   167: lload #4
    //   169: putfield 嬉 : J
    //   172: aload_0
    //   173: getfield 赤 : Z
    //   176: ifeq -> 184
    //   179: iconst_m1
    //   180: istore_1
    //   181: goto -> 224
    //   184: aload #7
    //   186: invokevirtual 不 : ()Z
    //   189: ifeq -> 201
    //   192: aload #7
    //   194: getfield 暑 : I
    //   197: istore_1
    //   198: goto -> 224
    //   201: aload #7
    //   203: getfield 恐 : Landroidx/recyclerview/widget/RecyclerView;
    //   206: astore #8
    //   208: aload #8
    //   210: ifnonnull -> 216
    //   213: goto -> 179
    //   216: aload #8
    //   218: aload #7
    //   220: invokevirtual 寝 : (Ly/ef;)I
    //   223: istore_1
    //   224: aload #9
    //   226: iload_1
    //   227: putfield 苦 : I
    //   230: aload #7
    //   232: getfield 硬 : Landroid/view/View;
    //   235: astore #7
    //   237: aload #7
    //   239: invokevirtual getId : ()I
    //   242: istore_1
    //   243: aload #7
    //   245: invokevirtual isFocused : ()Z
    //   248: ifne -> 303
    //   251: aload #7
    //   253: instanceof android/view/ViewGroup
    //   256: ifeq -> 303
    //   259: aload #7
    //   261: invokevirtual hasFocus : ()Z
    //   264: ifeq -> 303
    //   267: aload #7
    //   269: checkcast android/view/ViewGroup
    //   272: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   275: astore #8
    //   277: aload #8
    //   279: astore #7
    //   281: aload #8
    //   283: invokevirtual getId : ()I
    //   286: iconst_m1
    //   287: if_icmpeq -> 243
    //   290: aload #8
    //   292: invokevirtual getId : ()I
    //   295: istore_1
    //   296: aload #8
    //   298: astore #7
    //   300: goto -> 243
    //   303: aload #9
    //   305: iload_1
    //   306: putfield 悲 : I
    //   309: aload #9
    //   311: getfield 辛 : Z
    //   314: ifeq -> 330
    //   317: aload_0
    //   318: getfield し : Z
    //   321: ifeq -> 330
    //   324: iconst_1
    //   325: istore #6
    //   327: goto -> 333
    //   330: iconst_0
    //   331: istore #6
    //   333: aload #9
    //   335: iload #6
    //   337: putfield 旨 : Z
    //   340: aload_0
    //   341: iconst_0
    //   342: putfield し : Z
    //   345: aload_0
    //   346: iconst_0
    //   347: putfield た : Z
    //   350: aload #9
    //   352: aload #9
    //   354: getfield ぱ : Z
    //   357: putfield 美 : Z
    //   360: aload #9
    //   362: aload_0
    //   363: getfield 壊 : Ly/he;
    //   366: invokevirtual 硬 : ()I
    //   369: putfield 冷 : I
    //   372: aload_0
    //   373: aload_0
    //   374: getfield 僕 : [I
    //   377: invokevirtual 歩 : ([I)V
    //   380: aload #9
    //   382: getfield 辛 : Z
    //   385: ifeq -> 577
    //   388: aload_0
    //   389: getfield 痒 : Ly/話;
    //   392: invokevirtual 冷 : ()I
    //   395: istore_3
    //   396: iconst_0
    //   397: istore_1
    //   398: iload_1
    //   399: iload_3
    //   400: if_icmpge -> 577
    //   403: aload_0
    //   404: getfield 痒 : Ly/話;
    //   407: iload_1
    //   408: invokevirtual 暑 : (I)Landroid/view/View;
    //   411: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   414: astore #7
    //   416: aload #7
    //   418: invokevirtual 寂 : ()Z
    //   421: ifne -> 570
    //   424: aload #7
    //   426: invokevirtual 美 : ()Z
    //   429: ifeq -> 445
    //   432: aload_0
    //   433: getfield 壊 : Ly/he;
    //   436: getfield 堅 : Z
    //   439: ifne -> 445
    //   442: goto -> 570
    //   445: aload_0
    //   446: getfield ㅌ : Ly/me;
    //   449: astore #8
    //   451: aload #7
    //   453: invokestatic 堅 : (Ly/ef;)V
    //   456: aload #7
    //   458: invokevirtual 暑 : ()Ljava/util/List;
    //   461: pop
    //   462: aload #8
    //   464: invokevirtual getClass : ()Ljava/lang/Class;
    //   467: pop
    //   468: new y/le
    //   471: dup
    //   472: iconst_0
    //   473: invokespecial <init> : (I)V
    //   476: astore #8
    //   478: aload #8
    //   480: aload #7
    //   482: invokevirtual 硬 : (Ly/ef;)V
    //   485: aload #10
    //   487: aload #7
    //   489: aload #8
    //   491: invokevirtual 熱 : (Ly/ef;Ly/le;)V
    //   494: aload #9
    //   496: getfield 旨 : Z
    //   499: ifeq -> 570
    //   502: aload #7
    //   504: getfield 辛 : I
    //   507: iconst_2
    //   508: iand
    //   509: ifeq -> 517
    //   512: iconst_1
    //   513: istore_2
    //   514: goto -> 519
    //   517: iconst_0
    //   518: istore_2
    //   519: iload_2
    //   520: ifeq -> 570
    //   523: aload #7
    //   525: invokevirtual 不 : ()Z
    //   528: ifne -> 570
    //   531: aload #7
    //   533: invokevirtual 寂 : ()Z
    //   536: ifne -> 570
    //   539: aload #7
    //   541: invokevirtual 美 : ()Z
    //   544: ifne -> 570
    //   547: aload_0
    //   548: aload #7
    //   550: invokevirtual 噛 : (Ly/ef;)J
    //   553: lstore #4
    //   555: aload #10
    //   557: getfield 熱 : Ljava/lang/Object;
    //   560: checkcast y/烏
    //   563: lload #4
    //   565: aload #7
    //   567: invokevirtual 寒 : (JLjava/lang/Object;)V
    //   570: iload_1
    //   571: iconst_1
    //   572: iadd
    //   573: istore_1
    //   574: goto -> 398
    //   577: aload #9
    //   579: getfield ぱ : Z
    //   582: ifeq -> 918
    //   585: aload_0
    //   586: getfield 痒 : Ly/話;
    //   589: invokevirtual 旨 : ()I
    //   592: istore_2
    //   593: iconst_0
    //   594: istore_1
    //   595: iload_1
    //   596: iload_2
    //   597: if_icmpge -> 647
    //   600: aload_0
    //   601: getfield 痒 : Ly/話;
    //   604: iload_1
    //   605: invokevirtual 美 : (I)Landroid/view/View;
    //   608: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   611: astore #7
    //   613: aload #7
    //   615: invokevirtual 寂 : ()Z
    //   618: ifne -> 640
    //   621: aload #7
    //   623: getfield 暑 : I
    //   626: iconst_m1
    //   627: if_icmpne -> 640
    //   630: aload #7
    //   632: aload #7
    //   634: getfield 熱 : I
    //   637: putfield 暑 : I
    //   640: iload_1
    //   641: iconst_1
    //   642: iadd
    //   643: istore_1
    //   644: goto -> 595
    //   647: aload #9
    //   649: getfield 寒 : Z
    //   652: istore #6
    //   654: aload #9
    //   656: iconst_0
    //   657: putfield 寒 : Z
    //   660: aload_0
    //   661: getfield 帰 : Ly/pe;
    //   664: aload_0
    //   665: getfield 怖 : Ly/we;
    //   668: aload #9
    //   670: invokevirtual ㅌ : (Ly/we;Ly/bf;)V
    //   673: aload #9
    //   675: iload #6
    //   677: putfield 寒 : Z
    //   680: iconst_0
    //   681: istore_1
    //   682: iload_1
    //   683: aload_0
    //   684: getfield 痒 : Ly/話;
    //   687: invokevirtual 冷 : ()I
    //   690: if_icmpge -> 911
    //   693: aload_0
    //   694: getfield 痒 : Ly/話;
    //   697: iload_1
    //   698: invokevirtual 暑 : (I)Landroid/view/View;
    //   701: invokestatic 投 : (Landroid/view/View;)Ly/ef;
    //   704: astore #11
    //   706: aload #11
    //   708: invokevirtual 寂 : ()Z
    //   711: ifeq -> 717
    //   714: goto -> 904
    //   717: aload #10
    //   719: getfield 堅 : Ljava/lang/Object;
    //   722: checkcast y/ol
    //   725: aload #11
    //   727: aconst_null
    //   728: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   731: checkcast y/dx
    //   734: astore #7
    //   736: aload #7
    //   738: ifnull -> 756
    //   741: aload #7
    //   743: getfield 硬 : I
    //   746: iconst_4
    //   747: iand
    //   748: ifeq -> 756
    //   751: iconst_1
    //   752: istore_2
    //   753: goto -> 758
    //   756: iconst_0
    //   757: istore_2
    //   758: iload_2
    //   759: ifne -> 904
    //   762: aload #11
    //   764: invokestatic 堅 : (Ly/ef;)V
    //   767: aload #11
    //   769: getfield 辛 : I
    //   772: sipush #8192
    //   775: iand
    //   776: ifeq -> 784
    //   779: iconst_1
    //   780: istore_2
    //   781: goto -> 786
    //   784: iconst_0
    //   785: istore_2
    //   786: aload_0
    //   787: getfield ㅌ : Ly/me;
    //   790: astore #7
    //   792: aload #11
    //   794: invokevirtual 暑 : ()Ljava/util/List;
    //   797: pop
    //   798: aload #7
    //   800: invokevirtual getClass : ()Ljava/lang/Class;
    //   803: pop
    //   804: new y/le
    //   807: dup
    //   808: iconst_0
    //   809: invokespecial <init> : (I)V
    //   812: astore #12
    //   814: aload #12
    //   816: aload #11
    //   818: invokevirtual 硬 : (Ly/ef;)V
    //   821: iload_2
    //   822: ifeq -> 836
    //   825: aload_0
    //   826: aload #11
    //   828: aload #12
    //   830: invokevirtual 큰 : (Ly/ef;Ly/le;)V
    //   833: goto -> 904
    //   836: aload #10
    //   838: getfield 堅 : Ljava/lang/Object;
    //   841: checkcast y/ol
    //   844: aload #11
    //   846: aconst_null
    //   847: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   850: checkcast y/dx
    //   853: astore #8
    //   855: aload #8
    //   857: astore #7
    //   859: aload #8
    //   861: ifnonnull -> 885
    //   864: invokestatic 硬 : ()Ly/dx;
    //   867: astore #7
    //   869: aload #10
    //   871: getfield 堅 : Ljava/lang/Object;
    //   874: checkcast y/ol
    //   877: aload #11
    //   879: aload #7
    //   881: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   884: pop
    //   885: aload #7
    //   887: aload #7
    //   889: getfield 硬 : I
    //   892: iconst_2
    //   893: ior
    //   894: putfield 硬 : I
    //   897: aload #7
    //   899: aload #12
    //   901: putfield 堅 : Ly/le;
    //   904: iload_1
    //   905: iconst_1
    //   906: iadd
    //   907: istore_1
    //   908: goto -> 682
    //   911: aload_0
    //   912: invokevirtual ぱ : ()V
    //   915: goto -> 922
    //   918: aload_0
    //   919: invokevirtual ぱ : ()V
    //   922: aload_0
    //   923: iconst_1
    //   924: invokevirtual も : (Z)V
    //   927: aload_0
    //   928: iconst_0
    //   929: invokevirtual 탑 : (Z)V
    //   932: aload #9
    //   934: iconst_2
    //   935: putfield 暑 : I
    //   938: return
  }
  
  public final void 産() {
    if (this.크 != null)
      return; 
    this.코.getClass();
    EdgeEffect edgeEffect = new EdgeEffect(getContext());
    this.크 = edgeEffect;
    if (this.起) {
      edgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    } 
    edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public final void 痒(int paramInt1, int paramInt2) {
    this.若++;
    int i = getScrollX();
    int j = getScrollY();
    onScrollChanged(i, j, i - paramInt1, j - paramInt2);
    te te1 = this.퉁;
    if (te1 != null)
      te1.堅(this, paramInt1, paramInt2); 
    ArrayList arrayList = this.者;
    if (arrayList != null) {
      i = arrayList.size();
      while (true) {
        if (--i >= 0) {
          ((te)this.者.get(i)).堅(this, paramInt1, paramInt2);
          continue;
        } 
        break;
      } 
    } 
    this.若--;
  }
  
  public final void 痛(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    getScrollingChildHelper().冷(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  public final void 美(ne paramne) {
    pe pe1 = this.帰;
    if (pe1 != null)
      pe1.熱("Cannot add item decoration during a scroll  or layout"); 
    ArrayList<ne> arrayList = this.返;
    if (arrayList.isEmpty())
      setWillNotDraw(false); 
    arrayList.add(paramne);
    ゃ();
    requestLayout();
  }
  
  public final void 臭() {
    if (this.키 != null)
      return; 
    this.코.getClass();
    EdgeEffect edgeEffect = new EdgeEffect(getContext());
    this.키 = edgeEffect;
    if (this.起) {
      edgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    } 
    edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public final void 興() {
    if (this.큰 != null)
      return; 
    this.코.getClass();
    EdgeEffect edgeEffect = new EdgeEffect(getContext());
    this.큰 = edgeEffect;
    if (this.起) {
      edgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    } 
    edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  public final void 若(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.탁) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.탁 = paramMotionEvent.getPointerId(i);
      int j = (int)(paramMotionEvent.getX(i) + 0.5F);
      this.탑 = j;
      this.탈 = j;
      i = (int)(paramMotionEvent.getY(i) + 0.5F);
      this.탕 = i;
      this.탐 = i;
    } 
  }
  
  public final void 苦(int paramInt1, int paramInt2) {
    EdgeEffect edgeEffect = this.쾌;
    if (edgeEffect != null && !edgeEffect.isFinished() && paramInt1 > 0) {
      this.쾌.onRelease();
      bool2 = this.쾌.isFinished();
    } else {
      bool2 = false;
    } 
    edgeEffect = this.큰;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt1 < 0) {
          this.큰.onRelease();
          bool1 = bool2 | this.큰.isFinished();
        } 
      } 
    } 
    edgeEffect = this.크;
    boolean bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt2 > 0) {
          this.크.onRelease();
          bool2 = bool1 | this.크.isFinished();
        } 
      } 
    } 
    edgeEffect = this.키;
    bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt2 < 0) {
          this.키.onRelease();
          bool1 = bool2 | this.키.isFinished();
        } 
      } 
    } 
    if (bool1)
      rw.痒((View)this); 
  }
  
  public final ef 触(View paramView) {
    ViewParent viewParent = paramView.getParent();
    if (viewParent == null || viewParent == this)
      return 投(paramView); 
    StringBuilder stringBuilder = new StringBuilder("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a direct child of ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final void 赤(int paramInt1, int paramInt2, boolean paramBoolean) {
    int k = paramInt1 + paramInt2;
    int j = this.痒.旨();
    int i;
    for (i = 0; i < j; i++) {
      ef ef = 投(this.痒.美(i));
      if (ef != null && !ef.寂()) {
        int m = ef.熱;
        bf bf1 = this.투;
        if (m >= k) {
          ef.苦(-paramInt2, paramBoolean);
          bf1.寒 = true;
        } else if (m >= paramInt1) {
          m = -paramInt2;
          ef.堅(8);
          ef.苦(m, paramBoolean);
          ef.熱 = paramInt1 - 1;
          bf1.寒 = true;
        } 
      } 
    } 
    we we1 = this.怖;
    ArrayList<ef> arrayList = we1.熱;
    i = arrayList.size();
    while (true) {
      j = i - 1;
      if (j >= 0) {
        ef ef = arrayList.get(j);
        i = j;
        if (ef != null) {
          int m = ef.熱;
          if (m >= k) {
            ef.苦(-paramInt2, paramBoolean);
            i = j;
            continue;
          } 
          i = j;
          if (m >= paramInt1) {
            ef.堅(8);
            we1.冷(j);
            i = j;
          } 
        } 
        continue;
      } 
      requestLayout();
      return;
    } 
  }
  
  public final void 起() {
    if (this.쾌 != null)
      return; 
    this.코.getClass();
    EdgeEffect edgeEffect = new EdgeEffect(getContext());
    this.쾌 = edgeEffect;
    if (this.起) {
      edgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    } 
    edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  public final ef 踊(int paramInt) {
    boolean bool = this.赤;
    ef ef = null;
    if (bool)
      return null; 
    int j = this.痒.旨();
    int i = 0;
    while (i < j) {
      ef ef2 = 投(this.痒.美(i));
      ef ef1 = ef;
      if (ef2 != null) {
        ef1 = ef;
        if (!ef2.不()) {
          ef1 = ef;
          if (寝(ef2) == paramInt)
            if (this.痒.辛(ef2.硬)) {
              ef1 = ef2;
            } else {
              return ef2;
            }  
        } 
      } 
      i++;
      ef = ef1;
    } 
    return ef;
  }
  
  public final boolean 返(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield 歩 : Ljava/util/ArrayList;
    //   10: astore #8
    //   12: aload #8
    //   14: invokevirtual size : ()I
    //   17: istore #5
    //   19: iconst_0
    //   20: istore_2
    //   21: iload_2
    //   22: iload #5
    //   24: if_icmpge -> 196
    //   27: aload #8
    //   29: iload_2
    //   30: invokevirtual get : (I)Ljava/lang/Object;
    //   33: checkcast y/se
    //   36: astore #9
    //   38: aload #9
    //   40: checkcast y/ㅂ
    //   43: astore #10
    //   45: aload #10
    //   47: getfield 起 : I
    //   50: istore_3
    //   51: iload_3
    //   52: iconst_1
    //   53: if_icmpne -> 159
    //   56: aload #10
    //   58: aload_1
    //   59: invokevirtual getX : ()F
    //   62: aload_1
    //   63: invokevirtual getY : ()F
    //   66: invokevirtual 暑 : (FF)Z
    //   69: istore #6
    //   71: aload #10
    //   73: aload_1
    //   74: invokevirtual getX : ()F
    //   77: aload_1
    //   78: invokevirtual getY : ()F
    //   81: invokevirtual 熱 : (FF)Z
    //   84: istore #7
    //   86: aload_1
    //   87: invokevirtual getAction : ()I
    //   90: ifne -> 169
    //   93: iload #6
    //   95: ifne -> 103
    //   98: iload #7
    //   100: ifeq -> 169
    //   103: iload #7
    //   105: ifeq -> 128
    //   108: aload #10
    //   110: iconst_1
    //   111: putfield 興 : I
    //   114: aload #10
    //   116: aload_1
    //   117: invokevirtual getX : ()F
    //   120: f2i
    //   121: i2f
    //   122: putfield 淋 : F
    //   125: goto -> 150
    //   128: iload #6
    //   130: ifeq -> 150
    //   133: aload #10
    //   135: iconst_2
    //   136: putfield 興 : I
    //   139: aload #10
    //   141: aload_1
    //   142: invokevirtual getY : ()F
    //   145: f2i
    //   146: i2f
    //   147: putfield 嬉 : F
    //   150: aload #10
    //   152: iconst_2
    //   153: invokevirtual 冷 : (I)V
    //   156: goto -> 164
    //   159: iload_3
    //   160: iconst_2
    //   161: if_icmpne -> 169
    //   164: iconst_1
    //   165: istore_3
    //   166: goto -> 171
    //   169: iconst_0
    //   170: istore_3
    //   171: iload_3
    //   172: ifeq -> 189
    //   175: iload #4
    //   177: iconst_3
    //   178: if_icmpeq -> 189
    //   181: aload_0
    //   182: aload #9
    //   184: putfield 泳 : Ly/se;
    //   187: iconst_1
    //   188: ireturn
    //   189: iload_2
    //   190: iconst_1
    //   191: iadd
    //   192: istore_2
    //   193: goto -> 21
    //   196: iconst_0
    //   197: ireturn
  }
  
  public final void 코() {
    if (!this.く && this.踊) {
      rw.臭((View)this, (Runnable)this.ね);
      this.く = true;
    } 
  }
  
  public final void 쾌() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 赤 : Z
    //   4: ifeq -> 47
    //   7: aload_0
    //   8: getfield 痛 : Ly/料;
    //   11: astore #4
    //   13: aload #4
    //   15: aload #4
    //   17: getfield 堅 : Ljava/util/ArrayList;
    //   20: invokevirtual 苦 : (Ljava/util/ArrayList;)V
    //   23: aload #4
    //   25: aload #4
    //   27: getfield 熱 : Ljava/util/ArrayList;
    //   30: invokevirtual 苦 : (Ljava/util/ArrayList;)V
    //   33: aload_0
    //   34: getfield わ : Z
    //   37: ifeq -> 47
    //   40: aload_0
    //   41: getfield 帰 : Ly/pe;
    //   44: invokevirtual 쾌 : ()V
    //   47: aload_0
    //   48: getfield ㅌ : Ly/me;
    //   51: astore #4
    //   53: iconst_1
    //   54: istore_3
    //   55: aload #4
    //   57: ifnull -> 75
    //   60: aload_0
    //   61: getfield 帰 : Ly/pe;
    //   64: invokevirtual く : ()Z
    //   67: ifeq -> 75
    //   70: iconst_1
    //   71: istore_1
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_1
    //   77: iload_1
    //   78: ifeq -> 91
    //   81: aload_0
    //   82: getfield 痛 : Ly/料;
    //   85: invokevirtual 辛 : ()V
    //   88: goto -> 98
    //   91: aload_0
    //   92: getfield 痛 : Ly/料;
    //   95: invokevirtual 熱 : ()V
    //   98: aload_0
    //   99: getfield た : Z
    //   102: ifne -> 120
    //   105: aload_0
    //   106: getfield し : Z
    //   109: ifeq -> 115
    //   112: goto -> 120
    //   115: iconst_0
    //   116: istore_1
    //   117: goto -> 122
    //   120: iconst_1
    //   121: istore_1
    //   122: aload_0
    //   123: getfield 噛 : Z
    //   126: ifeq -> 178
    //   129: aload_0
    //   130: getfield ㅌ : Ly/me;
    //   133: ifnull -> 178
    //   136: aload_0
    //   137: getfield 赤 : Z
    //   140: istore_2
    //   141: iload_2
    //   142: ifne -> 159
    //   145: iload_1
    //   146: ifne -> 159
    //   149: aload_0
    //   150: getfield 帰 : Ly/pe;
    //   153: getfield 寒 : Z
    //   156: ifeq -> 178
    //   159: iload_2
    //   160: ifeq -> 173
    //   163: aload_0
    //   164: getfield 壊 : Ly/he;
    //   167: getfield 堅 : Z
    //   170: ifeq -> 178
    //   173: iconst_1
    //   174: istore_2
    //   175: goto -> 180
    //   178: iconst_0
    //   179: istore_2
    //   180: aload_0
    //   181: getfield 투 : Ly/bf;
    //   184: astore #4
    //   186: aload #4
    //   188: iload_2
    //   189: putfield 辛 : Z
    //   192: iload_2
    //   193: ifeq -> 240
    //   196: iload_1
    //   197: ifeq -> 240
    //   200: aload_0
    //   201: getfield 赤 : Z
    //   204: ifne -> 240
    //   207: aload_0
    //   208: getfield ㅌ : Ly/me;
    //   211: ifnull -> 229
    //   214: aload_0
    //   215: getfield 帰 : Ly/pe;
    //   218: invokevirtual く : ()Z
    //   221: ifeq -> 229
    //   224: iconst_1
    //   225: istore_1
    //   226: goto -> 231
    //   229: iconst_0
    //   230: istore_1
    //   231: iload_1
    //   232: ifeq -> 240
    //   235: iload_3
    //   236: istore_2
    //   237: goto -> 242
    //   240: iconst_0
    //   241: istore_2
    //   242: aload #4
    //   244: iload_2
    //   245: putfield ぱ : Z
    //   248: return
  }
  
  public final void 크(boolean paramBoolean) {
    this.わ = paramBoolean | this.わ;
    this.赤 = true;
    int j = this.痒.旨();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      ef ef = 投(this.痒.美(i));
      if (ef != null && !ef.寂())
        ef.堅(6); 
    } 
    ゃ();
    we we1 = this.怖;
    ArrayList<ef> arrayList = we1.熱;
    j = arrayList.size();
    for (i = bool; i < j; i++) {
      ef ef = arrayList.get(i);
      if (ef != null) {
        ef.堅(6);
        ef.硬(null);
      } 
    } 
    he he1 = we1.旨.壊;
    if (he1 == null || !he1.堅)
      we1.暑(); 
  }
  
  public final void 큰(ef paramef, le paramle) {
    int i = paramef.辛;
    boolean bool = false;
    i = i & 0xFFFFDFFF | 0x0;
    paramef.辛 = i;
    boolean bool1 = this.투.旨;
    ex ex1 = this.臭;
    if (bool1) {
      if ((i & 0x2) != 0)
        bool = true; 
      if (bool && !paramef.不() && !paramef.寂()) {
        long l = 噛(paramef);
        ((烏)ex1.熱).寒(l, paramef);
      } 
    } 
    ex1.熱(paramef, paramle);
  }
  
  public final void 키(View paramView1, View paramView2) {
    boolean bool;
    View view;
    if (paramView2 != null) {
      view = paramView2;
    } else {
      view = paramView1;
    } 
    int i = view.getWidth();
    int j = view.getHeight();
    Rect rect = this.興;
    rect.set(0, 0, i, j);
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (layoutParams instanceof qe) {
      qe qe = (qe)layoutParams;
      if (!qe.熱) {
        i = rect.left;
        Rect rect1 = qe.堅;
        rect.left = i - rect1.left;
        rect.right += rect1.right;
        rect.top -= rect1.top;
        rect.bottom += rect1.bottom;
      } 
    } 
    if (paramView2 != null) {
      offsetDescendantRectToMyCoords(paramView2, rect);
      offsetRectIntoDescendantCoords(paramView1, rect);
    } 
    pe pe1 = this.帰;
    rect = this.興;
    boolean bool1 = this.噛;
    if (paramView2 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    pe1.택(this, paramView1, rect, bool1 ^ true, bool);
  }
  
  public final boolean 타(int paramInt1, int paramInt2, MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 嬉 : ()V
    //   4: aload_0
    //   5: getfield 壊 : Ly/he;
    //   8: astore #21
    //   10: aload_0
    //   11: getfield う : [I
    //   14: astore #22
    //   16: iconst_1
    //   17: istore #20
    //   19: aload #21
    //   21: ifnull -> 77
    //   24: aload #22
    //   26: iconst_0
    //   27: iconst_0
    //   28: iastore
    //   29: aload #22
    //   31: iconst_1
    //   32: iconst_0
    //   33: iastore
    //   34: aload_0
    //   35: iload_1
    //   36: iload_2
    //   37: aload #22
    //   39: invokevirtual 탁 : (II[I)V
    //   42: aload #22
    //   44: iconst_0
    //   45: iaload
    //   46: istore #9
    //   48: aload #22
    //   50: iconst_1
    //   51: iaload
    //   52: istore #12
    //   54: iload #9
    //   56: istore #11
    //   58: iload #12
    //   60: istore #10
    //   62: iload_1
    //   63: iload #9
    //   65: isub
    //   66: istore #9
    //   68: iload_2
    //   69: iload #12
    //   71: isub
    //   72: istore #13
    //   74: goto -> 89
    //   77: iconst_0
    //   78: istore #10
    //   80: iconst_0
    //   81: istore #11
    //   83: iconst_0
    //   84: istore #9
    //   86: iconst_0
    //   87: istore #13
    //   89: aload_0
    //   90: getfield 返 : Ljava/util/ArrayList;
    //   93: invokevirtual isEmpty : ()Z
    //   96: ifne -> 103
    //   99: aload_0
    //   100: invokevirtual invalidate : ()V
    //   103: aload #22
    //   105: iconst_0
    //   106: iconst_0
    //   107: iastore
    //   108: aload #22
    //   110: iconst_1
    //   111: iconst_0
    //   112: iastore
    //   113: aload_0
    //   114: iload #11
    //   116: iload #10
    //   118: iload #9
    //   120: iload #13
    //   122: aload_0
    //   123: getfield 俺 : [I
    //   126: iconst_0
    //   127: aload #22
    //   129: invokevirtual 痛 : (IIII[II[I)V
    //   132: aload #22
    //   134: iconst_0
    //   135: iaload
    //   136: istore #14
    //   138: aload #22
    //   140: iconst_1
    //   141: iaload
    //   142: istore #15
    //   144: iload #14
    //   146: ifne -> 163
    //   149: iload #15
    //   151: ifeq -> 157
    //   154: goto -> 163
    //   157: iconst_0
    //   158: istore #12
    //   160: goto -> 166
    //   163: iconst_1
    //   164: istore #12
    //   166: aload_0
    //   167: getfield 탑 : I
    //   170: istore #17
    //   172: aload_0
    //   173: getfield 俺 : [I
    //   176: astore #21
    //   178: aload #21
    //   180: iconst_0
    //   181: iaload
    //   182: istore #16
    //   184: aload_0
    //   185: iload #17
    //   187: iload #16
    //   189: isub
    //   190: putfield 탑 : I
    //   193: aload_0
    //   194: getfield 탕 : I
    //   197: istore #17
    //   199: aload #21
    //   201: iconst_1
    //   202: iaload
    //   203: istore #18
    //   205: aload_0
    //   206: iload #17
    //   208: iload #18
    //   210: isub
    //   211: putfield 탕 : I
    //   214: aload_0
    //   215: getfield ょ : [I
    //   218: astore #21
    //   220: aload #21
    //   222: iconst_0
    //   223: aload #21
    //   225: iconst_0
    //   226: iaload
    //   227: iload #16
    //   229: iadd
    //   230: iastore
    //   231: aload #21
    //   233: iconst_1
    //   234: aload #21
    //   236: iconst_1
    //   237: iaload
    //   238: iload #18
    //   240: iadd
    //   241: iastore
    //   242: aload_0
    //   243: invokevirtual getOverScrollMode : ()I
    //   246: iconst_2
    //   247: if_icmpeq -> 541
    //   250: aload_3
    //   251: ifnull -> 535
    //   254: aload_3
    //   255: sipush #8194
    //   258: invokestatic 帰 : (Landroid/view/MotionEvent;I)Z
    //   261: ifne -> 535
    //   264: aload_3
    //   265: invokevirtual getX : ()F
    //   268: fstore #6
    //   270: iload #9
    //   272: iload #14
    //   274: isub
    //   275: i2f
    //   276: fstore #4
    //   278: aload_3
    //   279: invokevirtual getY : ()F
    //   282: fstore #7
    //   284: iload #13
    //   286: iload #15
    //   288: isub
    //   289: i2f
    //   290: fstore #5
    //   292: fload #4
    //   294: fconst_0
    //   295: fcmpg
    //   296: ifge -> 347
    //   299: aload_0
    //   300: invokevirtual 起 : ()V
    //   303: aload_0
    //   304: getfield 쾌 : Landroid/widget/EdgeEffect;
    //   307: astore_3
    //   308: fload #4
    //   310: fneg
    //   311: aload_0
    //   312: invokevirtual getWidth : ()I
    //   315: i2f
    //   316: fdiv
    //   317: fstore #8
    //   319: fload #7
    //   321: aload_0
    //   322: invokevirtual getHeight : ()I
    //   325: i2f
    //   326: fdiv
    //   327: fstore #7
    //   329: getstatic android/os/Build$VERSION.SDK_INT : I
    //   332: istore #9
    //   334: aload_3
    //   335: fload #8
    //   337: fconst_1
    //   338: fload #7
    //   340: fsub
    //   341: invokestatic 硬 : (Landroid/widget/EdgeEffect;FF)V
    //   344: goto -> 396
    //   347: fload #4
    //   349: fconst_0
    //   350: fcmpl
    //   351: ifle -> 402
    //   354: aload_0
    //   355: invokevirtual 興 : ()V
    //   358: aload_0
    //   359: getfield 큰 : Landroid/widget/EdgeEffect;
    //   362: astore_3
    //   363: fload #4
    //   365: aload_0
    //   366: invokevirtual getWidth : ()I
    //   369: i2f
    //   370: fdiv
    //   371: fstore #8
    //   373: fload #7
    //   375: aload_0
    //   376: invokevirtual getHeight : ()I
    //   379: i2f
    //   380: fdiv
    //   381: fstore #7
    //   383: getstatic android/os/Build$VERSION.SDK_INT : I
    //   386: istore #9
    //   388: aload_3
    //   389: fload #8
    //   391: fload #7
    //   393: invokestatic 硬 : (Landroid/widget/EdgeEffect;FF)V
    //   396: iconst_1
    //   397: istore #9
    //   399: goto -> 405
    //   402: iconst_0
    //   403: istore #9
    //   405: fload #5
    //   407: fconst_0
    //   408: fcmpg
    //   409: ifge -> 458
    //   412: aload_0
    //   413: invokevirtual 産 : ()V
    //   416: aload_0
    //   417: getfield 크 : Landroid/widget/EdgeEffect;
    //   420: astore_3
    //   421: fload #5
    //   423: fneg
    //   424: aload_0
    //   425: invokevirtual getHeight : ()I
    //   428: i2f
    //   429: fdiv
    //   430: fstore #7
    //   432: fload #6
    //   434: aload_0
    //   435: invokevirtual getWidth : ()I
    //   438: i2f
    //   439: fdiv
    //   440: fstore #6
    //   442: getstatic android/os/Build$VERSION.SDK_INT : I
    //   445: istore #9
    //   447: aload_3
    //   448: fload #7
    //   450: fload #6
    //   452: invokestatic 硬 : (Landroid/widget/EdgeEffect;FF)V
    //   455: goto -> 509
    //   458: fload #5
    //   460: fconst_0
    //   461: fcmpl
    //   462: ifle -> 512
    //   465: aload_0
    //   466: invokevirtual 臭 : ()V
    //   469: aload_0
    //   470: getfield 키 : Landroid/widget/EdgeEffect;
    //   473: astore_3
    //   474: fload #5
    //   476: aload_0
    //   477: invokevirtual getHeight : ()I
    //   480: i2f
    //   481: fdiv
    //   482: fstore #7
    //   484: fload #6
    //   486: aload_0
    //   487: invokevirtual getWidth : ()I
    //   490: i2f
    //   491: fdiv
    //   492: fstore #6
    //   494: getstatic android/os/Build$VERSION.SDK_INT : I
    //   497: istore #9
    //   499: aload_3
    //   500: fload #7
    //   502: fconst_1
    //   503: fload #6
    //   505: fsub
    //   506: invokestatic 硬 : (Landroid/widget/EdgeEffect;FF)V
    //   509: iconst_1
    //   510: istore #9
    //   512: iload #9
    //   514: ifne -> 531
    //   517: fload #4
    //   519: fconst_0
    //   520: fcmpl
    //   521: ifne -> 531
    //   524: fload #5
    //   526: fconst_0
    //   527: fcmpl
    //   528: ifeq -> 535
    //   531: aload_0
    //   532: invokestatic 痒 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: iload_1
    //   537: iload_2
    //   538: invokevirtual 苦 : (II)V
    //   541: iload #11
    //   543: ifne -> 551
    //   546: iload #10
    //   548: ifeq -> 559
    //   551: aload_0
    //   552: iload #11
    //   554: iload #10
    //   556: invokevirtual 痒 : (II)V
    //   559: aload_0
    //   560: invokevirtual awakenScrollBars : ()Z
    //   563: ifne -> 570
    //   566: aload_0
    //   567: invokevirtual invalidate : ()V
    //   570: iload #20
    //   572: istore #19
    //   574: iload #12
    //   576: ifne -> 598
    //   579: iload #20
    //   581: istore #19
    //   583: iload #11
    //   585: ifne -> 598
    //   588: iload #10
    //   590: ifeq -> 595
    //   593: iconst_1
    //   594: ireturn
    //   595: iconst_0
    //   596: istore #19
    //   598: iload #19
    //   600: ireturn
  }
  
  public final void 탁(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    탐();
    わ();
    ss.硬("RV Scroll");
    bf bf1 = this.투;
    壊(bf1);
    we we1 = this.怖;
    if (paramInt1 != 0) {
      paramInt1 = this.帰.터(paramInt1, we1, bf1);
    } else {
      paramInt1 = 0;
    } 
    if (paramInt2 != 0) {
      paramInt2 = this.帰.토(paramInt2, we1, bf1);
    } else {
      paramInt2 = 0;
    } 
    ss.堅();
    int j = this.痒.冷();
    int i;
    for (i = 0; i < j; i++) {
      View view = this.痒.暑(i);
      ef ef = 触(view);
      if (ef != null) {
        ef = ef.不;
        if (ef != null) {
          int k = view.getLeft();
          int m = view.getTop();
          view = ef.硬;
          if (k != view.getLeft() || m != view.getTop())
            view.layout(k, m, view.getWidth() + k, view.getHeight() + m); 
        } 
      } 
    } 
    も(true);
    탑(false);
    if (paramArrayOfint != null) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt2;
    } 
  }
  
  public final void 탄(int paramInt) {
    if (this.あ)
      return; 
    setScrollState(0);
    df df1 = this.톨;
    df1.起.removeCallbacks((Runnable)df1);
    df1.恐.abortAnimation();
    pe pe1 = this.帰;
    if (pe1 != null) {
      邪 邪 = pe1.冷;
      if (邪 != null)
        邪.寒(); 
    } 
    pe1 = this.帰;
    if (pe1 == null)
      return; 
    pe1.테(paramInt);
    awakenScrollBars();
  }
  
  public final void 탈(int paramInt1, int paramInt2, boolean paramBoolean) {
    pe pe1 = this.帰;
    if (pe1 == null)
      return; 
    if (this.あ)
      return; 
    boolean bool = pe1.暑();
    int j = 0;
    int i = paramInt1;
    if (!bool)
      i = 0; 
    if (!this.帰.冷())
      paramInt2 = 0; 
    if (i != 0 || paramInt2 != 0) {
      if (paramBoolean) {
        paramInt1 = j;
        if (i != 0)
          paramInt1 = 1; 
        j = paramInt1;
        if (paramInt2 != 0)
          j = paramInt1 | 0x2; 
        getScrollingChildHelper().美(j, 1);
      } 
      this.톨.堅(i, paramInt2, -2147483648, null);
    } 
  }
  
  public final void 탐() {
    int i = this.触 + 1;
    this.触 = i;
    if (i == 1 && !this.あ)
      this.投 = false; 
  }
  
  public final void 탑(boolean paramBoolean) {
    if (this.触 < 1)
      this.触 = 1; 
    if (!paramBoolean && !this.あ)
      this.投 = false; 
    if (this.触 == 1) {
      if (paramBoolean && this.投 && !this.あ && this.帰 != null && this.壊 != null)
        寂(); 
      if (!this.あ)
        this.投 = false; 
    } 
    this.触--;
  }
  
  public final void 탕(int paramInt) {
    getScrollingChildHelper().旨(paramInt);
  }
  
  static {
    boolean bool;
  }
  
  public static final boolean ご;
  
  public static final int[] 医 = new int[] { 16843830 };
  
  public static final vw 師;
  
  public static final boolean 看;
  
  public static final Class[] 護;
  
  public boolean あ;
  
  public final int[] う;
  
  public boolean か;
  
  public boolean く;
  
  public boolean し;
  
  public boolean た;
  
  public int ち;
  
  public final fe ね;
  
  public gf ぼ;
  
  public int も;
  
  public final AccessibilityManager ゃ;
  
  public final int[] ょ;
  
  public k5 れ;
  
  public boolean わ;
  
  public me ㅌ;
  
  public final int[] 俺;
  
  public final int[] 僕;
  
  public boolean 噛;
  
  public he 壊;
  
  public boolean 寝;
  
  public final ArrayList 少;
  
  public pe 帰;
  
  public final ge 年;
  
  public final we 怖;
  
  public ye 恐;
  
  public boolean 投;
  
  public final ArrayList 歩;
  
  public final RectF 死;
  
  public se 泳;
  
  public final h9 淋;
  
  public final Rect 産;
  
  public 話 痒;
  
  public 料 痛;
  
  public final ge 私;
  
  public ArrayList 者;
  
  public final ex 臭;
  
  public final Rect 興;
  
  public int 若;
  
  public int 触;
  
  public boolean 赤;
  
  public boolean 起;
  
  public boolean 踊;
  
  public final ArrayList 返;
  
  public ke 코;
  
  public EdgeEffect 쾌;
  
  public EdgeEffect 크;
  
  public EdgeEffect 큰;
  
  public EdgeEffect 키;
  
  public int 타;
  
  public int 탁;
  
  public VelocityTracker 탄;
  
  public int 탈;
  
  public int 탐;
  
  public int 탑;
  
  public int 탕;
  
  public int 태;
  
  public re 택;
  
  public final int 탱;
  
  public final int 터;
  
  public final float 테;
  
  public final float 토;
  
  public boolean 톤;
  
  public final df 톨;
  
  public 품 통;
  
  public final 표 퇴;
  
  public final bf 투;
  
  public te 퉁;
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\recyclerview\widget\RecyclerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */