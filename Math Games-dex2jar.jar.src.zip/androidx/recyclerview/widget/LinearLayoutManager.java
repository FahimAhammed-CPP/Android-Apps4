package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import y.af;
import y.bf;
import y.bm;
import y.ik;
import y.k8;
import y.l8;
import y.pe;
import y.qe;
import y.rw;
import y.we;
import y.ぜ;
import y.む;
import y.胸;
import y.邪;
import y.骨;
import y.표;

public class LinearLayoutManager extends pe implements af {
  public ぜ 壊 = null;
  
  public final 骨 帰 = new 骨();
  
  public 胸 怖;
  
  public k8 恐;
  
  public final int 歩 = 2;
  
  public int 死 = Integer.MIN_VALUE;
  
  public final int[] 泳 = new int[2];
  
  public int 淋 = 1;
  
  public int 産 = -1;
  
  public boolean 痒 = false;
  
  public boolean 痛;
  
  public boolean 臭 = false;
  
  public final boolean 興 = true;
  
  public boolean 起 = false;
  
  public final む 返 = new む();
  
  public LinearLayoutManager(int paramInt) {
    消(paramInt);
    熱(null);
    if (!this.痒)
      return; 
    this.痒 = false;
    탱();
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView$LayoutManager$Properties recyclerView$LayoutManager$Properties = pe.踊(paramContext, paramAttributeSet, paramInt1, paramInt2);
    消(recyclerView$LayoutManager$Properties.硬);
    boolean bool = recyclerView$LayoutManager$Properties.熱;
    熱(null);
    if (bool != this.痒) {
      this.痒 = bool;
      탱();
    } 
    防(recyclerView$LayoutManager$Properties.暑);
  }
  
  public final int う(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.淋 == 1) ? 1 : Integer.MIN_VALUE)) : ((this.淋 == 0) ? 1 : Integer.MIN_VALUE)) : ((this.淋 == 1) ? -1 : Integer.MIN_VALUE)) : ((this.淋 == 0) ? -1 : Integer.MIN_VALUE)) : ((this.淋 == 1) ? 1 : (せ() ? -1 : 1))) : ((this.淋 == 1) ? -1 : (せ() ? 1 : -1));
  }
  
  public boolean く() {
    return (this.壊 == null && this.痛 == this.起);
  }
  
  public final void け(int paramInt1, int paramInt2, boolean paramBoolean, bf parambf) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 怖 : Ly/胸;
    //   4: astore #11
    //   6: aload_0
    //   7: getfield 恐 : Ly/k8;
    //   10: invokevirtual 美 : ()I
    //   13: istore #5
    //   15: iconst_0
    //   16: istore #7
    //   18: iconst_1
    //   19: istore #9
    //   21: iconst_1
    //   22: istore #8
    //   24: iload #5
    //   26: ifne -> 45
    //   29: aload_0
    //   30: getfield 恐 : Ly/k8;
    //   33: invokevirtual 冷 : ()I
    //   36: ifne -> 45
    //   39: iconst_1
    //   40: istore #10
    //   42: goto -> 48
    //   45: iconst_0
    //   46: istore #10
    //   48: aload #11
    //   50: iload #10
    //   52: putfield 苦 : Z
    //   55: aload_0
    //   56: getfield 怖 : Ly/胸;
    //   59: iload_1
    //   60: putfield 寒 : I
    //   63: aload_0
    //   64: getfield 泳 : [I
    //   67: astore #11
    //   69: aload #11
    //   71: iconst_0
    //   72: iconst_0
    //   73: iastore
    //   74: aload #11
    //   76: iconst_1
    //   77: iconst_0
    //   78: iastore
    //   79: aload_0
    //   80: aload #4
    //   82: aload #11
    //   84: invokevirtual ぼ : (Ly/bf;[I)V
    //   87: iconst_0
    //   88: aload #11
    //   90: iconst_0
    //   91: iaload
    //   92: invokestatic max : (II)I
    //   95: istore #5
    //   97: iconst_0
    //   98: aload #11
    //   100: iconst_1
    //   101: iaload
    //   102: invokestatic max : (II)I
    //   105: istore #6
    //   107: iload_1
    //   108: iconst_1
    //   109: if_icmpne -> 115
    //   112: iconst_1
    //   113: istore #7
    //   115: aload_0
    //   116: getfield 怖 : Ly/胸;
    //   119: astore #4
    //   121: iload #7
    //   123: ifeq -> 132
    //   126: iload #6
    //   128: istore_1
    //   129: goto -> 135
    //   132: iload #5
    //   134: istore_1
    //   135: aload #4
    //   137: iload_1
    //   138: putfield 旨 : I
    //   141: iload #7
    //   143: ifeq -> 149
    //   146: goto -> 153
    //   149: iload #6
    //   151: istore #5
    //   153: aload #4
    //   155: iload #5
    //   157: putfield 不 : I
    //   160: iload #7
    //   162: ifeq -> 322
    //   165: aload_0
    //   166: getfield 恐 : Ly/k8;
    //   169: astore #11
    //   171: aload #11
    //   173: getfield 暑 : I
    //   176: istore #5
    //   178: aload #11
    //   180: getfield 硬 : Ly/pe;
    //   183: astore #11
    //   185: iload #5
    //   187: tableswitch default -> 204, 0 -> 207
    //   204: goto -> 217
    //   207: aload #11
    //   209: invokevirtual 返 : ()I
    //   212: istore #5
    //   214: goto -> 224
    //   217: aload #11
    //   219: invokevirtual 壊 : ()I
    //   222: istore #5
    //   224: aload #4
    //   226: iload #5
    //   228: iload_1
    //   229: iadd
    //   230: putfield 旨 : I
    //   233: aload_0
    //   234: invokevirtual 科 : ()Landroid/view/View;
    //   237: astore #4
    //   239: aload_0
    //   240: getfield 怖 : Ly/胸;
    //   243: astore #11
    //   245: iload #8
    //   247: istore_1
    //   248: aload_0
    //   249: getfield 臭 : Z
    //   252: ifeq -> 257
    //   255: iconst_m1
    //   256: istore_1
    //   257: aload #11
    //   259: iload_1
    //   260: putfield 冷 : I
    //   263: aload #4
    //   265: invokestatic 泳 : (Landroid/view/View;)I
    //   268: istore_1
    //   269: aload_0
    //   270: getfield 怖 : Ly/胸;
    //   273: astore #12
    //   275: aload #11
    //   277: iload_1
    //   278: aload #12
    //   280: getfield 冷 : I
    //   283: iadd
    //   284: putfield 暑 : I
    //   287: aload #12
    //   289: aload_0
    //   290: getfield 恐 : Ly/k8;
    //   293: aload #4
    //   295: invokevirtual 堅 : (Landroid/view/View;)I
    //   298: putfield 堅 : I
    //   301: aload_0
    //   302: getfield 恐 : Ly/k8;
    //   305: aload #4
    //   307: invokevirtual 堅 : (Landroid/view/View;)I
    //   310: aload_0
    //   311: getfield 恐 : Ly/k8;
    //   314: invokevirtual 寒 : ()I
    //   317: isub
    //   318: istore_1
    //   319: goto -> 438
    //   322: aload_0
    //   323: invokevirtual は : ()Landroid/view/View;
    //   326: astore #4
    //   328: aload_0
    //   329: getfield 怖 : Ly/胸;
    //   332: astore #11
    //   334: aload #11
    //   336: getfield 旨 : I
    //   339: istore_1
    //   340: aload #11
    //   342: aload_0
    //   343: getfield 恐 : Ly/k8;
    //   346: invokevirtual 旨 : ()I
    //   349: iload_1
    //   350: iadd
    //   351: putfield 旨 : I
    //   354: aload_0
    //   355: getfield 怖 : Ly/胸;
    //   358: astore #11
    //   360: aload_0
    //   361: getfield 臭 : Z
    //   364: ifeq -> 373
    //   367: iload #9
    //   369: istore_1
    //   370: goto -> 375
    //   373: iconst_m1
    //   374: istore_1
    //   375: aload #11
    //   377: iload_1
    //   378: putfield 冷 : I
    //   381: aload #4
    //   383: invokestatic 泳 : (Landroid/view/View;)I
    //   386: istore_1
    //   387: aload_0
    //   388: getfield 怖 : Ly/胸;
    //   391: astore #12
    //   393: aload #11
    //   395: iload_1
    //   396: aload #12
    //   398: getfield 冷 : I
    //   401: iadd
    //   402: putfield 暑 : I
    //   405: aload #12
    //   407: aload_0
    //   408: getfield 恐 : Ly/k8;
    //   411: aload #4
    //   413: invokevirtual 暑 : (Landroid/view/View;)I
    //   416: putfield 堅 : I
    //   419: aload_0
    //   420: getfield 恐 : Ly/k8;
    //   423: aload #4
    //   425: invokevirtual 暑 : (Landroid/view/View;)I
    //   428: ineg
    //   429: aload_0
    //   430: getfield 恐 : Ly/k8;
    //   433: invokevirtual 旨 : ()I
    //   436: iadd
    //   437: istore_1
    //   438: aload_0
    //   439: getfield 怖 : Ly/胸;
    //   442: astore #4
    //   444: aload #4
    //   446: iload_2
    //   447: putfield 熱 : I
    //   450: iload_3
    //   451: ifeq -> 462
    //   454: aload #4
    //   456: iload_2
    //   457: iload_1
    //   458: isub
    //   459: putfield 熱 : I
    //   462: aload #4
    //   464: iload_1
    //   465: putfield 美 : I
    //   468: return
  }
  
  public final int ご() {
    View view = 師(0, 起(), false);
    return (view == null) ? -1 : pe.泳(view);
  }
  
  public final void さ(int paramInt1, int paramInt2) {
    boolean bool;
    this.怖.熱 = this.恐.寒() - paramInt2;
    胸 胸1 = this.怖;
    if (this.臭) {
      bool = true;
    } else {
      bool = true;
    } 
    胸1.冷 = bool;
    胸1.暑 = paramInt1;
    胸1.寒 = 1;
    胸1.堅 = paramInt2;
    胸1.美 = Integer.MIN_VALUE;
  }
  
  public void し(RecyclerView paramRecyclerView, int paramInt) {
    邪 邪 = new 邪(paramRecyclerView.getContext());
    邪.硬 = paramInt;
    私(邪);
  }
  
  public final boolean せ() {
    return (rw.不((View)this.堅) == 1);
  }
  
  public final void つ(int paramInt1, int paramInt2) {
    this.怖.熱 = paramInt2 - this.恐.旨();
    胸 胸1 = this.怖;
    胸1.暑 = paramInt1;
    if (this.臭) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    胸1.冷 = paramInt1;
    胸1.寒 = -1;
    胸1.堅 = paramInt2;
    胸1.美 = Integer.MIN_VALUE;
  }
  
  public final int ね(we paramwe, 胸 param胸, bf parambf, boolean paramBoolean) {
    int j = param胸.熱;
    int i = param胸.美;
    if (i != Integer.MIN_VALUE) {
      if (j < 0)
        param胸.美 = i + j; 
      家(paramwe, param胸);
    } 
    i = param胸.熱 + param胸.旨;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        Object object = SYNTHETIC_LOCAL_VARIABLE_6;
        if (((む)SYNTHETIC_LOCAL_VARIABLE_9).暑)
          break; 
      } 
    } 
    return j - param胸.熱;
  }
  
  public final View は() {
    boolean bool;
    if (this.臭) {
      bool = 起() - 1;
    } else {
      bool = false;
    } 
    return 臭(bool);
  }
  
  public int ぱ(bf parambf) {
    return 俺(parambf);
  }
  
  public View ふ(we paramwe, bf parambf, int paramInt1, int paramInt2, int paramInt3) {
    View view;
    byte b;
    少();
    int i = this.恐.旨();
    int j = this.恐.寒();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    parambf = null;
    for (paramwe = null; paramInt1 != paramInt2; paramwe = we1) {
      View view1;
      View view2 = 臭(paramInt1);
      int k = pe.泳(view2);
      bf bf1 = parambf;
      we we1 = paramwe;
      if (k >= 0) {
        bf1 = parambf;
        we1 = paramwe;
        if (k < paramInt3)
          if (((qe)view2.getLayoutParams()).熱()) {
            bf1 = parambf;
            we1 = paramwe;
            if (paramwe == null) {
              View view3 = view2;
              bf1 = parambf;
            } 
          } else if (this.恐.暑(view2) >= j || this.恐.堅(view2) < i) {
            bf1 = parambf;
            we1 = paramwe;
            if (parambf == null) {
              view1 = view2;
              we1 = paramwe;
            } 
          } else {
            return view2;
          }  
      } 
      paramInt1 += b;
      view = view1;
    } 
    return (View)((view != null) ? view : paramwe);
  }
  
  public final void べ(we paramwe, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (true) {
        if (--paramInt2 >= paramInt1) {
          View view = 臭(paramInt2);
          태(paramInt2);
          paramwe.寒(view);
          continue;
        } 
        break;
      } 
    } else {
      while (i > paramInt2) {
        View view = 臭(i);
        태(i);
        paramwe.寒(view);
        i--;
      } 
    } 
  }
  
  public void ぼ(bf parambf, int[] paramArrayOfint) {
    int i;
    int j;
    boolean bool;
    if (parambf.硬 != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = this.恐.不();
    } else {
      i = 0;
    } 
    if (this.怖.寒 == -1) {
      j = 0;
      bool = i;
    } else {
      bool = false;
      j = i;
    } 
    paramArrayOfint[0] = bool;
    paramArrayOfint[1] = j;
  }
  
  public final void ゃ(RecyclerView paramRecyclerView) {}
  
  public final int ょ(bf parambf) {
    if (起() == 0)
      return 0; 
    少();
    k8 k81 = this.恐;
    int i = this.興 ^ true;
    return ik.淋(parambf, (l8)k81, 医(i), 年(i), this, this.興);
  }
  
  public final int れ(bf parambf) {
    if (起() == 0)
      return 0; 
    少();
    k8 k81 = this.恐;
    int i = this.興 ^ true;
    return ik.悲(parambf, (l8)k81, 医(i), 年(i), this, this.興);
  }
  
  public final void わ(AccessibilityEvent paramAccessibilityEvent) {
    super.わ(paramAccessibilityEvent);
    if (起() > 0) {
      paramAccessibilityEvent.setFromIndex(ご());
      paramAccessibilityEvent.setToIndex(看());
    } 
  }
  
  public void ㅌ(we paramwe, bf parambf) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 壊 : Ly/ぜ;
    //   4: ifnonnull -> 15
    //   7: aload_0
    //   8: getfield 産 : I
    //   11: iconst_m1
    //   12: if_icmpeq -> 28
    //   15: aload_2
    //   16: invokevirtual 堅 : ()I
    //   19: ifne -> 28
    //   22: aload_0
    //   23: aload_1
    //   24: invokevirtual 탐 : (Ly/we;)V
    //   27: return
    //   28: aload_0
    //   29: getfield 壊 : Ly/ぜ;
    //   32: astore #12
    //   34: aload #12
    //   36: ifnull -> 68
    //   39: aload #12
    //   41: getfield 淋 : I
    //   44: istore #4
    //   46: iload #4
    //   48: iflt -> 56
    //   51: iconst_1
    //   52: istore_3
    //   53: goto -> 58
    //   56: iconst_0
    //   57: istore_3
    //   58: iload_3
    //   59: ifeq -> 68
    //   62: aload_0
    //   63: iload #4
    //   65: putfield 産 : I
    //   68: aload_0
    //   69: invokevirtual 少 : ()V
    //   72: aload_0
    //   73: getfield 怖 : Ly/胸;
    //   76: iconst_0
    //   77: putfield 硬 : Z
    //   80: aload_0
    //   81: invokevirtual 弁 : ()V
    //   84: aload_0
    //   85: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   88: astore #12
    //   90: aload #12
    //   92: ifnonnull -> 101
    //   95: aconst_null
    //   96: astore #12
    //   98: goto -> 132
    //   101: aload #12
    //   103: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   106: astore #13
    //   108: aload #13
    //   110: ifnull -> 95
    //   113: aload #13
    //   115: astore #12
    //   117: aload_0
    //   118: getfield 硬 : Ly/話;
    //   121: aload #13
    //   123: invokevirtual 辛 : (Landroid/view/View;)Z
    //   126: ifeq -> 132
    //   129: goto -> 95
    //   132: aload_0
    //   133: getfield 帰 : Ly/骨;
    //   136: astore #14
    //   138: aload #14
    //   140: getfield 暑 : Z
    //   143: ifeq -> 222
    //   146: aload_0
    //   147: getfield 産 : I
    //   150: iconst_m1
    //   151: if_icmpne -> 222
    //   154: aload_0
    //   155: getfield 壊 : Ly/ぜ;
    //   158: ifnull -> 164
    //   161: goto -> 222
    //   164: aload #12
    //   166: ifnull -> 1150
    //   169: aload_0
    //   170: getfield 恐 : Ly/k8;
    //   173: aload #12
    //   175: invokevirtual 暑 : (Landroid/view/View;)I
    //   178: aload_0
    //   179: getfield 恐 : Ly/k8;
    //   182: invokevirtual 寒 : ()I
    //   185: if_icmpge -> 207
    //   188: aload_0
    //   189: getfield 恐 : Ly/k8;
    //   192: aload #12
    //   194: invokevirtual 堅 : (Landroid/view/View;)I
    //   197: aload_0
    //   198: getfield 恐 : Ly/k8;
    //   201: invokevirtual 旨 : ()I
    //   204: if_icmpgt -> 1150
    //   207: aload #14
    //   209: aload #12
    //   211: aload #12
    //   213: invokestatic 泳 : (Landroid/view/View;)I
    //   216: invokevirtual 熱 : (Landroid/view/View;I)V
    //   219: goto -> 1150
    //   222: aload #14
    //   224: invokevirtual 暑 : ()V
    //   227: aload #14
    //   229: aload_0
    //   230: getfield 臭 : Z
    //   233: aload_0
    //   234: getfield 起 : Z
    //   237: ixor
    //   238: putfield 熱 : Z
    //   241: aload_2
    //   242: getfield 美 : Z
    //   245: ifne -> 731
    //   248: aload_0
    //   249: getfield 産 : I
    //   252: istore_3
    //   253: iload_3
    //   254: iconst_m1
    //   255: if_icmpne -> 261
    //   258: goto -> 731
    //   261: iload_3
    //   262: iflt -> 720
    //   265: iload_3
    //   266: aload_2
    //   267: invokevirtual 堅 : ()I
    //   270: if_icmplt -> 276
    //   273: goto -> 720
    //   276: aload_0
    //   277: getfield 産 : I
    //   280: istore #4
    //   282: aload #14
    //   284: iload #4
    //   286: putfield 堅 : I
    //   289: aload_0
    //   290: getfield 壊 : Ly/ぜ;
    //   293: astore #12
    //   295: aload #12
    //   297: ifnull -> 384
    //   300: aload #12
    //   302: getfield 淋 : I
    //   305: iflt -> 313
    //   308: iconst_1
    //   309: istore_3
    //   310: goto -> 315
    //   313: iconst_0
    //   314: istore_3
    //   315: iload_3
    //   316: ifeq -> 384
    //   319: aload #12
    //   321: getfield 恐 : Z
    //   324: istore #11
    //   326: aload #14
    //   328: iload #11
    //   330: putfield 熱 : Z
    //   333: iload #11
    //   335: ifeq -> 361
    //   338: aload #14
    //   340: aload_0
    //   341: getfield 恐 : Ly/k8;
    //   344: invokevirtual 寒 : ()I
    //   347: aload_0
    //   348: getfield 壊 : Ly/ぜ;
    //   351: getfield 怖 : I
    //   354: isub
    //   355: putfield 冷 : I
    //   358: goto -> 715
    //   361: aload #14
    //   363: aload_0
    //   364: getfield 恐 : Ly/k8;
    //   367: invokevirtual 旨 : ()I
    //   370: aload_0
    //   371: getfield 壊 : Ly/ぜ;
    //   374: getfield 怖 : I
    //   377: iadd
    //   378: putfield 冷 : I
    //   381: goto -> 715
    //   384: aload_0
    //   385: getfield 死 : I
    //   388: ldc -2147483648
    //   390: if_icmpne -> 660
    //   393: aload_0
    //   394: iload #4
    //   396: invokevirtual 怖 : (I)Landroid/view/View;
    //   399: astore #12
    //   401: aload #12
    //   403: ifnull -> 594
    //   406: aload_0
    //   407: getfield 恐 : Ly/k8;
    //   410: aload #12
    //   412: invokevirtual 熱 : (Landroid/view/View;)I
    //   415: aload_0
    //   416: getfield 恐 : Ly/k8;
    //   419: invokevirtual 不 : ()I
    //   422: if_icmple -> 433
    //   425: aload #14
    //   427: invokevirtual 硬 : ()V
    //   430: goto -> 715
    //   433: aload_0
    //   434: getfield 恐 : Ly/k8;
    //   437: aload #12
    //   439: invokevirtual 暑 : (Landroid/view/View;)I
    //   442: aload_0
    //   443: getfield 恐 : Ly/k8;
    //   446: invokevirtual 旨 : ()I
    //   449: isub
    //   450: ifge -> 474
    //   453: aload #14
    //   455: aload_0
    //   456: getfield 恐 : Ly/k8;
    //   459: invokevirtual 旨 : ()I
    //   462: putfield 冷 : I
    //   465: aload #14
    //   467: iconst_0
    //   468: putfield 熱 : Z
    //   471: goto -> 715
    //   474: aload_0
    //   475: getfield 恐 : Ly/k8;
    //   478: invokevirtual 寒 : ()I
    //   481: aload_0
    //   482: getfield 恐 : Ly/k8;
    //   485: aload #12
    //   487: invokevirtual 堅 : (Landroid/view/View;)I
    //   490: isub
    //   491: ifge -> 515
    //   494: aload #14
    //   496: aload_0
    //   497: getfield 恐 : Ly/k8;
    //   500: invokevirtual 寒 : ()I
    //   503: putfield 冷 : I
    //   506: aload #14
    //   508: iconst_1
    //   509: putfield 熱 : Z
    //   512: goto -> 715
    //   515: aload #14
    //   517: getfield 熱 : Z
    //   520: ifeq -> 575
    //   523: aload_0
    //   524: getfield 恐 : Ly/k8;
    //   527: aload #12
    //   529: invokevirtual 堅 : (Landroid/view/View;)I
    //   532: istore #4
    //   534: aload_0
    //   535: getfield 恐 : Ly/k8;
    //   538: astore #12
    //   540: ldc -2147483648
    //   542: aload #12
    //   544: getfield 堅 : I
    //   547: if_icmpne -> 555
    //   550: iconst_0
    //   551: istore_3
    //   552: goto -> 567
    //   555: aload #12
    //   557: invokevirtual 不 : ()I
    //   560: aload #12
    //   562: getfield 堅 : I
    //   565: isub
    //   566: istore_3
    //   567: iload_3
    //   568: iload #4
    //   570: iadd
    //   571: istore_3
    //   572: goto -> 585
    //   575: aload_0
    //   576: getfield 恐 : Ly/k8;
    //   579: aload #12
    //   581: invokevirtual 暑 : (Landroid/view/View;)I
    //   584: istore_3
    //   585: aload #14
    //   587: iload_3
    //   588: putfield 冷 : I
    //   591: goto -> 715
    //   594: aload_0
    //   595: invokevirtual 起 : ()I
    //   598: ifle -> 652
    //   601: aload_0
    //   602: iconst_0
    //   603: invokevirtual 臭 : (I)Landroid/view/View;
    //   606: invokestatic 泳 : (Landroid/view/View;)I
    //   609: istore_3
    //   610: aload_0
    //   611: getfield 産 : I
    //   614: iload_3
    //   615: if_icmpge -> 624
    //   618: iconst_1
    //   619: istore #11
    //   621: goto -> 627
    //   624: iconst_0
    //   625: istore #11
    //   627: iload #11
    //   629: aload_0
    //   630: getfield 臭 : Z
    //   633: if_icmpne -> 642
    //   636: iconst_1
    //   637: istore #11
    //   639: goto -> 645
    //   642: iconst_0
    //   643: istore #11
    //   645: aload #14
    //   647: iload #11
    //   649: putfield 熱 : Z
    //   652: aload #14
    //   654: invokevirtual 硬 : ()V
    //   657: goto -> 715
    //   660: aload_0
    //   661: getfield 臭 : Z
    //   664: istore #11
    //   666: aload #14
    //   668: iload #11
    //   670: putfield 熱 : Z
    //   673: iload #11
    //   675: ifeq -> 698
    //   678: aload #14
    //   680: aload_0
    //   681: getfield 恐 : Ly/k8;
    //   684: invokevirtual 寒 : ()I
    //   687: aload_0
    //   688: getfield 死 : I
    //   691: isub
    //   692: putfield 冷 : I
    //   695: goto -> 715
    //   698: aload #14
    //   700: aload_0
    //   701: getfield 恐 : Ly/k8;
    //   704: invokevirtual 旨 : ()I
    //   707: aload_0
    //   708: getfield 死 : I
    //   711: iadd
    //   712: putfield 冷 : I
    //   715: iconst_1
    //   716: istore_3
    //   717: goto -> 733
    //   720: aload_0
    //   721: iconst_m1
    //   722: putfield 産 : I
    //   725: aload_0
    //   726: ldc -2147483648
    //   728: putfield 死 : I
    //   731: iconst_0
    //   732: istore_3
    //   733: iload_3
    //   734: ifeq -> 740
    //   737: goto -> 1144
    //   740: aload_0
    //   741: invokevirtual 起 : ()I
    //   744: ifne -> 750
    //   747: goto -> 1105
    //   750: aload_0
    //   751: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   754: astore #12
    //   756: aload #12
    //   758: ifnonnull -> 767
    //   761: aconst_null
    //   762: astore #12
    //   764: goto -> 798
    //   767: aload #12
    //   769: invokevirtual getFocusedChild : ()Landroid/view/View;
    //   772: astore #13
    //   774: aload #13
    //   776: ifnull -> 761
    //   779: aload #13
    //   781: astore #12
    //   783: aload_0
    //   784: getfield 硬 : Ly/話;
    //   787: aload #13
    //   789: invokevirtual 辛 : (Landroid/view/View;)Z
    //   792: ifeq -> 798
    //   795: goto -> 761
    //   798: aload #12
    //   800: ifnull -> 867
    //   803: aload #12
    //   805: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   808: checkcast y/qe
    //   811: astore #13
    //   813: aload #13
    //   815: invokevirtual 熱 : ()Z
    //   818: ifne -> 846
    //   821: aload #13
    //   823: invokevirtual 硬 : ()I
    //   826: iflt -> 846
    //   829: aload #13
    //   831: invokevirtual 硬 : ()I
    //   834: aload_2
    //   835: invokevirtual 堅 : ()I
    //   838: if_icmpge -> 846
    //   841: iconst_1
    //   842: istore_3
    //   843: goto -> 848
    //   846: iconst_0
    //   847: istore_3
    //   848: iload_3
    //   849: ifeq -> 867
    //   852: aload #14
    //   854: aload #12
    //   856: aload #12
    //   858: invokestatic 泳 : (Landroid/view/View;)I
    //   861: invokevirtual 熱 : (Landroid/view/View;I)V
    //   864: goto -> 1100
    //   867: aload_0
    //   868: getfield 痛 : Z
    //   871: aload_0
    //   872: getfield 起 : Z
    //   875: if_icmpeq -> 881
    //   878: goto -> 1105
    //   881: aload #14
    //   883: getfield 熱 : Z
    //   886: ifeq -> 938
    //   889: aload_0
    //   890: getfield 臭 : Z
    //   893: ifeq -> 916
    //   896: aload_0
    //   897: aload_1
    //   898: aload_2
    //   899: iconst_0
    //   900: aload_0
    //   901: invokevirtual 起 : ()I
    //   904: aload_2
    //   905: invokevirtual 堅 : ()I
    //   908: invokevirtual ふ : (Ly/we;Ly/bf;III)Landroid/view/View;
    //   911: astore #12
    //   913: goto -> 984
    //   916: aload_0
    //   917: aload_1
    //   918: aload_2
    //   919: aload_0
    //   920: invokevirtual 起 : ()I
    //   923: iconst_1
    //   924: isub
    //   925: iconst_m1
    //   926: aload_2
    //   927: invokevirtual 堅 : ()I
    //   930: invokevirtual ふ : (Ly/we;Ly/bf;III)Landroid/view/View;
    //   933: astore #12
    //   935: goto -> 984
    //   938: aload_0
    //   939: getfield 臭 : Z
    //   942: ifeq -> 967
    //   945: aload_0
    //   946: aload_1
    //   947: aload_2
    //   948: aload_0
    //   949: invokevirtual 起 : ()I
    //   952: iconst_1
    //   953: isub
    //   954: iconst_m1
    //   955: aload_2
    //   956: invokevirtual 堅 : ()I
    //   959: invokevirtual ふ : (Ly/we;Ly/bf;III)Landroid/view/View;
    //   962: astore #12
    //   964: goto -> 984
    //   967: aload_0
    //   968: aload_1
    //   969: aload_2
    //   970: iconst_0
    //   971: aload_0
    //   972: invokevirtual 起 : ()I
    //   975: aload_2
    //   976: invokevirtual 堅 : ()I
    //   979: invokevirtual ふ : (Ly/we;Ly/bf;III)Landroid/view/View;
    //   982: astore #12
    //   984: aload #12
    //   986: ifnull -> 1105
    //   989: aload #14
    //   991: aload #12
    //   993: aload #12
    //   995: invokestatic 泳 : (Landroid/view/View;)I
    //   998: invokevirtual 堅 : (Landroid/view/View;I)V
    //   1001: aload_2
    //   1002: getfield 美 : Z
    //   1005: ifne -> 1100
    //   1008: aload_0
    //   1009: invokevirtual く : ()Z
    //   1012: ifeq -> 1100
    //   1015: aload_0
    //   1016: getfield 恐 : Ly/k8;
    //   1019: aload #12
    //   1021: invokevirtual 暑 : (Landroid/view/View;)I
    //   1024: aload_0
    //   1025: getfield 恐 : Ly/k8;
    //   1028: invokevirtual 寒 : ()I
    //   1031: if_icmpge -> 1061
    //   1034: aload_0
    //   1035: getfield 恐 : Ly/k8;
    //   1038: aload #12
    //   1040: invokevirtual 堅 : (Landroid/view/View;)I
    //   1043: aload_0
    //   1044: getfield 恐 : Ly/k8;
    //   1047: invokevirtual 旨 : ()I
    //   1050: if_icmpge -> 1056
    //   1053: goto -> 1061
    //   1056: iconst_0
    //   1057: istore_3
    //   1058: goto -> 1063
    //   1061: iconst_1
    //   1062: istore_3
    //   1063: iload_3
    //   1064: ifeq -> 1100
    //   1067: aload #14
    //   1069: getfield 熱 : Z
    //   1072: ifeq -> 1086
    //   1075: aload_0
    //   1076: getfield 恐 : Ly/k8;
    //   1079: invokevirtual 寒 : ()I
    //   1082: istore_3
    //   1083: goto -> 1094
    //   1086: aload_0
    //   1087: getfield 恐 : Ly/k8;
    //   1090: invokevirtual 旨 : ()I
    //   1093: istore_3
    //   1094: aload #14
    //   1096: iload_3
    //   1097: putfield 冷 : I
    //   1100: iconst_1
    //   1101: istore_3
    //   1102: goto -> 1107
    //   1105: iconst_0
    //   1106: istore_3
    //   1107: iload_3
    //   1108: ifeq -> 1114
    //   1111: goto -> 1144
    //   1114: aload #14
    //   1116: invokevirtual 硬 : ()V
    //   1119: aload_0
    //   1120: getfield 起 : Z
    //   1123: ifeq -> 1136
    //   1126: aload_2
    //   1127: invokevirtual 堅 : ()I
    //   1130: iconst_1
    //   1131: isub
    //   1132: istore_3
    //   1133: goto -> 1138
    //   1136: iconst_0
    //   1137: istore_3
    //   1138: aload #14
    //   1140: iload_3
    //   1141: putfield 堅 : I
    //   1144: aload #14
    //   1146: iconst_1
    //   1147: putfield 暑 : Z
    //   1150: aload_0
    //   1151: getfield 怖 : Ly/胸;
    //   1154: astore #12
    //   1156: aload #12
    //   1158: getfield 辛 : I
    //   1161: iflt -> 1169
    //   1164: iconst_1
    //   1165: istore_3
    //   1166: goto -> 1171
    //   1169: iconst_m1
    //   1170: istore_3
    //   1171: aload #12
    //   1173: iload_3
    //   1174: putfield 寒 : I
    //   1177: aload_0
    //   1178: getfield 泳 : [I
    //   1181: astore #12
    //   1183: aload #12
    //   1185: iconst_0
    //   1186: iconst_0
    //   1187: iastore
    //   1188: aload #12
    //   1190: iconst_1
    //   1191: iconst_0
    //   1192: iastore
    //   1193: aload_0
    //   1194: aload_2
    //   1195: aload #12
    //   1197: invokevirtual ぼ : (Ly/bf;[I)V
    //   1200: iconst_0
    //   1201: aload #12
    //   1203: iconst_0
    //   1204: iaload
    //   1205: invokestatic max : (II)I
    //   1208: istore_3
    //   1209: aload_0
    //   1210: getfield 恐 : Ly/k8;
    //   1213: invokevirtual 旨 : ()I
    //   1216: iload_3
    //   1217: iadd
    //   1218: istore #5
    //   1220: iconst_0
    //   1221: aload #12
    //   1223: iconst_1
    //   1224: iaload
    //   1225: invokestatic max : (II)I
    //   1228: istore #4
    //   1230: aload_0
    //   1231: getfield 恐 : Ly/k8;
    //   1234: astore #12
    //   1236: aload #12
    //   1238: getfield 暑 : I
    //   1241: istore_3
    //   1242: aload #12
    //   1244: getfield 硬 : Ly/pe;
    //   1247: astore #12
    //   1249: iload_3
    //   1250: tableswitch default -> 1268, 0 -> 1271
    //   1268: goto -> 1280
    //   1271: aload #12
    //   1273: invokevirtual 返 : ()I
    //   1276: istore_3
    //   1277: goto -> 1286
    //   1280: aload #12
    //   1282: invokevirtual 壊 : ()I
    //   1285: istore_3
    //   1286: iload_3
    //   1287: iload #4
    //   1289: iadd
    //   1290: istore #6
    //   1292: iload #6
    //   1294: istore_3
    //   1295: iload #5
    //   1297: istore #4
    //   1299: aload_2
    //   1300: getfield 美 : Z
    //   1303: ifeq -> 1449
    //   1306: aload_0
    //   1307: getfield 産 : I
    //   1310: istore #7
    //   1312: iload #6
    //   1314: istore_3
    //   1315: iload #5
    //   1317: istore #4
    //   1319: iload #7
    //   1321: iconst_m1
    //   1322: if_icmpeq -> 1449
    //   1325: iload #6
    //   1327: istore_3
    //   1328: iload #5
    //   1330: istore #4
    //   1332: aload_0
    //   1333: getfield 死 : I
    //   1336: ldc -2147483648
    //   1338: if_icmpeq -> 1449
    //   1341: aload_0
    //   1342: iload #7
    //   1344: invokevirtual 怖 : (I)Landroid/view/View;
    //   1347: astore #12
    //   1349: iload #6
    //   1351: istore_3
    //   1352: iload #5
    //   1354: istore #4
    //   1356: aload #12
    //   1358: ifnull -> 1449
    //   1361: aload_0
    //   1362: getfield 臭 : Z
    //   1365: ifeq -> 1395
    //   1368: aload_0
    //   1369: getfield 恐 : Ly/k8;
    //   1372: invokevirtual 寒 : ()I
    //   1375: aload_0
    //   1376: getfield 恐 : Ly/k8;
    //   1379: aload #12
    //   1381: invokevirtual 堅 : (Landroid/view/View;)I
    //   1384: isub
    //   1385: istore #4
    //   1387: aload_0
    //   1388: getfield 死 : I
    //   1391: istore_3
    //   1392: goto -> 1419
    //   1395: aload_0
    //   1396: getfield 恐 : Ly/k8;
    //   1399: aload #12
    //   1401: invokevirtual 暑 : (Landroid/view/View;)I
    //   1404: aload_0
    //   1405: getfield 恐 : Ly/k8;
    //   1408: invokevirtual 旨 : ()I
    //   1411: isub
    //   1412: istore_3
    //   1413: aload_0
    //   1414: getfield 死 : I
    //   1417: istore #4
    //   1419: iload #4
    //   1421: iload_3
    //   1422: isub
    //   1423: istore_3
    //   1424: iload_3
    //   1425: ifle -> 1440
    //   1428: iload #5
    //   1430: iload_3
    //   1431: iadd
    //   1432: istore #4
    //   1434: iload #6
    //   1436: istore_3
    //   1437: goto -> 1449
    //   1440: iload #6
    //   1442: iload_3
    //   1443: isub
    //   1444: istore_3
    //   1445: iload #5
    //   1447: istore #4
    //   1449: aload #14
    //   1451: getfield 熱 : Z
    //   1454: ifeq -> 1467
    //   1457: aload_0
    //   1458: getfield 臭 : Z
    //   1461: ifeq -> 1474
    //   1464: goto -> 1480
    //   1467: aload_0
    //   1468: getfield 臭 : Z
    //   1471: ifeq -> 1480
    //   1474: iconst_m1
    //   1475: istore #5
    //   1477: goto -> 1483
    //   1480: iconst_1
    //   1481: istore #5
    //   1483: aload_0
    //   1484: aload_1
    //   1485: aload_2
    //   1486: aload #14
    //   1488: iload #5
    //   1490: invokevirtual 治 : (Ly/we;Ly/bf;Ly/骨;I)V
    //   1493: aload_0
    //   1494: aload_1
    //   1495: invokevirtual 淋 : (Ly/we;)V
    //   1498: aload_0
    //   1499: getfield 怖 : Ly/胸;
    //   1502: astore #12
    //   1504: aload_0
    //   1505: getfield 恐 : Ly/k8;
    //   1508: invokevirtual 美 : ()I
    //   1511: ifne -> 1530
    //   1514: aload_0
    //   1515: getfield 恐 : Ly/k8;
    //   1518: invokevirtual 冷 : ()I
    //   1521: ifne -> 1530
    //   1524: iconst_1
    //   1525: istore #11
    //   1527: goto -> 1533
    //   1530: iconst_0
    //   1531: istore #11
    //   1533: aload #12
    //   1535: iload #11
    //   1537: putfield 苦 : Z
    //   1540: aload_0
    //   1541: getfield 怖 : Ly/胸;
    //   1544: invokevirtual getClass : ()Ljava/lang/Class;
    //   1547: pop
    //   1548: aload_0
    //   1549: getfield 怖 : Ly/胸;
    //   1552: iconst_0
    //   1553: putfield 不 : I
    //   1556: aload #14
    //   1558: getfield 熱 : Z
    //   1561: ifeq -> 1773
    //   1564: aload_0
    //   1565: aload #14
    //   1567: getfield 堅 : I
    //   1570: aload #14
    //   1572: getfield 冷 : I
    //   1575: invokevirtual つ : (II)V
    //   1578: aload_0
    //   1579: getfield 怖 : Ly/胸;
    //   1582: astore #12
    //   1584: aload #12
    //   1586: iload #4
    //   1588: putfield 旨 : I
    //   1591: aload_0
    //   1592: aload_1
    //   1593: aload #12
    //   1595: aload_2
    //   1596: iconst_0
    //   1597: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1600: pop
    //   1601: aload_0
    //   1602: getfield 怖 : Ly/胸;
    //   1605: astore #12
    //   1607: aload #12
    //   1609: getfield 堅 : I
    //   1612: istore #5
    //   1614: aload #12
    //   1616: getfield 暑 : I
    //   1619: istore #7
    //   1621: aload #12
    //   1623: getfield 熱 : I
    //   1626: istore #6
    //   1628: iload_3
    //   1629: istore #4
    //   1631: iload #6
    //   1633: ifle -> 1642
    //   1636: iload_3
    //   1637: iload #6
    //   1639: iadd
    //   1640: istore #4
    //   1642: aload_0
    //   1643: aload #14
    //   1645: getfield 堅 : I
    //   1648: aload #14
    //   1650: getfield 冷 : I
    //   1653: invokevirtual さ : (II)V
    //   1656: aload_0
    //   1657: getfield 怖 : Ly/胸;
    //   1660: astore #12
    //   1662: aload #12
    //   1664: iload #4
    //   1666: putfield 旨 : I
    //   1669: aload #12
    //   1671: aload #12
    //   1673: getfield 暑 : I
    //   1676: aload #12
    //   1678: getfield 冷 : I
    //   1681: iadd
    //   1682: putfield 暑 : I
    //   1685: aload_0
    //   1686: aload_1
    //   1687: aload #12
    //   1689: aload_2
    //   1690: iconst_0
    //   1691: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1694: pop
    //   1695: aload_0
    //   1696: getfield 怖 : Ly/胸;
    //   1699: astore #12
    //   1701: aload #12
    //   1703: getfield 堅 : I
    //   1706: istore #6
    //   1708: aload #12
    //   1710: getfield 熱 : I
    //   1713: istore #8
    //   1715: iload #6
    //   1717: istore_3
    //   1718: iload #5
    //   1720: istore #4
    //   1722: iload #8
    //   1724: ifle -> 1977
    //   1727: aload_0
    //   1728: iload #7
    //   1730: iload #5
    //   1732: invokevirtual つ : (II)V
    //   1735: aload_0
    //   1736: getfield 怖 : Ly/胸;
    //   1739: astore #12
    //   1741: aload #12
    //   1743: iload #8
    //   1745: putfield 旨 : I
    //   1748: aload_0
    //   1749: aload_1
    //   1750: aload #12
    //   1752: aload_2
    //   1753: iconst_0
    //   1754: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1757: pop
    //   1758: aload_0
    //   1759: getfield 怖 : Ly/胸;
    //   1762: getfield 堅 : I
    //   1765: istore #4
    //   1767: iload #6
    //   1769: istore_3
    //   1770: goto -> 1977
    //   1773: aload_0
    //   1774: aload #14
    //   1776: getfield 堅 : I
    //   1779: aload #14
    //   1781: getfield 冷 : I
    //   1784: invokevirtual さ : (II)V
    //   1787: aload_0
    //   1788: getfield 怖 : Ly/胸;
    //   1791: astore #12
    //   1793: aload #12
    //   1795: iload_3
    //   1796: putfield 旨 : I
    //   1799: aload_0
    //   1800: aload_1
    //   1801: aload #12
    //   1803: aload_2
    //   1804: iconst_0
    //   1805: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1808: pop
    //   1809: aload_0
    //   1810: getfield 怖 : Ly/胸;
    //   1813: astore #12
    //   1815: aload #12
    //   1817: getfield 堅 : I
    //   1820: istore #5
    //   1822: aload #12
    //   1824: getfield 暑 : I
    //   1827: istore #7
    //   1829: aload #12
    //   1831: getfield 熱 : I
    //   1834: istore #6
    //   1836: iload #4
    //   1838: istore_3
    //   1839: iload #6
    //   1841: ifle -> 1850
    //   1844: iload #4
    //   1846: iload #6
    //   1848: iadd
    //   1849: istore_3
    //   1850: aload_0
    //   1851: aload #14
    //   1853: getfield 堅 : I
    //   1856: aload #14
    //   1858: getfield 冷 : I
    //   1861: invokevirtual つ : (II)V
    //   1864: aload_0
    //   1865: getfield 怖 : Ly/胸;
    //   1868: astore #12
    //   1870: aload #12
    //   1872: iload_3
    //   1873: putfield 旨 : I
    //   1876: aload #12
    //   1878: aload #12
    //   1880: getfield 暑 : I
    //   1883: aload #12
    //   1885: getfield 冷 : I
    //   1888: iadd
    //   1889: putfield 暑 : I
    //   1892: aload_0
    //   1893: aload_1
    //   1894: aload #12
    //   1896: aload_2
    //   1897: iconst_0
    //   1898: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1901: pop
    //   1902: aload_0
    //   1903: getfield 怖 : Ly/胸;
    //   1906: astore #12
    //   1908: aload #12
    //   1910: getfield 堅 : I
    //   1913: istore #6
    //   1915: aload #12
    //   1917: getfield 熱 : I
    //   1920: istore #8
    //   1922: iload #5
    //   1924: istore_3
    //   1925: iload #6
    //   1927: istore #4
    //   1929: iload #8
    //   1931: ifle -> 1977
    //   1934: aload_0
    //   1935: iload #7
    //   1937: iload #5
    //   1939: invokevirtual さ : (II)V
    //   1942: aload_0
    //   1943: getfield 怖 : Ly/胸;
    //   1946: astore #12
    //   1948: aload #12
    //   1950: iload #8
    //   1952: putfield 旨 : I
    //   1955: aload_0
    //   1956: aload_1
    //   1957: aload #12
    //   1959: aload_2
    //   1960: iconst_0
    //   1961: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   1964: pop
    //   1965: aload_0
    //   1966: getfield 怖 : Ly/胸;
    //   1969: getfield 堅 : I
    //   1972: istore_3
    //   1973: iload #6
    //   1975: istore #4
    //   1977: iload_3
    //   1978: istore #6
    //   1980: iload #4
    //   1982: istore #5
    //   1984: aload_0
    //   1985: invokevirtual 起 : ()I
    //   1988: ifle -> 2085
    //   1991: aload_0
    //   1992: getfield 臭 : Z
    //   1995: aload_0
    //   1996: getfield 起 : Z
    //   1999: ixor
    //   2000: ifeq -> 2039
    //   2003: aload_0
    //   2004: iload_3
    //   2005: aload_1
    //   2006: aload_2
    //   2007: iconst_1
    //   2008: invokevirtual 婦 : (ILy/we;Ly/bf;Z)I
    //   2011: istore #6
    //   2013: iload #4
    //   2015: iload #6
    //   2017: iadd
    //   2018: istore #5
    //   2020: iload_3
    //   2021: iload #6
    //   2023: iadd
    //   2024: istore #4
    //   2026: aload_0
    //   2027: iload #5
    //   2029: aload_1
    //   2030: aload_2
    //   2031: iconst_0
    //   2032: invokevirtual 歯 : (ILy/we;Ly/bf;Z)I
    //   2035: istore_3
    //   2036: goto -> 2073
    //   2039: aload_0
    //   2040: iload #4
    //   2042: aload_1
    //   2043: aload_2
    //   2044: iconst_1
    //   2045: invokevirtual 歯 : (ILy/we;Ly/bf;Z)I
    //   2048: istore #6
    //   2050: iload #4
    //   2052: iload #6
    //   2054: iadd
    //   2055: istore #5
    //   2057: iload_3
    //   2058: iload #6
    //   2060: iadd
    //   2061: istore #4
    //   2063: aload_0
    //   2064: iload #4
    //   2066: aload_1
    //   2067: aload_2
    //   2068: iconst_0
    //   2069: invokevirtual 婦 : (ILy/we;Ly/bf;Z)I
    //   2072: istore_3
    //   2073: iload #5
    //   2075: iload_3
    //   2076: iadd
    //   2077: istore #5
    //   2079: iload #4
    //   2081: iload_3
    //   2082: iadd
    //   2083: istore #6
    //   2085: aload_2
    //   2086: getfield ぱ : Z
    //   2089: ifeq -> 2400
    //   2092: aload_0
    //   2093: invokevirtual 起 : ()I
    //   2096: ifeq -> 2400
    //   2099: aload_2
    //   2100: getfield 美 : Z
    //   2103: ifne -> 2400
    //   2106: aload_0
    //   2107: invokevirtual く : ()Z
    //   2110: ifne -> 2116
    //   2113: goto -> 2400
    //   2116: aload_1
    //   2117: getfield 暑 : Ljava/util/List;
    //   2120: astore #12
    //   2122: aload #12
    //   2124: invokeinterface size : ()I
    //   2129: istore #9
    //   2131: aload_0
    //   2132: iconst_0
    //   2133: invokevirtual 臭 : (I)Landroid/view/View;
    //   2136: invokestatic 泳 : (Landroid/view/View;)I
    //   2139: istore #10
    //   2141: iconst_0
    //   2142: istore_3
    //   2143: iconst_0
    //   2144: istore #7
    //   2146: iconst_0
    //   2147: istore #4
    //   2149: iload_3
    //   2150: iload #9
    //   2152: if_icmpge -> 2267
    //   2155: aload #12
    //   2157: iload_3
    //   2158: invokeinterface get : (I)Ljava/lang/Object;
    //   2163: checkcast y/ef
    //   2166: astore #13
    //   2168: aload #13
    //   2170: invokevirtual 不 : ()Z
    //   2173: ifeq -> 2179
    //   2176: goto -> 2260
    //   2179: aload #13
    //   2181: invokevirtual 熱 : ()I
    //   2184: iload #10
    //   2186: if_icmpge -> 2195
    //   2189: iconst_1
    //   2190: istore #11
    //   2192: goto -> 2198
    //   2195: iconst_0
    //   2196: istore #11
    //   2198: iload #11
    //   2200: aload_0
    //   2201: getfield 臭 : Z
    //   2204: if_icmpeq -> 2213
    //   2207: iconst_m1
    //   2208: istore #8
    //   2210: goto -> 2216
    //   2213: iconst_1
    //   2214: istore #8
    //   2216: aload #13
    //   2218: getfield 硬 : Landroid/view/View;
    //   2221: astore #13
    //   2223: iload #8
    //   2225: iconst_m1
    //   2226: if_icmpne -> 2246
    //   2229: iload #7
    //   2231: aload_0
    //   2232: getfield 恐 : Ly/k8;
    //   2235: aload #13
    //   2237: invokevirtual 熱 : (Landroid/view/View;)I
    //   2240: iadd
    //   2241: istore #7
    //   2243: goto -> 2260
    //   2246: iload #4
    //   2248: aload_0
    //   2249: getfield 恐 : Ly/k8;
    //   2252: aload #13
    //   2254: invokevirtual 熱 : (Landroid/view/View;)I
    //   2257: iadd
    //   2258: istore #4
    //   2260: iload_3
    //   2261: iconst_1
    //   2262: iadd
    //   2263: istore_3
    //   2264: goto -> 2149
    //   2267: aload_0
    //   2268: getfield 怖 : Ly/胸;
    //   2271: aload #12
    //   2273: putfield ぱ : Ljava/util/List;
    //   2276: iload #7
    //   2278: ifle -> 2334
    //   2281: aload_0
    //   2282: aload_0
    //   2283: invokevirtual は : ()Landroid/view/View;
    //   2286: invokestatic 泳 : (Landroid/view/View;)I
    //   2289: iload #5
    //   2291: invokevirtual つ : (II)V
    //   2294: aload_0
    //   2295: getfield 怖 : Ly/胸;
    //   2298: astore #12
    //   2300: aload #12
    //   2302: iload #7
    //   2304: putfield 旨 : I
    //   2307: aload #12
    //   2309: iconst_0
    //   2310: putfield 熱 : I
    //   2313: aload #12
    //   2315: aconst_null
    //   2316: invokevirtual 硬 : (Landroid/view/View;)V
    //   2319: aload_0
    //   2320: aload_1
    //   2321: aload_0
    //   2322: getfield 怖 : Ly/胸;
    //   2325: aload_2
    //   2326: iconst_0
    //   2327: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   2330: pop
    //   2331: goto -> 2334
    //   2334: iload #4
    //   2336: ifle -> 2392
    //   2339: aload_0
    //   2340: aload_0
    //   2341: invokevirtual 科 : ()Landroid/view/View;
    //   2344: invokestatic 泳 : (Landroid/view/View;)I
    //   2347: iload #6
    //   2349: invokevirtual さ : (II)V
    //   2352: aload_0
    //   2353: getfield 怖 : Ly/胸;
    //   2356: astore #12
    //   2358: aload #12
    //   2360: iload #4
    //   2362: putfield 旨 : I
    //   2365: aload #12
    //   2367: iconst_0
    //   2368: putfield 熱 : I
    //   2371: aload #12
    //   2373: aconst_null
    //   2374: invokevirtual 硬 : (Landroid/view/View;)V
    //   2377: aload_0
    //   2378: aload_1
    //   2379: aload_0
    //   2380: getfield 怖 : Ly/胸;
    //   2383: aload_2
    //   2384: iconst_0
    //   2385: invokevirtual ね : (Ly/we;Ly/胸;Ly/bf;Z)I
    //   2388: pop
    //   2389: goto -> 2392
    //   2392: aload_0
    //   2393: getfield 怖 : Ly/胸;
    //   2396: aconst_null
    //   2397: putfield ぱ : Ljava/util/List;
    //   2400: aload_2
    //   2401: getfield 美 : Z
    //   2404: ifne -> 2423
    //   2407: aload_0
    //   2408: getfield 恐 : Ly/k8;
    //   2411: astore_1
    //   2412: aload_1
    //   2413: aload_1
    //   2414: invokevirtual 不 : ()I
    //   2417: putfield 堅 : I
    //   2420: goto -> 2428
    //   2423: aload #14
    //   2425: invokevirtual 暑 : ()V
    //   2428: aload_0
    //   2429: aload_0
    //   2430: getfield 起 : Z
    //   2433: putfield 痛 : Z
    //   2436: return
  }
  
  public final void 不(int paramInt, 표 param표) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 壊 : Ly/ぜ;
    //   4: astore #9
    //   6: iconst_1
    //   7: istore #4
    //   9: aload #9
    //   11: ifnull -> 50
    //   14: aload #9
    //   16: getfield 淋 : I
    //   19: istore #5
    //   21: iload #5
    //   23: iflt -> 31
    //   26: iconst_1
    //   27: istore_3
    //   28: goto -> 33
    //   31: iconst_0
    //   32: istore_3
    //   33: iload_3
    //   34: ifeq -> 50
    //   37: aload #9
    //   39: getfield 恐 : Z
    //   42: istore #7
    //   44: iload #5
    //   46: istore_3
    //   47: goto -> 101
    //   50: aload_0
    //   51: invokevirtual 弁 : ()V
    //   54: aload_0
    //   55: getfield 臭 : Z
    //   58: istore #8
    //   60: aload_0
    //   61: getfield 産 : I
    //   64: istore #5
    //   66: iload #8
    //   68: istore #7
    //   70: iload #5
    //   72: istore_3
    //   73: iload #5
    //   75: iconst_m1
    //   76: if_icmpne -> 101
    //   79: iload #8
    //   81: ifeq -> 95
    //   84: iload_1
    //   85: iconst_1
    //   86: isub
    //   87: istore_3
    //   88: iload #8
    //   90: istore #7
    //   92: goto -> 101
    //   95: iconst_0
    //   96: istore_3
    //   97: iload #8
    //   99: istore #7
    //   101: iload #7
    //   103: ifeq -> 109
    //   106: iconst_m1
    //   107: istore #4
    //   109: iconst_0
    //   110: istore #6
    //   112: iload_3
    //   113: istore #5
    //   115: iload #6
    //   117: istore_3
    //   118: iload_3
    //   119: aload_0
    //   120: getfield 歩 : I
    //   123: if_icmpge -> 158
    //   126: iload #5
    //   128: iflt -> 158
    //   131: iload #5
    //   133: iload_1
    //   134: if_icmpge -> 158
    //   137: aload_2
    //   138: iload #5
    //   140: iconst_0
    //   141: invokevirtual 硬 : (II)V
    //   144: iload #5
    //   146: iload #4
    //   148: iadd
    //   149: istore #5
    //   151: iload_3
    //   152: iconst_1
    //   153: iadd
    //   154: istore_3
    //   155: goto -> 118
    //   158: return
  }
  
  public final int 俺(bf parambf) {
    if (起() == 0)
      return 0; 
    少();
    k8 k81 = this.恐;
    int i = this.興 ^ true;
    return ik.寂(parambf, (l8)k81, 医(i), 年(i), this, this.興, this.臭);
  }
  
  public void 僕(bf parambf, 胸 param胸, 표 param표) {
    int i = param胸.暑;
    if (i >= 0 && i < parambf.堅())
      param표.硬(i, Math.max(0, param胸.美)); 
  }
  
  public final boolean 冷() {
    return (this.淋 == 1);
  }
  
  public final View 医(boolean paramBoolean) {
    return this.臭 ? 師(起() - 1, -1, paramBoolean) : 師(0, 起(), paramBoolean);
  }
  
  public final int 士(int paramInt, we paramwe, bf parambf) {
    if (起() != 0) {
      byte b;
      if (paramInt == 0)
        return 0; 
      少();
      this.怖.硬 = true;
      if (paramInt > 0) {
        b = 1;
      } else {
        b = -1;
      } 
      int i = Math.abs(paramInt);
      け(b, i, true, parambf);
      胸 胸1 = this.怖;
      int j = 胸1.美;
      j = ね(paramwe, 胸1, parambf, false) + j;
      if (j < 0)
        return 0; 
      if (i > j)
        paramInt = b * j; 
      this.恐.苦(-paramInt);
      this.怖.辛 = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public final int 婦(int paramInt, we paramwe, bf parambf, boolean paramBoolean) {
    int i = this.恐.寒() - paramInt;
    if (i > 0) {
      i = -士(-i, paramwe, parambf);
      if (paramBoolean) {
        paramInt = this.恐.寒() - paramInt + i;
        if (paramInt > 0) {
          this.恐.苦(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public final int 嬉(bf parambf) {
    return れ(parambf);
  }
  
  public final void 家(we paramwe, 胸 param胸) {
    if (param胸.硬) {
      if (param胸.苦)
        return; 
      int i = param胸.美;
      int j = param胸.不;
      if (param胸.寒 == -1) {
        int k = 起();
        if (i < 0)
          return; 
        j = this.恐.冷() - i + j;
        if (this.臭) {
          for (i = 0; i < k; i++) {
            View view = 臭(i);
            if (this.恐.暑(view) < j || this.恐.ぱ(view) < j) {
              べ(paramwe, 0, i);
              return;
            } 
          } 
        } else {
          for (i = --k; i >= 0; i--) {
            View view = 臭(i);
            if (this.恐.暑(view) < j || this.恐.ぱ(view) < j) {
              べ(paramwe, k, i);
              return;
            } 
          } 
        } 
      } else {
        if (i < 0)
          return; 
        j = i - j;
        int k = 起();
        if (this.臭) {
          for (i = --k; i >= 0; i--) {
            View view = 臭(i);
            if (this.恐.堅(view) > j || this.恐.辛(view) > j) {
              べ(paramwe, k, i);
              return;
            } 
          } 
        } else {
          for (i = 0; i < k; i++) {
            View view = 臭(i);
            if (this.恐.堅(view) > j || this.恐.辛(view) > j) {
              べ(paramwe, 0, i);
              break;
            } 
          } 
        } 
      } 
    } 
  }
  
  public int 寂(bf parambf) {
    return ょ(parambf);
  }
  
  public final void 少() {
    if (this.怖 == null)
      this.怖 = new 胸(); 
  }
  
  public final View 師(int paramInt1, int paramInt2, boolean paramBoolean) {
    char c;
    少();
    if (paramBoolean) {
      c = '怃';
    } else {
      c = 'ŀ';
    } 
    return (this.淋 == 0) ? this.熱.寒(paramInt1, paramInt2, c, 320) : this.暑.寒(paramInt1, paramInt2, c, 320);
  }
  
  public final View 年(boolean paramBoolean) {
    return this.臭 ? 師(0, 起(), paramBoolean) : 師(起() - 1, -1, paramBoolean);
  }
  
  public final void 弁() {
    if (this.淋 == 1 || !せ()) {
      this.臭 = this.痒;
      return;
    } 
    this.臭 = this.痒 ^ true;
  }
  
  public final View 怖(int paramInt) {
    int i = 起();
    if (i == 0)
      return null; 
    int j = paramInt - pe.泳(臭(0));
    if (j >= 0 && j < i) {
      View view = 臭(j);
      if (pe.泳(view) == paramInt)
        return view; 
    } 
    return super.怖(paramInt);
  }
  
  public qe 恐() {
    return new qe(-2, -2);
  }
  
  public int 悲(bf parambf) {
    return 俺(parambf);
  }
  
  public void 政(we paramwe, bf parambf, 胸 param胸, む paramむ) {
    View view = param胸.堅(paramwe);
    if (view == null) {
      paramむ.堅 = true;
      return;
    } 
    qe qe1 = (qe)view.getLayoutParams();
    if (param胸.ぱ == null) {
      boolean bool1;
      boolean bool2 = this.臭;
      if (param胸.寒 == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        堅(-1, view, false);
      } else {
        堅(0, view, false);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.臭;
      if (param胸.寒 == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        堅(-1, view, true);
      } else {
        堅(0, view, true);
      } 
    } 
    qe qe2 = (qe)view.getLayoutParams();
    Rect rect = this.堅.あ(view);
    int k = rect.left;
    int m = rect.right;
    int i = rect.top;
    int j = rect.bottom;
    int n = this.悲;
    int i1 = this.苦;
    int i2 = 帰();
    int i3 = 返();
    int i4 = ((ViewGroup.MarginLayoutParams)qe2).leftMargin;
    int i5 = ((ViewGroup.MarginLayoutParams)qe2).rightMargin;
    int i6 = ((ViewGroup.MarginLayoutParams)qe2).width;
    k = pe.興(暑(), n, i1, i3 + i2 + i4 + i5 + k + m + 0, i6);
    m = this.寂;
    n = this.嬉;
    i1 = 歩();
    i2 = 壊();
    i3 = ((ViewGroup.MarginLayoutParams)qe2).topMargin;
    i4 = ((ViewGroup.MarginLayoutParams)qe2).bottomMargin;
    i5 = ((ViewGroup.MarginLayoutParams)qe2).height;
    i = pe.興(冷(), m, n, i2 + i1 + i3 + i4 + i + j + 0, i5);
    if (퉁(view, k, i, qe2))
      view.measure(k, i); 
    paramむ.硬 = this.恐.熱(view);
    if (this.淋 == 1) {
      if (せ()) {
        k = this.悲 - 返();
        j = k - this.恐.嬉(view);
      } else {
        j = 帰();
        k = this.恐.嬉(view) + j;
      } 
      if (param胸.寒 == -1) {
        n = param胸.堅;
        i = n - paramむ.硬;
        m = j;
        j = n;
      } else {
        i = param胸.堅;
        n = paramむ.硬 + i;
        m = j;
        j = n;
      } 
    } else {
      i = 歩();
      j = this.恐.嬉(view) + i;
      if (param胸.寒 == -1) {
        m = param胸.堅;
        n = paramむ.硬;
        k = m;
        m -= n;
      } else {
        k = param胸.堅;
        n = paramむ.硬;
        m = k;
        k = n + k;
      } 
    } 
    pe.あ(view, m, i, k, j);
    if (qe1.熱() || qe1.堅())
      paramむ.熱 = true; 
    paramむ.暑 = view.hasFocusable();
  }
  
  public final void 旨(int paramInt1, int paramInt2, bf parambf, 표 param표) {
    if (this.淋 != 0)
      paramInt1 = paramInt2; 
    if (起() != 0) {
      if (paramInt1 == 0)
        return; 
      少();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      け(paramInt2, Math.abs(paramInt1), true, parambf);
      僕(parambf, this.怖, param표);
    } 
  }
  
  public final boolean 暑() {
    return (this.淋 == 0);
  }
  
  public final int 歯(int paramInt, we paramwe, bf parambf, boolean paramBoolean) {
    int i = paramInt - this.恐.旨();
    if (i > 0) {
      int j = -士(i, paramwe, parambf);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.恐.旨();
        i = j;
        if (paramInt > 0) {
          this.恐.苦(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public void 治(we paramwe, bf parambf, 骨 param骨, int paramInt) {}
  
  public final void 消(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      熱(null);
      if (paramInt != this.淋 || this.恐 == null) {
        k8 k81 = l8.硬(this, paramInt);
        this.恐 = k81;
        this.帰.寒 = k81;
        this.淋 = paramInt;
        탱();
      } 
      return;
    } 
    throw new IllegalArgumentException(bm.熱("invalid orientation:", paramInt));
  }
  
  public final void 熱(String paramString) {
    if (this.壊 == null) {
      RecyclerView recyclerView = this.堅;
      if (recyclerView != null)
        recyclerView.不(paramString); 
    } 
  }
  
  public final int 看() {
    View view = 師(起() - 1, -1, false);
    return (view == null) ? -1 : pe.泳(view);
  }
  
  public final PointF 硬(int paramInt) {
    if (起() == 0)
      return null; 
    boolean bool1 = false;
    int i = pe.泳(臭(0));
    boolean bool = true;
    if (paramInt < i)
      bool1 = true; 
    paramInt = bool;
    if (bool1 != this.臭)
      paramInt = -1; 
    return (this.淋 == 0) ? new PointF(paramInt, 0.0F) : new PointF(0.0F, paramInt);
  }
  
  public final View 科() {
    int i;
    if (this.臭) {
      i = 0;
    } else {
      i = 起() - 1;
    } 
    return 臭(i);
  }
  
  public final boolean 者() {
    int i = this.嬉;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i != 1073741824) {
      bool1 = bool2;
      if (this.苦 != 1073741824) {
        int j = 起();
        i = 0;
        while (true) {
          if (i < j) {
            ViewGroup.LayoutParams layoutParams = 臭(i).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
              i = 1;
              break;
            } 
            i++;
            continue;
          } 
          i = 0;
          break;
        } 
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public int 苦(bf parambf) {
    return ょ(parambf);
  }
  
  public final boolean 触() {
    return true;
  }
  
  public final View 護(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    少();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return 臭(paramInt1); 
    if (this.恐.暑(臭(paramInt1)) < this.恐.旨()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    return (this.淋 == 0) ? this.熱.寒(paramInt1, paramInt2, c1, c2) : this.暑.寒(paramInt1, paramInt2, c1, c2);
  }
  
  public View 赤(View paramView, int paramInt, we paramwe, bf parambf) {
    View view1;
    View view2;
    弁();
    if (起() == 0)
      return null; 
    paramInt = う(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    少();
    け(paramInt, (int)(this.恐.不() * 0.33333334F), false, parambf);
    胸 胸1 = this.怖;
    胸1.美 = Integer.MIN_VALUE;
    胸1.硬 = false;
    ね(paramwe, 胸1, parambf, true);
    if (paramInt == -1) {
      if (this.臭) {
        view1 = 護(起() - 1, -1);
      } else {
        view1 = 護(0, 起());
      } 
    } else if (this.臭) {
      view1 = 護(0, 起());
    } else {
      view1 = 護(起() - 1, -1);
    } 
    if (paramInt == -1) {
      view2 = は();
    } else {
      view2 = 科();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public final int 辛(bf parambf) {
    return れ(parambf);
  }
  
  public void 防(boolean paramBoolean) {
    熱(null);
    if (this.起 == paramBoolean)
      return; 
    this.起 = paramBoolean;
    탱();
  }
  
  public void 타(bf parambf) {
    this.壊 = null;
    this.産 = -1;
    this.死 = Integer.MIN_VALUE;
    this.帰.暑();
  }
  
  public final void 탁(Parcelable paramParcelable) {
    if (paramParcelable instanceof ぜ) {
      this.壊 = (ぜ)paramParcelable;
      탱();
    } 
  }
  
  public final Parcelable 탄() {
    ぜ ぜ1 = this.壊;
    if (ぜ1 != null)
      return (Parcelable)new ぜ(ぜ1); 
    ぜ1 = new ぜ();
    if (起() > 0) {
      少();
      int i = this.痛 ^ this.臭;
      ぜ1.恐 = i;
      if (i != 0) {
        View view1 = 科();
        ぜ1.怖 = this.恐.寒() - this.恐.堅(view1);
        ぜ1.淋 = pe.泳(view1);
        return (Parcelable)ぜ1;
      } 
      View view = は();
      ぜ1.淋 = pe.泳(view);
      ぜ1.怖 = this.恐.暑(view) - this.恐.旨();
      return (Parcelable)ぜ1;
    } 
    ぜ1.淋 = -1;
    return (Parcelable)ぜ1;
  }
  
  public int 터(int paramInt, we paramwe, bf parambf) {
    return (this.淋 == 1) ? 0 : 士(paramInt, paramwe, parambf);
  }
  
  public final void 테(int paramInt) {
    this.産 = paramInt;
    this.死 = Integer.MIN_VALUE;
    ぜ ぜ1 = this.壊;
    if (ぜ1 != null)
      ぜ1.淋 = -1; 
    탱();
  }
  
  public int 토(int paramInt, we paramwe, bf parambf) {
    return (this.淋 == 0) ? 0 : 士(paramInt, paramwe, parambf);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */