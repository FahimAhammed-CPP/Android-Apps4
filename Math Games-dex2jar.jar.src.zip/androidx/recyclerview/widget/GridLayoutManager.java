package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.WeakHashMap;
import y.as;
import y.aw;
import y.bf;
import y.bm;
import y.pe;
import y.qe;
import y.rw;
import y.we;
import y.む;
import y.コ;
import y.胸;
import y.賊;
import y.骨;
import y.표;
import y.획;

public class GridLayoutManager extends LinearLayoutManager {
  public final SparseIntArray あ = new SparseIntArray();
  
  public final as か = new as(1);
  
  public final Rect ち = new Rect();
  
  public int[] 噛;
  
  public int 寝 = -1;
  
  public final SparseIntArray 投 = new SparseIntArray();
  
  public View[] 触;
  
  public boolean 踊 = false;
  
  public GridLayoutManager(int paramInt) {
    super(1);
    築(paramInt);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    築((pe.踊(paramContext, paramAttributeSet, paramInt1, paramInt2)).堅);
  }
  
  public final boolean く() {
    return (this.壊 == null && !this.踊);
  }
  
  public final int ぱ(bf parambf) {
    return 俺(parambf);
  }
  
  public final View ふ(we paramwe, bf parambf, int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    少();
    int i = this.恐.旨();
    int j = this.恐.寒();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    View view2 = null;
    View view1;
    for (view1 = null; paramInt1 != paramInt2; view1 = view4) {
      View view5 = 臭(paramInt1);
      int k = pe.泳(view5);
      View view3 = view2;
      View view4 = view1;
      if (k >= 0) {
        view3 = view2;
        view4 = view1;
        if (k < paramInt3)
          if (へ(k, paramwe, parambf) != 0) {
            view3 = view2;
            view4 = view1;
          } else if (((qe)view5.getLayoutParams()).熱()) {
            view3 = view2;
            view4 = view1;
            if (view1 == null) {
              view4 = view5;
              view3 = view2;
            } 
          } else if (this.恐.暑(view5) >= j || this.恐.堅(view5) < i) {
            view3 = view2;
            view4 = view1;
            if (view2 == null) {
              view3 = view5;
              view4 = view1;
            } 
          } else {
            return view5;
          }  
      } 
      paramInt1 += b;
      view2 = view3;
    } 
    return (view2 != null) ? view2 : view1;
  }
  
  public final int へ(int paramInt, we paramwe, bf parambf) {
    boolean bool = parambf.美;
    as as1 = this.か;
    if (!bool)
      return as1.熱(paramInt, this.寝); 
    int i = this.あ.get(paramInt, -1);
    if (i != -1)
      return i; 
    paramInt = paramwe.堅(paramInt);
    return (paramInt == -1) ? 0 : as1.熱(paramInt, this.寝);
  }
  
  public final void ㅌ(we paramwe, bf parambf) {
    boolean bool = parambf.美;
    SparseIntArray sparseIntArray1 = this.あ;
    SparseIntArray sparseIntArray2 = this.投;
    if (bool) {
      int j = 起();
      for (int i = 0; i < j; i++) {
        획 획 = (획)臭(i).getLayoutParams();
        int k = 획.硬();
        sparseIntArray2.put(k, 획.寒);
        sparseIntArray1.put(k, 획.冷);
      } 
    } 
    super.ㅌ(paramwe, parambf);
    sparseIntArray2.clear();
    sparseIntArray1.clear();
  }
  
  public final void 僕(bf parambf, 胸 param胸, 표 param표) {
    int j = this.寝;
    int i = 0;
    while (i < this.寝) {
      int k = param胸.暑;
      if (k >= 0 && k < parambf.堅()) {
        k = 1;
      } else {
        k = 0;
      } 
      if (k != 0 && j > 0) {
        param표.硬(param胸.暑, Math.max(0, param胸.美));
        this.か.getClass();
        j--;
        param胸.暑 += param胸.冷;
        i++;
      } 
    } 
  }
  
  public final void 先() {
    int i;
    int j;
    if (this.淋 == 1) {
      i = this.悲 - 返();
      j = 帰();
    } else {
      i = this.寂 - 壊();
      j = 歩();
    } 
    警(i - j);
  }
  
  public final int 兵(int paramInt, we paramwe, bf parambf) {
    boolean bool = parambf.美;
    as as1 = this.か;
    if (!bool) {
      as1.getClass();
      return 1;
    } 
    int i = this.投.get(paramInt, -1);
    if (i != -1)
      return i; 
    if (paramwe.堅(paramInt) == -1)
      return 1; 
    as1.getClass();
    return 1;
  }
  
  public final int 官(int paramInt, we paramwe, bf parambf) {
    boolean bool = parambf.美;
    as as1 = this.か;
    if (!bool)
      return as1.堅(paramInt, this.寝); 
    paramInt = paramwe.堅(paramInt);
    return (paramInt == -1) ? 0 : as1.堅(paramInt, this.寝);
  }
  
  public final int 寂(bf parambf) {
    return ょ(parambf);
  }
  
  public final boolean 寒(qe paramqe) {
    return paramqe instanceof 획;
  }
  
  public final int 寝(we paramwe, bf parambf) {
    return (this.淋 == 0) ? this.寝 : ((parambf.堅() < 1) ? 0 : (官(parambf.堅() - 1, paramwe, parambf) + 1));
  }
  
  public final int 察(int paramInt1, int paramInt2) {
    if (this.淋 == 1 && せ()) {
      int[] arrayOfInt1 = this.噛;
      int i = this.寝;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.噛;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public final void 建(int paramInt, View paramView, boolean paramBoolean) {
    획 획 = (획)paramView.getLayoutParams();
    Rect rect = ((qe)획).堅;
    int j = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams)획).topMargin + ((ViewGroup.MarginLayoutParams)획).bottomMargin;
    int i = rect.left + rect.right + ((ViewGroup.MarginLayoutParams)획).leftMargin + ((ViewGroup.MarginLayoutParams)획).rightMargin;
    int k = 察(획.冷, 획.寒);
    if (this.淋 == 1) {
      i = pe.興(false, k, paramInt, i, ((ViewGroup.MarginLayoutParams)획).width);
      paramInt = pe.興(true, this.恐.不(), this.嬉, j, ((ViewGroup.MarginLayoutParams)획).height);
    } else {
      paramInt = pe.興(false, k, paramInt, j, ((ViewGroup.MarginLayoutParams)획).height);
      i = pe.興(true, this.恐.不(), this.苦, i, ((ViewGroup.MarginLayoutParams)획).width);
    } 
    qe qe = (qe)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = た(paramView, i, paramInt, qe);
    } else {
      paramBoolean = 퉁(paramView, i, paramInt, qe);
    } 
    if (paramBoolean)
      paramView.measure(i, paramInt); 
  }
  
  public final qe 恐() {
    return (qe)((this.淋 == 0) ? new 획(-2, -1) : new 획(-1, -2));
  }
  
  public final int 悲(bf parambf) {
    return 俺(parambf);
  }
  
  public final void 政(we paramwe, bf parambf, 胸 param胸, む paramむ) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 恐 : Ly/k8;
    //   4: astore #19
    //   6: aload #19
    //   8: getfield 暑 : I
    //   11: istore #8
    //   13: aload #19
    //   15: getfield 硬 : Ly/pe;
    //   18: astore #19
    //   20: iload #8
    //   22: tableswitch default -> 40, 0 -> 43
    //   40: goto -> 53
    //   43: aload #19
    //   45: getfield 嬉 : I
    //   48: istore #11
    //   50: goto -> 60
    //   53: aload #19
    //   55: getfield 苦 : I
    //   58: istore #11
    //   60: iload #11
    //   62: ldc_w 1073741824
    //   65: if_icmpeq -> 74
    //   68: iconst_1
    //   69: istore #12
    //   71: goto -> 77
    //   74: iconst_0
    //   75: istore #12
    //   77: aload_0
    //   78: invokevirtual 起 : ()I
    //   81: ifle -> 98
    //   84: aload_0
    //   85: getfield 噛 : [I
    //   88: aload_0
    //   89: getfield 寝 : I
    //   92: iaload
    //   93: istore #13
    //   95: goto -> 101
    //   98: iconst_0
    //   99: istore #13
    //   101: iload #12
    //   103: ifeq -> 110
    //   106: aload_0
    //   107: invokevirtual 先 : ()V
    //   110: aload_3
    //   111: getfield 冷 : I
    //   114: iconst_1
    //   115: if_icmpne -> 124
    //   118: iconst_1
    //   119: istore #14
    //   121: goto -> 127
    //   124: iconst_0
    //   125: istore #14
    //   127: aload_0
    //   128: getfield 寝 : I
    //   131: istore #9
    //   133: iload #14
    //   135: ifne -> 161
    //   138: aload_0
    //   139: aload_3
    //   140: getfield 暑 : I
    //   143: aload_1
    //   144: aload_2
    //   145: invokevirtual へ : (ILy/we;Ly/bf;)I
    //   148: aload_0
    //   149: aload_3
    //   150: getfield 暑 : I
    //   153: aload_1
    //   154: aload_2
    //   155: invokevirtual 兵 : (ILy/we;Ly/bf;)I
    //   158: iadd
    //   159: istore #9
    //   161: iconst_0
    //   162: istore #8
    //   164: iload #8
    //   166: aload_0
    //   167: getfield 寝 : I
    //   170: if_icmpge -> 355
    //   173: aload_3
    //   174: getfield 暑 : I
    //   177: istore #10
    //   179: iload #10
    //   181: iflt -> 199
    //   184: iload #10
    //   186: aload_2
    //   187: invokevirtual 堅 : ()I
    //   190: if_icmpge -> 199
    //   193: iconst_1
    //   194: istore #10
    //   196: goto -> 202
    //   199: iconst_0
    //   200: istore #10
    //   202: iload #10
    //   204: ifeq -> 355
    //   207: iload #9
    //   209: ifle -> 355
    //   212: aload_3
    //   213: getfield 暑 : I
    //   216: istore #10
    //   218: aload_0
    //   219: iload #10
    //   221: aload_1
    //   222: aload_2
    //   223: invokevirtual 兵 : (ILy/we;Ly/bf;)I
    //   226: istore #15
    //   228: iload #15
    //   230: aload_0
    //   231: getfield 寝 : I
    //   234: if_icmpgt -> 285
    //   237: iload #9
    //   239: iload #15
    //   241: isub
    //   242: istore #9
    //   244: iload #9
    //   246: ifge -> 252
    //   249: goto -> 355
    //   252: aload_3
    //   253: aload_1
    //   254: invokevirtual 堅 : (Ly/we;)Landroid/view/View;
    //   257: astore #19
    //   259: aload #19
    //   261: ifnonnull -> 267
    //   264: goto -> 355
    //   267: aload_0
    //   268: getfield 触 : [Landroid/view/View;
    //   271: iload #8
    //   273: aload #19
    //   275: aastore
    //   276: iload #8
    //   278: iconst_1
    //   279: iadd
    //   280: istore #8
    //   282: goto -> 164
    //   285: new java/lang/StringBuilder
    //   288: dup
    //   289: ldc_w 'Item at position '
    //   292: invokespecial <init> : (Ljava/lang/String;)V
    //   295: astore_1
    //   296: aload_1
    //   297: iload #10
    //   299: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   302: pop
    //   303: aload_1
    //   304: ldc_w ' requires '
    //   307: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   310: pop
    //   311: aload_1
    //   312: iload #15
    //   314: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: aload_1
    //   319: ldc_w ' spans but GridLayoutManager has only '
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: pop
    //   326: aload_1
    //   327: aload_0
    //   328: getfield 寝 : I
    //   331: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload_1
    //   336: ldc_w ' spans.'
    //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: pop
    //   343: new java/lang/IllegalArgumentException
    //   346: dup
    //   347: aload_1
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokespecial <init> : (Ljava/lang/String;)V
    //   354: athrow
    //   355: iload #8
    //   357: ifne -> 367
    //   360: aload #4
    //   362: iconst_1
    //   363: putfield 堅 : Z
    //   366: return
    //   367: iload #14
    //   369: ifeq -> 388
    //   372: iconst_0
    //   373: istore #9
    //   375: iload #8
    //   377: istore #15
    //   379: iconst_0
    //   380: istore #10
    //   382: iconst_1
    //   383: istore #16
    //   385: goto -> 403
    //   388: iload #8
    //   390: iconst_1
    //   391: isub
    //   392: istore #9
    //   394: iconst_m1
    //   395: istore #15
    //   397: iconst_0
    //   398: istore #10
    //   400: iconst_m1
    //   401: istore #16
    //   403: iload #9
    //   405: iload #15
    //   407: if_icmpeq -> 473
    //   410: aload_0
    //   411: getfield 触 : [Landroid/view/View;
    //   414: iload #9
    //   416: aaload
    //   417: astore #19
    //   419: aload #19
    //   421: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   424: checkcast y/획
    //   427: astore #20
    //   429: aload_0
    //   430: aload #19
    //   432: invokestatic 泳 : (Landroid/view/View;)I
    //   435: aload_1
    //   436: aload_2
    //   437: invokevirtual 兵 : (ILy/we;Ly/bf;)I
    //   440: istore #17
    //   442: aload #20
    //   444: iload #17
    //   446: putfield 寒 : I
    //   449: aload #20
    //   451: iload #10
    //   453: putfield 冷 : I
    //   456: iload #10
    //   458: iload #17
    //   460: iadd
    //   461: istore #10
    //   463: iload #9
    //   465: iload #16
    //   467: iadd
    //   468: istore #9
    //   470: goto -> 403
    //   473: fconst_0
    //   474: fstore #5
    //   476: iconst_0
    //   477: istore #10
    //   479: iconst_0
    //   480: istore #9
    //   482: iload #10
    //   484: iload #8
    //   486: if_icmpge -> 681
    //   489: aload_0
    //   490: getfield 触 : [Landroid/view/View;
    //   493: iload #10
    //   495: aaload
    //   496: astore_1
    //   497: aload_3
    //   498: getfield ぱ : Ljava/util/List;
    //   501: ifnonnull -> 529
    //   504: iload #14
    //   506: ifeq -> 519
    //   509: aload_0
    //   510: iconst_m1
    //   511: aload_1
    //   512: iconst_0
    //   513: invokevirtual 堅 : (ILandroid/view/View;Z)V
    //   516: goto -> 551
    //   519: aload_0
    //   520: iconst_0
    //   521: aload_1
    //   522: iconst_0
    //   523: invokevirtual 堅 : (ILandroid/view/View;Z)V
    //   526: goto -> 551
    //   529: iload #14
    //   531: ifeq -> 544
    //   534: aload_0
    //   535: iconst_m1
    //   536: aload_1
    //   537: iconst_1
    //   538: invokevirtual 堅 : (ILandroid/view/View;Z)V
    //   541: goto -> 551
    //   544: aload_0
    //   545: iconst_0
    //   546: aload_1
    //   547: iconst_1
    //   548: invokevirtual 堅 : (ILandroid/view/View;Z)V
    //   551: aload_0
    //   552: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   555: astore_2
    //   556: aload_0
    //   557: getfield ち : Landroid/graphics/Rect;
    //   560: astore #19
    //   562: aload_2
    //   563: ifnonnull -> 578
    //   566: aload #19
    //   568: iconst_0
    //   569: iconst_0
    //   570: iconst_0
    //   571: iconst_0
    //   572: invokevirtual set : (IIII)V
    //   575: goto -> 588
    //   578: aload #19
    //   580: aload_2
    //   581: aload_1
    //   582: invokevirtual あ : (Landroid/view/View;)Landroid/graphics/Rect;
    //   585: invokevirtual set : (Landroid/graphics/Rect;)V
    //   588: aload_0
    //   589: iload #11
    //   591: aload_1
    //   592: iconst_0
    //   593: invokevirtual 建 : (ILandroid/view/View;Z)V
    //   596: aload_0
    //   597: getfield 恐 : Ly/k8;
    //   600: aload_1
    //   601: invokevirtual 熱 : (Landroid/view/View;)I
    //   604: istore #16
    //   606: iload #9
    //   608: istore #15
    //   610: iload #16
    //   612: iload #9
    //   614: if_icmple -> 621
    //   617: iload #16
    //   619: istore #15
    //   621: aload_1
    //   622: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   625: checkcast y/획
    //   628: astore_2
    //   629: aload_0
    //   630: getfield 恐 : Ly/k8;
    //   633: aload_1
    //   634: invokevirtual 嬉 : (Landroid/view/View;)I
    //   637: i2f
    //   638: fconst_1
    //   639: fmul
    //   640: aload_2
    //   641: getfield 寒 : I
    //   644: i2f
    //   645: fdiv
    //   646: fstore #7
    //   648: fload #5
    //   650: fstore #6
    //   652: fload #7
    //   654: fload #5
    //   656: fcmpl
    //   657: ifle -> 664
    //   660: fload #7
    //   662: fstore #6
    //   664: iload #10
    //   666: iconst_1
    //   667: iadd
    //   668: istore #10
    //   670: fload #6
    //   672: fstore #5
    //   674: iload #15
    //   676: istore #9
    //   678: goto -> 482
    //   681: iload #9
    //   683: istore #10
    //   685: iload #12
    //   687: ifeq -> 782
    //   690: aload_0
    //   691: fload #5
    //   693: aload_0
    //   694: getfield 寝 : I
    //   697: i2f
    //   698: fmul
    //   699: invokestatic round : (F)I
    //   702: iload #13
    //   704: invokestatic max : (II)I
    //   707: invokevirtual 警 : (I)V
    //   710: iconst_0
    //   711: istore #11
    //   713: iconst_0
    //   714: istore #9
    //   716: iload #9
    //   718: istore #10
    //   720: iload #11
    //   722: iload #8
    //   724: if_icmpge -> 782
    //   727: aload_0
    //   728: getfield 触 : [Landroid/view/View;
    //   731: iload #11
    //   733: aaload
    //   734: astore_1
    //   735: aload_0
    //   736: ldc_w 1073741824
    //   739: aload_1
    //   740: iconst_1
    //   741: invokevirtual 建 : (ILandroid/view/View;Z)V
    //   744: aload_0
    //   745: getfield 恐 : Ly/k8;
    //   748: aload_1
    //   749: invokevirtual 熱 : (Landroid/view/View;)I
    //   752: istore #12
    //   754: iload #9
    //   756: istore #10
    //   758: iload #12
    //   760: iload #9
    //   762: if_icmple -> 769
    //   765: iload #12
    //   767: istore #10
    //   769: iload #11
    //   771: iconst_1
    //   772: iadd
    //   773: istore #11
    //   775: iload #10
    //   777: istore #9
    //   779: goto -> 716
    //   782: iconst_0
    //   783: istore #9
    //   785: iload #9
    //   787: iload #8
    //   789: if_icmpge -> 997
    //   792: aload_0
    //   793: getfield 触 : [Landroid/view/View;
    //   796: iload #9
    //   798: aaload
    //   799: astore_1
    //   800: aload_0
    //   801: getfield 恐 : Ly/k8;
    //   804: aload_1
    //   805: invokevirtual 熱 : (Landroid/view/View;)I
    //   808: iload #10
    //   810: if_icmpeq -> 988
    //   813: aload_1
    //   814: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   817: checkcast y/획
    //   820: astore_2
    //   821: aload_2
    //   822: getfield 堅 : Landroid/graphics/Rect;
    //   825: astore #19
    //   827: aload #19
    //   829: getfield top : I
    //   832: aload #19
    //   834: getfield bottom : I
    //   837: iadd
    //   838: aload_2
    //   839: getfield topMargin : I
    //   842: iadd
    //   843: aload_2
    //   844: getfield bottomMargin : I
    //   847: iadd
    //   848: istore #12
    //   850: aload #19
    //   852: getfield left : I
    //   855: aload #19
    //   857: getfield right : I
    //   860: iadd
    //   861: aload_2
    //   862: getfield leftMargin : I
    //   865: iadd
    //   866: aload_2
    //   867: getfield rightMargin : I
    //   870: iadd
    //   871: istore #11
    //   873: aload_0
    //   874: aload_2
    //   875: getfield 冷 : I
    //   878: aload_2
    //   879: getfield 寒 : I
    //   882: invokevirtual 察 : (II)I
    //   885: istore #13
    //   887: aload_0
    //   888: getfield 淋 : I
    //   891: iconst_1
    //   892: if_icmpne -> 928
    //   895: iconst_0
    //   896: iload #13
    //   898: ldc_w 1073741824
    //   901: iload #11
    //   903: aload_2
    //   904: getfield width : I
    //   907: invokestatic 興 : (ZIIII)I
    //   910: istore #11
    //   912: iload #10
    //   914: iload #12
    //   916: isub
    //   917: ldc_w 1073741824
    //   920: invokestatic makeMeasureSpec : (II)I
    //   923: istore #12
    //   925: goto -> 958
    //   928: iload #10
    //   930: iload #11
    //   932: isub
    //   933: ldc_w 1073741824
    //   936: invokestatic makeMeasureSpec : (II)I
    //   939: istore #11
    //   941: iconst_0
    //   942: iload #13
    //   944: ldc_w 1073741824
    //   947: iload #12
    //   949: aload_2
    //   950: getfield height : I
    //   953: invokestatic 興 : (ZIIII)I
    //   956: istore #12
    //   958: aload_0
    //   959: aload_1
    //   960: iload #11
    //   962: iload #12
    //   964: aload_1
    //   965: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   968: checkcast y/qe
    //   971: invokevirtual た : (Landroid/view/View;IILy/qe;)Z
    //   974: ifeq -> 988
    //   977: aload_1
    //   978: iload #11
    //   980: iload #12
    //   982: invokevirtual measure : (II)V
    //   985: goto -> 988
    //   988: iload #9
    //   990: iconst_1
    //   991: iadd
    //   992: istore #9
    //   994: goto -> 785
    //   997: aload #4
    //   999: iload #10
    //   1001: putfield 硬 : I
    //   1004: aload_0
    //   1005: getfield 淋 : I
    //   1008: iconst_1
    //   1009: if_icmpne -> 1066
    //   1012: aload_3
    //   1013: getfield 寒 : I
    //   1016: iconst_m1
    //   1017: if_icmpne -> 1036
    //   1020: aload_3
    //   1021: getfield 堅 : I
    //   1024: istore #9
    //   1026: iload #9
    //   1028: iload #10
    //   1030: isub
    //   1031: istore #10
    //   1033: goto -> 1057
    //   1036: aload_3
    //   1037: getfield 堅 : I
    //   1040: istore #9
    //   1042: iload #9
    //   1044: iload #10
    //   1046: iadd
    //   1047: istore #11
    //   1049: iload #9
    //   1051: istore #10
    //   1053: iload #11
    //   1055: istore #9
    //   1057: iconst_0
    //   1058: istore #11
    //   1060: iconst_0
    //   1061: istore #12
    //   1063: goto -> 1117
    //   1066: aload_3
    //   1067: getfield 寒 : I
    //   1070: iconst_m1
    //   1071: if_icmpne -> 1094
    //   1074: aload_3
    //   1075: getfield 堅 : I
    //   1078: istore #9
    //   1080: iload #9
    //   1082: istore #11
    //   1084: iload #9
    //   1086: iload #10
    //   1088: isub
    //   1089: istore #12
    //   1091: goto -> 1111
    //   1094: aload_3
    //   1095: getfield 堅 : I
    //   1098: istore #9
    //   1100: iload #9
    //   1102: istore #12
    //   1104: iload #10
    //   1106: iload #9
    //   1108: iadd
    //   1109: istore #11
    //   1111: iconst_0
    //   1112: istore #10
    //   1114: iconst_0
    //   1115: istore #9
    //   1117: iconst_0
    //   1118: istore #13
    //   1120: iload #12
    //   1122: istore #15
    //   1124: iload #11
    //   1126: istore #14
    //   1128: iload #10
    //   1130: istore #11
    //   1132: iload #9
    //   1134: istore #12
    //   1136: iload #13
    //   1138: iload #8
    //   1140: if_icmpge -> 1360
    //   1143: aload_0
    //   1144: getfield 触 : [Landroid/view/View;
    //   1147: iload #13
    //   1149: aaload
    //   1150: astore_1
    //   1151: aload_1
    //   1152: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1155: checkcast y/획
    //   1158: astore_2
    //   1159: aload_0
    //   1160: getfield 淋 : I
    //   1163: iconst_1
    //   1164: if_icmpne -> 1251
    //   1167: aload_0
    //   1168: invokevirtual せ : ()Z
    //   1171: ifeq -> 1211
    //   1174: aload_0
    //   1175: invokevirtual 帰 : ()I
    //   1178: aload_0
    //   1179: getfield 噛 : [I
    //   1182: aload_0
    //   1183: getfield 寝 : I
    //   1186: aload_2
    //   1187: getfield 冷 : I
    //   1190: isub
    //   1191: iaload
    //   1192: iadd
    //   1193: istore #9
    //   1195: iload #9
    //   1197: aload_0
    //   1198: getfield 恐 : Ly/k8;
    //   1201: aload_1
    //   1202: invokevirtual 嬉 : (Landroid/view/View;)I
    //   1205: isub
    //   1206: istore #10
    //   1208: goto -> 1292
    //   1211: aload_0
    //   1212: invokevirtual 帰 : ()I
    //   1215: aload_0
    //   1216: getfield 噛 : [I
    //   1219: aload_2
    //   1220: getfield 冷 : I
    //   1223: iaload
    //   1224: iadd
    //   1225: istore #9
    //   1227: aload_0
    //   1228: getfield 恐 : Ly/k8;
    //   1231: aload_1
    //   1232: invokevirtual 嬉 : (Landroid/view/View;)I
    //   1235: istore #14
    //   1237: iload #9
    //   1239: istore #10
    //   1241: iload #14
    //   1243: iload #9
    //   1245: iadd
    //   1246: istore #9
    //   1248: goto -> 1292
    //   1251: aload_0
    //   1252: invokevirtual 歩 : ()I
    //   1255: istore #9
    //   1257: aload_0
    //   1258: getfield 噛 : [I
    //   1261: aload_2
    //   1262: getfield 冷 : I
    //   1265: iaload
    //   1266: iload #9
    //   1268: iadd
    //   1269: istore #11
    //   1271: aload_0
    //   1272: getfield 恐 : Ly/k8;
    //   1275: aload_1
    //   1276: invokevirtual 嬉 : (Landroid/view/View;)I
    //   1279: iload #11
    //   1281: iadd
    //   1282: istore #12
    //   1284: iload #15
    //   1286: istore #10
    //   1288: iload #14
    //   1290: istore #9
    //   1292: aload_1
    //   1293: iload #10
    //   1295: iload #11
    //   1297: iload #9
    //   1299: iload #12
    //   1301: invokestatic あ : (Landroid/view/View;IIII)V
    //   1304: aload_2
    //   1305: invokevirtual 熱 : ()Z
    //   1308: ifne -> 1318
    //   1311: aload_2
    //   1312: invokevirtual 堅 : ()Z
    //   1315: ifeq -> 1324
    //   1318: aload #4
    //   1320: iconst_1
    //   1321: putfield 熱 : Z
    //   1324: aload #4
    //   1326: getfield 暑 : Z
    //   1329: istore #18
    //   1331: aload #4
    //   1333: aload_1
    //   1334: invokevirtual hasFocusable : ()Z
    //   1337: iload #18
    //   1339: ior
    //   1340: putfield 暑 : Z
    //   1343: iload #13
    //   1345: iconst_1
    //   1346: iadd
    //   1347: istore #13
    //   1349: iload #9
    //   1351: istore #14
    //   1353: iload #10
    //   1355: istore #15
    //   1357: goto -> 1136
    //   1360: aload_0
    //   1361: getfield 触 : [Landroid/view/View;
    //   1364: aconst_null
    //   1365: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   1368: return
  }
  
  public final void 治(we paramwe, bf parambf, 骨 param骨, int paramInt) {
    先();
    if (parambf.堅() > 0 && !parambf.美) {
      if (paramInt == 1) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      int i = へ(param骨.堅, paramwe, parambf);
      if (paramInt != 0) {
        while (i > 0) {
          paramInt = param骨.堅;
          if (paramInt > 0) {
            param骨.堅 = --paramInt;
            i = へ(paramInt, paramwe, parambf);
          } 
        } 
      } else {
        int j = parambf.堅();
        paramInt = param骨.堅;
        while (paramInt < j - 1) {
          int m = paramInt + 1;
          int k = へ(m, paramwe, parambf);
          if (k > i) {
            paramInt = m;
            i = k;
          } 
        } 
        param骨.堅 = paramInt;
      } 
    } 
    View[] arrayOfView = this.触;
    if (arrayOfView == null || arrayOfView.length != this.寝)
      this.触 = new View[this.寝]; 
  }
  
  public final int 産(we paramwe, bf parambf) {
    return (this.淋 == 1) ? this.寝 : ((parambf.堅() < 1) ? 0 : (官(parambf.堅() - 1, paramwe, parambf) + 1));
  }
  
  public final qe 痒(ViewGroup.LayoutParams paramLayoutParams) {
    return (qe)((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new 획((ViewGroup.MarginLayoutParams)paramLayoutParams) : new 획(paramLayoutParams));
  }
  
  public final qe 痛(Context paramContext, AttributeSet paramAttributeSet) {
    return (qe)new 획(paramContext, paramAttributeSet);
  }
  
  public final void 築(int paramInt) {
    if (paramInt == this.寝)
      return; 
    this.踊 = true;
    if (paramInt >= 1) {
      this.寝 = paramInt;
      this.か.冷();
      탱();
      return;
    } 
    throw new IllegalArgumentException(bm.熱("Span count should be at least 1. Provided ", paramInt));
  }
  
  public final void 若(we paramwe, bf parambf, View paramView, コ paramコ) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof 획)) {
      も(paramView, paramコ);
      return;
    } 
    획 획 = (획)layoutParams;
    int i = 官(획.硬(), paramwe, parambf);
    if (this.淋 == 0) {
      paramコ.旨(賊.起(획.冷, 획.寒, i, 1, false));
      return;
    } 
    paramコ.旨(賊.起(i, 1, 획.冷, 획.寒, false));
  }
  
  public final int 苦(bf parambf) {
    return ょ(parambf);
  }
  
  public final void 警(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 噛 : [I
    //   4: astore #9
    //   6: aload_0
    //   7: getfield 寝 : I
    //   10: istore #6
    //   12: iconst_1
    //   13: istore_3
    //   14: aload #9
    //   16: ifnull -> 45
    //   19: aload #9
    //   21: arraylength
    //   22: iload #6
    //   24: iconst_1
    //   25: iadd
    //   26: if_icmpne -> 45
    //   29: aload #9
    //   31: astore #8
    //   33: aload #9
    //   35: aload #9
    //   37: arraylength
    //   38: iconst_1
    //   39: isub
    //   40: iaload
    //   41: iload_1
    //   42: if_icmpeq -> 53
    //   45: iload #6
    //   47: iconst_1
    //   48: iadd
    //   49: newarray int
    //   51: astore #8
    //   53: iconst_0
    //   54: istore #4
    //   56: aload #8
    //   58: iconst_0
    //   59: iconst_0
    //   60: iastore
    //   61: iload_1
    //   62: iload #6
    //   64: idiv
    //   65: istore #5
    //   67: iload_1
    //   68: iload #6
    //   70: irem
    //   71: istore #7
    //   73: iconst_0
    //   74: istore_2
    //   75: iload #4
    //   77: istore_1
    //   78: iload_3
    //   79: iload #6
    //   81: if_icmpgt -> 137
    //   84: iload_1
    //   85: iload #7
    //   87: iadd
    //   88: istore_1
    //   89: iload_1
    //   90: ifle -> 116
    //   93: iload #6
    //   95: iload_1
    //   96: isub
    //   97: iload #7
    //   99: if_icmpge -> 116
    //   102: iload #5
    //   104: iconst_1
    //   105: iadd
    //   106: istore #4
    //   108: iload_1
    //   109: iload #6
    //   111: isub
    //   112: istore_1
    //   113: goto -> 120
    //   116: iload #5
    //   118: istore #4
    //   120: iload_2
    //   121: iload #4
    //   123: iadd
    //   124: istore_2
    //   125: aload #8
    //   127: iload_3
    //   128: iload_2
    //   129: iastore
    //   130: iload_3
    //   131: iconst_1
    //   132: iadd
    //   133: istore_3
    //   134: goto -> 78
    //   137: aload_0
    //   138: aload #8
    //   140: putfield 噛 : [I
    //   143: return
  }
  
  public final View 赤(View paramView, int paramInt, we paramwe, bf parambf) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   4: astore #20
    //   6: aconst_null
    //   7: astore #21
    //   9: aload #20
    //   11: ifnonnull -> 20
    //   14: aconst_null
    //   15: astore #20
    //   17: goto -> 55
    //   20: aload #20
    //   22: aload_1
    //   23: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   26: astore #22
    //   28: aload #22
    //   30: ifnonnull -> 36
    //   33: goto -> 14
    //   36: aload #22
    //   38: astore #20
    //   40: aload_0
    //   41: getfield 硬 : Ly/話;
    //   44: aload #22
    //   46: invokevirtual 辛 : (Landroid/view/View;)Z
    //   49: ifeq -> 55
    //   52: goto -> 33
    //   55: aload #20
    //   57: ifnonnull -> 62
    //   60: aconst_null
    //   61: areturn
    //   62: aload #20
    //   64: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   67: checkcast y/획
    //   70: astore #22
    //   72: aload #22
    //   74: getfield 冷 : I
    //   77: istore #14
    //   79: aload #22
    //   81: getfield 寒 : I
    //   84: iload #14
    //   86: iadd
    //   87: istore #15
    //   89: aload_0
    //   90: aload_1
    //   91: iload_2
    //   92: aload_3
    //   93: aload #4
    //   95: invokespecial 赤 : (Landroid/view/View;ILy/we;Ly/bf;)Landroid/view/View;
    //   98: ifnonnull -> 103
    //   101: aconst_null
    //   102: areturn
    //   103: aload_0
    //   104: iload_2
    //   105: invokevirtual う : (I)I
    //   108: iconst_1
    //   109: if_icmpne -> 118
    //   112: iconst_1
    //   113: istore #19
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #19
    //   121: iload #19
    //   123: aload_0
    //   124: getfield 臭 : Z
    //   127: if_icmpeq -> 135
    //   130: iconst_1
    //   131: istore_2
    //   132: goto -> 137
    //   135: iconst_0
    //   136: istore_2
    //   137: iload_2
    //   138: ifeq -> 157
    //   141: aload_0
    //   142: invokevirtual 起 : ()I
    //   145: iconst_1
    //   146: isub
    //   147: istore #5
    //   149: iconst_m1
    //   150: istore_2
    //   151: iconst_m1
    //   152: istore #6
    //   154: goto -> 168
    //   157: aload_0
    //   158: invokevirtual 起 : ()I
    //   161: istore_2
    //   162: iconst_0
    //   163: istore #5
    //   165: iconst_1
    //   166: istore #6
    //   168: aload_0
    //   169: getfield 淋 : I
    //   172: iconst_1
    //   173: if_icmpne -> 189
    //   176: aload_0
    //   177: invokevirtual せ : ()Z
    //   180: ifeq -> 189
    //   183: iconst_1
    //   184: istore #7
    //   186: goto -> 192
    //   189: iconst_0
    //   190: istore #7
    //   192: aload_0
    //   193: iload #5
    //   195: aload_3
    //   196: aload #4
    //   198: invokevirtual 官 : (ILy/we;Ly/bf;)I
    //   201: istore #16
    //   203: iconst_m1
    //   204: istore #12
    //   206: iconst_0
    //   207: istore #13
    //   209: iconst_0
    //   210: istore #11
    //   212: iconst_m1
    //   213: istore #10
    //   215: aconst_null
    //   216: astore_1
    //   217: iload_2
    //   218: istore #8
    //   220: iload #5
    //   222: istore #9
    //   224: iload #13
    //   226: istore_2
    //   227: iload #9
    //   229: iload #8
    //   231: if_icmpeq -> 619
    //   234: aload_0
    //   235: iload #9
    //   237: aload_3
    //   238: aload #4
    //   240: invokevirtual 官 : (ILy/we;Ly/bf;)I
    //   243: istore #5
    //   245: aload_0
    //   246: iload #9
    //   248: invokevirtual 臭 : (I)Landroid/view/View;
    //   251: astore #22
    //   253: aload #22
    //   255: aload #20
    //   257: if_acmpne -> 263
    //   260: goto -> 619
    //   263: aload #22
    //   265: invokevirtual hasFocusable : ()Z
    //   268: ifeq -> 289
    //   271: iload #5
    //   273: iload #16
    //   275: if_icmpeq -> 289
    //   278: aload #21
    //   280: ifnull -> 286
    //   283: goto -> 619
    //   286: goto -> 609
    //   289: aload #22
    //   291: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   294: checkcast y/획
    //   297: astore #23
    //   299: aload #23
    //   301: getfield 冷 : I
    //   304: istore #13
    //   306: aload #23
    //   308: getfield 寒 : I
    //   311: iload #13
    //   313: iadd
    //   314: istore #17
    //   316: aload #22
    //   318: invokevirtual hasFocusable : ()Z
    //   321: ifeq -> 341
    //   324: iload #13
    //   326: iload #14
    //   328: if_icmpne -> 341
    //   331: iload #17
    //   333: iload #15
    //   335: if_icmpne -> 341
    //   338: aload #22
    //   340: areturn
    //   341: aload #22
    //   343: invokevirtual hasFocusable : ()Z
    //   346: ifeq -> 354
    //   349: aload #21
    //   351: ifnull -> 366
    //   354: aload #22
    //   356: invokevirtual hasFocusable : ()Z
    //   359: ifne -> 369
    //   362: aload_1
    //   363: ifnonnull -> 369
    //   366: goto -> 436
    //   369: iload #13
    //   371: iload #14
    //   373: invokestatic max : (II)I
    //   376: istore #5
    //   378: iload #17
    //   380: iload #15
    //   382: invokestatic min : (II)I
    //   385: iload #5
    //   387: isub
    //   388: istore #18
    //   390: aload #22
    //   392: invokevirtual hasFocusable : ()Z
    //   395: ifeq -> 442
    //   398: iload #18
    //   400: iload_2
    //   401: if_icmple -> 407
    //   404: goto -> 436
    //   407: iload #18
    //   409: iload_2
    //   410: if_icmpne -> 533
    //   413: iload #13
    //   415: iload #10
    //   417: if_icmple -> 426
    //   420: iconst_1
    //   421: istore #5
    //   423: goto -> 429
    //   426: iconst_0
    //   427: istore #5
    //   429: iload #7
    //   431: iload #5
    //   433: if_icmpne -> 533
    //   436: iconst_1
    //   437: istore #5
    //   439: goto -> 536
    //   442: aload #21
    //   444: ifnonnull -> 533
    //   447: aload_0
    //   448: getfield 熱 : Ly/ex;
    //   451: aload #22
    //   453: invokevirtual 旨 : (Landroid/view/View;)Z
    //   456: ifeq -> 477
    //   459: aload_0
    //   460: getfield 暑 : Ly/ex;
    //   463: aload #22
    //   465: invokevirtual 旨 : (Landroid/view/View;)Z
    //   468: ifeq -> 477
    //   471: iconst_1
    //   472: istore #5
    //   474: goto -> 480
    //   477: iconst_0
    //   478: istore #5
    //   480: iload #5
    //   482: iconst_1
    //   483: ixor
    //   484: ifeq -> 533
    //   487: iload #18
    //   489: iload #11
    //   491: if_icmple -> 497
    //   494: goto -> 527
    //   497: iload #18
    //   499: iload #11
    //   501: if_icmpne -> 533
    //   504: iload #13
    //   506: iload #12
    //   508: if_icmple -> 517
    //   511: iconst_1
    //   512: istore #5
    //   514: goto -> 520
    //   517: iconst_0
    //   518: istore #5
    //   520: iload #7
    //   522: iload #5
    //   524: if_icmpne -> 533
    //   527: iconst_1
    //   528: istore #5
    //   530: goto -> 536
    //   533: iconst_0
    //   534: istore #5
    //   536: iload #5
    //   538: ifeq -> 609
    //   541: aload #22
    //   543: invokevirtual hasFocusable : ()Z
    //   546: ifeq -> 579
    //   549: aload #23
    //   551: getfield 冷 : I
    //   554: istore #10
    //   556: iload #17
    //   558: iload #15
    //   560: invokestatic min : (II)I
    //   563: iload #13
    //   565: iload #14
    //   567: invokestatic max : (II)I
    //   570: isub
    //   571: istore_2
    //   572: aload #22
    //   574: astore #21
    //   576: goto -> 609
    //   579: aload #23
    //   581: getfield 冷 : I
    //   584: istore #12
    //   586: iload #17
    //   588: iload #15
    //   590: invokestatic min : (II)I
    //   593: iload #13
    //   595: iload #14
    //   597: invokestatic max : (II)I
    //   600: isub
    //   601: istore #11
    //   603: aload #22
    //   605: astore_1
    //   606: goto -> 609
    //   609: iload #9
    //   611: iload #6
    //   613: iadd
    //   614: istore #9
    //   616: goto -> 227
    //   619: aload #21
    //   621: ifnull -> 627
    //   624: aload #21
    //   626: areturn
    //   627: aload_1
    //   628: areturn
  }
  
  public final void 防(boolean paramBoolean) {
    if (!paramBoolean) {
      super.防(false);
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public final void 코(int paramInt1, int paramInt2) {
    as as1 = this.か;
    as1.冷();
    ((SparseIntArray)as1.暑).clear();
  }
  
  public final void 쾌() {
    as as1 = this.か;
    as1.冷();
    ((SparseIntArray)as1.暑).clear();
  }
  
  public final void 크(int paramInt1, int paramInt2) {
    as as1 = this.か;
    as1.冷();
    ((SparseIntArray)as1.暑).clear();
  }
  
  public final void 큰(int paramInt1, int paramInt2) {
    as as1 = this.か;
    as1.冷();
    ((SparseIntArray)as1.暑).clear();
  }
  
  public final void 키(int paramInt1, int paramInt2) {
    as as1 = this.か;
    as1.冷();
    ((SparseIntArray)as1.暑).clear();
  }
  
  public final void 타(bf parambf) {
    super.타(parambf);
    this.踊 = false;
  }
  
  public final int 터(int paramInt, we paramwe, bf parambf) {
    先();
    View[] arrayOfView = this.触;
    if (arrayOfView == null || arrayOfView.length != this.寝)
      this.触 = new View[this.寝]; 
    return super.터(paramInt, paramwe, parambf);
  }
  
  public final int 토(int paramInt, we paramwe, bf parambf) {
    先();
    View[] arrayOfView = this.触;
    if (arrayOfView == null || arrayOfView.length != this.寝)
      this.触 = new View[this.寝]; 
    return super.토(paramInt, paramwe, parambf);
  }
  
  public final void 통(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.噛 == null)
      super.통(paramRect, paramInt1, paramInt2); 
    int i = 帰();
    i = 返() + i;
    int j = 歩();
    j = 壊() + j;
    if (this.淋 == 1) {
      int k = paramRect.height();
      RecyclerView recyclerView = this.堅;
      WeakHashMap weakHashMap = rw.硬;
      int m = Build.VERSION.SDK_INT;
      paramInt2 = pe.美(paramInt2, k + j, aw.暑((View)recyclerView));
      arrayOfInt = this.噛;
      i = pe.美(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, aw.冷((View)this.堅));
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      int k = arrayOfInt.width();
      RecyclerView recyclerView = this.堅;
      WeakHashMap weakHashMap = rw.硬;
      int m = Build.VERSION.SDK_INT;
      paramInt1 = pe.美(paramInt1, k + i, aw.冷((View)recyclerView));
      int[] arrayOfInt1 = this.噛;
      i = pe.美(paramInt2, arrayOfInt1[arrayOfInt1.length - 1] + j, aw.暑((View)this.堅));
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.冷(this.堅, paramInt2, paramInt1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\recyclerview\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */