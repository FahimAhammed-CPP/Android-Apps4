package androidx.lifecycle;

import y.mx;
import y.t6;
import y.ぞ;
import y.叔;
import y.尻;
import y.心;
import y.肉;
import y.腰;
import y.銅;

class LiveData$LifecycleBoundObserver extends 叔 implements 肉 {
  public final 腰 痒;
  
  public LiveData$LifecycleBoundObserver(for paramfor, 銅 param銅, mx parammx) {
    super(paramfor, (t6)parammx);
    this.痒 = (腰)param銅;
  }
  
  public final void 寒() {
    this.痒.痒().興((心)this);
  }
  
  public final boolean 旨() {
    return (this.痒.痒()).興.硬(ぞ.痛);
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    叔 叔1;
    腰 腰1 = this.痒;
    ぞ ぞ = (腰1.痒()).興;
    if (ぞ == ぞ.淋) {
      for for1 = this.臭;
      for1.getClass();
      for.硬("removeObserver");
      叔1 = (叔)for1.堅.美(this.淋);
      if (叔1 == null)
        return; 
      叔1.寒();
      叔1.熱(false);
      return;
    } 
    param尻 = null;
    while (param尻 != 叔1) {
      熱(旨());
      ぞ ぞ2 = (腰1.痒()).興;
      叔 叔2 = 叔1;
      ぞ ぞ1 = ぞ2;
    } 
  }
  
  public final boolean 美(銅 param銅) {
    return (this.痒 == param銅);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\LiveData$LifecycleBoundObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */