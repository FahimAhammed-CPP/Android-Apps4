package androidx.lifecycle;

import java.util.HashMap;
import y.尻;
import y.肉;
import y.腰;
import y.핍;

class CompositeGeneratedAdaptersObserver implements 肉 {
  public final 핍[] 淋;
  
  public CompositeGeneratedAdaptersObserver(핍[] paramArrayOf핍) {
    this.淋 = paramArrayOf핍;
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    new HashMap<Object, Object>();
    핍[] arrayOf핍 = this.淋;
    if (arrayOf핍.length <= 0) {
      if (arrayOf핍.length <= 0)
        return; 
      핍1 = arrayOf핍[0];
      throw null;
    } 
    핍 핍1 = 핍1[0];
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */