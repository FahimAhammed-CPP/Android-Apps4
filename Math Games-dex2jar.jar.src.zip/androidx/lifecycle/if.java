package androidx.lifecycle;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import y.ぞ;
import y.尻;
import y.心;
import y.肉;
import y.腰;
import y.血;
import y.녁;
import y.핍;

public final class if {
  public final 肉 堅;
  
  public ぞ 硬;
  
  public if(心 param心, ぞ paramぞ) {
    FullLifecycleObserverAdapter fullLifecycleObserverAdapter;
    ReflectiveGenericLifecycleObserver reflectiveGenericLifecycleObserver;
    HashMap hashMap = 血.硬;
    boolean bool1 = param心 instanceof 肉;
    boolean bool2 = param心 instanceof 녁;
    if (bool1 && bool2) {
      fullLifecycleObserverAdapter = new FullLifecycleObserverAdapter((녁)param心, (肉)param心);
    } else if (bool2) {
      fullLifecycleObserverAdapter = new FullLifecycleObserverAdapter((녁)fullLifecycleObserverAdapter, null);
    } else if (bool1) {
      fullLifecycleObserverAdapter = fullLifecycleObserverAdapter;
    } else {
      CompositeGeneratedAdaptersObserver compositeGeneratedAdaptersObserver;
      Class<?> clazz = fullLifecycleObserverAdapter.getClass();
      if (血.熱(clazz) == 2) {
        SingleGeneratedAdapterObserver singleGeneratedAdapterObserver;
        List<Constructor> list = (List)血.堅.get(clazz);
        int j = list.size();
        int i = 0;
        if (j == 1) {
          血.硬(list.get(0), fullLifecycleObserverAdapter);
          singleGeneratedAdapterObserver = new SingleGeneratedAdapterObserver();
        } else {
          핍[] arrayOf핍 = new 핍[list.size()];
          while (i < list.size()) {
            血.硬(list.get(i), singleGeneratedAdapterObserver);
            arrayOf핍[i] = null;
            i++;
          } 
          compositeGeneratedAdaptersObserver = new CompositeGeneratedAdaptersObserver(arrayOf핍);
        } 
      } else {
        reflectiveGenericLifecycleObserver = new ReflectiveGenericLifecycleObserver(compositeGeneratedAdaptersObserver);
      } 
    } 
    this.堅 = reflectiveGenericLifecycleObserver;
    this.硬 = paramぞ;
  }
  
  public final void 硬(腰 param腰, 尻 param尻) {
    ぞ<ぞ> ぞ2 = param尻.硬();
    ぞ<ぞ> ぞ3 = this.硬;
    ぞ<ぞ> ぞ1 = ぞ3;
    if (ぞ2.compareTo(ぞ3) < 0)
      ぞ1 = ぞ2; 
    this.硬 = ぞ1;
    this.堅.暑(param腰, param尻);
    this.硬 = ぞ2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */