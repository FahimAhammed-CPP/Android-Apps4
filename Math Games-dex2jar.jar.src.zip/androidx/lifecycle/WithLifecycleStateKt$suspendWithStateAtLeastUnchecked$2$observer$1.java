package androidx.lifecycle;

import y.尻;
import y.肉;
import y.腰;

public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements 肉 {
  public final void 暑(腰 param腰, 尻 param尻) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */