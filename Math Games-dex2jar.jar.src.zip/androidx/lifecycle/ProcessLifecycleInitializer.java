package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.Collections;
import java.util.List;
import y.da;
import y.し;
import y.尻;
import y.筋;
import y.臓;
import y.駅;

public final class ProcessLifecycleInitializer implements し {
  public final Object 堅(Context paramContext) {
    if ((駅.熱(paramContext)).堅.contains(ProcessLifecycleInitializer.class)) {
      if (!筋.硬.getAndSet(true))
        ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new 臓()); 
      da da = da.産;
      da.getClass();
      da.痒 = new Handler();
      da.臭.消(尻.ON_CREATE);
      ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new try(da));
      return da;
    } 
    throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily. \nPlease ensure that you have: \n<meta-data\n    android:name='androidx.lifecycle.ProcessLifecycleInitializer' \n    android:value='androidx.startup' /> \nunder InitializationProvider in your AndroidManifest.xml");
  }
  
  public final List 硬() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */