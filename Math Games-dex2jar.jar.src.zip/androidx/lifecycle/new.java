package androidx.lifecycle;

import android.app.Activity;
import y.da;
import y.尻;
import y.못;

public final class new extends 못 {
  public void onActivityPostResumed(Activity paramActivity) {
    this.this$1.this$0.堅();
  }
  
  public void onActivityPostStarted(Activity paramActivity) {
    da da = this.this$1.this$0;
    int i = da.淋 + 1;
    da.淋 = i;
    if (i == 1 && da.痛) {
      da.臭.消(尻.ON_START);
      da.痛 = false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\new.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */