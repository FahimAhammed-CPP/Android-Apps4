package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import y.bm;
import y.ew;
import y.qe1;
import y.rw;
import y.zz;
import y.頼;
import y.싱;
import y.싸;
import y.쌍;
import y.암;
import y.애;
import y.앵;

public final class FragmentContainerView extends FrameLayout {
  public final ArrayList 怖 = new ArrayList();
  
  public View.OnApplyWindowInsetsListener 恐;
  
  public final ArrayList 淋 = new ArrayList();
  
  public boolean 痛 = true;
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    if (paramAttributeSet != null) {
      String str1;
      String str2;
      String str3 = paramAttributeSet.getClassAttribute();
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, qe1.怖, 0, 0);
      if (str3 == null) {
        str1 = typedArray.getString(0);
        str2 = "android:name";
      } else {
        str2 = "class";
        str1 = str3;
      } 
      typedArray.recycle();
      if (str1 != null) {
        if (isInEditMode())
          return; 
        StringBuilder stringBuilder = new StringBuilder("FragmentContainerView must be within a FragmentActivity to use ");
        stringBuilder.append(str2);
        stringBuilder.append("=\"");
        stringBuilder.append(str1);
        stringBuilder.append('"');
        throw new UnsupportedOperationException(stringBuilder.toString());
      } 
    } 
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, 앵 param앵) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, qe1.怖, 0, 0);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    str2 = typedArray.getString(1);
    typedArray.recycle();
    int i = getId();
    싱 싱 = param앵.歩(i);
    if (str1 != null && 싱 == null) {
      String str;
      Activity activity;
      if (i == -1) {
        if (str2 != null) {
          str = " with tag ".concat(str2);
        } else {
          str = "";
        } 
        throw new IllegalStateException(bm.痛("FragmentContainerView must have an android:id to add Fragment ", str1, str));
      } 
      암 암 = param앵.踊();
      str.getClassLoader();
      싱 싱1 = 암.硬(str1);
      싱1.코 = true;
      싸 싸 = 싱1.触;
      if (싸 == null) {
        싸 = null;
      } else {
        activity = 싸.크;
      } 
      if (activity != null)
        싱1.코 = true; 
      頼 頼 = new 頼(param앵);
      頼.寂 = true;
      싱1.쾌 = (ViewGroup)this;
      頼.冷(getId(), 싱1, str2, 1);
      if (!頼.美) {
        頼.淋.壊((애)頼, true);
      } else {
        throw new IllegalStateException("This transaction is already being added to the back stack");
      } 
    } 
    for (do do : param앵.熱.嬉()) {
      싱 싱1 = do.熱;
      if (싱1.ち == getId()) {
        View view = 싱1.크;
        if (view != null && view.getParent() == null) {
          싱1.쾌 = (ViewGroup)this;
          do.堅();
        } 
      } 
    } 
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    Object object = paramView.getTag(2131231074);
    if (object instanceof 싱) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public final WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    zz zz1;
    zz zz2 = zz.美(paramWindowInsets, null);
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.恐;
    if (onApplyWindowInsetsListener != null) {
      zz1 = zz.美(onApplyWindowInsetsListener.onApplyWindowInsets((View)this, paramWindowInsets), null);
    } else {
      WeakHashMap weakHashMap = rw.硬;
      int i = Build.VERSION.SDK_INT;
      WindowInsets windowInsets = zz2.寒();
      zz1 = zz2;
      if (windowInsets != null) {
        WindowInsets windowInsets1 = ew.堅((View)this, windowInsets);
        zz1 = zz2;
        if (!windowInsets1.equals(windowInsets))
          zz1 = zz.美(windowInsets1, (View)this); 
      } 
    } 
    if (!zz1.硬.嬉()) {
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        View view = getChildAt(i);
        WeakHashMap weakHashMap = rw.硬;
        int k = Build.VERSION.SDK_INT;
        WindowInsets windowInsets = zz1.寒();
        if (windowInsets != null) {
          WindowInsets windowInsets1 = ew.硬(view, windowInsets);
          if (!windowInsets1.equals(windowInsets))
            zz.美(windowInsets1, view); 
        } 
      } 
    } 
    return paramWindowInsets;
  }
  
  public final void dispatchDraw(Canvas paramCanvas) {
    if (this.痛) {
      Iterator<View> iterator = this.淋.iterator();
      while (iterator.hasNext())
        super.drawChild(paramCanvas, iterator.next(), getDrawingTime()); 
    } 
    super.dispatchDraw(paramCanvas);
  }
  
  public final boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.痛) {
      ArrayList arrayList = this.淋;
      if ((arrayList.isEmpty() ^ true) != 0 && arrayList.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public final void endViewTransition(View paramView) {
    this.怖.remove(paramView);
    if (this.淋.remove(paramView))
      this.痛 = true; 
    super.endViewTransition(paramView);
  }
  
  public final <F extends 싱> F getFragment() {
    StringBuilder stringBuilder;
    싱 싱1;
    싱 싱2;
    FragmentContainerView fragmentContainerView = this;
    while (true) {
      싱2 = null;
      if (fragmentContainerView != null) {
        Object object = fragmentContainerView.getTag(2131231074);
        if (object instanceof 싱) {
          object = object;
        } else {
          object = null;
        } 
        if (object != null)
          break; 
        ViewParent viewParent = fragmentContainerView.getParent();
        if (viewParent instanceof View) {
          View view = (View)viewParent;
          continue;
        } 
        viewParent = null;
        continue;
      } 
      싱1 = null;
      break;
    } 
    if (싱1 != null) {
      boolean bool;
      if (싱1.触 != null && 싱1.壊) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        앵 앵 = 싱1.寒();
      } else {
        stringBuilder = new StringBuilder("The Fragment ");
        stringBuilder.append(싱1);
        stringBuilder.append(" that owns View ");
        stringBuilder.append(this);
        stringBuilder.append(" has already been destroyed. Nested fragments should always use the child FragmentManager.");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      쌍 쌍;
      Context context = getContext();
      while (true) {
        싱1 = 싱2;
        if (context instanceof ContextWrapper) {
          if (context instanceof 쌍) {
            쌍 = (쌍)context;
            break;
          } 
          context = ((ContextWrapper)context).getBaseContext();
          continue;
        } 
        break;
      } 
      if (쌍 != null) {
        앵 앵 = ((싸)쌍.踊.淋).ㅌ;
        return (F)앵.歩(getId());
      } 
      stringBuilder = new StringBuilder("View ");
      stringBuilder.append(this);
      stringBuilder.append(" is not within a subclass of FragmentActivity.");
      throw new IllegalStateException(stringBuilder.toString());
    } 
    return (F)stringBuilder.歩(getId());
  }
  
  public final WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    return paramWindowInsets;
  }
  
  public final void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; -1 < i; i--)
      硬(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  public final void removeView(View paramView) {
    硬(paramView);
    super.removeView(paramView);
  }
  
  public final void removeViewAt(int paramInt) {
    硬(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public final void removeViewInLayout(View paramView) {
    硬(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public final void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      硬(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public final void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      硬(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public final void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.痛 = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    int i = Build.VERSION.SDK_INT;
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    this.恐 = paramOnApplyWindowInsetsListener;
  }
  
  public final void startViewTransition(View paramView) {
    if (paramView.getParent() == this)
      this.怖.add(paramView); 
    super.startViewTransition(paramView);
  }
  
  public final void 硬(View paramView) {
    if (this.怖.contains(paramView))
      this.淋.add(paramView); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\fragment\app\FragmentContainerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */