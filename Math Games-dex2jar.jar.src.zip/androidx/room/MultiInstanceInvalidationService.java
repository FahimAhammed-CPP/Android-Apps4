package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.LinkedHashMap;
import y.t4;
import y.u4;

public final class MultiInstanceInvalidationService extends Service {
  public final LinkedHashMap 怖 = new LinkedHashMap<Object, Object>();
  
  public final u4 恐 = new u4(this);
  
  public int 淋;
  
  public final t4 痛 = new t4(this);
  
  public final IBinder onBind(Intent paramIntent) {
    return (IBinder)this.痛;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */