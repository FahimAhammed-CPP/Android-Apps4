package androidx.startup;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Trace;
import y.駅;
import y.꽃;
import y.싶;

public class InitializationProvider extends ContentProvider {
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final boolean onCreate() {
    Context context = getContext();
    if (context != null) {
      if (context.getApplicationContext() != null) {
        駅 駅 = 駅.熱(context);
        Context context1 = 駅.熱;
        try {
          int i = Build.VERSION.SDK_INT;
          Trace.beginSection("Startup");
          ComponentName componentName = new ComponentName(context1.getPackageName(), InitializationProvider.class.getName());
          駅.硬((context1.getPackageManager().getProviderInfo(componentName, 128)).metaData);
          꽃.起();
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          throw new 싶(nameNotFoundException);
        } finally {}
      } 
      return true;
    } 
    throw new 싶("Context cannot be null", 0);
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */