package androidx.emoji2.text;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import y.p31;
import y.心;
import y.녁;
import y.망;
import y.즐;

class EmojiCompatInitializer$1 implements 녁 {
  public EmojiCompatInitializer$1(EmojiCompatInitializer paramEmojiCompatInitializer, p31 paramp31) {}
  
  public final void onResume() {
    Handler handler;
    this.怖.getClass();
    if (Build.VERSION.SDK_INT >= 28) {
      handler = 즐.硬(Looper.getMainLooper());
    } else {
      handler = new Handler(Looper.getMainLooper());
    } 
    handler.postDelayed((Runnable)new 망(), 500L);
    this.淋.興((心)this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */