package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.util.WeakHashMap;
import y.g5;
import y.gw;
import y.h5;
import y.i5;
import y.j5;
import y.k5;
import y.m5;
import y.n5;
import y.nul;
import y.p31;
import y.rw;
import y.茎;
import y.醤;
import y.르;

public class NestedScrollView extends FrameLayout implements m5 {
  public static final float 若 = (float)(Math.log(0.78D) / Math.log(0.9D));
  
  public static final g5 코 = new g5();
  
  public static final int[] 쾌 = new int[] { 16843130 };
  
  public int あ;
  
  public int か;
  
  public j5 ち;
  
  public i5 も;
  
  public final n5 ゃ;
  
  public float わ;
  
  public int 噛;
  
  public boolean 壊;
  
  public int 寝;
  
  public VelocityTracker 帰;
  
  public long 怖;
  
  public final Rect 恐;
  
  public final int[] 投;
  
  public boolean 歩;
  
  public View 死;
  
  public int 泳;
  
  public final float 淋;
  
  public boolean 産;
  
  public final EdgeEffect 痒;
  
  public OverScroller 痛;
  
  public final EdgeEffect 臭;
  
  public boolean 興;
  
  public final int[] 触;
  
  public final k5 赤;
  
  public int 起;
  
  public int 踊;
  
  public boolean 返;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903795);
    EdgeEffect edgeEffect;
    this.恐 = new Rect();
    this.興 = true;
    this.産 = false;
    this.死 = null;
    this.壊 = false;
    this.歩 = true;
    this.噛 = -1;
    this.触 = new int[2];
    this.投 = new int[2];
    int i = Build.VERSION.SDK_INT;
    if (i >= 31) {
      edgeEffect = 르.硬(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.痒 = edgeEffect;
    if (i >= 31) {
      edgeEffect = 르.硬(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.臭 = edgeEffect;
    this.淋 = (paramContext.getResources().getDisplayMetrics()).density * 160.0F * 386.0878F * 0.84F;
    this.痛 = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.泳 = viewConfiguration.getScaledTouchSlop();
    this.踊 = viewConfiguration.getScaledMinimumFlingVelocity();
    this.寝 = viewConfiguration.getScaledMaximumFlingVelocity();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, 쾌, 2130903795, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.ゃ = new n5(0);
    this.赤 = new k5((View)this);
    setNestedScrollingEnabled(true);
    rw.帰((View)this, (nul)코);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.わ == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.わ = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.わ;
  }
  
  public static boolean 嬉(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && 嬉((View)viewParent, paramView2));
  }
  
  public final void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public final void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public final void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public final int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public final int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public final int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public final void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 痛 : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield 痛 : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield 痛 : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore #6
    //   28: iload #6
    //   30: aload_0
    //   31: getfield か : I
    //   34: isub
    //   35: istore #4
    //   37: aload_0
    //   38: invokevirtual getHeight : ()I
    //   41: istore #5
    //   43: aload_0
    //   44: getfield 臭 : Landroid/widget/EdgeEffect;
    //   47: astore #8
    //   49: aload_0
    //   50: getfield 痒 : Landroid/widget/EdgeEffect;
    //   53: astore #9
    //   55: iload #4
    //   57: ifle -> 129
    //   60: aload #9
    //   62: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   65: fconst_0
    //   66: fcmpl
    //   67: ifeq -> 129
    //   70: iload #4
    //   72: ineg
    //   73: i2f
    //   74: ldc_w 4.0
    //   77: fmul
    //   78: iload #5
    //   80: i2f
    //   81: fdiv
    //   82: fstore_1
    //   83: iload #5
    //   85: ineg
    //   86: i2f
    //   87: ldc_w 4.0
    //   90: fdiv
    //   91: fstore_2
    //   92: aload #9
    //   94: fload_1
    //   95: ldc_w 0.5
    //   98: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   101: fload_2
    //   102: fmul
    //   103: invokestatic round : (F)I
    //   106: istore #5
    //   108: iload #5
    //   110: istore_3
    //   111: iload #5
    //   113: iload #4
    //   115: if_icmpeq -> 206
    //   118: aload #9
    //   120: invokevirtual finish : ()V
    //   123: iload #5
    //   125: istore_3
    //   126: goto -> 206
    //   129: iload #4
    //   131: istore_3
    //   132: iload #4
    //   134: ifge -> 211
    //   137: iload #4
    //   139: istore_3
    //   140: aload #8
    //   142: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   145: fconst_0
    //   146: fcmpl
    //   147: ifeq -> 211
    //   150: iload #4
    //   152: i2f
    //   153: fstore_2
    //   154: iload #5
    //   156: i2f
    //   157: fstore_1
    //   158: fload_2
    //   159: ldc_w 4.0
    //   162: fmul
    //   163: fload_1
    //   164: fdiv
    //   165: fstore_2
    //   166: fload_1
    //   167: ldc_w 4.0
    //   170: fdiv
    //   171: fstore_1
    //   172: aload #8
    //   174: fload_2
    //   175: ldc_w 0.5
    //   178: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   181: fload_1
    //   182: fmul
    //   183: invokestatic round : (F)I
    //   186: istore #5
    //   188: iload #5
    //   190: istore_3
    //   191: iload #5
    //   193: iload #4
    //   195: if_icmpeq -> 206
    //   198: aload #8
    //   200: invokevirtual finish : ()V
    //   203: iload #5
    //   205: istore_3
    //   206: iload #4
    //   208: iload_3
    //   209: isub
    //   210: istore_3
    //   211: aload_0
    //   212: iload #6
    //   214: putfield か : I
    //   217: aload_0
    //   218: getfield 投 : [I
    //   221: astore #10
    //   223: iconst_0
    //   224: istore #5
    //   226: aload #10
    //   228: iconst_1
    //   229: iconst_0
    //   230: iastore
    //   231: aload_0
    //   232: getfield 赤 : Ly/k5;
    //   235: iconst_0
    //   236: iload_3
    //   237: iconst_1
    //   238: aload #10
    //   240: aconst_null
    //   241: invokevirtual 熱 : (III[I[I)Z
    //   244: pop
    //   245: iload_3
    //   246: aload #10
    //   248: iconst_1
    //   249: iaload
    //   250: isub
    //   251: istore #4
    //   253: aload_0
    //   254: invokevirtual getScrollRange : ()I
    //   257: istore #6
    //   259: iload #4
    //   261: istore_3
    //   262: iload #4
    //   264: ifeq -> 336
    //   267: aload_0
    //   268: invokevirtual getScrollY : ()I
    //   271: istore_3
    //   272: aload_0
    //   273: iload #4
    //   275: aload_0
    //   276: invokevirtual getScrollX : ()I
    //   279: iload_3
    //   280: iload #6
    //   282: invokevirtual 怖 : (IIII)Z
    //   285: pop
    //   286: aload_0
    //   287: invokevirtual getScrollY : ()I
    //   290: iload_3
    //   291: isub
    //   292: istore_3
    //   293: iload #4
    //   295: iload_3
    //   296: isub
    //   297: istore #4
    //   299: aload #10
    //   301: iconst_1
    //   302: iconst_0
    //   303: iastore
    //   304: aload_0
    //   305: getfield 触 : [I
    //   308: astore #11
    //   310: aload_0
    //   311: getfield 赤 : Ly/k5;
    //   314: iconst_0
    //   315: iload_3
    //   316: iconst_0
    //   317: iload #4
    //   319: aload #11
    //   321: iconst_1
    //   322: aload #10
    //   324: invokevirtual 冷 : (IIII[II[I)Z
    //   327: pop
    //   328: iload #4
    //   330: aload #10
    //   332: iconst_1
    //   333: iaload
    //   334: isub
    //   335: istore_3
    //   336: iload_3
    //   337: ifeq -> 439
    //   340: aload_0
    //   341: invokevirtual getOverScrollMode : ()I
    //   344: istore #7
    //   346: iload #7
    //   348: ifeq -> 370
    //   351: iload #5
    //   353: istore #4
    //   355: iload #7
    //   357: iconst_1
    //   358: if_icmpne -> 373
    //   361: iload #5
    //   363: istore #4
    //   365: iload #6
    //   367: ifle -> 373
    //   370: iconst_1
    //   371: istore #4
    //   373: iload #4
    //   375: ifeq -> 427
    //   378: iload_3
    //   379: ifge -> 406
    //   382: aload #9
    //   384: invokevirtual isFinished : ()Z
    //   387: ifeq -> 427
    //   390: aload #9
    //   392: aload_0
    //   393: getfield 痛 : Landroid/widget/OverScroller;
    //   396: invokevirtual getCurrVelocity : ()F
    //   399: f2i
    //   400: invokevirtual onAbsorb : (I)V
    //   403: goto -> 427
    //   406: aload #8
    //   408: invokevirtual isFinished : ()Z
    //   411: ifeq -> 427
    //   414: aload #8
    //   416: aload_0
    //   417: getfield 痛 : Landroid/widget/OverScroller;
    //   420: invokevirtual getCurrVelocity : ()F
    //   423: f2i
    //   424: invokevirtual onAbsorb : (I)V
    //   427: aload_0
    //   428: getfield 痛 : Landroid/widget/OverScroller;
    //   431: invokevirtual abortAnimation : ()V
    //   434: aload_0
    //   435: iconst_1
    //   436: invokevirtual 起 : (I)V
    //   439: aload_0
    //   440: getfield 痛 : Landroid/widget/OverScroller;
    //   443: invokevirtual isFinished : ()Z
    //   446: ifne -> 454
    //   449: aload_0
    //   450: invokestatic 痒 : (Landroid/view/View;)V
    //   453: return
    //   454: aload_0
    //   455: iconst_1
    //   456: invokevirtual 起 : (I)V
    //   459: return
  }
  
  public final int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public final int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public final int computeVerticalScrollRange() {
    int j = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (j == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    j = view.getBottom() + layoutParams.bottomMargin;
    int k = getScrollY();
    int m = Math.max(0, j - i);
    if (k < 0)
      return j - k; 
    i = j;
    if (k > m)
      i = j + k - m; 
    return i;
  }
  
  public final boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || 辛(paramKeyEvent));
  }
  
  public final boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.赤.硬(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public final boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.赤.堅(paramFloat1, paramFloat2);
  }
  
  public final boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return this.赤.熱(paramInt1, paramInt2, 0, paramArrayOfint1, paramArrayOfint2);
  }
  
  public final boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.赤.冷(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, 0, null);
  }
  
  public final void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int i = getScrollY();
    EdgeEffect edgeEffect = this.痒;
    boolean bool = edgeEffect.isFinished();
    byte b = 0;
    if (!bool) {
      int i3 = paramCanvas.save();
      int j = getWidth();
      int i2 = getHeight();
      int i1 = Math.min(0, i);
      int k = Build.VERSION.SDK_INT;
      if (h5.硬((ViewGroup)this)) {
        k = getPaddingLeft();
        j -= getPaddingRight() + k;
        k = getPaddingLeft() + 0;
      } else {
        k = 0;
      } 
      int n = i2;
      int m = i1;
      if (h5.硬((ViewGroup)this)) {
        m = getPaddingTop();
        n = i2 - getPaddingBottom() + m;
        m = i1 + getPaddingTop();
      } 
      paramCanvas.translate(k, m);
      edgeEffect.setSize(j, n);
      if (edgeEffect.draw(paramCanvas))
        rw.痒((View)this); 
      paramCanvas.restoreToCount(i3);
    } 
    edgeEffect = this.臭;
    if (!edgeEffect.isFinished()) {
      int i3 = paramCanvas.save();
      int m = getWidth();
      int i1 = getHeight();
      int i2 = Math.max(getScrollRange(), i) + i1;
      int j = Build.VERSION.SDK_INT;
      int k = b;
      j = m;
      if (h5.硬((ViewGroup)this)) {
        j = getPaddingLeft();
        j = m - getPaddingRight() + j;
        k = 0 + getPaddingLeft();
      } 
      int n = i2;
      m = i1;
      if (h5.硬((ViewGroup)this)) {
        m = getPaddingTop();
        m = i1 - getPaddingBottom() + m;
        n = i2 - getPaddingBottom();
      } 
      paramCanvas.translate((k - j), n);
      paramCanvas.rotate(180.0F, j, 0.0F);
      edgeEffect.setSize(j, m);
      if (edgeEffect.draw(paramCanvas))
        rw.痒((View)this); 
      paramCanvas.restoreToCount(i3);
    } 
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int j = getHeight();
    int k = getPaddingBottom();
    j = view.getBottom() + layoutParams.bottomMargin - getScrollY() - j - k;
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    n5 n51 = this.ゃ;
    int i = n51.淋;
    return n51.怖 | i;
  }
  
  public int getScrollRange() {
    int j = getChildCount();
    int i = 0;
    if (j > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public final boolean hasNestedScrollingParent() {
    k5 k51 = this.赤;
    boolean bool = false;
    if (k51.寒(0) != null)
      bool = true; 
    return bool;
  }
  
  public final boolean isNestedScrollingEnabled() {
    return this.赤.暑;
  }
  
  public final void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramInt2 = getPaddingLeft();
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt2, layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public final void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramInt3 = getPaddingLeft();
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt3 + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.産 = false;
  }
  
  public final boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore #6
    //   8: iconst_0
    //   9: istore #8
    //   11: iload_3
    //   12: bipush #8
    //   14: if_icmpne -> 337
    //   17: aload_0
    //   18: getfield 壊 : Z
    //   21: ifne -> 337
    //   24: aload_1
    //   25: iconst_2
    //   26: invokestatic 帰 : (Landroid/view/MotionEvent;I)Z
    //   29: ifeq -> 42
    //   32: aload_1
    //   33: bipush #9
    //   35: invokevirtual getAxisValue : (I)F
    //   38: fstore_2
    //   39: goto -> 64
    //   42: aload_1
    //   43: ldc_w 4194304
    //   46: invokestatic 帰 : (Landroid/view/MotionEvent;I)Z
    //   49: ifeq -> 62
    //   52: aload_1
    //   53: bipush #26
    //   55: invokevirtual getAxisValue : (I)F
    //   58: fstore_2
    //   59: goto -> 64
    //   62: fconst_0
    //   63: fstore_2
    //   64: fload_2
    //   65: fconst_0
    //   66: fcmpl
    //   67: ifeq -> 337
    //   70: fload_2
    //   71: aload_0
    //   72: invokespecial getVerticalScrollFactorCompat : ()F
    //   75: fmul
    //   76: f2i
    //   77: istore_3
    //   78: aload_0
    //   79: invokevirtual getScrollRange : ()I
    //   82: istore #5
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore #7
    //   90: iload #7
    //   92: iload_3
    //   93: isub
    //   94: istore #4
    //   96: iload #4
    //   98: ifge -> 204
    //   101: aload_0
    //   102: invokevirtual getOverScrollMode : ()I
    //   105: istore_3
    //   106: iload_3
    //   107: ifeq -> 130
    //   110: iload_3
    //   111: iconst_1
    //   112: if_icmpne -> 125
    //   115: aload_0
    //   116: invokevirtual getScrollRange : ()I
    //   119: ifle -> 125
    //   122: goto -> 130
    //   125: iconst_0
    //   126: istore_3
    //   127: goto -> 132
    //   130: iconst_1
    //   131: istore_3
    //   132: iload_3
    //   133: ifeq -> 151
    //   136: aload_1
    //   137: sipush #8194
    //   140: invokestatic 帰 : (Landroid/view/MotionEvent;I)Z
    //   143: ifne -> 151
    //   146: iconst_1
    //   147: istore_3
    //   148: goto -> 153
    //   151: iconst_0
    //   152: istore_3
    //   153: iload_3
    //   154: ifeq -> 199
    //   157: iload #4
    //   159: i2f
    //   160: fneg
    //   161: aload_0
    //   162: invokevirtual getHeight : ()I
    //   165: i2f
    //   166: fdiv
    //   167: fstore_2
    //   168: aload_0
    //   169: getfield 痒 : Landroid/widget/EdgeEffect;
    //   172: astore_1
    //   173: aload_1
    //   174: fload_2
    //   175: ldc_w 0.5
    //   178: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   181: pop
    //   182: aload_1
    //   183: invokevirtual onRelease : ()V
    //   186: aload_0
    //   187: invokevirtual invalidate : ()V
    //   190: iconst_1
    //   191: istore #8
    //   193: iload #6
    //   195: istore_3
    //   196: goto -> 317
    //   199: iconst_0
    //   200: istore_3
    //   201: goto -> 314
    //   204: iload #4
    //   206: istore_3
    //   207: iload #4
    //   209: iload #5
    //   211: if_icmple -> 314
    //   214: aload_0
    //   215: invokevirtual getOverScrollMode : ()I
    //   218: istore_3
    //   219: iload_3
    //   220: ifeq -> 243
    //   223: iload_3
    //   224: iconst_1
    //   225: if_icmpne -> 238
    //   228: aload_0
    //   229: invokevirtual getScrollRange : ()I
    //   232: ifle -> 238
    //   235: goto -> 243
    //   238: iconst_0
    //   239: istore_3
    //   240: goto -> 245
    //   243: iconst_1
    //   244: istore_3
    //   245: iload_3
    //   246: ifeq -> 264
    //   249: aload_1
    //   250: sipush #8194
    //   253: invokestatic 帰 : (Landroid/view/MotionEvent;I)Z
    //   256: ifne -> 264
    //   259: iconst_1
    //   260: istore_3
    //   261: goto -> 266
    //   264: iconst_0
    //   265: istore_3
    //   266: iload_3
    //   267: ifeq -> 308
    //   270: iload #4
    //   272: iload #5
    //   274: isub
    //   275: i2f
    //   276: aload_0
    //   277: invokevirtual getHeight : ()I
    //   280: i2f
    //   281: fdiv
    //   282: fstore_2
    //   283: aload_0
    //   284: getfield 臭 : Landroid/widget/EdgeEffect;
    //   287: astore_1
    //   288: aload_1
    //   289: fload_2
    //   290: ldc_w 0.5
    //   293: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   296: pop
    //   297: aload_1
    //   298: invokevirtual onRelease : ()V
    //   301: aload_0
    //   302: invokevirtual invalidate : ()V
    //   305: iconst_1
    //   306: istore #8
    //   308: iload #5
    //   310: istore_3
    //   311: goto -> 317
    //   314: iconst_0
    //   315: istore #8
    //   317: iload_3
    //   318: iload #7
    //   320: if_icmpeq -> 334
    //   323: aload_0
    //   324: aload_0
    //   325: invokevirtual getScrollX : ()I
    //   328: iload_3
    //   329: invokespecial scrollTo : (II)V
    //   332: iconst_1
    //   333: ireturn
    //   334: iload #8
    //   336: ireturn
    //   337: iconst_0
    //   338: ireturn
  }
  
  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_2
    //   5: iconst_1
    //   6: istore #7
    //   8: iconst_1
    //   9: istore #6
    //   11: iload_2
    //   12: iconst_2
    //   13: if_icmpne -> 25
    //   16: aload_0
    //   17: getfield 壊 : Z
    //   20: ifeq -> 25
    //   23: iconst_1
    //   24: ireturn
    //   25: iload_2
    //   26: sipush #255
    //   29: iand
    //   30: istore_2
    //   31: iload_2
    //   32: ifeq -> 247
    //   35: iload_2
    //   36: iconst_1
    //   37: if_icmpeq -> 182
    //   40: iload_2
    //   41: iconst_2
    //   42: if_icmpeq -> 67
    //   45: iload_2
    //   46: iconst_3
    //   47: if_icmpeq -> 182
    //   50: iload_2
    //   51: bipush #6
    //   53: if_icmpeq -> 59
    //   56: goto -> 495
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual 淋 : (Landroid/view/MotionEvent;)V
    //   64: goto -> 495
    //   67: aload_0
    //   68: getfield 噛 : I
    //   71: istore_2
    //   72: iload_2
    //   73: iconst_m1
    //   74: if_icmpne -> 80
    //   77: goto -> 495
    //   80: aload_1
    //   81: iload_2
    //   82: invokevirtual findPointerIndex : (I)I
    //   85: istore_2
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpne -> 94
    //   91: goto -> 495
    //   94: aload_1
    //   95: iload_2
    //   96: invokevirtual getY : (I)F
    //   99: f2i
    //   100: istore_2
    //   101: iload_2
    //   102: aload_0
    //   103: getfield 起 : I
    //   106: isub
    //   107: invokestatic abs : (I)I
    //   110: aload_0
    //   111: getfield 泳 : I
    //   114: if_icmple -> 495
    //   117: iconst_2
    //   118: aload_0
    //   119: invokevirtual getNestedScrollAxes : ()I
    //   122: iand
    //   123: ifne -> 495
    //   126: aload_0
    //   127: iconst_1
    //   128: putfield 壊 : Z
    //   131: aload_0
    //   132: iload_2
    //   133: putfield 起 : I
    //   136: aload_0
    //   137: getfield 帰 : Landroid/view/VelocityTracker;
    //   140: ifnonnull -> 150
    //   143: aload_0
    //   144: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   147: putfield 帰 : Landroid/view/VelocityTracker;
    //   150: aload_0
    //   151: getfield 帰 : Landroid/view/VelocityTracker;
    //   154: aload_1
    //   155: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   158: aload_0
    //   159: iconst_0
    //   160: putfield あ : I
    //   163: aload_0
    //   164: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   167: astore_1
    //   168: aload_1
    //   169: ifnull -> 495
    //   172: aload_1
    //   173: iconst_1
    //   174: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   179: goto -> 495
    //   182: aload_0
    //   183: iconst_0
    //   184: putfield 壊 : Z
    //   187: aload_0
    //   188: iconst_m1
    //   189: putfield 噛 : I
    //   192: aload_0
    //   193: getfield 帰 : Landroid/view/VelocityTracker;
    //   196: astore_1
    //   197: aload_1
    //   198: ifnull -> 210
    //   201: aload_1
    //   202: invokevirtual recycle : ()V
    //   205: aload_0
    //   206: aconst_null
    //   207: putfield 帰 : Landroid/view/VelocityTracker;
    //   210: aload_0
    //   211: getfield 痛 : Landroid/widget/OverScroller;
    //   214: aload_0
    //   215: invokevirtual getScrollX : ()I
    //   218: aload_0
    //   219: invokevirtual getScrollY : ()I
    //   222: iconst_0
    //   223: iconst_0
    //   224: iconst_0
    //   225: aload_0
    //   226: invokevirtual getScrollRange : ()I
    //   229: invokevirtual springBack : (IIIIII)Z
    //   232: ifeq -> 239
    //   235: aload_0
    //   236: invokestatic 痒 : (Landroid/view/View;)V
    //   239: aload_0
    //   240: iconst_0
    //   241: invokevirtual 起 : (I)V
    //   244: goto -> 495
    //   247: aload_1
    //   248: invokevirtual getY : ()F
    //   251: f2i
    //   252: istore_3
    //   253: aload_1
    //   254: invokevirtual getX : ()F
    //   257: f2i
    //   258: istore_2
    //   259: aload_0
    //   260: invokevirtual getChildCount : ()I
    //   263: ifle -> 326
    //   266: aload_0
    //   267: invokevirtual getScrollY : ()I
    //   270: istore #4
    //   272: aload_0
    //   273: iconst_0
    //   274: invokevirtual getChildAt : (I)Landroid/view/View;
    //   277: astore #8
    //   279: iload_3
    //   280: aload #8
    //   282: invokevirtual getTop : ()I
    //   285: iload #4
    //   287: isub
    //   288: if_icmplt -> 326
    //   291: iload_3
    //   292: aload #8
    //   294: invokevirtual getBottom : ()I
    //   297: iload #4
    //   299: isub
    //   300: if_icmpge -> 326
    //   303: iload_2
    //   304: aload #8
    //   306: invokevirtual getLeft : ()I
    //   309: if_icmplt -> 326
    //   312: iload_2
    //   313: aload #8
    //   315: invokevirtual getRight : ()I
    //   318: if_icmpge -> 326
    //   321: iconst_1
    //   322: istore_2
    //   323: goto -> 328
    //   326: iconst_0
    //   327: istore_2
    //   328: iload_2
    //   329: ifne -> 391
    //   332: iload #6
    //   334: istore #5
    //   336: aload_0
    //   337: aload_1
    //   338: invokevirtual 臭 : (Landroid/view/MotionEvent;)Z
    //   341: ifne -> 364
    //   344: aload_0
    //   345: getfield 痛 : Landroid/widget/OverScroller;
    //   348: invokevirtual isFinished : ()Z
    //   351: ifne -> 361
    //   354: iload #6
    //   356: istore #5
    //   358: goto -> 364
    //   361: iconst_0
    //   362: istore #5
    //   364: aload_0
    //   365: iload #5
    //   367: putfield 壊 : Z
    //   370: aload_0
    //   371: getfield 帰 : Landroid/view/VelocityTracker;
    //   374: astore_1
    //   375: aload_1
    //   376: ifnull -> 495
    //   379: aload_1
    //   380: invokevirtual recycle : ()V
    //   383: aload_0
    //   384: aconst_null
    //   385: putfield 帰 : Landroid/view/VelocityTracker;
    //   388: goto -> 495
    //   391: aload_0
    //   392: iload_3
    //   393: putfield 起 : I
    //   396: aload_0
    //   397: aload_1
    //   398: iconst_0
    //   399: invokevirtual getPointerId : (I)I
    //   402: putfield 噛 : I
    //   405: aload_0
    //   406: getfield 帰 : Landroid/view/VelocityTracker;
    //   409: astore #8
    //   411: aload #8
    //   413: ifnonnull -> 426
    //   416: aload_0
    //   417: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   420: putfield 帰 : Landroid/view/VelocityTracker;
    //   423: goto -> 431
    //   426: aload #8
    //   428: invokevirtual clear : ()V
    //   431: aload_0
    //   432: getfield 帰 : Landroid/view/VelocityTracker;
    //   435: aload_1
    //   436: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   439: aload_0
    //   440: getfield 痛 : Landroid/widget/OverScroller;
    //   443: invokevirtual computeScrollOffset : ()Z
    //   446: pop
    //   447: iload #7
    //   449: istore #5
    //   451: aload_0
    //   452: aload_1
    //   453: invokevirtual 臭 : (Landroid/view/MotionEvent;)Z
    //   456: ifne -> 479
    //   459: aload_0
    //   460: getfield 痛 : Landroid/widget/OverScroller;
    //   463: invokevirtual isFinished : ()Z
    //   466: ifne -> 476
    //   469: iload #7
    //   471: istore #5
    //   473: goto -> 479
    //   476: iconst_0
    //   477: istore #5
    //   479: aload_0
    //   480: iload #5
    //   482: putfield 壊 : Z
    //   485: aload_0
    //   486: getfield 赤 : Ly/k5;
    //   489: iconst_2
    //   490: iconst_0
    //   491: invokevirtual 美 : (II)Z
    //   494: pop
    //   495: aload_0
    //   496: getfield 壊 : Z
    //   499: ireturn
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    boolean bool = false;
    this.興 = false;
    View view = this.死;
    if (view != null && 嬉(view, (View)this)) {
      view = this.死;
      Rect rect = this.恐;
      view.getDrawingRect(rect);
      offsetDescendantRectToMyCoords(view, rect);
      paramInt1 = 旨(rect);
      if (paramInt1 != 0)
        scrollBy(0, paramInt1); 
    } 
    this.死 = null;
    if (!this.産) {
      if (this.ち != null) {
        scrollTo(getScrollX(), this.ち.淋);
        this.ち = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt3 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        paramInt3 = 0;
      } 
      paramInt4 = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
      paramInt2 = getScrollY();
      paramInt1 = bool;
      if (paramInt4 < paramInt3)
        if (paramInt2 < 0) {
          paramInt1 = bool;
        } else if (paramInt4 + paramInt2 > paramInt3) {
          paramInt1 = paramInt3 - paramInt4;
        } else {
          paramInt1 = paramInt2;
        }  
      if (paramInt1 != paramInt2)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.産 = true;
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.返)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (i < paramInt2) {
        i = getPaddingLeft();
        view.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      } 
    } 
  }
  
  public final boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      ぱ((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public final boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public final void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    熱(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public final void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    寂(paramInt4, 0, null);
  }
  
  public final void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    硬(paramView1, paramView2, paramInt, 0);
  }
  
  public final void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public final boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (((true ^ 悲(view, 0, getHeight())) != 0) ? false : view.requestFocus(i, paramRect));
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof j5)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    j5 j51 = (j5)paramParcelable;
    super.onRestoreInstanceState(j51.getSuperState());
    this.ち = j51;
    requestLayout();
  }
  
  public final Parcelable onSaveInstanceState() {
    j5 j51 = new j5(super.onSaveInstanceState());
    j51.淋 = getScrollY();
    return (Parcelable)j51;
  }
  
  public final void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    i5 i51 = this.も;
    if (i51 != null) {
      茎 茎 = (茎)i51;
      醤.熱((View)this, (View)茎.怖, (View)茎.恐);
    } 
  }
  
  public final void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (悲(view, 0, paramInt4)) {
        Rect rect = this.恐;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        不(旨(rect));
      } 
    } 
  }
  
  public final boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return 寒(paramView1, paramView2, paramInt, 0);
  }
  
  public final void onStopNestedScroll(View paramView) {
    堅(paramView, 0);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 帰 : Landroid/view/VelocityTracker;
    //   4: ifnonnull -> 14
    //   7: aload_0
    //   8: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   11: putfield 帰 : Landroid/view/VelocityTracker;
    //   14: aload_1
    //   15: invokevirtual getActionMasked : ()I
    //   18: istore #5
    //   20: iload #5
    //   22: ifne -> 30
    //   25: aload_0
    //   26: iconst_0
    //   27: putfield あ : I
    //   30: aload_1
    //   31: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    //   34: astore #14
    //   36: aload_0
    //   37: getfield あ : I
    //   40: i2f
    //   41: fstore_3
    //   42: fconst_0
    //   43: fstore_2
    //   44: aload #14
    //   46: fconst_0
    //   47: fload_3
    //   48: invokevirtual offsetLocation : (FF)V
    //   51: aload_0
    //   52: getfield 赤 : Ly/k5;
    //   55: astore #17
    //   57: iload #5
    //   59: ifeq -> 1169
    //   62: aload_0
    //   63: getfield 痒 : Landroid/widget/EdgeEffect;
    //   66: astore #15
    //   68: aload_0
    //   69: getfield 臭 : Landroid/widget/EdgeEffect;
    //   72: astore #16
    //   74: iload #5
    //   76: iconst_1
    //   77: if_icmpeq -> 922
    //   80: iload #5
    //   82: iconst_2
    //   83: if_icmpeq -> 252
    //   86: iload #5
    //   88: iconst_3
    //   89: if_icmpeq -> 163
    //   92: iload #5
    //   94: iconst_5
    //   95: if_icmpeq -> 133
    //   98: iload #5
    //   100: bipush #6
    //   102: if_icmpeq -> 108
    //   105: goto -> 1252
    //   108: aload_0
    //   109: aload_1
    //   110: invokevirtual 淋 : (Landroid/view/MotionEvent;)V
    //   113: aload_0
    //   114: aload_1
    //   115: aload_1
    //   116: aload_0
    //   117: getfield 噛 : I
    //   120: invokevirtual findPointerIndex : (I)I
    //   123: invokevirtual getY : (I)F
    //   126: f2i
    //   127: putfield 起 : I
    //   130: goto -> 1252
    //   133: aload_1
    //   134: invokevirtual getActionIndex : ()I
    //   137: istore #5
    //   139: aload_0
    //   140: aload_1
    //   141: iload #5
    //   143: invokevirtual getY : (I)F
    //   146: f2i
    //   147: putfield 起 : I
    //   150: aload_0
    //   151: aload_1
    //   152: iload #5
    //   154: invokevirtual getPointerId : (I)I
    //   157: putfield 噛 : I
    //   160: goto -> 1252
    //   163: aload_0
    //   164: getfield 壊 : Z
    //   167: ifeq -> 206
    //   170: aload_0
    //   171: invokevirtual getChildCount : ()I
    //   174: ifle -> 206
    //   177: aload_0
    //   178: getfield 痛 : Landroid/widget/OverScroller;
    //   181: aload_0
    //   182: invokevirtual getScrollX : ()I
    //   185: aload_0
    //   186: invokevirtual getScrollY : ()I
    //   189: iconst_0
    //   190: iconst_0
    //   191: iconst_0
    //   192: aload_0
    //   193: invokevirtual getScrollRange : ()I
    //   196: invokevirtual springBack : (IIIIII)Z
    //   199: ifeq -> 206
    //   202: aload_0
    //   203: invokestatic 痒 : (Landroid/view/View;)V
    //   206: aload_0
    //   207: iconst_m1
    //   208: putfield 噛 : I
    //   211: aload_0
    //   212: iconst_0
    //   213: putfield 壊 : Z
    //   216: aload_0
    //   217: getfield 帰 : Landroid/view/VelocityTracker;
    //   220: astore_1
    //   221: aload_1
    //   222: ifnull -> 234
    //   225: aload_1
    //   226: invokevirtual recycle : ()V
    //   229: aload_0
    //   230: aconst_null
    //   231: putfield 帰 : Landroid/view/VelocityTracker;
    //   234: aload_0
    //   235: iconst_0
    //   236: invokevirtual 起 : (I)V
    //   239: aload #15
    //   241: invokevirtual onRelease : ()V
    //   244: aload #16
    //   246: invokevirtual onRelease : ()V
    //   249: goto -> 1252
    //   252: aload_1
    //   253: aload_0
    //   254: getfield 噛 : I
    //   257: invokevirtual findPointerIndex : (I)I
    //   260: istore #8
    //   262: iload #8
    //   264: iconst_m1
    //   265: if_icmpne -> 271
    //   268: goto -> 1252
    //   271: aload_1
    //   272: iload #8
    //   274: invokevirtual getY : (I)F
    //   277: f2i
    //   278: istore #7
    //   280: aload_0
    //   281: getfield 起 : I
    //   284: iload #7
    //   286: isub
    //   287: istore #5
    //   289: aload_1
    //   290: iload #8
    //   292: invokevirtual getX : (I)F
    //   295: aload_0
    //   296: invokevirtual getWidth : ()I
    //   299: i2f
    //   300: fdiv
    //   301: fstore_3
    //   302: iload #5
    //   304: i2f
    //   305: aload_0
    //   306: invokevirtual getHeight : ()I
    //   309: i2f
    //   310: fdiv
    //   311: fstore #4
    //   313: aload #15
    //   315: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   318: fconst_0
    //   319: fcmpl
    //   320: ifeq -> 356
    //   323: aload #15
    //   325: fload #4
    //   327: fneg
    //   328: fload_3
    //   329: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   332: fneg
    //   333: fstore_3
    //   334: fload_3
    //   335: fstore_2
    //   336: aload #15
    //   338: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   341: fconst_0
    //   342: fcmpl
    //   343: ifne -> 353
    //   346: aload #15
    //   348: invokevirtual onRelease : ()V
    //   351: fload_3
    //   352: fstore_2
    //   353: goto -> 399
    //   356: aload #16
    //   358: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   361: fconst_0
    //   362: fcmpl
    //   363: ifeq -> 399
    //   366: aload #16
    //   368: fload #4
    //   370: fconst_1
    //   371: fload_3
    //   372: fsub
    //   373: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   376: fstore_3
    //   377: fload_3
    //   378: fstore_2
    //   379: aload #16
    //   381: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   384: fconst_0
    //   385: fcmpl
    //   386: ifne -> 353
    //   389: aload #16
    //   391: invokevirtual onRelease : ()V
    //   394: fload_3
    //   395: fstore_2
    //   396: goto -> 353
    //   399: fload_2
    //   400: aload_0
    //   401: invokevirtual getHeight : ()I
    //   404: i2f
    //   405: fmul
    //   406: invokestatic round : (F)I
    //   409: istore #6
    //   411: iload #6
    //   413: ifeq -> 420
    //   416: aload_0
    //   417: invokevirtual invalidate : ()V
    //   420: iload #5
    //   422: iload #6
    //   424: isub
    //   425: istore #6
    //   427: iload #6
    //   429: istore #5
    //   431: aload_0
    //   432: getfield 壊 : Z
    //   435: ifne -> 504
    //   438: iload #6
    //   440: istore #5
    //   442: iload #6
    //   444: invokestatic abs : (I)I
    //   447: aload_0
    //   448: getfield 泳 : I
    //   451: if_icmple -> 504
    //   454: aload_0
    //   455: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   458: astore #18
    //   460: aload #18
    //   462: ifnull -> 473
    //   465: aload #18
    //   467: iconst_1
    //   468: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   473: aload_0
    //   474: iconst_1
    //   475: putfield 壊 : Z
    //   478: iload #6
    //   480: ifle -> 495
    //   483: iload #6
    //   485: aload_0
    //   486: getfield 泳 : I
    //   489: isub
    //   490: istore #5
    //   492: goto -> 504
    //   495: iload #6
    //   497: aload_0
    //   498: getfield 泳 : I
    //   501: iadd
    //   502: istore #5
    //   504: aload_0
    //   505: getfield 壊 : Z
    //   508: ifeq -> 1252
    //   511: aload_0
    //   512: getfield 投 : [I
    //   515: astore #18
    //   517: aload_0
    //   518: getfield 触 : [I
    //   521: astore #19
    //   523: aload_0
    //   524: getfield 赤 : Ly/k5;
    //   527: iconst_0
    //   528: iload #5
    //   530: iconst_0
    //   531: aload #18
    //   533: aload #19
    //   535: invokevirtual 熱 : (III[I[I)Z
    //   538: istore #13
    //   540: aload_0
    //   541: getfield 投 : [I
    //   544: astore #18
    //   546: aload_0
    //   547: getfield 触 : [I
    //   550: astore #19
    //   552: iload #5
    //   554: istore #6
    //   556: iload #13
    //   558: ifeq -> 583
    //   561: iload #5
    //   563: aload #18
    //   565: iconst_1
    //   566: iaload
    //   567: isub
    //   568: istore #6
    //   570: aload_0
    //   571: aload_0
    //   572: getfield あ : I
    //   575: aload #19
    //   577: iconst_1
    //   578: iaload
    //   579: iadd
    //   580: putfield あ : I
    //   583: aload_0
    //   584: iload #7
    //   586: aload #19
    //   588: iconst_1
    //   589: iaload
    //   590: isub
    //   591: putfield 起 : I
    //   594: aload_0
    //   595: invokevirtual getScrollY : ()I
    //   598: istore #10
    //   600: aload_0
    //   601: invokevirtual getScrollRange : ()I
    //   604: istore #9
    //   606: aload_0
    //   607: invokevirtual getOverScrollMode : ()I
    //   610: istore #5
    //   612: iload #5
    //   614: ifeq -> 637
    //   617: iload #5
    //   619: iconst_1
    //   620: if_icmpne -> 631
    //   623: iload #9
    //   625: ifle -> 631
    //   628: goto -> 637
    //   631: iconst_0
    //   632: istore #7
    //   634: goto -> 640
    //   637: iconst_1
    //   638: istore #7
    //   640: aload_0
    //   641: iload #6
    //   643: iconst_0
    //   644: aload_0
    //   645: invokevirtual getScrollY : ()I
    //   648: iload #9
    //   650: invokevirtual 怖 : (IIII)Z
    //   653: ifeq -> 685
    //   656: aload #17
    //   658: iconst_0
    //   659: invokevirtual 寒 : (I)Landroid/view/ViewParent;
    //   662: ifnull -> 671
    //   665: iconst_1
    //   666: istore #5
    //   668: goto -> 674
    //   671: iconst_0
    //   672: istore #5
    //   674: iload #5
    //   676: ifne -> 685
    //   679: iconst_1
    //   680: istore #5
    //   682: goto -> 688
    //   685: iconst_0
    //   686: istore #5
    //   688: aload_0
    //   689: invokevirtual getScrollY : ()I
    //   692: iload #10
    //   694: isub
    //   695: istore #11
    //   697: aload #18
    //   699: iconst_1
    //   700: iconst_0
    //   701: iastore
    //   702: aload_0
    //   703: getfield 触 : [I
    //   706: astore #17
    //   708: aload_0
    //   709: getfield 赤 : Ly/k5;
    //   712: iconst_0
    //   713: iload #11
    //   715: iconst_0
    //   716: iload #6
    //   718: iload #11
    //   720: isub
    //   721: aload #17
    //   723: iconst_0
    //   724: aload #18
    //   726: invokevirtual 冷 : (IIII[II[I)Z
    //   729: pop
    //   730: aload_0
    //   731: getfield 起 : I
    //   734: istore #11
    //   736: aload #19
    //   738: iconst_1
    //   739: iaload
    //   740: istore #12
    //   742: aload_0
    //   743: iload #11
    //   745: iload #12
    //   747: isub
    //   748: putfield 起 : I
    //   751: aload_0
    //   752: aload_0
    //   753: getfield あ : I
    //   756: iload #12
    //   758: iadd
    //   759: putfield あ : I
    //   762: iload #7
    //   764: ifeq -> 907
    //   767: iload #6
    //   769: aload #18
    //   771: iconst_1
    //   772: iaload
    //   773: isub
    //   774: istore #6
    //   776: iload #10
    //   778: iload #6
    //   780: iadd
    //   781: istore #7
    //   783: iload #7
    //   785: ifge -> 832
    //   788: aload #15
    //   790: iload #6
    //   792: ineg
    //   793: i2f
    //   794: aload_0
    //   795: invokevirtual getHeight : ()I
    //   798: i2f
    //   799: fdiv
    //   800: aload_1
    //   801: iload #8
    //   803: invokevirtual getX : (I)F
    //   806: aload_0
    //   807: invokevirtual getWidth : ()I
    //   810: i2f
    //   811: fdiv
    //   812: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   815: pop
    //   816: aload #16
    //   818: invokevirtual isFinished : ()Z
    //   821: ifne -> 881
    //   824: aload #16
    //   826: invokevirtual onRelease : ()V
    //   829: goto -> 881
    //   832: iload #7
    //   834: iload #9
    //   836: if_icmple -> 881
    //   839: aload #16
    //   841: iload #6
    //   843: i2f
    //   844: aload_0
    //   845: invokevirtual getHeight : ()I
    //   848: i2f
    //   849: fdiv
    //   850: fconst_1
    //   851: aload_1
    //   852: iload #8
    //   854: invokevirtual getX : (I)F
    //   857: aload_0
    //   858: invokevirtual getWidth : ()I
    //   861: i2f
    //   862: fdiv
    //   863: fsub
    //   864: invokestatic 臭 : (Landroid/widget/EdgeEffect;FF)F
    //   867: pop
    //   868: aload #15
    //   870: invokevirtual isFinished : ()Z
    //   873: ifne -> 881
    //   876: aload #15
    //   878: invokevirtual onRelease : ()V
    //   881: aload #15
    //   883: invokevirtual isFinished : ()Z
    //   886: ifeq -> 897
    //   889: aload #16
    //   891: invokevirtual isFinished : ()Z
    //   894: ifne -> 907
    //   897: aload_0
    //   898: invokestatic 痒 : (Landroid/view/View;)V
    //   901: iconst_0
    //   902: istore #5
    //   904: goto -> 907
    //   907: iload #5
    //   909: ifeq -> 1252
    //   912: aload_0
    //   913: getfield 帰 : Landroid/view/VelocityTracker;
    //   916: invokevirtual clear : ()V
    //   919: goto -> 1252
    //   922: aload_0
    //   923: getfield 帰 : Landroid/view/VelocityTracker;
    //   926: astore_1
    //   927: aload_1
    //   928: sipush #1000
    //   931: aload_0
    //   932: getfield 寝 : I
    //   935: i2f
    //   936: invokevirtual computeCurrentVelocity : (IF)V
    //   939: aload_1
    //   940: aload_0
    //   941: getfield 噛 : I
    //   944: invokevirtual getYVelocity : (I)F
    //   947: f2i
    //   948: istore #6
    //   950: iload #6
    //   952: invokestatic abs : (I)I
    //   955: aload_0
    //   956: getfield 踊 : I
    //   959: if_icmplt -> 1094
    //   962: aload #15
    //   964: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   967: fconst_0
    //   968: fcmpl
    //   969: ifeq -> 1003
    //   972: aload_0
    //   973: aload #15
    //   975: iload #6
    //   977: invokevirtual 痛 : (Landroid/widget/EdgeEffect;I)Z
    //   980: ifeq -> 993
    //   983: aload #15
    //   985: iload #6
    //   987: invokevirtual onAbsorb : (I)V
    //   990: goto -> 1045
    //   993: aload_0
    //   994: iload #6
    //   996: ineg
    //   997: invokevirtual ぱ : (I)V
    //   1000: goto -> 1045
    //   1003: aload #16
    //   1005: invokestatic 旨 : (Landroid/widget/EdgeEffect;)F
    //   1008: fconst_0
    //   1009: fcmpl
    //   1010: ifeq -> 1051
    //   1013: iload #6
    //   1015: ineg
    //   1016: istore #5
    //   1018: aload_0
    //   1019: aload #16
    //   1021: iload #5
    //   1023: invokevirtual 痛 : (Landroid/widget/EdgeEffect;I)Z
    //   1026: ifeq -> 1039
    //   1029: aload #16
    //   1031: iload #5
    //   1033: invokevirtual onAbsorb : (I)V
    //   1036: goto -> 1045
    //   1039: aload_0
    //   1040: iload #5
    //   1042: invokevirtual ぱ : (I)V
    //   1045: iconst_1
    //   1046: istore #5
    //   1048: goto -> 1054
    //   1051: iconst_0
    //   1052: istore #5
    //   1054: iload #5
    //   1056: ifne -> 1123
    //   1059: iload #6
    //   1061: ineg
    //   1062: istore #5
    //   1064: iload #5
    //   1066: i2f
    //   1067: fstore_2
    //   1068: aload_0
    //   1069: fconst_0
    //   1070: fload_2
    //   1071: invokevirtual dispatchNestedPreFling : (FF)Z
    //   1074: ifne -> 1123
    //   1077: aload_0
    //   1078: fconst_0
    //   1079: fload_2
    //   1080: iconst_1
    //   1081: invokevirtual dispatchNestedFling : (FFZ)Z
    //   1084: pop
    //   1085: aload_0
    //   1086: iload #5
    //   1088: invokevirtual ぱ : (I)V
    //   1091: goto -> 1123
    //   1094: aload_0
    //   1095: getfield 痛 : Landroid/widget/OverScroller;
    //   1098: aload_0
    //   1099: invokevirtual getScrollX : ()I
    //   1102: aload_0
    //   1103: invokevirtual getScrollY : ()I
    //   1106: iconst_0
    //   1107: iconst_0
    //   1108: iconst_0
    //   1109: aload_0
    //   1110: invokevirtual getScrollRange : ()I
    //   1113: invokevirtual springBack : (IIIIII)Z
    //   1116: ifeq -> 1123
    //   1119: aload_0
    //   1120: invokestatic 痒 : (Landroid/view/View;)V
    //   1123: aload_0
    //   1124: iconst_m1
    //   1125: putfield 噛 : I
    //   1128: aload_0
    //   1129: iconst_0
    //   1130: putfield 壊 : Z
    //   1133: aload_0
    //   1134: getfield 帰 : Landroid/view/VelocityTracker;
    //   1137: astore_1
    //   1138: aload_1
    //   1139: ifnull -> 1151
    //   1142: aload_1
    //   1143: invokevirtual recycle : ()V
    //   1146: aload_0
    //   1147: aconst_null
    //   1148: putfield 帰 : Landroid/view/VelocityTracker;
    //   1151: aload_0
    //   1152: iconst_0
    //   1153: invokevirtual 起 : (I)V
    //   1156: aload #15
    //   1158: invokevirtual onRelease : ()V
    //   1161: aload #16
    //   1163: invokevirtual onRelease : ()V
    //   1166: goto -> 1252
    //   1169: aload_0
    //   1170: invokevirtual getChildCount : ()I
    //   1173: ifne -> 1178
    //   1176: iconst_0
    //   1177: ireturn
    //   1178: aload_0
    //   1179: getfield 壊 : Z
    //   1182: ifeq -> 1204
    //   1185: aload_0
    //   1186: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1189: astore #15
    //   1191: aload #15
    //   1193: ifnull -> 1204
    //   1196: aload #15
    //   1198: iconst_1
    //   1199: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   1204: aload_0
    //   1205: getfield 痛 : Landroid/widget/OverScroller;
    //   1208: invokevirtual isFinished : ()Z
    //   1211: ifne -> 1226
    //   1214: aload_0
    //   1215: getfield 痛 : Landroid/widget/OverScroller;
    //   1218: invokevirtual abortAnimation : ()V
    //   1221: aload_0
    //   1222: iconst_1
    //   1223: invokevirtual 起 : (I)V
    //   1226: aload_0
    //   1227: aload_1
    //   1228: invokevirtual getY : ()F
    //   1231: f2i
    //   1232: putfield 起 : I
    //   1235: aload_0
    //   1236: aload_1
    //   1237: iconst_0
    //   1238: invokevirtual getPointerId : (I)I
    //   1241: putfield 噛 : I
    //   1244: aload #17
    //   1246: iconst_2
    //   1247: iconst_0
    //   1248: invokevirtual 美 : (II)Z
    //   1251: pop
    //   1252: aload_0
    //   1253: getfield 帰 : Landroid/view/VelocityTracker;
    //   1256: astore_1
    //   1257: aload_1
    //   1258: ifnull -> 1267
    //   1261: aload_1
    //   1262: aload #14
    //   1264: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   1267: aload #14
    //   1269: invokevirtual recycle : ()V
    //   1272: iconst_1
    //   1273: ireturn
  }
  
  public final void requestChildFocus(View paramView1, View paramView2) {
    if (!this.興) {
      Rect rect = this.恐;
      paramView2.getDrawingRect(rect);
      offsetDescendantRectToMyCoords(paramView2, rect);
      int i = 旨(rect);
      if (i != 0)
        scrollBy(0, i); 
    } else {
      this.死 = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public final boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    int i = 旨(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      痒(0, i, false);
    } 
    return bool;
  }
  
  public final void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean) {
      VelocityTracker velocityTracker = this.帰;
      if (velocityTracker != null) {
        velocityTracker.recycle();
        this.帰 = null;
      } 
    } 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public final void requestLayout() {
    this.興 = true;
    super.requestLayout();
  }
  
  public final void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      int i;
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int m = getWidth() - getPaddingLeft() - getPaddingRight();
      int n = view.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
      int j = getHeight() - getPaddingTop() - getPaddingBottom();
      int k = view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      if (m >= n || paramInt1 < 0) {
        i = 0;
      } else {
        i = paramInt1;
        if (m + paramInt1 > n)
          i = n - m; 
      } 
      if (j >= k || paramInt2 < 0) {
        paramInt1 = 0;
      } else {
        paramInt1 = paramInt2;
        if (j + paramInt2 > k)
          paramInt1 = k - j; 
      } 
      if (i != getScrollX() || paramInt1 != getScrollY())
        super.scrollTo(i, paramInt1); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.返) {
      this.返 = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    k5 k51 = this.赤;
    if (k51.暑) {
      WeakHashMap weakHashMap = rw.硬;
      int i = Build.VERSION.SDK_INT;
      gw.壊(k51.熱);
    } 
    k51.暑 = paramBoolean;
  }
  
  public void setOnScrollChangeListener(i5 parami5) {
    this.も = parami5;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.歩 = paramBoolean;
  }
  
  public final boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public final boolean startNestedScroll(int paramInt) {
    return this.赤.美(paramInt, 0);
  }
  
  public final void stopNestedScroll() {
    起(0);
  }
  
  public final void ぱ(int paramInt) {
    if (getChildCount() > 0) {
      this.痛.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      this.赤.美(2, 1);
      this.か = getScrollY();
      rw.痒((View)this);
    } 
  }
  
  public final void 不(int paramInt) {
    if (paramInt != 0) {
      if (this.歩) {
        痒(0, paramInt, false);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public final void 冷(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    寂(paramInt4, paramInt5, null);
  }
  
  public final void 堅(View paramView, int paramInt) {
    n5 n51 = this.ゃ;
    if (paramInt == 1) {
      n51.怖 = 0;
    } else {
      n51.淋 = 0;
    } 
    起(paramInt);
  }
  
  public final void 寂(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.赤.暑(i, paramInt1 - i, paramInt2, paramArrayOfint);
  }
  
  public final boolean 寒(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public final boolean 怖(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: pop
    //   5: aload_0
    //   6: invokevirtual computeHorizontalScrollRange : ()I
    //   9: pop
    //   10: aload_0
    //   11: invokevirtual computeHorizontalScrollExtent : ()I
    //   14: pop
    //   15: aload_0
    //   16: invokevirtual computeVerticalScrollRange : ()I
    //   19: pop
    //   20: aload_0
    //   21: invokevirtual computeVerticalScrollExtent : ()I
    //   24: pop
    //   25: iconst_1
    //   26: istore #7
    //   28: iload_2
    //   29: iconst_0
    //   30: iadd
    //   31: istore_2
    //   32: iload_3
    //   33: iload_1
    //   34: iadd
    //   35: istore_1
    //   36: iload #4
    //   38: iconst_0
    //   39: iadd
    //   40: istore_3
    //   41: iload_2
    //   42: ifle -> 48
    //   45: goto -> 52
    //   48: iload_2
    //   49: ifge -> 60
    //   52: iconst_1
    //   53: istore #5
    //   55: iconst_0
    //   56: istore_2
    //   57: goto -> 63
    //   60: iconst_0
    //   61: istore #5
    //   63: iload_1
    //   64: iload_3
    //   65: if_icmple -> 73
    //   68: iload_3
    //   69: istore_1
    //   70: goto -> 79
    //   73: iload_1
    //   74: ifge -> 85
    //   77: iconst_0
    //   78: istore_1
    //   79: iconst_1
    //   80: istore #6
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #6
    //   88: iload #6
    //   90: ifeq -> 132
    //   93: aload_0
    //   94: getfield 赤 : Ly/k5;
    //   97: iconst_1
    //   98: invokevirtual 寒 : (I)Landroid/view/ViewParent;
    //   101: ifnull -> 109
    //   104: iconst_1
    //   105: istore_3
    //   106: goto -> 111
    //   109: iconst_0
    //   110: istore_3
    //   111: iload_3
    //   112: ifne -> 132
    //   115: aload_0
    //   116: getfield 痛 : Landroid/widget/OverScroller;
    //   119: iload_2
    //   120: iload_1
    //   121: iconst_0
    //   122: iconst_0
    //   123: iconst_0
    //   124: aload_0
    //   125: invokevirtual getScrollRange : ()I
    //   128: invokevirtual springBack : (IIIIII)Z
    //   131: pop
    //   132: aload_0
    //   133: iload_2
    //   134: iload_1
    //   135: iload #5
    //   137: iload #6
    //   139: invokevirtual onOverScrolled : (IIZZ)V
    //   142: iload #5
    //   144: ifne -> 157
    //   147: iload #6
    //   149: ifeq -> 154
    //   152: iconst_1
    //   153: ireturn
    //   154: iconst_0
    //   155: istore #7
    //   157: iload #7
    //   159: ireturn
  }
  
  public final boolean 恐(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getHeight : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getScrollY : ()I
    //   10: istore #10
    //   12: iload #4
    //   14: iload #10
    //   16: iadd
    //   17: istore #11
    //   19: iload_1
    //   20: bipush #33
    //   22: if_icmpne -> 31
    //   25: iconst_1
    //   26: istore #6
    //   28: goto -> 34
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: iconst_2
    //   36: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   39: astore #18
    //   41: aload #18
    //   43: invokeinterface size : ()I
    //   48: istore #12
    //   50: aconst_null
    //   51: astore #16
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #7
    //   61: iload #12
    //   63: if_icmpge -> 285
    //   66: aload #18
    //   68: iload #7
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: checkcast android/view/View
    //   78: astore #17
    //   80: aload #17
    //   82: invokevirtual getTop : ()I
    //   85: istore #9
    //   87: aload #17
    //   89: invokevirtual getBottom : ()I
    //   92: istore #13
    //   94: aload #16
    //   96: astore #15
    //   98: iload #8
    //   100: istore #5
    //   102: iload_2
    //   103: iload #13
    //   105: if_icmpge -> 268
    //   108: aload #16
    //   110: astore #15
    //   112: iload #8
    //   114: istore #5
    //   116: iload #9
    //   118: iload_3
    //   119: if_icmpge -> 268
    //   122: iload_2
    //   123: iload #9
    //   125: if_icmpge -> 140
    //   128: iload #13
    //   130: iload_3
    //   131: if_icmpge -> 140
    //   134: iconst_1
    //   135: istore #4
    //   137: goto -> 143
    //   140: iconst_0
    //   141: istore #4
    //   143: aload #16
    //   145: ifnonnull -> 159
    //   148: aload #17
    //   150: astore #15
    //   152: iload #4
    //   154: istore #5
    //   156: goto -> 268
    //   159: iload #6
    //   161: ifeq -> 174
    //   164: iload #9
    //   166: aload #16
    //   168: invokevirtual getTop : ()I
    //   171: if_icmplt -> 189
    //   174: iload #6
    //   176: ifne -> 195
    //   179: iload #13
    //   181: aload #16
    //   183: invokevirtual getBottom : ()I
    //   186: if_icmple -> 195
    //   189: iconst_1
    //   190: istore #9
    //   192: goto -> 198
    //   195: iconst_0
    //   196: istore #9
    //   198: iload #8
    //   200: ifeq -> 232
    //   203: aload #16
    //   205: astore #15
    //   207: iload #8
    //   209: istore #5
    //   211: iload #4
    //   213: ifeq -> 268
    //   216: aload #16
    //   218: astore #15
    //   220: iload #8
    //   222: istore #5
    //   224: iload #9
    //   226: ifeq -> 268
    //   229: goto -> 260
    //   232: iload #4
    //   234: ifeq -> 247
    //   237: aload #17
    //   239: astore #15
    //   241: iconst_1
    //   242: istore #5
    //   244: goto -> 268
    //   247: aload #16
    //   249: astore #15
    //   251: iload #8
    //   253: istore #5
    //   255: iload #9
    //   257: ifeq -> 268
    //   260: aload #17
    //   262: astore #15
    //   264: iload #8
    //   266: istore #5
    //   268: iload #7
    //   270: iconst_1
    //   271: iadd
    //   272: istore #7
    //   274: aload #15
    //   276: astore #16
    //   278: iload #5
    //   280: istore #8
    //   282: goto -> 59
    //   285: aload #16
    //   287: astore #15
    //   289: aload #16
    //   291: ifnonnull -> 297
    //   294: aload_0
    //   295: astore #15
    //   297: iload_2
    //   298: iload #10
    //   300: if_icmplt -> 315
    //   303: iload_3
    //   304: iload #11
    //   306: if_icmpgt -> 315
    //   309: iconst_0
    //   310: istore #14
    //   312: goto -> 341
    //   315: iload #6
    //   317: ifeq -> 328
    //   320: iload_2
    //   321: iload #10
    //   323: isub
    //   324: istore_2
    //   325: goto -> 333
    //   328: iload_3
    //   329: iload #11
    //   331: isub
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: invokevirtual 不 : (I)V
    //   338: iconst_1
    //   339: istore #14
    //   341: aload #15
    //   343: aload_0
    //   344: invokevirtual findFocus : ()Landroid/view/View;
    //   347: if_acmpeq -> 357
    //   350: aload #15
    //   352: iload_1
    //   353: invokevirtual requestFocus : (I)Z
    //   356: pop
    //   357: iload #14
    //   359: ireturn
  }
  
  public final boolean 悲(View paramView, int paramInt1, int paramInt2) {
    Rect rect = this.恐;
    paramView.getDrawingRect(rect);
    offsetDescendantRectToMyCoords(paramView, rect);
    return (rect.bottom + paramInt1 >= getScrollY() && rect.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public final int 旨(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int m = getHeight();
    int j = getScrollY();
    int k = j + m;
    int n = getVerticalFadingEdgeLength();
    i = j;
    if (paramRect.top > 0)
      i = j + n; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      j = k - n;
    } else {
      j = k;
    } 
    n = paramRect.bottom;
    if (n > j && paramRect.top > i) {
      if (paramRect.height() > m) {
        i = paramRect.top - i;
      } else {
        i = paramRect.bottom - j;
      } 
      return Math.min(i + 0, view.getBottom() + layoutParams.bottomMargin - k);
    } 
    k = bool;
    if (paramRect.top < i) {
      k = bool;
      if (n < j) {
        if (paramRect.height() > m) {
          i = 0 - j - paramRect.bottom;
        } else {
          i = 0 - i - paramRect.top;
        } 
        k = Math.max(i, -getScrollY());
      } 
    } 
    return k;
  }
  
  public final void 暑(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    寂(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public final void 淋(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.噛) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.起 = (int)paramMotionEvent.getY(i);
      this.噛 = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.帰;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public final void 熱(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    this.赤.熱(paramInt1, paramInt2, paramInt3, paramArrayOfint, null);
  }
  
  public final void 痒(int paramInt1, int paramInt2, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.怖 > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getHeight();
      int j = layoutParams.topMargin;
      int k = layoutParams.bottomMargin;
      int m = getHeight();
      int n = getPaddingTop();
      int i1 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, i + j + k - m - n - i1)));
      this.痛.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, 250);
      if (paramBoolean) {
        this.赤.美(2, 1);
      } else {
        起(1);
      } 
      this.か = getScrollY();
      rw.痒((View)this);
    } else {
      if (!this.痛.isFinished()) {
        this.痛.abortAnimation();
        起(1);
      } 
      scrollBy(paramInt1, paramInt2);
    } 
    this.怖 = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public final boolean 痛(EdgeEffect paramEdgeEffect, int paramInt) {
    if (paramInt > 0)
      return true; 
    float f1 = p31.旨(paramEdgeEffect);
    float f2 = getHeight();
    float f3 = Math.abs(-paramInt);
    float f4 = this.淋 * 0.015F;
    double d1 = Math.log((f3 * 0.35F / f4));
    double d2 = 若;
    double d3 = f4;
    return ((float)(Math.exp(d2 / (d2 - 1.0D) * d1) * d3) < f1 * f2);
  }
  
  public final void 硬(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    n5 n51 = this.ゃ;
    if (paramInt2 == 1) {
      n51.怖 = paramInt1;
    } else {
      n51.淋 = paramInt1;
    } 
    this.赤.美(2, paramInt2);
  }
  
  public final boolean 美(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && 悲(view2, i, getHeight())) {
      Rect rect = this.恐;
      view2.getDrawingRect(rect);
      offsetDescendantRectToMyCoords(view2, rect);
      不(旨(rect));
      view2.requestFocus(paramInt);
    } else {
      int j;
      if (paramInt == 33 && getScrollY() < i) {
        j = getScrollY();
      } else {
        j = i;
        if (paramInt == 130) {
          j = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            j = view2.getBottom();
            int k = layoutParams.bottomMargin;
            int m = getScrollY();
            j = Math.min(j + k - getHeight() + m - getPaddingBottom(), i);
          } 
        } 
      } 
      if (j == 0)
        return false; 
      if (paramInt != 130)
        j = -j; 
      不(j);
    } 
    if (view1 != null && view1.isFocused() && (悲(view1, 0, getHeight()) ^ true) != 0) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public final boolean 臭(MotionEvent paramMotionEvent) {
    boolean bool;
    EdgeEffect edgeEffect = this.痒;
    if (p31.旨(edgeEffect) != 0.0F) {
      p31.臭(edgeEffect, 0.0F, paramMotionEvent.getX() / getWidth());
      bool = true;
    } else {
      bool = false;
    } 
    edgeEffect = this.臭;
    if (p31.旨(edgeEffect) != 0.0F) {
      p31.臭(edgeEffect, 0.0F, 1.0F - paramMotionEvent.getX() / getWidth());
      return true;
    } 
    return bool;
  }
  
  public final boolean 苦(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    Rect rect = this.恐;
    rect.top = 0;
    rect.bottom = j;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        i = view.getBottom();
        int k = layoutParams.bottomMargin;
        rect.bottom = getPaddingBottom() + i + k;
        rect.top = rect.bottom - j;
      } 
    } 
    return 恐(paramInt, rect.top, rect.bottom);
  }
  
  public final void 起(int paramInt) {
    this.赤.旨(paramInt);
  }
  
  public final boolean 辛(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 恐 : Landroid/graphics/Rect;
    //   4: astore #7
    //   6: aload #7
    //   8: invokevirtual setEmpty : ()V
    //   11: aload_0
    //   12: invokevirtual getChildCount : ()I
    //   15: istore_2
    //   16: iconst_0
    //   17: istore #6
    //   19: iload_2
    //   20: ifle -> 79
    //   23: aload_0
    //   24: iconst_0
    //   25: invokevirtual getChildAt : (I)Landroid/view/View;
    //   28: astore #8
    //   30: aload #8
    //   32: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   35: checkcast android/widget/FrameLayout$LayoutParams
    //   38: astore #9
    //   40: aload #8
    //   42: invokevirtual getHeight : ()I
    //   45: aload #9
    //   47: getfield topMargin : I
    //   50: iadd
    //   51: aload #9
    //   53: getfield bottomMargin : I
    //   56: iadd
    //   57: aload_0
    //   58: invokevirtual getHeight : ()I
    //   61: aload_0
    //   62: invokevirtual getPaddingTop : ()I
    //   65: isub
    //   66: aload_0
    //   67: invokevirtual getPaddingBottom : ()I
    //   70: isub
    //   71: if_icmple -> 79
    //   74: iconst_1
    //   75: istore_2
    //   76: goto -> 81
    //   79: iconst_0
    //   80: istore_2
    //   81: iload_2
    //   82: ifne -> 154
    //   85: aload_0
    //   86: invokevirtual isFocused : ()Z
    //   89: ifeq -> 152
    //   92: aload_1
    //   93: invokevirtual getKeyCode : ()I
    //   96: iconst_4
    //   97: if_icmpeq -> 152
    //   100: aload_0
    //   101: invokevirtual findFocus : ()Landroid/view/View;
    //   104: astore #7
    //   106: aload #7
    //   108: astore_1
    //   109: aload #7
    //   111: aload_0
    //   112: if_acmpne -> 117
    //   115: aconst_null
    //   116: astore_1
    //   117: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   120: aload_0
    //   121: aload_1
    //   122: sipush #130
    //   125: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   128: astore_1
    //   129: aload_1
    //   130: ifnull -> 150
    //   133: aload_1
    //   134: aload_0
    //   135: if_acmpeq -> 150
    //   138: aload_1
    //   139: sipush #130
    //   142: invokevirtual requestFocus : (I)Z
    //   145: ifeq -> 150
    //   148: iconst_1
    //   149: ireturn
    //   150: iconst_0
    //   151: ireturn
    //   152: iconst_0
    //   153: ireturn
    //   154: aload_1
    //   155: invokevirtual getAction : ()I
    //   158: ifne -> 410
    //   161: aload_1
    //   162: invokevirtual getKeyCode : ()I
    //   165: istore_3
    //   166: bipush #33
    //   168: istore_2
    //   169: iload_3
    //   170: bipush #19
    //   172: if_icmpeq -> 388
    //   175: iload_3
    //   176: bipush #20
    //   178: if_icmpeq -> 365
    //   181: iload_3
    //   182: bipush #62
    //   184: if_icmpeq -> 189
    //   187: iconst_0
    //   188: ireturn
    //   189: aload_1
    //   190: invokevirtual isShiftPressed : ()Z
    //   193: ifeq -> 199
    //   196: goto -> 203
    //   199: sipush #130
    //   202: istore_2
    //   203: iload_2
    //   204: sipush #130
    //   207: if_icmpne -> 215
    //   210: iconst_1
    //   211: istore_3
    //   212: goto -> 217
    //   215: iconst_0
    //   216: istore_3
    //   217: aload_0
    //   218: invokevirtual getHeight : ()I
    //   221: istore #4
    //   223: iload_3
    //   224: ifeq -> 311
    //   227: aload #7
    //   229: aload_0
    //   230: invokevirtual getScrollY : ()I
    //   233: iload #4
    //   235: iadd
    //   236: putfield top : I
    //   239: aload_0
    //   240: invokevirtual getChildCount : ()I
    //   243: istore_3
    //   244: iload_3
    //   245: ifle -> 335
    //   248: aload_0
    //   249: iload_3
    //   250: iconst_1
    //   251: isub
    //   252: invokevirtual getChildAt : (I)Landroid/view/View;
    //   255: astore_1
    //   256: aload_1
    //   257: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   260: checkcast android/widget/FrameLayout$LayoutParams
    //   263: astore #8
    //   265: aload_1
    //   266: invokevirtual getBottom : ()I
    //   269: istore_3
    //   270: aload #8
    //   272: getfield bottomMargin : I
    //   275: istore #5
    //   277: aload_0
    //   278: invokevirtual getPaddingBottom : ()I
    //   281: iload_3
    //   282: iload #5
    //   284: iadd
    //   285: iadd
    //   286: istore_3
    //   287: aload #7
    //   289: getfield top : I
    //   292: iload #4
    //   294: iadd
    //   295: iload_3
    //   296: if_icmple -> 335
    //   299: aload #7
    //   301: iload_3
    //   302: iload #4
    //   304: isub
    //   305: putfield top : I
    //   308: goto -> 335
    //   311: aload_0
    //   312: invokevirtual getScrollY : ()I
    //   315: iload #4
    //   317: isub
    //   318: istore_3
    //   319: aload #7
    //   321: iload_3
    //   322: putfield top : I
    //   325: iload_3
    //   326: ifge -> 335
    //   329: aload #7
    //   331: iconst_0
    //   332: putfield top : I
    //   335: aload #7
    //   337: getfield top : I
    //   340: istore_3
    //   341: iload #4
    //   343: iload_3
    //   344: iadd
    //   345: istore #4
    //   347: aload #7
    //   349: iload #4
    //   351: putfield bottom : I
    //   354: aload_0
    //   355: iload_2
    //   356: iload_3
    //   357: iload #4
    //   359: invokevirtual 恐 : (III)Z
    //   362: pop
    //   363: iconst_0
    //   364: ireturn
    //   365: aload_1
    //   366: invokevirtual isAltPressed : ()Z
    //   369: ifne -> 380
    //   372: aload_0
    //   373: sipush #130
    //   376: invokevirtual 美 : (I)Z
    //   379: ireturn
    //   380: aload_0
    //   381: sipush #130
    //   384: invokevirtual 苦 : (I)Z
    //   387: ireturn
    //   388: aload_1
    //   389: invokevirtual isAltPressed : ()Z
    //   392: ifne -> 402
    //   395: aload_0
    //   396: bipush #33
    //   398: invokevirtual 美 : (I)Z
    //   401: ireturn
    //   402: aload_0
    //   403: bipush #33
    //   405: invokevirtual 苦 : (I)Z
    //   408: istore #6
    //   410: iload #6
    //   412: ireturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */