package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import androidx.versionedparcelable.CustomVersionedParcelable;
import y.お;
import y.ひ;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode ぱ = PorterDuff.Mode.SRC_IN;
  
  public String 不;
  
  public int 冷;
  
  public Object 堅;
  
  public int 寒;
  
  public PorterDuff.Mode 旨;
  
  public Parcelable 暑;
  
  public byte[] 熱;
  
  public int 硬;
  
  public ColorStateList 美;
  
  public String 辛;
  
  public IconCompat() {
    this.硬 = -1;
    this.熱 = null;
    this.暑 = null;
    this.冷 = 0;
    this.寒 = 0;
    this.美 = null;
    this.旨 = ぱ;
    this.不 = null;
  }
  
  public IconCompat(int paramInt) {
    this.熱 = null;
    this.暑 = null;
    this.冷 = 0;
    this.寒 = 0;
    this.美 = null;
    this.旨 = ぱ;
    this.不 = null;
    this.硬 = 2;
  }
  
  public static IconCompat 堅(int paramInt) {
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(0);
      iconCompat.冷 = paramInt;
      iconCompat.堅 = "";
      iconCompat.辛 = "";
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  public static Bitmap 硬(Bitmap paramBitmap) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f = i * 0.5F;
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate(-(paramBitmap.getWidth() - i) / 2.0F, -(paramBitmap.getHeight() - i) / 2.0F);
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f, f, 0.9166667F * f, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public final String toString() {
    String str;
    if (this.硬 == -1)
      return String.valueOf(this.堅); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    switch (this.硬) {
      default:
        str = "UNKNOWN";
        break;
      case 6:
        str = "URI_MASKABLE";
        break;
      case 5:
        str = "BITMAP_MASKABLE";
        break;
      case 4:
        str = "URI";
        break;
      case 3:
        str = "DATA";
        break;
      case 2:
        str = "RESOURCE";
        break;
      case 1:
        str = "BITMAP";
        break;
    } 
    stringBuilder.append(str);
    switch (this.硬) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.堅);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.冷);
        if (this.寒 != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.寒);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.辛);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(熱()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.堅).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.堅).getHeight());
        break;
    } 
    if (this.美 != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.美);
    } 
    if (this.旨 != ぱ) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.旨);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public final Uri 暑() {
    int i = this.硬;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return ひ.硬(this.堅); 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.堅); 
    StringBuilder stringBuilder = new StringBuilder("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final int 熱() {
    int i = this.硬;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Object object = this.堅;
        if (j >= 28)
          return お.硬(object); 
        try {
          return ((Integer)object.getClass().getMethod("getResId", new Class[0]).invoke(object, new Object[0])).intValue();
        } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|NoSuchMethodException illegalAccessException) {
          return 0;
        } 
      } 
    } 
    if (i == 2)
      return this.冷; 
    StringBuilder stringBuilder = new StringBuilder("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */