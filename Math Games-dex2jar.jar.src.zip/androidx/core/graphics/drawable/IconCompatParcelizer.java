package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import y.ov;
import y.pv;

public class IconCompatParcelizer {
  public static IconCompat read(ov paramov) {
    String str1;
    Parcelable parcelable2;
    byte[] arrayOfByte1;
    IconCompat iconCompat = new IconCompat();
    iconCompat.硬 = paramov.寒(iconCompat.硬, 1);
    byte[] arrayOfByte2 = iconCompat.熱;
    if (paramov.冷(2)) {
      Parcel parcel = ((pv)paramov).冷;
      int i = parcel.readInt();
      if (i < 0) {
        arrayOfByte2 = null;
      } else {
        arrayOfByte2 = new byte[i];
        parcel.readByteArray(arrayOfByte2);
      } 
    } 
    iconCompat.熱 = arrayOfByte2;
    iconCompat.暑 = paramov.美(iconCompat.暑, 3);
    iconCompat.冷 = paramov.寒(iconCompat.冷, 4);
    iconCompat.寒 = paramov.寒(iconCompat.寒, 5);
    iconCompat.美 = (ColorStateList)paramov.美((Parcelable)iconCompat.美, 6);
    String str2 = iconCompat.不;
    if (paramov.冷(7))
      str2 = ((pv)paramov).冷.readString(); 
    iconCompat.不 = str2;
    str2 = iconCompat.辛;
    if (!paramov.冷(8)) {
      str1 = str2;
    } else {
      str1 = ((pv)str1).冷.readString();
    } 
    iconCompat.辛 = str1;
    iconCompat.旨 = PorterDuff.Mode.valueOf(iconCompat.不);
    switch (iconCompat.硬) {
      default:
        return iconCompat;
      case 3:
        iconCompat.堅 = iconCompat.熱;
        return iconCompat;
      case 2:
      case 4:
      case 6:
        str1 = new String(iconCompat.熱, Charset.forName("UTF-16"));
        iconCompat.堅 = str1;
        if (iconCompat.硬 == 2 && iconCompat.辛 == null) {
          iconCompat.辛 = str1.split(":", -1)[0];
          return iconCompat;
        } 
        return iconCompat;
      case 1:
      case 5:
        parcelable2 = iconCompat.暑;
        if (parcelable2 != null) {
          iconCompat.堅 = parcelable2;
          return iconCompat;
        } 
        arrayOfByte1 = iconCompat.熱;
        iconCompat.堅 = arrayOfByte1;
        iconCompat.硬 = 3;
        iconCompat.冷 = 0;
        iconCompat.寒 = arrayOfByte1.length;
        return iconCompat;
      case -1:
        break;
    } 
    Parcelable parcelable1 = iconCompat.暑;
    if (parcelable1 != null) {
      iconCompat.堅 = parcelable1;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public static void write(IconCompat paramIconCompat, ov paramov) {
    paramov.getClass();
    paramIconCompat.不 = paramIconCompat.旨.name();
    switch (paramIconCompat.硬) {
      case 4:
      case 6:
        paramIconCompat.熱 = paramIconCompat.堅.toString().getBytes(Charset.forName("UTF-16"));
        break;
      case 3:
        paramIconCompat.熱 = (byte[])paramIconCompat.堅;
        break;
      case 2:
        paramIconCompat.熱 = ((String)paramIconCompat.堅).getBytes(Charset.forName("UTF-16"));
        break;
      case 1:
      case 5:
        paramIconCompat.暑 = (Parcelable)paramIconCompat.堅;
        break;
      case -1:
        paramIconCompat.暑 = (Parcelable)paramIconCompat.堅;
        break;
    } 
    int i = paramIconCompat.硬;
    if (-1 != i) {
      paramov.不(1);
      ((pv)paramov).冷.writeInt(i);
    } 
    byte[] arrayOfByte = paramIconCompat.熱;
    if (arrayOfByte != null) {
      paramov.不(2);
      pv pv = (pv)paramov;
      i = arrayOfByte.length;
      Parcel parcel = pv.冷;
      parcel.writeInt(i);
      parcel.writeByteArray(arrayOfByte);
    } 
    Parcelable parcelable = paramIconCompat.暑;
    if (parcelable != null) {
      paramov.不(3);
      ((pv)paramov).冷.writeParcelable(parcelable, 0);
    } 
    i = paramIconCompat.冷;
    if (i != 0) {
      paramov.不(4);
      ((pv)paramov).冷.writeInt(i);
    } 
    i = paramIconCompat.寒;
    if (i != 0) {
      paramov.不(5);
      ((pv)paramov).冷.writeInt(i);
    } 
    ColorStateList colorStateList = paramIconCompat.美;
    if (colorStateList != null) {
      paramov.不(6);
      ((pv)paramov).冷.writeParcelable((Parcelable)colorStateList, 0);
    } 
    String str2 = paramIconCompat.不;
    if (str2 != null) {
      paramov.不(7);
      ((pv)paramov).冷.writeString(str2);
    } 
    String str1 = paramIconCompat.辛;
    if (str1 != null) {
      paramov.不(8);
      ((pv)paramov).冷.writeString(str1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */