package androidx.core.app;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;

public class CoreComponentFactory extends AppComponentFactory {
  public final Activity instantiateActivity(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    return super.instantiateActivity(paramClassLoader, paramString, paramIntent);
  }
  
  public final Application instantiateApplication(ClassLoader paramClassLoader, String paramString) {
    return super.instantiateApplication(paramClassLoader, paramString);
  }
  
  public final ContentProvider instantiateProvider(ClassLoader paramClassLoader, String paramString) {
    return super.instantiateProvider(paramClassLoader, paramString);
  }
  
  public final BroadcastReceiver instantiateReceiver(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    return super.instantiateReceiver(paramClassLoader, paramString, paramIntent);
  }
  
  public final Service instantiateService(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    return super.instantiateService(paramClassLoader, paramString, paramIntent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\app\CoreComponentFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */