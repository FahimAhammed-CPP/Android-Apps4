package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import y.qv;

public final class RemoteActionCompat implements qv {
  public boolean 冷;
  
  public CharSequence 堅;
  
  public boolean 寒;
  
  public PendingIntent 暑;
  
  public CharSequence 熱;
  
  public IconCompat 硬;
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */