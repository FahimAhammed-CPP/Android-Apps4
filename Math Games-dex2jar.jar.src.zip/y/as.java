package y;

import android.util.SparseIntArray;

public final class as {
  public boolean 堅;
  
  public Object 暑;
  
  public Object 熱;
  
  public boolean 硬;
  
  public as(int paramInt) {
    this.熱 = new SparseIntArray();
    this.暑 = new SparseIntArray();
    this.硬 = false;
    this.堅 = false;
  }
  
  public final void 冷() {
    ((SparseIntArray)this.熱).clear();
  }
  
  public final int 堅(int paramInt1, int paramInt2) {
    if (!this.堅)
      return 暑(paramInt1, paramInt2); 
    int i = ((SparseIntArray)this.暑).get(paramInt1, -1);
    if (i != -1)
      return i; 
    paramInt2 = 暑(paramInt1, paramInt2);
    ((SparseIntArray)this.暑).put(paramInt1, paramInt2);
    return paramInt2;
  }
  
  public final void 寒(String... paramVarArgs) {
    if (this.硬) {
      if (paramVarArgs.length != 0) {
        this.暑 = paramVarArgs.clone();
        return;
      } 
      throw new IllegalArgumentException("At least one TLS version is required");
    } 
    throw new IllegalStateException("no TLS versions for cleartext connections");
  }
  
  public final int 暑(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 堅 : Z
    //   4: ifeq -> 163
    //   7: aload_0
    //   8: getfield 暑 : Ljava/lang/Object;
    //   11: checkcast android/util/SparseIntArray
    //   14: astore #9
    //   16: aload #9
    //   18: invokevirtual size : ()I
    //   21: iconst_1
    //   22: isub
    //   23: istore #4
    //   25: iconst_0
    //   26: istore_3
    //   27: iload_3
    //   28: iload #4
    //   30: if_icmpgt -> 69
    //   33: iload_3
    //   34: iload #4
    //   36: iadd
    //   37: iconst_1
    //   38: iushr
    //   39: istore #5
    //   41: aload #9
    //   43: iload #5
    //   45: invokevirtual keyAt : (I)I
    //   48: iload_1
    //   49: if_icmpge -> 60
    //   52: iload #5
    //   54: iconst_1
    //   55: iadd
    //   56: istore_3
    //   57: goto -> 27
    //   60: iload #5
    //   62: iconst_1
    //   63: isub
    //   64: istore #4
    //   66: goto -> 27
    //   69: iload_3
    //   70: iconst_1
    //   71: isub
    //   72: istore_3
    //   73: iload_3
    //   74: iflt -> 96
    //   77: iload_3
    //   78: aload #9
    //   80: invokevirtual size : ()I
    //   83: if_icmpge -> 96
    //   86: aload #9
    //   88: iload_3
    //   89: invokevirtual keyAt : (I)I
    //   92: istore_3
    //   93: goto -> 98
    //   96: iconst_m1
    //   97: istore_3
    //   98: iload_3
    //   99: iconst_m1
    //   100: if_icmpeq -> 163
    //   103: aload_0
    //   104: getfield 暑 : Ljava/lang/Object;
    //   107: checkcast android/util/SparseIntArray
    //   110: iload_3
    //   111: invokevirtual get : (I)I
    //   114: istore #7
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: istore #6
    //   121: aload_0
    //   122: iload_3
    //   123: iload_2
    //   124: invokevirtual 熱 : (II)I
    //   127: iconst_1
    //   128: iadd
    //   129: istore #8
    //   131: iload #8
    //   133: istore #4
    //   135: iload #7
    //   137: istore_3
    //   138: iload #6
    //   140: istore #5
    //   142: iload #8
    //   144: iload_2
    //   145: if_icmpne -> 171
    //   148: iload #7
    //   150: iconst_1
    //   151: iadd
    //   152: istore_3
    //   153: iconst_0
    //   154: istore #4
    //   156: iload #6
    //   158: istore #5
    //   160: goto -> 171
    //   163: iconst_0
    //   164: istore #4
    //   166: iconst_0
    //   167: istore_3
    //   168: iconst_0
    //   169: istore #5
    //   171: iload #5
    //   173: iload_1
    //   174: if_icmpge -> 233
    //   177: iload #4
    //   179: iconst_1
    //   180: iadd
    //   181: istore #7
    //   183: iload #7
    //   185: iload_2
    //   186: if_icmpne -> 200
    //   189: iload_3
    //   190: iconst_1
    //   191: iadd
    //   192: istore #6
    //   194: iconst_0
    //   195: istore #4
    //   197: goto -> 221
    //   200: iload #7
    //   202: istore #4
    //   204: iload_3
    //   205: istore #6
    //   207: iload #7
    //   209: iload_2
    //   210: if_icmple -> 221
    //   213: iload_3
    //   214: iconst_1
    //   215: iadd
    //   216: istore #6
    //   218: iconst_1
    //   219: istore #4
    //   221: iload #5
    //   223: iconst_1
    //   224: iadd
    //   225: istore #5
    //   227: iload #6
    //   229: istore_3
    //   230: goto -> 171
    //   233: iload_3
    //   234: istore_1
    //   235: iload #4
    //   237: iconst_1
    //   238: iadd
    //   239: iload_2
    //   240: if_icmple -> 247
    //   243: iload_3
    //   244: iconst_1
    //   245: iadd
    //   246: istore_1
    //   247: iload_1
    //   248: ireturn
  }
  
  public final int 熱(int paramInt1, int paramInt2) {
    if (!this.硬)
      return paramInt1 % paramInt2; 
    int i = ((SparseIntArray)this.熱).get(paramInt1, -1);
    if (i != -1)
      return i; 
    paramInt2 = paramInt1 % paramInt2;
    ((SparseIntArray)this.熱).put(paramInt1, paramInt2);
    return paramInt2;
  }
  
  public final void 硬(String... paramVarArgs) {
    if (this.硬) {
      if (paramVarArgs.length != 0) {
        this.熱 = paramVarArgs.clone();
        return;
      } 
      throw new IllegalArgumentException("At least one cipher suite is required");
    } 
    throw new IllegalStateException("no cipher suites for cleartext connections");
  }
  
  public final void 美(ds... paramVarArgs) {
    if (this.硬) {
      String[] arrayOfString = new String[paramVarArgs.length];
      for (int i = 0; i < paramVarArgs.length; i++)
        arrayOfString[i] = (paramVarArgs[i]).淋; 
      寒(arrayOfString);
      return;
    } 
    throw new IllegalStateException("no TLS versions for cleartext connections");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */