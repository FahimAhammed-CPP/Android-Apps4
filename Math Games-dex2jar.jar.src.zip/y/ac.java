package y;

import android.content.Context;
import android.os.Build;
import android.os.CancellationSignal;
import ocos.app.db.room.QuizRoomDatabase;

public final class ac {
  public final Object 不;
  
  public final Object 冷;
  
  public final Object 堅;
  
  public final Object 寒;
  
  public final Object 旨;
  
  public final Object 暑;
  
  public final Object 熱;
  
  public final Object 硬;
  
  public final Object 美;
  
  public final Object 辛;
  
  public final Object 硬(間 param間, rh paramrh) {
    fi fi = fi.熱("SELECT * FROM math_puzzle_quiz WHERE id = ? LIMIT 1", 1);
    ((aw2)this.熱).getClass();
    fi.壊(param間.硬(), 1);
    int i = Build.VERSION.SDK_INT;
    CancellationSignal cancellationSignal = new CancellationSignal();
    return p31.寒((kh)this.硬, false, cancellationSignal, new s21(this, fi, 4), paramrh);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */