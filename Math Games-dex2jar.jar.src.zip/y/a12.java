package y;

import android.content.pm.PackageInfo;
import android.os.Bundle;
import java.util.concurrent.Executor;

public final class a12 implements c32 {
  public final Object 冷;
  
  public final Object 堅;
  
  public final Object 暑;
  
  public final Object 熱;
  
  public a12(c61 paramc61, wq1 paramwq1, a72 parama72, String paramString) {
    this.堅 = paramc61;
    this.暑 = paramwq1;
    this.熱 = parama72;
    this.冷 = paramString;
  }
  
  public a12(yw0 paramyw0, c61 paramc61, String paramString, PackageInfo paramPackageInfo) {
    this.冷 = paramyw0;
    this.堅 = paramc61;
    this.熱 = paramString;
    this.暑 = paramPackageInfo;
  }
  
  public final oi2 暑() {
    ki2 ki2;
    k41 k41;
    sp0 sp0;
    q32 q32;
    int i = this.硬;
    Object object = this.堅;
    switch (i) {
      default:
        ki2 = td.歯(this.熱);
        q32 = q32.硬;
        object = object;
        return td.看(td.家(ki2, q32, (Executor)object), Throwable.class, new vt1(19, this), (Executor)object);
      case 5:
        object = object;
        k41 = new k41(21, this);
        return ((oh2)object).堅(k41);
      case 4:
        object = object;
        k41 = new k41(18, this);
        return ((oh2)object).堅(k41);
      case 3:
        object = object;
        k41 = new k41(14, this);
        return ((oh2)object).堅(k41);
      case 2:
        object = object;
        k41 = new k41(10, this);
        return ((oh2)object).堅(k41);
      case 1:
        sp0 = xp0.官;
        if (!md2.硬((String)ml0.暑.熱.硬(sp0))) {
          g12 g12 = (g12)this.冷;
          if (!g12.硬.get() && ((ns1)this.暑).堅) {
            g12.硬.set(true);
            object = object;
            k41 k411 = new k41(9, this);
            return ((oh2)object).堅(k411);
          } 
        } 
        return td.歯(new f12(new Bundle()));
      case 0:
        break;
    } 
    return td.家(((c32)object).暑(), new x70(7, this), d61.寒);
  }
  
  public final int 硬() {
    switch (this.硬) {
      default:
        return 41;
      case 5:
        return 26;
      case 4:
        return 22;
      case 3:
        return 17;
      case 2:
        return 9;
      case 1:
        return 1;
      case 0:
        break;
    } 
    return 7;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a12.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */