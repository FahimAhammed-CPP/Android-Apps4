package y;

public final class a8 extends ik {
  public final String toString() {
    return "SUCCESS";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */