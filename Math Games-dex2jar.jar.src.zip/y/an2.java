package y;

import com.google.android.gms.internal.ads.草;
import com.google.android.gms.internal.ads.飛;

public final class an2 extends xp2 {}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\an2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */