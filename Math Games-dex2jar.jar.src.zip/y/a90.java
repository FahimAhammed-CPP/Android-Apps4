package y;

import java.util.Arrays;
import java.util.Collections;

public final class a90 implements e90 {
  public static final byte[] 起 = new byte[] { 73, 68, 51 };
  
  public boolean ぱ;
  
  public int 不 = 0;
  
  public String 冷;
  
  public final n40 堅 = new n40(7, new byte[7]);
  
  public int 嬉 = -1;
  
  public int 寂;
  
  public l40 寒;
  
  public long 怖 = -9223372036854775807L;
  
  public int 恐;
  
  public int 悲 = -1;
  
  public int 旨 = 0;
  
  public final String 暑;
  
  public boolean 淋;
  
  public final tl0 熱 = new tl0(Arrays.copyOf(起, 10), 1);
  
  public l40 痒;
  
  public long 痛 = -9223372036854775807L;
  
  public final boolean 硬;
  
  public l40 美;
  
  public long 臭;
  
  public boolean 苦;
  
  public int 辛 = 256;
  
  public a90(boolean paramBoolean, String paramString) {
    this.硬 = paramBoolean;
    this.暑 = paramString;
  }
  
  public final void 冷(tl0 paramtl0) {
    this.寒.getClass();
    int i = yx1.硬;
    while (paramtl0.旨() > 0) {
      int j = this.旨;
      i = 1;
      tl0 tl01 = this.熱;
      n40 n401 = this.堅;
      if (j != 0) {
        l40 l401;
        if (j != 1) {
          r70 r70;
          if (j != 2) {
            if (j != 3) {
              i = Math.min(paramtl0.旨(), this.恐 - this.不);
              this.痒.堅(i, paramtl0);
              i = this.不 + i;
              this.不 = i;
              j = this.恐;
              if (i == j) {
                long l = this.痛;
                if (l != -9223372036854775807L) {
                  this.痒.寒(l, 1, j, 0, null);
                  this.痛 += this.臭;
                } 
                this.旨 = 0;
                this.不 = 0;
                this.辛 = 256;
              } 
              continue;
            } 
            if (true != this.ぱ) {
              i = 5;
            } else {
              i = 7;
            } 
            byte[] arrayOfByte2 = n401.堅;
            j = Math.min(paramtl0.旨(), i - this.不);
            paramtl0.硬(arrayOfByte2, this.不, j);
            j = this.不 + j;
            this.不 = j;
            if (j == i) {
              i = 1;
            } else {
              i = 0;
            } 
            if (i != 0) {
              n401.嬉(0);
              if (!this.淋) {
                if (n401.冷(2) + 1 != 2)
                  eq1.暑(); 
                n401.淋(5);
                i = n401.冷(3);
                j = this.悲;
                arrayOfByte2 = new byte[2];
                arrayOfByte2[0] = (byte)(j >> 1 & 0x7 | 0x10);
                arrayOfByte2[1] = (byte)(i << 3 & 0x78 | j << 7 & 0x80);
                맥 맥 = p31.ㅌ(new n40(2, arrayOfByte2), false);
                j60 j60 = new j60();
                j60.硬 = this.冷;
                j60.辛 = "audio/mp4a-latm";
                j60.美 = (String)맥.暑;
                j60.興 = 맥.熱;
                j60.産 = 맥.堅;
                j60.苦 = Collections.singletonList(arrayOfByte2);
                j60.熱 = this.暑;
                r70 = new r70(j60);
                this.怖 = 1024000000L / r70.死;
                this.寒.暑(r70);
                this.淋 = true;
              } else {
                n401.淋(10);
              } 
              n401.淋(4);
              j = n401.冷(13) - 7;
              i = j;
              if (this.ぱ)
                i = j - 2; 
              l401 = this.寒;
              long l = this.怖;
              this.旨 = 4;
              this.不 = 0;
              this.痒 = l401;
              this.臭 = l;
              this.恐 = i;
            } 
            continue;
          } 
          byte[] arrayOfByte1 = ((tl0)r70).堅;
          j = Math.min(paramtl0.旨(), 10 - this.不);
          paramtl0.硬(arrayOfByte1, this.不, j);
          j = this.不 + j;
          this.不 = j;
          if (j != 10)
            i = 0; 
          if (i != 0) {
            this.美.堅(10, (tl0)r70);
            r70.冷(6);
            l401 = this.美;
            i = r70.怖();
            this.旨 = 4;
            this.不 = 10;
            this.痒 = l401;
            this.臭 = 0L;
            this.恐 = i + 10;
          } 
          continue;
        } 
        if (paramtl0.旨() != 0) {
          ((n40)l401).堅[0] = paramtl0.堅[paramtl0.辛()];
          l401.嬉(2);
          i = l401.冷(4);
          j = this.悲;
          if (j != -1 && i != j) {
            this.苦 = false;
            this.旨 = 0;
            this.不 = 0;
            this.辛 = 256;
            continue;
          } 
          if (!this.苦) {
            this.苦 = true;
            this.嬉 = this.寂;
            this.悲 = i;
          } 
          this.旨 = 3;
          this.不 = 0;
        } 
        continue;
      } 
      byte[] arrayOfByte = paramtl0.堅;
      i = paramtl0.辛();
      int k = paramtl0.ぱ();
      while (true) {
        this.辛 = 256;
        i = j - 1;
      } 
      continue;
      paramtl0.冷(i);
    } 
  }
  
  public final void 堅() {
    this.痛 = -9223372036854775807L;
    this.苦 = false;
    this.旨 = 0;
    this.不 = 0;
    this.辛 = 256;
  }
  
  public final void 寒(y53 paramy53, ca0 paramca0) {
    paramca0.硬();
    paramca0.堅();
    this.冷 = paramca0.冷;
    paramca0.堅();
    l40 l401 = paramy53.痛(paramca0.暑, 1);
    this.寒 = l401;
    this.痒 = l401;
    if (this.硬) {
      paramca0.硬();
      paramca0.堅();
      l40 l402 = paramy53.痛(paramca0.暑, 5);
      this.美 = l402;
      j60 j60 = new j60();
      paramca0.堅();
      j60.硬 = paramca0.冷;
      j60.辛 = "application/id3";
      l402.暑(new r70(j60));
      return;
    } 
    this.美 = new v53();
  }
  
  public final void 熱() {}
  
  public final void 美(int paramInt, long paramLong) {
    if (paramLong != -9223372036854775807L)
      this.痛 = paramLong; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a90.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */