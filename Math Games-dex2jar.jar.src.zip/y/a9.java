package y;

import com.google.android.gms.internal.ads.private;
import com.google.android.gms.internal.ads.鰺;

public final class a9 implements bo0, xm1 {
  public int 怖;
  
  public boolean 淋;
  
  public final void 旨(Object paramObject) {
    int i = this.怖;
    boolean bool = this.淋;
    ((pv2)paramObject).壊(i, bool);
  }
  
  public final void 臭(vo0 paramvo0) {
    boolean bool = this.淋;
    int i = this.怖;
    int j = o91.통;
    pp0 pp0 = 鰺.興();
    if (((鰺)pp0.怖).帰() != bool) {
      pp0.冷();
      鰺.死((鰺)pp0.怖, bool);
    } 
    pp0.冷();
    鰺.壊((鰺)pp0.怖, i);
    鰺 鰺 = (鰺)pp0.熱();
    paramvo0.冷();
    private.触((private)paramvo0.怖, 鰺);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a9.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */