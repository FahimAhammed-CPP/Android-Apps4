package y;

public final class a32 implements c32 {
  public final boolean 硬;
  
  public a32(a62 parama62) {
    boolean bool;
    if (parama62 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.硬 = bool;
  }
  
  public final oi2 暑() {
    Object object;
    if (this.硬) {
      object = z22.硬;
    } else {
      object = null;
    } 
    return td.歯(object);
  }
  
  public final int 硬() {
    return 36;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a32.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */