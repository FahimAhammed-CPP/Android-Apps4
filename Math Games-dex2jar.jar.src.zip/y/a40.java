package y;

public final class a40 implements i40 {
  public final long[] 堅;
  
  public final boolean 暑;
  
  public final long 熱;
  
  public final long[] 硬;
  
  public a40(long paramLong, long[] paramArrayOflong1, long[] paramArrayOflong2) {
    boolean bool;
    int j = paramArrayOflong1.length;
    int i = paramArrayOflong2.length;
    if (j == i) {
      bool = true;
    } else {
      bool = false;
    } 
    ik.歯(bool);
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.暑 = bool;
    if (bool && paramArrayOflong2[0] > 0L) {
      j = i + 1;
      long[] arrayOfLong1 = new long[j];
      this.硬 = arrayOfLong1;
      long[] arrayOfLong2 = new long[j];
      this.堅 = arrayOfLong2;
      System.arraycopy(paramArrayOflong1, 0, arrayOfLong1, 1, i);
      System.arraycopy(paramArrayOflong2, 0, arrayOfLong2, 1, i);
    } else {
      this.硬 = paramArrayOflong1;
      this.堅 = paramArrayOflong2;
    } 
    this.熱 = paramLong;
  }
  
  public final g40 不(long paramLong) {
    if (!this.暑) {
      j40 j401 = j40.熱;
      return new g40(j401, j401);
    } 
    long[] arrayOfLong1 = this.堅;
    int i = yx1.苦(arrayOfLong1, paramLong, true);
    long l = arrayOfLong1[i];
    long[] arrayOfLong2 = this.硬;
    j40 j40 = new j40(l, arrayOfLong2[i]);
    return (l == paramLong || i == arrayOfLong1.length - 1) ? new g40(j40, j40) : new g40(j40, new j40(arrayOfLong1[++i], arrayOfLong2[i]));
  }
  
  public final long 堅() {
    return this.熱;
  }
  
  public final boolean 寒() {
    return this.暑;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */