package y;

import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class al0 extends Thread {
  public final long 怖;
  
  public final CountDownLatch 恐;
  
  public final WeakReference 淋;
  
  public boolean 痛;
  
  public al0(ヒ paramヒ, long paramLong) {
    this.淋 = new WeakReference<ヒ>(paramヒ);
    this.怖 = paramLong;
    this.恐 = new CountDownLatch(1);
    this.痛 = false;
    start();
  }
  
  public final void run() {
    WeakReference<ヒ> weakReference = this.淋;
    try {
      if (!this.恐.await(this.怖, TimeUnit.MILLISECONDS)) {
        ヒ ヒ = weakReference.get();
        if (ヒ != null) {
          ヒ.熱();
          this.痛 = true;
        } 
      } 
      return;
    } catch (InterruptedException interruptedException) {
      ヒ ヒ = weakReference.get();
      if (ヒ != null) {
        ヒ.熱();
        this.痛 = true;
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\al0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */