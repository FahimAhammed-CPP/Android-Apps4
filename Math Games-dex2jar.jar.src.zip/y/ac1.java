package y;

import java.util.HashMap;
import java.util.Map;

public final class ac1 {
  public Map 堅;
  
  public final Map 硬 = new HashMap<Object, Object>();
  
  public final Map 硬() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 堅 : Ljava/util/Map;
    //   6: ifnonnull -> 27
    //   9: aload_0
    //   10: new java/util/HashMap
    //   13: dup
    //   14: aload_0
    //   15: getfield 硬 : Ljava/util/Map;
    //   18: invokespecial <init> : (Ljava/util/Map;)V
    //   21: invokestatic unmodifiableMap : (Ljava/util/Map;)Ljava/util/Map;
    //   24: putfield 堅 : Ljava/util/Map;
    //   27: aload_0
    //   28: getfield 堅 : Ljava/util/Map;
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: areturn
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	36	finally
    //   27	32	36	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ac1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */