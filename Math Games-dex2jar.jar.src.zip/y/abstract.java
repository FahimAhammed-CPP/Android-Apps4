package y;

public final class abstract {
  public final Throwable 硬;
  
  static {
    new abstract(new private(0));
  }
  
  public abstract(Throwable paramThrowable) {
    boolean bool = protected.痛;
    paramThrowable.getClass();
    this.硬 = paramThrowable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\abstract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */