package y;

public abstract class am {
  public static final String 堅;
  
  public static final String 熱;
  
  public static final String 硬 = 年.起(-364588970598L);
  
  static {
    年.起(-450488316518L);
    年.起(-484848054886L);
    年.起(-510617858662L);
    堅 = 年.起(-609402106470L);
    熱 = 年.起(-699596419686L);
    年.起(-901459882598L);
    年.起(-974474326630L);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */