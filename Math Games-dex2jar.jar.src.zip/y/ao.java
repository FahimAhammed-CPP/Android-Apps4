package y;

public final class ao extends 각 {
  public final String 堅;
  
  public final Integer 暑;
  
  public final Long 熱;
  
  public ao(String paramString, Long paramLong, Integer paramInteger) {
    this.堅 = paramString;
    this.熱 = paramLong;
    this.暑 = paramInteger;
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ao))
      return false; 
    paramObject = paramObject;
    String str = ((ao)paramObject).堅;
    return !ik.熱(this.堅, str) ? false : (!ik.熱(this.熱, ((ao)paramObject).熱) ? false : (!!ik.熱(this.暑, ((ao)paramObject).暑)));
  }
  
  public final int hashCode() {
    int i;
    int j;
    int k = 0;
    String str = this.堅;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    Long long_ = this.熱;
    if (long_ == null) {
      j = 0;
    } else {
      j = long_.hashCode();
    } 
    Integer integer = this.暑;
    if (integer != null)
      k = integer.hashCode(); 
    return (i * 31 + j) * 31 + k;
  }
  
  public final String toString() {
    int i = nf.硬;
    return super.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */