package y;

import android.content.Context;
import java.util.concurrent.Executor;

public final class ae1 implements dt2 {
  public final kt2 堅;
  
  public final Object 暑;
  
  public final kt2 熱;
  
  public final Object 暑() {
    bm1 bm1;
    int i = this.硬;
    kt2 kt21 = this.熱;
    kt2 kt22 = this.堅;
    switch (i) {
      default:
        return new uk1(new zp1(((ln1)((aq1)kt22).硬).硬()), (Executor)kt21.暑());
      case 2:
        bm1 = (bm1)kt22.暑();
        c61 = d61.硬;
        il0.死(c61);
        return new uk1(bm1, c61);
      case 1:
        return new bl0((Context)c61.暑(), (y31)bm1.暑());
      case 0:
        break;
    } 
    gf1 gf1 = (gf1)c61.暑();
    c61 c61 = d61.硬;
    il0.死(c61);
    return new uk1(gf1, c61);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ae1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */