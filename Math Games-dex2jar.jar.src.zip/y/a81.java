package y;

import java.util.ArrayList;
import java.util.Iterator;

public final class a81 implements Iterable {
  public final ArrayList 淋 = new ArrayList();
  
  public final Iterator iterator() {
    return this.淋.iterator();
  }
  
  public final boolean 熱(z61 paramz61) {
    ArrayList<z71> arrayList = new ArrayList();
    for (z71 z71 : this) {
      if (z71.堅 == paramz61)
        arrayList.add(z71); 
    } 
    if (arrayList.isEmpty())
      return false; 
    Iterator<z71> iterator = arrayList.iterator();
    while (iterator.hasNext())
      ((z71)iterator.next()).熱.旨(); 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a81.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */