package y;

import android.os.IBinder;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;

public final class as0 extends mf0 implements cs0 {
  public as0(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.formats.client.IAttributionInfo", 0);
  }
  
  public final String 冷() {
    Parcel parcel = ㅌ(あ(), 2);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final List 寒() {
    Parcel parcel = ㅌ(あ(), 3);
    ArrayList arrayList = parcel.readArrayList(of0.硬);
    parcel.recycle();
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\as0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */