package y;

public final class ai extends 테 {
  public int 臭;
  
  public ai(ei paramei, 탱 param탱) {
    super(param탱);
  }
  
  public final Object 不(Object paramObject) {
    this.痛 = paramObject;
    this.臭 |= Integer.MIN_VALUE;
    return this.痒.寒(null, this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */