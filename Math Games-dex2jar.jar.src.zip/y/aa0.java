package y;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import java.util.Collections;
import java.util.List;

public final class aa0 implements w53 {
  public int ぱ;
  
  public c50 不;
  
  public final SparseArray 冷;
  
  public final tl0 堅;
  
  public boolean 嬉;
  
  public int 寂;
  
  public final SparseBooleanArray 寒;
  
  public boolean 悲;
  
  public final s90 旨;
  
  public final mz1 暑;
  
  public final SparseIntArray 熱;
  
  public final List 硬;
  
  public final SparseBooleanArray 美;
  
  public boolean 苦;
  
  public y53 辛;
  
  public aa0() {
    this.暑 = mz11;
    this.硬 = Collections.singletonList(ex1);
    this.堅 = new tl0(0, new byte[9400]);
    SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
    this.寒 = sparseBooleanArray;
    this.美 = new SparseBooleanArray();
    SparseArray sparseArray2 = new SparseArray();
    this.冷 = sparseArray2;
    this.熱 = new SparseIntArray();
    this.旨 = new s90(0);
    this.辛 = y53.悲;
    this.寂 = -1;
    sparseBooleanArray.clear();
    sparseArray2.clear();
    SparseArray sparseArray1 = new SparseArray();
    int j = sparseArray1.size();
    for (int i = 0; i < j; i++)
      this.冷.put(sparseArray1.keyAt(i), sparseArray1.valueAt(i)); 
    this.冷.put(0, new y90(new dm1(this)));
  }
  
  public final void 冷(y53 paramy53) {
    this.辛 = paramy53;
  }
  
  public final int 旨(x53 paramx53, f40 paramf40) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface 美 : ()J
    //   6: lstore #12
    //   8: aload_0
    //   9: getfield 苦 : Z
    //   12: istore #14
    //   14: iconst_1
    //   15: istore_3
    //   16: iload #14
    //   18: ifeq -> 771
    //   21: ldc2_w -9223372036854775807
    //   24: lstore #10
    //   26: aload_0
    //   27: getfield 旨 : Ly/s90;
    //   30: astore #15
    //   32: lload #12
    //   34: ldc2_w -1
    //   37: lcmp
    //   38: ifeq -> 594
    //   41: aload #15
    //   43: getfield 暑 : Z
    //   46: ifeq -> 52
    //   49: goto -> 594
    //   52: aload_0
    //   53: getfield 寂 : I
    //   56: istore #7
    //   58: iload #7
    //   60: ifgt -> 71
    //   63: aload #15
    //   65: aload_1
    //   66: invokevirtual 熱 : (Ly/x53;)V
    //   69: iconst_0
    //   70: ireturn
    //   71: aload #15
    //   73: getfield 寒 : Z
    //   76: istore #14
    //   78: aload #15
    //   80: getfield 熱 : Ly/tl0;
    //   83: astore #16
    //   85: iload #14
    //   87: ifne -> 331
    //   90: aload_1
    //   91: invokeinterface 美 : ()J
    //   96: lstore #12
    //   98: ldc2_w 112800
    //   101: lload #12
    //   103: invokestatic min : (JJ)J
    //   106: l2i
    //   107: istore #4
    //   109: lload #12
    //   111: iload #4
    //   113: i2l
    //   114: lsub
    //   115: lstore #12
    //   117: aload_1
    //   118: invokeinterface 不 : ()J
    //   123: lload #12
    //   125: lcmp
    //   126: ifeq -> 138
    //   129: aload_2
    //   130: lload #12
    //   132: putfield 硬 : J
    //   135: goto -> 507
    //   138: aload #16
    //   140: iload #4
    //   142: invokevirtual 堅 : (I)V
    //   145: aload_1
    //   146: invokeinterface 苦 : ()V
    //   151: aload #16
    //   153: getfield 堅 : [B
    //   156: astore_2
    //   157: aload_1
    //   158: checkcast y/q53
    //   161: aload_2
    //   162: iconst_0
    //   163: iload #4
    //   165: iconst_0
    //   166: invokevirtual 恐 : ([BIIZ)Z
    //   169: pop
    //   170: aload #16
    //   172: invokevirtual 辛 : ()I
    //   175: istore #8
    //   177: aload #16
    //   179: invokevirtual ぱ : ()I
    //   182: istore #9
    //   184: iload #9
    //   186: sipush #188
    //   189: isub
    //   190: istore #4
    //   192: lload #10
    //   194: lstore #12
    //   196: iload #4
    //   198: iload #8
    //   200: if_icmplt -> 315
    //   203: aload #16
    //   205: getfield 堅 : [B
    //   208: astore_1
    //   209: bipush #-4
    //   211: istore #5
    //   213: iconst_0
    //   214: istore_3
    //   215: iload #5
    //   217: iconst_4
    //   218: if_icmpgt -> 306
    //   221: iload #5
    //   223: sipush #188
    //   226: imul
    //   227: iload #4
    //   229: iadd
    //   230: istore #6
    //   232: iload #6
    //   234: iload #8
    //   236: if_icmplt -> 295
    //   239: iload #6
    //   241: iload #9
    //   243: if_icmpge -> 295
    //   246: aload_1
    //   247: iload #6
    //   249: baload
    //   250: bipush #71
    //   252: if_icmpeq -> 258
    //   255: goto -> 295
    //   258: iload_3
    //   259: iconst_1
    //   260: iadd
    //   261: istore #6
    //   263: iload #6
    //   265: istore_3
    //   266: iload #6
    //   268: iconst_5
    //   269: if_icmpne -> 297
    //   272: aload #16
    //   274: iload #4
    //   276: iload #7
    //   278: invokestatic 쾌 : (Ly/tl0;II)J
    //   281: lstore #12
    //   283: lload #12
    //   285: ldc2_w -9223372036854775807
    //   288: lcmp
    //   289: ifeq -> 306
    //   292: goto -> 315
    //   295: iconst_0
    //   296: istore_3
    //   297: iload #5
    //   299: iconst_1
    //   300: iadd
    //   301: istore #5
    //   303: goto -> 215
    //   306: iload #4
    //   308: iconst_1
    //   309: isub
    //   310: istore #4
    //   312: goto -> 192
    //   315: aload #15
    //   317: lload #12
    //   319: putfield 旨 : J
    //   322: aload #15
    //   324: iconst_1
    //   325: putfield 寒 : Z
    //   328: goto -> 505
    //   331: aload #15
    //   333: getfield 旨 : J
    //   336: ldc2_w -9223372036854775807
    //   339: lcmp
    //   340: ifne -> 351
    //   343: aload #15
    //   345: aload_1
    //   346: invokevirtual 熱 : (Ly/x53;)V
    //   349: iconst_0
    //   350: ireturn
    //   351: aload #15
    //   353: getfield 冷 : Z
    //   356: ifne -> 509
    //   359: ldc2_w 112800
    //   362: aload_1
    //   363: invokeinterface 美 : ()J
    //   368: invokestatic min : (JJ)J
    //   371: l2i
    //   372: istore #4
    //   374: aload_1
    //   375: invokeinterface 不 : ()J
    //   380: lconst_0
    //   381: lcmp
    //   382: ifeq -> 393
    //   385: aload_2
    //   386: lconst_0
    //   387: putfield 硬 : J
    //   390: goto -> 507
    //   393: aload #16
    //   395: iload #4
    //   397: invokevirtual 堅 : (I)V
    //   400: aload_1
    //   401: invokeinterface 苦 : ()V
    //   406: aload #16
    //   408: getfield 堅 : [B
    //   411: astore_2
    //   412: aload_1
    //   413: checkcast y/q53
    //   416: aload_2
    //   417: iconst_0
    //   418: iload #4
    //   420: iconst_0
    //   421: invokevirtual 恐 : ([BIIZ)Z
    //   424: pop
    //   425: aload #16
    //   427: invokevirtual 辛 : ()I
    //   430: istore_3
    //   431: aload #16
    //   433: invokevirtual ぱ : ()I
    //   436: istore #4
    //   438: lload #10
    //   440: lstore #12
    //   442: iload_3
    //   443: iload #4
    //   445: if_icmpge -> 492
    //   448: aload #16
    //   450: getfield 堅 : [B
    //   453: iload_3
    //   454: baload
    //   455: bipush #71
    //   457: if_icmpeq -> 463
    //   460: goto -> 485
    //   463: aload #16
    //   465: iload_3
    //   466: iload #7
    //   468: invokestatic 쾌 : (Ly/tl0;II)J
    //   471: lstore #12
    //   473: lload #12
    //   475: ldc2_w -9223372036854775807
    //   478: lcmp
    //   479: ifeq -> 485
    //   482: goto -> 492
    //   485: iload_3
    //   486: iconst_1
    //   487: iadd
    //   488: istore_3
    //   489: goto -> 438
    //   492: aload #15
    //   494: lload #12
    //   496: putfield 美 : J
    //   499: aload #15
    //   501: iconst_1
    //   502: putfield 冷 : Z
    //   505: iconst_0
    //   506: istore_3
    //   507: iload_3
    //   508: ireturn
    //   509: aload #15
    //   511: getfield 美 : J
    //   514: lstore #10
    //   516: lload #10
    //   518: ldc2_w -9223372036854775807
    //   521: lcmp
    //   522: ifne -> 533
    //   525: aload #15
    //   527: aload_1
    //   528: invokevirtual 熱 : (Ly/x53;)V
    //   531: iconst_0
    //   532: ireturn
    //   533: aload #15
    //   535: getfield 堅 : Ly/ex1;
    //   538: astore_2
    //   539: aload_2
    //   540: lload #10
    //   542: invokevirtual 堅 : (J)J
    //   545: lstore #10
    //   547: aload_2
    //   548: aload #15
    //   550: getfield 旨 : J
    //   553: invokevirtual 堅 : (J)J
    //   556: lload #10
    //   558: lsub
    //   559: lstore #10
    //   561: aload #15
    //   563: lload #10
    //   565: putfield 不 : J
    //   568: lload #10
    //   570: lconst_0
    //   571: lcmp
    //   572: ifge -> 586
    //   575: invokestatic 暑 : ()V
    //   578: aload #15
    //   580: ldc2_w -9223372036854775807
    //   583: putfield 不 : J
    //   586: aload #15
    //   588: aload_1
    //   589: invokevirtual 熱 : (Ly/x53;)V
    //   592: iconst_0
    //   593: ireturn
    //   594: aload_0
    //   595: getfield 嬉 : Z
    //   598: ifne -> 691
    //   601: aload_0
    //   602: iconst_1
    //   603: putfield 嬉 : Z
    //   606: aload #15
    //   608: invokevirtual 硬 : ()J
    //   611: ldc2_w -9223372036854775807
    //   614: lcmp
    //   615: ifeq -> 666
    //   618: new y/c50
    //   621: dup
    //   622: aload #15
    //   624: getfield 堅 : Ly/ex1;
    //   627: aload #15
    //   629: invokevirtual 硬 : ()J
    //   632: lload #12
    //   634: aload_0
    //   635: getfield 寂 : I
    //   638: invokespecial <init> : (Ly/ex1;JJI)V
    //   641: astore #15
    //   643: aload_0
    //   644: aload #15
    //   646: putfield 不 : Ly/c50;
    //   649: aload_0
    //   650: getfield 辛 : Ly/y53;
    //   653: aload #15
    //   655: getfield 硬 : Ly/l53;
    //   658: invokeinterface 淋 : (Ly/i40;)V
    //   663: goto -> 691
    //   666: aload_0
    //   667: getfield 辛 : Ly/y53;
    //   670: new y/h40
    //   673: dup
    //   674: aload #15
    //   676: invokevirtual 硬 : ()J
    //   679: lconst_0
    //   680: invokespecial <init> : (JJ)V
    //   683: invokeinterface 淋 : (Ly/i40;)V
    //   688: goto -> 691
    //   691: aload_0
    //   692: getfield 悲 : Z
    //   695: ifeq -> 730
    //   698: aload_0
    //   699: iconst_0
    //   700: putfield 悲 : Z
    //   703: aload_0
    //   704: lconst_0
    //   705: lconst_0
    //   706: invokevirtual 硬 : (JJ)V
    //   709: aload_1
    //   710: invokeinterface 不 : ()J
    //   715: lconst_0
    //   716: lcmp
    //   717: ifne -> 723
    //   720: goto -> 730
    //   723: aload_2
    //   724: lconst_0
    //   725: putfield 硬 : J
    //   728: iconst_1
    //   729: ireturn
    //   730: aload_0
    //   731: getfield 不 : Ly/c50;
    //   734: astore #15
    //   736: aload #15
    //   738: ifnull -> 771
    //   741: aload #15
    //   743: getfield 熱 : Ly/ke0;
    //   746: ifnull -> 754
    //   749: iconst_1
    //   750: istore_3
    //   751: goto -> 756
    //   754: iconst_0
    //   755: istore_3
    //   756: iload_3
    //   757: ifne -> 763
    //   760: goto -> 771
    //   763: aload #15
    //   765: aload_1
    //   766: aload_2
    //   767: invokevirtual 硬 : (Ly/x53;Ly/f40;)I
    //   770: ireturn
    //   771: aload_0
    //   772: getfield 堅 : Ly/tl0;
    //   775: astore_2
    //   776: aload_2
    //   777: getfield 堅 : [B
    //   780: astore #15
    //   782: sipush #9400
    //   785: aload_2
    //   786: invokevirtual 辛 : ()I
    //   789: isub
    //   790: sipush #188
    //   793: if_icmplt -> 799
    //   796: goto -> 828
    //   799: aload_2
    //   800: invokevirtual 旨 : ()I
    //   803: istore_3
    //   804: iload_3
    //   805: ifle -> 821
    //   808: aload #15
    //   810: aload_2
    //   811: invokevirtual 辛 : ()I
    //   814: aload #15
    //   816: iconst_0
    //   817: iload_3
    //   818: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   821: aload_2
    //   822: iload_3
    //   823: aload #15
    //   825: invokevirtual 熱 : (I[B)V
    //   828: aload_2
    //   829: invokevirtual 旨 : ()I
    //   832: sipush #188
    //   835: if_icmpge -> 878
    //   838: aload_2
    //   839: invokevirtual ぱ : ()I
    //   842: istore_3
    //   843: aload_1
    //   844: aload #15
    //   846: iload_3
    //   847: sipush #9400
    //   850: iload_3
    //   851: isub
    //   852: invokeinterface 暑 : ([BII)I
    //   857: istore #4
    //   859: iload #4
    //   861: iconst_m1
    //   862: if_icmpne -> 867
    //   865: iconst_m1
    //   866: ireturn
    //   867: aload_2
    //   868: iload_3
    //   869: iload #4
    //   871: iadd
    //   872: invokevirtual 暑 : (I)V
    //   875: goto -> 828
    //   878: aload_2
    //   879: invokevirtual 辛 : ()I
    //   882: istore_3
    //   883: aload_2
    //   884: invokevirtual ぱ : ()I
    //   887: istore #4
    //   889: aload_2
    //   890: getfield 堅 : [B
    //   893: astore_1
    //   894: iload_3
    //   895: iload #4
    //   897: if_icmpge -> 915
    //   900: aload_1
    //   901: iload_3
    //   902: baload
    //   903: bipush #71
    //   905: if_icmpeq -> 915
    //   908: iload_3
    //   909: iconst_1
    //   910: iadd
    //   911: istore_3
    //   912: goto -> 894
    //   915: aload_2
    //   916: iload_3
    //   917: invokevirtual 冷 : (I)V
    //   920: iload_3
    //   921: sipush #188
    //   924: iadd
    //   925: istore #5
    //   927: aload_2
    //   928: invokevirtual ぱ : ()I
    //   931: istore #6
    //   933: iload #5
    //   935: iload #6
    //   937: if_icmple -> 942
    //   940: iconst_0
    //   941: ireturn
    //   942: aload_2
    //   943: invokevirtual 苦 : ()I
    //   946: istore #8
    //   948: ldc_w 8388608
    //   951: iload #8
    //   953: iand
    //   954: ifeq -> 965
    //   957: aload_2
    //   958: iload #5
    //   960: invokevirtual 冷 : (I)V
    //   963: iconst_0
    //   964: ireturn
    //   965: ldc_w 4194304
    //   968: iload #8
    //   970: iand
    //   971: ifeq -> 979
    //   974: iconst_1
    //   975: istore_3
    //   976: goto -> 981
    //   979: iconst_0
    //   980: istore_3
    //   981: iload #8
    //   983: bipush #8
    //   985: ishr
    //   986: sipush #8191
    //   989: iand
    //   990: istore #7
    //   992: iload #8
    //   994: bipush #16
    //   996: iand
    //   997: ifeq -> 1016
    //   1000: aload_0
    //   1001: getfield 冷 : Landroid/util/SparseArray;
    //   1004: iload #7
    //   1006: invokevirtual get : (I)Ljava/lang/Object;
    //   1009: checkcast y/da0
    //   1012: astore_1
    //   1013: goto -> 1018
    //   1016: aconst_null
    //   1017: astore_1
    //   1018: aload_1
    //   1019: ifnonnull -> 1030
    //   1022: aload_2
    //   1023: iload #5
    //   1025: invokevirtual 冷 : (I)V
    //   1028: iconst_0
    //   1029: ireturn
    //   1030: iload #8
    //   1032: bipush #15
    //   1034: iand
    //   1035: istore #4
    //   1037: aload_0
    //   1038: getfield 熱 : Landroid/util/SparseIntArray;
    //   1041: astore #15
    //   1043: aload #15
    //   1045: iload #7
    //   1047: iload #4
    //   1049: iconst_1
    //   1050: isub
    //   1051: invokevirtual get : (II)I
    //   1054: istore #9
    //   1056: aload #15
    //   1058: iload #7
    //   1060: iload #4
    //   1062: invokevirtual put : (II)V
    //   1065: iload #9
    //   1067: iload #4
    //   1069: if_icmpne -> 1080
    //   1072: aload_2
    //   1073: iload #5
    //   1075: invokevirtual 冷 : (I)V
    //   1078: iconst_0
    //   1079: ireturn
    //   1080: iload #4
    //   1082: iload #9
    //   1084: iconst_1
    //   1085: iadd
    //   1086: bipush #15
    //   1088: iand
    //   1089: if_icmpeq -> 1098
    //   1092: aload_1
    //   1093: invokeinterface 熱 : ()V
    //   1098: iload_3
    //   1099: istore #4
    //   1101: iload #8
    //   1103: bipush #32
    //   1105: iand
    //   1106: ifeq -> 1148
    //   1109: aload_2
    //   1110: invokevirtual 恐 : ()I
    //   1113: istore #8
    //   1115: aload_2
    //   1116: invokevirtual 恐 : ()I
    //   1119: bipush #64
    //   1121: iand
    //   1122: ifeq -> 1131
    //   1125: iconst_2
    //   1126: istore #4
    //   1128: goto -> 1134
    //   1131: iconst_0
    //   1132: istore #4
    //   1134: iload_3
    //   1135: iload #4
    //   1137: ior
    //   1138: istore #4
    //   1140: aload_2
    //   1141: iload #8
    //   1143: iconst_1
    //   1144: isub
    //   1145: invokevirtual 寒 : (I)V
    //   1148: aload_0
    //   1149: getfield 苦 : Z
    //   1152: istore #14
    //   1154: iload #14
    //   1156: ifne -> 1172
    //   1159: aload_0
    //   1160: getfield 美 : Landroid/util/SparseBooleanArray;
    //   1163: iload #7
    //   1165: iconst_0
    //   1166: invokevirtual get : (IZ)Z
    //   1169: ifne -> 1198
    //   1172: aload_2
    //   1173: iload #5
    //   1175: invokevirtual 暑 : (I)V
    //   1178: aload_1
    //   1179: iload #4
    //   1181: aload_2
    //   1182: invokeinterface 硬 : (ILy/tl0;)V
    //   1187: aload_2
    //   1188: iload #6
    //   1190: invokevirtual 暑 : (I)V
    //   1193: iload #14
    //   1195: ifne -> 1219
    //   1198: aload_0
    //   1199: getfield 苦 : Z
    //   1202: ifeq -> 1219
    //   1205: lload #12
    //   1207: ldc2_w -1
    //   1210: lcmp
    //   1211: ifeq -> 1219
    //   1214: aload_0
    //   1215: iconst_1
    //   1216: putfield 悲 : Z
    //   1219: aload_2
    //   1220: iload #5
    //   1222: invokevirtual 冷 : (I)V
    //   1225: iconst_0
    //   1226: ireturn
  }
  
  public final boolean 熱(x53 paramx53) {
    byte[] arrayOfByte = this.堅.堅;
    paramx53 = paramx53;
    paramx53.恐(arrayOfByte, 0, 940, false);
    int i = 0;
    label14: while (i < 188) {
      for (int j = 0; j < 5; j++) {
        if (arrayOfByte[j * 188 + i] != 71) {
          i++;
          continue label14;
        } 
      } 
      paramx53.寂(i);
      return true;
    } 
    return false;
  }
  
  public final void 硬(long paramLong1, long paramLong2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 硬 : Ljava/util/List;
    //   4: astore #8
    //   6: aload #8
    //   8: invokeinterface size : ()I
    //   13: istore #7
    //   15: iconst_0
    //   16: istore #6
    //   18: iconst_0
    //   19: istore #5
    //   21: iload #5
    //   23: iload #7
    //   25: if_icmpge -> 95
    //   28: aload #8
    //   30: iload #5
    //   32: invokeinterface get : (I)Ljava/lang/Object;
    //   37: checkcast y/ex1
    //   40: astore #9
    //   42: aload #9
    //   44: invokevirtual 暑 : ()J
    //   47: ldc2_w -9223372036854775807
    //   50: lcmp
    //   51: ifeq -> 80
    //   54: aload #9
    //   56: invokevirtual 熱 : ()J
    //   59: lstore_1
    //   60: lload_1
    //   61: ldc2_w -9223372036854775807
    //   64: lcmp
    //   65: ifeq -> 86
    //   68: lload_1
    //   69: lconst_0
    //   70: lcmp
    //   71: ifeq -> 86
    //   74: lload_1
    //   75: lload_3
    //   76: lcmp
    //   77: ifeq -> 86
    //   80: aload #9
    //   82: lload_3
    //   83: invokevirtual 冷 : (J)V
    //   86: iload #5
    //   88: iconst_1
    //   89: iadd
    //   90: istore #5
    //   92: goto -> 21
    //   95: lload_3
    //   96: lconst_0
    //   97: lcmp
    //   98: ifeq -> 118
    //   101: aload_0
    //   102: getfield 不 : Ly/c50;
    //   105: astore #8
    //   107: aload #8
    //   109: ifnull -> 118
    //   112: aload #8
    //   114: lload_3
    //   115: invokevirtual 堅 : (J)V
    //   118: aload_0
    //   119: getfield 堅 : Ly/tl0;
    //   122: iconst_0
    //   123: invokevirtual 堅 : (I)V
    //   126: aload_0
    //   127: getfield 熱 : Landroid/util/SparseIntArray;
    //   130: invokevirtual clear : ()V
    //   133: iload #6
    //   135: istore #5
    //   137: aload_0
    //   138: getfield 冷 : Landroid/util/SparseArray;
    //   141: astore #8
    //   143: iload #5
    //   145: aload #8
    //   147: invokevirtual size : ()I
    //   150: if_icmpge -> 177
    //   153: aload #8
    //   155: iload #5
    //   157: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   160: checkcast y/da0
    //   163: invokeinterface 熱 : ()V
    //   168: iload #5
    //   170: iconst_1
    //   171: iadd
    //   172: istore #5
    //   174: goto -> 137
    //   177: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aa0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */