package y;

import android.text.TextUtils;
import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

public abstract class ad0 {
  public static HashMap 硬(String paramString) {
    try {
      if (!TextUtils.isEmpty(paramString))
        return (HashMap)(new ObjectInputStream(new ByteArrayInputStream(Base64.decode(paramString.getBytes(), 0)))).readObject(); 
    } catch (IOException|ClassNotFoundException iOException) {}
    return null;
  }
  
  public final String toString() {
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      objectOutputStream.writeObject(堅());
      objectOutputStream.close();
      return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  public abstract HashMap 堅();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ad0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */