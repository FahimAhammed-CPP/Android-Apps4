package y;

public final class aq1 implements dt2 {
  public final kt2 硬;
  
  public aq1(ln1 paramln1) {
    this.硬 = paramln1;
  }
  
  public final Object 暑() {
    return new zp1(((ln1)this.硬).硬());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aq1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */