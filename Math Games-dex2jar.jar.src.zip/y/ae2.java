package y;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.SortedMap;

public class ae2 extends AbstractMap {
  public transient me2 怖;
  
  public final transient Map 恐;
  
  public transient zd2 淋;
  
  public ae2(wd2 paramwd2, Map paramMap) {
    this.恐 = paramMap;
  }
  
  public final void clear() {
    wd2 wd21 = this.痛;
    Map map = wd21.痛;
    if (this.恐 == map) {
      wd21.堅();
      return;
    } 
    he2 he2 = new he2(this);
    while (he2.hasNext()) {
      he2.next();
      he2.remove();
    } 
  }
  
  public final boolean containsKey(Object paramObject) {
    Map map = this.恐;
    map.getClass();
    try {
      return map.containsKey(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      return false;
    } 
  }
  
  public final boolean equals(Object paramObject) {
    return (this == paramObject || this.恐.equals(paramObject));
  }
  
  public final Object get(Object paramObject) {
    Map map = this.恐;
    map.getClass();
    try {
      map = (Map)map.get(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      classCastException = null;
    } 
    Collection collection = (Collection)classCastException;
    if (collection == null)
      return null; 
    wd2 wd21 = this.痛;
    wd21.getClass();
    collection = collection;
    return (collection instanceof java.util.RandomAccess) ? new ee2(wd21, paramObject, (List)collection, null) : new ke2(wd21, paramObject, (List)collection, null);
  }
  
  public final int hashCode() {
    return this.恐.hashCode();
  }
  
  public Set keySet() {
    wd2 wd21 = this.痛;
    be2 be22 = wd21.淋;
    be2 be21 = be22;
    if (be22 == null) {
      bg2 bg2 = (bg2)wd21;
      Map map = bg2.痛;
      if (map instanceof NavigableMap) {
        be21 = new de2(bg2, (NavigableMap)map);
      } else {
        ge2 ge2;
        if (map instanceof SortedMap) {
          ge2 = new ge2((wd2)be21, (SortedMap)map);
        } else {
          be21 = new be2((wd2)ge2, map);
        } 
      } 
      wd21.淋 = be21;
    } 
    return be21;
  }
  
  public final int size() {
    return this.恐.size();
  }
  
  public final String toString() {
    return this.恐.toString();
  }
  
  public final Collection 堅() {
    me2 me22 = this.怖;
    me2 me21 = me22;
    if (me22 == null) {
      me21 = new me2(this);
      this.怖 = me21;
    } 
    return me21;
  }
  
  public final jf2 熱(Map.Entry paramEntry) {
    ke2 ke2;
    Object object = paramEntry.getKey();
    Collection collection = (Collection)paramEntry.getValue();
    wd2 wd21 = this.痛;
    wd21.getClass();
    collection = collection;
    if (collection instanceof java.util.RandomAccess) {
      ke2 = new ee2(wd21, object, (List)collection, null);
    } else {
      ke2 = new ke2((wd2)ke2, object, (List)collection, null);
    } 
    return new jf2(object, ke2);
  }
  
  public final Set 硬() {
    zd2 zd22 = this.淋;
    zd2 zd21 = zd22;
    if (zd22 == null) {
      zd21 = new zd2(this);
      this.淋 = zd21;
    } 
    return zd21;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ae2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */