package y;

public final class ah2 {
  public static final ah2 暑 = new ah2(null, false);
  
  public static final ah2 熱 = new ah2(null, true);
  
  public final Throwable 堅;
  
  public final boolean 硬;
  
  public ah2(Throwable paramThrowable, boolean paramBoolean) {
    this.硬 = paramBoolean;
    this.堅 = paramThrowable;
  }
  
  static {
    if (lh2.痛) {
      暑 = null;
      熱 = null;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ah2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */