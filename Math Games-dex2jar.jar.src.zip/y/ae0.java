package y;

import android.util.Base64;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class ae0 {
  public static final Object 堅 = new Object();
  
  public static final Object 熱 = new Object();
  
  public static Cipher 硬;
  
  public static byte[] 堅(String paramString, byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length;
    try {
      byte[] arrayOfByte = 年.퇴(paramString, false);
      i = arrayOfByte.length;
      if (i > 16) {
        ByteBuffer byteBuffer = ByteBuffer.allocate(i);
        byteBuffer.put(arrayOfByte);
        byteBuffer.flip();
        arrayOfByte = new byte[16];
        byte[] arrayOfByte1 = new byte[i - 16];
        byteBuffer.get(arrayOfByte);
        byteBuffer.get(arrayOfByte1);
        SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte, "AES");
        synchronized (堅) {
          熱().init(2, secretKeySpec, new IvParameterSpec(arrayOfByte));
          arrayOfByte = 熱().doFinal(arrayOfByte1);
          return arrayOfByte;
        } 
      } 
      throw new zd0();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new zd0(noSuchAlgorithmException);
    } catch (InvalidKeyException invalidKeyException) {
      throw new zd0(invalidKeyException);
    } catch (IllegalBlockSizeException illegalBlockSizeException) {
      throw new zd0(illegalBlockSizeException);
    } catch (NoSuchPaddingException noSuchPaddingException) {
      throw new zd0(noSuchPaddingException);
    } catch (BadPaddingException badPaddingException) {
      throw new zd0(badPaddingException);
    } catch (InvalidAlgorithmParameterException invalidAlgorithmParameterException) {
      throw new zd0(invalidAlgorithmParameterException);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new zd0(illegalArgumentException);
    } 
  }
  
  public static final Cipher 熱() {
    synchronized (熱) {
      if (硬 == null)
        硬 = Cipher.getInstance("AES/CBC/PKCS5Padding"); 
      return 硬;
    } 
  }
  
  public static String 硬(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    int i = paramArrayOfbyte1.length;
    try {
      SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES");
      synchronized (堅) {
        熱().init(1, secretKeySpec, (SecureRandom)null);
        paramArrayOfbyte2 = 熱().doFinal(paramArrayOfbyte2);
        byte[] arrayOfByte = 熱().getIV();
        i = paramArrayOfbyte2.length + arrayOfByte.length;
        null = ByteBuffer.allocate(i);
        null.put(arrayOfByte).put(paramArrayOfbyte2);
        null.flip();
        paramArrayOfbyte2 = new byte[i];
        null.get(paramArrayOfbyte2);
        return Base64.encodeToString(paramArrayOfbyte2, 2);
      } 
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new zd0(noSuchAlgorithmException);
    } catch (InvalidKeyException invalidKeyException) {
      throw new zd0(invalidKeyException);
    } catch (IllegalBlockSizeException illegalBlockSizeException) {
      throw new zd0(illegalBlockSizeException);
    } catch (NoSuchPaddingException noSuchPaddingException) {
      throw new zd0(noSuchPaddingException);
    } catch (BadPaddingException badPaddingException) {
      throw new zd0(badPaddingException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ae0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */