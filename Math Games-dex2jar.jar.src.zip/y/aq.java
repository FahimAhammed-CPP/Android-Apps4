package y;

public final class aq implements Comparable {
  public final int 怖;
  
  public final String 恐;
  
  public final int 淋;
  
  public final String 痛;
  
  public aq(int paramInt1, int paramInt2, String paramString1, String paramString2) {
    this.淋 = paramInt1;
    this.怖 = paramInt2;
    this.恐 = paramString1;
    this.痛 = paramString2;
  }
  
  public final int compareTo(Object paramObject) {
    paramObject = paramObject;
    int i = ((aq)paramObject).淋;
    int j = this.淋 - i;
    i = j;
    if (j == 0)
      i = this.怖 - ((aq)paramObject).怖; 
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */