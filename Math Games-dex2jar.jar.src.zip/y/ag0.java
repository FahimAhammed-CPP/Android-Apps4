package y;

public final class ag0 {
  public final long 堅;
  
  public volatile long 暑;
  
  public volatile long 熱;
  
  public final int 硬;
  
  public ag0(int paramInt, long paramLong) {
    this.硬 = paramInt;
    this.堅 = paramLong;
    this.熱 = paramLong;
    this.暑 = paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ag0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */