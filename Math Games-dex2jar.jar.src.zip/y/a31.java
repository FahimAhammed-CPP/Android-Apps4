package y;

import android.os.IInterface;

public interface a31 extends IInterface {
  String 不();
  
  int 堅();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a31.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */