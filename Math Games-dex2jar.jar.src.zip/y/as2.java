package y;

public final class as2 implements bq2 {
  public static final as2 硬 = new as2();
  
  public final boolean 硬(int paramInt) {
    return !(paramInt != 0 && paramInt != 1 && paramInt != 2 && paramInt != 3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\as2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */