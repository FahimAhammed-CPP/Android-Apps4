package y;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.Choreographer;

public final class a53 implements Choreographer.FrameCallback, Handler.Callback {
  public static final a53 痒 = new a53();
  
  public final Handler 怖;
  
  public Choreographer 恐;
  
  public volatile long 淋 = -9223372036854775807L;
  
  public int 痛;
  
  public a53() {
    HandlerThread handlerThread = new HandlerThread("ExoPlayer:FrameReleaseChoreographer");
    handlerThread.start();
    Looper looper = handlerThread.getLooper();
    int i = yx1.硬;
    Handler handler = new Handler(looper, this);
    this.怖 = handler;
    handler.sendEmptyMessage(0);
  }
  
  public final void doFrame(long paramLong) {
    this.淋 = paramLong;
    Choreographer choreographer = this.恐;
    choreographer.getClass();
    choreographer.postFrameCallbackDelayed(this, 500L);
  }
  
  public final boolean handleMessage(Message paramMessage) {
    int i = paramMessage.what;
    if (i != 0) {
      if (i != 1) {
        if (i != 2)
          return false; 
        Choreographer choreographer1 = this.恐;
        if (choreographer1 != null) {
          i = this.痛 - 1;
          this.痛 = i;
          if (i == 0) {
            choreographer1.removeFrameCallback(this);
            this.淋 = -9223372036854775807L;
          } 
        } 
        return true;
      } 
      Choreographer choreographer = this.恐;
      if (choreographer != null) {
        i = this.痛 + 1;
        this.痛 = i;
        if (i == 1)
          choreographer.postFrameCallback(this); 
      } 
      return true;
    } 
    try {
      this.恐 = Choreographer.getInstance();
      return true;
    } catch (RuntimeException runtimeException) {
      eq1.冷("Vsync sampling disabled due to platform error", runtimeException);
      return true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a53.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */