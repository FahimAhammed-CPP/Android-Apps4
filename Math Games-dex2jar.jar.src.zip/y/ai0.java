package y;

public final class ai0 {
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ai0))
      return false; 
    ((ai0)paramObject).getClass();
    return true;
  }
  
  public final int hashCode() {
    int i = (int)-9223372034707292159L;
    int j = Float.floatToIntBits(-3.4028235E38F);
    return Float.floatToIntBits(-3.4028235E38F) + (j + ((i * 31 + i) * 31 + i) * 31) * 31;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ai0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */