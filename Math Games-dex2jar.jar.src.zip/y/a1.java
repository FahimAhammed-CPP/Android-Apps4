package y;

import android.widget.Button;

public class a1 {
  public Button 冷;
  
  public final 본 堅;
  
  public final 본 暑;
  
  public final 본 熱;
  
  public final 본 硬;
  
  public a1(본 param본1, 본 param본2, 본 param본3, 본 param본4) {
    this.硬 = param본1;
    this.堅 = param본2;
    this.熱 = param본3;
    this.暑 = param본4;
  }
  
  public final void 冷(boolean paramBoolean, 본 param본1, 본 param본2) {
    暑().setTextColor(((Number)param본1.不(paramBoolean)).intValue());
    暑().setBackgroundResource(((Number)param본2.不(paramBoolean)).intValue());
  }
  
  public void 堅() {
    throw new di2();
  }
  
  public final Button 暑() {
    Button button = this.冷;
    return (button != null) ? button : null;
  }
  
  public void 熱() {
    본 본1 = this.暑;
    冷(false, this.熱, 본1);
  }
  
  public void 硬() {
    본 본1 = this.暑;
    冷(false, this.熱, 본1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */