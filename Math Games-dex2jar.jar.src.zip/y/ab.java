package y;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.lifecycle.for;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class ab extends 골 implements t3, 稲 {
  public static final String 看 = cb.熱;
  
  public final ArrayList う = new ArrayList();
  
  public final int く = 3;
  
  public final hp ご = new hp(new ra(this, 1));
  
  public final hp し = new hp(new ra(this, 10));
  
  public final hp た = new hp(new ra(this, 8));
  
  public 昨 ね;
  
  public z0 ぼ;
  
  public final ArrayList ょ = new ArrayList();
  
  public boolean れ;
  
  public final u9 俺 = new u9(0, 0);
  
  public z0 僕;
  
  public final hp 医 = new hp(new ra(this, 0));
  
  public boolean 少 = true;
  
  public 七 年;
  
  public final int 私 = 3;
  
  public final hp 者 = new hp(new ra(this, 9));
  
  public tc 택;
  
  public s4 탱;
  
  public ci0 터;
  
  public 혹 테;
  
  public final hp 토 = new hp(new ra(this, 3));
  
  public int 톤;
  
  public final 男 톨 = new 男(18);
  
  public le 통;
  
  public final ArrayList 퇴 = new ArrayList();
  
  public final ArrayList 투 = new ArrayList();
  
  public RelativeLayout 퉁;
  
  public static 복 年(辞 param辞) {
    return new 복(String.valueOf((int)param辞.硬.硬().硬().doubleValue()), param辞.堅.硬(), String.valueOf((int)param辞.熱.硬().硬().doubleValue()));
  }
  
  public final void onBackPressed() {
    int i = this.톤 + 1;
    this.톤 = i;
    int j = nf.硬;
    if (i > 1 || this.톨.淋().booleanValue()) {
      this.톤 = 0;
      finishAfterTransition();
    } 
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ょ();
    this.통 = 꽃.泳(this);
    寝();
    踊();
    触();
    う();
    少();
    this.테 = new 혹(findViewById(2131231128));
    oy0.ち(this.탐, null, new ua(this, null), 3);
    ね();
    findViewById(2131231377);
    辛();
    this.少 = getIntent().getExtras().getBoolean(看);
  }
  
  public final void onPause() {
    this.톤 = 0;
    れ();
    昨 昨1 = this.ね;
    if (昨1 != null)
      昨1.ぱ(); 
    super.onPause();
  }
  
  public final void onResume() {
    boolean bool;
    super.onResume();
    int i = nf.硬;
    け け = (け)this.탐.熱().堅(yw0.怖);
    if (け != null) {
      bool = け.硬();
    } else {
      bool = true;
    } 
    if (!bool)
      this.탐 = oy0.硬(年.硬()); 
  }
  
  public final void onWindowFocusChanged(boolean paramBoolean) {
    int i = nf.硬;
    if (paramBoolean)
      赤(); 
  }
  
  public final void あ(z0 paramz0) {
    ((Button)(paramz0.硬()).硬).setOnTouchListener(new pa(paramz0, this));
  }
  
  public abstract void う();
  
  public int か() {
    int i = ((Button)別.家(this.퇴)).getMeasuredWidth();
    腕.硬(i);
    return i;
  }
  
  public void く(int paramInt1, int paramInt2, int paramInt3) {
    le le2 = this.통;
    le le1 = le2;
    if (le2 == null)
      le1 = null; 
    int i = le1.堅;
    int j = 腕.怖;
    i = (i - Integer.valueOf(paramInt2).intValue() * paramInt1) / (paramInt1 + 1);
    paramInt3 = Integer.valueOf(paramInt3).intValue();
    Iterator<Button> iterator = this.퇴.iterator();
    int k = i;
    j = 0;
    while (iterator.hasNext()) {
      int m;
      Button button = iterator.next();
      z0 z01 = new z0();
      this.う.add(z01);
      z01.堅(k, paramInt3);
      z01.硬 = new 본(button, 타());
      ik.코((View)(z01.硬()).硬, k, paramInt3);
      ((Button)(z01.硬()).硬).setVisibility(0);
      あ(z01);
      int n = Integer.valueOf(paramInt2).intValue();
      if (j == paramInt1 - 1) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m) {
        m = Integer.valueOf(paramInt2).intValue() * 3 / 2;
        k = i;
        m += paramInt3;
        paramInt3 = k;
      } else {
        k = n + i + k;
        m = paramInt3;
        paramInt3 = k;
      } 
      j++;
      k = paramInt3;
      paramInt3 = m;
    } 
  }
  
  public abstract void し();
  
  public void た() {
    if ((탱()).冷) {
      者();
      return;
    } 
    톨();
  }
  
  public int ち() {
    int i = ((View)別.家(this.투)).getMeasuredWidth();
    腕.硬(i);
    return i;
  }
  
  public void ね() {
    퍼 퍼1 = this.탐;
    hp hp1 = this.태;
    i00 i001 = (i00)hp1.getValue();
    男 男1 = this.크;
    this.택 = new tc(퍼1, i001, 男1, 터(), (平)this.탑.getValue());
    this.탱 = new s4(ㅌ(), 男1, this.탐, 터(), this);
    퍼 퍼2 = this.탐;
    i00 i002 = (i00)hp1.getValue();
    bb bb = 토();
    s4 s42 = this.탱;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    this.터 = new ci0(퍼2, i002, bb, s41, this);
    俺();
    ㅌ().旨();
  }
  
  public abstract void ぼ();
  
  public boolean も() {
    return this instanceof ocos.mathset.ui.MatchGameActivity ^ true;
  }
  
  public int ゃ() {
    return Integer.valueOf(탐()).intValue();
  }
  
  public abstract void ょ();
  
  public void れ() {
    s4 s42 = this.탱;
    s4 s41 = s42;
    if (s42 == null)
      s41 = null; 
    s41.熱();
  }
  
  public boolean わ(z0 paramz0) {
    return true;
  }
  
  public final tc ㅌ() {
    tc tc1 = this.택;
    return (tc1 != null) ? tc1 : null;
  }
  
  public abstract void 俺();
  
  public void 僕() {
    for (z0 z01 : this.ょ) {
      z01.熱();
      z01.暑 = false;
    } 
    for (z0 z01 : this.う) {
      Button button = (Button)(z01.硬()).硬;
      u9 u91 = z01.熱;
      ik.코((View)button, u91.硬, u91.堅);
      z01.硬().美();
      z01.暑 = false;
    } 
  }
  
  public void 医(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 若 : ()Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield ぼ : Ly/z0;
    //   12: ifnonnull -> 16
    //   15: return
    //   16: aload_1
    //   17: invokevirtual getX : ()F
    //   20: f2i
    //   21: istore #7
    //   23: aload_1
    //   24: invokevirtual getY : ()F
    //   27: f2i
    //   28: istore #8
    //   30: aload_0
    //   31: getfield ぼ : Ly/z0;
    //   34: astore #16
    //   36: aload_1
    //   37: invokevirtual getAction : ()I
    //   40: istore #9
    //   42: iconst_1
    //   43: istore #6
    //   45: aload_0
    //   46: getfield 俺 : Ly/u9;
    //   49: astore #15
    //   51: iload #9
    //   53: ifeq -> 776
    //   56: iload #9
    //   58: iconst_1
    //   59: if_icmpeq -> 276
    //   62: iload #9
    //   64: iconst_2
    //   65: if_icmpeq -> 69
    //   68: return
    //   69: aload_0
    //   70: getfield れ : Z
    //   73: ifeq -> 810
    //   76: aload #16
    //   78: getfield 暑 : Z
    //   81: ifne -> 810
    //   84: aload #16
    //   86: invokevirtual 硬 : ()Ly/본;
    //   89: getfield 硬 : Ljava/lang/Object;
    //   92: checkcast android/widget/Button
    //   95: astore #16
    //   97: aload #15
    //   99: getfield 硬 : I
    //   102: istore #9
    //   104: aload #16
    //   106: invokevirtual getLeft : ()I
    //   109: iload #7
    //   111: iload #9
    //   113: isub
    //   114: iadd
    //   115: istore #9
    //   117: aload #15
    //   119: getfield 堅 : I
    //   122: istore #10
    //   124: aload #16
    //   126: invokevirtual getTop : ()I
    //   129: iload #8
    //   131: iload #10
    //   133: isub
    //   134: iadd
    //   135: istore #10
    //   137: aload_0
    //   138: getfield 크 : Ly/男;
    //   141: invokevirtual 淋 : ()Ljava/lang/Boolean;
    //   144: invokevirtual booleanValue : ()Z
    //   147: ifeq -> 153
    //   150: goto -> 244
    //   153: aload_0
    //   154: invokevirtual 탁 : ()I
    //   157: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   160: invokevirtual intValue : ()I
    //   163: istore #11
    //   165: iload #11
    //   167: i2d
    //   168: dstore_2
    //   169: aload_0
    //   170: getfield 통 : Ly/le;
    //   173: astore_1
    //   174: aload_1
    //   175: ifnonnull -> 183
    //   178: aconst_null
    //   179: astore_1
    //   180: goto -> 183
    //   183: iload #11
    //   185: iload #9
    //   187: iadd
    //   188: aload_1
    //   189: getfield 堅 : I
    //   192: if_icmpgt -> 239
    //   195: iload #9
    //   197: iflt -> 239
    //   200: iload #10
    //   202: i2d
    //   203: dstore #4
    //   205: aload_0
    //   206: invokevirtual 탈 : ()Landroid/widget/RelativeLayout;
    //   209: invokevirtual getHeight : ()I
    //   212: istore #11
    //   214: getstatic y/nf.硬 : I
    //   217: istore #12
    //   219: dload #4
    //   221: dload_2
    //   222: ldc2_w 1.25
    //   225: dmul
    //   226: dadd
    //   227: iload #11
    //   229: i2d
    //   230: dcmpl
    //   231: ifgt -> 239
    //   234: iload #10
    //   236: ifge -> 247
    //   239: getstatic y/nf.硬 : I
    //   242: istore #6
    //   244: iconst_0
    //   245: istore #6
    //   247: iload #6
    //   249: ifeq -> 261
    //   252: aload #16
    //   254: iload #9
    //   256: iload #10
    //   258: invokestatic 코 : (Landroid/view/View;II)V
    //   261: aload #15
    //   263: iload #7
    //   265: putfield 硬 : I
    //   268: aload #15
    //   270: iload #8
    //   272: putfield 堅 : I
    //   275: return
    //   276: getstatic y/nf.硬 : I
    //   279: istore #6
    //   281: aload_0
    //   282: iconst_0
    //   283: putfield れ : Z
    //   286: aload #16
    //   288: invokevirtual 硬 : ()Ly/본;
    //   291: getfield 硬 : Ljava/lang/Object;
    //   294: checkcast android/widget/Button
    //   297: astore_1
    //   298: aload_1
    //   299: invokevirtual getLeft : ()I
    //   302: istore #7
    //   304: aload_1
    //   305: invokevirtual getTop : ()I
    //   308: istore #8
    //   310: new java/util/ArrayList
    //   313: dup
    //   314: invokespecial <init> : ()V
    //   317: astore_1
    //   318: aload_0
    //   319: invokevirtual 탐 : ()I
    //   322: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   325: invokevirtual intValue : ()I
    //   328: istore #9
    //   330: aload_0
    //   331: invokevirtual 탐 : ()I
    //   334: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   337: invokevirtual intValue : ()I
    //   340: istore #10
    //   342: iload #9
    //   344: iconst_2
    //   345: idiv
    //   346: istore #11
    //   348: iload #10
    //   350: iconst_2
    //   351: idiv
    //   352: istore #12
    //   354: iload #9
    //   356: ifle -> 365
    //   359: iconst_1
    //   360: istore #6
    //   362: goto -> 368
    //   365: iconst_0
    //   366: istore #6
    //   368: iload #6
    //   370: ifeq -> 762
    //   373: iload #10
    //   375: ifle -> 384
    //   378: iconst_1
    //   379: istore #6
    //   381: goto -> 387
    //   384: iconst_0
    //   385: istore #6
    //   387: iload #6
    //   389: ifeq -> 748
    //   392: aload_0
    //   393: getfield ょ : Ljava/util/ArrayList;
    //   396: invokevirtual iterator : ()Ljava/util/Iterator;
    //   399: astore #17
    //   401: aload #17
    //   403: invokeinterface hasNext : ()Z
    //   408: ifeq -> 552
    //   411: aload #17
    //   413: invokeinterface next : ()Ljava/lang/Object;
    //   418: checkcast y/z0
    //   421: astore #18
    //   423: aload_0
    //   424: getfield し : Ly/hp;
    //   427: invokevirtual getValue : ()Ljava/lang/Object;
    //   430: checkcast java/lang/Number
    //   433: invokevirtual intValue : ()I
    //   436: istore #6
    //   438: aload #18
    //   440: getfield 熱 : Ly/u9;
    //   443: astore #19
    //   445: aload #19
    //   447: getfield 硬 : I
    //   450: istore #14
    //   452: aload #19
    //   454: getfield 堅 : I
    //   457: istore #13
    //   459: iload #7
    //   461: iload #11
    //   463: iadd
    //   464: iload #14
    //   466: iload #11
    //   468: iadd
    //   469: isub
    //   470: istore #14
    //   472: iload #8
    //   474: iload #12
    //   476: iadd
    //   477: iload #13
    //   479: iload #12
    //   481: iadd
    //   482: isub
    //   483: istore #13
    //   485: iload #13
    //   487: iload #13
    //   489: imul
    //   490: iload #14
    //   492: iload #14
    //   494: imul
    //   495: iadd
    //   496: iload #10
    //   498: iload #10
    //   500: imul
    //   501: iload #9
    //   503: iload #9
    //   505: imul
    //   506: iadd
    //   507: iload #6
    //   509: iadd
    //   510: if_icmpge -> 519
    //   513: iconst_1
    //   514: istore #6
    //   516: goto -> 522
    //   519: iconst_0
    //   520: istore #6
    //   522: iload #6
    //   524: ifeq -> 549
    //   527: aload_0
    //   528: aload #18
    //   530: invokevirtual 코 : (Ly/z0;)V
    //   533: aload_0
    //   534: aload #18
    //   536: invokevirtual わ : (Ly/z0;)Z
    //   539: ifeq -> 549
    //   542: aload_1
    //   543: aload #18
    //   545: invokevirtual add : (Ljava/lang/Object;)Z
    //   548: pop
    //   549: goto -> 401
    //   552: aload_1
    //   553: invokevirtual isEmpty : ()Z
    //   556: ifeq -> 564
    //   559: aconst_null
    //   560: astore_1
    //   561: goto -> 570
    //   564: aload_1
    //   565: iconst_0
    //   566: invokevirtual get : (I)Ljava/lang/Object;
    //   569: astore_1
    //   570: aload_1
    //   571: checkcast y/z0
    //   574: astore_1
    //   575: aload_1
    //   576: ifnull -> 584
    //   579: getstatic y/nf.硬 : I
    //   582: istore #6
    //   584: aload_1
    //   585: ifnonnull -> 629
    //   588: getstatic y/nf.硬 : I
    //   591: istore #6
    //   593: aload #16
    //   595: invokevirtual 硬 : ()Ly/본;
    //   598: getfield 硬 : Ljava/lang/Object;
    //   601: checkcast android/widget/Button
    //   604: astore_1
    //   605: aload #16
    //   607: getfield 熱 : Ly/u9;
    //   610: astore #16
    //   612: aload_1
    //   613: aload #16
    //   615: getfield 硬 : I
    //   618: aload #16
    //   620: getfield 堅 : I
    //   623: invokestatic 코 : (Landroid/view/View;II)V
    //   626: goto -> 730
    //   629: getstatic y/nf.硬 : I
    //   632: istore #6
    //   634: aload_0
    //   635: invokevirtual も : ()Z
    //   638: ifeq -> 656
    //   641: aload_0
    //   642: invokevirtual 泳 : ()Ly/国;
    //   645: invokevirtual getClass : ()Ljava/lang/Class;
    //   648: pop
    //   649: aload_0
    //   650: getstatic y/鏡.탕 : Ljava/lang/String;
    //   653: invokevirtual 噛 : (Ljava/lang/String;)V
    //   656: aload #16
    //   658: invokevirtual 硬 : ()Ly/본;
    //   661: getfield 硬 : Ljava/lang/Object;
    //   664: checkcast android/widget/Button
    //   667: astore #17
    //   669: aload_1
    //   670: getfield 熱 : Ly/u9;
    //   673: astore #18
    //   675: aload #17
    //   677: aload #18
    //   679: getfield 硬 : I
    //   682: aload #18
    //   684: getfield 堅 : I
    //   687: invokestatic 코 : (Landroid/view/View;II)V
    //   690: aload #16
    //   692: invokevirtual 硬 : ()Ly/본;
    //   695: getfield 堅 : Ljava/lang/Object;
    //   698: checkcast y/a1
    //   701: invokevirtual 硬 : ()V
    //   704: aload #16
    //   706: aload_1
    //   707: putfield 寒 : Ly/z0;
    //   710: aload_1
    //   711: aload #16
    //   713: putfield 寒 : Ly/z0;
    //   716: aload_0
    //   717: invokevirtual 통 : ()Z
    //   720: ifeq -> 730
    //   723: aload_0
    //   724: aload_1
    //   725: aload #16
    //   727: invokevirtual 크 : (Ly/z0;Ly/z0;)V
    //   730: aload #15
    //   732: iconst_0
    //   733: putfield 硬 : I
    //   736: aload #15
    //   738: iconst_0
    //   739: putfield 堅 : I
    //   742: aload_0
    //   743: aconst_null
    //   744: putfield ぼ : Ly/z0;
    //   747: return
    //   748: new java/lang/IllegalArgumentException
    //   751: dup
    //   752: ldc_w 'Failed requirement.'
    //   755: invokevirtual toString : ()Ljava/lang/String;
    //   758: invokespecial <init> : (Ljava/lang/String;)V
    //   761: athrow
    //   762: new java/lang/IllegalArgumentException
    //   765: dup
    //   766: ldc_w 'Failed requirement.'
    //   769: invokevirtual toString : ()Ljava/lang/String;
    //   772: invokespecial <init> : (Ljava/lang/String;)V
    //   775: athrow
    //   776: getstatic y/nf.硬 : I
    //   779: istore #6
    //   781: aload_0
    //   782: iconst_1
    //   783: putfield れ : Z
    //   786: aload_0
    //   787: aload #16
    //   789: iload #7
    //   791: iload #8
    //   793: invokevirtual 투 : (Ly/z0;II)V
    //   796: aload #15
    //   798: iload #7
    //   800: putfield 硬 : I
    //   803: aload #15
    //   805: iload #8
    //   807: putfield 堅 : I
    //   810: return
  }
  
  public void 少() {
    탈().setOnTouchListener(new qa(this));
  }
  
  public void 投(z0 paramz0) {
    paramz0.熱();
    paramz0.硬().美();
    this.ぼ = paramz0;
    int i = nf.硬;
  }
  
  public abstract void 私();
  
  public final void 者() {
    int i = nf.硬;
    男 男1 = this.크;
    男1.怖();
    僕();
    泳().getClass();
    鏡 鏡 = 鏡.硬;
    噛(鏡.탑);
    ㅌ().苦(택());
    ((잔)this.토.getValue()).硬.setVisibility(0);
    男1.起();
  }
  
  public void 臭(boolean paramBoolean) {
    this.크.怖();
    if (paramBoolean) {
      퉁();
    } else {
      私();
    } 
    oy0.ち(this.탐, null, new wa(paramBoolean, this, null), 3);
  }
  
  public boolean 若() {
    boolean bool = this.크.淋().booleanValue();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      boolean bool3;
      z0 z01 = this.ぼ;
      if (z01 != null && !z01.暑) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      bool1 = bool2;
      if (bool3)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void 触() {
    ArrayList<View> arrayList = this.퇴;
    arrayList.add(findViewById(2131230932));
    arrayList.add(findViewById(2131230946));
    arrayList.add(findViewById(2131230943));
    arrayList.add(findViewById(2131230899));
    arrayList.add(findViewById(2131230898));
    arrayList.add(findViewById(2131230939));
  }
  
  public void 赤() {
    男 男1 = this.톨;
    if (男1.淋().booleanValue())
      return; 
    int i = nf.硬;
    ゃ();
    int m = 탐() / 2;
    腕.硬(m);
    int n = 탐();
    le le2 = this.통;
    le le1 = le2;
    if (le2 == null)
      le1 = null; 
    i = le1.堅;
    int j = Integer.valueOf(n).intValue();
    int k = this.私;
    k = (i - j * k) / (k + 1);
    Iterator<View> iterator = this.투.iterator();
    j = k;
    for (i = 0; iterator.hasNext(); i++) {
      View view = iterator.next();
      z0 z01 = new z0();
      if (i == 0 || i == 2)
        this.ょ.add(z01); 
      z01.堅(j, Integer.valueOf(m).intValue());
      ik.코(view, j, Integer.valueOf(m).intValue());
      view.setVisibility(0);
      j += Integer.valueOf(n).intValue() + k;
    } 
    i = 탄(탁());
    く(this.く, 탁(), i);
    i = nf.硬;
    男1.怖();
    ((for)(테()).起).寒(Boolean.TRUE);
  }
  
  public final void 辛() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 泳 : ()Ly/国;
    //   4: getfield 暑 : Ly/古;
    //   7: invokevirtual 暑 : ()Z
    //   10: istore_3
    //   11: iconst_1
    //   12: istore_1
    //   13: iload_3
    //   14: iconst_1
    //   15: ixor
    //   16: ifne -> 20
    //   19: return
    //   20: getstatic y/nf.硬 : I
    //   23: istore_2
    //   24: aload_0
    //   25: invokevirtual 泳 : ()Ly/国;
    //   28: invokevirtual getClass : ()Ljava/lang/Class;
    //   31: pop
    //   32: aload_0
    //   33: invokevirtual 키 : ()Ly/西;
    //   36: getfield 堅 : Z
    //   39: istore_3
    //   40: aload_0
    //   41: getfield 타 : Ly/髪;
    //   44: astore #6
    //   46: iload_3
    //   47: ifeq -> 336
    //   50: aload_0
    //   51: getfield ね : Ly/昨;
    //   54: ifnonnull -> 320
    //   57: aload_0
    //   58: invokevirtual 키 : ()Ly/西;
    //   61: getfield 冷 : Ljava/lang/String;
    //   64: astore #7
    //   66: aload_0
    //   67: invokevirtual 泳 : ()Ly/国;
    //   70: invokevirtual getClass : ()Ljava/lang/Class;
    //   73: pop
    //   74: getstatic y/鏡.硬 : Ly/鏡;
    //   77: astore #8
    //   79: getstatic y/鏡.美 : [Ly/oa;
    //   82: invokestatic ジ : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   85: checkcast y/oa
    //   88: getfield 淋 : Ljava/lang/String;
    //   91: astore #8
    //   93: ldc_w 'pub-3940256099942544'
    //   96: invokestatic 硬 : (Ljava/lang/String;)V
    //   99: iconst_1
    //   100: anewarray y/oa
    //   103: dup
    //   104: iconst_0
    //   105: new y/oa
    //   108: dup
    //   109: ldc_w 'pub-3940256099942544'
    //   112: invokespecial <init> : (Ljava/lang/String;)V
    //   115: aastore
    //   116: invokestatic ジ : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   119: checkcast y/oa
    //   122: getfield 淋 : Ljava/lang/String;
    //   125: astore #9
    //   127: aload #7
    //   129: invokestatic 弁 : (Ljava/lang/CharSequence;)Z
    //   132: ifeq -> 138
    //   135: goto -> 166
    //   138: aload #7
    //   140: aload #8
    //   142: iconst_1
    //   143: invokestatic せ : (Ljava/lang/String;Ljava/lang/String;Z)Z
    //   146: ifeq -> 152
    //   149: goto -> 168
    //   152: aload #7
    //   154: aload #9
    //   156: iconst_1
    //   157: invokestatic せ : (Ljava/lang/String;Ljava/lang/String;Z)Z
    //   160: ifeq -> 166
    //   163: goto -> 168
    //   166: iconst_0
    //   167: istore_1
    //   168: iload_1
    //   169: ifne -> 175
    //   172: goto -> 336
    //   175: aload #6
    //   177: invokeinterface getValue : ()Ljava/lang/Object;
    //   182: checkcast y/try
    //   185: astore #7
    //   187: new y/y9
    //   190: dup
    //   191: aconst_null
    //   192: aload_0
    //   193: invokevirtual 큰 : ()Ljava/lang/String;
    //   196: invokespecial <init> : (Ljava/lang/Number;Ljava/lang/String;)V
    //   199: astore #8
    //   201: aload_0
    //   202: invokevirtual 키 : ()Ly/西;
    //   205: getfield 冷 : Ljava/lang/String;
    //   208: astore #9
    //   210: aload_0
    //   211: getfield 少 : Z
    //   214: istore_3
    //   215: aload_0
    //   216: invokevirtual 泳 : ()Ly/国;
    //   219: invokevirtual getClass : ()Ljava/lang/Class;
    //   222: pop
    //   223: new y/瓜
    //   226: dup
    //   227: iload_3
    //   228: invokespecial <init> : (Z)V
    //   231: astore #10
    //   233: aload_0
    //   234: invokevirtual 키 : ()Ly/西;
    //   237: getfield 美 : J
    //   240: lstore #4
    //   242: aload_0
    //   243: invokevirtual 키 : ()Ly/西;
    //   246: getfield 寒 : I
    //   249: istore_1
    //   250: aload_0
    //   251: invokevirtual 泳 : ()Ly/国;
    //   254: invokevirtual getClass : ()Ljava/lang/Class;
    //   257: pop
    //   258: new y/요
    //   261: dup
    //   262: lload #4
    //   264: iload_1
    //   265: getstatic y/鏡.키 : J
    //   268: invokespecial <init> : (JIJ)V
    //   271: astore #11
    //   273: aload_0
    //   274: getfield ゃ : Ly/髪;
    //   277: invokeinterface getValue : ()Ljava/lang/Object;
    //   282: checkcast y/mp
    //   285: astore #12
    //   287: getstatic y/롱.痛 : I
    //   290: istore_1
    //   291: aload_0
    //   292: aload #7
    //   294: aload #8
    //   296: aload #9
    //   298: aload #10
    //   300: aload #11
    //   302: new y/閉
    //   305: dup
    //   306: aload #12
    //   308: lconst_0
    //   309: invokespecial <init> : (Ly/mp;J)V
    //   312: invokeinterface 熱 : (Ly/y9;Ljava/lang/String;Ly/瓜;Ly/요;Ly/閉;)Ly/昨;
    //   317: putfield ね : Ly/昨;
    //   320: aload_0
    //   321: getfield ね : Ly/昨;
    //   324: astore #7
    //   326: aload #7
    //   328: ifnull -> 336
    //   331: aload #7
    //   333: invokevirtual 辛 : ()V
    //   336: aload_0
    //   337: getfield 年 : Ly/七;
    //   340: ifnonnull -> 456
    //   343: aload_0
    //   344: getfield ご : Ly/hp;
    //   347: invokevirtual getValue : ()Ljava/lang/Object;
    //   350: checkcast java/lang/Boolean
    //   353: invokevirtual booleanValue : ()Z
    //   356: ifeq -> 456
    //   359: aload_0
    //   360: ldc_w 2131034140
    //   363: invokestatic 堅 : (Landroid/content/Context;I)I
    //   366: istore_1
    //   367: aload_0
    //   368: invokevirtual 키 : ()Ly/西;
    //   371: getfield 暑 : Ljava/lang/String;
    //   374: astore #7
    //   376: aload #6
    //   378: invokeinterface getValue : ()Ljava/lang/Object;
    //   383: checkcast y/try
    //   386: astore #6
    //   388: aload_0
    //   389: getfield 少 : Z
    //   392: istore_3
    //   393: aload_0
    //   394: invokevirtual 泳 : ()Ly/国;
    //   397: invokevirtual getClass : ()Ljava/lang/Class;
    //   400: pop
    //   401: new y/七
    //   404: dup
    //   405: aload_0
    //   406: iload_1
    //   407: aload #7
    //   409: aload #6
    //   411: new y/瓜
    //   414: dup
    //   415: iload_3
    //   416: invokespecial <init> : (Z)V
    //   419: invokespecial <init> : (Ly/銅;ILjava/lang/String;Ly/try;Ly/瓜;)V
    //   422: astore #6
    //   424: aload_0
    //   425: aload #6
    //   427: putfield 年 : Ly/七;
    //   430: aload #6
    //   432: aload_0
    //   433: ldc_w 2131231129
    //   436: invokevirtual findViewById : (I)Landroid/view/View;
    //   439: checkcast android/view/ViewGroup
    //   442: aload_0
    //   443: ldc_w 2131231240
    //   446: invokevirtual findViewById : (I)Landroid/view/View;
    //   449: checkcast android/view/ViewGroup
    //   452: aconst_null
    //   453: invokevirtual 硬 : (Landroid/view/ViewGroup;Landroid/view/ViewGroup;Landroid/view/View;)V
    //   456: return
  }
  
  public void 코(z0 paramz0) {}
  
  public void 쾌() {
    oy0.ち(this.탐, null, new sa(this, null), 3);
  }
  
  public abstract void 크(z0 paramz01, z0 paramz02);
  
  public abstract String 큰();
  
  public final 西 키() {
    return (西)this.医.getValue();
  }
  
  public abstract a1 타();
  
  public final int 탁() {
    return ((腕)this.た.getValue()).淋;
  }
  
  public int 탄(int paramInt) {
    int i = 탑();
    int j = 腕.怖;
    paramInt = Integer.valueOf(paramInt).intValue() * 3 / 2;
    腕.硬(paramInt);
    paramInt += i;
    腕.硬(paramInt);
    return paramInt;
  }
  
  public final RelativeLayout 탈() {
    RelativeLayout relativeLayout = this.퉁;
    return (relativeLayout != null) ? relativeLayout : null;
  }
  
  public final int 탐() {
    return ((腕)this.者.getValue()).淋;
  }
  
  public abstract int 탑();
  
  public final gc 탕() {
    gc gc = (토()).寒;
    return (gc != null) ? gc : null;
  }
  
  public final 間 태() {
    間 間 = (토()).冷;
    return (間 != null) ? 間 : null;
  }
  
  public final 間 택() {
    gc gc = (토()).寒;
    if (gc == null)
      gc = null; 
    return gc.硬;
  }
  
  public final ld 탱() {
    ld ld = (토()).美;
    return (ld != null) ? ld : null;
  }
  
  public abstract sd 터();
  
  public final ci0 테() {
    ci0 ci01 = this.터;
    return (ci01 != null) ? ci01 : null;
  }
  
  public abstract bb 토();
  
  public final void 톤(List paramList) {
    Iterator<z0> iterator = this.う.iterator();
    for (int i = 0; iterator.hasNext(); i++) {
      z0 z01 = iterator.next();
      int j = ((채)paramList.get(i)).硬.intValue();
      z01.冷 = j;
      ((Button)(z01.硬()).硬).setText(String.valueOf(j));
    } 
  }
  
  public abstract void 톨();
  
  public boolean 통() {
    ArrayList arrayList = this.ょ;
    boolean bool = arrayList instanceof java.util.Collection;
    boolean bool1 = true;
    if (bool && arrayList.isEmpty())
      return true; 
    Iterator iterator = arrayList.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        boolean bool2;
        if (((z0)iterator.next()).寒 == null) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (bool2) {
          bool = false;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final boolean 퇴(z0 paramz0) {
    return this.ょ.contains(paramz0);
  }
  
  public void 투(z0 paramz0, int paramInt1, int paramInt2) {
    int i = Integer.valueOf(탐()).intValue() / 2;
    ik.코((View)(paramz0.硬()).硬, paramInt1 - i, paramInt2 - i);
  }
  
  public abstract void 퉁();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */