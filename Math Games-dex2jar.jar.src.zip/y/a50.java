package y;

public final class a50 implements q40 {
  public final r70 硬;
  
  public a50(r70 paramr70) {
    this.硬 = paramr70;
  }
  
  public final int 硬() {
    return 1718776947;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a50.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */