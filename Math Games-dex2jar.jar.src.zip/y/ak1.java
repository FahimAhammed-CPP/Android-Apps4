package y;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public final class ak1 extends mf0 {
  public ak1(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOutOfContextTesterCreator", 0);
  }
  
  public final kj1 鬚(r6 paramr6, qx0 paramqx0) {
    kj1 kj1;
    Parcel parcel2 = あ();
    of0.冷(parcel2, paramr6);
    of0.冷(parcel2, paramqx0);
    parcel2.writeInt(224400000);
    Parcel parcel1 = ㅌ(parcel2, 1);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOutOfContextTester");
      if (iInterface instanceof kj1) {
        kj1 = (kj1)iInterface;
      } else {
        kj1 = new vi1((IBinder)kj1);
      } 
    } 
    parcel1.recycle();
    return kj1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ak1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */