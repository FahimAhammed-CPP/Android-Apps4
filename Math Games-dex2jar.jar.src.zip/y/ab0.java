package y;

import android.net.TrafficStats;
import android.os.Process;
import android.os.SystemClock;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

public final class ab0 extends Thread {
  public final za0 怖;
  
  public final ub0 恐;
  
  public final BlockingQueue 淋;
  
  public final yd0 痒;
  
  public volatile boolean 痛 = false;
  
  public ab0(PriorityBlockingQueue paramPriorityBlockingQueue, za0 paramza0, ub0 paramub0, yd0 paramyd0) {
    this.淋 = paramPriorityBlockingQueue;
    this.怖 = paramza0;
    this.恐 = paramub0;
    this.痒 = paramyd0;
  }
  
  public final void run() {
    Process.setThreadPriority(10);
    while (true) {
      try {
        while (true)
          硬(); 
        break;
      } catch (InterruptedException interruptedException) {
        if (this.痛) {
          Thread.currentThread().interrupt();
          return;
        } 
        mb0.堅("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
      } 
    } 
  }
  
  public final void 硬() {
    yd0 yd01 = this.痒;
    gb0 gb0 = this.淋.take();
    SystemClock.elapsedRealtime();
    gb0.辛(3);
    try {
      gb0.暑("network-queue-take");
      gb0.嬉();
      TrafficStats.setThreadStatsTag(gb0.痛);
      eb0 eb0 = this.怖.辛(gb0);
      gb0.暑("network-http-complete");
      if (eb0.冷 && gb0.苦()) {
        gb0.寒("not-modified");
        gb0.旨();
        gb0.辛(4);
        return;
      } 
      ib0 ib0 = gb0.硬(eb0);
      gb0.暑("network-parse-complete");
      if ((ta0)ib0.熱 != null) {
        this.恐.熱(gb0.堅(), (ta0)ib0.熱);
        gb0.暑("network-cache-written");
      } 
      gb0.美();
      yd01.辛(gb0, ib0, null);
      gb0.不(ib0);
      gb0.辛(4);
      return;
    } catch (jb0 null) {
    
    } catch (Exception exception) {
    
    } finally {}
    mb0.堅("Unhandled exception %s", new Object[] { exception.toString() });
    exception = new jb0(exception);
    SystemClock.elapsedRealtime();
    yd01.寒(gb0, (jb0)exception);
    gb0.旨();
    gb0.辛(4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ab0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */