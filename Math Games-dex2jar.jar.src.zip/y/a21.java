package y;

public final class a21 {
  public final x30 硬;
  
  static {
    (new ai1()).熱();
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof a21))
      return false; 
    paramObject = paramObject;
    return this.硬.equals(((a21)paramObject).硬);
  }
  
  public final int hashCode() {
    return this.硬.hashCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */