package y;

import android.os.Handler;
import android.os.Looper;

public final class a13 extends o03 {
  public final j03 ぱ;
  
  public final h81 嬉;
  
  public y03 寂;
  
  public boolean 怖;
  
  public boolean 恐;
  
  public final b71 悲;
  
  public s03 淋;
  
  public boolean 痛;
  
  public final boolean 苦;
  
  public a13(j03 paramj03, boolean paramBoolean) {
    this.ぱ = paramj03;
    if (paramBoolean) {
      paramj03.淋();
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.苦 = paramBoolean;
    this.嬉 = new h81();
    this.悲 = new b71();
    paramj03.暑();
    this.寂 = new y03(new z03(paramj03.熱()), h81.悲, y03.冷);
  }
  
  public final void 嬉() {
    this.恐 = false;
    this.怖 = false;
    super.嬉();
  }
  
  public final void 怖() {}
  
  public final void 暑() {
    this.ぱ.暑();
  }
  
  public final void 淋() {
    this.ぱ.淋();
  }
  
  public final po0 熱() {
    return this.ぱ.熱();
  }
  
  public final void 産(long paramLong) {
    s03 s031 = this.淋;
    int i = this.寂.硬(s031.淋.硬);
    if (i == -1)
      return; 
    y03 y031 = this.寂;
    b71 b711 = this.悲;
    y031.暑(i, b711, false);
    long l2 = b711.暑;
    long l1 = paramLong;
    if (l2 != -9223372036854775807L) {
      l1 = paramLong;
      if (paramLong >= l2)
        l1 = Math.max(0L, l2 - 1L); 
    } 
    s031.臭 = l1;
  }
  
  public final void 硬(c13 paramc13) {
    s03 s031 = (s03)paramc13;
    c13 c131 = s031.痛;
    if (c131 != null) {
      j03 j031 = s031.恐;
      j031.getClass();
      j031.硬(c131);
    } 
    if (paramc13 == this.淋)
      this.淋 = null; 
  }
  
  public final d13 臭(Object paramObject, d13 paramd13) {
    paramObject = paramObject;
    Object object1 = paramd13.硬;
    Object object2 = this.寂.暑;
    paramObject = object1;
    if (object2 != null) {
      paramObject = object1;
      if (object2.equals(object1))
        paramObject = y03.冷; 
    } 
    return paramd13.堅(paramObject);
  }
  
  public final s03 興(d13 paramd13, e40 parame40, long paramLong) {
    boolean bool;
    s03 s031 = new s03(paramd13, parame40, paramLong);
    if (s031.恐 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    ik.は(bool);
    Object object = this.ぱ;
    s031.恐 = (j03)object;
    if (this.恐) {
      Object object2 = this.寂.暑;
      Object object1 = paramd13.硬;
      object = object1;
      if (object2 != null) {
        object = object1;
        if (object1.equals(y03.冷))
          object = this.寂.暑; 
      } 
      s031.不(paramd13.堅(object));
      return s031;
    } 
    this.淋 = s031;
    if (!this.怖) {
      this.怖 = true;
      恐(null, (j03)object);
    } 
    return s031;
  }
  
  public final void 起(Object paramObject, j03 paramj03, t81 paramt81) {
    // Byte code:
    //   0: aload_1
    //   1: checkcast java/lang/Void
    //   4: astore_1
    //   5: aload_0
    //   6: getfield 恐 : Z
    //   9: ifeq -> 57
    //   12: aload_0
    //   13: getfield 寂 : Ly/y03;
    //   16: astore_1
    //   17: aload_0
    //   18: new y/y03
    //   21: dup
    //   22: aload_3
    //   23: aload_1
    //   24: getfield 熱 : Ljava/lang/Object;
    //   27: aload_1
    //   28: getfield 暑 : Ljava/lang/Object;
    //   31: invokespecial <init> : (Ly/t81;Ljava/lang/Object;Ljava/lang/Object;)V
    //   34: putfield 寂 : Ly/y03;
    //   37: aload_0
    //   38: getfield 淋 : Ly/s03;
    //   41: astore_1
    //   42: aload_1
    //   43: ifnull -> 348
    //   46: aload_0
    //   47: aload_1
    //   48: getfield 臭 : J
    //   51: invokevirtual 産 : (J)V
    //   54: goto -> 348
    //   57: aload_3
    //   58: invokevirtual 寂 : ()Z
    //   61: ifeq -> 119
    //   64: aload_0
    //   65: getfield 痛 : Z
    //   68: ifeq -> 96
    //   71: aload_0
    //   72: getfield 寂 : Ly/y03;
    //   75: astore_1
    //   76: new y/y03
    //   79: dup
    //   80: aload_3
    //   81: aload_1
    //   82: getfield 熱 : Ljava/lang/Object;
    //   85: aload_1
    //   86: getfield 暑 : Ljava/lang/Object;
    //   89: invokespecial <init> : (Ly/t81;Ljava/lang/Object;Ljava/lang/Object;)V
    //   92: astore_1
    //   93: goto -> 111
    //   96: new y/y03
    //   99: dup
    //   100: aload_3
    //   101: getstatic y/h81.悲 : Ljava/lang/Object;
    //   104: getstatic y/y03.冷 : Ljava/lang/Object;
    //   107: invokespecial <init> : (Ly/t81;Ljava/lang/Object;Ljava/lang/Object;)V
    //   110: astore_1
    //   111: aload_0
    //   112: aload_1
    //   113: putfield 寂 : Ly/y03;
    //   116: goto -> 348
    //   119: aload_0
    //   120: getfield 嬉 : Ly/h81;
    //   123: astore_2
    //   124: aload_3
    //   125: iconst_0
    //   126: aload_2
    //   127: lconst_0
    //   128: invokevirtual 冷 : (ILy/h81;J)Ly/h81;
    //   131: pop
    //   132: aload_2
    //   133: getfield 硬 : Ljava/lang/Object;
    //   136: astore_1
    //   137: aload_0
    //   138: getfield 淋 : Ly/s03;
    //   141: astore #6
    //   143: aload #6
    //   145: ifnull -> 196
    //   148: aload_0
    //   149: getfield 寂 : Ly/y03;
    //   152: aload #6
    //   154: getfield 淋 : Ly/d13;
    //   157: getfield 硬 : Ljava/lang/Object;
    //   160: aload_0
    //   161: getfield 悲 : Ly/b71;
    //   164: invokevirtual 悲 : (Ljava/lang/Object;Ly/b71;)Ly/b71;
    //   167: pop
    //   168: aload_0
    //   169: getfield 寂 : Ly/y03;
    //   172: iconst_0
    //   173: aload_2
    //   174: lconst_0
    //   175: invokevirtual 冷 : (ILy/h81;J)Ly/h81;
    //   178: pop
    //   179: aload #6
    //   181: getfield 怖 : J
    //   184: lstore #4
    //   186: lload #4
    //   188: lconst_0
    //   189: lcmp
    //   190: ifeq -> 196
    //   193: goto -> 199
    //   196: lconst_0
    //   197: lstore #4
    //   199: aload_3
    //   200: aload_0
    //   201: getfield 嬉 : Ly/h81;
    //   204: aload_0
    //   205: getfield 悲 : Ly/b71;
    //   208: iconst_0
    //   209: lload #4
    //   211: invokevirtual 苦 : (Ly/h81;Ly/b71;IJ)Landroid/util/Pair;
    //   214: astore_2
    //   215: aload_2
    //   216: getfield first : Ljava/lang/Object;
    //   219: astore #6
    //   221: aload_2
    //   222: getfield second : Ljava/lang/Object;
    //   225: checkcast java/lang/Long
    //   228: invokevirtual longValue : ()J
    //   231: lstore #4
    //   233: aload_0
    //   234: getfield 痛 : Z
    //   237: ifeq -> 265
    //   240: aload_0
    //   241: getfield 寂 : Ly/y03;
    //   244: astore_1
    //   245: new y/y03
    //   248: dup
    //   249: aload_3
    //   250: aload_1
    //   251: getfield 熱 : Ljava/lang/Object;
    //   254: aload_1
    //   255: getfield 暑 : Ljava/lang/Object;
    //   258: invokespecial <init> : (Ly/t81;Ljava/lang/Object;Ljava/lang/Object;)V
    //   261: astore_1
    //   262: goto -> 277
    //   265: new y/y03
    //   268: dup
    //   269: aload_3
    //   270: aload_1
    //   271: aload #6
    //   273: invokespecial <init> : (Ly/t81;Ljava/lang/Object;Ljava/lang/Object;)V
    //   276: astore_1
    //   277: aload_0
    //   278: aload_1
    //   279: putfield 寂 : Ly/y03;
    //   282: aload_0
    //   283: getfield 淋 : Ly/s03;
    //   286: astore_1
    //   287: aload_1
    //   288: ifnull -> 348
    //   291: aload_0
    //   292: lload #4
    //   294: invokevirtual 産 : (J)V
    //   297: aload_1
    //   298: getfield 淋 : Ly/d13;
    //   301: astore_3
    //   302: aload_3
    //   303: getfield 硬 : Ljava/lang/Object;
    //   306: astore_2
    //   307: aload_2
    //   308: astore_1
    //   309: aload_0
    //   310: getfield 寂 : Ly/y03;
    //   313: getfield 暑 : Ljava/lang/Object;
    //   316: ifnull -> 339
    //   319: aload_2
    //   320: astore_1
    //   321: aload_2
    //   322: getstatic y/y03.冷 : Ljava/lang/Object;
    //   325: invokevirtual equals : (Ljava/lang/Object;)Z
    //   328: ifeq -> 339
    //   331: aload_0
    //   332: getfield 寂 : Ly/y03;
    //   335: getfield 暑 : Ljava/lang/Object;
    //   338: astore_1
    //   339: aload_3
    //   340: aload_1
    //   341: invokevirtual 堅 : (Ljava/lang/Object;)Ly/d13;
    //   344: astore_1
    //   345: goto -> 350
    //   348: aconst_null
    //   349: astore_1
    //   350: aload_0
    //   351: iconst_1
    //   352: putfield 痛 : Z
    //   355: aload_0
    //   356: iconst_1
    //   357: putfield 恐 : Z
    //   360: aload_0
    //   361: aload_0
    //   362: getfield 寂 : Ly/y03;
    //   365: invokevirtual ぱ : (Ly/t81;)V
    //   368: aload_1
    //   369: ifnull -> 387
    //   372: aload_0
    //   373: getfield 淋 : Ly/s03;
    //   376: astore_2
    //   377: aload_2
    //   378: invokevirtual getClass : ()Ljava/lang/Class;
    //   381: pop
    //   382: aload_2
    //   383: aload_1
    //   384: invokevirtual 不 : (Ly/d13;)V
    //   387: return
  }
  
  public final void 辛(yd2 paramyd2) {
    this.辛 = paramyd2;
    int i = yx1.硬;
    Looper looper = Looper.myLooper();
    ik.護(looper);
    this.不 = new Handler(looper, null);
    if (!this.苦) {
      this.怖 = true;
      恐(null, this.ぱ);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a13.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */