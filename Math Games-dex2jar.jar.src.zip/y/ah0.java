package y;

import android.media.AudioTrack;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.SystemClock;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedList;

public final class ah0 {
  public pg0[] あ;
  
  public ByteBuffer[] か;
  
  public ByteBuffer ち;
  
  public int ぱ;
  
  public int も;
  
  public ByteBuffer ゃ;
  
  public int わ;
  
  public AudioTrack 不;
  
  public final ConditionVariable 冷;
  
  public long 噛;
  
  public final gh0 堅;
  
  public Method 壊;
  
  public int 嬉;
  
  public long 寂;
  
  public final long[] 寒;
  
  public long 寝;
  
  public int 帰;
  
  public ig0 怖;
  
  public long 恐;
  
  public int 悲;
  
  public float 投;
  
  public final LinkedList 旨;
  
  public final ch0 暑;
  
  public int 歩;
  
  public long 死;
  
  public long 泳;
  
  public ig0 淋;
  
  public final pg0[] 熱;
  
  public boolean 産;
  
  public int 痒;
  
  public long 痛;
  
  public final bh0 硬;
  
  public final ug0 美;
  
  public int 臭;
  
  public long 興;
  
  public boolean 若;
  
  public int 苦;
  
  public long 触;
  
  public byte[] 赤;
  
  public long 起;
  
  public int 踊;
  
  public int 辛;
  
  public long 返;
  
  public boolean 코;
  
  public int 쾌;
  
  public boolean 크;
  
  public ah0(pg0[] paramArrayOfpg0, ch0 paramch0) {
    this.暑 = paramch0;
    this.冷 = new ConditionVariable(true);
    if (wl0.硬 >= 18)
      try {
        this.壊 = AudioTrack.class.getMethod("getLatency", null);
      } catch (NoSuchMethodException noSuchMethodException) {} 
    if (wl0.硬 >= 19) {
      this.美 = new vg0();
    } else {
      this.美 = new ug0();
    } 
    bh0 bh01 = new bh0();
    this.硬 = bh01;
    gh0 gh01 = new gh0();
    this.堅 = gh01;
    pg0[] arrayOfPg0 = new pg0[3];
    this.熱 = arrayOfPg0;
    arrayOfPg0[0] = new eh0();
    arrayOfPg0[1] = bh01;
    System.arraycopy(paramArrayOfpg0, 0, arrayOfPg0, 2, 0);
    arrayOfPg0[2] = gh01;
    this.寒 = new long[10];
    this.投 = 1.0F;
    this.踊 = 0;
    this.쾌 = 0;
    this.怖 = ig0.熱;
    this.も = -1;
    this.あ = new pg0[0];
    this.か = new ByteBuffer[0];
    this.旨 = new LinkedList();
  }
  
  public final boolean ぱ() {
    int i = wl0.硬;
    boolean bool = false;
    if (i < 23) {
      i = this.嬉;
      if (i != 5)
        return !(i != 6); 
      bool = true;
    } 
    return bool;
  }
  
  public final boolean 不() {
    ah0 ah01;
    if (this.も == -1) {
      this.も = 0;
      ah01 = this;
    } else {
      boolean bool1 = false;
      ah01 = this;
      int j = ah01.も;
      pg0[] arrayOfPg01 = ah01.あ;
    } 
    boolean bool = true;
    int i = ah01.も;
    pg0[] arrayOfPg0 = ah01.あ;
  }
  
  public final boolean 冷() {
    if (辛()) {
      long l1 = this.泳 / this.歩;
      long l2 = this.美.硬();
      boolean bool = true;
      if (l1 <= l2) {
        if (ぱ() && this.不.getPlayState() == 2 && this.不.getPlaybackHeadPosition() == 0)
          return true; 
      } else {
        return bool;
      } 
    } 
    return false;
  }
  
  public final void 堅(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: iload_3
    //   2: iload_1
    //   3: invokestatic 暑 : (II)I
    //   6: putfield 帰 : I
    //   9: aload_0
    //   10: getfield 硬 : Ly/bh0;
    //   13: aload #4
    //   15: putfield 暑 : [I
    //   18: iconst_0
    //   19: istore #10
    //   21: iconst_0
    //   22: istore #8
    //   24: iconst_0
    //   25: istore #7
    //   27: iload_3
    //   28: istore #5
    //   30: iload_1
    //   31: istore #6
    //   33: iload #8
    //   35: istore_1
    //   36: iload_1
    //   37: iconst_3
    //   38: if_icmpge -> 118
    //   41: aload_0
    //   42: getfield 熱 : [Ly/pg0;
    //   45: iload_1
    //   46: aaload
    //   47: astore #4
    //   49: aload #4
    //   51: iload_2
    //   52: iload #6
    //   54: iload #5
    //   56: invokeinterface 悲 : (III)Z
    //   61: istore #11
    //   63: iload #7
    //   65: iload #11
    //   67: ior
    //   68: istore #7
    //   70: aload #4
    //   72: invokeinterface 旨 : ()Z
    //   77: ifeq -> 99
    //   80: aload #4
    //   82: invokeinterface 硬 : ()I
    //   87: istore #6
    //   89: aload #4
    //   91: invokeinterface 暑 : ()V
    //   96: iconst_2
    //   97: istore #5
    //   99: iload_1
    //   100: iconst_1
    //   101: iadd
    //   102: istore_1
    //   103: goto -> 36
    //   106: astore #4
    //   108: new y/wg0
    //   111: dup
    //   112: aload #4
    //   114: invokespecial <init> : (Ly/og0;)V
    //   117: athrow
    //   118: iload #7
    //   120: ifeq -> 127
    //   123: aload_0
    //   124: invokevirtual 美 : ()V
    //   127: sipush #252
    //   130: istore #8
    //   132: iload #6
    //   134: tableswitch default -> 180, 1 -> 242, 2 -> 236, 3 -> 230, 4 -> 223, 5 -> 216, 6 -> 209, 7 -> 202, 8 -> 195
    //   180: new y/wg0
    //   183: dup
    //   184: ldc 'Unsupported channel count: '
    //   186: iload #6
    //   188: invokestatic 熱 : (Ljava/lang/String;I)Ljava/lang/String;
    //   191: invokespecial <init> : (Ljava/lang/String;)V
    //   194: athrow
    //   195: getstatic y/uf0.硬 : I
    //   198: istore_1
    //   199: goto -> 244
    //   202: sipush #1276
    //   205: istore_1
    //   206: goto -> 244
    //   209: sipush #252
    //   212: istore_1
    //   213: goto -> 244
    //   216: sipush #220
    //   219: istore_1
    //   220: goto -> 244
    //   223: sipush #204
    //   226: istore_1
    //   227: goto -> 244
    //   230: bipush #28
    //   232: istore_1
    //   233: goto -> 244
    //   236: bipush #12
    //   238: istore_1
    //   239: goto -> 244
    //   242: iconst_4
    //   243: istore_1
    //   244: getstatic y/wl0.硬 : I
    //   247: istore #9
    //   249: iload #9
    //   251: bipush #23
    //   253: if_icmpgt -> 313
    //   256: ldc 'foster'
    //   258: getstatic y/wl0.堅 : Ljava/lang/String;
    //   261: invokevirtual equals : (Ljava/lang/Object;)Z
    //   264: ifeq -> 313
    //   267: ldc 'NVIDIA'
    //   269: getstatic y/wl0.熱 : Ljava/lang/String;
    //   272: invokevirtual equals : (Ljava/lang/Object;)Z
    //   275: ifeq -> 313
    //   278: iload #8
    //   280: istore_3
    //   281: iload #6
    //   283: iconst_3
    //   284: if_icmpeq -> 315
    //   287: iload #8
    //   289: istore_3
    //   290: iload #6
    //   292: iconst_5
    //   293: if_icmpeq -> 315
    //   296: iload #6
    //   298: bipush #7
    //   300: if_icmpeq -> 306
    //   303: goto -> 313
    //   306: getstatic y/uf0.硬 : I
    //   309: istore_3
    //   310: goto -> 315
    //   313: iload_1
    //   314: istore_3
    //   315: iload #9
    //   317: bipush #25
    //   319: if_icmpgt -> 331
    //   322: ldc 'fugu'
    //   324: getstatic y/wl0.堅 : Ljava/lang/String;
    //   327: invokevirtual equals : (Ljava/lang/Object;)Z
    //   330: pop
    //   331: iload #7
    //   333: ifne -> 372
    //   336: aload_0
    //   337: invokevirtual 辛 : ()Z
    //   340: ifeq -> 372
    //   343: aload_0
    //   344: getfield 苦 : I
    //   347: iload #5
    //   349: if_icmpne -> 372
    //   352: aload_0
    //   353: getfield 辛 : I
    //   356: iload_2
    //   357: if_icmpne -> 372
    //   360: aload_0
    //   361: getfield ぱ : I
    //   364: iload_3
    //   365: if_icmpeq -> 371
    //   368: goto -> 372
    //   371: return
    //   372: aload_0
    //   373: invokevirtual 熱 : ()V
    //   376: aload_0
    //   377: iload #5
    //   379: putfield 苦 : I
    //   382: aload_0
    //   383: iload_2
    //   384: putfield 辛 : I
    //   387: aload_0
    //   388: iload_3
    //   389: putfield ぱ : I
    //   392: aload_0
    //   393: iconst_2
    //   394: putfield 嬉 : I
    //   397: aload_0
    //   398: iconst_2
    //   399: iload #6
    //   401: invokestatic 暑 : (II)I
    //   404: putfield 歩 : I
    //   407: iload_2
    //   408: iload_3
    //   409: aload_0
    //   410: getfield 嬉 : I
    //   413: invokestatic getMinBufferSize : (III)I
    //   416: istore_3
    //   417: iload_3
    //   418: bipush #-2
    //   420: if_icmpeq -> 426
    //   423: iconst_1
    //   424: istore #10
    //   426: iload #10
    //   428: invokestatic 年 : (Z)V
    //   431: iload_3
    //   432: iconst_4
    //   433: imul
    //   434: istore_2
    //   435: aload_0
    //   436: getfield 辛 : I
    //   439: istore #5
    //   441: iload #5
    //   443: i2l
    //   444: ldc2_w 250000
    //   447: lmul
    //   448: ldc2_w 1000000
    //   451: ldiv
    //   452: lstore #12
    //   454: aload_0
    //   455: getfield 歩 : I
    //   458: istore #6
    //   460: lload #12
    //   462: l2i
    //   463: iload #6
    //   465: imul
    //   466: istore_1
    //   467: iload_3
    //   468: i2l
    //   469: iload #5
    //   471: i2l
    //   472: ldc2_w 750000
    //   475: lmul
    //   476: ldc2_w 1000000
    //   479: ldiv
    //   480: iload #6
    //   482: i2l
    //   483: lmul
    //   484: invokestatic max : (JJ)J
    //   487: l2i
    //   488: istore_3
    //   489: iload_2
    //   490: iload_1
    //   491: if_icmpge -> 497
    //   494: goto -> 506
    //   497: iload_2
    //   498: istore_1
    //   499: iload_2
    //   500: iload_3
    //   501: if_icmple -> 506
    //   504: iload_3
    //   505: istore_1
    //   506: aload_0
    //   507: iload_1
    //   508: putfield 悲 : I
    //   511: aload_0
    //   512: iload_1
    //   513: aload_0
    //   514: getfield 歩 : I
    //   517: idiv
    //   518: i2l
    //   519: ldc2_w 1000000
    //   522: lmul
    //   523: aload_0
    //   524: getfield 辛 : I
    //   527: i2l
    //   528: ldiv
    //   529: putfield 寂 : J
    //   532: aload_0
    //   533: aload_0
    //   534: getfield 怖 : Ly/ig0;
    //   537: invokevirtual 硬 : (Ly/ig0;)Ly/ig0;
    //   540: pop
    //   541: return
    // Exception table:
    //   from	to	target	type
    //   49	63	106	y/og0
  }
  
  public final void 寒(long paramLong) {
    int j = this.あ.length;
    for (int i = j; i >= 0; i--) {
      ByteBuffer byteBuffer;
      if (i > 0) {
        byteBuffer = this.か[i - 1];
      } else {
        ByteBuffer byteBuffer1 = this.ち;
        byteBuffer = byteBuffer1;
        if (byteBuffer1 == null)
          byteBuffer = pg0.硬; 
      } 
      if (i == j) {
        苦(byteBuffer);
      } else {
        pg0 pg01 = this.あ[i];
        pg01.嬉(byteBuffer);
        ByteBuffer byteBuffer1 = pg01.熱();
        this.か[i] = byteBuffer1;
        if (byteBuffer1.hasRemaining()) {
          i++;
          continue;
        } 
      } 
      if (byteBuffer.hasRemaining())
        return; 
    } 
  }
  
  public final void 旨() {
    if (!辛())
      return; 
    if (wl0.硬 >= 21) {
      this.不.setVolume(this.投);
      return;
    } 
    AudioTrack audioTrack = this.不;
    float f = this.投;
    audioTrack.setStereoVolume(f, f);
  }
  
  public final boolean 暑(ByteBuffer paramByteBuffer, long paramLong) {
    ByteBuffer byteBuffer = this.ち;
    if (byteBuffer == null || paramByteBuffer == byteBuffer) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    p31.퇴(bool1);
    boolean bool1 = 辛();
    ug0 ug01 = this.美;
    ch0 ch01 = this.暑;
    if (!bool1) {
      this.冷.block();
      int i = this.쾌;
      if (i == 0) {
        this.不 = new AudioTrack(3, this.辛, this.ぱ, this.嬉, this.悲, 1);
      } else {
        this.不 = new AudioTrack(3, this.辛, this.ぱ, this.嬉, this.悲, 1, i);
      } 
      i = this.不.getState();
      if (i == 1) {
        i = this.不.getAudioSessionId();
        if (this.쾌 != i) {
          this.쾌 = i;
          ((Handler)ch01.硬.わ.怖).post(new rg0(0));
        } 
        ug01.暑(this.不, ぱ());
        旨();
        this.크 = false;
        if (this.코) {
          this.코 = true;
          if (辛()) {
            this.噛 = System.nanoTime() / 1000L;
            this.不.play();
          } 
        } 
      } else {
        try {
          this.不.release();
        } catch (Exception exception) {
        
        } finally {
          this.不 = null;
        } 
        throw new xg0(i, this.辛, this.ぱ, this.悲);
      } 
    } 
    if (ぱ()) {
      if (this.不.getPlayState() == 2) {
        this.크 = false;
        return false;
      } 
      if (this.不.getPlayState() == 1 && ug01.硬() != 0L)
        return false; 
    } 
    bool1 = this.크;
    boolean bool2 = 冷();
    this.크 = bool2;
    if (bool1 && !bool2 && this.不.getPlayState() != 1) {
      SystemClock.elapsedRealtime();
      uf0.硬(this.寂);
      ((Handler)ch01.硬.わ.怖).post(new rg0());
    } 
    if (this.ち == null) {
      if (!paramByteBuffer.hasRemaining())
        return true; 
      if (this.淋 != null) {
        if (!不())
          return false; 
        this.旨.add(new yg0(this.淋, Math.max(0L, paramLong), this.泳 / this.歩 * 1000000L / this.辛));
        this.淋 = null;
        美();
      } 
      int i = this.踊;
      if (i == 0) {
        this.寝 = Math.max(0L, paramLong);
        this.踊 = 1;
      } else {
        long l = this.寝;
        l = this.返 / this.帰 * 1000000L / this.辛 + l;
        if (i == 1 && Math.abs(l - paramLong) > 200000L)
          this.踊 = 2; 
        if (this.踊 == 2) {
          this.寝 = paramLong - l + this.寝;
          this.踊 = 1;
          ch01.硬.큰 = true;
        } 
      } 
      this.返 += paramByteBuffer.remaining();
      this.ち = paramByteBuffer;
    } 
    寒(paramLong);
    if (!this.ち.hasRemaining()) {
      this.ち = null;
      return true;
    } 
    return false;
  }
  
  public final void 熱() {
    if (辛()) {
      this.返 = 0L;
      this.泳 = 0L;
      ig0 ig01 = this.淋;
      LinkedList linkedList = this.旨;
      if (ig01 != null) {
        this.怖 = ig01;
        this.淋 = null;
      } else if (!linkedList.isEmpty()) {
        this.怖 = ((yg0)linkedList.getLast()).硬;
      } 
      linkedList.clear();
      this.恐 = 0L;
      this.痛 = 0L;
      this.ち = null;
      this.ゃ = null;
      int i = 0;
      while (true) {
        pg0[] arrayOfPg0 = this.あ;
        if (i < arrayOfPg0.length) {
          pg0 pg01 = arrayOfPg0[i];
          pg01.美();
          this.か[i] = pg01.熱();
          i++;
          continue;
        } 
        this.若 = false;
        this.も = -1;
        this.踊 = 0;
        this.触 = 0L;
        this.起 = 0L;
        this.臭 = 0;
        this.痒 = 0;
        this.興 = 0L;
        this.産 = false;
        this.死 = 0L;
        if (this.不.getPlayState() == 3)
          this.不.pause(); 
        AudioTrack audioTrack = this.不;
        this.不 = null;
        this.美.暑(null, false);
        this.冷.close();
        (new tg0(this, audioTrack)).start();
        break;
      } 
    } 
  }
  
  public final ig0 硬(ig0 paramig0) {
    float f = paramig0.硬;
    gh0 gh01 = this.堅;
    gh01.getClass();
    int i = wl0.硬;
    f = Math.max(0.1F, Math.min(f, 8.0F));
    gh01.冷 = f;
    gh01.寒 = Math.max(0.1F, Math.min(1.0F, 8.0F));
    ig0 ig03 = new ig0(f);
    ig0 ig02 = this.淋;
    ig0 ig01 = ig02;
    if (ig02 == null) {
      LinkedList linkedList = this.旨;
      if (!linkedList.isEmpty()) {
        ig0 ig04 = ((yg0)linkedList.getLast()).硬;
      } else {
        ig01 = this.怖;
      } 
    } 
    if (!ig03.equals(ig01))
      if (辛()) {
        this.淋 = ig03;
      } else {
        this.怖 = ig03;
      }  
    return this.怖;
  }
  
  public final void 美() {
    ArrayList<pg0> arrayList = new ArrayList();
    boolean bool = false;
    int i;
    for (i = 0; i < 3; i++) {
      pg0 pg01 = this.熱[i];
      if (pg01.旨()) {
        arrayList.add(pg01);
      } else {
        pg01.美();
      } 
    } 
    int j = arrayList.size();
    this.あ = arrayList.<pg0>toArray(new pg0[j]);
    this.か = new ByteBuffer[j];
    for (i = bool; i < j; i++) {
      pg0 pg01 = this.あ[i];
      pg01.美();
      this.か[i] = pg01.熱();
    } 
  }
  
  public final void 苦(ByteBuffer paramByteBuffer) {
    if (!paramByteBuffer.hasRemaining())
      return; 
    ByteBuffer byteBuffer = this.ゃ;
    int i = 0;
    if (byteBuffer != null) {
      boolean bool;
      if (byteBuffer == paramByteBuffer) {
        bool = true;
      } else {
        bool = false;
      } 
      p31.퇴(bool);
    } else {
      this.ゃ = paramByteBuffer;
      if (wl0.硬 < 21) {
        int k = paramByteBuffer.remaining();
        byte[] arrayOfByte = this.赤;
        if (arrayOfByte == null || arrayOfByte.length < k)
          this.赤 = new byte[k]; 
        int m = paramByteBuffer.position();
        paramByteBuffer.get(this.赤, 0, k);
        paramByteBuffer.position(m);
        this.わ = 0;
      } 
    } 
    int j = paramByteBuffer.remaining();
    if (wl0.硬 < 21) {
      long l1 = this.泳;
      long l2 = this.美.硬();
      int k = this.歩;
      k = this.悲 - (int)(l1 - l2 * k);
      if (k > 0) {
        i = Math.min(j, k);
        k = this.不.write(this.赤, this.わ, i);
        i = k;
        if (k > 0) {
          this.わ += k;
          paramByteBuffer.position(paramByteBuffer.position() + k);
          i = k;
        } 
      } 
    } else {
      i = this.不.write(paramByteBuffer, j, 1);
    } 
    SystemClock.elapsedRealtime();
    if (i >= 0) {
      this.泳 += i;
      if (i == j)
        this.ゃ = null; 
      return;
    } 
    throw new zg0(i);
  }
  
  public final boolean 辛() {
    return (this.不 != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ah0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */