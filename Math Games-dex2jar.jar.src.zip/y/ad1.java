package y;

public final class ad1 implements dt2 {
  public final zc1 堅;
  
  public final Object 暑() {
    int i = this.硬;
    zc1 zc11 = this.堅;
    switch (i) {
      default:
        return zc11.堅;
      case 0:
        break;
    } 
    return zc11.硬;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ad1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */