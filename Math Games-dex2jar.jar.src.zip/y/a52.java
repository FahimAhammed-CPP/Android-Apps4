package y;

import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

public final class a52 extends fw0 implements px2, en0 {
  public final Context 怖;
  
  public AtomicBoolean 恐 = new AtomicBoolean();
  
  public hd1 死;
  
  public final ga1 淋;
  
  public yc1 産;
  
  public final y42 痒;
  
  public final String 痛;
  
  public final x42 臭;
  
  public long 興 = -1L;
  
  public final x51 起;
  
  public a52(ga1 paramga1, Context paramContext, String paramString, y42 paramy42, x42 paramx42, x51 paramx51) {
    this.淋 = paramga1;
    this.怖 = paramContext;
    this.痛 = paramString;
    this.痒 = paramy42;
    this.臭 = paramx42;
    this.起 = paramx51;
    paramx42.臭.set(this);
  }
  
  public final void あ(int paramInt) {
    int i = paramInt - 1;
    if (paramInt != 0) {
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3)
              return; 
            タ(6);
            return;
          } 
          タ(3);
          return;
        } 
        タ(4);
        return;
      } 
      タ(2);
      return;
    } 
    throw null;
  }
  
  public final void さ(ci1 paramci1) {}
  
  public final void そ(f41 paramf41) {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final void ち() {}
  
  public final void な(boolean paramBoolean) {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final void に(wv2 paramwv2, fq0 paramfq0) {}
  
  public final void ひ(類 param類) {}
  
  public final boolean ぶ(wv2 paramwv2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xq0.暑 : Ly/lq0;
    //   5: invokevirtual 嬉 : ()Ljava/lang/Object;
    //   8: checkcast java/lang/Boolean
    //   11: invokevirtual booleanValue : ()Z
    //   14: ifeq -> 211
    //   17: getstatic y/xp0.必 : Ly/sp0;
    //   20: astore #5
    //   22: getstatic y/ml0.暑 : Ly/ml0;
    //   25: getfield 熱 : Ly/vp0;
    //   28: aload #5
    //   30: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   33: checkcast java/lang/Boolean
    //   36: invokevirtual booleanValue : ()Z
    //   39: ifeq -> 211
    //   42: iconst_1
    //   43: istore_2
    //   44: goto -> 47
    //   47: aload_0
    //   48: getfield 起 : Ly/x51;
    //   51: getfield 恐 : I
    //   54: istore_3
    //   55: getstatic y/xp0.要 : Ly/sp0;
    //   58: astore #5
    //   60: iload_3
    //   61: getstatic y/ml0.暑 : Ly/ml0;
    //   64: getfield 熱 : Ly/vp0;
    //   67: aload #5
    //   69: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   72: checkcast java/lang/Integer
    //   75: invokevirtual intValue : ()I
    //   78: if_icmplt -> 85
    //   81: iload_2
    //   82: ifne -> 90
    //   85: ldc 'loadAd must be called on the main UI thread.'
    //   87: invokestatic 暑 : (Ljava/lang/String;)V
    //   90: getstatic y/t13.帰 : Ly/t13;
    //   93: getfield 熱 : Ly/u03;
    //   96: astore #5
    //   98: aload_0
    //   99: getfield 怖 : Landroid/content/Context;
    //   102: invokestatic 熱 : (Landroid/content/Context;)Z
    //   105: ifeq -> 140
    //   108: aload_1
    //   109: getfield 触 : Ly/n01;
    //   112: ifnull -> 118
    //   115: goto -> 140
    //   118: ldc 'Failed to load the ad because app ID is missing.'
    //   120: invokestatic 冷 : (Ljava/lang/String;)V
    //   123: aload_0
    //   124: getfield 臭 : Ly/x42;
    //   127: iconst_4
    //   128: aconst_null
    //   129: aconst_null
    //   130: invokestatic し : (ILjava/lang/String;Ly/qr1;)Ly/qr1;
    //   133: invokevirtual 冷 : (Ly/qr1;)V
    //   136: aload_0
    //   137: monitorexit
    //   138: iconst_0
    //   139: ireturn
    //   140: aload_0
    //   141: invokevirtual 族 : ()Z
    //   144: istore #4
    //   146: iload #4
    //   148: ifeq -> 155
    //   151: aload_0
    //   152: monitorexit
    //   153: iconst_0
    //   154: ireturn
    //   155: aload_0
    //   156: new java/util/concurrent/atomic/AtomicBoolean
    //   159: dup
    //   160: invokespecial <init> : ()V
    //   163: putfield 恐 : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   166: new y/p42
    //   169: dup
    //   170: invokespecial <init> : ()V
    //   173: astore #5
    //   175: aload_0
    //   176: getfield 痒 : Ly/y42;
    //   179: aload_1
    //   180: aload_0
    //   181: getfield 痛 : Ljava/lang/String;
    //   184: aload #5
    //   186: new y/z32
    //   189: dup
    //   190: bipush #22
    //   192: aload_0
    //   193: invokespecial <init> : (ILjava/lang/Object;)V
    //   196: invokevirtual 冷 : (Ly/wv2;Ljava/lang/String;Ly/k21;Ly/j02;)Z
    //   199: istore #4
    //   201: aload_0
    //   202: monitorexit
    //   203: iload #4
    //   205: ireturn
    //   206: astore_1
    //   207: aload_0
    //   208: monitorexit
    //   209: aload_1
    //   210: athrow
    //   211: iconst_0
    //   212: istore_2
    //   213: goto -> 47
    // Exception table:
    //   from	to	target	type
    //   2	42	206	finally
    //   47	81	206	finally
    //   85	90	206	finally
    //   90	115	206	finally
    //   118	136	206	finally
    //   140	146	206	finally
    //   155	201	206	finally
  }
  
  public final void ぼ(bp0 parambp0) {}
  
  public final void む(k11 paramk11) {}
  
  public final void も() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'destroy must be called on the main UI thread.'
    //   4: invokestatic 暑 : (Ljava/lang/String;)V
    //   7: aload_0
    //   8: getfield 死 : Ly/hd1;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 23
    //   16: aload_1
    //   17: invokevirtual 硬 : ()V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	26	finally
    //   16	20	26	finally
  }
  
  public final void ゃ() {}
  
  public final void ゆ(q21 paramq21) {}
  
  public final void ょ(s72 params72) {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final void わ() {}
  
  public final void タ(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 恐 : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   6: iconst_0
    //   7: iconst_1
    //   8: invokevirtual compareAndSet : (ZZ)Z
    //   11: ifeq -> 110
    //   14: aload_0
    //   15: getfield 臭 : Ly/x42;
    //   18: invokevirtual 暑 : ()V
    //   21: aload_0
    //   22: getfield 産 : Ly/yc1;
    //   25: astore #6
    //   27: aload #6
    //   29: ifnull -> 43
    //   32: getstatic y/t13.帰 : Ly/t13;
    //   35: getfield 寒 : Ly/wm0;
    //   38: aload #6
    //   40: invokevirtual ぱ : (Ly/yc1;)V
    //   43: aload_0
    //   44: getfield 死 : Ly/hd1;
    //   47: ifnull -> 103
    //   50: aload_0
    //   51: getfield 興 : J
    //   54: lstore #4
    //   56: ldc2_w -1
    //   59: lstore_2
    //   60: lload #4
    //   62: ldc2_w -1
    //   65: lcmp
    //   66: ifne -> 72
    //   69: goto -> 91
    //   72: getstatic y/t13.帰 : Ly/t13;
    //   75: getfield 辛 : Ly/꿈;
    //   78: invokevirtual getClass : ()Ljava/lang/Class;
    //   81: pop
    //   82: invokestatic elapsedRealtime : ()J
    //   85: aload_0
    //   86: getfield 興 : J
    //   89: lsub
    //   90: lstore_2
    //   91: aload_0
    //   92: getfield 死 : Ly/hd1;
    //   95: getfield 苦 : Ly/d11;
    //   98: iload_1
    //   99: lload_2
    //   100: invokevirtual 不 : (IJ)V
    //   103: aload_0
    //   104: invokevirtual も : ()V
    //   107: aload_0
    //   108: monitorexit
    //   109: return
    //   110: aload_0
    //   111: monitorexit
    //   112: return
    //   113: astore #6
    //   115: aload_0
    //   116: monitorexit
    //   117: aload #6
    //   119: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	113	finally
    //   32	43	113	finally
    //   43	56	113	finally
    //   72	91	113	finally
    //   91	103	113	finally
    //   103	107	113	finally
  }
  
  public final void ㅌ() {}
  
  public final void 先(mn0 parammn0) {
    this.臭.怖.set(parammn0);
  }
  
  public final dz2 冷() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
    return null;
  }
  
  public final void 堅() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 死 : Ly/hd1;
    //   6: astore #5
    //   8: aload #5
    //   10: ifnull -> 47
    //   13: getstatic y/t13.帰 : Ly/t13;
    //   16: getfield 辛 : Ly/꿈;
    //   19: invokevirtual getClass : ()Ljava/lang/Class;
    //   22: pop
    //   23: invokestatic elapsedRealtime : ()J
    //   26: lstore_1
    //   27: aload_0
    //   28: getfield 興 : J
    //   31: lstore_3
    //   32: aload #5
    //   34: getfield 苦 : Ly/d11;
    //   37: iconst_1
    //   38: lload_1
    //   39: lload_3
    //   40: lsub
    //   41: invokevirtual 不 : (IJ)V
    //   44: aload_0
    //   45: monitorexit
    //   46: return
    //   47: aload_0
    //   48: monitorexit
    //   49: return
    //   50: astore #5
    //   52: aload_0
    //   53: monitorexit
    //   54: aload #5
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	50	finally
    //   13	44	50	finally
  }
  
  public final void 婦(rn0 paramrn0) {}
  
  public final 類 嬉() {
    return null;
  }
  
  public final void 子(b61 paramb61) {}
  
  public final void 官(hq0 paramhq0) {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final ym1 寂() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
    return null;
  }
  
  public final void 怖() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 死 : Ly/hd1;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: getstatic y/t13.帰 : Ly/t13;
    //   17: astore_2
    //   18: aload_2
    //   19: getfield 辛 : Ly/꿈;
    //   22: invokevirtual getClass : ()Ljava/lang/Class;
    //   25: pop
    //   26: aload_0
    //   27: invokestatic elapsedRealtime : ()J
    //   30: putfield 興 : J
    //   33: aload_0
    //   34: getfield 死 : Ly/hd1;
    //   37: getfield 辛 : I
    //   40: istore_1
    //   41: iload_1
    //   42: ifgt -> 48
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: new y/yc1
    //   51: dup
    //   52: aload_0
    //   53: getfield 淋 : Ly/ga1;
    //   56: checkcast y/xa1
    //   59: getfield 寒 : Ly/kt2;
    //   62: invokeinterface 暑 : ()Ljava/lang/Object;
    //   67: checkcast java/util/concurrent/ScheduledExecutorService
    //   70: aload_2
    //   71: getfield 辛 : Ly/꿈;
    //   74: invokespecial <init> : (Ljava/util/concurrent/ScheduledExecutorService;Ly/꿈;)V
    //   77: astore_2
    //   78: aload_0
    //   79: aload_2
    //   80: putfield 産 : Ly/yc1;
    //   83: aload_2
    //   84: iload_1
    //   85: new y/z42
    //   88: dup
    //   89: aload_0
    //   90: iconst_1
    //   91: invokespecial <init> : (Ly/a52;I)V
    //   94: invokevirtual 堅 : (ILjava/lang/Runnable;)V
    //   97: aload_0
    //   98: monitorexit
    //   99: return
    //   100: astore_2
    //   101: aload_0
    //   102: monitorexit
    //   103: aload_2
    //   104: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	100	finally
    //   14	41	100	finally
    //   48	97	100	finally
  }
  
  public final boolean 族() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 痒 : Ly/y42;
    //   6: invokevirtual 暑 : ()Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public final bp0 旨() {
    return null;
  }
  
  public final void 泳() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc_w 'resume must be called on the main UI thread.'
    //   5: invokestatic 暑 : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  public final String 産() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
    return null;
  }
  
  public final void 硬() {
    タ(3);
  }
  
  public final Bundle 美() {
    return new Bundle();
  }
  
  public final void 者() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final void 耳() {}
  
  public final void 脛() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc_w 'pause must be called on the main UI thread.'
    //   5: invokestatic 暑 : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  public final String 臭() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 痛 : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final String 興() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
    return null;
  }
  
  public final k11 苦() {
    return null;
  }
  
  public final void 血(boolean paramBoolean) {}
  
  public final void 親(dz2 paramdz2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc_w 'setAdSize must be called on the main UI thread.'
    //   5: invokestatic 暑 : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  public final pl1 辛() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
    return null;
  }
  
  public final void 首(w33 paramw33) {
    this.痒.産.不 = paramw33;
  }
  
  public final void 탄() {}
  
  public final void 탈() {}
  
  public final void 탐() {
    /* monitor enter ThisExpression{ObjectType{y/a52}} */
    /* monitor exit ThisExpression{ObjectType{y/a52}} */
  }
  
  public final void 탑() {}
  
  public final boolean 통() {
    return false;
  }
  
  public final void 퉁() {}
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a52.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */