package y;

public final class ad implements bc {
  public final bc 硬;
  
  public ad(sh paramsh) {
    this.硬 = paramsh;
  }
  
  public final Object ぱ(間 param間, 탱 param탱) {
    return this.硬.美(param間, (테)param탱);
  }
  
  public final Object 堅(Object paramObject, 과 param과) {
    paramObject = paramObject;
    return this.硬.堅(paramObject, param과);
  }
  
  public final Object 旨(Object paramObject, 단 param단) {
    paramObject = paramObject;
    return this.硬.旨(paramObject, param단);
  }
  
  public final Object 辛(sd paramsd, 탱 param탱) {
    Object object = this.硬.辛(paramsd, param탱);
    return (object == 페.淋) ? object : hu.硬;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */