package y;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.net.Uri;
import java.io.FileInputStream;
import java.io.IOException;

public final class ad2 extends vz1 {
  public boolean 壊;
  
  public long 死;
  
  public FileInputStream 産;
  
  public final Resources 痒;
  
  public final String 臭;
  
  public AssetFileDescriptor 興;
  
  public Uri 起;
  
  public ad2(Context paramContext) {
    super(false);
    this.痒 = paramContext.getResources();
    this.臭 = paramContext.getPackageName();
  }
  
  public final long 寒(a42 parama42) {
    // Byte code:
    //   0: aload_1
    //   1: getfield 硬 : Landroid/net/Uri;
    //   4: astore #12
    //   6: aload_0
    //   7: aload #12
    //   9: putfield 起 : Landroid/net/Uri;
    //   12: ldc 'rawresource'
    //   14: aload #12
    //   16: invokevirtual getScheme : ()Ljava/lang/String;
    //   19: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   22: istore_3
    //   23: aload_0
    //   24: getfield 痒 : Landroid/content/res/Resources;
    //   27: astore #13
    //   29: iload_3
    //   30: ifne -> 225
    //   33: ldc 'android.resource'
    //   35: aload #12
    //   37: invokevirtual getScheme : ()Ljava/lang/String;
    //   40: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   43: ifeq -> 86
    //   46: aload #12
    //   48: invokevirtual getPathSegments : ()Ljava/util/List;
    //   51: invokeinterface size : ()I
    //   56: iconst_1
    //   57: if_icmpne -> 86
    //   60: aload #12
    //   62: invokevirtual getLastPathSegment : ()Ljava/lang/String;
    //   65: astore #10
    //   67: aload #10
    //   69: invokevirtual getClass : ()Ljava/lang/Class;
    //   72: pop
    //   73: aload #10
    //   75: ldc '\d+'
    //   77: invokevirtual matches : (Ljava/lang/String;)Z
    //   80: ifeq -> 86
    //   83: goto -> 225
    //   86: ldc 'android.resource'
    //   88: aload #12
    //   90: invokevirtual getScheme : ()Ljava/lang/String;
    //   93: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   96: ifeq -> 211
    //   99: aload #12
    //   101: invokevirtual getPath : ()Ljava/lang/String;
    //   104: astore #11
    //   106: aload #11
    //   108: invokevirtual getClass : ()Ljava/lang/Class;
    //   111: pop
    //   112: aload #11
    //   114: astore #10
    //   116: aload #11
    //   118: ldc '/'
    //   120: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   123: ifeq -> 134
    //   126: aload #11
    //   128: iconst_1
    //   129: invokevirtual substring : (I)Ljava/lang/String;
    //   132: astore #10
    //   134: aload #12
    //   136: invokevirtual getHost : ()Ljava/lang/String;
    //   139: astore #11
    //   141: aload #11
    //   143: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   146: ifeq -> 156
    //   149: ldc ''
    //   151: astore #11
    //   153: goto -> 168
    //   156: aload #11
    //   158: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   161: ldc ':'
    //   163: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   166: astore #11
    //   168: aload #13
    //   170: aload #11
    //   172: aload #10
    //   174: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   177: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   180: ldc 'raw'
    //   182: aload_0
    //   183: getfield 臭 : Ljava/lang/String;
    //   186: invokevirtual getIdentifier : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   189: istore_2
    //   190: iload_2
    //   191: ifeq -> 197
    //   194: goto -> 244
    //   197: new y/nc2
    //   200: dup
    //   201: sipush #2005
    //   204: ldc 'Resource not found.'
    //   206: aconst_null
    //   207: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   210: athrow
    //   211: new y/nc2
    //   214: dup
    //   215: sipush #1004
    //   218: ldc 'URI must either use scheme rawresource or android.resource'
    //   220: aconst_null
    //   221: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   224: athrow
    //   225: aload #12
    //   227: invokevirtual getLastPathSegment : ()Ljava/lang/String;
    //   230: astore #10
    //   232: aload #10
    //   234: invokevirtual getClass : ()Ljava/lang/Class;
    //   237: pop
    //   238: aload #10
    //   240: invokestatic parseInt : (Ljava/lang/String;)I
    //   243: istore_2
    //   244: aload_0
    //   245: aload_1
    //   246: invokevirtual 寂 : (Ly/a42;)V
    //   249: aload #13
    //   251: iload_2
    //   252: invokevirtual openRawResourceFd : (I)Landroid/content/res/AssetFileDescriptor;
    //   255: astore #10
    //   257: aload_0
    //   258: aload #10
    //   260: putfield 興 : Landroid/content/res/AssetFileDescriptor;
    //   263: aload #10
    //   265: ifnull -> 575
    //   268: aload #10
    //   270: invokevirtual getLength : ()J
    //   273: lstore #4
    //   275: new java/io/FileInputStream
    //   278: dup
    //   279: aload #10
    //   281: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
    //   284: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   287: astore #11
    //   289: aload_0
    //   290: aload #11
    //   292: putfield 産 : Ljava/io/FileInputStream;
    //   295: aload_1
    //   296: getfield 暑 : J
    //   299: lstore #6
    //   301: lload #4
    //   303: ldc2_w -1
    //   306: lcmp
    //   307: istore_2
    //   308: iload_2
    //   309: ifeq -> 336
    //   312: lload #6
    //   314: lload #4
    //   316: lcmp
    //   317: ifgt -> 323
    //   320: goto -> 336
    //   323: new y/nc2
    //   326: dup
    //   327: sipush #2008
    //   330: aconst_null
    //   331: aconst_null
    //   332: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   335: athrow
    //   336: aload #10
    //   338: invokevirtual getStartOffset : ()J
    //   341: lstore #8
    //   343: aload #11
    //   345: lload #8
    //   347: lload #6
    //   349: ladd
    //   350: invokevirtual skip : (J)J
    //   353: lload #8
    //   355: lsub
    //   356: lstore #8
    //   358: lload #8
    //   360: lload #6
    //   362: lcmp
    //   363: ifne -> 545
    //   366: iload_2
    //   367: ifne -> 444
    //   370: aload #11
    //   372: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   375: astore #10
    //   377: aload #10
    //   379: invokevirtual size : ()J
    //   382: lconst_0
    //   383: lcmp
    //   384: ifne -> 402
    //   387: aload_0
    //   388: ldc2_w -1
    //   391: putfield 死 : J
    //   394: ldc2_w -1
    //   397: lstore #4
    //   399: goto -> 464
    //   402: aload #10
    //   404: invokevirtual size : ()J
    //   407: aload #10
    //   409: invokevirtual position : ()J
    //   412: lsub
    //   413: lstore #4
    //   415: aload_0
    //   416: lload #4
    //   418: putfield 死 : J
    //   421: lload #4
    //   423: lconst_0
    //   424: lcmp
    //   425: iflt -> 431
    //   428: goto -> 464
    //   431: new y/nc2
    //   434: dup
    //   435: sipush #2008
    //   438: aconst_null
    //   439: aconst_null
    //   440: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   443: athrow
    //   444: lload #4
    //   446: lload #8
    //   448: lsub
    //   449: lstore #4
    //   451: aload_0
    //   452: lload #4
    //   454: putfield 死 : J
    //   457: lload #4
    //   459: lconst_0
    //   460: lcmp
    //   461: iflt -> 534
    //   464: aload_1
    //   465: getfield 冷 : J
    //   468: lstore #6
    //   470: lload #6
    //   472: ldc2_w -1
    //   475: lcmp
    //   476: istore_2
    //   477: iload_2
    //   478: ifeq -> 512
    //   481: lload #4
    //   483: ldc2_w -1
    //   486: lcmp
    //   487: ifeq -> 502
    //   490: lload #4
    //   492: lload #6
    //   494: invokestatic min : (JJ)J
    //   497: lstore #4
    //   499: goto -> 506
    //   502: lload #6
    //   504: lstore #4
    //   506: aload_0
    //   507: lload #4
    //   509: putfield 死 : J
    //   512: aload_0
    //   513: iconst_1
    //   514: putfield 壊 : Z
    //   517: aload_0
    //   518: aload_1
    //   519: invokevirtual 淋 : (Ly/a42;)V
    //   522: iload_2
    //   523: ifeq -> 529
    //   526: lload #6
    //   528: lreturn
    //   529: aload_0
    //   530: getfield 死 : J
    //   533: lreturn
    //   534: new y/n22
    //   537: dup
    //   538: sipush #2008
    //   541: invokespecial <init> : (I)V
    //   544: athrow
    //   545: new y/nc2
    //   548: dup
    //   549: sipush #2008
    //   552: aconst_null
    //   553: aconst_null
    //   554: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   557: athrow
    //   558: astore_1
    //   559: new y/nc2
    //   562: dup
    //   563: sipush #2000
    //   566: aconst_null
    //   567: aload_1
    //   568: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   571: athrow
    //   572: astore_1
    //   573: aload_1
    //   574: athrow
    //   575: new y/nc2
    //   578: dup
    //   579: sipush #2000
    //   582: ldc 'Resource is compressed: '
    //   584: aload #12
    //   586: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   589: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   592: aconst_null
    //   593: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   596: athrow
    //   597: astore_1
    //   598: new y/nc2
    //   601: dup
    //   602: sipush #2005
    //   605: aconst_null
    //   606: aload_1
    //   607: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   610: athrow
    //   611: new y/nc2
    //   614: dup
    //   615: sipush #1004
    //   618: ldc 'Resource identifier must be an integer.'
    //   620: aconst_null
    //   621: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   624: athrow
    //   625: astore_1
    //   626: goto -> 611
    // Exception table:
    //   from	to	target	type
    //   225	232	625	java/lang/NumberFormatException
    //   238	244	625	java/lang/NumberFormatException
    //   249	257	597	android/content/res/Resources$NotFoundException
    //   323	336	572	y/nc2
    //   323	336	558	java/io/IOException
    //   336	358	572	y/nc2
    //   336	358	558	java/io/IOException
    //   370	394	572	y/nc2
    //   370	394	558	java/io/IOException
    //   402	421	572	y/nc2
    //   402	421	558	java/io/IOException
    //   431	444	572	y/nc2
    //   431	444	558	java/io/IOException
    //   451	457	572	y/nc2
    //   451	457	558	java/io/IOException
    //   534	545	572	y/nc2
    //   534	545	558	java/io/IOException
    //   545	558	572	y/nc2
    //   545	558	558	java/io/IOException
  }
  
  public final int 暑(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 6
    //   4: iconst_0
    //   5: ireturn
    //   6: aload_0
    //   7: getfield 死 : J
    //   10: lstore #5
    //   12: lload #5
    //   14: lconst_0
    //   15: lcmp
    //   16: ifeq -> 148
    //   19: iload_3
    //   20: istore #4
    //   22: lload #5
    //   24: ldc2_w -1
    //   27: lcmp
    //   28: ifeq -> 45
    //   31: iload_3
    //   32: i2l
    //   33: lstore #7
    //   35: lload #5
    //   37: lload #7
    //   39: invokestatic min : (JJ)J
    //   42: l2i
    //   43: istore #4
    //   45: aload_0
    //   46: getfield 産 : Ljava/io/FileInputStream;
    //   49: astore #9
    //   51: getstatic y/yx1.硬 : I
    //   54: istore_3
    //   55: aload #9
    //   57: aload_1
    //   58: iload_2
    //   59: iload #4
    //   61: invokevirtual read : ([BII)I
    //   64: istore_2
    //   65: iload_2
    //   66: iconst_m1
    //   67: if_icmpne -> 103
    //   70: aload_0
    //   71: getfield 死 : J
    //   74: ldc2_w -1
    //   77: lcmp
    //   78: ifne -> 83
    //   81: iconst_m1
    //   82: ireturn
    //   83: new y/nc2
    //   86: dup
    //   87: sipush #2000
    //   90: ldc 'End of stream reached having not read sufficient data.'
    //   92: new java/io/EOFException
    //   95: dup
    //   96: invokespecial <init> : ()V
    //   99: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   102: athrow
    //   103: aload_0
    //   104: getfield 死 : J
    //   107: lstore #5
    //   109: lload #5
    //   111: ldc2_w -1
    //   114: lcmp
    //   115: ifeq -> 127
    //   118: aload_0
    //   119: lload #5
    //   121: iload_2
    //   122: i2l
    //   123: lsub
    //   124: putfield 死 : J
    //   127: aload_0
    //   128: iload_2
    //   129: invokevirtual 帰 : (I)V
    //   132: iload_2
    //   133: ireturn
    //   134: astore_1
    //   135: new y/nc2
    //   138: dup
    //   139: sipush #2000
    //   142: aconst_null
    //   143: aload_1
    //   144: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Exception;)V
    //   147: athrow
    //   148: iconst_m1
    //   149: ireturn
    // Exception table:
    //   from	to	target	type
    //   35	45	134	java/io/IOException
    //   45	65	134	java/io/IOException
  }
  
  public final Uri 熱() {
    return this.起;
  }
  
  public final void 美() {
    this.起 = null;
    try {
      null = this.産;
      if (null != null)
        null.close(); 
    } catch (IOException iOException) {
      throw new nc2(2000, null, iOException);
    } finally {
      null = null;
      this.産 = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ad2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */