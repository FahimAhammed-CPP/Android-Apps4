package y;

public final class a33 {
  public final Object 堅;
  
  public final Object 熱;
  
  public final Object 硬;
  
  public a33(Object paramObject1, Object paramObject2, Object paramObject3) {
    this.硬 = paramObject1;
    this.堅 = paramObject2;
    this.熱 = paramObject3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a33.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */