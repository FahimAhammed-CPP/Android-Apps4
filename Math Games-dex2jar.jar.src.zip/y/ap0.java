package y;

import android.os.Handler;

public final class ap0 implements m51 {
  public final o71 怖;
  
  public final o71 淋;
  
  public ap0(o71 paramo711, o71 paramo712) {
    this.淋 = paramo711;
    this.怖 = paramo712;
  }
  
  public final Object 暑() {
    ip0 ip0 = (ip0)this.淋.暑();
    Handler handler = t21.硬;
    ik.少(handler);
    return new qo0(ip0, handler, ((rs0)this.怖).硬());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ap0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */