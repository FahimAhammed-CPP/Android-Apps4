package y;

public final class an0 {
  public static final an0 硬 = new an0();
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof an0))
      return false; 
    ((an0)paramObject).getClass();
    return (yx1.暑(null, null) && yx1.暑(null, null));
  }
  
  public final int hashCode() {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\an0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */