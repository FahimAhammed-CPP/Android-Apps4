package y;

public final class am1 implements qk1 {
  public final ph1 淋;
  
  public am1(ph1 paramph1) {
    this.淋 = paramph1;
  }
  
  public final void 怖() {}
  
  public final void 硬() {
    ph1 ph11 = this.淋;
    ph11.getClass();
    ph11.察(new mz1(13, null));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\am1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */