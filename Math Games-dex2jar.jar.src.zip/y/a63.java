package y;

import android.net.Uri;
import java.util.Map;

public interface a63 {
  w53[] 淋(Uri paramUri, Map paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a63.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */