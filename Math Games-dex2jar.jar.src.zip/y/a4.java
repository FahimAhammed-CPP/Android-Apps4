package y;

import android.os.Parcel;
import android.os.Parcelable;

public final class a4 extends transient {
  public static final Parcelable.Creator<a4> CREATOR = new jv2(7);
  
  public final int 怖;
  
  public final int 恐;
  
  public final int 淋;
  
  public final int 産;
  
  public final long 痒;
  
  public final long 痛;
  
  public final String 臭;
  
  public final int 興;
  
  public final String 起;
  
  public a4(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, String paramString1, String paramString2, int paramInt4, int paramInt5) {
    this.淋 = paramInt1;
    this.怖 = paramInt2;
    this.恐 = paramInt3;
    this.痛 = paramLong1;
    this.痒 = paramLong2;
    this.臭 = paramString1;
    this.起 = paramString2;
    this.興 = paramInt4;
    this.産 = paramInt5;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = ik.俺(paramParcel, 20293);
    ik.퉁(paramParcel, 1, this.淋);
    ik.퉁(paramParcel, 2, this.怖);
    ik.퉁(paramParcel, 3, this.恐);
    ik.者(paramParcel, 4, this.痛);
    ik.者(paramParcel, 5, this.痒);
    ik.し(paramParcel, 6, this.臭);
    ik.し(paramParcel, 7, this.起);
    ik.퉁(paramParcel, 8, this.興);
    ik.퉁(paramParcel, 9, this.産);
    ik.看(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */