package y;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;

public final class al extends fl {
  public final cl 堅;
  
  public al(cl paramcl) {
    this.堅 = paramcl;
  }
  
  public final void 硬(Matrix paramMatrix, uk paramuk, int paramInt, Canvas paramCanvas) {
    boolean bool;
    cl cl1 = this.堅;
    float f1 = cl1.寒;
    float f2 = cl1.美;
    RectF rectF = new RectF(cl1.堅, cl1.熱, cl1.暑, cl1.冷);
    paramuk.getClass();
    if (f2 < 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    Path path = paramuk.美;
    int[] arrayOfInt = uk.ぱ;
    if (bool) {
      arrayOfInt[0] = 0;
      arrayOfInt[1] = paramuk.寒;
      arrayOfInt[2] = paramuk.冷;
      arrayOfInt[3] = paramuk.暑;
    } else {
      path.rewind();
      path.moveTo(rectF.centerX(), rectF.centerY());
      path.arcTo(rectF, f1, f2);
      path.close();
      float f = -paramInt;
      rectF.inset(f, f);
      arrayOfInt[0] = 0;
      arrayOfInt[1] = paramuk.暑;
      arrayOfInt[2] = paramuk.冷;
      arrayOfInt[3] = paramuk.寒;
    } 
    float f3 = rectF.width() / 2.0F;
    if (f3 <= 0.0F)
      return; 
    float f4 = 1.0F - paramInt / f3;
    float f5 = (1.0F - f4) / 2.0F;
    float[] arrayOfFloat = uk.苦;
    arrayOfFloat[1] = f4;
    arrayOfFloat[2] = f5 + f4;
    RadialGradient radialGradient = new RadialGradient(rectF.centerX(), rectF.centerY(), f3, arrayOfInt, arrayOfFloat, Shader.TileMode.CLAMP);
    Paint paint = paramuk.堅;
    paint.setShader((Shader)radialGradient);
    paramCanvas.save();
    paramCanvas.concat(paramMatrix);
    paramCanvas.scale(1.0F, rectF.height() / rectF.width());
    if (!bool) {
      paramCanvas.clipPath(path, Region.Op.DIFFERENCE);
      paramCanvas.drawPath(path, paramuk.旨);
    } 
    paramCanvas.drawArc(rectF, f1, f2, true, paint);
    paramCanvas.restore();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */