package y;

import android.text.TextUtils;

public final class aj0 {
  public final boolean 堅;
  
  public final String 硬;
  
  public aj0(String paramString, boolean paramBoolean) {
    this.硬 = paramString;
    this.堅 = paramBoolean;
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (paramObject.getClass() != aj0.class)
        return false; 
      paramObject = paramObject;
      if (TextUtils.equals(this.硬, ((aj0)paramObject).硬) && this.堅 == ((aj0)paramObject).堅)
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    int i;
    char c;
    String str = this.硬;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    if (true != this.堅) {
      c = 'ӕ';
    } else {
      c = 'ӏ';
    } 
    return (i + 31) * 31 + c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aj0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */