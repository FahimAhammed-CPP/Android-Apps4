package y;

public final class aa {
  public final Long 堅;
  
  public final String 硬;
  
  public aa(long paramLong, String paramString) {
    this.硬 = paramString;
    this.堅 = Long.valueOf(paramLong);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof aa))
      return false; 
    paramObject = paramObject;
    String str = ((aa)paramObject).硬;
    if (!this.硬.equals(str))
      return false; 
    paramObject = ((aa)paramObject).堅;
    Long long_ = this.堅;
    return (long_ != null) ? long_.equals(paramObject) : ((paramObject == null));
  }
  
  public final int hashCode() {
    byte b;
    int i = this.硬.hashCode();
    Long long_ = this.堅;
    if (long_ != null) {
      b = long_.hashCode();
    } else {
      b = 0;
    } 
    return i * 31 + b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */