package y;

import java.util.NoSuchElementException;

public final class ap2 extends tg2 {
  public int 怖 = 0;
  
  public final int 恐;
  
  public ap2(fp2 paramfp2) {
    super(1);
    this.恐 = paramfp2.辛();
  }
  
  public final boolean hasNext() {
    return (this.怖 < this.恐);
  }
  
  public final byte 硬() {
    int i = this.怖;
    if (i < this.恐) {
      this.怖 = i + 1;
      return this.痛.旨(i);
    } 
    throw new NoSuchElementException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ap2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */