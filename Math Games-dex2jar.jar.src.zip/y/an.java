package y;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

public abstract class an extends 랭 {
  public zm 歩;
  
  public boolean 泳;
  
  public final void applyTheme(Resources.Theme paramTheme) {
    super.applyTheme(paramTheme);
    onStateChange(getState());
  }
  
  public Drawable mutate() {
    if (!this.泳) {
      super.mutate();
      this.歩.冷();
      this.泳 = true;
    } 
    return this;
  }
  
  public abstract boolean onStateChange(int[] paramArrayOfint);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */