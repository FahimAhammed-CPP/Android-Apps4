package y;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public final class a71 {
  public boolean ぱ;
  
  public boolean 不;
  
  public final cq0 冷;
  
  public final String 堅;
  
  public boolean 嬉;
  
  public boolean 寂;
  
  public final 窓 寒;
  
  public long 怖;
  
  public o61 悲;
  
  public final String[] 旨;
  
  public final aq0 暑;
  
  public boolean 淋;
  
  public final x51 熱;
  
  public final Context 硬;
  
  public final long[] 美;
  
  public boolean 苦;
  
  public boolean 辛;
  
  public a71(Context paramContext, x51 paramx51, String paramString, cq0 paramcq0, aq0 paramaq0) {
    茎 茎 = new 茎(15);
    茎.起("min_1", Double.MIN_VALUE, 1.0D);
    茎.起("1_5", 1.0D, 5.0D);
    茎.起("5_10", 5.0D, 10.0D);
    茎.起("10_20", 10.0D, 20.0D);
    茎.起("20_30", 20.0D, 30.0D);
    茎.起("30_max", 30.0D, Double.MAX_VALUE);
    this.寒 = new 窓(茎);
    int i = 0;
    this.不 = false;
    this.辛 = false;
    this.ぱ = false;
    this.苦 = false;
    this.怖 = -1L;
    this.硬 = paramContext;
    this.熱 = paramx51;
    this.堅 = paramString;
    this.冷 = paramcq0;
    this.暑 = paramaq0;
    sp0 sp0 = xp0.起;
    String str = (String)ml0.暑.熱.硬(sp0);
    if (str == null) {
      this.旨 = new String[0];
      this.美 = new long[0];
      return;
    } 
    String[] arrayOfString = TextUtils.split(str, ",");
    int j = arrayOfString.length;
    this.旨 = new String[j];
    this.美 = new long[j];
    while (true) {
      if (i < arrayOfString.length) {
        try {
          this.美[i] = Long.parseLong(arrayOfString[i]);
        } catch (NumberFormatException numberFormatException) {
          df1 df1 = rr1.硬;
          this.美[i] = -1L;
        } 
        i++;
        continue;
      } 
      return;
    } 
  }
  
  public final void 堅(o61 paramo61) {
    if (this.ぱ && !this.苦) {
      if (rr1.堅() && !this.苦)
        rr1.硬("VideoMetricsMixin first frame"); 
      p31.か(this.冷, this.暑, new String[] { "vff2" });
      this.苦 = true;
    } 
    t13.帰.辛.getClass();
    long l1 = System.nanoTime();
    if (this.嬉 && this.淋 && this.怖 != -1L) {
      long l3 = TimeUnit.SECONDS.toNanos(1L);
      long l4 = this.怖;
      double d = l3 / (l1 - l4);
      窓 窓1 = this.寒;
      窓1.淋++;
      int j = 0;
      while (true) {
        double[] arrayOfDouble = (double[])窓1.痛;
        if (j < arrayOfDouble.length) {
          double d1 = arrayOfDouble[j];
          if (d1 <= d && d < ((double[])窓1.恐)[j]) {
            int[] arrayOfInt = (int[])窓1.痒;
            arrayOfInt[j] = arrayOfInt[j] + 1;
          } 
          if (d < d1)
            break; 
          j++;
          continue;
        } 
        break;
      } 
    } 
    this.淋 = this.嬉;
    this.怖 = l1;
    sp0 sp0 = xp0.興;
    l1 = ((Long)ml0.暑.熱.硬(sp0)).longValue();
    long l2 = paramo61.不();
    int i = 0;
    while (true) {
      String[] arrayOfString = this.旨;
      if (i < arrayOfString.length) {
        if (arrayOfString[i] == null && l1 > Math.abs(l2 - this.美[i])) {
          Bitmap bitmap = paramo61.getBitmap(8, 8);
          l1 = 63L;
          l2 = 0L;
          int j;
          for (j = 0; j < 8; j++) {
            int k = 0;
            while (k < 8) {
              long l;
              int m = bitmap.getPixel(k, j);
              int n = Color.blue(m);
              int i1 = Color.red(m);
              if (Color.green(m) + i1 + n > 128) {
                l = 1L;
              } else {
                l = 0L;
              } 
              l2 |= l << (int)l1;
              k++;
              l1--;
            } 
          } 
          arrayOfString[i] = String.format("%016X", new Object[] { Long.valueOf(l2) });
          return;
        } 
        i++;
        continue;
      } 
      break;
    } 
  }
  
  public final void 硬() {
    if (((Boolean)pr0.硬.嬉()).booleanValue() && !this.寂) {
      Bundle bundle = new Bundle();
      bundle.putString("type", "native-player-metrics");
      bundle.putString("request", this.堅);
      bundle.putString("player", this.悲.怖());
      窓 窓1 = this.寒;
      窓1.getClass();
      String[] arrayOfString = (String[])窓1.怖;
      ArrayList<pm0> arrayList = new ArrayList(arrayOfString.length);
      int i;
      for (i = 0; i < arrayOfString.length; i++) {
        String str = arrayOfString[i];
        double d1 = ((double[])窓1.痛)[i];
        double d2 = ((double[])窓1.恐)[i];
        int j = ((int[])窓1.痒)[i];
        arrayList.add(new pm0(str, d1, d2, j / 窓1.淋, j));
      } 
      for (pm0 pm0 : arrayList) {
        bundle.putString("fps_c_".concat(String.valueOf(pm0.硬)), Integer.toString(pm0.冷));
        bundle.putString("fps_p_".concat(String.valueOf(pm0.硬)), Double.toString(pm0.暑));
      } 
      i = 0;
      while (true) {
        long[] arrayOfLong = this.美;
        if (i < arrayOfLong.length) {
          String str1 = this.旨[i];
          if (str1 != null)
            bundle.putString("fh_".concat(Long.valueOf(arrayOfLong[i]).toString()), str1); 
          i++;
          continue;
        } 
        u03 u03 = t13.帰.熱;
        String str = this.熱.淋;
        bundle.putString("device", u03.歩());
        sp0 sp0 = xp0.硬;
        bundle.putString("eids", TextUtils.join(",", ml0.暑.硬.冷()));
        s51 s51 = nj0.寒.硬;
        Context context = this.硬;
        s51.ぱ(context, str, bundle, new 畳(context, 12, str));
        this.寂 = true;
        break;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a71.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */