package y;

import android.os.IBinder;
import android.os.IInterface;

public abstract class a11 extends nf0 implements b11 {
  public static b11 タ(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.query.IUpdateUrlsCallback");
    return (iInterface instanceof b11) ? (b11)iInterface : new z01(paramIBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */