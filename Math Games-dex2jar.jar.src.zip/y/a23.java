package y;

import android.net.Uri;
import android.os.Looper;
import java.util.concurrent.ExecutorService;

public final class a23 extends j03 {
  public final wy2 ぱ;
  
  public final kl0 不;
  
  public boolean 嬉;
  
  public boolean 寂;
  
  public yd2 怖;
  
  public final kd1 恐;
  
  public long 悲;
  
  public final po0 旨;
  
  public boolean 淋;
  
  public final int 苦;
  
  public final y12 辛;
  
  public final c13 堅(d13 paramd13, e40 parame40, long paramLong) {
    e22 e22 = this.辛.硬();
    yd2 yd21 = this.怖;
    if (yd21 != null)
      e22.ぱ(yd21); 
    Uri uri = this.不.硬;
    ik.護(this.美);
    return new y13(uri, e22, new d11(21, this.恐.怖), this.ぱ, new sy2(this.暑.熱, 0, paramd13), new sy2(this.熱.熱, 0, paramd13, 0), this, parame40, this.苦);
  }
  
  public final void 嬉() {}
  
  public final void 怖() {}
  
  public final void 恐(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    long l = paramLong;
    if (paramLong == -9223372036854775807L)
      l = this.悲; 
    if (!this.嬉 && this.悲 == l && this.寂 == paramBoolean1 && this.淋 == paramBoolean2)
      return; 
    this.悲 = l;
    this.寂 = paramBoolean1;
    this.淋 = paramBoolean2;
    this.嬉 = false;
    痛();
  }
  
  public final po0 熱() {
    return this.旨;
  }
  
  public final void 痛() {
    ai0 ai0;
    z13 z13;
    long l = this.悲;
    boolean bool1 = this.寂;
    boolean bool2 = this.淋;
    po0 po01 = this.旨;
    if (bool2) {
      ai0 = po01.熱;
    } else {
      ai0 = null;
    } 
    l23 l232 = new l23(l, l, bool1, po01, ai0);
    l23 l231 = l232;
    if (this.嬉)
      z13 = new z13(l232); 
    ぱ(z13);
  }
  
  public final void 硬(c13 paramc13) {
    paramc13 = paramc13;
    if (((y13)paramc13).噛)
      for (d23 d23 : ((y13)paramc13).泳) {
        d23.嬉();
        if (d23.帰 != null) {
          d23.帰 = null;
          d23.寒 = null;
        } 
      }  
    g43 g43 = ((y13)paramc13).起;
    d43 d43 = g43.堅;
    if (d43 != null)
      d43.硬(true); 
    au1 au1 = new au1(18, paramc13);
    ExecutorService executorService = g43.硬;
    executorService.execute(au1);
    executorService.shutdown();
    ((y13)paramc13).帰.removeCallbacksAndMessages(null);
    ((y13)paramc13).返 = null;
    ((y13)paramc13).ㅌ = true;
  }
  
  public final void 辛(yd2 paramyd2) {
    this.怖 = paramyd2;
    Looper.myLooper().getClass();
    ik.護(this.美);
    痛();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */