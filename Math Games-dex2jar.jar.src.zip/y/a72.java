package y;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import java.util.ArrayList;
import java.util.List;

public final class a72 {
  public final int ぱ;
  
  public final xr0 不;
  
  public final dz2 冷;
  
  public final vv0 堅;
  
  public final na 嬉;
  
  public final rx2 寂;
  
  public final String 寒;
  
  public final boolean 怖;
  
  public final f41 恐;
  
  public final k11 悲;
  
  public final ArrayList 旨;
  
  public final wv2 暑;
  
  public final boolean 淋;
  
  public final e02 熱;
  
  public final s72 硬;
  
  public final ArrayList 美;
  
  public final 蕉 苦;
  
  public final w33 辛;
  
  public a72(z62 paramz62) {
    boolean bool;
    xr0 xr02;
    xr0 xr01;
    this.冷 = paramz62.堅;
    this.寒 = paramz62.熱;
    this.恐 = paramz62.痛;
    wv2 wv21 = paramz62.硬;
    int i = wv21.淋;
    long l = wv21.怖;
    Bundle bundle = wv21.恐;
    int j = wv21.痛;
    List list = wv21.痒;
    boolean bool1 = wv21.臭;
    int k = wv21.起;
    if (wv21.興 || paramz62.冷) {
      bool = true;
    } else {
      bool = false;
    } 
    this.暑 = new wv2(i, l, bundle, j, list, bool1, k, bool, wv21.産, wv21.死, wv21.壊, wv21.帰, wv21.返, wv21.歩, wv21.泳, wv21.踊, wv21.寝, wv21.噛, wv21.触, wv21.投, wv21.あ, wv21.か, u03.痛(wv21.ち), paramz62.硬.ゃ);
    s72 s721 = paramz62.暑;
    bundle = null;
    if (s721 == null) {
      xr02 = paramz62.旨;
      if (xr02 != null) {
        s72 s722 = xr02.臭;
      } else {
        xr02 = null;
      } 
    } 
    this.硬 = (s72)xr02;
    ArrayList arrayList = paramz62.寒;
    this.美 = arrayList;
    this.旨 = paramz62.美;
    if (arrayList == null) {
      Bundle bundle1 = bundle;
    } else {
      xr0 xr03 = paramz62.旨;
      xr01 = xr03;
      if (xr03 == null)
        xr01 = new xr0(new c5(new c5())); 
    } 
    this.不 = xr01;
    this.辛 = paramz62.不;
    this.ぱ = paramz62.嬉;
    this.苦 = paramz62.辛;
    this.嬉 = paramz62.ぱ;
    this.悲 = paramz62.苦;
    this.堅 = paramz62.悲;
    this.寂 = new rx2(paramz62.寂);
    this.淋 = paramz62.淋;
    this.熱 = paramz62.怖;
    this.怖 = paramz62.恐;
  }
  
  public final boolean 堅() {
    sp0 sp0 = xp0.骨;
    String str = (String)ml0.暑.熱.硬(sp0);
    return this.寒.matches(str);
  }
  
  public final tt0 硬() {
    蕉 蕉1 = this.苦;
    na na1 = this.嬉;
    if (na1 != null || 蕉1 != null) {
      if (na1 != null) {
        iBinder = na1.恐;
        if (iBinder == null)
          return null; 
        int j = st0.淋;
        IInterface iInterface1 = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IShouldDelayBannerRenderingListener");
        return (iInterface1 instanceof tt0) ? (tt0)iInterface1 : new rt0(iBinder);
      } 
      IBinder iBinder = ((蕉)iBinder).怖;
      if (iBinder == null)
        return null; 
      int i = st0.淋;
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IShouldDelayBannerRenderingListener");
      return (iInterface instanceof tt0) ? (tt0)iInterface : new rt0(iBinder);
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a72.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */