package y;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

public final class ai2 extends ni2 {
  public final Executor 恐;
  
  public final Callable 痒;
  
  public ai2(bi2 parambi2, Callable paramCallable, Executor paramExecutor) {
    paramExecutor.getClass();
    this.恐 = paramExecutor;
    this.痒 = paramCallable;
  }
  
  public final void 冷(Object paramObject) {
    this.痛.踊 = null;
    this.臭.旨(paramObject);
  }
  
  public final String 堅() {
    return this.痒.toString();
  }
  
  public final boolean 寒() {
    return this.痛.isDone();
  }
  
  public final void 暑(Throwable paramThrowable) {
    bi2 bi21 = this.痛;
    bi21.踊 = null;
    if (paramThrowable instanceof ExecutionException) {
      bi21.不(((ExecutionException)paramThrowable).getCause());
      return;
    } 
    if (paramThrowable instanceof java.util.concurrent.CancellationException) {
      bi21.cancel(false);
      return;
    } 
    bi21.不(paramThrowable);
  }
  
  public final Object 硬() {
    return this.痒.call();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ai2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */