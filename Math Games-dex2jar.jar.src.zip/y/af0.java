package y;

import com.google.android.gms.internal.ads.break;

public final class af0 extends hf0 {
  public static final Object 不 = new Object();
  
  public static volatile Long 旨;
  
  public af0(je0 paramje0, lc0 paramlc0, int paramInt) {
    super(paramje0, "BL1uRQDu2iGGdqxtPT0UZ/lh1a1ebdj6ce5dHzXL9Xdh/V7EjoG/mOlN+ePhmCVj", "VbWvt5u3iV1e6mTKIEv50y8+Z2ekDgVJovyXyxeSHYc=", paramlc0, paramInt, 22);
  }
  
  public final void 硬() {
    if (旨 == null)
      synchronized (不) {
        if (旨 == null)
          旨 = (Long)this.冷.invoke(null, new Object[0]); 
      }  
    synchronized (this.暑) {
      lc0 lc0 = this.暑;
      long l = 旨.longValue();
      lc0.冷();
      break.護((break)lc0.怖, l);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\af0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */