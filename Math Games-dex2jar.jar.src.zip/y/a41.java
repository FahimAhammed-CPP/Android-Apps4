package y;

import android.content.Context;
import java.math.BigInteger;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.Executor;
import org.json.JSONObject;

public final class a41 implements dt2 {
  public final kt2 堅;
  
  public final kt2 暑;
  
  public final kt2 熱;
  
  public final Object 暑() {
    int i;
    boolean bool;
    jr1 jr1;
    dr1 dr1;
    mt0 mt0;
    Context context;
    cr1 cr1;
    ky1 ky1;
    ix1 ix11;
    tx1 tx1;
    nx1 nx11;
    uc1 uc14;
    Set<?> set4;
    uc1 uc13;
    Set<?> set3;
    uc1 uc12;
    Set<?> set2;
    uc1 uc11;
    Set<?> set1;
    jm0 jm0;
    占 占1;
    c61 c613;
    占 占2;
    c61 c612;
    ix1 ix12;
    nx1 nx12;
    c61 c611;
    hx0 hx0;
    yv1 yv1;
    vv1 vv1;
    c61 c615;
    uv1 uv1;
    o51 o51;
    a72 a72;
    c61 c614;
    sp0 sp0;
    String str;
    switch (this.硬) {
      default:
        return new ss1((zs1)this.堅.暑(), ((ug1)this.熱).硬(), (String)this.暑.暑());
      case 28:
        return new jr1((fr1)this.堅.暑(), ((it2)this.熱).堅(), (占)this.暑.暑());
      case 27:
        jr1 = (jr1)this.堅.暑();
        c613 = d61.硬;
        il0.死(c613);
        yv1 = (yv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(yv1, c613) : new uk1(jr1, c613);
      case 26:
        dr1 = (dr1)this.堅.暑();
        c613 = d61.硬;
        il0.死(c613);
        vv1 = (vv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(vv1, c613) : new uk1(dr1, c613);
      case 25:
        dr1 = (dr1)this.堅.暑();
        c613 = d61.硬;
        il0.死(c613);
        vv1 = (vv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(vv1, c613) : new uk1(dr1, c613);
      case 24:
        dr1 = (dr1)this.堅.暑();
        c613 = d61.硬;
        il0.死(c613);
        vv1 = (vv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(vv1, c613) : new uk1(dr1, c613);
      case 23:
        i = (((ug1)this.暑).硬()).寂.怖;
        if (i != 0)
          return (i - 1 != 0) ? ((hz1)this.熱).硬() : ((hz1)this.堅).硬(); 
        throw null;
      case 22:
        return new np1((String)((sf1)this.堅).硬.痛, (an1)this.熱.暑(), ((ln1)this.暑).硬());
      case 21:
        return new lp1((String)((sf1)this.堅).硬.痛, (an1)this.熱.暑(), ((ln1)this.暑).硬());
      case 20:
        return new kp1((String)((sf1)this.堅).硬.痛, (an1)this.熱.暑(), ((ln1)this.暑).硬());
      case 19:
        return new fp1((Executor)this.堅.暑(), (xc1)this.熱.暑(), (vk1)this.暑.暑());
      case 18:
        mt0 = (mt0)this.堅.暑();
        占2 = (占)this.熱.暑();
        c615 = d61.硬;
        il0.死(c615);
        return new no1(mt0, 占2, c615);
      case 17:
        return new vk1((Context)this.堅.暑(), ((it2)this.熱).堅(), ((rf1)this.暑).硬());
      case 16:
        context = (Context)this.堅.暑();
        return new kg1(((rf1)this.熱).硬());
      case 15:
        return new ig1((Context)this.堅.暑(), ((qa1)this.熱).硬(), ((ug1)this.暑).硬());
      case 14:
        cr1 = (cr1)this.堅.暑();
        c612 = d61.硬;
        il0.死(c612);
        uv1 = (uv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(uv1, c612) : new uk1(cr1, c612);
      case 13:
        cr1 = (cr1)this.堅.暑();
        c612 = d61.硬;
        il0.死(c612);
        uv1 = (uv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(uv1, c612) : new uk1(cr1, c612);
      case 12:
        cr1 = (cr1)this.堅.暑();
        c612 = d61.硬;
        il0.死(c612);
        uv1 = (uv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(uv1, c612) : new uk1(cr1, c612);
      case 11:
        cr1 = (cr1)this.堅.暑();
        c612 = d61.硬;
        il0.死(c612);
        uv1 = (uv1)this.暑.暑();
        sp0 = xp0.刻;
        return ((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() ? new uk1(uv1, c612) : new uk1(cr1, c612);
      case 10:
        null = (占)this.堅.暑();
        o51 = ((ra1)this.熱).硬();
        str = (((ug1)this.暑).硬()).寒;
        synchronized (o51.熱) {
          String str1 = ((BigInteger)null.怖).toString();
          null.怖 = ((BigInteger)null.怖).add(BigInteger.ONE);
          null.恐 = str1;
          return new g51(null, o51, str1, str);
        } 
      case 9:
        return new bf1(((rf1)this.堅).硬(), (mh1)this.熱.暑(), (ki1)this.暑.暑());
      case 8:
        bool = ((de1)this.堅).硬().booleanValue();
        ky1 = ((ly1)this.熱).硬();
        ix12 = ((hz1)this.暑).硬();
        if (true != bool)
          ix11 = ix12; 
        return ix11;
      case 7:
        a72 = ((ug1)this.堅).硬();
        tx1 = ((ux1)this.熱).硬();
        nx12 = ((ox1)this.暑).硬();
        if (a72.硬() == null)
          nx11 = nx12; 
        return nx11;
      case 6:
        uc14 = (uc1)this.堅.暑();
        c611 = d61.硬;
        il0.死(c611);
        if ((JSONObject)this.暑.暑() == null) {
          set4 = Collections.emptySet();
        } else {
          set4 = Collections.singleton(new uk1(set4, c611));
        } 
        il0.死(set4);
        return set4;
      case 5:
        uc13 = (uc1)this.堅.暑();
        c611 = d61.硬;
        il0.死(c611);
        if ((JSONObject)this.暑.暑() == null) {
          set3 = Collections.emptySet();
        } else {
          set3 = Collections.singleton(new uk1(set3, c611));
        } 
        il0.死(set3);
        return set3;
      case 4:
        uc12 = (uc1)this.堅.暑();
        c611 = d61.硬;
        il0.死(c611);
        if ((JSONObject)this.暑.暑() == null) {
          set2 = Collections.emptySet();
        } else {
          set2 = Collections.singleton(new uk1(set2, c611));
        } 
        il0.死(set2);
        return set2;
      case 3:
        uc11 = (uc1)this.堅.暑();
        c611 = d61.硬;
        il0.死(c611);
        if ((JSONObject)this.暑.暑() == null) {
          set1 = Collections.emptySet();
        } else {
          set1 = Collections.singleton(new uk1(set1, c611));
        } 
        il0.死(set1);
        return set1;
      case 2:
        jm0 = (jm0)this.堅.暑();
        hx0 = (hx0)this.熱.暑();
        c614 = td.寝();
        il0.死(c614);
        return new rc1(jm0.熱, hx0, c614);
      case 1:
        占1 = (占)this.堅.暑();
        return new b41((te2)this.熱.暑(), (o41)this.暑.暑());
      case 0:
        break;
    } 
    return new z31((Context)this.堅.暑(), (te2)this.熱.暑(), (o41)this.暑.暑());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a41.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */