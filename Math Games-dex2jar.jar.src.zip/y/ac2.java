package y;

import java.util.regex.Pattern;

public abstract class ac2 {
  public static final Pattern 堅;
  
  public static final Pattern 硬 = Pattern.compile("bytes (\\d+)-(\\d+)/(?:\\d+|\\*)");
  
  static {
    堅 = Pattern.compile("bytes (?:(?:\\d+-\\d+)|\\*)/(\\d+)");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ac2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */