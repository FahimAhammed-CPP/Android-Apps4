package y;

import java.io.InputStream;

public final class ao0 {
  public final boolean 冷;
  
  public final boolean 堅;
  
  public final long 暑;
  
  public final boolean 熱;
  
  public final InputStream 硬;
  
  public ao0(zn0 paramzn0, boolean paramBoolean1, boolean paramBoolean2, long paramLong, boolean paramBoolean3) {
    this.硬 = paramzn0;
    this.堅 = paramBoolean1;
    this.熱 = paramBoolean2;
    this.暑 = paramLong;
    this.冷 = paramBoolean3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ao0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */