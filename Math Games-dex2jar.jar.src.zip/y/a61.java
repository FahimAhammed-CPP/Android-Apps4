package y;

public final class a61 extends t81 {
  public final h81 冷(int paramInt, h81 paramh81, long paramLong) {
    throw new IndexOutOfBoundsException();
  }
  
  public final int 堅() {
    return 0;
  }
  
  public final Object 寒(int paramInt) {
    throw new IndexOutOfBoundsException();
  }
  
  public final b71 暑(int paramInt, b71 paramb71, boolean paramBoolean) {
    throw new IndexOutOfBoundsException();
  }
  
  public final int 熱() {
    return 0;
  }
  
  public final int 硬(Object paramObject) {
    return -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a61.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */