package y;

public enum aa2 {
  怖, 恐, 痒, 痛;
  
  public final String 淋;
  
  static {
    aa2 aa21 = new aa2(0, "DEFINED_BY_JAVASCRIPT", "definedByJavaScript");
    怖 = aa21;
    aa2 aa22 = new aa2(1, "UNSPECIFIED", "unspecified");
    恐 = aa22;
    aa2 aa23 = new aa2(2, "LOADED", "loaded");
    aa2 aa24 = new aa2(3, "BEGIN_TO_RENDER", "beginToRender");
    痛 = aa24;
    aa2 aa25 = new aa2(4, "ONE_PIXEL", "onePixel");
    痒 = aa25;
    臭 = new aa2[] { aa21, aa22, aa23, aa24, aa25, new aa2(5, "VIEWABLE", "viewable"), new aa2(6, "AUDIBLE", "audible"), new aa2(7, "OTHER", "other") };
  }
  
  aa2(String paramString1) {
    this.淋 = paramString1;
  }
  
  public final String toString() {
    return this.淋;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aa2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */