package y;

import android.os.Process;

public final class ag extends Thread {
  public final int 淋;
  
  public ag(Runnable paramRunnable, String paramString, int paramInt) {
    super(paramRunnable, paramString);
    this.淋 = paramInt;
  }
  
  public final void run() {
    Process.setThreadPriority(this.淋);
    super.run();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */