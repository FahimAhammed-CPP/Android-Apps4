package y;

import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;

public final class a3 extends FrameLayout implements 掛 {
  public final CollapsibleActionView 淋;
  
  public a3(View paramView) {
    super(paramView.getContext());
    this.淋 = (CollapsibleActionView)paramView;
    addView(paramView);
  }
  
  public final void onActionViewCollapsed() {
    this.淋.onActionViewCollapsed();
  }
  
  public final void onActionViewExpanded() {
    this.淋.onActionViewExpanded();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */