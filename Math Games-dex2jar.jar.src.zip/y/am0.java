package y;

import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;

public final class am0 extends HandlerThread implements SurfaceTexture.OnFrameAvailableListener, Handler.Callback {
  public Handler 怖;
  
  public SurfaceTexture 恐;
  
  public final int[] 淋 = new int[1];
  
  public RuntimeException 痒;
  
  public Error 痛;
  
  public bm0 臭;
  
  public am0() {
    super("dummySurface");
  }
  
  public final boolean handleMessage(Message paramMessage) {
    // Byte code:
    //   0: aload_1
    //   1: getfield what : I
    //   4: istore_2
    //   5: iload_2
    //   6: iconst_1
    //   7: if_icmpeq -> 89
    //   10: iload_2
    //   11: iconst_2
    //   12: if_icmpeq -> 80
    //   15: iload_2
    //   16: iconst_3
    //   17: if_icmpeq -> 22
    //   20: iconst_1
    //   21: ireturn
    //   22: aload_0
    //   23: getfield 恐 : Landroid/graphics/SurfaceTexture;
    //   26: invokevirtual release : ()V
    //   29: aload_0
    //   30: aconst_null
    //   31: putfield 臭 : Ly/bm0;
    //   34: aload_0
    //   35: aconst_null
    //   36: putfield 恐 : Landroid/graphics/SurfaceTexture;
    //   39: iconst_1
    //   40: aload_0
    //   41: getfield 淋 : [I
    //   44: iconst_0
    //   45: invokestatic glDeleteTextures : (I[II)V
    //   48: goto -> 73
    //   51: astore_1
    //   52: aload_0
    //   53: aconst_null
    //   54: putfield 臭 : Ly/bm0;
    //   57: aload_0
    //   58: aconst_null
    //   59: putfield 恐 : Landroid/graphics/SurfaceTexture;
    //   62: iconst_1
    //   63: aload_0
    //   64: getfield 淋 : [I
    //   67: iconst_0
    //   68: invokestatic glDeleteTextures : (I[II)V
    //   71: aload_1
    //   72: athrow
    //   73: aload_0
    //   74: invokevirtual quit : ()Z
    //   77: pop
    //   78: iconst_1
    //   79: ireturn
    //   80: aload_0
    //   81: getfield 恐 : Landroid/graphics/SurfaceTexture;
    //   84: invokevirtual updateTexImage : ()V
    //   87: iconst_1
    //   88: ireturn
    //   89: aload_1
    //   90: getfield arg1 : I
    //   93: ifeq -> 642
    //   96: iconst_1
    //   97: istore_2
    //   98: goto -> 101
    //   101: iconst_0
    //   102: invokestatic eglGetDisplay : (I)Landroid/opengl/EGLDisplay;
    //   105: astore #4
    //   107: aload #4
    //   109: ifnull -> 647
    //   112: iconst_1
    //   113: istore_3
    //   114: goto -> 117
    //   117: ldc 'eglGetDisplay failed'
    //   119: iload_3
    //   120: invokestatic 師 : (Ljava/lang/String;Z)V
    //   123: iconst_2
    //   124: newarray int
    //   126: astore_1
    //   127: ldc 'eglInitialize failed'
    //   129: aload #4
    //   131: aload_1
    //   132: iconst_0
    //   133: aload_1
    //   134: iconst_1
    //   135: invokestatic eglInitialize : (Landroid/opengl/EGLDisplay;[II[II)Z
    //   138: invokestatic 師 : (Ljava/lang/String;Z)V
    //   141: iconst_1
    //   142: anewarray android/opengl/EGLConfig
    //   145: astore_1
    //   146: iconst_1
    //   147: newarray int
    //   149: astore #5
    //   151: aload #4
    //   153: bipush #17
    //   155: newarray int
    //   157: dup
    //   158: iconst_0
    //   159: sipush #12352
    //   162: iastore
    //   163: dup
    //   164: iconst_1
    //   165: iconst_4
    //   166: iastore
    //   167: dup
    //   168: iconst_2
    //   169: sipush #12324
    //   172: iastore
    //   173: dup
    //   174: iconst_3
    //   175: bipush #8
    //   177: iastore
    //   178: dup
    //   179: iconst_4
    //   180: sipush #12323
    //   183: iastore
    //   184: dup
    //   185: iconst_5
    //   186: bipush #8
    //   188: iastore
    //   189: dup
    //   190: bipush #6
    //   192: sipush #12322
    //   195: iastore
    //   196: dup
    //   197: bipush #7
    //   199: bipush #8
    //   201: iastore
    //   202: dup
    //   203: bipush #8
    //   205: sipush #12321
    //   208: iastore
    //   209: dup
    //   210: bipush #9
    //   212: bipush #8
    //   214: iastore
    //   215: dup
    //   216: bipush #10
    //   218: sipush #12325
    //   221: iastore
    //   222: dup
    //   223: bipush #11
    //   225: iconst_0
    //   226: iastore
    //   227: dup
    //   228: bipush #12
    //   230: sipush #12327
    //   233: iastore
    //   234: dup
    //   235: bipush #13
    //   237: sipush #12344
    //   240: iastore
    //   241: dup
    //   242: bipush #14
    //   244: sipush #12339
    //   247: iastore
    //   248: dup
    //   249: bipush #15
    //   251: iconst_4
    //   252: iastore
    //   253: dup
    //   254: bipush #16
    //   256: sipush #12344
    //   259: iastore
    //   260: iconst_0
    //   261: aload_1
    //   262: iconst_0
    //   263: iconst_1
    //   264: aload #5
    //   266: iconst_0
    //   267: invokestatic eglChooseConfig : (Landroid/opengl/EGLDisplay;[II[Landroid/opengl/EGLConfig;II[II)Z
    //   270: ifeq -> 652
    //   273: aload #5
    //   275: iconst_0
    //   276: iaload
    //   277: ifle -> 652
    //   280: aload_1
    //   281: iconst_0
    //   282: aaload
    //   283: ifnull -> 652
    //   286: iconst_1
    //   287: istore_3
    //   288: goto -> 291
    //   291: ldc 'eglChooseConfig failed'
    //   293: iload_3
    //   294: invokestatic 師 : (Ljava/lang/String;Z)V
    //   297: aload_1
    //   298: iconst_0
    //   299: aaload
    //   300: astore #5
    //   302: iload_2
    //   303: ifeq -> 339
    //   306: iconst_5
    //   307: newarray int
    //   309: astore_1
    //   310: aload_1
    //   311: iconst_0
    //   312: sipush #12440
    //   315: iastore
    //   316: aload_1
    //   317: iconst_1
    //   318: iconst_2
    //   319: iastore
    //   320: aload_1
    //   321: iconst_2
    //   322: sipush #12992
    //   325: iastore
    //   326: aload_1
    //   327: iconst_3
    //   328: iconst_1
    //   329: iastore
    //   330: aload_1
    //   331: iconst_4
    //   332: sipush #12344
    //   335: iastore
    //   336: goto -> 359
    //   339: iconst_3
    //   340: newarray int
    //   342: astore_1
    //   343: aload_1
    //   344: iconst_0
    //   345: sipush #12440
    //   348: iastore
    //   349: aload_1
    //   350: iconst_1
    //   351: iconst_2
    //   352: iastore
    //   353: aload_1
    //   354: iconst_2
    //   355: sipush #12344
    //   358: iastore
    //   359: aload #4
    //   361: aload #5
    //   363: getstatic android/opengl/EGL14.EGL_NO_CONTEXT : Landroid/opengl/EGLContext;
    //   366: aload_1
    //   367: iconst_0
    //   368: invokestatic eglCreateContext : (Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Landroid/opengl/EGLContext;[II)Landroid/opengl/EGLContext;
    //   371: astore #6
    //   373: aload #6
    //   375: ifnull -> 657
    //   378: iconst_1
    //   379: istore_3
    //   380: goto -> 383
    //   383: ldc 'eglCreateContext failed'
    //   385: iload_3
    //   386: invokestatic 師 : (Ljava/lang/String;Z)V
    //   389: iload_2
    //   390: ifeq -> 438
    //   393: bipush #7
    //   395: newarray int
    //   397: astore_1
    //   398: aload_1
    //   399: iconst_0
    //   400: sipush #12375
    //   403: iastore
    //   404: aload_1
    //   405: iconst_1
    //   406: iconst_1
    //   407: iastore
    //   408: aload_1
    //   409: iconst_2
    //   410: sipush #12374
    //   413: iastore
    //   414: aload_1
    //   415: iconst_3
    //   416: iconst_1
    //   417: iastore
    //   418: aload_1
    //   419: iconst_4
    //   420: sipush #12992
    //   423: iastore
    //   424: aload_1
    //   425: iconst_5
    //   426: iconst_1
    //   427: iastore
    //   428: aload_1
    //   429: bipush #6
    //   431: sipush #12344
    //   434: iastore
    //   435: goto -> 468
    //   438: iconst_5
    //   439: newarray int
    //   441: astore_1
    //   442: aload_1
    //   443: iconst_0
    //   444: sipush #12375
    //   447: iastore
    //   448: aload_1
    //   449: iconst_1
    //   450: iconst_1
    //   451: iastore
    //   452: aload_1
    //   453: iconst_2
    //   454: sipush #12374
    //   457: iastore
    //   458: aload_1
    //   459: iconst_3
    //   460: iconst_1
    //   461: iastore
    //   462: aload_1
    //   463: iconst_4
    //   464: sipush #12344
    //   467: iastore
    //   468: aload #4
    //   470: aload #5
    //   472: aload_1
    //   473: iconst_0
    //   474: invokestatic eglCreatePbufferSurface : (Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;[II)Landroid/opengl/EGLSurface;
    //   477: astore_1
    //   478: aload_1
    //   479: ifnull -> 662
    //   482: iconst_1
    //   483: istore_3
    //   484: goto -> 487
    //   487: ldc 'eglCreatePbufferSurface failed'
    //   489: iload_3
    //   490: invokestatic 師 : (Ljava/lang/String;Z)V
    //   493: ldc 'eglMakeCurrent failed'
    //   495: aload #4
    //   497: aload_1
    //   498: aload_1
    //   499: aload #6
    //   501: invokestatic eglMakeCurrent : (Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z
    //   504: invokestatic 師 : (Ljava/lang/String;Z)V
    //   507: iconst_1
    //   508: aload_0
    //   509: getfield 淋 : [I
    //   512: iconst_0
    //   513: invokestatic glGenTextures : (I[II)V
    //   516: new android/graphics/SurfaceTexture
    //   519: dup
    //   520: aload_0
    //   521: getfield 淋 : [I
    //   524: iconst_0
    //   525: iaload
    //   526: invokespecial <init> : (I)V
    //   529: astore_1
    //   530: aload_0
    //   531: aload_1
    //   532: putfield 恐 : Landroid/graphics/SurfaceTexture;
    //   535: aload_1
    //   536: aload_0
    //   537: invokevirtual setOnFrameAvailableListener : (Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V
    //   540: aload_0
    //   541: new y/bm0
    //   544: dup
    //   545: aload_0
    //   546: aload_0
    //   547: getfield 恐 : Landroid/graphics/SurfaceTexture;
    //   550: invokespecial <init> : (Ly/am0;Landroid/graphics/SurfaceTexture;)V
    //   553: putfield 臭 : Ly/bm0;
    //   556: aload_0
    //   557: monitorenter
    //   558: aload_0
    //   559: invokevirtual notify : ()V
    //   562: aload_0
    //   563: monitorexit
    //   564: iconst_1
    //   565: ireturn
    //   566: astore_1
    //   567: aload_0
    //   568: monitorexit
    //   569: aload_1
    //   570: athrow
    //   571: astore_1
    //   572: goto -> 623
    //   575: astore_1
    //   576: goto -> 583
    //   579: astore_1
    //   580: goto -> 603
    //   583: aload_0
    //   584: aload_1
    //   585: putfield 痛 : Ljava/lang/Error;
    //   588: aload_0
    //   589: monitorenter
    //   590: aload_0
    //   591: invokevirtual notify : ()V
    //   594: aload_0
    //   595: monitorexit
    //   596: iconst_1
    //   597: ireturn
    //   598: astore_1
    //   599: aload_0
    //   600: monitorexit
    //   601: aload_1
    //   602: athrow
    //   603: aload_0
    //   604: aload_1
    //   605: putfield 痒 : Ljava/lang/RuntimeException;
    //   608: aload_0
    //   609: monitorenter
    //   610: aload_0
    //   611: invokevirtual notify : ()V
    //   614: aload_0
    //   615: monitorexit
    //   616: iconst_1
    //   617: ireturn
    //   618: astore_1
    //   619: aload_0
    //   620: monitorexit
    //   621: aload_1
    //   622: athrow
    //   623: aload_0
    //   624: monitorenter
    //   625: aload_0
    //   626: invokevirtual notify : ()V
    //   629: aload_0
    //   630: monitorexit
    //   631: aload_1
    //   632: athrow
    //   633: astore_1
    //   634: aload_0
    //   635: monitorexit
    //   636: aload_1
    //   637: athrow
    //   638: astore_1
    //   639: goto -> 73
    //   642: iconst_0
    //   643: istore_2
    //   644: goto -> 101
    //   647: iconst_0
    //   648: istore_3
    //   649: goto -> 117
    //   652: iconst_0
    //   653: istore_3
    //   654: goto -> 291
    //   657: iconst_0
    //   658: istore_3
    //   659: goto -> 383
    //   662: iconst_0
    //   663: istore_3
    //   664: goto -> 487
    // Exception table:
    //   from	to	target	type
    //   22	29	51	finally
    //   29	48	638	finally
    //   52	73	638	finally
    //   89	96	579	java/lang/RuntimeException
    //   89	96	575	java/lang/Error
    //   89	96	571	finally
    //   101	107	579	java/lang/RuntimeException
    //   101	107	575	java/lang/Error
    //   101	107	571	finally
    //   117	273	579	java/lang/RuntimeException
    //   117	273	575	java/lang/Error
    //   117	273	571	finally
    //   291	297	579	java/lang/RuntimeException
    //   291	297	575	java/lang/Error
    //   291	297	571	finally
    //   306	310	579	java/lang/RuntimeException
    //   306	310	575	java/lang/Error
    //   306	310	571	finally
    //   339	343	579	java/lang/RuntimeException
    //   339	343	575	java/lang/Error
    //   339	343	571	finally
    //   359	373	579	java/lang/RuntimeException
    //   359	373	575	java/lang/Error
    //   359	373	571	finally
    //   383	389	579	java/lang/RuntimeException
    //   383	389	575	java/lang/Error
    //   383	389	571	finally
    //   393	398	579	java/lang/RuntimeException
    //   393	398	575	java/lang/Error
    //   393	398	571	finally
    //   438	442	579	java/lang/RuntimeException
    //   438	442	575	java/lang/Error
    //   438	442	571	finally
    //   468	478	579	java/lang/RuntimeException
    //   468	478	575	java/lang/Error
    //   468	478	571	finally
    //   487	556	579	java/lang/RuntimeException
    //   487	556	575	java/lang/Error
    //   487	556	571	finally
    //   558	564	566	finally
    //   567	569	566	finally
    //   583	588	571	finally
    //   590	596	598	finally
    //   599	601	598	finally
    //   603	608	571	finally
    //   610	616	618	finally
    //   619	621	618	finally
    //   625	631	633	finally
    //   634	636	633	finally
  }
  
  public final void onFrameAvailable(SurfaceTexture paramSurfaceTexture) {
    this.怖.sendEmptyMessage(2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\am0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */