package y;

import com.google.android.gms.internal.ads.ガ;
import com.google.android.gms.internal.ads.ク;
import com.google.android.gms.internal.ads.ゲ;
import com.google.android.gms.internal.ads.ゴ;
import com.google.android.gms.internal.ads.ッ;
import com.google.android.gms.internal.ads.ト;
import com.google.android.gms.internal.ads.バ;
import com.google.android.gms.internal.ads.ブ;
import com.google.android.gms.internal.ads.ホ;
import com.google.android.gms.internal.ads.ボ;
import com.google.android.gms.internal.ads.モ;
import com.google.android.gms.internal.ads.植;
import com.google.android.gms.internal.ads.殻;
import com.google.android.gms.internal.ads.熊;
import com.google.android.gms.internal.ads.章;
import com.google.android.gms.internal.ads.蛇;
import com.google.android.gms.internal.ads.蛉;
import com.google.android.gms.internal.ads.蛛;
import com.google.android.gms.internal.ads.蛾;
import com.google.android.gms.internal.ads.蜘;
import com.google.android.gms.internal.ads.蜚;
import com.google.android.gms.internal.ads.蜥;
import com.google.android.gms.internal.ads.蜻;
import com.google.android.gms.internal.ads.蝉;
import com.google.android.gms.internal.ads.蝗;
import com.google.android.gms.internal.ads.蝶;
import com.google.android.gms.internal.ads.蝸;
import com.google.android.gms.internal.ads.蠅;
import com.google.android.gms.internal.ads.貝;
import com.google.android.gms.internal.ads.飛;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;

public final class ak2 extends 婚 {
  public ak2(int paramInt) {
    super(ガ.class, new ml2[] { new yj2(aj2.class, 0) });
  }
  
  public static void 噛(蜚 param蜚) {
    if (param蜚.興() >= 10) {
      int i = param蜚.返() - 2;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i == 5) {
                if (param蜚.興() <= 28)
                  return; 
                throw new GeneralSecurityException("tag size too big");
              } 
              throw new GeneralSecurityException("unknown hash type");
            } 
            if (param蜚.興() <= 64)
              return; 
            throw new GeneralSecurityException("tag size too big");
          } 
          if (param蜚.興() <= 32)
            return; 
          throw new GeneralSecurityException("tag size too big");
        } 
        if (param蜚.興() <= 48)
          return; 
        throw new GeneralSecurityException("tag size too big");
      } 
      if (param蜚.興() <= 20)
        return; 
      throw new GeneralSecurityException("tag size too big");
    } 
    throw new GeneralSecurityException("tag size too small");
  }
  
  public static cl2 壊(int paramInt1, int paramInt2) {
    wm2 wm2 = 蛉.産();
    wm2.冷();
    蛉.歩((蛉)wm2.怖, paramInt1);
    xm2 xm2 = バ.産();
    xm2.冷();
    バ.帰((バ)xm2.怖);
    バ バ = (バ)xm2.熱();
    wm2.冷();
    蛉.返((蛉)wm2.怖, バ);
    return new cl2(paramInt2, wm2.熱());
  }
  
  public static void 寝(蝶 param蝶) {
    if (param蝶.興() >= 10) {
      if (param蝶.興() <= 16)
        return; 
      throw new GeneralSecurityException("tag size too long");
    } 
    throw new GeneralSecurityException("tag size too short");
  }
  
  public static cl2 帰(int paramInt1, int paramInt2, int paramInt3) {
    tm2 tm2 = ト.産();
    um2 um2 = ボ.産();
    um2.冷();
    ボ.帰((ボ)um2.怖);
    ボ ボ = (ボ)um2.熱();
    tm2.冷();
    ト.歩((ト)tm2.怖, ボ);
    tm2.冷();
    ト.泳((ト)tm2.怖, paramInt1);
    ト ト = (ト)tm2.熱();
    on2 on2 = ブ.産();
    qn2 qn2 = 蜚.産();
    qn2.冷();
    蜚.歩((蜚)qn2.怖, 5);
    qn2.冷();
    蜚.帰((蜚)qn2.怖, paramInt2);
    蜚 蜚 = (蜚)qn2.熱();
    on2.冷();
    ブ.歩((ブ)on2.怖, 蜚);
    on2.冷();
    ブ.泳((ブ)on2.怖, 32);
    ブ ブ = (ブ)on2.熱();
    rm2 rm2 = 蛾.興();
    rm2.冷();
    蛾.返((蛾)rm2.怖, ト);
    rm2.冷();
    蛾.歩((蛾)rm2.怖, ブ);
    return new cl2(paramInt3, rm2.熱());
  }
  
  public static cl2 歩(int paramInt1, int paramInt2) {
    cn2 cn2 = ク.産();
    cn2.冷();
    ク.帰((ク)cn2.怖, paramInt1);
    return new cl2(paramInt2, cn2.熱());
  }
  
  public static final void 泳(ゴ paramゴ) {
    to2.堅(paramゴ.興());
    if (paramゴ.歩().辛() >= 16) {
      噛(paramゴ.返());
      return;
    } 
    throw new GeneralSecurityException("key too short");
  }
  
  public static cl2 踊(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    on2 on2 = ブ.産();
    qn2 qn2 = 蜚.産();
    qn2.冷();
    蜚.歩((蜚)qn2.怖, paramInt3);
    qn2.冷();
    蜚.帰((蜚)qn2.怖, paramInt2);
    蜚 蜚 = (蜚)qn2.熱();
    on2.冷();
    ブ.歩((ブ)on2.怖, 蜚);
    on2.冷();
    ブ.泳((ブ)on2.怖, paramInt1);
    return new cl2(paramInt4, on2.熱());
  }
  
  public static cl2 返(int paramInt1, int paramInt2) {
    an2 an2 = 飛.産();
    an2.冷();
    飛.帰((飛)an2.怖, paramInt1);
    return new cl2(paramInt2, an2.熱());
  }
  
  public final int 死() {
    switch (this.暑) {
      default:
        return 1;
      case 0:
      case 3:
      case 13:
        break;
    } 
    return 2;
  }
  
  public final int 痒() {
    switch (this.暑) {
      default:
        return 2;
      case 10:
      case 11:
        return 4;
      case 6:
      case 7:
        break;
    } 
    return 5;
  }
  
  public final i50 痛() {
    switch (this.暑) {
      default:
        super.痛();
        throw null;
      case 13:
        return new zj2(ブ.class, 11);
      case 12:
        return new tl2();
      case 9:
        return new zj2(蜘.class, 8);
      case 8:
        return new zj2(熊.class, 7);
      case 7:
        return new zj2(蜥.class, 6);
      case 6:
        return new zj2(殻.class, 5);
      case 5:
        return new zj2(ホ.class, 4);
      case 4:
        return new zj2(ク.class, 3);
      case 3:
        return new zj2(飛.class, 2);
      case 2:
        return new zj2(蛉.class, 1);
      case 1:
        return new bk2(this);
      case 0:
        break;
    } 
    return new zj2(蛾.class, 0);
  }
  
  public final 植 臭(fp2 paramfp2) {
    switch (this.暑) {
      default:
        return (植)ゴ.帰(paramfp2, qp2.堅);
      case 12:
        return (植)章.壊(paramfp2, qp2.堅);
      case 11:
        return (植)蝸.返(paramfp2, qp2.堅);
      case 10:
        return (植)蠅.返(paramfp2, qp2.堅);
      case 9:
        return (植)モ.壊(paramfp2, qp2.堅);
      case 8:
        return (植)蛇.壊(paramfp2, qp2.堅);
      case 7:
        return (植)ゲ.壊(paramfp2, qp2.堅);
      case 6:
        return (植)貝.壊(paramfp2, qp2.堅);
      case 5:
        return (植)蛛.壊(paramfp2, qp2.堅);
      case 4:
        return (植)蝗.壊(paramfp2, qp2.堅);
      case 3:
        return (植)ッ.壊(paramfp2, qp2.堅);
      case 2:
        return (植)蜻.壊(paramfp2, qp2.堅);
      case 1:
        return (植)蝉.帰(paramfp2, qp2.堅);
      case 0:
        break;
    } 
    return (植)ガ.壊(paramfp2, qp2.堅);
  }
  
  public final void 興(植 param植) {
    章 章;
    蝸 蝸;
    蠅 蠅;
    モ モ;
    StringBuilder stringBuilder;
    蛇 蛇;
    蛛 蛛;
    蝗 蝗;
    ッ ッ;
    蜻 蜻;
    蝉 蝉1;
    ボ ボ1;
    ガ ガ;
    int i;
    蝉 蝉2;
    ボ ボ2;
    switch (this.暑) {
      case 12:
        章 = (章)param植;
        to2.堅(章.興());
        if (章.返().辛() == 32) {
          寝(章.帰());
          return;
        } 
        throw new GeneralSecurityException("AesCmacKey size wrong, must be 32 bytes");
      case 11:
        蝸 = (蝸)章;
        to2.堅(蝸.興());
        if (蝸.噛()) {
          yk2.硬(蝸.産());
          return;
        } 
        throw new GeneralSecurityException("Missing HPKE key params.");
      case 10:
        蠅 = (蠅)蝸;
        to2.堅(蠅.興());
        td.わ(蠅.産());
        return;
      case 9:
        モ = (モ)蠅;
        to2.堅(モ.興());
        if (モ.帰().辛() == 64)
          return; 
        i = モ.帰().辛();
        stringBuilder = new StringBuilder("invalid key size: ");
        stringBuilder.append(i);
        stringBuilder.append(". Valid keys must have 64 bytes.");
        throw new InvalidKeyException(stringBuilder.toString());
      case 8:
        蛇 = (蛇)stringBuilder;
        to2.堅(蛇.興());
        if (蛇.帰().辛() == 32)
          return; 
        throw new GeneralSecurityException("invalid XChaCha20Poly1305Key: incorrect key length");
      case 7:
        to2.堅(((ゲ)蛇).興());
        return;
      case 6:
        to2.堅(((貝)蛇).興());
        return;
      case 5:
        蛛 = (蛛)蛇;
        to2.堅(蛛.興());
        if (蛛.帰().辛() == 32)
          return; 
        throw new GeneralSecurityException("invalid ChaCha20Poly1305Key: incorrect key length");
      case 4:
        蝗 = (蝗)蛛;
        to2.堅(蝗.興());
        to2.硬(蝗.帰().辛());
        return;
      case 3:
        ッ = (ッ)蝗;
        to2.堅(ッ.興());
        to2.硬(ッ.帰().辛());
        return;
      case 2:
        蜻 = (蜻)ッ;
        to2.堅(蜻.興());
        to2.硬(蜻.返().辛());
        if (蜻.帰().興() != 12) {
          if (蜻.帰().興() == 16)
            return; 
          throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
        } 
        return;
      case 1:
        蝉1 = (蝉)蜻;
        to2.堅(蝉1.興());
        to2.硬(蝉1.歩().辛());
        ボ1 = 蝉1.返();
        if (ボ1.興() >= 12 && ボ1.興() <= 16)
          return; 
        throw new GeneralSecurityException("invalid IV size");
      case 0:
        ガ = (ガ)ボ1;
        to2.堅(ガ.興());
        new ak2(1);
        蝉2 = ガ.帰();
        to2.堅(蝉2.興());
        to2.硬(蝉2.歩().辛());
        ボ2 = 蝉2.返();
        if (ボ2.興() >= 12 && ボ2.興() <= 16) {
          new ak2(13);
          泳(ガ.返());
          return;
        } 
        throw new GeneralSecurityException("invalid IV size");
    } 
    泳((ゴ)ガ);
  }
  
  public final String 起() {
    switch (this.暑) {
      default:
        return "type.googleapis.com/google.crypto.tink.HmacKey";
      case 12:
        return "type.googleapis.com/google.crypto.tink.AesCmacKey";
      case 11:
        return "type.googleapis.com/google.crypto.tink.HpkePublicKey";
      case 10:
        return "type.googleapis.com/google.crypto.tink.EciesAeadHkdfPublicKey";
      case 9:
        return "type.googleapis.com/google.crypto.tink.AesSivKey";
      case 8:
        return "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key";
      case 7:
        return "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey";
      case 6:
        return "type.googleapis.com/google.crypto.tink.KmsAeadKey";
      case 5:
        return "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key";
      case 4:
        return "type.googleapis.com/google.crypto.tink.AesGcmSivKey";
      case 3:
        return "type.googleapis.com/google.crypto.tink.AesGcmKey";
      case 2:
        return "type.googleapis.com/google.crypto.tink.AesEaxKey";
      case 1:
        return "type.googleapis.com/google.crypto.tink.AesCtrKey";
      case 0:
        break;
    } 
    return "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ak2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */