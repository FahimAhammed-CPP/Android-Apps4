package y;

public final class ak0 {
  public int ぱ;
  
  public int 不;
  
  public int[] 冷 = new int[1000];
  
  public int[] 堅 = new int[1000];
  
  public long 嬉 = Long.MIN_VALUE;
  
  public boolean 寂 = true;
  
  public long[] 寒 = new long[1000];
  
  public gg0 怖;
  
  public long 悲 = Long.MIN_VALUE;
  
  public gg0[] 旨 = new gg0[1000];
  
  public int[] 暑 = new int[1000];
  
  public boolean 淋 = true;
  
  public long[] 熱 = new long[1000];
  
  public int 硬 = 1000;
  
  public wh0[] 美 = new wh0[1000];
  
  public int 苦;
  
  public int 辛;
  
  public final void 堅(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield 悲 : J
    //   7: lload_1
    //   8: invokestatic max : (JJ)J
    //   11: putfield 悲 : J
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_3
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_3
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  public final boolean 熱() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 不 : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ifeq -> 15
    //   13: iconst_1
    //   14: ireturn
    //   15: iconst_0
    //   16: ireturn
    //   17: astore_2
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_2
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	17	finally
  }
  
  public final void 硬(long paramLong1, int paramInt1, long paramLong2, int paramInt2, wh0 paramwh0) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 寂 : Z
    //   6: istore #9
    //   8: iload #9
    //   10: ifeq -> 27
    //   13: iload_3
    //   14: iconst_1
    //   15: iand
    //   16: ifne -> 22
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: iconst_0
    //   24: putfield 寂 : Z
    //   27: aload_0
    //   28: getfield 淋 : Z
    //   31: iconst_1
    //   32: ixor
    //   33: invokestatic 年 : (Z)V
    //   36: aload_0
    //   37: lload_1
    //   38: invokevirtual 堅 : (J)V
    //   41: aload_0
    //   42: getfield 寒 : [J
    //   45: astore #10
    //   47: aload_0
    //   48: getfield 苦 : I
    //   51: istore #8
    //   53: aload #10
    //   55: iload #8
    //   57: lload_1
    //   58: lastore
    //   59: aload_0
    //   60: getfield 熱 : [J
    //   63: astore #10
    //   65: aload #10
    //   67: iload #8
    //   69: lload #4
    //   71: lastore
    //   72: aload_0
    //   73: getfield 暑 : [I
    //   76: iload #8
    //   78: iload #6
    //   80: iastore
    //   81: aload_0
    //   82: getfield 冷 : [I
    //   85: iload #8
    //   87: iload_3
    //   88: iastore
    //   89: aload_0
    //   90: getfield 美 : [Ly/wh0;
    //   93: iload #8
    //   95: aload #7
    //   97: aastore
    //   98: aload_0
    //   99: getfield 旨 : [Ly/gg0;
    //   102: iload #8
    //   104: aload_0
    //   105: getfield 怖 : Ly/gg0;
    //   108: aastore
    //   109: aload_0
    //   110: getfield 堅 : [I
    //   113: iload #8
    //   115: iconst_0
    //   116: iastore
    //   117: aload_0
    //   118: getfield 不 : I
    //   121: iconst_1
    //   122: iadd
    //   123: istore #6
    //   125: aload_0
    //   126: iload #6
    //   128: putfield 不 : I
    //   131: aload_0
    //   132: getfield 硬 : I
    //   135: istore_3
    //   136: iload #6
    //   138: iload_3
    //   139: if_icmpne -> 473
    //   142: iload_3
    //   143: sipush #1000
    //   146: iadd
    //   147: istore #6
    //   149: iload #6
    //   151: newarray int
    //   153: astore #7
    //   155: iload #6
    //   157: newarray long
    //   159: astore #11
    //   161: iload #6
    //   163: newarray long
    //   165: astore #12
    //   167: iload #6
    //   169: newarray int
    //   171: astore #13
    //   173: iload #6
    //   175: newarray int
    //   177: astore #14
    //   179: iload #6
    //   181: anewarray y/wh0
    //   184: astore #15
    //   186: iload #6
    //   188: anewarray y/gg0
    //   191: astore #16
    //   193: aload_0
    //   194: getfield ぱ : I
    //   197: istore #8
    //   199: iload_3
    //   200: iload #8
    //   202: isub
    //   203: istore_3
    //   204: aload #10
    //   206: iload #8
    //   208: aload #11
    //   210: iconst_0
    //   211: iload_3
    //   212: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   215: aload_0
    //   216: getfield 寒 : [J
    //   219: aload_0
    //   220: getfield ぱ : I
    //   223: aload #12
    //   225: iconst_0
    //   226: iload_3
    //   227: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   230: aload_0
    //   231: getfield 冷 : [I
    //   234: aload_0
    //   235: getfield ぱ : I
    //   238: aload #13
    //   240: iconst_0
    //   241: iload_3
    //   242: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   245: aload_0
    //   246: getfield 暑 : [I
    //   249: aload_0
    //   250: getfield ぱ : I
    //   253: aload #14
    //   255: iconst_0
    //   256: iload_3
    //   257: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   260: aload_0
    //   261: getfield 美 : [Ly/wh0;
    //   264: aload_0
    //   265: getfield ぱ : I
    //   268: aload #15
    //   270: iconst_0
    //   271: iload_3
    //   272: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   275: aload_0
    //   276: getfield 旨 : [Ly/gg0;
    //   279: aload_0
    //   280: getfield ぱ : I
    //   283: aload #16
    //   285: iconst_0
    //   286: iload_3
    //   287: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   290: aload_0
    //   291: getfield 堅 : [I
    //   294: aload_0
    //   295: getfield ぱ : I
    //   298: aload #7
    //   300: iconst_0
    //   301: iload_3
    //   302: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   305: aload_0
    //   306: getfield ぱ : I
    //   309: istore #8
    //   311: aload_0
    //   312: getfield 熱 : [J
    //   315: iconst_0
    //   316: aload #11
    //   318: iload_3
    //   319: iload #8
    //   321: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   324: aload_0
    //   325: getfield 寒 : [J
    //   328: iconst_0
    //   329: aload #12
    //   331: iload_3
    //   332: iload #8
    //   334: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   337: aload_0
    //   338: getfield 冷 : [I
    //   341: iconst_0
    //   342: aload #13
    //   344: iload_3
    //   345: iload #8
    //   347: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   350: aload_0
    //   351: getfield 暑 : [I
    //   354: iconst_0
    //   355: aload #14
    //   357: iload_3
    //   358: iload #8
    //   360: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   363: aload_0
    //   364: getfield 美 : [Ly/wh0;
    //   367: iconst_0
    //   368: aload #15
    //   370: iload_3
    //   371: iload #8
    //   373: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   376: aload_0
    //   377: getfield 旨 : [Ly/gg0;
    //   380: iconst_0
    //   381: aload #16
    //   383: iload_3
    //   384: iload #8
    //   386: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   389: aload_0
    //   390: getfield 堅 : [I
    //   393: iconst_0
    //   394: aload #7
    //   396: iload_3
    //   397: iload #8
    //   399: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   402: aload_0
    //   403: aload #11
    //   405: putfield 熱 : [J
    //   408: aload_0
    //   409: aload #12
    //   411: putfield 寒 : [J
    //   414: aload_0
    //   415: aload #13
    //   417: putfield 冷 : [I
    //   420: aload_0
    //   421: aload #14
    //   423: putfield 暑 : [I
    //   426: aload_0
    //   427: aload #15
    //   429: putfield 美 : [Ly/wh0;
    //   432: aload_0
    //   433: aload #16
    //   435: putfield 旨 : [Ly/gg0;
    //   438: aload_0
    //   439: aload #7
    //   441: putfield 堅 : [I
    //   444: aload_0
    //   445: iconst_0
    //   446: putfield ぱ : I
    //   449: aload_0
    //   450: getfield 硬 : I
    //   453: istore_3
    //   454: aload_0
    //   455: iload_3
    //   456: putfield 苦 : I
    //   459: aload_0
    //   460: iload_3
    //   461: putfield 不 : I
    //   464: aload_0
    //   465: iload #6
    //   467: putfield 硬 : I
    //   470: aload_0
    //   471: monitorexit
    //   472: return
    //   473: iload #8
    //   475: iconst_1
    //   476: iadd
    //   477: istore #6
    //   479: aload_0
    //   480: iload #6
    //   482: putfield 苦 : I
    //   485: iload #6
    //   487: iload_3
    //   488: if_icmpne -> 499
    //   491: aload_0
    //   492: iconst_0
    //   493: putfield 苦 : I
    //   496: aload_0
    //   497: monitorexit
    //   498: return
    //   499: aload_0
    //   500: monitorexit
    //   501: return
    //   502: astore #7
    //   504: aload_0
    //   505: monitorexit
    //   506: aload #7
    //   508: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	502	finally
    //   22	27	502	finally
    //   27	53	502	finally
    //   59	65	502	finally
    //   72	136	502	finally
    //   149	199	502	finally
    //   204	470	502	finally
    //   479	485	502	finally
    //   491	496	502	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ak0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */