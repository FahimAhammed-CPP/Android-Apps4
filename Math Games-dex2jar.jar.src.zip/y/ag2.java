package y;

import java.io.Serializable;
import java.util.ArrayList;

public final class ag2 implements Serializable, td2 {}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ag2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */