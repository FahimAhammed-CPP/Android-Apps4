package y;

import android.os.IInterface;

public interface a51 extends IInterface {
  void ア(類 param類, e51 parame51, x41 paramx41);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a51.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */