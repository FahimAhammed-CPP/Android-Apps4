package y;

import java.util.Arrays;

public final class am2 extends fm2 {
  public final int 怖;
  
  public final int 恐;
  
  public final yl2 痒;
  
  public final zl2 痛;
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof am2))
      return false; 
    paramObject = paramObject;
    return (((am2)paramObject).怖 == this.怖 && paramObject.怖() == 怖() && ((am2)paramObject).痛 == this.痛 && ((am2)paramObject).痒 == this.痒);
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.恐), this.痛, this.痒 });
  }
  
  public final String toString() {
    String str1 = String.valueOf(this.痛);
    String str2 = String.valueOf(this.痒);
    StringBuilder stringBuilder = new StringBuilder("HMAC Parameters (variant: ");
    stringBuilder.append(str1);
    stringBuilder.append(", hashType: ");
    stringBuilder.append(str2);
    stringBuilder.append(", ");
    stringBuilder.append(this.恐);
    stringBuilder.append("-byte tags, and ");
    stringBuilder.append(this.怖);
    stringBuilder.append("-byte key)");
    return stringBuilder.toString();
  }
  
  public final int 怖() {
    zl2 zl21 = zl2.冷;
    int i = this.恐;
    zl2 zl22 = this.痛;
    if (zl22 == zl21)
      return i; 
    if (zl22 == zl2.堅)
      return i + 5; 
    if (zl22 == zl2.熱)
      return i + 5; 
    if (zl22 == zl2.暑)
      return i + 5; 
    throw new IllegalStateException("Unknown variant");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\am2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */