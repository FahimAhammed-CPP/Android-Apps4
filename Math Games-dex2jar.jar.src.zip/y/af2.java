package y;

import java.util.ConcurrentModificationException;
import java.util.Iterator;

public abstract class af2 implements Iterator {
  public int 怖;
  
  public int 恐;
  
  public int 淋;
  
  public af2(cf2 paramcf2) {
    boolean bool;
    this.淋 = paramcf2.痒;
    if (paramcf2.isEmpty()) {
      bool = true;
    } else {
      bool = false;
    } 
    this.怖 = bool;
    this.恐 = -1;
  }
  
  public final boolean hasNext() {
    return (this.怖 >= 0);
  }
  
  public final Object next() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 痛 : Ly/cf2;
    //   4: astore #4
    //   6: aload #4
    //   8: getfield 痒 : I
    //   11: aload_0
    //   12: getfield 淋 : I
    //   15: if_icmpne -> 155
    //   18: aload_0
    //   19: invokevirtual hasNext : ()Z
    //   22: ifeq -> 147
    //   25: aload_0
    //   26: getfield 怖 : I
    //   29: istore_1
    //   30: aload_0
    //   31: iload_1
    //   32: putfield 恐 : I
    //   35: aload_0
    //   36: checkcast y/oe2
    //   39: astore_3
    //   40: aload_3
    //   41: getfield 痒 : I
    //   44: istore_2
    //   45: aload_3
    //   46: getfield 臭 : Ly/cf2;
    //   49: astore_3
    //   50: iload_2
    //   51: tableswitch default -> 72, 0 -> 88, 1 -> 75
    //   72: goto -> 105
    //   75: new y/bf2
    //   78: dup
    //   79: aload_3
    //   80: iload_1
    //   81: invokespecial <init> : (Ly/cf2;I)V
    //   84: astore_3
    //   85: goto -> 119
    //   88: aload_3
    //   89: getfield 恐 : [Ljava/lang/Object;
    //   92: astore_3
    //   93: aload_3
    //   94: invokevirtual getClass : ()Ljava/lang/Class;
    //   97: pop
    //   98: aload_3
    //   99: iload_1
    //   100: aaload
    //   101: astore_3
    //   102: goto -> 119
    //   105: aload_3
    //   106: getfield 痛 : [Ljava/lang/Object;
    //   109: astore_3
    //   110: aload_3
    //   111: invokevirtual getClass : ()Ljava/lang/Class;
    //   114: pop
    //   115: aload_3
    //   116: iload_1
    //   117: aaload
    //   118: astore_3
    //   119: aload_0
    //   120: getfield 怖 : I
    //   123: iconst_1
    //   124: iadd
    //   125: istore_1
    //   126: iload_1
    //   127: aload #4
    //   129: getfield 臭 : I
    //   132: if_icmpge -> 138
    //   135: goto -> 140
    //   138: iconst_m1
    //   139: istore_1
    //   140: aload_0
    //   141: iload_1
    //   142: putfield 怖 : I
    //   145: aload_3
    //   146: areturn
    //   147: new java/util/NoSuchElementException
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: athrow
    //   155: new java/util/ConcurrentModificationException
    //   158: dup
    //   159: invokespecial <init> : ()V
    //   162: athrow
  }
  
  public final void remove() {
    cf2 cf21 = this.痛;
    if (cf21.痒 == this.淋) {
      boolean bool;
      if (this.恐 >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      꽃.官("no calls to next() since the last call to remove()", bool);
      this.淋 += 32;
      int i = this.恐;
      Object[] arrayOfObject = cf21.恐;
      arrayOfObject.getClass();
      cf21.remove(arrayOfObject[i]);
      this.怖--;
      this.恐 = -1;
      return;
    } 
    throw new ConcurrentModificationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\af2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */