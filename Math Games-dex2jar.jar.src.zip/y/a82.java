package y;

import java.util.ArrayDeque;

public final class a82 {
  public int 冷 = 1;
  
  public final yd0 堅;
  
  public e82 暑;
  
  public final ArrayDeque 熱;
  
  public final f72 硬;
  
  public a82(f72 paramf72, m72 paramm72, yd0 paramyd0) {
    this.硬 = paramf72;
    this.堅 = paramyd0;
    this.熱 = new ArrayDeque();
    paramm72.硬 = new mz1(29, this);
  }
  
  public final void 堅() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xp0.蠊 : Ly/sp0;
    //   5: astore_1
    //   6: getstatic y/ml0.暑 : Ly/ml0;
    //   9: getfield 熱 : Ly/vp0;
    //   12: aload_1
    //   13: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   16: checkcast java/lang/Boolean
    //   19: invokevirtual booleanValue : ()Z
    //   22: ifeq -> 56
    //   25: getstatic y/t13.帰 : Ly/t13;
    //   28: getfield 美 : Ly/j51;
    //   31: invokevirtual 熱 : ()Ly/gu2;
    //   34: invokevirtual 興 : ()Ly/h51;
    //   37: getfield 辛 : Z
    //   40: ifeq -> 46
    //   43: goto -> 56
    //   46: aload_0
    //   47: getfield 熱 : Ljava/util/ArrayDeque;
    //   50: invokevirtual clear : ()V
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: aload_0
    //   57: invokevirtual 熱 : ()Z
    //   60: ifeq -> 151
    //   63: aload_0
    //   64: getfield 熱 : Ljava/util/ArrayDeque;
    //   67: invokevirtual isEmpty : ()Z
    //   70: ifne -> 148
    //   73: aload_0
    //   74: getfield 熱 : Ljava/util/ArrayDeque;
    //   77: invokevirtual pollFirst : ()Ljava/lang/Object;
    //   80: checkcast y/g52
    //   83: astore_1
    //   84: aload_1
    //   85: ifnull -> 108
    //   88: aload_1
    //   89: getfield 美 : Ly/u72;
    //   92: astore_2
    //   93: aload_2
    //   94: ifnull -> 63
    //   97: aload_0
    //   98: getfield 硬 : Ly/f72;
    //   101: aload_2
    //   102: invokevirtual 寝 : (Ly/u72;)Z
    //   105: ifeq -> 63
    //   108: new y/e82
    //   111: dup
    //   112: aload_0
    //   113: getfield 硬 : Ly/f72;
    //   116: aload_0
    //   117: getfield 堅 : Ly/yd0;
    //   120: aload_1
    //   121: invokespecial <init> : (Ly/f72;Ly/yd0;Ly/g52;)V
    //   124: astore_2
    //   125: aload_0
    //   126: aload_2
    //   127: putfield 暑 : Ly/e82;
    //   130: aload_2
    //   131: new y/df1
    //   134: dup
    //   135: aload_0
    //   136: aload_1
    //   137: bipush #21
    //   139: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;I)V
    //   142: invokevirtual 堅 : (Ly/df1;)V
    //   145: aload_0
    //   146: monitorexit
    //   147: return
    //   148: aload_0
    //   149: monitorexit
    //   150: return
    //   151: aload_0
    //   152: monitorexit
    //   153: return
    //   154: astore_1
    //   155: aload_0
    //   156: monitorexit
    //   157: aload_1
    //   158: athrow
    // Exception table:
    //   from	to	target	type
    //   2	43	154	finally
    //   46	53	154	finally
    //   56	63	154	finally
    //   63	84	154	finally
    //   88	93	154	finally
    //   97	108	154	finally
    //   108	145	154	finally
  }
  
  public final boolean 熱() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 暑 : Ly/e82;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: ifnonnull -> 15
    //   13: iconst_1
    //   14: ireturn
    //   15: iconst_0
    //   16: ireturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	17	finally
  }
  
  public final void 硬(g52 paramg52) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 熱 : Ljava/util/ArrayDeque;
    //   6: aload_1
    //   7: invokevirtual add : (Ljava/lang/Object;)Z
    //   10: pop
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a82.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */