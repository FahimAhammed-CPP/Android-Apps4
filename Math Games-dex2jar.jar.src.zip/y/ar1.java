package y;

import android.os.SystemClock;
import java.util.Map;

public final class ar1 implements r82 {
  public final Object 怖;
  
  public final Object 恐;
  
  public ar1(co0 paramco0, Map paramMap) {
    this.怖 = paramMap;
    this.恐 = paramco0;
  }
  
  public ar1(gw1 paramgw1, hw1 paramhw1) {
    this.怖 = paramgw1;
    this.恐 = paramhw1;
  }
  
  public final void 堅(p82 paramp82, String paramString) {
    int i = this.淋;
    Object object = this.怖;
    switch (i) {
      case 0:
        object = object;
        if (object.containsKey(paramp82))
          ((co0)this.恐).堅(((zq1)object.get(paramp82)).堅); 
        return;
    } 
    sp0 sp0 = xp0.蝿;
    if (((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() && p82.痒 == paramp82) {
      gw1 gw1 = (gw1)object;
      if (gw1.熱() != 0L) {
        t13.帰.辛.getClass();
        long l = SystemClock.elapsedRealtime();
        synchronized (gw1.熱()) {
          synchronized (gw1.辛) {
            gw1.冷 = l - null;
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{y/gw1}, name=null} */
            return;
          } 
        } 
      } 
    } 
  }
  
  public final void 怖(String paramString) {}
  
  public final void 旨(p82 paramp82, String paramString, Throwable paramThrowable) {
    int i = this.淋;
    Object object = this.怖;
    switch (i) {
      case 0:
        object = object;
        if (object.containsKey(paramp82))
          ((co0)this.恐).堅(((zq1)object.get(paramp82)).熱); 
        return;
    } 
    sp0 sp0 = xp0.蝿;
    if (((Boolean)ml0.暑.熱.硬(sp0)).booleanValue() && p82.痒 == paramp82) {
      gw1 gw1 = (gw1)object;
      if (gw1.熱() != 0L) {
        t13.帰.辛.getClass();
        long l = SystemClock.elapsedRealtime();
        synchronized (gw1.熱()) {
          synchronized (gw1.辛) {
            gw1.冷 = l - null;
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{y/gw1}, name=null} */
            return;
          } 
        } 
      } 
    } 
  }
  
  public final void 硬(p82 paramp82, String paramString) {
    gw1 gw1;
    Map map;
    switch (this.淋) {
      case 0:
        map = (Map)this.怖;
        if (map.containsKey(paramp82))
          ((co0)this.恐).堅(((zq1)map.get(paramp82)).硬); 
        return;
    } 
    sp0 sp0 = xp0.蝿;
    if (!((Boolean)ml0.暑.熱.硬(sp0)).booleanValue())
      return; 
    if (p82.痒 == paramp82) {
      gw1 = (gw1)this.怖;
      t13.帰.辛.getClass();
      synchronized (SystemClock.elapsedRealtime()) {
        synchronized (gw1.不) {
          gw1.暑 = null;
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{y/gw1}, name=null} */
          return;
        } 
      } 
    } 
    if (p82.わ == gw1 || p82.痛 == gw1) {
      gw1 = (gw1)this.怖;
      t13.帰.辛.getClass();
      gw1.冷(SystemClock.elapsedRealtime());
      hw1 hw1 = (hw1)this.恐;
      long l = ((gw1)this.怖).暑();
      ((ol2)hw1.堅).不(new m50(hw1, l, 4));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ar1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */