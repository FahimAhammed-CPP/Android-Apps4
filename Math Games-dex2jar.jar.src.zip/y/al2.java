package y;

public interface al2 {
  k21 悲(nl2 paramnl2);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\al2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */