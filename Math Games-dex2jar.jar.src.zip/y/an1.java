package y;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import org.json.JSONObject;

public final class an1 extends if1 {
  public static final fg2 寝;
  
  public final hn1 ぱ;
  
  public final Executor 不;
  
  public final x51 壊;
  
  public final gn1 嬉;
  
  public final zs2 寂;
  
  public final Context 帰;
  
  public final zs2 怖;
  
  public final zs2 恐;
  
  public final in1 悲;
  
  public final f02 歩;
  
  public final vd0 死;
  
  public final HashMap 泳;
  
  public final zs2 淋;
  
  public final h41 産;
  
  public eo1 痒;
  
  public final zs2 痛;
  
  public boolean 臭;
  
  public boolean 興;
  
  public final rn1 苦;
  
  public boolean 起;
  
  public final ArrayList 踊;
  
  public final en1 辛;
  
  public final cn1 返;
  
  static {
    lf2 lf2 = nf2.怖;
    Object[] arrayOfObject = new Object[6];
    arrayOfObject[0] = "3010";
    arrayOfObject[1] = "3008";
    arrayOfObject[2] = "1005";
    arrayOfObject[3] = "1009";
    arrayOfObject[4] = "2011";
    arrayOfObject[5] = "2007";
    꽃.く(6, arrayOfObject);
    寝 = nf2.悲(6, arrayOfObject);
  }
  
  public an1(ci0 paramci0, Executor paramExecutor, en1 paramen1, hn1 paramhn1, rn1 paramrn1, gn1 paramgn1, in1 paramin1, zs2 paramzs21, zs2 paramzs22, zs2 paramzs23, zs2 paramzs24, zs2 paramzs25, h41 paramh41, vd0 paramvd0, x51 paramx51, Context paramContext, cn1 paramcn1, f02 paramf02) {
    super(paramci0);
    this.不 = paramExecutor;
    this.辛 = paramen1;
    this.ぱ = paramhn1;
    this.苦 = paramrn1;
    this.嬉 = paramgn1;
    this.悲 = paramin1;
    this.寂 = paramzs21;
    this.淋 = paramzs22;
    this.怖 = paramzs23;
    this.恐 = paramzs24;
    this.痛 = paramzs25;
    this.産 = paramh41;
    this.死 = paramvd0;
    this.壊 = paramx51;
    this.帰 = paramContext;
    this.返 = paramcn1;
    this.歩 = paramf02;
    this.泳 = new HashMap<Object, Object>();
    this.踊 = new ArrayList();
  }
  
  public static boolean 嬉(View paramView) {
    sp0 sp01;
    sp0 sp02 = xp0.聞;
    ml0 ml0 = ml0.暑;
    if (((Boolean)ml0.熱.硬(sp02)).booleanValue()) {
      u03 u03 = t13.帰.熱;
      long l = u03.踊(paramView);
      if (paramView.isShown() && paramView.getGlobalVisibleRect(new Rect(), null)) {
        sp01 = xp0.辞;
        if (l >= ((Integer)ml0.熱.硬(sp01)).intValue())
          return true; 
      } 
      return false;
    } 
    return (sp01.isShown() && sp01.getGlobalVisibleRect(new Rect(), null));
  }
  
  public final void ぱ(eo1 parameo1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xp0.ジ : Ly/sp0;
    //   5: astore_2
    //   6: getstatic y/ml0.暑 : Ly/ml0;
    //   9: getfield 熱 : Ly/vp0;
    //   12: aload_2
    //   13: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   16: checkcast java/lang/Boolean
    //   19: invokevirtual booleanValue : ()Z
    //   22: ifeq -> 45
    //   25: getstatic y/u03.不 : Ly/j32;
    //   28: new y/vm1
    //   31: dup
    //   32: aload_0
    //   33: aload_1
    //   34: iconst_0
    //   35: invokespecial <init> : (Ly/an1;Ly/eo1;I)V
    //   38: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   41: pop
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual 痛 : (Ly/eo1;)V
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   2	42	53	finally
    //   45	50	53	finally
  }
  
  public final void 不(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: invokeinterface 辛 : (Landroid/view/View;)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void 冷(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: invokeinterface 起 : (Landroid/os/Bundle;)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void 堅() {
    wm1 wm1 = new wm1(this, 0);
    Executor executor = this.不;
    executor.execute(wm1);
    if (this.辛.壊() != 7) {
      hn1 hn11 = this.ぱ;
      hn11.getClass();
      executor.execute(new pd0(26, hn11));
    } 
    super.堅();
  }
  
  public final void 壊(View paramView, Map paramMap1, Map paramMap2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 起 : Z
    //   6: istore #5
    //   8: iload #5
    //   10: ifeq -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: getstatic y/xp0.ア : Ly/sp0;
    //   19: astore #6
    //   21: getstatic y/ml0.暑 : Ly/ml0;
    //   24: getfield 熱 : Ly/vp0;
    //   27: aload #6
    //   29: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   32: checkcast java/lang/Boolean
    //   35: invokevirtual booleanValue : ()Z
    //   38: ifeq -> 112
    //   41: aload_0
    //   42: getfield 堅 : Ly/r62;
    //   45: getfield 톨 : Z
    //   48: ifeq -> 112
    //   51: aload_0
    //   52: getfield 泳 : Ljava/util/HashMap;
    //   55: invokevirtual keySet : ()Ljava/util/Set;
    //   58: invokeinterface iterator : ()Ljava/util/Iterator;
    //   63: astore #6
    //   65: aload #6
    //   67: invokeinterface hasNext : ()Z
    //   72: ifeq -> 112
    //   75: aload #6
    //   77: invokeinterface next : ()Ljava/lang/Object;
    //   82: checkcast java/lang/String
    //   85: astore #7
    //   87: aload_0
    //   88: getfield 泳 : Ljava/util/HashMap;
    //   91: aload #7
    //   93: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   96: checkcast java/lang/Boolean
    //   99: invokevirtual booleanValue : ()Z
    //   102: istore #5
    //   104: iload #5
    //   106: ifne -> 65
    //   109: aload_0
    //   110: monitorexit
    //   111: return
    //   112: iload #4
    //   114: ifne -> 221
    //   117: getstatic y/xp0.げ : Ly/sp0;
    //   120: astore #6
    //   122: getstatic y/ml0.暑 : Ly/ml0;
    //   125: getfield 熱 : Ly/vp0;
    //   128: aload #6
    //   130: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   133: checkcast java/lang/Boolean
    //   136: invokevirtual booleanValue : ()Z
    //   139: ifeq -> 218
    //   142: aload_2
    //   143: ifnull -> 218
    //   146: aload_2
    //   147: invokeinterface entrySet : ()Ljava/util/Set;
    //   152: invokeinterface iterator : ()Ljava/util/Iterator;
    //   157: astore #6
    //   159: aload #6
    //   161: invokeinterface hasNext : ()Z
    //   166: ifeq -> 218
    //   169: aload #6
    //   171: invokeinterface next : ()Ljava/lang/Object;
    //   176: checkcast java/util/Map$Entry
    //   179: invokeinterface getValue : ()Ljava/lang/Object;
    //   184: checkcast java/lang/ref/WeakReference
    //   187: invokevirtual get : ()Ljava/lang/Object;
    //   190: checkcast android/view/View
    //   193: astore #7
    //   195: aload #7
    //   197: ifnull -> 159
    //   200: aload #7
    //   202: invokestatic 嬉 : (Landroid/view/View;)Z
    //   205: ifeq -> 159
    //   208: aload_0
    //   209: aload_1
    //   210: aload_2
    //   211: aload_3
    //   212: invokevirtual 怖 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;)V
    //   215: aload_0
    //   216: monitorexit
    //   217: return
    //   218: aload_0
    //   219: monitorexit
    //   220: return
    //   221: aload_0
    //   222: aload_2
    //   223: invokevirtual 寂 : (Ljava/util/Map;)Landroid/view/View;
    //   226: astore #6
    //   228: aload #6
    //   230: ifnonnull -> 243
    //   233: aload_0
    //   234: aload_1
    //   235: aload_2
    //   236: aload_3
    //   237: invokevirtual 怖 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;)V
    //   240: aload_0
    //   241: monitorexit
    //   242: return
    //   243: getstatic y/xp0.人 : Ly/sp0;
    //   246: astore #8
    //   248: getstatic y/ml0.暑 : Ly/ml0;
    //   251: astore #7
    //   253: aload #7
    //   255: getfield 熱 : Ly/vp0;
    //   258: aload #8
    //   260: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   263: checkcast java/lang/Boolean
    //   266: invokevirtual booleanValue : ()Z
    //   269: ifeq -> 293
    //   272: aload #6
    //   274: invokestatic 嬉 : (Landroid/view/View;)Z
    //   277: ifeq -> 290
    //   280: aload_0
    //   281: aload_1
    //   282: aload_2
    //   283: aload_3
    //   284: invokevirtual 怖 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;)V
    //   287: aload_0
    //   288: monitorexit
    //   289: return
    //   290: aload_0
    //   291: monitorexit
    //   292: return
    //   293: getstatic y/xp0.間 : Ly/sp0;
    //   296: astore #8
    //   298: aload #7
    //   300: getfield 熱 : Ly/vp0;
    //   303: aload #8
    //   305: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   308: checkcast java/lang/Boolean
    //   311: invokevirtual booleanValue : ()Z
    //   314: ifeq -> 376
    //   317: new android/graphics/Rect
    //   320: dup
    //   321: invokespecial <init> : ()V
    //   324: astore #7
    //   326: aload #6
    //   328: aload #7
    //   330: aconst_null
    //   331: invokevirtual getGlobalVisibleRect : (Landroid/graphics/Rect;Landroid/graphics/Point;)Z
    //   334: ifeq -> 373
    //   337: aload #6
    //   339: invokevirtual getHeight : ()I
    //   342: aload #7
    //   344: invokevirtual height : ()I
    //   347: if_icmpne -> 373
    //   350: aload #6
    //   352: invokevirtual getWidth : ()I
    //   355: aload #7
    //   357: invokevirtual width : ()I
    //   360: if_icmpne -> 373
    //   363: aload_0
    //   364: aload_1
    //   365: aload_2
    //   366: aload_3
    //   367: invokevirtual 怖 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;)V
    //   370: aload_0
    //   371: monitorexit
    //   372: return
    //   373: aload_0
    //   374: monitorexit
    //   375: return
    //   376: aload_0
    //   377: aload_1
    //   378: aload_2
    //   379: aload_3
    //   380: invokevirtual 怖 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;)V
    //   383: aload_0
    //   384: monitorexit
    //   385: return
    //   386: astore_1
    //   387: aload_0
    //   388: monitorexit
    //   389: aload_1
    //   390: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	386	finally
    //   16	65	386	finally
    //   65	104	386	finally
    //   117	142	386	finally
    //   146	159	386	finally
    //   159	195	386	finally
    //   200	215	386	finally
    //   221	228	386	finally
    //   233	240	386	finally
    //   243	287	386	finally
    //   293	370	386	finally
    //   376	383	386	finally
  }
  
  public final View 寂(Map paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 10
    //   6: aload_0
    //   7: monitorexit
    //   8: aconst_null
    //   9: areturn
    //   10: getstatic y/an1.寝 : Ly/fg2;
    //   13: astore #4
    //   15: aload #4
    //   17: getfield 痛 : I
    //   20: istore_3
    //   21: iconst_0
    //   22: istore_2
    //   23: iload_2
    //   24: iload_3
    //   25: if_icmpge -> 70
    //   28: aload_1
    //   29: aload #4
    //   31: iload_2
    //   32: invokevirtual get : (I)Ljava/lang/Object;
    //   35: checkcast java/lang/String
    //   38: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   43: checkcast java/lang/ref/WeakReference
    //   46: astore #5
    //   48: iload_2
    //   49: iconst_1
    //   50: iadd
    //   51: istore_2
    //   52: aload #5
    //   54: ifnull -> 23
    //   57: aload #5
    //   59: invokevirtual get : ()Ljava/lang/Object;
    //   62: checkcast android/view/View
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: areturn
    //   70: aload_0
    //   71: monitorexit
    //   72: aconst_null
    //   73: areturn
    //   74: astore_1
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_1
    //   78: athrow
    // Exception table:
    //   from	to	target	type
    //   10	21	74	finally
    //   28	48	74	finally
    //   57	66	74	finally
  }
  
  public final void 寒(View paramView) {
    en1 en11 = this.辛;
    類 類 = en11.わ();
    e91 e91 = en11.か();
    if (this.嬉.熱() && 類 != null && e91 != null && paramView != null) {
      t13.帰.起.getClass();
      獅.寂(類, paramView);
    } 
  }
  
  public final void 帰(View paramView1, View paramView2, Map paramMap1, Map paramMap2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 苦 : Ly/rn1;
    //   6: astore #7
    //   8: aload_0
    //   9: getfield 痒 : Ly/eo1;
    //   12: astore #8
    //   14: aload #8
    //   16: ifnull -> 87
    //   19: aload #7
    //   21: getfield 冷 : Ly/yn1;
    //   24: astore #9
    //   26: aload #9
    //   28: ifnull -> 93
    //   31: aload #8
    //   33: invokeinterface 寒 : ()Landroid/widget/FrameLayout;
    //   38: ifnonnull -> 44
    //   41: goto -> 93
    //   44: aload #7
    //   46: getfield 熱 : Ly/gn1;
    //   49: invokevirtual 寒 : ()Z
    //   52: istore #6
    //   54: iload #6
    //   56: ifne -> 62
    //   59: goto -> 93
    //   62: aload #8
    //   64: invokeinterface 寒 : ()Landroid/widget/FrameLayout;
    //   69: aload #9
    //   71: invokevirtual 硬 : ()Landroid/view/View;
    //   74: invokevirtual addView : (Landroid/view/View;)V
    //   77: goto -> 93
    //   80: invokestatic 堅 : ()Z
    //   83: pop
    //   84: goto -> 93
    //   87: aload #7
    //   89: invokevirtual getClass : ()Ljava/lang/Class;
    //   92: pop
    //   93: aload_0
    //   94: getfield ぱ : Ly/hn1;
    //   97: aload_1
    //   98: aload_2
    //   99: aload_3
    //   100: aload #4
    //   102: iload #5
    //   104: aload_0
    //   105: invokevirtual 淋 : ()Landroid/widget/ImageView$ScaleType;
    //   108: invokeinterface 痛 : (Landroid/view/View;Landroid/view/View;Ljava/util/Map;Ljava/util/Map;ZLandroid/widget/ImageView$ScaleType;)V
    //   113: aload_0
    //   114: getfield 興 : Z
    //   117: ifeq -> 157
    //   120: aload_0
    //   121: getfield 辛 : Ly/en1;
    //   124: astore_1
    //   125: aload_1
    //   126: invokevirtual ち : ()Ly/e91;
    //   129: ifnonnull -> 135
    //   132: goto -> 157
    //   135: aload_1
    //   136: invokevirtual ち : ()Ly/e91;
    //   139: ldc_w 'onSdkAdUserInteractionClick'
    //   142: new y/緑
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: invokeinterface 硬 : (Ljava/lang/String;Ljava/util/Map;)V
    //   154: aload_0
    //   155: monitorexit
    //   156: return
    //   157: aload_0
    //   158: monitorexit
    //   159: return
    //   160: astore_1
    //   161: aload_0
    //   162: monitorexit
    //   163: aload_1
    //   164: athrow
    //   165: astore #7
    //   167: goto -> 80
    // Exception table:
    //   from	to	target	type
    //   2	14	160	finally
    //   19	26	160	finally
    //   31	41	160	finally
    //   44	54	160	finally
    //   62	77	165	y/j91
    //   62	77	160	finally
    //   80	84	160	finally
    //   87	93	160	finally
    //   93	132	160	finally
    //   135	154	160	finally
  }
  
  public final void 怖(View paramView, Map paramMap1, Map paramMap2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 苦 : Ly/rn1;
    //   6: aload_0
    //   7: getfield 痒 : Ly/eo1;
    //   10: invokevirtual 硬 : (Ly/eo1;)V
    //   13: aload_0
    //   14: getfield ぱ : Ly/hn1;
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload_0
    //   21: invokevirtual 淋 : ()Landroid/widget/ImageView$ScaleType;
    //   24: invokeinterface 美 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;Landroid/widget/ImageView$ScaleType;)V
    //   29: aload_0
    //   30: iconst_1
    //   31: putfield 起 : Z
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	34	37	finally
  }
  
  public final void 恐(eo1 parameo1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 臭 : Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: aload_1
    //   16: putfield 痒 : Ly/eo1;
    //   19: aload_0
    //   20: getfield 苦 : Ly/rn1;
    //   23: astore_3
    //   24: aload_3
    //   25: invokevirtual getClass : ()Ljava/lang/Class;
    //   28: pop
    //   29: new y/qw0
    //   32: dup
    //   33: aload_3
    //   34: bipush #26
    //   36: aload_1
    //   37: invokespecial <init> : (Ljava/lang/Object;ILjava/lang/Object;)V
    //   40: astore #4
    //   42: aload_3
    //   43: getfield 美 : Ljava/util/concurrent/Executor;
    //   46: aload #4
    //   48: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   53: aload_0
    //   54: getfield ぱ : Ly/hn1;
    //   57: aload_1
    //   58: invokeinterface 不 : ()Landroid/view/View;
    //   63: aload_1
    //   64: invokeinterface 恐 : ()Ljava/util/Map;
    //   69: aload_1
    //   70: invokeinterface 嬉 : ()Ljava/util/Map;
    //   75: aload_1
    //   76: aload_1
    //   77: invokeinterface 嬉 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;Landroid/view/View$OnTouchListener;Landroid/view/View$OnClickListener;)V
    //   82: getstatic y/xp0.ら : Ly/sp0;
    //   85: astore #4
    //   87: getstatic y/ml0.暑 : Ly/ml0;
    //   90: astore_3
    //   91: aload_3
    //   92: getfield 熱 : Ly/vp0;
    //   95: aload #4
    //   97: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   100: checkcast java/lang/Boolean
    //   103: invokevirtual booleanValue : ()Z
    //   106: ifeq -> 136
    //   109: aload_0
    //   110: getfield 死 : Ly/vd0;
    //   113: getfield 堅 : Ly/sd0;
    //   116: astore #4
    //   118: aload #4
    //   120: ifnull -> 136
    //   123: aload #4
    //   125: aload_1
    //   126: invokeinterface 不 : ()Landroid/view/View;
    //   131: invokeinterface 堅 : (Landroid/view/View;)V
    //   136: getstatic y/xp0.ア : Ly/sp0;
    //   139: astore #4
    //   141: aload_3
    //   142: getfield 熱 : Ly/vp0;
    //   145: aload #4
    //   147: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   150: checkcast java/lang/Boolean
    //   153: invokevirtual booleanValue : ()Z
    //   156: ifeq -> 317
    //   159: aload_0
    //   160: getfield 堅 : Ly/r62;
    //   163: astore_3
    //   164: aload_3
    //   165: getfield 톨 : Z
    //   168: ifne -> 174
    //   171: goto -> 317
    //   174: aload_3
    //   175: getfield 톤 : Lorg/json/JSONObject;
    //   178: invokevirtual keys : ()Ljava/util/Iterator;
    //   181: astore_3
    //   182: aload_3
    //   183: ifnull -> 317
    //   186: aload_3
    //   187: invokeinterface hasNext : ()Z
    //   192: ifeq -> 317
    //   195: aload_3
    //   196: invokeinterface next : ()Ljava/lang/Object;
    //   201: checkcast java/lang/String
    //   204: astore #4
    //   206: aload_0
    //   207: getfield 痒 : Ly/eo1;
    //   210: invokeinterface 寂 : ()Ljava/util/Map;
    //   215: aload #4
    //   217: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   222: checkcast java/lang/ref/WeakReference
    //   225: astore #5
    //   227: aload_0
    //   228: getfield 泳 : Ljava/util/HashMap;
    //   231: aload #4
    //   233: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   236: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   239: pop
    //   240: aload #5
    //   242: ifnull -> 186
    //   245: aload #5
    //   247: invokevirtual get : ()Ljava/lang/Object;
    //   250: checkcast android/view/View
    //   253: astore #5
    //   255: aload #5
    //   257: ifnull -> 186
    //   260: new y/mm0
    //   263: dup
    //   264: aload_0
    //   265: getfield 帰 : Landroid/content/Context;
    //   268: aload #5
    //   270: invokespecial <init> : (Landroid/content/Context;Landroid/view/View;)V
    //   273: astore #5
    //   275: aload_0
    //   276: getfield 踊 : Ljava/util/ArrayList;
    //   279: aload #5
    //   281: invokevirtual add : (Ljava/lang/Object;)Z
    //   284: pop
    //   285: new y/zm1
    //   288: dup
    //   289: aload_0
    //   290: aload #4
    //   292: invokespecial <init> : (Ly/an1;Ljava/lang/String;)V
    //   295: astore #4
    //   297: aload #5
    //   299: getfield 帰 : Ljava/util/HashSet;
    //   302: aload #4
    //   304: invokevirtual add : (Ljava/lang/Object;)Z
    //   307: pop
    //   308: aload #5
    //   310: iconst_3
    //   311: invokevirtual 熱 : (I)V
    //   314: goto -> 186
    //   317: aload_1
    //   318: invokeinterface 旨 : ()Ly/mm0;
    //   323: ifnull -> 355
    //   326: aload_1
    //   327: invokeinterface 旨 : ()Ly/mm0;
    //   332: astore_1
    //   333: aload_0
    //   334: getfield 産 : Ly/h41;
    //   337: astore_3
    //   338: aload_1
    //   339: getfield 帰 : Ljava/util/HashSet;
    //   342: aload_3
    //   343: invokevirtual add : (Ljava/lang/Object;)Z
    //   346: pop
    //   347: aload_1
    //   348: iconst_3
    //   349: invokevirtual 熱 : (I)V
    //   352: aload_0
    //   353: monitorexit
    //   354: return
    //   355: aload_0
    //   356: monitorexit
    //   357: return
    //   358: astore_1
    //   359: aload_0
    //   360: monitorexit
    //   361: aload_1
    //   362: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	358	finally
    //   14	118	358	finally
    //   123	136	358	finally
    //   136	171	358	finally
    //   174	182	358	finally
    //   186	240	358	finally
    //   245	255	358	finally
    //   260	314	358	finally
    //   317	352	358	finally
  }
  
  public final boolean 悲(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 起 : Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_1
    //   14: ireturn
    //   15: aload_0
    //   16: getfield ぱ : Ly/hn1;
    //   19: aload_1
    //   20: invokeinterface 不 : (Landroid/os/Bundle;)Z
    //   25: istore_2
    //   26: aload_0
    //   27: iload_2
    //   28: putfield 起 : Z
    //   31: aload_0
    //   32: monitorexit
    //   33: iload_2
    //   34: ireturn
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	35	finally
    //   15	31	35	finally
  }
  
  public final void 旨(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: invokeinterface 堅 : (Landroid/os/Bundle;)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void 暑(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: invokeinterface 큰 : (Ljava/lang/String;)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void 死(String paramString, boolean paramBoolean) {
    if (this.嬉.熱()) {
      if (TextUtils.isEmpty(paramString))
        return; 
      en1 en11 = this.辛;
      e91 e911 = en11.か();
      e91 e912 = en11.ち();
      if (e911 != null || e912 != null) {
        int i;
        String str1;
        int k = 0;
        if (e911 != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (e912 != null) {
          j = 1;
        } else {
          j = 0;
        } 
        sp0 sp01 = xp0.鶏;
        ml0 ml0 = ml0.暑;
        boolean bool = ((Boolean)ml0.熱.硬(sp01)).booleanValue();
        byte b = 2;
        if (bool) {
          this.嬉.硬();
          i = this.嬉.硬().嬉();
          j = i - 1;
          if (j != 0) {
            StringBuilder stringBuilder1;
            if (j != 1) {
              if (i != 1) {
                if (i != 2) {
                  paramString = "UNKNOWN";
                } else {
                  paramString = "DISPLAY";
                } 
              } else {
                paramString = "VIDEO";
              } 
              stringBuilder1 = new StringBuilder("Unknown omid media type: ");
              stringBuilder1.append(paramString);
              stringBuilder1.append(". Not initializing Omid.");
              rr1.美(stringBuilder1.toString());
              return;
            } 
            if (stringBuilder1 != null) {
              j = 1;
              i = 0;
            } else {
              rr1.美("Omid media type was display but there was no display webview.");
              return;
            } 
          } else if (e912 != null) {
            i = 1;
            j = k;
          } else {
            rr1.美("Omid media type was video but there was no video webview.");
            return;
          } 
        } else {
          k = i;
          i = j;
          j = k;
        } 
        if (j != 0) {
          sp01 = null;
        } else {
          str1 = "javascript";
          e911 = e912;
        } 
        e911.帰();
        t13 t13 = t13.帰;
        獅 獅1 = t13.起;
        Context context = this.帰;
        獅1.getClass();
        if (!獅.恐(context)) {
          rr1.美("Failed to initialize omid in InternalNativeAd");
          return;
        } 
        x51 x511 = this.壊;
        int j = x511.怖;
        k = x511.恐;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(j);
        stringBuilder.append(".");
        stringBuilder.append(k);
        String str3 = stringBuilder.toString();
        j = 3;
        if (i != 0) {
          k = 3;
          j = 2;
        } else {
          k = b;
          if (this.辛.壊() == 3) {
            j = 4;
            k = b;
          } 
        } 
        獅 獅2 = t13.起;
        WebView webView = e911.帰();
        String str2 = this.堅.통;
        獅2.getClass();
        sp0 sp02 = xp0.麟;
        if (((Boolean)ml0.熱.硬(sp02)).booleanValue()) {
          t92 t92 = p31.痛;
          if (t92.硬)
            if (!TextUtils.isEmpty(paramString)) {
              if (!TextUtils.isEmpty(str3)) {
                qj1 qj1 = new qj1(paramString, str3);
                ba2 ba21 = 獅.起("javascript");
                ba2 ba22 = 獅.起(str1);
                x92 x92 = 獅.痛(nv0.暑(k));
                ba2 ba23 = ba2.痛;
                if (ba21 == ba23) {
                  rr1.美("Omid js session error; Unable to parse impression owner: javascript");
                } else if (x92 == null) {
                  rr1.美("Omid js session error; Unable to parse creative type: ".concat(nv0.嬉(k)));
                } else if (x92 == x92.痒 && ba22 == ba23) {
                  rr1.美("Omid js session error; Video events owner unknown for video creative: ".concat(String.valueOf(str1)));
                } else {
                  r6 r6;
                  ps ps = new ps(qj1, webView, str2, v92.恐);
                  r52 r52 = r52.か(x92, 獅.臭(nv0.冷(j)), ba21, ba22);
                  if (t92.硬) {
                    r6 = new r6(new w92(r52, ps));
                  } else {
                    throw new IllegalStateException("Method called before OM SDK activation");
                  } 
                  if (r6 == null) {
                    rr1.美("Failed to create omid session in InternalNativeAd");
                    return;
                  } 
                } 
              } else {
                throw new IllegalArgumentException("Version is null or empty");
              } 
            } else {
              throw new IllegalArgumentException("Name is null or empty");
            }  
        } 
        paramString = null;
      } else {
        rr1.美("Omid display and video webview are null. Skipping initialization.");
        return;
      } 
    } else {
      return;
    } 
    if (paramString == null) {
      rr1.美("Failed to create omid session in InternalNativeAd");
      return;
    } 
  }
  
  public final ImageView.ScaleType 淋() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xp0.夜 : Ly/sp0;
    //   5: astore_2
    //   6: getstatic y/ml0.暑 : Ly/ml0;
    //   9: getfield 熱 : Ly/vp0;
    //   12: aload_2
    //   13: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   16: checkcast java/lang/Boolean
    //   19: invokevirtual booleanValue : ()Z
    //   22: istore_1
    //   23: iload_1
    //   24: ifne -> 31
    //   27: aload_0
    //   28: monitorexit
    //   29: aconst_null
    //   30: areturn
    //   31: aload_0
    //   32: getfield 痒 : Ly/eo1;
    //   35: astore_2
    //   36: aload_2
    //   37: ifnonnull -> 50
    //   40: ldc_w 'Ad should be associated with an ad view before calling getMediaviewScaleType()'
    //   43: invokestatic 暑 : (Ljava/lang/String;)V
    //   46: aload_0
    //   47: monitorexit
    //   48: aconst_null
    //   49: areturn
    //   50: aload_2
    //   51: invokeinterface 苦 : ()Ly/類;
    //   56: astore_2
    //   57: aload_2
    //   58: ifnull -> 73
    //   61: aload_2
    //   62: invokestatic ㅌ : (Ly/類;)Ljava/lang/Object;
    //   65: checkcast android/widget/ImageView$ScaleType
    //   68: astore_2
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_2
    //   72: areturn
    //   73: getstatic y/rn1.ぱ : Landroid/widget/ImageView$ScaleType;
    //   76: astore_2
    //   77: aload_0
    //   78: monitorexit
    //   79: aload_2
    //   80: areturn
    //   81: astore_2
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_2
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	81	finally
    //   31	36	81	finally
    //   40	46	81	finally
    //   50	57	81	finally
    //   61	69	81	finally
    //   73	77	81	finally
  }
  
  public final void 熱(FrameLayout paramFrameLayout, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xp0.三 : Ly/sp0;
    //   5: astore #4
    //   7: getstatic y/ml0.暑 : Ly/ml0;
    //   10: getfield 熱 : Ly/vp0;
    //   13: aload #4
    //   15: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   18: checkcast java/lang/Boolean
    //   21: invokevirtual booleanValue : ()Z
    //   24: istore_3
    //   25: iload_3
    //   26: ifne -> 32
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: aload_0
    //   33: getfield 痒 : Ly/eo1;
    //   36: astore #4
    //   38: aload #4
    //   40: ifnonnull -> 52
    //   43: ldc_w 'Ad should be associated with an ad view before calling performClickForCustomGesture()'
    //   46: invokestatic 暑 : (Ljava/lang/String;)V
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: aload #4
    //   54: instanceof y/pn1
    //   57: istore_3
    //   58: aload_0
    //   59: getfield 不 : Ljava/util/concurrent/Executor;
    //   62: new y/um1
    //   65: dup
    //   66: aload_0
    //   67: aload_1
    //   68: iload_3
    //   69: iload_2
    //   70: invokespecial <init> : (Ly/an1;Landroid/widget/FrameLayout;ZI)V
    //   73: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    //   81: astore_1
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_1
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	81	finally
    //   32	38	81	finally
    //   43	49	81	finally
    //   52	78	81	finally
  }
  
  public final void 産() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: invokeinterface 寒 : ()V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public final int 痒() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: invokeinterface 硬 : ()I
    //   11: istore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: iload_1
    //   15: ireturn
    //   16: astore_2
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_2
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public final void 痛(eo1 parameo1) {
    View view = parameo1.不();
    parameo1.寂();
    this.ぱ.悲(view);
    if (parameo1.寒() != null) {
      parameo1.寒().setClickable(false);
      parameo1.寒().removeAllViews();
    } 
    if (parameo1.旨() != null)
      (parameo1.旨()).帰.remove(this.産); 
    this.痒 = null;
  }
  
  public final void 硬() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: putfield 臭 : Z
    //   7: aload_0
    //   8: getfield 不 : Ljava/util/concurrent/Executor;
    //   11: new y/wm1
    //   14: dup
    //   15: aload_0
    //   16: iconst_1
    //   17: invokespecial <init> : (Ly/an1;I)V
    //   20: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   25: aload_0
    //   26: invokespecial 硬 : ()V
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	29	32	finally
  }
  
  public final void 美(View paramView1, MotionEvent paramMotionEvent, View paramView2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_2
    //   7: aload_3
    //   8: invokeinterface 苦 : (Landroid/view/MotionEvent;Landroid/view/View;)V
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	16	finally
  }
  
  public final JSONObject 臭(FrameLayout paramFrameLayout, Map paramMap1, Map paramMap2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: aload_2
    //   8: aload_3
    //   9: aload_0
    //   10: invokevirtual 淋 : ()Landroid/widget/ImageView$ScaleType;
    //   13: invokeinterface 熱 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;Landroid/widget/ImageView$ScaleType;)Lorg/json/JSONObject;
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	23	finally
  }
  
  public final void 興(FrameLayout paramFrameLayout) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 辛 : Ly/en1;
    //   4: invokevirtual わ : ()Ly/類;
    //   7: astore_2
    //   8: aload_0
    //   9: getfield 嬉 : Ly/gn1;
    //   12: invokevirtual 熱 : ()Z
    //   15: ifeq -> 185
    //   18: aload_2
    //   19: ifnull -> 185
    //   22: aload_1
    //   23: ifnull -> 185
    //   26: getstatic y/t13.帰 : Ly/t13;
    //   29: getfield 起 : Ly/獅;
    //   32: astore_3
    //   33: getstatic y/xp0.麟 : Ly/sp0;
    //   36: astore_3
    //   37: getstatic y/ml0.暑 : Ly/ml0;
    //   40: getfield 熱 : Ly/vp0;
    //   43: aload_3
    //   44: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   47: checkcast java/lang/Boolean
    //   50: invokevirtual booleanValue : ()Z
    //   53: ifeq -> 185
    //   56: getstatic y/p31.痛 : Ly/t92;
    //   59: getfield 硬 : Z
    //   62: ifne -> 66
    //   65: return
    //   66: aload_2
    //   67: invokestatic ㅌ : (Ly/類;)Ljava/lang/Object;
    //   70: astore_2
    //   71: aload_2
    //   72: instanceof y/u92
    //   75: ifeq -> 185
    //   78: aload_2
    //   79: checkcast y/u92
    //   82: checkcast y/w92
    //   85: astore_2
    //   86: aload_2
    //   87: getfield 寒 : Z
    //   90: ifne -> 185
    //   93: getstatic y/w92.旨 : Ljava/util/regex/Pattern;
    //   96: ldc_w 'Ad overlay'
    //   99: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   102: invokevirtual matches : ()Z
    //   105: ifeq -> 174
    //   108: aload_2
    //   109: getfield 堅 : Ljava/util/ArrayList;
    //   112: astore_3
    //   113: aload_3
    //   114: invokevirtual iterator : ()Ljava/util/Iterator;
    //   117: astore #4
    //   119: aload #4
    //   121: invokeinterface hasNext : ()Z
    //   126: ifeq -> 154
    //   129: aload #4
    //   131: invokeinterface next : ()Ljava/lang/Object;
    //   136: checkcast y/fa2
    //   139: astore_2
    //   140: aload_2
    //   141: getfield 硬 : Ly/ta2;
    //   144: invokevirtual get : ()Ljava/lang/Object;
    //   147: aload_1
    //   148: if_acmpne -> 119
    //   151: goto -> 156
    //   154: aconst_null
    //   155: astore_2
    //   156: aload_2
    //   157: ifnonnull -> 185
    //   160: aload_3
    //   161: new y/fa2
    //   164: dup
    //   165: aload_1
    //   166: invokespecial <init> : (Landroid/widget/FrameLayout;)V
    //   169: invokevirtual add : (Ljava/lang/Object;)Z
    //   172: pop
    //   173: return
    //   174: new java/lang/IllegalArgumentException
    //   177: dup
    //   178: ldc_w 'FriendlyObstruction has detailed reason that contains characters not in [a-z][A-Z][0-9] or space'
    //   181: invokespecial <init> : (Ljava/lang/String;)V
    //   184: athrow
    //   185: return
  }
  
  public final boolean 苦() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: invokeinterface 者 : ()Z
    //   11: istore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: iload_1
    //   15: ireturn
    //   16: astore_2
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_2
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public final JSONObject 起(View paramView, Map paramMap1, Map paramMap2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ぱ : Ly/hn1;
    //   6: aload_1
    //   7: aload_2
    //   8: aload_3
    //   9: aload_0
    //   10: invokevirtual 淋 : ()Landroid/widget/ImageView$ScaleType;
    //   13: invokeinterface 恐 : (Landroid/view/View;Ljava/util/Map;Ljava/util/Map;Landroid/widget/ImageView$ScaleType;)Lorg/json/JSONObject;
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	23	finally
  }
  
  public final void 辛(eo1 parameo1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic y/xp0.ジ : Ly/sp0;
    //   5: astore_2
    //   6: getstatic y/ml0.暑 : Ly/ml0;
    //   9: getfield 熱 : Ly/vp0;
    //   12: aload_2
    //   13: invokevirtual 硬 : (Ly/tp0;)Ljava/lang/Object;
    //   16: checkcast java/lang/Boolean
    //   19: invokevirtual booleanValue : ()Z
    //   22: ifeq -> 45
    //   25: getstatic y/u03.不 : Ly/j32;
    //   28: new y/vm1
    //   31: dup
    //   32: aload_0
    //   33: aload_1
    //   34: iconst_1
    //   35: invokespecial <init> : (Ly/an1;Ly/eo1;I)V
    //   38: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   41: pop
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual 恐 : (Ly/eo1;)V
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   2	42	53	finally
    //   45	50	53	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\an1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */