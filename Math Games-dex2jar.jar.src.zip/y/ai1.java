package y;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import com.google.android.gms.internal.ads.nul;
import com.google.android.gms.internal.ads.private;
import com.google.android.gms.internal.ads.protected;
import com.google.android.gms.internal.ads.transient;
import com.google.android.gms.internal.ads.volatile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

public final class ai1 implements ii2, h82 {
  public final Object 怖;
  
  public boolean 淋;
  
  public final boolean 冷() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 淋 : Z
    //   6: istore_1
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield 淋 : Z
    //   12: aload_0
    //   13: monitorexit
    //   14: iload_1
    //   15: ireturn
    //   16: astore_2
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_2
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public final void 堅(int paramInt) {
    ik.は(this.淋 ^ true);
    ((SparseBooleanArray)this.怖).append(paramInt, true);
  }
  
  public final boolean 寒() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 淋 : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_0
    //   14: ireturn
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield 淋 : Z
    //   20: aload_0
    //   21: invokevirtual notifyAll : ()V
    //   24: aload_0
    //   25: monitorexit
    //   26: iconst_1
    //   27: ireturn
    //   28: astore_2
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_2
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	28	finally
    //   15	24	28	finally
  }
  
  public final Object 旨(Object paramObject) {
    ps ps = (ps)this.怖;
    boolean bool = this.淋;
    SQLiteDatabase sQLiteDatabase = (SQLiteDatabase)paramObject;
    if (bool) {
      ((Context)ps.淋).deleteDatabase("OfflineUpload.db");
      return null;
    } 
    ps.getClass();
    paramObject = xp0.刻;
    bool = ((Boolean)ml0.暑.熱.硬((tp0)paramObject)).booleanValue();
    int i = 0;
    int j = 0;
    if (bool) {
      u82 u82 = u82.堅("oa_upload");
      u82.硬("oa_failed_reqs", String.valueOf(年.키(sQLiteDatabase, 0)));
      u82.硬("oa_total_reqs", String.valueOf(年.키(sQLiteDatabase, 1)));
      t13.帰.辛.getClass();
      u82.硬("oa_upload_time", String.valueOf(System.currentTimeMillis()));
      u82.硬("oa_last_successful_time", String.valueOf(年.토(sQLiteDatabase)));
      if (((gu2)ps.起).淋()) {
        paramObject = "";
      } else {
        paramObject = ps.痒;
      } 
      u82.硬("oa_session_id", (String)paramObject);
      ((v82)ps.臭).硬(u82);
      ArrayList<protected> arrayList = 年.퉁(sQLiteDatabase);
      ps.ぱ(sQLiteDatabase, arrayList);
      int k = arrayList.size();
      for (i = j; i < k; i++) {
        protected protected = arrayList.get(i);
        u82 u821 = u82.堅("oa_signals");
        if (((gu2)ps.起).淋()) {
          paramObject = "";
        } else {
          paramObject = ps.痒;
        } 
        u821.硬("oa_session_id", (String)paramObject);
        volatile volatile = protected.泳();
        if (volatile.帰()) {
          paramObject = String.valueOf(volatile.歩() - 1);
        } else {
          paramObject = "-1";
        } 
        String str = (new xf2(protected.投())).toString();
        u821.硬("oa_sig_ts", String.valueOf(protected.歩()));
        u821.硬("oa_sig_status", String.valueOf(protected.큰() - 1));
        u821.硬("oa_sig_resp_lat", String.valueOf(protected.返()));
        u821.硬("oa_sig_render_lat", String.valueOf(protected.帰()));
        u821.硬("oa_sig_formats", str);
        u821.硬("oa_sig_nw_type", (String)paramObject);
        u821.硬("oa_sig_wifi", String.valueOf(protected.키() - 1));
        u821.硬("oa_sig_airplane", String.valueOf(protected.코() - 1));
        u821.硬("oa_sig_data", String.valueOf(protected.쾌() - 1));
        u821.硬("oa_sig_nw_resp", String.valueOf(protected.壊()));
        u821.硬("oa_sig_offline", String.valueOf(protected.크() - 1));
        u821.硬("oa_sig_nw_state", String.valueOf((protected.触()).淋));
        if (volatile.壊() && volatile.帰() && volatile.歩() == 2)
          u821.硬("oa_sig_cell_type", String.valueOf(volatile.返() - 1)); 
        ((v82)ps.臭).硬(u821);
      } 
    } else {
      paramObject = 年.퉁(sQLiteDatabase);
      dp0 dp0 = transient.興();
      String str = ((Context)ps.淋).getPackageName();
      dp0.冷();
      transient.歩((transient)dp0.怖, str);
      str = Build.MODEL;
      dp0.冷();
      transient.泳((transient)dp0.怖, str);
      j = 年.키(sQLiteDatabase, 0);
      dp0.冷();
      transient.壊((transient)dp0.怖, j);
      dp0.冷();
      transient.死((transient)dp0.怖, (ArrayList)paramObject);
      j = 年.키(sQLiteDatabase, 1);
      dp0.冷();
      transient.帰((transient)dp0.怖, j);
      j = 年.키(sQLiteDatabase, 3);
      dp0.冷();
      transient.寝((transient)dp0.怖, j);
      t13.帰.辛.getClass();
      long l = System.currentTimeMillis();
      dp0.冷();
      transient.返((transient)dp0.怖, l);
      l = 年.토(sQLiteDatabase);
      dp0.冷();
      transient.踊((transient)dp0.怖, l);
      transient transient = (transient)dp0.熱();
      ps.ぱ(sQLiteDatabase, (ArrayList)paramObject);
      synchronized ((co0)ps.怖) {
        bool = ((co0)paramObject).熱;
        if (bool)
          try {
            vo0 vo0 = ((co0)paramObject).堅;
            vo0.冷();
            private.噛((private)vo0.怖, transient);
          } catch (NullPointerException nullPointerException) {
            t13.帰.美.旨("AdMobClearcutLogger.modify", nullPointerException);
          }  
        paramObject = nul.興();
        j = ((x51)ps.痛).怖;
        paramObject.冷();
        nul.死((nul)((xp2)paramObject).怖, j);
        j = ((x51)ps.痛).恐;
        paramObject.冷();
        nul.壊((nul)((xp2)paramObject).怖, j);
        if (true != ((x51)ps.痛).痛)
          i = 2; 
        paramObject.冷();
        nul.帰((nul)((xp2)paramObject).怖, i);
        paramObject = paramObject.熱();
        ((co0)ps.怖).硬(new z32(17, paramObject));
        ((co0)ps.怖).堅(10004);
        sQLiteDatabase.delete("offline_signal_contents", null, null);
        年.僕(sQLiteDatabase, "failed_requests");
        年.僕(sQLiteDatabase, "total_requests");
        年.僕(sQLiteDatabase, "completed_requests");
        return null;
      } 
    } 
    sQLiteDatabase.delete("offline_signal_contents", null, null);
    年.僕(sQLiteDatabase, "failed_requests");
    年.僕(sQLiteDatabase, "total_requests");
    年.僕(sQLiteDatabase, "completed_requests");
    return null;
  }
  
  public final void 暑() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_1
    //   4: aload_0
    //   5: getfield 淋 : Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifne -> 25
    //   13: aload_0
    //   14: invokevirtual wait : ()V
    //   17: goto -> 4
    //   20: iconst_1
    //   21: istore_1
    //   22: goto -> 4
    //   25: iload_1
    //   26: ifeq -> 38
    //   29: invokestatic currentThread : ()Ljava/lang/Thread;
    //   32: invokevirtual interrupt : ()V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: aload_0
    //   39: monitorexit
    //   40: return
    //   41: astore_3
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_3
    //   45: athrow
    //   46: astore_3
    //   47: goto -> 20
    // Exception table:
    //   from	to	target	type
    //   4	9	41	finally
    //   13	17	46	java/lang/InterruptedException
    //   13	17	41	finally
    //   29	35	41	finally
  }
  
  public final x30 熱() {
    ik.は(this.淋 ^ true);
    this.淋 = true;
    return new x30((SparseBooleanArray)this.怖);
  }
  
  public final void 産(Throwable paramThrowable) {
    rr1.冷("Failed to get signals bundle");
  }
  
  public final bi2 硬(Callable paramCallable, Executor paramExecutor) {
    return new bi2((nf2)this.怖, this.淋, paramExecutor, paramCallable);
  }
  
  public final void 美(Object<String> paramObject) {
    Bundle bundle = (Bundle)paramObject;
    jw1 jw1 = (jw1)this.怖;
    if (((gu2)jw1.硬).淋())
      return; 
    paramObject = (Object<String>)bundle.get("ad_types");
    if (paramObject instanceof java.util.List) {
      paramObject = paramObject;
    } else if (paramObject instanceof String[]) {
      paramObject = Arrays.asList((String[])paramObject);
    } else {
      paramObject = Collections.emptyList();
      ArrayList arrayList1 = new ArrayList();
      Iterator<String> iterator1 = paramObject.iterator();
    } 
    ArrayList<String> arrayList = new ArrayList(paramObject.size());
    paramObject = (Object<String>)paramObject.iterator();
    while (paramObject.hasNext()) {
      String str = (String)paramObject.next();
      if (str instanceof String)
        arrayList.add(str); 
    } 
    paramObject = Collections.unmodifiableList(arrayList);
    arrayList = new ArrayList<String>();
    Iterator<String> iterator = paramObject.iterator();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ai1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */