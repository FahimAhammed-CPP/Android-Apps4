package y;

public final class ab1 implements mg1 {
  public final xa1 怖;
  
  public a62 恐;
  
  public bk1 痒;
  
  public h52 痛;
  
  public og1 臭;
  
  public final lb1 硬() {
    il0.歩(bk1.class, this.痒);
    il0.歩(og1.class, this.臭);
    return new lb1(this.怖, new 獅(8), new yw0(null), this.痒, this.臭, this.恐, this.痛);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ab1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */