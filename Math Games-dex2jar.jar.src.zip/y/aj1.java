package y;

public interface aj1 {
  void 寒(e21 parame21);
  
  void 治(w62 paramw62);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aj1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */