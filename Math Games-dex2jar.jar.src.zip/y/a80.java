package y;

import android.util.Pair;
import android.util.SparseArray;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class a80 implements w53 {
  public static final r70 寝;
  
  public static final byte[] 踊 = new byte[] { 
      -94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 
      108, 66, 124, 100, -115, -12 };
  
  public final ArrayDeque ぱ;
  
  public final tl0 不;
  
  public final tl0 冷;
  
  public final SparseArray 堅;
  
  public boolean 壊;
  
  public int 嬉;
  
  public int 寂;
  
  public final byte[] 寒;
  
  public y53 帰;
  
  public long 怖;
  
  public int 恐;
  
  public long 悲;
  
  public final ol2 旨;
  
  public final tl0 暑;
  
  public l40[] 歩;
  
  public int 死;
  
  public boolean 泳;
  
  public tl0 淋;
  
  public final tl0 熱;
  
  public int 産;
  
  public long 痒;
  
  public long 痛;
  
  public final List 硬;
  
  public final tl0 美;
  
  public long 臭;
  
  public int 興;
  
  public int 苦;
  
  public z70 起;
  
  public final ArrayDeque 辛;
  
  public l40[] 返;
  
  static {
    j60 j60 = new j60();
    j60.辛 = "application/x-emsg";
    寝 = new r70(j60);
  }
  
  public a80() {
    this.硬 = Collections.unmodifiableList(list);
    this.旨 = new ol2(2);
    this.不 = new tl0(16, 1);
    this.熱 = new tl0(d40.硬, 1);
    this.暑 = new tl0(5, 1);
    this.冷 = new tl0(1);
    byte[] arrayOfByte = new byte[16];
    this.寒 = arrayOfByte;
    this.美 = new tl0(arrayOfByte, 1);
    this.辛 = new ArrayDeque();
    this.ぱ = new ArrayDeque();
    this.堅 = new SparseArray();
    this.痒 = -9223372036854775807L;
    this.痛 = -9223372036854775807L;
    this.臭 = -9223372036854775807L;
    this.帰 = y53.悲;
    this.返 = new l40[0];
    this.歩 = new l40[0];
  }
  
  public static l43 堅(ArrayList paramArrayList) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #5
    //   8: iconst_0
    //   9: istore_1
    //   10: iload_1
    //   11: iload_2
    //   12: if_icmpge -> 300
    //   15: aload_0
    //   16: iload_1
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast y/o70
    //   23: astore #6
    //   25: aload #5
    //   27: astore #4
    //   29: aload #6
    //   31: getfield 堅 : I
    //   34: ldc 1886614376
    //   36: if_icmpne -> 289
    //   39: aload #5
    //   41: astore #4
    //   43: aload #5
    //   45: ifnonnull -> 57
    //   48: new java/util/ArrayList
    //   51: dup
    //   52: invokespecial <init> : ()V
    //   55: astore #4
    //   57: aload #6
    //   59: getfield 熱 : Ly/tl0;
    //   62: getfield 堅 : [B
    //   65: astore #6
    //   67: new y/tl0
    //   70: dup
    //   71: aload #6
    //   73: iconst_1
    //   74: invokespecial <init> : ([BI)V
    //   77: astore #5
    //   79: aload #5
    //   81: invokevirtual ぱ : ()I
    //   84: bipush #32
    //   86: if_icmpge -> 92
    //   89: goto -> 205
    //   92: aload #5
    //   94: iconst_0
    //   95: invokevirtual 冷 : (I)V
    //   98: aload #5
    //   100: invokevirtual 苦 : ()I
    //   103: aload #5
    //   105: invokevirtual 旨 : ()I
    //   108: iconst_4
    //   109: iadd
    //   110: if_icmpeq -> 116
    //   113: goto -> 205
    //   116: aload #5
    //   118: invokevirtual 苦 : ()I
    //   121: ldc 1886614376
    //   123: if_icmpeq -> 129
    //   126: goto -> 205
    //   129: aload #5
    //   131: invokevirtual 苦 : ()I
    //   134: bipush #24
    //   136: ishr
    //   137: sipush #255
    //   140: iand
    //   141: istore_3
    //   142: iload_3
    //   143: iconst_1
    //   144: if_icmple -> 153
    //   147: invokestatic 暑 : ()V
    //   150: goto -> 205
    //   153: new java/util/UUID
    //   156: dup
    //   157: aload #5
    //   159: invokevirtual 歩 : ()J
    //   162: aload #5
    //   164: invokevirtual 歩 : ()J
    //   167: invokespecial <init> : (JJ)V
    //   170: astore #7
    //   172: iload_3
    //   173: iconst_1
    //   174: if_icmpne -> 190
    //   177: aload #5
    //   179: aload #5
    //   181: invokevirtual 起 : ()I
    //   184: bipush #16
    //   186: imul
    //   187: invokevirtual 寒 : (I)V
    //   190: aload #5
    //   192: invokevirtual 起 : ()I
    //   195: istore_3
    //   196: iload_3
    //   197: aload #5
    //   199: invokevirtual 旨 : ()I
    //   202: if_icmpeq -> 211
    //   205: aconst_null
    //   206: astore #5
    //   208: goto -> 238
    //   211: iload_3
    //   212: newarray byte
    //   214: astore #8
    //   216: aload #5
    //   218: aload #8
    //   220: iconst_0
    //   221: iload_3
    //   222: invokevirtual 硬 : ([BII)V
    //   225: new y/df1
    //   228: dup
    //   229: aload #7
    //   231: aload #8
    //   233: invokespecial <init> : (Ljava/util/UUID;[B)V
    //   236: astore #5
    //   238: aload #5
    //   240: ifnonnull -> 249
    //   243: aconst_null
    //   244: astore #5
    //   246: goto -> 259
    //   249: aload #5
    //   251: getfield 怖 : Ljava/lang/Object;
    //   254: checkcast java/util/UUID
    //   257: astore #5
    //   259: aload #5
    //   261: ifnonnull -> 270
    //   264: invokestatic 暑 : ()V
    //   267: goto -> 289
    //   270: aload #4
    //   272: new y/t33
    //   275: dup
    //   276: aload #5
    //   278: ldc 'video/mp4'
    //   280: aload #6
    //   282: invokespecial <init> : (Ljava/util/UUID;Ljava/lang/String;[B)V
    //   285: invokevirtual add : (Ljava/lang/Object;)Z
    //   288: pop
    //   289: iload_1
    //   290: iconst_1
    //   291: iadd
    //   292: istore_1
    //   293: aload #4
    //   295: astore #5
    //   297: goto -> 10
    //   300: aload #5
    //   302: ifnonnull -> 307
    //   305: aconst_null
    //   306: areturn
    //   307: new y/l43
    //   310: dup
    //   311: aconst_null
    //   312: iconst_0
    //   313: aload #5
    //   315: iconst_0
    //   316: anewarray y/t33
    //   319: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   324: checkcast [Ly/t33;
    //   327: invokespecial <init> : (Ljava/lang/String;Z[Ly/t33;)V
    //   330: areturn
  }
  
  public static void 寒(tl0 paramtl0, int paramInt, g80 paramg80) {
    paramtl0.冷(paramInt + 8);
    paramInt = paramtl0.苦() & 0xFFFFFF;
    if ((paramInt & 0x1) == 0) {
      boolean bool;
      if ((paramInt & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      paramInt = paramtl0.起();
      if (paramInt == 0) {
        Arrays.fill(paramg80.苦, 0, paramg80.冷, false);
        return;
      } 
      int i = paramg80.冷;
      if (paramInt == i) {
        Arrays.fill(paramg80.苦, 0, paramInt, bool);
        paramInt = paramtl0.旨();
        tl0 tl01 = paramg80.悲;
        tl01.堅(paramInt);
        paramg80.ぱ = true;
        paramg80.寂 = true;
        paramtl0.硬(tl01.堅, 0, tl01.ぱ());
        tl01.冷(0);
        paramg80.寂 = false;
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder("Senc sample count ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" is different from fragment sample count");
      stringBuilder.append(i);
      throw ow0.硬(stringBuilder.toString(), null);
    } 
    throw ow0.堅("Overriding TrackEncryptionBox parameters is unsupported.");
  }
  
  public final void 冷(y53 paramy53) {
    this.帰 = paramy53;
    暑();
    l40[] arrayOfL40 = new l40[2];
    this.返 = arrayOfL40;
    int j = 0;
    arrayOfL40 = (l40[])yx1.不(0, (Object[])arrayOfL40);
    this.返 = arrayOfL40;
    int k = arrayOfL40.length;
    int i;
    for (i = 0; i < k; i++)
      arrayOfL40[i].暑(寝); 
    List<r70> list = this.硬;
    this.歩 = new l40[list.size()];
    for (i = 100; j < this.歩.length; i++) {
      l40 l401 = this.帰.痛(i, 3);
      l401.暑(list.get(j));
      this.歩[j] = l401;
      j++;
    } 
  }
  
  public final int 旨(x53 paramx53, f40 paramf40) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void 暑() {
    this.苦 = 0;
    this.寂 = 0;
  }
  
  public final boolean 熱(x53 paramx53) {
    return 꽃.護(paramx53, true);
  }
  
  public final void 硬(long paramLong1, long paramLong2) {
    SparseArray sparseArray = this.堅;
    int j = sparseArray.size();
    int i;
    for (i = 0; i < j; i++)
      ((z70)sparseArray.valueAt(i)).熱(); 
    this.ぱ.clear();
    this.恐 = 0;
    this.痛 = paramLong2;
    this.辛.clear();
    暑();
  }
  
  public final void 美(long paramLong) {
    a80 a801 = this;
    while (true) {
      ArrayDeque<n70> arrayDeque = a801.辛;
      if (!arrayDeque.isEmpty() && ((n70)arrayDeque.peek()).熱 == paramLong) {
        r70 r701;
        z70 z701;
        SparseArray sparseArray2;
        a80 a802;
        n70 n70 = arrayDeque.pop();
        int i = n70.堅;
        SparseArray sparseArray1 = a801.堅;
        ArrayList arrayList = n70.暑;
        if (i == 1836019574) {
          boolean bool;
          l43 l43 = 堅(arrayList);
          n70 n701 = n70.辛(1836475768);
          n701.getClass();
          sparseArray2 = new SparseArray();
          ArrayList<o70> arrayList2 = n701.暑;
          int j = arrayList2.size();
          long l = -9223372036854775807L;
          for (i = 0; i < j; i++) {
            Pair pair;
            o70 o70 = arrayList2.get(i);
            int k = o70.堅;
            tl0 tl01 = o70.熱;
            if (k == 1953654136) {
              tl01.冷(12);
              pair = Pair.create(Integer.valueOf(tl01.苦()), new w70(tl01.苦() - 1, tl01.苦(), tl01.苦(), tl01.苦()));
              sparseArray2.put(((Integer)pair.first).intValue(), pair.second);
            } else if (k == 1835362404) {
              pair.冷(8);
              if ((pair.苦() >> 24 & 0xFF) == 0) {
                l = pair.泳();
              } else {
                l = pair.寝();
              } 
            } 
          } 
          ArrayList<h80> arrayList1 = v70.硬(n70, new c63(), l, l43, false, new x70(0, a801));
          j = arrayList1.size();
          if (sparseArray1.size() == 0) {
            for (i = 0; i < j; i++) {
              w70 w70;
              h80 h80 = arrayList1.get(i);
              e80 e80 = h80.硬;
              l40 l401 = a801.帰.痛(i, e80.堅);
              int k = sparseArray2.size();
              int m = e80.硬;
              if (k == 1) {
                w70 = (w70)sparseArray2.valueAt(0);
              } else {
                w70 = (w70)sparseArray2.get(m);
                w70.getClass();
              } 
              sparseArray1.put(m, new z70(l401, h80, w70));
              a801.痒 = Math.max(a801.痒, e80.冷);
            } 
            a801.帰.寂();
            continue;
          } 
          if (sparseArray1.size() == j) {
            bool = true;
          } else {
            bool = false;
          } 
          ik.は(bool);
          for (i = 0; i < j; i++) {
            w70 w70;
            h80 h80 = arrayList1.get(i);
            e80 e80 = h80.硬;
            z70 z702 = (z70)sparseArray1.get(e80.硬);
            if (sparseArray2.size() == 1) {
              w70 = (w70)sparseArray2.valueAt(0);
            } else {
              w70 = (w70)sparseArray2.get(((e80)w70).硬);
              w70.getClass();
            } 
            z702.暑 = h80;
            z702.冷 = w70;
            r701 = h80.硬.寒;
            z702.硬.暑(r701);
            z702.熱();
          } 
          continue;
        } 
        if (i == 1836019558) {
          StringBuilder stringBuilder1;
          r70 r702;
          ArrayList<n70> arrayList2 = ((n70)r701).冷;
          i = arrayList2.size();
          int j = 0;
          SparseArray sparseArray = sparseArray1;
          sparseArray1 = sparseArray2;
          ArrayList<n70> arrayList1 = arrayList2;
          a802 = a801;
          while (j < i) {
            n70 n701 = arrayList1.get(j);
            if (n701.堅 == 1953653094) {
              o70 o70 = n701.ぱ(1952868452);
              o70.getClass();
              tl0 tl01 = o70.熱;
              tl01.冷(8);
              int k = tl01.苦() & 0xFFFFFF;
              z70 z702 = (z70)sparseArray.get(tl01.苦());
              if (z702 == null) {
                z702 = null;
              } else {
                int m;
                int n;
                int i1;
                g80 g80 = z702.堅;
                if ((k & 0x1) != 0) {
                  long l = tl01.寝();
                  g80.堅 = l;
                  g80.熱 = l;
                } 
                w70 w70 = z702.冷;
                if ((k & 0x2) != 0) {
                  m = tl01.苦() - 1;
                } else {
                  m = w70.硬;
                } 
                if ((k & 0x8) != 0) {
                  n = tl01.苦();
                } else {
                  n = w70.堅;
                } 
                if ((k & 0x10) != 0) {
                  i1 = tl01.苦();
                } else {
                  i1 = w70.熱;
                } 
                if ((k & 0x20) != 0) {
                  k = tl01.苦();
                } else {
                  k = w70.暑;
                } 
                g80.硬 = new w70(m, n, i1, k);
              } 
              if (z702 != null) {
                g80 g80 = z702.堅;
                long l = g80.淋;
                boolean bool = g80.怖;
                z702.熱();
                z702.苦 = true;
                o70 o701 = n701.ぱ(1952867444);
                if (o701 != null) {
                  tl0 tl02 = o701.熱;
                  tl02.冷(8);
                  if ((tl02.苦() >> 24 & 0xFF) == 1) {
                    l = tl02.寝();
                  } else {
                    l = tl02.泳();
                  } 
                  g80.淋 = l;
                  g80.怖 = true;
                } else {
                  g80.淋 = l;
                  g80.怖 = bool;
                } 
                ArrayList<o70> arrayList3 = n701.暑;
                int i3 = arrayList3.size();
                int m = 0;
                int n = 0;
                int i1;
                for (i1 = 0; m < i3; i1 = k) {
                  o70 o702 = arrayList3.get(m);
                  int i4 = n;
                  k = i1;
                  if (o702.堅 == 1953658222) {
                    tl0 tl02 = o702.熱;
                    tl02.冷(12);
                    int i5 = tl02.起();
                    i4 = n;
                    k = i1;
                    if (i5 > 0) {
                      k = i1 + i5;
                      i4 = n + 1;
                    } 
                  } 
                  m++;
                  n = i4;
                } 
                z702.旨 = 0;
                z702.美 = 0;
                z702.寒 = 0;
                g80.暑 = n;
                g80.冷 = i1;
                if (g80.美.length < n) {
                  g80.寒 = new long[n];
                  g80.美 = new int[n];
                } 
                if (g80.旨.length < i1) {
                  m = i1 * 125 / 100;
                  g80.旨 = new int[m];
                  g80.不 = new long[m];
                  g80.辛 = new boolean[m];
                  g80.苦 = new boolean[m];
                } 
                int i2 = 0;
                i1 = 0;
                k = 0;
                m = i;
                while (true) {
                  f80 f80;
                  tl0 tl02;
                  long l1 = 0L;
                  if (i2 < i3) {
                    o70 o704 = arrayList3.get(i2);
                    if (o704.堅 == 1953658222) {
                      int i10 = k + 1;
                      tl0 tl03 = o704.熱;
                      tl03.冷(8);
                      int i4 = tl03.苦() & 0xFFFFFF;
                      e80 e801 = z702.暑.硬;
                      w70 w701 = g80.硬;
                      i = yx1.硬;
                      g80.美[k] = tl03.起();
                      long[] arrayOfLong1 = g80.寒;
                      l = g80.堅;
                      arrayOfLong1[k] = l;
                      if ((i4 & 0x1) != 0)
                        arrayOfLong1[k] = l + tl03.苦(); 
                      if ((i4 & 0x4) != 0) {
                        i = 1;
                      } else {
                        i = 0;
                      } 
                      n = w701.暑;
                      if (i != 0)
                        n = tl03.苦(); 
                      int i6 = i4 & 0x100;
                      int i9 = i4 & 0x200;
                      int i7 = i4 & 0x400;
                      int i5 = i4 & 0x800;
                      arrayOfLong1 = e801.旨;
                      if (arrayOfLong1 != null) {
                        l = l1;
                        if (arrayOfLong1.length == 1) {
                          l = l1;
                          if (arrayOfLong1[0] == 0L)
                            l = e801.不[0]; 
                        } 
                      } else {
                        l = l1;
                      } 
                      int[] arrayOfInt = g80.旨;
                      long[] arrayOfLong2 = g80.不;
                      boolean[] arrayOfBoolean = g80.辛;
                      i4 = g80.美[k] + i1;
                      l1 = e801.熱;
                      k = i1;
                      long l2 = g80.淋;
                      i1 = i4;
                      int i8 = i;
                      for (i = k;; i++) {
                        arrayOfBoolean[i] = bool;
                        l2 += SYNTHETIC_LOCAL_VARIABLE_17;
                      } 
                      g80.淋 = l2;
                      k = i10;
                    } 
                    continue;
                  } 
                  e80 e80 = z702.暑.硬;
                  w70 w70 = g80.硬;
                  w70.getClass();
                  f80[] arrayOfF80 = e80.ぱ;
                  if (arrayOfF80 == null) {
                    w70 = null;
                  } else {
                    f80 = arrayOfF80[w70.硬];
                  } 
                  o70 o703 = n701.ぱ(1935763834);
                  if (o703 != null) {
                    f80.getClass();
                    tl0 tl03 = o703.熱;
                    tl03.冷(8);
                    if ((tl03.苦() & 0x1) == 1)
                      tl03.寒(8); 
                    i = tl03.恐();
                    i1 = tl03.起();
                    n = g80.冷;
                    if (i1 <= n) {
                      k = f80.暑;
                      if (i == 0) {
                        boolean[] arrayOfBoolean = g80.苦;
                        n = 0;
                        i = 0;
                        while (n < i1) {
                          int i4 = tl03.恐();
                          i += i4;
                          if (i4 > k) {
                            bool = true;
                          } else {
                            bool = false;
                          } 
                          arrayOfBoolean[n] = bool;
                          n++;
                        } 
                      } else {
                        if (i > k) {
                          bool = true;
                        } else {
                          bool = false;
                        } 
                        i *= i1;
                        Arrays.fill(g80.苦, 0, i1, bool);
                      } 
                      Arrays.fill(g80.苦, i1, g80.冷, false);
                      if (i > 0) {
                        g80.悲.堅(i);
                        g80.ぱ = true;
                        g80.寂 = true;
                      } 
                    } else {
                      stringBuilder1 = new StringBuilder("Saiz sample count ");
                      stringBuilder1.append(i1);
                      stringBuilder1.append(" is greater than fragment sample count");
                      stringBuilder1.append(n);
                      throw ow0.硬(stringBuilder1.toString(), null);
                    } 
                  } 
                  o703 = n701.ぱ(1935763823);
                  if (o703 != null) {
                    tl0 tl03 = o703.熱;
                    tl03.冷(8);
                    i = tl03.苦();
                    if ((i & 0x1) == 1)
                      tl03.寒(8); 
                    n = tl03.起();
                    if (n == 1) {
                      l1 = g80.熱;
                      if ((i >> 24 & 0xFF) == 0) {
                        l = tl03.泳();
                      } else {
                        l = tl03.寝();
                      } 
                      g80.熱 = l1 + l;
                    } else {
                      stringBuilder1 = new StringBuilder("Unexpected saio entry count: ");
                      stringBuilder1.append(n);
                      throw ow0.硬(stringBuilder1.toString(), null);
                    } 
                  } 
                  o70 o702 = n701.ぱ(1936027235);
                  if (o702 != null)
                    寒(o702.熱, 0, g80); 
                  if (f80 != null) {
                    String str = f80.堅;
                  } else {
                    f80 = null;
                  } 
                  o703 = null;
                  o702 = o703;
                  i = 0;
                  while (i < arrayList3.size()) {
                    tl0 tl04;
                    o70 o704 = arrayList3.get(i);
                    tl0 tl03 = o704.熱;
                    n = o704.堅;
                    if (n == 1935828848) {
                      tl03.冷(12);
                      o704 = o703;
                      o70 o705 = o702;
                      if (tl03.苦() == 1936025959) {
                        tl0 tl05 = tl03;
                        o705 = o702;
                      } 
                    } else {
                      o704 = o703;
                      o70 o705 = o702;
                      if (n == 1936158820) {
                        tl03.冷(12);
                        o704 = o703;
                        o705 = o702;
                        if (tl03.苦() == 1936025959) {
                          tl04 = tl03;
                          o704 = o703;
                        } 
                      } 
                    } 
                    i++;
                    o703 = o704;
                    tl02 = tl04;
                  } 
                  if (o703 != null && tl02 != null) {
                    o703.冷(8);
                    i = o703.苦();
                    o703.寒(4);
                    if ((i >> 24 & 0xFF) == 1)
                      o703.寒(4); 
                    if (o703.苦() == 1) {
                      tl02.冷(8);
                      i = tl02.苦() >> 24 & 0xFF;
                      tl02.寒(4);
                      if (i == 1) {
                        if (tl02.泳() == 0L)
                          throw ow0.堅("Variable length description in sgpd found (unsupported)"); 
                      } else if (i >= 2) {
                        tl02.寒(4);
                      } 
                      if (tl02.泳() == 1L) {
                        tl02.寒(1);
                        i = tl02.恐();
                        if (tl02.恐() == 1) {
                          n = tl02.恐();
                          byte[] arrayOfByte = new byte[16];
                          tl02.硬(arrayOfByte, 0, 16);
                          if (n == 0) {
                            i1 = tl02.恐();
                            byte[] arrayOfByte2 = new byte[i1];
                            tl02.硬(arrayOfByte2, 0, i1);
                            byte[] arrayOfByte1 = arrayOfByte2;
                          } else {
                            tl02 = null;
                          } 
                          g80.ぱ = true;
                          g80.嬉 = new f80(true, (String)f80, n, arrayOfByte, (i & 0xF0) >> 4, i & 0xF, (byte[])tl02);
                        } 
                      } else {
                        throw ow0.堅("Entry count in sgpd != 1 (unsupported).");
                      } 
                    } else {
                      throw ow0.堅("Entry count in sbgp != 1 (unsupported).");
                    } 
                  } 
                  n = arrayList3.size();
                  for (i = 0; i < n; i++) {
                    o70 o704 = arrayList3.get(i);
                    if (o704.堅 == 1970628964) {
                      tl0 tl03 = o704.熱;
                      tl03.冷(8);
                      byte[] arrayOfByte = this.寒;
                      tl03.硬(arrayOfByte, 0, 16);
                      if (Arrays.equals(arrayOfByte, 踊))
                        寒(tl03, 16, g80); 
                    } 
                  } 
                  a802 = this;
                  i = m;
                  break;
                  i2++;
                } 
              } 
            } 
            j++;
          } 
          l43 l43 = 堅((ArrayList)sparseArray1);
          StringBuilder stringBuilder2 = stringBuilder1;
          if (l43 != null) {
            j = stringBuilder1.size();
            i = 0;
            while (true) {
              stringBuilder2 = stringBuilder1;
              if (i < j) {
                f80 f80;
                z70 z702 = (z70)stringBuilder1.valueAt(i);
                e80 e80 = z702.暑.硬;
                w70 w70 = z702.堅.硬;
                int k = yx1.硬;
                k = w70.硬;
                f80[] arrayOfF80 = e80.ぱ;
                if (arrayOfF80 == null) {
                  arrayOfF80 = null;
                } else {
                  f80 = arrayOfF80[k];
                } 
                if (f80 != null) {
                  String str = f80.堅;
                } else {
                  f80 = null;
                } 
                l43 l431 = l43.堅((String)f80);
                r70 r703 = z702.暑.硬.寒;
                r703.getClass();
                j60 j60 = new j60(r703);
                j60.嬉 = l431;
                r702 = new r70(j60);
                z702.硬.暑(r702);
                i++;
                continue;
              } 
              break;
            } 
          } 
          a801 = a802;
          if (a802.痛 != -9223372036854775807L) {
            int k = r702.size();
            for (i = 0; i < k; i++) {
              z701 = (z70)r702.valueAt(i);
              long l = a802.痛;
              j = z701.寒;
              while (true) {
                g80 g80 = z701.堅;
                if (j < g80.冷 && g80.不[j] < l) {
                  if (g80.辛[j])
                    z701.不 = j; 
                  j++;
                  continue;
                } 
                break;
              } 
            } 
            a802.痛 = -9223372036854775807L;
            a801 = a802;
          } 
          continue;
        } 
        if (!a802.isEmpty())
          ((n70)a802.peek()).冷.add(z701); 
        continue;
      } 
      break;
    } 
    暑();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a80.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */