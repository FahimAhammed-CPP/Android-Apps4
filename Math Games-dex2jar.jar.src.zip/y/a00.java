package y;

import android.view.View;
import android.view.Window;

public class a00 extends 휘 {
  public final Window 怖;
  
  public final View 恐;
  
  public a00(Window paramWindow, View paramView) {
    super(2, null);
    this.怖 = paramWindow;
    this.恐 = paramView;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a00.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */