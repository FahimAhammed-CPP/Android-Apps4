package y;

import android.os.Bundle;
import java.util.Iterator;
import java.util.Map;

public final class aj implements ej {
  public boolean 堅;
  
  public final hp 暑;
  
  public Bundle 熱;
  
  public final fj 硬;
  
  public aj(fj paramfj, rx paramrx) {
    this.硬 = paramfj;
    this.暑 = new hp(new zi(0, paramrx));
  }
  
  public final void 堅() {
    if (!this.堅) {
      this.熱 = this.硬.硬("androidx.lifecycle.internal.SavedStateHandlesProvider");
      this.堅 = true;
      bj bj = (bj)this.暑.getValue();
    } 
  }
  
  public final Bundle 硬() {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.熱;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    Iterator<Map.Entry> iterator = ((bj)this.暑.getValue()).熱.entrySet().iterator();
    if (!iterator.hasNext()) {
      this.堅 = false;
      return bundle1;
    } 
    Map.Entry entry = iterator.next();
    String str = (String)entry.getKey();
    ((xi)entry.getValue()).getClass();
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */