package y;

public final class aq0 {
  public final String 堅;
  
  public final aq0 熱;
  
  public final long 硬;
  
  public aq0(long paramLong, String paramString, aq0 paramaq0) {
    this.硬 = paramLong;
    this.堅 = paramString;
    this.熱 = paramaq0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aq0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */