package y;

public interface as1 {
  void 堅(wv2 paramwv2);
  
  void 熱();
  
  void 硬();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\as1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */