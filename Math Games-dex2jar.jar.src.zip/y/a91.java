package y;

import android.content.DialogInterface;
import android.webkit.JsResult;

public final class a91 implements DialogInterface.OnClickListener {
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    paramInt = this.淋;
    JsResult jsResult = this.怖;
    switch (paramInt) {
      case 0:
        jsResult.cancel();
        return;
    } 
    jsResult.confirm();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a91.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */