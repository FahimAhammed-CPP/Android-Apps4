package y;

import java.util.Collections;
import java.util.Set;

public final class al1 implements dt2 {
  public final kt2 堅;
  
  public final Object 暑() {
    c61 c612;
    String str;
    c61 c611;
    in1 in1;
    Set<?> set;
    u82 u82;
    int i = this.硬;
    kt2 kt21 = this.堅;
    switch (i) {
      default:
        return new a32((a62)kt21.暑());
      case 28:
        c612 = d61.硬;
        il0.死(c612);
        return new w12(c612, 2);
      case 27:
        c612 = d61.硬;
        il0.死(c612);
        return new w12(c612, 1);
      case 26:
        return new q62((占)c612.暑());
      case 25:
        c612 = d61.硬;
        il0.死(c612);
        return new w12(c612, 0);
      case 24:
        return new o02(2, c612.暑());
      case 23:
        return new o02(1, c612.暑());
      case 22:
        return new o02(0, ((ka1)c612).硬());
      case 21:
        return new e02((v82)c612.暑());
      case 20:
        c612 = d61.硬;
        il0.死(c612);
        return new tz1(c612);
      case 19:
        return new rz1((uq1)c612.暑());
      case 18:
        return new ax1((String)c612.暑());
      case 17:
        str = (String)c612.暑();
        u82 = new u82();
        u82.硬.put("request_id", str);
        return u82;
      case 16:
        return new it1(((ka1)str).硬());
      case 15:
        return new qs1(((ka1)str).硬());
      case 14:
        return new nr1((占)str.暑());
      case 13:
        c611 = d61.硬;
        il0.死(c611);
        return new wq1(c611);
      case 12:
        return ((((ug1)c611).硬()).寂.怖 == 3) ? "rewarded_interstitial" : "rewarded";
      case 11:
        return ((((ug1)c611).硬()).寂.怖 == 3) ? fo0.返 : fo0.産;
      case 10:
        return new uk1(c611.暑(), d61.寒);
      case 9:
        return new gn1(((rf1)c611).硬());
      case 8:
        return new cn1(new sm1(((ln1)((tm1)c611).硬).硬()));
      case 7:
        in1 = (in1)((gm1)c611).硬.怖;
        il0.死(in1);
        if (in1.暑 != null) {
          set = Collections.singleton("banner");
        } else {
          set = Collections.emptySet();
        } 
        il0.死(set);
        return set;
      case 6:
        return new am1((ph1)set.暑());
      case 5:
        return new uk1(set.暑(), d61.寒);
      case 4:
        set = Collections.singleton(new uk1(set.暑(), d61.寒));
        il0.死(set);
        return set;
      case 3:
        return new ml1(((it2)set).堅());
      case 2:
        return new hl1(((it2)set).堅());
      case 1:
        return new dl1(((it2)set).堅());
      case 0:
        break;
    } 
    return new zk1(((it2)set).堅());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\al1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */