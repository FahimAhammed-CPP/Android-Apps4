package y;

public interface aq2 {}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\aq2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */