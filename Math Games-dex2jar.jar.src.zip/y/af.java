package y;

import android.graphics.PointF;

public interface af {
  PointF 硬(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */