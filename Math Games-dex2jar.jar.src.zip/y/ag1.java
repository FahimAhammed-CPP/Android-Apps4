package y;

public final class ag1 {
  static {
    lf2 lf2 = nf2.怖;
    new ag1(fg2.痒);
  }
  
  public ag1(fg2 paramfg2) {
    nf2.寂(paramfg2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\ag1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */