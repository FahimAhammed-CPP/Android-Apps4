package y;

import android.net.Uri;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class a42 {
  public final long 冷;
  
  public final Map 堅;
  
  public final int 寒;
  
  public final long 暑;
  
  public final long 熱;
  
  public final Uri 硬;
  
  static {
    zo0.硬("media3.datasource");
  }
  
  public a42(Uri paramUri, long paramLong1, long paramLong2, long paramLong3, int paramInt) {
    this(paramUri, paramLong1 - paramLong2, Collections.emptyMap(), paramLong2, paramLong3, paramInt);
  }
  
  public a42(Uri paramUri, long paramLong1, Map<?, ?> paramMap, long paramLong2, long paramLong3, int paramInt) {
    long l = paramLong1 + paramLong2;
    boolean bool2 = true;
    if (l >= 0L) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    ik.歯(bool1);
    if (paramLong2 >= 0L) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    ik.歯(bool1);
    boolean bool1 = bool2;
    paramLong1 = paramLong3;
    if (paramLong3 <= 0L)
      if (paramLong3 == -1L) {
        paramLong1 = -1L;
        bool1 = bool2;
      } else {
        bool1 = false;
        paramLong1 = paramLong3;
      }  
    ik.歯(bool1);
    this.硬 = paramUri;
    this.堅 = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap));
    this.暑 = paramLong2;
    this.熱 = l;
    this.冷 = paramLong1;
    this.寒 = paramInt;
  }
  
  public final String toString() {
    String str = String.valueOf(this.硬);
    StringBuilder stringBuilder = new StringBuilder("DataSpec[GET ");
    stringBuilder.append(str);
    stringBuilder.append(", ");
    stringBuilder.append(this.暑);
    stringBuilder.append(", ");
    stringBuilder.append(this.冷);
    stringBuilder.append(", null, ");
    stringBuilder.append(this.寒);
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a42.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */