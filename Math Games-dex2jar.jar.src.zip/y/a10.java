package y;

import android.os.Handler;
import java.util.concurrent.Executor;

public final class a10 implements Executor {
  public final void execute(Runnable paramRunnable) {
    int i = this.淋;
    Object object = this.怖;
    switch (i) {
      case 0:
        ((Handler)((茎)object).恐).post(paramRunnable);
        return;
    } 
    ((Handler)object).post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a10.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */