package y;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.os.Build;

public abstract class a30 implements DialogInterface.OnClickListener {
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    try {
      硬();
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      Build.FINGERPRINT.contains("generic");
      return;
    } finally {
      paramDialogInterface.dismiss();
    } 
  }
  
  public abstract void 硬();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\y\a30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */