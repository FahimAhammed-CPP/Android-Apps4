package kotlinx.coroutines.scheduling;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import y.e10;
import y.fq;
import y.yd;

public final class do extends Thread {
  private volatile int indexInArray;
  
  private volatile Object nextParkedWorker;
  
  public int 怖;
  
  public long 恐;
  
  public final e10 淋;
  
  public int 痒;
  
  public long 痛;
  
  public boolean 臭;
  
  public do(if paramif, int paramInt) {
    setDaemon(true);
    this.淋 = new e10();
    this.怖 = 4;
    this.workerCtl = 0;
    this.nextParkedWorker = if.壊;
    this.痒 = yd.淋.美();
    寒(paramInt);
  }
  
  public final void run() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   6: invokevirtual isTerminated : ()Z
    //   9: ifne -> 585
    //   12: aload_0
    //   13: getfield 怖 : I
    //   16: iconst_5
    //   17: if_icmpeq -> 585
    //   20: aload_0
    //   21: aload_0
    //   22: getfield 臭 : Z
    //   25: invokevirtual 硬 : (Z)Ly/fq;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 198
    //   35: aload_0
    //   36: lconst_0
    //   37: putfield 痛 : J
    //   40: aload #6
    //   42: getfield 怖 : Ly/륵;
    //   45: getfield 淋 : I
    //   48: istore_1
    //   49: aload_0
    //   50: lconst_0
    //   51: putfield 恐 : J
    //   54: aload_0
    //   55: getfield 怖 : I
    //   58: iconst_3
    //   59: if_icmpne -> 67
    //   62: aload_0
    //   63: iconst_2
    //   64: putfield 怖 : I
    //   67: aload_0
    //   68: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   71: astore #5
    //   73: iload_1
    //   74: ifne -> 80
    //   77: goto -> 121
    //   80: aload_0
    //   81: iconst_2
    //   82: invokevirtual 旨 : (I)Z
    //   85: ifeq -> 121
    //   88: aload #5
    //   90: invokevirtual 帰 : ()Z
    //   93: ifeq -> 99
    //   96: goto -> 121
    //   99: aload #5
    //   101: aload #5
    //   103: getfield controlState : J
    //   106: invokevirtual 痛 : (J)Z
    //   109: ifeq -> 115
    //   112: goto -> 121
    //   115: aload #5
    //   117: invokevirtual 帰 : ()Z
    //   120: pop
    //   121: aload #5
    //   123: invokevirtual getClass : ()Ljava/lang/Class;
    //   126: pop
    //   127: aload #6
    //   129: invokeinterface run : ()V
    //   134: goto -> 158
    //   137: astore #6
    //   139: invokestatic currentThread : ()Ljava/lang/Thread;
    //   142: astore #7
    //   144: aload #7
    //   146: invokevirtual getUncaughtExceptionHandler : ()Ljava/lang/Thread$UncaughtExceptionHandler;
    //   149: aload #7
    //   151: aload #6
    //   153: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   158: iload_1
    //   159: ifne -> 165
    //   162: goto -> 0
    //   165: getstatic kotlinx/coroutines/scheduling/if.産 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   168: aload #5
    //   170: ldc2_w -2097152
    //   173: invokevirtual addAndGet : (Ljava/lang/Object;J)J
    //   176: pop2
    //   177: aload_0
    //   178: getfield 怖 : I
    //   181: iconst_5
    //   182: if_icmpeq -> 0
    //   185: aload_0
    //   186: iconst_4
    //   187: putfield 怖 : I
    //   190: goto -> 0
    //   193: astore #5
    //   195: aload #5
    //   197: athrow
    //   198: aload_0
    //   199: iconst_0
    //   200: putfield 臭 : Z
    //   203: aload_0
    //   204: getfield 痛 : J
    //   207: lconst_0
    //   208: lcmp
    //   209: ifeq -> 246
    //   212: iload_1
    //   213: ifne -> 221
    //   216: iconst_1
    //   217: istore_1
    //   218: goto -> 2
    //   221: aload_0
    //   222: iconst_3
    //   223: invokevirtual 旨 : (I)Z
    //   226: pop
    //   227: invokestatic interrupted : ()Z
    //   230: pop
    //   231: aload_0
    //   232: getfield 痛 : J
    //   235: invokestatic parkNanos : (J)V
    //   238: aload_0
    //   239: lconst_0
    //   240: putfield 痛 : J
    //   243: goto -> 0
    //   246: aload_0
    //   247: getfield nextParkedWorker : Ljava/lang/Object;
    //   250: getstatic kotlinx/coroutines/scheduling/if.壊 : Ly/i80;
    //   253: if_acmpeq -> 261
    //   256: iconst_1
    //   257: istore_2
    //   258: goto -> 263
    //   261: iconst_0
    //   262: istore_2
    //   263: iload_2
    //   264: ifne -> 278
    //   267: aload_0
    //   268: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   271: aload_0
    //   272: invokevirtual 熱 : (Lkotlinx/coroutines/scheduling/do;)V
    //   275: goto -> 2
    //   278: aload_0
    //   279: iconst_m1
    //   280: putfield workerCtl : I
    //   283: aload_0
    //   284: getfield nextParkedWorker : Ljava/lang/Object;
    //   287: getstatic kotlinx/coroutines/scheduling/if.壊 : Ly/i80;
    //   290: if_acmpeq -> 298
    //   293: iconst_1
    //   294: istore_2
    //   295: goto -> 300
    //   298: iconst_0
    //   299: istore_2
    //   300: iload_2
    //   301: ifeq -> 2
    //   304: aload_0
    //   305: getfield workerCtl : I
    //   308: iconst_m1
    //   309: if_icmpne -> 2
    //   312: aload_0
    //   313: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   316: invokevirtual isTerminated : ()Z
    //   319: ifne -> 2
    //   322: aload_0
    //   323: getfield 怖 : I
    //   326: iconst_5
    //   327: if_icmpne -> 333
    //   330: goto -> 2
    //   333: aload_0
    //   334: iconst_3
    //   335: invokevirtual 旨 : (I)Z
    //   338: pop
    //   339: invokestatic interrupted : ()Z
    //   342: pop
    //   343: aload_0
    //   344: getfield 恐 : J
    //   347: lconst_0
    //   348: lcmp
    //   349: ifne -> 367
    //   352: aload_0
    //   353: invokestatic nanoTime : ()J
    //   356: aload_0
    //   357: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   360: getfield 恐 : J
    //   363: ladd
    //   364: putfield 恐 : J
    //   367: aload_0
    //   368: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   371: getfield 恐 : J
    //   374: invokestatic parkNanos : (J)V
    //   377: invokestatic nanoTime : ()J
    //   380: aload_0
    //   381: getfield 恐 : J
    //   384: lsub
    //   385: lconst_0
    //   386: lcmp
    //   387: iflt -> 283
    //   390: aload_0
    //   391: lconst_0
    //   392: putfield 恐 : J
    //   395: aload_0
    //   396: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   399: astore #6
    //   401: aload #6
    //   403: getfield 起 : Ly/fg;
    //   406: astore #5
    //   408: aload #5
    //   410: monitorenter
    //   411: aload #6
    //   413: invokevirtual isTerminated : ()Z
    //   416: istore #4
    //   418: iload #4
    //   420: ifeq -> 429
    //   423: aload #5
    //   425: monitorexit
    //   426: goto -> 283
    //   429: aload #6
    //   431: getfield controlState : J
    //   434: ldc2_w 2097151
    //   437: land
    //   438: l2i
    //   439: istore_2
    //   440: aload #6
    //   442: getfield 淋 : I
    //   445: istore_3
    //   446: iload_2
    //   447: iload_3
    //   448: if_icmpgt -> 457
    //   451: aload #5
    //   453: monitorexit
    //   454: goto -> 283
    //   457: getstatic kotlinx/coroutines/scheduling/do.興 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   460: aload_0
    //   461: iconst_m1
    //   462: iconst_1
    //   463: invokevirtual compareAndSet : (Ljava/lang/Object;II)Z
    //   466: istore #4
    //   468: iload #4
    //   470: ifne -> 479
    //   473: aload #5
    //   475: monitorexit
    //   476: goto -> 283
    //   479: aload_0
    //   480: getfield indexInArray : I
    //   483: istore_2
    //   484: aload_0
    //   485: iconst_0
    //   486: invokevirtual 寒 : (I)V
    //   489: aload #6
    //   491: aload_0
    //   492: iload_2
    //   493: iconst_0
    //   494: invokevirtual 寂 : (Lkotlinx/coroutines/scheduling/do;II)V
    //   497: getstatic kotlinx/coroutines/scheduling/if.産 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   500: aload #6
    //   502: invokevirtual getAndDecrement : (Ljava/lang/Object;)J
    //   505: ldc2_w 2097151
    //   508: land
    //   509: l2i
    //   510: istore_3
    //   511: iload_3
    //   512: iload_2
    //   513: if_icmpeq -> 556
    //   516: aload #6
    //   518: getfield 起 : Ly/fg;
    //   521: iload_3
    //   522: invokevirtual 堅 : (I)Ljava/lang/Object;
    //   525: checkcast kotlinx/coroutines/scheduling/do
    //   528: astore #7
    //   530: aload #6
    //   532: getfield 起 : Ly/fg;
    //   535: iload_2
    //   536: aload #7
    //   538: invokevirtual 熱 : (ILkotlinx/coroutines/scheduling/do;)V
    //   541: aload #7
    //   543: iload_2
    //   544: invokevirtual 寒 : (I)V
    //   547: aload #6
    //   549: aload #7
    //   551: iload_3
    //   552: iload_2
    //   553: invokevirtual 寂 : (Lkotlinx/coroutines/scheduling/do;II)V
    //   556: aload #6
    //   558: getfield 起 : Ly/fg;
    //   561: iload_3
    //   562: aconst_null
    //   563: invokevirtual 熱 : (ILkotlinx/coroutines/scheduling/do;)V
    //   566: aload #5
    //   568: monitorexit
    //   569: aload_0
    //   570: iconst_5
    //   571: putfield 怖 : I
    //   574: goto -> 283
    //   577: astore #6
    //   579: aload #5
    //   581: monitorexit
    //   582: aload #6
    //   584: athrow
    //   585: aload_0
    //   586: iconst_5
    //   587: invokevirtual 旨 : (I)Z
    //   590: pop
    //   591: return
    // Exception table:
    //   from	to	target	type
    //   127	134	137	finally
    //   139	158	193	finally
    //   411	418	577	finally
    //   429	446	577	finally
    //   457	468	577	finally
    //   479	511	577	finally
    //   516	556	577	finally
    //   556	566	577	finally
  }
  
  public final fq 不(boolean paramBoolean) {
    int k = (int)(this.起.controlState & 0x1FFFFFL);
    if (k < 2)
      return null; 
    int i = 暑(k);
    if if1 = this.起;
    int j = 0;
    long l;
    for (l = Long.MAX_VALUE; j < k; l = l1) {
      int m = i + 1;
      i = m;
      if (m > k)
        i = 1; 
      do do1 = (do)if1.起.堅(i);
      long l1 = l;
      if (do1 != null) {
        l1 = l;
        if (do1 != this) {
          long l2;
          if (paramBoolean) {
            l2 = this.淋.冷(do1.淋);
          } else {
            e10 e101 = this.淋;
            e10 e102 = do1.淋;
            e101.getClass();
            fq fq = e102.暑();
            if (fq != null) {
              e101.硬(fq, false);
              l2 = -1L;
            } else {
              l2 = e101.寒(e102, false);
            } 
          } 
          if (l2 == -1L) {
            e10 e101 = this.淋;
            e101.getClass();
            fq fq2 = e10.堅.getAndSet(e101, null);
            fq fq1 = fq2;
            if (fq2 == null)
              fq1 = e101.暑(); 
            return fq1;
          } 
          l1 = l;
          if (l2 > 0L)
            l1 = Math.min(l, l2); 
        } 
      } 
      j++;
    } 
    if (l == Long.MAX_VALUE)
      l = 0L; 
    this.痛 = l;
    return null;
  }
  
  public final fq 冷() {
    int i = 暑(2);
    if if1 = this.起;
    if (i == 0) {
      fq fq1 = (fq)if1.痒.暑();
      return (fq1 != null) ? fq1 : (fq)if1.臭.暑();
    } 
    fq fq = (fq)if1.臭.暑();
    return (fq != null) ? fq : (fq)if1.痒.暑();
  }
  
  public final int 堅() {
    return this.indexInArray;
  }
  
  public final void 寒(int paramInt) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.起.痛);
    stringBuilder.append("-worker-");
    if (paramInt == 0) {
      str = "TERMINATED";
    } else {
      str = String.valueOf(paramInt);
    } 
    stringBuilder.append(str);
    setName(stringBuilder.toString());
    this.indexInArray = paramInt;
  }
  
  public final boolean 旨(int paramInt) {
    int i = this.怖;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    if (bool)
      if.産.addAndGet(this.起, 4398046511104L); 
    if (i != paramInt)
      this.怖 = paramInt; 
    return bool;
  }
  
  public final int 暑(int paramInt) {
    int i = this.痒;
    i ^= i << 13;
    i ^= i >> 17;
    i ^= i << 5;
    this.痒 = i;
    int j = paramInt - 1;
    return ((j & paramInt) == 0) ? (i & j) : ((i & Integer.MAX_VALUE) % paramInt);
  }
  
  public final Object 熱() {
    return this.nextParkedWorker;
  }
  
  public final fq 硬(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 怖 : I
    //   4: istore_2
    //   5: iconst_1
    //   6: istore_3
    //   7: iload_2
    //   8: iconst_1
    //   9: if_icmpne -> 15
    //   12: goto -> 76
    //   15: aload_0
    //   16: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   19: astore #6
    //   21: aload #6
    //   23: getfield controlState : J
    //   26: lstore #4
    //   28: ldc2_w 9223367638808264704
    //   31: lload #4
    //   33: land
    //   34: bipush #42
    //   36: lshr
    //   37: l2i
    //   38: ifne -> 46
    //   41: iconst_0
    //   42: istore_2
    //   43: goto -> 67
    //   46: getstatic kotlinx/coroutines/scheduling/if.産 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   49: aload #6
    //   51: lload #4
    //   53: lload #4
    //   55: ldc2_w 4398046511104
    //   58: lsub
    //   59: invokevirtual compareAndSet : (Ljava/lang/Object;JJ)Z
    //   62: ifeq -> 21
    //   65: iconst_1
    //   66: istore_2
    //   67: iload_2
    //   68: ifeq -> 81
    //   71: aload_0
    //   72: iconst_1
    //   73: putfield 怖 : I
    //   76: iconst_1
    //   77: istore_2
    //   78: goto -> 83
    //   81: iconst_0
    //   82: istore_2
    //   83: iload_2
    //   84: ifeq -> 219
    //   87: iload_1
    //   88: ifeq -> 199
    //   91: aload_0
    //   92: aload_0
    //   93: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   96: getfield 淋 : I
    //   99: iconst_2
    //   100: imul
    //   101: invokevirtual 暑 : (I)I
    //   104: ifne -> 112
    //   107: iload_3
    //   108: istore_2
    //   109: goto -> 114
    //   112: iconst_0
    //   113: istore_2
    //   114: iload_2
    //   115: ifeq -> 132
    //   118: aload_0
    //   119: invokevirtual 冷 : ()Ly/fq;
    //   122: astore #6
    //   124: aload #6
    //   126: ifnull -> 132
    //   129: aload #6
    //   131: areturn
    //   132: aload_0
    //   133: getfield 淋 : Ly/e10;
    //   136: astore #7
    //   138: aload #7
    //   140: invokevirtual getClass : ()Ljava/lang/Class;
    //   143: pop
    //   144: getstatic y/e10.堅 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   147: aload #7
    //   149: aconst_null
    //   150: invokevirtual getAndSet : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   153: checkcast y/fq
    //   156: astore #6
    //   158: aload #6
    //   160: ifnonnull -> 173
    //   163: aload #7
    //   165: invokevirtual 暑 : ()Ly/fq;
    //   168: astore #6
    //   170: goto -> 173
    //   173: aload #6
    //   175: ifnull -> 181
    //   178: aload #6
    //   180: areturn
    //   181: iload_2
    //   182: ifne -> 213
    //   185: aload_0
    //   186: invokevirtual 冷 : ()Ly/fq;
    //   189: astore #6
    //   191: aload #6
    //   193: ifnull -> 213
    //   196: aload #6
    //   198: areturn
    //   199: aload_0
    //   200: invokevirtual 冷 : ()Ly/fq;
    //   203: astore #6
    //   205: aload #6
    //   207: ifnull -> 213
    //   210: aload #6
    //   212: areturn
    //   213: aload_0
    //   214: iconst_0
    //   215: invokevirtual 不 : (Z)Ly/fq;
    //   218: areturn
    //   219: iload_1
    //   220: ifeq -> 292
    //   223: aload_0
    //   224: getfield 淋 : Ly/e10;
    //   227: astore #8
    //   229: aload #8
    //   231: invokevirtual getClass : ()Ljava/lang/Class;
    //   234: pop
    //   235: getstatic y/e10.堅 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   238: aload #8
    //   240: aconst_null
    //   241: invokevirtual getAndSet : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   244: checkcast y/fq
    //   247: astore #6
    //   249: aload #6
    //   251: astore #7
    //   253: aload #6
    //   255: ifnonnull -> 265
    //   258: aload #8
    //   260: invokevirtual 暑 : ()Ly/fq;
    //   263: astore #7
    //   265: aload #7
    //   267: astore #6
    //   269: aload #7
    //   271: ifnonnull -> 307
    //   274: aload_0
    //   275: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   278: getfield 臭 : Ly/합;
    //   281: invokevirtual 暑 : ()Ljava/lang/Object;
    //   284: checkcast y/fq
    //   287: astore #6
    //   289: goto -> 307
    //   292: aload_0
    //   293: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   296: getfield 臭 : Ly/합;
    //   299: invokevirtual 暑 : ()Ljava/lang/Object;
    //   302: checkcast y/fq
    //   305: astore #6
    //   307: aload #6
    //   309: astore #7
    //   311: aload #6
    //   313: ifnonnull -> 323
    //   316: aload_0
    //   317: iconst_1
    //   318: invokevirtual 不 : (Z)Ly/fq;
    //   321: astore #7
    //   323: aload #7
    //   325: areturn
  }
  
  public final void 美(Object paramObject) {
    this.nextParkedWorker = paramObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\kotlinx\coroutines\scheduling\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */