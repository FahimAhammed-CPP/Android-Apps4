package kotlinx.coroutines.scheduling;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import y.bm;
import y.fg;
import y.i80;
import y.lq;
import y.꽃;
import y.륵;
import y.합;

public final class if implements Executor, Closeable {
  public static final i80 壊 = new i80("NOT_IN_STACK");
  
  public final int 怖;
  
  public final long 恐;
  
  public final int 淋;
  
  public final 합 痒;
  
  public final String 痛;
  
  public final 합 臭;
  
  public final fg 起;
  
  static {
    産 = AtomicLongFieldUpdater.newUpdater(if.class, "controlState");
    死 = AtomicIntegerFieldUpdater.newUpdater(if.class, "_isTerminated");
  }
  
  public if(int paramInt1, int paramInt2, long paramLong, String paramString) {
    boolean bool1;
    this.淋 = paramInt1;
    this.怖 = paramInt2;
    this.恐 = paramLong;
    this.痛 = paramString;
    boolean bool2 = true;
    if (paramInt1 >= 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      if (paramInt2 >= paramInt1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        if (paramInt2 <= 2097150) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool1) {
          if (paramLong > 0L) {
            paramInt2 = bool2;
          } else {
            paramInt2 = 0;
          } 
          if (paramInt2 != 0) {
            this.痒 = new 합();
            this.臭 = new 합();
            this.parkedWorkersStack = 0L;
            this.起 = new fg(paramInt1 + 1);
            this.controlState = paramInt1 << 42L;
            this._isTerminated = 0;
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder("Idle worker keep alive time ");
          stringBuilder2.append(paramLong);
          stringBuilder2.append(" must be positive");
          throw new IllegalArgumentException(stringBuilder2.toString().toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder("Max pool size ");
        stringBuilder1.append(paramInt2);
        stringBuilder1.append(" should not exceed maximal supported number of threads 2097150");
        throw new IllegalArgumentException(stringBuilder1.toString().toString());
      } 
      throw new IllegalArgumentException(bm.暑("Max pool size ", paramInt2, " should be greater than or equals to core pool size ", paramInt1).toString());
    } 
    StringBuilder stringBuilder = new StringBuilder("Core pool size ");
    stringBuilder.append(paramInt1);
    stringBuilder.append(" should be at least 1");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public final void close() {
    // Byte code:
    //   0: getstatic kotlinx/coroutines/scheduling/if.死 : Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;
    //   3: aload_0
    //   4: iconst_0
    //   5: iconst_1
    //   6: invokevirtual compareAndSet : (Ljava/lang/Object;II)Z
    //   9: ifne -> 13
    //   12: return
    //   13: invokestatic currentThread : ()Ljava/lang/Thread;
    //   16: astore #6
    //   18: aload #6
    //   20: instanceof kotlinx/coroutines/scheduling/do
    //   23: ifeq -> 36
    //   26: aload #6
    //   28: checkcast kotlinx/coroutines/scheduling/do
    //   31: astore #6
    //   33: goto -> 39
    //   36: aconst_null
    //   37: astore #6
    //   39: aload #6
    //   41: ifnull -> 63
    //   44: aload #6
    //   46: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   49: aload_0
    //   50: invokestatic 熱 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   53: ifeq -> 63
    //   56: aload #6
    //   58: astore #7
    //   60: goto -> 66
    //   63: aconst_null
    //   64: astore #7
    //   66: aload_0
    //   67: getfield 起 : Ly/fg;
    //   70: astore #6
    //   72: aload #6
    //   74: monitorenter
    //   75: aload_0
    //   76: getfield controlState : J
    //   79: lstore #4
    //   81: lload #4
    //   83: ldc2_w 2097151
    //   86: land
    //   87: l2i
    //   88: istore_3
    //   89: aload #6
    //   91: monitorexit
    //   92: iconst_1
    //   93: iload_3
    //   94: if_icmpgt -> 232
    //   97: iconst_1
    //   98: istore_1
    //   99: aload_0
    //   100: getfield 起 : Ly/fg;
    //   103: iload_1
    //   104: invokevirtual 堅 : (I)Ljava/lang/Object;
    //   107: checkcast kotlinx/coroutines/scheduling/do
    //   110: astore #6
    //   112: aload #6
    //   114: aload #7
    //   116: if_acmpeq -> 220
    //   119: aload #6
    //   121: invokevirtual isAlive : ()Z
    //   124: ifeq -> 143
    //   127: aload #6
    //   129: invokestatic unpark : (Ljava/lang/Thread;)V
    //   132: aload #6
    //   134: ldc2_w 10000
    //   137: invokevirtual join : (J)V
    //   140: goto -> 119
    //   143: aload #6
    //   145: getfield 淋 : Ly/e10;
    //   148: astore #6
    //   150: aload_0
    //   151: getfield 臭 : Ly/합;
    //   154: astore #8
    //   156: aload #6
    //   158: invokevirtual getClass : ()Ljava/lang/Class;
    //   161: pop
    //   162: getstatic y/e10.堅 : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   165: aload #6
    //   167: aconst_null
    //   168: invokevirtual getAndSet : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   171: checkcast y/fq
    //   174: astore #9
    //   176: aload #9
    //   178: ifnull -> 189
    //   181: aload #8
    //   183: aload #9
    //   185: invokevirtual 硬 : (Ljava/lang/Object;)Z
    //   188: pop
    //   189: aload #6
    //   191: invokevirtual 暑 : ()Ly/fq;
    //   194: astore #9
    //   196: aload #9
    //   198: ifnonnull -> 206
    //   201: iconst_0
    //   202: istore_2
    //   203: goto -> 216
    //   206: aload #8
    //   208: aload #9
    //   210: invokevirtual 硬 : (Ljava/lang/Object;)Z
    //   213: pop
    //   214: iconst_1
    //   215: istore_2
    //   216: iload_2
    //   217: ifne -> 189
    //   220: iload_1
    //   221: iload_3
    //   222: if_icmpeq -> 232
    //   225: iload_1
    //   226: iconst_1
    //   227: iadd
    //   228: istore_1
    //   229: goto -> 99
    //   232: aload_0
    //   233: getfield 臭 : Ly/합;
    //   236: invokevirtual 堅 : ()V
    //   239: aload_0
    //   240: getfield 痒 : Ly/합;
    //   243: invokevirtual 堅 : ()V
    //   246: aload #7
    //   248: ifnull -> 268
    //   251: aload #7
    //   253: iconst_1
    //   254: invokevirtual 硬 : (Z)Ly/fq;
    //   257: astore #8
    //   259: aload #8
    //   261: astore #6
    //   263: aload #8
    //   265: ifnonnull -> 333
    //   268: aload_0
    //   269: getfield 痒 : Ly/합;
    //   272: invokevirtual 暑 : ()Ljava/lang/Object;
    //   275: checkcast y/fq
    //   278: astore #8
    //   280: aload #8
    //   282: astore #6
    //   284: aload #8
    //   286: ifnonnull -> 333
    //   289: aload_0
    //   290: getfield 臭 : Ly/합;
    //   293: invokevirtual 暑 : ()Ljava/lang/Object;
    //   296: checkcast y/fq
    //   299: astore #8
    //   301: aload #8
    //   303: astore #6
    //   305: aload #8
    //   307: ifnonnull -> 333
    //   310: aload #7
    //   312: ifnull -> 322
    //   315: aload #7
    //   317: iconst_5
    //   318: invokevirtual 旨 : (I)Z
    //   321: pop
    //   322: aload_0
    //   323: lconst_0
    //   324: putfield parkedWorkersStack : J
    //   327: aload_0
    //   328: lconst_0
    //   329: putfield controlState : J
    //   332: return
    //   333: aload #6
    //   335: invokeinterface run : ()V
    //   340: goto -> 246
    //   343: astore #6
    //   345: invokestatic currentThread : ()Ljava/lang/Thread;
    //   348: astore #8
    //   350: aload #8
    //   352: invokevirtual getUncaughtExceptionHandler : ()Ljava/lang/Thread$UncaughtExceptionHandler;
    //   355: aload #8
    //   357: aload #6
    //   359: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   364: goto -> 246
    //   367: astore #6
    //   369: aload #6
    //   371: athrow
    //   372: astore #7
    //   374: aload #6
    //   376: monitorexit
    //   377: aload #7
    //   379: athrow
    // Exception table:
    //   from	to	target	type
    //   75	81	372	finally
    //   333	340	343	finally
    //   345	364	367	finally
  }
  
  public final void execute(Runnable paramRunnable) {
    堅(paramRunnable, lq.寒, false);
  }
  
  public final boolean isTerminated() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final String toString() {
    ArrayList<String> arrayList = new ArrayList();
    int m = this.起.硬();
    int k = 0;
    byte b3 = 0;
    byte b2 = 0;
    int j = 0;
    byte b1 = 0;
    int i = 1;
    while (i < m) {
      int n;
      byte b4;
      byte b5;
      byte b6;
      do do = (do)this.起.堅(i);
      if (do == null) {
        n = k;
        b4 = b3;
        b5 = b2;
        b6 = b1;
      } else {
        int i1 = do.淋.熱();
        n = bm.興(do.怖);
        if (n != 0) {
          if (n != 1) {
            if (n != 2) {
              if (n != 3) {
                if (n != 4) {
                  n = k;
                  b4 = b3;
                  b5 = b2;
                  b6 = b1;
                } else {
                  b6 = b1 + 1;
                  n = k;
                  b4 = b3;
                  b5 = b2;
                } 
              } else {
                int i2 = j + 1;
                n = k;
                b4 = b3;
                b5 = b2;
                j = i2;
                b6 = b1;
                if (i1 > 0) {
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append(i1);
                  stringBuilder1.append('d');
                  arrayList.add(stringBuilder1.toString());
                  n = k;
                  b4 = b3;
                  b5 = b2;
                  j = i2;
                  b6 = b1;
                } 
              } 
            } else {
              b5 = b2 + 1;
              n = k;
              b4 = b3;
              b6 = b1;
            } 
          } else {
            b4 = b3 + 1;
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(i1);
            stringBuilder1.append('b');
            arrayList.add(stringBuilder1.toString());
            n = k;
            b5 = b2;
            b6 = b1;
          } 
        } else {
          n = k + 1;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(i1);
          stringBuilder1.append('c');
          arrayList.add(stringBuilder1.toString());
          b6 = b1;
          b5 = b2;
          b4 = b3;
        } 
      } 
      i++;
      k = n;
      b3 = b4;
      b2 = b5;
      b1 = b6;
    } 
    long l = this.controlState;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.痛);
    stringBuilder.append('@');
    stringBuilder.append(꽃.死(this));
    stringBuilder.append("[Pool Size {core = ");
    stringBuilder.append(this.淋);
    stringBuilder.append(", max = ");
    stringBuilder.append(this.怖);
    stringBuilder.append("}, Worker States {CPU = ");
    stringBuilder.append(k);
    stringBuilder.append(", blocking = ");
    stringBuilder.append(b3);
    stringBuilder.append(", parked = ");
    stringBuilder.append(b2);
    stringBuilder.append(", dormant = ");
    stringBuilder.append(j);
    stringBuilder.append(", terminated = ");
    stringBuilder.append(b1);
    stringBuilder.append("}, running workers queues = ");
    stringBuilder.append(arrayList);
    stringBuilder.append(", global CPU queue size = ");
    stringBuilder.append(this.痒.熱());
    stringBuilder.append(", global blocking queue size = ");
    stringBuilder.append(this.臭.熱());
    stringBuilder.append(", Control State {created workers= ");
    stringBuilder.append((int)(0x1FFFFFL & l));
    stringBuilder.append(", blocking tasks = ");
    stringBuilder.append((int)((0x3FFFFE00000L & l) >> 21L));
    stringBuilder.append(", CPUs acquired = ");
    stringBuilder.append(this.淋 - (int)((0x7FFFFC0000000000L & l) >> 42L));
    stringBuilder.append("}]");
    return stringBuilder.toString();
  }
  
  public final void 堅(Runnable paramRunnable, 륵 param륵, boolean paramBoolean) {
    // Byte code:
    //   0: getstatic y/lq.冷 : Ly/z4;
    //   3: invokevirtual getClass : ()Ljava/lang/Class;
    //   6: pop
    //   7: invokestatic nanoTime : ()J
    //   10: lstore #7
    //   12: aload_1
    //   13: instanceof y/fq
    //   16: ifeq -> 38
    //   19: aload_1
    //   20: checkcast y/fq
    //   23: astore_1
    //   24: aload_1
    //   25: lload #7
    //   27: putfield 淋 : J
    //   30: aload_1
    //   31: aload_2
    //   32: putfield 怖 : Ly/륵;
    //   35: goto -> 50
    //   38: new y/kq
    //   41: dup
    //   42: aload_1
    //   43: lload #7
    //   45: aload_2
    //   46: invokespecial <init> : (Ljava/lang/Runnable;JLy/륵;)V
    //   49: astore_1
    //   50: invokestatic currentThread : ()Ljava/lang/Thread;
    //   53: astore_2
    //   54: aload_2
    //   55: instanceof kotlinx/coroutines/scheduling/do
    //   58: istore #6
    //   60: aconst_null
    //   61: astore #10
    //   63: iload #6
    //   65: ifeq -> 76
    //   68: aload_2
    //   69: checkcast kotlinx/coroutines/scheduling/do
    //   72: astore_2
    //   73: goto -> 78
    //   76: aconst_null
    //   77: astore_2
    //   78: aload #10
    //   80: astore #9
    //   82: aload_2
    //   83: ifnull -> 104
    //   86: aload #10
    //   88: astore #9
    //   90: aload_2
    //   91: getfield 起 : Lkotlinx/coroutines/scheduling/if;
    //   94: aload_0
    //   95: invokestatic 熱 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   98: ifeq -> 104
    //   101: aload_2
    //   102: astore #9
    //   104: iconst_1
    //   105: istore #5
    //   107: aload #9
    //   109: ifnonnull -> 115
    //   112: goto -> 147
    //   115: aload #9
    //   117: getfield 怖 : I
    //   120: istore #4
    //   122: iload #4
    //   124: iconst_5
    //   125: if_icmpne -> 131
    //   128: goto -> 147
    //   131: aload_1
    //   132: getfield 怖 : Ly/륵;
    //   135: getfield 淋 : I
    //   138: ifne -> 152
    //   141: iload #4
    //   143: iconst_2
    //   144: if_icmpne -> 152
    //   147: aload_1
    //   148: astore_2
    //   149: goto -> 169
    //   152: aload #9
    //   154: iconst_1
    //   155: putfield 臭 : Z
    //   158: aload #9
    //   160: getfield 淋 : Ly/e10;
    //   163: aload_1
    //   164: iload_3
    //   165: invokevirtual 硬 : (Ly/fq;Z)Ly/fq;
    //   168: astore_2
    //   169: aload_2
    //   170: ifnull -> 254
    //   173: aload_2
    //   174: getfield 怖 : Ly/륵;
    //   177: getfield 淋 : I
    //   180: iconst_1
    //   181: if_icmpne -> 190
    //   184: iconst_1
    //   185: istore #4
    //   187: goto -> 193
    //   190: iconst_0
    //   191: istore #4
    //   193: iload #4
    //   195: ifeq -> 211
    //   198: aload_0
    //   199: getfield 臭 : Ly/합;
    //   202: aload_2
    //   203: invokevirtual 硬 : (Ljava/lang/Object;)Z
    //   206: istore #6
    //   208: goto -> 221
    //   211: aload_0
    //   212: getfield 痒 : Ly/합;
    //   215: aload_2
    //   216: invokevirtual 硬 : (Ljava/lang/Object;)Z
    //   219: istore #6
    //   221: iload #6
    //   223: ifeq -> 229
    //   226: goto -> 254
    //   229: new java/util/concurrent/RejectedExecutionException
    //   232: dup
    //   233: new java/lang/StringBuilder
    //   236: dup
    //   237: invokespecial <init> : ()V
    //   240: aload_0
    //   241: getfield 痛 : Ljava/lang/String;
    //   244: ldc_w ' was terminated'
    //   247: invokestatic 旨 : (Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   250: invokespecial <init> : (Ljava/lang/String;)V
    //   253: athrow
    //   254: iload_3
    //   255: ifeq -> 270
    //   258: aload #9
    //   260: ifnull -> 270
    //   263: iload #5
    //   265: istore #4
    //   267: goto -> 273
    //   270: iconst_0
    //   271: istore #4
    //   273: aload_1
    //   274: getfield 怖 : Ly/륵;
    //   277: getfield 淋 : I
    //   280: ifne -> 315
    //   283: iload #4
    //   285: ifeq -> 289
    //   288: return
    //   289: aload_0
    //   290: invokevirtual 帰 : ()Z
    //   293: ifeq -> 297
    //   296: return
    //   297: aload_0
    //   298: aload_0
    //   299: getfield controlState : J
    //   302: invokevirtual 痛 : (J)Z
    //   305: ifeq -> 309
    //   308: return
    //   309: aload_0
    //   310: invokevirtual 帰 : ()Z
    //   313: pop
    //   314: return
    //   315: getstatic kotlinx/coroutines/scheduling/if.産 : Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;
    //   318: aload_0
    //   319: ldc2_w 2097152
    //   322: invokevirtual addAndGet : (Ljava/lang/Object;J)J
    //   325: lstore #7
    //   327: iload #4
    //   329: ifeq -> 333
    //   332: return
    //   333: aload_0
    //   334: invokevirtual 帰 : ()Z
    //   337: ifeq -> 341
    //   340: return
    //   341: aload_0
    //   342: lload #7
    //   344: invokevirtual 痛 : (J)Z
    //   347: ifeq -> 351
    //   350: return
    //   351: aload_0
    //   352: invokevirtual 帰 : ()Z
    //   355: pop
    //   356: return
  }
  
  public final void 寂(do paramdo, int paramInt1, int paramInt2) {
    int i;
    long l;
    do {
      l = this.parkedWorkersStack;
      int j = (int)(0x1FFFFFL & l);
      i = j;
      if (j != paramInt1)
        continue; 
      if (paramInt2 == 0) {
        for (Object object = paramdo.熱();; object = object.熱()) {
          if (object == 壊) {
            i = -1;
            break;
          } 
          if (object == null) {
            i = 0;
            break;
          } 
          object = object;
          i = object.堅();
          if (i != 0)
            break; 
        } 
      } else {
        i = paramInt2;
      } 
    } while (i < 0 || !興.compareAndSet(this, l, 2097152L + l & 0xFFFFFFFFFFE00000L | i));
  }
  
  public final boolean 帰() {
    label28: while (true) {
      long l = this.parkedWorkersStack;
      int i = (int)(0x1FFFFFL & l);
      do do = (do)this.起.堅(i);
      if (do == null) {
        Object object1 = null;
        continue;
      } 
      Object object = do.熱();
      while (true) {
        i80 i801 = 壊;
        if (object == i801) {
          i = -1;
        } else if (object == null) {
          i = 0;
        } else {
          object = object;
          i = object.堅();
          if (i == 0) {
            object = object.熱();
            continue;
          } 
        } 
        if (i >= 0) {
          if (興.compareAndSet(this, l, i | 2097152L + l & 0xFFFFFFFFFFE00000L)) {
            do.美(i801);
            object = do;
            if (object == null)
              return false; 
            if (do.興.compareAndSet(object, -1, 0)) {
              LockSupport.unpark((Thread)object);
              return true;
            } 
            continue label28;
          } 
          continue label28;
        } 
        continue label28;
      } 
      break;
    } 
  }
  
  public final void 熱(do paramdo) {
    int i;
    long l;
    if (paramdo.熱() != 壊)
      return; 
    do {
      l = this.parkedWorkersStack;
      int j = (int)(0x1FFFFFL & l);
      i = paramdo.堅();
      paramdo.美(this.起.堅(j));
    } while (!興.compareAndSet(this, l, i | 2097152L + l & 0xFFFFFFFFFFE00000L));
  }
  
  public final boolean 痛(long paramLong) {
    int j = (int)(0x1FFFFFL & paramLong) - (int)((paramLong & 0x3FFFFE00000L) >> 21L);
    int i = j;
    if (j < 0)
      i = 0; 
    j = this.淋;
    if (i < j) {
      i = 硬();
      if (i == 1 && j > 1)
        硬(); 
      if (i > 0)
        return true; 
    } 
    return false;
  }
  
  public final int 硬() {
    synchronized (this.起) {
      int i = this._isTerminated;
      if (i != 0)
        return -1; 
      long l = this.controlState;
      int k = (int)(l & 0x1FFFFFL);
      int j = k - (int)((l & 0x3FFFFE00000L) >> 21L);
      boolean bool = false;
      i = j;
      if (j < 0)
        i = 0; 
      j = this.淋;
      if (i >= j)
        return 0; 
      j = this.怖;
      if (k >= j)
        return 0; 
      k = (int)(this.controlState & 0x1FFFFFL) + 1;
      if (k > 0 && this.起.堅(k) == null) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 0) {
        do do = new do(this, k);
        this.起.熱(k, do);
        j = bool;
        if (k == (int)(0x1FFFFFL & 産.incrementAndGet(this)))
          j = 1; 
        if (j != 0) {
          do.start();
          return i + 1;
        } 
        throw new IllegalArgumentException("Failed requirement.".toString());
      } 
      throw new IllegalArgumentException("Failed requirement.".toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\kotlinx\coroutines\scheduling\if.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */