package kotlinx.coroutines.internal;

import y.범;

public final class MainDispatchException extends 범 {
  public MainDispatchException() {
    super(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\kotlinx\coroutines\internal\MainDispatchException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */