package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import y.vf;
import y.x7;
import y.竜;
import y.꽃;

public class do {
  static {
    怖 = AtomicReferenceFieldUpdater.newUpdater(do.class, Object.class, "_prev");
    恐 = AtomicReferenceFieldUpdater.newUpdater(do.class, Object.class, "_removedRef");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(new 竜(this));
    stringBuilder.append('@');
    stringBuilder.append(꽃.死(this));
    return stringBuilder.toString();
  }
  
  public final Object ぱ() {
    while (true) {
      Object object = this._next;
      if (!(object instanceof x7))
        return object; 
      ((x7)object).硬(this);
    } 
  }
  
  public final do 不() {
    label46: while (true) {
      do do2 = (do)this._prev;
      do do1 = do2;
      label45: while (true) {
        AtomicReferenceFieldUpdater<do, do> atomicReferenceFieldUpdater = null;
        while (true) {
          Object object = do1._next;
          boolean bool2 = true;
          boolean bool1 = true;
          if (object == this) {
            if (do2 == do1)
              return do1; 
            atomicReferenceFieldUpdater = 怖;
            while (!atomicReferenceFieldUpdater.compareAndSet(this, do2, do1)) {
              if (atomicReferenceFieldUpdater.get(this) != do2) {
                bool1 = false;
                break;
              } 
            } 
            if (!bool1)
              continue label46; 
            return do1;
          } 
          if (悲())
            return null; 
          if (object == null)
            return do1; 
          if (object instanceof x7) {
            ((x7)object).硬(do1);
            continue label46;
          } 
          if (object instanceof vf) {
            AtomicReferenceFieldUpdater<do, do> atomicReferenceFieldUpdater1;
            if (atomicReferenceFieldUpdater != null) {
              AtomicReferenceFieldUpdater<AtomicReferenceFieldUpdater<do, do>, Object> atomicReferenceFieldUpdater2 = 淋;
              object = ((vf)object).硬;
              while (true) {
                if (atomicReferenceFieldUpdater2.compareAndSet(atomicReferenceFieldUpdater, do1, object)) {
                  bool1 = bool2;
                  break;
                } 
                if (atomicReferenceFieldUpdater2.get(atomicReferenceFieldUpdater) != do1) {
                  bool1 = false;
                  break;
                } 
              } 
              if (!bool1)
                continue label46; 
              atomicReferenceFieldUpdater1 = atomicReferenceFieldUpdater;
              continue label45;
            } 
            do3 = (do)((do)atomicReferenceFieldUpdater1)._prev;
            continue;
          } 
          do do5 = (do)object;
          do do4 = do3;
          do do3 = do5;
        } 
        break;
      } 
      break;
    } 
  }
  
  public final do 嬉() {
    do do1 = 不();
    if (do1 == null)
      for (do1 = (do)this._prev;; do1 = (do)do1._prev) {
        if (!do1.悲())
          return do1; 
      }  
    return do1;
  }
  
  public final void 寂() {
    while (true) {
      boolean bool;
      Object object = ぱ();
      if (object instanceof vf) {
        do do2 = ((vf)object).硬;
        return;
      } 
      if (object == this) {
        do do2 = (do)object;
        return;
      } 
      do do1 = (do)object;
      vf vf2 = (vf)do1._removedRef;
      vf vf1 = vf2;
      if (vf2 == null) {
        vf1 = new vf(do1);
        恐.lazySet(do1, vf1);
      } 
      AtomicReferenceFieldUpdater<do, Object> atomicReferenceFieldUpdater = 淋;
      while (true) {
        if (atomicReferenceFieldUpdater.compareAndSet(this, object, vf1)) {
          bool = true;
          break;
        } 
        if (atomicReferenceFieldUpdater.get(this) != object) {
          bool = false;
          break;
        } 
      } 
      if (bool) {
        do1.不();
        return;
      } 
    } 
  }
  
  public boolean 悲() {
    return ぱ() instanceof vf;
  }
  
  public final do 苦() {
    Object object = ぱ();
    if (object instanceof vf) {
      null = (do)object;
    } else {
      null = null;
    } 
    if (null != null) {
      do do1 = ((vf)null).硬;
      null = do1;
      return (do1 == null) ? (do)object : null;
    } 
    return (do)object;
  }
  
  public final void 辛(do paramdo) {
    while (true) {
      boolean bool;
      do do1 = (do)paramdo._prev;
      if (ぱ() != paramdo)
        return; 
      AtomicReferenceFieldUpdater<do, do> atomicReferenceFieldUpdater = 怖;
      while (true) {
        if (atomicReferenceFieldUpdater.compareAndSet(paramdo, do1, this)) {
          bool = true;
          break;
        } 
        if (atomicReferenceFieldUpdater.get(paramdo) != do1) {
          bool = false;
          break;
        } 
      } 
      if (bool) {
        if (悲())
          paramdo.不(); 
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\kotlinx\coroutines\internal\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */