package kotlinx.coroutines.android;

import y.범;

public final class AndroidFlowException extends 범 {
  public AndroidFlowException() {
    super(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\kotlinx\coroutines\android\AndroidFlowException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */