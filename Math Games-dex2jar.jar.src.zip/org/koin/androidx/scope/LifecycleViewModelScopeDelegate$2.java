package org.koin.androidx.scope;

import y.녁;

public final class LifecycleViewModelScopeDelegate$2 implements 녁 {
  public final void 堅() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\org\koin\androidx\scope\LifecycleViewModelScopeDelegate$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */