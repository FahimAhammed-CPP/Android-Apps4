package android.support.v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

public final class CompoundButtonCompat {
  private static final CompoundButtonCompatBaseImpl IMPL = new CompoundButtonCompatBaseImpl();
  
  @Nullable
  public static Drawable getButtonDrawable(@NonNull CompoundButton paramCompoundButton) {
    return IMPL.getButtonDrawable(paramCompoundButton);
  }
  
  @Nullable
  public static ColorStateList getButtonTintList(@NonNull CompoundButton paramCompoundButton) {
    return IMPL.getButtonTintList(paramCompoundButton);
  }
  
  @Nullable
  public static PorterDuff.Mode getButtonTintMode(@NonNull CompoundButton paramCompoundButton) {
    return IMPL.getButtonTintMode(paramCompoundButton);
  }
  
  public static void setButtonTintList(@NonNull CompoundButton paramCompoundButton, @Nullable ColorStateList paramColorStateList) {
    IMPL.setButtonTintList(paramCompoundButton, paramColorStateList);
  }
  
  public static void setButtonTintMode(@NonNull CompoundButton paramCompoundButton, @Nullable PorterDuff.Mode paramMode) {
    IMPL.setButtonTintMode(paramCompoundButton, paramMode);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 23) {
      IMPL = new CompoundButtonCompatApi23Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      IMPL = new CompoundButtonCompatApi21Impl();
      return;
    } 
  }
  
  @RequiresApi(21)
  static class CompoundButtonCompatApi21Impl extends CompoundButtonCompatBaseImpl {
    public ColorStateList getButtonTintList(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonTintList();
    }
    
    public PorterDuff.Mode getButtonTintMode(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonTintMode();
    }
    
    public void setButtonTintList(CompoundButton param1CompoundButton, ColorStateList param1ColorStateList) {
      param1CompoundButton.setButtonTintList(param1ColorStateList);
    }
    
    public void setButtonTintMode(CompoundButton param1CompoundButton, PorterDuff.Mode param1Mode) {
      param1CompoundButton.setButtonTintMode(param1Mode);
    }
  }
  
  @RequiresApi(23)
  static class CompoundButtonCompatApi23Impl extends CompoundButtonCompatApi21Impl {
    public Drawable getButtonDrawable(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonDrawable();
    }
  }
  
  static class CompoundButtonCompatBaseImpl {
    private static final String TAG = "CompoundButtonCompat";
    
    private static Field sButtonDrawableField;
    
    private static boolean sButtonDrawableFieldFetched;
    
    public Drawable getButtonDrawable(CompoundButton param1CompoundButton) {
      // Byte code:
      //   0: getstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableFieldFetched : Z
      //   3: ifne -> 27
      //   6: ldc android/widget/CompoundButton
      //   8: ldc 'mButtonDrawable'
      //   10: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   13: putstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableField : Ljava/lang/reflect/Field;
      //   16: getstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableField : Ljava/lang/reflect/Field;
      //   19: iconst_1
      //   20: invokevirtual setAccessible : (Z)V
      //   23: iconst_1
      //   24: putstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableFieldFetched : Z
      //   27: getstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableField : Ljava/lang/reflect/Field;
      //   30: ifnull -> 73
      //   33: getstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableField : Ljava/lang/reflect/Field;
      //   36: aload_1
      //   37: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   40: checkcast android/graphics/drawable/Drawable
      //   43: astore_1
      //   44: aload_1
      //   45: areturn
      //   46: astore_2
      //   47: ldc 'CompoundButtonCompat'
      //   49: ldc 'Failed to retrieve mButtonDrawable field'
      //   51: aload_2
      //   52: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   55: pop
      //   56: goto -> 23
      //   59: astore_1
      //   60: ldc 'CompoundButtonCompat'
      //   62: ldc 'Failed to get button drawable via reflection'
      //   64: aload_1
      //   65: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   68: pop
      //   69: aconst_null
      //   70: putstatic android/support/v4/widget/CompoundButtonCompat$CompoundButtonCompatBaseImpl.sButtonDrawableField : Ljava/lang/reflect/Field;
      //   73: aconst_null
      //   74: areturn
      // Exception table:
      //   from	to	target	type
      //   6	23	46	java/lang/NoSuchFieldException
      //   33	44	59	java/lang/IllegalAccessException
    }
    
    public ColorStateList getButtonTintList(CompoundButton param1CompoundButton) {
      return (param1CompoundButton instanceof TintableCompoundButton) ? ((TintableCompoundButton)param1CompoundButton).getSupportButtonTintList() : null;
    }
    
    public PorterDuff.Mode getButtonTintMode(CompoundButton param1CompoundButton) {
      return (param1CompoundButton instanceof TintableCompoundButton) ? ((TintableCompoundButton)param1CompoundButton).getSupportButtonTintMode() : null;
    }
    
    public void setButtonTintList(CompoundButton param1CompoundButton, ColorStateList param1ColorStateList) {
      if (param1CompoundButton instanceof TintableCompoundButton)
        ((TintableCompoundButton)param1CompoundButton).setSupportButtonTintList(param1ColorStateList); 
    }
    
    public void setButtonTintMode(CompoundButton param1CompoundButton, PorterDuff.Mode param1Mode) {
      if (param1CompoundButton instanceof TintableCompoundButton)
        ((TintableCompoundButton)param1CompoundButton).setSupportButtonTintMode(param1Mode); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\widget\CompoundButtonCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */