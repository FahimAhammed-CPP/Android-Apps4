package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import java.io.IOException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class DrawableCompat {
  static final DrawableCompatBaseImpl IMPL = new DrawableCompatBaseImpl();
  
  public static void applyTheme(@NonNull Drawable paramDrawable, @NonNull Resources.Theme paramTheme) {
    IMPL.applyTheme(paramDrawable, paramTheme);
  }
  
  public static boolean canApplyTheme(@NonNull Drawable paramDrawable) {
    return IMPL.canApplyTheme(paramDrawable);
  }
  
  public static void clearColorFilter(@NonNull Drawable paramDrawable) {
    IMPL.clearColorFilter(paramDrawable);
  }
  
  public static int getAlpha(@NonNull Drawable paramDrawable) {
    return IMPL.getAlpha(paramDrawable);
  }
  
  public static ColorFilter getColorFilter(@NonNull Drawable paramDrawable) {
    return IMPL.getColorFilter(paramDrawable);
  }
  
  public static int getLayoutDirection(@NonNull Drawable paramDrawable) {
    return IMPL.getLayoutDirection(paramDrawable);
  }
  
  public static void inflate(@NonNull Drawable paramDrawable, @NonNull Resources paramResources, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    IMPL.inflate(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  public static boolean isAutoMirrored(@NonNull Drawable paramDrawable) {
    return IMPL.isAutoMirrored(paramDrawable);
  }
  
  public static void jumpToCurrentState(@NonNull Drawable paramDrawable) {
    IMPL.jumpToCurrentState(paramDrawable);
  }
  
  public static void setAutoMirrored(@NonNull Drawable paramDrawable, boolean paramBoolean) {
    IMPL.setAutoMirrored(paramDrawable, paramBoolean);
  }
  
  public static void setHotspot(@NonNull Drawable paramDrawable, float paramFloat1, float paramFloat2) {
    IMPL.setHotspot(paramDrawable, paramFloat1, paramFloat2);
  }
  
  public static void setHotspotBounds(@NonNull Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    IMPL.setHotspotBounds(paramDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static boolean setLayoutDirection(@NonNull Drawable paramDrawable, int paramInt) {
    return IMPL.setLayoutDirection(paramDrawable, paramInt);
  }
  
  public static void setTint(@NonNull Drawable paramDrawable, @ColorInt int paramInt) {
    IMPL.setTint(paramDrawable, paramInt);
  }
  
  public static void setTintList(@NonNull Drawable paramDrawable, @Nullable ColorStateList paramColorStateList) {
    IMPL.setTintList(paramDrawable, paramColorStateList);
  }
  
  public static void setTintMode(@NonNull Drawable paramDrawable, @Nullable PorterDuff.Mode paramMode) {
    IMPL.setTintMode(paramDrawable, paramMode);
  }
  
  public static <T extends Drawable> T unwrap(@NonNull Drawable paramDrawable) {
    Drawable drawable = paramDrawable;
    if (paramDrawable instanceof DrawableWrapper)
      drawable = ((DrawableWrapper)paramDrawable).getWrappedDrawable(); 
    return (T)drawable;
  }
  
  public static Drawable wrap(@NonNull Drawable paramDrawable) {
    return IMPL.wrap(paramDrawable);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 23) {
      IMPL = new DrawableCompatApi23Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      IMPL = new DrawableCompatApi21Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      IMPL = new DrawableCompatApi19Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 17) {
      IMPL = new DrawableCompatApi17Impl();
      return;
    } 
  }
  
  @RequiresApi(17)
  static class DrawableCompatApi17Impl extends DrawableCompatBaseImpl {
    private static final String TAG = "DrawableCompatApi17";
    
    private static Method sGetLayoutDirectionMethod;
    
    private static boolean sGetLayoutDirectionMethodFetched;
    
    private static Method sSetLayoutDirectionMethod;
    
    private static boolean sSetLayoutDirectionMethodFetched;
    
    public int getLayoutDirection(Drawable param1Drawable) {
      // Byte code:
      //   0: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethodFetched : Z
      //   3: ifne -> 31
      //   6: ldc android/graphics/drawable/Drawable
      //   8: ldc 'getLayoutDirection'
      //   10: iconst_0
      //   11: anewarray java/lang/Class
      //   14: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   17: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   20: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   23: iconst_1
      //   24: invokevirtual setAccessible : (Z)V
      //   27: iconst_1
      //   28: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethodFetched : Z
      //   31: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   34: ifnull -> 84
      //   37: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   40: aload_1
      //   41: iconst_0
      //   42: anewarray java/lang/Object
      //   45: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   48: checkcast java/lang/Integer
      //   51: invokevirtual intValue : ()I
      //   54: istore_2
      //   55: iload_2
      //   56: ireturn
      //   57: astore_3
      //   58: ldc 'DrawableCompatApi17'
      //   60: ldc 'Failed to retrieve getLayoutDirection() method'
      //   62: aload_3
      //   63: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   66: pop
      //   67: goto -> 27
      //   70: astore_1
      //   71: ldc 'DrawableCompatApi17'
      //   73: ldc 'Failed to invoke getLayoutDirection() via reflection'
      //   75: aload_1
      //   76: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   79: pop
      //   80: aconst_null
      //   81: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sGetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   84: iconst_0
      //   85: ireturn
      // Exception table:
      //   from	to	target	type
      //   6	27	57	java/lang/NoSuchMethodException
      //   37	55	70	java/lang/Exception
    }
    
    public boolean setLayoutDirection(Drawable param1Drawable, int param1Int) {
      // Byte code:
      //   0: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethodFetched : Z
      //   3: ifne -> 37
      //   6: ldc android/graphics/drawable/Drawable
      //   8: ldc 'setLayoutDirection'
      //   10: iconst_1
      //   11: anewarray java/lang/Class
      //   14: dup
      //   15: iconst_0
      //   16: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   19: aastore
      //   20: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   23: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   26: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   29: iconst_1
      //   30: invokevirtual setAccessible : (Z)V
      //   33: iconst_1
      //   34: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethodFetched : Z
      //   37: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   40: ifnull -> 91
      //   43: getstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   46: aload_1
      //   47: iconst_1
      //   48: anewarray java/lang/Object
      //   51: dup
      //   52: iconst_0
      //   53: iload_2
      //   54: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   57: aastore
      //   58: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   61: pop
      //   62: iconst_1
      //   63: ireturn
      //   64: astore_3
      //   65: ldc 'DrawableCompatApi17'
      //   67: ldc 'Failed to retrieve setLayoutDirection(int) method'
      //   69: aload_3
      //   70: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   73: pop
      //   74: goto -> 33
      //   77: astore_1
      //   78: ldc 'DrawableCompatApi17'
      //   80: ldc 'Failed to invoke setLayoutDirection(int) via reflection'
      //   82: aload_1
      //   83: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   86: pop
      //   87: aconst_null
      //   88: putstatic android/support/v4/graphics/drawable/DrawableCompat$DrawableCompatApi17Impl.sSetLayoutDirectionMethod : Ljava/lang/reflect/Method;
      //   91: iconst_0
      //   92: ireturn
      // Exception table:
      //   from	to	target	type
      //   6	33	64	java/lang/NoSuchMethodException
      //   43	62	77	java/lang/Exception
    }
  }
  
  @RequiresApi(19)
  static class DrawableCompatApi19Impl extends DrawableCompatApi17Impl {
    public int getAlpha(Drawable param1Drawable) {
      return param1Drawable.getAlpha();
    }
    
    public boolean isAutoMirrored(Drawable param1Drawable) {
      return param1Drawable.isAutoMirrored();
    }
    
    public void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean) {
      param1Drawable.setAutoMirrored(param1Boolean);
    }
    
    public Drawable wrap(Drawable param1Drawable) {
      Drawable drawable = param1Drawable;
      if (!(param1Drawable instanceof TintAwareDrawable))
        drawable = new DrawableWrapperApi19(param1Drawable); 
      return drawable;
    }
  }
  
  @RequiresApi(21)
  static class DrawableCompatApi21Impl extends DrawableCompatApi19Impl {
    public void applyTheme(Drawable param1Drawable, Resources.Theme param1Theme) {
      param1Drawable.applyTheme(param1Theme);
    }
    
    public boolean canApplyTheme(Drawable param1Drawable) {
      return param1Drawable.canApplyTheme();
    }
    
    public void clearColorFilter(Drawable param1Drawable) {
      param1Drawable.clearColorFilter();
      if (param1Drawable instanceof InsetDrawable) {
        clearColorFilter(((InsetDrawable)param1Drawable).getDrawable());
        return;
      } 
      if (param1Drawable instanceof DrawableWrapper) {
        clearColorFilter(((DrawableWrapper)param1Drawable).getWrappedDrawable());
        return;
      } 
      if (param1Drawable instanceof DrawableContainer) {
        DrawableContainer.DrawableContainerState drawableContainerState = (DrawableContainer.DrawableContainerState)((DrawableContainer)param1Drawable).getConstantState();
        if (drawableContainerState != null) {
          int i = 0;
          int j = drawableContainerState.getChildCount();
          while (true) {
            if (i < j) {
              Drawable drawable = drawableContainerState.getChild(i);
              if (drawable != null)
                clearColorFilter(drawable); 
              i++;
              continue;
            } 
            return;
          } 
        } 
      } 
    }
    
    public ColorFilter getColorFilter(Drawable param1Drawable) {
      return param1Drawable.getColorFilter();
    }
    
    public void inflate(Drawable param1Drawable, Resources param1Resources, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) throws IOException, XmlPullParserException {
      param1Drawable.inflate(param1Resources, param1XmlPullParser, param1AttributeSet, param1Theme);
    }
    
    public void setHotspot(Drawable param1Drawable, float param1Float1, float param1Float2) {
      param1Drawable.setHotspot(param1Float1, param1Float2);
    }
    
    public void setHotspotBounds(Drawable param1Drawable, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1Drawable.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setTint(Drawable param1Drawable, int param1Int) {
      param1Drawable.setTint(param1Int);
    }
    
    public void setTintList(Drawable param1Drawable, ColorStateList param1ColorStateList) {
      param1Drawable.setTintList(param1ColorStateList);
    }
    
    public void setTintMode(Drawable param1Drawable, PorterDuff.Mode param1Mode) {
      param1Drawable.setTintMode(param1Mode);
    }
    
    public Drawable wrap(Drawable param1Drawable) {
      Drawable drawable = param1Drawable;
      if (!(param1Drawable instanceof TintAwareDrawable))
        drawable = new DrawableWrapperApi21(param1Drawable); 
      return drawable;
    }
  }
  
  @RequiresApi(23)
  static class DrawableCompatApi23Impl extends DrawableCompatApi21Impl {
    public void clearColorFilter(Drawable param1Drawable) {
      param1Drawable.clearColorFilter();
    }
    
    public int getLayoutDirection(Drawable param1Drawable) {
      return param1Drawable.getLayoutDirection();
    }
    
    public boolean setLayoutDirection(Drawable param1Drawable, int param1Int) {
      return param1Drawable.setLayoutDirection(param1Int);
    }
    
    public Drawable wrap(Drawable param1Drawable) {
      return param1Drawable;
    }
  }
  
  static class DrawableCompatBaseImpl {
    public void applyTheme(Drawable param1Drawable, Resources.Theme param1Theme) {}
    
    public boolean canApplyTheme(Drawable param1Drawable) {
      return false;
    }
    
    public void clearColorFilter(Drawable param1Drawable) {
      param1Drawable.clearColorFilter();
    }
    
    public int getAlpha(Drawable param1Drawable) {
      return 0;
    }
    
    public ColorFilter getColorFilter(Drawable param1Drawable) {
      return null;
    }
    
    public int getLayoutDirection(Drawable param1Drawable) {
      return 0;
    }
    
    public void inflate(Drawable param1Drawable, Resources param1Resources, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) throws IOException, XmlPullParserException {
      param1Drawable.inflate(param1Resources, param1XmlPullParser, param1AttributeSet);
    }
    
    public boolean isAutoMirrored(Drawable param1Drawable) {
      return false;
    }
    
    public void jumpToCurrentState(Drawable param1Drawable) {
      param1Drawable.jumpToCurrentState();
    }
    
    public void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean) {}
    
    public void setHotspot(Drawable param1Drawable, float param1Float1, float param1Float2) {}
    
    public void setHotspotBounds(Drawable param1Drawable, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    public boolean setLayoutDirection(Drawable param1Drawable, int param1Int) {
      return false;
    }
    
    public void setTint(Drawable param1Drawable, int param1Int) {
      if (param1Drawable instanceof TintAwareDrawable)
        ((TintAwareDrawable)param1Drawable).setTint(param1Int); 
    }
    
    public void setTintList(Drawable param1Drawable, ColorStateList param1ColorStateList) {
      if (param1Drawable instanceof TintAwareDrawable)
        ((TintAwareDrawable)param1Drawable).setTintList(param1ColorStateList); 
    }
    
    public void setTintMode(Drawable param1Drawable, PorterDuff.Mode param1Mode) {
      if (param1Drawable instanceof TintAwareDrawable)
        ((TintAwareDrawable)param1Drawable).setTintMode(param1Mode); 
    }
    
    public Drawable wrap(Drawable param1Drawable) {
      Drawable drawable = param1Drawable;
      if (!(param1Drawable instanceof TintAwareDrawable))
        drawable = new DrawableWrapperApi14(param1Drawable); 
      return drawable;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\graphics\drawable\DrawableCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */