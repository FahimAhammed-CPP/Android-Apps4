package android.support.v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.v4.util.ArraySet;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final Interpolator ACCELERATE_CUBIC;
  
  static final Interpolator ACCELERATE_QUINT;
  
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT;
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  static Field sAnimationListenerField = null;
  
  SparseArray<Fragment> mActive;
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>> mLifecycleCallbacks = new CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  String mNoTransactionsBecause;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  FragmentManagerNonConfig mSavedNonConfig;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = (Interpolator)new AccelerateInterpolator(2.5F);
    ACCELERATE_CUBIC = (Interpolator)new AccelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    if (this.mCurState >= 1) {
      int j = Math.min(this.mCurState, 4);
      int k = this.mAdded.size();
      int i = 0;
      while (true) {
        if (i < k) {
          Fragment fragment = this.mAdded.get(i);
          if (fragment.mState < j) {
            moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
            if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
              paramArraySet.add(fragment); 
          } 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private void animateRemoveFragment(@NonNull final Fragment fragment, @NonNull AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    final View viewToAnimate = fragment.mView;
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      Animation animation = paramAnimationOrAnimator.animation;
      fragment.setAnimatingAway(fragment.mView);
      animation.setAnimationListener(new AnimationListenerWrapper(getAnimationListener(animation)) {
            public void onAnimationEnd(Animation param1Animation) {
              super.onAnimationEnd(param1Animation);
              if (fragment.getAnimatingAway() != null) {
                fragment.setAnimatingAway(null);
                FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
              } 
            }
          });
      setHWLayerAnimListenerIfAlpha(view, paramAnimationOrAnimator);
      fragment.mView.startAnimation(animation);
      return;
    } 
    Animator animator = paramAnimationOrAnimator.animator;
    fragment.setAnimator(paramAnimationOrAnimator.animator);
    final ViewGroup container = fragment.mContainer;
    if (viewGroup != null)
      viewGroup.startViewTransition(view); 
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            if (container != null)
              container.endViewTransition(viewToAnimate); 
            if (fragment.getAnimator() != null) {
              fragment.setAnimator(null);
              FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
            } 
          }
        });
    animator.setTarget(fragment.mView);
    setHWLayerAnimListenerIfAlpha(fragment.mView, paramAnimationOrAnimator);
    animator.start();
  }
  
  private void burpActive() {
    if (this.mActive != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        if (this.mActive.valueAt(i) == null)
          this.mActive.delete(this.mActive.keyAt(i)); 
      }  
  }
  
  private void checkStateLoss() {
    if (this.mStateSaved)
      throw new IllegalStateException("Can not perform this action after onSaveInstanceState"); 
    if (this.mNoTransactionsBecause != null)
      throw new IllegalStateException("Can not perform this action inside of " + this.mNoTransactionsBecause); 
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    if (this.mActive != null) {
      int j = this.mActive.size();
      for (int i = 0; i < j; i++) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
          if (fragment.mPostponedAlpha > 0.0F)
            fragment.mView.setAlpha(fragment.mPostponedAlpha); 
          if (paramBoolean3) {
            fragment.mPostponedAlpha = 0.0F;
          } else {
            fragment.mPostponedAlpha = -1.0F;
            fragment.mIsNewlyAdded = false;
          } 
        } 
      } 
    } 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    int i;
    if (this.mActive == null) {
      i = 0;
    } else {
      i = this.mActive.size();
    } 
    for (int j = 0; j < i; j++) {
      Fragment fragment = (Fragment)this.mActive.valueAt(j);
      if (fragment != null)
        if (fragment.getAnimatingAway() != null) {
          int k = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          fragment.setAnimatingAway(null);
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          moveToState(fragment, k, 0, 0, false);
        } else if (fragment.getAnimator() != null) {
          fragment.getAnimator().end();
        }  
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (this.mExecutingActions)
      throw new IllegalStateException("FragmentManager is already executing transactions"); 
    if (Looper.myLooper() != this.mHost.getHandler().getLooper())
      throw new IllegalStateException("Must be called from main thread of fragment host"); 
    if (!paramBoolean)
      checkStateLoss(); 
    if (this.mTmpRecords == null) {
      this.mTmpRecords = new ArrayList<BackStackRecord>();
      this.mTmpIsPop = new ArrayList<Boolean>();
    } 
    this.mExecutingActions = true;
    try {
      executePostponedTransaction(null, null);
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue()) {
        boolean bool;
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 == paramInt2 - 1) {
          bool = true;
        } else {
          bool = false;
        } 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((BackStackRecord)paramArrayList.get(paramInt1)).mReorderingAllowed;
    boolean bool = false;
    if (this.mTmpAddedFragments == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      this.mTmpAddedFragments.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    i = paramInt2;
    if (bool1) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      i = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } 
    if (i != paramInt1 && bool1) {
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, i, true);
      moveToState(this.mCurState, true);
    } 
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      paramInt1++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: ifnonnull -> 105
    //   7: iconst_0
    //   8: istore_3
    //   9: iconst_0
    //   10: istore #5
    //   12: iload_3
    //   13: istore #4
    //   15: iload #5
    //   17: istore_3
    //   18: iload_3
    //   19: iload #4
    //   21: if_icmpge -> 236
    //   24: aload_0
    //   25: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   28: iload_3
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast android/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener
    //   35: astore #7
    //   37: aload_1
    //   38: ifnull -> 116
    //   41: aload #7
    //   43: invokestatic access$300 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Z
    //   46: ifne -> 116
    //   49: aload_1
    //   50: aload #7
    //   52: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   55: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   58: istore #5
    //   60: iload #5
    //   62: iconst_m1
    //   63: if_icmpeq -> 116
    //   66: aload_2
    //   67: iload #5
    //   69: invokevirtual get : (I)Ljava/lang/Object;
    //   72: checkcast java/lang/Boolean
    //   75: invokevirtual booleanValue : ()Z
    //   78: ifeq -> 116
    //   81: aload #7
    //   83: invokevirtual cancelTransaction : ()V
    //   86: iload #4
    //   88: istore #6
    //   90: iload_3
    //   91: istore #5
    //   93: iload #5
    //   95: iconst_1
    //   96: iadd
    //   97: istore_3
    //   98: iload #6
    //   100: istore #4
    //   102: goto -> 18
    //   105: aload_0
    //   106: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   109: invokevirtual size : ()I
    //   112: istore_3
    //   113: goto -> 9
    //   116: aload #7
    //   118: invokevirtual isReady : ()Z
    //   121: ifne -> 159
    //   124: iload_3
    //   125: istore #5
    //   127: iload #4
    //   129: istore #6
    //   131: aload_1
    //   132: ifnull -> 93
    //   135: iload_3
    //   136: istore #5
    //   138: iload #4
    //   140: istore #6
    //   142: aload #7
    //   144: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   147: aload_1
    //   148: iconst_0
    //   149: aload_1
    //   150: invokevirtual size : ()I
    //   153: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   156: ifeq -> 93
    //   159: aload_0
    //   160: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   163: iload_3
    //   164: invokevirtual remove : (I)Ljava/lang/Object;
    //   167: pop
    //   168: iload_3
    //   169: iconst_1
    //   170: isub
    //   171: istore #5
    //   173: iload #4
    //   175: iconst_1
    //   176: isub
    //   177: istore #6
    //   179: aload_1
    //   180: ifnull -> 228
    //   183: aload #7
    //   185: invokestatic access$300 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Z
    //   188: ifne -> 228
    //   191: aload_1
    //   192: aload #7
    //   194: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   197: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   200: istore_3
    //   201: iload_3
    //   202: iconst_m1
    //   203: if_icmpeq -> 228
    //   206: aload_2
    //   207: iload_3
    //   208: invokevirtual get : (I)Ljava/lang/Object;
    //   211: checkcast java/lang/Boolean
    //   214: invokevirtual booleanValue : ()Z
    //   217: ifeq -> 228
    //   220: aload #7
    //   222: invokevirtual cancelTransaction : ()V
    //   225: goto -> 93
    //   228: aload #7
    //   230: invokevirtual completeTransaction : ()V
    //   233: goto -> 93
    //   236: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup == null || view == null)
      return null; 
    for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mContainer == viewGroup) {
        paramFragment = fragment;
        if (fragment.mView == null)
          continue; 
        return paramFragment;
      } 
      continue;
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    /* monitor enter ThisExpression{ObjectType{android/support/v4/app/FragmentManagerImpl}} */
    try {
      if (this.mPendingActions == null || this.mPendingActions.size() == 0) {
        /* monitor exit ThisExpression{ObjectType{android/support/v4/app/FragmentManagerImpl}} */
        return false;
      } 
      int j = this.mPendingActions.size();
      int i = 0;
      boolean bool = false;
      while (true) {
        if (i < j) {
          try {
            boolean bool1 = ((OpGenerator)this.mPendingActions.get(i)).generateOps(paramArrayList, paramArrayList1);
            i++;
            bool |= bool1;
            continue;
          } finally {}
        } else {
          try {
            this.mPendingActions.clear();
            this.mHost.getHandler().removeCallbacks(this.mExecCommit);
            /* monitor exit ThisExpression{ObjectType{android/support/v4/app/FragmentManagerImpl}} */
            return bool;
          } finally {}
        } 
        /* monitor exit ThisExpression{ObjectType{android/support/v4/app/FragmentManagerImpl}} */
        throw paramArrayList;
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{android/support/v4/app/FragmentManagerImpl}} */
    throw paramArrayList;
  }
  
  private static Animation.AnimationListener getAnimationListener(Animation paramAnimation) {
    try {
      if (sAnimationListenerField == null) {
        sAnimationListenerField = Animation.class.getDeclaredField("mListener");
        sAnimationListenerField.setAccessible(true);
      } 
      return (Animation.AnimationListener)sAnimationListenerField.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException);
      return null;
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException);
      return null;
    } 
  }
  
  static AnimationOrAnimator makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.getView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  static boolean modifiesAlpha(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (int i = 0; i < arrayOfPropertyValuesHolder.length; i++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[i].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (int i = 0; i < arrayList.size(); i++) {
        if (modifiesAlpha(arrayList.get(i)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean modifiesAlpha(AnimationOrAnimator paramAnimationOrAnimator) {
    List list;
    if (paramAnimationOrAnimator.animation instanceof AlphaAnimation)
      return true; 
    if (paramAnimationOrAnimator.animation instanceof AnimationSet) {
      list = ((AnimationSet)paramAnimationOrAnimator.animation).getAnimations();
      for (int i = 0; i < list.size(); i++) {
        if (list.get(i) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return modifiesAlpha(((AnimationOrAnimator)list).animator);
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    if (this.mPrimaryNav != null && paramInt1 < 0 && paramString == null) {
      FragmentManager fragmentManager = this.mPrimaryNav.peekChildFragmentManager();
      if (fragmentManager != null && fragmentManager.popBackStackImmediate())
        return true; 
    } 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
        doPendingDeferredStart();
        return bool;
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int j = paramInt2;
    int i = paramInt2 - 1;
    while (i >= paramInt1) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
      j = k;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null && !paramArrayList.isEmpty()) {
      if (paramArrayList1 == null || paramArrayList.size() != paramArrayList1.size())
        throw new IllegalStateException("Internal error with the back stack records"); 
      executePostponedTransaction(paramArrayList, paramArrayList1);
      int k = paramArrayList.size();
      int j = 0;
      int i = 0;
      while (i < k) {
        int n = i;
        int m = j;
        if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
          if (j != i)
            executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          executeOpsTogether(paramArrayList, paramArrayList1, i, m);
          i = m;
          n = m - 1;
          m = i;
        } 
        i = n + 1;
        j = m;
      } 
      if (j != k) {
        executeOpsTogether(paramArrayList, paramArrayList1, j, k);
        return;
      } 
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    switch (paramInt) {
      default:
        return 0;
      case 4097:
        return 8194;
      case 8194:
        return 4097;
      case 4099:
        break;
    } 
    return 4099;
  }
  
  private void scheduleCommit() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   8: ifnull -> 92
    //   11: aload_0
    //   12: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   15: invokevirtual isEmpty : ()Z
    //   18: ifne -> 92
    //   21: iconst_1
    //   22: istore_1
    //   23: aload_0
    //   24: getfield mPendingActions : Ljava/util/ArrayList;
    //   27: ifnull -> 97
    //   30: aload_0
    //   31: getfield mPendingActions : Ljava/util/ArrayList;
    //   34: invokevirtual size : ()I
    //   37: iconst_1
    //   38: if_icmpne -> 97
    //   41: goto -> 81
    //   44: aload_0
    //   45: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   48: invokevirtual getHandler : ()Landroid/os/Handler;
    //   51: aload_0
    //   52: getfield mExecCommit : Ljava/lang/Runnable;
    //   55: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   58: aload_0
    //   59: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   62: invokevirtual getHandler : ()Landroid/os/Handler;
    //   65: aload_0
    //   66: getfield mExecCommit : Ljava/lang/Runnable;
    //   69: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   72: pop
    //   73: aload_0
    //   74: monitorexit
    //   75: return
    //   76: astore_3
    //   77: aload_0
    //   78: monitorexit
    //   79: aload_3
    //   80: athrow
    //   81: iload_1
    //   82: ifne -> 44
    //   85: iload_2
    //   86: ifeq -> 73
    //   89: goto -> 44
    //   92: iconst_0
    //   93: istore_1
    //   94: goto -> 23
    //   97: iconst_0
    //   98: istore_2
    //   99: goto -> 81
    // Exception table:
    //   from	to	target	type
    //   4	21	76	finally
    //   23	41	76	finally
    //   44	73	76	finally
    //   73	75	76	finally
    //   77	79	76	finally
  }
  
  private static void setHWLayerAnimListenerIfAlpha(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramView != null && paramAnimationOrAnimator != null && shouldRunOnHWLayer(paramView, paramAnimationOrAnimator)) {
      if (paramAnimationOrAnimator.animator != null) {
        paramAnimationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorOnHWLayerIfNeededListener(paramView));
        return;
      } 
      Animation.AnimationListener animationListener = getAnimationListener(paramAnimationOrAnimator.animation);
      paramView.setLayerType(2, null);
      paramAnimationOrAnimator.animation.setAnimationListener(new AnimateOnHWLayerIfNeededListener(paramView, animationListener));
      return;
    } 
  }
  
  private static void setRetaining(FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramFragmentManagerNonConfig != null) {
      List<Fragment> list1 = paramFragmentManagerNonConfig.getFragments();
      if (list1 != null) {
        Iterator<Fragment> iterator = list1.iterator();
        while (iterator.hasNext())
          ((Fragment)iterator.next()).mRetaining = true; 
      } 
      List<FragmentManagerNonConfig> list = paramFragmentManagerNonConfig.getChildNonConfigs();
      if (list != null) {
        Iterator<FragmentManagerNonConfig> iterator = list.iterator();
        while (true) {
          if (iterator.hasNext()) {
            setRetaining(iterator.next());
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  static boolean shouldRunOnHWLayer(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    return (paramView != null && paramAnimationOrAnimator != null && Build.VERSION.SDK_INT >= 19 && paramView.getLayerType() == 0 && ViewCompat.hasOverlappingRendering(paramView) && modifiesAlpha(paramAnimationOrAnimator));
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    if (this.mHost != null) {
      try {
        this.mHost.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
      throw paramRuntimeException;
    } 
    try {
      dump("  ", null, (PrintWriter)exception, new String[0]);
    } catch (Exception exception1) {
      Log.e("FragmentManager", "Failed dumping state", exception1);
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    switch (paramInt) {
      default:
        return -1;
      case 4097:
        return paramBoolean ? 1 : 2;
      case 8194:
        return paramBoolean ? 3 : 4;
      case 4099:
        break;
    } 
    return paramBoolean ? 5 : 6;
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG)
      Log.v("FragmentManager", "add: " + paramFragment); 
    makeActive(paramFragment);
    if (!paramFragment.mDetached) {
      if (this.mAdded.contains(paramFragment))
        throw new IllegalStateException("Fragment already added: " + paramFragment); 
      synchronized (this.mAdded) {
        this.mAdded.add(paramFragment);
        paramFragment.mAdded = true;
        paramFragment.mRemoving = false;
        if (paramFragment.mView == null)
          paramFragment.mHiddenChanged = false; 
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        if (paramBoolean)
          moveToState(paramFragment); 
        return;
      } 
    } 
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 19
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 100
    //   19: aload_0
    //   20: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   23: ifnonnull -> 37
    //   26: aload_0
    //   27: new java/util/ArrayList
    //   30: dup
    //   31: invokespecial <init> : ()V
    //   34: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   37: aload_0
    //   38: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   41: invokevirtual size : ()I
    //   44: istore_2
    //   45: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   48: ifeq -> 87
    //   51: ldc 'FragmentManager'
    //   53: new java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: ldc_w 'Setting back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: iload_2
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: ldc_w ' to '
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: aload_1
    //   77: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   80: invokevirtual toString : ()Ljava/lang/String;
    //   83: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   86: pop
    //   87: aload_0
    //   88: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   91: aload_1
    //   92: invokevirtual add : (Ljava/lang/Object;)Z
    //   95: pop
    //   96: aload_0
    //   97: monitorexit
    //   98: iload_2
    //   99: ireturn
    //   100: aload_0
    //   101: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   104: aload_0
    //   105: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   108: invokevirtual size : ()I
    //   111: iconst_1
    //   112: isub
    //   113: invokevirtual remove : (I)Ljava/lang/Object;
    //   116: checkcast java/lang/Integer
    //   119: invokevirtual intValue : ()I
    //   122: istore_2
    //   123: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   126: ifeq -> 165
    //   129: ldc 'FragmentManager'
    //   131: new java/lang/StringBuilder
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: ldc_w 'Adding back stack index '
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: iload_2
    //   145: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   148: ldc_w ' with '
    //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: aload_1
    //   155: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   158: invokevirtual toString : ()Ljava/lang/String;
    //   161: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   164: pop
    //   165: aload_0
    //   166: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   169: iload_2
    //   170: aload_1
    //   171: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   174: pop
    //   175: aload_0
    //   176: monitorexit
    //   177: iload_2
    //   178: ireturn
    //   179: astore_1
    //   180: aload_0
    //   181: monitorexit
    //   182: aload_1
    //   183: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	179	finally
    //   19	37	179	finally
    //   37	87	179	finally
    //   87	98	179	finally
    //   100	165	179	finally
    //   165	177	179	finally
    //   180	182	179	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost != null)
      throw new IllegalStateException("Already attached"); 
    this.mHost = paramFragmentHostCallback;
    this.mContainer = paramFragmentContainer;
    this.mParent = paramFragment;
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG)
      Log.v("FragmentManager", "attach: " + paramFragment); 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        if (this.mAdded.contains(paramFragment))
          throw new IllegalStateException("Fragment already added: " + paramFragment); 
        if (DEBUG)
          Log.v("FragmentManager", "add from attach: " + paramFragment); 
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          return;
        } 
      } 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      boolean bool;
      int i = fragment.getNextTransition();
      if (!fragment.mHidden) {
        bool = true;
      } else {
        bool = false;
      } 
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, i, bool, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
        animationOrAnimator.animator.start();
      } else {
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          i = 8;
        } else {
          i = 0;
        } 
        fragment.mView.setVisibility(i);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && fragment.mHasMenu && fragment.mMenuVisible)
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG)
      Log.v("FragmentManager", "detach: " + paramFragment); 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG)
          Log.v("FragmentManager", "remove from detach: " + paramFragment); 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool = false;
    ArrayList<Fragment> arrayList = null;
    int i = 0;
    while (i < this.mAdded.size()) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool1 = bool;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool1 = bool;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          bool1 = true;
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
        } 
      } 
      i++;
      arrayList = arrayList1;
      bool = bool1;
    } 
    if (this.mCreatedMenus != null)
      for (i = 0; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(4);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    boolean bool = false;
    int i = 0;
    while (i < this.mAdded.size()) {
      Fragment fragment = this.mAdded.get(i);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      i++;
      bool = bool1;
    } 
    return bool;
  }
  
  public void dispatchReallyStop() {
    dispatchStateChange(2);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    dispatchStateChange(5);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStop() {
    this.mStateSaved = true;
    dispatchStateChange(3);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      boolean bool = false;
      int i = 0;
      while (i < this.mActive.size()) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        boolean bool1 = bool;
        if (fragment != null) {
          bool1 = bool;
          if (fragment.mLoaderManager != null)
            bool1 = bool | fragment.mLoaderManager.hasRunningLoaders(); 
        } 
        i++;
        bool = bool1;
      } 
      if (!bool) {
        this.mHavePendingDeferredStart = false;
        startPendingDeferredFragments();
      } 
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: aload_1
    //   8: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   11: ldc_w '    '
    //   14: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: invokevirtual toString : ()Ljava/lang/String;
    //   20: astore #7
    //   22: aload_0
    //   23: getfield mActive : Landroid/util/SparseArray;
    //   26: ifnull -> 153
    //   29: aload_0
    //   30: getfield mActive : Landroid/util/SparseArray;
    //   33: invokevirtual size : ()I
    //   36: istore #6
    //   38: iload #6
    //   40: ifle -> 153
    //   43: aload_3
    //   44: aload_1
    //   45: invokevirtual print : (Ljava/lang/String;)V
    //   48: aload_3
    //   49: ldc_w 'Active Fragments in '
    //   52: invokevirtual print : (Ljava/lang/String;)V
    //   55: aload_3
    //   56: aload_0
    //   57: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   60: invokestatic toHexString : (I)Ljava/lang/String;
    //   63: invokevirtual print : (Ljava/lang/String;)V
    //   66: aload_3
    //   67: ldc_w ':'
    //   70: invokevirtual println : (Ljava/lang/String;)V
    //   73: iconst_0
    //   74: istore #5
    //   76: iload #5
    //   78: iload #6
    //   80: if_icmpge -> 153
    //   83: aload_0
    //   84: getfield mActive : Landroid/util/SparseArray;
    //   87: iload #5
    //   89: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   92: checkcast android/support/v4/app/Fragment
    //   95: astore #8
    //   97: aload_3
    //   98: aload_1
    //   99: invokevirtual print : (Ljava/lang/String;)V
    //   102: aload_3
    //   103: ldc_w '  #'
    //   106: invokevirtual print : (Ljava/lang/String;)V
    //   109: aload_3
    //   110: iload #5
    //   112: invokevirtual print : (I)V
    //   115: aload_3
    //   116: ldc_w ': '
    //   119: invokevirtual print : (Ljava/lang/String;)V
    //   122: aload_3
    //   123: aload #8
    //   125: invokevirtual println : (Ljava/lang/Object;)V
    //   128: aload #8
    //   130: ifnull -> 144
    //   133: aload #8
    //   135: aload #7
    //   137: aload_2
    //   138: aload_3
    //   139: aload #4
    //   141: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   144: iload #5
    //   146: iconst_1
    //   147: iadd
    //   148: istore #5
    //   150: goto -> 76
    //   153: aload_0
    //   154: getfield mAdded : Ljava/util/ArrayList;
    //   157: invokevirtual size : ()I
    //   160: istore #6
    //   162: iload #6
    //   164: ifle -> 246
    //   167: aload_3
    //   168: aload_1
    //   169: invokevirtual print : (Ljava/lang/String;)V
    //   172: aload_3
    //   173: ldc_w 'Added Fragments:'
    //   176: invokevirtual println : (Ljava/lang/String;)V
    //   179: iconst_0
    //   180: istore #5
    //   182: iload #5
    //   184: iload #6
    //   186: if_icmpge -> 246
    //   189: aload_0
    //   190: getfield mAdded : Ljava/util/ArrayList;
    //   193: iload #5
    //   195: invokevirtual get : (I)Ljava/lang/Object;
    //   198: checkcast android/support/v4/app/Fragment
    //   201: astore #8
    //   203: aload_3
    //   204: aload_1
    //   205: invokevirtual print : (Ljava/lang/String;)V
    //   208: aload_3
    //   209: ldc_w '  #'
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: iload #5
    //   218: invokevirtual print : (I)V
    //   221: aload_3
    //   222: ldc_w ': '
    //   225: invokevirtual print : (Ljava/lang/String;)V
    //   228: aload_3
    //   229: aload #8
    //   231: invokevirtual toString : ()Ljava/lang/String;
    //   234: invokevirtual println : (Ljava/lang/String;)V
    //   237: iload #5
    //   239: iconst_1
    //   240: iadd
    //   241: istore #5
    //   243: goto -> 182
    //   246: aload_0
    //   247: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   250: ifnull -> 346
    //   253: aload_0
    //   254: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   257: invokevirtual size : ()I
    //   260: istore #6
    //   262: iload #6
    //   264: ifle -> 346
    //   267: aload_3
    //   268: aload_1
    //   269: invokevirtual print : (Ljava/lang/String;)V
    //   272: aload_3
    //   273: ldc_w 'Fragments Created Menus:'
    //   276: invokevirtual println : (Ljava/lang/String;)V
    //   279: iconst_0
    //   280: istore #5
    //   282: iload #5
    //   284: iload #6
    //   286: if_icmpge -> 346
    //   289: aload_0
    //   290: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   293: iload #5
    //   295: invokevirtual get : (I)Ljava/lang/Object;
    //   298: checkcast android/support/v4/app/Fragment
    //   301: astore #8
    //   303: aload_3
    //   304: aload_1
    //   305: invokevirtual print : (Ljava/lang/String;)V
    //   308: aload_3
    //   309: ldc_w '  #'
    //   312: invokevirtual print : (Ljava/lang/String;)V
    //   315: aload_3
    //   316: iload #5
    //   318: invokevirtual print : (I)V
    //   321: aload_3
    //   322: ldc_w ': '
    //   325: invokevirtual print : (Ljava/lang/String;)V
    //   328: aload_3
    //   329: aload #8
    //   331: invokevirtual toString : ()Ljava/lang/String;
    //   334: invokevirtual println : (Ljava/lang/String;)V
    //   337: iload #5
    //   339: iconst_1
    //   340: iadd
    //   341: istore #5
    //   343: goto -> 282
    //   346: aload_0
    //   347: getfield mBackStack : Ljava/util/ArrayList;
    //   350: ifnull -> 457
    //   353: aload_0
    //   354: getfield mBackStack : Ljava/util/ArrayList;
    //   357: invokevirtual size : ()I
    //   360: istore #6
    //   362: iload #6
    //   364: ifle -> 457
    //   367: aload_3
    //   368: aload_1
    //   369: invokevirtual print : (Ljava/lang/String;)V
    //   372: aload_3
    //   373: ldc_w 'Back Stack:'
    //   376: invokevirtual println : (Ljava/lang/String;)V
    //   379: iconst_0
    //   380: istore #5
    //   382: iload #5
    //   384: iload #6
    //   386: if_icmpge -> 457
    //   389: aload_0
    //   390: getfield mBackStack : Ljava/util/ArrayList;
    //   393: iload #5
    //   395: invokevirtual get : (I)Ljava/lang/Object;
    //   398: checkcast android/support/v4/app/BackStackRecord
    //   401: astore #8
    //   403: aload_3
    //   404: aload_1
    //   405: invokevirtual print : (Ljava/lang/String;)V
    //   408: aload_3
    //   409: ldc_w '  #'
    //   412: invokevirtual print : (Ljava/lang/String;)V
    //   415: aload_3
    //   416: iload #5
    //   418: invokevirtual print : (I)V
    //   421: aload_3
    //   422: ldc_w ': '
    //   425: invokevirtual print : (Ljava/lang/String;)V
    //   428: aload_3
    //   429: aload #8
    //   431: invokevirtual toString : ()Ljava/lang/String;
    //   434: invokevirtual println : (Ljava/lang/String;)V
    //   437: aload #8
    //   439: aload #7
    //   441: aload_2
    //   442: aload_3
    //   443: aload #4
    //   445: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   448: iload #5
    //   450: iconst_1
    //   451: iadd
    //   452: istore #5
    //   454: goto -> 382
    //   457: aload_0
    //   458: monitorenter
    //   459: aload_0
    //   460: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   463: ifnull -> 554
    //   466: aload_0
    //   467: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   470: invokevirtual size : ()I
    //   473: istore #6
    //   475: iload #6
    //   477: ifle -> 554
    //   480: aload_3
    //   481: aload_1
    //   482: invokevirtual print : (Ljava/lang/String;)V
    //   485: aload_3
    //   486: ldc_w 'Back Stack Indices:'
    //   489: invokevirtual println : (Ljava/lang/String;)V
    //   492: iconst_0
    //   493: istore #5
    //   495: iload #5
    //   497: iload #6
    //   499: if_icmpge -> 554
    //   502: aload_0
    //   503: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   506: iload #5
    //   508: invokevirtual get : (I)Ljava/lang/Object;
    //   511: checkcast android/support/v4/app/BackStackRecord
    //   514: astore_2
    //   515: aload_3
    //   516: aload_1
    //   517: invokevirtual print : (Ljava/lang/String;)V
    //   520: aload_3
    //   521: ldc_w '  #'
    //   524: invokevirtual print : (Ljava/lang/String;)V
    //   527: aload_3
    //   528: iload #5
    //   530: invokevirtual print : (I)V
    //   533: aload_3
    //   534: ldc_w ': '
    //   537: invokevirtual print : (Ljava/lang/String;)V
    //   540: aload_3
    //   541: aload_2
    //   542: invokevirtual println : (Ljava/lang/Object;)V
    //   545: iload #5
    //   547: iconst_1
    //   548: iadd
    //   549: istore #5
    //   551: goto -> 495
    //   554: aload_0
    //   555: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   558: ifnull -> 597
    //   561: aload_0
    //   562: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   565: invokevirtual size : ()I
    //   568: ifle -> 597
    //   571: aload_3
    //   572: aload_1
    //   573: invokevirtual print : (Ljava/lang/String;)V
    //   576: aload_3
    //   577: ldc_w 'mAvailBackStackIndices: '
    //   580: invokevirtual print : (Ljava/lang/String;)V
    //   583: aload_3
    //   584: aload_0
    //   585: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   588: invokevirtual toArray : ()[Ljava/lang/Object;
    //   591: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   594: invokevirtual println : (Ljava/lang/String;)V
    //   597: aload_0
    //   598: monitorexit
    //   599: aload_0
    //   600: getfield mPendingActions : Ljava/util/ArrayList;
    //   603: ifnull -> 699
    //   606: aload_0
    //   607: getfield mPendingActions : Ljava/util/ArrayList;
    //   610: invokevirtual size : ()I
    //   613: istore #6
    //   615: iload #6
    //   617: ifle -> 699
    //   620: aload_3
    //   621: aload_1
    //   622: invokevirtual print : (Ljava/lang/String;)V
    //   625: aload_3
    //   626: ldc_w 'Pending Actions:'
    //   629: invokevirtual println : (Ljava/lang/String;)V
    //   632: iconst_0
    //   633: istore #5
    //   635: iload #5
    //   637: iload #6
    //   639: if_icmpge -> 699
    //   642: aload_0
    //   643: getfield mPendingActions : Ljava/util/ArrayList;
    //   646: iload #5
    //   648: invokevirtual get : (I)Ljava/lang/Object;
    //   651: checkcast android/support/v4/app/FragmentManagerImpl$OpGenerator
    //   654: astore_2
    //   655: aload_3
    //   656: aload_1
    //   657: invokevirtual print : (Ljava/lang/String;)V
    //   660: aload_3
    //   661: ldc_w '  #'
    //   664: invokevirtual print : (Ljava/lang/String;)V
    //   667: aload_3
    //   668: iload #5
    //   670: invokevirtual print : (I)V
    //   673: aload_3
    //   674: ldc_w ': '
    //   677: invokevirtual print : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_2
    //   682: invokevirtual println : (Ljava/lang/Object;)V
    //   685: iload #5
    //   687: iconst_1
    //   688: iadd
    //   689: istore #5
    //   691: goto -> 635
    //   694: astore_1
    //   695: aload_0
    //   696: monitorexit
    //   697: aload_1
    //   698: athrow
    //   699: aload_3
    //   700: aload_1
    //   701: invokevirtual print : (Ljava/lang/String;)V
    //   704: aload_3
    //   705: ldc_w 'FragmentManager misc state:'
    //   708: invokevirtual println : (Ljava/lang/String;)V
    //   711: aload_3
    //   712: aload_1
    //   713: invokevirtual print : (Ljava/lang/String;)V
    //   716: aload_3
    //   717: ldc_w '  mHost='
    //   720: invokevirtual print : (Ljava/lang/String;)V
    //   723: aload_3
    //   724: aload_0
    //   725: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   728: invokevirtual println : (Ljava/lang/Object;)V
    //   731: aload_3
    //   732: aload_1
    //   733: invokevirtual print : (Ljava/lang/String;)V
    //   736: aload_3
    //   737: ldc_w '  mContainer='
    //   740: invokevirtual print : (Ljava/lang/String;)V
    //   743: aload_3
    //   744: aload_0
    //   745: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   748: invokevirtual println : (Ljava/lang/Object;)V
    //   751: aload_0
    //   752: getfield mParent : Landroid/support/v4/app/Fragment;
    //   755: ifnull -> 778
    //   758: aload_3
    //   759: aload_1
    //   760: invokevirtual print : (Ljava/lang/String;)V
    //   763: aload_3
    //   764: ldc_w '  mParent='
    //   767: invokevirtual print : (Ljava/lang/String;)V
    //   770: aload_3
    //   771: aload_0
    //   772: getfield mParent : Landroid/support/v4/app/Fragment;
    //   775: invokevirtual println : (Ljava/lang/Object;)V
    //   778: aload_3
    //   779: aload_1
    //   780: invokevirtual print : (Ljava/lang/String;)V
    //   783: aload_3
    //   784: ldc_w '  mCurState='
    //   787: invokevirtual print : (Ljava/lang/String;)V
    //   790: aload_3
    //   791: aload_0
    //   792: getfield mCurState : I
    //   795: invokevirtual print : (I)V
    //   798: aload_3
    //   799: ldc_w ' mStateSaved='
    //   802: invokevirtual print : (Ljava/lang/String;)V
    //   805: aload_3
    //   806: aload_0
    //   807: getfield mStateSaved : Z
    //   810: invokevirtual print : (Z)V
    //   813: aload_3
    //   814: ldc_w ' mDestroyed='
    //   817: invokevirtual print : (Ljava/lang/String;)V
    //   820: aload_3
    //   821: aload_0
    //   822: getfield mDestroyed : Z
    //   825: invokevirtual println : (Z)V
    //   828: aload_0
    //   829: getfield mNeedMenuInvalidate : Z
    //   832: ifeq -> 855
    //   835: aload_3
    //   836: aload_1
    //   837: invokevirtual print : (Ljava/lang/String;)V
    //   840: aload_3
    //   841: ldc_w '  mNeedMenuInvalidate='
    //   844: invokevirtual print : (Ljava/lang/String;)V
    //   847: aload_3
    //   848: aload_0
    //   849: getfield mNeedMenuInvalidate : Z
    //   852: invokevirtual println : (Z)V
    //   855: aload_0
    //   856: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   859: ifnull -> 882
    //   862: aload_3
    //   863: aload_1
    //   864: invokevirtual print : (Ljava/lang/String;)V
    //   867: aload_3
    //   868: ldc_w '  mNoTransactionsBecause='
    //   871: invokevirtual print : (Ljava/lang/String;)V
    //   874: aload_3
    //   875: aload_0
    //   876: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   879: invokevirtual println : (Ljava/lang/String;)V
    //   882: return
    // Exception table:
    //   from	to	target	type
    //   459	475	694	finally
    //   480	492	694	finally
    //   502	545	694	finally
    //   554	597	694	finally
    //   597	599	694	finally
    //   695	697	694	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 24
    //   17: aload_0
    //   18: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   21: ifnonnull -> 47
    //   24: iload_2
    //   25: ifeq -> 31
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: new java/lang/IllegalStateException
    //   34: dup
    //   35: ldc_w 'Activity has been destroyed'
    //   38: invokespecial <init> : (Ljava/lang/String;)V
    //   41: athrow
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    //   47: aload_0
    //   48: getfield mPendingActions : Ljava/util/ArrayList;
    //   51: ifnonnull -> 65
    //   54: aload_0
    //   55: new java/util/ArrayList
    //   58: dup
    //   59: invokespecial <init> : ()V
    //   62: putfield mPendingActions : Ljava/util/ArrayList;
    //   65: aload_0
    //   66: getfield mPendingActions : Ljava/util/ArrayList;
    //   69: aload_1
    //   70: invokevirtual add : (Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_0
    //   75: invokespecial scheduleCommit : ()V
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    // Exception table:
    //   from	to	target	type
    //   10	24	42	finally
    //   28	30	42	finally
    //   31	42	42	finally
    //   43	45	42	finally
    //   47	65	42	finally
    //   65	80	42	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.mView = paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
    } else {
      return;
    } 
    paramFragment.mInnerView = null;
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
        doPendingDeferredStart();
        return;
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    int i = this.mAdded.size() - 1;
    while (i >= 0) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment == null || fragment.mFragmentId != paramInt) {
        i--;
        continue;
      } 
      return fragment;
    } 
    if (this.mActive != null)
      for (i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          Fragment fragment1 = fragment;
          if (fragment.mFragmentId != paramInt)
            continue; 
          return fragment1;
        } 
        continue;
      }  
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null) {
      int i = this.mAdded.size() - 1;
      while (i >= 0) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment == null || !paramString.equals(fragment.mTag)) {
          i--;
          continue;
        } 
        return fragment;
      } 
    } 
    if (this.mActive != null && paramString != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          Fragment fragment1 = fragment;
          if (!paramString.equals(fragment.mTag))
            continue; 
          return fragment1;
        } 
        continue;
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    if (this.mActive != null && paramString != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          fragment = fragment.findFragmentByWho(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 62
    //   36: ldc 'FragmentManager'
    //   38: new java/lang/StringBuilder
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: iload_1
    //   52: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   55: invokevirtual toString : ()Ljava/lang/String;
    //   58: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   61: pop
    //   62: aload_0
    //   63: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   66: iload_1
    //   67: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   70: invokevirtual add : (Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_0
    //   75: monitorexit
    //   76: return
    //   77: astore_2
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_2
    //   81: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	77	finally
    //   30	62	77	finally
    //   62	76	77	finally
    //   78	80	77	finally
  }
  
  int getActiveFragmentCount() {
    return (this.mActive == null) ? 0 : this.mActive.size();
  }
  
  List<Fragment> getActiveFragments() {
    if (this.mActive == null)
      return null; 
    int j = this.mActive.size();
    ArrayList<Object> arrayList = new ArrayList(j);
    int i = 0;
    while (true) {
      ArrayList<Object> arrayList1 = arrayList;
      if (i < j) {
        arrayList.add(this.mActive.valueAt(i));
        i++;
        continue;
      } 
      return arrayList1;
    } 
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    return (this.mBackStack != null) ? this.mBackStack.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    Fragment fragment2 = (Fragment)this.mActive.get(i);
    Fragment fragment1 = fragment2;
    if (fragment2 == null) {
      throwException(new IllegalStateException("Fragment no longer exists for key " + paramString + ": index " + i));
      return fragment2;
    } 
    return fragment1;
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.EMPTY_LIST; 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  public void hideFragment(Fragment paramFragment) {
    boolean bool = true;
    if (DEBUG)
      Log.v("FragmentManager", "hide: " + paramFragment); 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      if (paramFragment.mHiddenChanged)
        bool = false; 
      paramFragment.mHiddenChanged = bool;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return this.mStateSaved;
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool2;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          if (bool)
            throw runtimeException; 
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mHost.onHasWindowAnimations())
            paramInt1 = this.mHost.onGetWindowAnimations(); 
        } 
        return (AnimationOrAnimator)((paramInt1 == 0) ? null : null);
      case 1:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.125F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(this.mHost.getContext(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(this.mHost.getContext(), 0.0F, 1.0F);
      case 6:
        break;
    } 
    return makeFadeAnimation(this.mHost.getContext(), 1.0F, 0.0F);
  }
  
  void makeActive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      int i = this.mNextFragmentIndex;
      this.mNextFragmentIndex = i + 1;
      paramFragment.setIndex(i, this.mParent);
      if (this.mActive == null)
        this.mActive = new SparseArray(); 
      this.mActive.put(paramFragment.mIndex, paramFragment);
      if (DEBUG) {
        Log.v("FragmentManager", "Allocated fragment index " + paramFragment);
        return;
      } 
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (DEBUG)
      Log.v("FragmentManager", "Freeing fragment index " + paramFragment); 
    this.mActive.put(paramFragment.mIndex, null);
    this.mHost.inactivateFragment(paramFragment.mWho);
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment != null) {
      int j = this.mCurState;
      int i = j;
      if (paramFragment.mRemoving)
        if (paramFragment.isInBackStack()) {
          i = Math.min(j, 1);
        } else {
          i = Math.min(j, 0);
        }  
      moveToState(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
      if (paramFragment.mView != null) {
        Fragment fragment = findFragmentUnder(paramFragment);
        if (fragment != null) {
          View view = fragment.mView;
          ViewGroup viewGroup = paramFragment.mContainer;
          i = viewGroup.indexOfChild(view);
          j = viewGroup.indexOfChild(paramFragment.mView);
          if (j < i) {
            viewGroup.removeViewAt(j);
            viewGroup.addView(paramFragment.mView, i);
          } 
        } 
        if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
          if (paramFragment.mPostponedAlpha > 0.0F)
            paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
          paramFragment.mPostponedAlpha = 0.0F;
          paramFragment.mIsNewlyAdded = false;
          AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
          if (animationOrAnimator != null) {
            setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
            if (animationOrAnimator.animation != null) {
              paramFragment.mView.startAnimation(animationOrAnimator.animation);
            } else {
              animationOrAnimator.animator.setTarget(paramFragment.mView);
              animationOrAnimator.animator.start();
            } 
          } 
        } 
      } 
      if (paramFragment.mHiddenChanged) {
        completeShowHideFragment(paramFragment);
        return;
      } 
    } 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   4: ifnonnull -> 22
    //   7: iload_1
    //   8: ifeq -> 22
    //   11: new java/lang/IllegalStateException
    //   14: dup
    //   15: ldc_w 'No activity'
    //   18: invokespecial <init> : (Ljava/lang/String;)V
    //   21: athrow
    //   22: iload_2
    //   23: ifne -> 35
    //   26: iload_1
    //   27: aload_0
    //   28: getfield mCurState : I
    //   31: if_icmpne -> 35
    //   34: return
    //   35: aload_0
    //   36: iload_1
    //   37: putfield mCurState : I
    //   40: aload_0
    //   41: getfield mActive : Landroid/util/SparseArray;
    //   44: ifnull -> 34
    //   47: iconst_0
    //   48: istore_1
    //   49: aload_0
    //   50: getfield mAdded : Ljava/util/ArrayList;
    //   53: invokevirtual size : ()I
    //   56: istore #5
    //   58: iconst_0
    //   59: istore_3
    //   60: iload_3
    //   61: iload #5
    //   63: if_icmpge -> 118
    //   66: aload_0
    //   67: getfield mAdded : Ljava/util/ArrayList;
    //   70: iload_3
    //   71: invokevirtual get : (I)Ljava/lang/Object;
    //   74: checkcast android/support/v4/app/Fragment
    //   77: astore #6
    //   79: aload_0
    //   80: aload #6
    //   82: invokevirtual moveFragmentToExpectedState : (Landroid/support/v4/app/Fragment;)V
    //   85: iload_1
    //   86: istore #4
    //   88: aload #6
    //   90: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   93: ifnull -> 108
    //   96: iload_1
    //   97: aload #6
    //   99: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   102: invokevirtual hasRunningLoaders : ()Z
    //   105: ior
    //   106: istore #4
    //   108: iload_3
    //   109: iconst_1
    //   110: iadd
    //   111: istore_3
    //   112: iload #4
    //   114: istore_1
    //   115: goto -> 60
    //   118: aload_0
    //   119: getfield mActive : Landroid/util/SparseArray;
    //   122: invokevirtual size : ()I
    //   125: istore #5
    //   127: iconst_0
    //   128: istore #4
    //   130: iload_1
    //   131: istore_3
    //   132: iload #4
    //   134: istore_1
    //   135: iload_1
    //   136: iload #5
    //   138: if_icmpge -> 231
    //   141: aload_0
    //   142: getfield mActive : Landroid/util/SparseArray;
    //   145: iload_1
    //   146: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   149: checkcast android/support/v4/app/Fragment
    //   152: astore #6
    //   154: iload_3
    //   155: istore #4
    //   157: aload #6
    //   159: ifnull -> 221
    //   162: aload #6
    //   164: getfield mRemoving : Z
    //   167: ifne -> 181
    //   170: iload_3
    //   171: istore #4
    //   173: aload #6
    //   175: getfield mDetached : Z
    //   178: ifeq -> 221
    //   181: iload_3
    //   182: istore #4
    //   184: aload #6
    //   186: getfield mIsNewlyAdded : Z
    //   189: ifne -> 221
    //   192: aload_0
    //   193: aload #6
    //   195: invokevirtual moveFragmentToExpectedState : (Landroid/support/v4/app/Fragment;)V
    //   198: iload_3
    //   199: istore #4
    //   201: aload #6
    //   203: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   206: ifnull -> 221
    //   209: iload_3
    //   210: aload #6
    //   212: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   215: invokevirtual hasRunningLoaders : ()Z
    //   218: ior
    //   219: istore #4
    //   221: iload_1
    //   222: iconst_1
    //   223: iadd
    //   224: istore_1
    //   225: iload #4
    //   227: istore_3
    //   228: goto -> 135
    //   231: iload_3
    //   232: ifne -> 239
    //   235: aload_0
    //   236: invokevirtual startPendingDeferredFragments : ()V
    //   239: aload_0
    //   240: getfield mNeedMenuInvalidate : Z
    //   243: ifeq -> 34
    //   246: aload_0
    //   247: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   250: ifnull -> 34
    //   253: aload_0
    //   254: getfield mCurState : I
    //   257: iconst_5
    //   258: if_icmpne -> 34
    //   261: aload_0
    //   262: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   265: invokevirtual onSupportInvalidateOptionsMenu : ()V
    //   268: aload_0
    //   269: iconst_0
    //   270: putfield mNeedMenuInvalidate : Z
    //   273: return
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: ifeq -> 17
    //   7: iload_2
    //   8: istore #7
    //   10: aload_1
    //   11: getfield mDetached : Z
    //   14: ifeq -> 28
    //   17: iload_2
    //   18: istore #7
    //   20: iload_2
    //   21: iconst_1
    //   22: if_icmple -> 28
    //   25: iconst_1
    //   26: istore #7
    //   28: iload #7
    //   30: istore #6
    //   32: aload_1
    //   33: getfield mRemoving : Z
    //   36: ifeq -> 69
    //   39: iload #7
    //   41: istore #6
    //   43: iload #7
    //   45: aload_1
    //   46: getfield mState : I
    //   49: if_icmple -> 69
    //   52: aload_1
    //   53: getfield mState : I
    //   56: ifne -> 124
    //   59: aload_1
    //   60: invokevirtual isInBackStack : ()Z
    //   63: ifeq -> 124
    //   66: iconst_1
    //   67: istore #6
    //   69: iload #6
    //   71: istore_2
    //   72: aload_1
    //   73: getfield mDeferStart : Z
    //   76: ifeq -> 101
    //   79: iload #6
    //   81: istore_2
    //   82: aload_1
    //   83: getfield mState : I
    //   86: iconst_4
    //   87: if_icmpge -> 101
    //   90: iload #6
    //   92: istore_2
    //   93: iload #6
    //   95: iconst_3
    //   96: if_icmple -> 101
    //   99: iconst_3
    //   100: istore_2
    //   101: aload_1
    //   102: getfield mState : I
    //   105: iload_2
    //   106: if_icmpgt -> 1320
    //   109: aload_1
    //   110: getfield mFromLayout : Z
    //   113: ifeq -> 133
    //   116: aload_1
    //   117: getfield mInLayout : Z
    //   120: ifne -> 133
    //   123: return
    //   124: aload_1
    //   125: getfield mState : I
    //   128: istore #6
    //   130: goto -> 69
    //   133: aload_1
    //   134: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   137: ifnonnull -> 147
    //   140: aload_1
    //   141: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   144: ifnull -> 169
    //   147: aload_1
    //   148: aconst_null
    //   149: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   152: aload_1
    //   153: aconst_null
    //   154: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   157: aload_0
    //   158: aload_1
    //   159: aload_1
    //   160: invokevirtual getStateAfterAnimating : ()I
    //   163: iconst_0
    //   164: iconst_0
    //   165: iconst_1
    //   166: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   169: iload_2
    //   170: istore #4
    //   172: iload_2
    //   173: istore #6
    //   175: iload_2
    //   176: istore #7
    //   178: iload_2
    //   179: istore_3
    //   180: aload_1
    //   181: getfield mState : I
    //   184: tableswitch default -> 220, 0 -> 295, 1 -> 735, 2 -> 1130, 3 -> 1149, 4 -> 1203
    //   220: iload_2
    //   221: istore #6
    //   223: aload_1
    //   224: getfield mState : I
    //   227: iload #6
    //   229: if_icmpeq -> 123
    //   232: ldc 'FragmentManager'
    //   234: new java/lang/StringBuilder
    //   237: dup
    //   238: invokespecial <init> : ()V
    //   241: ldc_w 'moveToState: Fragment state for '
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: aload_1
    //   248: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   251: ldc_w ' not updated inline; '
    //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: ldc_w 'expected state '
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: iload #6
    //   265: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   268: ldc_w ' found '
    //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   274: aload_1
    //   275: getfield mState : I
    //   278: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   281: invokevirtual toString : ()Ljava/lang/String;
    //   284: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   287: pop
    //   288: aload_1
    //   289: iload #6
    //   291: putfield mState : I
    //   294: return
    //   295: iload_2
    //   296: istore #4
    //   298: iload_2
    //   299: ifle -> 735
    //   302: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   305: ifeq -> 334
    //   308: ldc 'FragmentManager'
    //   310: new java/lang/StringBuilder
    //   313: dup
    //   314: invokespecial <init> : ()V
    //   317: ldc_w 'moveto CREATED: '
    //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: aload_1
    //   324: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   327: invokevirtual toString : ()Ljava/lang/String;
    //   330: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   333: pop
    //   334: iload_2
    //   335: istore #4
    //   337: aload_1
    //   338: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   341: ifnull -> 449
    //   344: aload_1
    //   345: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   348: aload_0
    //   349: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   352: invokevirtual getContext : ()Landroid/content/Context;
    //   355: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   358: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   361: aload_1
    //   362: aload_1
    //   363: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   366: ldc 'android:view_state'
    //   368: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   371: putfield mSavedViewState : Landroid/util/SparseArray;
    //   374: aload_1
    //   375: aload_0
    //   376: aload_1
    //   377: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   380: ldc 'android:target_state'
    //   382: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    //   385: putfield mTarget : Landroid/support/v4/app/Fragment;
    //   388: aload_1
    //   389: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   392: ifnull -> 409
    //   395: aload_1
    //   396: aload_1
    //   397: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   400: ldc 'android:target_req_state'
    //   402: iconst_0
    //   403: invokevirtual getInt : (Ljava/lang/String;I)I
    //   406: putfield mTargetRequestCode : I
    //   409: aload_1
    //   410: aload_1
    //   411: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   414: ldc 'android:user_visible_hint'
    //   416: iconst_1
    //   417: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   420: putfield mUserVisibleHint : Z
    //   423: iload_2
    //   424: istore #4
    //   426: aload_1
    //   427: getfield mUserVisibleHint : Z
    //   430: ifne -> 449
    //   433: aload_1
    //   434: iconst_1
    //   435: putfield mDeferStart : Z
    //   438: iload_2
    //   439: istore #4
    //   441: iload_2
    //   442: iconst_3
    //   443: if_icmple -> 449
    //   446: iconst_3
    //   447: istore #4
    //   449: aload_1
    //   450: aload_0
    //   451: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   454: putfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   457: aload_1
    //   458: aload_0
    //   459: getfield mParent : Landroid/support/v4/app/Fragment;
    //   462: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   465: aload_0
    //   466: getfield mParent : Landroid/support/v4/app/Fragment;
    //   469: ifnull -> 562
    //   472: aload_0
    //   473: getfield mParent : Landroid/support/v4/app/Fragment;
    //   476: getfield mChildFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   479: astore #8
    //   481: aload_1
    //   482: aload #8
    //   484: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   487: aload_1
    //   488: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   491: ifnull -> 597
    //   494: aload_0
    //   495: getfield mActive : Landroid/util/SparseArray;
    //   498: aload_1
    //   499: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   502: getfield mIndex : I
    //   505: invokevirtual get : (I)Ljava/lang/Object;
    //   508: aload_1
    //   509: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   512: if_acmpeq -> 574
    //   515: new java/lang/IllegalStateException
    //   518: dup
    //   519: new java/lang/StringBuilder
    //   522: dup
    //   523: invokespecial <init> : ()V
    //   526: ldc_w 'Fragment '
    //   529: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   532: aload_1
    //   533: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   536: ldc_w ' declared target fragment '
    //   539: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   542: aload_1
    //   543: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   546: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   549: ldc_w ' that does not belong to this FragmentManager!'
    //   552: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   555: invokevirtual toString : ()Ljava/lang/String;
    //   558: invokespecial <init> : (Ljava/lang/String;)V
    //   561: athrow
    //   562: aload_0
    //   563: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   566: invokevirtual getFragmentManagerImpl : ()Landroid/support/v4/app/FragmentManagerImpl;
    //   569: astore #8
    //   571: goto -> 481
    //   574: aload_1
    //   575: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   578: getfield mState : I
    //   581: iconst_1
    //   582: if_icmpge -> 597
    //   585: aload_0
    //   586: aload_1
    //   587: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   590: iconst_1
    //   591: iconst_0
    //   592: iconst_0
    //   593: iconst_1
    //   594: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   597: aload_0
    //   598: aload_1
    //   599: aload_0
    //   600: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   603: invokevirtual getContext : ()Landroid/content/Context;
    //   606: iconst_0
    //   607: invokevirtual dispatchOnFragmentPreAttached : (Landroid/support/v4/app/Fragment;Landroid/content/Context;Z)V
    //   610: aload_1
    //   611: iconst_0
    //   612: putfield mCalled : Z
    //   615: aload_1
    //   616: aload_0
    //   617: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   620: invokevirtual getContext : ()Landroid/content/Context;
    //   623: invokevirtual onAttach : (Landroid/content/Context;)V
    //   626: aload_1
    //   627: getfield mCalled : Z
    //   630: ifne -> 667
    //   633: new android/support/v4/app/SuperNotCalledException
    //   636: dup
    //   637: new java/lang/StringBuilder
    //   640: dup
    //   641: invokespecial <init> : ()V
    //   644: ldc_w 'Fragment '
    //   647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   650: aload_1
    //   651: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   654: ldc_w ' did not call through to super.onAttach()'
    //   657: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   660: invokevirtual toString : ()Ljava/lang/String;
    //   663: invokespecial <init> : (Ljava/lang/String;)V
    //   666: athrow
    //   667: aload_1
    //   668: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   671: ifnonnull -> 1269
    //   674: aload_0
    //   675: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   678: aload_1
    //   679: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   682: aload_0
    //   683: aload_1
    //   684: aload_0
    //   685: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   688: invokevirtual getContext : ()Landroid/content/Context;
    //   691: iconst_0
    //   692: invokevirtual dispatchOnFragmentAttached : (Landroid/support/v4/app/Fragment;Landroid/content/Context;Z)V
    //   695: aload_1
    //   696: getfield mIsCreated : Z
    //   699: ifne -> 1280
    //   702: aload_0
    //   703: aload_1
    //   704: aload_1
    //   705: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   708: iconst_0
    //   709: invokevirtual dispatchOnFragmentPreCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   712: aload_1
    //   713: aload_1
    //   714: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   717: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   720: aload_0
    //   721: aload_1
    //   722: aload_1
    //   723: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   726: iconst_0
    //   727: invokevirtual dispatchOnFragmentCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   730: aload_1
    //   731: iconst_0
    //   732: putfield mRetaining : Z
    //   735: aload_0
    //   736: aload_1
    //   737: invokevirtual ensureInflatedFragmentView : (Landroid/support/v4/app/Fragment;)V
    //   740: iload #4
    //   742: istore #6
    //   744: iload #4
    //   746: iconst_1
    //   747: if_icmple -> 1130
    //   750: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   753: ifeq -> 782
    //   756: ldc 'FragmentManager'
    //   758: new java/lang/StringBuilder
    //   761: dup
    //   762: invokespecial <init> : ()V
    //   765: ldc_w 'moveto ACTIVITY_CREATED: '
    //   768: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   771: aload_1
    //   772: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   775: invokevirtual toString : ()Ljava/lang/String;
    //   778: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   781: pop
    //   782: aload_1
    //   783: getfield mFromLayout : Z
    //   786: ifne -> 1088
    //   789: aconst_null
    //   790: astore #8
    //   792: aload_1
    //   793: getfield mContainerId : I
    //   796: ifeq -> 955
    //   799: aload_1
    //   800: getfield mContainerId : I
    //   803: iconst_m1
    //   804: if_icmpne -> 844
    //   807: aload_0
    //   808: new java/lang/IllegalArgumentException
    //   811: dup
    //   812: new java/lang/StringBuilder
    //   815: dup
    //   816: invokespecial <init> : ()V
    //   819: ldc_w 'Cannot create fragment '
    //   822: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   825: aload_1
    //   826: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   829: ldc_w ' for a container view with no id'
    //   832: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   835: invokevirtual toString : ()Ljava/lang/String;
    //   838: invokespecial <init> : (Ljava/lang/String;)V
    //   841: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   844: aload_0
    //   845: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   848: aload_1
    //   849: getfield mContainerId : I
    //   852: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   855: checkcast android/view/ViewGroup
    //   858: astore #9
    //   860: aload #9
    //   862: astore #8
    //   864: aload #9
    //   866: ifnonnull -> 955
    //   869: aload #9
    //   871: astore #8
    //   873: aload_1
    //   874: getfield mRestored : Z
    //   877: ifne -> 955
    //   880: aload_1
    //   881: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   884: aload_1
    //   885: getfield mContainerId : I
    //   888: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   891: astore #8
    //   893: aload_0
    //   894: new java/lang/IllegalArgumentException
    //   897: dup
    //   898: new java/lang/StringBuilder
    //   901: dup
    //   902: invokespecial <init> : ()V
    //   905: ldc_w 'No view found for id 0x'
    //   908: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   911: aload_1
    //   912: getfield mContainerId : I
    //   915: invokestatic toHexString : (I)Ljava/lang/String;
    //   918: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   921: ldc_w ' ('
    //   924: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   927: aload #8
    //   929: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   932: ldc_w ') for fragment '
    //   935: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   938: aload_1
    //   939: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   942: invokevirtual toString : ()Ljava/lang/String;
    //   945: invokespecial <init> : (Ljava/lang/String;)V
    //   948: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   951: aload #9
    //   953: astore #8
    //   955: aload_1
    //   956: aload #8
    //   958: putfield mContainer : Landroid/view/ViewGroup;
    //   961: aload_1
    //   962: aload_1
    //   963: aload_1
    //   964: aload_1
    //   965: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   968: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   971: aload #8
    //   973: aload_1
    //   974: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   977: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   980: putfield mView : Landroid/view/View;
    //   983: aload_1
    //   984: getfield mView : Landroid/view/View;
    //   987: ifnull -> 1312
    //   990: aload_1
    //   991: aload_1
    //   992: getfield mView : Landroid/view/View;
    //   995: putfield mInnerView : Landroid/view/View;
    //   998: aload_1
    //   999: getfield mView : Landroid/view/View;
    //   1002: iconst_0
    //   1003: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1006: aload #8
    //   1008: ifnull -> 1020
    //   1011: aload #8
    //   1013: aload_1
    //   1014: getfield mView : Landroid/view/View;
    //   1017: invokevirtual addView : (Landroid/view/View;)V
    //   1020: aload_1
    //   1021: getfield mHidden : Z
    //   1024: ifeq -> 1036
    //   1027: aload_1
    //   1028: getfield mView : Landroid/view/View;
    //   1031: bipush #8
    //   1033: invokevirtual setVisibility : (I)V
    //   1036: aload_1
    //   1037: aload_1
    //   1038: getfield mView : Landroid/view/View;
    //   1041: aload_1
    //   1042: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1045: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1048: aload_0
    //   1049: aload_1
    //   1050: aload_1
    //   1051: getfield mView : Landroid/view/View;
    //   1054: aload_1
    //   1055: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1058: iconst_0
    //   1059: invokevirtual dispatchOnFragmentViewCreated : (Landroid/support/v4/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1062: aload_1
    //   1063: getfield mView : Landroid/view/View;
    //   1066: invokevirtual getVisibility : ()I
    //   1069: ifne -> 1306
    //   1072: aload_1
    //   1073: getfield mContainer : Landroid/view/ViewGroup;
    //   1076: ifnull -> 1306
    //   1079: iconst_1
    //   1080: istore #5
    //   1082: aload_1
    //   1083: iload #5
    //   1085: putfield mIsNewlyAdded : Z
    //   1088: aload_1
    //   1089: aload_1
    //   1090: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1093: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1096: aload_0
    //   1097: aload_1
    //   1098: aload_1
    //   1099: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1102: iconst_0
    //   1103: invokevirtual dispatchOnFragmentActivityCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   1106: aload_1
    //   1107: getfield mView : Landroid/view/View;
    //   1110: ifnull -> 1121
    //   1113: aload_1
    //   1114: aload_1
    //   1115: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1118: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1121: aload_1
    //   1122: aconst_null
    //   1123: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1126: iload #4
    //   1128: istore #6
    //   1130: iload #6
    //   1132: istore #7
    //   1134: iload #6
    //   1136: iconst_2
    //   1137: if_icmple -> 1149
    //   1140: aload_1
    //   1141: iconst_3
    //   1142: putfield mState : I
    //   1145: iload #6
    //   1147: istore #7
    //   1149: iload #7
    //   1151: istore_3
    //   1152: iload #7
    //   1154: iconst_3
    //   1155: if_icmple -> 1203
    //   1158: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1161: ifeq -> 1190
    //   1164: ldc 'FragmentManager'
    //   1166: new java/lang/StringBuilder
    //   1169: dup
    //   1170: invokespecial <init> : ()V
    //   1173: ldc_w 'moveto STARTED: '
    //   1176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1179: aload_1
    //   1180: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1183: invokevirtual toString : ()Ljava/lang/String;
    //   1186: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1189: pop
    //   1190: aload_1
    //   1191: invokevirtual performStart : ()V
    //   1194: aload_0
    //   1195: aload_1
    //   1196: iconst_0
    //   1197: invokevirtual dispatchOnFragmentStarted : (Landroid/support/v4/app/Fragment;Z)V
    //   1200: iload #7
    //   1202: istore_3
    //   1203: iload_3
    //   1204: istore #6
    //   1206: iload_3
    //   1207: iconst_4
    //   1208: if_icmple -> 223
    //   1211: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1214: ifeq -> 1243
    //   1217: ldc 'FragmentManager'
    //   1219: new java/lang/StringBuilder
    //   1222: dup
    //   1223: invokespecial <init> : ()V
    //   1226: ldc_w 'moveto RESUMED: '
    //   1229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1232: aload_1
    //   1233: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1236: invokevirtual toString : ()Ljava/lang/String;
    //   1239: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1242: pop
    //   1243: aload_1
    //   1244: invokevirtual performResume : ()V
    //   1247: aload_0
    //   1248: aload_1
    //   1249: iconst_0
    //   1250: invokevirtual dispatchOnFragmentResumed : (Landroid/support/v4/app/Fragment;Z)V
    //   1253: aload_1
    //   1254: aconst_null
    //   1255: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1258: aload_1
    //   1259: aconst_null
    //   1260: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1263: iload_3
    //   1264: istore #6
    //   1266: goto -> 223
    //   1269: aload_1
    //   1270: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   1273: aload_1
    //   1274: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   1277: goto -> 682
    //   1280: aload_1
    //   1281: aload_1
    //   1282: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1285: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   1288: aload_1
    //   1289: iconst_1
    //   1290: putfield mState : I
    //   1293: goto -> 730
    //   1296: astore #8
    //   1298: ldc_w 'unknown'
    //   1301: astore #8
    //   1303: goto -> 893
    //   1306: iconst_0
    //   1307: istore #5
    //   1309: goto -> 1082
    //   1312: aload_1
    //   1313: aconst_null
    //   1314: putfield mInnerView : Landroid/view/View;
    //   1317: goto -> 1088
    //   1320: iload_2
    //   1321: istore #6
    //   1323: aload_1
    //   1324: getfield mState : I
    //   1327: iload_2
    //   1328: if_icmple -> 223
    //   1331: aload_1
    //   1332: getfield mState : I
    //   1335: tableswitch default -> 1368, 1 -> 1374, 2 -> 1572, 3 -> 1531, 4 -> 1484, 5 -> 1437
    //   1368: iload_2
    //   1369: istore #6
    //   1371: goto -> 223
    //   1374: iload_2
    //   1375: istore #6
    //   1377: iload_2
    //   1378: iconst_1
    //   1379: if_icmpge -> 223
    //   1382: aload_0
    //   1383: getfield mDestroyed : Z
    //   1386: ifeq -> 1412
    //   1389: aload_1
    //   1390: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1393: ifnull -> 1796
    //   1396: aload_1
    //   1397: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1400: astore #8
    //   1402: aload_1
    //   1403: aconst_null
    //   1404: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1407: aload #8
    //   1409: invokevirtual clearAnimation : ()V
    //   1412: aload_1
    //   1413: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1416: ifnonnull -> 1426
    //   1419: aload_1
    //   1420: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1423: ifnull -> 1822
    //   1426: aload_1
    //   1427: iload_2
    //   1428: invokevirtual setStateAfterAnimating : (I)V
    //   1431: iconst_1
    //   1432: istore #6
    //   1434: goto -> 223
    //   1437: iload_2
    //   1438: iconst_5
    //   1439: if_icmpge -> 1484
    //   1442: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1445: ifeq -> 1474
    //   1448: ldc 'FragmentManager'
    //   1450: new java/lang/StringBuilder
    //   1453: dup
    //   1454: invokespecial <init> : ()V
    //   1457: ldc_w 'movefrom RESUMED: '
    //   1460: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1463: aload_1
    //   1464: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1467: invokevirtual toString : ()Ljava/lang/String;
    //   1470: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1473: pop
    //   1474: aload_1
    //   1475: invokevirtual performPause : ()V
    //   1478: aload_0
    //   1479: aload_1
    //   1480: iconst_0
    //   1481: invokevirtual dispatchOnFragmentPaused : (Landroid/support/v4/app/Fragment;Z)V
    //   1484: iload_2
    //   1485: iconst_4
    //   1486: if_icmpge -> 1531
    //   1489: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1492: ifeq -> 1521
    //   1495: ldc 'FragmentManager'
    //   1497: new java/lang/StringBuilder
    //   1500: dup
    //   1501: invokespecial <init> : ()V
    //   1504: ldc_w 'movefrom STARTED: '
    //   1507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1510: aload_1
    //   1511: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1514: invokevirtual toString : ()Ljava/lang/String;
    //   1517: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1520: pop
    //   1521: aload_1
    //   1522: invokevirtual performStop : ()V
    //   1525: aload_0
    //   1526: aload_1
    //   1527: iconst_0
    //   1528: invokevirtual dispatchOnFragmentStopped : (Landroid/support/v4/app/Fragment;Z)V
    //   1531: iload_2
    //   1532: iconst_3
    //   1533: if_icmpge -> 1572
    //   1536: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1539: ifeq -> 1568
    //   1542: ldc 'FragmentManager'
    //   1544: new java/lang/StringBuilder
    //   1547: dup
    //   1548: invokespecial <init> : ()V
    //   1551: ldc_w 'movefrom STOPPED: '
    //   1554: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1557: aload_1
    //   1558: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1561: invokevirtual toString : ()Ljava/lang/String;
    //   1564: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1567: pop
    //   1568: aload_1
    //   1569: invokevirtual performReallyStop : ()V
    //   1572: iload_2
    //   1573: iconst_2
    //   1574: if_icmpge -> 1374
    //   1577: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1580: ifeq -> 1609
    //   1583: ldc 'FragmentManager'
    //   1585: new java/lang/StringBuilder
    //   1588: dup
    //   1589: invokespecial <init> : ()V
    //   1592: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1595: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1598: aload_1
    //   1599: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1602: invokevirtual toString : ()Ljava/lang/String;
    //   1605: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1608: pop
    //   1609: aload_1
    //   1610: getfield mView : Landroid/view/View;
    //   1613: ifnull -> 1639
    //   1616: aload_0
    //   1617: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   1620: aload_1
    //   1621: invokevirtual onShouldSaveFragmentState : (Landroid/support/v4/app/Fragment;)Z
    //   1624: ifeq -> 1639
    //   1627: aload_1
    //   1628: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1631: ifnonnull -> 1639
    //   1634: aload_0
    //   1635: aload_1
    //   1636: invokevirtual saveFragmentViewState : (Landroid/support/v4/app/Fragment;)V
    //   1639: aload_1
    //   1640: invokevirtual performDestroyView : ()V
    //   1643: aload_0
    //   1644: aload_1
    //   1645: iconst_0
    //   1646: invokevirtual dispatchOnFragmentViewDestroyed : (Landroid/support/v4/app/Fragment;Z)V
    //   1649: aload_1
    //   1650: getfield mView : Landroid/view/View;
    //   1653: ifnull -> 1773
    //   1656: aload_1
    //   1657: getfield mContainer : Landroid/view/ViewGroup;
    //   1660: ifnull -> 1773
    //   1663: aload_1
    //   1664: getfield mView : Landroid/view/View;
    //   1667: invokevirtual clearAnimation : ()V
    //   1670: aload_1
    //   1671: getfield mContainer : Landroid/view/ViewGroup;
    //   1674: aload_1
    //   1675: getfield mView : Landroid/view/View;
    //   1678: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1681: aconst_null
    //   1682: astore #9
    //   1684: aload #9
    //   1686: astore #8
    //   1688: aload_0
    //   1689: getfield mCurState : I
    //   1692: ifle -> 1744
    //   1695: aload #9
    //   1697: astore #8
    //   1699: aload_0
    //   1700: getfield mDestroyed : Z
    //   1703: ifne -> 1744
    //   1706: aload #9
    //   1708: astore #8
    //   1710: aload_1
    //   1711: getfield mView : Landroid/view/View;
    //   1714: invokevirtual getVisibility : ()I
    //   1717: ifne -> 1744
    //   1720: aload #9
    //   1722: astore #8
    //   1724: aload_1
    //   1725: getfield mPostponedAlpha : F
    //   1728: fconst_0
    //   1729: fcmpl
    //   1730: iflt -> 1744
    //   1733: aload_0
    //   1734: aload_1
    //   1735: iload_3
    //   1736: iconst_0
    //   1737: iload #4
    //   1739: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1742: astore #8
    //   1744: aload_1
    //   1745: fconst_0
    //   1746: putfield mPostponedAlpha : F
    //   1749: aload #8
    //   1751: ifnull -> 1762
    //   1754: aload_0
    //   1755: aload_1
    //   1756: aload #8
    //   1758: iload_2
    //   1759: invokespecial animateRemoveFragment : (Landroid/support/v4/app/Fragment;Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1762: aload_1
    //   1763: getfield mContainer : Landroid/view/ViewGroup;
    //   1766: aload_1
    //   1767: getfield mView : Landroid/view/View;
    //   1770: invokevirtual removeView : (Landroid/view/View;)V
    //   1773: aload_1
    //   1774: aconst_null
    //   1775: putfield mContainer : Landroid/view/ViewGroup;
    //   1778: aload_1
    //   1779: aconst_null
    //   1780: putfield mView : Landroid/view/View;
    //   1783: aload_1
    //   1784: aconst_null
    //   1785: putfield mInnerView : Landroid/view/View;
    //   1788: aload_1
    //   1789: iconst_0
    //   1790: putfield mInLayout : Z
    //   1793: goto -> 1374
    //   1796: aload_1
    //   1797: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1800: ifnull -> 1412
    //   1803: aload_1
    //   1804: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1807: astore #8
    //   1809: aload_1
    //   1810: aconst_null
    //   1811: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1814: aload #8
    //   1816: invokevirtual cancel : ()V
    //   1819: goto -> 1412
    //   1822: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1825: ifeq -> 1854
    //   1828: ldc 'FragmentManager'
    //   1830: new java/lang/StringBuilder
    //   1833: dup
    //   1834: invokespecial <init> : ()V
    //   1837: ldc_w 'movefrom CREATED: '
    //   1840: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1843: aload_1
    //   1844: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1847: invokevirtual toString : ()Ljava/lang/String;
    //   1850: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1853: pop
    //   1854: aload_1
    //   1855: getfield mRetaining : Z
    //   1858: ifne -> 1907
    //   1861: aload_1
    //   1862: invokevirtual performDestroy : ()V
    //   1865: aload_0
    //   1866: aload_1
    //   1867: iconst_0
    //   1868: invokevirtual dispatchOnFragmentDestroyed : (Landroid/support/v4/app/Fragment;Z)V
    //   1871: aload_1
    //   1872: invokevirtual performDetach : ()V
    //   1875: aload_0
    //   1876: aload_1
    //   1877: iconst_0
    //   1878: invokevirtual dispatchOnFragmentDetached : (Landroid/support/v4/app/Fragment;Z)V
    //   1881: iload_2
    //   1882: istore #6
    //   1884: iload #5
    //   1886: ifne -> 223
    //   1889: aload_1
    //   1890: getfield mRetaining : Z
    //   1893: ifne -> 1915
    //   1896: aload_0
    //   1897: aload_1
    //   1898: invokevirtual makeInactive : (Landroid/support/v4/app/Fragment;)V
    //   1901: iload_2
    //   1902: istore #6
    //   1904: goto -> 223
    //   1907: aload_1
    //   1908: iconst_0
    //   1909: putfield mState : I
    //   1912: goto -> 1871
    //   1915: aload_1
    //   1916: aconst_null
    //   1917: putfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   1920: aload_1
    //   1921: aconst_null
    //   1922: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   1925: aload_1
    //   1926: aconst_null
    //   1927: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   1930: iload_2
    //   1931: istore #6
    //   1933: goto -> 223
    // Exception table:
    //   from	to	target	type
    //   880	893	1296	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    this.mSavedNonConfig = null;
    this.mStateSaved = false;
    int j = this.mAdded.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    Fragment fragment1;
    boolean bool;
    if (!"fragment".equals(paramString))
      return null; 
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    String str2 = paramString;
    if (paramString == null)
      str2 = typedArray.getString(0); 
    int i = typedArray.getResourceId(1, -1);
    String str3 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass(this.mHost.getContext(), str2))
      return null; 
    if (paramView != null) {
      bool = paramView.getId();
    } else {
      bool = false;
    } 
    if (bool == -1 && i == -1 && str3 == null)
      throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str2); 
    if (i != -1) {
      Fragment fragment = findFragmentById(i);
    } else {
      paramString = null;
    } 
    String str1 = paramString;
    if (paramString == null) {
      str1 = paramString;
      if (str3 != null)
        fragment1 = findFragmentByTag(str3); 
    } 
    Fragment fragment2 = fragment1;
    if (fragment1 == null) {
      fragment2 = fragment1;
      if (bool != -1)
        fragment2 = findFragmentById(bool); 
    } 
    if (DEBUG)
      Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(i) + " fname=" + str2 + " existing=" + fragment2); 
    if (fragment2 == null) {
      boolean bool1;
      fragment1 = this.mContainer.instantiate(paramContext, str2, null);
      fragment1.mFromLayout = true;
      if (i != 0) {
        bool1 = i;
      } else {
        bool1 = bool;
      } 
      fragment1.mFragmentId = bool1;
      fragment1.mContainerId = bool;
      fragment1.mTag = str3;
      fragment1.mInLayout = true;
      fragment1.mFragmentManager = this;
      fragment1.mHost = this.mHost;
      fragment1.onInflate(this.mHost.getContext(), paramAttributeSet, fragment1.mSavedFragmentState);
      addFragment(fragment1, true);
    } else {
      if (fragment2.mInLayout)
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(i) + ", tag " + str3 + ", or parent id 0x" + Integer.toHexString(bool) + " with another fragment for " + str2); 
      fragment2.mInLayout = true;
      fragment2.mHost = this.mHost;
      fragment1 = fragment2;
      if (!fragment2.mRetaining) {
        fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
        fragment1 = fragment2;
      } 
    } 
    if (this.mCurState < 1 && fragment1.mFromLayout) {
      moveToState(fragment1, 1, 0, 0, false);
    } else {
      moveToState(fragment1);
    } 
    if (fragment1.mView == null)
      throw new IllegalStateException("Fragment " + str2 + " did not create a view."); 
    if (i != 0)
      fragment1.mView.setId(i); 
    if (fragment1.mView.getTag() == null)
      fragment1.mView.setTag(str3); 
    return fragment1.mView;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
    } else {
      return;
    } 
    paramFragment.mDeferStart = false;
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Bad id: " + paramInt1); 
    enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Bad id: " + paramInt1); 
    return popBackStackImmediate(null, paramInt1, paramInt2);
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_3
    //   10: ifnonnull -> 66
    //   13: iload #4
    //   15: ifge -> 66
    //   18: iload #5
    //   20: iconst_1
    //   21: iand
    //   22: ifne -> 66
    //   25: aload_0
    //   26: getfield mBackStack : Ljava/util/ArrayList;
    //   29: invokevirtual size : ()I
    //   32: iconst_1
    //   33: isub
    //   34: istore #4
    //   36: iload #4
    //   38: iflt -> 7
    //   41: aload_1
    //   42: aload_0
    //   43: getfield mBackStack : Ljava/util/ArrayList;
    //   46: iload #4
    //   48: invokevirtual remove : (I)Ljava/lang/Object;
    //   51: invokevirtual add : (Ljava/lang/Object;)Z
    //   54: pop
    //   55: aload_2
    //   56: iconst_1
    //   57: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   60: invokevirtual add : (Ljava/lang/Object;)Z
    //   63: pop
    //   64: iconst_1
    //   65: ireturn
    //   66: iconst_m1
    //   67: istore #6
    //   69: aload_3
    //   70: ifnonnull -> 78
    //   73: iload #4
    //   75: iflt -> 241
    //   78: aload_0
    //   79: getfield mBackStack : Ljava/util/ArrayList;
    //   82: invokevirtual size : ()I
    //   85: iconst_1
    //   86: isub
    //   87: istore #7
    //   89: iload #7
    //   91: iflt -> 124
    //   94: aload_0
    //   95: getfield mBackStack : Ljava/util/ArrayList;
    //   98: iload #7
    //   100: invokevirtual get : (I)Ljava/lang/Object;
    //   103: checkcast android/support/v4/app/BackStackRecord
    //   106: astore #8
    //   108: aload_3
    //   109: ifnull -> 217
    //   112: aload_3
    //   113: aload #8
    //   115: invokevirtual getName : ()Ljava/lang/String;
    //   118: invokevirtual equals : (Ljava/lang/Object;)Z
    //   121: ifeq -> 217
    //   124: iload #7
    //   126: iflt -> 7
    //   129: iload #7
    //   131: istore #6
    //   133: iload #5
    //   135: iconst_1
    //   136: iand
    //   137: ifeq -> 241
    //   140: iload #7
    //   142: iconst_1
    //   143: isub
    //   144: istore #5
    //   146: iload #5
    //   148: istore #6
    //   150: iload #5
    //   152: iflt -> 241
    //   155: aload_0
    //   156: getfield mBackStack : Ljava/util/ArrayList;
    //   159: iload #5
    //   161: invokevirtual get : (I)Ljava/lang/Object;
    //   164: checkcast android/support/v4/app/BackStackRecord
    //   167: astore #8
    //   169: aload_3
    //   170: ifnull -> 185
    //   173: aload_3
    //   174: aload #8
    //   176: invokevirtual getName : ()Ljava/lang/String;
    //   179: invokevirtual equals : (Ljava/lang/Object;)Z
    //   182: ifne -> 208
    //   185: iload #5
    //   187: istore #6
    //   189: iload #4
    //   191: iflt -> 241
    //   194: iload #5
    //   196: istore #6
    //   198: iload #4
    //   200: aload #8
    //   202: getfield mIndex : I
    //   205: if_icmpne -> 241
    //   208: iload #5
    //   210: iconst_1
    //   211: isub
    //   212: istore #5
    //   214: goto -> 146
    //   217: iload #4
    //   219: iflt -> 232
    //   222: iload #4
    //   224: aload #8
    //   226: getfield mIndex : I
    //   229: if_icmpeq -> 124
    //   232: iload #7
    //   234: iconst_1
    //   235: isub
    //   236: istore #7
    //   238: goto -> 89
    //   241: iload #6
    //   243: aload_0
    //   244: getfield mBackStack : Ljava/util/ArrayList;
    //   247: invokevirtual size : ()I
    //   250: iconst_1
    //   251: isub
    //   252: if_icmpeq -> 7
    //   255: aload_0
    //   256: getfield mBackStack : Ljava/util/ArrayList;
    //   259: invokevirtual size : ()I
    //   262: iconst_1
    //   263: isub
    //   264: istore #4
    //   266: iload #4
    //   268: iload #6
    //   270: if_icmple -> 64
    //   273: aload_1
    //   274: aload_0
    //   275: getfield mBackStack : Ljava/util/ArrayList;
    //   278: iload #4
    //   280: invokevirtual remove : (I)Ljava/lang/Object;
    //   283: invokevirtual add : (Ljava/lang/Object;)Z
    //   286: pop
    //   287: aload_2
    //   288: iconst_1
    //   289: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   292: invokevirtual add : (Ljava/lang/Object;)Z
    //   295: pop
    //   296: iload #4
    //   298: iconst_1
    //   299: isub
    //   300: istore #4
    //   302: goto -> 266
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new Pair(paramFragmentLifecycleCallbacks, Boolean.valueOf(paramBoolean)));
  }
  
  public void removeFragment(Fragment paramFragment) {
    boolean bool;
    if (DEBUG)
      Log.v("FragmentManager", "remove: " + paramFragment + " nesting=" + paramFragment.mBackStackNesting); 
    if (!paramFragment.isInBackStack()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!paramFragment.mDetached || bool)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners != null)
      this.mBackStackChangeListeners.remove(paramOnBackStackChangedListener); 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramParcelable != null) {
      FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
      if (fragmentManagerState.mActive != null) {
        Fragment fragment;
        paramParcelable = null;
        if (paramFragmentManagerNonConfig != null) {
          byte b;
          List<Fragment> list1 = paramFragmentManagerNonConfig.getFragments();
          List<FragmentManagerNonConfig> list = paramFragmentManagerNonConfig.getChildNonConfigs();
          if (list1 != null) {
            b = list1.size();
          } else {
            b = 0;
          } 
          int j = 0;
          while (true) {
            List<FragmentManagerNonConfig> list2 = list;
            if (j < b) {
              fragment = list1.get(j);
              if (DEBUG)
                Log.v("FragmentManager", "restoreAllState: re-attaching retained " + fragment); 
              int k;
              for (k = 0; k < fragmentManagerState.mActive.length && (fragmentManagerState.mActive[k]).mIndex != fragment.mIndex; k++);
              if (k == fragmentManagerState.mActive.length)
                throwException(new IllegalStateException("Could not find active fragment with index " + fragment.mIndex)); 
              FragmentState fragmentState = fragmentManagerState.mActive[k];
              fragmentState.mInstance = fragment;
              fragment.mSavedViewState = null;
              fragment.mBackStackNesting = 0;
              fragment.mInLayout = false;
              fragment.mAdded = false;
              fragment.mTarget = null;
              if (fragmentState.mSavedFragmentState != null) {
                fragmentState.mSavedFragmentState.setClassLoader(this.mHost.getContext().getClassLoader());
                fragment.mSavedViewState = fragmentState.mSavedFragmentState.getSparseParcelableArray("android:view_state");
                fragment.mSavedFragmentState = fragmentState.mSavedFragmentState;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        this.mActive = new SparseArray(fragmentManagerState.mActive.length);
        int i;
        for (i = 0; i < fragmentManagerState.mActive.length; i++) {
          FragmentState fragmentState = fragmentManagerState.mActive[i];
          if (fragmentState != null) {
            FragmentManagerNonConfig fragmentManagerNonConfig2 = null;
            FragmentManagerNonConfig fragmentManagerNonConfig1 = fragmentManagerNonConfig2;
            if (fragment != null) {
              fragmentManagerNonConfig1 = fragmentManagerNonConfig2;
              if (i < fragment.size())
                fragmentManagerNonConfig1 = fragment.get(i); 
            } 
            Fragment fragment1 = fragmentState.instantiate(this.mHost, this.mContainer, this.mParent, fragmentManagerNonConfig1);
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: active #" + i + ": " + fragment1); 
            this.mActive.put(fragment1.mIndex, fragment1);
            fragmentState.mInstance = null;
          } 
        } 
        if (paramFragmentManagerNonConfig != null) {
          List<Fragment> list = paramFragmentManagerNonConfig.getFragments();
          if (list != null) {
            i = list.size();
          } else {
            i = 0;
          } 
          int j;
          for (j = 0; j < i; j++) {
            Fragment fragment1 = list.get(j);
            if (fragment1.mTargetIndex >= 0) {
              fragment1.mTarget = (Fragment)this.mActive.get(fragment1.mTargetIndex);
              if (fragment1.mTarget == null)
                Log.w("FragmentManager", "Re-attaching retained fragment " + fragment1 + " target no longer exists: " + fragment1.mTargetIndex); 
            } 
          } 
        } 
        this.mAdded.clear();
        if (fragmentManagerState.mAdded != null) {
          i = 0;
          while (i < fragmentManagerState.mAdded.length) {
            null = (Fragment)this.mActive.get(fragmentManagerState.mAdded[i]);
            if (null == null)
              throwException(new IllegalStateException("No instantiated fragment for index #" + fragmentManagerState.mAdded[i])); 
            null.mAdded = true;
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: added #" + i + ": " + null); 
            if (this.mAdded.contains(null))
              throw new IllegalStateException("Already added!"); 
            synchronized (this.mAdded) {
              this.mAdded.add(null);
              i++;
            } 
          } 
        } 
        if (fragmentManagerState.mBackStack != null) {
          this.mBackStack = new ArrayList<BackStackRecord>(fragmentManagerState.mBackStack.length);
          for (i = 0; i < fragmentManagerState.mBackStack.length; i++) {
            BackStackRecord backStackRecord = fragmentManagerState.mBackStack[i].instantiate(this);
            if (DEBUG) {
              Log.v("FragmentManager", "restoreAllState: back stack #" + i + " (index " + backStackRecord.mIndex + "): " + backStackRecord);
              PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
              backStackRecord.dump("  ", printWriter, false);
              printWriter.close();
            } 
            this.mBackStack.add(backStackRecord);
            if (backStackRecord.mIndex >= 0)
              setBackStackIndex(backStackRecord.mIndex, backStackRecord); 
          } 
        } else {
          this.mBackStack = null;
        } 
        if (fragmentManagerState.mPrimaryNavActiveIndex >= 0)
          this.mPrimaryNav = (Fragment)this.mActive.get(fragmentManagerState.mPrimaryNavActiveIndex); 
        this.mNextFragmentIndex = fragmentManagerState.mNextFragmentIndex;
        return;
      } 
    } 
  }
  
  FragmentManagerNonConfig retainNonConfig() {
    setRetaining(this.mSavedNonConfig);
    return this.mSavedNonConfig;
  }
  
  Parcelable saveAllState() {
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    this.mSavedNonConfig = null;
    if (this.mActive != null && this.mActive.size() > 0) {
      int k = this.mActive.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[k];
      int j = 0;
      int i;
      for (i = 0; i < k; i++) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          if (fragment.mIndex < 0)
            throwException(new IllegalStateException("Failure saving state: active " + fragment + " has cleared index: " + fragment.mIndex)); 
          byte b = 1;
          FragmentState fragmentState = new FragmentState(fragment);
          arrayOfFragmentState[i] = fragmentState;
          if (fragment.mState > 0 && fragmentState.mSavedFragmentState == null) {
            fragmentState.mSavedFragmentState = saveFragmentBasicState(fragment);
            if (fragment.mTarget != null) {
              if (fragment.mTarget.mIndex < 0)
                throwException(new IllegalStateException("Failure saving state: " + fragment + " has target not in fragment manager: " + fragment.mTarget)); 
              if (fragmentState.mSavedFragmentState == null)
                fragmentState.mSavedFragmentState = new Bundle(); 
              putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment.mTarget);
              if (fragment.mTargetRequestCode != 0)
                fragmentState.mSavedFragmentState.putInt("android:target_req_state", fragment.mTargetRequestCode); 
            } 
          } else {
            fragmentState.mSavedFragmentState = fragment.mSavedFragmentState;
          } 
          j = b;
          if (DEBUG) {
            Log.v("FragmentManager", "Saved state of " + fragment + ": " + fragmentState.mSavedFragmentState);
            j = b;
          } 
        } 
      } 
      if (!j) {
        if (DEBUG) {
          Log.v("FragmentManager", "saveAllState: no fragments!");
          return null;
        } 
        return null;
      } 
      int[] arrayOfInt = null;
      BackStackState[] arrayOfBackStackState2 = null;
      j = this.mAdded.size();
      if (j > 0) {
        int[] arrayOfInt1 = new int[j];
        i = 0;
        while (true) {
          arrayOfInt = arrayOfInt1;
          if (i < j) {
            arrayOfInt1[i] = ((Fragment)this.mAdded.get(i)).mIndex;
            if (arrayOfInt1[i] < 0)
              throwException(new IllegalStateException("Failure saving state: active " + this.mAdded.get(i) + " has cleared index: " + arrayOfInt1[i])); 
            if (DEBUG)
              Log.v("FragmentManager", "saveAllState: adding fragment #" + i + ": " + this.mAdded.get(i)); 
            i++;
            continue;
          } 
          break;
        } 
      } 
      BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
      if (this.mBackStack != null) {
        j = this.mBackStack.size();
        arrayOfBackStackState1 = arrayOfBackStackState2;
        if (j > 0) {
          arrayOfBackStackState2 = new BackStackState[j];
          i = 0;
          while (true) {
            arrayOfBackStackState1 = arrayOfBackStackState2;
            if (i < j) {
              arrayOfBackStackState2[i] = new BackStackState(this.mBackStack.get(i));
              if (DEBUG)
                Log.v("FragmentManager", "saveAllState: adding back stack #" + i + ": " + this.mBackStack.get(i)); 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      FragmentManagerState fragmentManagerState = new FragmentManagerState();
      fragmentManagerState.mActive = arrayOfFragmentState;
      fragmentManagerState.mAdded = arrayOfInt;
      fragmentManagerState.mBackStack = arrayOfBackStackState1;
      if (this.mPrimaryNav != null)
        fragmentManagerState.mPrimaryNavActiveIndex = this.mPrimaryNav.mIndex; 
      fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
      saveNonConfig();
      return fragmentManagerState;
    } 
    return null;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    Bundle bundle2 = null;
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    if (!this.mStateBundle.isEmpty()) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    Fragment.SavedState savedState2 = null;
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    Fragment.SavedState savedState1 = savedState2;
    if (paramFragment.mState > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView != null) {
      if (this.mStateArray == null) {
        this.mStateArray = new SparseArray();
      } else {
        this.mStateArray.clear();
      } 
      paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
      if (this.mStateArray.size() > 0) {
        paramFragment.mSavedViewState = this.mStateArray;
        this.mStateArray = null;
        return;
      } 
    } 
  }
  
  void saveNonConfig() {
    ArrayList<Fragment> arrayList4 = null;
    ArrayList<Fragment> arrayList1 = null;
    ArrayList<Fragment> arrayList3 = null;
    ArrayList<Fragment> arrayList2 = null;
    if (this.mActive != null) {
      int i = 0;
      while (true) {
        arrayList3 = arrayList2;
        arrayList4 = arrayList1;
        if (i < this.mActive.size()) {
          Fragment fragment = (Fragment)this.mActive.valueAt(i);
          arrayList4 = arrayList2;
          ArrayList<Fragment> arrayList = arrayList1;
          if (fragment != null) {
            FragmentManagerNonConfig fragmentManagerNonConfig;
            arrayList3 = arrayList1;
            if (fragment.mRetainInstance) {
              byte b;
              arrayList4 = arrayList1;
              if (arrayList1 == null)
                arrayList4 = new ArrayList(); 
              arrayList4.add(fragment);
              if (fragment.mTarget != null) {
                b = fragment.mTarget.mIndex;
              } else {
                b = -1;
              } 
              fragment.mTargetIndex = b;
              arrayList3 = arrayList4;
              if (DEBUG) {
                Log.v("FragmentManager", "retainNonConfig: keeping retained " + fragment);
                arrayList3 = arrayList4;
              } 
            } 
            if (fragment.mChildFragmentManager != null) {
              fragment.mChildFragmentManager.saveNonConfig();
              fragmentManagerNonConfig = fragment.mChildFragmentManager.mSavedNonConfig;
            } else {
              fragmentManagerNonConfig = ((Fragment)fragmentManagerNonConfig).mChildNonConfig;
            } 
            arrayList1 = arrayList2;
            if (arrayList2 == null) {
              arrayList1 = arrayList2;
              if (fragmentManagerNonConfig != null) {
                arrayList2 = new ArrayList<Fragment>(this.mActive.size());
                int j = 0;
                while (true) {
                  arrayList1 = arrayList2;
                  if (j < i) {
                    arrayList2.add(null);
                    j++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            arrayList4 = arrayList1;
            arrayList = arrayList3;
            if (arrayList1 != null) {
              arrayList1.add(fragmentManagerNonConfig);
              arrayList = arrayList3;
              arrayList4 = arrayList1;
            } 
          } 
          i++;
          arrayList2 = arrayList4;
          arrayList1 = arrayList;
          continue;
        } 
        break;
      } 
    } 
    if (arrayList4 == null && arrayList3 == null) {
      this.mSavedNonConfig = null;
      return;
    } 
    this.mSavedNonConfig = new FragmentManagerNonConfig(arrayList4, (List)arrayList3);
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 93
    //   38: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 80
    //   44: ldc 'FragmentManager'
    //   46: new java/lang/StringBuilder
    //   49: dup
    //   50: invokespecial <init> : ()V
    //   53: ldc_w 'Setting back stack index '
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: iload_1
    //   60: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   63: ldc_w ' to '
    //   66: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   69: aload_2
    //   70: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   73: invokevirtual toString : ()Ljava/lang/String;
    //   76: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   79: pop
    //   80: aload_0
    //   81: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   84: iload_1
    //   85: aload_2
    //   86: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   89: pop
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: iload_3
    //   94: iload_1
    //   95: if_icmpge -> 176
    //   98: aload_0
    //   99: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   102: aconst_null
    //   103: invokevirtual add : (Ljava/lang/Object;)Z
    //   106: pop
    //   107: aload_0
    //   108: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   111: ifnonnull -> 125
    //   114: aload_0
    //   115: new java/util/ArrayList
    //   118: dup
    //   119: invokespecial <init> : ()V
    //   122: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   125: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   128: ifeq -> 157
    //   131: ldc 'FragmentManager'
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: ldc_w 'Adding available back stack index '
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: iload_3
    //   147: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   150: invokevirtual toString : ()Ljava/lang/String;
    //   153: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   156: pop
    //   157: aload_0
    //   158: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   161: iload_3
    //   162: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   165: invokevirtual add : (Ljava/lang/Object;)Z
    //   168: pop
    //   169: iload_3
    //   170: iconst_1
    //   171: iadd
    //   172: istore_3
    //   173: goto -> 93
    //   176: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   179: ifeq -> 218
    //   182: ldc 'FragmentManager'
    //   184: new java/lang/StringBuilder
    //   187: dup
    //   188: invokespecial <init> : ()V
    //   191: ldc_w 'Adding back stack index '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: iload_1
    //   198: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   201: ldc_w ' with '
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: aload_2
    //   208: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   211: invokevirtual toString : ()Ljava/lang/String;
    //   214: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   217: pop
    //   218: aload_0
    //   219: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   222: aload_2
    //   223: invokevirtual add : (Ljava/lang/Object;)Z
    //   226: pop
    //   227: goto -> 90
    //   230: astore_2
    //   231: aload_0
    //   232: monitorexit
    //   233: aload_2
    //   234: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	230	finally
    //   20	29	230	finally
    //   38	80	230	finally
    //   80	90	230	finally
    //   90	92	230	finally
    //   98	125	230	finally
    //   125	157	230	finally
    //   157	169	230	finally
    //   176	218	230	finally
    //   218	227	230	finally
    //   231	233	230	finally
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment != null && (this.mActive.get(paramFragment.mIndex) != paramFragment || (paramFragment.mHost != null && paramFragment.getFragmentManager() != this)))
      throw new IllegalArgumentException("Fragment " + paramFragment + " is not an active fragment of FragmentManager " + this); 
    this.mPrimaryNav = paramFragment;
  }
  
  public void showFragment(Fragment paramFragment) {
    boolean bool = false;
    if (DEBUG)
      Log.v("FragmentManager", "show: " + paramFragment); 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      if (!paramFragment.mHiddenChanged)
        bool = true; 
      paramFragment.mHiddenChanged = bool;
    } 
  }
  
  void startPendingDeferredFragments() {
    if (this.mActive != null) {
      int i = 0;
      while (true) {
        if (i < this.mActive.size()) {
          Fragment fragment = (Fragment)this.mActive.valueAt(i);
          if (fragment != null)
            performPendingDeferredStart(fragment); 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    if (this.mParent != null) {
      DebugUtils.buildShortClassTag(this.mParent, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    } 
    DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore #4
    //   6: aload #4
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore_2
    //   11: aload_0
    //   12: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   15: invokevirtual size : ()I
    //   18: istore_3
    //   19: iload_2
    //   20: iload_3
    //   21: if_icmpge -> 51
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_2
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast android/support/v4/util/Pair
    //   35: getfield first : Ljava/lang/Object;
    //   38: aload_1
    //   39: if_acmpne -> 61
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_2
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: aload #4
    //   53: monitorexit
    //   54: return
    //   55: astore_1
    //   56: aload #4
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    //   61: iload_2
    //   62: iconst_1
    //   63: iadd
    //   64: istore_2
    //   65: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   11	19	55	finally
    //   24	51	55	finally
    //   51	54	55	finally
    //   56	59	55	finally
  }
  
  private static class AnimateOnHWLayerIfNeededListener extends AnimationListenerWrapper {
    View mView;
    
    AnimateOnHWLayerIfNeededListener(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.mView = param1View;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (ViewCompat.isAttachedToWindow(this.mView) || Build.VERSION.SDK_INT >= 24) {
        this.mView.post(new Runnable() {
              public void run() {
                FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.this.mView.setLayerType(0, null);
              }
            });
      } else {
        this.mView.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$0.mView.setLayerType(0, null);
    }
  }
  
  private static class AnimationListenerWrapper implements Animation.AnimationListener {
    private final Animation.AnimationListener mWrapped;
    
    private AnimationListenerWrapper(Animation.AnimationListener param1AnimationListener) {
      this.mWrapped = param1AnimationListener;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationEnd(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationRepeat(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationRepeat(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationStart(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationStart(param1Animation); 
    }
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    private AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator == null)
        throw new IllegalStateException("Animator cannot be null"); 
    }
    
    private AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation == null)
        throw new IllegalStateException("Animation cannot be null"); 
    }
  }
  
  private static class AnimatorOnHWLayerIfNeededListener extends AnimatorListenerAdapter {
    View mView;
    
    AnimatorOnHWLayerIfNeededListener(View param1View) {
      this.mView = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.mView.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.mView.setLayerType(2, null);
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      if (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null) {
        FragmentManager fragmentManager = FragmentManagerImpl.this.mPrimaryNav.peekChildFragmentManager();
        if (fragmentManager != null && fragmentManager.popBackStackImmediate())
          return false; 
      } 
      return FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    private final boolean mIsBack;
    
    private int mNumPostponed;
    
    private final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      boolean bool1;
      boolean bool2 = false;
      if (this.mNumPostponed > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int j = fragmentManagerImpl.mAdded.size();
      for (int i = 0; i < j; i++) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(i);
        fragment.setOnStartEnterTransitionListener(null);
        if (bool1 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
      } 
      fragmentManagerImpl = this.mRecord.mManager;
      BackStackRecord backStackRecord = this.mRecord;
      boolean bool = this.mIsBack;
      if (!bool1)
        bool2 = true; 
      fragmentManagerImpl.completeExecute(backStackRecord, bool, bool2, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      this.mNumPostponed--;
      if (this.mNumPostponed != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */