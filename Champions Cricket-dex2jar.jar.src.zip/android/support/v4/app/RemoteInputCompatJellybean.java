package android.support.v4.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

@RequiresApi(16)
class RemoteInputCompatJellybean {
  private static final String EXTRA_DATA_TYPE_RESULTS_DATA = "android.remoteinput.dataTypeResultsData";
  
  private static final String KEY_ALLOWED_DATA_TYPES = "allowedDataTypes";
  
  private static final String KEY_ALLOW_FREE_FORM_INPUT = "allowFreeFormInput";
  
  private static final String KEY_CHOICES = "choices";
  
  private static final String KEY_EXTRAS = "extras";
  
  private static final String KEY_LABEL = "label";
  
  private static final String KEY_RESULT_KEY = "resultKey";
  
  public static void addDataResultToIntent(RemoteInput paramRemoteInput, Intent paramIntent, Map<String, Uri> paramMap) {
    Intent intent2 = getClipDataIntentFromIntent(paramIntent);
    Intent intent1 = intent2;
    if (intent2 == null)
      intent1 = new Intent(); 
    for (Map.Entry<String, Uri> entry : paramMap.entrySet()) {
      String str = (String)entry.getKey();
      Uri uri = (Uri)entry.getValue();
      if (str != null) {
        Bundle bundle2 = intent1.getBundleExtra(getExtraResultsKeyForData(str));
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle1.putString(paramRemoteInput.getResultKey(), uri.toString());
        intent1.putExtra(getExtraResultsKeyForData(str), bundle1);
      } 
    } 
    paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", intent1));
  }
  
  static void addResultsToIntent(RemoteInputCompatBase.RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle) {
    Intent intent2 = getClipDataIntentFromIntent(paramIntent);
    Intent intent1 = intent2;
    if (intent2 == null)
      intent1 = new Intent(); 
    Bundle bundle2 = intent1.getBundleExtra("android.remoteinput.resultsData");
    Bundle bundle1 = bundle2;
    if (bundle2 == null)
      bundle1 = new Bundle(); 
    int j = paramArrayOfRemoteInput.length;
    for (int i = 0; i < j; i++) {
      RemoteInputCompatBase.RemoteInput remoteInput = paramArrayOfRemoteInput[i];
      Object object = paramBundle.get(remoteInput.getResultKey());
      if (object instanceof CharSequence)
        bundle1.putCharSequence(remoteInput.getResultKey(), (CharSequence)object); 
    } 
    intent1.putExtra("android.remoteinput.resultsData", bundle1);
    paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", intent1));
  }
  
  static RemoteInputCompatBase.RemoteInput fromBundle(Bundle paramBundle, RemoteInputCompatBase.RemoteInput.Factory paramFactory) {
    ArrayList arrayList = paramBundle.getStringArrayList("allowedDataTypes");
    HashSet<String> hashSet = new HashSet();
    if (arrayList != null) {
      Iterator<String> iterator = arrayList.iterator();
      while (iterator.hasNext())
        hashSet.add(iterator.next()); 
    } 
    return paramFactory.build(paramBundle.getString("resultKey"), paramBundle.getCharSequence("label"), paramBundle.getCharSequenceArray("choices"), paramBundle.getBoolean("allowFreeFormInput"), paramBundle.getBundle("extras"), hashSet);
  }
  
  static RemoteInputCompatBase.RemoteInput[] fromBundleArray(Bundle[] paramArrayOfBundle, RemoteInputCompatBase.RemoteInput.Factory paramFactory) {
    if (paramArrayOfBundle == null)
      return null; 
    RemoteInputCompatBase.RemoteInput[] arrayOfRemoteInput = paramFactory.newArray(paramArrayOfBundle.length);
    int i = 0;
    while (true) {
      RemoteInputCompatBase.RemoteInput[] arrayOfRemoteInput1 = arrayOfRemoteInput;
      if (i < paramArrayOfBundle.length) {
        arrayOfRemoteInput[i] = fromBundle(paramArrayOfBundle[i], paramFactory);
        i++;
        continue;
      } 
      return arrayOfRemoteInput1;
    } 
  }
  
  private static Intent getClipDataIntentFromIntent(Intent paramIntent) {
    ClipData clipData = paramIntent.getClipData();
    if (clipData != null) {
      ClipDescription clipDescription = clipData.getDescription();
      if (clipDescription.hasMimeType("text/vnd.android.intent") && clipDescription.getLabel().equals("android.remoteinput.results"))
        return clipData.getItemAt(0).getIntent(); 
    } 
    return null;
  }
  
  static Map<String, Uri> getDataResultsFromIntent(Intent paramIntent, String paramString) {
    paramIntent = getClipDataIntentFromIntent(paramIntent);
    if (paramIntent == null)
      return null; 
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    for (String str : paramIntent.getExtras().keySet()) {
      if (str.startsWith("android.remoteinput.dataTypeResultsData")) {
        String str1 = str.substring("android.remoteinput.dataTypeResultsData".length());
        if (str1 != null && !str1.isEmpty()) {
          str = paramIntent.getBundleExtra(str).getString(paramString);
          if (str != null && !str.isEmpty())
            hashMap2.put(str1, Uri.parse(str)); 
        } 
      } 
    } 
    HashMap<Object, Object> hashMap1 = hashMap2;
    if (hashMap2.isEmpty())
      hashMap1 = null; 
    return (Map)hashMap1;
  }
  
  private static String getExtraResultsKeyForData(String paramString) {
    return "android.remoteinput.dataTypeResultsData" + paramString;
  }
  
  static Bundle getResultsFromIntent(Intent paramIntent) {
    paramIntent = getClipDataIntentFromIntent(paramIntent);
    return (paramIntent == null) ? null : (Bundle)paramIntent.getExtras().getParcelable("android.remoteinput.resultsData");
  }
  
  static Bundle toBundle(RemoteInputCompatBase.RemoteInput paramRemoteInput) {
    Bundle bundle = new Bundle();
    bundle.putString("resultKey", paramRemoteInput.getResultKey());
    bundle.putCharSequence("label", paramRemoteInput.getLabel());
    bundle.putCharSequenceArray("choices", paramRemoteInput.getChoices());
    bundle.putBoolean("allowFreeFormInput", paramRemoteInput.getAllowFreeFormInput());
    bundle.putBundle("extras", paramRemoteInput.getExtras());
    Set<String> set = paramRemoteInput.getAllowedDataTypes();
    if (set != null && !set.isEmpty()) {
      ArrayList<String> arrayList = new ArrayList(set.size());
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        arrayList.add(iterator.next()); 
      bundle.putStringArrayList("allowedDataTypes", arrayList);
    } 
    return bundle;
  }
  
  static Bundle[] toBundleArray(RemoteInputCompatBase.RemoteInput[] paramArrayOfRemoteInput) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfRemoteInput.length];
    int i = 0;
    while (true) {
      Bundle[] arrayOfBundle1 = arrayOfBundle;
      if (i < paramArrayOfRemoteInput.length) {
        arrayOfBundle[i] = toBundle(paramArrayOfRemoteInput[i]);
        i++;
        continue;
      } 
      return arrayOfBundle1;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\app\RemoteInputCompatJellybean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */