package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

@Deprecated
public interface LayoutInflaterFactory {
  View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet);
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\view\LayoutInflaterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */