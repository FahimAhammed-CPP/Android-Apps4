package android.support.v4.view.accessibility;

import android.support.annotation.RequiresApi;
import android.view.accessibility.AccessibilityNodeInfo;

@RequiresApi(19)
class AccessibilityNodeInfoCompatKitKat {
  static class RangeInfo {
    static float getCurrent(Object param1Object) {
      return ((AccessibilityNodeInfo.RangeInfo)param1Object).getCurrent();
    }
    
    static float getMax(Object param1Object) {
      return ((AccessibilityNodeInfo.RangeInfo)param1Object).getMax();
    }
    
    static float getMin(Object param1Object) {
      return ((AccessibilityNodeInfo.RangeInfo)param1Object).getMin();
    }
    
    static int getType(Object param1Object) {
      return ((AccessibilityNodeInfo.RangeInfo)param1Object).getType();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\view\accessibility\AccessibilityNodeInfoCompatKitKat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */