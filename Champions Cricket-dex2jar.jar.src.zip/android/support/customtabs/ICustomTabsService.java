package android.support.customtabs;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;

public interface ICustomTabsService extends IInterface {
  Bundle extraCommand(String paramString, Bundle paramBundle) throws RemoteException;
  
  boolean mayLaunchUrl(ICustomTabsCallback paramICustomTabsCallback, Uri paramUri, Bundle paramBundle, List<Bundle> paramList) throws RemoteException;
  
  boolean newSession(ICustomTabsCallback paramICustomTabsCallback) throws RemoteException;
  
  int postMessage(ICustomTabsCallback paramICustomTabsCallback, String paramString, Bundle paramBundle) throws RemoteException;
  
  boolean requestPostMessageChannel(ICustomTabsCallback paramICustomTabsCallback, Uri paramUri) throws RemoteException;
  
  boolean updateVisuals(ICustomTabsCallback paramICustomTabsCallback, Bundle paramBundle) throws RemoteException;
  
  boolean warmup(long paramLong) throws RemoteException;
  
  public static abstract class Stub extends Binder implements ICustomTabsService {
    private static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsService";
    
    static final int TRANSACTION_extraCommand = 5;
    
    static final int TRANSACTION_mayLaunchUrl = 4;
    
    static final int TRANSACTION_newSession = 3;
    
    static final int TRANSACTION_postMessage = 8;
    
    static final int TRANSACTION_requestPostMessageChannel = 7;
    
    static final int TRANSACTION_updateVisuals = 6;
    
    static final int TRANSACTION_warmup = 2;
    
    public Stub() {
      attachInterface(this, "android.support.customtabs.ICustomTabsService");
    }
    
    public static ICustomTabsService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.ICustomTabsService");
      return (iInterface != null && iInterface instanceof ICustomTabsService) ? (ICustomTabsService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      boolean bool;
      Uri uri;
      String str1;
      Bundle bundle2;
      ICustomTabsCallback iCustomTabsCallback2;
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      boolean bool5 = false;
      boolean bool1 = false;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("android.support.customtabs.ICustomTabsService");
          return true;
        case 2:
          param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          bool = warmup(param1Parcel1.readLong());
          param1Parcel2.writeNoException();
          param1Int1 = bool1;
          if (bool)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 3:
          param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          bool = newSession(ICustomTabsCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          param1Int1 = bool2;
          if (bool)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 4:
          param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          iCustomTabsCallback2 = ICustomTabsCallback.Stub.asInterface(param1Parcel1.readStrongBinder());
          if (param1Parcel1.readInt() != 0) {
            uri = (Uri)Uri.CREATOR.createFromParcel(param1Parcel1);
          } else {
            uri = null;
          } 
          if (param1Parcel1.readInt() != 0) {
            bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1);
          } else {
            bundle2 = null;
          } 
          bool = mayLaunchUrl(iCustomTabsCallback2, uri, bundle2, param1Parcel1.createTypedArrayList(Bundle.CREATOR));
          param1Parcel2.writeNoException();
          param1Int1 = bool3;
          if (bool)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 5:
          param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          str1 = param1Parcel1.readString();
          if (param1Parcel1.readInt() != 0) {
            Bundle bundle = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1);
          } else {
            param1Parcel1 = null;
          } 
          bundle1 = extraCommand(str1, (Bundle)param1Parcel1);
          param1Parcel2.writeNoException();
          if (bundle1 != null) {
            param1Parcel2.writeInt(1);
            bundle1.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        case 6:
          bundle1.enforceInterface("android.support.customtabs.ICustomTabsService");
          iCustomTabsCallback1 = ICustomTabsCallback.Stub.asInterface(bundle1.readStrongBinder());
          if (bundle1.readInt() != 0) {
            bundle1 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1);
          } else {
            bundle1 = null;
          } 
          bool = updateVisuals(iCustomTabsCallback1, bundle1);
          param1Parcel2.writeNoException();
          param1Int1 = bool4;
          if (bool)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 7:
          bundle1.enforceInterface("android.support.customtabs.ICustomTabsService");
          iCustomTabsCallback1 = ICustomTabsCallback.Stub.asInterface(bundle1.readStrongBinder());
          if (bundle1.readInt() != 0) {
            Uri uri1 = (Uri)Uri.CREATOR.createFromParcel((Parcel)bundle1);
          } else {
            bundle1 = null;
          } 
          bool = requestPostMessageChannel(iCustomTabsCallback1, (Uri)bundle1);
          param1Parcel2.writeNoException();
          param1Int1 = bool5;
          if (bool)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 8:
          break;
      } 
      bundle1.enforceInterface("android.support.customtabs.ICustomTabsService");
      ICustomTabsCallback iCustomTabsCallback1 = ICustomTabsCallback.Stub.asInterface(bundle1.readStrongBinder());
      String str2 = bundle1.readString();
      if (bundle1.readInt() != 0) {
        bundle1 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1);
        param1Int1 = postMessage(iCustomTabsCallback1, str2, bundle1);
        param1Parcel2.writeNoException();
        param1Parcel2.writeInt(param1Int1);
        return true;
      } 
      Bundle bundle1 = null;
      param1Int1 = postMessage(iCustomTabsCallback1, str2, bundle1);
      param1Parcel2.writeNoException();
      param1Parcel2.writeInt(param1Int1);
      return true;
    }
    
    private static class Proxy implements ICustomTabsService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public Bundle extraCommand(String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          parcel1.writeString(param2String);
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(5, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2String = null;
        parcel2.recycle();
        parcel1.recycle();
        return (Bundle)param2String;
      }
      
      public String getInterfaceDescriptor() {
        return "android.support.customtabs.ICustomTabsService";
      }
      
      public boolean mayLaunchUrl(ICustomTabsCallback param2ICustomTabsCallback, Uri param2Uri, Bundle param2Bundle, List<Bundle> param2List) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          if (param2ICustomTabsCallback != null) {
            IBinder iBinder = param2ICustomTabsCallback.asBinder();
          } else {
            param2ICustomTabsCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ICustomTabsCallback);
          if (param2Uri != null) {
            parcel1.writeInt(1);
            param2Uri.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeTypedList(param2List);
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i == 0)
            bool = false; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean newSession(ICustomTabsCallback param2ICustomTabsCallback) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          if (param2ICustomTabsCallback != null) {
            IBinder iBinder = param2ICustomTabsCallback.asBinder();
          } else {
            param2ICustomTabsCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ICustomTabsCallback);
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int postMessage(ICustomTabsCallback param2ICustomTabsCallback, String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          if (param2ICustomTabsCallback != null) {
            IBinder iBinder = param2ICustomTabsCallback.asBinder();
          } else {
            param2ICustomTabsCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ICustomTabsCallback);
          parcel1.writeString(param2String);
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
            this.mRemote.transact(8, parcel1, parcel2, 0);
            parcel2.readException();
            return parcel2.readInt();
          } 
          parcel1.writeInt(0);
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean requestPostMessageChannel(ICustomTabsCallback param2ICustomTabsCallback, Uri param2Uri) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          if (param2ICustomTabsCallback != null) {
            IBinder iBinder = param2ICustomTabsCallback.asBinder();
          } else {
            param2ICustomTabsCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ICustomTabsCallback);
          if (param2Uri != null) {
            parcel1.writeInt(1);
            param2Uri.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i == 0)
            bool = false; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean updateVisuals(ICustomTabsCallback param2ICustomTabsCallback, Bundle param2Bundle) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          if (param2ICustomTabsCallback != null) {
            IBinder iBinder = param2ICustomTabsCallback.asBinder();
          } else {
            param2ICustomTabsCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ICustomTabsCallback);
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i == 0)
            bool = false; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean warmup(long param2Long) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          parcel1.writeLong(param2Long);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ICustomTabsService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public Bundle extraCommand(String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        parcel1.writeString(param1String);
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(5, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1String = null;
      parcel2.recycle();
      parcel1.recycle();
      return (Bundle)param1String;
    }
    
    public String getInterfaceDescriptor() {
      return "android.support.customtabs.ICustomTabsService";
    }
    
    public boolean mayLaunchUrl(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri, Bundle param1Bundle, List<Bundle> param1List) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        if (param1ICustomTabsCallback != null) {
          IBinder iBinder = param1ICustomTabsCallback.asBinder();
        } else {
          param1ICustomTabsCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ICustomTabsCallback);
        if (param1Uri != null) {
          parcel1.writeInt(1);
          param1Uri.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeTypedList(param1List);
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean newSession(ICustomTabsCallback param1ICustomTabsCallback) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        if (param1ICustomTabsCallback != null) {
          IBinder iBinder = param1ICustomTabsCallback.asBinder();
        } else {
          param1ICustomTabsCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ICustomTabsCallback);
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int postMessage(ICustomTabsCallback param1ICustomTabsCallback, String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        if (param1ICustomTabsCallback != null) {
          IBinder iBinder = param1ICustomTabsCallback.asBinder();
        } else {
          param1ICustomTabsCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ICustomTabsCallback);
        parcel1.writeString(param1String);
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } 
        parcel1.writeInt(0);
        this.mRemote.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean requestPostMessageChannel(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        if (param1ICustomTabsCallback != null) {
          IBinder iBinder = param1ICustomTabsCallback.asBinder();
        } else {
          param1ICustomTabsCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ICustomTabsCallback);
        if (param1Uri != null) {
          parcel1.writeInt(1);
          param1Uri.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean updateVisuals(ICustomTabsCallback param1ICustomTabsCallback, Bundle param1Bundle) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        if (param1ICustomTabsCallback != null) {
          IBinder iBinder = param1ICustomTabsCallback.asBinder();
        } else {
          param1ICustomTabsCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ICustomTabsCallback);
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean warmup(long param1Long) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
        parcel1.writeLong(param1Long);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\customtabs\ICustomTabsService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */