package android.arch.lifecycle;

@Deprecated
public interface LifecycleRegistryOwner extends LifecycleOwner {
  LifecycleRegistry getLifecycle();
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\arch\lifecycle\LifecycleRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */