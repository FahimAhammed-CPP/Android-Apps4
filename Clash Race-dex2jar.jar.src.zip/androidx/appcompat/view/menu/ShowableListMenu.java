package androidx.appcompat.view.menu;

import android.widget.ListView;

public interface ShowableListMenu {
  void dismiss();
  
  ListView getListView();
  
  boolean isShowing();
  
  void show();
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\appcompat\view\menu\ShowableListMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */