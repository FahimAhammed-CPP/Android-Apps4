package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.R;
import androidx.appcompat.view.ActionBarPolicy;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.BaseMenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.view.menu.ShowableListMenu;
import androidx.appcompat.view.menu.SubMenuBuilder;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ActionProvider;
import java.util.ArrayList;

class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  ActionButtonSubmenu mActionButtonPopup;
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  int mOpenSubMenuId;
  
  OverflowMenuButton mOverflowButton;
  
  OverflowPopup mOverflowPopup;
  
  private Drawable mPendingOverflowIcon;
  
  private boolean mPendingOverflowIconSet;
  
  private ActionMenuPopupCallback mPopupCallback;
  
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  
  OpenOverflowRunnable mPostedOpenRunnable;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.mMenuView;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof MenuView.ItemView && ((MenuView.ItemView)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)paramItemView;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.mPopupCallback == null)
      this.mPopupCallback = new ActionMenuPopupCallback(); 
    actionMenuItemView.setPopupCallback(this.mPopupCallback);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    // Byte code:
    //   0: aload_0
    //   1: astore #18
    //   3: aload #18
    //   5: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   8: ifnull -> 31
    //   11: aload #18
    //   13: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   16: invokevirtual getVisibleItems : ()Ljava/util/ArrayList;
    //   19: astore #17
    //   21: aload #17
    //   23: invokevirtual size : ()I
    //   26: istore #4
    //   28: goto -> 37
    //   31: aconst_null
    //   32: astore #17
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #18
    //   39: getfield mMaxItems : I
    //   42: istore_1
    //   43: aload #18
    //   45: getfield mActionItemWidthLimit : I
    //   48: istore #10
    //   50: iconst_0
    //   51: iconst_0
    //   52: invokestatic makeMeasureSpec : (II)I
    //   55: istore #11
    //   57: aload #18
    //   59: getfield mMenuView : Landroidx/appcompat/view/menu/MenuView;
    //   62: checkcast android/view/ViewGroup
    //   65: astore #19
    //   67: iconst_0
    //   68: istore_2
    //   69: iconst_0
    //   70: istore #6
    //   72: iconst_0
    //   73: istore_3
    //   74: iconst_0
    //   75: istore #5
    //   77: iload_2
    //   78: iload #4
    //   80: if_icmpge -> 164
    //   83: aload #17
    //   85: iload_2
    //   86: invokevirtual get : (I)Ljava/lang/Object;
    //   89: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   92: astore #20
    //   94: aload #20
    //   96: invokevirtual requiresActionButton : ()Z
    //   99: ifeq -> 109
    //   102: iload_3
    //   103: iconst_1
    //   104: iadd
    //   105: istore_3
    //   106: goto -> 129
    //   109: aload #20
    //   111: invokevirtual requestsActionButton : ()Z
    //   114: ifeq -> 126
    //   117: iload #5
    //   119: iconst_1
    //   120: iadd
    //   121: istore #5
    //   123: goto -> 129
    //   126: iconst_1
    //   127: istore #6
    //   129: iload_1
    //   130: istore #7
    //   132: aload #18
    //   134: getfield mExpandedActionViewsExclusive : Z
    //   137: ifeq -> 154
    //   140: iload_1
    //   141: istore #7
    //   143: aload #20
    //   145: invokevirtual isActionViewExpanded : ()Z
    //   148: ifeq -> 154
    //   151: iconst_0
    //   152: istore #7
    //   154: iload_2
    //   155: iconst_1
    //   156: iadd
    //   157: istore_2
    //   158: iload #7
    //   160: istore_1
    //   161: goto -> 77
    //   164: iload_1
    //   165: istore_2
    //   166: aload #18
    //   168: getfield mReserveOverflow : Z
    //   171: ifeq -> 193
    //   174: iload #6
    //   176: ifne -> 189
    //   179: iload_1
    //   180: istore_2
    //   181: iload #5
    //   183: iload_3
    //   184: iadd
    //   185: iload_1
    //   186: if_icmple -> 193
    //   189: iload_1
    //   190: iconst_1
    //   191: isub
    //   192: istore_2
    //   193: iload_2
    //   194: iload_3
    //   195: isub
    //   196: istore_1
    //   197: aload #18
    //   199: getfield mActionButtonGroups : Landroid/util/SparseBooleanArray;
    //   202: astore #20
    //   204: aload #20
    //   206: invokevirtual clear : ()V
    //   209: aload #18
    //   211: getfield mStrictWidthLimit : Z
    //   214: ifeq -> 241
    //   217: aload #18
    //   219: getfield mMinCellSize : I
    //   222: istore_2
    //   223: iload #10
    //   225: iload_2
    //   226: idiv
    //   227: istore_3
    //   228: iload_2
    //   229: iload #10
    //   231: iload_2
    //   232: irem
    //   233: iload_3
    //   234: idiv
    //   235: iadd
    //   236: istore #8
    //   238: goto -> 246
    //   241: iconst_0
    //   242: istore #8
    //   244: iconst_0
    //   245: istore_3
    //   246: iconst_0
    //   247: istore #9
    //   249: iconst_0
    //   250: istore_2
    //   251: iload #10
    //   253: istore #6
    //   255: iload #4
    //   257: istore #10
    //   259: aload_0
    //   260: astore #18
    //   262: iload #9
    //   264: iload #10
    //   266: if_icmpge -> 744
    //   269: aload #17
    //   271: iload #9
    //   273: invokevirtual get : (I)Ljava/lang/Object;
    //   276: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   279: astore #21
    //   281: aload #21
    //   283: invokevirtual requiresActionButton : ()Z
    //   286: ifeq -> 393
    //   289: aload #18
    //   291: aload #21
    //   293: aconst_null
    //   294: aload #19
    //   296: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   299: astore #22
    //   301: aload #18
    //   303: getfield mStrictWidthLimit : Z
    //   306: ifeq -> 326
    //   309: iload_3
    //   310: aload #22
    //   312: iload #8
    //   314: iload_3
    //   315: iload #11
    //   317: iconst_0
    //   318: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   321: isub
    //   322: istore_3
    //   323: goto -> 335
    //   326: aload #22
    //   328: iload #11
    //   330: iload #11
    //   332: invokevirtual measure : (II)V
    //   335: aload #22
    //   337: invokevirtual getMeasuredWidth : ()I
    //   340: istore #5
    //   342: iload #6
    //   344: iload #5
    //   346: isub
    //   347: istore #7
    //   349: iload_2
    //   350: istore #4
    //   352: iload_2
    //   353: ifne -> 360
    //   356: iload #5
    //   358: istore #4
    //   360: aload #21
    //   362: invokevirtual getGroupId : ()I
    //   365: istore_2
    //   366: iload_2
    //   367: ifeq -> 377
    //   370: aload #20
    //   372: iload_2
    //   373: iconst_1
    //   374: invokevirtual put : (IZ)V
    //   377: aload #21
    //   379: iconst_1
    //   380: invokevirtual setIsActionButton : (Z)V
    //   383: iload #7
    //   385: istore #6
    //   387: iload #4
    //   389: istore_2
    //   390: goto -> 735
    //   393: aload #21
    //   395: invokevirtual requestsActionButton : ()Z
    //   398: ifeq -> 729
    //   401: aload #21
    //   403: invokevirtual getGroupId : ()I
    //   406: istore #12
    //   408: aload #20
    //   410: iload #12
    //   412: invokevirtual get : (I)Z
    //   415: istore #16
    //   417: iload_1
    //   418: ifgt -> 426
    //   421: iload #16
    //   423: ifeq -> 449
    //   426: iload #6
    //   428: ifle -> 449
    //   431: aload #18
    //   433: getfield mStrictWidthLimit : Z
    //   436: ifeq -> 443
    //   439: iload_3
    //   440: ifle -> 449
    //   443: iconst_1
    //   444: istore #13
    //   446: goto -> 452
    //   449: iconst_0
    //   450: istore #13
    //   452: iload #13
    //   454: istore #14
    //   456: iload #13
    //   458: istore #15
    //   460: iload #6
    //   462: istore #7
    //   464: iload_3
    //   465: istore #5
    //   467: iload_2
    //   468: istore #4
    //   470: iload #13
    //   472: ifeq -> 605
    //   475: aload #18
    //   477: aload #21
    //   479: aconst_null
    //   480: aload #19
    //   482: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   485: astore #22
    //   487: aload #18
    //   489: getfield mStrictWidthLimit : Z
    //   492: ifeq -> 531
    //   495: aload #22
    //   497: iload #8
    //   499: iload_3
    //   500: iload #11
    //   502: iconst_0
    //   503: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   506: istore #5
    //   508: iload_3
    //   509: iload #5
    //   511: isub
    //   512: istore #4
    //   514: iload #4
    //   516: istore_3
    //   517: iload #5
    //   519: ifne -> 540
    //   522: iconst_0
    //   523: istore #14
    //   525: iload #4
    //   527: istore_3
    //   528: goto -> 540
    //   531: aload #22
    //   533: iload #11
    //   535: iload #11
    //   537: invokevirtual measure : (II)V
    //   540: aload #22
    //   542: invokevirtual getMeasuredWidth : ()I
    //   545: istore #5
    //   547: iload #6
    //   549: iload #5
    //   551: isub
    //   552: istore #7
    //   554: iload_2
    //   555: istore #4
    //   557: iload_2
    //   558: ifne -> 565
    //   561: iload #5
    //   563: istore #4
    //   565: aload #18
    //   567: getfield mStrictWidthLimit : Z
    //   570: ifeq -> 581
    //   573: iload #7
    //   575: iflt -> 594
    //   578: goto -> 589
    //   581: iload #7
    //   583: iload #4
    //   585: iadd
    //   586: ifle -> 594
    //   589: iconst_1
    //   590: istore_2
    //   591: goto -> 596
    //   594: iconst_0
    //   595: istore_2
    //   596: iload #14
    //   598: iload_2
    //   599: iand
    //   600: istore #15
    //   602: iload_3
    //   603: istore #5
    //   605: iload #15
    //   607: ifeq -> 628
    //   610: iload #12
    //   612: ifeq -> 628
    //   615: aload #20
    //   617: iload #12
    //   619: iconst_1
    //   620: invokevirtual put : (IZ)V
    //   623: iload_1
    //   624: istore_2
    //   625: goto -> 705
    //   628: iload_1
    //   629: istore_2
    //   630: iload #16
    //   632: ifeq -> 705
    //   635: aload #20
    //   637: iload #12
    //   639: iconst_0
    //   640: invokevirtual put : (IZ)V
    //   643: iconst_0
    //   644: istore_3
    //   645: iload_1
    //   646: istore_2
    //   647: iload_3
    //   648: iload #9
    //   650: if_icmpge -> 705
    //   653: aload #17
    //   655: iload_3
    //   656: invokevirtual get : (I)Ljava/lang/Object;
    //   659: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   662: astore #18
    //   664: iload_1
    //   665: istore_2
    //   666: aload #18
    //   668: invokevirtual getGroupId : ()I
    //   671: iload #12
    //   673: if_icmpne -> 696
    //   676: iload_1
    //   677: istore_2
    //   678: aload #18
    //   680: invokevirtual isActionButton : ()Z
    //   683: ifeq -> 690
    //   686: iload_1
    //   687: iconst_1
    //   688: iadd
    //   689: istore_2
    //   690: aload #18
    //   692: iconst_0
    //   693: invokevirtual setIsActionButton : (Z)V
    //   696: iload_3
    //   697: iconst_1
    //   698: iadd
    //   699: istore_3
    //   700: iload_2
    //   701: istore_1
    //   702: goto -> 645
    //   705: iload_2
    //   706: istore_1
    //   707: iload #15
    //   709: ifeq -> 716
    //   712: iload_2
    //   713: iconst_1
    //   714: isub
    //   715: istore_1
    //   716: aload #21
    //   718: iload #15
    //   720: invokevirtual setIsActionButton : (Z)V
    //   723: iload #5
    //   725: istore_3
    //   726: goto -> 383
    //   729: aload #21
    //   731: iconst_0
    //   732: invokevirtual setIsActionButton : (Z)V
    //   735: iload #9
    //   737: iconst_1
    //   738: iadd
    //   739: istore #9
    //   741: goto -> 259
    //   744: iconst_1
    //   745: ireturn
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView())
      view = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup); 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView2 = this.mMenuView;
    MenuView menuView1 = super.getMenuView(paramViewGroup);
    if (menuView2 != menuView1)
      ((ActionMenuView)menuView1).setPresenter(this); 
    return menuView1;
  }
  
  public Drawable getOverflowIcon() {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    return (overflowMenuButton != null) ? overflowMenuButton.getDrawable() : (this.mPendingOverflowIconSet ? this.mPendingOverflowIcon : null);
  }
  
  public boolean hideOverflowMenu() {
    if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    ActionButtonSubmenu actionButtonSubmenu = this.mActionButtonPopup;
    if (actionButtonSubmenu != null) {
      actionButtonSubmenu.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.mOverflowButton == null) {
        OverflowMenuButton overflowMenuButton = new OverflowMenuButton(this.mSystemContext);
        this.mOverflowButton = overflowMenuButton;
        if (this.mPendingOverflowIconSet) {
          overflowMenuButton.setImageDrawable(this.mPendingOverflowIcon);
          this.mPendingOverflowIcon = null;
          this.mPendingOverflowIconSet = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      } 
      i -= this.mOverflowButton.getMeasuredWidth();
    } else {
      this.mOverflowButton = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public boolean isOverflowMenuShowPending() {
    return (this.mPostedOpenRunnable != null || isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing() {
    OverflowPopup overflowPopup = this.mOverflowPopup;
    return (overflowPopup != null && overflowPopup.isShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = ActionBarPolicy.get(this.mContext).getMaxActionButtons(); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState))
      return; 
    paramParcelable = paramParcelable;
    if (((SavedState)paramParcelable).openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(((SavedState)paramParcelable).openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.mOpenSubMenuId;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool = paramSubMenuBuilder.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    SubMenuBuilder subMenuBuilder;
    for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
    View view = findViewForItem(subMenuBuilder.getItem());
    if (view == null)
      return false; 
    this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
    int j = paramSubMenuBuilder.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramSubMenuBuilder.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    ActionButtonSubmenu actionButtonSubmenu = new ActionButtonSubmenu(this.mContext, paramSubMenuBuilder, view);
    this.mActionButtonPopup = actionButtonSubmenu;
    actionButtonSubmenu.setForceShowIcon(bool);
    this.mActionButtonPopup.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
      return;
    } 
    if (this.mMenu != null)
      this.mMenu.close(false); 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView) {
    this.mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(this.mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    if (overflowMenuButton != null) {
      overflowMenuButton.setImageDrawable(paramDrawable);
      return;
    } 
    this.mPendingOverflowIconSet = true;
    this.mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null && !this.mMenu.getNonActionItems().isEmpty()) {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, (View)this.mOverflowButton, true));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return true;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    MenuBuilder<MenuItemImpl> menuBuilder = this.mMenu;
    byte b = 0;
    if (menuBuilder != null) {
      ArrayList<MenuItemImpl> arrayList = this.mMenu.getActionItems();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        ActionProvider actionProvider = ((MenuItemImpl)arrayList.get(j)).getSupportActionProvider();
        if (actionProvider != null)
          actionProvider.setSubUiVisibilityListener(this); 
      } 
    } 
    if (this.mMenu != null) {
      ArrayList arrayList = this.mMenu.getNonActionItems();
    } else {
      menuBuilder = null;
    } 
    int i = b;
    if (this.mReserveOverflow) {
      i = b;
      if (menuBuilder != null) {
        int j = menuBuilder.size();
        if (j == 1) {
          i = ((MenuItemImpl)menuBuilder.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.mOverflowButton == null)
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext); 
      ViewGroup viewGroup = (ViewGroup)this.mOverflowButton.getParent();
      if (viewGroup != this.mMenuView) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.mOverflowButton); 
        viewGroup = (ActionMenuView)this.mMenuView;
        viewGroup.addView((View)this.mOverflowButton, (ViewGroup.LayoutParams)viewGroup.generateOverflowButtonLayoutParams());
      } 
    } else {
      OverflowMenuButton overflowMenuButton = this.mOverflowButton;
      if (overflowMenuButton != null && overflowMenuButton.getParent() == this.mMenuView)
        ((ViewGroup)this.mMenuView).removeView((View)this.mOverflowButton); 
    } 
    ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
  }
  
  private class ActionButtonSubmenu extends MenuPopupHelper {
    public ActionButtonSubmenu(Context param1Context, SubMenuBuilder param1SubMenuBuilder, View param1View) {
      super(param1Context, (MenuBuilder)param1SubMenuBuilder, param1View, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)param1SubMenuBuilder.getItem()).isActionButton()) {
        ActionMenuPresenter.OverflowMenuButton overflowMenuButton;
        if (ActionMenuPresenter.this.mOverflowButton == null) {
          View view = (View)ActionMenuPresenter.this.mMenuView;
        } else {
          overflowMenuButton = ActionMenuPresenter.this.mOverflowButton;
        } 
        setAnchorView((View)overflowMenuButton);
      } 
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      ActionMenuPresenter.this.mActionButtonPopup = null;
      ActionMenuPresenter.this.mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  private class ActionMenuPopupCallback extends ActionMenuItemView.PopupCallback {
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mActionButtonPopup != null) ? ActionMenuPresenter.this.mActionButtonPopup.getPopup() : null);
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.changeMenuMode(); 
      View view = (View)ActionMenuPresenter.this.mMenuView;
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        ActionMenuPresenter.this.mOverflowPopup = this.mPopup; 
      ActionMenuPresenter.this.mPostedOpenRunnable = null;
    }
  }
  
  private class OverflowMenuButton extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    private final float[] mTempPts = new float[2];
    
    public OverflowMenuButton(Context param1Context) {
      super(param1Context, (AttributeSet)null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new ForwardingListener((View)this) {
            public ShowableListMenu getPopup() {
              return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
            }
            
            public boolean onForwardingStarted() {
              ActionMenuPresenter.this.showOverflowMenu();
              return true;
            }
            
            public boolean onForwardingStopped() {
              if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
                return false; 
              ActionMenuPresenter.this.hideOverflowMenu();
              return true;
            }
          });
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        DrawableCompat.setHotspotBounds(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
  }
  
  class null extends ForwardingListener {
    null(View param1View) {
      super(param1View);
    }
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
    }
    
    public boolean onForwardingStarted() {
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    public boolean onForwardingStopped() {
      if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
        return false; 
      ActionMenuPresenter.this.hideOverflowMenu();
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    public OverflowPopup(Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean, R.attr.actionOverflowMenuStyle);
      setGravity(8388613);
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.close(); 
      ActionMenuPresenter.this.mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        param1MenuBuilder.getRootMenu().close(false); 
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        callback.onCloseMenu(param1MenuBuilder, param1Boolean); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      boolean bool = false;
      if (param1MenuBuilder == null)
        return false; 
      ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId();
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        bool = callback.onOpenSubMenu(param1MenuBuilder); 
      return bool;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\appcompat\widget\ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */