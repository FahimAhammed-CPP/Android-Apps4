package androidx.appcompat;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130837504;
    
    public static final int actionBarItemBackground = 2130837505;
    
    public static final int actionBarPopupTheme = 2130837506;
    
    public static final int actionBarSize = 2130837507;
    
    public static final int actionBarSplitStyle = 2130837508;
    
    public static final int actionBarStyle = 2130837509;
    
    public static final int actionBarTabBarStyle = 2130837510;
    
    public static final int actionBarTabStyle = 2130837511;
    
    public static final int actionBarTabTextStyle = 2130837512;
    
    public static final int actionBarTheme = 2130837513;
    
    public static final int actionBarWidgetTheme = 2130837514;
    
    public static final int actionButtonStyle = 2130837515;
    
    public static final int actionDropDownStyle = 2130837516;
    
    public static final int actionLayout = 2130837517;
    
    public static final int actionMenuTextAppearance = 2130837518;
    
    public static final int actionMenuTextColor = 2130837519;
    
    public static final int actionModeBackground = 2130837520;
    
    public static final int actionModeCloseButtonStyle = 2130837521;
    
    public static final int actionModeCloseDrawable = 2130837522;
    
    public static final int actionModeCopyDrawable = 2130837523;
    
    public static final int actionModeCutDrawable = 2130837524;
    
    public static final int actionModeFindDrawable = 2130837525;
    
    public static final int actionModePasteDrawable = 2130837526;
    
    public static final int actionModePopupWindowStyle = 2130837527;
    
    public static final int actionModeSelectAllDrawable = 2130837528;
    
    public static final int actionModeShareDrawable = 2130837529;
    
    public static final int actionModeSplitBackground = 2130837530;
    
    public static final int actionModeStyle = 2130837531;
    
    public static final int actionModeWebSearchDrawable = 2130837532;
    
    public static final int actionOverflowButtonStyle = 2130837533;
    
    public static final int actionOverflowMenuStyle = 2130837534;
    
    public static final int actionProviderClass = 2130837535;
    
    public static final int actionViewClass = 2130837536;
    
    public static final int activityChooserViewStyle = 2130837537;
    
    public static final int alertDialogButtonGroupStyle = 2130837538;
    
    public static final int alertDialogCenterButtons = 2130837539;
    
    public static final int alertDialogStyle = 2130837540;
    
    public static final int alertDialogTheme = 2130837541;
    
    public static final int allowStacking = 2130837542;
    
    public static final int alpha = 2130837543;
    
    public static final int alphabeticModifiers = 2130837544;
    
    public static final int arrowHeadLength = 2130837545;
    
    public static final int arrowShaftLength = 2130837546;
    
    public static final int autoCompleteTextViewStyle = 2130837547;
    
    public static final int autoSizeMaxTextSize = 2130837548;
    
    public static final int autoSizeMinTextSize = 2130837549;
    
    public static final int autoSizePresetSizes = 2130837550;
    
    public static final int autoSizeStepGranularity = 2130837551;
    
    public static final int autoSizeTextType = 2130837552;
    
    public static final int background = 2130837553;
    
    public static final int backgroundSplit = 2130837554;
    
    public static final int backgroundStacked = 2130837555;
    
    public static final int backgroundTint = 2130837556;
    
    public static final int backgroundTintMode = 2130837557;
    
    public static final int barLength = 2130837558;
    
    public static final int borderlessButtonStyle = 2130837559;
    
    public static final int buttonBarButtonStyle = 2130837560;
    
    public static final int buttonBarNegativeButtonStyle = 2130837561;
    
    public static final int buttonBarNeutralButtonStyle = 2130837562;
    
    public static final int buttonBarPositiveButtonStyle = 2130837563;
    
    public static final int buttonBarStyle = 2130837564;
    
    public static final int buttonCompat = 2130837565;
    
    public static final int buttonGravity = 2130837566;
    
    public static final int buttonIconDimen = 2130837567;
    
    public static final int buttonPanelSideLayout = 2130837568;
    
    public static final int buttonStyle = 2130837569;
    
    public static final int buttonStyleSmall = 2130837570;
    
    public static final int buttonTint = 2130837571;
    
    public static final int buttonTintMode = 2130837572;
    
    public static final int checkboxStyle = 2130837580;
    
    public static final int checkedTextViewStyle = 2130837581;
    
    public static final int closeIcon = 2130837582;
    
    public static final int closeItemLayout = 2130837583;
    
    public static final int collapseContentDescription = 2130837584;
    
    public static final int collapseIcon = 2130837585;
    
    public static final int color = 2130837586;
    
    public static final int colorAccent = 2130837587;
    
    public static final int colorBackgroundFloating = 2130837588;
    
    public static final int colorButtonNormal = 2130837589;
    
    public static final int colorControlActivated = 2130837590;
    
    public static final int colorControlHighlight = 2130837591;
    
    public static final int colorControlNormal = 2130837592;
    
    public static final int colorError = 2130837593;
    
    public static final int colorPrimary = 2130837594;
    
    public static final int colorPrimaryDark = 2130837595;
    
    public static final int colorSwitchThumbNormal = 2130837596;
    
    public static final int commitIcon = 2130837609;
    
    public static final int contentDescription = 2130837610;
    
    public static final int contentInsetEnd = 2130837611;
    
    public static final int contentInsetEndWithActions = 2130837612;
    
    public static final int contentInsetLeft = 2130837613;
    
    public static final int contentInsetRight = 2130837614;
    
    public static final int contentInsetStart = 2130837615;
    
    public static final int contentInsetStartWithNavigation = 2130837616;
    
    public static final int controlBackground = 2130837622;
    
    public static final int customNavigationLayout = 2130837624;
    
    public static final int defaultQueryHint = 2130837625;
    
    public static final int dialogCornerRadius = 2130837626;
    
    public static final int dialogPreferredPadding = 2130837627;
    
    public static final int dialogTheme = 2130837628;
    
    public static final int displayOptions = 2130837629;
    
    public static final int divider = 2130837630;
    
    public static final int dividerHorizontal = 2130837631;
    
    public static final int dividerPadding = 2130837632;
    
    public static final int dividerVertical = 2130837633;
    
    public static final int drawableBottomCompat = 2130837634;
    
    public static final int drawableEndCompat = 2130837635;
    
    public static final int drawableLeftCompat = 2130837636;
    
    public static final int drawableRightCompat = 2130837637;
    
    public static final int drawableSize = 2130837638;
    
    public static final int drawableStartCompat = 2130837639;
    
    public static final int drawableTint = 2130837640;
    
    public static final int drawableTintMode = 2130837641;
    
    public static final int drawableTopCompat = 2130837642;
    
    public static final int drawerArrowStyle = 2130837643;
    
    public static final int dropDownListViewStyle = 2130837644;
    
    public static final int dropdownListPreferredItemHeight = 2130837645;
    
    public static final int editTextBackground = 2130837646;
    
    public static final int editTextColor = 2130837647;
    
    public static final int editTextStyle = 2130837648;
    
    public static final int elevation = 2130837649;
    
    public static final int expandActivityOverflowButtonDrawable = 2130837650;
    
    public static final int firstBaselineToTopHeight = 2130837651;
    
    public static final int font = 2130837652;
    
    public static final int fontFamily = 2130837653;
    
    public static final int fontProviderAuthority = 2130837654;
    
    public static final int fontProviderCerts = 2130837655;
    
    public static final int fontProviderFetchStrategy = 2130837656;
    
    public static final int fontProviderFetchTimeout = 2130837657;
    
    public static final int fontProviderPackage = 2130837658;
    
    public static final int fontProviderQuery = 2130837659;
    
    public static final int fontStyle = 2130837660;
    
    public static final int fontVariationSettings = 2130837661;
    
    public static final int fontWeight = 2130837662;
    
    public static final int gapBetweenBars = 2130837663;
    
    public static final int goIcon = 2130837664;
    
    public static final int height = 2130837665;
    
    public static final int hideOnContentScroll = 2130837666;
    
    public static final int homeAsUpIndicator = 2130837667;
    
    public static final int homeLayout = 2130837668;
    
    public static final int icon = 2130837669;
    
    public static final int iconTint = 2130837670;
    
    public static final int iconTintMode = 2130837671;
    
    public static final int iconifiedByDefault = 2130837672;
    
    public static final int imageButtonStyle = 2130837673;
    
    public static final int indeterminateProgressStyle = 2130837674;
    
    public static final int initialActivityCount = 2130837675;
    
    public static final int isLightTheme = 2130837676;
    
    public static final int itemPadding = 2130837677;
    
    public static final int lastBaselineToBottomHeight = 2130837679;
    
    public static final int layout = 2130837680;
    
    public static final int lineHeight = 2130837687;
    
    public static final int listChoiceBackgroundIndicator = 2130837688;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130837689;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130837690;
    
    public static final int listDividerAlertDialog = 2130837691;
    
    public static final int listItemLayout = 2130837692;
    
    public static final int listLayout = 2130837693;
    
    public static final int listMenuViewStyle = 2130837694;
    
    public static final int listPopupWindowStyle = 2130837695;
    
    public static final int listPreferredItemHeight = 2130837696;
    
    public static final int listPreferredItemHeightLarge = 2130837697;
    
    public static final int listPreferredItemHeightSmall = 2130837698;
    
    public static final int listPreferredItemPaddingEnd = 2130837699;
    
    public static final int listPreferredItemPaddingLeft = 2130837700;
    
    public static final int listPreferredItemPaddingRight = 2130837701;
    
    public static final int listPreferredItemPaddingStart = 2130837702;
    
    public static final int logo = 2130837703;
    
    public static final int logoDescription = 2130837704;
    
    public static final int maxButtonHeight = 2130837705;
    
    public static final int measureWithLargestChild = 2130837706;
    
    public static final int menu = 2130837707;
    
    public static final int multiChoiceItemLayout = 2130837708;
    
    public static final int navigationContentDescription = 2130837709;
    
    public static final int navigationIcon = 2130837710;
    
    public static final int navigationMode = 2130837711;
    
    public static final int numericModifiers = 2130837712;
    
    public static final int overlapAnchor = 2130837713;
    
    public static final int paddingBottomNoButtons = 2130837714;
    
    public static final int paddingEnd = 2130837715;
    
    public static final int paddingStart = 2130837716;
    
    public static final int paddingTopNoTitle = 2130837717;
    
    public static final int panelBackground = 2130837718;
    
    public static final int panelMenuListTheme = 2130837719;
    
    public static final int panelMenuListWidth = 2130837720;
    
    public static final int popupMenuStyle = 2130837721;
    
    public static final int popupTheme = 2130837722;
    
    public static final int popupWindowStyle = 2130837723;
    
    public static final int preserveIconSpacing = 2130837724;
    
    public static final int progressBarPadding = 2130837725;
    
    public static final int progressBarStyle = 2130837726;
    
    public static final int queryBackground = 2130837727;
    
    public static final int queryHint = 2130837728;
    
    public static final int radioButtonStyle = 2130837729;
    
    public static final int ratingBarStyle = 2130837730;
    
    public static final int ratingBarStyleIndicator = 2130837731;
    
    public static final int ratingBarStyleSmall = 2130837732;
    
    public static final int searchHintIcon = 2130837733;
    
    public static final int searchIcon = 2130837734;
    
    public static final int searchViewStyle = 2130837735;
    
    public static final int seekBarStyle = 2130837736;
    
    public static final int selectableItemBackground = 2130837737;
    
    public static final int selectableItemBackgroundBorderless = 2130837738;
    
    public static final int showAsAction = 2130837739;
    
    public static final int showDividers = 2130837740;
    
    public static final int showText = 2130837741;
    
    public static final int showTitle = 2130837742;
    
    public static final int singleChoiceItemLayout = 2130837743;
    
    public static final int spinBars = 2130837744;
    
    public static final int spinnerDropDownItemStyle = 2130837745;
    
    public static final int spinnerStyle = 2130837746;
    
    public static final int splitTrack = 2130837747;
    
    public static final int srcCompat = 2130837748;
    
    public static final int state_above_anchor = 2130837749;
    
    public static final int subMenuArrow = 2130837751;
    
    public static final int submitBackground = 2130837752;
    
    public static final int subtitle = 2130837753;
    
    public static final int subtitleTextAppearance = 2130837754;
    
    public static final int subtitleTextColor = 2130837755;
    
    public static final int subtitleTextStyle = 2130837756;
    
    public static final int suggestionRowLayout = 2130837757;
    
    public static final int switchMinWidth = 2130837758;
    
    public static final int switchPadding = 2130837759;
    
    public static final int switchStyle = 2130837760;
    
    public static final int switchTextAppearance = 2130837761;
    
    public static final int textAllCaps = 2130837762;
    
    public static final int textAppearanceLargePopupMenu = 2130837763;
    
    public static final int textAppearanceListItem = 2130837764;
    
    public static final int textAppearanceListItemSecondary = 2130837765;
    
    public static final int textAppearanceListItemSmall = 2130837766;
    
    public static final int textAppearancePopupMenuHeader = 2130837767;
    
    public static final int textAppearanceSearchResultSubtitle = 2130837768;
    
    public static final int textAppearanceSearchResultTitle = 2130837769;
    
    public static final int textAppearanceSmallPopupMenu = 2130837770;
    
    public static final int textColorAlertDialogListItem = 2130837771;
    
    public static final int textColorSearchUrl = 2130837772;
    
    public static final int textLocale = 2130837773;
    
    public static final int theme = 2130837774;
    
    public static final int thickness = 2130837775;
    
    public static final int thumbTextPadding = 2130837776;
    
    public static final int thumbTint = 2130837777;
    
    public static final int thumbTintMode = 2130837778;
    
    public static final int tickMark = 2130837779;
    
    public static final int tickMarkTint = 2130837780;
    
    public static final int tickMarkTintMode = 2130837781;
    
    public static final int tint = 2130837782;
    
    public static final int tintMode = 2130837783;
    
    public static final int title = 2130837784;
    
    public static final int titleMargin = 2130837785;
    
    public static final int titleMarginBottom = 2130837786;
    
    public static final int titleMarginEnd = 2130837787;
    
    public static final int titleMarginStart = 2130837788;
    
    public static final int titleMarginTop = 2130837789;
    
    public static final int titleMargins = 2130837790;
    
    public static final int titleTextAppearance = 2130837791;
    
    public static final int titleTextColor = 2130837792;
    
    public static final int titleTextStyle = 2130837793;
    
    public static final int toolbarNavigationButtonStyle = 2130837794;
    
    public static final int toolbarStyle = 2130837795;
    
    public static final int tooltipForegroundColor = 2130837796;
    
    public static final int tooltipFrameBackground = 2130837797;
    
    public static final int tooltipText = 2130837798;
    
    public static final int track = 2130837799;
    
    public static final int trackTint = 2130837800;
    
    public static final int trackTintMode = 2130837801;
    
    public static final int ttcIndex = 2130837802;
    
    public static final int viewInflaterClass = 2130837803;
    
    public static final int voiceIcon = 2130837804;
    
    public static final int windowActionBar = 2130837805;
    
    public static final int windowActionBarOverlay = 2130837806;
    
    public static final int windowActionModeOverlay = 2130837807;
    
    public static final int windowFixedHeightMajor = 2130837808;
    
    public static final int windowFixedHeightMinor = 2130837809;
    
    public static final int windowFixedWidthMajor = 2130837810;
    
    public static final int windowFixedWidthMinor = 2130837811;
    
    public static final int windowMinWidthMajor = 2130837812;
    
    public static final int windowMinWidthMinor = 2130837813;
    
    public static final int windowNoTitle = 2130837814;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130903040;
    
    public static final int abc_allow_stacked_button_bar = 2130903041;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130903042;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2130968576;
    
    public static final int abc_background_cache_hint_selector_material_light = 2130968577;
    
    public static final int abc_btn_colored_borderless_text_material = 2130968578;
    
    public static final int abc_btn_colored_text_material = 2130968579;
    
    public static final int abc_color_highlight_material = 2130968580;
    
    public static final int abc_hint_foreground_material_dark = 2130968581;
    
    public static final int abc_hint_foreground_material_light = 2130968582;
    
    public static final int abc_input_method_navigation_guard = 2130968583;
    
    public static final int abc_primary_text_disable_only_material_dark = 2130968584;
    
    public static final int abc_primary_text_disable_only_material_light = 2130968585;
    
    public static final int abc_primary_text_material_dark = 2130968586;
    
    public static final int abc_primary_text_material_light = 2130968587;
    
    public static final int abc_search_url_text = 2130968588;
    
    public static final int abc_search_url_text_normal = 2130968589;
    
    public static final int abc_search_url_text_pressed = 2130968590;
    
    public static final int abc_search_url_text_selected = 2130968591;
    
    public static final int abc_secondary_text_material_dark = 2130968592;
    
    public static final int abc_secondary_text_material_light = 2130968593;
    
    public static final int abc_tint_btn_checkable = 2130968594;
    
    public static final int abc_tint_default = 2130968595;
    
    public static final int abc_tint_edittext = 2130968596;
    
    public static final int abc_tint_seek_thumb = 2130968597;
    
    public static final int abc_tint_spinner = 2130968598;
    
    public static final int abc_tint_switch_track = 2130968599;
    
    public static final int accent_material_dark = 2130968600;
    
    public static final int accent_material_light = 2130968601;
    
    public static final int background_floating_material_dark = 2130968602;
    
    public static final int background_floating_material_light = 2130968603;
    
    public static final int background_material_dark = 2130968604;
    
    public static final int background_material_light = 2130968605;
    
    public static final int bright_foreground_disabled_material_dark = 2130968606;
    
    public static final int bright_foreground_disabled_material_light = 2130968607;
    
    public static final int bright_foreground_inverse_material_dark = 2130968608;
    
    public static final int bright_foreground_inverse_material_light = 2130968609;
    
    public static final int bright_foreground_material_dark = 2130968610;
    
    public static final int bright_foreground_material_light = 2130968611;
    
    public static final int button_material_dark = 2130968616;
    
    public static final int button_material_light = 2130968617;
    
    public static final int dim_foreground_disabled_material_dark = 2130968639;
    
    public static final int dim_foreground_disabled_material_light = 2130968640;
    
    public static final int dim_foreground_material_dark = 2130968641;
    
    public static final int dim_foreground_material_light = 2130968642;
    
    public static final int error_color_material_dark = 2130968643;
    
    public static final int error_color_material_light = 2130968644;
    
    public static final int foreground_material_dark = 2130968645;
    
    public static final int foreground_material_light = 2130968646;
    
    public static final int highlighted_text_material_dark = 2130968647;
    
    public static final int highlighted_text_material_light = 2130968648;
    
    public static final int material_blue_grey_800 = 2130968649;
    
    public static final int material_blue_grey_900 = 2130968650;
    
    public static final int material_blue_grey_950 = 2130968651;
    
    public static final int material_deep_teal_200 = 2130968652;
    
    public static final int material_deep_teal_500 = 2130968653;
    
    public static final int material_grey_100 = 2130968654;
    
    public static final int material_grey_300 = 2130968655;
    
    public static final int material_grey_50 = 2130968656;
    
    public static final int material_grey_600 = 2130968657;
    
    public static final int material_grey_800 = 2130968658;
    
    public static final int material_grey_850 = 2130968659;
    
    public static final int material_grey_900 = 2130968660;
    
    public static final int notification_action_color_filter = 2130968661;
    
    public static final int notification_icon_bg_color = 2130968662;
    
    public static final int primary_dark_material_dark = 2130968664;
    
    public static final int primary_dark_material_light = 2130968665;
    
    public static final int primary_material_dark = 2130968666;
    
    public static final int primary_material_light = 2130968667;
    
    public static final int primary_text_default_material_dark = 2130968668;
    
    public static final int primary_text_default_material_light = 2130968669;
    
    public static final int primary_text_disabled_material_dark = 2130968670;
    
    public static final int primary_text_disabled_material_light = 2130968671;
    
    public static final int ripple_material_dark = 2130968672;
    
    public static final int ripple_material_light = 2130968673;
    
    public static final int secondary_text_default_material_dark = 2130968674;
    
    public static final int secondary_text_default_material_light = 2130968675;
    
    public static final int secondary_text_disabled_material_dark = 2130968676;
    
    public static final int secondary_text_disabled_material_light = 2130968677;
    
    public static final int switch_thumb_disabled_material_dark = 2130968678;
    
    public static final int switch_thumb_disabled_material_light = 2130968679;
    
    public static final int switch_thumb_material_dark = 2130968680;
    
    public static final int switch_thumb_material_light = 2130968681;
    
    public static final int switch_thumb_normal_material_dark = 2130968682;
    
    public static final int switch_thumb_normal_material_light = 2130968683;
    
    public static final int tooltip_background_dark = 2130968684;
    
    public static final int tooltip_background_light = 2130968685;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131034112;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131034113;
    
    public static final int abc_action_bar_default_height_material = 2131034114;
    
    public static final int abc_action_bar_default_padding_end_material = 2131034115;
    
    public static final int abc_action_bar_default_padding_start_material = 2131034116;
    
    public static final int abc_action_bar_elevation_material = 2131034117;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131034118;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131034119;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131034120;
    
    public static final int abc_action_bar_stacked_max_height = 2131034121;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131034122;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131034123;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131034124;
    
    public static final int abc_action_button_min_height_material = 2131034125;
    
    public static final int abc_action_button_min_width_material = 2131034126;
    
    public static final int abc_action_button_min_width_overflow_material = 2131034127;
    
    public static final int abc_alert_dialog_button_bar_height = 2131034128;
    
    public static final int abc_alert_dialog_button_dimen = 2131034129;
    
    public static final int abc_button_inset_horizontal_material = 2131034130;
    
    public static final int abc_button_inset_vertical_material = 2131034131;
    
    public static final int abc_button_padding_horizontal_material = 2131034132;
    
    public static final int abc_button_padding_vertical_material = 2131034133;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131034134;
    
    public static final int abc_config_prefDialogWidth = 2131034135;
    
    public static final int abc_control_corner_material = 2131034136;
    
    public static final int abc_control_inset_material = 2131034137;
    
    public static final int abc_control_padding_material = 2131034138;
    
    public static final int abc_dialog_corner_radius_material = 2131034139;
    
    public static final int abc_dialog_fixed_height_major = 2131034140;
    
    public static final int abc_dialog_fixed_height_minor = 2131034141;
    
    public static final int abc_dialog_fixed_width_major = 2131034142;
    
    public static final int abc_dialog_fixed_width_minor = 2131034143;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131034144;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131034145;
    
    public static final int abc_dialog_min_width_major = 2131034146;
    
    public static final int abc_dialog_min_width_minor = 2131034147;
    
    public static final int abc_dialog_padding_material = 2131034148;
    
    public static final int abc_dialog_padding_top_material = 2131034149;
    
    public static final int abc_dialog_title_divider_material = 2131034150;
    
    public static final int abc_disabled_alpha_material_dark = 2131034151;
    
    public static final int abc_disabled_alpha_material_light = 2131034152;
    
    public static final int abc_dropdownitem_icon_width = 2131034153;
    
    public static final int abc_dropdownitem_text_padding_left = 2131034154;
    
    public static final int abc_dropdownitem_text_padding_right = 2131034155;
    
    public static final int abc_edit_text_inset_bottom_material = 2131034156;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131034157;
    
    public static final int abc_edit_text_inset_top_material = 2131034158;
    
    public static final int abc_floating_window_z = 2131034159;
    
    public static final int abc_list_item_height_large_material = 2131034160;
    
    public static final int abc_list_item_height_material = 2131034161;
    
    public static final int abc_list_item_height_small_material = 2131034162;
    
    public static final int abc_list_item_padding_horizontal_material = 2131034163;
    
    public static final int abc_panel_menu_list_width = 2131034164;
    
    public static final int abc_progress_bar_height_material = 2131034165;
    
    public static final int abc_search_view_preferred_height = 2131034166;
    
    public static final int abc_search_view_preferred_width = 2131034167;
    
    public static final int abc_seekbar_track_background_height_material = 2131034168;
    
    public static final int abc_seekbar_track_progress_height_material = 2131034169;
    
    public static final int abc_select_dialog_padding_start_material = 2131034170;
    
    public static final int abc_switch_padding = 2131034171;
    
    public static final int abc_text_size_body_1_material = 2131034172;
    
    public static final int abc_text_size_body_2_material = 2131034173;
    
    public static final int abc_text_size_button_material = 2131034174;
    
    public static final int abc_text_size_caption_material = 2131034175;
    
    public static final int abc_text_size_display_1_material = 2131034176;
    
    public static final int abc_text_size_display_2_material = 2131034177;
    
    public static final int abc_text_size_display_3_material = 2131034178;
    
    public static final int abc_text_size_display_4_material = 2131034179;
    
    public static final int abc_text_size_headline_material = 2131034180;
    
    public static final int abc_text_size_large_material = 2131034181;
    
    public static final int abc_text_size_medium_material = 2131034182;
    
    public static final int abc_text_size_menu_header_material = 2131034183;
    
    public static final int abc_text_size_menu_material = 2131034184;
    
    public static final int abc_text_size_small_material = 2131034185;
    
    public static final int abc_text_size_subhead_material = 2131034186;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131034187;
    
    public static final int abc_text_size_title_material = 2131034188;
    
    public static final int abc_text_size_title_material_toolbar = 2131034189;
    
    public static final int compat_button_inset_horizontal_material = 2131034211;
    
    public static final int compat_button_inset_vertical_material = 2131034212;
    
    public static final int compat_button_padding_horizontal_material = 2131034213;
    
    public static final int compat_button_padding_vertical_material = 2131034214;
    
    public static final int compat_control_corner_material = 2131034215;
    
    public static final int compat_notification_large_icon_max_height = 2131034216;
    
    public static final int compat_notification_large_icon_max_width = 2131034217;
    
    public static final int disabled_alpha_material_dark = 2131034218;
    
    public static final int disabled_alpha_material_light = 2131034219;
    
    public static final int highlight_alpha_material_colored = 2131034220;
    
    public static final int highlight_alpha_material_dark = 2131034221;
    
    public static final int highlight_alpha_material_light = 2131034222;
    
    public static final int hint_alpha_material_dark = 2131034223;
    
    public static final int hint_alpha_material_light = 2131034224;
    
    public static final int hint_pressed_alpha_material_dark = 2131034225;
    
    public static final int hint_pressed_alpha_material_light = 2131034226;
    
    public static final int notification_action_icon_size = 2131034227;
    
    public static final int notification_action_text_size = 2131034228;
    
    public static final int notification_big_circle_margin = 2131034229;
    
    public static final int notification_content_margin_start = 2131034230;
    
    public static final int notification_large_icon_height = 2131034231;
    
    public static final int notification_large_icon_width = 2131034232;
    
    public static final int notification_main_column_padding_top = 2131034233;
    
    public static final int notification_media_narrow_margin = 2131034234;
    
    public static final int notification_right_icon_size = 2131034235;
    
    public static final int notification_right_side_padding_top = 2131034236;
    
    public static final int notification_small_icon_background_padding = 2131034237;
    
    public static final int notification_small_icon_size_as_large = 2131034238;
    
    public static final int notification_subtext_size = 2131034239;
    
    public static final int notification_top_pad = 2131034240;
    
    public static final int notification_top_pad_large_text = 2131034241;
    
    public static final int tooltip_corner_radius = 2131034246;
    
    public static final int tooltip_horizontal_padding = 2131034247;
    
    public static final int tooltip_margin = 2131034248;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131034249;
    
    public static final int tooltip_precise_anchor_threshold = 2131034250;
    
    public static final int tooltip_vertical_padding = 2131034251;
    
    public static final int tooltip_y_offset_non_touch = 2131034252;
    
    public static final int tooltip_y_offset_touch = 2131034253;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131099648;
    
    public static final int abc_action_bar_item_background_material = 2131099649;
    
    public static final int abc_btn_borderless_material = 2131099650;
    
    public static final int abc_btn_check_material = 2131099651;
    
    public static final int abc_btn_check_material_anim = 2131099652;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131099653;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131099654;
    
    public static final int abc_btn_colored_material = 2131099655;
    
    public static final int abc_btn_default_mtrl_shape = 2131099656;
    
    public static final int abc_btn_radio_material = 2131099657;
    
    public static final int abc_btn_radio_material_anim = 2131099658;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131099659;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131099660;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131099661;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131099662;
    
    public static final int abc_cab_background_internal_bg = 2131099663;
    
    public static final int abc_cab_background_top_material = 2131099664;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131099665;
    
    public static final int abc_control_background_material = 2131099666;
    
    public static final int abc_dialog_material_background = 2131099667;
    
    public static final int abc_edit_text_material = 2131099668;
    
    public static final int abc_ic_ab_back_material = 2131099669;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131099670;
    
    public static final int abc_ic_clear_material = 2131099671;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131099672;
    
    public static final int abc_ic_go_search_api_material = 2131099673;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131099674;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131099675;
    
    public static final int abc_ic_menu_overflow_material = 2131099676;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131099677;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131099678;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131099679;
    
    public static final int abc_ic_search_api_material = 2131099680;
    
    public static final int abc_ic_star_black_16dp = 2131099681;
    
    public static final int abc_ic_star_black_36dp = 2131099682;
    
    public static final int abc_ic_star_black_48dp = 2131099683;
    
    public static final int abc_ic_star_half_black_16dp = 2131099684;
    
    public static final int abc_ic_star_half_black_36dp = 2131099685;
    
    public static final int abc_ic_star_half_black_48dp = 2131099686;
    
    public static final int abc_ic_voice_search_api_material = 2131099687;
    
    public static final int abc_item_background_holo_dark = 2131099688;
    
    public static final int abc_item_background_holo_light = 2131099689;
    
    public static final int abc_list_divider_material = 2131099690;
    
    public static final int abc_list_divider_mtrl_alpha = 2131099691;
    
    public static final int abc_list_focused_holo = 2131099692;
    
    public static final int abc_list_longpressed_holo = 2131099693;
    
    public static final int abc_list_pressed_holo_dark = 2131099694;
    
    public static final int abc_list_pressed_holo_light = 2131099695;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131099696;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131099697;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131099698;
    
    public static final int abc_list_selector_disabled_holo_light = 2131099699;
    
    public static final int abc_list_selector_holo_dark = 2131099700;
    
    public static final int abc_list_selector_holo_light = 2131099701;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131099702;
    
    public static final int abc_popup_background_mtrl_mult = 2131099703;
    
    public static final int abc_ratingbar_indicator_material = 2131099704;
    
    public static final int abc_ratingbar_material = 2131099705;
    
    public static final int abc_ratingbar_small_material = 2131099706;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131099707;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131099708;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131099709;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131099710;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131099711;
    
    public static final int abc_seekbar_thumb_material = 2131099712;
    
    public static final int abc_seekbar_tick_mark_material = 2131099713;
    
    public static final int abc_seekbar_track_material = 2131099714;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131099715;
    
    public static final int abc_spinner_textfield_background_material = 2131099716;
    
    public static final int abc_switch_thumb_material = 2131099717;
    
    public static final int abc_switch_track_mtrl_alpha = 2131099718;
    
    public static final int abc_tab_indicator_material = 2131099719;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131099720;
    
    public static final int abc_text_cursor_material = 2131099721;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131099722;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131099723;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131099724;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131099725;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131099726;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131099727;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131099728;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131099729;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131099730;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131099731;
    
    public static final int abc_textfield_search_material = 2131099732;
    
    public static final int abc_vector_test = 2131099733;
    
    public static final int btn_checkbox_checked_mtrl = 2131099734;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131099735;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131099736;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131099737;
    
    public static final int btn_radio_off_mtrl = 2131099738;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131099739;
    
    public static final int btn_radio_on_mtrl = 2131099740;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131099741;
    
    public static final int notification_action_background = 2131099765;
    
    public static final int notification_bg = 2131099766;
    
    public static final int notification_bg_low = 2131099767;
    
    public static final int notification_bg_low_normal = 2131099768;
    
    public static final int notification_bg_low_pressed = 2131099769;
    
    public static final int notification_bg_normal = 2131099770;
    
    public static final int notification_bg_normal_pressed = 2131099771;
    
    public static final int notification_icon_background = 2131099772;
    
    public static final int notification_template_icon_bg = 2131099773;
    
    public static final int notification_template_icon_low_bg = 2131099774;
    
    public static final int notification_tile_bg = 2131099775;
    
    public static final int notify_panel_notification_icon_bg = 2131099776;
    
    public static final int tooltip_frame_dark = 2131099777;
    
    public static final int tooltip_frame_light = 2131099778;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131165190;
    
    public static final int accessibility_custom_action_0 = 2131165191;
    
    public static final int accessibility_custom_action_1 = 2131165192;
    
    public static final int accessibility_custom_action_10 = 2131165193;
    
    public static final int accessibility_custom_action_11 = 2131165194;
    
    public static final int accessibility_custom_action_12 = 2131165195;
    
    public static final int accessibility_custom_action_13 = 2131165196;
    
    public static final int accessibility_custom_action_14 = 2131165197;
    
    public static final int accessibility_custom_action_15 = 2131165198;
    
    public static final int accessibility_custom_action_16 = 2131165199;
    
    public static final int accessibility_custom_action_17 = 2131165200;
    
    public static final int accessibility_custom_action_18 = 2131165201;
    
    public static final int accessibility_custom_action_19 = 2131165202;
    
    public static final int accessibility_custom_action_2 = 2131165203;
    
    public static final int accessibility_custom_action_20 = 2131165204;
    
    public static final int accessibility_custom_action_21 = 2131165205;
    
    public static final int accessibility_custom_action_22 = 2131165206;
    
    public static final int accessibility_custom_action_23 = 2131165207;
    
    public static final int accessibility_custom_action_24 = 2131165208;
    
    public static final int accessibility_custom_action_25 = 2131165209;
    
    public static final int accessibility_custom_action_26 = 2131165210;
    
    public static final int accessibility_custom_action_27 = 2131165211;
    
    public static final int accessibility_custom_action_28 = 2131165212;
    
    public static final int accessibility_custom_action_29 = 2131165213;
    
    public static final int accessibility_custom_action_3 = 2131165214;
    
    public static final int accessibility_custom_action_30 = 2131165215;
    
    public static final int accessibility_custom_action_31 = 2131165216;
    
    public static final int accessibility_custom_action_4 = 2131165217;
    
    public static final int accessibility_custom_action_5 = 2131165218;
    
    public static final int accessibility_custom_action_6 = 2131165219;
    
    public static final int accessibility_custom_action_7 = 2131165220;
    
    public static final int accessibility_custom_action_8 = 2131165221;
    
    public static final int accessibility_custom_action_9 = 2131165222;
    
    public static final int action_bar = 2131165224;
    
    public static final int action_bar_activity_content = 2131165225;
    
    public static final int action_bar_container = 2131165226;
    
    public static final int action_bar_root = 2131165227;
    
    public static final int action_bar_spinner = 2131165228;
    
    public static final int action_bar_subtitle = 2131165229;
    
    public static final int action_bar_title = 2131165230;
    
    public static final int action_container = 2131165231;
    
    public static final int action_context_bar = 2131165232;
    
    public static final int action_divider = 2131165233;
    
    public static final int action_image = 2131165234;
    
    public static final int action_menu_divider = 2131165235;
    
    public static final int action_menu_presenter = 2131165236;
    
    public static final int action_mode_bar = 2131165237;
    
    public static final int action_mode_bar_stub = 2131165238;
    
    public static final int action_mode_close_button = 2131165239;
    
    public static final int action_text = 2131165240;
    
    public static final int actions = 2131165241;
    
    public static final int activity_chooser_view_content = 2131165242;
    
    public static final int add = 2131165243;
    
    public static final int alertTitle = 2131165244;
    
    public static final int async = 2131165247;
    
    public static final int blocking = 2131165250;
    
    public static final int buttonPanel = 2131165259;
    
    public static final int checkbox = 2131165265;
    
    public static final int checked = 2131165266;
    
    public static final int chronometer = 2131165267;
    
    public static final int content = 2131165282;
    
    public static final int contentPanel = 2131165283;
    
    public static final int custom = 2131165284;
    
    public static final int customPanel = 2131165285;
    
    public static final int decor_content_parent = 2131165286;
    
    public static final int default_activity_button = 2131165287;
    
    public static final int dialog_button = 2131165288;
    
    public static final int edit_query = 2131165291;
    
    public static final int expand_activities_button = 2131165294;
    
    public static final int expanded_menu = 2131165295;
    
    public static final int forever = 2131165299;
    
    public static final int group_divider = 2131165300;
    
    public static final int home = 2131165301;
    
    public static final int icon = 2131165303;
    
    public static final int icon_group = 2131165304;
    
    public static final int image = 2131165306;
    
    public static final int info = 2131165307;
    
    public static final int italic = 2131165309;
    
    public static final int line1 = 2131165312;
    
    public static final int line3 = 2131165313;
    
    public static final int listMode = 2131165314;
    
    public static final int list_item = 2131165315;
    
    public static final int message = 2131165317;
    
    public static final int multiply = 2131165319;
    
    public static final int none = 2131165322;
    
    public static final int normal = 2131165323;
    
    public static final int notification_background = 2131165324;
    
    public static final int notification_main_column = 2131165325;
    
    public static final int notification_main_column_container = 2131165326;
    
    public static final int off = 2131165327;
    
    public static final int on = 2131165328;
    
    public static final int parentPanel = 2131165331;
    
    public static final int progress_circular = 2131165333;
    
    public static final int progress_horizontal = 2131165334;
    
    public static final int radio = 2131165335;
    
    public static final int right_icon = 2131165337;
    
    public static final int right_side = 2131165338;
    
    public static final int screen = 2131165339;
    
    public static final int scrollIndicatorDown = 2131165340;
    
    public static final int scrollIndicatorUp = 2131165341;
    
    public static final int scrollView = 2131165342;
    
    public static final int search_badge = 2131165343;
    
    public static final int search_bar = 2131165344;
    
    public static final int search_button = 2131165345;
    
    public static final int search_close_btn = 2131165346;
    
    public static final int search_edit_frame = 2131165347;
    
    public static final int search_go_btn = 2131165348;
    
    public static final int search_mag_icon = 2131165349;
    
    public static final int search_plate = 2131165350;
    
    public static final int search_src_text = 2131165351;
    
    public static final int search_voice_btn = 2131165352;
    
    public static final int select_dialog_listview = 2131165353;
    
    public static final int shortcut = 2131165354;
    
    public static final int spacer = 2131165359;
    
    public static final int split_action_bar = 2131165360;
    
    public static final int src_atop = 2131165361;
    
    public static final int src_in = 2131165362;
    
    public static final int src_over = 2131165363;
    
    public static final int submenuarrow = 2131165367;
    
    public static final int submit_area = 2131165368;
    
    public static final int tabMode = 2131165369;
    
    public static final int tag_accessibility_actions = 2131165370;
    
    public static final int tag_accessibility_clickable_spans = 2131165371;
    
    public static final int tag_accessibility_heading = 2131165372;
    
    public static final int tag_accessibility_pane_title = 2131165373;
    
    public static final int tag_screen_reader_focusable = 2131165374;
    
    public static final int tag_transition_group = 2131165375;
    
    public static final int tag_unhandled_key_event_manager = 2131165376;
    
    public static final int tag_unhandled_key_listeners = 2131165377;
    
    public static final int text = 2131165378;
    
    public static final int text2 = 2131165379;
    
    public static final int textSpacerNoButtons = 2131165380;
    
    public static final int textSpacerNoTitle = 2131165381;
    
    public static final int time = 2131165382;
    
    public static final int title = 2131165383;
    
    public static final int titleDividerNoCustom = 2131165384;
    
    public static final int title_template = 2131165385;
    
    public static final int topPanel = 2131165387;
    
    public static final int unchecked = 2131165388;
    
    public static final int uniform = 2131165389;
    
    public static final int up = 2131165392;
    
    public static final int wrap_content = 2131165395;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131230720;
    
    public static final int abc_config_activityShortDur = 2131230721;
    
    public static final int cancel_button_image_alpha = 2131230722;
    
    public static final int config_tooltipAnimTime = 2131230723;
    
    public static final int status_bar_notification_info_maxnum = 2131230725;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131296256;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131296257;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131296258;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131296259;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131296260;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131296261;
    
    public static final int fast_out_slow_in = 2131296262;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131361792;
    
    public static final int abc_action_bar_up_container = 2131361793;
    
    public static final int abc_action_menu_item_layout = 2131361794;
    
    public static final int abc_action_menu_layout = 2131361795;
    
    public static final int abc_action_mode_bar = 2131361796;
    
    public static final int abc_action_mode_close_item_material = 2131361797;
    
    public static final int abc_activity_chooser_view = 2131361798;
    
    public static final int abc_activity_chooser_view_list_item = 2131361799;
    
    public static final int abc_alert_dialog_button_bar_material = 2131361800;
    
    public static final int abc_alert_dialog_material = 2131361801;
    
    public static final int abc_alert_dialog_title_material = 2131361802;
    
    public static final int abc_cascading_menu_item_layout = 2131361803;
    
    public static final int abc_dialog_title_material = 2131361804;
    
    public static final int abc_expanded_menu_layout = 2131361805;
    
    public static final int abc_list_menu_item_checkbox = 2131361806;
    
    public static final int abc_list_menu_item_icon = 2131361807;
    
    public static final int abc_list_menu_item_layout = 2131361808;
    
    public static final int abc_list_menu_item_radio = 2131361809;
    
    public static final int abc_popup_menu_header_item_layout = 2131361810;
    
    public static final int abc_popup_menu_item_layout = 2131361811;
    
    public static final int abc_screen_content_include = 2131361812;
    
    public static final int abc_screen_simple = 2131361813;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131361814;
    
    public static final int abc_screen_toolbar = 2131361815;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131361816;
    
    public static final int abc_search_view = 2131361817;
    
    public static final int abc_select_dialog_material = 2131361818;
    
    public static final int abc_tooltip = 2131361819;
    
    public static final int custom_dialog = 2131361827;
    
    public static final int notification_action = 2131361828;
    
    public static final int notification_action_tombstone = 2131361829;
    
    public static final int notification_template_custom_big = 2131361836;
    
    public static final int notification_template_icon_group = 2131361837;
    
    public static final int notification_template_part_chronometer = 2131361841;
    
    public static final int notification_template_part_time = 2131361842;
    
    public static final int select_dialog_item_material = 2131361843;
    
    public static final int select_dialog_multichoice_material = 2131361844;
    
    public static final int select_dialog_singlechoice_material = 2131361845;
    
    public static final int support_simple_spinner_dropdown_item = 2131361846;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131492864;
    
    public static final int abc_action_bar_up_description = 2131492865;
    
    public static final int abc_action_menu_overflow_description = 2131492866;
    
    public static final int abc_action_mode_done = 2131492867;
    
    public static final int abc_activity_chooser_view_see_all = 2131492868;
    
    public static final int abc_activitychooserview_choose_application = 2131492869;
    
    public static final int abc_capital_off = 2131492870;
    
    public static final int abc_capital_on = 2131492871;
    
    public static final int abc_menu_alt_shortcut_label = 2131492872;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131492873;
    
    public static final int abc_menu_delete_shortcut_label = 2131492874;
    
    public static final int abc_menu_enter_shortcut_label = 2131492875;
    
    public static final int abc_menu_function_shortcut_label = 2131492876;
    
    public static final int abc_menu_meta_shortcut_label = 2131492877;
    
    public static final int abc_menu_shift_shortcut_label = 2131492878;
    
    public static final int abc_menu_space_shortcut_label = 2131492879;
    
    public static final int abc_menu_sym_shortcut_label = 2131492880;
    
    public static final int abc_prepend_shortcut_label = 2131492881;
    
    public static final int abc_search_hint = 2131492882;
    
    public static final int abc_searchview_description_clear = 2131492883;
    
    public static final int abc_searchview_description_query = 2131492884;
    
    public static final int abc_searchview_description_search = 2131492885;
    
    public static final int abc_searchview_description_submit = 2131492886;
    
    public static final int abc_searchview_description_voice = 2131492887;
    
    public static final int abc_shareactionprovider_share_with = 2131492888;
    
    public static final int abc_shareactionprovider_share_with_application = 2131492889;
    
    public static final int abc_toolbar_collapse_description = 2131492890;
    
    public static final int search_menu_title = 2131492917;
    
    public static final int status_bar_notification_info_overflow = 2131492918;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131558400;
    
    public static final int AlertDialog_AppCompat_Light = 2131558401;
    
    public static final int Animation_AppCompat_Dialog = 2131558402;
    
    public static final int Animation_AppCompat_DropDownUp = 2131558403;
    
    public static final int Animation_AppCompat_Tooltip = 2131558404;
    
    public static final int Base_AlertDialog_AppCompat = 2131558405;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131558406;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131558407;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131558408;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131558409;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131558412;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131558411;
    
    public static final int Base_TextAppearance_AppCompat = 2131558413;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131558414;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131558415;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131558416;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131558417;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131558418;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131558419;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131558420;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131558421;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131558422;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131558423;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131558424;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131558425;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131558426;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131558427;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131558428;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131558429;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131558430;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131558431;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131558432;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131558433;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131558434;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131558435;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131558436;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131558437;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131558438;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131558439;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131558440;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131558441;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131558442;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131558443;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131558444;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131558445;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131558446;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131558447;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131558448;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131558449;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131558450;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131558451;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131558452;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131558453;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131558454;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131558455;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131558456;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131558457;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131558458;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131558459;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131558460;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131558475;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131558476;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131558477;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131558478;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131558479;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131558480;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131558481;
    
    public static final int Base_Theme_AppCompat = 2131558461;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131558462;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131558463;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131558467;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131558464;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131558465;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131558466;
    
    public static final int Base_Theme_AppCompat_Light = 2131558468;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131558469;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131558470;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131558474;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131558471;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131558472;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131558473;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131558486;
    
    public static final int Base_V21_Theme_AppCompat = 2131558482;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131558483;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131558484;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131558485;
    
    public static final int Base_V22_Theme_AppCompat = 2131558487;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131558488;
    
    public static final int Base_V23_Theme_AppCompat = 2131558489;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131558490;
    
    public static final int Base_V26_Theme_AppCompat = 2131558491;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131558492;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131558493;
    
    public static final int Base_V28_Theme_AppCompat = 2131558494;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131558495;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131558500;
    
    public static final int Base_V7_Theme_AppCompat = 2131558496;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131558497;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131558498;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131558499;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131558501;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131558502;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131558503;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131558504;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131558505;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131558506;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131558507;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131558508;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131558509;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131558510;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131558511;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131558512;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131558513;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131558514;
    
    public static final int Base_Widget_AppCompat_Button = 2131558515;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131558521;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131558522;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131558516;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131558517;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131558518;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131558519;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131558520;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131558523;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131558524;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131558525;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131558526;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131558527;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131558528;
    
    public static final int Base_Widget_AppCompat_EditText = 2131558529;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131558530;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131558531;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131558532;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131558533;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131558534;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131558535;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131558536;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131558537;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131558538;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131558539;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131558540;
    
    public static final int Base_Widget_AppCompat_ListView = 2131558541;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131558542;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131558543;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131558544;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131558545;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131558546;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131558547;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131558548;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131558549;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131558550;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131558551;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131558552;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131558553;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131558554;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131558555;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131558556;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131558557;
    
    public static final int Base_Widget_AppCompat_TextView = 2131558558;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131558559;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131558560;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131558561;
    
    public static final int Platform_AppCompat = 2131558566;
    
    public static final int Platform_AppCompat_Light = 2131558567;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131558568;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131558569;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131558570;
    
    public static final int Platform_V21_AppCompat = 2131558571;
    
    public static final int Platform_V21_AppCompat_Light = 2131558572;
    
    public static final int Platform_V25_AppCompat = 2131558573;
    
    public static final int Platform_V25_AppCompat_Light = 2131558574;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131558575;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131558576;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131558577;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131558578;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131558579;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131558580;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131558581;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131558582;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131558583;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131558584;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131558590;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131558585;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131558586;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131558587;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131558588;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131558589;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131558591;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131558592;
    
    public static final int TextAppearance_AppCompat = 2131558593;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131558594;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131558595;
    
    public static final int TextAppearance_AppCompat_Button = 2131558596;
    
    public static final int TextAppearance_AppCompat_Caption = 2131558597;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131558598;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131558599;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131558600;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131558601;
    
    public static final int TextAppearance_AppCompat_Headline = 2131558602;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131558603;
    
    public static final int TextAppearance_AppCompat_Large = 2131558604;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131558605;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131558606;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131558607;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131558608;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131558609;
    
    public static final int TextAppearance_AppCompat_Medium = 2131558610;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131558611;
    
    public static final int TextAppearance_AppCompat_Menu = 2131558612;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131558613;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131558614;
    
    public static final int TextAppearance_AppCompat_Small = 2131558615;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131558616;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131558617;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131558618;
    
    public static final int TextAppearance_AppCompat_Title = 2131558619;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131558620;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131558621;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131558622;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131558623;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131558624;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131558625;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131558626;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131558627;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131558628;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131558629;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131558630;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131558631;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131558632;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131558633;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131558634;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131558635;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131558636;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131558637;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131558638;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131558639;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131558640;
    
    public static final int TextAppearance_Compat_Notification = 2131558641;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131558642;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131558644;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131558647;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131558649;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131558651;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131558652;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131558653;
    
    public static final int ThemeOverlay_AppCompat = 2131558675;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131558676;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131558677;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131558678;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131558679;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131558680;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131558681;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131558682;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131558683;
    
    public static final int Theme_AppCompat = 2131558654;
    
    public static final int Theme_AppCompat_CompactMenu = 2131558655;
    
    public static final int Theme_AppCompat_DayNight = 2131558656;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131558657;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131558658;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131558661;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131558659;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131558660;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131558662;
    
    public static final int Theme_AppCompat_Dialog = 2131558663;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131558666;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131558664;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131558665;
    
    public static final int Theme_AppCompat_Light = 2131558667;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131558668;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131558669;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131558672;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131558670;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131558671;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131558673;
    
    public static final int Theme_AppCompat_NoActionBar = 2131558674;
    
    public static final int Widget_AppCompat_ActionBar = 2131558686;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131558687;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131558688;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131558689;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131558690;
    
    public static final int Widget_AppCompat_ActionButton = 2131558691;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131558692;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131558693;
    
    public static final int Widget_AppCompat_ActionMode = 2131558694;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131558695;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131558696;
    
    public static final int Widget_AppCompat_Button = 2131558697;
    
    public static final int Widget_AppCompat_ButtonBar = 2131558703;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131558704;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131558698;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131558699;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131558700;
    
    public static final int Widget_AppCompat_Button_Colored = 2131558701;
    
    public static final int Widget_AppCompat_Button_Small = 2131558702;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131558705;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131558706;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131558707;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131558708;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131558709;
    
    public static final int Widget_AppCompat_EditText = 2131558710;
    
    public static final int Widget_AppCompat_ImageButton = 2131558711;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131558712;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131558713;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131558714;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131558715;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131558716;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131558717;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131558718;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131558719;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131558720;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131558721;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131558722;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131558723;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131558724;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131558725;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131558726;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131558727;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131558728;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131558729;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131558730;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131558731;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131558732;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131558733;
    
    public static final int Widget_AppCompat_ListMenuView = 2131558734;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131558735;
    
    public static final int Widget_AppCompat_ListView = 2131558736;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131558737;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131558738;
    
    public static final int Widget_AppCompat_PopupMenu = 2131558739;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131558740;
    
    public static final int Widget_AppCompat_PopupWindow = 2131558741;
    
    public static final int Widget_AppCompat_ProgressBar = 2131558742;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131558743;
    
    public static final int Widget_AppCompat_RatingBar = 2131558744;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131558745;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131558746;
    
    public static final int Widget_AppCompat_SearchView = 2131558747;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131558748;
    
    public static final int Widget_AppCompat_SeekBar = 2131558749;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131558750;
    
    public static final int Widget_AppCompat_Spinner = 2131558751;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131558752;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131558753;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131558754;
    
    public static final int Widget_AppCompat_TextView = 2131558755;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131558756;
    
    public static final int Widget_AppCompat_Toolbar = 2131558757;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131558758;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131558759;
    
    public static final int Widget_Compat_NotificationActionText = 2131558760;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130837553, 2130837554, 2130837555, 2130837611, 2130837612, 2130837613, 2130837614, 2130837615, 2130837616, 2130837624, 
        2130837629, 2130837630, 2130837649, 2130837665, 2130837666, 2130837667, 2130837668, 2130837669, 2130837674, 2130837677, 
        2130837703, 2130837711, 2130837722, 2130837725, 2130837726, 2130837753, 2130837756, 2130837784, 2130837793 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130837553, 2130837554, 2130837583, 2130837665, 2130837756, 2130837793 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130837650, 2130837675 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130837567, 2130837568, 2130837692, 2130837693, 2130837708, 2130837742, 2130837743 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130837748, 2130837782, 2130837783 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130837779, 2130837780, 2130837781 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130837548, 2130837549, 2130837550, 2130837551, 2130837552, 2130837634, 2130837635, 2130837636, 2130837637, 
        2130837639, 2130837640, 2130837641, 2130837642, 2130837651, 2130837653, 2130837661, 2130837679, 2130837687, 2130837762, 
        2130837773 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130837504, 2130837505, 2130837506, 2130837507, 2130837508, 2130837509, 2130837510, 2130837511, 
        2130837512, 2130837513, 2130837514, 2130837515, 2130837516, 2130837518, 2130837519, 2130837520, 2130837521, 2130837522, 
        2130837523, 2130837524, 2130837525, 2130837526, 2130837527, 2130837528, 2130837529, 2130837530, 2130837531, 2130837532, 
        2130837533, 2130837534, 2130837537, 2130837538, 2130837539, 2130837540, 2130837541, 2130837547, 2130837559, 2130837560, 
        2130837561, 2130837562, 2130837563, 2130837564, 2130837569, 2130837570, 2130837580, 2130837581, 2130837587, 2130837588, 
        2130837589, 2130837590, 2130837591, 2130837592, 2130837593, 2130837594, 2130837595, 2130837596, 2130837622, 2130837626, 
        2130837627, 2130837628, 2130837631, 2130837633, 2130837644, 2130837645, 2130837646, 2130837647, 2130837648, 2130837667, 
        2130837673, 2130837688, 2130837689, 2130837690, 2130837691, 2130837694, 2130837695, 2130837696, 2130837697, 2130837698, 
        2130837699, 2130837700, 2130837701, 2130837702, 2130837718, 2130837719, 2130837720, 2130837721, 2130837723, 2130837729, 
        2130837730, 2130837731, 2130837732, 2130837735, 2130837736, 2130837737, 2130837738, 2130837745, 2130837746, 2130837760, 
        2130837763, 2130837764, 2130837765, 2130837766, 2130837767, 2130837768, 2130837769, 2130837770, 2130837771, 2130837772, 
        2130837794, 2130837795, 2130837796, 2130837797, 2130837803, 2130837805, 2130837806, 2130837807, 2130837808, 2130837809, 
        2130837810, 2130837811, 2130837812, 2130837813, 2130837814 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] ButtonBarLayout = new int[] { 2130837542 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130837543 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130837565, 2130837571, 2130837572 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130837545, 2130837546, 2130837558, 2130837586, 2130837638, 2130837663, 2130837744, 2130837775 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130837654, 2130837655, 2130837656, 2130837657, 2130837658, 2130837659 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130837652, 2130837660, 2130837661, 2130837662, 2130837802 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130837630, 2130837632, 2130837706, 2130837740 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130837517, 2130837535, 2130837536, 2130837544, 2130837610, 2130837670, 2130837671, 
        2130837712, 2130837739, 2130837798 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130837724, 2130837751 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130837713 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130837749 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130837714, 2130837717 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130837582, 2130837609, 2130837625, 2130837664, 2130837672, 2130837680, 
        2130837727, 2130837728, 2130837733, 2130837734, 2130837752, 2130837757, 2130837804 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130837722 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130837741, 2130837747, 2130837758, 2130837759, 2130837761, 2130837776, 2130837777, 
        2130837778, 2130837799, 2130837800, 2130837801 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130837653, 2130837661, 2130837762, 2130837773 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130837566, 2130837584, 2130837585, 2130837611, 2130837612, 2130837613, 2130837614, 2130837615, 
        2130837616, 2130837703, 2130837704, 2130837705, 2130837707, 2130837709, 2130837710, 2130837722, 2130837753, 2130837754, 
        2130837755, 2130837784, 2130837785, 2130837786, 2130837787, 2130837788, 2130837789, 2130837790, 2130837791, 2130837792 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130837715, 2130837716, 2130837774 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130837556, 2130837557 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\appcompat\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */