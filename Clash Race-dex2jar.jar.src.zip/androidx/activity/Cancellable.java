package androidx.activity;

interface Cancellable {
  void cancel();
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\activity\Cancellable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */