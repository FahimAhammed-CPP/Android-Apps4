package androidx.browser;

public final class R {
  public static final class attr {
    public static final int alpha = 2130837543;
    
    public static final int coordinatorLayoutStyle = 2130837623;
    
    public static final int font = 2130837652;
    
    public static final int fontProviderAuthority = 2130837654;
    
    public static final int fontProviderCerts = 2130837655;
    
    public static final int fontProviderFetchStrategy = 2130837656;
    
    public static final int fontProviderFetchTimeout = 2130837657;
    
    public static final int fontProviderPackage = 2130837658;
    
    public static final int fontProviderQuery = 2130837659;
    
    public static final int fontStyle = 2130837660;
    
    public static final int fontVariationSettings = 2130837661;
    
    public static final int fontWeight = 2130837662;
    
    public static final int keylines = 2130837678;
    
    public static final int layout_anchor = 2130837681;
    
    public static final int layout_anchorGravity = 2130837682;
    
    public static final int layout_behavior = 2130837683;
    
    public static final int layout_dodgeInsetEdges = 2130837684;
    
    public static final int layout_insetEdge = 2130837685;
    
    public static final int layout_keyline = 2130837686;
    
    public static final int statusBarBackground = 2130837750;
    
    public static final int ttcIndex = 2130837802;
  }
  
  public static final class color {
    public static final int browser_actions_bg_grey = 2130968612;
    
    public static final int browser_actions_divider_color = 2130968613;
    
    public static final int browser_actions_text_color = 2130968614;
    
    public static final int browser_actions_title_color = 2130968615;
    
    public static final int notification_action_color_filter = 2130968661;
    
    public static final int notification_icon_bg_color = 2130968662;
    
    public static final int ripple_material_light = 2130968673;
    
    public static final int secondary_text_default_material_light = 2130968675;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131034190;
    
    public static final int browser_actions_context_menu_min_padding = 2131034191;
    
    public static final int compat_button_inset_horizontal_material = 2131034211;
    
    public static final int compat_button_inset_vertical_material = 2131034212;
    
    public static final int compat_button_padding_horizontal_material = 2131034213;
    
    public static final int compat_button_padding_vertical_material = 2131034214;
    
    public static final int compat_control_corner_material = 2131034215;
    
    public static final int compat_notification_large_icon_max_height = 2131034216;
    
    public static final int compat_notification_large_icon_max_width = 2131034217;
    
    public static final int notification_action_icon_size = 2131034227;
    
    public static final int notification_action_text_size = 2131034228;
    
    public static final int notification_big_circle_margin = 2131034229;
    
    public static final int notification_content_margin_start = 2131034230;
    
    public static final int notification_large_icon_height = 2131034231;
    
    public static final int notification_large_icon_width = 2131034232;
    
    public static final int notification_main_column_padding_top = 2131034233;
    
    public static final int notification_media_narrow_margin = 2131034234;
    
    public static final int notification_right_icon_size = 2131034235;
    
    public static final int notification_right_side_padding_top = 2131034236;
    
    public static final int notification_small_icon_background_padding = 2131034237;
    
    public static final int notification_small_icon_size_as_large = 2131034238;
    
    public static final int notification_subtext_size = 2131034239;
    
    public static final int notification_top_pad = 2131034240;
    
    public static final int notification_top_pad_large_text = 2131034241;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131099765;
    
    public static final int notification_bg = 2131099766;
    
    public static final int notification_bg_low = 2131099767;
    
    public static final int notification_bg_low_normal = 2131099768;
    
    public static final int notification_bg_low_pressed = 2131099769;
    
    public static final int notification_bg_normal = 2131099770;
    
    public static final int notification_bg_normal_pressed = 2131099771;
    
    public static final int notification_icon_background = 2131099772;
    
    public static final int notification_template_icon_bg = 2131099773;
    
    public static final int notification_template_icon_low_bg = 2131099774;
    
    public static final int notification_tile_bg = 2131099775;
    
    public static final int notify_panel_notification_icon_bg = 2131099776;
  }
  
  public static final class id {
    public static final int action_container = 2131165231;
    
    public static final int action_divider = 2131165233;
    
    public static final int action_image = 2131165234;
    
    public static final int action_text = 2131165240;
    
    public static final int actions = 2131165241;
    
    public static final int async = 2131165247;
    
    public static final int blocking = 2131165250;
    
    public static final int bottom = 2131165251;
    
    public static final int browser_actions_header_text = 2131165253;
    
    public static final int browser_actions_menu_item_icon = 2131165254;
    
    public static final int browser_actions_menu_item_text = 2131165255;
    
    public static final int browser_actions_menu_items = 2131165256;
    
    public static final int browser_actions_menu_view = 2131165257;
    
    public static final int chronometer = 2131165267;
    
    public static final int end = 2131165292;
    
    public static final int forever = 2131165299;
    
    public static final int icon = 2131165303;
    
    public static final int icon_group = 2131165304;
    
    public static final int info = 2131165307;
    
    public static final int italic = 2131165309;
    
    public static final int left = 2131165311;
    
    public static final int line1 = 2131165312;
    
    public static final int line3 = 2131165313;
    
    public static final int none = 2131165322;
    
    public static final int normal = 2131165323;
    
    public static final int notification_background = 2131165324;
    
    public static final int notification_main_column = 2131165325;
    
    public static final int notification_main_column_container = 2131165326;
    
    public static final int right = 2131165336;
    
    public static final int right_icon = 2131165337;
    
    public static final int right_side = 2131165338;
    
    public static final int start = 2131165365;
    
    public static final int tag_transition_group = 2131165375;
    
    public static final int tag_unhandled_key_event_manager = 2131165376;
    
    public static final int tag_unhandled_key_listeners = 2131165377;
    
    public static final int text = 2131165378;
    
    public static final int text2 = 2131165379;
    
    public static final int time = 2131165382;
    
    public static final int title = 2131165383;
    
    public static final int top = 2131165386;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131230725;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131361820;
    
    public static final int browser_actions_context_menu_row = 2131361821;
    
    public static final int notification_action = 2131361828;
    
    public static final int notification_action_tombstone = 2131361829;
    
    public static final int notification_template_custom_big = 2131361836;
    
    public static final int notification_template_icon_group = 2131361837;
    
    public static final int notification_template_part_chronometer = 2131361841;
    
    public static final int notification_template_part_time = 2131361842;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131492918;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131558641;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131558642;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131558644;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131558647;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131558649;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131558759;
    
    public static final int Widget_Compat_NotificationActionText = 2131558760;
    
    public static final int Widget_Support_CoordinatorLayout = 2131558761;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130837543 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CoordinatorLayout = new int[] { 2130837678, 2130837750 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130837681, 2130837682, 2130837683, 2130837684, 2130837685, 2130837686 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130837654, 2130837655, 2130837656, 2130837657, 2130837658, 2130837659 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130837652, 2130837660, 2130837661, 2130837662, 2130837802 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */