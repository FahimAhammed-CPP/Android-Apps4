package androidx.documentfile;

public final class R {}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\documentfile\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */