package androidx.core.view;

public interface NestedScrollingChild3 extends NestedScrollingChild2 {
  void dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2);
}


/* Location:              C:\soft\dex2jar-2.0\Clash Race-dex2jar.jar!\androidx\core\view\NestedScrollingChild3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */