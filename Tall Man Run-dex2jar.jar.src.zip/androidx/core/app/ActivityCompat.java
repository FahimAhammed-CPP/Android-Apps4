package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.LocusId;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.DragEvent;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.content.LocusIdCompat;
import androidx.core.view.DragAndDropPermissionsCompat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ActivityCompat extends ContextCompat {
  private static PermissionCompatDelegate sDelegate;
  
  public static void finishAffinity(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.finishAffinity();
      return;
    } 
    paramActivity.finish();
  }
  
  public static void finishAfterTransition(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 21) {
      paramActivity.finishAfterTransition();
      return;
    } 
    paramActivity.finish();
  }
  
  public static PermissionCompatDelegate getPermissionCompatDelegate() {
    return sDelegate;
  }
  
  public static Uri getReferrer(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 22)
      return paramActivity.getReferrer(); 
    Intent intent = paramActivity.getIntent();
    Uri uri = (Uri)intent.getParcelableExtra("android.intent.extra.REFERRER");
    if (uri != null)
      return uri; 
    String str = intent.getStringExtra("android.intent.extra.REFERRER_NAME");
    return (str != null) ? Uri.parse(str) : null;
  }
  
  @Deprecated
  public static boolean invalidateOptionsMenu(Activity paramActivity) {
    paramActivity.invalidateOptionsMenu();
    return true;
  }
  
  public static void postponeEnterTransition(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 21)
      paramActivity.postponeEnterTransition(); 
  }
  
  public static void recreate(final Activity activity) {
    if (Build.VERSION.SDK_INT >= 28) {
      activity.recreate();
      return;
    } 
    if (Build.VERSION.SDK_INT <= 23) {
      (new Handler(activity.getMainLooper())).post(new Runnable() {
            public void run() {
              if (!activity.isFinishing() && !ActivityRecreator.recreate(activity))
                activity.recreate(); 
            }
          });
      return;
    } 
    if (!ActivityRecreator.recreate(activity))
      activity.recreate(); 
  }
  
  public static DragAndDropPermissionsCompat requestDragAndDropPermissions(Activity paramActivity, DragEvent paramDragEvent) {
    return DragAndDropPermissionsCompat.request(paramActivity, paramDragEvent);
  }
  
  public static void requestPermissions(Activity paramActivity, final String[] permissions, final int requestCode) {
    final StringBuilder activity;
    PermissionCompatDelegate permissionCompatDelegate = sDelegate;
    if (permissionCompatDelegate != null && permissionCompatDelegate.requestPermissions(paramActivity, permissions, requestCode))
      return; 
    int j = permissions.length;
    int i = 0;
    while (i < j) {
      if (!TextUtils.isEmpty(permissions[i])) {
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])permissions));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof RequestPermissionsRequestCodeValidator)
        ((RequestPermissionsRequestCodeValidator)stringBuilder).validateRequestPermissionsRequestCode(requestCode); 
      stringBuilder.requestPermissions(permissions, requestCode);
      return;
    } 
    if (stringBuilder instanceof OnRequestPermissionsResultCallback)
      (new Handler(Looper.getMainLooper())).post(new Runnable() {
            public void run() {
              int[] arrayOfInt = new int[permissions.length];
              PackageManager packageManager = activity.getPackageManager();
              String str = activity.getPackageName();
              int j = permissions.length;
              for (int i = 0; i < j; i++)
                arrayOfInt[i] = packageManager.checkPermission(permissions[i], str); 
              ((ActivityCompat.OnRequestPermissionsResultCallback)activity).onRequestPermissionsResult(requestCode, permissions, arrayOfInt);
            }
          }); 
  }
  
  public static <T extends View> T requireViewById(Activity paramActivity, int paramInt) {
    if (Build.VERSION.SDK_INT >= 28)
      return (T)paramActivity.requireViewById(paramInt); 
    View view = paramActivity.findViewById(paramInt);
    if (view != null)
      return (T)view; 
    throw new IllegalArgumentException("ID does not reference a View inside this Activity");
  }
  
  public static void setEnterSharedElementCallback(Activity paramActivity, SharedElementCallback paramSharedElementCallback) {
    if (Build.VERSION.SDK_INT >= 21) {
      if (paramSharedElementCallback != null) {
        SharedElementCallback21Impl sharedElementCallback21Impl = new SharedElementCallback21Impl(paramSharedElementCallback);
      } else {
        paramSharedElementCallback = null;
      } 
      paramActivity.setEnterSharedElementCallback((SharedElementCallback)paramSharedElementCallback);
    } 
  }
  
  public static void setExitSharedElementCallback(Activity paramActivity, SharedElementCallback paramSharedElementCallback) {
    if (Build.VERSION.SDK_INT >= 21) {
      if (paramSharedElementCallback != null) {
        SharedElementCallback21Impl sharedElementCallback21Impl = new SharedElementCallback21Impl(paramSharedElementCallback);
      } else {
        paramSharedElementCallback = null;
      } 
      paramActivity.setExitSharedElementCallback((SharedElementCallback)paramSharedElementCallback);
    } 
  }
  
  public static void setLocusContext(Activity paramActivity, LocusIdCompat paramLocusIdCompat, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 30)
      Api30Impl.setLocusContext(paramActivity, paramLocusIdCompat, paramBundle); 
  }
  
  public static void setPermissionCompatDelegate(PermissionCompatDelegate paramPermissionCompatDelegate) {
    sDelegate = paramPermissionCompatDelegate;
  }
  
  public static boolean shouldShowRequestPermissionRationale(Activity paramActivity, String paramString) {
    return (Build.VERSION.SDK_INT >= 23) ? paramActivity.shouldShowRequestPermissionRationale(paramString) : false;
  }
  
  public static void startActivityForResult(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.startActivityForResult(paramIntent, paramInt, paramBundle);
      return;
    } 
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }
  
  public static void startIntentSenderForResult(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    } 
    paramActivity.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public static void startPostponedEnterTransition(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 21)
      paramActivity.startPostponedEnterTransition(); 
  }
  
  static class Api30Impl {
    static void setLocusContext(Activity param1Activity, LocusIdCompat param1LocusIdCompat, Bundle param1Bundle) {
      LocusId locusId;
      if (param1LocusIdCompat == null) {
        param1LocusIdCompat = null;
      } else {
        locusId = param1LocusIdCompat.toLocusId();
      } 
      param1Activity.setLocusContext(locusId, param1Bundle);
    }
  }
  
  public static interface OnRequestPermissionsResultCallback {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface PermissionCompatDelegate {
    boolean onActivityResult(Activity param1Activity, int param1Int1, int param1Int2, Intent param1Intent);
    
    boolean requestPermissions(Activity param1Activity, String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface RequestPermissionsRequestCodeValidator {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
  
  private static class SharedElementCallback21Impl extends SharedElementCallback {
    private final SharedElementCallback mCallback;
    
    SharedElementCallback21Impl(SharedElementCallback param1SharedElementCallback) {
      this.mCallback = param1SharedElementCallback;
    }
    
    public Parcelable onCaptureSharedElementSnapshot(View param1View, Matrix param1Matrix, RectF param1RectF) {
      return this.mCallback.onCaptureSharedElementSnapshot(param1View, param1Matrix, param1RectF);
    }
    
    public View onCreateSnapshotView(Context param1Context, Parcelable param1Parcelable) {
      return this.mCallback.onCreateSnapshotView(param1Context, param1Parcelable);
    }
    
    public void onMapSharedElements(List<String> param1List, Map<String, View> param1Map) {
      this.mCallback.onMapSharedElements(param1List, param1Map);
    }
    
    public void onRejectSharedElements(List<View> param1List) {
      this.mCallback.onRejectSharedElements(param1List);
    }
    
    public void onSharedElementEnd(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.mCallback.onSharedElementEnd(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementStart(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.mCallback.onSharedElementStart(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementsArrived(List<String> param1List, List<View> param1List1, final SharedElementCallback.OnSharedElementsReadyListener listener) {
      this.mCallback.onSharedElementsArrived(param1List, param1List1, new SharedElementCallback.OnSharedElementsReadyListener() {
            public void onSharedElementsReady() {
              listener.onSharedElementsReady();
            }
          });
    }
  }
  
  class null implements SharedElementCallback.OnSharedElementsReadyListener {
    public void onSharedElementsReady() {
      listener.onSharedElementsReady();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\core\app\ActivityCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */