package androidx.core.graphics.drawable;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\"\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\005\032*\020\000\032\0020\001*\0020\0022\b\b\003\020\003\032\0020\0042\b\b\003\020\005\032\0020\0042\n\b\002\020\006\032\004\030\0010\007\0322\020\b\032\0020\t*\0020\0022\b\b\003\020\n\032\0020\0042\b\b\003\020\013\032\0020\0042\b\b\003\020\f\032\0020\0042\b\b\003\020\r\032\0020\004¨\006\016"}, d2 = {"toBitmap", "Landroid/graphics/Bitmap;", "Landroid/graphics/drawable/Drawable;", "width", "", "height", "config", "Landroid/graphics/Bitmap$Config;", "updateBounds", "", "left", "top", "right", "bottom", "core-ktx_release"}, k = 2, mv = {1, 1, 16})
public final class DrawableKt {
  public static final Bitmap toBitmap(Drawable paramDrawable, int paramInt1, int paramInt2, Bitmap.Config paramConfig) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '$this$toBitmap'
    //   3: invokestatic checkParameterIsNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: instanceof android/graphics/drawable/BitmapDrawable
    //   10: ifeq -> 95
    //   13: aload_3
    //   14: ifnull -> 42
    //   17: aload_0
    //   18: checkcast android/graphics/drawable/BitmapDrawable
    //   21: invokevirtual getBitmap : ()Landroid/graphics/Bitmap;
    //   24: astore #8
    //   26: aload #8
    //   28: ldc 'bitmap'
    //   30: invokestatic checkExpressionValueIsNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
    //   33: aload #8
    //   35: invokevirtual getConfig : ()Landroid/graphics/Bitmap$Config;
    //   38: aload_3
    //   39: if_acmpne -> 95
    //   42: aload_0
    //   43: checkcast android/graphics/drawable/BitmapDrawable
    //   46: astore_0
    //   47: iload_1
    //   48: aload_0
    //   49: invokevirtual getIntrinsicWidth : ()I
    //   52: if_icmpne -> 76
    //   55: iload_2
    //   56: aload_0
    //   57: invokevirtual getIntrinsicHeight : ()I
    //   60: if_icmpne -> 76
    //   63: aload_0
    //   64: invokevirtual getBitmap : ()Landroid/graphics/Bitmap;
    //   67: astore_0
    //   68: aload_0
    //   69: ldc 'bitmap'
    //   71: invokestatic checkExpressionValueIsNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
    //   74: aload_0
    //   75: areturn
    //   76: aload_0
    //   77: invokevirtual getBitmap : ()Landroid/graphics/Bitmap;
    //   80: iload_1
    //   81: iload_2
    //   82: iconst_1
    //   83: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   86: astore_0
    //   87: aload_0
    //   88: ldc 'Bitmap.createScaledBitma…map, width, height, true)'
    //   90: invokestatic checkExpressionValueIsNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
    //   93: aload_0
    //   94: areturn
    //   95: aload_0
    //   96: invokevirtual getBounds : ()Landroid/graphics/Rect;
    //   99: astore #8
    //   101: aload #8
    //   103: getfield left : I
    //   106: istore #4
    //   108: aload #8
    //   110: getfield top : I
    //   113: istore #5
    //   115: aload #8
    //   117: getfield right : I
    //   120: istore #6
    //   122: aload #8
    //   124: getfield bottom : I
    //   127: istore #7
    //   129: aload_3
    //   130: ifnull -> 136
    //   133: goto -> 140
    //   136: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
    //   139: astore_3
    //   140: iload_1
    //   141: iload_2
    //   142: aload_3
    //   143: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   146: astore_3
    //   147: aload_0
    //   148: iconst_0
    //   149: iconst_0
    //   150: iload_1
    //   151: iload_2
    //   152: invokevirtual setBounds : (IIII)V
    //   155: aload_0
    //   156: new android/graphics/Canvas
    //   159: dup
    //   160: aload_3
    //   161: invokespecial <init> : (Landroid/graphics/Bitmap;)V
    //   164: invokevirtual draw : (Landroid/graphics/Canvas;)V
    //   167: aload_0
    //   168: iload #4
    //   170: iload #5
    //   172: iload #6
    //   174: iload #7
    //   176: invokevirtual setBounds : (IIII)V
    //   179: aload_3
    //   180: ldc 'bitmap'
    //   182: invokestatic checkExpressionValueIsNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
    //   185: aload_3
    //   186: areturn
  }
  
  public static final void updateBounds(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Intrinsics.checkParameterIsNotNull(paramDrawable, "$this$updateBounds");
    paramDrawable.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\core\graphics\drawable\DrawableKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */