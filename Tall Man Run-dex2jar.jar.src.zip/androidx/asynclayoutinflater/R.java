package androidx.asynclayoutinflater;

public final class R {
  public static final class attr {
    public static final int alpha = 2130968658;
    
    public static final int font = 2130968994;
    
    public static final int fontProviderAuthority = 2130968996;
    
    public static final int fontProviderCerts = 2130968997;
    
    public static final int fontProviderFetchStrategy = 2130968998;
    
    public static final int fontProviderFetchTimeout = 2130968999;
    
    public static final int fontProviderPackage = 2130969000;
    
    public static final int fontProviderQuery = 2130969001;
    
    public static final int fontStyle = 2130969003;
    
    public static final int fontVariationSettings = 2130969004;
    
    public static final int fontWeight = 2130969005;
    
    public static final int ttcIndex = 2130969509;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131099973;
    
    public static final int notification_icon_bg_color = 2131099974;
    
    public static final int ripple_material_light = 2131099986;
    
    public static final int secondary_text_default_material_light = 2131099988;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131165342;
    
    public static final int compat_button_inset_vertical_material = 2131165343;
    
    public static final int compat_button_padding_horizontal_material = 2131165344;
    
    public static final int compat_button_padding_vertical_material = 2131165345;
    
    public static final int compat_control_corner_material = 2131165346;
    
    public static final int compat_notification_large_icon_max_height = 2131165347;
    
    public static final int compat_notification_large_icon_max_width = 2131165348;
    
    public static final int notification_action_icon_size = 2131165705;
    
    public static final int notification_action_text_size = 2131165706;
    
    public static final int notification_big_circle_margin = 2131165707;
    
    public static final int notification_content_margin_start = 2131165708;
    
    public static final int notification_large_icon_height = 2131165709;
    
    public static final int notification_large_icon_width = 2131165710;
    
    public static final int notification_main_column_padding_top = 2131165711;
    
    public static final int notification_media_narrow_margin = 2131165712;
    
    public static final int notification_right_icon_size = 2131165713;
    
    public static final int notification_right_side_padding_top = 2131165714;
    
    public static final int notification_small_icon_background_padding = 2131165715;
    
    public static final int notification_small_icon_size_as_large = 2131165716;
    
    public static final int notification_subtext_size = 2131165717;
    
    public static final int notification_top_pad = 2131165718;
    
    public static final int notification_top_pad_large_text = 2131165719;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131231209;
    
    public static final int notification_bg = 2131231210;
    
    public static final int notification_bg_low = 2131231211;
    
    public static final int notification_bg_low_normal = 2131231212;
    
    public static final int notification_bg_low_pressed = 2131231213;
    
    public static final int notification_bg_normal = 2131231214;
    
    public static final int notification_bg_normal_pressed = 2131231215;
    
    public static final int notification_icon_background = 2131231216;
    
    public static final int notification_template_icon_bg = 2131231217;
    
    public static final int notification_template_icon_low_bg = 2131231218;
    
    public static final int notification_tile_bg = 2131231219;
    
    public static final int notify_panel_notification_icon_bg = 2131231220;
  }
  
  public static final class id {
    public static final int action_container = 2131361848;
    
    public static final int action_divider = 2131361850;
    
    public static final int action_image = 2131361851;
    
    public static final int action_text = 2131361858;
    
    public static final int actions = 2131361859;
    
    public static final int async = 2131361949;
    
    public static final int blocking = 2131361964;
    
    public static final int chronometer = 2131361995;
    
    public static final int forever = 2131362093;
    
    public static final int icon = 2131362143;
    
    public static final int icon_group = 2131362144;
    
    public static final int info = 2131362153;
    
    public static final int italic = 2131362171;
    
    public static final int line1 = 2131362185;
    
    public static final int line3 = 2131362186;
    
    public static final int normal = 2131362393;
    
    public static final int notification_background = 2131362394;
    
    public static final int notification_main_column = 2131362395;
    
    public static final int notification_main_column_container = 2131362396;
    
    public static final int right_icon = 2131362442;
    
    public static final int right_side = 2131362443;
    
    public static final int tag_transition_group = 2131362527;
    
    public static final int tag_unhandled_key_event_manager = 2131362528;
    
    public static final int tag_unhandled_key_listeners = 2131362529;
    
    public static final int text = 2131362535;
    
    public static final int text2 = 2131362536;
    
    public static final int time = 2131362553;
    
    public static final int title = 2131362557;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131427362;
  }
  
  public static final class layout {
    public static final int notification_action = 2131558581;
    
    public static final int notification_action_tombstone = 2131558582;
    
    public static final int notification_template_custom_big = 2131558589;
    
    public static final int notification_template_icon_group = 2131558590;
    
    public static final int notification_template_part_chronometer = 2131558594;
    
    public static final int notification_template_part_time = 2131558595;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131886454;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131952037;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131952038;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131952040;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131952043;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131952045;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952285;
    
    public static final int Widget_Compat_NotificationActionText = 2131952286;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968658 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] FontFamily = new int[] { 2130968996, 2130968997, 2130968998, 2130968999, 2130969000, 2130969001, 2130969002 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968994, 2130969003, 2130969004, 2130969005, 2130969509 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\asynclayoutinflater\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */