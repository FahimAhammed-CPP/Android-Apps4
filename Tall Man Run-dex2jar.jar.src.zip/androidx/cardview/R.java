package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130968737;
    
    public static final int cardCornerRadius = 2130968738;
    
    public static final int cardElevation = 2130968739;
    
    public static final int cardMaxElevation = 2130968741;
    
    public static final int cardPreventCornerOverlap = 2130968742;
    
    public static final int cardUseCompatPadding = 2130968743;
    
    public static final int cardViewStyle = 2130968744;
    
    public static final int contentPadding = 2130968849;
    
    public static final int contentPaddingBottom = 2130968850;
    
    public static final int contentPaddingLeft = 2130968852;
    
    public static final int contentPaddingRight = 2130968853;
    
    public static final int contentPaddingTop = 2130968855;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131099722;
    
    public static final int cardview_light_background = 2131099723;
    
    public static final int cardview_shadow_end_color = 2131099724;
    
    public static final int cardview_shadow_start_color = 2131099725;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131165322;
    
    public static final int cardview_default_elevation = 2131165323;
    
    public static final int cardview_default_radius = 2131165324;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131951664;
    
    public static final int CardView = 2131951878;
    
    public static final int CardView_Dark = 2131951879;
    
    public static final int CardView_Light = 2131951880;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130968737, 2130968738, 2130968739, 2130968741, 2130968742, 2130968743, 2130968849, 2130968850, 
        2130968852, 2130968853, 2130968855 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */