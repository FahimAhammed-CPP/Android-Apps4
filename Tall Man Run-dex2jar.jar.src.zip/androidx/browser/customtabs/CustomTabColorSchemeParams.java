package androidx.browser.customtabs;

import android.os.Bundle;

public final class CustomTabColorSchemeParams {
  public final Integer navigationBarColor;
  
  public final Integer navigationBarDividerColor;
  
  public final Integer secondaryToolbarColor;
  
  public final Integer toolbarColor;
  
  CustomTabColorSchemeParams(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4) {
    this.toolbarColor = paramInteger1;
    this.secondaryToolbarColor = paramInteger2;
    this.navigationBarColor = paramInteger3;
    this.navigationBarDividerColor = paramInteger4;
  }
  
  static CustomTabColorSchemeParams fromBundle(Bundle paramBundle) {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(0); 
    return new CustomTabColorSchemeParams((Integer)bundle.get("android.support.customtabs.extra.TOOLBAR_COLOR"), (Integer)bundle.get("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR"), (Integer)bundle.get("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR"), (Integer)bundle.get("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR"));
  }
  
  Bundle toBundle() {
    Bundle bundle = new Bundle();
    Integer integer = this.toolbarColor;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", integer.intValue()); 
    integer = this.secondaryToolbarColor;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR", integer.intValue()); 
    integer = this.navigationBarColor;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR", integer.intValue()); 
    integer = this.navigationBarDividerColor;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR", integer.intValue()); 
    return bundle;
  }
  
  CustomTabColorSchemeParams withDefaults(CustomTabColorSchemeParams paramCustomTabColorSchemeParams) {
    Integer integer2 = this.toolbarColor;
    Integer integer1 = integer2;
    if (integer2 == null)
      integer1 = paramCustomTabColorSchemeParams.toolbarColor; 
    Integer integer3 = this.secondaryToolbarColor;
    integer2 = integer3;
    if (integer3 == null)
      integer2 = paramCustomTabColorSchemeParams.secondaryToolbarColor; 
    Integer integer4 = this.navigationBarColor;
    integer3 = integer4;
    if (integer4 == null)
      integer3 = paramCustomTabColorSchemeParams.navigationBarColor; 
    Integer integer5 = this.navigationBarDividerColor;
    integer4 = integer5;
    if (integer5 == null)
      integer4 = paramCustomTabColorSchemeParams.navigationBarDividerColor; 
    return new CustomTabColorSchemeParams(integer1, integer2, integer3, integer4);
  }
  
  public static final class Builder {
    private Integer mNavigationBarColor;
    
    private Integer mNavigationBarDividerColor;
    
    private Integer mSecondaryToolbarColor;
    
    private Integer mToolbarColor;
    
    public CustomTabColorSchemeParams build() {
      return new CustomTabColorSchemeParams(this.mToolbarColor, this.mSecondaryToolbarColor, this.mNavigationBarColor, this.mNavigationBarDividerColor);
    }
    
    public Builder setNavigationBarColor(int param1Int) {
      this.mNavigationBarColor = Integer.valueOf(param1Int | 0xFF000000);
      return this;
    }
    
    public Builder setNavigationBarDividerColor(int param1Int) {
      this.mNavigationBarDividerColor = Integer.valueOf(param1Int);
      return this;
    }
    
    public Builder setSecondaryToolbarColor(int param1Int) {
      this.mSecondaryToolbarColor = Integer.valueOf(param1Int);
      return this;
    }
    
    public Builder setToolbarColor(int param1Int) {
      this.mToolbarColor = Integer.valueOf(param1Int | 0xFF000000);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\browser\customtabs\CustomTabColorSchemeParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */