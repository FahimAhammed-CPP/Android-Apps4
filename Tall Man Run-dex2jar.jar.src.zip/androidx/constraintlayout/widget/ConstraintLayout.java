package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final boolean MEASURE = false;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-2.0.4";
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  protected ConstraintLayoutStates mConstraintLayoutSpec = null;
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private ConstraintsChangedListener mConstraintsChangedListener;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  protected boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  protected ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  Measurer mMeasurer = new Measurer(this);
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOnMeasureHeightMeasureSpec = 0;
  
  private int mOnMeasureWidthMeasureSpec = 0;
  
  private int mOptimizationLevel = 257;
  
  private SparseArray<ConstraintWidget> mTempMapIdToWidget = new SparseArray();
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int getPaddingWidth() {
    int j = getPaddingLeft();
    int i = 0;
    j = Math.max(0, j) + Math.max(0, getPaddingRight());
    if (Build.VERSION.SDK_INT >= 17) {
      i = Math.max(0, getPaddingStart());
      i = Math.max(0, getPaddingEnd()) + i;
    } 
    if (i > 0)
      j = i; 
    return j;
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view2 = (View)this.mChildrenByIds.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (ConstraintWidget)((view1 == this) ? this.mLayoutWidget : ((view1 == null) ? null : ((LayoutParams)view1.getLayoutParams()).widget));
  }
  
  private void init(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mLayoutWidget.setMeasurer(this.mMeasurer);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int i = typedArray.getIndex(paramInt1);
          if (i == R.styleable.ConstraintLayout_Layout_android_minWidth) {
            this.mMinWidth = typedArray.getDimensionPixelOffset(i, this.mMinWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_minHeight) {
            this.mMinHeight = typedArray.getDimensionPixelOffset(i, this.mMinHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
            this.mMaxWidth = typedArray.getDimensionPixelOffset(i, this.mMaxWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
            this.mMaxHeight = typedArray.getDimensionPixelOffset(i, this.mMaxHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
            this.mOptimizationLevel = typedArray.getInt(i, this.mOptimizationLevel);
          } else if (i == R.styleable.ConstraintLayout_Layout_layoutDescription) {
            i = typedArray.getResourceId(i, 0);
            if (i != 0)
              try {
                parseLayoutDescription(i);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.mConstraintLayoutSpec = null;
              }  
          } else if (i == R.styleable.ConstraintLayout_Layout_constraintSet) {
            i = typedArray.getResourceId(i, 0);
            try {
              ConstraintSet constraintSet = new ConstraintSet();
              this.mConstraintSet = constraintSet;
              constraintSet.load(getContext(), i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.mConstraintSet = null;
            } 
            this.mConstraintSetId = i;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
        return;
      } 
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void markHierarchyDirty() {
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual reset : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   133: aload #5
    //   135: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield mConstraintSetId : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 206
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 206
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: astore #5
    //   167: aload #5
    //   169: invokevirtual getId : ()I
    //   172: aload_0
    //   173: getfield mConstraintSetId : I
    //   176: if_icmpne -> 199
    //   179: aload #5
    //   181: instanceof androidx/constraintlayout/widget/Constraints
    //   184: ifeq -> 199
    //   187: aload_0
    //   188: aload #5
    //   190: checkcast androidx/constraintlayout/widget/Constraints
    //   193: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   196: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   199: iload_1
    //   200: iconst_1
    //   201: iadd
    //   202: istore_1
    //   203: goto -> 155
    //   206: aload_0
    //   207: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   210: astore #5
    //   212: aload #5
    //   214: ifnull -> 224
    //   217: aload #5
    //   219: aload_0
    //   220: iconst_1
    //   221: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   224: aload_0
    //   225: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   228: invokevirtual removeAllChildren : ()V
    //   231: aload_0
    //   232: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   235: invokevirtual size : ()I
    //   238: istore_3
    //   239: iload_3
    //   240: ifle -> 272
    //   243: iconst_0
    //   244: istore_1
    //   245: iload_1
    //   246: iload_3
    //   247: if_icmpge -> 272
    //   250: aload_0
    //   251: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   254: iload_1
    //   255: invokevirtual get : (I)Ljava/lang/Object;
    //   258: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   261: aload_0
    //   262: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   265: iload_1
    //   266: iconst_1
    //   267: iadd
    //   268: istore_1
    //   269: goto -> 245
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: iload_2
    //   276: if_icmpge -> 310
    //   279: aload_0
    //   280: iload_1
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: astore #5
    //   286: aload #5
    //   288: instanceof androidx/constraintlayout/widget/Placeholder
    //   291: ifeq -> 303
    //   294: aload #5
    //   296: checkcast androidx/constraintlayout/widget/Placeholder
    //   299: aload_0
    //   300: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   303: iload_1
    //   304: iconst_1
    //   305: iadd
    //   306: istore_1
    //   307: goto -> 274
    //   310: aload_0
    //   311: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   314: invokevirtual clear : ()V
    //   317: aload_0
    //   318: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   321: iconst_0
    //   322: aload_0
    //   323: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   326: invokevirtual put : (ILjava/lang/Object;)V
    //   329: aload_0
    //   330: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   333: aload_0
    //   334: invokevirtual getId : ()I
    //   337: aload_0
    //   338: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   341: invokevirtual put : (ILjava/lang/Object;)V
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 387
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   364: astore #6
    //   366: aload_0
    //   367: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   370: aload #5
    //   372: invokevirtual getId : ()I
    //   375: aload #6
    //   377: invokevirtual put : (ILjava/lang/Object;)V
    //   380: iload_1
    //   381: iconst_1
    //   382: iadd
    //   383: istore_1
    //   384: goto -> 346
    //   387: iconst_0
    //   388: istore_1
    //   389: iload_1
    //   390: iload_2
    //   391: if_icmpge -> 459
    //   394: aload_0
    //   395: iload_1
    //   396: invokevirtual getChildAt : (I)Landroid/view/View;
    //   399: astore #5
    //   401: aload_0
    //   402: aload #5
    //   404: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   407: astore #6
    //   409: aload #6
    //   411: ifnonnull -> 417
    //   414: goto -> 452
    //   417: aload #5
    //   419: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   422: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   425: astore #7
    //   427: aload_0
    //   428: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   431: aload #6
    //   433: invokevirtual add : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   436: aload_0
    //   437: iload #4
    //   439: aload #5
    //   441: aload #6
    //   443: aload #7
    //   445: aload_0
    //   446: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   449: invokevirtual applyConstraintsFromLayoutParams : (ZLandroid/view/View;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Landroid/util/SparseArray;)V
    //   452: iload_1
    //   453: iconst_1
    //   454: iadd
    //   455: istore_1
    //   456: goto -> 389
    //   459: return
    //   460: astore #5
    //   462: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	460	android/content/res/Resources$NotFoundException
    //   114	124	460	android/content/res/Resources$NotFoundException
    //   124	138	460	android/content/res/Resources$NotFoundException
  }
  
  private boolean updateHierarchy() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (getChildAt(i).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1)
      setChildrenConstraints(); 
    return bool1;
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected void applyConstraintsFromLayoutParams(boolean paramBoolean, View paramView, ConstraintWidget paramConstraintWidget, LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray) {
    paramLayoutParams.validate();
    paramLayoutParams.helped = false;
    paramConstraintWidget.setVisibility(paramView.getVisibility());
    if (paramLayoutParams.isInPlaceholder) {
      paramConstraintWidget.setInPlaceholder(true);
      paramConstraintWidget.setVisibility(8);
    } 
    paramConstraintWidget.setCompanionWidget(paramView);
    if (paramView instanceof ConstraintHelper)
      ((ConstraintHelper)paramView).resolveRtl(paramConstraintWidget, this.mLayoutWidget.isRtl()); 
    if (paramLayoutParams.isGuideline) {
      Guideline guideline = (Guideline)paramConstraintWidget;
      int i = paramLayoutParams.resolvedGuideBegin;
      int j = paramLayoutParams.resolvedGuideEnd;
      float f = paramLayoutParams.resolvedGuidePercent;
      if (Build.VERSION.SDK_INT < 17) {
        i = paramLayoutParams.guideBegin;
        j = paramLayoutParams.guideEnd;
        f = paramLayoutParams.guidePercent;
      } 
      if (f != -1.0F) {
        guideline.setGuidePercent(f);
        return;
      } 
      if (i != -1) {
        guideline.setGuideBegin(i);
        return;
      } 
      if (j != -1) {
        guideline.setGuideEnd(j);
        return;
      } 
    } else {
      int i = paramLayoutParams.resolvedLeftToLeft;
      int j = paramLayoutParams.resolvedLeftToRight;
      int m = paramLayoutParams.resolvedRightToLeft;
      int k = paramLayoutParams.resolvedRightToRight;
      int i1 = paramLayoutParams.resolveGoneLeftMargin;
      int n = paramLayoutParams.resolveGoneRightMargin;
      float f = paramLayoutParams.resolvedHorizontalBias;
      if (Build.VERSION.SDK_INT < 17) {
        k = paramLayoutParams.leftToLeft;
        m = paramLayoutParams.leftToRight;
        int i2 = paramLayoutParams.rightToLeft;
        int i3 = paramLayoutParams.rightToRight;
        i1 = paramLayoutParams.goneLeftMargin;
        n = paramLayoutParams.goneRightMargin;
        f = paramLayoutParams.horizontalBias;
        i = k;
        j = m;
        if (k == -1) {
          i = k;
          j = m;
          if (m == -1)
            if (paramLayoutParams.startToStart != -1) {
              i = paramLayoutParams.startToStart;
              j = m;
            } else {
              i = k;
              j = m;
              if (paramLayoutParams.startToEnd != -1) {
                j = paramLayoutParams.startToEnd;
                i = k;
              } 
            }  
        } 
        m = i2;
        k = i3;
        if (i2 == -1) {
          m = i2;
          k = i3;
          if (i3 == -1)
            if (paramLayoutParams.endToStart != -1) {
              m = paramLayoutParams.endToStart;
              k = i3;
            } else {
              m = i2;
              k = i3;
              if (paramLayoutParams.endToEnd != -1) {
                k = paramLayoutParams.endToEnd;
                m = i2;
              } 
            }  
        } 
      } 
      if (paramLayoutParams.circleConstraint != -1) {
        ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.circleConstraint);
        if (constraintWidget != null)
          paramConstraintWidget.connectCircularConstraint(constraintWidget, paramLayoutParams.circleAngle, paramLayoutParams.circleRadius); 
      } else {
        if (i != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(i);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.leftMargin, i1); 
        } else if (j != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(j);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.leftMargin, i1); 
        } 
        if (m != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(m);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.rightMargin, n); 
        } else if (k != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(k);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.rightMargin, n); 
        } 
        if (paramLayoutParams.topToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } else if (paramLayoutParams.topToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } 
        if (paramLayoutParams.bottomToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } else if (paramLayoutParams.bottomToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } 
        if (paramLayoutParams.baselineToBaseline != -1) {
          paramView = (View)this.mChildrenByIds.get(paramLayoutParams.baselineToBaseline);
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.baselineToBaseline);
          if (constraintWidget != null && paramView != null && paramView.getLayoutParams() instanceof LayoutParams) {
            LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
            paramLayoutParams.needsBaseline = true;
            layoutParams.needsBaseline = true;
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE), 0, -1, true);
            paramConstraintWidget.setHasBaseline(true);
            layoutParams.widget.setHasBaseline(true);
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP).reset();
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).reset();
          } 
        } 
        if (f >= 0.0F)
          paramConstraintWidget.setHorizontalBiasPercent(f); 
        if (paramLayoutParams.verticalBias >= 0.0F)
          paramConstraintWidget.setVerticalBiasPercent(paramLayoutParams.verticalBias); 
      } 
      if (paramBoolean && (paramLayoutParams.editorAbsoluteX != -1 || paramLayoutParams.editorAbsoluteY != -1))
        paramConstraintWidget.setOrigin(paramLayoutParams.editorAbsoluteX, paramLayoutParams.editorAbsoluteY); 
      if (!paramLayoutParams.horizontalDimensionFixed) {
        if (paramLayoutParams.width == -1) {
          if (paramLayoutParams.constrainedWidth) {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.LEFT)).mMargin = paramLayoutParams.leftMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT)).mMargin = paramLayoutParams.rightMargin;
        } else {
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setWidth(0);
        } 
      } else {
        paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setWidth(paramLayoutParams.width);
        if (paramLayoutParams.width == -2)
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      if (!paramLayoutParams.verticalDimensionFixed) {
        if (paramLayoutParams.height == -1) {
          if (paramLayoutParams.constrainedHeight) {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP)).mMargin = paramLayoutParams.topMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM)).mMargin = paramLayoutParams.bottomMargin;
        } else {
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setHeight(0);
        } 
      } else {
        paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setHeight(paramLayoutParams.height);
        if (paramLayoutParams.height == -2)
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      paramConstraintWidget.setDimensionRatio(paramLayoutParams.dimensionRatio);
      paramConstraintWidget.setHorizontalWeight(paramLayoutParams.horizontalWeight);
      paramConstraintWidget.setVerticalWeight(paramLayoutParams.verticalWeight);
      paramConstraintWidget.setHorizontalChainStyle(paramLayoutParams.horizontalChainStyle);
      paramConstraintWidget.setVerticalChainStyle(paramLayoutParams.verticalChainStyle);
      paramConstraintWidget.setHorizontalMatchStyle(paramLayoutParams.matchConstraintDefaultWidth, paramLayoutParams.matchConstraintMinWidth, paramLayoutParams.matchConstraintMaxWidth, paramLayoutParams.matchConstraintPercentWidth);
      paramConstraintWidget.setVerticalMatchStyle(paramLayoutParams.matchConstraintDefaultHeight, paramLayoutParams.matchConstraintMinHeight, paramLayoutParams.matchConstraintMaxHeight, paramLayoutParams.matchConstraintPercentHeight);
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        int j;
        for (j = 0; j < i; j++)
          ((ConstraintHelper)this.mConstraintHelpers.get(j)).updatePreDraw(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int j = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      int i;
      for (i = 0; i < j; i++) {
        View view = getChildAt(i);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int m = Integer.parseInt((String)object[0]);
              int i1 = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              m = (int)(m / 1080.0F * f1);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = m;
              float f4 = i1;
              float f5 = (m + n);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i1 + k);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  public void forceLayout() {
    markHierarchyDirty();
    super.forceLayout();
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.mDesignIds;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.mDesignIds.get(paramObject); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    return (ConstraintWidget)((paramView == this) ? this.mLayoutWidget : ((paramView == null) ? null : ((LayoutParams)paramView.getLayoutParams()).widget));
  }
  
  protected boolean isRtl() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 17) {
      if (((getContext().getApplicationInfo()).flags & 0x400000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (1 == getLayoutDirection())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0)
      try {
        this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
        return;
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        this.mConstraintLayoutSpec = null;
        return;
      }  
    this.mConstraintLayoutSpec = null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || layoutParams.isVirtualGroup || paramBoolean) && !layoutParams.isInPlaceholder) {
        paramInt4 = constraintWidget.getX();
        int i = constraintWidget.getY();
        int j = constraintWidget.getWidth() + paramInt4;
        int k = constraintWidget.getHeight() + i;
        view.layout(paramInt4, i, j, k);
        if (view instanceof Placeholder) {
          view = ((Placeholder)view).getContent();
          if (view != null) {
            view.setVisibility(0);
            view.layout(paramInt4, i, j, k);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!this.mDirtyHierarchy) {
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        if (getChildAt(i).isLayoutRequested()) {
          this.mDirtyHierarchy = true;
          break;
        } 
      } 
    } 
    if (!this.mDirtyHierarchy) {
      if (this.mOnMeasureWidthMeasureSpec == paramInt1 && this.mOnMeasureHeightMeasureSpec == paramInt2) {
        resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
        return;
      } 
      if (this.mOnMeasureWidthMeasureSpec == paramInt1 && View.MeasureSpec.getMode(paramInt1) == 1073741824 && View.MeasureSpec.getMode(paramInt2) == Integer.MIN_VALUE && View.MeasureSpec.getMode(this.mOnMeasureHeightMeasureSpec) == Integer.MIN_VALUE && View.MeasureSpec.getSize(paramInt2) >= this.mLayoutWidget.getHeight()) {
        this.mOnMeasureWidthMeasureSpec = paramInt1;
        this.mOnMeasureHeightMeasureSpec = paramInt2;
        resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
        return;
      } 
    } 
    this.mOnMeasureWidthMeasureSpec = paramInt1;
    this.mOnMeasureHeightMeasureSpec = paramInt2;
    this.mLayoutWidget.setRtl(isRtl());
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      if (updateHierarchy())
        this.mLayoutWidget.updateHierarchy(); 
    } 
    resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, paramInt1, paramInt2);
    resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mDirtyHierarchy = true;
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    markHierarchyDirty();
    super.requestLayout();
  }
  
  protected void resolveMeasuredDimension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.mMeasurer.paddingHeight;
    paramInt3 += this.mMeasurer.paddingWidth;
    paramInt4 += i;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = resolveSizeAndState(paramInt3, paramInt1, 0);
      paramInt3 = resolveSizeAndState(paramInt4, paramInt2, 0);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      paramInt3 = Math.min(this.mMaxHeight, paramInt3 & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (paramBoolean1)
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = paramInt3;
      if (paramBoolean2)
        paramInt2 = paramInt3 | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
      return;
    } 
    setMeasuredDimension(paramInt3, paramInt4);
    this.mLastMeasureWidth = paramInt3;
    this.mLastMeasureHeight = paramInt4;
  }
  
  protected void resolveSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3) {
    int i = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int j = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int k = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = k + i3;
    int i2 = getPaddingWidth();
    this.mMeasurer.captureLayoutInfos(paramInt2, paramInt3, k, i3, i2, n);
    if (Build.VERSION.SDK_INT >= 17) {
      paramInt2 = Math.max(0, getPaddingStart());
      paramInt3 = Math.max(0, getPaddingEnd());
      if (paramInt2 > 0 || paramInt3 > 0) {
        if (isRtl())
          paramInt2 = paramInt3; 
      } else {
        paramInt2 = Math.max(0, getPaddingLeft());
      } 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    setSelfDimensionBehaviour(paramConstraintWidgetContainer, i, paramInt3, j, m);
    paramConstraintWidgetContainer.measure(paramInt1, i, paramInt3, j, m, this.mLastMeasureWidth, this.mLastMeasureHeight, paramInt2, k);
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.setOnConstraintsChanged(paramConstraintsChangedListener); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  protected void setSelfDimensionBehaviour(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   4: getfield paddingHeight : I
    //   7: istore #6
    //   9: aload_0
    //   10: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   13: getfield paddingWidth : I
    //   16: istore #7
    //   18: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   21: astore #9
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #10
    //   28: aload_0
    //   29: invokevirtual getChildCount : ()I
    //   32: istore #8
    //   34: iload_2
    //   35: ldc_w -2147483648
    //   38: if_icmpeq -> 102
    //   41: iload_2
    //   42: ifeq -> 72
    //   45: iload_2
    //   46: ldc_w 1073741824
    //   49: if_icmpeq -> 57
    //   52: iconst_0
    //   53: istore_3
    //   54: goto -> 129
    //   57: aload_0
    //   58: getfield mMaxWidth : I
    //   61: iload #7
    //   63: isub
    //   64: iload_3
    //   65: invokestatic min : (II)I
    //   68: istore_3
    //   69: goto -> 129
    //   72: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   75: astore #11
    //   77: aload #11
    //   79: astore #9
    //   81: iload #8
    //   83: ifne -> 52
    //   86: iconst_0
    //   87: aload_0
    //   88: getfield mMinWidth : I
    //   91: invokestatic max : (II)I
    //   94: istore_3
    //   95: aload #11
    //   97: astore #9
    //   99: goto -> 129
    //   102: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   105: astore #11
    //   107: aload #11
    //   109: astore #9
    //   111: iload #8
    //   113: ifne -> 129
    //   116: iconst_0
    //   117: aload_0
    //   118: getfield mMinWidth : I
    //   121: invokestatic max : (II)I
    //   124: istore_3
    //   125: aload #11
    //   127: astore #9
    //   129: iload #4
    //   131: ldc_w -2147483648
    //   134: if_icmpeq -> 204
    //   137: iload #4
    //   139: ifeq -> 173
    //   142: iload #4
    //   144: ldc_w 1073741824
    //   147: if_icmpeq -> 156
    //   150: iconst_0
    //   151: istore #5
    //   153: goto -> 232
    //   156: aload_0
    //   157: getfield mMaxHeight : I
    //   160: iload #6
    //   162: isub
    //   163: iload #5
    //   165: invokestatic min : (II)I
    //   168: istore #5
    //   170: goto -> 232
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: astore #11
    //   178: aload #11
    //   180: astore #10
    //   182: iload #8
    //   184: ifne -> 150
    //   187: iconst_0
    //   188: aload_0
    //   189: getfield mMinHeight : I
    //   192: invokestatic max : (II)I
    //   195: istore #5
    //   197: aload #11
    //   199: astore #10
    //   201: goto -> 232
    //   204: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   207: astore #11
    //   209: aload #11
    //   211: astore #10
    //   213: iload #8
    //   215: ifne -> 232
    //   218: iconst_0
    //   219: aload_0
    //   220: getfield mMinHeight : I
    //   223: invokestatic max : (II)I
    //   226: istore #5
    //   228: aload #11
    //   230: astore #10
    //   232: iload_3
    //   233: aload_1
    //   234: invokevirtual getWidth : ()I
    //   237: if_icmpne -> 249
    //   240: iload #5
    //   242: aload_1
    //   243: invokevirtual getHeight : ()I
    //   246: if_icmpeq -> 253
    //   249: aload_1
    //   250: invokevirtual invalidateMeasures : ()V
    //   253: aload_1
    //   254: iconst_0
    //   255: invokevirtual setX : (I)V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual setY : (I)V
    //   263: aload_1
    //   264: aload_0
    //   265: getfield mMaxWidth : I
    //   268: iload #7
    //   270: isub
    //   271: invokevirtual setMaxWidth : (I)V
    //   274: aload_1
    //   275: aload_0
    //   276: getfield mMaxHeight : I
    //   279: iload #6
    //   281: isub
    //   282: invokevirtual setMaxHeight : (I)V
    //   285: aload_1
    //   286: iconst_0
    //   287: invokevirtual setMinWidth : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual setMinHeight : (I)V
    //   295: aload_1
    //   296: aload #9
    //   298: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   301: aload_1
    //   302: iload_3
    //   303: invokevirtual setWidth : (I)V
    //   306: aload_1
    //   307: aload #10
    //   309: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   312: aload_1
    //   313: iload #5
    //   315: invokevirtual setHeight : (I)V
    //   318: aload_1
    //   319: aload_0
    //   320: getfield mMinWidth : I
    //   323: iload #7
    //   325: isub
    //   326: invokevirtual setMinWidth : (I)V
    //   329: aload_1
    //   330: aload_0
    //   331: getfield mMinHeight : I
    //   334: iload #6
    //   336: isub
    //   337: invokevirtual setMinHeight : (I)V
    //   340: return
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.updateConstraints(paramInt1, paramInt2, paramInt3); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int END = 7;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public int baselineToBaseline = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String constraintTag = null;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    boolean isVirtualGroup = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = -1;
    
    int resolveGoneRightMargin = -1;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield circleConstraint : I
      //   72: aload_0
      //   73: iconst_0
      //   74: putfield circleRadius : I
      //   77: aload_0
      //   78: fconst_0
      //   79: putfield circleAngle : F
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield startToEnd : I
      //   87: aload_0
      //   88: iconst_m1
      //   89: putfield startToStart : I
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield endToStart : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield endToEnd : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield goneLeftMargin : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield goneTopMargin : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield goneRightMargin : I
      //   117: aload_0
      //   118: iconst_m1
      //   119: putfield goneBottomMargin : I
      //   122: aload_0
      //   123: iconst_m1
      //   124: putfield goneStartMargin : I
      //   127: aload_0
      //   128: iconst_m1
      //   129: putfield goneEndMargin : I
      //   132: aload_0
      //   133: ldc 0.5
      //   135: putfield horizontalBias : F
      //   138: aload_0
      //   139: ldc 0.5
      //   141: putfield verticalBias : F
      //   144: aload_0
      //   145: aconst_null
      //   146: putfield dimensionRatio : Ljava/lang/String;
      //   149: aload_0
      //   150: fconst_0
      //   151: putfield dimensionRatioValue : F
      //   154: aload_0
      //   155: iconst_1
      //   156: putfield dimensionRatioSide : I
      //   159: aload_0
      //   160: ldc -1.0
      //   162: putfield horizontalWeight : F
      //   165: aload_0
      //   166: ldc -1.0
      //   168: putfield verticalWeight : F
      //   171: aload_0
      //   172: iconst_0
      //   173: putfield horizontalChainStyle : I
      //   176: aload_0
      //   177: iconst_0
      //   178: putfield verticalChainStyle : I
      //   181: aload_0
      //   182: iconst_0
      //   183: putfield matchConstraintDefaultWidth : I
      //   186: aload_0
      //   187: iconst_0
      //   188: putfield matchConstraintDefaultHeight : I
      //   191: aload_0
      //   192: iconst_0
      //   193: putfield matchConstraintMinWidth : I
      //   196: aload_0
      //   197: iconst_0
      //   198: putfield matchConstraintMinHeight : I
      //   201: aload_0
      //   202: iconst_0
      //   203: putfield matchConstraintMaxWidth : I
      //   206: aload_0
      //   207: iconst_0
      //   208: putfield matchConstraintMaxHeight : I
      //   211: aload_0
      //   212: fconst_1
      //   213: putfield matchConstraintPercentWidth : F
      //   216: aload_0
      //   217: fconst_1
      //   218: putfield matchConstraintPercentHeight : F
      //   221: aload_0
      //   222: iconst_m1
      //   223: putfield editorAbsoluteX : I
      //   226: aload_0
      //   227: iconst_m1
      //   228: putfield editorAbsoluteY : I
      //   231: aload_0
      //   232: iconst_m1
      //   233: putfield orientation : I
      //   236: aload_0
      //   237: iconst_0
      //   238: putfield constrainedWidth : Z
      //   241: aload_0
      //   242: iconst_0
      //   243: putfield constrainedHeight : Z
      //   246: aload_0
      //   247: aconst_null
      //   248: putfield constraintTag : Ljava/lang/String;
      //   251: aload_0
      //   252: iconst_1
      //   253: putfield horizontalDimensionFixed : Z
      //   256: aload_0
      //   257: iconst_1
      //   258: putfield verticalDimensionFixed : Z
      //   261: aload_0
      //   262: iconst_0
      //   263: putfield needsBaseline : Z
      //   266: aload_0
      //   267: iconst_0
      //   268: putfield isGuideline : Z
      //   271: aload_0
      //   272: iconst_0
      //   273: putfield isHelper : Z
      //   276: aload_0
      //   277: iconst_0
      //   278: putfield isInPlaceholder : Z
      //   281: aload_0
      //   282: iconst_0
      //   283: putfield isVirtualGroup : Z
      //   286: aload_0
      //   287: iconst_m1
      //   288: putfield resolvedLeftToLeft : I
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedLeftToRight : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolvedRightToLeft : I
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolvedRightToRight : I
      //   306: aload_0
      //   307: iconst_m1
      //   308: putfield resolveGoneLeftMargin : I
      //   311: aload_0
      //   312: iconst_m1
      //   313: putfield resolveGoneRightMargin : I
      //   316: aload_0
      //   317: ldc 0.5
      //   319: putfield resolvedHorizontalBias : F
      //   322: aload_0
      //   323: new androidx/constraintlayout/solver/widgets/ConstraintWidget
      //   326: dup
      //   327: invokespecial <init> : ()V
      //   330: putfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   333: aload_0
      //   334: iconst_0
      //   335: putfield helped : Z
      //   338: aload_1
      //   339: aload_2
      //   340: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   343: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   346: astore_1
      //   347: aload_1
      //   348: invokevirtual getIndexCount : ()I
      //   351: istore #7
      //   353: iconst_0
      //   354: istore #5
      //   356: iload #5
      //   358: iload #7
      //   360: if_icmpge -> 2096
      //   363: aload_1
      //   364: iload #5
      //   366: invokevirtual getIndex : (I)I
      //   369: istore #6
      //   371: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   374: iload #6
      //   376: invokevirtual get : (I)I
      //   379: istore #8
      //   381: iload #8
      //   383: tableswitch default -> 548, 1 -> 2073, 2 -> 2035, 3 -> 2018, 4 -> 1976, 5 -> 1959, 6 -> 1942, 7 -> 1925, 8 -> 1887, 9 -> 1849, 10 -> 1811, 11 -> 1773, 12 -> 1735, 13 -> 1697, 14 -> 1659, 15 -> 1621, 16 -> 1583, 17 -> 1545, 18 -> 1507, 19 -> 1469, 20 -> 1431, 21 -> 1414, 22 -> 1397, 23 -> 1380, 24 -> 1363, 25 -> 1346, 26 -> 1329, 27 -> 1312, 28 -> 1295, 29 -> 1278, 30 -> 1261, 31 -> 1227, 32 -> 1193, 33 -> 1152, 34 -> 1111, 35 -> 1085, 36 -> 1044, 37 -> 1003, 38 -> 977
      //   548: iload #8
      //   550: tableswitch default -> 596, 44 -> 708, 45 -> 691, 46 -> 674, 47 -> 660, 48 -> 646, 49 -> 629, 50 -> 612, 51 -> 599
      //   596: goto -> 2087
      //   599: aload_0
      //   600: aload_1
      //   601: iload #6
      //   603: invokevirtual getString : (I)Ljava/lang/String;
      //   606: putfield constraintTag : Ljava/lang/String;
      //   609: goto -> 2087
      //   612: aload_0
      //   613: aload_1
      //   614: iload #6
      //   616: aload_0
      //   617: getfield editorAbsoluteY : I
      //   620: invokevirtual getDimensionPixelOffset : (II)I
      //   623: putfield editorAbsoluteY : I
      //   626: goto -> 2087
      //   629: aload_0
      //   630: aload_1
      //   631: iload #6
      //   633: aload_0
      //   634: getfield editorAbsoluteX : I
      //   637: invokevirtual getDimensionPixelOffset : (II)I
      //   640: putfield editorAbsoluteX : I
      //   643: goto -> 2087
      //   646: aload_0
      //   647: aload_1
      //   648: iload #6
      //   650: iconst_0
      //   651: invokevirtual getInt : (II)I
      //   654: putfield verticalChainStyle : I
      //   657: goto -> 2087
      //   660: aload_0
      //   661: aload_1
      //   662: iload #6
      //   664: iconst_0
      //   665: invokevirtual getInt : (II)I
      //   668: putfield horizontalChainStyle : I
      //   671: goto -> 2087
      //   674: aload_0
      //   675: aload_1
      //   676: iload #6
      //   678: aload_0
      //   679: getfield verticalWeight : F
      //   682: invokevirtual getFloat : (IF)F
      //   685: putfield verticalWeight : F
      //   688: goto -> 2087
      //   691: aload_0
      //   692: aload_1
      //   693: iload #6
      //   695: aload_0
      //   696: getfield horizontalWeight : F
      //   699: invokevirtual getFloat : (IF)F
      //   702: putfield horizontalWeight : F
      //   705: goto -> 2087
      //   708: aload_1
      //   709: iload #6
      //   711: invokevirtual getString : (I)Ljava/lang/String;
      //   714: astore_2
      //   715: aload_0
      //   716: aload_2
      //   717: putfield dimensionRatio : Ljava/lang/String;
      //   720: aload_0
      //   721: ldc_w NaN
      //   724: putfield dimensionRatioValue : F
      //   727: aload_0
      //   728: iconst_m1
      //   729: putfield dimensionRatioSide : I
      //   732: aload_2
      //   733: ifnull -> 2087
      //   736: aload_2
      //   737: invokevirtual length : ()I
      //   740: istore #8
      //   742: aload_0
      //   743: getfield dimensionRatio : Ljava/lang/String;
      //   746: bipush #44
      //   748: invokevirtual indexOf : (I)I
      //   751: istore #6
      //   753: iload #6
      //   755: ifle -> 820
      //   758: iload #6
      //   760: iload #8
      //   762: iconst_1
      //   763: isub
      //   764: if_icmpge -> 820
      //   767: aload_0
      //   768: getfield dimensionRatio : Ljava/lang/String;
      //   771: iconst_0
      //   772: iload #6
      //   774: invokevirtual substring : (II)Ljava/lang/String;
      //   777: astore_2
      //   778: aload_2
      //   779: ldc_w 'W'
      //   782: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   785: ifeq -> 796
      //   788: aload_0
      //   789: iconst_0
      //   790: putfield dimensionRatioSide : I
      //   793: goto -> 811
      //   796: aload_2
      //   797: ldc_w 'H'
      //   800: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   803: ifeq -> 811
      //   806: aload_0
      //   807: iconst_1
      //   808: putfield dimensionRatioSide : I
      //   811: iload #6
      //   813: iconst_1
      //   814: iadd
      //   815: istore #6
      //   817: goto -> 823
      //   820: iconst_0
      //   821: istore #6
      //   823: aload_0
      //   824: getfield dimensionRatio : Ljava/lang/String;
      //   827: bipush #58
      //   829: invokevirtual indexOf : (I)I
      //   832: istore #9
      //   834: iload #9
      //   836: iflt -> 949
      //   839: iload #9
      //   841: iload #8
      //   843: iconst_1
      //   844: isub
      //   845: if_icmpge -> 949
      //   848: aload_0
      //   849: getfield dimensionRatio : Ljava/lang/String;
      //   852: iload #6
      //   854: iload #9
      //   856: invokevirtual substring : (II)Ljava/lang/String;
      //   859: astore_2
      //   860: aload_0
      //   861: getfield dimensionRatio : Ljava/lang/String;
      //   864: iload #9
      //   866: iconst_1
      //   867: iadd
      //   868: invokevirtual substring : (I)Ljava/lang/String;
      //   871: astore #10
      //   873: aload_2
      //   874: invokevirtual length : ()I
      //   877: ifle -> 2087
      //   880: aload #10
      //   882: invokevirtual length : ()I
      //   885: ifle -> 2087
      //   888: aload_2
      //   889: invokestatic parseFloat : (Ljava/lang/String;)F
      //   892: fstore_3
      //   893: aload #10
      //   895: invokestatic parseFloat : (Ljava/lang/String;)F
      //   898: fstore #4
      //   900: fload_3
      //   901: fconst_0
      //   902: fcmpl
      //   903: ifle -> 2087
      //   906: fload #4
      //   908: fconst_0
      //   909: fcmpl
      //   910: ifle -> 2087
      //   913: aload_0
      //   914: getfield dimensionRatioSide : I
      //   917: iconst_1
      //   918: if_icmpne -> 935
      //   921: aload_0
      //   922: fload #4
      //   924: fload_3
      //   925: fdiv
      //   926: invokestatic abs : (F)F
      //   929: putfield dimensionRatioValue : F
      //   932: goto -> 2087
      //   935: aload_0
      //   936: fload_3
      //   937: fload #4
      //   939: fdiv
      //   940: invokestatic abs : (F)F
      //   943: putfield dimensionRatioValue : F
      //   946: goto -> 2087
      //   949: aload_0
      //   950: getfield dimensionRatio : Ljava/lang/String;
      //   953: iload #6
      //   955: invokevirtual substring : (I)Ljava/lang/String;
      //   958: astore_2
      //   959: aload_2
      //   960: invokevirtual length : ()I
      //   963: ifle -> 2087
      //   966: aload_0
      //   967: aload_2
      //   968: invokestatic parseFloat : (Ljava/lang/String;)F
      //   971: putfield dimensionRatioValue : F
      //   974: goto -> 2087
      //   977: aload_0
      //   978: fconst_0
      //   979: aload_1
      //   980: iload #6
      //   982: aload_0
      //   983: getfield matchConstraintPercentHeight : F
      //   986: invokevirtual getFloat : (IF)F
      //   989: invokestatic max : (FF)F
      //   992: putfield matchConstraintPercentHeight : F
      //   995: aload_0
      //   996: iconst_2
      //   997: putfield matchConstraintDefaultHeight : I
      //   1000: goto -> 2087
      //   1003: aload_0
      //   1004: aload_1
      //   1005: iload #6
      //   1007: aload_0
      //   1008: getfield matchConstraintMaxHeight : I
      //   1011: invokevirtual getDimensionPixelSize : (II)I
      //   1014: putfield matchConstraintMaxHeight : I
      //   1017: goto -> 2087
      //   1020: aload_1
      //   1021: iload #6
      //   1023: aload_0
      //   1024: getfield matchConstraintMaxHeight : I
      //   1027: invokevirtual getInt : (II)I
      //   1030: bipush #-2
      //   1032: if_icmpne -> 2087
      //   1035: aload_0
      //   1036: bipush #-2
      //   1038: putfield matchConstraintMaxHeight : I
      //   1041: goto -> 2087
      //   1044: aload_0
      //   1045: aload_1
      //   1046: iload #6
      //   1048: aload_0
      //   1049: getfield matchConstraintMinHeight : I
      //   1052: invokevirtual getDimensionPixelSize : (II)I
      //   1055: putfield matchConstraintMinHeight : I
      //   1058: goto -> 2087
      //   1061: aload_1
      //   1062: iload #6
      //   1064: aload_0
      //   1065: getfield matchConstraintMinHeight : I
      //   1068: invokevirtual getInt : (II)I
      //   1071: bipush #-2
      //   1073: if_icmpne -> 2087
      //   1076: aload_0
      //   1077: bipush #-2
      //   1079: putfield matchConstraintMinHeight : I
      //   1082: goto -> 2087
      //   1085: aload_0
      //   1086: fconst_0
      //   1087: aload_1
      //   1088: iload #6
      //   1090: aload_0
      //   1091: getfield matchConstraintPercentWidth : F
      //   1094: invokevirtual getFloat : (IF)F
      //   1097: invokestatic max : (FF)F
      //   1100: putfield matchConstraintPercentWidth : F
      //   1103: aload_0
      //   1104: iconst_2
      //   1105: putfield matchConstraintDefaultWidth : I
      //   1108: goto -> 2087
      //   1111: aload_0
      //   1112: aload_1
      //   1113: iload #6
      //   1115: aload_0
      //   1116: getfield matchConstraintMaxWidth : I
      //   1119: invokevirtual getDimensionPixelSize : (II)I
      //   1122: putfield matchConstraintMaxWidth : I
      //   1125: goto -> 2087
      //   1128: aload_1
      //   1129: iload #6
      //   1131: aload_0
      //   1132: getfield matchConstraintMaxWidth : I
      //   1135: invokevirtual getInt : (II)I
      //   1138: bipush #-2
      //   1140: if_icmpne -> 2087
      //   1143: aload_0
      //   1144: bipush #-2
      //   1146: putfield matchConstraintMaxWidth : I
      //   1149: goto -> 2087
      //   1152: aload_0
      //   1153: aload_1
      //   1154: iload #6
      //   1156: aload_0
      //   1157: getfield matchConstraintMinWidth : I
      //   1160: invokevirtual getDimensionPixelSize : (II)I
      //   1163: putfield matchConstraintMinWidth : I
      //   1166: goto -> 2087
      //   1169: aload_1
      //   1170: iload #6
      //   1172: aload_0
      //   1173: getfield matchConstraintMinWidth : I
      //   1176: invokevirtual getInt : (II)I
      //   1179: bipush #-2
      //   1181: if_icmpne -> 2087
      //   1184: aload_0
      //   1185: bipush #-2
      //   1187: putfield matchConstraintMinWidth : I
      //   1190: goto -> 2087
      //   1193: aload_1
      //   1194: iload #6
      //   1196: iconst_0
      //   1197: invokevirtual getInt : (II)I
      //   1200: istore #6
      //   1202: aload_0
      //   1203: iload #6
      //   1205: putfield matchConstraintDefaultHeight : I
      //   1208: iload #6
      //   1210: iconst_1
      //   1211: if_icmpne -> 2087
      //   1214: ldc_w 'ConstraintLayout'
      //   1217: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1220: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1223: pop
      //   1224: goto -> 2087
      //   1227: aload_1
      //   1228: iload #6
      //   1230: iconst_0
      //   1231: invokevirtual getInt : (II)I
      //   1234: istore #6
      //   1236: aload_0
      //   1237: iload #6
      //   1239: putfield matchConstraintDefaultWidth : I
      //   1242: iload #6
      //   1244: iconst_1
      //   1245: if_icmpne -> 2087
      //   1248: ldc_w 'ConstraintLayout'
      //   1251: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1254: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1257: pop
      //   1258: goto -> 2087
      //   1261: aload_0
      //   1262: aload_1
      //   1263: iload #6
      //   1265: aload_0
      //   1266: getfield verticalBias : F
      //   1269: invokevirtual getFloat : (IF)F
      //   1272: putfield verticalBias : F
      //   1275: goto -> 2087
      //   1278: aload_0
      //   1279: aload_1
      //   1280: iload #6
      //   1282: aload_0
      //   1283: getfield horizontalBias : F
      //   1286: invokevirtual getFloat : (IF)F
      //   1289: putfield horizontalBias : F
      //   1292: goto -> 2087
      //   1295: aload_0
      //   1296: aload_1
      //   1297: iload #6
      //   1299: aload_0
      //   1300: getfield constrainedHeight : Z
      //   1303: invokevirtual getBoolean : (IZ)Z
      //   1306: putfield constrainedHeight : Z
      //   1309: goto -> 2087
      //   1312: aload_0
      //   1313: aload_1
      //   1314: iload #6
      //   1316: aload_0
      //   1317: getfield constrainedWidth : Z
      //   1320: invokevirtual getBoolean : (IZ)Z
      //   1323: putfield constrainedWidth : Z
      //   1326: goto -> 2087
      //   1329: aload_0
      //   1330: aload_1
      //   1331: iload #6
      //   1333: aload_0
      //   1334: getfield goneEndMargin : I
      //   1337: invokevirtual getDimensionPixelSize : (II)I
      //   1340: putfield goneEndMargin : I
      //   1343: goto -> 2087
      //   1346: aload_0
      //   1347: aload_1
      //   1348: iload #6
      //   1350: aload_0
      //   1351: getfield goneStartMargin : I
      //   1354: invokevirtual getDimensionPixelSize : (II)I
      //   1357: putfield goneStartMargin : I
      //   1360: goto -> 2087
      //   1363: aload_0
      //   1364: aload_1
      //   1365: iload #6
      //   1367: aload_0
      //   1368: getfield goneBottomMargin : I
      //   1371: invokevirtual getDimensionPixelSize : (II)I
      //   1374: putfield goneBottomMargin : I
      //   1377: goto -> 2087
      //   1380: aload_0
      //   1381: aload_1
      //   1382: iload #6
      //   1384: aload_0
      //   1385: getfield goneRightMargin : I
      //   1388: invokevirtual getDimensionPixelSize : (II)I
      //   1391: putfield goneRightMargin : I
      //   1394: goto -> 2087
      //   1397: aload_0
      //   1398: aload_1
      //   1399: iload #6
      //   1401: aload_0
      //   1402: getfield goneTopMargin : I
      //   1405: invokevirtual getDimensionPixelSize : (II)I
      //   1408: putfield goneTopMargin : I
      //   1411: goto -> 2087
      //   1414: aload_0
      //   1415: aload_1
      //   1416: iload #6
      //   1418: aload_0
      //   1419: getfield goneLeftMargin : I
      //   1422: invokevirtual getDimensionPixelSize : (II)I
      //   1425: putfield goneLeftMargin : I
      //   1428: goto -> 2087
      //   1431: aload_1
      //   1432: iload #6
      //   1434: aload_0
      //   1435: getfield endToEnd : I
      //   1438: invokevirtual getResourceId : (II)I
      //   1441: istore #8
      //   1443: aload_0
      //   1444: iload #8
      //   1446: putfield endToEnd : I
      //   1449: iload #8
      //   1451: iconst_m1
      //   1452: if_icmpne -> 2087
      //   1455: aload_0
      //   1456: aload_1
      //   1457: iload #6
      //   1459: iconst_m1
      //   1460: invokevirtual getInt : (II)I
      //   1463: putfield endToEnd : I
      //   1466: goto -> 2087
      //   1469: aload_1
      //   1470: iload #6
      //   1472: aload_0
      //   1473: getfield endToStart : I
      //   1476: invokevirtual getResourceId : (II)I
      //   1479: istore #8
      //   1481: aload_0
      //   1482: iload #8
      //   1484: putfield endToStart : I
      //   1487: iload #8
      //   1489: iconst_m1
      //   1490: if_icmpne -> 2087
      //   1493: aload_0
      //   1494: aload_1
      //   1495: iload #6
      //   1497: iconst_m1
      //   1498: invokevirtual getInt : (II)I
      //   1501: putfield endToStart : I
      //   1504: goto -> 2087
      //   1507: aload_1
      //   1508: iload #6
      //   1510: aload_0
      //   1511: getfield startToStart : I
      //   1514: invokevirtual getResourceId : (II)I
      //   1517: istore #8
      //   1519: aload_0
      //   1520: iload #8
      //   1522: putfield startToStart : I
      //   1525: iload #8
      //   1527: iconst_m1
      //   1528: if_icmpne -> 2087
      //   1531: aload_0
      //   1532: aload_1
      //   1533: iload #6
      //   1535: iconst_m1
      //   1536: invokevirtual getInt : (II)I
      //   1539: putfield startToStart : I
      //   1542: goto -> 2087
      //   1545: aload_1
      //   1546: iload #6
      //   1548: aload_0
      //   1549: getfield startToEnd : I
      //   1552: invokevirtual getResourceId : (II)I
      //   1555: istore #8
      //   1557: aload_0
      //   1558: iload #8
      //   1560: putfield startToEnd : I
      //   1563: iload #8
      //   1565: iconst_m1
      //   1566: if_icmpne -> 2087
      //   1569: aload_0
      //   1570: aload_1
      //   1571: iload #6
      //   1573: iconst_m1
      //   1574: invokevirtual getInt : (II)I
      //   1577: putfield startToEnd : I
      //   1580: goto -> 2087
      //   1583: aload_1
      //   1584: iload #6
      //   1586: aload_0
      //   1587: getfield baselineToBaseline : I
      //   1590: invokevirtual getResourceId : (II)I
      //   1593: istore #8
      //   1595: aload_0
      //   1596: iload #8
      //   1598: putfield baselineToBaseline : I
      //   1601: iload #8
      //   1603: iconst_m1
      //   1604: if_icmpne -> 2087
      //   1607: aload_0
      //   1608: aload_1
      //   1609: iload #6
      //   1611: iconst_m1
      //   1612: invokevirtual getInt : (II)I
      //   1615: putfield baselineToBaseline : I
      //   1618: goto -> 2087
      //   1621: aload_1
      //   1622: iload #6
      //   1624: aload_0
      //   1625: getfield bottomToBottom : I
      //   1628: invokevirtual getResourceId : (II)I
      //   1631: istore #8
      //   1633: aload_0
      //   1634: iload #8
      //   1636: putfield bottomToBottom : I
      //   1639: iload #8
      //   1641: iconst_m1
      //   1642: if_icmpne -> 2087
      //   1645: aload_0
      //   1646: aload_1
      //   1647: iload #6
      //   1649: iconst_m1
      //   1650: invokevirtual getInt : (II)I
      //   1653: putfield bottomToBottom : I
      //   1656: goto -> 2087
      //   1659: aload_1
      //   1660: iload #6
      //   1662: aload_0
      //   1663: getfield bottomToTop : I
      //   1666: invokevirtual getResourceId : (II)I
      //   1669: istore #8
      //   1671: aload_0
      //   1672: iload #8
      //   1674: putfield bottomToTop : I
      //   1677: iload #8
      //   1679: iconst_m1
      //   1680: if_icmpne -> 2087
      //   1683: aload_0
      //   1684: aload_1
      //   1685: iload #6
      //   1687: iconst_m1
      //   1688: invokevirtual getInt : (II)I
      //   1691: putfield bottomToTop : I
      //   1694: goto -> 2087
      //   1697: aload_1
      //   1698: iload #6
      //   1700: aload_0
      //   1701: getfield topToBottom : I
      //   1704: invokevirtual getResourceId : (II)I
      //   1707: istore #8
      //   1709: aload_0
      //   1710: iload #8
      //   1712: putfield topToBottom : I
      //   1715: iload #8
      //   1717: iconst_m1
      //   1718: if_icmpne -> 2087
      //   1721: aload_0
      //   1722: aload_1
      //   1723: iload #6
      //   1725: iconst_m1
      //   1726: invokevirtual getInt : (II)I
      //   1729: putfield topToBottom : I
      //   1732: goto -> 2087
      //   1735: aload_1
      //   1736: iload #6
      //   1738: aload_0
      //   1739: getfield topToTop : I
      //   1742: invokevirtual getResourceId : (II)I
      //   1745: istore #8
      //   1747: aload_0
      //   1748: iload #8
      //   1750: putfield topToTop : I
      //   1753: iload #8
      //   1755: iconst_m1
      //   1756: if_icmpne -> 2087
      //   1759: aload_0
      //   1760: aload_1
      //   1761: iload #6
      //   1763: iconst_m1
      //   1764: invokevirtual getInt : (II)I
      //   1767: putfield topToTop : I
      //   1770: goto -> 2087
      //   1773: aload_1
      //   1774: iload #6
      //   1776: aload_0
      //   1777: getfield rightToRight : I
      //   1780: invokevirtual getResourceId : (II)I
      //   1783: istore #8
      //   1785: aload_0
      //   1786: iload #8
      //   1788: putfield rightToRight : I
      //   1791: iload #8
      //   1793: iconst_m1
      //   1794: if_icmpne -> 2087
      //   1797: aload_0
      //   1798: aload_1
      //   1799: iload #6
      //   1801: iconst_m1
      //   1802: invokevirtual getInt : (II)I
      //   1805: putfield rightToRight : I
      //   1808: goto -> 2087
      //   1811: aload_1
      //   1812: iload #6
      //   1814: aload_0
      //   1815: getfield rightToLeft : I
      //   1818: invokevirtual getResourceId : (II)I
      //   1821: istore #8
      //   1823: aload_0
      //   1824: iload #8
      //   1826: putfield rightToLeft : I
      //   1829: iload #8
      //   1831: iconst_m1
      //   1832: if_icmpne -> 2087
      //   1835: aload_0
      //   1836: aload_1
      //   1837: iload #6
      //   1839: iconst_m1
      //   1840: invokevirtual getInt : (II)I
      //   1843: putfield rightToLeft : I
      //   1846: goto -> 2087
      //   1849: aload_1
      //   1850: iload #6
      //   1852: aload_0
      //   1853: getfield leftToRight : I
      //   1856: invokevirtual getResourceId : (II)I
      //   1859: istore #8
      //   1861: aload_0
      //   1862: iload #8
      //   1864: putfield leftToRight : I
      //   1867: iload #8
      //   1869: iconst_m1
      //   1870: if_icmpne -> 2087
      //   1873: aload_0
      //   1874: aload_1
      //   1875: iload #6
      //   1877: iconst_m1
      //   1878: invokevirtual getInt : (II)I
      //   1881: putfield leftToRight : I
      //   1884: goto -> 2087
      //   1887: aload_1
      //   1888: iload #6
      //   1890: aload_0
      //   1891: getfield leftToLeft : I
      //   1894: invokevirtual getResourceId : (II)I
      //   1897: istore #8
      //   1899: aload_0
      //   1900: iload #8
      //   1902: putfield leftToLeft : I
      //   1905: iload #8
      //   1907: iconst_m1
      //   1908: if_icmpne -> 2087
      //   1911: aload_0
      //   1912: aload_1
      //   1913: iload #6
      //   1915: iconst_m1
      //   1916: invokevirtual getInt : (II)I
      //   1919: putfield leftToLeft : I
      //   1922: goto -> 2087
      //   1925: aload_0
      //   1926: aload_1
      //   1927: iload #6
      //   1929: aload_0
      //   1930: getfield guidePercent : F
      //   1933: invokevirtual getFloat : (IF)F
      //   1936: putfield guidePercent : F
      //   1939: goto -> 2087
      //   1942: aload_0
      //   1943: aload_1
      //   1944: iload #6
      //   1946: aload_0
      //   1947: getfield guideEnd : I
      //   1950: invokevirtual getDimensionPixelOffset : (II)I
      //   1953: putfield guideEnd : I
      //   1956: goto -> 2087
      //   1959: aload_0
      //   1960: aload_1
      //   1961: iload #6
      //   1963: aload_0
      //   1964: getfield guideBegin : I
      //   1967: invokevirtual getDimensionPixelOffset : (II)I
      //   1970: putfield guideBegin : I
      //   1973: goto -> 2087
      //   1976: aload_1
      //   1977: iload #6
      //   1979: aload_0
      //   1980: getfield circleAngle : F
      //   1983: invokevirtual getFloat : (IF)F
      //   1986: ldc_w 360.0
      //   1989: frem
      //   1990: fstore_3
      //   1991: aload_0
      //   1992: fload_3
      //   1993: putfield circleAngle : F
      //   1996: fload_3
      //   1997: fconst_0
      //   1998: fcmpg
      //   1999: ifge -> 2087
      //   2002: aload_0
      //   2003: ldc_w 360.0
      //   2006: fload_3
      //   2007: fsub
      //   2008: ldc_w 360.0
      //   2011: frem
      //   2012: putfield circleAngle : F
      //   2015: goto -> 2087
      //   2018: aload_0
      //   2019: aload_1
      //   2020: iload #6
      //   2022: aload_0
      //   2023: getfield circleRadius : I
      //   2026: invokevirtual getDimensionPixelSize : (II)I
      //   2029: putfield circleRadius : I
      //   2032: goto -> 2087
      //   2035: aload_1
      //   2036: iload #6
      //   2038: aload_0
      //   2039: getfield circleConstraint : I
      //   2042: invokevirtual getResourceId : (II)I
      //   2045: istore #8
      //   2047: aload_0
      //   2048: iload #8
      //   2050: putfield circleConstraint : I
      //   2053: iload #8
      //   2055: iconst_m1
      //   2056: if_icmpne -> 2087
      //   2059: aload_0
      //   2060: aload_1
      //   2061: iload #6
      //   2063: iconst_m1
      //   2064: invokevirtual getInt : (II)I
      //   2067: putfield circleConstraint : I
      //   2070: goto -> 2087
      //   2073: aload_0
      //   2074: aload_1
      //   2075: iload #6
      //   2077: aload_0
      //   2078: getfield orientation : I
      //   2081: invokevirtual getInt : (II)I
      //   2084: putfield orientation : I
      //   2087: iload #5
      //   2089: iconst_1
      //   2090: iadd
      //   2091: istore #5
      //   2093: goto -> 356
      //   2096: aload_1
      //   2097: invokevirtual recycle : ()V
      //   2100: aload_0
      //   2101: invokevirtual validate : ()V
      //   2104: return
      //   2105: astore_2
      //   2106: goto -> 2087
      //   2109: astore_2
      //   2110: goto -> 1020
      //   2113: astore_2
      //   2114: goto -> 1061
      //   2117: astore_2
      //   2118: goto -> 1128
      //   2121: astore_2
      //   2122: goto -> 1169
      // Exception table:
      //   from	to	target	type
      //   888	900	2105	java/lang/NumberFormatException
      //   913	932	2105	java/lang/NumberFormatException
      //   935	946	2105	java/lang/NumberFormatException
      //   966	974	2105	java/lang/NumberFormatException
      //   1003	1017	2109	java/lang/Exception
      //   1044	1058	2113	java/lang/Exception
      //   1111	1125	2117	java/lang/Exception
      //   1152	1166	2121	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.constraintTag = param1LayoutParams.constraintTag;
      this.widget = param1LayoutParams.widget;
    }
    
    public String getConstraintTag() {
      return this.constraintTag;
    }
    
    public ConstraintWidget getConstraintWidget() {
      return this.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #4
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #5
      //   12: getstatic android/os/Build$VERSION.SDK_INT : I
      //   15: istore #6
      //   17: iconst_0
      //   18: istore_3
      //   19: iload #6
      //   21: bipush #17
      //   23: if_icmplt -> 44
      //   26: aload_0
      //   27: iload_1
      //   28: invokespecial resolveLayoutDirection : (I)V
      //   31: iconst_1
      //   32: aload_0
      //   33: invokevirtual getLayoutDirection : ()I
      //   36: if_icmpne -> 44
      //   39: iconst_1
      //   40: istore_1
      //   41: goto -> 46
      //   44: iconst_0
      //   45: istore_1
      //   46: aload_0
      //   47: iconst_m1
      //   48: putfield resolvedRightToLeft : I
      //   51: aload_0
      //   52: iconst_m1
      //   53: putfield resolvedRightToRight : I
      //   56: aload_0
      //   57: iconst_m1
      //   58: putfield resolvedLeftToLeft : I
      //   61: aload_0
      //   62: iconst_m1
      //   63: putfield resolvedLeftToRight : I
      //   66: aload_0
      //   67: iconst_m1
      //   68: putfield resolveGoneLeftMargin : I
      //   71: aload_0
      //   72: iconst_m1
      //   73: putfield resolveGoneRightMargin : I
      //   76: aload_0
      //   77: aload_0
      //   78: getfield goneLeftMargin : I
      //   81: putfield resolveGoneLeftMargin : I
      //   84: aload_0
      //   85: aload_0
      //   86: getfield goneRightMargin : I
      //   89: putfield resolveGoneRightMargin : I
      //   92: aload_0
      //   93: aload_0
      //   94: getfield horizontalBias : F
      //   97: putfield resolvedHorizontalBias : F
      //   100: aload_0
      //   101: aload_0
      //   102: getfield guideBegin : I
      //   105: putfield resolvedGuideBegin : I
      //   108: aload_0
      //   109: aload_0
      //   110: getfield guideEnd : I
      //   113: putfield resolvedGuideEnd : I
      //   116: aload_0
      //   117: aload_0
      //   118: getfield guidePercent : F
      //   121: putfield resolvedGuidePercent : F
      //   124: iload_1
      //   125: ifeq -> 354
      //   128: aload_0
      //   129: getfield startToEnd : I
      //   132: istore_1
      //   133: iload_1
      //   134: iconst_m1
      //   135: if_icmpeq -> 148
      //   138: aload_0
      //   139: iload_1
      //   140: putfield resolvedRightToLeft : I
      //   143: iconst_1
      //   144: istore_1
      //   145: goto -> 171
      //   148: aload_0
      //   149: getfield startToStart : I
      //   152: istore #6
      //   154: iload_3
      //   155: istore_1
      //   156: iload #6
      //   158: iconst_m1
      //   159: if_icmpeq -> 171
      //   162: aload_0
      //   163: iload #6
      //   165: putfield resolvedRightToRight : I
      //   168: goto -> 143
      //   171: aload_0
      //   172: getfield endToStart : I
      //   175: istore_3
      //   176: iload_3
      //   177: iconst_m1
      //   178: if_icmpeq -> 188
      //   181: aload_0
      //   182: iload_3
      //   183: putfield resolvedLeftToRight : I
      //   186: iconst_1
      //   187: istore_1
      //   188: aload_0
      //   189: getfield endToEnd : I
      //   192: istore_3
      //   193: iload_3
      //   194: iconst_m1
      //   195: if_icmpeq -> 205
      //   198: aload_0
      //   199: iload_3
      //   200: putfield resolvedLeftToLeft : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield goneStartMargin : I
      //   209: istore_3
      //   210: iload_3
      //   211: iconst_m1
      //   212: if_icmpeq -> 220
      //   215: aload_0
      //   216: iload_3
      //   217: putfield resolveGoneRightMargin : I
      //   220: aload_0
      //   221: getfield goneEndMargin : I
      //   224: istore_3
      //   225: iload_3
      //   226: iconst_m1
      //   227: if_icmpeq -> 235
      //   230: aload_0
      //   231: iload_3
      //   232: putfield resolveGoneLeftMargin : I
      //   235: iload_1
      //   236: ifeq -> 249
      //   239: aload_0
      //   240: fconst_1
      //   241: aload_0
      //   242: getfield horizontalBias : F
      //   245: fsub
      //   246: putfield resolvedHorizontalBias : F
      //   249: aload_0
      //   250: getfield isGuideline : Z
      //   253: ifeq -> 444
      //   256: aload_0
      //   257: getfield orientation : I
      //   260: iconst_1
      //   261: if_icmpne -> 444
      //   264: aload_0
      //   265: getfield guidePercent : F
      //   268: fstore_2
      //   269: fload_2
      //   270: ldc -1.0
      //   272: fcmpl
      //   273: ifeq -> 296
      //   276: aload_0
      //   277: fconst_1
      //   278: fload_2
      //   279: fsub
      //   280: putfield resolvedGuidePercent : F
      //   283: aload_0
      //   284: iconst_m1
      //   285: putfield resolvedGuideBegin : I
      //   288: aload_0
      //   289: iconst_m1
      //   290: putfield resolvedGuideEnd : I
      //   293: goto -> 444
      //   296: aload_0
      //   297: getfield guideBegin : I
      //   300: istore_1
      //   301: iload_1
      //   302: iconst_m1
      //   303: if_icmpeq -> 325
      //   306: aload_0
      //   307: iload_1
      //   308: putfield resolvedGuideEnd : I
      //   311: aload_0
      //   312: iconst_m1
      //   313: putfield resolvedGuideBegin : I
      //   316: aload_0
      //   317: ldc -1.0
      //   319: putfield resolvedGuidePercent : F
      //   322: goto -> 444
      //   325: aload_0
      //   326: getfield guideEnd : I
      //   329: istore_1
      //   330: iload_1
      //   331: iconst_m1
      //   332: if_icmpeq -> 444
      //   335: aload_0
      //   336: iload_1
      //   337: putfield resolvedGuideBegin : I
      //   340: aload_0
      //   341: iconst_m1
      //   342: putfield resolvedGuideEnd : I
      //   345: aload_0
      //   346: ldc -1.0
      //   348: putfield resolvedGuidePercent : F
      //   351: goto -> 444
      //   354: aload_0
      //   355: getfield startToEnd : I
      //   358: istore_1
      //   359: iload_1
      //   360: iconst_m1
      //   361: if_icmpeq -> 369
      //   364: aload_0
      //   365: iload_1
      //   366: putfield resolvedLeftToRight : I
      //   369: aload_0
      //   370: getfield startToStart : I
      //   373: istore_1
      //   374: iload_1
      //   375: iconst_m1
      //   376: if_icmpeq -> 384
      //   379: aload_0
      //   380: iload_1
      //   381: putfield resolvedLeftToLeft : I
      //   384: aload_0
      //   385: getfield endToStart : I
      //   388: istore_1
      //   389: iload_1
      //   390: iconst_m1
      //   391: if_icmpeq -> 399
      //   394: aload_0
      //   395: iload_1
      //   396: putfield resolvedRightToLeft : I
      //   399: aload_0
      //   400: getfield endToEnd : I
      //   403: istore_1
      //   404: iload_1
      //   405: iconst_m1
      //   406: if_icmpeq -> 414
      //   409: aload_0
      //   410: iload_1
      //   411: putfield resolvedRightToRight : I
      //   414: aload_0
      //   415: getfield goneStartMargin : I
      //   418: istore_1
      //   419: iload_1
      //   420: iconst_m1
      //   421: if_icmpeq -> 429
      //   424: aload_0
      //   425: iload_1
      //   426: putfield resolveGoneLeftMargin : I
      //   429: aload_0
      //   430: getfield goneEndMargin : I
      //   433: istore_1
      //   434: iload_1
      //   435: iconst_m1
      //   436: if_icmpeq -> 444
      //   439: aload_0
      //   440: iload_1
      //   441: putfield resolveGoneRightMargin : I
      //   444: aload_0
      //   445: getfield endToStart : I
      //   448: iconst_m1
      //   449: if_icmpne -> 612
      //   452: aload_0
      //   453: getfield endToEnd : I
      //   456: iconst_m1
      //   457: if_icmpne -> 612
      //   460: aload_0
      //   461: getfield startToStart : I
      //   464: iconst_m1
      //   465: if_icmpne -> 612
      //   468: aload_0
      //   469: getfield startToEnd : I
      //   472: iconst_m1
      //   473: if_icmpne -> 612
      //   476: aload_0
      //   477: getfield rightToLeft : I
      //   480: istore_1
      //   481: iload_1
      //   482: iconst_m1
      //   483: if_icmpeq -> 512
      //   486: aload_0
      //   487: iload_1
      //   488: putfield resolvedRightToLeft : I
      //   491: aload_0
      //   492: getfield rightMargin : I
      //   495: ifgt -> 545
      //   498: iload #5
      //   500: ifle -> 545
      //   503: aload_0
      //   504: iload #5
      //   506: putfield rightMargin : I
      //   509: goto -> 545
      //   512: aload_0
      //   513: getfield rightToRight : I
      //   516: istore_1
      //   517: iload_1
      //   518: iconst_m1
      //   519: if_icmpeq -> 545
      //   522: aload_0
      //   523: iload_1
      //   524: putfield resolvedRightToRight : I
      //   527: aload_0
      //   528: getfield rightMargin : I
      //   531: ifgt -> 545
      //   534: iload #5
      //   536: ifle -> 545
      //   539: aload_0
      //   540: iload #5
      //   542: putfield rightMargin : I
      //   545: aload_0
      //   546: getfield leftToLeft : I
      //   549: istore_1
      //   550: iload_1
      //   551: iconst_m1
      //   552: if_icmpeq -> 579
      //   555: aload_0
      //   556: iload_1
      //   557: putfield resolvedLeftToLeft : I
      //   560: aload_0
      //   561: getfield leftMargin : I
      //   564: ifgt -> 612
      //   567: iload #4
      //   569: ifle -> 612
      //   572: aload_0
      //   573: iload #4
      //   575: putfield leftMargin : I
      //   578: return
      //   579: aload_0
      //   580: getfield leftToRight : I
      //   583: istore_1
      //   584: iload_1
      //   585: iconst_m1
      //   586: if_icmpeq -> 612
      //   589: aload_0
      //   590: iload_1
      //   591: putfield resolvedLeftToRight : I
      //   594: aload_0
      //   595: getfield leftMargin : I
      //   598: ifgt -> 612
      //   601: iload #4
      //   603: ifle -> 612
      //   606: aload_0
      //   607: iload #4
      //   609: putfield leftMargin : I
      //   612: return
    }
    
    public void setWidgetDebugName(String param1String) {
      this.widget.setDebugName(param1String);
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        if (this.matchConstraintDefaultWidth == 0)
          this.matchConstraintDefaultWidth = 1; 
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        if (this.matchConstraintDefaultHeight == 0)
          this.matchConstraintDefaultHeight = 1; 
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TAG = 51;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        map = sparseIntArray;
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TAG = 51;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      map = sparseIntArray;
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
    }
  }
  
  class Measurer implements BasicMeasure.Measurer {
    ConstraintLayout layout;
    
    int layoutHeightSpec;
    
    int layoutWidthSpec;
    
    int paddingBottom;
    
    int paddingHeight;
    
    int paddingTop;
    
    int paddingWidth;
    
    public Measurer(ConstraintLayout param1ConstraintLayout1) {
      this.layout = param1ConstraintLayout1;
    }
    
    private boolean isSimilarSpec(int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int1 == param1Int2)
        return true; 
      int i = View.MeasureSpec.getMode(param1Int1);
      View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      return (param1Int1 == 1073741824 && (i == Integer.MIN_VALUE || i == 0) && param1Int3 == param1Int2);
    }
    
    public void captureLayoutInfos(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.paddingTop = param1Int3;
      this.paddingBottom = param1Int4;
      this.paddingWidth = param1Int5;
      this.paddingHeight = param1Int6;
      this.layoutWidthSpec = param1Int1;
      this.layoutHeightSpec = param1Int2;
    }
    
    public final void didMeasures() {
      int j = this.layout.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        View view = this.layout.getChildAt(i);
        if (view instanceof Placeholder)
          ((Placeholder)view).updatePostMeasure(this.layout); 
      } 
      j = this.layout.mConstraintHelpers.size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((ConstraintHelper)this.layout.mConstraintHelpers.get(i)).updatePostMeasure(this.layout);  
    }
    
    public final void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual getVisibility : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual isInPlaceholder : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield measuredWidth : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield measuredHeight : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield measuredBaseline : I
      //   36: return
      //   37: aload_1
      //   38: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   41: ifnonnull -> 45
      //   44: return
      //   45: aload_2
      //   46: getfield horizontalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   49: astore #20
      //   51: aload_2
      //   52: getfield verticalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   55: astore #21
      //   57: aload_2
      //   58: getfield horizontalDimension : I
      //   61: istore #4
      //   63: aload_2
      //   64: getfield verticalDimension : I
      //   67: istore #7
      //   69: aload_0
      //   70: getfield paddingTop : I
      //   73: aload_0
      //   74: getfield paddingBottom : I
      //   77: iadd
      //   78: istore #8
      //   80: aload_0
      //   81: getfield paddingWidth : I
      //   84: istore #5
      //   86: aload_1
      //   87: invokevirtual getCompanionWidget : ()Ljava/lang/Object;
      //   90: checkcast android/view/View
      //   93: astore #19
      //   95: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   98: aload #20
      //   100: invokevirtual ordinal : ()I
      //   103: iaload
      //   104: istore #6
      //   106: iload #6
      //   108: iconst_1
      //   109: if_icmpeq -> 322
      //   112: iload #6
      //   114: iconst_2
      //   115: if_icmpeq -> 306
      //   118: iload #6
      //   120: iconst_3
      //   121: if_icmpeq -> 286
      //   124: iload #6
      //   126: iconst_4
      //   127: if_icmpeq -> 136
      //   130: iconst_0
      //   131: istore #4
      //   133: goto -> 331
      //   136: aload_0
      //   137: getfield layoutWidthSpec : I
      //   140: iload #5
      //   142: bipush #-2
      //   144: invokestatic getChildMeasureSpec : (III)I
      //   147: istore #6
      //   149: aload_1
      //   150: getfield mMatchConstraintDefaultWidth : I
      //   153: iconst_1
      //   154: if_icmpne -> 163
      //   157: iconst_1
      //   158: istore #5
      //   160: goto -> 166
      //   163: iconst_0
      //   164: istore #5
      //   166: aload_2
      //   167: getfield measureStrategy : I
      //   170: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   173: if_icmpeq -> 190
      //   176: iload #6
      //   178: istore #4
      //   180: aload_2
      //   181: getfield measureStrategy : I
      //   184: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   187: if_icmpne -> 331
      //   190: aload #19
      //   192: invokevirtual getMeasuredHeight : ()I
      //   195: aload_1
      //   196: invokevirtual getHeight : ()I
      //   199: if_icmpne -> 208
      //   202: iconst_1
      //   203: istore #4
      //   205: goto -> 211
      //   208: iconst_0
      //   209: istore #4
      //   211: aload_2
      //   212: getfield measureStrategy : I
      //   215: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   218: if_icmpeq -> 260
      //   221: iload #5
      //   223: ifeq -> 260
      //   226: iload #5
      //   228: ifeq -> 236
      //   231: iload #4
      //   233: ifne -> 260
      //   236: aload #19
      //   238: instanceof androidx/constraintlayout/widget/Placeholder
      //   241: ifne -> 260
      //   244: aload_1
      //   245: invokevirtual isResolvedHorizontally : ()Z
      //   248: ifeq -> 254
      //   251: goto -> 260
      //   254: iconst_0
      //   255: istore #5
      //   257: goto -> 263
      //   260: iconst_1
      //   261: istore #5
      //   263: iload #6
      //   265: istore #4
      //   267: iload #5
      //   269: ifeq -> 331
      //   272: aload_1
      //   273: invokevirtual getWidth : ()I
      //   276: ldc 1073741824
      //   278: invokestatic makeMeasureSpec : (II)I
      //   281: istore #4
      //   283: goto -> 331
      //   286: aload_0
      //   287: getfield layoutWidthSpec : I
      //   290: iload #5
      //   292: aload_1
      //   293: invokevirtual getHorizontalMargin : ()I
      //   296: iadd
      //   297: iconst_m1
      //   298: invokestatic getChildMeasureSpec : (III)I
      //   301: istore #4
      //   303: goto -> 331
      //   306: aload_0
      //   307: getfield layoutWidthSpec : I
      //   310: iload #5
      //   312: bipush #-2
      //   314: invokestatic getChildMeasureSpec : (III)I
      //   317: istore #4
      //   319: goto -> 331
      //   322: iload #4
      //   324: ldc 1073741824
      //   326: invokestatic makeMeasureSpec : (II)I
      //   329: istore #4
      //   331: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   334: aload #21
      //   336: invokevirtual ordinal : ()I
      //   339: iaload
      //   340: istore #5
      //   342: iload #5
      //   344: iconst_1
      //   345: if_icmpeq -> 558
      //   348: iload #5
      //   350: iconst_2
      //   351: if_icmpeq -> 542
      //   354: iload #5
      //   356: iconst_3
      //   357: if_icmpeq -> 522
      //   360: iload #5
      //   362: iconst_4
      //   363: if_icmpeq -> 372
      //   366: iconst_0
      //   367: istore #5
      //   369: goto -> 567
      //   372: aload_0
      //   373: getfield layoutHeightSpec : I
      //   376: iload #8
      //   378: bipush #-2
      //   380: invokestatic getChildMeasureSpec : (III)I
      //   383: istore #7
      //   385: aload_1
      //   386: getfield mMatchConstraintDefaultHeight : I
      //   389: iconst_1
      //   390: if_icmpne -> 399
      //   393: iconst_1
      //   394: istore #6
      //   396: goto -> 402
      //   399: iconst_0
      //   400: istore #6
      //   402: aload_2
      //   403: getfield measureStrategy : I
      //   406: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   409: if_icmpeq -> 426
      //   412: iload #7
      //   414: istore #5
      //   416: aload_2
      //   417: getfield measureStrategy : I
      //   420: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   423: if_icmpne -> 567
      //   426: aload #19
      //   428: invokevirtual getMeasuredWidth : ()I
      //   431: aload_1
      //   432: invokevirtual getWidth : ()I
      //   435: if_icmpne -> 444
      //   438: iconst_1
      //   439: istore #5
      //   441: goto -> 447
      //   444: iconst_0
      //   445: istore #5
      //   447: aload_2
      //   448: getfield measureStrategy : I
      //   451: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   454: if_icmpeq -> 496
      //   457: iload #6
      //   459: ifeq -> 496
      //   462: iload #6
      //   464: ifeq -> 472
      //   467: iload #5
      //   469: ifne -> 496
      //   472: aload #19
      //   474: instanceof androidx/constraintlayout/widget/Placeholder
      //   477: ifne -> 496
      //   480: aload_1
      //   481: invokevirtual isResolvedVertically : ()Z
      //   484: ifeq -> 490
      //   487: goto -> 496
      //   490: iconst_0
      //   491: istore #6
      //   493: goto -> 499
      //   496: iconst_1
      //   497: istore #6
      //   499: iload #7
      //   501: istore #5
      //   503: iload #6
      //   505: ifeq -> 567
      //   508: aload_1
      //   509: invokevirtual getHeight : ()I
      //   512: ldc 1073741824
      //   514: invokestatic makeMeasureSpec : (II)I
      //   517: istore #5
      //   519: goto -> 567
      //   522: aload_0
      //   523: getfield layoutHeightSpec : I
      //   526: iload #8
      //   528: aload_1
      //   529: invokevirtual getVerticalMargin : ()I
      //   532: iadd
      //   533: iconst_m1
      //   534: invokestatic getChildMeasureSpec : (III)I
      //   537: istore #5
      //   539: goto -> 567
      //   542: aload_0
      //   543: getfield layoutHeightSpec : I
      //   546: iload #8
      //   548: bipush #-2
      //   550: invokestatic getChildMeasureSpec : (III)I
      //   553: istore #5
      //   555: goto -> 567
      //   558: iload #7
      //   560: ldc 1073741824
      //   562: invokestatic makeMeasureSpec : (II)I
      //   565: istore #5
      //   567: aload_1
      //   568: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   571: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
      //   574: astore #22
      //   576: aload #22
      //   578: ifnull -> 739
      //   581: aload_0
      //   582: getfield this$0 : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   585: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   588: sipush #256
      //   591: invokestatic enabled : (II)Z
      //   594: ifeq -> 739
      //   597: aload #19
      //   599: invokevirtual getMeasuredWidth : ()I
      //   602: aload_1
      //   603: invokevirtual getWidth : ()I
      //   606: if_icmpne -> 739
      //   609: aload #19
      //   611: invokevirtual getMeasuredWidth : ()I
      //   614: aload #22
      //   616: invokevirtual getWidth : ()I
      //   619: if_icmpge -> 739
      //   622: aload #19
      //   624: invokevirtual getMeasuredHeight : ()I
      //   627: aload_1
      //   628: invokevirtual getHeight : ()I
      //   631: if_icmpne -> 739
      //   634: aload #19
      //   636: invokevirtual getMeasuredHeight : ()I
      //   639: aload #22
      //   641: invokevirtual getHeight : ()I
      //   644: if_icmpge -> 739
      //   647: aload #19
      //   649: invokevirtual getBaseline : ()I
      //   652: aload_1
      //   653: invokevirtual getBaselineDistance : ()I
      //   656: if_icmpne -> 739
      //   659: aload_1
      //   660: invokevirtual isMeasureRequested : ()Z
      //   663: ifne -> 739
      //   666: aload_0
      //   667: aload_1
      //   668: invokevirtual getLastHorizontalMeasureSpec : ()I
      //   671: iload #4
      //   673: aload_1
      //   674: invokevirtual getWidth : ()I
      //   677: invokespecial isSimilarSpec : (III)Z
      //   680: ifeq -> 706
      //   683: aload_0
      //   684: aload_1
      //   685: invokevirtual getLastVerticalMeasureSpec : ()I
      //   688: iload #5
      //   690: aload_1
      //   691: invokevirtual getHeight : ()I
      //   694: invokespecial isSimilarSpec : (III)Z
      //   697: ifeq -> 706
      //   700: iconst_1
      //   701: istore #6
      //   703: goto -> 709
      //   706: iconst_0
      //   707: istore #6
      //   709: iload #6
      //   711: ifeq -> 739
      //   714: aload_2
      //   715: aload_1
      //   716: invokevirtual getWidth : ()I
      //   719: putfield measuredWidth : I
      //   722: aload_2
      //   723: aload_1
      //   724: invokevirtual getHeight : ()I
      //   727: putfield measuredHeight : I
      //   730: aload_2
      //   731: aload_1
      //   732: invokevirtual getBaselineDistance : ()I
      //   735: putfield measuredBaseline : I
      //   738: return
      //   739: aload #20
      //   741: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   744: if_acmpne -> 753
      //   747: iconst_1
      //   748: istore #6
      //   750: goto -> 756
      //   753: iconst_0
      //   754: istore #6
      //   756: aload #21
      //   758: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   761: if_acmpne -> 770
      //   764: iconst_1
      //   765: istore #7
      //   767: goto -> 773
      //   770: iconst_0
      //   771: istore #7
      //   773: aload #21
      //   775: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   778: if_acmpeq -> 798
      //   781: aload #21
      //   783: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   786: if_acmpne -> 792
      //   789: goto -> 798
      //   792: iconst_0
      //   793: istore #10
      //   795: goto -> 801
      //   798: iconst_1
      //   799: istore #10
      //   801: aload #20
      //   803: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   806: if_acmpeq -> 826
      //   809: aload #20
      //   811: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   814: if_acmpne -> 820
      //   817: goto -> 826
      //   820: iconst_0
      //   821: istore #11
      //   823: goto -> 829
      //   826: iconst_1
      //   827: istore #11
      //   829: iload #6
      //   831: ifeq -> 849
      //   834: aload_1
      //   835: getfield mDimensionRatio : F
      //   838: fconst_0
      //   839: fcmpl
      //   840: ifle -> 849
      //   843: iconst_1
      //   844: istore #12
      //   846: goto -> 852
      //   849: iconst_0
      //   850: istore #12
      //   852: iload #7
      //   854: ifeq -> 872
      //   857: aload_1
      //   858: getfield mDimensionRatio : F
      //   861: fconst_0
      //   862: fcmpl
      //   863: ifle -> 872
      //   866: iconst_1
      //   867: istore #13
      //   869: goto -> 875
      //   872: iconst_0
      //   873: istore #13
      //   875: aload #19
      //   877: ifnonnull -> 881
      //   880: return
      //   881: aload #19
      //   883: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   886: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
      //   889: astore #20
      //   891: aload_2
      //   892: getfield measureStrategy : I
      //   895: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   898: if_icmpeq -> 950
      //   901: aload_2
      //   902: getfield measureStrategy : I
      //   905: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   908: if_icmpeq -> 950
      //   911: iload #6
      //   913: ifeq -> 950
      //   916: aload_1
      //   917: getfield mMatchConstraintDefaultWidth : I
      //   920: ifne -> 950
      //   923: iload #7
      //   925: ifeq -> 950
      //   928: aload_1
      //   929: getfield mMatchConstraintDefaultHeight : I
      //   932: ifeq -> 938
      //   935: goto -> 950
      //   938: iconst_0
      //   939: istore #6
      //   941: iconst_0
      //   942: istore #9
      //   944: iconst_0
      //   945: istore #10
      //   947: goto -> 1331
      //   950: aload #19
      //   952: instanceof androidx/constraintlayout/widget/VirtualLayout
      //   955: ifeq -> 988
      //   958: aload_1
      //   959: instanceof androidx/constraintlayout/solver/widgets/VirtualLayout
      //   962: ifeq -> 988
      //   965: aload_1
      //   966: checkcast androidx/constraintlayout/solver/widgets/VirtualLayout
      //   969: astore #21
      //   971: aload #19
      //   973: checkcast androidx/constraintlayout/widget/VirtualLayout
      //   976: aload #21
      //   978: iload #4
      //   980: iload #5
      //   982: invokevirtual onMeasure : (Landroidx/constraintlayout/solver/widgets/VirtualLayout;II)V
      //   985: goto -> 997
      //   988: aload #19
      //   990: iload #4
      //   992: iload #5
      //   994: invokevirtual measure : (II)V
      //   997: aload_1
      //   998: iload #4
      //   1000: iload #5
      //   1002: invokevirtual setLastMeasureSpec : (II)V
      //   1005: aload #19
      //   1007: invokevirtual getMeasuredWidth : ()I
      //   1010: istore #15
      //   1012: aload #19
      //   1014: invokevirtual getMeasuredHeight : ()I
      //   1017: istore #14
      //   1019: aload #19
      //   1021: invokevirtual getBaseline : ()I
      //   1024: istore #16
      //   1026: aload_1
      //   1027: getfield mMatchConstraintMinWidth : I
      //   1030: ifle -> 1047
      //   1033: aload_1
      //   1034: getfield mMatchConstraintMinWidth : I
      //   1037: iload #15
      //   1039: invokestatic max : (II)I
      //   1042: istore #7
      //   1044: goto -> 1051
      //   1047: iload #15
      //   1049: istore #7
      //   1051: iload #7
      //   1053: istore #6
      //   1055: aload_1
      //   1056: getfield mMatchConstraintMaxWidth : I
      //   1059: ifle -> 1073
      //   1062: aload_1
      //   1063: getfield mMatchConstraintMaxWidth : I
      //   1066: iload #7
      //   1068: invokestatic min : (II)I
      //   1071: istore #6
      //   1073: aload_1
      //   1074: getfield mMatchConstraintMinHeight : I
      //   1077: ifle -> 1094
      //   1080: aload_1
      //   1081: getfield mMatchConstraintMinHeight : I
      //   1084: iload #14
      //   1086: invokestatic max : (II)I
      //   1089: istore #7
      //   1091: goto -> 1098
      //   1094: iload #14
      //   1096: istore #7
      //   1098: iload #7
      //   1100: istore #9
      //   1102: aload_1
      //   1103: getfield mMatchConstraintMaxHeight : I
      //   1106: ifle -> 1120
      //   1109: aload_1
      //   1110: getfield mMatchConstraintMaxHeight : I
      //   1113: iload #7
      //   1115: invokestatic min : (II)I
      //   1118: istore #9
      //   1120: iload #6
      //   1122: istore #8
      //   1124: iload #9
      //   1126: istore #7
      //   1128: aload_0
      //   1129: getfield this$0 : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   1132: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   1135: iconst_1
      //   1136: invokestatic enabled : (II)Z
      //   1139: ifne -> 1223
      //   1142: iload #12
      //   1144: ifeq -> 1176
      //   1147: iload #10
      //   1149: ifeq -> 1176
      //   1152: aload_1
      //   1153: getfield mDimensionRatio : F
      //   1156: fstore_3
      //   1157: iload #9
      //   1159: i2f
      //   1160: fload_3
      //   1161: fmul
      //   1162: ldc_w 0.5
      //   1165: fadd
      //   1166: f2i
      //   1167: istore #8
      //   1169: iload #9
      //   1171: istore #7
      //   1173: goto -> 1223
      //   1176: iload #6
      //   1178: istore #8
      //   1180: iload #9
      //   1182: istore #7
      //   1184: iload #13
      //   1186: ifeq -> 1223
      //   1189: iload #6
      //   1191: istore #8
      //   1193: iload #9
      //   1195: istore #7
      //   1197: iload #11
      //   1199: ifeq -> 1223
      //   1202: aload_1
      //   1203: getfield mDimensionRatio : F
      //   1206: fstore_3
      //   1207: iload #6
      //   1209: i2f
      //   1210: fload_3
      //   1211: fdiv
      //   1212: ldc_w 0.5
      //   1215: fadd
      //   1216: f2i
      //   1217: istore #7
      //   1219: iload #6
      //   1221: istore #8
      //   1223: iload #15
      //   1225: iload #8
      //   1227: if_icmpne -> 1255
      //   1230: iload #16
      //   1232: istore #6
      //   1234: iload #8
      //   1236: istore #9
      //   1238: iload #7
      //   1240: istore #10
      //   1242: iload #14
      //   1244: iload #7
      //   1246: if_icmpeq -> 1252
      //   1249: goto -> 1255
      //   1252: goto -> 1331
      //   1255: iload #15
      //   1257: iload #8
      //   1259: if_icmpeq -> 1271
      //   1262: iload #8
      //   1264: ldc 1073741824
      //   1266: invokestatic makeMeasureSpec : (II)I
      //   1269: istore #4
      //   1271: iload #14
      //   1273: iload #7
      //   1275: if_icmpeq -> 1290
      //   1278: iload #7
      //   1280: ldc 1073741824
      //   1282: invokestatic makeMeasureSpec : (II)I
      //   1285: istore #5
      //   1287: goto -> 1290
      //   1290: aload #19
      //   1292: iload #4
      //   1294: iload #5
      //   1296: invokevirtual measure : (II)V
      //   1299: aload_1
      //   1300: iload #4
      //   1302: iload #5
      //   1304: invokevirtual setLastMeasureSpec : (II)V
      //   1307: aload #19
      //   1309: invokevirtual getMeasuredWidth : ()I
      //   1312: istore #9
      //   1314: aload #19
      //   1316: invokevirtual getMeasuredHeight : ()I
      //   1319: istore #10
      //   1321: aload #19
      //   1323: invokevirtual getBaseline : ()I
      //   1326: istore #6
      //   1328: goto -> 1252
      //   1331: iload #6
      //   1333: iconst_m1
      //   1334: if_icmpeq -> 1343
      //   1337: iconst_1
      //   1338: istore #17
      //   1340: goto -> 1346
      //   1343: iconst_0
      //   1344: istore #17
      //   1346: iload #9
      //   1348: aload_2
      //   1349: getfield horizontalDimension : I
      //   1352: if_icmpne -> 1373
      //   1355: iload #10
      //   1357: aload_2
      //   1358: getfield verticalDimension : I
      //   1361: if_icmpeq -> 1367
      //   1364: goto -> 1373
      //   1367: iconst_0
      //   1368: istore #18
      //   1370: goto -> 1376
      //   1373: iconst_1
      //   1374: istore #18
      //   1376: aload_2
      //   1377: iload #18
      //   1379: putfield measuredNeedsSolverPass : Z
      //   1382: aload #20
      //   1384: getfield needsBaseline : Z
      //   1387: ifeq -> 1393
      //   1390: iconst_1
      //   1391: istore #17
      //   1393: iload #17
      //   1395: ifeq -> 1418
      //   1398: iload #6
      //   1400: iconst_m1
      //   1401: if_icmpeq -> 1418
      //   1404: aload_1
      //   1405: invokevirtual getBaselineDistance : ()I
      //   1408: iload #6
      //   1410: if_icmpeq -> 1418
      //   1413: aload_2
      //   1414: iconst_1
      //   1415: putfield measuredNeedsSolverPass : Z
      //   1418: aload_2
      //   1419: iload #9
      //   1421: putfield measuredWidth : I
      //   1424: aload_2
      //   1425: iload #10
      //   1427: putfield measuredHeight : I
      //   1430: aload_2
      //   1431: iload #17
      //   1433: putfield measuredHasBaseline : Z
      //   1436: aload_2
      //   1437: iload #6
      //   1439: putfield measuredBaseline : I
      //   1442: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */