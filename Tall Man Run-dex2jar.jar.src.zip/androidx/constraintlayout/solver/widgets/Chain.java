package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.ArrayList;

public class Chain {
  private static final boolean DEBUG = false;
  
  public static final boolean USE_CHAIN_OPTIMIZATION = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: aload #4
    //   2: getfield mFirst : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   5: astore #26
    //   7: aload #4
    //   9: getfield mLast : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   12: astore #23
    //   14: aload #4
    //   16: getfield mFirstVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   19: astore #20
    //   21: aload #4
    //   23: getfield mLastVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   26: astore #24
    //   28: aload #4
    //   30: getfield mHead : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   33: astore #18
    //   35: aload #4
    //   37: getfield mTotalWeight : F
    //   40: fstore #5
    //   42: aload #4
    //   44: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   47: astore #17
    //   49: aload #4
    //   51: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #17
    //   56: aload_0
    //   57: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   60: iload_2
    //   61: aaload
    //   62: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   65: if_acmpne -> 74
    //   68: iconst_1
    //   69: istore #12
    //   71: goto -> 77
    //   74: iconst_0
    //   75: istore #12
    //   77: iload_2
    //   78: ifne -> 136
    //   81: aload #18
    //   83: getfield mHorizontalChainStyle : I
    //   86: ifne -> 95
    //   89: iconst_1
    //   90: istore #8
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #8
    //   98: aload #18
    //   100: getfield mHorizontalChainStyle : I
    //   103: iconst_1
    //   104: if_icmpne -> 113
    //   107: iconst_1
    //   108: istore #9
    //   110: goto -> 116
    //   113: iconst_0
    //   114: istore #9
    //   116: iload #8
    //   118: istore #10
    //   120: iload #9
    //   122: istore #11
    //   124: aload #18
    //   126: getfield mHorizontalChainStyle : I
    //   129: iconst_2
    //   130: if_icmpne -> 198
    //   133: goto -> 188
    //   136: aload #18
    //   138: getfield mVerticalChainStyle : I
    //   141: ifne -> 150
    //   144: iconst_1
    //   145: istore #8
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #8
    //   153: aload #18
    //   155: getfield mVerticalChainStyle : I
    //   158: iconst_1
    //   159: if_icmpne -> 168
    //   162: iconst_1
    //   163: istore #9
    //   165: goto -> 171
    //   168: iconst_0
    //   169: istore #9
    //   171: iload #8
    //   173: istore #10
    //   175: iload #9
    //   177: istore #11
    //   179: aload #18
    //   181: getfield mVerticalChainStyle : I
    //   184: iconst_2
    //   185: if_icmpne -> 198
    //   188: iconst_1
    //   189: istore #13
    //   191: iload #8
    //   193: istore #10
    //   195: goto -> 205
    //   198: iconst_0
    //   199: istore #13
    //   201: iload #11
    //   203: istore #9
    //   205: aload #26
    //   207: astore #19
    //   209: iconst_0
    //   210: istore #8
    //   212: iload #9
    //   214: istore #11
    //   216: aconst_null
    //   217: astore #25
    //   219: aconst_null
    //   220: astore #21
    //   222: iload #8
    //   224: ifne -> 631
    //   227: aload #19
    //   229: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   232: iload_3
    //   233: aaload
    //   234: astore #17
    //   236: iload #13
    //   238: ifeq -> 247
    //   241: iconst_1
    //   242: istore #9
    //   244: goto -> 250
    //   247: iconst_4
    //   248: istore #9
    //   250: aload #17
    //   252: invokevirtual getMargin : ()I
    //   255: istore #16
    //   257: aload #19
    //   259: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   262: iload_2
    //   263: aaload
    //   264: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: if_acmpne -> 286
    //   270: aload #19
    //   272: getfield mResolvedMatchConstraintDefault : [I
    //   275: iload_2
    //   276: iaload
    //   277: ifne -> 286
    //   280: iconst_1
    //   281: istore #15
    //   283: goto -> 289
    //   286: iconst_0
    //   287: istore #15
    //   289: iload #16
    //   291: istore #14
    //   293: aload #17
    //   295: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   298: ifnull -> 325
    //   301: iload #16
    //   303: istore #14
    //   305: aload #19
    //   307: aload #26
    //   309: if_acmpeq -> 325
    //   312: iload #16
    //   314: aload #17
    //   316: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   319: invokevirtual getMargin : ()I
    //   322: iadd
    //   323: istore #14
    //   325: iload #13
    //   327: ifeq -> 351
    //   330: aload #19
    //   332: aload #26
    //   334: if_acmpeq -> 351
    //   337: aload #19
    //   339: aload #20
    //   341: if_acmpeq -> 351
    //   344: bipush #8
    //   346: istore #9
    //   348: goto -> 351
    //   351: aload #17
    //   353: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   356: ifnull -> 452
    //   359: aload #19
    //   361: aload #20
    //   363: if_acmpne -> 390
    //   366: aload_1
    //   367: aload #17
    //   369: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   372: aload #17
    //   374: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   377: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   380: iload #14
    //   382: bipush #6
    //   384: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   387: goto -> 411
    //   390: aload_1
    //   391: aload #17
    //   393: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   396: aload #17
    //   398: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   401: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   404: iload #14
    //   406: bipush #8
    //   408: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   411: iload #15
    //   413: ifeq -> 427
    //   416: iload #13
    //   418: ifne -> 427
    //   421: iconst_5
    //   422: istore #9
    //   424: goto -> 427
    //   427: aload_1
    //   428: aload #17
    //   430: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   433: aload #17
    //   435: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   438: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   441: iload #14
    //   443: iload #9
    //   445: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   448: pop
    //   449: goto -> 452
    //   452: iload #12
    //   454: ifeq -> 537
    //   457: aload #19
    //   459: invokevirtual getVisibility : ()I
    //   462: bipush #8
    //   464: if_icmpeq -> 511
    //   467: aload #19
    //   469: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   472: iload_2
    //   473: aaload
    //   474: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   477: if_acmpne -> 511
    //   480: aload_1
    //   481: aload #19
    //   483: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   486: iload_3
    //   487: iconst_1
    //   488: iadd
    //   489: aaload
    //   490: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   493: aload #19
    //   495: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   498: iload_3
    //   499: aaload
    //   500: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   503: iconst_0
    //   504: iconst_5
    //   505: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   508: goto -> 511
    //   511: aload_1
    //   512: aload #19
    //   514: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   517: iload_3
    //   518: aaload
    //   519: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   522: aload_0
    //   523: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   526: iload_3
    //   527: aaload
    //   528: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   531: iconst_0
    //   532: bipush #8
    //   534: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   537: aload #19
    //   539: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   542: iload_3
    //   543: iconst_1
    //   544: iadd
    //   545: aaload
    //   546: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   549: astore #22
    //   551: aload #21
    //   553: astore #17
    //   555: aload #22
    //   557: ifnull -> 613
    //   560: aload #22
    //   562: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   565: astore #22
    //   567: aload #21
    //   569: astore #17
    //   571: aload #22
    //   573: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   576: iload_3
    //   577: aaload
    //   578: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   581: ifnull -> 613
    //   584: aload #22
    //   586: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   589: iload_3
    //   590: aaload
    //   591: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   594: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   597: aload #19
    //   599: if_acmpeq -> 609
    //   602: aload #21
    //   604: astore #17
    //   606: goto -> 613
    //   609: aload #22
    //   611: astore #17
    //   613: aload #17
    //   615: ifnull -> 625
    //   618: aload #17
    //   620: astore #19
    //   622: goto -> 628
    //   625: iconst_1
    //   626: istore #8
    //   628: goto -> 216
    //   631: aload #24
    //   633: ifnull -> 827
    //   636: aload #23
    //   638: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   641: astore #17
    //   643: iload_3
    //   644: iconst_1
    //   645: iadd
    //   646: istore #9
    //   648: aload #17
    //   650: iload #9
    //   652: aaload
    //   653: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   656: ifnull -> 827
    //   659: aload #24
    //   661: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   664: iload #9
    //   666: aaload
    //   667: astore #17
    //   669: aload #24
    //   671: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   674: iload_2
    //   675: aaload
    //   676: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   679: if_acmpne -> 698
    //   682: aload #24
    //   684: getfield mResolvedMatchConstraintDefault : [I
    //   687: iload_2
    //   688: iaload
    //   689: ifne -> 698
    //   692: iconst_1
    //   693: istore #8
    //   695: goto -> 701
    //   698: iconst_0
    //   699: istore #8
    //   701: iload #8
    //   703: ifeq -> 751
    //   706: iload #13
    //   708: ifne -> 751
    //   711: aload #17
    //   713: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   716: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   719: aload_0
    //   720: if_acmpne -> 751
    //   723: aload_1
    //   724: aload #17
    //   726: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   729: aload #17
    //   731: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   734: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   737: aload #17
    //   739: invokevirtual getMargin : ()I
    //   742: ineg
    //   743: iconst_5
    //   744: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   747: pop
    //   748: goto -> 793
    //   751: iload #13
    //   753: ifeq -> 793
    //   756: aload #17
    //   758: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   761: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   764: aload_0
    //   765: if_acmpne -> 793
    //   768: aload_1
    //   769: aload #17
    //   771: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   774: aload #17
    //   776: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   779: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   782: aload #17
    //   784: invokevirtual getMargin : ()I
    //   787: ineg
    //   788: iconst_4
    //   789: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   792: pop
    //   793: aload_1
    //   794: aload #17
    //   796: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   799: aload #23
    //   801: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   804: iload #9
    //   806: aaload
    //   807: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   810: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   813: aload #17
    //   815: invokevirtual getMargin : ()I
    //   818: ineg
    //   819: bipush #6
    //   821: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   824: goto -> 827
    //   827: iload #12
    //   829: ifeq -> 877
    //   832: aload_0
    //   833: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   836: astore_0
    //   837: iload_3
    //   838: iconst_1
    //   839: iadd
    //   840: istore #8
    //   842: aload_1
    //   843: aload_0
    //   844: iload #8
    //   846: aaload
    //   847: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   850: aload #23
    //   852: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   855: iload #8
    //   857: aaload
    //   858: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   861: aload #23
    //   863: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   866: iload #8
    //   868: aaload
    //   869: invokevirtual getMargin : ()I
    //   872: bipush #8
    //   874: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   877: aload #4
    //   879: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   882: astore_0
    //   883: aload_0
    //   884: ifnull -> 1179
    //   887: aload_0
    //   888: invokevirtual size : ()I
    //   891: istore #8
    //   893: iload #8
    //   895: iconst_1
    //   896: if_icmple -> 1179
    //   899: aload #4
    //   901: getfield mHasUndefinedWeights : Z
    //   904: ifeq -> 926
    //   907: aload #4
    //   909: getfield mHasComplexMatchWeights : Z
    //   912: ifne -> 926
    //   915: aload #4
    //   917: getfield mWidgetsMatchCount : I
    //   920: i2f
    //   921: fstore #6
    //   923: goto -> 930
    //   926: fload #5
    //   928: fstore #6
    //   930: aconst_null
    //   931: astore #17
    //   933: iconst_0
    //   934: istore #9
    //   936: fconst_0
    //   937: fstore #7
    //   939: iload #9
    //   941: iload #8
    //   943: if_icmpge -> 1179
    //   946: aload_0
    //   947: iload #9
    //   949: invokevirtual get : (I)Ljava/lang/Object;
    //   952: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   955: astore #19
    //   957: aload #19
    //   959: getfield mWeight : [F
    //   962: iload_2
    //   963: faload
    //   964: fstore #5
    //   966: fload #5
    //   968: fconst_0
    //   969: fcmpg
    //   970: ifge -> 1019
    //   973: aload #4
    //   975: getfield mHasComplexMatchWeights : Z
    //   978: ifeq -> 1013
    //   981: aload_1
    //   982: aload #19
    //   984: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   987: iload_3
    //   988: iconst_1
    //   989: iadd
    //   990: aaload
    //   991: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   994: aload #19
    //   996: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   999: iload_3
    //   1000: aaload
    //   1001: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1004: iconst_0
    //   1005: iconst_4
    //   1006: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1009: pop
    //   1010: goto -> 1056
    //   1013: fconst_1
    //   1014: fstore #5
    //   1016: goto -> 1019
    //   1019: fload #5
    //   1021: fconst_0
    //   1022: fcmpl
    //   1023: ifne -> 1063
    //   1026: aload_1
    //   1027: aload #19
    //   1029: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1032: iload_3
    //   1033: iconst_1
    //   1034: iadd
    //   1035: aaload
    //   1036: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1039: aload #19
    //   1041: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1044: iload_3
    //   1045: aaload
    //   1046: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1049: iconst_0
    //   1050: bipush #8
    //   1052: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1055: pop
    //   1056: fload #7
    //   1058: fstore #5
    //   1060: goto -> 1166
    //   1063: aload #17
    //   1065: ifnull -> 1162
    //   1068: aload #17
    //   1070: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1073: iload_3
    //   1074: aaload
    //   1075: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1078: astore #21
    //   1080: aload #17
    //   1082: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1085: astore #17
    //   1087: iload_3
    //   1088: iconst_1
    //   1089: iadd
    //   1090: istore #12
    //   1092: aload #17
    //   1094: iload #12
    //   1096: aaload
    //   1097: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1100: astore #17
    //   1102: aload #19
    //   1104: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1107: iload_3
    //   1108: aaload
    //   1109: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1112: astore #22
    //   1114: aload #19
    //   1116: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1119: iload #12
    //   1121: aaload
    //   1122: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1125: astore #27
    //   1127: aload_1
    //   1128: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   1131: astore #28
    //   1133: aload #28
    //   1135: fload #7
    //   1137: fload #6
    //   1139: fload #5
    //   1141: aload #21
    //   1143: aload #17
    //   1145: aload #22
    //   1147: aload #27
    //   1149: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/ArrayRow;
    //   1152: pop
    //   1153: aload_1
    //   1154: aload #28
    //   1156: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   1159: goto -> 1162
    //   1162: aload #19
    //   1164: astore #17
    //   1166: iload #9
    //   1168: iconst_1
    //   1169: iadd
    //   1170: istore #9
    //   1172: fload #5
    //   1174: fstore #7
    //   1176: goto -> 939
    //   1179: aload #20
    //   1181: ifnull -> 1356
    //   1184: aload #20
    //   1186: aload #24
    //   1188: if_acmpeq -> 1196
    //   1191: iload #13
    //   1193: ifeq -> 1356
    //   1196: aload #26
    //   1198: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1201: iload_3
    //   1202: aaload
    //   1203: astore_0
    //   1204: aload #23
    //   1206: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1209: astore #4
    //   1211: iload_3
    //   1212: iconst_1
    //   1213: iadd
    //   1214: istore #8
    //   1216: aload #4
    //   1218: iload #8
    //   1220: aaload
    //   1221: astore #4
    //   1223: aload_0
    //   1224: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1227: ifnull -> 1241
    //   1230: aload_0
    //   1231: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1234: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1237: astore_0
    //   1238: goto -> 1243
    //   1241: aconst_null
    //   1242: astore_0
    //   1243: aload #4
    //   1245: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1248: ifnull -> 1264
    //   1251: aload #4
    //   1253: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1256: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1259: astore #4
    //   1261: goto -> 1267
    //   1264: aconst_null
    //   1265: astore #4
    //   1267: aload #20
    //   1269: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1272: iload_3
    //   1273: aaload
    //   1274: astore #17
    //   1276: aload #24
    //   1278: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1281: iload #8
    //   1283: aaload
    //   1284: astore #19
    //   1286: aload_0
    //   1287: ifnull -> 2431
    //   1290: aload #4
    //   1292: ifnull -> 2431
    //   1295: iload_2
    //   1296: ifne -> 1309
    //   1299: aload #18
    //   1301: getfield mHorizontalBiasPercent : F
    //   1304: fstore #5
    //   1306: goto -> 1316
    //   1309: aload #18
    //   1311: getfield mVerticalBiasPercent : F
    //   1314: fstore #5
    //   1316: aload #17
    //   1318: invokevirtual getMargin : ()I
    //   1321: istore_2
    //   1322: aload #19
    //   1324: invokevirtual getMargin : ()I
    //   1327: istore #8
    //   1329: aload_1
    //   1330: aload #17
    //   1332: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1335: aload_0
    //   1336: iload_2
    //   1337: fload #5
    //   1339: aload #4
    //   1341: aload #19
    //   1343: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1346: iload #8
    //   1348: bipush #7
    //   1350: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1353: goto -> 2431
    //   1356: iload #10
    //   1358: ifeq -> 1856
    //   1361: aload #20
    //   1363: ifnull -> 1856
    //   1366: aload #4
    //   1368: getfield mWidgetsMatchCount : I
    //   1371: ifle -> 1393
    //   1374: aload #4
    //   1376: getfield mWidgetsCount : I
    //   1379: aload #4
    //   1381: getfield mWidgetsMatchCount : I
    //   1384: if_icmpne -> 1393
    //   1387: iconst_1
    //   1388: istore #12
    //   1390: goto -> 1396
    //   1393: iconst_0
    //   1394: istore #12
    //   1396: aload #20
    //   1398: astore #4
    //   1400: aload #4
    //   1402: astore #19
    //   1404: aload #4
    //   1406: ifnull -> 2431
    //   1409: aload #4
    //   1411: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1414: iload_2
    //   1415: aaload
    //   1416: astore #17
    //   1418: aload #17
    //   1420: ifnull -> 1445
    //   1423: aload #17
    //   1425: invokevirtual getVisibility : ()I
    //   1428: bipush #8
    //   1430: if_icmpne -> 1445
    //   1433: aload #17
    //   1435: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1438: iload_2
    //   1439: aaload
    //   1440: astore #17
    //   1442: goto -> 1418
    //   1445: aload #17
    //   1447: ifnonnull -> 1463
    //   1450: aload #4
    //   1452: aload #24
    //   1454: if_acmpne -> 1460
    //   1457: goto -> 1463
    //   1460: goto -> 1835
    //   1463: aload #4
    //   1465: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1468: iload_3
    //   1469: aaload
    //   1470: astore #21
    //   1472: aload #21
    //   1474: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1477: astore #28
    //   1479: aload #21
    //   1481: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1484: ifnull -> 1500
    //   1487: aload #21
    //   1489: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1492: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1495: astore #18
    //   1497: goto -> 1503
    //   1500: aconst_null
    //   1501: astore #18
    //   1503: aload #19
    //   1505: aload #4
    //   1507: if_acmpeq -> 1526
    //   1510: aload #19
    //   1512: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1515: iload_3
    //   1516: iconst_1
    //   1517: iadd
    //   1518: aaload
    //   1519: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1522: astore_0
    //   1523: goto -> 1578
    //   1526: aload #18
    //   1528: astore_0
    //   1529: aload #4
    //   1531: aload #20
    //   1533: if_acmpne -> 1578
    //   1536: aload #18
    //   1538: astore_0
    //   1539: aload #19
    //   1541: aload #4
    //   1543: if_acmpne -> 1578
    //   1546: aload #26
    //   1548: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1551: iload_3
    //   1552: aaload
    //   1553: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1556: ifnull -> 1576
    //   1559: aload #26
    //   1561: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1564: iload_3
    //   1565: aaload
    //   1566: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1569: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1572: astore_0
    //   1573: goto -> 1578
    //   1576: aconst_null
    //   1577: astore_0
    //   1578: aload #21
    //   1580: invokevirtual getMargin : ()I
    //   1583: istore #13
    //   1585: aload #4
    //   1587: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1590: astore #18
    //   1592: iload_3
    //   1593: iconst_1
    //   1594: iadd
    //   1595: istore #14
    //   1597: aload #18
    //   1599: iload #14
    //   1601: aaload
    //   1602: invokevirtual getMargin : ()I
    //   1605: istore #9
    //   1607: aload #17
    //   1609: ifnull -> 1644
    //   1612: aload #17
    //   1614: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1617: iload_3
    //   1618: aaload
    //   1619: astore #18
    //   1621: aload #18
    //   1623: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1626: astore #21
    //   1628: aload #4
    //   1630: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1633: iload #14
    //   1635: aaload
    //   1636: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1639: astore #22
    //   1641: goto -> 1696
    //   1644: aload #23
    //   1646: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1649: iload #14
    //   1651: aaload
    //   1652: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1655: astore #27
    //   1657: aload #27
    //   1659: ifnull -> 1672
    //   1662: aload #27
    //   1664: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1667: astore #18
    //   1669: goto -> 1675
    //   1672: aconst_null
    //   1673: astore #18
    //   1675: aload #4
    //   1677: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1680: iload #14
    //   1682: aaload
    //   1683: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1686: astore #22
    //   1688: aload #18
    //   1690: astore #21
    //   1692: aload #27
    //   1694: astore #18
    //   1696: iload #9
    //   1698: istore #8
    //   1700: aload #18
    //   1702: ifnull -> 1715
    //   1705: iload #9
    //   1707: aload #18
    //   1709: invokevirtual getMargin : ()I
    //   1712: iadd
    //   1713: istore #8
    //   1715: iload #13
    //   1717: istore #9
    //   1719: aload #19
    //   1721: ifnull -> 1740
    //   1724: iload #13
    //   1726: aload #19
    //   1728: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1731: iload #14
    //   1733: aaload
    //   1734: invokevirtual getMargin : ()I
    //   1737: iadd
    //   1738: istore #9
    //   1740: aload #28
    //   1742: ifnull -> 1460
    //   1745: aload_0
    //   1746: ifnull -> 1460
    //   1749: aload #21
    //   1751: ifnull -> 1460
    //   1754: aload #22
    //   1756: ifnull -> 1460
    //   1759: aload #4
    //   1761: aload #20
    //   1763: if_acmpne -> 1778
    //   1766: aload #20
    //   1768: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1771: iload_3
    //   1772: aaload
    //   1773: invokevirtual getMargin : ()I
    //   1776: istore #9
    //   1778: aload #4
    //   1780: aload #24
    //   1782: if_acmpne -> 1801
    //   1785: aload #24
    //   1787: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1790: iload #14
    //   1792: aaload
    //   1793: invokevirtual getMargin : ()I
    //   1796: istore #8
    //   1798: goto -> 1801
    //   1801: iload #12
    //   1803: ifeq -> 1813
    //   1806: bipush #8
    //   1808: istore #13
    //   1810: goto -> 1816
    //   1813: iconst_5
    //   1814: istore #13
    //   1816: aload_1
    //   1817: aload #28
    //   1819: aload_0
    //   1820: iload #9
    //   1822: ldc 0.5
    //   1824: aload #21
    //   1826: aload #22
    //   1828: iload #8
    //   1830: iload #13
    //   1832: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1835: aload #4
    //   1837: invokevirtual getVisibility : ()I
    //   1840: bipush #8
    //   1842: if_icmpeq -> 1849
    //   1845: aload #4
    //   1847: astore #19
    //   1849: aload #17
    //   1851: astore #4
    //   1853: goto -> 1404
    //   1856: iload #11
    //   1858: ifeq -> 2431
    //   1861: aload #20
    //   1863: ifnull -> 2431
    //   1866: aload #4
    //   1868: getfield mWidgetsMatchCount : I
    //   1871: ifle -> 1893
    //   1874: aload #4
    //   1876: getfield mWidgetsCount : I
    //   1879: aload #4
    //   1881: getfield mWidgetsMatchCount : I
    //   1884: if_icmpne -> 1893
    //   1887: iconst_1
    //   1888: istore #8
    //   1890: goto -> 1896
    //   1893: iconst_0
    //   1894: istore #8
    //   1896: aload #20
    //   1898: astore #4
    //   1900: aload #4
    //   1902: astore #17
    //   1904: aload #4
    //   1906: ifnull -> 2271
    //   1909: aload #4
    //   1911: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1914: iload_2
    //   1915: aaload
    //   1916: astore_0
    //   1917: aload_0
    //   1918: ifnull -> 1940
    //   1921: aload_0
    //   1922: invokevirtual getVisibility : ()I
    //   1925: bipush #8
    //   1927: if_icmpne -> 1940
    //   1930: aload_0
    //   1931: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1934: iload_2
    //   1935: aaload
    //   1936: astore_0
    //   1937: goto -> 1917
    //   1940: aload #4
    //   1942: aload #20
    //   1944: if_acmpeq -> 2244
    //   1947: aload #4
    //   1949: aload #24
    //   1951: if_acmpeq -> 2244
    //   1954: aload_0
    //   1955: ifnull -> 2244
    //   1958: aload_0
    //   1959: aload #24
    //   1961: if_acmpne -> 1969
    //   1964: aconst_null
    //   1965: astore_0
    //   1966: goto -> 1969
    //   1969: aload #4
    //   1971: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1974: iload_3
    //   1975: aaload
    //   1976: astore #18
    //   1978: aload #18
    //   1980: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1983: astore #27
    //   1985: aload #18
    //   1987: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1990: ifnull -> 2003
    //   1993: aload #18
    //   1995: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1998: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2001: astore #19
    //   2003: aload #17
    //   2005: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2008: astore #19
    //   2010: iload_3
    //   2011: iconst_1
    //   2012: iadd
    //   2013: istore #14
    //   2015: aload #19
    //   2017: iload #14
    //   2019: aaload
    //   2020: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2023: astore #28
    //   2025: aload #18
    //   2027: invokevirtual getMargin : ()I
    //   2030: istore #13
    //   2032: aload #4
    //   2034: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2037: iload #14
    //   2039: aaload
    //   2040: invokevirtual getMargin : ()I
    //   2043: istore #12
    //   2045: aload_0
    //   2046: ifnull -> 2091
    //   2049: aload_0
    //   2050: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2053: iload_3
    //   2054: aaload
    //   2055: astore #19
    //   2057: aload #19
    //   2059: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2062: astore #21
    //   2064: aload #19
    //   2066: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2069: ifnull -> 2085
    //   2072: aload #19
    //   2074: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2077: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2080: astore #18
    //   2082: goto -> 2139
    //   2085: aconst_null
    //   2086: astore #18
    //   2088: goto -> 2139
    //   2091: aload #24
    //   2093: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2096: iload_3
    //   2097: aaload
    //   2098: astore #22
    //   2100: aload #22
    //   2102: ifnull -> 2115
    //   2105: aload #22
    //   2107: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2110: astore #19
    //   2112: goto -> 2118
    //   2115: aconst_null
    //   2116: astore #19
    //   2118: aload #4
    //   2120: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2123: iload #14
    //   2125: aaload
    //   2126: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2129: astore #18
    //   2131: aload #19
    //   2133: astore #21
    //   2135: aload #22
    //   2137: astore #19
    //   2139: iload #12
    //   2141: istore #9
    //   2143: aload #19
    //   2145: ifnull -> 2158
    //   2148: iload #12
    //   2150: aload #19
    //   2152: invokevirtual getMargin : ()I
    //   2155: iadd
    //   2156: istore #9
    //   2158: iload #13
    //   2160: istore #12
    //   2162: aload #17
    //   2164: ifnull -> 2183
    //   2167: iload #13
    //   2169: aload #17
    //   2171: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2174: iload #14
    //   2176: aaload
    //   2177: invokevirtual getMargin : ()I
    //   2180: iadd
    //   2181: istore #12
    //   2183: iload #8
    //   2185: ifeq -> 2195
    //   2188: bipush #8
    //   2190: istore #13
    //   2192: goto -> 2198
    //   2195: iconst_4
    //   2196: istore #13
    //   2198: aload #27
    //   2200: ifnull -> 2241
    //   2203: aload #28
    //   2205: ifnull -> 2241
    //   2208: aload #21
    //   2210: ifnull -> 2241
    //   2213: aload #18
    //   2215: ifnull -> 2241
    //   2218: aload_1
    //   2219: aload #27
    //   2221: aload #28
    //   2223: iload #12
    //   2225: ldc 0.5
    //   2227: aload #21
    //   2229: aload #18
    //   2231: iload #9
    //   2233: iload #13
    //   2235: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2238: goto -> 2241
    //   2241: goto -> 2244
    //   2244: aload #4
    //   2246: invokevirtual getVisibility : ()I
    //   2249: bipush #8
    //   2251: if_icmpeq -> 2257
    //   2254: goto -> 2261
    //   2257: aload #17
    //   2259: astore #4
    //   2261: aload #4
    //   2263: astore #17
    //   2265: aload_0
    //   2266: astore #4
    //   2268: goto -> 1904
    //   2271: aload #20
    //   2273: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2276: iload_3
    //   2277: aaload
    //   2278: astore_0
    //   2279: aload #26
    //   2281: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2284: iload_3
    //   2285: aaload
    //   2286: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2289: astore #4
    //   2291: aload #24
    //   2293: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2296: astore #17
    //   2298: iload_3
    //   2299: iconst_1
    //   2300: iadd
    //   2301: istore_2
    //   2302: aload #17
    //   2304: iload_2
    //   2305: aaload
    //   2306: astore #17
    //   2308: aload #23
    //   2310: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2313: iload_2
    //   2314: aaload
    //   2315: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2318: astore #18
    //   2320: aload #4
    //   2322: ifnull -> 2397
    //   2325: aload #20
    //   2327: aload #24
    //   2329: if_acmpeq -> 2354
    //   2332: aload_1
    //   2333: aload_0
    //   2334: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2337: aload #4
    //   2339: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2342: aload_0
    //   2343: invokevirtual getMargin : ()I
    //   2346: iconst_5
    //   2347: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2350: pop
    //   2351: goto -> 2397
    //   2354: aload #18
    //   2356: ifnull -> 2397
    //   2359: aload_1
    //   2360: aload_0
    //   2361: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2364: aload #4
    //   2366: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2369: aload_0
    //   2370: invokevirtual getMargin : ()I
    //   2373: ldc 0.5
    //   2375: aload #17
    //   2377: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2380: aload #18
    //   2382: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2385: aload #17
    //   2387: invokevirtual getMargin : ()I
    //   2390: iconst_5
    //   2391: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2394: goto -> 2397
    //   2397: aload #18
    //   2399: ifnull -> 2431
    //   2402: aload #20
    //   2404: aload #24
    //   2406: if_acmpeq -> 2431
    //   2409: aload_1
    //   2410: aload #17
    //   2412: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2415: aload #18
    //   2417: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2420: aload #17
    //   2422: invokevirtual getMargin : ()I
    //   2425: ineg
    //   2426: iconst_5
    //   2427: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2430: pop
    //   2431: iload #10
    //   2433: ifne -> 2441
    //   2436: iload #11
    //   2438: ifeq -> 2651
    //   2441: aload #20
    //   2443: ifnull -> 2651
    //   2446: aload #20
    //   2448: aload #24
    //   2450: if_acmpeq -> 2651
    //   2453: aload #20
    //   2455: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2458: iload_3
    //   2459: aaload
    //   2460: astore #17
    //   2462: aload #24
    //   2464: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2467: astore_0
    //   2468: iload_3
    //   2469: iconst_1
    //   2470: iadd
    //   2471: istore_2
    //   2472: aload_0
    //   2473: iload_2
    //   2474: aaload
    //   2475: astore #18
    //   2477: aload #17
    //   2479: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2482: ifnull -> 2498
    //   2485: aload #17
    //   2487: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2490: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2493: astore #4
    //   2495: goto -> 2501
    //   2498: aconst_null
    //   2499: astore #4
    //   2501: aload #18
    //   2503: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2506: ifnull -> 2521
    //   2509: aload #18
    //   2511: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2514: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2517: astore_0
    //   2518: goto -> 2523
    //   2521: aconst_null
    //   2522: astore_0
    //   2523: aload #23
    //   2525: aload #24
    //   2527: if_acmpeq -> 2562
    //   2530: aload #23
    //   2532: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2535: iload_2
    //   2536: aaload
    //   2537: astore #19
    //   2539: aload #25
    //   2541: astore_0
    //   2542: aload #19
    //   2544: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2547: ifnull -> 2559
    //   2550: aload #19
    //   2552: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2555: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2558: astore_0
    //   2559: goto -> 2562
    //   2562: aload #20
    //   2564: aload #24
    //   2566: if_acmpne -> 2587
    //   2569: aload #20
    //   2571: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2574: iload_3
    //   2575: aaload
    //   2576: astore #17
    //   2578: aload #20
    //   2580: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2583: iload_2
    //   2584: aaload
    //   2585: astore #18
    //   2587: aload #4
    //   2589: ifnull -> 2651
    //   2592: aload_0
    //   2593: ifnull -> 2651
    //   2596: aload #17
    //   2598: invokevirtual getMargin : ()I
    //   2601: istore_3
    //   2602: aload #24
    //   2604: ifnonnull -> 2614
    //   2607: aload #23
    //   2609: astore #19
    //   2611: goto -> 2618
    //   2614: aload #24
    //   2616: astore #19
    //   2618: aload #19
    //   2620: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2623: iload_2
    //   2624: aaload
    //   2625: invokevirtual getMargin : ()I
    //   2628: istore_2
    //   2629: aload_1
    //   2630: aload #17
    //   2632: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2635: aload #4
    //   2637: iload_3
    //   2638: ldc 0.5
    //   2640: aload_0
    //   2641: aload #18
    //   2643: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2646: iload_2
    //   2647: iconst_5
    //   2648: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2651: return
  }
  
  public static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, ArrayList<ConstraintWidget> paramArrayList, int paramInt) {
    int i;
    byte b;
    ChainHead[] arrayOfChainHead;
    int j = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b = 0;
    } else {
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
      b = 2;
    } 
    while (j < i) {
      ChainHead chainHead = arrayOfChainHead[j];
      chainHead.define();
      if (paramArrayList == null || (paramArrayList != null && paramArrayList.contains(chainHead.mFirst)))
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b, chainHead); 
      j++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */