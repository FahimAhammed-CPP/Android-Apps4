package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.Iterator;

public class ChainRun extends WidgetRun {
  private int chainStyle;
  
  ArrayList<WidgetRun> widgets = new ArrayList<WidgetRun>();
  
  public ChainRun(ConstraintWidget paramConstraintWidget, int paramInt) {
    super(paramConstraintWidget);
    this.orientation = paramInt;
    build();
  }
  
  private void build() {
    int i;
    ConstraintWidget constraintWidget2 = this.widget;
    ConstraintWidget constraintWidget1;
    for (constraintWidget1 = constraintWidget2.getPreviousChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget) {
      ConstraintWidget constraintWidget = constraintWidget1.getPreviousChainMember(this.orientation);
      constraintWidget2 = constraintWidget1;
    } 
    this.widget = constraintWidget2;
    this.widgets.add(constraintWidget2.getRun(this.orientation));
    for (constraintWidget1 = constraintWidget2.getNextChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget1.getNextChainMember(this.orientation))
      this.widgets.add(constraintWidget1.getRun(this.orientation)); 
    for (WidgetRun widgetRun : this.widgets) {
      if (this.orientation == 0) {
        widgetRun.widget.horizontalChainRun = this;
        continue;
      } 
      if (this.orientation == 1)
        widgetRun.widget.verticalChainRun = this; 
    } 
    if (this.orientation == 0 && ((ConstraintWidgetContainer)this.widget.getParent()).isRtl()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && this.widgets.size() > 1) {
      ArrayList<WidgetRun> arrayList = this.widgets;
      this.widget = ((WidgetRun)arrayList.get(arrayList.size() - 1)).widget;
    } 
    if (this.orientation == 0) {
      i = this.widget.getHorizontalChainStyle();
    } else {
      i = this.widget.getVerticalChainStyle();
    } 
    this.chainStyle = i;
  }
  
  private ConstraintWidget getFirstVisibleWidget() {
    for (int i = 0; i < this.widgets.size(); i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  private ConstraintWidget getLastVisibleWidget() {
    for (int i = this.widgets.size() - 1; i >= 0; i--) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  void apply() {
    DependencyNode dependencyNode;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).apply(); 
    int i = this.widgets.size();
    if (i < 1)
      return; 
    ConstraintWidget constraintWidget2 = ((WidgetRun)this.widgets.get(0)).widget;
    ConstraintWidget constraintWidget1 = ((WidgetRun)this.widgets.get(i - 1)).widget;
    if (this.orientation == 0) {
      ConstraintAnchor constraintAnchor2 = constraintWidget2.mLeft;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mRight;
      DependencyNode dependencyNode1 = getTarget(constraintAnchor2, 0);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget = getFirstVisibleWidget();
      if (constraintWidget != null)
        i = constraintWidget.mLeft.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.start, dependencyNode1, i); 
      dependencyNode = getTarget(constraintAnchor1, 0);
      i = constraintAnchor1.getMargin();
      constraintWidget1 = getLastVisibleWidget();
      if (constraintWidget1 != null)
        i = constraintWidget1.mRight.getMargin(); 
      if (dependencyNode != null)
        addTarget(this.end, dependencyNode, -i); 
    } else {
      ConstraintAnchor constraintAnchor2 = ((ConstraintWidget)dependencyNode).mTop;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mBottom;
      DependencyNode dependencyNode2 = getTarget(constraintAnchor2, 1);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget4 = getFirstVisibleWidget();
      if (constraintWidget4 != null)
        i = constraintWidget4.mTop.getMargin(); 
      if (dependencyNode2 != null)
        addTarget(this.start, dependencyNode2, i); 
      DependencyNode dependencyNode1 = getTarget(constraintAnchor1, 1);
      i = constraintAnchor1.getMargin();
      ConstraintWidget constraintWidget3 = getLastVisibleWidget();
      if (constraintWidget3 != null)
        i = constraintWidget3.mBottom.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.end, dependencyNode1, -i); 
    } 
    this.start.updateDelegate = this;
    this.end.updateDelegate = this;
  }
  
  public void applyToWidget() {
    for (int i = 0; i < this.widgets.size(); i++)
      ((WidgetRun)this.widgets.get(i)).applyToWidget(); 
  }
  
  void clear() {
    this.runGroup = null;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
  }
  
  public long getWrapDimension() {
    int j = this.widgets.size();
    long l = 0L;
    for (int i = 0; i < j; i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      l = l + widgetRun.start.margin + widgetRun.getWrapDimension() + widgetRun.end.margin;
    } 
    return l;
  }
  
  void reset() {
    this.start.resolved = false;
    this.end.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    int j = this.widgets.size();
    for (int i = 0; i < j; i++) {
      if (!((WidgetRun)this.widgets.get(i)).supportsWrapComputation())
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ChainRun ");
    if (this.orientation == 0) {
      str = "horizontal : ";
    } else {
      str = "vertical : ";
    } 
    stringBuilder.append(str);
    String str = stringBuilder.toString();
    for (WidgetRun widgetRun : this.widgets) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append("<");
      str = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(widgetRun);
      str = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append("> ");
      str = stringBuilder1.toString();
    } 
    return str;
  }
  
  public void update(Dependency paramDependency) {
    // Byte code:
    //   0: aload_0
    //   1: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   4: getfield resolved : Z
    //   7: ifeq -> 2536
    //   10: aload_0
    //   11: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   14: getfield resolved : Z
    //   17: ifne -> 21
    //   20: return
    //   21: aload_0
    //   22: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   25: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   28: astore_1
    //   29: aload_1
    //   30: ifnull -> 52
    //   33: aload_1
    //   34: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   37: ifeq -> 52
    //   40: aload_1
    //   41: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   44: invokevirtual isRtl : ()Z
    //   47: istore #21
    //   49: goto -> 55
    //   52: iconst_0
    //   53: istore #21
    //   55: aload_0
    //   56: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   59: getfield value : I
    //   62: aload_0
    //   63: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   66: getfield value : I
    //   69: isub
    //   70: istore #20
    //   72: aload_0
    //   73: getfield widgets : Ljava/util/ArrayList;
    //   76: invokevirtual size : ()I
    //   79: istore #19
    //   81: iconst_0
    //   82: istore #5
    //   84: iconst_m1
    //   85: istore #6
    //   87: iload #5
    //   89: iload #19
    //   91: if_icmpge -> 130
    //   94: iload #5
    //   96: istore #14
    //   98: aload_0
    //   99: getfield widgets : Ljava/util/ArrayList;
    //   102: iload #5
    //   104: invokevirtual get : (I)Ljava/lang/Object;
    //   107: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   110: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   113: invokevirtual getVisibility : ()I
    //   116: bipush #8
    //   118: if_icmpne -> 133
    //   121: iload #5
    //   123: iconst_1
    //   124: iadd
    //   125: istore #5
    //   127: goto -> 84
    //   130: iconst_m1
    //   131: istore #14
    //   133: iload #19
    //   135: iconst_1
    //   136: isub
    //   137: istore #18
    //   139: iload #18
    //   141: istore #5
    //   143: iload #6
    //   145: istore #15
    //   147: iload #5
    //   149: iflt -> 188
    //   152: aload_0
    //   153: getfield widgets : Ljava/util/ArrayList;
    //   156: iload #5
    //   158: invokevirtual get : (I)Ljava/lang/Object;
    //   161: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   164: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   167: invokevirtual getVisibility : ()I
    //   170: bipush #8
    //   172: if_icmpne -> 184
    //   175: iload #5
    //   177: iconst_1
    //   178: isub
    //   179: istore #5
    //   181: goto -> 143
    //   184: iload #5
    //   186: istore #15
    //   188: iconst_0
    //   189: istore #9
    //   191: iload #9
    //   193: iconst_2
    //   194: if_icmpge -> 658
    //   197: iconst_0
    //   198: istore #10
    //   200: iconst_0
    //   201: istore #7
    //   203: iconst_0
    //   204: istore #5
    //   206: iconst_0
    //   207: istore #8
    //   209: fconst_0
    //   210: fstore_2
    //   211: iload #10
    //   213: iload #19
    //   215: if_icmpge -> 623
    //   218: aload_0
    //   219: getfield widgets : Ljava/util/ArrayList;
    //   222: iload #10
    //   224: invokevirtual get : (I)Ljava/lang/Object;
    //   227: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   230: astore_1
    //   231: aload_1
    //   232: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   235: invokevirtual getVisibility : ()I
    //   238: bipush #8
    //   240: if_icmpne -> 254
    //   243: iload #7
    //   245: istore #6
    //   247: iload #5
    //   249: istore #11
    //   251: goto -> 606
    //   254: iload #8
    //   256: iconst_1
    //   257: iadd
    //   258: istore #16
    //   260: iload #7
    //   262: istore #6
    //   264: iload #10
    //   266: ifle -> 292
    //   269: iload #7
    //   271: istore #6
    //   273: iload #10
    //   275: iload #14
    //   277: if_icmplt -> 292
    //   280: iload #7
    //   282: aload_1
    //   283: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   286: getfield margin : I
    //   289: iadd
    //   290: istore #6
    //   292: aload_1
    //   293: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   296: getfield value : I
    //   299: istore #11
    //   301: aload_1
    //   302: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   305: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   308: if_acmpeq -> 317
    //   311: iconst_1
    //   312: istore #8
    //   314: goto -> 320
    //   317: iconst_0
    //   318: istore #8
    //   320: iload #8
    //   322: ifeq -> 398
    //   325: aload_0
    //   326: getfield orientation : I
    //   329: ifne -> 349
    //   332: aload_1
    //   333: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   336: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   339: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   342: getfield resolved : Z
    //   345: ifne -> 349
    //   348: return
    //   349: iload #8
    //   351: istore #13
    //   353: iload #11
    //   355: istore #12
    //   357: iload #5
    //   359: istore #7
    //   361: aload_0
    //   362: getfield orientation : I
    //   365: iconst_1
    //   366: if_icmpne -> 474
    //   369: iload #8
    //   371: istore #13
    //   373: iload #11
    //   375: istore #12
    //   377: iload #5
    //   379: istore #7
    //   381: aload_1
    //   382: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   385: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   388: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   391: getfield resolved : Z
    //   394: ifne -> 474
    //   397: return
    //   398: aload_1
    //   399: getfield matchConstraintsType : I
    //   402: iconst_1
    //   403: if_icmpne -> 437
    //   406: iload #9
    //   408: ifne -> 437
    //   411: aload_1
    //   412: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   415: getfield wrapValue : I
    //   418: istore #7
    //   420: iload #5
    //   422: iconst_1
    //   423: iadd
    //   424: istore #8
    //   426: iload #7
    //   428: istore #5
    //   430: iload #8
    //   432: istore #7
    //   434: goto -> 467
    //   437: iload #8
    //   439: istore #13
    //   441: iload #11
    //   443: istore #12
    //   445: iload #5
    //   447: istore #7
    //   449: aload_1
    //   450: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   453: getfield resolved : Z
    //   456: ifeq -> 474
    //   459: iload #5
    //   461: istore #7
    //   463: iload #11
    //   465: istore #5
    //   467: iconst_1
    //   468: istore #13
    //   470: iload #5
    //   472: istore #12
    //   474: iload #13
    //   476: ifne -> 532
    //   479: iload #7
    //   481: iconst_1
    //   482: iadd
    //   483: istore #8
    //   485: aload_1
    //   486: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   489: getfield mWeight : [F
    //   492: aload_0
    //   493: getfield orientation : I
    //   496: faload
    //   497: fstore #4
    //   499: iload #6
    //   501: istore #5
    //   503: iload #8
    //   505: istore #7
    //   507: fload_2
    //   508: fstore_3
    //   509: fload #4
    //   511: fconst_0
    //   512: fcmpl
    //   513: iflt -> 541
    //   516: fload_2
    //   517: fload #4
    //   519: fadd
    //   520: fstore_3
    //   521: iload #6
    //   523: istore #5
    //   525: iload #8
    //   527: istore #7
    //   529: goto -> 541
    //   532: iload #6
    //   534: iload #12
    //   536: iadd
    //   537: istore #5
    //   539: fload_2
    //   540: fstore_3
    //   541: iload #5
    //   543: istore #6
    //   545: iload #7
    //   547: istore #11
    //   549: iload #16
    //   551: istore #8
    //   553: fload_3
    //   554: fstore_2
    //   555: iload #10
    //   557: iload #18
    //   559: if_icmpge -> 606
    //   562: iload #5
    //   564: istore #6
    //   566: iload #7
    //   568: istore #11
    //   570: iload #16
    //   572: istore #8
    //   574: fload_3
    //   575: fstore_2
    //   576: iload #10
    //   578: iload #15
    //   580: if_icmpge -> 606
    //   583: iload #5
    //   585: aload_1
    //   586: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   589: getfield margin : I
    //   592: ineg
    //   593: iadd
    //   594: istore #6
    //   596: fload_3
    //   597: fstore_2
    //   598: iload #16
    //   600: istore #8
    //   602: iload #7
    //   604: istore #11
    //   606: iload #10
    //   608: iconst_1
    //   609: iadd
    //   610: istore #10
    //   612: iload #6
    //   614: istore #7
    //   616: iload #11
    //   618: istore #5
    //   620: goto -> 211
    //   623: iload #7
    //   625: iload #20
    //   627: if_icmplt -> 647
    //   630: iload #5
    //   632: ifne -> 638
    //   635: goto -> 647
    //   638: iload #9
    //   640: iconst_1
    //   641: iadd
    //   642: istore #9
    //   644: goto -> 191
    //   647: iload #8
    //   649: istore #16
    //   651: iload #5
    //   653: istore #6
    //   655: goto -> 669
    //   658: iconst_0
    //   659: istore #16
    //   661: iconst_0
    //   662: istore #7
    //   664: iconst_0
    //   665: istore #6
    //   667: fconst_0
    //   668: fstore_2
    //   669: aload_0
    //   670: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   673: getfield value : I
    //   676: istore #8
    //   678: iload #21
    //   680: ifeq -> 692
    //   683: aload_0
    //   684: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   687: getfield value : I
    //   690: istore #8
    //   692: iload #8
    //   694: istore #5
    //   696: iload #7
    //   698: iload #20
    //   700: if_icmple -> 745
    //   703: iload #21
    //   705: ifeq -> 728
    //   708: iload #8
    //   710: iload #7
    //   712: iload #20
    //   714: isub
    //   715: i2f
    //   716: fconst_2
    //   717: fdiv
    //   718: ldc 0.5
    //   720: fadd
    //   721: f2i
    //   722: iadd
    //   723: istore #5
    //   725: goto -> 745
    //   728: iload #8
    //   730: iload #7
    //   732: iload #20
    //   734: isub
    //   735: i2f
    //   736: fconst_2
    //   737: fdiv
    //   738: ldc 0.5
    //   740: fadd
    //   741: f2i
    //   742: isub
    //   743: istore #5
    //   745: iload #6
    //   747: ifle -> 1309
    //   750: iload #20
    //   752: iload #7
    //   754: isub
    //   755: i2f
    //   756: fstore_3
    //   757: fload_3
    //   758: iload #6
    //   760: i2f
    //   761: fdiv
    //   762: ldc 0.5
    //   764: fadd
    //   765: f2i
    //   766: istore #11
    //   768: iconst_0
    //   769: istore #17
    //   771: iconst_0
    //   772: istore #8
    //   774: iload #7
    //   776: istore #9
    //   778: iload #5
    //   780: istore #10
    //   782: iload #17
    //   784: iload #19
    //   786: if_icmpge -> 1109
    //   789: aload_0
    //   790: getfield widgets : Ljava/util/ArrayList;
    //   793: iload #17
    //   795: invokevirtual get : (I)Ljava/lang/Object;
    //   798: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   801: astore_1
    //   802: aload_1
    //   803: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   806: invokevirtual getVisibility : ()I
    //   809: bipush #8
    //   811: if_icmpne -> 817
    //   814: goto -> 1092
    //   817: aload_1
    //   818: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   821: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   824: if_acmpne -> 1092
    //   827: aload_1
    //   828: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   831: getfield resolved : Z
    //   834: ifne -> 1092
    //   837: fload_2
    //   838: fconst_0
    //   839: fcmpl
    //   840: ifle -> 868
    //   843: aload_1
    //   844: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   847: getfield mWeight : [F
    //   850: aload_0
    //   851: getfield orientation : I
    //   854: faload
    //   855: fload_3
    //   856: fmul
    //   857: fload_2
    //   858: fdiv
    //   859: ldc 0.5
    //   861: fadd
    //   862: f2i
    //   863: istore #5
    //   865: goto -> 872
    //   868: iload #11
    //   870: istore #5
    //   872: aload_0
    //   873: getfield orientation : I
    //   876: ifne -> 981
    //   879: aload_1
    //   880: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   883: getfield mMatchConstraintMaxWidth : I
    //   886: istore #13
    //   888: aload_1
    //   889: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   892: getfield mMatchConstraintMinWidth : I
    //   895: istore #12
    //   897: aload_1
    //   898: getfield matchConstraintsType : I
    //   901: iconst_1
    //   902: if_icmpne -> 922
    //   905: iload #5
    //   907: aload_1
    //   908: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   911: getfield wrapValue : I
    //   914: invokestatic min : (II)I
    //   917: istore #7
    //   919: goto -> 926
    //   922: iload #5
    //   924: istore #7
    //   926: iload #12
    //   928: iload #7
    //   930: invokestatic max : (II)I
    //   933: istore #7
    //   935: iload #7
    //   937: istore #12
    //   939: iload #13
    //   941: ifle -> 953
    //   944: iload #13
    //   946: iload #7
    //   948: invokestatic min : (II)I
    //   951: istore #12
    //   953: iload #5
    //   955: istore #13
    //   957: iload #8
    //   959: istore #7
    //   961: iload #12
    //   963: iload #5
    //   965: if_icmpeq -> 1080
    //   968: iload #8
    //   970: iconst_1
    //   971: iadd
    //   972: istore #7
    //   974: iload #12
    //   976: istore #13
    //   978: goto -> 1080
    //   981: aload_1
    //   982: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   985: getfield mMatchConstraintMaxHeight : I
    //   988: istore #13
    //   990: aload_1
    //   991: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   994: getfield mMatchConstraintMinHeight : I
    //   997: istore #12
    //   999: aload_1
    //   1000: getfield matchConstraintsType : I
    //   1003: iconst_1
    //   1004: if_icmpne -> 1024
    //   1007: iload #5
    //   1009: aload_1
    //   1010: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1013: getfield wrapValue : I
    //   1016: invokestatic min : (II)I
    //   1019: istore #7
    //   1021: goto -> 1028
    //   1024: iload #5
    //   1026: istore #7
    //   1028: iload #12
    //   1030: iload #7
    //   1032: invokestatic max : (II)I
    //   1035: istore #7
    //   1037: iload #7
    //   1039: istore #12
    //   1041: iload #13
    //   1043: ifle -> 1055
    //   1046: iload #13
    //   1048: iload #7
    //   1050: invokestatic min : (II)I
    //   1053: istore #12
    //   1055: iload #5
    //   1057: istore #13
    //   1059: iload #8
    //   1061: istore #7
    //   1063: iload #12
    //   1065: iload #5
    //   1067: if_icmpeq -> 1080
    //   1070: iload #8
    //   1072: iconst_1
    //   1073: iadd
    //   1074: istore #7
    //   1076: iload #12
    //   1078: istore #13
    //   1080: aload_1
    //   1081: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1084: iload #13
    //   1086: invokevirtual resolve : (I)V
    //   1089: goto -> 1096
    //   1092: iload #8
    //   1094: istore #7
    //   1096: iload #17
    //   1098: iconst_1
    //   1099: iadd
    //   1100: istore #17
    //   1102: iload #7
    //   1104: istore #8
    //   1106: goto -> 782
    //   1109: iload #8
    //   1111: ifle -> 1257
    //   1114: iload #6
    //   1116: iload #8
    //   1118: isub
    //   1119: istore #9
    //   1121: iconst_0
    //   1122: istore #6
    //   1124: iconst_0
    //   1125: istore #5
    //   1127: iload #6
    //   1129: iload #19
    //   1131: if_icmpge -> 1250
    //   1134: aload_0
    //   1135: getfield widgets : Ljava/util/ArrayList;
    //   1138: iload #6
    //   1140: invokevirtual get : (I)Ljava/lang/Object;
    //   1143: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1146: astore_1
    //   1147: aload_1
    //   1148: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1151: invokevirtual getVisibility : ()I
    //   1154: bipush #8
    //   1156: if_icmpne -> 1162
    //   1159: goto -> 1241
    //   1162: iload #5
    //   1164: istore #7
    //   1166: iload #6
    //   1168: ifle -> 1194
    //   1171: iload #5
    //   1173: istore #7
    //   1175: iload #6
    //   1177: iload #14
    //   1179: if_icmplt -> 1194
    //   1182: iload #5
    //   1184: aload_1
    //   1185: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1188: getfield margin : I
    //   1191: iadd
    //   1192: istore #7
    //   1194: iload #7
    //   1196: aload_1
    //   1197: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1200: getfield value : I
    //   1203: iadd
    //   1204: istore #7
    //   1206: iload #7
    //   1208: istore #5
    //   1210: iload #6
    //   1212: iload #18
    //   1214: if_icmpge -> 1241
    //   1217: iload #7
    //   1219: istore #5
    //   1221: iload #6
    //   1223: iload #15
    //   1225: if_icmpge -> 1241
    //   1228: iload #7
    //   1230: aload_1
    //   1231: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1234: getfield margin : I
    //   1237: ineg
    //   1238: iadd
    //   1239: istore #5
    //   1241: iload #6
    //   1243: iconst_1
    //   1244: iadd
    //   1245: istore #6
    //   1247: goto -> 1127
    //   1250: iload #9
    //   1252: istore #6
    //   1254: goto -> 1261
    //   1257: iload #9
    //   1259: istore #5
    //   1261: aload_0
    //   1262: getfield chainStyle : I
    //   1265: iconst_2
    //   1266: if_icmpne -> 1294
    //   1269: iload #8
    //   1271: ifne -> 1294
    //   1274: aload_0
    //   1275: iconst_0
    //   1276: putfield chainStyle : I
    //   1279: iload #5
    //   1281: istore #7
    //   1283: iload #6
    //   1285: istore #9
    //   1287: iload #10
    //   1289: istore #5
    //   1291: goto -> 1313
    //   1294: iload #5
    //   1296: istore #7
    //   1298: iload #6
    //   1300: istore #9
    //   1302: iload #10
    //   1304: istore #5
    //   1306: goto -> 1313
    //   1309: iload #6
    //   1311: istore #9
    //   1313: iload #7
    //   1315: iload #20
    //   1317: if_icmple -> 1325
    //   1320: aload_0
    //   1321: iconst_2
    //   1322: putfield chainStyle : I
    //   1325: iload #16
    //   1327: ifle -> 1347
    //   1330: iload #9
    //   1332: ifne -> 1347
    //   1335: iload #14
    //   1337: iload #15
    //   1339: if_icmpne -> 1347
    //   1342: aload_0
    //   1343: iconst_2
    //   1344: putfield chainStyle : I
    //   1347: aload_0
    //   1348: getfield chainStyle : I
    //   1351: istore #6
    //   1353: iload #6
    //   1355: iconst_1
    //   1356: if_icmpne -> 1773
    //   1359: iload #16
    //   1361: iconst_1
    //   1362: if_icmple -> 1380
    //   1365: iload #20
    //   1367: iload #7
    //   1369: isub
    //   1370: iload #16
    //   1372: iconst_1
    //   1373: isub
    //   1374: idiv
    //   1375: istore #6
    //   1377: goto -> 1401
    //   1380: iload #16
    //   1382: iconst_1
    //   1383: if_icmpne -> 1398
    //   1386: iload #20
    //   1388: iload #7
    //   1390: isub
    //   1391: iconst_2
    //   1392: idiv
    //   1393: istore #6
    //   1395: goto -> 1401
    //   1398: iconst_0
    //   1399: istore #6
    //   1401: iload #6
    //   1403: istore #8
    //   1405: iload #9
    //   1407: ifle -> 1413
    //   1410: iconst_0
    //   1411: istore #8
    //   1413: iconst_0
    //   1414: istore #6
    //   1416: iload #5
    //   1418: istore #7
    //   1420: iload #6
    //   1422: iload #19
    //   1424: if_icmpge -> 2536
    //   1427: iload #21
    //   1429: ifeq -> 1444
    //   1432: iload #19
    //   1434: iload #6
    //   1436: iconst_1
    //   1437: iadd
    //   1438: isub
    //   1439: istore #5
    //   1441: goto -> 1448
    //   1444: iload #6
    //   1446: istore #5
    //   1448: aload_0
    //   1449: getfield widgets : Ljava/util/ArrayList;
    //   1452: iload #5
    //   1454: invokevirtual get : (I)Ljava/lang/Object;
    //   1457: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1460: astore_1
    //   1461: aload_1
    //   1462: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1465: invokevirtual getVisibility : ()I
    //   1468: bipush #8
    //   1470: if_icmpne -> 1498
    //   1473: aload_1
    //   1474: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1477: iload #7
    //   1479: invokevirtual resolve : (I)V
    //   1482: aload_1
    //   1483: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1486: iload #7
    //   1488: invokevirtual resolve : (I)V
    //   1491: iload #7
    //   1493: istore #5
    //   1495: goto -> 1760
    //   1498: iload #7
    //   1500: istore #5
    //   1502: iload #6
    //   1504: ifle -> 1529
    //   1507: iload #21
    //   1509: ifeq -> 1522
    //   1512: iload #7
    //   1514: iload #8
    //   1516: isub
    //   1517: istore #5
    //   1519: goto -> 1529
    //   1522: iload #7
    //   1524: iload #8
    //   1526: iadd
    //   1527: istore #5
    //   1529: iload #5
    //   1531: istore #7
    //   1533: iload #6
    //   1535: ifle -> 1581
    //   1538: iload #5
    //   1540: istore #7
    //   1542: iload #6
    //   1544: iload #14
    //   1546: if_icmplt -> 1581
    //   1549: iload #21
    //   1551: ifeq -> 1569
    //   1554: iload #5
    //   1556: aload_1
    //   1557: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1560: getfield margin : I
    //   1563: isub
    //   1564: istore #7
    //   1566: goto -> 1581
    //   1569: iload #5
    //   1571: aload_1
    //   1572: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1575: getfield margin : I
    //   1578: iadd
    //   1579: istore #7
    //   1581: iload #21
    //   1583: ifeq -> 1598
    //   1586: aload_1
    //   1587: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1590: iload #7
    //   1592: invokevirtual resolve : (I)V
    //   1595: goto -> 1607
    //   1598: aload_1
    //   1599: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1602: iload #7
    //   1604: invokevirtual resolve : (I)V
    //   1607: aload_1
    //   1608: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1611: getfield value : I
    //   1614: istore #9
    //   1616: iload #9
    //   1618: istore #5
    //   1620: aload_1
    //   1621: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1624: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1627: if_acmpne -> 1651
    //   1630: iload #9
    //   1632: istore #5
    //   1634: aload_1
    //   1635: getfield matchConstraintsType : I
    //   1638: iconst_1
    //   1639: if_icmpne -> 1651
    //   1642: aload_1
    //   1643: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1646: getfield wrapValue : I
    //   1649: istore #5
    //   1651: iload #21
    //   1653: ifeq -> 1666
    //   1656: iload #7
    //   1658: iload #5
    //   1660: isub
    //   1661: istore #7
    //   1663: goto -> 1673
    //   1666: iload #7
    //   1668: iload #5
    //   1670: iadd
    //   1671: istore #7
    //   1673: iload #21
    //   1675: ifeq -> 1690
    //   1678: aload_1
    //   1679: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1682: iload #7
    //   1684: invokevirtual resolve : (I)V
    //   1687: goto -> 1699
    //   1690: aload_1
    //   1691: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1694: iload #7
    //   1696: invokevirtual resolve : (I)V
    //   1699: aload_1
    //   1700: iconst_1
    //   1701: putfield resolved : Z
    //   1704: iload #7
    //   1706: istore #5
    //   1708: iload #6
    //   1710: iload #18
    //   1712: if_icmpge -> 1760
    //   1715: iload #7
    //   1717: istore #5
    //   1719: iload #6
    //   1721: iload #15
    //   1723: if_icmpge -> 1760
    //   1726: iload #21
    //   1728: ifeq -> 1747
    //   1731: iload #7
    //   1733: aload_1
    //   1734: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1737: getfield margin : I
    //   1740: ineg
    //   1741: isub
    //   1742: istore #5
    //   1744: goto -> 1760
    //   1747: iload #7
    //   1749: aload_1
    //   1750: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1753: getfield margin : I
    //   1756: ineg
    //   1757: iadd
    //   1758: istore #5
    //   1760: iload #6
    //   1762: iconst_1
    //   1763: iadd
    //   1764: istore #6
    //   1766: iload #5
    //   1768: istore #7
    //   1770: goto -> 1420
    //   1773: iload #6
    //   1775: ifne -> 2137
    //   1778: iload #20
    //   1780: iload #7
    //   1782: isub
    //   1783: iload #16
    //   1785: iconst_1
    //   1786: iadd
    //   1787: idiv
    //   1788: istore #8
    //   1790: iload #9
    //   1792: ifle -> 1798
    //   1795: iconst_0
    //   1796: istore #8
    //   1798: iconst_0
    //   1799: istore #6
    //   1801: iload #6
    //   1803: iload #19
    //   1805: if_icmpge -> 2536
    //   1808: iload #21
    //   1810: ifeq -> 1825
    //   1813: iload #19
    //   1815: iload #6
    //   1817: iconst_1
    //   1818: iadd
    //   1819: isub
    //   1820: istore #7
    //   1822: goto -> 1829
    //   1825: iload #6
    //   1827: istore #7
    //   1829: aload_0
    //   1830: getfield widgets : Ljava/util/ArrayList;
    //   1833: iload #7
    //   1835: invokevirtual get : (I)Ljava/lang/Object;
    //   1838: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1841: astore_1
    //   1842: aload_1
    //   1843: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1846: invokevirtual getVisibility : ()I
    //   1849: bipush #8
    //   1851: if_icmpne -> 1875
    //   1854: aload_1
    //   1855: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1858: iload #5
    //   1860: invokevirtual resolve : (I)V
    //   1863: aload_1
    //   1864: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1867: iload #5
    //   1869: invokevirtual resolve : (I)V
    //   1872: goto -> 2128
    //   1875: iload #21
    //   1877: ifeq -> 1890
    //   1880: iload #5
    //   1882: iload #8
    //   1884: isub
    //   1885: istore #7
    //   1887: goto -> 1897
    //   1890: iload #5
    //   1892: iload #8
    //   1894: iadd
    //   1895: istore #7
    //   1897: iload #7
    //   1899: istore #5
    //   1901: iload #6
    //   1903: ifle -> 1949
    //   1906: iload #7
    //   1908: istore #5
    //   1910: iload #6
    //   1912: iload #14
    //   1914: if_icmplt -> 1949
    //   1917: iload #21
    //   1919: ifeq -> 1937
    //   1922: iload #7
    //   1924: aload_1
    //   1925: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1928: getfield margin : I
    //   1931: isub
    //   1932: istore #5
    //   1934: goto -> 1949
    //   1937: iload #7
    //   1939: aload_1
    //   1940: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1943: getfield margin : I
    //   1946: iadd
    //   1947: istore #5
    //   1949: iload #21
    //   1951: ifeq -> 1966
    //   1954: aload_1
    //   1955: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1958: iload #5
    //   1960: invokevirtual resolve : (I)V
    //   1963: goto -> 1975
    //   1966: aload_1
    //   1967: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1970: iload #5
    //   1972: invokevirtual resolve : (I)V
    //   1975: aload_1
    //   1976: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1979: getfield value : I
    //   1982: istore #9
    //   1984: iload #9
    //   1986: istore #7
    //   1988: aload_1
    //   1989: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1992: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1995: if_acmpne -> 2024
    //   1998: iload #9
    //   2000: istore #7
    //   2002: aload_1
    //   2003: getfield matchConstraintsType : I
    //   2006: iconst_1
    //   2007: if_icmpne -> 2024
    //   2010: iload #9
    //   2012: aload_1
    //   2013: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   2016: getfield wrapValue : I
    //   2019: invokestatic min : (II)I
    //   2022: istore #7
    //   2024: iload #21
    //   2026: ifeq -> 2039
    //   2029: iload #5
    //   2031: iload #7
    //   2033: isub
    //   2034: istore #7
    //   2036: goto -> 2046
    //   2039: iload #5
    //   2041: iload #7
    //   2043: iadd
    //   2044: istore #7
    //   2046: iload #21
    //   2048: ifeq -> 2063
    //   2051: aload_1
    //   2052: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2055: iload #7
    //   2057: invokevirtual resolve : (I)V
    //   2060: goto -> 2072
    //   2063: aload_1
    //   2064: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2067: iload #7
    //   2069: invokevirtual resolve : (I)V
    //   2072: iload #7
    //   2074: istore #5
    //   2076: iload #6
    //   2078: iload #18
    //   2080: if_icmpge -> 2128
    //   2083: iload #7
    //   2085: istore #5
    //   2087: iload #6
    //   2089: iload #15
    //   2091: if_icmpge -> 2128
    //   2094: iload #21
    //   2096: ifeq -> 2115
    //   2099: iload #7
    //   2101: aload_1
    //   2102: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2105: getfield margin : I
    //   2108: ineg
    //   2109: isub
    //   2110: istore #5
    //   2112: goto -> 2128
    //   2115: iload #7
    //   2117: aload_1
    //   2118: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2121: getfield margin : I
    //   2124: ineg
    //   2125: iadd
    //   2126: istore #5
    //   2128: iload #6
    //   2130: iconst_1
    //   2131: iadd
    //   2132: istore #6
    //   2134: goto -> 1801
    //   2137: iload #6
    //   2139: iconst_2
    //   2140: if_icmpne -> 2536
    //   2143: aload_0
    //   2144: getfield orientation : I
    //   2147: ifne -> 2161
    //   2150: aload_0
    //   2151: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2154: invokevirtual getHorizontalBiasPercent : ()F
    //   2157: fstore_2
    //   2158: goto -> 2169
    //   2161: aload_0
    //   2162: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2165: invokevirtual getVerticalBiasPercent : ()F
    //   2168: fstore_2
    //   2169: fload_2
    //   2170: fstore_3
    //   2171: iload #21
    //   2173: ifeq -> 2180
    //   2176: fconst_1
    //   2177: fload_2
    //   2178: fsub
    //   2179: fstore_3
    //   2180: iload #20
    //   2182: iload #7
    //   2184: isub
    //   2185: i2f
    //   2186: fload_3
    //   2187: fmul
    //   2188: ldc 0.5
    //   2190: fadd
    //   2191: f2i
    //   2192: istore #6
    //   2194: iload #6
    //   2196: iflt -> 2204
    //   2199: iload #9
    //   2201: ifle -> 2207
    //   2204: iconst_0
    //   2205: istore #6
    //   2207: iload #21
    //   2209: ifeq -> 2222
    //   2212: iload #5
    //   2214: iload #6
    //   2216: isub
    //   2217: istore #5
    //   2219: goto -> 2229
    //   2222: iload #5
    //   2224: iload #6
    //   2226: iadd
    //   2227: istore #5
    //   2229: iconst_0
    //   2230: istore #6
    //   2232: iload #6
    //   2234: iload #19
    //   2236: if_icmpge -> 2536
    //   2239: iload #21
    //   2241: ifeq -> 2256
    //   2244: iload #19
    //   2246: iload #6
    //   2248: iconst_1
    //   2249: iadd
    //   2250: isub
    //   2251: istore #7
    //   2253: goto -> 2260
    //   2256: iload #6
    //   2258: istore #7
    //   2260: aload_0
    //   2261: getfield widgets : Ljava/util/ArrayList;
    //   2264: iload #7
    //   2266: invokevirtual get : (I)Ljava/lang/Object;
    //   2269: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   2272: astore_1
    //   2273: aload_1
    //   2274: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2277: invokevirtual getVisibility : ()I
    //   2280: bipush #8
    //   2282: if_icmpne -> 2306
    //   2285: aload_1
    //   2286: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2289: iload #5
    //   2291: invokevirtual resolve : (I)V
    //   2294: aload_1
    //   2295: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2298: iload #5
    //   2300: invokevirtual resolve : (I)V
    //   2303: goto -> 2527
    //   2306: iload #5
    //   2308: istore #7
    //   2310: iload #6
    //   2312: ifle -> 2358
    //   2315: iload #5
    //   2317: istore #7
    //   2319: iload #6
    //   2321: iload #14
    //   2323: if_icmplt -> 2358
    //   2326: iload #21
    //   2328: ifeq -> 2346
    //   2331: iload #5
    //   2333: aload_1
    //   2334: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2337: getfield margin : I
    //   2340: isub
    //   2341: istore #7
    //   2343: goto -> 2358
    //   2346: iload #5
    //   2348: aload_1
    //   2349: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2352: getfield margin : I
    //   2355: iadd
    //   2356: istore #7
    //   2358: iload #21
    //   2360: ifeq -> 2375
    //   2363: aload_1
    //   2364: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2367: iload #7
    //   2369: invokevirtual resolve : (I)V
    //   2372: goto -> 2384
    //   2375: aload_1
    //   2376: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2379: iload #7
    //   2381: invokevirtual resolve : (I)V
    //   2384: aload_1
    //   2385: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   2388: getfield value : I
    //   2391: istore #5
    //   2393: aload_1
    //   2394: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2397: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2400: if_acmpne -> 2423
    //   2403: aload_1
    //   2404: getfield matchConstraintsType : I
    //   2407: iconst_1
    //   2408: if_icmpne -> 2423
    //   2411: aload_1
    //   2412: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   2415: getfield wrapValue : I
    //   2418: istore #5
    //   2420: goto -> 2423
    //   2423: iload #21
    //   2425: ifeq -> 2438
    //   2428: iload #7
    //   2430: iload #5
    //   2432: isub
    //   2433: istore #7
    //   2435: goto -> 2445
    //   2438: iload #7
    //   2440: iload #5
    //   2442: iadd
    //   2443: istore #7
    //   2445: iload #21
    //   2447: ifeq -> 2462
    //   2450: aload_1
    //   2451: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2454: iload #7
    //   2456: invokevirtual resolve : (I)V
    //   2459: goto -> 2471
    //   2462: aload_1
    //   2463: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2466: iload #7
    //   2468: invokevirtual resolve : (I)V
    //   2471: iload #7
    //   2473: istore #5
    //   2475: iload #6
    //   2477: iload #18
    //   2479: if_icmpge -> 2527
    //   2482: iload #7
    //   2484: istore #5
    //   2486: iload #6
    //   2488: iload #15
    //   2490: if_icmpge -> 2527
    //   2493: iload #21
    //   2495: ifeq -> 2514
    //   2498: iload #7
    //   2500: aload_1
    //   2501: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2504: getfield margin : I
    //   2507: ineg
    //   2508: isub
    //   2509: istore #5
    //   2511: goto -> 2527
    //   2514: iload #7
    //   2516: aload_1
    //   2517: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2520: getfield margin : I
    //   2523: ineg
    //   2524: iadd
    //   2525: istore #5
    //   2527: iload #6
    //   2529: iconst_1
    //   2530: iadd
    //   2531: istore #6
    //   2533: goto -> 2232
    //   2536: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\ChainRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */