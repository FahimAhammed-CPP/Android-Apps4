package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.HelperWidget;
import java.util.ArrayList;

public class Grouping {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_GROUPING = false;
  
  public static WidgetGroup findDependents(ConstraintWidget paramConstraintWidget, int paramInt, ArrayList<WidgetGroup> paramArrayList, WidgetGroup paramWidgetGroup) {
    int i;
    WidgetGroup widgetGroup;
    if (paramInt == 0) {
      i = paramConstraintWidget.horizontalGroup;
    } else {
      i = paramConstraintWidget.verticalGroup;
    } 
    boolean bool = false;
    if (i != -1 && (paramWidgetGroup == null || i != paramWidgetGroup.id)) {
      int j = 0;
      while (true) {
        widgetGroup = paramWidgetGroup;
        if (j < paramArrayList.size()) {
          widgetGroup = paramArrayList.get(j);
          if (widgetGroup.getId() == i) {
            if (paramWidgetGroup != null) {
              paramWidgetGroup.moveTo(paramInt, widgetGroup);
              paramArrayList.remove(paramWidgetGroup);
            } 
            break;
          } 
          j++;
          continue;
        } 
        break;
      } 
    } else {
      widgetGroup = paramWidgetGroup;
      if (i != -1)
        return paramWidgetGroup; 
    } 
    paramWidgetGroup = widgetGroup;
    if (widgetGroup == null) {
      paramWidgetGroup = widgetGroup;
      if (paramConstraintWidget instanceof HelperWidget) {
        int j = ((HelperWidget)paramConstraintWidget).findGroupInDependents(paramInt);
        paramWidgetGroup = widgetGroup;
        if (j != -1) {
          i = 0;
          while (true) {
            paramWidgetGroup = widgetGroup;
            if (i < paramArrayList.size()) {
              paramWidgetGroup = paramArrayList.get(i);
              if (paramWidgetGroup.getId() == j)
                break; 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      widgetGroup = paramWidgetGroup;
      if (paramWidgetGroup == null)
        widgetGroup = new WidgetGroup(paramInt); 
      paramArrayList.add(widgetGroup);
      paramWidgetGroup = widgetGroup;
    } 
    if (paramWidgetGroup.add(paramConstraintWidget)) {
      if (paramConstraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)paramConstraintWidget;
        ConstraintAnchor constraintAnchor = guideline.getAnchor();
        i = bool;
        if (guideline.getOrientation() == 0)
          i = 1; 
        constraintAnchor.findDependents(i, paramArrayList, paramWidgetGroup);
      } 
      if (paramInt == 0) {
        paramConstraintWidget.horizontalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mLeft.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mRight.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } else {
        paramConstraintWidget.verticalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mTop.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBaseline.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBottom.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } 
      paramConstraintWidget.mCenter.findDependents(paramInt, paramArrayList, paramWidgetGroup);
    } 
    return paramWidgetGroup;
  }
  
  private static WidgetGroup findGroup(ArrayList<WidgetGroup> paramArrayList, int paramInt) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      WidgetGroup widgetGroup = paramArrayList.get(i);
      if (paramInt == widgetGroup.id)
        return widgetGroup; 
    } 
    return null;
  }
  
  public static boolean simpleSolvingPass(ConstraintWidgetContainer paramConstraintWidgetContainer, BasicMeasure.Measurer paramMeasurer) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildren : ()Ljava/util/ArrayList;
    //   4: astore #16
    //   6: aload #16
    //   8: invokevirtual size : ()I
    //   11: istore_3
    //   12: iconst_0
    //   13: istore_2
    //   14: iload_2
    //   15: iload_3
    //   16: if_icmpge -> 73
    //   19: aload #16
    //   21: iload_2
    //   22: invokevirtual get : (I)Ljava/lang/Object;
    //   25: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   28: astore #5
    //   30: aload_0
    //   31: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   34: aload_0
    //   35: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   38: aload #5
    //   40: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   43: aload #5
    //   45: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   48: invokestatic validInGroup : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   51: ifne -> 56
    //   54: iconst_0
    //   55: ireturn
    //   56: aload #5
    //   58: instanceof androidx/constraintlayout/solver/widgets/Flow
    //   61: ifeq -> 66
    //   64: iconst_0
    //   65: ireturn
    //   66: iload_2
    //   67: iconst_1
    //   68: iadd
    //   69: istore_2
    //   70: goto -> 14
    //   73: aload_0
    //   74: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   77: ifnull -> 98
    //   80: aload_0
    //   81: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   84: astore #5
    //   86: aload #5
    //   88: aload #5
    //   90: getfield grouping : J
    //   93: lconst_1
    //   94: ladd
    //   95: putfield grouping : J
    //   98: iconst_0
    //   99: istore_2
    //   100: aconst_null
    //   101: astore #11
    //   103: aconst_null
    //   104: astore #5
    //   106: aconst_null
    //   107: astore #7
    //   109: aconst_null
    //   110: astore #6
    //   112: aconst_null
    //   113: astore #9
    //   115: aconst_null
    //   116: astore #8
    //   118: iload_2
    //   119: iload_3
    //   120: if_icmpge -> 677
    //   123: aload #16
    //   125: iload_2
    //   126: invokevirtual get : (I)Ljava/lang/Object;
    //   129: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   132: astore #17
    //   134: aload_0
    //   135: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   138: aload_0
    //   139: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   142: aload #17
    //   144: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   147: aload #17
    //   149: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   152: invokestatic validInGroup : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   155: ifne -> 175
    //   158: aload #17
    //   160: aload_1
    //   161: aload_0
    //   162: getfield mMeasure : Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;
    //   165: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   168: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   171: pop
    //   172: goto -> 175
    //   175: aload #17
    //   177: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   180: istore #4
    //   182: aload #11
    //   184: astore #13
    //   186: aload #7
    //   188: astore #12
    //   190: iload #4
    //   192: ifeq -> 291
    //   195: aload #17
    //   197: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   200: astore #14
    //   202: aload #7
    //   204: astore #10
    //   206: aload #14
    //   208: invokevirtual getOrientation : ()I
    //   211: ifne -> 240
    //   214: aload #7
    //   216: astore #10
    //   218: aload #7
    //   220: ifnonnull -> 232
    //   223: new java/util/ArrayList
    //   226: dup
    //   227: invokespecial <init> : ()V
    //   230: astore #10
    //   232: aload #10
    //   234: aload #14
    //   236: invokevirtual add : (Ljava/lang/Object;)Z
    //   239: pop
    //   240: aload #11
    //   242: astore #13
    //   244: aload #10
    //   246: astore #12
    //   248: aload #14
    //   250: invokevirtual getOrientation : ()I
    //   253: iconst_1
    //   254: if_icmpne -> 291
    //   257: aload #11
    //   259: astore #7
    //   261: aload #11
    //   263: ifnonnull -> 275
    //   266: new java/util/ArrayList
    //   269: dup
    //   270: invokespecial <init> : ()V
    //   273: astore #7
    //   275: aload #7
    //   277: aload #14
    //   279: invokevirtual add : (Ljava/lang/Object;)Z
    //   282: pop
    //   283: aload #10
    //   285: astore #12
    //   287: aload #7
    //   289: astore #13
    //   291: aload #5
    //   293: astore #7
    //   295: aload #6
    //   297: astore #10
    //   299: aload #17
    //   301: instanceof androidx/constraintlayout/solver/widgets/HelperWidget
    //   304: ifeq -> 469
    //   307: aload #17
    //   309: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   312: ifeq -> 410
    //   315: aload #17
    //   317: checkcast androidx/constraintlayout/solver/widgets/Barrier
    //   320: astore #14
    //   322: aload #5
    //   324: astore #11
    //   326: aload #14
    //   328: invokevirtual getOrientation : ()I
    //   331: ifne -> 360
    //   334: aload #5
    //   336: astore #11
    //   338: aload #5
    //   340: ifnonnull -> 352
    //   343: new java/util/ArrayList
    //   346: dup
    //   347: invokespecial <init> : ()V
    //   350: astore #11
    //   352: aload #11
    //   354: aload #14
    //   356: invokevirtual add : (Ljava/lang/Object;)Z
    //   359: pop
    //   360: aload #11
    //   362: astore #7
    //   364: aload #6
    //   366: astore #10
    //   368: aload #14
    //   370: invokevirtual getOrientation : ()I
    //   373: iconst_1
    //   374: if_icmpne -> 469
    //   377: aload #6
    //   379: astore #10
    //   381: aload #6
    //   383: ifnonnull -> 395
    //   386: new java/util/ArrayList
    //   389: dup
    //   390: invokespecial <init> : ()V
    //   393: astore #10
    //   395: aload #10
    //   397: aload #14
    //   399: invokevirtual add : (Ljava/lang/Object;)Z
    //   402: pop
    //   403: aload #11
    //   405: astore #7
    //   407: goto -> 469
    //   410: aload #17
    //   412: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   415: astore #11
    //   417: aload #5
    //   419: astore #7
    //   421: aload #5
    //   423: ifnonnull -> 435
    //   426: new java/util/ArrayList
    //   429: dup
    //   430: invokespecial <init> : ()V
    //   433: astore #7
    //   435: aload #7
    //   437: aload #11
    //   439: invokevirtual add : (Ljava/lang/Object;)Z
    //   442: pop
    //   443: aload #6
    //   445: astore #10
    //   447: aload #6
    //   449: ifnonnull -> 461
    //   452: new java/util/ArrayList
    //   455: dup
    //   456: invokespecial <init> : ()V
    //   459: astore #10
    //   461: aload #10
    //   463: aload #11
    //   465: invokevirtual add : (Ljava/lang/Object;)Z
    //   468: pop
    //   469: aload #9
    //   471: astore #14
    //   473: aload #17
    //   475: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   478: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   481: ifnonnull -> 550
    //   484: aload #9
    //   486: astore #14
    //   488: aload #17
    //   490: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   493: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   496: ifnonnull -> 550
    //   499: aload #9
    //   501: astore #14
    //   503: iload #4
    //   505: ifne -> 550
    //   508: aload #9
    //   510: astore #14
    //   512: aload #17
    //   514: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   517: ifne -> 550
    //   520: aload #9
    //   522: astore #5
    //   524: aload #9
    //   526: ifnonnull -> 538
    //   529: new java/util/ArrayList
    //   532: dup
    //   533: invokespecial <init> : ()V
    //   536: astore #5
    //   538: aload #5
    //   540: aload #17
    //   542: invokevirtual add : (Ljava/lang/Object;)Z
    //   545: pop
    //   546: aload #5
    //   548: astore #14
    //   550: aload #8
    //   552: astore #15
    //   554: aload #17
    //   556: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   559: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   562: ifnonnull -> 646
    //   565: aload #8
    //   567: astore #15
    //   569: aload #17
    //   571: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   574: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   577: ifnonnull -> 646
    //   580: aload #8
    //   582: astore #15
    //   584: aload #17
    //   586: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   589: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   592: ifnonnull -> 646
    //   595: aload #8
    //   597: astore #15
    //   599: iload #4
    //   601: ifne -> 646
    //   604: aload #8
    //   606: astore #15
    //   608: aload #17
    //   610: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   613: ifne -> 646
    //   616: aload #8
    //   618: astore #5
    //   620: aload #8
    //   622: ifnonnull -> 634
    //   625: new java/util/ArrayList
    //   628: dup
    //   629: invokespecial <init> : ()V
    //   632: astore #5
    //   634: aload #5
    //   636: aload #17
    //   638: invokevirtual add : (Ljava/lang/Object;)Z
    //   641: pop
    //   642: aload #5
    //   644: astore #15
    //   646: iload_2
    //   647: iconst_1
    //   648: iadd
    //   649: istore_2
    //   650: aload #13
    //   652: astore #11
    //   654: aload #7
    //   656: astore #5
    //   658: aload #12
    //   660: astore #7
    //   662: aload #10
    //   664: astore #6
    //   666: aload #14
    //   668: astore #9
    //   670: aload #15
    //   672: astore #8
    //   674: goto -> 118
    //   677: new java/util/ArrayList
    //   680: dup
    //   681: invokespecial <init> : ()V
    //   684: astore #10
    //   686: aload #11
    //   688: ifnull -> 726
    //   691: aload #11
    //   693: invokevirtual iterator : ()Ljava/util/Iterator;
    //   696: astore_1
    //   697: aload_1
    //   698: invokeinterface hasNext : ()Z
    //   703: ifeq -> 726
    //   706: aload_1
    //   707: invokeinterface next : ()Ljava/lang/Object;
    //   712: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   715: iconst_0
    //   716: aload #10
    //   718: aconst_null
    //   719: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   722: pop
    //   723: goto -> 697
    //   726: aload #5
    //   728: ifnull -> 788
    //   731: aload #5
    //   733: invokevirtual iterator : ()Ljava/util/Iterator;
    //   736: astore_1
    //   737: aload_1
    //   738: invokeinterface hasNext : ()Z
    //   743: ifeq -> 788
    //   746: aload_1
    //   747: invokeinterface next : ()Ljava/lang/Object;
    //   752: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   755: astore #5
    //   757: aload #5
    //   759: iconst_0
    //   760: aload #10
    //   762: aconst_null
    //   763: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   766: astore #11
    //   768: aload #5
    //   770: aload #10
    //   772: iconst_0
    //   773: aload #11
    //   775: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   778: aload #11
    //   780: aload #10
    //   782: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   785: goto -> 737
    //   788: aload_0
    //   789: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   792: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   795: astore_1
    //   796: aload_1
    //   797: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   800: ifnull -> 843
    //   803: aload_1
    //   804: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   807: invokevirtual iterator : ()Ljava/util/Iterator;
    //   810: astore_1
    //   811: aload_1
    //   812: invokeinterface hasNext : ()Z
    //   817: ifeq -> 843
    //   820: aload_1
    //   821: invokeinterface next : ()Ljava/lang/Object;
    //   826: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   829: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   832: iconst_0
    //   833: aload #10
    //   835: aconst_null
    //   836: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   839: pop
    //   840: goto -> 811
    //   843: aload_0
    //   844: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   847: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   850: astore_1
    //   851: aload_1
    //   852: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   855: ifnull -> 898
    //   858: aload_1
    //   859: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   862: invokevirtual iterator : ()Ljava/util/Iterator;
    //   865: astore_1
    //   866: aload_1
    //   867: invokeinterface hasNext : ()Z
    //   872: ifeq -> 898
    //   875: aload_1
    //   876: invokeinterface next : ()Ljava/lang/Object;
    //   881: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   884: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   887: iconst_0
    //   888: aload #10
    //   890: aconst_null
    //   891: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   894: pop
    //   895: goto -> 866
    //   898: aload_0
    //   899: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   902: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   905: astore_1
    //   906: aload_1
    //   907: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   910: ifnull -> 953
    //   913: aload_1
    //   914: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   917: invokevirtual iterator : ()Ljava/util/Iterator;
    //   920: astore_1
    //   921: aload_1
    //   922: invokeinterface hasNext : ()Z
    //   927: ifeq -> 953
    //   930: aload_1
    //   931: invokeinterface next : ()Ljava/lang/Object;
    //   936: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   939: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   942: iconst_0
    //   943: aload #10
    //   945: aconst_null
    //   946: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   949: pop
    //   950: goto -> 921
    //   953: aload #9
    //   955: ifnull -> 993
    //   958: aload #9
    //   960: invokevirtual iterator : ()Ljava/util/Iterator;
    //   963: astore_1
    //   964: aload_1
    //   965: invokeinterface hasNext : ()Z
    //   970: ifeq -> 993
    //   973: aload_1
    //   974: invokeinterface next : ()Ljava/lang/Object;
    //   979: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   982: iconst_0
    //   983: aload #10
    //   985: aconst_null
    //   986: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   989: pop
    //   990: goto -> 964
    //   993: aload #7
    //   995: ifnull -> 1033
    //   998: aload #7
    //   1000: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1003: astore_1
    //   1004: aload_1
    //   1005: invokeinterface hasNext : ()Z
    //   1010: ifeq -> 1033
    //   1013: aload_1
    //   1014: invokeinterface next : ()Ljava/lang/Object;
    //   1019: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   1022: iconst_1
    //   1023: aload #10
    //   1025: aconst_null
    //   1026: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1029: pop
    //   1030: goto -> 1004
    //   1033: aload #6
    //   1035: ifnull -> 1095
    //   1038: aload #6
    //   1040: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1043: astore_1
    //   1044: aload_1
    //   1045: invokeinterface hasNext : ()Z
    //   1050: ifeq -> 1095
    //   1053: aload_1
    //   1054: invokeinterface next : ()Ljava/lang/Object;
    //   1059: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   1062: astore #5
    //   1064: aload #5
    //   1066: iconst_1
    //   1067: aload #10
    //   1069: aconst_null
    //   1070: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1073: astore #6
    //   1075: aload #5
    //   1077: aload #10
    //   1079: iconst_1
    //   1080: aload #6
    //   1082: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   1085: aload #6
    //   1087: aload #10
    //   1089: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   1092: goto -> 1044
    //   1095: aload_0
    //   1096: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1099: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1102: astore_1
    //   1103: aload_1
    //   1104: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1107: ifnull -> 1150
    //   1110: aload_1
    //   1111: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1114: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1117: astore_1
    //   1118: aload_1
    //   1119: invokeinterface hasNext : ()Z
    //   1124: ifeq -> 1150
    //   1127: aload_1
    //   1128: invokeinterface next : ()Ljava/lang/Object;
    //   1133: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1136: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1139: iconst_1
    //   1140: aload #10
    //   1142: aconst_null
    //   1143: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1146: pop
    //   1147: goto -> 1118
    //   1150: aload_0
    //   1151: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1154: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1157: astore_1
    //   1158: aload_1
    //   1159: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1162: ifnull -> 1205
    //   1165: aload_1
    //   1166: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1169: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1172: astore_1
    //   1173: aload_1
    //   1174: invokeinterface hasNext : ()Z
    //   1179: ifeq -> 1205
    //   1182: aload_1
    //   1183: invokeinterface next : ()Ljava/lang/Object;
    //   1188: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1191: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1194: iconst_1
    //   1195: aload #10
    //   1197: aconst_null
    //   1198: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1201: pop
    //   1202: goto -> 1173
    //   1205: aload_0
    //   1206: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1209: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1212: astore_1
    //   1213: aload_1
    //   1214: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1217: ifnull -> 1260
    //   1220: aload_1
    //   1221: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1224: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1227: astore_1
    //   1228: aload_1
    //   1229: invokeinterface hasNext : ()Z
    //   1234: ifeq -> 1260
    //   1237: aload_1
    //   1238: invokeinterface next : ()Ljava/lang/Object;
    //   1243: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1246: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1249: iconst_1
    //   1250: aload #10
    //   1252: aconst_null
    //   1253: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1256: pop
    //   1257: goto -> 1228
    //   1260: aload_0
    //   1261: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1264: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1267: astore_1
    //   1268: aload_1
    //   1269: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1272: ifnull -> 1315
    //   1275: aload_1
    //   1276: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1279: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1282: astore_1
    //   1283: aload_1
    //   1284: invokeinterface hasNext : ()Z
    //   1289: ifeq -> 1315
    //   1292: aload_1
    //   1293: invokeinterface next : ()Ljava/lang/Object;
    //   1298: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1301: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1304: iconst_1
    //   1305: aload #10
    //   1307: aconst_null
    //   1308: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1311: pop
    //   1312: goto -> 1283
    //   1315: aload #8
    //   1317: ifnull -> 1355
    //   1320: aload #8
    //   1322: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1325: astore_1
    //   1326: aload_1
    //   1327: invokeinterface hasNext : ()Z
    //   1332: ifeq -> 1355
    //   1335: aload_1
    //   1336: invokeinterface next : ()Ljava/lang/Object;
    //   1341: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1344: iconst_1
    //   1345: aload #10
    //   1347: aconst_null
    //   1348: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1351: pop
    //   1352: goto -> 1326
    //   1355: iconst_0
    //   1356: istore_2
    //   1357: iload_2
    //   1358: iload_3
    //   1359: if_icmpge -> 1440
    //   1362: aload #16
    //   1364: iload_2
    //   1365: invokevirtual get : (I)Ljava/lang/Object;
    //   1368: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1371: astore #5
    //   1373: aload #5
    //   1375: invokevirtual oppositeDimensionsTied : ()Z
    //   1378: ifeq -> 1433
    //   1381: aload #10
    //   1383: aload #5
    //   1385: getfield horizontalGroup : I
    //   1388: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1391: astore_1
    //   1392: aload #10
    //   1394: aload #5
    //   1396: getfield verticalGroup : I
    //   1399: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1402: astore #5
    //   1404: aload_1
    //   1405: ifnull -> 1433
    //   1408: aload #5
    //   1410: ifnull -> 1433
    //   1413: aload_1
    //   1414: iconst_0
    //   1415: aload #5
    //   1417: invokevirtual moveTo : (ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   1420: aload #5
    //   1422: iconst_2
    //   1423: invokevirtual setOrientation : (I)V
    //   1426: aload #10
    //   1428: aload_1
    //   1429: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1432: pop
    //   1433: iload_2
    //   1434: iconst_1
    //   1435: iadd
    //   1436: istore_2
    //   1437: goto -> 1357
    //   1440: aload #10
    //   1442: invokevirtual size : ()I
    //   1445: iconst_1
    //   1446: if_icmpgt -> 1451
    //   1449: iconst_0
    //   1450: ireturn
    //   1451: aload_0
    //   1452: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1455: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1458: if_acmpne -> 1563
    //   1461: aload #10
    //   1463: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1466: astore #6
    //   1468: aconst_null
    //   1469: astore_1
    //   1470: iconst_0
    //   1471: istore_2
    //   1472: aload #6
    //   1474: invokeinterface hasNext : ()Z
    //   1479: ifeq -> 1536
    //   1482: aload #6
    //   1484: invokeinterface next : ()Ljava/lang/Object;
    //   1489: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetGroup
    //   1492: astore #5
    //   1494: aload #5
    //   1496: invokevirtual getOrientation : ()I
    //   1499: iconst_1
    //   1500: if_icmpne -> 1506
    //   1503: goto -> 1472
    //   1506: aload #5
    //   1508: iconst_0
    //   1509: invokevirtual setAuthoritative : (Z)V
    //   1512: aload #5
    //   1514: aload_0
    //   1515: invokevirtual getSystem : ()Landroidx/constraintlayout/solver/LinearSystem;
    //   1518: iconst_0
    //   1519: invokevirtual measureWrap : (Landroidx/constraintlayout/solver/LinearSystem;I)I
    //   1522: istore_3
    //   1523: iload_3
    //   1524: iload_2
    //   1525: if_icmple -> 1472
    //   1528: aload #5
    //   1530: astore_1
    //   1531: iload_3
    //   1532: istore_2
    //   1533: goto -> 1472
    //   1536: aload_1
    //   1537: ifnull -> 1563
    //   1540: aload_0
    //   1541: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1544: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1547: aload_0
    //   1548: iload_2
    //   1549: invokevirtual setWidth : (I)V
    //   1552: aload_1
    //   1553: iconst_1
    //   1554: invokevirtual setAuthoritative : (Z)V
    //   1557: aload_1
    //   1558: astore #5
    //   1560: goto -> 1566
    //   1563: aconst_null
    //   1564: astore #5
    //   1566: aload_0
    //   1567: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1570: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1573: if_acmpne -> 1674
    //   1576: aload #10
    //   1578: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1581: astore #7
    //   1583: aconst_null
    //   1584: astore_1
    //   1585: iconst_0
    //   1586: istore_2
    //   1587: aload #7
    //   1589: invokeinterface hasNext : ()Z
    //   1594: ifeq -> 1650
    //   1597: aload #7
    //   1599: invokeinterface next : ()Ljava/lang/Object;
    //   1604: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetGroup
    //   1607: astore #6
    //   1609: aload #6
    //   1611: invokevirtual getOrientation : ()I
    //   1614: ifne -> 1620
    //   1617: goto -> 1587
    //   1620: aload #6
    //   1622: iconst_0
    //   1623: invokevirtual setAuthoritative : (Z)V
    //   1626: aload #6
    //   1628: aload_0
    //   1629: invokevirtual getSystem : ()Landroidx/constraintlayout/solver/LinearSystem;
    //   1632: iconst_1
    //   1633: invokevirtual measureWrap : (Landroidx/constraintlayout/solver/LinearSystem;I)I
    //   1636: istore_3
    //   1637: iload_3
    //   1638: iload_2
    //   1639: if_icmple -> 1587
    //   1642: aload #6
    //   1644: astore_1
    //   1645: iload_3
    //   1646: istore_2
    //   1647: goto -> 1587
    //   1650: aload_1
    //   1651: ifnull -> 1674
    //   1654: aload_0
    //   1655: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1658: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1661: aload_0
    //   1662: iload_2
    //   1663: invokevirtual setHeight : (I)V
    //   1666: aload_1
    //   1667: iconst_1
    //   1668: invokevirtual setAuthoritative : (Z)V
    //   1671: goto -> 1676
    //   1674: aconst_null
    //   1675: astore_1
    //   1676: aload #5
    //   1678: ifnonnull -> 1690
    //   1681: aload_1
    //   1682: ifnull -> 1688
    //   1685: goto -> 1690
    //   1688: iconst_0
    //   1689: ireturn
    //   1690: iconst_1
    //   1691: ireturn
  }
  
  public static boolean validInGroup(ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour3, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour4) {
    boolean bool1;
    boolean bool2;
    if (paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.FIXED || paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && paramDimensionBehaviour1 != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.FIXED || paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && paramDimensionBehaviour2 != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    return !bool1 ? (bool2) : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\Grouping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */