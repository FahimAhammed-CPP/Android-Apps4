package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.ChainRun;
import androidx.constraintlayout.solver.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtuaLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    // Byte code:
    //   0: aload_1
    //   1: aload #10
    //   3: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   6: astore #39
    //   8: aload_1
    //   9: aload #11
    //   11: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   14: astore #38
    //   16: aload_1
    //   17: aload #10
    //   19: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   22: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   25: astore #41
    //   27: aload_1
    //   28: aload #11
    //   30: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   36: astore #36
    //   38: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   41: ifnull -> 61
    //   44: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   47: astore #37
    //   49: aload #37
    //   51: aload #37
    //   53: getfield nonresolvedWidgets : J
    //   56: lconst_1
    //   57: ladd
    //   58: putfield nonresolvedWidgets : J
    //   61: aload #10
    //   63: invokevirtual isConnected : ()Z
    //   66: istore #33
    //   68: aload #11
    //   70: invokevirtual isConnected : ()Z
    //   73: istore #34
    //   75: aload_0
    //   76: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   79: invokevirtual isConnected : ()Z
    //   82: istore #35
    //   84: iload #33
    //   86: ifeq -> 95
    //   89: iconst_1
    //   90: istore #29
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #29
    //   98: iload #29
    //   100: istore #28
    //   102: iload #34
    //   104: ifeq -> 113
    //   107: iload #29
    //   109: iconst_1
    //   110: iadd
    //   111: istore #28
    //   113: iload #28
    //   115: istore #30
    //   117: iload #35
    //   119: ifeq -> 128
    //   122: iload #28
    //   124: iconst_1
    //   125: iadd
    //   126: istore #30
    //   128: iload #17
    //   130: ifeq -> 139
    //   133: iconst_3
    //   134: istore #22
    //   136: goto -> 139
    //   139: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
    //   142: aload #8
    //   144: invokevirtual ordinal : ()I
    //   147: iaload
    //   148: istore #28
    //   150: iload #28
    //   152: iconst_1
    //   153: if_icmpeq -> 174
    //   156: iload #28
    //   158: iconst_2
    //   159: if_icmpeq -> 174
    //   162: iload #28
    //   164: iconst_3
    //   165: if_icmpeq -> 174
    //   168: iload #28
    //   170: iconst_4
    //   171: if_icmpeq -> 180
    //   174: iconst_0
    //   175: istore #28
    //   177: goto -> 189
    //   180: iload #22
    //   182: iconst_4
    //   183: if_icmpeq -> 174
    //   186: iconst_1
    //   187: istore #28
    //   189: iload #22
    //   191: istore #29
    //   193: aload_0
    //   194: getfield mVisibility : I
    //   197: bipush #8
    //   199: if_icmpne -> 211
    //   202: iconst_0
    //   203: istore #13
    //   205: iconst_0
    //   206: istore #22
    //   208: goto -> 215
    //   211: iload #28
    //   213: istore #22
    //   215: iload #27
    //   217: ifeq -> 275
    //   220: iload #33
    //   222: ifne -> 246
    //   225: iload #34
    //   227: ifne -> 246
    //   230: iload #35
    //   232: ifne -> 246
    //   235: aload_1
    //   236: aload #39
    //   238: iload #12
    //   240: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   243: goto -> 275
    //   246: iload #33
    //   248: ifeq -> 275
    //   251: iload #34
    //   253: ifne -> 275
    //   256: aload_1
    //   257: aload #39
    //   259: aload #41
    //   261: aload #10
    //   263: invokevirtual getMargin : ()I
    //   266: bipush #8
    //   268: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   271: pop
    //   272: goto -> 275
    //   275: aload #36
    //   277: astore #8
    //   279: iload #22
    //   281: ifne -> 367
    //   284: iload #9
    //   286: ifeq -> 339
    //   289: aload_1
    //   290: aload #38
    //   292: aload #39
    //   294: iconst_0
    //   295: iconst_3
    //   296: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   299: pop
    //   300: iload #14
    //   302: ifle -> 317
    //   305: aload_1
    //   306: aload #38
    //   308: aload #39
    //   310: iload #14
    //   312: bipush #8
    //   314: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   317: iload #15
    //   319: ldc 2147483647
    //   321: if_icmpge -> 352
    //   324: aload_1
    //   325: aload #38
    //   327: aload #39
    //   329: iload #15
    //   331: bipush #8
    //   333: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   336: goto -> 352
    //   339: aload_1
    //   340: aload #38
    //   342: aload #39
    //   344: iload #13
    //   346: bipush #8
    //   348: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   351: pop
    //   352: iload #25
    //   354: istore #12
    //   356: iload #24
    //   358: istore #25
    //   360: iload #22
    //   362: istore #28
    //   364: goto -> 825
    //   367: iload #30
    //   369: iconst_2
    //   370: if_icmpeq -> 443
    //   373: iload #17
    //   375: ifne -> 443
    //   378: iload #29
    //   380: iconst_1
    //   381: if_icmpeq -> 389
    //   384: iload #29
    //   386: ifne -> 443
    //   389: iload #24
    //   391: iload #13
    //   393: invokestatic max : (II)I
    //   396: istore #13
    //   398: iload #13
    //   400: istore #12
    //   402: iload #25
    //   404: ifle -> 416
    //   407: iload #25
    //   409: iload #13
    //   411: invokestatic min : (II)I
    //   414: istore #12
    //   416: aload_1
    //   417: aload #38
    //   419: aload #39
    //   421: iload #12
    //   423: bipush #8
    //   425: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   428: pop
    //   429: iconst_0
    //   430: istore #28
    //   432: iload #25
    //   434: istore #12
    //   436: iload #24
    //   438: istore #25
    //   440: goto -> 825
    //   443: iload #24
    //   445: istore #12
    //   447: iload #24
    //   449: bipush #-2
    //   451: if_icmpne -> 458
    //   454: iload #13
    //   456: istore #12
    //   458: iload #25
    //   460: bipush #-2
    //   462: if_icmpne -> 472
    //   465: iload #13
    //   467: istore #15
    //   469: goto -> 476
    //   472: iload #25
    //   474: istore #15
    //   476: iload #13
    //   478: istore #24
    //   480: iload #13
    //   482: ifle -> 498
    //   485: iload #13
    //   487: istore #24
    //   489: iload #29
    //   491: iconst_1
    //   492: if_icmpeq -> 498
    //   495: iconst_0
    //   496: istore #24
    //   498: iload #24
    //   500: istore #13
    //   502: iload #12
    //   504: ifle -> 528
    //   507: aload_1
    //   508: aload #38
    //   510: aload #39
    //   512: iload #12
    //   514: bipush #8
    //   516: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   519: iload #24
    //   521: iload #12
    //   523: invokestatic max : (II)I
    //   526: istore #13
    //   528: iload #15
    //   530: ifle -> 584
    //   533: iload_3
    //   534: ifeq -> 549
    //   537: iload #29
    //   539: iconst_1
    //   540: if_icmpne -> 549
    //   543: iconst_0
    //   544: istore #24
    //   546: goto -> 552
    //   549: iconst_1
    //   550: istore #24
    //   552: iload #24
    //   554: ifeq -> 572
    //   557: aload_1
    //   558: aload #38
    //   560: aload #39
    //   562: iload #15
    //   564: bipush #8
    //   566: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   569: goto -> 572
    //   572: iload #13
    //   574: iload #15
    //   576: invokestatic min : (II)I
    //   579: istore #13
    //   581: goto -> 584
    //   584: iload #29
    //   586: iconst_1
    //   587: if_icmpne -> 677
    //   590: iload_3
    //   591: ifeq -> 610
    //   594: aload_1
    //   595: aload #38
    //   597: aload #39
    //   599: iload #13
    //   601: bipush #8
    //   603: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   606: pop
    //   607: goto -> 666
    //   610: iload #19
    //   612: ifeq -> 642
    //   615: aload_1
    //   616: aload #38
    //   618: aload #39
    //   620: iload #13
    //   622: iconst_5
    //   623: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   626: pop
    //   627: aload_1
    //   628: aload #38
    //   630: aload #39
    //   632: iload #13
    //   634: bipush #8
    //   636: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   639: goto -> 666
    //   642: aload_1
    //   643: aload #38
    //   645: aload #39
    //   647: iload #13
    //   649: iconst_5
    //   650: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   653: pop
    //   654: aload_1
    //   655: aload #38
    //   657: aload #39
    //   659: iload #13
    //   661: bipush #8
    //   663: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   666: iload #12
    //   668: istore #24
    //   670: iload #15
    //   672: istore #12
    //   674: goto -> 356
    //   677: iload #29
    //   679: iconst_2
    //   680: if_icmpne -> 810
    //   683: aload #10
    //   685: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   688: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   691: if_acmpeq -> 743
    //   694: aload #10
    //   696: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   699: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   702: if_acmpne -> 708
    //   705: goto -> 743
    //   708: aload_1
    //   709: aload_0
    //   710: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   713: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   716: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   719: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   722: astore #36
    //   724: aload_1
    //   725: aload_0
    //   726: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   729: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   732: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   735: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   738: astore #37
    //   740: goto -> 775
    //   743: aload_1
    //   744: aload_0
    //   745: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   748: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   751: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   754: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   757: astore #36
    //   759: aload_1
    //   760: aload_0
    //   761: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   764: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   767: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   770: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   773: astore #37
    //   775: aload_1
    //   776: aload_1
    //   777: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   780: aload #38
    //   782: aload #39
    //   784: aload #37
    //   786: aload #36
    //   788: fload #26
    //   790: invokevirtual createRowDimensionRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;F)Landroidx/constraintlayout/solver/ArrayRow;
    //   793: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   796: iload #12
    //   798: istore #25
    //   800: iconst_0
    //   801: istore #28
    //   803: iload #15
    //   805: istore #12
    //   807: goto -> 825
    //   810: iconst_1
    //   811: istore #5
    //   813: iload #22
    //   815: istore #28
    //   817: iload #12
    //   819: istore #25
    //   821: iload #15
    //   823: istore #12
    //   825: aload #8
    //   827: astore #40
    //   829: aload #41
    //   831: astore #8
    //   833: iload #27
    //   835: ifeq -> 2258
    //   838: iload #19
    //   840: ifeq -> 846
    //   843: goto -> 2258
    //   846: iload #33
    //   848: ifne -> 864
    //   851: iload #34
    //   853: ifne -> 864
    //   856: iload #35
    //   858: ifne -> 864
    //   861: goto -> 2155
    //   864: iload #33
    //   866: ifeq -> 877
    //   869: iload #34
    //   871: ifne -> 877
    //   874: goto -> 2155
    //   877: iload #33
    //   879: ifne -> 978
    //   882: iload #34
    //   884: ifeq -> 978
    //   887: aload_1
    //   888: aload #38
    //   890: aload #40
    //   892: aload #11
    //   894: invokevirtual getMargin : ()I
    //   897: ineg
    //   898: bipush #8
    //   900: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   903: pop
    //   904: iload_3
    //   905: ifeq -> 2155
    //   908: aload_0
    //   909: getfield OPTIMIZE_WRAP : Z
    //   912: ifeq -> 965
    //   915: aload #39
    //   917: getfield isFinalValue : Z
    //   920: ifeq -> 965
    //   923: aload_0
    //   924: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   927: astore #8
    //   929: aload #8
    //   931: ifnull -> 965
    //   934: aload #8
    //   936: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   939: astore #6
    //   941: iload_2
    //   942: ifeq -> 955
    //   945: aload #6
    //   947: aload #10
    //   949: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   952: goto -> 2155
    //   955: aload #6
    //   957: aload #10
    //   959: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   962: goto -> 2155
    //   965: aload_1
    //   966: aload #39
    //   968: aload #6
    //   970: iconst_0
    //   971: iconst_5
    //   972: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   975: goto -> 2155
    //   978: iload #33
    //   980: ifeq -> 2155
    //   983: iload #34
    //   985: ifeq -> 2155
    //   988: aload #10
    //   990: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   993: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   996: astore #43
    //   998: aload #11
    //   1000: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1003: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1006: astore #36
    //   1008: aload_0
    //   1009: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1012: astore #42
    //   1014: bipush #6
    //   1016: istore #31
    //   1018: iload #28
    //   1020: ifeq -> 1462
    //   1023: iload #29
    //   1025: istore #13
    //   1027: iload #13
    //   1029: ifne -> 1187
    //   1032: iload #12
    //   1034: ifne -> 1112
    //   1037: iload #25
    //   1039: ifne -> 1112
    //   1042: aload #8
    //   1044: getfield isFinalValue : Z
    //   1047: ifeq -> 1092
    //   1050: aload #40
    //   1052: getfield isFinalValue : Z
    //   1055: ifeq -> 1092
    //   1058: aload_1
    //   1059: aload #39
    //   1061: aload #8
    //   1063: aload #10
    //   1065: invokevirtual getMargin : ()I
    //   1068: bipush #8
    //   1070: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1073: pop
    //   1074: aload_1
    //   1075: aload #38
    //   1077: aload #40
    //   1079: aload #11
    //   1081: invokevirtual getMargin : ()I
    //   1084: ineg
    //   1085: bipush #8
    //   1087: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1090: pop
    //   1091: return
    //   1092: iconst_0
    //   1093: istore #13
    //   1095: iconst_1
    //   1096: istore #15
    //   1098: iconst_0
    //   1099: istore #12
    //   1101: bipush #8
    //   1103: istore #22
    //   1105: bipush #8
    //   1107: istore #23
    //   1109: goto -> 1127
    //   1112: iconst_1
    //   1113: istore #13
    //   1115: iconst_0
    //   1116: istore #15
    //   1118: iconst_1
    //   1119: istore #12
    //   1121: iconst_5
    //   1122: istore #22
    //   1124: iconst_5
    //   1125: istore #23
    //   1127: aload #43
    //   1129: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1132: ifne -> 1153
    //   1135: aload #36
    //   1137: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1140: ifeq -> 1146
    //   1143: goto -> 1153
    //   1146: iload #23
    //   1148: istore #30
    //   1150: goto -> 1156
    //   1153: iconst_4
    //   1154: istore #30
    //   1156: bipush #6
    //   1158: istore #32
    //   1160: iload #15
    //   1162: istore #23
    //   1164: iload #12
    //   1166: istore #15
    //   1168: iload #13
    //   1170: istore #24
    //   1172: iload #22
    //   1174: istore #12
    //   1176: iload #32
    //   1178: istore #22
    //   1180: iload #30
    //   1182: istore #13
    //   1184: goto -> 1572
    //   1187: iload #13
    //   1189: iconst_1
    //   1190: if_icmpne -> 1209
    //   1193: iconst_1
    //   1194: istore #15
    //   1196: iconst_1
    //   1197: istore #24
    //   1199: iconst_0
    //   1200: istore #23
    //   1202: bipush #8
    //   1204: istore #12
    //   1206: goto -> 1565
    //   1209: iload #13
    //   1211: iconst_3
    //   1212: if_icmpne -> 1453
    //   1215: aload_0
    //   1216: getfield mResolvedDimensionRatioSide : I
    //   1219: iconst_m1
    //   1220: if_icmpne -> 1271
    //   1223: iload #20
    //   1225: ifeq -> 1248
    //   1228: bipush #8
    //   1230: istore #12
    //   1232: iload_3
    //   1233: ifeq -> 1242
    //   1236: iconst_5
    //   1237: istore #22
    //   1239: goto -> 1256
    //   1242: iconst_4
    //   1243: istore #22
    //   1245: goto -> 1256
    //   1248: bipush #8
    //   1250: istore #12
    //   1252: bipush #8
    //   1254: istore #22
    //   1256: iconst_1
    //   1257: istore #23
    //   1259: iconst_1
    //   1260: istore #24
    //   1262: iconst_1
    //   1263: istore #15
    //   1265: iconst_5
    //   1266: istore #13
    //   1268: goto -> 1572
    //   1271: iload #17
    //   1273: ifeq -> 1353
    //   1276: iload #23
    //   1278: iconst_2
    //   1279: if_icmpeq -> 1297
    //   1282: iload #23
    //   1284: iconst_1
    //   1285: if_icmpne -> 1291
    //   1288: goto -> 1297
    //   1291: iconst_0
    //   1292: istore #12
    //   1294: goto -> 1300
    //   1297: iconst_1
    //   1298: istore #12
    //   1300: iload #12
    //   1302: ifne -> 1315
    //   1305: bipush #8
    //   1307: istore #13
    //   1309: iconst_5
    //   1310: istore #12
    //   1312: goto -> 1321
    //   1315: iconst_5
    //   1316: istore #13
    //   1318: iconst_4
    //   1319: istore #12
    //   1321: iload #13
    //   1323: istore #22
    //   1325: iload #12
    //   1327: istore #13
    //   1329: iconst_1
    //   1330: istore #15
    //   1332: iconst_1
    //   1333: istore #24
    //   1335: iconst_1
    //   1336: istore #23
    //   1338: bipush #6
    //   1340: istore #30
    //   1342: iload #22
    //   1344: istore #12
    //   1346: iload #30
    //   1348: istore #22
    //   1350: goto -> 1572
    //   1353: iload #12
    //   1355: ifle -> 1368
    //   1358: iconst_5
    //   1359: istore #12
    //   1361: bipush #6
    //   1363: istore #22
    //   1365: goto -> 1256
    //   1368: iload #12
    //   1370: ifne -> 1441
    //   1373: iload #25
    //   1375: ifne -> 1441
    //   1378: iload #20
    //   1380: ifne -> 1406
    //   1383: iconst_1
    //   1384: istore #15
    //   1386: iconst_1
    //   1387: istore #24
    //   1389: iconst_1
    //   1390: istore #23
    //   1392: iconst_5
    //   1393: istore #12
    //   1395: bipush #6
    //   1397: istore #22
    //   1399: bipush #8
    //   1401: istore #13
    //   1403: goto -> 1572
    //   1406: aload #43
    //   1408: aload #42
    //   1410: if_acmpeq -> 1426
    //   1413: aload #36
    //   1415: aload #42
    //   1417: if_acmpeq -> 1426
    //   1420: iconst_4
    //   1421: istore #12
    //   1423: goto -> 1429
    //   1426: iconst_5
    //   1427: istore #12
    //   1429: iconst_1
    //   1430: istore #15
    //   1432: iconst_1
    //   1433: istore #24
    //   1435: iconst_1
    //   1436: istore #23
    //   1438: goto -> 1565
    //   1441: iconst_1
    //   1442: istore #15
    //   1444: iconst_1
    //   1445: istore #24
    //   1447: iconst_1
    //   1448: istore #23
    //   1450: goto -> 1562
    //   1453: iconst_0
    //   1454: istore #15
    //   1456: iconst_0
    //   1457: istore #24
    //   1459: goto -> 1559
    //   1462: aload #8
    //   1464: getfield isFinalValue : Z
    //   1467: ifeq -> 1553
    //   1470: aload #40
    //   1472: getfield isFinalValue : Z
    //   1475: ifeq -> 1553
    //   1478: aload_1
    //   1479: aload #39
    //   1481: aload #8
    //   1483: aload #10
    //   1485: invokevirtual getMargin : ()I
    //   1488: fload #16
    //   1490: aload #40
    //   1492: aload #38
    //   1494: aload #11
    //   1496: invokevirtual getMargin : ()I
    //   1499: bipush #8
    //   1501: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1504: iload_3
    //   1505: ifeq -> 1552
    //   1508: iload #5
    //   1510: ifeq -> 1552
    //   1513: aload #11
    //   1515: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1518: ifnull -> 1531
    //   1521: aload #11
    //   1523: invokevirtual getMargin : ()I
    //   1526: istore #12
    //   1528: goto -> 1534
    //   1531: iconst_0
    //   1532: istore #12
    //   1534: aload #40
    //   1536: aload #7
    //   1538: if_acmpeq -> 1552
    //   1541: aload_1
    //   1542: aload #7
    //   1544: aload #38
    //   1546: iload #12
    //   1548: iconst_5
    //   1549: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1552: return
    //   1553: iconst_1
    //   1554: istore #15
    //   1556: iconst_1
    //   1557: istore #24
    //   1559: iconst_0
    //   1560: istore #23
    //   1562: iconst_5
    //   1563: istore #12
    //   1565: bipush #6
    //   1567: istore #22
    //   1569: iconst_4
    //   1570: istore #13
    //   1572: iload #29
    //   1574: istore #30
    //   1576: iload #15
    //   1578: ifeq -> 1604
    //   1581: aload #8
    //   1583: aload #40
    //   1585: if_acmpne -> 1604
    //   1588: aload #43
    //   1590: aload #42
    //   1592: if_acmpeq -> 1604
    //   1595: iconst_0
    //   1596: istore #15
    //   1598: iconst_0
    //   1599: istore #29
    //   1601: goto -> 1607
    //   1604: iconst_1
    //   1605: istore #29
    //   1607: iload #24
    //   1609: ifeq -> 1686
    //   1612: iload #28
    //   1614: ifne -> 1657
    //   1617: iload #18
    //   1619: ifne -> 1657
    //   1622: iload #20
    //   1624: ifne -> 1657
    //   1627: aload #8
    //   1629: aload #6
    //   1631: if_acmpne -> 1657
    //   1634: aload #40
    //   1636: aload #7
    //   1638: if_acmpne -> 1657
    //   1641: iconst_0
    //   1642: istore_3
    //   1643: bipush #8
    //   1645: istore #12
    //   1647: bipush #8
    //   1649: istore #22
    //   1651: iconst_0
    //   1652: istore #29
    //   1654: goto -> 1657
    //   1657: aload_1
    //   1658: aload #39
    //   1660: aload #8
    //   1662: aload #10
    //   1664: invokevirtual getMargin : ()I
    //   1667: fload #16
    //   1669: aload #40
    //   1671: aload #38
    //   1673: aload #11
    //   1675: invokevirtual getMargin : ()I
    //   1678: iload #22
    //   1680: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1683: goto -> 1686
    //   1686: aload #8
    //   1688: astore #41
    //   1690: aload #39
    //   1692: astore #37
    //   1694: aload #42
    //   1696: astore #8
    //   1698: aload_0
    //   1699: getfield mVisibility : I
    //   1702: bipush #8
    //   1704: if_icmpne -> 1716
    //   1707: aload #11
    //   1709: invokevirtual hasDependents : ()Z
    //   1712: ifne -> 1716
    //   1715: return
    //   1716: iload #15
    //   1718: ifeq -> 1797
    //   1721: iload_3
    //   1722: ifeq -> 1763
    //   1725: aload #41
    //   1727: aload #40
    //   1729: if_acmpeq -> 1763
    //   1732: iload #28
    //   1734: ifne -> 1763
    //   1737: aload #43
    //   1739: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1742: ifne -> 1756
    //   1745: aload #36
    //   1747: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1750: ifeq -> 1763
    //   1753: goto -> 1756
    //   1756: bipush #6
    //   1758: istore #12
    //   1760: goto -> 1763
    //   1763: aload_1
    //   1764: aload #37
    //   1766: aload #41
    //   1768: aload #10
    //   1770: invokevirtual getMargin : ()I
    //   1773: iload #12
    //   1775: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1778: aload_1
    //   1779: aload #38
    //   1781: aload #40
    //   1783: aload #11
    //   1785: invokevirtual getMargin : ()I
    //   1788: ineg
    //   1789: iload #12
    //   1791: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1794: goto -> 1797
    //   1797: iload_3
    //   1798: ifeq -> 1836
    //   1801: iload #21
    //   1803: ifeq -> 1836
    //   1806: aload #43
    //   1808: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1811: ifne -> 1836
    //   1814: aload #36
    //   1816: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1819: ifne -> 1836
    //   1822: bipush #6
    //   1824: istore #15
    //   1826: bipush #6
    //   1828: istore #12
    //   1830: iconst_1
    //   1831: istore #29
    //   1833: goto -> 1844
    //   1836: iload #12
    //   1838: istore #15
    //   1840: iload #13
    //   1842: istore #12
    //   1844: iload #29
    //   1846: ifeq -> 2038
    //   1849: iload #23
    //   1851: ifeq -> 1958
    //   1854: iload #20
    //   1856: ifeq -> 1864
    //   1859: iload #4
    //   1861: ifeq -> 1958
    //   1864: aload #8
    //   1866: astore #39
    //   1868: iload #31
    //   1870: istore #13
    //   1872: aload #43
    //   1874: aload #39
    //   1876: if_acmpeq -> 1897
    //   1879: aload #36
    //   1881: aload #39
    //   1883: if_acmpne -> 1893
    //   1886: iload #31
    //   1888: istore #13
    //   1890: goto -> 1897
    //   1893: iload #12
    //   1895: istore #13
    //   1897: aload #43
    //   1899: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   1902: ifne -> 1913
    //   1905: aload #36
    //   1907: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   1910: ifeq -> 1916
    //   1913: iconst_5
    //   1914: istore #13
    //   1916: aload #43
    //   1918: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1921: ifne -> 1932
    //   1924: aload #36
    //   1926: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1929: ifeq -> 1935
    //   1932: iconst_5
    //   1933: istore #13
    //   1935: iload #20
    //   1937: ifeq -> 1946
    //   1940: iconst_5
    //   1941: istore #13
    //   1943: goto -> 1946
    //   1946: iload #13
    //   1948: iload #12
    //   1950: invokestatic max : (II)I
    //   1953: istore #12
    //   1955: goto -> 1958
    //   1958: iload #12
    //   1960: istore #13
    //   1962: iload_3
    //   1963: ifeq -> 2005
    //   1966: iload #15
    //   1968: iload #12
    //   1970: invokestatic min : (II)I
    //   1973: istore #13
    //   1975: iload #17
    //   1977: ifeq -> 2005
    //   1980: iload #20
    //   1982: ifne -> 2005
    //   1985: aload #43
    //   1987: aload #8
    //   1989: if_acmpeq -> 1999
    //   1992: aload #36
    //   1994: aload #8
    //   1996: if_acmpne -> 2005
    //   1999: iconst_4
    //   2000: istore #13
    //   2002: goto -> 2005
    //   2005: aload_1
    //   2006: aload #37
    //   2008: aload #41
    //   2010: aload #10
    //   2012: invokevirtual getMargin : ()I
    //   2015: iload #13
    //   2017: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2020: pop
    //   2021: aload_1
    //   2022: aload #38
    //   2024: aload #40
    //   2026: aload #11
    //   2028: invokevirtual getMargin : ()I
    //   2031: ineg
    //   2032: iload #13
    //   2034: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2037: pop
    //   2038: iload_3
    //   2039: ifeq -> 2080
    //   2042: aload #6
    //   2044: aload #41
    //   2046: if_acmpne -> 2059
    //   2049: aload #10
    //   2051: invokevirtual getMargin : ()I
    //   2054: istore #12
    //   2056: goto -> 2062
    //   2059: iconst_0
    //   2060: istore #12
    //   2062: aload #41
    //   2064: aload #6
    //   2066: if_acmpeq -> 2080
    //   2069: aload_1
    //   2070: aload #37
    //   2072: aload #6
    //   2074: iload #12
    //   2076: iconst_5
    //   2077: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2080: iload_3
    //   2081: istore #4
    //   2083: iload_3
    //   2084: ifeq -> 2158
    //   2087: iload_3
    //   2088: istore #4
    //   2090: iload #28
    //   2092: ifeq -> 2158
    //   2095: iload_3
    //   2096: istore #4
    //   2098: iload #14
    //   2100: ifne -> 2158
    //   2103: iload_3
    //   2104: istore #4
    //   2106: iload #25
    //   2108: ifne -> 2158
    //   2111: iload #28
    //   2113: ifeq -> 2139
    //   2116: iload #30
    //   2118: iconst_3
    //   2119: if_icmpne -> 2139
    //   2122: aload_1
    //   2123: aload #38
    //   2125: aload #37
    //   2127: iconst_0
    //   2128: bipush #8
    //   2130: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2133: iload_3
    //   2134: istore #4
    //   2136: goto -> 2158
    //   2139: aload_1
    //   2140: aload #38
    //   2142: aload #37
    //   2144: iconst_0
    //   2145: iconst_5
    //   2146: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2149: iload_3
    //   2150: istore #4
    //   2152: goto -> 2158
    //   2155: iload_3
    //   2156: istore #4
    //   2158: iload #4
    //   2160: ifeq -> 2257
    //   2163: iload #5
    //   2165: ifeq -> 2257
    //   2168: aload #11
    //   2170: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2173: ifnull -> 2186
    //   2176: aload #11
    //   2178: invokevirtual getMargin : ()I
    //   2181: istore #12
    //   2183: goto -> 2189
    //   2186: iconst_0
    //   2187: istore #12
    //   2189: aload #40
    //   2191: aload #7
    //   2193: if_acmpeq -> 2257
    //   2196: aload_0
    //   2197: getfield OPTIMIZE_WRAP : Z
    //   2200: ifeq -> 2246
    //   2203: aload #38
    //   2205: getfield isFinalValue : Z
    //   2208: ifeq -> 2246
    //   2211: aload_0
    //   2212: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2215: astore #6
    //   2217: aload #6
    //   2219: ifnull -> 2246
    //   2222: aload #6
    //   2224: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   2227: astore_1
    //   2228: iload_2
    //   2229: ifeq -> 2239
    //   2232: aload_1
    //   2233: aload #11
    //   2235: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   2238: return
    //   2239: aload_1
    //   2240: aload #11
    //   2242: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   2245: return
    //   2246: aload_1
    //   2247: aload #7
    //   2249: aload #38
    //   2251: iload #12
    //   2253: iconst_5
    //   2254: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2257: return
    //   2258: iconst_1
    //   2259: istore #13
    //   2261: iload #30
    //   2263: iconst_2
    //   2264: if_icmpge -> 2404
    //   2267: iload_3
    //   2268: ifeq -> 2404
    //   2271: iload #5
    //   2273: ifeq -> 2404
    //   2276: aload_1
    //   2277: aload #39
    //   2279: aload #6
    //   2281: iconst_0
    //   2282: bipush #8
    //   2284: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2287: iload_2
    //   2288: ifne -> 2310
    //   2291: aload_0
    //   2292: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2295: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2298: ifnonnull -> 2304
    //   2301: goto -> 2310
    //   2304: iconst_0
    //   2305: istore #12
    //   2307: goto -> 2313
    //   2310: iconst_1
    //   2311: istore #12
    //   2313: iload_2
    //   2314: ifne -> 2388
    //   2317: aload_0
    //   2318: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2321: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2324: ifnull -> 2388
    //   2327: aload_0
    //   2328: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2331: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2334: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2337: astore #6
    //   2339: aload #6
    //   2341: getfield mDimensionRatio : F
    //   2344: fconst_0
    //   2345: fcmpl
    //   2346: ifeq -> 2382
    //   2349: aload #6
    //   2351: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2354: iconst_0
    //   2355: aaload
    //   2356: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2359: if_acmpne -> 2382
    //   2362: aload #6
    //   2364: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2367: iconst_1
    //   2368: aaload
    //   2369: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2372: if_acmpne -> 2382
    //   2375: iload #13
    //   2377: istore #12
    //   2379: goto -> 2388
    //   2382: iconst_0
    //   2383: istore #12
    //   2385: goto -> 2388
    //   2388: iload #12
    //   2390: ifeq -> 2404
    //   2393: aload_1
    //   2394: aload #7
    //   2396: aload #38
    //   2398: iconst_0
    //   2399: bipush #8
    //   2401: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2404: return
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   8: astore #28
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   18: astore #27
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   28: astore #30
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   38: astore #29
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   48: astore #26
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #24
    //   56: aload #24
    //   58: ifnull -> 128
    //   61: aload #24
    //   63: ifnull -> 85
    //   66: aload #24
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #11
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   92: astore #24
    //   94: aload #24
    //   96: ifnull -> 118
    //   99: aload #24
    //   101: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: iconst_1
    //   105: aaload
    //   106: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   109: if_acmpne -> 118
    //   112: iconst_1
    //   113: istore #12
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #12
    //   121: iload #11
    //   123: istore #14
    //   125: goto -> 134
    //   128: iconst_0
    //   129: istore #14
    //   131: iconst_0
    //   132: istore #12
    //   134: aload_0
    //   135: getfield mVisibility : I
    //   138: bipush #8
    //   140: if_icmpne -> 171
    //   143: aload_0
    //   144: invokevirtual hasDependencies : ()Z
    //   147: ifne -> 171
    //   150: aload_0
    //   151: getfield mIsInBarrier : [Z
    //   154: astore #24
    //   156: aload #24
    //   158: iconst_0
    //   159: baload
    //   160: ifne -> 171
    //   163: aload #24
    //   165: iconst_1
    //   166: baload
    //   167: ifne -> 171
    //   170: return
    //   171: aload_0
    //   172: getfield resolvedHorizontal : Z
    //   175: ifne -> 185
    //   178: aload_0
    //   179: getfield resolvedVertical : Z
    //   182: ifeq -> 435
    //   185: aload_0
    //   186: getfield resolvedHorizontal : Z
    //   189: ifeq -> 285
    //   192: aload_1
    //   193: aload #28
    //   195: aload_0
    //   196: getfield mX : I
    //   199: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   202: aload_1
    //   203: aload #27
    //   205: aload_0
    //   206: getfield mX : I
    //   209: aload_0
    //   210: getfield mWidth : I
    //   213: iadd
    //   214: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   217: iload #14
    //   219: ifeq -> 285
    //   222: aload_0
    //   223: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   226: astore #24
    //   228: aload #24
    //   230: ifnull -> 285
    //   233: aload_0
    //   234: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   237: ifeq -> 268
    //   240: aload #24
    //   242: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   245: astore #24
    //   247: aload #24
    //   249: aload_0
    //   250: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   253: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   256: aload #24
    //   258: aload_0
    //   259: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   262: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   265: goto -> 285
    //   268: aload_1
    //   269: aload_1
    //   270: aload #24
    //   272: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   275: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   278: aload #27
    //   280: iconst_0
    //   281: iconst_5
    //   282: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   285: aload_0
    //   286: getfield resolvedVertical : Z
    //   289: ifeq -> 410
    //   292: aload_1
    //   293: aload #30
    //   295: aload_0
    //   296: getfield mY : I
    //   299: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   302: aload_1
    //   303: aload #29
    //   305: aload_0
    //   306: getfield mY : I
    //   309: aload_0
    //   310: getfield mHeight : I
    //   313: iadd
    //   314: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   317: aload_0
    //   318: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   321: invokevirtual hasDependents : ()Z
    //   324: ifeq -> 342
    //   327: aload_1
    //   328: aload #26
    //   330: aload_0
    //   331: getfield mY : I
    //   334: aload_0
    //   335: getfield mBaselineDistance : I
    //   338: iadd
    //   339: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   342: iload #12
    //   344: ifeq -> 410
    //   347: aload_0
    //   348: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   351: astore #24
    //   353: aload #24
    //   355: ifnull -> 410
    //   358: aload_0
    //   359: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   362: ifeq -> 393
    //   365: aload #24
    //   367: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   370: astore #24
    //   372: aload #24
    //   374: aload_0
    //   375: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   378: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   381: aload #24
    //   383: aload_0
    //   384: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   387: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   390: goto -> 410
    //   393: aload_1
    //   394: aload_1
    //   395: aload #24
    //   397: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   400: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   403: aload #29
    //   405: iconst_0
    //   406: iconst_5
    //   407: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   410: aload_0
    //   411: getfield resolvedHorizontal : Z
    //   414: ifeq -> 435
    //   417: aload_0
    //   418: getfield resolvedVertical : Z
    //   421: ifeq -> 435
    //   424: aload_0
    //   425: iconst_0
    //   426: putfield resolvedHorizontal : Z
    //   429: aload_0
    //   430: iconst_0
    //   431: putfield resolvedVertical : Z
    //   434: return
    //   435: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   438: ifnull -> 458
    //   441: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   444: astore #24
    //   446: aload #24
    //   448: aload #24
    //   450: getfield widgets : J
    //   453: lconst_1
    //   454: ladd
    //   455: putfield widgets : J
    //   458: iload_2
    //   459: ifeq -> 733
    //   462: aload_0
    //   463: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   466: astore #24
    //   468: aload #24
    //   470: ifnull -> 733
    //   473: aload_0
    //   474: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   477: ifnull -> 733
    //   480: aload #24
    //   482: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   485: getfield resolved : Z
    //   488: ifeq -> 733
    //   491: aload_0
    //   492: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   495: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   498: getfield resolved : Z
    //   501: ifeq -> 733
    //   504: aload_0
    //   505: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   508: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   511: getfield resolved : Z
    //   514: ifeq -> 733
    //   517: aload_0
    //   518: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   521: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   524: getfield resolved : Z
    //   527: ifeq -> 733
    //   530: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   533: ifnull -> 553
    //   536: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   539: astore #24
    //   541: aload #24
    //   543: aload #24
    //   545: getfield graphSolved : J
    //   548: lconst_1
    //   549: ladd
    //   550: putfield graphSolved : J
    //   553: aload_1
    //   554: aload #28
    //   556: aload_0
    //   557: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   560: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   563: getfield value : I
    //   566: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   569: aload_1
    //   570: aload #27
    //   572: aload_0
    //   573: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   576: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   579: getfield value : I
    //   582: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   585: aload_1
    //   586: aload #30
    //   588: aload_0
    //   589: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   592: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   595: getfield value : I
    //   598: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   601: aload_1
    //   602: aload #29
    //   604: aload_0
    //   605: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   608: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   611: getfield value : I
    //   614: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   617: aload_1
    //   618: aload #26
    //   620: aload_0
    //   621: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   624: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   627: getfield value : I
    //   630: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   633: aload_0
    //   634: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   637: ifnull -> 722
    //   640: iload #14
    //   642: ifeq -> 681
    //   645: aload_0
    //   646: getfield isTerminalWidget : [Z
    //   649: iconst_0
    //   650: baload
    //   651: ifeq -> 681
    //   654: aload_0
    //   655: invokevirtual isInHorizontalChain : ()Z
    //   658: ifne -> 681
    //   661: aload_1
    //   662: aload_1
    //   663: aload_0
    //   664: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   667: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   670: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   673: aload #27
    //   675: iconst_0
    //   676: bipush #8
    //   678: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   681: iload #12
    //   683: ifeq -> 722
    //   686: aload_0
    //   687: getfield isTerminalWidget : [Z
    //   690: iconst_1
    //   691: baload
    //   692: ifeq -> 722
    //   695: aload_0
    //   696: invokevirtual isInVerticalChain : ()Z
    //   699: ifne -> 722
    //   702: aload_1
    //   703: aload_1
    //   704: aload_0
    //   705: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   708: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   711: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   714: aload #29
    //   716: iconst_0
    //   717: bipush #8
    //   719: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   722: aload_0
    //   723: iconst_0
    //   724: putfield resolvedHorizontal : Z
    //   727: aload_0
    //   728: iconst_0
    //   729: putfield resolvedVertical : Z
    //   732: return
    //   733: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   736: ifnull -> 756
    //   739: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   742: astore #24
    //   744: aload #24
    //   746: aload #24
    //   748: getfield linearSolved : J
    //   751: lconst_1
    //   752: ladd
    //   753: putfield linearSolved : J
    //   756: aload_0
    //   757: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   760: ifnull -> 957
    //   763: aload_0
    //   764: iconst_0
    //   765: invokespecial isChainHead : (I)Z
    //   768: ifeq -> 789
    //   771: aload_0
    //   772: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   775: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   778: aload_0
    //   779: iconst_0
    //   780: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   783: iconst_1
    //   784: istore #11
    //   786: goto -> 795
    //   789: aload_0
    //   790: invokevirtual isInHorizontalChain : ()Z
    //   793: istore #11
    //   795: aload_0
    //   796: iconst_1
    //   797: invokespecial isChainHead : (I)Z
    //   800: ifeq -> 821
    //   803: aload_0
    //   804: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   807: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   810: aload_0
    //   811: iconst_1
    //   812: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   815: iconst_1
    //   816: istore #13
    //   818: goto -> 827
    //   821: aload_0
    //   822: invokevirtual isInVerticalChain : ()Z
    //   825: istore #13
    //   827: iload #11
    //   829: ifne -> 885
    //   832: iload #14
    //   834: ifeq -> 885
    //   837: aload_0
    //   838: getfield mVisibility : I
    //   841: bipush #8
    //   843: if_icmpeq -> 885
    //   846: aload_0
    //   847: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   850: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   853: ifnonnull -> 885
    //   856: aload_0
    //   857: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   860: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   863: ifnonnull -> 885
    //   866: aload_1
    //   867: aload_1
    //   868: aload_0
    //   869: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   872: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   875: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   878: aload #27
    //   880: iconst_0
    //   881: iconst_1
    //   882: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   885: iload #13
    //   887: ifne -> 950
    //   890: iload #12
    //   892: ifeq -> 950
    //   895: aload_0
    //   896: getfield mVisibility : I
    //   899: bipush #8
    //   901: if_icmpeq -> 950
    //   904: aload_0
    //   905: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   908: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   911: ifnonnull -> 950
    //   914: aload_0
    //   915: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   918: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   921: ifnonnull -> 950
    //   924: aload_0
    //   925: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   928: ifnonnull -> 950
    //   931: aload_1
    //   932: aload_1
    //   933: aload_0
    //   934: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   937: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   940: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   943: aload #29
    //   945: iconst_0
    //   946: iconst_1
    //   947: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   950: iload #11
    //   952: istore #15
    //   954: goto -> 963
    //   957: iconst_0
    //   958: istore #13
    //   960: iconst_0
    //   961: istore #15
    //   963: aload_0
    //   964: getfield mWidth : I
    //   967: istore #5
    //   969: aload_0
    //   970: getfield mMinWidth : I
    //   973: istore #6
    //   975: iload #5
    //   977: istore #4
    //   979: iload #5
    //   981: iload #6
    //   983: if_icmpge -> 990
    //   986: iload #6
    //   988: istore #4
    //   990: aload_0
    //   991: getfield mHeight : I
    //   994: istore #6
    //   996: aload_0
    //   997: getfield mMinHeight : I
    //   1000: istore #7
    //   1002: iload #6
    //   1004: istore #5
    //   1006: iload #6
    //   1008: iload #7
    //   1010: if_icmpge -> 1017
    //   1013: iload #7
    //   1015: istore #5
    //   1017: aload_0
    //   1018: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1021: iconst_0
    //   1022: aaload
    //   1023: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1026: if_acmpeq -> 1035
    //   1029: iconst_1
    //   1030: istore #11
    //   1032: goto -> 1038
    //   1035: iconst_0
    //   1036: istore #11
    //   1038: aload_0
    //   1039: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1042: iconst_1
    //   1043: aaload
    //   1044: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1047: if_acmpeq -> 1056
    //   1050: iconst_1
    //   1051: istore #16
    //   1053: goto -> 1059
    //   1056: iconst_0
    //   1057: istore #16
    //   1059: aload_0
    //   1060: aload_0
    //   1061: getfield mDimensionRatioSide : I
    //   1064: putfield mResolvedDimensionRatioSide : I
    //   1067: aload_0
    //   1068: getfield mDimensionRatio : F
    //   1071: fstore_3
    //   1072: aload_0
    //   1073: fload_3
    //   1074: putfield mResolvedDimensionRatio : F
    //   1077: aload_0
    //   1078: getfield mMatchConstraintDefaultWidth : I
    //   1081: istore #7
    //   1083: aload_0
    //   1084: getfield mMatchConstraintDefaultHeight : I
    //   1087: istore #8
    //   1089: fload_3
    //   1090: fconst_0
    //   1091: fcmpl
    //   1092: ifle -> 1439
    //   1095: aload_0
    //   1096: getfield mVisibility : I
    //   1099: bipush #8
    //   1101: if_icmpeq -> 1439
    //   1104: iload #7
    //   1106: istore #6
    //   1108: aload_0
    //   1109: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1112: iconst_0
    //   1113: aaload
    //   1114: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1117: if_acmpne -> 1132
    //   1120: iload #7
    //   1122: istore #6
    //   1124: iload #7
    //   1126: ifne -> 1132
    //   1129: iconst_3
    //   1130: istore #6
    //   1132: iload #8
    //   1134: istore #7
    //   1136: aload_0
    //   1137: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1140: iconst_1
    //   1141: aaload
    //   1142: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1145: if_acmpne -> 1160
    //   1148: iload #8
    //   1150: istore #7
    //   1152: iload #8
    //   1154: ifne -> 1160
    //   1157: iconst_3
    //   1158: istore #7
    //   1160: aload_0
    //   1161: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1164: iconst_0
    //   1165: aaload
    //   1166: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1169: if_acmpne -> 1211
    //   1172: aload_0
    //   1173: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1176: iconst_1
    //   1177: aaload
    //   1178: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1181: if_acmpne -> 1211
    //   1184: iload #6
    //   1186: iconst_3
    //   1187: if_icmpne -> 1211
    //   1190: iload #7
    //   1192: iconst_3
    //   1193: if_icmpne -> 1211
    //   1196: aload_0
    //   1197: iload #14
    //   1199: iload #12
    //   1201: iload #11
    //   1203: iload #16
    //   1205: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1208: goto -> 1409
    //   1211: aload_0
    //   1212: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1215: iconst_0
    //   1216: aaload
    //   1217: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1220: if_acmpne -> 1303
    //   1223: iload #6
    //   1225: iconst_3
    //   1226: if_icmpne -> 1303
    //   1229: aload_0
    //   1230: iconst_0
    //   1231: putfield mResolvedDimensionRatioSide : I
    //   1234: aload_0
    //   1235: getfield mResolvedDimensionRatio : F
    //   1238: aload_0
    //   1239: getfield mHeight : I
    //   1242: i2f
    //   1243: fmul
    //   1244: f2i
    //   1245: istore #4
    //   1247: aload_0
    //   1248: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1251: iconst_1
    //   1252: aaload
    //   1253: astore #24
    //   1255: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1258: astore #25
    //   1260: iload #7
    //   1262: istore #8
    //   1264: aload #24
    //   1266: aload #25
    //   1268: if_acmpeq -> 1296
    //   1271: iload #5
    //   1273: istore #6
    //   1275: iconst_0
    //   1276: istore #11
    //   1278: iconst_4
    //   1279: istore #7
    //   1281: iload #4
    //   1283: istore #5
    //   1285: iload #6
    //   1287: istore #4
    //   1289: iload #8
    //   1291: istore #6
    //   1293: goto -> 1458
    //   1296: iload #4
    //   1298: istore #8
    //   1300: goto -> 1413
    //   1303: aload_0
    //   1304: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1307: iconst_1
    //   1308: aaload
    //   1309: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1312: if_acmpne -> 1409
    //   1315: iload #7
    //   1317: iconst_3
    //   1318: if_icmpne -> 1409
    //   1321: aload_0
    //   1322: iconst_1
    //   1323: putfield mResolvedDimensionRatioSide : I
    //   1326: aload_0
    //   1327: getfield mDimensionRatioSide : I
    //   1330: iconst_m1
    //   1331: if_icmpne -> 1344
    //   1334: aload_0
    //   1335: fconst_1
    //   1336: aload_0
    //   1337: getfield mResolvedDimensionRatio : F
    //   1340: fdiv
    //   1341: putfield mResolvedDimensionRatio : F
    //   1344: aload_0
    //   1345: getfield mResolvedDimensionRatio : F
    //   1348: aload_0
    //   1349: getfield mWidth : I
    //   1352: i2f
    //   1353: fmul
    //   1354: f2i
    //   1355: istore #8
    //   1357: aload_0
    //   1358: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1361: iconst_0
    //   1362: aaload
    //   1363: astore #24
    //   1365: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1368: astore #25
    //   1370: aload #24
    //   1372: aload #25
    //   1374: if_acmpeq -> 1398
    //   1377: iload #6
    //   1379: istore #7
    //   1381: iconst_0
    //   1382: istore #11
    //   1384: iconst_4
    //   1385: istore #6
    //   1387: iload #4
    //   1389: istore #5
    //   1391: iload #8
    //   1393: istore #4
    //   1395: goto -> 1458
    //   1398: iload #4
    //   1400: istore #5
    //   1402: iload #8
    //   1404: istore #4
    //   1406: goto -> 1421
    //   1409: iload #4
    //   1411: istore #8
    //   1413: iload #5
    //   1415: istore #4
    //   1417: iload #8
    //   1419: istore #5
    //   1421: iload #6
    //   1423: istore #8
    //   1425: iload #7
    //   1427: istore #6
    //   1429: iconst_1
    //   1430: istore #11
    //   1432: iload #8
    //   1434: istore #7
    //   1436: goto -> 1458
    //   1439: iload #8
    //   1441: istore #6
    //   1443: iload #4
    //   1445: istore #8
    //   1447: iload #5
    //   1449: istore #4
    //   1451: iconst_0
    //   1452: istore #11
    //   1454: iload #8
    //   1456: istore #5
    //   1458: aload_0
    //   1459: getfield mResolvedMatchConstraintDefault : [I
    //   1462: astore #24
    //   1464: aload #24
    //   1466: iconst_0
    //   1467: iload #7
    //   1469: iastore
    //   1470: aload #24
    //   1472: iconst_1
    //   1473: iload #6
    //   1475: iastore
    //   1476: aload_0
    //   1477: iload #11
    //   1479: putfield mResolvedHasRatio : Z
    //   1482: iload #11
    //   1484: ifeq -> 1510
    //   1487: aload_0
    //   1488: getfield mResolvedDimensionRatioSide : I
    //   1491: istore #8
    //   1493: iload #8
    //   1495: ifeq -> 1504
    //   1498: iload #8
    //   1500: iconst_m1
    //   1501: if_icmpne -> 1510
    //   1504: iconst_1
    //   1505: istore #17
    //   1507: goto -> 1513
    //   1510: iconst_0
    //   1511: istore #17
    //   1513: iload #11
    //   1515: ifeq -> 1542
    //   1518: aload_0
    //   1519: getfield mResolvedDimensionRatioSide : I
    //   1522: istore #8
    //   1524: iload #8
    //   1526: iconst_1
    //   1527: if_icmpeq -> 1536
    //   1530: iload #8
    //   1532: iconst_m1
    //   1533: if_icmpne -> 1542
    //   1536: iconst_1
    //   1537: istore #16
    //   1539: goto -> 1545
    //   1542: iconst_0
    //   1543: istore #16
    //   1545: aload_0
    //   1546: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1549: iconst_0
    //   1550: aaload
    //   1551: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1554: if_acmpne -> 1570
    //   1557: aload_0
    //   1558: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1561: ifeq -> 1570
    //   1564: iconst_1
    //   1565: istore #18
    //   1567: goto -> 1573
    //   1570: iconst_0
    //   1571: istore #18
    //   1573: iload #18
    //   1575: ifeq -> 1584
    //   1578: iconst_0
    //   1579: istore #5
    //   1581: goto -> 1584
    //   1584: aload_0
    //   1585: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1588: invokevirtual isConnected : ()Z
    //   1591: iconst_1
    //   1592: ixor
    //   1593: istore #20
    //   1595: aload_0
    //   1596: getfield mIsInBarrier : [Z
    //   1599: astore #24
    //   1601: aload #24
    //   1603: iconst_0
    //   1604: baload
    //   1605: istore #22
    //   1607: aload #24
    //   1609: iconst_1
    //   1610: baload
    //   1611: istore #21
    //   1613: aload_0
    //   1614: getfield mHorizontalResolution : I
    //   1617: iconst_2
    //   1618: if_icmpeq -> 1953
    //   1621: aload_0
    //   1622: getfield resolvedHorizontal : Z
    //   1625: ifne -> 1953
    //   1628: iload_2
    //   1629: ifeq -> 1757
    //   1632: aload_0
    //   1633: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1636: astore #24
    //   1638: aload #24
    //   1640: ifnull -> 1757
    //   1643: aload #24
    //   1645: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1648: getfield resolved : Z
    //   1651: ifeq -> 1757
    //   1654: aload_0
    //   1655: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1658: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1661: getfield resolved : Z
    //   1664: ifne -> 1670
    //   1667: goto -> 1757
    //   1670: iload_2
    //   1671: ifeq -> 1953
    //   1674: aload_1
    //   1675: aload #28
    //   1677: aload_0
    //   1678: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1681: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1684: getfield value : I
    //   1687: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1690: aload_1
    //   1691: aload #27
    //   1693: aload_0
    //   1694: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1697: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1700: getfield value : I
    //   1703: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1706: aload_0
    //   1707: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1710: ifnull -> 1953
    //   1713: iload #14
    //   1715: ifeq -> 1953
    //   1718: aload_0
    //   1719: getfield isTerminalWidget : [Z
    //   1722: iconst_0
    //   1723: baload
    //   1724: ifeq -> 1953
    //   1727: aload_0
    //   1728: invokevirtual isInHorizontalChain : ()Z
    //   1731: ifne -> 1953
    //   1734: aload_1
    //   1735: aload_1
    //   1736: aload_0
    //   1737: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1740: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1743: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1746: aload #27
    //   1748: iconst_0
    //   1749: bipush #8
    //   1751: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1754: goto -> 1953
    //   1757: aload_0
    //   1758: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1761: astore #24
    //   1763: aload #24
    //   1765: ifnull -> 1782
    //   1768: aload_1
    //   1769: aload #24
    //   1771: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1774: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1777: astore #24
    //   1779: goto -> 1785
    //   1782: aconst_null
    //   1783: astore #24
    //   1785: aload_0
    //   1786: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1789: astore #25
    //   1791: aload #25
    //   1793: ifnull -> 1810
    //   1796: aload_1
    //   1797: aload #25
    //   1799: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1802: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1805: astore #25
    //   1807: goto -> 1813
    //   1810: aconst_null
    //   1811: astore #25
    //   1813: aload_0
    //   1814: getfield isTerminalWidget : [Z
    //   1817: iconst_0
    //   1818: baload
    //   1819: istore #23
    //   1821: aload_0
    //   1822: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1825: astore #31
    //   1827: aload #31
    //   1829: iconst_0
    //   1830: aaload
    //   1831: astore #32
    //   1833: aload_0
    //   1834: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1837: astore #33
    //   1839: aload_0
    //   1840: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1843: astore #34
    //   1845: aload_0
    //   1846: getfield mX : I
    //   1849: istore #8
    //   1851: aload_0
    //   1852: getfield mMinWidth : I
    //   1855: istore #9
    //   1857: aload_0
    //   1858: getfield mMaxDimension : [I
    //   1861: iconst_0
    //   1862: iaload
    //   1863: istore #10
    //   1865: aload_0
    //   1866: getfield mHorizontalBiasPercent : F
    //   1869: fstore_3
    //   1870: aload #31
    //   1872: iconst_1
    //   1873: aaload
    //   1874: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1877: if_acmpne -> 1886
    //   1880: iconst_1
    //   1881: istore #19
    //   1883: goto -> 1889
    //   1886: iconst_0
    //   1887: istore #19
    //   1889: aload_0
    //   1890: aload_1
    //   1891: iconst_1
    //   1892: iload #14
    //   1894: iload #12
    //   1896: iload #23
    //   1898: aload #25
    //   1900: aload #24
    //   1902: aload #32
    //   1904: iload #18
    //   1906: aload #33
    //   1908: aload #34
    //   1910: iload #8
    //   1912: iload #5
    //   1914: iload #9
    //   1916: iload #10
    //   1918: fload_3
    //   1919: iload #17
    //   1921: iload #19
    //   1923: iload #15
    //   1925: iload #13
    //   1927: iload #22
    //   1929: iload #7
    //   1931: iload #6
    //   1933: aload_0
    //   1934: getfield mMatchConstraintMinWidth : I
    //   1937: aload_0
    //   1938: getfield mMatchConstraintMaxWidth : I
    //   1941: aload_0
    //   1942: getfield mMatchConstraintPercentWidth : F
    //   1945: iload #20
    //   1947: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   1950: goto -> 1953
    //   1953: aload #30
    //   1955: astore #25
    //   1957: aload #29
    //   1959: astore #24
    //   1961: aload #27
    //   1963: astore #29
    //   1965: iload #12
    //   1967: istore #18
    //   1969: iload_2
    //   1970: ifeq -> 2149
    //   1973: aload_0
    //   1974: astore #27
    //   1976: aload #27
    //   1978: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1981: astore #30
    //   1983: aload #30
    //   1985: ifnull -> 2146
    //   1988: aload #30
    //   1990: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1993: getfield resolved : Z
    //   1996: ifeq -> 2146
    //   1999: aload #27
    //   2001: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   2004: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2007: getfield resolved : Z
    //   2010: ifeq -> 2146
    //   2013: aload #27
    //   2015: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   2018: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2021: getfield value : I
    //   2024: istore #5
    //   2026: aload_1
    //   2027: astore #30
    //   2029: aload #30
    //   2031: aload #25
    //   2033: iload #5
    //   2035: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   2038: aload #27
    //   2040: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   2043: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2046: getfield value : I
    //   2049: istore #5
    //   2051: aload #24
    //   2053: astore #31
    //   2055: aload #30
    //   2057: aload #31
    //   2059: iload #5
    //   2061: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   2064: aload #30
    //   2066: aload #26
    //   2068: aload #27
    //   2070: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   2073: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2076: getfield value : I
    //   2079: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   2082: aload #27
    //   2084: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2087: astore #32
    //   2089: aload #32
    //   2091: ifnull -> 2140
    //   2094: iload #13
    //   2096: ifne -> 2140
    //   2099: iload #18
    //   2101: ifeq -> 2140
    //   2104: aload #27
    //   2106: getfield isTerminalWidget : [Z
    //   2109: iconst_1
    //   2110: baload
    //   2111: ifeq -> 2137
    //   2114: aload #30
    //   2116: aload #30
    //   2118: aload #32
    //   2120: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2123: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2126: aload #31
    //   2128: iconst_0
    //   2129: bipush #8
    //   2131: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2134: goto -> 2140
    //   2137: goto -> 2140
    //   2140: iconst_0
    //   2141: istore #5
    //   2143: goto -> 2152
    //   2146: goto -> 2149
    //   2149: iconst_1
    //   2150: istore #5
    //   2152: aload_0
    //   2153: astore #30
    //   2155: aload_1
    //   2156: astore #31
    //   2158: aload #26
    //   2160: astore #32
    //   2162: aload #30
    //   2164: getfield mVerticalResolution : I
    //   2167: iconst_2
    //   2168: if_icmpne -> 2177
    //   2171: iconst_0
    //   2172: istore #5
    //   2174: goto -> 2177
    //   2177: iload #5
    //   2179: ifeq -> 2580
    //   2182: aload #30
    //   2184: getfield resolvedVertical : Z
    //   2187: ifne -> 2580
    //   2190: aload #30
    //   2192: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2195: iconst_1
    //   2196: aaload
    //   2197: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2200: if_acmpne -> 2216
    //   2203: aload #30
    //   2205: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   2208: ifeq -> 2216
    //   2211: iconst_1
    //   2212: istore_2
    //   2213: goto -> 2218
    //   2216: iconst_0
    //   2217: istore_2
    //   2218: iload_2
    //   2219: ifeq -> 2225
    //   2222: iconst_0
    //   2223: istore #4
    //   2225: aload #30
    //   2227: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2230: astore #26
    //   2232: aload #26
    //   2234: ifnull -> 2252
    //   2237: aload #31
    //   2239: aload #26
    //   2241: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2244: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2247: astore #26
    //   2249: goto -> 2255
    //   2252: aconst_null
    //   2253: astore #26
    //   2255: aload #30
    //   2257: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2260: astore #27
    //   2262: aload #27
    //   2264: ifnull -> 2282
    //   2267: aload #31
    //   2269: aload #27
    //   2271: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2274: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2277: astore #27
    //   2279: goto -> 2285
    //   2282: aconst_null
    //   2283: astore #27
    //   2285: aload #30
    //   2287: getfield mBaselineDistance : I
    //   2290: ifgt -> 2303
    //   2293: aload #30
    //   2295: getfield mVisibility : I
    //   2298: bipush #8
    //   2300: if_icmpne -> 2426
    //   2303: aload #30
    //   2305: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2308: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2311: ifnull -> 2384
    //   2314: aload #31
    //   2316: aload #32
    //   2318: aload #25
    //   2320: aload_0
    //   2321: invokevirtual getBaselineDistance : ()I
    //   2324: bipush #8
    //   2326: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2329: pop
    //   2330: aload #31
    //   2332: aload #32
    //   2334: aload #31
    //   2336: aload #30
    //   2338: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2341: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2344: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2347: iconst_0
    //   2348: bipush #8
    //   2350: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2353: pop
    //   2354: iload #18
    //   2356: ifeq -> 2378
    //   2359: aload #31
    //   2361: aload #26
    //   2363: aload #31
    //   2365: aload #30
    //   2367: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2370: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2373: iconst_0
    //   2374: iconst_5
    //   2375: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2378: iconst_0
    //   2379: istore #12
    //   2381: goto -> 2430
    //   2384: aload #30
    //   2386: getfield mVisibility : I
    //   2389: bipush #8
    //   2391: if_icmpne -> 2410
    //   2394: aload #31
    //   2396: aload #32
    //   2398: aload #25
    //   2400: iconst_0
    //   2401: bipush #8
    //   2403: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2406: pop
    //   2407: goto -> 2426
    //   2410: aload #31
    //   2412: aload #32
    //   2414: aload #25
    //   2416: aload_0
    //   2417: invokevirtual getBaselineDistance : ()I
    //   2420: bipush #8
    //   2422: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2425: pop
    //   2426: iload #20
    //   2428: istore #12
    //   2430: aload #30
    //   2432: getfield isTerminalWidget : [Z
    //   2435: iconst_1
    //   2436: baload
    //   2437: istore #19
    //   2439: aload #30
    //   2441: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2444: astore #31
    //   2446: aload #31
    //   2448: iconst_1
    //   2449: aaload
    //   2450: astore #32
    //   2452: aload #30
    //   2454: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2457: astore #33
    //   2459: aload #30
    //   2461: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2464: astore #34
    //   2466: aload #30
    //   2468: getfield mY : I
    //   2471: istore #5
    //   2473: aload #30
    //   2475: getfield mMinHeight : I
    //   2478: istore #8
    //   2480: aload #30
    //   2482: getfield mMaxDimension : [I
    //   2485: iconst_1
    //   2486: iaload
    //   2487: istore #9
    //   2489: aload #30
    //   2491: getfield mVerticalBiasPercent : F
    //   2494: fstore_3
    //   2495: aload #31
    //   2497: iconst_0
    //   2498: aaload
    //   2499: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2502: if_acmpne -> 2511
    //   2505: iconst_1
    //   2506: istore #17
    //   2508: goto -> 2514
    //   2511: iconst_0
    //   2512: istore #17
    //   2514: aload_0
    //   2515: aload_1
    //   2516: iconst_0
    //   2517: iload #18
    //   2519: iload #14
    //   2521: iload #19
    //   2523: aload #27
    //   2525: aload #26
    //   2527: aload #32
    //   2529: iload_2
    //   2530: aload #33
    //   2532: aload #34
    //   2534: iload #5
    //   2536: iload #4
    //   2538: iload #8
    //   2540: iload #9
    //   2542: fload_3
    //   2543: iload #16
    //   2545: iload #17
    //   2547: iload #13
    //   2549: iload #15
    //   2551: iload #21
    //   2553: iload #6
    //   2555: iload #7
    //   2557: aload #30
    //   2559: getfield mMatchConstraintMinHeight : I
    //   2562: aload #30
    //   2564: getfield mMatchConstraintMaxHeight : I
    //   2567: aload #30
    //   2569: getfield mMatchConstraintPercentHeight : F
    //   2572: iload #12
    //   2574: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2577: goto -> 2580
    //   2580: iload #11
    //   2582: ifeq -> 2641
    //   2585: aload_0
    //   2586: astore #26
    //   2588: aload #26
    //   2590: getfield mResolvedDimensionRatioSide : I
    //   2593: iconst_1
    //   2594: if_icmpne -> 2619
    //   2597: aload_1
    //   2598: aload #24
    //   2600: aload #25
    //   2602: aload #29
    //   2604: aload #28
    //   2606: aload #26
    //   2608: getfield mResolvedDimensionRatio : F
    //   2611: bipush #8
    //   2613: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2616: goto -> 2641
    //   2619: aload_1
    //   2620: aload #29
    //   2622: aload #28
    //   2624: aload #24
    //   2626: aload #25
    //   2628: aload #26
    //   2630: getfield mResolvedDimensionRatio : F
    //   2633: bipush #8
    //   2635: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2638: goto -> 2641
    //   2641: aload_0
    //   2642: astore #24
    //   2644: aload #24
    //   2646: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2649: invokevirtual isConnected : ()Z
    //   2652: ifeq -> 2694
    //   2655: aload_1
    //   2656: aload #24
    //   2658: aload #24
    //   2660: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2663: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2666: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2669: aload #24
    //   2671: getfield mCircleConstraintAngle : F
    //   2674: ldc_w 90.0
    //   2677: fadd
    //   2678: f2d
    //   2679: invokestatic toRadians : (D)D
    //   2682: d2f
    //   2683: aload #24
    //   2685: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2688: invokevirtual getMargin : ()I
    //   2691: invokevirtual addCenterPoint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   2694: aload #24
    //   2696: iconst_0
    //   2697: putfield resolvedHorizontal : Z
    //   2700: aload #24
    //   2702: iconst_0
    //   2703: putfield resolvedVertical : Z
    //   2706: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   4: if_acmpne -> 351
    //   7: aload_3
    //   8: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   11: if_acmpne -> 242
    //   14: aload_0
    //   15: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   18: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   21: astore_1
    //   22: aload_0
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   26: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   29: astore_3
    //   30: aload_0
    //   31: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   34: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   37: astore #6
    //   39: aload_0
    //   40: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   43: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   46: astore #7
    //   48: iconst_1
    //   49: istore #5
    //   51: aload_1
    //   52: ifnull -> 62
    //   55: aload_1
    //   56: invokevirtual isConnected : ()Z
    //   59: ifne -> 73
    //   62: aload_3
    //   63: ifnull -> 79
    //   66: aload_3
    //   67: invokevirtual isConnected : ()Z
    //   70: ifeq -> 79
    //   73: iconst_0
    //   74: istore #4
    //   76: goto -> 106
    //   79: aload_0
    //   80: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   83: aload_2
    //   84: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   87: iconst_0
    //   88: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   91: aload_0
    //   92: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   95: aload_2
    //   96: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   99: iconst_0
    //   100: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   103: iconst_1
    //   104: istore #4
    //   106: aload #6
    //   108: ifnull -> 119
    //   111: aload #6
    //   113: invokevirtual isConnected : ()Z
    //   116: ifne -> 132
    //   119: aload #7
    //   121: ifnull -> 138
    //   124: aload #7
    //   126: invokevirtual isConnected : ()Z
    //   129: ifeq -> 138
    //   132: iconst_0
    //   133: istore #5
    //   135: goto -> 162
    //   138: aload_0
    //   139: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   142: aload_2
    //   143: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   146: iconst_0
    //   147: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   150: aload_0
    //   151: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   154: aload_2
    //   155: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   158: iconst_0
    //   159: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   162: iload #4
    //   164: ifeq -> 192
    //   167: iload #5
    //   169: ifeq -> 192
    //   172: aload_0
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   176: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   179: aload_2
    //   180: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   183: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   186: iconst_0
    //   187: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   190: pop
    //   191: return
    //   192: iload #4
    //   194: ifeq -> 217
    //   197: aload_0
    //   198: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   201: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   204: aload_2
    //   205: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   208: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   211: iconst_0
    //   212: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   215: pop
    //   216: return
    //   217: iload #5
    //   219: ifeq -> 879
    //   222: aload_0
    //   223: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   226: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   229: aload_2
    //   230: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   233: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   236: iconst_0
    //   237: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   240: pop
    //   241: return
    //   242: aload_3
    //   243: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   246: if_acmpeq -> 311
    //   249: aload_3
    //   250: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   253: if_acmpne -> 259
    //   256: goto -> 311
    //   259: aload_3
    //   260: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   263: if_acmpeq -> 273
    //   266: aload_3
    //   267: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   270: if_acmpne -> 879
    //   273: aload_0
    //   274: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   277: aload_2
    //   278: aload_3
    //   279: iconst_0
    //   280: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   283: aload_0
    //   284: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   287: aload_2
    //   288: aload_3
    //   289: iconst_0
    //   290: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   293: aload_0
    //   294: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   297: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   300: aload_2
    //   301: aload_3
    //   302: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   305: iconst_0
    //   306: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   309: pop
    //   310: return
    //   311: aload_0
    //   312: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   315: aload_2
    //   316: aload_3
    //   317: iconst_0
    //   318: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   321: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   324: astore_1
    //   325: aload_0
    //   326: aload_1
    //   327: aload_2
    //   328: aload_3
    //   329: iconst_0
    //   330: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   333: aload_0
    //   334: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   337: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   340: aload_2
    //   341: aload_3
    //   342: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   345: iconst_0
    //   346: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   349: pop
    //   350: return
    //   351: aload_1
    //   352: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   355: if_acmpne -> 422
    //   358: aload_3
    //   359: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   362: if_acmpeq -> 372
    //   365: aload_3
    //   366: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   369: if_acmpne -> 422
    //   372: aload_0
    //   373: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   376: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   379: astore_1
    //   380: aload_2
    //   381: aload_3
    //   382: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   385: astore_2
    //   386: aload_0
    //   387: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   390: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   393: astore_3
    //   394: aload_1
    //   395: aload_2
    //   396: iconst_0
    //   397: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   400: pop
    //   401: aload_3
    //   402: aload_2
    //   403: iconst_0
    //   404: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   407: pop
    //   408: aload_0
    //   409: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   412: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   415: aload_2
    //   416: iconst_0
    //   417: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   420: pop
    //   421: return
    //   422: aload_1
    //   423: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   426: if_acmpne -> 489
    //   429: aload_3
    //   430: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   433: if_acmpeq -> 443
    //   436: aload_3
    //   437: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   440: if_acmpne -> 489
    //   443: aload_2
    //   444: aload_3
    //   445: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   448: astore_1
    //   449: aload_0
    //   450: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   453: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   456: aload_1
    //   457: iconst_0
    //   458: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   461: pop
    //   462: aload_0
    //   463: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   466: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   469: aload_1
    //   470: iconst_0
    //   471: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   474: pop
    //   475: aload_0
    //   476: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   479: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   482: aload_1
    //   483: iconst_0
    //   484: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   487: pop
    //   488: return
    //   489: aload_1
    //   490: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   493: if_acmpne -> 559
    //   496: aload_3
    //   497: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   500: if_acmpne -> 559
    //   503: aload_0
    //   504: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   507: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   510: aload_2
    //   511: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   514: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   517: iconst_0
    //   518: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   521: pop
    //   522: aload_0
    //   523: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   526: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   529: aload_2
    //   530: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   533: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   536: iconst_0
    //   537: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   540: pop
    //   541: aload_0
    //   542: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   545: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   548: aload_2
    //   549: aload_3
    //   550: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   553: iconst_0
    //   554: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   557: pop
    //   558: return
    //   559: aload_1
    //   560: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   563: if_acmpne -> 629
    //   566: aload_3
    //   567: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   570: if_acmpne -> 629
    //   573: aload_0
    //   574: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   577: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   580: aload_2
    //   581: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   584: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   587: iconst_0
    //   588: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   591: pop
    //   592: aload_0
    //   593: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   596: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   599: aload_2
    //   600: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   603: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   606: iconst_0
    //   607: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   610: pop
    //   611: aload_0
    //   612: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   615: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   618: aload_2
    //   619: aload_3
    //   620: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   623: iconst_0
    //   624: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   627: pop
    //   628: return
    //   629: aload_0
    //   630: aload_1
    //   631: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   634: astore #6
    //   636: aload_2
    //   637: aload_3
    //   638: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   641: astore_2
    //   642: aload #6
    //   644: aload_2
    //   645: invokevirtual isValidConnection : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)Z
    //   648: ifeq -> 879
    //   651: aload_1
    //   652: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   655: if_acmpne -> 696
    //   658: aload_0
    //   659: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   662: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   665: astore_1
    //   666: aload_0
    //   667: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   670: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   673: astore_3
    //   674: aload_1
    //   675: ifnull -> 682
    //   678: aload_1
    //   679: invokevirtual reset : ()V
    //   682: aload_3
    //   683: ifnull -> 690
    //   686: aload_3
    //   687: invokevirtual reset : ()V
    //   690: iconst_0
    //   691: istore #5
    //   693: goto -> 870
    //   696: aload_1
    //   697: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   700: if_acmpeq -> 794
    //   703: aload_1
    //   704: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   707: if_acmpne -> 713
    //   710: goto -> 794
    //   713: aload_1
    //   714: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   717: if_acmpeq -> 731
    //   720: iload #4
    //   722: istore #5
    //   724: aload_1
    //   725: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   728: if_acmpne -> 870
    //   731: aload_0
    //   732: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   735: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   738: astore_3
    //   739: aload_3
    //   740: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   743: aload_2
    //   744: if_acmpeq -> 751
    //   747: aload_3
    //   748: invokevirtual reset : ()V
    //   751: aload_0
    //   752: aload_1
    //   753: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   756: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   759: astore_1
    //   760: aload_0
    //   761: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   764: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   767: astore_3
    //   768: iload #4
    //   770: istore #5
    //   772: aload_3
    //   773: invokevirtual isConnected : ()Z
    //   776: ifeq -> 870
    //   779: aload_1
    //   780: invokevirtual reset : ()V
    //   783: aload_3
    //   784: invokevirtual reset : ()V
    //   787: iload #4
    //   789: istore #5
    //   791: goto -> 870
    //   794: aload_0
    //   795: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   798: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   801: astore_3
    //   802: aload_3
    //   803: ifnull -> 810
    //   806: aload_3
    //   807: invokevirtual reset : ()V
    //   810: aload_0
    //   811: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   814: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   817: astore_3
    //   818: aload_3
    //   819: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   822: aload_2
    //   823: if_acmpeq -> 830
    //   826: aload_3
    //   827: invokevirtual reset : ()V
    //   830: aload_0
    //   831: aload_1
    //   832: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   835: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   838: astore_1
    //   839: aload_0
    //   840: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   843: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   846: astore_3
    //   847: iload #4
    //   849: istore #5
    //   851: aload_3
    //   852: invokevirtual isConnected : ()Z
    //   855: ifeq -> 870
    //   858: aload_1
    //   859: invokevirtual reset : ()V
    //   862: aload_3
    //   863: invokevirtual reset : ()V
    //   866: iload #4
    //   868: istore #5
    //   870: aload #6
    //   872: aload_2
    //   873: iload #5
    //   875: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   878: pop
    //   879: return
    //   880: astore_1
    //   881: aload_1
    //   882: athrow
    // Exception table:
    //   from	to	target	type
    //   325	333	880	finally
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtuaLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    return (dimensionBehaviour1 == DimensionBehaviour.MATCH_CONSTRAINT && dimensionBehaviour2 == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (arrayOfDimensionBehaviour[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = bool2;
      if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt = this.mMaxDimension;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtuaLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
    paramInt1 = this.mWidth;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            return; 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt1 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt1 = 0; 
    this.mMatchConstraintMaxWidth = paramInt1;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && this.mMatchConstraintDefaultWidth == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtuaLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt1 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt1 = 0; 
    this.mMatchConstraintMaxHeight = paramInt1;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && this.mMatchConstraintDefaultHeight == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      if (this.mMatchConstraintMinWidth > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #7
    //   69: iload #6
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #7
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #6
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #6
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #7
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #7
    //   137: istore #5
    //   139: iload #7
    //   141: ldc 2147483647
    //   143: if_icmpne -> 157
    //   146: iconst_0
    //   147: istore_3
    //   148: iconst_0
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #6
    //   154: iconst_0
    //   155: istore #5
    //   157: iload #6
    //   159: iload_3
    //   160: isub
    //   161: istore #6
    //   163: iload #5
    //   165: iload #4
    //   167: isub
    //   168: istore #5
    //   170: iload #9
    //   172: ifeq -> 180
    //   175: aload_0
    //   176: iload_3
    //   177: putfield mX : I
    //   180: iload #8
    //   182: ifeq -> 191
    //   185: aload_0
    //   186: iload #4
    //   188: putfield mY : I
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 211
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield mWidth : I
    //   205: aload_0
    //   206: iconst_0
    //   207: putfield mHeight : I
    //   210: return
    //   211: iload #9
    //   213: ifeq -> 273
    //   216: iload #6
    //   218: istore_3
    //   219: aload_0
    //   220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   223: iconst_0
    //   224: aaload
    //   225: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield mWidth : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield mWidth : I
    //   255: aload_0
    //   256: getfield mMinWidth : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield mWidth : I
    //   273: iload #8
    //   275: ifeq -> 335
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: if_acmpne -> 312
    //   293: aload_0
    //   294: getfield mHeight : I
    //   297: istore #4
    //   299: iload #5
    //   301: istore_3
    //   302: iload #5
    //   304: iload #4
    //   306: if_icmpge -> 312
    //   309: iload #4
    //   311: istore_3
    //   312: aload_0
    //   313: iload_3
    //   314: putfield mHeight : I
    //   317: aload_0
    //   318: getfield mMinHeight : I
    //   321: istore #4
    //   323: iload_3
    //   324: iload #4
    //   326: if_icmpge -> 335
    //   329: aload_0
    //   330: iload #4
    //   332: putfield mHeight : I
    //   335: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 127
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore_1
    //   56: iload #4
    //   58: istore #5
    //   60: iload #6
    //   62: istore_3
    //   63: aload_1
    //   64: ifnull -> 127
    //   67: iload #4
    //   69: istore #5
    //   71: iload #6
    //   73: istore_3
    //   74: aload_1
    //   75: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   78: getfield resolved : Z
    //   81: ifeq -> 127
    //   84: iload #4
    //   86: istore #5
    //   88: iload #6
    //   90: istore_3
    //   91: aload_0
    //   92: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   95: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   98: getfield resolved : Z
    //   101: ifeq -> 127
    //   104: aload_0
    //   105: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   108: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   111: getfield value : I
    //   114: istore #5
    //   116: aload_0
    //   117: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   120: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   123: getfield value : I
    //   126: istore_3
    //   127: iload #7
    //   129: istore #6
    //   131: iload #8
    //   133: istore #4
    //   135: iload_2
    //   136: ifeq -> 219
    //   139: aload_0
    //   140: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   143: astore_1
    //   144: iload #7
    //   146: istore #6
    //   148: iload #8
    //   150: istore #4
    //   152: aload_1
    //   153: ifnull -> 219
    //   156: iload #7
    //   158: istore #6
    //   160: iload #8
    //   162: istore #4
    //   164: aload_1
    //   165: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   168: getfield resolved : Z
    //   171: ifeq -> 219
    //   174: iload #7
    //   176: istore #6
    //   178: iload #8
    //   180: istore #4
    //   182: aload_0
    //   183: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   186: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   189: getfield resolved : Z
    //   192: ifeq -> 219
    //   195: aload_0
    //   196: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   199: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   202: getfield value : I
    //   205: istore #6
    //   207: aload_0
    //   208: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   211: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   214: getfield value : I
    //   217: istore #4
    //   219: iload_3
    //   220: iload #5
    //   222: isub
    //   223: iflt -> 298
    //   226: iload #4
    //   228: iload #6
    //   230: isub
    //   231: iflt -> 298
    //   234: iload #5
    //   236: ldc_w -2147483648
    //   239: if_icmpeq -> 298
    //   242: iload #5
    //   244: ldc 2147483647
    //   246: if_icmpeq -> 298
    //   249: iload #6
    //   251: ldc_w -2147483648
    //   254: if_icmpeq -> 298
    //   257: iload #6
    //   259: ldc 2147483647
    //   261: if_icmpeq -> 298
    //   264: iload_3
    //   265: ldc_w -2147483648
    //   268: if_icmpeq -> 298
    //   271: iload_3
    //   272: ldc 2147483647
    //   274: if_icmpeq -> 298
    //   277: iload #4
    //   279: ldc_w -2147483648
    //   282: if_icmpeq -> 298
    //   285: iload_3
    //   286: istore #7
    //   288: iload #4
    //   290: istore_3
    //   291: iload #4
    //   293: ldc 2147483647
    //   295: if_icmpne -> 309
    //   298: iconst_0
    //   299: istore_3
    //   300: iconst_0
    //   301: istore #5
    //   303: iconst_0
    //   304: istore #6
    //   306: iconst_0
    //   307: istore #7
    //   309: aload_0
    //   310: iload #5
    //   312: iload #6
    //   314: iload #7
    //   316: iload_3
    //   317: invokevirtual setFrame : (IIII)V
    //   320: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour;
      $VALUES = new DimensionBehaviour[] { FIXED, WRAP_CONTENT, MATCH_CONSTRAINT, dimensionBehaviour };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tall Man Run-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */