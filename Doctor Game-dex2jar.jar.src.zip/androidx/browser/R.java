package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2130903042;
    
    public static final int browser_actions_divider_color = 2130903043;
    
    public static final int browser_actions_text_color = 2130903044;
    
    public static final int browser_actions_title_color = 2130903045;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2130968576;
    
    public static final int browser_actions_context_menu_min_padding = 2130968577;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131099693;
    
    public static final int browser_actions_menu_item_icon = 2131099694;
    
    public static final int browser_actions_menu_item_text = 2131099695;
    
    public static final int browser_actions_menu_items = 2131099696;
    
    public static final int browser_actions_menu_view = 2131099697;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131230720;
    
    public static final int browser_actions_context_menu_row = 2131230721;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131361817;
    
    public static final int fallback_menu_item_copy_link = 2131361818;
    
    public static final int fallback_menu_item_open_in_browser = 2131361819;
    
    public static final int fallback_menu_item_share_link = 2131361820;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2131558400;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */