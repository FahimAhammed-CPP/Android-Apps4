package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.StateSet;
import android.util.TypedValue;
import android.util.Xml;
import androidx.core.R;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class ColorStateListInflaterCompat {
  private static final ThreadLocal<TypedValue> sTempTypedValue = new ThreadLocal<TypedValue>();
  
  public static ColorStateList createFromXml(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return createFromXmlInner(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    XmlPullParserException xmlPullParserException = new XmlPullParserException("No start tag found");
    throw xmlPullParserException;
  }
  
  public static ColorStateList createFromXmlInner(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static TypedValue getTypedValue() {
    TypedValue typedValue2 = sTempTypedValue.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      sTempTypedValue.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList inflate(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    try {
      return createFromXml(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  private static ColorStateList inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int j = paramXmlPullParser.getDepth() + 1;
    int[][] arrayOfInt = new int[20][];
    int[] arrayOfInt1 = new int[20];
    int i = 0;
    while (true) {
      int k = paramXmlPullParser.next();
      if (k != 1) {
        int m = paramXmlPullParser.getDepth();
        if (m >= j || k != 3) {
          int[] arrayOfInt5 = arrayOfInt1;
          int[][] arrayOfInt4 = arrayOfInt;
          int n = i;
          if (k == 2) {
            arrayOfInt5 = arrayOfInt1;
            arrayOfInt4 = arrayOfInt;
            n = i;
            if (m <= j)
              if (!paramXmlPullParser.getName().equals("item")) {
                arrayOfInt5 = arrayOfInt1;
                arrayOfInt4 = arrayOfInt;
                n = i;
              } else {
                TypedArray typedArray = obtainAttributes(paramResources, paramTheme, paramAttributeSet, R.styleable.ColorStateListItem);
                n = typedArray.getResourceId(R.styleable.ColorStateListItem_android_color, -1);
                if (n != -1 && !isColorInt(paramResources, n)) {
                  try {
                    n = createFromXml(paramResources, (XmlPullParser)paramResources.getXml(n), paramTheme).getDefaultColor();
                  } catch (Exception exception) {
                    n = typedArray.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                  } 
                } else {
                  n = typedArray.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                } 
                float f = 1.0F;
                if (typedArray.hasValue(R.styleable.ColorStateListItem_android_alpha)) {
                  f = typedArray.getFloat(R.styleable.ColorStateListItem_android_alpha, 1.0F);
                } else if (typedArray.hasValue(R.styleable.ColorStateListItem_alpha)) {
                  f = typedArray.getFloat(R.styleable.ColorStateListItem_alpha, 1.0F);
                } 
                typedArray.recycle();
                int i1 = paramAttributeSet.getAttributeCount();
                int[] arrayOfInt6 = new int[i1];
                k = 0;
                for (m = 0; k < i1; m = i2) {
                  int i3 = paramAttributeSet.getAttributeNameResource(k);
                  int i2 = m;
                  if (i3 != 16843173) {
                    i2 = m;
                    if (i3 != 16843551) {
                      i2 = m;
                      if (i3 != R.attr.alpha) {
                        if (paramAttributeSet.getAttributeBooleanValue(k, false)) {
                          i2 = i3;
                        } else {
                          i2 = -i3;
                        } 
                        arrayOfInt6[m] = i2;
                        i2 = m + 1;
                      } 
                    } 
                  } 
                  k++;
                } 
                arrayOfInt6 = StateSet.trimStateSet(arrayOfInt6, m);
                arrayOfInt5 = GrowingArrayUtils.append(arrayOfInt1, i, modulateColorAlpha(n, f));
                arrayOfInt4 = GrowingArrayUtils.<int[]>append(arrayOfInt, i, arrayOfInt6);
                n = i + 1;
              }  
          } 
          arrayOfInt1 = arrayOfInt5;
          arrayOfInt = arrayOfInt4;
          i = n;
          continue;
        } 
      } 
      int[] arrayOfInt2 = new int[i];
      int[][] arrayOfInt3 = new int[i][];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
      System.arraycopy(arrayOfInt, 0, arrayOfInt3, 0, i);
      return new ColorStateList(arrayOfInt3, arrayOfInt2);
    } 
  }
  
  private static boolean isColorInt(Resources paramResources, int paramInt) {
    TypedValue typedValue = getTypedValue();
    paramResources.getValue(paramInt, typedValue, true);
    return (typedValue.type >= 28 && typedValue.type <= 31);
  }
  
  private static int modulateColorAlpha(int paramInt, float paramFloat) {
    return paramInt & 0xFFFFFF | Math.round(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  private static TypedArray obtainAttributes(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\core\content\res\ColorStateListInflaterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */