package androidx.core.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
  public void onAnimationCancel(View paramView) {}
  
  public void onAnimationEnd(View paramView) {}
  
  public void onAnimationStart(View paramView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\core\view\ViewPropertyAnimatorListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */