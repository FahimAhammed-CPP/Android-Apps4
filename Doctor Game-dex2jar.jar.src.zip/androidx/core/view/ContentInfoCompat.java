package androidx.core.view;

import android.content.ClipData;
import android.content.ClipDescription;
import android.net.Uri;
import android.os.Bundle;
import android.util.Pair;
import androidx.core.util.Preconditions;
import androidx.core.util.Predicate;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

public final class ContentInfoCompat {
  public static final int FLAG_CONVERT_TO_PLAIN_TEXT = 1;
  
  public static final int SOURCE_APP = 0;
  
  public static final int SOURCE_CLIPBOARD = 1;
  
  public static final int SOURCE_DRAG_AND_DROP = 3;
  
  public static final int SOURCE_INPUT_METHOD = 2;
  
  final ClipData mClip;
  
  final Bundle mExtras;
  
  final int mFlags;
  
  final Uri mLinkUri;
  
  final int mSource;
  
  ContentInfoCompat(Builder paramBuilder) {
    this.mClip = (ClipData)Preconditions.checkNotNull(paramBuilder.mClip);
    this.mSource = Preconditions.checkArgumentInRange(paramBuilder.mSource, 0, 3, "source");
    this.mFlags = Preconditions.checkFlagsArgument(paramBuilder.mFlags, 1);
    this.mLinkUri = paramBuilder.mLinkUri;
    this.mExtras = paramBuilder.mExtras;
  }
  
  private static ClipData buildClipData(ClipDescription paramClipDescription, List<ClipData.Item> paramList) {
    ClipData clipData = new ClipData(new ClipDescription(paramClipDescription), paramList.get(0));
    for (int i = 1; i < paramList.size(); i++)
      clipData.addItem(paramList.get(i)); 
    return clipData;
  }
  
  static String flagsToString(int paramInt) {
    return ((paramInt & 0x1) != 0) ? "FLAG_CONVERT_TO_PLAIN_TEXT" : String.valueOf(paramInt);
  }
  
  static String sourceToString(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? String.valueOf(paramInt) : "SOURCE_DRAG_AND_DROP") : "SOURCE_INPUT_METHOD") : "SOURCE_CLIPBOARD") : "SOURCE_APP";
  }
  
  public ClipData getClip() {
    return this.mClip;
  }
  
  public Bundle getExtras() {
    return this.mExtras;
  }
  
  public int getFlags() {
    return this.mFlags;
  }
  
  public Uri getLinkUri() {
    return this.mLinkUri;
  }
  
  public int getSource() {
    return this.mSource;
  }
  
  public Pair<ContentInfoCompat, ContentInfoCompat> partition(Predicate<ClipData.Item> paramPredicate) {
    int j = this.mClip.getItemCount();
    int i = 0;
    ContentInfoCompat contentInfoCompat = null;
    if (j == 1) {
      boolean bool = paramPredicate.test(this.mClip.getItemAt(0));
      if (bool) {
        ContentInfoCompat contentInfoCompat1 = this;
      } else {
        paramPredicate = null;
      } 
      if (!bool)
        contentInfoCompat = this; 
      return Pair.create(paramPredicate, contentInfoCompat);
    } 
    ArrayList<ClipData.Item> arrayList1 = new ArrayList();
    ArrayList<ClipData.Item> arrayList2 = new ArrayList();
    while (i < this.mClip.getItemCount()) {
      ClipData.Item item = this.mClip.getItemAt(i);
      if (paramPredicate.test(item)) {
        arrayList1.add(item);
      } else {
        arrayList2.add(item);
      } 
      i++;
    } 
    return arrayList1.isEmpty() ? Pair.create(null, this) : (arrayList2.isEmpty() ? Pair.create(this, null) : Pair.create((new Builder(this)).setClip(buildClipData(this.mClip.getDescription(), arrayList1)).build(), (new Builder(this)).setClip(buildClipData(this.mClip.getDescription(), arrayList2)).build()));
  }
  
  public String toString() {
    String str1;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ContentInfoCompat{clip=");
    stringBuilder.append(this.mClip.getDescription());
    stringBuilder.append(", source=");
    stringBuilder.append(sourceToString(this.mSource));
    stringBuilder.append(", flags=");
    stringBuilder.append(flagsToString(this.mFlags));
    Uri uri = this.mLinkUri;
    String str2 = "";
    if (uri == null) {
      str1 = "";
    } else {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(", hasLinkUri(");
      stringBuilder1.append(this.mLinkUri.toString().length());
      stringBuilder1.append(")");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    if (this.mExtras == null) {
      str1 = str2;
    } else {
      str1 = ", hasExtras";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static final class Builder {
    ClipData mClip;
    
    Bundle mExtras;
    
    int mFlags;
    
    Uri mLinkUri;
    
    int mSource;
    
    public Builder(ClipData param1ClipData, int param1Int) {
      this.mClip = param1ClipData;
      this.mSource = param1Int;
    }
    
    public Builder(ContentInfoCompat param1ContentInfoCompat) {
      this.mClip = param1ContentInfoCompat.mClip;
      this.mSource = param1ContentInfoCompat.mSource;
      this.mFlags = param1ContentInfoCompat.mFlags;
      this.mLinkUri = param1ContentInfoCompat.mLinkUri;
      this.mExtras = param1ContentInfoCompat.mExtras;
    }
    
    public ContentInfoCompat build() {
      return new ContentInfoCompat(this);
    }
    
    public Builder setClip(ClipData param1ClipData) {
      this.mClip = param1ClipData;
      return this;
    }
    
    public Builder setExtras(Bundle param1Bundle) {
      this.mExtras = param1Bundle;
      return this;
    }
    
    public Builder setFlags(int param1Int) {
      this.mFlags = param1Int;
      return this;
    }
    
    public Builder setLinkUri(Uri param1Uri) {
      this.mLinkUri = param1Uri;
      return this;
    }
    
    public Builder setSource(int param1Int) {
      this.mSource = param1Int;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Flags {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Source {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\core\view\ContentInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */