package androidx.core.view;

import android.view.View;

public interface NestedScrollingParent3 extends NestedScrollingParent2 {
  void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\core\view\NestedScrollingParent3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */