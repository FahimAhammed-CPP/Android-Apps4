package androidx.core.view.inputmethod;

import android.os.Build;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import androidx.core.util.Preconditions;

public final class EditorInfoCompat {
  private static final String CONTENT_MIME_TYPES_INTEROP_KEY = "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES";
  
  private static final String CONTENT_MIME_TYPES_KEY = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES";
  
  private static final String CONTENT_SELECTION_END_KEY = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END";
  
  private static final String CONTENT_SELECTION_HEAD_KEY = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD";
  
  private static final String CONTENT_SURROUNDING_TEXT_KEY = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT";
  
  private static final String[] EMPTY_STRING_ARRAY = new String[0];
  
  public static final int IME_FLAG_FORCE_ASCII = -2147483648;
  
  public static final int IME_FLAG_NO_PERSONALIZED_LEARNING = 16777216;
  
  static final int MAX_INITIAL_SELECTION_LENGTH = 1024;
  
  static final int MEMORY_EFFICIENT_TEXT_LENGTH = 2048;
  
  public static String[] getContentMimeTypes(EditorInfo paramEditorInfo) {
    String[] arrayOfString1;
    if (Build.VERSION.SDK_INT >= 25) {
      arrayOfString1 = paramEditorInfo.contentMimeTypes;
      return (arrayOfString1 != null) ? arrayOfString1 : EMPTY_STRING_ARRAY;
    } 
    if (((EditorInfo)arrayOfString1).extras == null)
      return EMPTY_STRING_ARRAY; 
    String[] arrayOfString3 = ((EditorInfo)arrayOfString1).extras.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
    String[] arrayOfString2 = arrayOfString3;
    if (arrayOfString3 == null)
      arrayOfString2 = ((EditorInfo)arrayOfString1).extras.getStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"); 
    return (arrayOfString2 != null) ? arrayOfString2 : EMPTY_STRING_ARRAY;
  }
  
  public static CharSequence getInitialSelectedText(EditorInfo paramEditorInfo, int paramInt) {
    int i;
    int j;
    if (Build.VERSION.SDK_INT >= 30)
      return Impl30.getInitialSelectedText(paramEditorInfo, paramInt); 
    if (paramEditorInfo.extras == null)
      return null; 
    if (paramEditorInfo.initialSelStart > paramEditorInfo.initialSelEnd) {
      i = paramEditorInfo.initialSelEnd;
    } else {
      i = paramEditorInfo.initialSelStart;
    } 
    if (paramEditorInfo.initialSelStart > paramEditorInfo.initialSelEnd) {
      j = paramEditorInfo.initialSelStart;
    } else {
      j = paramEditorInfo.initialSelEnd;
    } 
    int k = paramEditorInfo.extras.getInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD");
    int m = paramEditorInfo.extras.getInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END");
    if (paramEditorInfo.initialSelStart >= 0 && paramEditorInfo.initialSelEnd >= 0) {
      if (m - k != j - i)
        return null; 
      CharSequence charSequence = paramEditorInfo.extras.getCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT");
      return (charSequence == null) ? null : (((paramInt & 0x1) != 0) ? charSequence.subSequence(k, m) : TextUtils.substring(charSequence, k, m));
    } 
    return null;
  }
  
  public static CharSequence getInitialTextAfterCursor(EditorInfo paramEditorInfo, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 30)
      return Impl30.getInitialTextAfterCursor(paramEditorInfo, paramInt1, paramInt2); 
    if (paramEditorInfo.extras == null)
      return null; 
    CharSequence charSequence = paramEditorInfo.extras.getCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT");
    if (charSequence == null)
      return null; 
    int i = paramEditorInfo.extras.getInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END");
    paramInt1 = Math.min(paramInt1, charSequence.length() - i);
    return ((paramInt2 & 0x1) != 0) ? charSequence.subSequence(i, paramInt1 + i) : TextUtils.substring(charSequence, i, paramInt1 + i);
  }
  
  public static CharSequence getInitialTextBeforeCursor(EditorInfo paramEditorInfo, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 30)
      return Impl30.getInitialTextBeforeCursor(paramEditorInfo, paramInt1, paramInt2); 
    if (paramEditorInfo.extras == null)
      return null; 
    CharSequence charSequence = paramEditorInfo.extras.getCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT");
    if (charSequence == null)
      return null; 
    int i = paramEditorInfo.extras.getInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD");
    paramInt1 = Math.min(paramInt1, i);
    return ((paramInt2 & 0x1) != 0) ? charSequence.subSequence(i - paramInt1, i) : TextUtils.substring(charSequence, i - paramInt1, i);
  }
  
  static int getProtocol(EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT >= 25)
      return 1; 
    if (paramEditorInfo.extras == null)
      return 0; 
    boolean bool1 = paramEditorInfo.extras.containsKey("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
    boolean bool2 = paramEditorInfo.extras.containsKey("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
    return (bool1 && bool2) ? 4 : (bool1 ? 3 : (bool2 ? 2 : 0));
  }
  
  private static boolean isCutOnSurrogate(CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    return (paramInt2 != 0) ? ((paramInt2 != 1) ? false : Character.isHighSurrogate(paramCharSequence.charAt(paramInt1))) : Character.isLowSurrogate(paramCharSequence.charAt(paramInt1));
  }
  
  private static boolean isPasswordInputType(int paramInt) {
    paramInt &= 0xFFF;
    return (paramInt == 129 || paramInt == 225 || paramInt == 18);
  }
  
  public static void setContentMimeTypes(EditorInfo paramEditorInfo, String[] paramArrayOfString) {
    if (Build.VERSION.SDK_INT >= 25) {
      paramEditorInfo.contentMimeTypes = paramArrayOfString;
      return;
    } 
    if (paramEditorInfo.extras == null)
      paramEditorInfo.extras = new Bundle(); 
    paramEditorInfo.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", paramArrayOfString);
    paramEditorInfo.extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", paramArrayOfString);
  }
  
  public static void setInitialSurroundingSubText(EditorInfo paramEditorInfo, CharSequence paramCharSequence, int paramInt) {
    int i;
    Preconditions.checkNotNull(paramCharSequence);
    if (Build.VERSION.SDK_INT >= 30) {
      Impl30.setInitialSurroundingSubText(paramEditorInfo, paramCharSequence, paramInt);
      return;
    } 
    if (paramEditorInfo.initialSelStart > paramEditorInfo.initialSelEnd) {
      i = paramEditorInfo.initialSelEnd;
    } else {
      i = paramEditorInfo.initialSelStart;
    } 
    int j = i - paramInt;
    if (paramEditorInfo.initialSelStart > paramEditorInfo.initialSelEnd) {
      i = paramEditorInfo.initialSelStart;
    } else {
      i = paramEditorInfo.initialSelEnd;
    } 
    i -= paramInt;
    int k = paramCharSequence.length();
    if (paramInt < 0 || j < 0 || i > k) {
      setSurroundingText(paramEditorInfo, null, 0, 0);
      return;
    } 
    if (isPasswordInputType(paramEditorInfo.inputType)) {
      setSurroundingText(paramEditorInfo, null, 0, 0);
      return;
    } 
    if (k <= 2048) {
      setSurroundingText(paramEditorInfo, paramCharSequence, j, i);
      return;
    } 
    trimLongSurroundingText(paramEditorInfo, paramCharSequence, j, i);
  }
  
  public static void setInitialSurroundingText(EditorInfo paramEditorInfo, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 30) {
      Impl30.setInitialSurroundingSubText(paramEditorInfo, paramCharSequence, 0);
      return;
    } 
    setInitialSurroundingSubText(paramEditorInfo, paramCharSequence, 0);
  }
  
  private static void setSurroundingText(EditorInfo paramEditorInfo, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    if (paramEditorInfo.extras == null)
      paramEditorInfo.extras = new Bundle(); 
    if (paramCharSequence != null) {
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(paramCharSequence);
    } else {
      paramCharSequence = null;
    } 
    paramEditorInfo.extras.putCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT", paramCharSequence);
    paramEditorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD", paramInt1);
    paramEditorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END", paramInt2);
  }
  
  private static void trimLongSurroundingText(EditorInfo paramEditorInfo, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    int i;
    int m = paramInt2 - paramInt1;
    if (m > 1024) {
      i = 0;
    } else {
      i = m;
    } 
    int k = paramCharSequence.length();
    int j = 2048 - i;
    double d = j;
    Double.isNaN(d);
    int n = Math.min(k - paramInt2, j - Math.min(paramInt1, (int)(d * 0.8D)));
    k = Math.min(paramInt1, j - n);
    int i1 = paramInt1 - k;
    j = k;
    paramInt1 = i1;
    if (isCutOnSurrogate(paramCharSequence, i1, 0)) {
      paramInt1 = i1 + 1;
      j = k - 1;
    } 
    k = n;
    if (isCutOnSurrogate(paramCharSequence, paramInt2 + n - 1, 1))
      k = n - 1; 
    if (i != m) {
      paramCharSequence = TextUtils.concat(new CharSequence[] { paramCharSequence.subSequence(paramInt1, paramInt1 + j), paramCharSequence.subSequence(paramInt2, k + paramInt2) });
    } else {
      paramCharSequence = paramCharSequence.subSequence(paramInt1, j + i + k + paramInt1);
    } 
    paramInt1 = j + 0;
    setSurroundingText(paramEditorInfo, paramCharSequence, paramInt1, i + paramInt1);
  }
  
  private static class Impl30 {
    static CharSequence getInitialSelectedText(EditorInfo param1EditorInfo, int param1Int) {
      return param1EditorInfo.getInitialSelectedText(param1Int);
    }
    
    static CharSequence getInitialTextAfterCursor(EditorInfo param1EditorInfo, int param1Int1, int param1Int2) {
      return param1EditorInfo.getInitialTextAfterCursor(param1Int1, param1Int2);
    }
    
    static CharSequence getInitialTextBeforeCursor(EditorInfo param1EditorInfo, int param1Int1, int param1Int2) {
      return param1EditorInfo.getInitialTextBeforeCursor(param1Int1, param1Int2);
    }
    
    static void setInitialSurroundingSubText(EditorInfo param1EditorInfo, CharSequence param1CharSequence, int param1Int) {
      param1EditorInfo.setInitialSurroundingSubText(param1CharSequence, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\core\view\inputmethod\EditorInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */