package androidx.lifecycle;

import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.arch.core.internal.FastSafeIterableMap;
import androidx.arch.core.internal.SafeIterableMap;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class LifecycleRegistry extends Lifecycle {
  private int mAddingObserverCounter = 0;
  
  private final boolean mEnforceMainThread;
  
  private boolean mHandlingEvent = false;
  
  private final WeakReference<LifecycleOwner> mLifecycleOwner;
  
  private boolean mNewEventOccurred = false;
  
  private FastSafeIterableMap<LifecycleObserver, ObserverWithState> mObserverMap = new FastSafeIterableMap();
  
  private ArrayList<Lifecycle.State> mParentStates = new ArrayList<Lifecycle.State>();
  
  private Lifecycle.State mState;
  
  public LifecycleRegistry(LifecycleOwner paramLifecycleOwner) {
    this(paramLifecycleOwner, true);
  }
  
  private LifecycleRegistry(LifecycleOwner paramLifecycleOwner, boolean paramBoolean) {
    this.mLifecycleOwner = new WeakReference<LifecycleOwner>(paramLifecycleOwner);
    this.mState = Lifecycle.State.INITIALIZED;
    this.mEnforceMainThread = paramBoolean;
  }
  
  private void backwardPass(LifecycleOwner paramLifecycleOwner) {
    Iterator<Map.Entry> iterator = this.mObserverMap.descendingIterator();
    while (iterator.hasNext() && !this.mNewEventOccurred) {
      Map.Entry entry = iterator.next();
      ObserverWithState observerWithState = (ObserverWithState)entry.getValue();
      while (observerWithState.mState.compareTo(this.mState) > 0 && !this.mNewEventOccurred && this.mObserverMap.contains(entry.getKey())) {
        Lifecycle.Event event = Lifecycle.Event.downFrom(observerWithState.mState);
        if (event != null) {
          pushParentState(event.getTargetState());
          observerWithState.dispatchEvent(paramLifecycleOwner, event);
          popParentState();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(observerWithState.mState);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private Lifecycle.State calculateTargetState(LifecycleObserver paramLifecycleObserver) {
    Lifecycle.State state;
    Map.Entry entry = this.mObserverMap.ceil(paramLifecycleObserver);
    ArrayList<Lifecycle.State> arrayList = null;
    if (entry != null) {
      Lifecycle.State state1 = ((ObserverWithState)entry.getValue()).mState;
    } else {
      entry = null;
    } 
    if (!this.mParentStates.isEmpty()) {
      arrayList = this.mParentStates;
      state = arrayList.get(arrayList.size() - 1);
    } 
    return min(min(this.mState, (Lifecycle.State)entry), state);
  }
  
  public static LifecycleRegistry createUnsafe(LifecycleOwner paramLifecycleOwner) {
    return new LifecycleRegistry(paramLifecycleOwner, false);
  }
  
  private void enforceMainThreadIfNeeded(String paramString) {
    if (this.mEnforceMainThread) {
      if (ArchTaskExecutor.getInstance().isMainThread())
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Method ");
      stringBuilder.append(paramString);
      stringBuilder.append(" must be called on the main thread");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private void forwardPass(LifecycleOwner paramLifecycleOwner) {
    SafeIterableMap.IteratorWithAdditions<Map.Entry> iteratorWithAdditions = this.mObserverMap.iteratorWithAdditions();
    while (iteratorWithAdditions.hasNext() && !this.mNewEventOccurred) {
      Map.Entry entry = iteratorWithAdditions.next();
      ObserverWithState observerWithState = (ObserverWithState)entry.getValue();
      while (observerWithState.mState.compareTo(this.mState) < 0 && !this.mNewEventOccurred && this.mObserverMap.contains(entry.getKey())) {
        pushParentState(observerWithState.mState);
        Lifecycle.Event event = Lifecycle.Event.upFrom(observerWithState.mState);
        if (event != null) {
          observerWithState.dispatchEvent(paramLifecycleOwner, event);
          popParentState();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(observerWithState.mState);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private boolean isSynced() {
    if (this.mObserverMap.size() == 0)
      return true; 
    Lifecycle.State state1 = ((ObserverWithState)this.mObserverMap.eldest().getValue()).mState;
    Lifecycle.State state2 = ((ObserverWithState)this.mObserverMap.newest().getValue()).mState;
    return (state1 == state2 && this.mState == state2);
  }
  
  static Lifecycle.State min(Lifecycle.State paramState1, Lifecycle.State paramState2) {
    Lifecycle.State state = paramState1;
    if (paramState2 != null) {
      state = paramState1;
      if (paramState2.compareTo(paramState1) < 0)
        state = paramState2; 
    } 
    return state;
  }
  
  private void moveToState(Lifecycle.State paramState) {
    if (this.mState == paramState)
      return; 
    this.mState = paramState;
    if (this.mHandlingEvent || this.mAddingObserverCounter != 0) {
      this.mNewEventOccurred = true;
      return;
    } 
    this.mHandlingEvent = true;
    sync();
    this.mHandlingEvent = false;
  }
  
  private void popParentState() {
    ArrayList<Lifecycle.State> arrayList = this.mParentStates;
    arrayList.remove(arrayList.size() - 1);
  }
  
  private void pushParentState(Lifecycle.State paramState) {
    this.mParentStates.add(paramState);
  }
  
  private void sync() {
    LifecycleOwner lifecycleOwner = this.mLifecycleOwner.get();
    if (lifecycleOwner != null) {
      while (!isSynced()) {
        this.mNewEventOccurred = false;
        if (this.mState.compareTo(((ObserverWithState)this.mObserverMap.eldest().getValue()).mState) < 0)
          backwardPass(lifecycleOwner); 
        Map.Entry entry = this.mObserverMap.newest();
        if (!this.mNewEventOccurred && entry != null && this.mState.compareTo(((ObserverWithState)entry.getValue()).mState) > 0)
          forwardPass(lifecycleOwner); 
      } 
      this.mNewEventOccurred = false;
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
    throw illegalStateException;
  }
  
  public void addObserver(LifecycleObserver paramLifecycleObserver) {
    boolean bool;
    enforceMainThreadIfNeeded("addObserver");
    if (this.mState == Lifecycle.State.DESTROYED) {
      state = Lifecycle.State.DESTROYED;
    } else {
      state = Lifecycle.State.INITIALIZED;
    } 
    ObserverWithState observerWithState = new ObserverWithState(paramLifecycleObserver, state);
    if ((ObserverWithState)this.mObserverMap.putIfAbsent(paramLifecycleObserver, observerWithState) != null)
      return; 
    LifecycleOwner lifecycleOwner = this.mLifecycleOwner.get();
    if (lifecycleOwner == null)
      return; 
    if (this.mAddingObserverCounter != 0 || this.mHandlingEvent) {
      bool = true;
    } else {
      bool = false;
    } 
    Lifecycle.State state = calculateTargetState(paramLifecycleObserver);
    this.mAddingObserverCounter++;
    while (observerWithState.mState.compareTo(state) < 0 && this.mObserverMap.contains(paramLifecycleObserver)) {
      pushParentState(observerWithState.mState);
      Lifecycle.Event event = Lifecycle.Event.upFrom(observerWithState.mState);
      if (event != null) {
        observerWithState.dispatchEvent(lifecycleOwner, event);
        popParentState();
        Lifecycle.State state1 = calculateTargetState(paramLifecycleObserver);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(observerWithState.mState);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      sync(); 
    this.mAddingObserverCounter--;
  }
  
  public Lifecycle.State getCurrentState() {
    return this.mState;
  }
  
  public int getObserverCount() {
    enforceMainThreadIfNeeded("getObserverCount");
    return this.mObserverMap.size();
  }
  
  public void handleLifecycleEvent(Lifecycle.Event paramEvent) {
    enforceMainThreadIfNeeded("handleLifecycleEvent");
    moveToState(paramEvent.getTargetState());
  }
  
  @Deprecated
  public void markState(Lifecycle.State paramState) {
    enforceMainThreadIfNeeded("markState");
    setCurrentState(paramState);
  }
  
  public void removeObserver(LifecycleObserver paramLifecycleObserver) {
    enforceMainThreadIfNeeded("removeObserver");
    this.mObserverMap.remove(paramLifecycleObserver);
  }
  
  public void setCurrentState(Lifecycle.State paramState) {
    enforceMainThreadIfNeeded("setCurrentState");
    moveToState(paramState);
  }
  
  static class ObserverWithState {
    LifecycleEventObserver mLifecycleObserver;
    
    Lifecycle.State mState;
    
    ObserverWithState(LifecycleObserver param1LifecycleObserver, Lifecycle.State param1State) {
      this.mLifecycleObserver = Lifecycling.lifecycleEventObserver(param1LifecycleObserver);
      this.mState = param1State;
    }
    
    void dispatchEvent(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      Lifecycle.State state = param1Event.getTargetState();
      this.mState = LifecycleRegistry.min(this.mState, state);
      this.mLifecycleObserver.onStateChanged(param1LifecycleOwner, param1Event);
      this.mState = state;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\lifecycle\LifecycleRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */