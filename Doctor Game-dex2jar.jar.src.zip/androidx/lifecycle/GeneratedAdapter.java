package androidx.lifecycle;

public interface GeneratedAdapter {
  void callMethods(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent, boolean paramBoolean, MethodCallsLogger paramMethodCallsLogger);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\lifecycle\GeneratedAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */