package androidx.lifecycle;

public interface ViewModelStoreOwner {
  ViewModelStore getViewModelStore();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\lifecycle\ViewModelStoreOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */