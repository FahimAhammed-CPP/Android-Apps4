package androidx.lifecycle;

import android.view.View;
import android.view.ViewParent;
import androidx.lifecycle.runtime.R;

public class ViewTreeLifecycleOwner {
  public static LifecycleOwner get(View paramView) {
    LifecycleOwner lifecycleOwner2 = (LifecycleOwner)paramView.getTag(R.id.view_tree_lifecycle_owner);
    if (lifecycleOwner2 != null)
      return lifecycleOwner2; 
    ViewParent viewParent = paramView.getParent();
    LifecycleOwner lifecycleOwner1 = lifecycleOwner2;
    while (lifecycleOwner1 == null && viewParent instanceof View) {
      View view = (View)viewParent;
      lifecycleOwner1 = (LifecycleOwner)view.getTag(R.id.view_tree_lifecycle_owner);
      ViewParent viewParent1 = view.getParent();
    } 
    return lifecycleOwner1;
  }
  
  public static void set(View paramView, LifecycleOwner paramLifecycleOwner) {
    paramView.setTag(R.id.view_tree_lifecycle_owner, paramLifecycleOwner);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\androidx\lifecycle\ViewTreeLifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */