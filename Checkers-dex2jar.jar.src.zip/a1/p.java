package a1;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import javax.annotation.CheckForNull;

public abstract class p extends AbstractCollection implements Serializable {
  public static final Object[] i = new Object[0];
  
  @Deprecated
  public final boolean add(Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(Collection paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  public abstract int b(Object[] paramArrayOfObject);
  
  int c() {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void clear() {
    throw new UnsupportedOperationException();
  }
  
  int d() {
    throw new UnsupportedOperationException();
  }
  
  @CheckForNull
  public Object[] f() {
    return null;
  }
  
  @Deprecated
  public final boolean remove(@CheckForNull Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean removeAll(Collection paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean retainAll(Collection paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  public final Object[] toArray() {
    return toArray(i);
  }
  
  public final Object[] toArray(Object[] paramArrayOfObject) {
    Object[] arrayOfObject;
    paramArrayOfObject.getClass();
    int i = size();
    int j = paramArrayOfObject.length;
    if (j < i) {
      arrayOfObject = f();
      if (arrayOfObject == null) {
        arrayOfObject = (Object[])Array.newInstance(paramArrayOfObject.getClass().getComponentType(), i);
      } else {
        return Arrays.copyOfRange(arrayOfObject, d(), c(), (Class)paramArrayOfObject.getClass());
      } 
    } else {
      arrayOfObject = paramArrayOfObject;
      if (j > i) {
        paramArrayOfObject[i] = null;
        arrayOfObject = paramArrayOfObject;
      } 
    } 
    b(arrayOfObject);
    return arrayOfObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */