package a1;

import android.os.Parcel;
import android.os.Parcelable;

public final class n {
  static {
    n.class.getClassLoader();
  }
  
  public static Parcelable a(Parcel paramParcel, Parcelable.Creator paramCreator) {
    return (paramParcel.readInt() == 0) ? null : (Parcelable)paramCreator.createFromParcel(paramParcel);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */