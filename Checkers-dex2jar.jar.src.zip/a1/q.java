package a1;

import java.util.NoSuchElementException;
import t0.b;

public final class q extends h {
  public final int i;
  
  public int j;
  
  public final s k;
  
  public q(s params, int paramInt) {
    b.t(paramInt, i);
    this.i = i;
    this.j = paramInt;
    this.k = params;
  }
  
  public final boolean b() {
    return (this.j < this.i);
  }
  
  public final boolean c() {
    return (this.j > 0);
  }
  
  public final Object d() {
    if (b()) {
      int i = this.j;
      this.j = i + 1;
      return this.k.get(i);
    } 
    throw new NoSuchElementException();
  }
  
  public final Object e() {
    if (c()) {
      int i = this.j - 1;
      this.j = i;
      return this.k.get(i);
    } 
    throw new NoSuchElementException();
  }
  
  public final int nextIndex() {
    return this.j;
  }
  
  public final int previousIndex() {
    return this.j - 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */