package a1;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.CheckForNull;

public final class o {
  public static String a(@CheckForNull String paramString, @CheckForNull Object... paramVarArgs) {
    int j = 0;
    int i = 0;
    while (true) {
      int k = paramVarArgs.length;
      if (i < k) {
        String str;
        Object object = paramVarArgs[i];
        if (object == null) {
          str = "null";
        } else {
          try {
            str = object.toString();
          } catch (Exception exception) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(object.getClass().getName());
            stringBuilder1.append('@');
            stringBuilder1.append(Integer.toHexString(System.identityHashCode(object)));
            object = stringBuilder1.toString();
            Logger.getLogger("com.google.common.base.Strings").logp(Level.WARNING, "com.google.common.base.Strings", "lenientToString", "Exception during lenientFormat for ".concat((String)object), exception);
            stringBuilder1 = new StringBuilder();
            stringBuilder1.append("<");
            stringBuilder1.append((String)object);
            stringBuilder1.append(" threw ");
            stringBuilder1.append(exception.getClass().getName());
            stringBuilder1.append(">");
            str = stringBuilder1.toString();
          } 
        } 
        paramVarArgs[i] = str;
        i++;
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder(paramString.length() + k * 16);
      k = 0;
      i = j;
      while (true) {
        j = paramVarArgs.length;
        if (i < j) {
          int m = paramString.indexOf("%s", k);
          if (m == -1)
            break; 
          stringBuilder.append(paramString, k, m);
          stringBuilder.append(paramVarArgs[i]);
          k = m + 2;
          i++;
          continue;
        } 
        break;
      } 
      stringBuilder.append(paramString, k, paramString.length());
      if (i < j) {
        stringBuilder.append(" [");
        k = i + 1;
        stringBuilder.append(paramVarArgs[i]);
        for (i = k; i < paramVarArgs.length; i++) {
          stringBuilder.append(", ");
          stringBuilder.append(paramVarArgs[i]);
        } 
        stringBuilder.append(']');
      } 
      return stringBuilder.toString();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */