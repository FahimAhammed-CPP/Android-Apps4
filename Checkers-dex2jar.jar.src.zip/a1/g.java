package a1;

import javax.annotation.CheckForNull;

public final class g extends u {
  public static final g o = new g(null, new Object[0], 0);
  
  @CheckForNull
  public final transient Object l;
  
  public final transient Object[] m;
  
  public final transient int n;
  
  public g(@CheckForNull Object paramObject, Object[] paramArrayOfObject, int paramInt) {
    this.l = paramObject;
    this.m = paramArrayOfObject;
    this.n = paramInt;
  }
  
  @CheckForNull
  public final Object get(@CheckForNull Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield l : Ljava/lang/Object;
    //   4: astore #6
    //   6: aload_0
    //   7: getfield m : [Ljava/lang/Object;
    //   10: astore #5
    //   12: aload_0
    //   13: getfield n : I
    //   16: istore_2
    //   17: aload_1
    //   18: ifnonnull -> 26
    //   21: aconst_null
    //   22: astore_1
    //   23: goto -> 297
    //   26: iload_2
    //   27: iconst_1
    //   28: if_icmpne -> 65
    //   31: aload #5
    //   33: iconst_0
    //   34: aaload
    //   35: astore #6
    //   37: aload #6
    //   39: invokevirtual getClass : ()Ljava/lang/Class;
    //   42: pop
    //   43: aload #6
    //   45: aload_1
    //   46: invokevirtual equals : (Ljava/lang/Object;)Z
    //   49: ifeq -> 21
    //   52: aload #5
    //   54: iconst_1
    //   55: aaload
    //   56: astore_1
    //   57: aload_1
    //   58: invokevirtual getClass : ()Ljava/lang/Class;
    //   61: pop
    //   62: goto -> 297
    //   65: aload #6
    //   67: ifnonnull -> 73
    //   70: goto -> 21
    //   73: aload #6
    //   75: instanceof [B
    //   78: ifeq -> 157
    //   81: aload #6
    //   83: checkcast [B
    //   86: astore #6
    //   88: aload #6
    //   90: arraylength
    //   91: istore_3
    //   92: aload_1
    //   93: invokevirtual hashCode : ()I
    //   96: invokestatic r : (I)I
    //   99: istore_2
    //   100: iload_2
    //   101: iload_3
    //   102: iconst_1
    //   103: isub
    //   104: iand
    //   105: istore_2
    //   106: aload #6
    //   108: iload_2
    //   109: baload
    //   110: sipush #255
    //   113: iand
    //   114: istore #4
    //   116: iload #4
    //   118: sipush #255
    //   121: if_icmpne -> 127
    //   124: goto -> 21
    //   127: aload_1
    //   128: aload #5
    //   130: iload #4
    //   132: aaload
    //   133: invokevirtual equals : (Ljava/lang/Object;)Z
    //   136: ifeq -> 150
    //   139: aload #5
    //   141: iload #4
    //   143: iconst_1
    //   144: ixor
    //   145: aaload
    //   146: astore_1
    //   147: goto -> 297
    //   150: iload_2
    //   151: iconst_1
    //   152: iadd
    //   153: istore_2
    //   154: goto -> 100
    //   157: aload #6
    //   159: instanceof [S
    //   162: ifeq -> 237
    //   165: aload #6
    //   167: checkcast [S
    //   170: astore #6
    //   172: aload #6
    //   174: arraylength
    //   175: istore_3
    //   176: aload_1
    //   177: invokevirtual hashCode : ()I
    //   180: invokestatic r : (I)I
    //   183: istore_2
    //   184: iload_2
    //   185: iload_3
    //   186: iconst_1
    //   187: isub
    //   188: iand
    //   189: istore_2
    //   190: aload #6
    //   192: iload_2
    //   193: saload
    //   194: i2c
    //   195: istore #4
    //   197: iload #4
    //   199: ldc 65535
    //   201: if_icmpne -> 207
    //   204: goto -> 21
    //   207: aload_1
    //   208: aload #5
    //   210: iload #4
    //   212: aaload
    //   213: invokevirtual equals : (Ljava/lang/Object;)Z
    //   216: ifeq -> 230
    //   219: aload #5
    //   221: iload #4
    //   223: iconst_1
    //   224: ixor
    //   225: aaload
    //   226: astore_1
    //   227: goto -> 297
    //   230: iload_2
    //   231: iconst_1
    //   232: iadd
    //   233: istore_2
    //   234: goto -> 184
    //   237: aload #6
    //   239: checkcast [I
    //   242: astore #6
    //   244: aload #6
    //   246: arraylength
    //   247: istore_3
    //   248: aload_1
    //   249: invokevirtual hashCode : ()I
    //   252: invokestatic r : (I)I
    //   255: istore_2
    //   256: iload_2
    //   257: iload_3
    //   258: iconst_1
    //   259: isub
    //   260: iand
    //   261: istore_2
    //   262: aload #6
    //   264: iload_2
    //   265: iaload
    //   266: istore #4
    //   268: iload #4
    //   270: iconst_m1
    //   271: if_icmpne -> 277
    //   274: goto -> 21
    //   277: aload_1
    //   278: aload #5
    //   280: iload #4
    //   282: aaload
    //   283: invokevirtual equals : (Ljava/lang/Object;)Z
    //   286: ifeq -> 305
    //   289: aload #5
    //   291: iload #4
    //   293: iconst_1
    //   294: ixor
    //   295: aaload
    //   296: astore_1
    //   297: aload_1
    //   298: ifnonnull -> 303
    //   301: aconst_null
    //   302: areturn
    //   303: aload_1
    //   304: areturn
    //   305: iload_2
    //   306: iconst_1
    //   307: iadd
    //   308: istore_2
    //   309: goto -> 256
  }
  
  public final int size() {
    return this.n;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */