package a1;

import androidx.lifecycle.a;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.annotation.CheckForNull;

public abstract class u implements Map, Serializable {
  @CheckForNull
  public transient d i;
  
  @CheckForNull
  public transient e j;
  
  @CheckForNull
  public transient f k;
  
  @Deprecated
  public final void clear() {
    throw new UnsupportedOperationException();
  }
  
  public final boolean containsKey(@CheckForNull Object paramObject) {
    return (get(paramObject) != null);
  }
  
  public final boolean containsValue(@CheckForNull Object paramObject) {
    f f2 = this.k;
    f f1 = f2;
    if (f2 == null) {
      g g = (g)this;
      f1 = new f(g.m, 1, g.n);
      this.k = f1;
    } 
    return f1.contains(paramObject);
  }
  
  public final Set entrySet() {
    d d2 = this.i;
    d d1 = d2;
    if (d2 == null) {
      g g = (g)this;
      d1 = new d(g, g.m, g.n);
      this.i = d1;
    } 
    return d1;
  }
  
  public final boolean equals(@CheckForNull Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Map))
      return false; 
    paramObject = paramObject;
    return entrySet().equals(paramObject.entrySet());
  }
  
  @CheckForNull
  public abstract Object get(@CheckForNull Object paramObject);
  
  @CheckForNull
  public final Object getOrDefault(@CheckForNull Object paramObject1, @CheckForNull Object paramObject2) {
    paramObject1 = get(paramObject1);
    return (paramObject1 != null) ? paramObject1 : paramObject2;
  }
  
  public final int hashCode() {
    d d2 = this.i;
    d d1 = d2;
    if (d2 == null) {
      g g = (g)this;
      d1 = new d(g, g.m, g.n);
      this.i = d1;
    } 
    Iterator iterator = d1.iterator();
    int i = 0;
    while (true) {
      q q = (q)iterator;
      if (q.hasNext()) {
        byte b;
        q = q.next();
        if (q != null) {
          b = q.hashCode();
        } else {
          b = 0;
        } 
        i += b;
        continue;
      } 
      return i;
    } 
  }
  
  public final boolean isEmpty() {
    return (((g)this).n == 0);
  }
  
  public final Set keySet() {
    e e1 = this.j;
    if (e1 == null) {
      g g = (g)this;
      e1 = new e(g, new f(g.m, 0, g.n));
      this.j = e1;
      return e1;
    } 
    return e1;
  }
  
  @Deprecated
  @CheckForNull
  public final Object put(Object paramObject1, Object paramObject2) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void putAll(Map paramMap) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  @CheckForNull
  public final Object remove(@CheckForNull Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  public final String toString() {
    int i = ((g)this).n;
    if (i >= 0) {
      StringBuilder stringBuilder = new StringBuilder((int)Math.min(i * 8L, 1073741824L));
      stringBuilder.append('{');
      Iterator<Map.Entry> iterator = ((d)entrySet()).iterator();
      for (i = 1; iterator.hasNext(); i = 0) {
        Map.Entry entry = iterator.next();
        if (i == 0)
          stringBuilder.append(", "); 
        stringBuilder.append(entry.getKey());
        stringBuilder.append('=');
        stringBuilder.append(entry.getValue());
      } 
      stringBuilder.append('}');
      return stringBuilder.toString();
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException(a.b("size cannot be negative but was: ", i));
    throw illegalArgumentException;
  }
  
  public final Collection values() {
    f f2 = this.k;
    f f1 = f2;
    if (f2 == null) {
      g g = (g)this;
      f1 = new f(g.m, 1, g.n);
      this.k = f1;
    } 
    return f1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */