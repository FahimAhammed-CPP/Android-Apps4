package a1;

import java.util.Iterator;
import javax.annotation.CheckForNull;

public final class e extends v {
  public final transient u k;
  
  public final transient s l;
  
  public e(u paramu, f paramf) {
    this.k = paramu;
    this.l = paramf;
  }
  
  public final int b(Object[] paramArrayOfObject) {
    return this.l.b(paramArrayOfObject);
  }
  
  public final boolean contains(@CheckForNull Object paramObject) {
    return (this.k.get(paramObject) != null);
  }
  
  public final s h() {
    return this.l;
  }
  
  public final int size() {
    return ((g)this.k).n;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */