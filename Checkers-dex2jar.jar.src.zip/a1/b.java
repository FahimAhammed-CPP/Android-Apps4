package a1;

public final class b extends s {
  public static final b m = new b(new Object[0], 0);
  
  public final transient Object[] k;
  
  public final transient int l;
  
  public b(Object[] paramArrayOfObject, int paramInt) {
    this.k = paramArrayOfObject;
    this.l = paramInt;
  }
  
  public final int b(Object[] paramArrayOfObject) {
    System.arraycopy(this.k, 0, paramArrayOfObject, 0, this.l);
    return this.l;
  }
  
  public final int c() {
    return this.l;
  }
  
  public final int d() {
    return 0;
  }
  
  public final Object[] f() {
    return this.k;
  }
  
  public final Object get(int paramInt) {
    t0.b.p(paramInt, this.l);
    Object object = this.k[paramInt];
    object.getClass();
    return object;
  }
  
  public final int size() {
    return this.l;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */