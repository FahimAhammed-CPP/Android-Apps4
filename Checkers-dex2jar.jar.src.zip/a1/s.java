package a1;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import javax.annotation.CheckForNull;
import t0.b;

public abstract class s extends p implements List, RandomAccess {
  public static final q j = new q(b.m, 0);
  
  @Deprecated
  public final void add(int paramInt, Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(int paramInt, Collection paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  public int b(Object[] paramArrayOfObject) {
    int j = size();
    for (int i = 0; i < j; i++)
      paramArrayOfObject[i] = get(i); 
    return j;
  }
  
  public final boolean contains(@CheckForNull Object paramObject) {
    return (indexOf(paramObject) >= 0);
  }
  
  public final boolean equals(@CheckForNull Object paramObject) {
    boolean bool2 = true;
    if (paramObject == this)
      return true; 
    if (paramObject instanceof List) {
      List<Object> list = (List)paramObject;
      int i = size();
      if (i == list.size()) {
        boolean bool;
        if (list instanceof RandomAccess) {
          int j = 0;
          while (true) {
            bool = bool2;
            if (j < i) {
              boolean bool3;
              paramObject = get(j);
              Object object = list.get(j);
              if (paramObject == object || (paramObject != null && paramObject.equals(object))) {
                bool3 = true;
              } else {
                bool3 = false;
              } 
              if (!bool3)
                // Byte code: goto -> 231 
              j++;
              continue;
            } 
            break;
          } 
        } else {
          paramObject = i(0);
          Iterator<Object> iterator = list.iterator();
          while (paramObject.b()) {
            boolean bool3;
            if (!iterator.hasNext())
              // Byte code: goto -> 231 
            Object object = paramObject.d();
            Object object1 = iterator.next();
            if (object == object1 || (object != null && object.equals(object1))) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (!bool3)
              // Byte code: goto -> 231 
          } 
          if (!iterator.hasNext())
            return true; 
          bool = false;
        } 
        return bool;
      } 
    } 
    boolean bool1 = false;
  }
  
  public s h(int paramInt1, int paramInt2) {
    b.x(paramInt1, paramInt2, size());
    paramInt2 -= paramInt1;
    return (s)((paramInt2 == size()) ? this : ((paramInt2 == 0) ? b.m : new r(this, paramInt1, paramInt2)));
  }
  
  public final int hashCode() {
    int k = size();
    int j = 1;
    for (int i = 0; i < k; i++)
      j = j * 31 + get(i).hashCode(); 
    return j;
  }
  
  public final q i(int paramInt) {
    b.t(paramInt, size());
    return isEmpty() ? j : new q(this, paramInt);
  }
  
  public final int indexOf(@CheckForNull Object paramObject) {
    if (paramObject == null)
      return -1; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (paramObject.equals(get(i)))
        return i; 
    } 
    return -1;
  }
  
  public final int lastIndexOf(@CheckForNull Object paramObject) {
    if (paramObject == null)
      return -1; 
    for (int i = size() - 1; i >= 0; i--) {
      if (paramObject.equals(get(i)))
        return i; 
    } 
    return -1;
  }
  
  @Deprecated
  public final Object remove(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final Object set(int paramInt, Object paramObject) {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */