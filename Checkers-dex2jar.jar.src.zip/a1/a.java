package a1;

import b.b;
import java.util.Arrays;
import java.util.Objects;
import t0.b;

public enum a {
  j;
  
  public static final g k;
  
  public final int i;
  
  static {
    Object[] arrayOfObject1;
    g g1;
    a a1 = new a(0, -999, "RESPONSE_CODE_UNSPECIFIED");
    j = a1;
    l = new a[] { 
        a1, new a(1, -3, "SERVICE_TIMEOUT"), new a(2, -2, "FEATURE_NOT_SUPPORTED"), new a(3, -1, "SERVICE_DISCONNECTED"), new a(4, 0, "OK"), new a(5, 1, "USER_CANCELED"), new a(6, 2, "SERVICE_UNAVAILABLE"), new a(7, 3, "BILLING_UNAVAILABLE"), new a(8, 4, "ITEM_UNAVAILABLE"), new a(9, 5, "DEVELOPER_ERROR"), 
        new a(10, 6, "ERROR"), new a(11, 7, "ITEM_ALREADY_OWNED"), new a(12, 8, "ITEM_NOT_OWNED"), new a(13, 11, "EXPIRED_OFFER_TOKEN") };
    Object[] arrayOfObject2 = new Object[8];
    a[] arrayOfA = values();
    int k = arrayOfA.length;
    int j = 0;
    int i = 0;
    while (j < k) {
      a a2 = arrayOfA[j];
      Integer integer = Integer.valueOf(a2.i);
      int n = i + 1;
      int m = arrayOfObject2.length;
      int i1 = n + n;
      arrayOfObject1 = arrayOfObject2;
      if (i1 > m) {
        int i2 = m + (m >> 1) + 1;
        m = i2;
        if (i2 < i1) {
          m = Integer.highestOneBit(i1 - 1);
          m += m;
        } 
        i2 = m;
        if (m < 0)
          i2 = Integer.MAX_VALUE; 
        arrayOfObject1 = Arrays.copyOf(arrayOfObject2, i2);
      } 
      if (integer != null) {
        i += i;
        arrayOfObject1[i] = integer;
        arrayOfObject1[i + 1] = a2;
        j++;
        i = n;
        arrayOfObject2 = arrayOfObject1;
        continue;
      } 
      Objects.toString(a2);
      throw new NullPointerException("null key in entry: null=".concat(String.valueOf(a2)));
    } 
    short[] arrayOfShort = null;
    arrayOfA = null;
    a1 = null;
    if (i == 0) {
      g1 = g.o;
      a[] arrayOfA1 = arrayOfA;
    } else if (i == 1) {
      g1[0].getClass();
      g1[1].getClass();
      g1 = new g(null, (Object[])g1, 1);
    } else {
      b.t(i, g1.length >> 1);
      int m = Math.max(i, 2);
      j = 1073741824;
      if (m < 751619276) {
        int n = Integer.highestOneBit(m - 1);
        n += n;
        while (true) {
          double d = n;
          Double.isNaN(d);
          Double.isNaN(d);
          Double.isNaN(d);
          Double.isNaN(d);
          Double.isNaN(d);
          j = n;
          if (d * 0.7D < m) {
            n += n;
            continue;
          } 
          break;
        } 
      } else if (m >= 1073741824) {
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("collection too large");
        throw illegalArgumentException;
      } 
      if (i == 1) {
        g1[0].getClass();
        g1[1].getClass();
        a1 = null;
      } else {
        int n = j - 1;
        if (j <= 128) {
          byte[] arrayOfByte1;
          byte[] arrayOfByte2 = new byte[j];
          Arrays.fill(arrayOfByte2, (byte)-1);
          int i1 = 0;
          j = 0;
          a1 = null;
          label120: while (i1 < i) {
            k = j + j;
            m = i1 + i1;
            g g4 = g1[m];
            g4.getClass();
            g g3 = g1[m ^ 0x1];
            g3.getClass();
            m = b.r(g4.hashCode());
            while (true) {
              m &= n;
              int i2 = arrayOfByte2[m] & 0xFF;
              if (i2 == 255) {
                arrayOfByte2[m] = (byte)k;
                if (j < i1) {
                  g1[k] = g4;
                  g1[k ^ 0x1] = g3;
                } 
                j++;
              } else if (g4.equals(g1[i2])) {
                m = i2 ^ 0x1;
                g g5 = g1[m];
                g5.getClass();
                t t = new t(g4, g3, g5);
                g1[m] = g3;
              } else {
                m++;
                continue;
              } 
              i1++;
              continue label120;
            } 
          } 
          if (j == i) {
            arrayOfByte1 = arrayOfByte2;
          } else {
            arrayOfObject1 = new Object[] { arrayOfByte2, Integer.valueOf(j), arrayOfByte1 };
          } 
        } else if (j <= 32768) {
          short[] arrayOfShort1;
          short[] arrayOfShort2 = new short[j];
          Arrays.fill(arrayOfShort2, (short)-1);
          j = 0;
          int i1 = 0;
          a1 = null;
          label121: while (i1 < i) {
            k = j + j;
            m = i1 + i1;
            g g4 = g1[m];
            g4.getClass();
            g g3 = g1[m ^ 0x1];
            g3.getClass();
            m = b.r(g4.hashCode());
            while (true) {
              m &= n;
              char c = (char)arrayOfShort2[m];
              if (c == Character.MAX_VALUE) {
                arrayOfShort2[m] = (short)k;
                if (j < i1) {
                  g1[k] = g4;
                  g1[k ^ 0x1] = g3;
                } 
                j++;
              } else if (g4.equals(g1[c])) {
                m = c ^ 0x1;
                g g5 = g1[m];
                g5.getClass();
                t t = new t(g4, g3, g5);
                g1[m] = g3;
              } else {
                m++;
                continue;
              } 
              i1++;
              continue label121;
            } 
          } 
          if (j == i) {
            arrayOfShort1 = arrayOfShort2;
          } else {
            Object[] arrayOfObject6 = new Object[3];
            arrayOfObject6[0] = arrayOfShort2;
            arrayOfObject6[1] = Integer.valueOf(j);
            arrayOfObject6[2] = arrayOfShort1;
            Object[] arrayOfObject5 = arrayOfObject6;
            g g3 = g1;
            arrayOfShort1 = arrayOfShort;
            arrayOfObject4 = arrayOfObject5;
          } 
        } else {
          int[] arrayOfInt1;
          int[] arrayOfInt2 = new int[j];
          Arrays.fill(arrayOfInt2, -1);
          int i1 = 0;
          j = 0;
          a1 = null;
          label122: while (i1 < i) {
            k = j + j;
            m = i1 + i1;
            g g4 = g1[m];
            g4.getClass();
            g g3 = g1[0x1 ^ m];
            g3.getClass();
            m = b.r(g4.hashCode());
            while (true) {
              m &= n;
              int i2 = arrayOfInt2[m];
              if (i2 == -1) {
                arrayOfInt2[m] = k;
                if (j < i1) {
                  g1[k] = g4;
                  g1[k ^ 0x1] = g3;
                } 
                j++;
              } else if (g4.equals(g1[i2])) {
                m = i2 ^ 0x1;
                g g5 = g1[m];
                g5.getClass();
                t t = new t(g4, g3, g5);
                g1[m] = g3;
              } else {
                m++;
                continue;
              } 
              i1++;
              continue label122;
            } 
          } 
          if (j == i) {
            arrayOfInt1 = arrayOfInt2;
          } else {
            Object[] arrayOfObject6 = new Object[3];
            arrayOfObject6[0] = arrayOfInt2;
            arrayOfObject6[1] = Integer.valueOf(j);
            arrayOfObject6[2] = arrayOfInt1;
            Object[] arrayOfObject5 = arrayOfObject6;
            g g3 = g1;
            arrayOfObject1 = arrayOfObject4;
            arrayOfObject4 = arrayOfObject5;
          } 
        } 
      } 
      Object[] arrayOfObject3 = arrayOfObject1;
      g g2 = g1;
      arrayOfObject1 = arrayOfObject4;
      Object[] arrayOfObject4 = arrayOfObject3;
    } 
    if (arrayOfObject1 == null) {
      k = g1;
      return;
    } 
    StringBuilder stringBuilder = b.c("Multiple entries with same key: ");
    stringBuilder.append(((t)arrayOfObject1).a);
    stringBuilder.append("=");
    stringBuilder.append(((t)arrayOfObject1).b);
    stringBuilder.append(" and ");
    stringBuilder.append(((t)arrayOfObject1).a);
    stringBuilder.append("=");
    stringBuilder.append(((t)arrayOfObject1).c);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  a(String paramString) {
    this.i = this$enum$index;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */