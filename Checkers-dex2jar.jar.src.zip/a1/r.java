package a1;

import java.util.List;
import javax.annotation.CheckForNull;
import t0.b;

public final class r extends s {
  public final transient int k;
  
  public final transient int l;
  
  public r(s params, int paramInt1, int paramInt2) {
    this.k = paramInt1;
    this.l = paramInt2;
  }
  
  public final int c() {
    return this.m.d() + this.k + this.l;
  }
  
  public final int d() {
    return this.m.d() + this.k;
  }
  
  @CheckForNull
  public final Object[] f() {
    return this.m.f();
  }
  
  public final Object get(int paramInt) {
    b.p(paramInt, this.l);
    return this.m.get(paramInt + this.k);
  }
  
  public final s h(int paramInt1, int paramInt2) {
    b.x(paramInt1, paramInt2, this.l);
    s s1 = this.m;
    int i = this.k;
    return s1.h(paramInt1 + i, paramInt2 + i);
  }
  
  public final int size() {
    return this.l;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */