package a1;

import java.util.Iterator;
import java.util.Map;
import javax.annotation.CheckForNull;

public final class d extends v {
  public final transient u k;
  
  public final transient Object[] l;
  
  public final transient int m;
  
  public d(u paramu, Object[] paramArrayOfObject, int paramInt) {
    this.k = paramu;
    this.l = paramArrayOfObject;
    this.m = paramInt;
  }
  
  public final int b(Object[] paramArrayOfObject) {
    return h().b(paramArrayOfObject);
  }
  
  public final boolean contains(@CheckForNull Object paramObject) {
    if (paramObject instanceof Map.Entry) {
      Map.Entry entry = (Map.Entry)paramObject;
      paramObject = entry.getKey();
      entry = (Map.Entry)entry.getValue();
      if (entry != null && entry.equals(this.k.get(paramObject)))
        return true; 
    } 
    return false;
  }
  
  public final s i() {
    return new c(this);
  }
  
  public final int size() {
    return this.m;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */