package a1;

import java.util.AbstractMap;
import t0.b;

public final class c extends s {
  public c(d paramd) {}
  
  public final int size() {
    return this.k.m;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */