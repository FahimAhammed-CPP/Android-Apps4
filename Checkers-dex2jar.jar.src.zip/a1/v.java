package a1;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.CheckForNull;

public abstract class v extends p implements Set {
  @CheckForNull
  public transient s j;
  
  public final boolean equals(@CheckForNull Object paramObject) {
    boolean bool = true;
    if (paramObject != this) {
      if (paramObject == this)
        return true; 
      if (paramObject instanceof Set) {
        paramObject = paramObject;
        try {
          if (size() == paramObject.size()) {
            bool = containsAll((Collection<?>)paramObject);
            if (bool)
              return true; 
          } 
        } catch (NullPointerException|ClassCastException nullPointerException) {}
      } 
      bool = false;
    } 
    return bool;
  }
  
  public s h() {
    s s2 = this.j;
    s s1 = s2;
    if (s2 == null) {
      s1 = i();
      this.j = s1;
    } 
    return s1;
  }
  
  public final int hashCode() {
    Iterator<E> iterator = iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += b) {
      byte b;
      E e = iterator.next();
      if (e != null) {
        b = e.hashCode();
      } else {
        b = 0;
      } 
    } 
    return i;
  }
  
  public s i() {
    Object[] arrayOfObject = toArray();
    q q = s.j;
    int i = arrayOfObject.length;
    return (i == 0) ? b.m : new b(arrayOfObject, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */