package a1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.android.billingclient.api.Purchase;
import e0.f;
import e0.v;
import java.util.ArrayList;
import org.json.JSONException;

public final class i {
  public static final int a = Runtime.getRuntime().availableProcessors();
  
  public static int a(Bundle paramBundle, String paramString) {
    Object object;
    if (paramBundle == null) {
      object = "Unexpected null bundle received!";
    } else {
      object = object.get("RESPONSE_CODE");
      if (object == null) {
        e(paramString, "getResponseCodeFromBundle() got null response code, assuming OK");
        return 0;
      } 
      if (object instanceof Integer)
        return ((Integer)object).intValue(); 
      object = "Unexpected type for bundle response code: ".concat(object.getClass().getName());
    } 
    f(paramString, (String)object);
    return 6;
  }
  
  public static Bundle b(int paramInt, boolean paramBoolean, String paramString, ArrayList<v> paramArrayList) {
    Bundle bundle = new Bundle();
    if (paramInt >= 9)
      bundle.putString("playBillingLibraryVersion", paramString); 
    if (paramInt >= 9 && paramBoolean)
      bundle.putBoolean("enablePendingPurchases", true); 
    if (paramInt >= 14) {
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      ArrayList<Integer> arrayList = new ArrayList();
      int m = paramArrayList.size();
      int j = 0;
      int k = 0;
      paramInt = 0;
      while (j < m) {
        v v = paramArrayList.get(j);
        arrayList1.add(null);
        k |= TextUtils.isEmpty(null) ^ true;
        arrayList2.add(null);
        paramInt |= TextUtils.isEmpty(null) ^ true;
        arrayList.add(Integer.valueOf(0));
        j++;
      } 
      if (k != 0)
        bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList1); 
      if (paramInt != 0)
        bundle.putStringArrayList("SKU_OFFER_ID_LIST", arrayList2); 
    } 
    return bundle;
  }
  
  public static f c(Intent paramIntent, String paramString) {
    f f1;
    if (paramIntent == null) {
      f("BillingHelper", "Got null intent!");
      f1 = new f();
      f1.a = 6;
      f1.b = "An internal error occurred.";
      return f1;
    } 
    int j = a(f1.getExtras(), paramString);
    String str = d(f1.getExtras(), paramString);
    f f2 = new f();
    f2.a = j;
    f2.b = str;
    return f2;
  }
  
  public static String d(Bundle paramBundle, String paramString) {
    if (paramBundle == null) {
      f(paramString, "Unexpected null bundle received!");
      return "";
    } 
    Object object = paramBundle.get("DEBUG_MESSAGE");
    if (object == null) {
      e(paramString, "getDebugMessageFromBundle() got null response code, assuming OK");
      return "";
    } 
    if (object instanceof String)
      return (String)object; 
    f(paramString, "Unexpected type for debug message: ".concat(object.getClass().getName()));
    return "";
  }
  
  public static void e(String paramString1, String paramString2) {
    if (Log.isLoggable(paramString1, 2))
      if (!paramString2.isEmpty()) {
        for (int j = 40000; !paramString2.isEmpty() && j > 0; j -= k) {
          int k = Math.min(paramString2.length(), Math.min(4000, j));
          Log.v(paramString1, paramString2.substring(0, k));
          paramString2 = paramString2.substring(k);
        } 
      } else {
        Log.v(paramString1, paramString2);
      }  
  }
  
  public static void f(String paramString1, String paramString2) {
    if (Log.isLoggable(paramString1, 5))
      Log.w(paramString1, paramString2); 
  }
  
  public static void g(String paramString1, String paramString2, Exception paramException) {
    if (Log.isLoggable(paramString1, 5))
      Log.w(paramString1, paramString2, paramException); 
  }
  
  public static Purchase h(String paramString1, String paramString2) {
    if (paramString1 == null || paramString2 == null) {
      e("BillingHelper", "Received a null purchase data.");
      return null;
    } 
    try {
      return new Purchase(paramString1, paramString2);
    } catch (JSONException jSONException) {
      f("BillingHelper", "Got JSONException while parsing purchase data: ".concat(jSONException.toString()));
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */