package a1;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import y0.a;

public final class j extends a implements l {
  public j(IBinder paramIBinder) {
    super(paramIBinder);
  }
  
  public final Bundle A(String paramString1, String paramString2, Bundle paramBundle1, Bundle paramBundle2) {
    Parcel parcel2 = d1();
    parcel2.writeInt(10);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    int i = n.a;
    parcel2.writeInt(1);
    paramBundle1.writeToParcel(parcel2, 0);
    parcel2.writeInt(1);
    paramBundle2.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 901);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final Bundle A0(String paramString1, String paramString2, String paramString3) {
    Parcel parcel2 = d1();
    parcel2.writeInt(3);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    parcel2.writeString(paramString3);
    parcel2.writeString(null);
    Parcel parcel1 = e1(parcel2, 3);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final int C(int paramInt, String paramString1, String paramString2) {
    Parcel parcel2 = d1();
    parcel2.writeInt(paramInt);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    Parcel parcel1 = e1(parcel2, 1);
    paramInt = parcel1.readInt();
    parcel1.recycle();
    return paramInt;
  }
  
  public final Bundle C0(String paramString1, String paramString2, String paramString3, Bundle paramBundle) {
    Parcel parcel2 = d1();
    parcel2.writeInt(9);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    parcel2.writeString(paramString3);
    int i = n.a;
    parcel2.writeInt(1);
    paramBundle.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 11);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final Bundle G(String paramString1, String paramString2, Bundle paramBundle) {
    Parcel parcel2 = d1();
    parcel2.writeInt(9);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    int i = n.a;
    parcel2.writeInt(1);
    paramBundle.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 902);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final Bundle R(String paramString1, String paramString2, Bundle paramBundle) {
    Parcel parcel2 = d1();
    parcel2.writeInt(3);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    int i = n.a;
    parcel2.writeInt(1);
    paramBundle.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 2);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final Bundle V0(String paramString1, String paramString2, String paramString3) {
    Parcel parcel2 = d1();
    parcel2.writeInt(3);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    parcel2.writeString(paramString3);
    Parcel parcel1 = e1(parcel2, 4);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final Bundle v(int paramInt, String paramString1, String paramString2, String paramString3, Bundle paramBundle) {
    Parcel parcel2 = d1();
    parcel2.writeInt(paramInt);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    parcel2.writeString(paramString3);
    parcel2.writeString(null);
    paramInt = n.a;
    parcel2.writeInt(1);
    paramBundle.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 8);
    Bundle bundle = (Bundle)n.a(parcel1, Bundle.CREATOR);
    parcel1.recycle();
    return bundle;
  }
  
  public final int x0(int paramInt, String paramString1, String paramString2, Bundle paramBundle) {
    Parcel parcel2 = d1();
    parcel2.writeInt(paramInt);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    paramInt = n.a;
    parcel2.writeInt(1);
    paramBundle.writeToParcel(parcel2, 0);
    Parcel parcel1 = e1(parcel2, 10);
    paramInt = parcel1.readInt();
    parcel1.recycle();
    return paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */