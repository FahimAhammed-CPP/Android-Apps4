package a1;

import java.util.Iterator;
import java.util.ListIterator;

public abstract class h implements ListIterator, Iterator {
  @Deprecated
  public final void a() {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void add(Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void set(Object paramObject) {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */