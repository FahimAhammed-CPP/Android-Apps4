package a1;

import android.os.Bundle;
import android.os.IInterface;

public interface l extends IInterface {
  Bundle A(String paramString1, String paramString2, Bundle paramBundle1, Bundle paramBundle2);
  
  Bundle A0(String paramString1, String paramString2, String paramString3);
  
  int C(int paramInt, String paramString1, String paramString2);
  
  Bundle C0(String paramString1, String paramString2, String paramString3, Bundle paramBundle);
  
  Bundle G(String paramString1, String paramString2, Bundle paramBundle);
  
  Bundle R(String paramString1, String paramString2, Bundle paramBundle);
  
  Bundle V0(String paramString1, String paramString2, String paramString3);
  
  Bundle v(int paramInt, String paramString1, String paramString2, String paramString3, Bundle paramBundle);
  
  int x0(int paramInt, String paramString1, String paramString2, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */