package a1;

public final class t {
  public final Object a;
  
  public final Object b;
  
  public final Object c;
  
  public t(Object paramObject1, Object paramObject2, Object paramObject3) {
    this.a = paramObject1;
    this.b = paramObject2;
    this.c = paramObject3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */