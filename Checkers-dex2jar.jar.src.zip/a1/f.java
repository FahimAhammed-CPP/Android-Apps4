package a1;

import t0.b;

public final class f extends s {
  public final transient Object[] k;
  
  public final transient int l;
  
  public final transient int m;
  
  public f(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
    this.k = paramArrayOfObject;
    this.l = paramInt1;
    this.m = paramInt2;
  }
  
  public final Object get(int paramInt) {
    b.p(paramInt, this.m);
    Object object = this.k[paramInt + paramInt + this.l];
    object.getClass();
    return object;
  }
  
  public final int size() {
    return this.m;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a1\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */