package b0;

import f1.a;
import java.util.concurrent.Executor;

public final class c<V> extends a<V> {
  public final boolean i(V paramV) {
    V v = paramV;
    if (paramV == null)
      v = (V)a.o; 
    if (a.n.b(this, null, v)) {
      a.c(this);
      return true;
    } 
    return false;
  }
  
  public final boolean j(Throwable paramThrowable) {
    paramThrowable.getClass();
    a.c c1 = new a.c(paramThrowable);
    if (a.n.b(this, null, c1)) {
      a.c(this);
      return true;
    } 
    return false;
  }
  
  public final boolean k(a<? extends V> parama) {
    Object object1;
    parama.getClass();
    Object object3 = this.i;
    Object object2 = object3;
    if (object3 == null) {
      if (((a)parama).isDone()) {
        object1 = a.f(parama);
        if (a.n.b(this, null, object1)) {
          a.c(this);
          return true;
        } 
      } else {
        object2 = new a.f(this, (a<?>)object1);
        if (a.n.b(this, null, object2)) {
          try {
            object3 = b.i;
            ((a)object1).b((Runnable)object2, (Executor)object3);
          } finally {}
          return true;
        } 
        object2 = this.i;
        if (object2 instanceof a.b) {
          boolean bool = ((a.b)object2).a;
          ((a)object1).cancel(bool);
        } 
      } 
      return false;
    } 
    if (object2 instanceof a.b) {
      boolean bool = ((a.b)object2).a;
      ((a)object1).cancel(bool);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\b0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */