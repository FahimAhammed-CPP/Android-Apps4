package b0;

import java.util.concurrent.Executor;

public enum b implements Executor {
  i;
  
  static {
    b b1 = new b();
    i = b1;
    j = new b[] { b1 };
  }
  
  public final void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public final String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */