package b0;

import f1.a;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a<V> implements a<V> {
  public static final boolean l = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
  
  public static final Logger m = Logger.getLogger(a.class.getName());
  
  public static final a n;
  
  public static final Object o = new Object();
  
  public volatile Object i;
  
  public volatile d j;
  
  public volatile h k;
  
  public static void c(a<?> parama) {
    a a2 = null;
    a<?> a1 = parama;
    parama = a2;
    label34: while (true) {
      h h1 = a1.k;
      if (n.c(a1, h1, h.c)) {
        while (h1 != null) {
          Thread thread = h1.a;
          if (thread != null) {
            h1.a = null;
            LockSupport.unpark(thread);
          } 
          h1 = h1.b;
        } 
        while (true) {
          d d1 = a1.j;
          if (n.a(a1, d1, d.d)) {
            d d2 = d1;
            while (true) {
              d1 = d2;
              a<?> a3 = parama;
              if (d1 != null) {
                d2 = d1.c;
                d1.c = (d)parama;
                d d3 = d1;
                continue;
              } 
              break;
            } 
            while (d2 != null) {
              a<V> a3;
              d d3 = d2.c;
              Runnable runnable = d2.a;
              if (runnable instanceof f) {
                runnable = runnable;
                a3 = ((f)runnable).i;
                if (a3.i == runnable) {
                  Object object = f(((f)runnable).j);
                  if (n.b(a3, runnable, object))
                    continue label34; 
                } 
              } else {
                d(runnable, ((d)a3).b);
              } 
              d d4 = d3;
            } 
            return;
          } 
        } 
        continue;
      } 
    } 
  }
  
  public static void d(Runnable paramRunnable, Executor paramExecutor) {
    try {
      paramExecutor.execute(paramRunnable);
      return;
    } catch (RuntimeException runtimeException) {
      Logger logger = m;
      Level level = Level.SEVERE;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RuntimeException while executing runnable ");
      stringBuilder.append(paramRunnable);
      stringBuilder.append(" with executor ");
      stringBuilder.append(paramExecutor);
      logger.log(level, stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  public static Object e(Object paramObject) {
    if (!(paramObject instanceof b)) {
      if (!(paramObject instanceof c)) {
        Object object = paramObject;
        if (paramObject == o)
          object = null; 
        return object;
      } 
      throw new ExecutionException(((c)paramObject).a);
    } 
    paramObject = ((b)paramObject).b;
    CancellationException cancellationException = new CancellationException("Task was cancelled.");
    cancellationException.initCause((Throwable)paramObject);
    throw cancellationException;
  }
  
  public static Object f(a<?> parama) {
    Object object;
    if (parama instanceof a) {
      Object object1 = ((a)parama).i;
      object = object1;
      if (object1 instanceof b) {
        b b = (b)object1;
        object = object1;
        if (b.a) {
          if (b.b != null)
            return new b(false, b.b); 
          object = b.d;
        } 
      } 
      return object;
    } 
    boolean bool1 = ((a)object).i instanceof b;
    if (((l ^ true) & bool1) != 0)
      return b.d; 
    boolean bool = false;
    while (true) {
      try {
        StringBuilder stringBuilder = (StringBuilder)((a<Object>)object).get();
        if (bool)
          return stringBuilder; 
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  public final void a(StringBuilder paramStringBuilder) {
    // Byte code:
    //   0: ldc_w ']'
    //   3: astore #4
    //   5: iconst_0
    //   6: istore_2
    //   7: aload_0
    //   8: invokevirtual get : ()Ljava/lang/Object;
    //   11: astore_3
    //   12: iload_2
    //   13: ifeq -> 22
    //   16: invokestatic currentThread : ()Ljava/lang/Thread;
    //   19: invokevirtual interrupt : ()V
    //   22: aload_1
    //   23: ldc_w 'SUCCESS, result=['
    //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: pop
    //   30: aload_3
    //   31: aload_0
    //   32: if_acmpne -> 42
    //   35: ldc_w 'this future'
    //   38: astore_3
    //   39: goto -> 47
    //   42: aload_3
    //   43: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   46: astore_3
    //   47: aload_1
    //   48: aload_3
    //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: pop
    //   53: aload_1
    //   54: ldc_w ']'
    //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: pop
    //   61: return
    //   62: astore_3
    //   63: iload_2
    //   64: ifeq -> 73
    //   67: invokestatic currentThread : ()Ljava/lang/Thread;
    //   70: invokevirtual interrupt : ()V
    //   73: aload_3
    //   74: athrow
    //   75: aload_1
    //   76: ldc_w 'UNKNOWN, cause=['
    //   79: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: pop
    //   83: aload_1
    //   84: aload_3
    //   85: invokevirtual getClass : ()Ljava/lang/Class;
    //   88: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   91: pop
    //   92: ldc_w ' thrown from get()]'
    //   95: astore_3
    //   96: goto -> 126
    //   99: ldc_w 'CANCELLED'
    //   102: astore_3
    //   103: goto -> 126
    //   106: aload_1
    //   107: ldc_w 'FAILURE, cause=['
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: aload_1
    //   115: aload_3
    //   116: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   119: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: aload #4
    //   125: astore_3
    //   126: aload_1
    //   127: aload_3
    //   128: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   131: pop
    //   132: return
    //   133: iconst_1
    //   134: istore_2
    //   135: goto -> 7
    //   138: astore_3
    //   139: goto -> 133
    //   142: astore_3
    //   143: goto -> 99
    //   146: astore_3
    //   147: goto -> 75
    //   150: astore_3
    //   151: goto -> 106
    // Exception table:
    //   from	to	target	type
    //   7	12	138	java/lang/InterruptedException
    //   7	12	62	finally
    //   16	22	150	java/util/concurrent/ExecutionException
    //   16	22	142	java/util/concurrent/CancellationException
    //   16	22	146	java/lang/RuntimeException
    //   22	30	150	java/util/concurrent/ExecutionException
    //   22	30	142	java/util/concurrent/CancellationException
    //   22	30	146	java/lang/RuntimeException
    //   42	47	150	java/util/concurrent/ExecutionException
    //   42	47	142	java/util/concurrent/CancellationException
    //   42	47	146	java/lang/RuntimeException
    //   47	61	150	java/util/concurrent/ExecutionException
    //   47	61	142	java/util/concurrent/CancellationException
    //   47	61	146	java/lang/RuntimeException
    //   67	73	150	java/util/concurrent/ExecutionException
    //   67	73	142	java/util/concurrent/CancellationException
    //   67	73	146	java/lang/RuntimeException
    //   73	75	150	java/util/concurrent/ExecutionException
    //   73	75	142	java/util/concurrent/CancellationException
    //   73	75	146	java/lang/RuntimeException
  }
  
  public final void b(Runnable paramRunnable, Executor paramExecutor) {
    paramExecutor.getClass();
    d d1 = this.j;
    if (d1 != d.d) {
      d d2;
      d d3 = new d(paramRunnable, paramExecutor);
      do {
        d3.c = d1;
        if (n.a(this, d1, d3))
          return; 
        d2 = this.j;
        d1 = d2;
      } while (d2 != d.d);
    } 
    d(paramRunnable, paramExecutor);
  }
  
  public final boolean cancel(boolean paramBoolean) {
    boolean bool;
    Object object = this.i;
    boolean bool1 = false;
    if (object == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool | object instanceof f) {
      b b;
      Object object1;
      if (l) {
        b = new b(paramBoolean, new CancellationException("Future.cancel() was called."));
      } else if (paramBoolean) {
        b = b.c;
      } else {
        b = b.d;
      } 
      bool1 = false;
      a<?> a1 = this;
      do {
        while (n.b(a1, object, b)) {
          c(a1);
          if (object instanceof f) {
            object = ((f)object).j;
            if (object instanceof a) {
              a1 = (a)object;
              object = a1.i;
              if (object == null) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool | object instanceof f) {
                bool1 = true;
                continue;
              } 
            } else {
              ((a)object).cancel(paramBoolean);
            } 
          } 
          return true;
        } 
        object1 = a1.i;
        object = object1;
      } while (object1 instanceof f);
    } 
    return bool1;
  }
  
  public final String g() {
    Object object = this.i;
    if (object instanceof f) {
      StringBuilder stringBuilder = b.b.c("setFuture=[");
      object = ((f)object).j;
      if (object == this) {
        object = "this future";
      } else {
        object = String.valueOf(object);
      } 
      stringBuilder.append((String)object);
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
    if (this instanceof ScheduledFuture) {
      object = b.b.c("remaining delay=[");
      object.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
      object.append(" ms]");
      return object.toString();
    } 
    return null;
  }
  
  public final V get() {
    if (!Thread.interrupted()) {
      boolean bool;
      Object object = this.i;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof f ^ true)) != 0)
        return (V)e(object); 
      object = this.k;
      if (object != h.c) {
        h h1;
        h h2 = new h();
        do {
          a a1 = n;
          a1.d(h2, (h)object);
          if (a1.c(this, (h)object, h2))
            while (true) {
              LockSupport.park(this);
              if (!Thread.interrupted()) {
                object = this.i;
                if (object != null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if ((bool & (object instanceof f ^ true)) != 0)
                  return (V)e(object); 
                continue;
              } 
              h(h2);
              throw new InterruptedException();
            }  
          h1 = this.k;
          object = h1;
        } while (h1 != h.c);
      } 
      return (V)e(this.i);
    } 
    InterruptedException interruptedException = new InterruptedException();
    throw interruptedException;
  }
  
  public final V get(long paramLong, TimeUnit paramTimeUnit) {
    long l = paramTimeUnit.toNanos(paramLong);
    if (!Thread.interrupted()) {
      boolean bool;
      long l2;
      Object object = this.i;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof f ^ true)) != 0)
        return (V)e(object); 
      if (l > 0L) {
        l2 = System.nanoTime() + l;
      } else {
        l2 = 0L;
      } 
      long l1 = l;
      if (l >= 1000L) {
        object = this.k;
        if (object != h.c) {
          h h1 = new h();
          label78: while (true) {
            a a1 = n;
            a1.d(h1, (h)object);
            if (a1.c(this, (h)object, h1))
              while (true) {
                LockSupport.parkNanos(this, l);
                if (!Thread.interrupted()) {
                  object = this.i;
                  if (object != null) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  if ((bool & (object instanceof f ^ true)) != 0)
                    return (V)e(object); 
                  l1 = l2 - System.nanoTime();
                  l = l1;
                  if (l1 < 1000L) {
                    h(h1);
                    break;
                  } 
                  continue;
                } 
                h(h1);
                throw new InterruptedException();
              }  
            h h2 = this.k;
            object = h2;
            if (h2 == h.c)
              break label78; 
          } 
        } else {
          return (V)e(this.i);
        } 
      } 
      while (l1 > 0L) {
        object = this.i;
        if (object != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool & (object instanceof f ^ true)) != 0)
          return (V)e(object); 
        if (!Thread.interrupted()) {
          l1 = l2 - System.nanoTime();
          continue;
        } 
        throw new InterruptedException();
      } 
      String str3 = toString();
      String str2 = paramTimeUnit.toString();
      object = Locale.ROOT;
      String str4 = str2.toLowerCase((Locale)object);
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Waited ");
      stringBuilder2.append(paramLong);
      stringBuilder2.append(" ");
      stringBuilder2.append(paramTimeUnit.toString().toLowerCase((Locale)object));
      String str1 = stringBuilder2.toString();
      object = str1;
      if (l1 + 1000L < 0L) {
        object = new StringBuilder();
        object.append(str1);
        object.append(" (plus ");
        object = object.toString();
        l1 = -l1;
        paramLong = paramTimeUnit.convert(l1, TimeUnit.NANOSECONDS);
        l1 -= paramTimeUnit.toNanos(paramLong);
        if (paramLong == 0L || l1 > 1000L) {
          bool = true;
        } else {
          bool = false;
        } 
        Object object1 = object;
        if (paramLong > 0L) {
          object1 = new StringBuilder();
          object1.append((String)object);
          object1.append(paramLong);
          object1.append(" ");
          object1.append(str4);
          object = object1.toString();
          object1 = object;
          if (bool) {
            object1 = new StringBuilder();
            object1.append((String)object);
            object1.append(",");
            object1 = object1.toString();
          } 
          object = new StringBuilder();
          object.append((String)object1);
          object.append(" ");
          object1 = object.toString();
        } 
        object = object1;
        if (bool) {
          object = new StringBuilder();
          object.append((String)object1);
          object.append(l1);
          object.append(" nanoseconds ");
          object = object.toString();
        } 
        object1 = new StringBuilder();
        object1.append((String)object);
        object1.append("delay)");
        object = object1.toString();
      } 
      if (isDone()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((String)object);
        stringBuilder.append(" but future completed as timeout expired");
        throw new TimeoutException(stringBuilder.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append((String)object);
      stringBuilder1.append(" for ");
      stringBuilder1.append(str3);
      throw new TimeoutException(stringBuilder1.toString());
    } 
    InterruptedException interruptedException = new InterruptedException();
    throw interruptedException;
  }
  
  public final void h(h paramh) {
    paramh.a = null;
    label24: while (true) {
      paramh = this.k;
      if (paramh == h.c)
        return; 
      for (Object object = null; paramh != null; object = object1) {
        Object object1;
        h h1 = paramh.b;
        if (paramh.a != null) {
          object1 = paramh;
        } else if (object != null) {
          ((h)object).b = h1;
          object1 = object;
          if (((h)object).a == null)
            continue label24; 
        } else {
          object1 = object;
          if (!n.c(this, paramh, h1))
            continue label24; 
        } 
        paramh = h1;
      } 
      break;
    } 
  }
  
  public final boolean isCancelled() {
    return this.i instanceof b;
  }
  
  public final boolean isDone() {
    boolean bool;
    Object object = this.i;
    if (object != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (object instanceof f ^ true) & bool;
  }
  
  public final String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("[status=");
    if (this.i instanceof b) {
      str = "CANCELLED";
    } else {
      if (isDone()) {
        a(stringBuilder);
        stringBuilder.append("]");
        return stringBuilder.toString();
      } 
      try {
        str = g();
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder1 = b.b.c("Exception thrown from implementation: ");
        stringBuilder1.append(runtimeException.getClass());
        str = stringBuilder1.toString();
      } 
      if (str != null && !str.isEmpty()) {
        stringBuilder.append("PENDING, info=[");
        stringBuilder.append(str);
        stringBuilder.append("]");
      } else {
        if (isDone()) {
          a(stringBuilder);
          stringBuilder.append("]");
          return stringBuilder.toString();
        } 
        str = "PENDING";
        stringBuilder.append(str);
      } 
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
    stringBuilder.append(str);
  }
  
  static {
    Exception exception;
    g g;
  }
  
  static {
    try {
      e e = new e(AtomicReferenceFieldUpdater.newUpdater(h.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(h.class, h.class, "b"), AtomicReferenceFieldUpdater.newUpdater(a.class, h.class, "k"), AtomicReferenceFieldUpdater.newUpdater(a.class, d.class, "j"), AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, "i"));
    } finally {
      exception = null;
    } 
    n = g;
    if (exception != null)
      m.log(Level.SEVERE, "SafeAtomicHelper is broken!", exception); 
  }
  
  public static abstract class a {
    public abstract boolean a(a<?> param1a, a.d param1d1, a.d param1d2);
    
    public abstract boolean b(a<?> param1a, Object param1Object1, Object param1Object2);
    
    public abstract boolean c(a<?> param1a, a.h param1h1, a.h param1h2);
    
    public abstract void d(a.h param1h1, a.h param1h2);
    
    public abstract void e(a.h param1h, Thread param1Thread);
  }
  
  public static final class b {
    public static final b c = new b(true, null);
    
    public static final b d = new b(false, null);
    
    public final boolean a;
    
    public final Throwable b;
    
    static {
    
    }
    
    public b(boolean param1Boolean, Throwable param1Throwable) {
      this.a = param1Boolean;
      this.b = param1Throwable;
    }
    
    static {
      if (a.l) {
        d = null;
        c = null;
        return;
      } 
    }
  }
  
  public static final class c {
    public static final c b = new c(new a());
    
    public final Throwable a;
    
    public c(Throwable param1Throwable) {
      boolean bool = a.l;
      param1Throwable.getClass();
      this.a = param1Throwable;
    }
    
    public final class a extends Throwable {
      public a() {
        super("Failure occurred while trying to finish a future.");
      }
      
      public final Throwable fillInStackTrace() {
        /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{b0/a}.Lb0/a$c;}.Lb0/a$c$a;}} */
        /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{b0/a}.Lb0/a$c;}.Lb0/a$c$a;}} */
        return this;
      }
    }
  }
  
  public final class a extends Throwable {
    public a() {
      super("Failure occurred while trying to finish a future.");
    }
    
    public final Throwable fillInStackTrace() {
      /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{b0/a}.Lb0/a$c;}.Lb0/a$c$a;}} */
      /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{b0/a}.Lb0/a$c;}.Lb0/a$c$a;}} */
      return this;
    }
  }
  
  public static final class d {
    public static final d d = new d(null, null);
    
    public final Runnable a;
    
    public final Executor b;
    
    public d c;
    
    public d(Runnable param1Runnable, Executor param1Executor) {
      this.a = param1Runnable;
      this.b = param1Executor;
    }
  }
  
  public static final class e extends a {
    public final AtomicReferenceFieldUpdater<a.h, Thread> a;
    
    public final AtomicReferenceFieldUpdater<a.h, a.h> b;
    
    public final AtomicReferenceFieldUpdater<a, a.h> c;
    
    public final AtomicReferenceFieldUpdater<a, a.d> d;
    
    public final AtomicReferenceFieldUpdater<a, Object> e;
    
    public e(AtomicReferenceFieldUpdater<a.h, Thread> param1AtomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<a.h, a.h> param1AtomicReferenceFieldUpdater1, AtomicReferenceFieldUpdater<a, a.h> param1AtomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<a, a.d> param1AtomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<a, Object> param1AtomicReferenceFieldUpdater4) {
      this.a = param1AtomicReferenceFieldUpdater;
      this.b = param1AtomicReferenceFieldUpdater1;
      this.c = param1AtomicReferenceFieldUpdater2;
      this.d = param1AtomicReferenceFieldUpdater3;
      this.e = param1AtomicReferenceFieldUpdater4;
    }
    
    public final boolean a(a<?> param1a, a.d param1d1, a.d param1d2) {
      AtomicReferenceFieldUpdater<a, a.d> atomicReferenceFieldUpdater = this.d;
      while (true) {
        if (atomicReferenceFieldUpdater.compareAndSet(param1a, param1d1, param1d2))
          return true; 
        if (atomicReferenceFieldUpdater.get(param1a) != param1d1)
          return false; 
      } 
    }
    
    public final boolean b(a<?> param1a, Object param1Object1, Object param1Object2) {
      AtomicReferenceFieldUpdater<a, Object> atomicReferenceFieldUpdater = this.e;
      while (true) {
        if (atomicReferenceFieldUpdater.compareAndSet(param1a, param1Object1, param1Object2))
          return true; 
        if (atomicReferenceFieldUpdater.get(param1a) != param1Object1)
          return false; 
      } 
    }
    
    public final boolean c(a<?> param1a, a.h param1h1, a.h param1h2) {
      AtomicReferenceFieldUpdater<a, a.h> atomicReferenceFieldUpdater = this.c;
      while (true) {
        if (atomicReferenceFieldUpdater.compareAndSet(param1a, param1h1, param1h2))
          return true; 
        if (atomicReferenceFieldUpdater.get(param1a) != param1h1)
          return false; 
      } 
    }
    
    public final void d(a.h param1h1, a.h param1h2) {
      this.b.lazySet(param1h1, param1h2);
    }
    
    public final void e(a.h param1h, Thread param1Thread) {
      this.a.lazySet(param1h, param1Thread);
    }
  }
  
  public static final class f<V> implements Runnable {
    public final a<V> i;
    
    public final a<? extends V> j;
    
    public f(a<V> param1a, a<? extends V> param1a1) {
      this.i = param1a;
      this.j = param1a1;
    }
    
    public final void run() {
      if (this.i.i != this)
        return; 
      Object object = a.f(this.j);
      if (a.n.b(this.i, this, object))
        a.c(this.i); 
    }
  }
  
  public static final class g extends a {
    public final boolean a(a<?> param1a, a.d param1d1, a.d param1d2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield j : Lb0/a$d;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield j : Lb0/a$d;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public final boolean b(a<?> param1a, Object param1Object1, Object param1Object2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield i : Ljava/lang/Object;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield i : Ljava/lang/Object;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public final boolean c(a<?> param1a, a.h param1h1, a.h param1h2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield k : Lb0/a$h;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield k : Lb0/a$h;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public final void d(a.h param1h1, a.h param1h2) {
      param1h1.b = param1h2;
    }
    
    public final void e(a.h param1h, Thread param1Thread) {
      param1h.a = param1Thread;
    }
  }
  
  public static final class h {
    public static final h c = new h(0);
    
    public volatile Thread a;
    
    public volatile h b;
    
    public h() {
      a.n.e(this, Thread.currentThread());
    }
    
    public h(int param1Int) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\b0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */