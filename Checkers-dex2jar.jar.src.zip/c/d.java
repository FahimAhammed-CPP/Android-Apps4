package c;

import java.util.LinkedHashMap;
import z0.l0;

public class d<K, V> {
  public final LinkedHashMap<K, V> a = new LinkedHashMap<K, V>(0, 0.75F, true);
  
  public int b;
  
  public int c = 20;
  
  public int d;
  
  public int e;
  
  public final void a(Object paramObject, l0 paraml0) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 54
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: aload_0
    //   8: getfield b : I
    //   11: iconst_1
    //   12: iadd
    //   13: putfield b : I
    //   16: aload_0
    //   17: getfield a : Ljava/util/LinkedHashMap;
    //   20: aload_1
    //   21: aload_2
    //   22: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   25: ifnull -> 38
    //   28: aload_0
    //   29: aload_0
    //   30: getfield b : I
    //   33: iconst_1
    //   34: isub
    //   35: putfield b : I
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_0
    //   41: aload_0
    //   42: getfield c : I
    //   45: invokevirtual b : (I)V
    //   48: return
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    //   54: new java/lang/NullPointerException
    //   57: dup
    //   58: ldc 'key == null || value == null'
    //   60: invokespecial <init> : (Ljava/lang/String;)V
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   6	38	49	finally
    //   38	40	49	finally
    //   50	52	49	finally
  }
  
  public final void b(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : I
    //   6: iflt -> 109
    //   9: aload_0
    //   10: getfield a : Ljava/util/LinkedHashMap;
    //   13: invokevirtual isEmpty : ()Z
    //   16: ifeq -> 26
    //   19: aload_0
    //   20: getfield b : I
    //   23: ifne -> 109
    //   26: aload_0
    //   27: getfield b : I
    //   30: iload_1
    //   31: if_icmple -> 106
    //   34: aload_0
    //   35: getfield a : Ljava/util/LinkedHashMap;
    //   38: invokevirtual isEmpty : ()Z
    //   41: ifeq -> 47
    //   44: goto -> 106
    //   47: aload_0
    //   48: getfield a : Ljava/util/LinkedHashMap;
    //   51: invokevirtual entrySet : ()Ljava/util/Set;
    //   54: invokeinterface iterator : ()Ljava/util/Iterator;
    //   59: invokeinterface next : ()Ljava/lang/Object;
    //   64: checkcast java/util/Map$Entry
    //   67: astore_2
    //   68: aload_2
    //   69: invokeinterface getKey : ()Ljava/lang/Object;
    //   74: astore_3
    //   75: aload_2
    //   76: invokeinterface getValue : ()Ljava/lang/Object;
    //   81: pop
    //   82: aload_0
    //   83: getfield a : Ljava/util/LinkedHashMap;
    //   86: aload_3
    //   87: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   90: pop
    //   91: aload_0
    //   92: aload_0
    //   93: getfield b : I
    //   96: iconst_1
    //   97: isub
    //   98: putfield b : I
    //   101: aload_0
    //   102: monitorexit
    //   103: goto -> 0
    //   106: aload_0
    //   107: monitorexit
    //   108: return
    //   109: new java/lang/StringBuilder
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: astore_2
    //   117: aload_2
    //   118: aload_0
    //   119: invokevirtual getClass : ()Ljava/lang/Class;
    //   122: invokevirtual getName : ()Ljava/lang/String;
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload_2
    //   130: ldc '.sizeOf() is reporting inconsistent results!'
    //   132: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: pop
    //   136: new java/lang/IllegalStateException
    //   139: dup
    //   140: aload_2
    //   141: invokevirtual toString : ()Ljava/lang/String;
    //   144: invokespecial <init> : (Ljava/lang/String;)V
    //   147: athrow
    //   148: astore_2
    //   149: aload_0
    //   150: monitorexit
    //   151: goto -> 156
    //   154: aload_2
    //   155: athrow
    //   156: goto -> 154
    // Exception table:
    //   from	to	target	type
    //   2	26	148	finally
    //   26	44	148	finally
    //   47	103	148	finally
    //   106	108	148	finally
    //   109	148	148	finally
    //   149	151	148	finally
  }
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: istore_1
    //   7: aload_0
    //   8: getfield e : I
    //   11: iload_1
    //   12: iadd
    //   13: istore_2
    //   14: iload_2
    //   15: ifeq -> 87
    //   18: iload_1
    //   19: bipush #100
    //   21: imul
    //   22: iload_2
    //   23: idiv
    //   24: istore_1
    //   25: goto -> 28
    //   28: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   31: ldc 'LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]'
    //   33: iconst_4
    //   34: anewarray java/lang/Object
    //   37: dup
    //   38: iconst_0
    //   39: aload_0
    //   40: getfield c : I
    //   43: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   46: aastore
    //   47: dup
    //   48: iconst_1
    //   49: aload_0
    //   50: getfield d : I
    //   53: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   56: aastore
    //   57: dup
    //   58: iconst_2
    //   59: aload_0
    //   60: getfield e : I
    //   63: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   66: aastore
    //   67: dup
    //   68: iconst_3
    //   69: iload_1
    //   70: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   73: aastore
    //   74: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   77: astore_3
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_3
    //   81: areturn
    //   82: astore_3
    //   83: aload_0
    //   84: monitorexit
    //   85: aload_3
    //   86: athrow
    //   87: iconst_0
    //   88: istore_1
    //   89: goto -> 28
    // Exception table:
    //   from	to	target	type
    //   2	14	82	finally
    //   18	25	82	finally
    //   28	78	82	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */