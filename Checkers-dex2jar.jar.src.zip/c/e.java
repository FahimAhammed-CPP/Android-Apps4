package c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public abstract class e<K, V> {
  public b a;
  
  public c b;
  
  public e c;
  
  public static <T> boolean c(Set<T> paramSet, Object paramObject) {
    if (paramSet == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      paramObject = paramObject;
      try {
        if (paramSet.size() == paramObject.size()) {
          boolean bool = paramSet.containsAll((Collection<?>)paramObject);
          if (bool)
            return true; 
        } 
        return false;
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    } 
    return false;
  }
  
  public abstract Object a(int paramInt1, int paramInt2);
  
  public abstract void b(int paramInt);
  
  public final <T> T[] d(T[] paramArrayOfT, int paramInt) {
    int j = ((a)this).d.k;
    T[] arrayOfT = paramArrayOfT;
    if (paramArrayOfT.length < j)
      arrayOfT = (T[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), j); 
    for (int i = 0; i < j; i++)
      arrayOfT[i] = (T)a(i, paramInt); 
    if (arrayOfT.length > j)
      arrayOfT[j] = null; 
    return arrayOfT;
  }
  
  public final class a<T> implements Iterator<T> {
    public final int i;
    
    public int j;
    
    public int k;
    
    public boolean l = false;
    
    public a(e this$0, int param1Int) {
      this.i = param1Int;
      this.j = ((a)this$0).d.k;
    }
    
    public final boolean hasNext() {
      return (this.k < this.j);
    }
    
    public final T next() {
      if (hasNext()) {
        Object object = this.m.a(this.k, this.i);
        this.k++;
        this.l = true;
        return (T)object;
      } 
      throw new NoSuchElementException();
    }
    
    public final void remove() {
      if (this.l) {
        int i = this.k - 1;
        this.k = i;
        this.j--;
        this.l = false;
        this.m.b(i);
        return;
      } 
      throw new IllegalStateException();
    }
  }
  
  public final class b implements Set<Map.Entry<K, V>> {
    public b(e this$0) {}
    
    public final boolean add(Object param1Object) {
      param1Object = param1Object;
      throw new UnsupportedOperationException();
    }
    
    public final boolean addAll(Collection<? extends Map.Entry<K, V>> param1Collection) {
      int i = ((a)this.i).d.k;
      for (Map.Entry<K, V> entry : param1Collection) {
        e e1 = this.i;
        Object object = entry.getKey();
        entry = (Map.Entry<K, V>)entry.getValue();
        ((a)e1).d.put(object, entry);
      } 
      return (i != ((a)this.i).d.k);
    }
    
    public final void clear() {
      ((a)this.i).d.clear();
    }
    
    public final boolean contains(Object param1Object) {
      null = param1Object instanceof Map.Entry;
      boolean bool = false;
      if (!null)
        return false; 
      param1Object = param1Object;
      e e1 = this.i;
      Object object2 = param1Object.getKey();
      int i = ((a)e1).d.e(object2);
      if (i < 0)
        return false; 
      Object object1 = this.i.a(i, 1);
      param1Object = param1Object.getValue();
      if (object1 != param1Object) {
        null = bool;
        if (object1 != null) {
          null = bool;
          if (object1.equals(param1Object))
            return true; 
        } 
        return null;
      } 
      return true;
    }
    
    public final boolean containsAll(Collection<?> param1Collection) {
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext()) {
        if (!contains(iterator.next()))
          return false; 
      } 
      return true;
    }
    
    public final boolean equals(Object param1Object) {
      return e.c(this, param1Object);
    }
    
    public final int hashCode() {
      int i = ((a)this.i).d.k - 1;
      int j = 0;
      while (i >= 0) {
        int k;
        int m;
        Object object1 = this.i.a(i, 0);
        Object object2 = this.i.a(i, 1);
        if (object1 == null) {
          k = 0;
        } else {
          k = object1.hashCode();
        } 
        if (object2 == null) {
          m = 0;
        } else {
          m = object2.hashCode();
        } 
        j += k ^ m;
        i--;
      } 
      return j;
    }
    
    public final boolean isEmpty() {
      return (((a)this.i).d.k == 0);
    }
    
    public final Iterator<Map.Entry<K, V>> iterator() {
      return new e.d(this.i);
    }
    
    public final boolean remove(Object param1Object) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean removeAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean retainAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public final int size() {
      return ((a)this.i).d.k;
    }
    
    public final Object[] toArray() {
      throw new UnsupportedOperationException();
    }
    
    public final <T> T[] toArray(T[] param1ArrayOfT) {
      throw new UnsupportedOperationException();
    }
  }
  
  public final class c implements Set<K> {
    public c(e this$0) {}
    
    public final boolean add(K param1K) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean addAll(Collection<? extends K> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public final void clear() {
      ((a)this.i).d.clear();
    }
    
    public final boolean contains(Object param1Object) {
      return (((a)this.i).d.e(param1Object) >= 0);
    }
    
    public final boolean containsAll(Collection<?> param1Collection) {
      b b = ((a)this.i).d;
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext()) {
        if (!b.containsKey(iterator.next()))
          return false; 
      } 
      return true;
    }
    
    public final boolean equals(Object param1Object) {
      return e.c(this, param1Object);
    }
    
    public final int hashCode() {
      int i = ((a)this.i).d.k - 1;
      int j = 0;
      while (i >= 0) {
        int k;
        Object object = this.i.a(i, 0);
        if (object == null) {
          k = 0;
        } else {
          k = object.hashCode();
        } 
        j += k;
        i--;
      } 
      return j;
    }
    
    public final boolean isEmpty() {
      return (((a)this.i).d.k == 0);
    }
    
    public final Iterator<K> iterator() {
      return new e.a<K>(this.i, 0);
    }
    
    public final boolean remove(Object param1Object) {
      int i = ((a)this.i).d.e(param1Object);
      if (i >= 0) {
        this.i.b(i);
        return true;
      } 
      return false;
    }
    
    public final boolean removeAll(Collection<?> param1Collection) {
      b b = ((a)this.i).d;
      int i = b.size();
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext())
        b.remove(iterator.next()); 
      return (i != b.size());
    }
    
    public final boolean retainAll(Collection<?> param1Collection) {
      b b = ((a)this.i).d;
      int i = b.size();
      Iterator iterator = b.keySet().iterator();
      while (iterator.hasNext()) {
        if (!param1Collection.contains(iterator.next()))
          iterator.remove(); 
      } 
      return (i != b.size());
    }
    
    public final int size() {
      return ((a)this.i).d.k;
    }
    
    public final Object[] toArray() {
      e e1 = this.i;
      e1.getClass();
      int j = ((a)e1).d.k;
      Object[] arrayOfObject = new Object[j];
      for (int i = 0; i < j; i++)
        arrayOfObject[i] = e1.a(i, 0); 
      return arrayOfObject;
    }
    
    public final <T> T[] toArray(T[] param1ArrayOfT) {
      return (T[])this.i.d((Object[])param1ArrayOfT, 0);
    }
  }
  
  public final class d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {
    public int i;
    
    public int j;
    
    public boolean k = false;
    
    public d(e this$0) {
      this.i = ((a)this$0).d.k - 1;
      this.j = -1;
    }
    
    public final boolean equals(Object param1Object) {
      if (this.k) {
        boolean bool1;
        boolean bool = param1Object instanceof Map.Entry;
        boolean bool2 = false;
        if (!bool)
          return false; 
        param1Object = param1Object;
        Object object1 = param1Object.getKey();
        Object object2 = this.l.a(this.j, 0);
        if (object1 == object2 || (object1 != null && object1.equals(object2))) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        bool = bool2;
        if (bool1) {
          param1Object = param1Object.getValue();
          object1 = this.l.a(this.j, 1);
          if (param1Object == object1 || (param1Object != null && param1Object.equals(object1))) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          bool = bool2;
          if (bool1)
            bool = true; 
        } 
        return bool;
      } 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public final K getKey() {
      if (this.k)
        return (K)this.l.a(this.j, 0); 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public final V getValue() {
      if (this.k)
        return (V)this.l.a(this.j, 1); 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public final boolean hasNext() {
      return (this.j < this.i);
    }
    
    public final int hashCode() {
      if (this.k) {
        e e1 = this.l;
        int i = this.j;
        int j = 0;
        Object object1 = e1.a(i, 0);
        Object object2 = this.l.a(this.j, 1);
        if (object1 == null) {
          i = 0;
        } else {
          i = object1.hashCode();
        } 
        if (object2 != null)
          j = object2.hashCode(); 
        return i ^ j;
      } 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public final Object next() {
      if (hasNext()) {
        this.j++;
        this.k = true;
        return this;
      } 
      throw new NoSuchElementException();
    }
    
    public final void remove() {
      if (this.k) {
        this.l.b(this.j);
        this.j--;
        this.i--;
        this.k = false;
        return;
      } 
      throw new IllegalStateException();
    }
    
    public final V setValue(V param1V) {
      if (this.k) {
        e e1 = this.l;
        int i = this.j;
        b b = ((a)e1).d;
        i = (i << 1) + 1;
        Object[] arrayOfObject = b.j;
        Object object = arrayOfObject[i];
        arrayOfObject[i] = param1V;
        return (V)object;
      } 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public final String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(getKey());
      stringBuilder.append("=");
      stringBuilder.append(getValue());
      return stringBuilder.toString();
    }
  }
  
  public final class e implements Collection<V> {
    public e(e this$0) {}
    
    public final boolean add(V param1V) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean addAll(Collection<? extends V> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public final void clear() {
      ((a)this.i).d.clear();
    }
    
    public final boolean contains(Object param1Object) {
      return (((a)this.i).d.g(param1Object) >= 0);
    }
    
    public final boolean containsAll(Collection<?> param1Collection) {
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext()) {
        if (!contains(iterator.next()))
          return false; 
      } 
      return true;
    }
    
    public final boolean isEmpty() {
      return (((a)this.i).d.k == 0);
    }
    
    public final Iterator<V> iterator() {
      return new e.a<V>(this.i, 1);
    }
    
    public final boolean remove(Object param1Object) {
      int i = ((a)this.i).d.g(param1Object);
      if (i >= 0) {
        this.i.b(i);
        return true;
      } 
      return false;
    }
    
    public final boolean removeAll(Collection<?> param1Collection) {
      int j = ((a)this.i).d.k;
      int i = 0;
      boolean bool = false;
      while (i < j) {
        int k = j;
        int m = i;
        if (param1Collection.contains(this.i.a(i, 1))) {
          this.i.b(i);
          m = i - 1;
          k = j - 1;
          bool = true;
        } 
        i = m + 1;
        j = k;
      } 
      return bool;
    }
    
    public final boolean retainAll(Collection<?> param1Collection) {
      int j = ((a)this.i).d.k;
      int i = 0;
      boolean bool = false;
      while (i < j) {
        int k = j;
        int m = i;
        if (!param1Collection.contains(this.i.a(i, 1))) {
          this.i.b(i);
          m = i - 1;
          k = j - 1;
          bool = true;
        } 
        i = m + 1;
        j = k;
      } 
      return bool;
    }
    
    public final int size() {
      return ((a)this.i).d.k;
    }
    
    public final Object[] toArray() {
      e e1 = this.i;
      e1.getClass();
      int j = ((a)e1).d.k;
      Object[] arrayOfObject = new Object[j];
      for (int i = 0; i < j; i++)
        arrayOfObject[i] = e1.a(i, 1); 
      return arrayOfObject;
    }
    
    public final <T> T[] toArray(T[] param1ArrayOfT) {
      return (T[])this.i.d((Object[])param1ArrayOfT, 1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */