package c;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

public final class b<K, V> extends f<K, V> implements Map<K, V> {
  public a p;
  
  public b() {}
  
  public b(int paramInt) {
    super(paramInt);
  }
  
  public final Set<Map.Entry<K, V>> entrySet() {
    if (this.p == null)
      this.p = new a(this); 
    a a1 = this.p;
    if (a1.a == null)
      a1.a = new e.b(a1); 
    return a1.a;
  }
  
  public final Set<K> keySet() {
    if (this.p == null)
      this.p = new a(this); 
    a a1 = this.p;
    if (a1.b == null)
      a1.b = new e.c(a1); 
    return a1.b;
  }
  
  public final void putAll(Map<? extends K, ? extends V> paramMap) {
    int i = this.k;
    i = paramMap.size() + i;
    int j = this.k;
    int[] arrayOfInt = this.i;
    if (arrayOfInt.length < i) {
      Object[] arrayOfObject = this.j;
      a(i);
      if (this.k > 0) {
        System.arraycopy(arrayOfInt, 0, this.i, 0, j);
        System.arraycopy(arrayOfObject, 0, this.j, 0, j << 1);
      } 
      f.c(arrayOfInt, arrayOfObject, j);
    } 
    if (this.k == j) {
      for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet())
        put((K)entry.getKey(), (V)entry.getValue()); 
      return;
    } 
    ConcurrentModificationException concurrentModificationException = new ConcurrentModificationException();
    throw concurrentModificationException;
  }
  
  public final Collection<V> values() {
    if (this.p == null)
      this.p = new a(this); 
    a a1 = this.p;
    if (a1.c == null)
      a1.c = new e.e(a1); 
    return a1.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */