package c;

import android.content.Context;
import android.content.res.Resources;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Xml;
import d1.l2;
import d1.n2;
import d1.z3;
import e0.b;
import f0.k;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import n1.h;
import org.w3c.dom.Element;
import org.xmlpull.v1.XmlSerializer;
import p0.e;
import w0.j8;
import z0.a8;
import z0.d9;
import z0.i;
import z0.k;
import z0.n5;
import z0.o;
import z0.s;
import z0.v3;
import z0.z7;

public final class c implements l2, b, h {
  public static final int[] a = new int[0];
  
  public static final Object[] b = new Object[0];
  
  public static final String[] d = new String[] { 
      "ad_activeview", "ad_click", "ad_exposure", "ad_query", "ad_reward", "adunit_exposure", "app_background", "app_clear_data", "app_exception", "app_remove", 
      "app_store_refund", "app_store_subscription_cancel", "app_store_subscription_convert", "app_store_subscription_renew", "app_upgrade", "app_update", "ga_campaign", "error", "first_open", "first_visit", 
      "in_app_purchase", "notification_dismiss", "notification_foreground", "notification_open", "notification_receive", "os_update", "session_start", "session_start_with_rollout", "user_engagement", "ad_impression", 
      "screen_view", "ga_extra_parameter", "firebase_campaign" };
  
  public static final String[] e = new String[] { "ad_impression" };
  
  public static final String[] f = new String[] { 
      "_aa", "_ac", "_xa", "_aq", "_ar", "_xu", "_ab", "_cd", "_ae", "_ui", 
      "app_store_refund", "app_store_subscription_cancel", "app_store_subscription_convert", "app_store_subscription_renew", "_ug", "_au", "_cmp", "_err", "_f", "_v", 
      "_iap", "_nd", "_nf", "_no", "_nr", "_ou", "_s", "_ssr", "_e", "_ai", 
      "_vs", "_ep", "_cmp" };
  
  public static final String[] g = new String[] { 
      "purchase", "refund", "add_payment_info", "add_shipping_info", "add_to_cart", "add_to_wishlist", "begin_checkout", "remove_from_cart", "select_item", "select_promotion", 
      "view_cart", "view_item", "view_item_list", "view_promotion", "ecommerce_purchase", "purchase_refund", "set_checkout_option", "checkout_progress", "select_content", "view_search_results" };
  
  public static final char[] h = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  public static final char[] i = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  public static final z7 j = new z7();
  
  public static final a8 k = new a8();
  
  public static String a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(k.c);
    stringBuilder.append("/");
    stringBuilder.append(paramString);
    String str2 = i(new File(stringBuilder.toString()));
    String str1 = str2;
    if (str2 == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("/data/data/com.dimcoms.checkers/");
      stringBuilder1.append(paramString);
      str1 = i(new File(stringBuilder1.toString()));
    } 
    return str1;
  }
  
  public static void b(String paramString1, String paramString2) {
    XmlSerializer xmlSerializer = Xml.newSerializer();
    StringWriter stringWriter = new StringWriter();
    try {
      xmlSerializer.setOutput(stringWriter);
      xmlSerializer.startDocument("UTF-8", Boolean.TRUE);
      xmlSerializer.startTag("", "root");
      xmlSerializer.startTag("", "time");
      xmlSerializer.text(paramString2);
      xmlSerializer.endTag("", "time");
      xmlSerializer.endTag("", "root");
      xmlSerializer.endDocument();
      paramString2 = stringWriter.toString();
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(k.c);
        stringBuilder.append("/");
        File file = new File(stringBuilder.toString());
        file.mkdir();
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(new File(file, paramString1)));
        outputStreamWriter.write(paramString2);
        outputStreamWriter.flush();
        outputStreamWriter.close();
        return;
      } catch (IOException iOException) {
        iOException.printStackTrace();
        return;
      } 
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public static boolean c(String paramString) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(k.c);
      stringBuilder.append("/");
      stringBuilder.append(paramString);
      if ((new File(stringBuilder.toString())).exists())
        return true; 
      stringBuilder = new StringBuilder();
      stringBuilder.append("/data/data/com.dimcoms.checkers/");
      stringBuilder.append(paramString);
      boolean bool = (new File(stringBuilder.toString())).exists();
      if (bool)
        return true; 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return false;
  }
  
  public static String d() {
    boolean bool = c("Level.xml");
    String str = "0";
    if (bool) {
      str = a("Level.xml");
      if (str == null)
        return "0"; 
    } 
    return str;
  }
  
  public static int e() {
    if (c("PlayAs.xml")) {
      String str = a("PlayAs.xml");
      return (str == null) ? 1 : (str.equals("1") ? 1 : (str.equals("2") ? 2 : (str.equals("3") ? 3 : 0)));
    } 
    return 1;
  }
  
  public static boolean f() {
    if (c("Sound.xml")) {
      String str = a("Sound.xml");
      if (str == null)
        return true; 
      if (str.equals("0"))
        return false; 
    } 
    return true;
  }
  
  public static Integer g() {
    Integer integer = Integer.valueOf(0);
    if (c("Type.xml")) {
      String str = a("Type.xml");
      if (str != null) {
        if (str.equals("0"))
          return integer; 
        if (str.equals("1")) {
          boolean bool = true;
          return Integer.valueOf(bool);
        } 
        if (str.equals("2")) {
          byte b1 = 2;
          return Integer.valueOf(b1);
        } 
        if (str.equals("3")) {
          byte b1 = 3;
          return Integer.valueOf(b1);
        } 
        if (str.equals("4")) {
          byte b1 = 4;
          return Integer.valueOf(b1);
        } 
        if (str.equals("5")) {
          byte b1 = 5;
          return Integer.valueOf(b1);
        } 
        if (str.equals("6")) {
          byte b1 = 6;
          return Integer.valueOf(b1);
        } 
        if (str.equals("7")) {
          byte b1 = 7;
          return Integer.valueOf(b1);
        } 
        if (str.equals("8")) {
          byte b1 = 8;
          return Integer.valueOf(b1);
        } 
        if (str.equals("9")) {
          byte b1 = 9;
          return Integer.valueOf(b1);
        } 
        if (str.equals("10")) {
          byte b1 = 10;
          return Integer.valueOf(b1);
        } 
        if (str.equals("11")) {
          byte b1 = 11;
          return Integer.valueOf(b1);
        } 
      } 
    } 
    return integer;
  }
  
  public static Integer h(int paramInt) {
    // Byte code:
    //   0: iload_0
    //   1: invokestatic valueOf : (I)Ljava/lang/String;
    //   4: astore_3
    //   5: aload_3
    //   6: ldc_w '0'
    //   9: invokevirtual equals : (Ljava/lang/Object;)Z
    //   12: istore_2
    //   13: iconst_0
    //   14: istore_1
    //   15: iload_2
    //   16: ifeq -> 53
    //   19: ldc_w 'LevelB.xml'
    //   22: invokestatic c : (Ljava/lang/String;)Z
    //   25: ifeq -> 53
    //   28: ldc_w 'LevelB.xml'
    //   31: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   34: astore #4
    //   36: aload #4
    //   38: ifnull -> 53
    //   41: aload #4
    //   43: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   46: invokevirtual intValue : ()I
    //   49: istore_0
    //   50: goto -> 55
    //   53: iconst_0
    //   54: istore_0
    //   55: aload_3
    //   56: ldc_w '1'
    //   59: invokevirtual equals : (Ljava/lang/Object;)Z
    //   62: ifeq -> 101
    //   65: ldc_w 'LevelI.xml'
    //   68: invokestatic c : (Ljava/lang/String;)Z
    //   71: ifeq -> 99
    //   74: ldc_w 'LevelI.xml'
    //   77: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   80: astore #4
    //   82: aload #4
    //   84: ifnull -> 99
    //   87: aload #4
    //   89: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   92: invokevirtual intValue : ()I
    //   95: istore_0
    //   96: goto -> 101
    //   99: iconst_0
    //   100: istore_0
    //   101: aload_3
    //   102: ldc_w '2'
    //   105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   108: ifeq -> 147
    //   111: ldc_w 'LevelE.xml'
    //   114: invokestatic c : (Ljava/lang/String;)Z
    //   117: ifeq -> 145
    //   120: ldc_w 'LevelE.xml'
    //   123: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   126: astore #4
    //   128: aload #4
    //   130: ifnull -> 145
    //   133: aload #4
    //   135: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   138: invokevirtual intValue : ()I
    //   141: istore_0
    //   142: goto -> 147
    //   145: iconst_0
    //   146: istore_0
    //   147: aload_3
    //   148: ldc_w '3'
    //   151: invokevirtual equals : (Ljava/lang/Object;)Z
    //   154: ifeq -> 193
    //   157: ldc_w 'LevelR.xml'
    //   160: invokestatic c : (Ljava/lang/String;)Z
    //   163: ifeq -> 191
    //   166: ldc_w 'LevelR.xml'
    //   169: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   172: astore #4
    //   174: aload #4
    //   176: ifnull -> 191
    //   179: aload #4
    //   181: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   184: invokevirtual intValue : ()I
    //   187: istore_0
    //   188: goto -> 193
    //   191: iconst_0
    //   192: istore_0
    //   193: aload_3
    //   194: ldc_w '4'
    //   197: invokevirtual equals : (Ljava/lang/Object;)Z
    //   200: ifeq -> 239
    //   203: ldc_w 'LevelS.xml'
    //   206: invokestatic c : (Ljava/lang/String;)Z
    //   209: ifeq -> 237
    //   212: ldc_w 'LevelS.xml'
    //   215: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   218: astore #4
    //   220: aload #4
    //   222: ifnull -> 237
    //   225: aload #4
    //   227: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   230: invokevirtual intValue : ()I
    //   233: istore_0
    //   234: goto -> 239
    //   237: iconst_0
    //   238: istore_0
    //   239: aload_3
    //   240: ldc_w '5'
    //   243: invokevirtual equals : (Ljava/lang/Object;)Z
    //   246: ifeq -> 285
    //   249: ldc_w 'LevelIT.xml'
    //   252: invokestatic c : (Ljava/lang/String;)Z
    //   255: ifeq -> 283
    //   258: ldc_w 'LevelIT.xml'
    //   261: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   264: astore #4
    //   266: aload #4
    //   268: ifnull -> 283
    //   271: aload #4
    //   273: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   276: invokevirtual intValue : ()I
    //   279: istore_0
    //   280: goto -> 285
    //   283: iconst_0
    //   284: istore_0
    //   285: aload_3
    //   286: ldc_w '6'
    //   289: invokevirtual equals : (Ljava/lang/Object;)Z
    //   292: ifeq -> 331
    //   295: ldc_w 'LevelTH.xml'
    //   298: invokestatic c : (Ljava/lang/String;)Z
    //   301: ifeq -> 329
    //   304: ldc_w 'LevelTH.xml'
    //   307: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   310: astore #4
    //   312: aload #4
    //   314: ifnull -> 329
    //   317: aload #4
    //   319: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   322: invokevirtual intValue : ()I
    //   325: istore_0
    //   326: goto -> 331
    //   329: iconst_0
    //   330: istore_0
    //   331: aload_3
    //   332: ldc_w '7'
    //   335: invokevirtual equals : (Ljava/lang/Object;)Z
    //   338: ifeq -> 377
    //   341: ldc_w 'LevelTR.xml'
    //   344: invokestatic c : (Ljava/lang/String;)Z
    //   347: ifeq -> 375
    //   350: ldc_w 'LevelTR.xml'
    //   353: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   356: astore #4
    //   358: aload #4
    //   360: ifnull -> 375
    //   363: aload #4
    //   365: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   368: invokevirtual intValue : ()I
    //   371: istore_0
    //   372: goto -> 377
    //   375: iconst_0
    //   376: istore_0
    //   377: aload_3
    //   378: ldc_w '8'
    //   381: invokevirtual equals : (Ljava/lang/Object;)Z
    //   384: ifeq -> 423
    //   387: ldc_w 'LevelCZ.xml'
    //   390: invokestatic c : (Ljava/lang/String;)Z
    //   393: ifeq -> 421
    //   396: ldc_w 'LevelCZ.xml'
    //   399: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   402: astore #4
    //   404: aload #4
    //   406: ifnull -> 421
    //   409: aload #4
    //   411: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   414: invokevirtual intValue : ()I
    //   417: istore_0
    //   418: goto -> 423
    //   421: iconst_0
    //   422: istore_0
    //   423: aload_3
    //   424: ldc_w '9'
    //   427: invokevirtual equals : (Ljava/lang/Object;)Z
    //   430: ifeq -> 469
    //   433: ldc_w 'LevelPO.xml'
    //   436: invokestatic c : (Ljava/lang/String;)Z
    //   439: ifeq -> 467
    //   442: ldc_w 'LevelPO.xml'
    //   445: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   448: astore #4
    //   450: aload #4
    //   452: ifnull -> 467
    //   455: aload #4
    //   457: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   460: invokevirtual intValue : ()I
    //   463: istore_0
    //   464: goto -> 469
    //   467: iconst_0
    //   468: istore_0
    //   469: aload_3
    //   470: ldc_w '10'
    //   473: invokevirtual equals : (Ljava/lang/Object;)Z
    //   476: ifeq -> 515
    //   479: ldc_w 'LevelGH.xml'
    //   482: invokestatic c : (Ljava/lang/String;)Z
    //   485: ifeq -> 513
    //   488: ldc_w 'LevelGH.xml'
    //   491: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   494: astore #4
    //   496: aload #4
    //   498: ifnull -> 513
    //   501: aload #4
    //   503: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   506: invokevirtual intValue : ()I
    //   509: istore_0
    //   510: goto -> 515
    //   513: iconst_0
    //   514: istore_0
    //   515: aload_3
    //   516: ldc_w '11'
    //   519: invokevirtual equals : (Ljava/lang/Object;)Z
    //   522: ifeq -> 560
    //   525: iload_1
    //   526: istore_0
    //   527: ldc_w 'LevelNG.xml'
    //   530: invokestatic c : (Ljava/lang/String;)Z
    //   533: ifeq -> 560
    //   536: ldc_w 'LevelNG.xml'
    //   539: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   542: astore_3
    //   543: iload_1
    //   544: istore_0
    //   545: aload_3
    //   546: ifnull -> 560
    //   549: aload_3
    //   550: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   553: invokevirtual intValue : ()I
    //   556: istore_0
    //   557: goto -> 560
    //   560: iload_0
    //   561: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   564: areturn
  }
  
  public static String i(File paramFile) {
    try {
      if (paramFile.exists()) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setNamespaceAware(true);
        return ((Element)documentBuilderFactory.newDocumentBuilder().parse(paramFile).getElementsByTagName("root").item(0)).getElementsByTagName("time").item(0).getFirstChild().getNodeValue();
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return null;
  }
  
  public static boolean j(Context paramContext, int paramInt) {
    String str = paramContext.getApplicationContext().getPackageName();
    long l = 2L;
    boolean bool = false;
    for (int i = 0; i < str.length(); i++)
      l = l * 3L + str.charAt(i); 
    if (183290045713L == l) {
      if (c("View.xml")) {
        str = a("View.xml");
        if (str == null || str.equals("0"))
          return true; 
      } else if (paramInt >= 800) {
        return true;
      } 
      return bool;
    } 
    RuntimeException runtimeException = new RuntimeException();
    throw runtimeException;
  }
  
  public static int k(int paramInt) {
    int i = 0;
    while (i < 3) {
      (new int[3])[0] = 1;
      (new int[3])[1] = 2;
      (new int[3])[2] = 3;
      int j = (new int[3])[i];
      if (j != 0) {
        if (j - 1 == paramInt)
          return j; 
        i++;
        continue;
      } 
      throw null;
    } 
    return 1;
  }
  
  public static String l(n5 paramn5) {
    StringBuilder stringBuilder = new StringBuilder(paramn5.d());
    for (int i = 0; i < paramn5.d(); i++) {
      byte b1 = paramn5.b(i);
      if (b1 != 34) {
        if (b1 != 39) {
          if (b1 != 92) {
            int j;
            String str;
            switch (b1) {
              default:
                if (b1 < 32 || b1 > 126) {
                  stringBuilder.append('\\');
                  stringBuilder.append((char)((b1 >>> 6 & 0x3) + 48));
                  stringBuilder.append((char)((b1 >>> 3 & 0x7) + 48));
                  j = (b1 & 0x7) + 48;
                } 
                stringBuilder.append((char)j);
                break;
              case 13:
                str = "\\r";
                stringBuilder.append(str);
              case 12:
                str = "\\f";
                stringBuilder.append(str);
              case 11:
                str = "\\v";
                stringBuilder.append(str);
              case 10:
                str = "\\n";
                stringBuilder.append(str);
              case 9:
                str = "\\t";
                stringBuilder.append(str);
              case 8:
                str = "\\b";
                stringBuilder.append(str);
              case 7:
                str = "\\a";
                stringBuilder.append(str);
            } 
          } else {
            String str = "\\\\";
            stringBuilder.append(str);
          } 
        } else {
          String str = "\\'";
          stringBuilder.append(str);
        } 
      } else {
        String str = "\\\"";
        stringBuilder.append(str);
      } 
    } 
    return stringBuilder.toString();
  }
  
  public static o m(k paramk, s params, j8 paramj8, ArrayList<o> paramArrayList) {
    o o;
    if (paramk.c(params.i)) {
      o = paramk.b(params.i);
      if (o instanceof i)
        return ((i)o).a(paramj8, paramArrayList); 
      throw new IllegalArgumentException(String.format("%s is not a function", new Object[] { params.i }));
    } 
    if ("hasOwnProperty".equals(params.i)) {
      v3.h("hasOwnProperty", 1, paramArrayList);
      return (o)(o.c(paramj8.b(paramArrayList.get(0)).zzi()) ? o.f : o.g);
    } 
    throw new IllegalArgumentException(String.format("Object has no function %s", new Object[] { params.i }));
  }
  
  public static final boolean n() {
    return (Looper.myLooper() == Looper.getMainLooper());
  }
  
  public static String q(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2) {
    int j = Math.min(paramArrayOfString1.length, paramArrayOfString2.length);
    for (int i = 0; i < j; i++) {
      String str = paramArrayOfString1[i];
      if ((paramString == null && str == null) || (paramString != null && paramString.equals(str)))
        return paramArrayOfString2[i]; 
    } 
    return null;
  }
  
  public static String r(Context paramContext, String paramString) {
    e.g(paramContext);
    Resources resources = paramContext.getResources();
    if (TextUtils.isEmpty(paramString))
      paramString = z3.a(paramContext); 
    int i = resources.getIdentifier("google_app_id", "string", paramString);
    if (i != 0)
      try {
        return resources.getString(i);
      } catch (android.content.res.Resources.NotFoundException notFoundException) {} 
    return null;
  }
  
  public Object zza() {
    List list = n2.a;
    return Long.valueOf(d9.j.a().zzt());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */