package c;

public final class a extends e<Object, Object> {
  public a(b paramb) {}
  
  public final Object a(int paramInt1, int paramInt2) {
    return this.d.j[(paramInt1 << 1) + paramInt2];
  }
  
  public final void b(int paramInt) {
    this.d.h(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */