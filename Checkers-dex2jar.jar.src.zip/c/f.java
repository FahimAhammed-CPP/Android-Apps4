package c;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class f<K, V> {
  public static Object[] l;
  
  public static int m;
  
  public static Object[] n;
  
  public static int o;
  
  public int[] i;
  
  public Object[] j;
  
  public int k;
  
  public f() {
    this.i = c.a;
    this.j = c.b;
    this.k = 0;
  }
  
  public f(int paramInt) {
    if (paramInt == 0) {
      this.i = c.a;
      this.j = c.b;
    } else {
      a(paramInt);
    } 
    this.k = 0;
  }
  
  public static int b(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: iconst_1
    //   2: isub
    //   3: istore_3
    //   4: iconst_0
    //   5: istore_1
    //   6: iload_1
    //   7: iload_3
    //   8: if_icmpgt -> 55
    //   11: iload_1
    //   12: iload_3
    //   13: iadd
    //   14: iconst_1
    //   15: iushr
    //   16: istore #4
    //   18: aload_0
    //   19: iload #4
    //   21: iaload
    //   22: istore #5
    //   24: iload #5
    //   26: iload_2
    //   27: if_icmpge -> 38
    //   30: iload #4
    //   32: iconst_1
    //   33: iadd
    //   34: istore_1
    //   35: goto -> 6
    //   38: iload #4
    //   40: istore_3
    //   41: iload #5
    //   43: iload_2
    //   44: if_icmple -> 59
    //   47: iload #4
    //   49: iconst_1
    //   50: isub
    //   51: istore_3
    //   52: goto -> 6
    //   55: iload_1
    //   56: iconst_m1
    //   57: ixor
    //   58: istore_3
    //   59: iload_3
    //   60: ireturn
  }
  
  public static void c(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 59
    //   7: ldc c/b
    //   9: monitorenter
    //   10: getstatic c/f.o : I
    //   13: bipush #10
    //   15: if_icmpge -> 49
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic c/f.n : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: ishl
    //   31: iconst_1
    //   32: isub
    //   33: istore_2
    //   34: goto -> 118
    //   37: aload_1
    //   38: putstatic c/f.n : [Ljava/lang/Object;
    //   41: getstatic c/f.o : I
    //   44: iconst_1
    //   45: iadd
    //   46: putstatic c/f.o : I
    //   49: ldc c/b
    //   51: monitorexit
    //   52: return
    //   53: astore_0
    //   54: ldc c/b
    //   56: monitorexit
    //   57: aload_0
    //   58: athrow
    //   59: aload_0
    //   60: arraylength
    //   61: iconst_4
    //   62: if_icmpne -> 117
    //   65: ldc c/b
    //   67: monitorenter
    //   68: getstatic c/f.m : I
    //   71: bipush #10
    //   73: if_icmpge -> 107
    //   76: aload_1
    //   77: iconst_0
    //   78: getstatic c/f.l : [Ljava/lang/Object;
    //   81: aastore
    //   82: aload_1
    //   83: iconst_1
    //   84: aload_0
    //   85: aastore
    //   86: iload_2
    //   87: iconst_1
    //   88: ishl
    //   89: iconst_1
    //   90: isub
    //   91: istore_2
    //   92: goto -> 134
    //   95: aload_1
    //   96: putstatic c/f.l : [Ljava/lang/Object;
    //   99: getstatic c/f.m : I
    //   102: iconst_1
    //   103: iadd
    //   104: putstatic c/f.m : I
    //   107: ldc c/b
    //   109: monitorexit
    //   110: return
    //   111: astore_0
    //   112: ldc c/b
    //   114: monitorexit
    //   115: aload_0
    //   116: athrow
    //   117: return
    //   118: iload_2
    //   119: iconst_2
    //   120: if_icmplt -> 37
    //   123: aload_1
    //   124: iload_2
    //   125: aconst_null
    //   126: aastore
    //   127: iload_2
    //   128: iconst_1
    //   129: isub
    //   130: istore_2
    //   131: goto -> 118
    //   134: iload_2
    //   135: iconst_2
    //   136: if_icmplt -> 95
    //   139: aload_1
    //   140: iload_2
    //   141: aconst_null
    //   142: aastore
    //   143: iload_2
    //   144: iconst_1
    //   145: isub
    //   146: istore_2
    //   147: goto -> 134
    // Exception table:
    //   from	to	target	type
    //   10	24	53	finally
    //   37	49	53	finally
    //   49	52	53	finally
    //   54	57	53	finally
    //   68	82	111	finally
    //   95	107	111	finally
    //   107	110	111	finally
    //   112	115	111	finally
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 73
    //   6: ldc c/b
    //   8: monitorenter
    //   9: getstatic c/f.n : [Ljava/lang/Object;
    //   12: astore_2
    //   13: aload_2
    //   14: ifnull -> 61
    //   17: aload_0
    //   18: aload_2
    //   19: putfield j : [Ljava/lang/Object;
    //   22: aload_2
    //   23: iconst_0
    //   24: aaload
    //   25: checkcast [Ljava/lang/Object;
    //   28: putstatic c/f.n : [Ljava/lang/Object;
    //   31: aload_0
    //   32: aload_2
    //   33: iconst_1
    //   34: aaload
    //   35: checkcast [I
    //   38: putfield i : [I
    //   41: aload_2
    //   42: iconst_1
    //   43: aconst_null
    //   44: aastore
    //   45: aload_2
    //   46: iconst_0
    //   47: aconst_null
    //   48: aastore
    //   49: getstatic c/f.o : I
    //   52: iconst_1
    //   53: isub
    //   54: putstatic c/f.o : I
    //   57: ldc c/b
    //   59: monitorexit
    //   60: return
    //   61: ldc c/b
    //   63: monitorexit
    //   64: goto -> 145
    //   67: astore_2
    //   68: ldc c/b
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    //   73: iload_1
    //   74: iconst_4
    //   75: if_icmpne -> 145
    //   78: ldc c/b
    //   80: monitorenter
    //   81: getstatic c/f.l : [Ljava/lang/Object;
    //   84: astore_2
    //   85: aload_2
    //   86: ifnull -> 133
    //   89: aload_0
    //   90: aload_2
    //   91: putfield j : [Ljava/lang/Object;
    //   94: aload_2
    //   95: iconst_0
    //   96: aaload
    //   97: checkcast [Ljava/lang/Object;
    //   100: putstatic c/f.l : [Ljava/lang/Object;
    //   103: aload_0
    //   104: aload_2
    //   105: iconst_1
    //   106: aaload
    //   107: checkcast [I
    //   110: putfield i : [I
    //   113: aload_2
    //   114: iconst_1
    //   115: aconst_null
    //   116: aastore
    //   117: aload_2
    //   118: iconst_0
    //   119: aconst_null
    //   120: aastore
    //   121: getstatic c/f.m : I
    //   124: iconst_1
    //   125: isub
    //   126: putstatic c/f.m : I
    //   129: ldc c/b
    //   131: monitorexit
    //   132: return
    //   133: ldc c/b
    //   135: monitorexit
    //   136: goto -> 145
    //   139: astore_2
    //   140: ldc c/b
    //   142: monitorexit
    //   143: aload_2
    //   144: athrow
    //   145: aload_0
    //   146: iload_1
    //   147: newarray int
    //   149: putfield i : [I
    //   152: aload_0
    //   153: iload_1
    //   154: iconst_1
    //   155: ishl
    //   156: anewarray java/lang/Object
    //   159: putfield j : [Ljava/lang/Object;
    //   162: return
    // Exception table:
    //   from	to	target	type
    //   9	13	67	finally
    //   17	41	67	finally
    //   49	60	67	finally
    //   61	64	67	finally
    //   68	71	67	finally
    //   81	85	139	finally
    //   89	113	139	finally
    //   121	132	139	finally
    //   133	136	139	finally
    //   140	143	139	finally
  }
  
  public final void clear() {
    int i = this.k;
    if (i > 0) {
      int[] arrayOfInt = this.i;
      Object[] arrayOfObject = this.j;
      this.i = c.a;
      this.j = c.b;
      this.k = 0;
      c(arrayOfInt, arrayOfObject, i);
    } 
    if (this.k <= 0)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public final boolean containsKey(Object paramObject) {
    return (e(paramObject) >= 0);
  }
  
  public final boolean containsValue(Object paramObject) {
    return (g(paramObject) >= 0);
  }
  
  public final int d(int paramInt, Object paramObject) {
    int j = this.k;
    if (j == 0)
      return -1; 
    int k = b(this.i, j, paramInt);
    if (k < 0)
      return k; 
    if (paramObject.equals(this.j[k << 1]))
      return k; 
    int i;
    for (i = k + 1; i < j && this.i[i] == paramInt; i++) {
      if (paramObject.equals(this.j[i << 1]))
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.i[j] == paramInt; j--) {
      if (paramObject.equals(this.j[j << 1]))
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public final int e(Object paramObject) {
    return (paramObject == null) ? f() : d(paramObject.hashCode(), paramObject);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof f) {
      paramObject = paramObject;
      if (this.k != ((f)paramObject).k)
        return false; 
      int i = 0;
      try {
        while (i < this.k) {
          Object[] arrayOfObject = this.j;
          int j = i << 1;
          Object object1 = arrayOfObject[j];
          Object object2 = arrayOfObject[j + 1];
          Object object3 = paramObject.get(object1);
          if (object2 == null) {
            if (object3 == null) {
              if (!paramObject.containsKey(object1))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = object2.equals(object3);
            if (!bool)
              return false; 
          } 
          i++;
        } 
        return true;
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    } 
    if (nullPointerException instanceof Map) {
      Map map = (Map)nullPointerException;
      if (this.k != map.size())
        return false; 
      int i = 0;
      try {
        while (i < this.k) {
          Object[] arrayOfObject = this.j;
          int j = i << 1;
          Object object1 = arrayOfObject[j];
          Object object2 = arrayOfObject[j + 1];
          Object object3 = map.get(object1);
          if (object2 == null) {
            if (object3 == null) {
              if (!map.containsKey(object1))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = object2.equals(object3);
            if (!bool)
              return false; 
          } 
          i++;
        } 
        return true;
      } catch (NullPointerException|ClassCastException nullPointerException1) {
        return false;
      } 
    } 
    return false;
  }
  
  public final int f() {
    int j = this.k;
    if (j == 0)
      return -1; 
    int k = b(this.i, j, 0);
    if (k < 0)
      return k; 
    if (this.j[k << 1] == null)
      return k; 
    int i;
    for (i = k + 1; i < j && this.i[i] == 0; i++) {
      if (this.j[i << 1] == null)
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.i[j] == 0; j--) {
      if (this.j[j << 1] == null)
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public final int g(Object paramObject) {
    int i = this.k * 2;
    Object[] arrayOfObject = this.j;
    if (paramObject == null) {
      for (int j = 1; j < i; j += 2) {
        if (arrayOfObject[j] == null)
          return j >> 1; 
      } 
    } else {
      for (int j = 1; j < i; j += 2) {
        if (paramObject.equals(arrayOfObject[j]))
          return j >> 1; 
      } 
    } 
    return -1;
  }
  
  public final V get(Object paramObject) {
    int i = e(paramObject);
    return (V)((i >= 0) ? this.j[(i << 1) + 1] : null);
  }
  
  public final V h(int paramInt) {
    Object[] arrayOfObject = this.j;
    int k = paramInt << 1;
    Object object = arrayOfObject[k + 1];
    int j = this.k;
    int i = 0;
    if (j <= 1) {
      c(this.i, arrayOfObject, j);
      this.i = c.a;
      this.j = c.b;
      paramInt = i;
    } else {
      int m = j - 1;
      int[] arrayOfInt = this.i;
      int n = arrayOfInt.length;
      i = 8;
      if (n > 8 && j < arrayOfInt.length / 3) {
        if (j > 8)
          i = j + (j >> 1); 
        a(i);
        if (j == this.k) {
          if (paramInt > 0) {
            System.arraycopy(arrayOfInt, 0, this.i, 0, paramInt);
            System.arraycopy(arrayOfObject, 0, this.j, 0, k);
          } 
          if (paramInt < m) {
            i = paramInt + 1;
            int[] arrayOfInt1 = this.i;
            n = m - paramInt;
            System.arraycopy(arrayOfInt, i, arrayOfInt1, paramInt, n);
            System.arraycopy(arrayOfObject, i << 1, this.j, k, n << 1);
          } 
        } else {
          throw new ConcurrentModificationException();
        } 
      } else {
        if (paramInt < m) {
          i = paramInt + 1;
          n = m - paramInt;
          System.arraycopy(arrayOfInt, i, arrayOfInt, paramInt, n);
          arrayOfObject = this.j;
          System.arraycopy(arrayOfObject, i << 1, arrayOfObject, k, n << 1);
        } 
        arrayOfObject = this.j;
        paramInt = m << 1;
        arrayOfObject[paramInt] = null;
        arrayOfObject[paramInt + 1] = null;
      } 
      paramInt = m;
    } 
    if (j == this.k) {
      this.k = paramInt;
      return (V)object;
    } 
    throw new ConcurrentModificationException();
  }
  
  public final int hashCode() {
    int[] arrayOfInt = this.i;
    Object[] arrayOfObject = this.j;
    int m = this.k;
    int i = 1;
    int j = 0;
    int k = 0;
    while (j < m) {
      int n;
      Object object = arrayOfObject[i];
      int i1 = arrayOfInt[j];
      if (object == null) {
        n = 0;
      } else {
        n = object.hashCode();
      } 
      k += n ^ i1;
      j++;
      i += 2;
    } 
    return k;
  }
  
  public final boolean isEmpty() {
    return (this.k <= 0);
  }
  
  public final V put(K paramK, V paramV) {
    Object[] arrayOfObject;
    int j;
    int k = this.k;
    if (paramK == null) {
      i = f();
      j = 0;
    } else {
      j = paramK.hashCode();
      i = d(j, paramK);
    } 
    if (i >= 0) {
      i = (i << 1) + 1;
      arrayOfObject = this.j;
      Object object = arrayOfObject[i];
      arrayOfObject[i] = paramV;
      return (V)object;
    } 
    int m = i ^ 0xFFFFFFFF;
    int[] arrayOfInt = this.i;
    if (k >= arrayOfInt.length) {
      i = 4;
      if (k >= 8) {
        i = (k >> 1) + k;
      } else if (k >= 4) {
        i = 8;
      } 
      Object[] arrayOfObject1 = this.j;
      a(i);
      if (k == this.k) {
        int[] arrayOfInt1 = this.i;
        if (arrayOfInt1.length > 0) {
          System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          System.arraycopy(arrayOfObject1, 0, this.j, 0, arrayOfObject1.length);
        } 
        c(arrayOfInt, arrayOfObject1, k);
      } else {
        throw new ConcurrentModificationException();
      } 
    } 
    if (m < k) {
      arrayOfInt = this.i;
      i = m + 1;
      System.arraycopy(arrayOfInt, m, arrayOfInt, i, k - m);
      Object[] arrayOfObject1 = this.j;
      System.arraycopy(arrayOfObject1, m << 1, arrayOfObject1, i << 1, this.k - m << 1);
    } 
    int i = this.k;
    if (k == i) {
      arrayOfInt = this.i;
      if (m < arrayOfInt.length) {
        arrayOfInt[m] = j;
        Object[] arrayOfObject1 = this.j;
        j = m << 1;
        arrayOfObject1[j] = arrayOfObject;
        arrayOfObject1[j + 1] = paramV;
        this.k = i + 1;
        return null;
      } 
    } 
    throw new ConcurrentModificationException();
  }
  
  public final V remove(Object paramObject) {
    int i = e(paramObject);
    return (i >= 0) ? h(i) : null;
  }
  
  public final int size() {
    return this.k;
  }
  
  public final String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.k * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.k; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      Object[] arrayOfObject = this.j;
      int j = i << 1;
      Object object = arrayOfObject[j];
      if (object != this) {
        stringBuilder.append(object);
      } else {
        stringBuilder.append("(this Map)");
      } 
      stringBuilder.append('=');
      object = this.j[j + 1];
      if (object != this) {
        stringBuilder.append(object);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */