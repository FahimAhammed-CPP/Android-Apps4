package c0;

public interface a {}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */