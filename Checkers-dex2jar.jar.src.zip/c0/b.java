package c0;

import a0.k;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public final class b implements a {
  public final k a;
  
  public final Handler b = new Handler(Looper.getMainLooper());
  
  public final a c = new a(this);
  
  public b(ExecutorService paramExecutorService) {
    this.a = new k(paramExecutorService);
  }
  
  public final void a(Runnable paramRunnable) {
    this.a.execute(paramRunnable);
  }
  
  public final class a implements Executor {
    public a(b this$0) {}
    
    public final void execute(Runnable param1Runnable) {
      this.i.b.post(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */