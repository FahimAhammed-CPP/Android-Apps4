package a;

import android.os.Looper;
import java.util.concurrent.Executor;

public final class a extends d {
  public static volatile a b;
  
  public static final a c = new a();
  
  public c a = new c();
  
  public static a e() {
    // Byte code:
    //   0: getstatic a/a.b : La/a;
    //   3: ifnull -> 10
    //   6: getstatic a/a.b : La/a;
    //   9: areturn
    //   10: ldc a/a
    //   12: monitorenter
    //   13: getstatic a/a.b : La/a;
    //   16: ifnonnull -> 29
    //   19: new a/a
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic a/a.b : La/a;
    //   29: ldc a/a
    //   31: monitorexit
    //   32: getstatic a/a.b : La/a;
    //   35: areturn
    //   36: astore_0
    //   37: ldc a/a
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public final void f(Runnable paramRunnable) {
    c c1 = this.a;
    if (c1.c == null)
      synchronized (c1.a) {
        if (c1.c == null)
          c1.c = c.e(Looper.getMainLooper()); 
      }  
    c1.c.post(paramRunnable);
  }
  
  public static final class a implements Executor {
    public final void execute(Runnable param1Runnable) {
      (a.e()).a.b.execute(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */