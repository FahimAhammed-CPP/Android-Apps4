package a;

import java.util.Set;
import k1.c;
import o1.a;

public abstract class d implements c {
  public Object a(Class paramClass) {
    a a = c(paramClass);
    return (a == null) ? null : a.get();
  }
  
  public Set b(Class paramClass) {
    return (Set)d(paramClass).get();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */