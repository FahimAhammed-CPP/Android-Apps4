package a;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class c extends d {
  public final Object a = new Object();
  
  public final ExecutorService b = Executors.newFixedThreadPool(4, new a());
  
  public volatile Handler c;
  
  public static Handler e(Looper paramLooper) {
    if (Build.VERSION.SDK_INT >= 28)
      return b.a(paramLooper); 
    try {
      return Handler.class.getDeclaredConstructor(new Class[] { Looper.class, Handler.Callback.class, boolean.class }).newInstance(new Object[] { paramLooper, null, Boolean.TRUE });
    } catch (IllegalAccessException|InstantiationException|NoSuchMethodException illegalAccessException) {
      return new Handler(paramLooper);
    } catch (InvocationTargetException invocationTargetException) {
      return new Handler(paramLooper);
    } 
  }
  
  public final class a implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(0);
    
    public final Thread newThread(Runnable param1Runnable) {
      param1Runnable = new Thread(param1Runnable);
      param1Runnable.setName(String.format("arch_disk_io_%d", new Object[] { Integer.valueOf(this.a.getAndIncrement()) }));
      return (Thread)param1Runnable;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */