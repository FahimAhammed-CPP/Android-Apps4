package b;

import java.util.HashMap;

public final class a<K, V> extends c<K, V> {
  public HashMap<K, c.c<K, V>> k = new HashMap<K, c.c<K, V>>();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */