package b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class c<K, V> implements Iterable<Map.Entry<K, V>> {
  public WeakHashMap<Object, Boolean> i = new WeakHashMap<Object, Boolean>();
  
  public int j = 0;
  
  public final boolean equals(Object<Map.Entry<K, V>> paramObject) {
    Map.Entry entry;
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof c))
      return false; 
    c c1 = (c)paramObject;
    if (this.j != c1.j)
      return false; 
    paramObject = (Object<Map.Entry<K, V>>)iterator();
    Iterator iterator = c1.iterator();
    while (true) {
      e e = (e)paramObject;
      if (e.hasNext()) {
        e e1 = (e)iterator;
        if (e1.hasNext()) {
          entry = (Map.Entry)e.next();
          Object object = e1.next();
          if ((entry == null && object != null) || (entry != null && !entry.equals(object)))
            return false; 
          continue;
        } 
      } 
      break;
    } 
    return (!entry.hasNext() && !((e)iterator).hasNext());
  }
  
  public final int hashCode() {
    Iterator<Map.Entry<K, V>> iterator = iterator();
    int i = 0;
    while (true) {
      e e = (e)iterator;
      if (e.hasNext()) {
        i += ((Map.Entry)e.next()).hashCode();
        continue;
      } 
      return i;
    } 
  }
  
  public final Iterator<Map.Entry<K, V>> iterator() {
    a<Object, Object> a = new a<Object, Object>(null, null);
    this.i.put(a, Boolean.FALSE);
    return (Iterator)a;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = b.c("[");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (true) {
      e e = (e)iterator;
      if (e.hasNext()) {
        stringBuilder.append(((Map.Entry)e.next()).toString());
        if (e.hasNext())
          stringBuilder.append(", "); 
        continue;
      } 
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
  }
  
  public static final class a<K, V> extends e<K, V> {
    public a(c.c<K, V> param1c1, c.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    public final c.c<K, V> a(c.c<K, V> param1c) {
      param1c.getClass();
      return null;
    }
  }
  
  public static final class b<K, V> extends e<K, V> {
    public b(c.c<K, V> param1c1, c.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    public final c.c<K, V> a(c.c<K, V> param1c) {
      param1c.getClass();
      return null;
    }
  }
  
  public static final class c<K, V> implements Map.Entry<K, V> {}
  
  public final class d implements Iterator<Map.Entry<K, V>> {
    public boolean i = true;
    
    public d(c this$0) {}
    
    public final boolean hasNext() {
      if (this.i) {
        this.j.getClass();
        return false;
      } 
      return false;
    }
    
    public final Object next() {
      if (this.i) {
        this.i = false;
        this.j.getClass();
        return null;
      } 
      return null;
    }
  }
  
  public static abstract class e<K, V> implements Iterator<Map.Entry<K, V>> {
    public e(c.c<K, V> param1c1, c.c<K, V> param1c2) {}
    
    public abstract c.c<K, V> a(c.c<K, V> param1c);
    
    public final boolean hasNext() {
      return false;
    }
    
    public final Object next() {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */