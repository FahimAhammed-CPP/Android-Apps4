package com.dimcoms.checkers;

import a1.i;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.android.billingclient.api.Purchase;
import com.google.firebase.analytics.FirebaseAnalytics;
import d1.f4;
import e0.d;
import e0.f;
import e0.h;
import e0.j;
import e0.k;
import e0.r;
import e0.t;
import e0.v;
import f0.a0;
import f0.j;
import f0.k;
import f0.l;
import f0.z;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import org.json.JSONObject;

public class SetActivity extends Activity {
  public static int m = 0;
  
  public static int n = 0;
  
  public static SoundPool o;
  
  public static boolean p = false;
  
  public static int q = 0;
  
  public static int r = 0;
  
  public static boolean s = true;
  
  public static String t = "hdpi";
  
  public static boolean u = false;
  
  public int a;
  
  public boolean b;
  
  public boolean c = false;
  
  public boolean d = false;
  
  public e0.c e;
  
  public HashMap f = new HashMap<Object, Object>();
  
  public String g = "ads_free";
  
  public SharedPreferences h;
  
  public SharedPreferences.Editor i;
  
  public boolean j = false;
  
  public boolean k = false;
  
  public FirebaseAnalytics l;
  
  public final void a() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165231)).setBackgroundColor(i);
    ((Button)findViewById(2131165232)).setBackgroundColor(i);
  }
  
  public final void b() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165246)).setBackgroundColor(i);
    ((Button)findViewById(2131165247)).setBackgroundColor(i);
  }
  
  public void backClicked(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Z
    //   4: ifeq -> 29
    //   7: new android/content/Intent
    //   10: dup
    //   11: aload_1
    //   12: invokevirtual getContext : ()Landroid/content/Context;
    //   15: ldc com/dimcoms/checkers/MainActivity
    //   17: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   20: astore_1
    //   21: aload_0
    //   22: aload_1
    //   23: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   26: goto -> 53
    //   29: aload_0
    //   30: getfield j : Z
    //   33: ifeq -> 53
    //   36: new android/content/Intent
    //   39: dup
    //   40: aload_1
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: ldc com/dimcoms/checkers/MenuActivity
    //   46: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   49: astore_1
    //   50: goto -> 21
    //   53: aload_0
    //   54: getfield b : Z
    //   57: ifeq -> 96
    //   60: getstatic com/dimcoms/checkers/SetActivity.o : Landroid/media/SoundPool;
    //   63: astore_1
    //   64: aload_1
    //   65: ifnull -> 96
    //   68: aload_1
    //   69: invokevirtual autoPause : ()V
    //   72: getstatic com/dimcoms/checkers/SetActivity.o : Landroid/media/SoundPool;
    //   75: getstatic com/dimcoms/checkers/SetActivity.m : I
    //   78: fconst_1
    //   79: fconst_1
    //   80: iconst_1
    //   81: iconst_0
    //   82: fconst_1
    //   83: invokevirtual play : (IFFIIF)I
    //   86: pop
    //   87: goto -> 96
    //   90: astore_1
    //   91: aload_1
    //   92: invokevirtual getMessage : ()Ljava/lang/String;
    //   95: pop
    //   96: aload_0
    //   97: invokevirtual finish : ()V
    //   100: return
    // Exception table:
    //   from	to	target	type
    //   60	64	90	java/lang/Error
    //   68	87	90	java/lang/Error
  }
  
  public final void c() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165248)).setBackgroundColor(i);
    ((Button)findViewById(2131165249)).setBackgroundColor(i);
  }
  
  public final void d() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165251)).setBackgroundColor(i);
    ((Button)findViewById(2131165252)).setBackgroundColor(i);
    ((Button)findViewById(2131165253)).setBackgroundColor(i);
  }
  
  public final void e() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165259)).setBackgroundColor(i);
    ((Button)findViewById(2131165260)).setBackgroundColor(i);
  }
  
  public final void f() {
    int i = Color.argb(0, 0, 0, 0);
    ViewParent viewParent = findViewById(2131165287).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165288).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165289).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165290).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165291).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165292).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165293).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
    viewParent = findViewById(2131165294).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundColor(i); 
  }
  
  public final void g() {
    int i = Color.argb(200, 0, 0, 0);
    ((Button)findViewById(2131165295)).setBackgroundColor(i);
    ((Button)findViewById(2131165296)).setBackgroundColor(i);
  }
  
  public final void h() {
    e();
    ((Button)findViewById(2131165260)).setBackgroundResource(2131099818);
    this.b = false;
  }
  
  public void h0Clicked(View paramView) {
    a();
    ((Button)findViewById(2131165231)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Helper.xml", String.valueOf(1));
  }
  
  public void h1Clicked(View paramView) {
    a();
    ((Button)findViewById(2131165232)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Helper.xml", String.valueOf(0));
  }
  
  public final void i() {
    e();
    ((Button)findViewById(2131165259)).setBackgroundResource(2131099818);
    this.b = true;
  }
  
  public final void j(Button paramButton, int paramInt) {
    if (paramButton != null) {
      Drawable drawable1;
      RippleDrawable rippleDrawable;
      int i = Build.VERSION.SDK_INT;
      Resources resources = getResources();
      if (i >= 21) {
        drawable1 = j.a(resources, paramInt, getTheme());
      } else {
        drawable1 = drawable1.getDrawable(paramInt);
      } 
      Drawable drawable2 = drawable1;
      if (i >= 21)
        rippleDrawable = new RippleDrawable(ColorStateList.valueOf(-16777216), drawable1, null); 
      paramButton.setBackground((Drawable)rippleDrawable);
    } 
  }
  
  public final void k() {
    f();
    ViewParent viewParent = ((Button)findViewById(2131165287)).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundResource(2131099818); 
  }
  
  public final void l() {
    g();
    ((Button)findViewById(2131165295)).setBackgroundResource(2131099818);
  }
  
  public final void m() {
    g();
    ((Button)findViewById(2131165296)).setBackgroundResource(2131099818);
  }
  
  public void m0Clicked(View paramView) {
    b();
    ((Button)findViewById(2131165246)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Move.xml", String.valueOf(1));
  }
  
  public void m1Clicked(View paramView) {
    b();
    ((Button)findViewById(2131165247)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Move.xml", String.valueOf(0));
  }
  
  public void mc0Clicked(View paramView) {
    c();
    ((Button)findViewById(2131165248)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Capture.xml", String.valueOf(1));
  }
  
  public void mc1Clicked(View paramView) {
    c();
    ((Button)findViewById(2131165249)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Capture.xml", String.valueOf(0));
  }
  
  public final void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Z
    //   4: ifeq -> 26
    //   7: new android/content/Intent
    //   10: dup
    //   11: aload_0
    //   12: ldc com/dimcoms/checkers/MainActivity
    //   14: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   17: astore_1
    //   18: aload_0
    //   19: aload_1
    //   20: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   23: goto -> 47
    //   26: aload_0
    //   27: getfield j : Z
    //   30: ifeq -> 47
    //   33: new android/content/Intent
    //   36: dup
    //   37: aload_0
    //   38: ldc com/dimcoms/checkers/MenuActivity
    //   40: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   43: astore_1
    //   44: goto -> 18
    //   47: aload_0
    //   48: invokevirtual finish : ()V
    //   51: return
  }
  
  public final void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: getstatic android/os/Build$VERSION.SDK_INT : I
    //   9: putfield a : I
    //   12: aload_0
    //   13: invokevirtual getWindow : ()Landroid/view/Window;
    //   16: invokevirtual getDecorView : ()Landroid/view/View;
    //   19: sipush #1280
    //   22: invokevirtual setSystemUiVisibility : (I)V
    //   25: aload_0
    //   26: getfield a : I
    //   29: bipush #19
    //   31: if_icmplt -> 67
    //   34: aload_0
    //   35: invokevirtual getWindow : ()Landroid/view/Window;
    //   38: invokevirtual getDecorView : ()Landroid/view/View;
    //   41: sipush #5894
    //   44: invokevirtual setSystemUiVisibility : (I)V
    //   47: aload_0
    //   48: invokevirtual getWindow : ()Landroid/view/Window;
    //   51: invokevirtual getDecorView : ()Landroid/view/View;
    //   54: astore_1
    //   55: aload_1
    //   56: new com/dimcoms/checkers/SetActivity$a
    //   59: dup
    //   60: aload_1
    //   61: invokespecial <init> : (Landroid/view/View;)V
    //   64: invokevirtual setOnSystemUiVisibilityChangeListener : (Landroid/view/View$OnSystemUiVisibilityChangeListener;)V
    //   67: aload_0
    //   68: aload_0
    //   69: invokestatic getInstance : (Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   72: putfield l : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   75: aload_0
    //   76: invokestatic getDefaultSharedPreferences : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   79: astore_1
    //   80: aload_0
    //   81: aload_1
    //   82: putfield h : Landroid/content/SharedPreferences;
    //   85: aload_0
    //   86: aload_1
    //   87: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   92: putfield i : Landroid/content/SharedPreferences$Editor;
    //   95: aload_0
    //   96: getfield h : Landroid/content/SharedPreferences;
    //   99: ldc_w 'checkers_removed_ads'
    //   102: iconst_0
    //   103: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   108: putstatic com/dimcoms/checkers/SetActivity.u : Z
    //   111: new com/dimcoms/checkers/SetActivity$b
    //   114: dup
    //   115: aload_0
    //   116: invokespecial <init> : (Lcom/dimcoms/checkers/SetActivity;)V
    //   119: astore_1
    //   120: iconst_1
    //   121: istore #6
    //   123: new e0/c
    //   126: dup
    //   127: iconst_1
    //   128: aload_0
    //   129: aload_1
    //   130: invokespecial <init> : (ZLandroid/content/Context;Le0/h;)V
    //   133: astore_1
    //   134: aload_0
    //   135: aload_1
    //   136: putfield e : Le0/c;
    //   139: aload_1
    //   140: new com/dimcoms/checkers/SetActivity$c
    //   143: dup
    //   144: aload_0
    //   145: invokespecial <init> : (Lcom/dimcoms/checkers/SetActivity;)V
    //   148: invokevirtual f : (Le0/d;)V
    //   151: new android/util/DisplayMetrics
    //   154: dup
    //   155: invokespecial <init> : ()V
    //   158: astore_1
    //   159: aload_0
    //   160: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
    //   163: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   168: aload_1
    //   169: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
    //   172: aload_1
    //   173: getfield widthPixels : I
    //   176: istore #4
    //   178: iload #4
    //   180: putstatic com/dimcoms/checkers/SetActivity.q : I
    //   183: aload_1
    //   184: getfield heightPixels : I
    //   187: istore #5
    //   189: iload #5
    //   191: putstatic com/dimcoms/checkers/SetActivity.r : I
    //   194: iload #4
    //   196: iload #5
    //   198: if_icmple -> 211
    //   201: iload #4
    //   203: putstatic com/dimcoms/checkers/SetActivity.r : I
    //   206: iload #5
    //   208: putstatic com/dimcoms/checkers/SetActivity.q : I
    //   211: aload_0
    //   212: invokevirtual getFilesDir : ()Ljava/io/File;
    //   215: astore_1
    //   216: aload_1
    //   217: ifnull -> 228
    //   220: aload_1
    //   221: invokevirtual getPath : ()Ljava/lang/String;
    //   224: astore_1
    //   225: goto -> 232
    //   228: ldc_w '/data/data/com.jetstartgames.chess/files'
    //   231: astore_1
    //   232: aload_1
    //   233: putstatic f0/k.c : Ljava/lang/String;
    //   236: aload_0
    //   237: getstatic com/dimcoms/checkers/SetActivity.r : I
    //   240: invokestatic j : (Landroid/content/Context;I)Z
    //   243: istore #7
    //   245: iload #7
    //   247: putstatic com/dimcoms/checkers/SetActivity.s : Z
    //   250: iconst_0
    //   251: putstatic com/dimcoms/checkers/SetActivity.p : Z
    //   254: iload #7
    //   256: ifeq -> 273
    //   259: aload_0
    //   260: bipush #6
    //   262: invokevirtual setRequestedOrientation : (I)V
    //   265: ldc_w 2131296261
    //   268: istore #4
    //   270: goto -> 283
    //   273: aload_0
    //   274: iconst_1
    //   275: invokevirtual setRequestedOrientation : (I)V
    //   278: ldc_w 2131296260
    //   281: istore #4
    //   283: aload_0
    //   284: iload #4
    //   286: invokevirtual setContentView : (I)V
    //   289: aload_0
    //   290: getstatic com/dimcoms/checkers/SetActivity.r : I
    //   293: getstatic com/dimcoms/checkers/SetActivity.q : I
    //   296: invokestatic l : (Landroid/app/Activity;II)Z
    //   299: ifeq -> 323
    //   302: aload_0
    //   303: ldc_w 2131165434
    //   306: invokevirtual findViewById : (I)Landroid/view/View;
    //   309: checkcast android/widget/RelativeLayout
    //   312: astore_1
    //   313: aload_1
    //   314: ifnull -> 323
    //   317: aload_1
    //   318: bipush #8
    //   320: invokevirtual setVisibility : (I)V
    //   323: aload_0
    //   324: invokevirtual getIntent : ()Landroid/content/Intent;
    //   327: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   330: ifnull -> 363
    //   333: aload_0
    //   334: iconst_1
    //   335: putfield d : Z
    //   338: aload_0
    //   339: ldc_w 2131165261
    //   342: invokevirtual findViewById : (I)Landroid/view/View;
    //   345: checkcast android/widget/Button
    //   348: astore_1
    //   349: aload_1
    //   350: ifnull -> 368
    //   353: aload_1
    //   354: ldc_w 2131427391
    //   357: invokevirtual setText : (I)V
    //   360: goto -> 368
    //   363: aload_0
    //   364: iconst_0
    //   365: putfield d : Z
    //   368: getstatic com/dimcoms/checkers/SetActivity.o : Landroid/media/SoundPool;
    //   371: ifnonnull -> 416
    //   374: new android/media/SoundPool
    //   377: dup
    //   378: bipush #10
    //   380: iconst_3
    //   381: iconst_0
    //   382: invokespecial <init> : (III)V
    //   385: astore_1
    //   386: aload_1
    //   387: putstatic com/dimcoms/checkers/SetActivity.o : Landroid/media/SoundPool;
    //   390: aload_1
    //   391: aload_0
    //   392: ldc_w 2131361801
    //   395: iconst_1
    //   396: invokevirtual load : (Landroid/content/Context;II)I
    //   399: putstatic com/dimcoms/checkers/SetActivity.n : I
    //   402: getstatic com/dimcoms/checkers/SetActivity.o : Landroid/media/SoundPool;
    //   405: aload_0
    //   406: ldc_w 2131361792
    //   409: iconst_2
    //   410: invokevirtual load : (Landroid/content/Context;II)I
    //   413: putstatic com/dimcoms/checkers/SetActivity.m : I
    //   416: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   419: ifeq -> 440
    //   422: aload_0
    //   423: ldc 2131165287
    //   425: invokevirtual findViewById : (I)Landroid/view/View;
    //   428: checkcast android/widget/Button
    //   431: astore_1
    //   432: ldc_w 2131099786
    //   435: istore #4
    //   437: goto -> 455
    //   440: aload_0
    //   441: ldc 2131165287
    //   443: invokevirtual findViewById : (I)Landroid/view/View;
    //   446: checkcast android/widget/Button
    //   449: astore_1
    //   450: ldc_w 2131099770
    //   453: istore #4
    //   455: aload_0
    //   456: aload_1
    //   457: iload #4
    //   459: invokevirtual j : (Landroid/widget/Button;I)V
    //   462: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   465: ifeq -> 486
    //   468: aload_0
    //   469: ldc 2131165288
    //   471: invokevirtual findViewById : (I)Landroid/view/View;
    //   474: checkcast android/widget/Button
    //   477: astore_1
    //   478: ldc_w 2131099778
    //   481: istore #4
    //   483: goto -> 501
    //   486: aload_0
    //   487: ldc 2131165288
    //   489: invokevirtual findViewById : (I)Landroid/view/View;
    //   492: checkcast android/widget/Button
    //   495: astore_1
    //   496: ldc_w 2131099762
    //   499: istore #4
    //   501: aload_0
    //   502: aload_1
    //   503: iload #4
    //   505: invokevirtual j : (Landroid/widget/Button;I)V
    //   508: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   511: ifeq -> 532
    //   514: aload_0
    //   515: ldc 2131165289
    //   517: invokevirtual findViewById : (I)Landroid/view/View;
    //   520: checkcast android/widget/Button
    //   523: astore_1
    //   524: ldc_w 2131099780
    //   527: istore #4
    //   529: goto -> 547
    //   532: aload_0
    //   533: ldc 2131165289
    //   535: invokevirtual findViewById : (I)Landroid/view/View;
    //   538: checkcast android/widget/Button
    //   541: astore_1
    //   542: ldc_w 2131099764
    //   545: istore #4
    //   547: aload_0
    //   548: aload_1
    //   549: iload #4
    //   551: invokevirtual j : (Landroid/widget/Button;I)V
    //   554: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   557: ifeq -> 578
    //   560: aload_0
    //   561: ldc 2131165290
    //   563: invokevirtual findViewById : (I)Landroid/view/View;
    //   566: checkcast android/widget/Button
    //   569: astore_1
    //   570: ldc_w 2131099772
    //   573: istore #4
    //   575: goto -> 593
    //   578: aload_0
    //   579: ldc 2131165290
    //   581: invokevirtual findViewById : (I)Landroid/view/View;
    //   584: checkcast android/widget/Button
    //   587: astore_1
    //   588: ldc_w 2131099756
    //   591: istore #4
    //   593: aload_0
    //   594: aload_1
    //   595: iload #4
    //   597: invokevirtual j : (Landroid/widget/Button;I)V
    //   600: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   603: ifeq -> 624
    //   606: aload_0
    //   607: ldc 2131165291
    //   609: invokevirtual findViewById : (I)Landroid/view/View;
    //   612: checkcast android/widget/Button
    //   615: astore_1
    //   616: ldc_w 2131099776
    //   619: istore #4
    //   621: goto -> 639
    //   624: aload_0
    //   625: ldc 2131165291
    //   627: invokevirtual findViewById : (I)Landroid/view/View;
    //   630: checkcast android/widget/Button
    //   633: astore_1
    //   634: ldc_w 2131099760
    //   637: istore #4
    //   639: aload_0
    //   640: aload_1
    //   641: iload #4
    //   643: invokevirtual j : (Landroid/widget/Button;I)V
    //   646: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   649: ifeq -> 670
    //   652: aload_0
    //   653: ldc 2131165292
    //   655: invokevirtual findViewById : (I)Landroid/view/View;
    //   658: checkcast android/widget/Button
    //   661: astore_1
    //   662: ldc_w 2131099774
    //   665: istore #4
    //   667: goto -> 685
    //   670: aload_0
    //   671: ldc 2131165292
    //   673: invokevirtual findViewById : (I)Landroid/view/View;
    //   676: checkcast android/widget/Button
    //   679: astore_1
    //   680: ldc_w 2131099758
    //   683: istore #4
    //   685: aload_0
    //   686: aload_1
    //   687: iload #4
    //   689: invokevirtual j : (Landroid/widget/Button;I)V
    //   692: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   695: ifeq -> 716
    //   698: aload_0
    //   699: ldc 2131165293
    //   701: invokevirtual findViewById : (I)Landroid/view/View;
    //   704: checkcast android/widget/Button
    //   707: astore_1
    //   708: ldc_w 2131099782
    //   711: istore #4
    //   713: goto -> 731
    //   716: aload_0
    //   717: ldc 2131165293
    //   719: invokevirtual findViewById : (I)Landroid/view/View;
    //   722: checkcast android/widget/Button
    //   725: astore_1
    //   726: ldc_w 2131099766
    //   729: istore #4
    //   731: aload_0
    //   732: aload_1
    //   733: iload #4
    //   735: invokevirtual j : (Landroid/widget/Button;I)V
    //   738: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   741: ifeq -> 762
    //   744: aload_0
    //   745: ldc 2131165294
    //   747: invokevirtual findViewById : (I)Landroid/view/View;
    //   750: checkcast android/widget/Button
    //   753: astore_1
    //   754: ldc_w 2131099784
    //   757: istore #4
    //   759: goto -> 777
    //   762: aload_0
    //   763: ldc 2131165294
    //   765: invokevirtual findViewById : (I)Landroid/view/View;
    //   768: checkcast android/widget/Button
    //   771: astore_1
    //   772: ldc_w 2131099768
    //   775: istore #4
    //   777: aload_0
    //   778: aload_1
    //   779: iload #4
    //   781: invokevirtual j : (Landroid/widget/Button;I)V
    //   784: ldc_w 'Theme.xml'
    //   787: invokestatic c : (Ljava/lang/String;)Z
    //   790: ifeq -> 1118
    //   793: ldc_w 'Theme.xml'
    //   796: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   799: astore_1
    //   800: aload_1
    //   801: ifnull -> 1118
    //   804: aload_1
    //   805: ldc_w '0'
    //   808: invokevirtual equals : (Ljava/lang/Object;)Z
    //   811: ifeq -> 817
    //   814: goto -> 1118
    //   817: aload_1
    //   818: ldc_w '1'
    //   821: invokevirtual equals : (Ljava/lang/Object;)Z
    //   824: ifeq -> 860
    //   827: aload_0
    //   828: invokevirtual f : ()V
    //   831: aload_0
    //   832: ldc 2131165288
    //   834: invokevirtual findViewById : (I)Landroid/view/View;
    //   837: checkcast android/widget/Button
    //   840: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   843: astore_1
    //   844: aload_1
    //   845: ifnull -> 1122
    //   848: aload_1
    //   849: checkcast android/widget/LinearLayout
    //   852: ldc 2131099818
    //   854: invokevirtual setBackgroundResource : (I)V
    //   857: goto -> 1122
    //   860: aload_1
    //   861: ldc_w '2'
    //   864: invokevirtual equals : (Ljava/lang/Object;)Z
    //   867: ifeq -> 903
    //   870: aload_0
    //   871: invokevirtual f : ()V
    //   874: aload_0
    //   875: ldc 2131165289
    //   877: invokevirtual findViewById : (I)Landroid/view/View;
    //   880: checkcast android/widget/Button
    //   883: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   886: astore_1
    //   887: aload_1
    //   888: ifnull -> 1122
    //   891: aload_1
    //   892: checkcast android/widget/LinearLayout
    //   895: ldc 2131099818
    //   897: invokevirtual setBackgroundResource : (I)V
    //   900: goto -> 1122
    //   903: aload_1
    //   904: ldc_w '3'
    //   907: invokevirtual equals : (Ljava/lang/Object;)Z
    //   910: ifeq -> 946
    //   913: aload_0
    //   914: invokevirtual f : ()V
    //   917: aload_0
    //   918: ldc 2131165290
    //   920: invokevirtual findViewById : (I)Landroid/view/View;
    //   923: checkcast android/widget/Button
    //   926: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   929: astore_1
    //   930: aload_1
    //   931: ifnull -> 1122
    //   934: aload_1
    //   935: checkcast android/widget/LinearLayout
    //   938: ldc 2131099818
    //   940: invokevirtual setBackgroundResource : (I)V
    //   943: goto -> 1122
    //   946: aload_1
    //   947: ldc_w '4'
    //   950: invokevirtual equals : (Ljava/lang/Object;)Z
    //   953: ifeq -> 989
    //   956: aload_0
    //   957: invokevirtual f : ()V
    //   960: aload_0
    //   961: ldc 2131165291
    //   963: invokevirtual findViewById : (I)Landroid/view/View;
    //   966: checkcast android/widget/Button
    //   969: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   972: astore_1
    //   973: aload_1
    //   974: ifnull -> 1122
    //   977: aload_1
    //   978: checkcast android/widget/LinearLayout
    //   981: ldc 2131099818
    //   983: invokevirtual setBackgroundResource : (I)V
    //   986: goto -> 1122
    //   989: aload_1
    //   990: ldc_w '5'
    //   993: invokevirtual equals : (Ljava/lang/Object;)Z
    //   996: ifeq -> 1032
    //   999: aload_0
    //   1000: invokevirtual f : ()V
    //   1003: aload_0
    //   1004: ldc 2131165292
    //   1006: invokevirtual findViewById : (I)Landroid/view/View;
    //   1009: checkcast android/widget/Button
    //   1012: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1015: astore_1
    //   1016: aload_1
    //   1017: ifnull -> 1122
    //   1020: aload_1
    //   1021: checkcast android/widget/LinearLayout
    //   1024: ldc 2131099818
    //   1026: invokevirtual setBackgroundResource : (I)V
    //   1029: goto -> 1122
    //   1032: aload_1
    //   1033: ldc_w '6'
    //   1036: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1039: ifeq -> 1075
    //   1042: aload_0
    //   1043: invokevirtual f : ()V
    //   1046: aload_0
    //   1047: ldc 2131165293
    //   1049: invokevirtual findViewById : (I)Landroid/view/View;
    //   1052: checkcast android/widget/Button
    //   1055: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1058: astore_1
    //   1059: aload_1
    //   1060: ifnull -> 1122
    //   1063: aload_1
    //   1064: checkcast android/widget/LinearLayout
    //   1067: ldc 2131099818
    //   1069: invokevirtual setBackgroundResource : (I)V
    //   1072: goto -> 1122
    //   1075: aload_1
    //   1076: ldc_w '7'
    //   1079: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1082: ifeq -> 1118
    //   1085: aload_0
    //   1086: invokevirtual f : ()V
    //   1089: aload_0
    //   1090: ldc 2131165294
    //   1092: invokevirtual findViewById : (I)Landroid/view/View;
    //   1095: checkcast android/widget/Button
    //   1098: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1101: astore_1
    //   1102: aload_1
    //   1103: ifnull -> 1122
    //   1106: aload_1
    //   1107: checkcast android/widget/LinearLayout
    //   1110: ldc 2131099818
    //   1112: invokevirtual setBackgroundResource : (I)V
    //   1115: goto -> 1122
    //   1118: aload_0
    //   1119: invokevirtual k : ()V
    //   1122: ldc_w 'Sound.xml'
    //   1125: invokestatic c : (Ljava/lang/String;)Z
    //   1128: ifeq -> 1162
    //   1131: ldc_w 'Sound.xml'
    //   1134: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1137: astore_1
    //   1138: aload_1
    //   1139: ifnull -> 1162
    //   1142: aload_1
    //   1143: ldc_w '1'
    //   1146: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1149: ifeq -> 1155
    //   1152: goto -> 1162
    //   1155: aload_0
    //   1156: invokevirtual h : ()V
    //   1159: goto -> 1166
    //   1162: aload_0
    //   1163: invokevirtual i : ()V
    //   1166: ldc_w 'HA.xml'
    //   1169: invokestatic c : (Ljava/lang/String;)Z
    //   1172: ifeq -> 1202
    //   1175: ldc_w 'HA.xml'
    //   1178: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1181: astore_1
    //   1182: aload_1
    //   1183: ifnonnull -> 1189
    //   1186: goto -> 1202
    //   1189: aload_1
    //   1190: ldc_w '1'
    //   1193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1196: ifeq -> 1202
    //   1199: goto -> 1205
    //   1202: iconst_0
    //   1203: istore #6
    //   1205: aload_0
    //   1206: iload #6
    //   1208: putfield c : Z
    //   1211: aload_0
    //   1212: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1215: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   1218: getfield density : F
    //   1221: fstore_2
    //   1222: new android/util/DisplayMetrics
    //   1225: dup
    //   1226: invokespecial <init> : ()V
    //   1229: astore_1
    //   1230: aload_0
    //   1231: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
    //   1234: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   1239: aload_1
    //   1240: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
    //   1243: aload_1
    //   1244: getfield widthPixels : I
    //   1247: istore #4
    //   1249: aload_1
    //   1250: getfield heightPixels : I
    //   1253: istore #5
    //   1255: aload_1
    //   1256: getfield density : F
    //   1259: fstore_3
    //   1260: iload #4
    //   1262: i2f
    //   1263: fload_3
    //   1264: fdiv
    //   1265: iload #5
    //   1267: i2f
    //   1268: fload_3
    //   1269: fdiv
    //   1270: invokestatic min : (FF)F
    //   1273: fstore_3
    //   1274: fload_2
    //   1275: f2d
    //   1276: ldc2_w 1.5
    //   1279: dcmpl
    //   1280: ifgt -> 1291
    //   1283: fload_3
    //   1284: ldc_w 600.0
    //   1287: fcmpl
    //   1288: iflt -> 1297
    //   1291: ldc_w 'xhdpi'
    //   1294: putstatic com/dimcoms/checkers/SetActivity.t : Ljava/lang/String;
    //   1297: aload_0
    //   1298: ldc_w 2131165352
    //   1301: invokevirtual findViewById : (I)Landroid/view/View;
    //   1304: checkcast android/widget/LinearLayout
    //   1307: astore_1
    //   1308: aload_1
    //   1309: ifnull -> 1339
    //   1312: getstatic com/dimcoms/checkers/SetActivity.u : Z
    //   1315: ifne -> 1333
    //   1318: aload_0
    //   1319: getfield k : Z
    //   1322: ifne -> 1333
    //   1325: aload_1
    //   1326: iconst_0
    //   1327: invokevirtual setVisibility : (I)V
    //   1330: goto -> 1339
    //   1333: aload_1
    //   1334: bipush #8
    //   1336: invokevirtual setVisibility : (I)V
    //   1339: aload_0
    //   1340: ldc_w 2131165349
    //   1343: invokevirtual findViewById : (I)Landroid/view/View;
    //   1346: checkcast android/widget/LinearLayout
    //   1349: astore_1
    //   1350: aload_1
    //   1351: ifnull -> 1373
    //   1354: aload_0
    //   1355: getfield c : Z
    //   1358: ifeq -> 1367
    //   1361: aload_1
    //   1362: iconst_0
    //   1363: invokevirtual setVisibility : (I)V
    //   1366: return
    //   1367: aload_1
    //   1368: bipush #8
    //   1370: invokevirtual setVisibility : (I)V
    //   1373: return
    //   1374: astore_1
    //   1375: goto -> 75
    // Exception table:
    //   from	to	target	type
    //   67	75	1374	java/lang/Error
    //   67	75	1374	java/lang/Exception
  }
  
  public final void onDestroy() {
    SoundPool soundPool = o;
    if (soundPool != null) {
      soundPool.release();
      o = null;
    } 
    super.onDestroy();
    p = true;
  }
  
  public final void onPause() {
    long l = k.b;
    l = System.currentTimeMillis() - k.a + l;
    k.b = l;
    this.i.putLong("checkers_gametime", l);
    this.i.commit();
    super.onPause();
  }
  
  public final void onResume() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onResume : ()V
    //   4: aload_0
    //   5: getfield l : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   8: aload_0
    //   9: getfield h : Landroid/content/SharedPreferences;
    //   12: aload_0
    //   13: getfield i : Landroid/content/SharedPreferences$Editor;
    //   16: invokestatic d : (Lcom/google/firebase/analytics/FirebaseAnalytics;Landroid/content/SharedPreferences;Landroid/content/SharedPreferences$Editor;)V
    //   19: aload_0
    //   20: ldc_w 2131165436
    //   23: invokevirtual findViewById : (I)Landroid/view/View;
    //   26: checkcast android/widget/RelativeLayout
    //   29: astore #5
    //   31: getstatic com/dimcoms/checkers/SetActivity.s : Z
    //   34: istore #4
    //   36: iconst_0
    //   37: istore_2
    //   38: aload_0
    //   39: aload #5
    //   41: iload #4
    //   43: iconst_0
    //   44: invokestatic a : (Landroid/content/Context;Landroid/widget/RelativeLayout;ZZ)V
    //   47: invokestatic f : ()Z
    //   50: ifeq -> 60
    //   53: aload_0
    //   54: invokevirtual i : ()V
    //   57: goto -> 64
    //   60: aload_0
    //   61: invokevirtual h : ()V
    //   64: ldc 'Move.xml'
    //   66: invokestatic c : (Ljava/lang/String;)Z
    //   69: ifeq -> 106
    //   72: ldc 'Move.xml'
    //   74: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   77: astore #5
    //   79: aload #5
    //   81: ifnonnull -> 87
    //   84: goto -> 106
    //   87: aload #5
    //   89: ldc_w '1'
    //   92: invokevirtual equals : (Ljava/lang/Object;)Z
    //   95: ifeq -> 101
    //   98: goto -> 106
    //   101: iconst_0
    //   102: istore_1
    //   103: goto -> 108
    //   106: iconst_1
    //   107: istore_1
    //   108: iload_1
    //   109: ifeq -> 133
    //   112: aload_0
    //   113: invokevirtual b : ()V
    //   116: aload_0
    //   117: ldc 2131165246
    //   119: invokevirtual findViewById : (I)Landroid/view/View;
    //   122: checkcast android/widget/Button
    //   125: ldc 2131099818
    //   127: invokevirtual setBackgroundResource : (I)V
    //   130: goto -> 151
    //   133: aload_0
    //   134: invokevirtual b : ()V
    //   137: aload_0
    //   138: ldc 2131165247
    //   140: invokevirtual findViewById : (I)Landroid/view/View;
    //   143: checkcast android/widget/Button
    //   146: ldc 2131099818
    //   148: invokevirtual setBackgroundResource : (I)V
    //   151: invokestatic e : ()I
    //   154: istore_1
    //   155: iload_1
    //   156: iconst_2
    //   157: if_icmpeq -> 215
    //   160: iload_1
    //   161: iconst_3
    //   162: if_icmpne -> 168
    //   165: goto -> 215
    //   168: iload_1
    //   169: iconst_1
    //   170: if_icmpne -> 194
    //   173: aload_0
    //   174: invokevirtual d : ()V
    //   177: aload_0
    //   178: ldc 2131165251
    //   180: invokevirtual findViewById : (I)Landroid/view/View;
    //   183: checkcast android/widget/Button
    //   186: ldc 2131099818
    //   188: invokevirtual setBackgroundResource : (I)V
    //   191: goto -> 233
    //   194: aload_0
    //   195: invokevirtual d : ()V
    //   198: aload_0
    //   199: ldc 2131165252
    //   201: invokevirtual findViewById : (I)Landroid/view/View;
    //   204: checkcast android/widget/Button
    //   207: ldc 2131099818
    //   209: invokevirtual setBackgroundResource : (I)V
    //   212: goto -> 233
    //   215: aload_0
    //   216: invokevirtual d : ()V
    //   219: aload_0
    //   220: ldc 2131165253
    //   222: invokevirtual findViewById : (I)Landroid/view/View;
    //   225: checkcast android/widget/Button
    //   228: ldc 2131099818
    //   230: invokevirtual setBackgroundResource : (I)V
    //   233: ldc 'Helper.xml'
    //   235: invokestatic c : (Ljava/lang/String;)Z
    //   238: ifeq -> 275
    //   241: ldc 'Helper.xml'
    //   243: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   246: astore #5
    //   248: aload #5
    //   250: ifnonnull -> 256
    //   253: goto -> 275
    //   256: aload #5
    //   258: ldc_w '1'
    //   261: invokevirtual equals : (Ljava/lang/Object;)Z
    //   264: ifeq -> 270
    //   267: goto -> 275
    //   270: iconst_0
    //   271: istore_1
    //   272: goto -> 277
    //   275: iconst_1
    //   276: istore_1
    //   277: iload_1
    //   278: ifeq -> 302
    //   281: aload_0
    //   282: invokevirtual a : ()V
    //   285: aload_0
    //   286: ldc 2131165231
    //   288: invokevirtual findViewById : (I)Landroid/view/View;
    //   291: checkcast android/widget/Button
    //   294: ldc 2131099818
    //   296: invokevirtual setBackgroundResource : (I)V
    //   299: goto -> 320
    //   302: aload_0
    //   303: invokevirtual a : ()V
    //   306: aload_0
    //   307: ldc 2131165232
    //   309: invokevirtual findViewById : (I)Landroid/view/View;
    //   312: checkcast android/widget/Button
    //   315: ldc 2131099818
    //   317: invokevirtual setBackgroundResource : (I)V
    //   320: ldc 'Capture.xml'
    //   322: invokestatic c : (Ljava/lang/String;)Z
    //   325: ifeq -> 356
    //   328: ldc 'Capture.xml'
    //   330: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   333: astore #5
    //   335: aload #5
    //   337: ifnonnull -> 343
    //   340: goto -> 356
    //   343: iload_2
    //   344: istore_1
    //   345: aload #5
    //   347: ldc_w '1'
    //   350: invokevirtual equals : (Ljava/lang/Object;)Z
    //   353: ifeq -> 358
    //   356: iconst_1
    //   357: istore_1
    //   358: iload_1
    //   359: ifeq -> 383
    //   362: aload_0
    //   363: invokevirtual c : ()V
    //   366: aload_0
    //   367: ldc 2131165248
    //   369: invokevirtual findViewById : (I)Landroid/view/View;
    //   372: checkcast android/widget/Button
    //   375: ldc 2131099818
    //   377: invokevirtual setBackgroundResource : (I)V
    //   380: goto -> 401
    //   383: aload_0
    //   384: invokevirtual c : ()V
    //   387: aload_0
    //   388: ldc 2131165249
    //   390: invokevirtual findViewById : (I)Landroid/view/View;
    //   393: checkcast android/widget/Button
    //   396: ldc 2131099818
    //   398: invokevirtual setBackgroundResource : (I)V
    //   401: ldc_w 'View.xml'
    //   404: invokestatic c : (Ljava/lang/String;)Z
    //   407: ifeq -> 437
    //   410: ldc_w 'View.xml'
    //   413: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   416: astore #5
    //   418: aload #5
    //   420: ifnull -> 479
    //   423: aload #5
    //   425: ldc_w '1'
    //   428: invokevirtual equals : (Ljava/lang/Object;)Z
    //   431: ifeq -> 474
    //   434: goto -> 479
    //   437: aload_0
    //   438: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   441: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   444: astore #5
    //   446: aload #5
    //   448: getfield heightPixels : I
    //   451: istore_2
    //   452: aload #5
    //   454: getfield widthPixels : I
    //   457: istore_3
    //   458: iload_2
    //   459: istore_1
    //   460: iload_3
    //   461: iload_2
    //   462: if_icmple -> 467
    //   465: iload_3
    //   466: istore_1
    //   467: iload_1
    //   468: sipush #800
    //   471: if_icmplt -> 479
    //   474: aload_0
    //   475: invokevirtual m : ()V
    //   478: return
    //   479: aload_0
    //   480: invokevirtual l : ()V
    //   483: return
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
  }
  
  @SuppressLint({"NewApi"})
  public final void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    if (this.a >= 19 && paramBoolean)
      getWindow().getDecorView().setSystemUiVisibility(5894); 
  }
  
  public void pa0Clicked(View paramView) {
    d();
    ((Button)findViewById(2131165251)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("PlayAs.xml", String.valueOf(1));
  }
  
  public void pa1Clicked(View paramView) {
    d();
    ((Button)findViewById(2131165252)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("PlayAs.xml", String.valueOf(0));
  }
  
  public void paAlterClicked(View paramView) {
    d();
    ((Button)findViewById(2131165253)).setBackgroundResource(2131099818);
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("PlayAs.xml", String.valueOf(2));
  }
  
  public void rateClicked(View paramView) {
    Context context = paramView.getContext();
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.dimcoms.checkers"));
    try {
      context.startActivity(intent);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      return;
    } 
  }
  
  public void resetProgressClicked(View paramView) {
    c.c.b("LevelB.xml", "0");
    c.c.b("LevelI.xml", "0");
    c.c.b("LevelE.xml", "0");
    c.c.b("LevelR.xml", "0");
  }
  
  public void rmClicked(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Ljava/util/HashMap;
    //   4: ldc 'ads_free'
    //   6: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   9: checkcast com/android/billingclient/api/SkuDetails
    //   12: astore #11
    //   14: aload #11
    //   16: ifnull -> 2419
    //   19: new java/util/ArrayList
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore_1
    //   27: aload_1
    //   28: aload #11
    //   30: invokevirtual add : (Ljava/lang/Object;)Z
    //   33: pop
    //   34: aload_1
    //   35: invokevirtual isEmpty : ()Z
    //   38: iconst_1
    //   39: ixor
    //   40: istore_3
    //   41: iload_3
    //   42: ifeq -> 2408
    //   45: iload_3
    //   46: ifeq -> 2406
    //   49: aload_1
    //   50: aconst_null
    //   51: invokevirtual contains : (Ljava/lang/Object;)Z
    //   54: ifne -> 2395
    //   57: aload_1
    //   58: invokevirtual size : ()I
    //   61: iconst_1
    //   62: if_icmple -> 267
    //   65: aload_1
    //   66: iconst_0
    //   67: invokevirtual get : (I)Ljava/lang/Object;
    //   70: checkcast com/android/billingclient/api/SkuDetails
    //   73: astore #12
    //   75: aload #12
    //   77: invokevirtual a : ()Ljava/lang/String;
    //   80: astore #11
    //   82: aload_1
    //   83: invokevirtual size : ()I
    //   86: istore #4
    //   88: iconst_0
    //   89: istore_2
    //   90: iload_2
    //   91: iload #4
    //   93: if_icmpge -> 165
    //   96: aload_1
    //   97: iload_2
    //   98: invokevirtual get : (I)Ljava/lang/Object;
    //   101: checkcast com/android/billingclient/api/SkuDetails
    //   104: astore #13
    //   106: aload #11
    //   108: ldc_w 'play_pass_subs'
    //   111: invokevirtual equals : (Ljava/lang/Object;)Z
    //   114: ifne -> 158
    //   117: aload #13
    //   119: invokevirtual a : ()Ljava/lang/String;
    //   122: ldc_w 'play_pass_subs'
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifne -> 158
    //   131: aload #11
    //   133: aload #13
    //   135: invokevirtual a : ()Ljava/lang/String;
    //   138: invokevirtual equals : (Ljava/lang/Object;)Z
    //   141: ifeq -> 147
    //   144: goto -> 158
    //   147: new java/lang/IllegalArgumentException
    //   150: dup
    //   151: ldc_w 'SKUs should have the same type.'
    //   154: invokespecial <init> : (Ljava/lang/String;)V
    //   157: athrow
    //   158: iload_2
    //   159: iconst_1
    //   160: iadd
    //   161: istore_2
    //   162: goto -> 90
    //   165: aload #12
    //   167: getfield b : Lorg/json/JSONObject;
    //   170: ldc_w 'packageName'
    //   173: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   176: astore #12
    //   178: aload_1
    //   179: invokevirtual size : ()I
    //   182: istore #4
    //   184: iconst_0
    //   185: istore_2
    //   186: iload_2
    //   187: iload #4
    //   189: if_icmpge -> 267
    //   192: aload_1
    //   193: iload_2
    //   194: invokevirtual get : (I)Ljava/lang/Object;
    //   197: checkcast com/android/billingclient/api/SkuDetails
    //   200: astore #13
    //   202: aload #11
    //   204: ldc_w 'play_pass_subs'
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifne -> 260
    //   213: aload #13
    //   215: invokevirtual a : ()Ljava/lang/String;
    //   218: ldc_w 'play_pass_subs'
    //   221: invokevirtual equals : (Ljava/lang/Object;)Z
    //   224: ifne -> 260
    //   227: aload #12
    //   229: aload #13
    //   231: getfield b : Lorg/json/JSONObject;
    //   234: ldc_w 'packageName'
    //   237: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   240: invokevirtual equals : (Ljava/lang/Object;)Z
    //   243: ifeq -> 249
    //   246: goto -> 260
    //   249: new java/lang/IllegalArgumentException
    //   252: dup
    //   253: ldc_w 'All SKUs must have the same package name.'
    //   256: invokespecial <init> : (Ljava/lang/String;)V
    //   259: athrow
    //   260: iload_2
    //   261: iconst_1
    //   262: iadd
    //   263: istore_2
    //   264: goto -> 186
    //   267: new e0/e
    //   270: dup
    //   271: invokespecial <init> : ()V
    //   274: astore #18
    //   276: iload_3
    //   277: ifeq -> 312
    //   280: aload_1
    //   281: iconst_0
    //   282: invokevirtual get : (I)Ljava/lang/Object;
    //   285: checkcast com/android/billingclient/api/SkuDetails
    //   288: getfield b : Lorg/json/JSONObject;
    //   291: ldc_w 'packageName'
    //   294: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   297: invokevirtual isEmpty : ()Z
    //   300: ifeq -> 306
    //   303: goto -> 312
    //   306: iconst_1
    //   307: istore #8
    //   309: goto -> 315
    //   312: iconst_0
    //   313: istore #8
    //   315: aload #18
    //   317: iload #8
    //   319: putfield a : Z
    //   322: aload #18
    //   324: aconst_null
    //   325: putfield b : Ljava/lang/String;
    //   328: aload #18
    //   330: aconst_null
    //   331: putfield c : Ljava/lang/String;
    //   334: aconst_null
    //   335: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   338: ifeq -> 356
    //   341: aconst_null
    //   342: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   345: ifne -> 351
    //   348: goto -> 356
    //   351: iconst_0
    //   352: istore_2
    //   353: goto -> 358
    //   356: iconst_1
    //   357: istore_2
    //   358: aconst_null
    //   359: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   362: istore #8
    //   364: iload_2
    //   365: ifeq -> 389
    //   368: iload #8
    //   370: iconst_1
    //   371: ixor
    //   372: ifne -> 378
    //   375: goto -> 389
    //   378: new java/lang/IllegalArgumentException
    //   381: dup
    //   382: ldc_w 'Please provide Old SKU purchase information(token/id) or original external transaction id, not both.'
    //   385: invokespecial <init> : (Ljava/lang/String;)V
    //   388: athrow
    //   389: new e0/e$b
    //   392: dup
    //   393: invokespecial <init> : ()V
    //   396: astore #11
    //   398: aload #11
    //   400: aconst_null
    //   401: putfield a : Ljava/lang/String;
    //   404: aload #11
    //   406: iconst_0
    //   407: putfield b : I
    //   410: aload #18
    //   412: aload #11
    //   414: putfield d : Le0/e$b;
    //   417: aload #18
    //   419: new java/util/ArrayList
    //   422: dup
    //   423: aload_1
    //   424: invokespecial <init> : (Ljava/util/Collection;)V
    //   427: putfield f : Ljava/util/ArrayList;
    //   430: aload #18
    //   432: iconst_0
    //   433: putfield g : Z
    //   436: getstatic a1/s.j : La1/q;
    //   439: astore_1
    //   440: aload #18
    //   442: getstatic a1/b.m : La1/b;
    //   445: putfield e : La1/s;
    //   448: aload_0
    //   449: getfield e : Le0/c;
    //   452: astore_1
    //   453: aload_1
    //   454: invokevirtual e : ()Z
    //   457: ifne -> 463
    //   460: goto -> 2324
    //   463: new java/util/ArrayList
    //   466: dup
    //   467: invokespecial <init> : ()V
    //   470: astore #23
    //   472: aload #23
    //   474: aload #18
    //   476: getfield f : Ljava/util/ArrayList;
    //   479: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   482: pop
    //   483: aload #18
    //   485: getfield e : La1/s;
    //   488: astore #12
    //   490: aload #23
    //   492: invokeinterface iterator : ()Ljava/util/Iterator;
    //   497: astore #11
    //   499: aload #11
    //   501: invokeinterface hasNext : ()Z
    //   506: ifeq -> 521
    //   509: aload #11
    //   511: invokeinterface next : ()Ljava/lang/Object;
    //   516: astore #11
    //   518: goto -> 524
    //   521: aconst_null
    //   522: astore #11
    //   524: aload #11
    //   526: checkcast com/android/billingclient/api/SkuDetails
    //   529: astore #11
    //   531: aload #12
    //   533: invokeinterface iterator : ()Ljava/util/Iterator;
    //   538: astore #13
    //   540: aload #13
    //   542: invokeinterface hasNext : ()Z
    //   547: ifeq -> 562
    //   550: aload #13
    //   552: invokeinterface next : ()Ljava/lang/Object;
    //   557: astore #13
    //   559: goto -> 565
    //   562: aconst_null
    //   563: astore #13
    //   565: aload #13
    //   567: checkcast e0/e$a
    //   570: astore #22
    //   572: aload #11
    //   574: ifnull -> 2387
    //   577: aload #11
    //   579: getfield b : Lorg/json/JSONObject;
    //   582: ldc_w 'productId'
    //   585: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   588: astore #19
    //   590: aload #11
    //   592: invokevirtual a : ()Ljava/lang/String;
    //   595: astore #20
    //   597: aload #20
    //   599: ldc_w 'subs'
    //   602: invokevirtual equals : (Ljava/lang/Object;)Z
    //   605: ifeq -> 635
    //   608: aload_1
    //   609: getfield h : Z
    //   612: ifeq -> 618
    //   615: goto -> 635
    //   618: ldc_w 'BillingClient'
    //   621: ldc_w 'Current client doesn't support subscriptions.'
    //   624: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   627: getstatic e0/t.k : Le0/f;
    //   630: astore #11
    //   632: goto -> 786
    //   635: aload #18
    //   637: getfield b : Ljava/lang/String;
    //   640: ifnonnull -> 683
    //   643: aload #18
    //   645: getfield c : Ljava/lang/String;
    //   648: ifnonnull -> 683
    //   651: aload #18
    //   653: getfield d : Le0/e$b;
    //   656: getfield b : I
    //   659: ifne -> 683
    //   662: aload #18
    //   664: getfield a : Z
    //   667: ifne -> 683
    //   670: aload #18
    //   672: getfield g : Z
    //   675: ifne -> 683
    //   678: iconst_0
    //   679: istore_2
    //   680: goto -> 685
    //   683: iconst_1
    //   684: istore_2
    //   685: iload_2
    //   686: ifeq -> 716
    //   689: aload_1
    //   690: getfield j : Z
    //   693: ifeq -> 699
    //   696: goto -> 716
    //   699: ldc_w 'BillingClient'
    //   702: ldc_w 'Current client doesn't support extra params for buy intent.'
    //   705: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   708: getstatic e0/t.f : Le0/f;
    //   711: astore #11
    //   713: goto -> 786
    //   716: aload #23
    //   718: invokevirtual size : ()I
    //   721: iconst_1
    //   722: if_icmple -> 752
    //   725: aload_1
    //   726: getfield o : Z
    //   729: ifeq -> 735
    //   732: goto -> 752
    //   735: ldc_w 'BillingClient'
    //   738: ldc_w 'Current client doesn't support multi-item purchases.'
    //   741: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   744: getstatic e0/t.l : Le0/f;
    //   747: astore #11
    //   749: goto -> 786
    //   752: aload #12
    //   754: invokeinterface isEmpty : ()Z
    //   759: ifne -> 789
    //   762: aload_1
    //   763: getfield p : Z
    //   766: ifeq -> 772
    //   769: goto -> 789
    //   772: ldc_w 'BillingClient'
    //   775: ldc_w 'Current client doesn't support purchases with ProductDetails.'
    //   778: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   781: getstatic e0/t.n : Le0/f;
    //   784: astore #11
    //   786: goto -> 2357
    //   789: aload_1
    //   790: getfield j : Z
    //   793: ifeq -> 2084
    //   796: aload_1
    //   797: getfield k : Z
    //   800: istore #8
    //   802: aload_1
    //   803: getfield q : Z
    //   806: istore #9
    //   808: aload_1
    //   809: getfield r : Z
    //   812: istore #10
    //   814: aload_1
    //   815: getfield b : Ljava/lang/String;
    //   818: astore #13
    //   820: getstatic a1/i.a : I
    //   823: istore_2
    //   824: new android/os/Bundle
    //   827: dup
    //   828: invokespecial <init> : ()V
    //   831: astore #21
    //   833: aload #21
    //   835: ldc_w 'playBillingLibraryVersion'
    //   838: aload #13
    //   840: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   843: aload #18
    //   845: getfield d : Le0/e$b;
    //   848: getfield b : I
    //   851: istore_2
    //   852: iload_2
    //   853: ifeq -> 865
    //   856: aload #21
    //   858: ldc_w 'prorationMode'
    //   861: iload_2
    //   862: invokevirtual putInt : (Ljava/lang/String;I)V
    //   865: aload #18
    //   867: getfield b : Ljava/lang/String;
    //   870: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   873: ifne -> 889
    //   876: aload #21
    //   878: ldc_w 'accountId'
    //   881: aload #18
    //   883: getfield b : Ljava/lang/String;
    //   886: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   889: aload #18
    //   891: getfield c : Ljava/lang/String;
    //   894: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   897: ifne -> 913
    //   900: aload #21
    //   902: ldc_w 'obfuscatedProfileId'
    //   905: aload #18
    //   907: getfield c : Ljava/lang/String;
    //   910: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   913: aload #18
    //   915: getfield g : Z
    //   918: ifeq -> 930
    //   921: aload #21
    //   923: ldc_w 'isOfferPersonalizedByDeveloper'
    //   926: iconst_1
    //   927: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   930: aconst_null
    //   931: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   934: ifne -> 963
    //   937: aload #21
    //   939: ldc_w 'skusToReplace'
    //   942: new java/util/ArrayList
    //   945: dup
    //   946: iconst_1
    //   947: anewarray java/lang/String
    //   950: dup
    //   951: iconst_0
    //   952: aconst_null
    //   953: aastore
    //   954: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   957: invokespecial <init> : (Ljava/util/Collection;)V
    //   960: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   963: aload #18
    //   965: getfield d : Le0/e$b;
    //   968: getfield a : Ljava/lang/String;
    //   971: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   974: ifne -> 993
    //   977: aload #21
    //   979: ldc_w 'oldSkuPurchaseToken'
    //   982: aload #18
    //   984: getfield d : Le0/e$b;
    //   987: getfield a : Ljava/lang/String;
    //   990: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   993: aconst_null
    //   994: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   997: ifne -> 1009
    //   1000: aload #21
    //   1002: ldc_w 'oldSkuPurchaseId'
    //   1005: aconst_null
    //   1006: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1009: aconst_null
    //   1010: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1013: ifne -> 1025
    //   1016: aload #21
    //   1018: ldc_w 'originalExternalTransactionId'
    //   1021: aconst_null
    //   1022: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1025: aconst_null
    //   1026: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1029: ifne -> 1041
    //   1032: aload #21
    //   1034: ldc_w 'paymentsPurchaseParams'
    //   1037: aconst_null
    //   1038: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1041: iload #8
    //   1043: ifeq -> 1063
    //   1046: iload #9
    //   1048: ifeq -> 1063
    //   1051: aload #21
    //   1053: ldc_w 'enablePendingPurchases'
    //   1056: iconst_1
    //   1057: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   1060: goto -> 1063
    //   1063: iload #10
    //   1065: ifeq -> 1077
    //   1068: aload #21
    //   1070: ldc_w 'enableAlternativeBilling'
    //   1073: iconst_1
    //   1074: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   1077: aload #23
    //   1079: invokevirtual isEmpty : ()Z
    //   1082: istore #8
    //   1084: ldc_w 'additionalSkuTypes'
    //   1087: astore #14
    //   1089: ldc_w 'additionalSkus'
    //   1092: astore #13
    //   1094: iload #8
    //   1096: ifne -> 1613
    //   1099: new java/util/ArrayList
    //   1102: dup
    //   1103: invokespecial <init> : ()V
    //   1106: astore #17
    //   1108: new java/util/ArrayList
    //   1111: dup
    //   1112: invokespecial <init> : ()V
    //   1115: astore #24
    //   1117: new java/util/ArrayList
    //   1120: dup
    //   1121: invokespecial <init> : ()V
    //   1124: astore #25
    //   1126: new java/util/ArrayList
    //   1129: dup
    //   1130: invokespecial <init> : ()V
    //   1133: astore #26
    //   1135: new java/util/ArrayList
    //   1138: dup
    //   1139: invokespecial <init> : ()V
    //   1142: astore #27
    //   1144: aload #23
    //   1146: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1149: astore #28
    //   1151: iconst_0
    //   1152: istore #5
    //   1154: iconst_0
    //   1155: istore #4
    //   1157: iconst_0
    //   1158: istore_3
    //   1159: iconst_0
    //   1160: istore_2
    //   1161: aload #28
    //   1163: invokeinterface hasNext : ()Z
    //   1168: ifeq -> 1389
    //   1171: aload #28
    //   1173: invokeinterface next : ()Ljava/lang/Object;
    //   1178: checkcast com/android/billingclient/api/SkuDetails
    //   1181: astore #29
    //   1183: aload #29
    //   1185: getfield b : Lorg/json/JSONObject;
    //   1188: ldc_w 'skuDetailsToken'
    //   1191: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1194: invokevirtual isEmpty : ()Z
    //   1197: ifne -> 1217
    //   1200: aload #17
    //   1202: aload #29
    //   1204: getfield b : Lorg/json/JSONObject;
    //   1207: ldc_w 'skuDetailsToken'
    //   1210: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1213: invokevirtual add : (Ljava/lang/Object;)Z
    //   1216: pop
    //   1217: aload #29
    //   1219: getfield b : Lorg/json/JSONObject;
    //   1222: ldc_w 'offerIdToken'
    //   1225: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1228: astore #16
    //   1230: aload #16
    //   1232: astore #15
    //   1234: aload #16
    //   1236: invokevirtual isEmpty : ()Z
    //   1239: ifeq -> 1255
    //   1242: aload #29
    //   1244: getfield b : Lorg/json/JSONObject;
    //   1247: ldc_w 'offer_id_token'
    //   1250: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1253: astore #15
    //   1255: aload #29
    //   1257: getfield b : Lorg/json/JSONObject;
    //   1260: ldc_w 'offer_id'
    //   1263: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1266: astore #16
    //   1268: aload #29
    //   1270: getfield b : Lorg/json/JSONObject;
    //   1273: ldc_w 'offer_type'
    //   1276: invokevirtual optInt : (Ljava/lang/String;)I
    //   1279: istore #7
    //   1281: aload #29
    //   1283: getfield b : Lorg/json/JSONObject;
    //   1286: ldc_w 'serializedDocid'
    //   1289: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1292: astore #29
    //   1294: aload #24
    //   1296: aload #15
    //   1298: invokevirtual add : (Ljava/lang/Object;)Z
    //   1301: pop
    //   1302: iload #5
    //   1304: aload #15
    //   1306: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1309: iconst_1
    //   1310: ixor
    //   1311: ior
    //   1312: istore #5
    //   1314: aload #25
    //   1316: aload #16
    //   1318: invokevirtual add : (Ljava/lang/Object;)Z
    //   1321: pop
    //   1322: iload #4
    //   1324: aload #16
    //   1326: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1329: iconst_1
    //   1330: ixor
    //   1331: ior
    //   1332: istore #6
    //   1334: aload #26
    //   1336: iload #7
    //   1338: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1341: invokevirtual add : (Ljava/lang/Object;)Z
    //   1344: pop
    //   1345: iload #7
    //   1347: ifeq -> 1356
    //   1350: iconst_1
    //   1351: istore #4
    //   1353: goto -> 1359
    //   1356: iconst_0
    //   1357: istore #4
    //   1359: iload_3
    //   1360: iload #4
    //   1362: ior
    //   1363: istore_3
    //   1364: iload_2
    //   1365: aload #29
    //   1367: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1370: iconst_1
    //   1371: ixor
    //   1372: ior
    //   1373: istore_2
    //   1374: aload #27
    //   1376: aload #29
    //   1378: invokevirtual add : (Ljava/lang/Object;)Z
    //   1381: pop
    //   1382: iload #6
    //   1384: istore #4
    //   1386: goto -> 1161
    //   1389: aload_1
    //   1390: astore #15
    //   1392: aload #11
    //   1394: astore #16
    //   1396: aload #17
    //   1398: invokevirtual isEmpty : ()Z
    //   1401: ifne -> 1414
    //   1404: aload #21
    //   1406: ldc_w 'skuDetailsTokens'
    //   1409: aload #17
    //   1411: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1414: iload #5
    //   1416: ifeq -> 1429
    //   1419: aload #21
    //   1421: ldc_w 'SKU_OFFER_ID_TOKEN_LIST'
    //   1424: aload #24
    //   1426: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1429: iload #4
    //   1431: ifeq -> 1444
    //   1434: aload #21
    //   1436: ldc_w 'SKU_OFFER_ID_LIST'
    //   1439: aload #25
    //   1441: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1444: iload_3
    //   1445: ifeq -> 1458
    //   1448: aload #21
    //   1450: ldc_w 'SKU_OFFER_TYPE_LIST'
    //   1453: aload #26
    //   1455: invokevirtual putIntegerArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1458: iload_2
    //   1459: ifeq -> 1472
    //   1462: aload #21
    //   1464: ldc_w 'SKU_SERIALIZED_DOCID_LIST'
    //   1467: aload #27
    //   1469: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1472: aload #15
    //   1474: astore_1
    //   1475: aload #16
    //   1477: astore #17
    //   1479: aload #12
    //   1481: astore #11
    //   1483: aload #23
    //   1485: invokevirtual size : ()I
    //   1488: iconst_1
    //   1489: if_icmple -> 1786
    //   1492: new java/util/ArrayList
    //   1495: dup
    //   1496: aload #23
    //   1498: invokevirtual size : ()I
    //   1501: iconst_1
    //   1502: isub
    //   1503: invokespecial <init> : (I)V
    //   1506: astore_1
    //   1507: new java/util/ArrayList
    //   1510: dup
    //   1511: aload #23
    //   1513: invokevirtual size : ()I
    //   1516: iconst_1
    //   1517: isub
    //   1518: invokespecial <init> : (I)V
    //   1521: astore #11
    //   1523: iconst_1
    //   1524: istore_2
    //   1525: iload_2
    //   1526: aload #23
    //   1528: invokevirtual size : ()I
    //   1531: if_icmpge -> 1582
    //   1534: aload_1
    //   1535: aload #23
    //   1537: iload_2
    //   1538: invokevirtual get : (I)Ljava/lang/Object;
    //   1541: checkcast com/android/billingclient/api/SkuDetails
    //   1544: getfield b : Lorg/json/JSONObject;
    //   1547: ldc_w 'productId'
    //   1550: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1553: invokevirtual add : (Ljava/lang/Object;)Z
    //   1556: pop
    //   1557: aload #11
    //   1559: aload #23
    //   1561: iload_2
    //   1562: invokevirtual get : (I)Ljava/lang/Object;
    //   1565: checkcast com/android/billingclient/api/SkuDetails
    //   1568: invokevirtual a : ()Ljava/lang/String;
    //   1571: invokevirtual add : (Ljava/lang/Object;)Z
    //   1574: pop
    //   1575: iload_2
    //   1576: iconst_1
    //   1577: iadd
    //   1578: istore_2
    //   1579: goto -> 1525
    //   1582: aload #21
    //   1584: aload #13
    //   1586: aload_1
    //   1587: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1590: aload #21
    //   1592: aload #14
    //   1594: aload #11
    //   1596: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1599: aload #15
    //   1601: astore_1
    //   1602: aload #16
    //   1604: astore #17
    //   1606: aload #12
    //   1608: astore #11
    //   1610: goto -> 1786
    //   1613: aload_1
    //   1614: astore #13
    //   1616: aload #11
    //   1618: astore #14
    //   1620: new java/util/ArrayList
    //   1623: dup
    //   1624: aload #12
    //   1626: invokeinterface size : ()I
    //   1631: iconst_1
    //   1632: isub
    //   1633: invokespecial <init> : (I)V
    //   1636: astore #15
    //   1638: new java/util/ArrayList
    //   1641: dup
    //   1642: aload #12
    //   1644: invokeinterface size : ()I
    //   1649: iconst_1
    //   1650: isub
    //   1651: invokespecial <init> : (I)V
    //   1654: astore #16
    //   1656: new java/util/ArrayList
    //   1659: dup
    //   1660: invokespecial <init> : ()V
    //   1663: astore_1
    //   1664: new java/util/ArrayList
    //   1667: dup
    //   1668: invokespecial <init> : ()V
    //   1671: astore #11
    //   1673: new java/util/ArrayList
    //   1676: dup
    //   1677: invokespecial <init> : ()V
    //   1680: astore #17
    //   1682: aload #12
    //   1684: invokeinterface size : ()I
    //   1689: ifgt -> 2067
    //   1692: aload #21
    //   1694: ldc_w 'SKU_OFFER_ID_TOKEN_LIST'
    //   1697: aload #11
    //   1699: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1702: aload_1
    //   1703: invokevirtual isEmpty : ()Z
    //   1706: ifne -> 1718
    //   1709: aload #21
    //   1711: ldc_w 'skuDetailsTokens'
    //   1714: aload_1
    //   1715: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1718: aload #17
    //   1720: invokevirtual isEmpty : ()Z
    //   1723: ifne -> 1736
    //   1726: aload #21
    //   1728: ldc_w 'SKU_SERIALIZED_DOCID_LIST'
    //   1731: aload #17
    //   1733: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1736: aload #13
    //   1738: astore_1
    //   1739: aload #14
    //   1741: astore #17
    //   1743: aload #12
    //   1745: astore #11
    //   1747: aload #15
    //   1749: invokevirtual isEmpty : ()Z
    //   1752: ifne -> 1786
    //   1755: aload #21
    //   1757: ldc_w 'additionalSkus'
    //   1760: aload #15
    //   1762: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1765: aload #21
    //   1767: ldc_w 'additionalSkuTypes'
    //   1770: aload #16
    //   1772: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   1775: aload #12
    //   1777: astore #11
    //   1779: aload #14
    //   1781: astore #17
    //   1783: aload #13
    //   1785: astore_1
    //   1786: aload #21
    //   1788: ldc_w 'SKU_OFFER_ID_TOKEN_LIST'
    //   1791: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   1794: istore #8
    //   1796: iload #8
    //   1798: ifeq -> 1819
    //   1801: aload_1
    //   1802: getfield m : Z
    //   1805: ifeq -> 1811
    //   1808: goto -> 1819
    //   1811: getstatic e0/t.m : Le0/f;
    //   1814: astore #11
    //   1816: goto -> 2357
    //   1819: aload #17
    //   1821: getfield b : Lorg/json/JSONObject;
    //   1824: ldc_w 'packageName'
    //   1827: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1830: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1833: ifne -> 1860
    //   1836: aload #21
    //   1838: ldc_w 'skuPackageName'
    //   1841: aload #17
    //   1843: getfield b : Lorg/json/JSONObject;
    //   1846: ldc_w 'packageName'
    //   1849: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1852: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1855: iconst_1
    //   1856: istore_2
    //   1857: goto -> 1867
    //   1860: aload #22
    //   1862: ifnonnull -> 2065
    //   1865: iconst_0
    //   1866: istore_2
    //   1867: aconst_null
    //   1868: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1871: ifne -> 1883
    //   1874: aload #21
    //   1876: ldc_w 'accountName'
    //   1879: aconst_null
    //   1880: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1883: aload_0
    //   1884: invokevirtual getIntent : ()Landroid/content/Intent;
    //   1887: astore #12
    //   1889: aload #12
    //   1891: ifnonnull -> 1906
    //   1894: ldc_w 'BillingClient'
    //   1897: ldc_w 'Activity's intent is null.'
    //   1900: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   1903: goto -> 1982
    //   1906: aload #12
    //   1908: ldc_w 'PROXY_PACKAGE'
    //   1911: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   1914: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1917: ifne -> 1982
    //   1920: aload #12
    //   1922: ldc_w 'PROXY_PACKAGE'
    //   1925: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   1928: astore #12
    //   1930: aload #21
    //   1932: ldc_w 'proxyPackage'
    //   1935: aload #12
    //   1937: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1940: aload_1
    //   1941: getfield e : Landroid/content/Context;
    //   1944: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   1947: aload #12
    //   1949: iconst_0
    //   1950: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   1953: getfield versionName : Ljava/lang/String;
    //   1956: astore #12
    //   1958: aload #21
    //   1960: ldc_w 'proxyPackageVersion'
    //   1963: aload #12
    //   1965: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1968: goto -> 1982
    //   1971: aload #21
    //   1973: ldc_w 'proxyPackageVersion'
    //   1976: ldc_w 'package not found'
    //   1979: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   1982: ldc_w 'BillingClient'
    //   1985: astore #12
    //   1987: aload_1
    //   1988: getfield p : Z
    //   1991: ifeq -> 2010
    //   1994: aload #11
    //   1996: invokeinterface isEmpty : ()Z
    //   2001: ifne -> 2010
    //   2004: bipush #17
    //   2006: istore_2
    //   2007: goto -> 2043
    //   2010: aload_1
    //   2011: getfield n : Z
    //   2014: ifeq -> 2027
    //   2017: iload_2
    //   2018: ifeq -> 2027
    //   2021: bipush #15
    //   2023: istore_2
    //   2024: goto -> 2043
    //   2027: aload_1
    //   2028: getfield k : Z
    //   2031: ifeq -> 2040
    //   2034: bipush #9
    //   2036: istore_2
    //   2037: goto -> 2043
    //   2040: bipush #6
    //   2042: istore_2
    //   2043: new e0/l
    //   2046: dup
    //   2047: aload_1
    //   2048: iload_2
    //   2049: aload #19
    //   2051: aload #20
    //   2053: aload #18
    //   2055: aload #21
    //   2057: invokespecial <init> : (Le0/c;ILjava/lang/String;Ljava/lang/String;Le0/e;Landroid/os/Bundle;)V
    //   2060: astore #11
    //   2062: goto -> 2104
    //   2065: aconst_null
    //   2066: athrow
    //   2067: aload #12
    //   2069: iconst_0
    //   2070: invokeinterface get : (I)Ljava/lang/Object;
    //   2075: checkcast e0/e$a
    //   2078: invokevirtual getClass : ()Ljava/lang/Class;
    //   2081: pop
    //   2082: aconst_null
    //   2083: athrow
    //   2084: ldc_w 'BillingClient'
    //   2087: astore #12
    //   2089: new e0/j
    //   2092: dup
    //   2093: aload_1
    //   2094: aload #19
    //   2096: aload #20
    //   2098: iconst_1
    //   2099: invokespecial <init> : (Le0/c;Ljava/lang/Object;Ljava/lang/Object;I)V
    //   2102: astore #11
    //   2104: aload_1
    //   2105: aload #11
    //   2107: ldc2_w 5000
    //   2110: aconst_null
    //   2111: aload_1
    //   2112: getfield c : Landroid/os/Handler;
    //   2115: invokevirtual i : (Ljava/util/concurrent/Callable;JLjava/lang/Runnable;Landroid/os/Handler;)Ljava/util/concurrent/Future;
    //   2118: astore #11
    //   2120: aload #11
    //   2122: ldc2_w 5000
    //   2125: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   2128: invokeinterface get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   2133: checkcast android/os/Bundle
    //   2136: astore #13
    //   2138: aload #13
    //   2140: aload #12
    //   2142: invokestatic a : (Landroid/os/Bundle;Ljava/lang/String;)I
    //   2145: istore_2
    //   2146: aload #13
    //   2148: aload #12
    //   2150: invokestatic d : (Landroid/os/Bundle;Ljava/lang/String;)Ljava/lang/String;
    //   2153: astore #11
    //   2155: iload_2
    //   2156: ifeq -> 2246
    //   2159: new java/lang/StringBuilder
    //   2162: dup
    //   2163: invokespecial <init> : ()V
    //   2166: astore #13
    //   2168: aload #13
    //   2170: ldc_w 'Unable to buy item, Error response code: '
    //   2173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2176: pop
    //   2177: aload #13
    //   2179: iload_2
    //   2180: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2183: pop
    //   2184: aload #12
    //   2186: aload #13
    //   2188: invokevirtual toString : ()Ljava/lang/String;
    //   2191: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   2194: new e0/f
    //   2197: dup
    //   2198: invokespecial <init> : ()V
    //   2201: astore #13
    //   2203: aload #13
    //   2205: iload_2
    //   2206: putfield a : I
    //   2209: aload #13
    //   2211: aload #11
    //   2213: putfield b : Ljava/lang/String;
    //   2216: invokestatic interrupted : ()Z
    //   2219: ifeq -> 2225
    //   2222: goto -> 2455
    //   2225: aload_1
    //   2226: getfield c : Landroid/os/Handler;
    //   2229: new e0/n
    //   2232: dup
    //   2233: aload_1
    //   2234: aload #13
    //   2236: invokespecial <init> : (Le0/c;Le0/f;)V
    //   2239: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   2242: pop
    //   2243: goto -> 2455
    //   2246: aload_0
    //   2247: astore #11
    //   2249: new android/content/Intent
    //   2252: dup
    //   2253: aload #11
    //   2255: ldc_w com/android/billingclient/api/ProxyBillingActivity
    //   2258: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   2261: astore #14
    //   2263: aload #14
    //   2265: ldc_w 'BUY_INTENT'
    //   2268: aload #13
    //   2270: ldc_w 'BUY_INTENT'
    //   2273: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   2276: checkcast android/app/PendingIntent
    //   2279: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   2282: pop
    //   2283: aload #11
    //   2285: aload #14
    //   2287: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   2290: getstatic e0/t.a : Le0/f;
    //   2293: astore_1
    //   2294: goto -> 2419
    //   2297: astore #11
    //   2299: goto -> 2314
    //   2302: astore #11
    //   2304: goto -> 2342
    //   2307: astore #11
    //   2309: goto -> 2342
    //   2312: astore #11
    //   2314: aload #12
    //   2316: ldc_w 'Exception while launching billing flow. Try to reconnect'
    //   2319: aload #11
    //   2321: invokestatic g : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   2324: getstatic e0/t.i : Le0/f;
    //   2327: astore #11
    //   2329: goto -> 2357
    //   2332: astore #11
    //   2334: goto -> 2342
    //   2337: astore #11
    //   2339: goto -> 2334
    //   2342: aload #12
    //   2344: ldc_w 'Time out while launching billing flow. Try to reconnect'
    //   2347: aload #11
    //   2349: invokestatic g : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   2352: getstatic e0/t.j : Le0/f;
    //   2355: astore #11
    //   2357: invokestatic interrupted : ()Z
    //   2360: ifeq -> 2366
    //   2363: goto -> 2419
    //   2366: aload_1
    //   2367: getfield c : Landroid/os/Handler;
    //   2370: new e0/n
    //   2373: dup
    //   2374: aload_1
    //   2375: aload #11
    //   2377: invokespecial <init> : (Le0/c;Le0/f;)V
    //   2380: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   2383: pop
    //   2384: goto -> 2419
    //   2387: aload #22
    //   2389: invokevirtual getClass : ()Ljava/lang/Class;
    //   2392: pop
    //   2393: aconst_null
    //   2394: athrow
    //   2395: new java/lang/IllegalArgumentException
    //   2398: dup
    //   2399: ldc_w 'SKU cannot be null.'
    //   2402: invokespecial <init> : (Ljava/lang/String;)V
    //   2405: athrow
    //   2406: aconst_null
    //   2407: athrow
    //   2408: new java/lang/IllegalArgumentException
    //   2411: dup
    //   2412: ldc_w 'Details of the products must be provided.'
    //   2415: invokespecial <init> : (Ljava/lang/String;)V
    //   2418: athrow
    //   2419: aload_0
    //   2420: getfield l : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   2423: astore_1
    //   2424: aload_1
    //   2425: ifnull -> 2442
    //   2428: aload_1
    //   2429: new android/os/Bundle
    //   2432: dup
    //   2433: invokespecial <init> : ()V
    //   2436: ldc_w 'purchase_view_ads_free'
    //   2439: invokevirtual a : (Landroid/os/Bundle;Ljava/lang/String;)V
    //   2442: return
    //   2443: astore #12
    //   2445: goto -> 1971
    //   2448: astore #12
    //   2450: goto -> 1971
    //   2453: astore_1
    //   2454: return
    //   2455: goto -> 2419
    // Exception table:
    //   from	to	target	type
    //   1940	1958	2443	android/content/pm/PackageManager$NameNotFoundException
    //   1958	1968	2448	android/content/pm/PackageManager$NameNotFoundException
    //   2120	2155	2337	java/util/concurrent/TimeoutException
    //   2120	2155	2332	java/util/concurrent/CancellationException
    //   2120	2155	2312	java/lang/Exception
    //   2159	2222	2337	java/util/concurrent/TimeoutException
    //   2159	2222	2332	java/util/concurrent/CancellationException
    //   2159	2222	2312	java/lang/Exception
    //   2225	2243	2337	java/util/concurrent/TimeoutException
    //   2225	2243	2332	java/util/concurrent/CancellationException
    //   2225	2243	2312	java/lang/Exception
    //   2249	2290	2307	java/util/concurrent/TimeoutException
    //   2249	2290	2302	java/util/concurrent/CancellationException
    //   2249	2290	2297	java/lang/Exception
    //   2419	2424	2453	java/lang/Error
    //   2419	2424	2453	java/lang/Exception
    //   2428	2442	2453	java/lang/Error
    //   2428	2442	2453	java/lang/Exception
  }
  
  public void sOffClicked(View paramView) {
    h();
    c.c.b("Sound.xml", String.valueOf(0));
  }
  
  public void sOnClicked(View paramView) {
    i();
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("Sound.xml", String.valueOf(1));
  }
  
  public void spClicked(View paramView) {
    Intent intent = new Intent("android.intent.action.SEND");
    intent.setType("text/plain");
    intent.putExtra("android.intent.extra.EMAIL", new String[] { "help.checkers@mail.ru" });
    startActivity(Intent.createChooser(intent, "Send Email"));
  }
  
  public void tm1Clicked(View paramView) {
    f();
    ViewParent viewParent = ((Button)findViewById(2131165287)).getParent();
    if (viewParent != null)
      ((LinearLayout)viewParent).setBackgroundResource(2131099818); 
    a0.e((Context)this, (RelativeLayout)findViewById(2131165436), s, false);
    c.c.b("Theme.xml", String.valueOf(0));
  }
  
  public void tm2Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("dark_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 1)).execute((Object[])new String[] { str });
  }
  
  public void tm3Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("gold_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 2)).execute((Object[])new String[] { str });
  }
  
  public void tm4Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("white_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 3)).execute((Object[])new String[] { str });
  }
  
  public void tm5Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("neo_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 4)).execute((Object[])new String[] { str });
  }
  
  public void tm6Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("ace_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 5)).execute((Object[])new String[] { str });
  }
  
  public void tm7Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("gray_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 6)).execute((Object[])new String[] { str });
  }
  
  public void tm8Clicked(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://s3-us-west-2.amazonaws.com/publicfilesbox/");
    stringBuilder.append("themes/");
    stringBuilder.append("green_");
    stringBuilder.append(t);
    stringBuilder.append(".zip");
    String str = stringBuilder.toString();
    (new l(this, 7)).execute((Object[])new String[] { str });
  }
  
  public void v0Clicked(View paramView) {
    l();
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("View.xml", String.valueOf(1));
    if (MenuActivity.V != null) {
      SharedPreferences.Editor editor = this.i;
      if (editor != null) {
        editor.putBoolean("isMenuFinisfed", true);
        this.i.commit();
      } 
      MenuActivity.V.finish();
      this.j = true;
    } 
  }
  
  public void v1Clicked(View paramView) {
    m();
    if (this.b) {
      SoundPool soundPool = o;
      if (soundPool != null) {
        soundPool.autoPause();
        o.play(n, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
    c.c.b("View.xml", String.valueOf(0));
    if (MenuActivity.V != null) {
      SharedPreferences.Editor editor = this.i;
      if (editor != null) {
        editor.putBoolean("isMenuFinisfed", true);
        this.i.commit();
      } 
      MenuActivity.V.finish();
      this.j = true;
    } 
  }
  
  public final class a implements View.OnSystemUiVisibilityChangeListener {
    public a(SetActivity this$0) {}
    
    public final void onSystemUiVisibilityChange(int param1Int) {
      if ((param1Int & 0x4) == 0)
        this.a.setSystemUiVisibility(5894); 
    }
  }
  
  public final class b implements h {
    public b(SetActivity this$0) {}
    
    public final void a(f param1f, List<Purchase> param1List) {
      if (param1f.a == 0 && param1List != null) {
        Iterator<Purchase> iterator = param1List.iterator();
        while (true) {
          if (iterator.hasNext()) {
            Purchase purchase = iterator.next();
            if (purchase != null) {
              SetActivity setActivity = this.a;
              setActivity.i.putBoolean("checkers_removed_ads", true);
              setActivity.i.commit();
              SetActivity.u = true;
              LinearLayout linearLayout = (LinearLayout)setActivity.findViewById(2131165352);
              if (linearLayout != null)
                linearLayout.setVisibility(8); 
              try {
                FirebaseAnalytics firebaseAnalytics = setActivity.l;
                if (firebaseAnalytics != null)
                  firebaseAnalytics.a(new Bundle(), "purchase_ads_free"); 
              } catch (Error|Exception error) {}
              JSONObject jSONObject = purchase.c;
              String str = jSONObject.optString("token", jSONObject.optString("purchaseToken"));
              if (str != null) {
                e0.a a = new e0.a();
                a.a = str;
                c.c c1 = new c.c();
                e0.c c = setActivity.e;
                if (c.e())
                  if (TextUtils.isEmpty(a.a)) {
                    i.f("BillingClient", "Please provide a valid purchase token.");
                  } else if (c.k) {
                    if (c.i((Callable)new j(c, a, c1, 0), 30000L, (Runnable)new k(0, c1), c.g()) == null)
                      c.h(); 
                    continue;
                  }  
                f f1 = t.a;
                continue;
              } 
              throw new IllegalArgumentException("Purchase token must be set");
            } 
            continue;
          } 
          return;
        } 
      } 
    }
  }
  
  public final class c implements d {
    public c(SetActivity this$0) {}
    
    public final void a(f param1f) {
      z z;
      SetActivity setActivity = this.a;
      setActivity.k = false;
      if (param1f.a == 0) {
        f f1;
        ArrayList<String> arrayList1 = new ArrayList();
        arrayList1.add(setActivity.g);
        ArrayList<String> arrayList2 = new ArrayList<String>(arrayList1);
        e0.c c1 = setActivity.e;
        z = new z(setActivity);
        if (!c1.e()) {
          f1 = t.i;
        } else if (!TextUtils.isEmpty("inapp")) {
          ArrayList<v> arrayList = new ArrayList();
          for (String str : arrayList2) {
            if (!TextUtils.isEmpty(str)) {
              arrayList.add(new v(str));
              continue;
            } 
            throw new IllegalArgumentException("SKU must be set.");
          } 
          if (f1.i((Callable)new f4((e0.c)f1, "inapp", arrayList, z), 30000L, (Runnable)new r(1, z), f1.g()) == null) {
            f1 = f1.h();
          } else {
            return;
          } 
        } else {
          i.f("BillingClient", "Please fix the input params. SKU type can't be empty.");
          f1 = t.d;
        } 
        z.a(f1, null);
        return;
      } 
      ((SetActivity)z).k = true;
      LinearLayout linearLayout = (LinearLayout)z.findViewById(2131165352);
      if (linearLayout != null)
        linearLayout.setVisibility(8); 
    }
    
    public final void b() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\SetActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */