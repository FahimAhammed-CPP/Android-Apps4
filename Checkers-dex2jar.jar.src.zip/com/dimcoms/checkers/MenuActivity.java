package com.dimcoms.checkers;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.billingclient.api.Purchase;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import org.json.JSONArray;

public class MenuActivity extends Activity {
  public static int A = 0;
  
  public static int B = 0;
  
  public static int C = 0;
  
  public static int D = 0;
  
  public static boolean E = true;
  
  public static int F = 0;
  
  public static int G = 0;
  
  public static int H = 0;
  
  public static RelativeLayout I;
  
  public static RelativeLayout J;
  
  public static RelativeLayout K;
  
  public static RelativeLayout L;
  
  public static RelativeLayout M;
  
  public static RelativeLayout N;
  
  public static RelativeLayout O;
  
  public static RelativeLayout P;
  
  public static RelativeLayout Q;
  
  public static RelativeLayout R;
  
  public static RelativeLayout S;
  
  public static RelativeLayout T;
  
  public static RelativeLayout U;
  
  public static MenuActivity V;
  
  public static int W = 0;
  
  public static float X = 0.0F;
  
  public static boolean w = false;
  
  public static int x;
  
  public static SoundPool y;
  
  public static int z;
  
  public boolean a = false;
  
  public int b;
  
  public SharedPreferences c;
  
  public SharedPreferences.Editor d;
  
  public e0.c e;
  
  public String f = "ads_free";
  
  public int g;
  
  public int h;
  
  public boolean i = true;
  
  public boolean j;
  
  public boolean k = false;
  
  public boolean l = false;
  
  public boolean m = false;
  
  public boolean n = false;
  
  public boolean o = false;
  
  public boolean p = false;
  
  public boolean q = false;
  
  public boolean r = false;
  
  public boolean s = false;
  
  public Toast t = null;
  
  public Toast u = null;
  
  public FirebaseAnalytics v;
  
  public static void b(int paramInt) {
    RelativeLayout relativeLayout;
    switch (paramInt) {
      default:
        return;
      case 12:
        relativeLayout = U;
        break;
      case 11:
        relativeLayout = T;
        break;
      case 10:
        relativeLayout = S;
        break;
      case 9:
        relativeLayout = R;
        break;
      case 8:
        relativeLayout = Q;
        break;
      case 7:
        relativeLayout = P;
        break;
      case 6:
        relativeLayout = O;
        break;
      case 5:
        relativeLayout = N;
        break;
      case 4:
        relativeLayout = M;
        break;
      case 3:
        relativeLayout = L;
        break;
      case 2:
        relativeLayout = J;
        break;
      case 1:
        relativeLayout = I;
        break;
      case 0:
        relativeLayout = K;
        break;
    } 
    relativeLayout.setBackgroundResource(0);
  }
  
  public static void c(MenuActivity paramMenuActivity) {
    Color.argb(200, 0, 0, 0);
    String str = String.valueOf(z);
    if (!str.equals("0")) {
      if (!str.equals("1")) {
        if (!str.equals("2")) {
          if (!str.equals("3")) {
            if (!str.equals("4")) {
              if (!str.equals("5")) {
                if (!str.equals("6")) {
                  if (!str.equals("7")) {
                    if (!str.equals("8")) {
                      RelativeLayout relativeLayout8 = (RelativeLayout)paramMenuActivity.findViewById(2131165236);
                      TextView textView8 = (TextView)paramMenuActivity.findViewById(2131165277);
                      SharedPreferences sharedPreferences9 = paramMenuActivity.c;
                      if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_9", sharedPreferences9, false)) {
                        sharedPreferences9 = paramMenuActivity.c;
                        StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
                        stringBuilder.append(paramMenuActivity.h);
                        stringBuilder.append("_9");
                        int i = sharedPreferences9.getInt(stringBuilder.toString(), 1);
                        f((RelativeLayout)paramMenuActivity.findViewById(2131165403), i);
                      } else {
                        f((RelativeLayout)paramMenuActivity.findViewById(2131165403), 0);
                      } 
                      relativeLayout8.setBackgroundResource(2131099823);
                      textView8.setText(2131427403);
                      paramMenuActivity.s = true;
                      ((RelativeLayout)paramMenuActivity.findViewById(2131165370)).setVisibility(8);
                    } 
                    RelativeLayout relativeLayout7 = (RelativeLayout)paramMenuActivity.findViewById(2131165245);
                    TextView textView7 = (TextView)paramMenuActivity.findViewById(2131165286);
                    SharedPreferences sharedPreferences8 = paramMenuActivity.c;
                    if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_8", sharedPreferences8, false)) {
                      sharedPreferences8 = paramMenuActivity.c;
                      StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
                      stringBuilder.append(paramMenuActivity.h);
                      stringBuilder.append("_8");
                      int i = sharedPreferences8.getInt(stringBuilder.toString(), 1);
                      f((RelativeLayout)paramMenuActivity.findViewById(2131165411), i);
                    } else {
                      f((RelativeLayout)paramMenuActivity.findViewById(2131165411), 0);
                    } 
                    relativeLayout7.setBackgroundResource(2131099823);
                    textView7.setText(2131427402);
                    paramMenuActivity.r = true;
                    ((RelativeLayout)paramMenuActivity.findViewById(2131165378)).setVisibility(8);
                  } 
                  RelativeLayout relativeLayout6 = (RelativeLayout)paramMenuActivity.findViewById(2131165244);
                  TextView textView6 = (TextView)paramMenuActivity.findViewById(2131165285);
                  SharedPreferences sharedPreferences7 = paramMenuActivity.c;
                  if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_7", sharedPreferences7, false)) {
                    sharedPreferences7 = paramMenuActivity.c;
                    StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
                    stringBuilder.append(paramMenuActivity.h);
                    stringBuilder.append("_7");
                    int i = sharedPreferences7.getInt(stringBuilder.toString(), 1);
                    f((RelativeLayout)paramMenuActivity.findViewById(2131165410), i);
                  } else {
                    f((RelativeLayout)paramMenuActivity.findViewById(2131165410), 0);
                  } 
                  relativeLayout6.setBackgroundResource(2131099823);
                  textView6.setText(2131427401);
                  paramMenuActivity.q = true;
                  ((RelativeLayout)paramMenuActivity.findViewById(2131165377)).setVisibility(8);
                } 
                RelativeLayout relativeLayout5 = (RelativeLayout)paramMenuActivity.findViewById(2131165243);
                TextView textView5 = (TextView)paramMenuActivity.findViewById(2131165284);
                SharedPreferences sharedPreferences6 = paramMenuActivity.c;
                if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_6", sharedPreferences6, false)) {
                  sharedPreferences6 = paramMenuActivity.c;
                  StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
                  stringBuilder.append(paramMenuActivity.h);
                  stringBuilder.append("_6");
                  int i = sharedPreferences6.getInt(stringBuilder.toString(), 1);
                  f((RelativeLayout)paramMenuActivity.findViewById(2131165409), i);
                } else {
                  f((RelativeLayout)paramMenuActivity.findViewById(2131165409), 0);
                } 
                relativeLayout5.setBackgroundResource(2131099823);
                textView5.setText(2131427400);
                paramMenuActivity.p = true;
                ((RelativeLayout)paramMenuActivity.findViewById(2131165376)).setVisibility(8);
              } 
              RelativeLayout relativeLayout4 = (RelativeLayout)paramMenuActivity.findViewById(2131165242);
              TextView textView4 = (TextView)paramMenuActivity.findViewById(2131165283);
              SharedPreferences sharedPreferences5 = paramMenuActivity.c;
              if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_5", sharedPreferences5, false)) {
                sharedPreferences5 = paramMenuActivity.c;
                StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
                stringBuilder.append(paramMenuActivity.h);
                stringBuilder.append("_5");
                int i = sharedPreferences5.getInt(stringBuilder.toString(), 1);
                f((RelativeLayout)paramMenuActivity.findViewById(2131165408), i);
              } else {
                f((RelativeLayout)paramMenuActivity.findViewById(2131165408), 0);
              } 
              relativeLayout4.setBackgroundResource(2131099823);
              textView4.setText(2131427398);
              paramMenuActivity.o = true;
              ((RelativeLayout)paramMenuActivity.findViewById(2131165375)).setVisibility(8);
            } 
            RelativeLayout relativeLayout3 = (RelativeLayout)paramMenuActivity.findViewById(2131165240);
            TextView textView3 = (TextView)paramMenuActivity.findViewById(2131165281);
            SharedPreferences sharedPreferences4 = paramMenuActivity.c;
            if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_4", sharedPreferences4, false)) {
              sharedPreferences4 = paramMenuActivity.c;
              StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
              stringBuilder.append(paramMenuActivity.h);
              stringBuilder.append("_4");
              int i = sharedPreferences4.getInt(stringBuilder.toString(), 1);
              f((RelativeLayout)paramMenuActivity.findViewById(2131165407), i);
            } else {
              f((RelativeLayout)paramMenuActivity.findViewById(2131165407), 0);
            } 
            relativeLayout3.setBackgroundResource(2131099823);
            textView3.setText(2131427397);
            paramMenuActivity.n = true;
            ((RelativeLayout)paramMenuActivity.findViewById(2131165374)).setVisibility(8);
          } 
          RelativeLayout relativeLayout2 = (RelativeLayout)paramMenuActivity.findViewById(2131165239);
          TextView textView2 = (TextView)paramMenuActivity.findViewById(2131165280);
          SharedPreferences sharedPreferences3 = paramMenuActivity.c;
          if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_3", sharedPreferences3, false)) {
            sharedPreferences3 = paramMenuActivity.c;
            StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
            stringBuilder.append(paramMenuActivity.h);
            stringBuilder.append("_3");
            int i = sharedPreferences3.getInt(stringBuilder.toString(), 1);
            f((RelativeLayout)paramMenuActivity.findViewById(2131165406), i);
          } else {
            f((RelativeLayout)paramMenuActivity.findViewById(2131165406), 0);
          } 
          relativeLayout2.setBackgroundResource(2131099823);
          textView2.setText(2131427396);
          paramMenuActivity.m = true;
          ((RelativeLayout)paramMenuActivity.findViewById(2131165373)).setVisibility(8);
        } 
        RelativeLayout relativeLayout1 = (RelativeLayout)paramMenuActivity.findViewById(2131165238);
        TextView textView1 = (TextView)paramMenuActivity.findViewById(2131165279);
        SharedPreferences sharedPreferences2 = paramMenuActivity.c;
        if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_2", sharedPreferences2, false)) {
          sharedPreferences2 = paramMenuActivity.c;
          StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
          stringBuilder.append(paramMenuActivity.h);
          stringBuilder.append("_2");
          int i = sharedPreferences2.getInt(stringBuilder.toString(), 1);
          f((RelativeLayout)paramMenuActivity.findViewById(2131165405), i);
        } else {
          f((RelativeLayout)paramMenuActivity.findViewById(2131165405), 0);
        } 
        relativeLayout1.setBackgroundResource(2131099823);
        textView1.setText(2131427395);
        paramMenuActivity.l = true;
        ((RelativeLayout)paramMenuActivity.findViewById(2131165372)).setVisibility(8);
      } 
      RelativeLayout relativeLayout = (RelativeLayout)paramMenuActivity.findViewById(2131165237);
      TextView textView = (TextView)paramMenuActivity.findViewById(2131165278);
      SharedPreferences sharedPreferences1 = paramMenuActivity.c;
      if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_1", sharedPreferences1, false)) {
        sharedPreferences1 = paramMenuActivity.c;
        StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
        stringBuilder.append(paramMenuActivity.h);
        stringBuilder.append("_1");
        int i = sharedPreferences1.getInt(stringBuilder.toString(), 1);
        f((RelativeLayout)paramMenuActivity.findViewById(2131165404), i);
      } else {
        f((RelativeLayout)paramMenuActivity.findViewById(2131165404), 0);
      } 
      relativeLayout.setBackgroundResource(2131099823);
      textView.setText(2131427394);
      paramMenuActivity.k = true;
      ((RelativeLayout)paramMenuActivity.findViewById(2131165371)).setVisibility(8);
    } 
    SharedPreferences sharedPreferences = paramMenuActivity.c;
    if (f0.u.a(b.b.c("checkers_fullUnlocked_"), paramMenuActivity.h, "_0", sharedPreferences, false)) {
      sharedPreferences = paramMenuActivity.c;
      StringBuilder stringBuilder = b.b.c("checkers_fullUnlocked_count_");
      stringBuilder.append(paramMenuActivity.h);
      stringBuilder.append("_0");
      int i = sharedPreferences.getInt(stringBuilder.toString(), 1);
      f((RelativeLayout)paramMenuActivity.findViewById(2131165402), i);
    } else {
      f((RelativeLayout)paramMenuActivity.findViewById(2131165402), 0);
    } 
    ((RelativeLayout)paramMenuActivity.findViewById(2131165235)).setBackgroundResource(2131099823);
    ((RelativeLayout)paramMenuActivity.findViewById(2131165241)).setBackgroundResource(2131099823);
  }
  
  public static void e(int paramInt) {
    RelativeLayout relativeLayout;
    switch (paramInt) {
      default:
        return;
      case 12:
        relativeLayout = U;
        paramInt = 2131099732;
        break;
      case 11:
        relativeLayout = T;
        paramInt = 2131099737;
        break;
      case 10:
        relativeLayout = S;
        paramInt = 2131099735;
        break;
      case 9:
        relativeLayout = R;
        paramInt = 2131099731;
        break;
      case 8:
        relativeLayout = Q;
        paramInt = 2131099754;
        break;
      case 7:
        relativeLayout = P;
        paramInt = 2131099752;
        break;
      case 6:
        relativeLayout = O;
        paramInt = 2131099750;
        break;
      case 5:
        relativeLayout = N;
        paramInt = 2131099748;
        break;
      case 4:
        relativeLayout = M;
        paramInt = 2131099746;
        break;
      case 3:
        relativeLayout = L;
        paramInt = 2131099744;
        break;
      case 2:
        relativeLayout = J;
        paramInt = 2131099740;
        break;
      case 1:
        relativeLayout = I;
        paramInt = 2131099730;
        break;
      case 0:
        relativeLayout = K;
        paramInt = 2131099742;
        break;
    } 
    relativeLayout.setBackgroundResource(paramInt);
  }
  
  public static void f(RelativeLayout paramRelativeLayout, int paramInt) {
    if (paramRelativeLayout != null) {
      if (paramInt > 3) {
        paramInt = 2131099727;
      } else if (paramInt == 3) {
        paramInt = 2131099725;
      } else if (paramInt == 2) {
        paramInt = 2131099723;
      } else if (paramInt == 1) {
        paramInt = 2131099720;
      } else {
        paramInt = 2131099721;
      } 
      paramRelativeLayout.setBackgroundResource(paramInt);
      paramRelativeLayout.setVisibility(0);
    } 
  }
  
  public static void g(int paramInt, float paramFloat1, float paramFloat2) {
    int m;
    int n = (int)(paramFloat1 / paramFloat2);
    e(paramInt);
    byte b = 1;
    int i;
    for (i = 1; i <= n; i++) {
      e(paramInt - i);
      e(paramInt + i);
    } 
    int j = 0;
    if (paramInt > n) {
      i = paramInt - n;
    } else {
      i = 0;
    } 
    int i1 = paramInt + n;
    if (12 > i1)
      j = 12 - i1; 
    int k = 1;
    while (true) {
      m = b;
      if (k <= i) {
        b(paramInt - n - k);
        k++;
        continue;
      } 
      break;
    } 
    while (m <= j) {
      b(i1 + m);
      m++;
    } 
  }
  
  public static void t(MenuActivity paramMenuActivity) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 2098
    //   4: aload_0
    //   5: getfield h : I
    //   8: bipush #100
    //   10: if_icmpne -> 93
    //   13: aload_0
    //   14: ldc_w 2131165345
    //   17: invokevirtual findViewById : (I)Landroid/view/View;
    //   20: checkcast android/widget/HorizontalScrollView
    //   23: astore #8
    //   25: aload #8
    //   27: ifnull -> 37
    //   30: aload #8
    //   32: bipush #8
    //   34: invokevirtual setVisibility : (I)V
    //   37: aload_0
    //   38: ldc_w 2131165440
    //   41: invokevirtual findViewById : (I)Landroid/view/View;
    //   44: checkcast android/widget/TextView
    //   47: astore #8
    //   49: aload #8
    //   51: ifnull -> 61
    //   54: aload #8
    //   56: bipush #8
    //   58: invokevirtual setVisibility : (I)V
    //   61: aload_0
    //   62: ldc_w 2131165254
    //   65: invokevirtual findViewById : (I)Landroid/view/View;
    //   68: checkcast android/widget/Button
    //   71: astore #8
    //   73: aload #8
    //   75: ifnull -> 195
    //   78: aload #8
    //   80: ldc_w 2131427390
    //   83: invokevirtual setText : (I)V
    //   86: ldc_w 25.0
    //   89: fstore_1
    //   90: goto -> 188
    //   93: aload_0
    //   94: ldc_w 2131165345
    //   97: invokevirtual findViewById : (I)Landroid/view/View;
    //   100: checkcast android/widget/HorizontalScrollView
    //   103: astore #8
    //   105: aload #8
    //   107: ifnull -> 116
    //   110: aload #8
    //   112: iconst_0
    //   113: invokevirtual setVisibility : (I)V
    //   116: aload_0
    //   117: ldc_w 2131165440
    //   120: invokevirtual findViewById : (I)Landroid/view/View;
    //   123: checkcast android/widget/TextView
    //   126: astore #8
    //   128: aload #8
    //   130: ifnull -> 139
    //   133: iconst_1
    //   134: istore #4
    //   136: goto -> 142
    //   139: iconst_0
    //   140: istore #4
    //   142: iload #4
    //   144: getstatic com/dimcoms/checkers/MenuActivity.E : Z
    //   147: iconst_1
    //   148: ixor
    //   149: iand
    //   150: ifeq -> 159
    //   153: aload #8
    //   155: iconst_0
    //   156: invokevirtual setVisibility : (I)V
    //   159: aload_0
    //   160: ldc_w 2131165254
    //   163: invokevirtual findViewById : (I)Landroid/view/View;
    //   166: checkcast android/widget/Button
    //   169: astore #8
    //   171: aload #8
    //   173: ifnull -> 195
    //   176: aload #8
    //   178: ldc_w 2131427391
    //   181: invokevirtual setText : (I)V
    //   184: ldc_w 30.0
    //   187: fstore_1
    //   188: aload #8
    //   190: iconst_1
    //   191: fload_1
    //   192: invokevirtual setTextSize : (IF)V
    //   195: aload_0
    //   196: getfield h : I
    //   199: invokestatic h : (I)Ljava/lang/Integer;
    //   202: invokevirtual intValue : ()I
    //   205: putstatic com/dimcoms/checkers/MenuActivity.z : I
    //   208: aload_0
    //   209: ldc_w 2131165402
    //   212: invokevirtual findViewById : (I)Landroid/view/View;
    //   215: checkcast android/widget/RelativeLayout
    //   218: astore #8
    //   220: aload #8
    //   222: ifnull -> 231
    //   225: aload #8
    //   227: iconst_4
    //   228: invokevirtual setVisibility : (I)V
    //   231: aload_0
    //   232: ldc_w 2131165404
    //   235: invokevirtual findViewById : (I)Landroid/view/View;
    //   238: checkcast android/widget/RelativeLayout
    //   241: astore #8
    //   243: aload #8
    //   245: ifnull -> 254
    //   248: aload #8
    //   250: iconst_4
    //   251: invokevirtual setVisibility : (I)V
    //   254: aload_0
    //   255: ldc_w 2131165405
    //   258: invokevirtual findViewById : (I)Landroid/view/View;
    //   261: checkcast android/widget/RelativeLayout
    //   264: astore #8
    //   266: aload #8
    //   268: ifnull -> 277
    //   271: aload #8
    //   273: iconst_4
    //   274: invokevirtual setVisibility : (I)V
    //   277: aload_0
    //   278: ldc_w 2131165406
    //   281: invokevirtual findViewById : (I)Landroid/view/View;
    //   284: checkcast android/widget/RelativeLayout
    //   287: astore #8
    //   289: aload #8
    //   291: ifnull -> 300
    //   294: aload #8
    //   296: iconst_4
    //   297: invokevirtual setVisibility : (I)V
    //   300: aload_0
    //   301: ldc_w 2131165407
    //   304: invokevirtual findViewById : (I)Landroid/view/View;
    //   307: checkcast android/widget/RelativeLayout
    //   310: astore #8
    //   312: aload #8
    //   314: ifnull -> 323
    //   317: aload #8
    //   319: iconst_4
    //   320: invokevirtual setVisibility : (I)V
    //   323: aload_0
    //   324: ldc_w 2131165408
    //   327: invokevirtual findViewById : (I)Landroid/view/View;
    //   330: checkcast android/widget/RelativeLayout
    //   333: astore #8
    //   335: aload #8
    //   337: ifnull -> 346
    //   340: aload #8
    //   342: iconst_4
    //   343: invokevirtual setVisibility : (I)V
    //   346: aload_0
    //   347: ldc_w 2131165409
    //   350: invokevirtual findViewById : (I)Landroid/view/View;
    //   353: checkcast android/widget/RelativeLayout
    //   356: astore #8
    //   358: aload #8
    //   360: ifnull -> 369
    //   363: aload #8
    //   365: iconst_4
    //   366: invokevirtual setVisibility : (I)V
    //   369: aload_0
    //   370: ldc_w 2131165410
    //   373: invokevirtual findViewById : (I)Landroid/view/View;
    //   376: checkcast android/widget/RelativeLayout
    //   379: astore #8
    //   381: aload #8
    //   383: ifnull -> 392
    //   386: aload #8
    //   388: iconst_4
    //   389: invokevirtual setVisibility : (I)V
    //   392: aload_0
    //   393: ldc_w 2131165411
    //   396: invokevirtual findViewById : (I)Landroid/view/View;
    //   399: checkcast android/widget/RelativeLayout
    //   402: astore #8
    //   404: aload #8
    //   406: ifnull -> 415
    //   409: aload #8
    //   411: iconst_4
    //   412: invokevirtual setVisibility : (I)V
    //   415: aload_0
    //   416: ldc_w 2131165403
    //   419: invokevirtual findViewById : (I)Landroid/view/View;
    //   422: checkcast android/widget/RelativeLayout
    //   425: astore #8
    //   427: aload #8
    //   429: ifnull -> 438
    //   432: aload #8
    //   434: iconst_4
    //   435: invokevirtual setVisibility : (I)V
    //   438: aload_0
    //   439: ldc_w 2131165371
    //   442: invokevirtual findViewById : (I)Landroid/view/View;
    //   445: checkcast android/widget/RelativeLayout
    //   448: iconst_0
    //   449: invokevirtual setVisibility : (I)V
    //   452: aload_0
    //   453: ldc_w 2131165237
    //   456: invokevirtual findViewById : (I)Landroid/view/View;
    //   459: checkcast android/widget/RelativeLayout
    //   462: astore #8
    //   464: aload_0
    //   465: ldc_w 2131165278
    //   468: invokevirtual findViewById : (I)Landroid/view/View;
    //   471: checkcast android/widget/TextView
    //   474: astore #9
    //   476: aload_0
    //   477: iconst_0
    //   478: putfield k : Z
    //   481: aload #8
    //   483: ldc_w 2131099812
    //   486: invokevirtual setBackgroundResource : (I)V
    //   489: aload #9
    //   491: ldc_w 2131427417
    //   494: invokevirtual setText : (I)V
    //   497: aload #9
    //   499: sipush #255
    //   502: sipush #255
    //   505: sipush #255
    //   508: sipush #255
    //   511: invokestatic argb : (IIII)I
    //   514: invokevirtual setTextColor : (I)V
    //   517: aload_0
    //   518: ldc_w 2131165372
    //   521: invokevirtual findViewById : (I)Landroid/view/View;
    //   524: checkcast android/widget/RelativeLayout
    //   527: iconst_0
    //   528: invokevirtual setVisibility : (I)V
    //   531: aload_0
    //   532: ldc_w 2131165238
    //   535: invokevirtual findViewById : (I)Landroid/view/View;
    //   538: checkcast android/widget/RelativeLayout
    //   541: astore #8
    //   543: aload_0
    //   544: ldc_w 2131165279
    //   547: invokevirtual findViewById : (I)Landroid/view/View;
    //   550: checkcast android/widget/TextView
    //   553: astore #9
    //   555: aload_0
    //   556: iconst_0
    //   557: putfield l : Z
    //   560: aload #8
    //   562: ldc_w 2131099812
    //   565: invokevirtual setBackgroundResource : (I)V
    //   568: aload #9
    //   570: ldc_w 2131427417
    //   573: invokevirtual setText : (I)V
    //   576: aload #9
    //   578: sipush #255
    //   581: sipush #255
    //   584: sipush #255
    //   587: sipush #255
    //   590: invokestatic argb : (IIII)I
    //   593: invokevirtual setTextColor : (I)V
    //   596: aload_0
    //   597: ldc_w 2131165373
    //   600: invokevirtual findViewById : (I)Landroid/view/View;
    //   603: checkcast android/widget/RelativeLayout
    //   606: iconst_0
    //   607: invokevirtual setVisibility : (I)V
    //   610: aload_0
    //   611: ldc_w 2131165239
    //   614: invokevirtual findViewById : (I)Landroid/view/View;
    //   617: checkcast android/widget/RelativeLayout
    //   620: astore #8
    //   622: aload_0
    //   623: ldc_w 2131165280
    //   626: invokevirtual findViewById : (I)Landroid/view/View;
    //   629: checkcast android/widget/TextView
    //   632: astore #9
    //   634: aload_0
    //   635: iconst_0
    //   636: putfield m : Z
    //   639: aload #8
    //   641: ldc_w 2131099812
    //   644: invokevirtual setBackgroundResource : (I)V
    //   647: aload #9
    //   649: ldc_w 2131427417
    //   652: invokevirtual setText : (I)V
    //   655: aload #9
    //   657: sipush #255
    //   660: sipush #255
    //   663: sipush #255
    //   666: sipush #255
    //   669: invokestatic argb : (IIII)I
    //   672: invokevirtual setTextColor : (I)V
    //   675: aload_0
    //   676: ldc_w 2131165374
    //   679: invokevirtual findViewById : (I)Landroid/view/View;
    //   682: checkcast android/widget/RelativeLayout
    //   685: iconst_0
    //   686: invokevirtual setVisibility : (I)V
    //   689: aload_0
    //   690: ldc_w 2131165240
    //   693: invokevirtual findViewById : (I)Landroid/view/View;
    //   696: checkcast android/widget/RelativeLayout
    //   699: astore #8
    //   701: aload_0
    //   702: ldc_w 2131165281
    //   705: invokevirtual findViewById : (I)Landroid/view/View;
    //   708: checkcast android/widget/TextView
    //   711: astore #9
    //   713: aload_0
    //   714: iconst_0
    //   715: putfield n : Z
    //   718: aload #8
    //   720: ldc_w 2131099812
    //   723: invokevirtual setBackgroundResource : (I)V
    //   726: aload #9
    //   728: ldc_w 2131427417
    //   731: invokevirtual setText : (I)V
    //   734: aload #9
    //   736: sipush #255
    //   739: sipush #255
    //   742: sipush #255
    //   745: sipush #255
    //   748: invokestatic argb : (IIII)I
    //   751: invokevirtual setTextColor : (I)V
    //   754: aload_0
    //   755: ldc_w 2131165375
    //   758: invokevirtual findViewById : (I)Landroid/view/View;
    //   761: checkcast android/widget/RelativeLayout
    //   764: iconst_0
    //   765: invokevirtual setVisibility : (I)V
    //   768: aload_0
    //   769: ldc_w 2131165242
    //   772: invokevirtual findViewById : (I)Landroid/view/View;
    //   775: checkcast android/widget/RelativeLayout
    //   778: astore #8
    //   780: aload_0
    //   781: ldc_w 2131165283
    //   784: invokevirtual findViewById : (I)Landroid/view/View;
    //   787: checkcast android/widget/TextView
    //   790: astore #9
    //   792: aload_0
    //   793: iconst_0
    //   794: putfield o : Z
    //   797: aload #8
    //   799: ldc_w 2131099812
    //   802: invokevirtual setBackgroundResource : (I)V
    //   805: aload #9
    //   807: ldc_w 2131427417
    //   810: invokevirtual setText : (I)V
    //   813: aload #9
    //   815: sipush #255
    //   818: sipush #255
    //   821: sipush #255
    //   824: sipush #255
    //   827: invokestatic argb : (IIII)I
    //   830: invokevirtual setTextColor : (I)V
    //   833: aload_0
    //   834: ldc_w 2131165376
    //   837: invokevirtual findViewById : (I)Landroid/view/View;
    //   840: checkcast android/widget/RelativeLayout
    //   843: iconst_0
    //   844: invokevirtual setVisibility : (I)V
    //   847: aload_0
    //   848: ldc_w 2131165243
    //   851: invokevirtual findViewById : (I)Landroid/view/View;
    //   854: checkcast android/widget/RelativeLayout
    //   857: astore #8
    //   859: aload_0
    //   860: ldc_w 2131165284
    //   863: invokevirtual findViewById : (I)Landroid/view/View;
    //   866: checkcast android/widget/TextView
    //   869: astore #9
    //   871: aload_0
    //   872: iconst_0
    //   873: putfield p : Z
    //   876: aload #8
    //   878: ldc_w 2131099812
    //   881: invokevirtual setBackgroundResource : (I)V
    //   884: aload #9
    //   886: ldc_w 2131427417
    //   889: invokevirtual setText : (I)V
    //   892: aload #9
    //   894: sipush #255
    //   897: sipush #255
    //   900: sipush #255
    //   903: sipush #255
    //   906: invokestatic argb : (IIII)I
    //   909: invokevirtual setTextColor : (I)V
    //   912: aload_0
    //   913: ldc_w 2131165377
    //   916: invokevirtual findViewById : (I)Landroid/view/View;
    //   919: checkcast android/widget/RelativeLayout
    //   922: iconst_0
    //   923: invokevirtual setVisibility : (I)V
    //   926: aload_0
    //   927: ldc_w 2131165244
    //   930: invokevirtual findViewById : (I)Landroid/view/View;
    //   933: checkcast android/widget/RelativeLayout
    //   936: astore #8
    //   938: aload_0
    //   939: ldc_w 2131165285
    //   942: invokevirtual findViewById : (I)Landroid/view/View;
    //   945: checkcast android/widget/TextView
    //   948: astore #9
    //   950: aload_0
    //   951: iconst_0
    //   952: putfield q : Z
    //   955: aload #8
    //   957: ldc_w 2131099812
    //   960: invokevirtual setBackgroundResource : (I)V
    //   963: aload #9
    //   965: ldc_w 2131427417
    //   968: invokevirtual setText : (I)V
    //   971: aload #9
    //   973: sipush #255
    //   976: sipush #255
    //   979: sipush #255
    //   982: sipush #255
    //   985: invokestatic argb : (IIII)I
    //   988: invokevirtual setTextColor : (I)V
    //   991: aload_0
    //   992: ldc_w 2131165378
    //   995: invokevirtual findViewById : (I)Landroid/view/View;
    //   998: checkcast android/widget/RelativeLayout
    //   1001: iconst_0
    //   1002: invokevirtual setVisibility : (I)V
    //   1005: aload_0
    //   1006: ldc_w 2131165245
    //   1009: invokevirtual findViewById : (I)Landroid/view/View;
    //   1012: checkcast android/widget/RelativeLayout
    //   1015: astore #8
    //   1017: aload_0
    //   1018: ldc_w 2131165286
    //   1021: invokevirtual findViewById : (I)Landroid/view/View;
    //   1024: checkcast android/widget/TextView
    //   1027: astore #9
    //   1029: aload_0
    //   1030: iconst_0
    //   1031: putfield r : Z
    //   1034: aload #8
    //   1036: ldc_w 2131099812
    //   1039: invokevirtual setBackgroundResource : (I)V
    //   1042: aload #9
    //   1044: ldc_w 2131427417
    //   1047: invokevirtual setText : (I)V
    //   1050: aload #9
    //   1052: sipush #255
    //   1055: sipush #255
    //   1058: sipush #255
    //   1061: sipush #255
    //   1064: invokestatic argb : (IIII)I
    //   1067: invokevirtual setTextColor : (I)V
    //   1070: aload_0
    //   1071: ldc_w 2131165370
    //   1074: invokevirtual findViewById : (I)Landroid/view/View;
    //   1077: checkcast android/widget/RelativeLayout
    //   1080: iconst_0
    //   1081: invokevirtual setVisibility : (I)V
    //   1084: aload_0
    //   1085: ldc 2131165236
    //   1087: invokevirtual findViewById : (I)Landroid/view/View;
    //   1090: checkcast android/widget/RelativeLayout
    //   1093: astore #8
    //   1095: aload_0
    //   1096: ldc 2131165277
    //   1098: invokevirtual findViewById : (I)Landroid/view/View;
    //   1101: checkcast android/widget/TextView
    //   1104: astore #9
    //   1106: aload_0
    //   1107: iconst_0
    //   1108: putfield s : Z
    //   1111: aload #8
    //   1113: ldc_w 2131099812
    //   1116: invokevirtual setBackgroundResource : (I)V
    //   1119: aload #9
    //   1121: ldc_w 2131427417
    //   1124: invokevirtual setText : (I)V
    //   1127: aload #9
    //   1129: sipush #255
    //   1132: sipush #255
    //   1135: sipush #255
    //   1138: sipush #255
    //   1141: invokestatic argb : (IIII)I
    //   1144: invokevirtual setTextColor : (I)V
    //   1147: aload_0
    //   1148: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1151: aload_0
    //   1152: ldc_w 2131165345
    //   1155: invokevirtual findViewById : (I)Landroid/view/View;
    //   1158: checkcast android/widget/HorizontalScrollView
    //   1161: astore #8
    //   1163: aload_0
    //   1164: ldc_w 2131165235
    //   1167: invokevirtual findViewById : (I)Landroid/view/View;
    //   1170: checkcast android/widget/RelativeLayout
    //   1173: invokestatic j : (Landroid/widget/RelativeLayout;)F
    //   1176: fstore_2
    //   1177: aload_0
    //   1178: ldc_w 2131165235
    //   1181: invokevirtual findViewById : (I)Landroid/view/View;
    //   1184: checkcast android/widget/RelativeLayout
    //   1187: astore #9
    //   1189: aload #9
    //   1191: ifnull -> 1232
    //   1194: aload #9
    //   1196: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1199: checkcast android/view/ViewGroup$MarginLayoutParams
    //   1202: astore #9
    //   1204: aload #9
    //   1206: ifnull -> 1232
    //   1209: aload #9
    //   1211: getfield width : I
    //   1214: i2f
    //   1215: fstore_1
    //   1216: aload #9
    //   1218: getfield leftMargin : I
    //   1221: i2f
    //   1222: fstore_3
    //   1223: fload_1
    //   1224: fload_3
    //   1225: fadd
    //   1226: fload_3
    //   1227: fadd
    //   1228: fstore_1
    //   1229: goto -> 1236
    //   1232: ldc_w 100.0
    //   1235: fstore_1
    //   1236: getstatic com/dimcoms/checkers/MenuActivity.W : I
    //   1239: i2f
    //   1240: fload_1
    //   1241: fsub
    //   1242: f2i
    //   1243: iconst_2
    //   1244: idiv
    //   1245: istore #7
    //   1247: ldc_w 'Level.xml'
    //   1250: invokestatic c : (Ljava/lang/String;)Z
    //   1253: ifeq -> 2004
    //   1256: ldc_w 'Level.xml'
    //   1259: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1262: astore #9
    //   1264: aload #9
    //   1266: ifnull -> 1282
    //   1269: aload #9
    //   1271: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1274: invokevirtual intValue : ()I
    //   1277: istore #4
    //   1279: goto -> 1285
    //   1282: iconst_0
    //   1283: istore #4
    //   1285: iload #4
    //   1287: istore #5
    //   1289: iload #4
    //   1291: bipush #50
    //   1293: if_icmpeq -> 1316
    //   1296: getstatic com/dimcoms/checkers/MenuActivity.z : I
    //   1299: istore #6
    //   1301: iload #4
    //   1303: istore #5
    //   1305: iload #4
    //   1307: iload #6
    //   1309: if_icmplt -> 1316
    //   1312: iload #6
    //   1314: istore #5
    //   1316: iload #5
    //   1318: invokestatic valueOf : (I)Ljava/lang/String;
    //   1321: astore #9
    //   1323: aload #9
    //   1325: ldc '0'
    //   1327: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1330: ifeq -> 1336
    //   1333: goto -> 2004
    //   1336: aload #9
    //   1338: ldc '1'
    //   1340: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1343: ifeq -> 1401
    //   1346: fload_2
    //   1347: fconst_1
    //   1348: fmul
    //   1349: iload #7
    //   1351: i2f
    //   1352: fsub
    //   1353: f2i
    //   1354: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1357: aload_0
    //   1358: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1361: aload_0
    //   1362: ldc_w 2131165237
    //   1365: invokevirtual findViewById : (I)Landroid/view/View;
    //   1368: checkcast android/widget/RelativeLayout
    //   1371: ldc_w 2131099818
    //   1374: invokevirtual setBackgroundResource : (I)V
    //   1377: aload_0
    //   1378: iconst_1
    //   1379: putfield g : I
    //   1382: aload_0
    //   1383: ldc_w 2131165440
    //   1386: invokevirtual findViewById : (I)Landroid/view/View;
    //   1389: checkcast android/widget/TextView
    //   1392: ldc_w 2131427406
    //   1395: invokevirtual setText : (I)V
    //   1398: goto -> 2049
    //   1401: aload #9
    //   1403: ldc '2'
    //   1405: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1408: ifeq -> 1462
    //   1411: fload_2
    //   1412: fconst_2
    //   1413: fmul
    //   1414: iload #7
    //   1416: i2f
    //   1417: fsub
    //   1418: f2i
    //   1419: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1422: aload_0
    //   1423: ldc_w 2131165238
    //   1426: invokevirtual findViewById : (I)Landroid/view/View;
    //   1429: checkcast android/widget/RelativeLayout
    //   1432: ldc_w 2131099818
    //   1435: invokevirtual setBackgroundResource : (I)V
    //   1438: aload_0
    //   1439: iconst_2
    //   1440: putfield g : I
    //   1443: aload_0
    //   1444: ldc_w 2131165440
    //   1447: invokevirtual findViewById : (I)Landroid/view/View;
    //   1450: checkcast android/widget/TextView
    //   1453: ldc_w 2131427407
    //   1456: invokevirtual setText : (I)V
    //   1459: goto -> 2049
    //   1462: aload #9
    //   1464: ldc '3'
    //   1466: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1469: ifeq -> 1529
    //   1472: fload_2
    //   1473: ldc_w 3.0
    //   1476: fmul
    //   1477: iload #7
    //   1479: i2f
    //   1480: fsub
    //   1481: f2i
    //   1482: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1485: aload_0
    //   1486: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1489: aload_0
    //   1490: ldc_w 2131165239
    //   1493: invokevirtual findViewById : (I)Landroid/view/View;
    //   1496: checkcast android/widget/RelativeLayout
    //   1499: ldc_w 2131099818
    //   1502: invokevirtual setBackgroundResource : (I)V
    //   1505: aload_0
    //   1506: iconst_3
    //   1507: putfield g : I
    //   1510: aload_0
    //   1511: ldc_w 2131165440
    //   1514: invokevirtual findViewById : (I)Landroid/view/View;
    //   1517: checkcast android/widget/TextView
    //   1520: ldc_w 2131427408
    //   1523: invokevirtual setText : (I)V
    //   1526: goto -> 2049
    //   1529: aload #9
    //   1531: ldc '4'
    //   1533: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1536: ifeq -> 1596
    //   1539: fload_2
    //   1540: ldc_w 4.0
    //   1543: fmul
    //   1544: iload #7
    //   1546: i2f
    //   1547: fsub
    //   1548: f2i
    //   1549: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1552: aload_0
    //   1553: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1556: aload_0
    //   1557: ldc_w 2131165240
    //   1560: invokevirtual findViewById : (I)Landroid/view/View;
    //   1563: checkcast android/widget/RelativeLayout
    //   1566: ldc_w 2131099818
    //   1569: invokevirtual setBackgroundResource : (I)V
    //   1572: aload_0
    //   1573: iconst_4
    //   1574: putfield g : I
    //   1577: aload_0
    //   1578: ldc_w 2131165440
    //   1581: invokevirtual findViewById : (I)Landroid/view/View;
    //   1584: checkcast android/widget/TextView
    //   1587: ldc_w 2131427409
    //   1590: invokevirtual setText : (I)V
    //   1593: goto -> 2049
    //   1596: aload #9
    //   1598: ldc '5'
    //   1600: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1603: ifeq -> 1663
    //   1606: fload_2
    //   1607: ldc_w 5.0
    //   1610: fmul
    //   1611: iload #7
    //   1613: i2f
    //   1614: fsub
    //   1615: f2i
    //   1616: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1619: aload_0
    //   1620: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1623: aload_0
    //   1624: ldc_w 2131165242
    //   1627: invokevirtual findViewById : (I)Landroid/view/View;
    //   1630: checkcast android/widget/RelativeLayout
    //   1633: ldc_w 2131099818
    //   1636: invokevirtual setBackgroundResource : (I)V
    //   1639: aload_0
    //   1640: iconst_5
    //   1641: putfield g : I
    //   1644: aload_0
    //   1645: ldc_w 2131165440
    //   1648: invokevirtual findViewById : (I)Landroid/view/View;
    //   1651: checkcast android/widget/TextView
    //   1654: ldc_w 2131427410
    //   1657: invokevirtual setText : (I)V
    //   1660: goto -> 2049
    //   1663: aload #9
    //   1665: ldc '6'
    //   1667: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1670: ifeq -> 1731
    //   1673: fload_2
    //   1674: ldc_w 6.0
    //   1677: fmul
    //   1678: iload #7
    //   1680: i2f
    //   1681: fsub
    //   1682: f2i
    //   1683: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1686: aload_0
    //   1687: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1690: aload_0
    //   1691: ldc_w 2131165243
    //   1694: invokevirtual findViewById : (I)Landroid/view/View;
    //   1697: checkcast android/widget/RelativeLayout
    //   1700: ldc_w 2131099818
    //   1703: invokevirtual setBackgroundResource : (I)V
    //   1706: aload_0
    //   1707: bipush #6
    //   1709: putfield g : I
    //   1712: aload_0
    //   1713: ldc_w 2131165440
    //   1716: invokevirtual findViewById : (I)Landroid/view/View;
    //   1719: checkcast android/widget/TextView
    //   1722: ldc_w 2131427412
    //   1725: invokevirtual setText : (I)V
    //   1728: goto -> 2049
    //   1731: aload #9
    //   1733: ldc '7'
    //   1735: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1738: ifeq -> 1799
    //   1741: fload_2
    //   1742: ldc_w 7.0
    //   1745: fmul
    //   1746: iload #7
    //   1748: i2f
    //   1749: fsub
    //   1750: f2i
    //   1751: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1754: aload_0
    //   1755: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1758: aload_0
    //   1759: ldc_w 2131165244
    //   1762: invokevirtual findViewById : (I)Landroid/view/View;
    //   1765: checkcast android/widget/RelativeLayout
    //   1768: ldc_w 2131099818
    //   1771: invokevirtual setBackgroundResource : (I)V
    //   1774: aload_0
    //   1775: bipush #7
    //   1777: putfield g : I
    //   1780: aload_0
    //   1781: ldc_w 2131165440
    //   1784: invokevirtual findViewById : (I)Landroid/view/View;
    //   1787: checkcast android/widget/TextView
    //   1790: ldc_w 2131427413
    //   1793: invokevirtual setText : (I)V
    //   1796: goto -> 2049
    //   1799: aload #9
    //   1801: ldc '8'
    //   1803: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1806: ifeq -> 1867
    //   1809: fload_2
    //   1810: ldc_w 8.0
    //   1813: fmul
    //   1814: iload #7
    //   1816: i2f
    //   1817: fsub
    //   1818: f2i
    //   1819: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1822: aload_0
    //   1823: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1826: aload_0
    //   1827: ldc_w 2131165245
    //   1830: invokevirtual findViewById : (I)Landroid/view/View;
    //   1833: checkcast android/widget/RelativeLayout
    //   1836: ldc_w 2131099818
    //   1839: invokevirtual setBackgroundResource : (I)V
    //   1842: aload_0
    //   1843: bipush #8
    //   1845: putfield g : I
    //   1848: aload_0
    //   1849: ldc_w 2131165440
    //   1852: invokevirtual findViewById : (I)Landroid/view/View;
    //   1855: checkcast android/widget/TextView
    //   1858: ldc_w 2131427414
    //   1861: invokevirtual setText : (I)V
    //   1864: goto -> 2049
    //   1867: aload #9
    //   1869: ldc_w '9'
    //   1872: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1875: ifeq -> 1935
    //   1878: fload_2
    //   1879: ldc_w 9.0
    //   1882: fmul
    //   1883: iload #7
    //   1885: i2f
    //   1886: fsub
    //   1887: f2i
    //   1888: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1891: aload_0
    //   1892: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1895: aload_0
    //   1896: ldc 2131165236
    //   1898: invokevirtual findViewById : (I)Landroid/view/View;
    //   1901: checkcast android/widget/RelativeLayout
    //   1904: ldc_w 2131099818
    //   1907: invokevirtual setBackgroundResource : (I)V
    //   1910: aload_0
    //   1911: bipush #9
    //   1913: putfield g : I
    //   1916: aload_0
    //   1917: ldc_w 2131165440
    //   1920: invokevirtual findViewById : (I)Landroid/view/View;
    //   1923: checkcast android/widget/TextView
    //   1926: ldc_w 2131427415
    //   1929: invokevirtual setText : (I)V
    //   1932: goto -> 2049
    //   1935: aload #9
    //   1937: ldc_w '50'
    //   1940: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1943: ifeq -> 2049
    //   1946: fload_2
    //   1947: ldc_w 10.0
    //   1950: fmul
    //   1951: iload #7
    //   1953: i2f
    //   1954: fsub
    //   1955: f2i
    //   1956: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   1959: aload_0
    //   1960: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   1963: aload_0
    //   1964: ldc_w 2131165241
    //   1967: invokevirtual findViewById : (I)Landroid/view/View;
    //   1970: checkcast android/widget/RelativeLayout
    //   1973: ldc_w 2131099818
    //   1976: invokevirtual setBackgroundResource : (I)V
    //   1979: aload_0
    //   1980: bipush #50
    //   1982: putfield g : I
    //   1985: aload_0
    //   1986: ldc_w 2131165440
    //   1989: invokevirtual findViewById : (I)Landroid/view/View;
    //   1992: checkcast android/widget/TextView
    //   1995: ldc_w 2131427411
    //   1998: invokevirtual setText : (I)V
    //   2001: goto -> 2049
    //   2004: iconst_0
    //   2005: putstatic com/dimcoms/checkers/MenuActivity.B : I
    //   2008: aload_0
    //   2009: invokestatic c : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   2012: aload_0
    //   2013: ldc_w 2131165235
    //   2016: invokevirtual findViewById : (I)Landroid/view/View;
    //   2019: checkcast android/widget/RelativeLayout
    //   2022: ldc_w 2131099818
    //   2025: invokevirtual setBackgroundResource : (I)V
    //   2028: aload_0
    //   2029: iconst_0
    //   2030: putfield g : I
    //   2033: aload_0
    //   2034: ldc_w 2131165440
    //   2037: invokevirtual findViewById : (I)Landroid/view/View;
    //   2040: checkcast android/widget/TextView
    //   2043: ldc_w 2131427405
    //   2046: invokevirtual setText : (I)V
    //   2049: aload_0
    //   2050: getfield j : Z
    //   2053: ifeq -> 2080
    //   2056: aload #8
    //   2058: new f0/w
    //   2061: dup
    //   2062: aload #8
    //   2064: invokespecial <init> : (Landroid/widget/HorizontalScrollView;)V
    //   2067: ldc2_w 10
    //   2070: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   2073: pop
    //   2074: aload_0
    //   2075: iconst_0
    //   2076: putfield j : Z
    //   2079: return
    //   2080: aload #8
    //   2082: new f0/x
    //   2085: dup
    //   2086: aload #8
    //   2088: invokespecial <init> : (Landroid/widget/HorizontalScrollView;)V
    //   2091: ldc2_w 300
    //   2094: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   2097: pop
    //   2098: return
  }
  
  public final void a(Context paramContext) {
    Intent intent = new Intent(paramContext, MainActivity.class);
    c.c.b("Level.xml", String.valueOf(this.g));
    c.c.b("Type.xml", String.valueOf(this.h));
    startActivity(intent);
  }
  
  public final void d() {
    RelativeLayout relativeLayout13 = (RelativeLayout)findViewById(2131165264);
    ((RelativeLayout)relativeLayout13.findViewById(2131165302)).setVisibility(4);
    ((RelativeLayout)relativeLayout13.findViewById(2131165329)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams13 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    int i = G / 50;
    layoutParams13.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout12 = (RelativeLayout)findViewById(2131165269);
    ((RelativeLayout)relativeLayout12.findViewById(2131165307)).setVisibility(4);
    ((RelativeLayout)relativeLayout12.findViewById(2131165334)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams12 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams12.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout11 = (RelativeLayout)findViewById(2131165270);
    ((RelativeLayout)relativeLayout11.findViewById(2131165308)).setVisibility(4);
    ((RelativeLayout)relativeLayout11.findViewById(2131165335)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams11 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams11.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout10 = (RelativeLayout)findViewById(2131165271);
    ((RelativeLayout)relativeLayout10.findViewById(2131165309)).setVisibility(4);
    ((RelativeLayout)relativeLayout10.findViewById(2131165336)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams10 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams10.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout9 = (RelativeLayout)findViewById(2131165272);
    ((RelativeLayout)relativeLayout9.findViewById(2131165310)).setVisibility(4);
    ((RelativeLayout)relativeLayout9.findViewById(2131165337)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams9.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout8 = (RelativeLayout)findViewById(2131165273);
    ((RelativeLayout)relativeLayout8.findViewById(2131165311)).setVisibility(4);
    ((RelativeLayout)relativeLayout8.findViewById(2131165338)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams8.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout7 = (RelativeLayout)findViewById(2131165274);
    ((RelativeLayout)relativeLayout7.findViewById(2131165312)).setVisibility(4);
    ((RelativeLayout)relativeLayout7.findViewById(2131165339)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams7.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout6 = (RelativeLayout)findViewById(2131165275);
    ((RelativeLayout)relativeLayout6.findViewById(2131165313)).setVisibility(4);
    ((RelativeLayout)relativeLayout6.findViewById(2131165340)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams6.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout5 = (RelativeLayout)findViewById(2131165276);
    ((RelativeLayout)relativeLayout5.findViewById(2131165314)).setVisibility(4);
    ((RelativeLayout)relativeLayout5.findViewById(2131165341)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams5.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout4 = (RelativeLayout)findViewById(2131165265);
    ((RelativeLayout)relativeLayout4.findViewById(2131165303)).setVisibility(4);
    ((RelativeLayout)relativeLayout4.findViewById(2131165330)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams4.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout3 = (RelativeLayout)findViewById(2131165267);
    ((RelativeLayout)relativeLayout3.findViewById(2131165305)).setVisibility(4);
    ((RelativeLayout)relativeLayout3.findViewById(2131165332)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams3.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout2 = (RelativeLayout)findViewById(2131165268);
    ((RelativeLayout)relativeLayout2.findViewById(2131165306)).setVisibility(4);
    ((RelativeLayout)relativeLayout2.findViewById(2131165333)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams2.setMargins(i, 0, i, 0);
    RelativeLayout relativeLayout1 = (RelativeLayout)findViewById(2131165266);
    ((RelativeLayout)relativeLayout1.findViewById(2131165304)).setVisibility(4);
    ((RelativeLayout)relativeLayout1.findViewById(2131165331)).setBackgroundResource(2131099822);
    LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams((int)(G / 1.3F), (int)(F / 1.3F));
    i = G / 50;
    layoutParams1.setMargins(i, 0, i, 0);
  }
  
  public final void h() {
    this.h = 9;
    ((TextView)findViewById(2131165438)).setText(2131427435);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165265);
    ((RelativeLayout)relativeLayout.findViewById(2131165303)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165330)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void i() {
    this.h = 10;
    ((TextView)findViewById(2131165438)).setText(2131427431);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165267);
    ((RelativeLayout)relativeLayout.findViewById(2131165305)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165332)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void j() {
    this.h = 11;
    ((TextView)findViewById(2131165438)).setText(2131427434);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165268);
    ((RelativeLayout)relativeLayout.findViewById(2131165306)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165333)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void k() {
    this.h = 0;
    ((TextView)findViewById(2131165438)).setText(2131427427);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165264);
    ((RelativeLayout)relativeLayout.findViewById(2131165302)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165329)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void l() {
    this.h = 1;
    ((TextView)findViewById(2131165438)).setText(2131427432);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165269);
    ((RelativeLayout)relativeLayout.findViewById(2131165307)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165334)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public void l10Clicked(View paramView) {
    if (this.s) {
      if (this.g == 9) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_9", sharedPreferences, false))
          (new Handler()).postDelayed(new i(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165236)).setBackgroundResource(2131099818);
      this.g = 9;
      c.c.b("Level.xml", String.valueOf(9));
      ((TextView)findViewById(2131165440)).setText(2131427415);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165370);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new j(this, relativeLayout), 400L);
    } 
  }
  
  public void l1Clicked(View paramView) {
    if (this.g == 0) {
      SharedPreferences sharedPreferences = this.c;
      if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_0", sharedPreferences, false))
        (new Handler()).postDelayed(new k(this), 400L); 
    } 
    paramView.getContext();
    c(this);
    ((RelativeLayout)findViewById(2131165235)).setBackgroundResource(2131099818);
    this.g = 0;
    c.c.b("Level.xml", String.valueOf(0));
    ((TextView)findViewById(2131165440)).setText(2131427405);
  }
  
  public void l2Clicked(View paramView) {
    if (this.k) {
      if (this.g == 1) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_1", sharedPreferences, false))
          (new Handler()).postDelayed(new p(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165237)).setBackgroundResource(2131099818);
      this.g = 1;
      c.c.b("Level.xml", String.valueOf(1));
      ((TextView)findViewById(2131165440)).setText(2131427406);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165371);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new q(this, relativeLayout), 400L);
    } 
  }
  
  public void l3Clicked(View paramView) {
    if (this.l) {
      if (this.g == 2) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_2", sharedPreferences, false))
          (new Handler()).postDelayed(new r(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165238)).setBackgroundResource(2131099818);
      this.g = 2;
      c.c.b("Level.xml", String.valueOf(2));
      ((TextView)findViewById(2131165440)).setText(2131427407);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165372);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new s(this, relativeLayout), 400L);
    } 
  }
  
  public void l4Clicked(View paramView) {
    if (this.m) {
      if (this.g == 3) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_3", sharedPreferences, false))
          (new Handler()).postDelayed(new t(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165239)).setBackgroundResource(2131099818);
      this.g = 3;
      c.c.b("Level.xml", String.valueOf(3));
      ((TextView)findViewById(2131165440)).setText(2131427408);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165373);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new u(this, relativeLayout), 400L);
    } 
  }
  
  public void l50Clicked(View paramView) {
    paramView.getContext();
    c(this);
    ((RelativeLayout)findViewById(2131165241)).setBackgroundResource(2131099818);
    this.g = 50;
    c.c.b("Level.xml", String.valueOf(50));
    ((TextView)findViewById(2131165440)).setText(2131427411);
  }
  
  public void l5Clicked(View paramView) {
    if (this.n) {
      if (this.g == 4) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_4", sharedPreferences, false))
          (new Handler()).postDelayed(new v(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165240)).setBackgroundResource(2131099818);
      this.g = 4;
      c.c.b("Level.xml", String.valueOf(4));
      ((TextView)findViewById(2131165440)).setText(2131427409);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165374);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new w(this, relativeLayout), 400L);
    } 
  }
  
  public void l6Clicked(View paramView) {
    if (this.o) {
      if (this.g == 5) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_5", sharedPreferences, false))
          (new Handler()).postDelayed(new a(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165242)).setBackgroundResource(2131099818);
      this.g = 5;
      c.c.b("Level.xml", String.valueOf(5));
      ((TextView)findViewById(2131165440)).setText(2131427410);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165375);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new b(this, relativeLayout), 400L);
    } 
  }
  
  public void l7Clicked(View paramView) {
    if (this.p) {
      if (this.g == 6) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_6", sharedPreferences, false))
          (new Handler()).postDelayed(new c(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165243)).setBackgroundResource(2131099818);
      this.g = 6;
      c.c.b("Level.xml", String.valueOf(6));
      ((TextView)findViewById(2131165440)).setText(2131427412);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165376);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new d(this, relativeLayout), 400L);
    } 
  }
  
  public void l8Clicked(View paramView) {
    if (this.q) {
      if (this.g == 7) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_7", sharedPreferences, false))
          (new Handler()).postDelayed(new e(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165244)).setBackgroundResource(2131099818);
      this.g = 7;
      c.c.b("Level.xml", String.valueOf(7));
      ((TextView)findViewById(2131165440)).setText(2131427413);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165377);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new f(this, relativeLayout), 400L);
    } 
  }
  
  public void l9Clicked(View paramView) {
    if (this.r) {
      if (this.g == 8) {
        SharedPreferences sharedPreferences = this.c;
        if (sharedPreferences != null && f0.u.a(b.b.c("checkers_fullUnlocked_"), this.h, "_8", sharedPreferences, false))
          (new Handler()).postDelayed(new g(this), 400L); 
      } 
      paramView.getContext();
      c(this);
      ((RelativeLayout)findViewById(2131165245)).setBackgroundResource(2131099818);
      this.g = 8;
      c.c.b("Level.xml", String.valueOf(8));
      ((TextView)findViewById(2131165440)).setText(2131427414);
      return;
    } 
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165378);
    if (relativeLayout != null) {
      relativeLayout.setBackgroundResource(2131099693);
      (new Handler()).postDelayed(new h(this, relativeLayout), 400L);
    } 
  }
  
  public final void m() {
    this.h = 2;
    ((TextView)findViewById(2131165438)).setText(2131427430);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165270);
    ((RelativeLayout)relativeLayout.findViewById(2131165308)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165335)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void n() {
    this.h = 3;
    ((TextView)findViewById(2131165438)).setText(2131427436);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165271);
    ((RelativeLayout)relativeLayout.findViewById(2131165309)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165336)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void o() {
    this.h = 4;
    ((TextView)findViewById(2131165438)).setText(2131427437);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165272);
    ((RelativeLayout)relativeLayout.findViewById(2131165310)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165337)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 29419451 && this.a)
      try {
        FirebaseAnalytics firebaseAnalytics = this.v;
        if (firebaseAnalytics != null)
          firebaseAnalytics.a(new Bundle(), "share"); 
        return;
      } catch (Error|Exception error) {
        return;
      }  
  }
  
  @SuppressLint({"NewApi"})
  public final void onAttachedToWindow() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void onBackPressed() {
    finish();
  }
  
  @SuppressLint({"NewApi"})
  public final void onCreate(Bundle paramBundle) {
    String str2;
    super.onCreate(paramBundle);
    int n = Build.VERSION.SDK_INT;
    this.b = n;
    getWindow().getDecorView().setSystemUiVisibility(1280);
    if (this.b >= 19) {
      getWindow().getDecorView().setSystemUiVisibility(5894);
      View view = getWindow().getDecorView();
      view.setOnSystemUiVisibilityChangeListener(new l(view));
    } 
    if (paramBundle == null)
      H = 0; 
    File file = getFilesDir();
    if (file != null) {
      str2 = file.getPath();
    } else {
      str2 = "/data/data/com.jetstartgames.chess/files";
    } 
    f0.k.c = str2;
    DisplayMetrics displayMetrics2 = new DisplayMetrics();
    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics2);
    C = displayMetrics2.widthPixels;
    D = displayMetrics2.heightPixels;
    Display display = getWindowManager().getDefaultDisplay();
    DisplayMetrics displayMetrics3 = new DisplayMetrics();
    display.getRealMetrics(displayMetrics3);
    int k = displayMetrics3.widthPixels;
    C = k;
    int m = displayMetrics3.heightPixels;
    D = m;
    int j = k;
    int i = m;
    if (n >= 24) {
      j = k;
      i = m;
      if (isInMultiWindowMode()) {
        j = displayMetrics2.widthPixels;
        C = j;
        i = displayMetrics2.heightPixels;
        D = i;
      } 
    } 
    if (j > i) {
      D = j;
      C = i;
    } 
    E = c.c.j((Context)this, D);
    try {
      this.v = FirebaseAnalytics.getInstance((Context)this);
    } catch (Error|Exception error) {}
    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)this);
    this.c = sharedPreferences;
    this.d = sharedPreferences.edit();
    w = this.c.getBoolean("checkers_removed_ads", false);
    e0.c c1 = new e0.c(true, (Context)this, new m());
    this.e = c1;
    c1.f(new n(this));
    SharedPreferences.Editor editor = this.d;
    if (editor != null) {
      editor.putBoolean("isMenuFinisfed", false);
      this.d.commit();
    } 
    this.h = c.c.g().intValue();
    this.g = Integer.valueOf(c.c.d()).intValue();
    String str1 = this.c.getString("checkers_gameState", null);
    String str3 = this.c.getString("checkers_bordHistory", null);
    if (str1 != null && str3 != null)
      a((Context)this); 
    if (E) {
      setContentView(2131296259);
      setRequestedOrientation(6);
    } else {
      setContentView(2131296258);
      setRequestedOrientation(1);
    } 
    this.t = Toast.makeText((Context)this, getString(2131427404), 0);
    this.u = Toast.makeText((Context)this, getString(2131427416), 0);
    float f1 = (getResources().getDisplayMetrics()).density;
    DisplayMetrics displayMetrics1 = new DisplayMetrics();
    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics1);
    i = displayMetrics1.widthPixels;
    j = displayMetrics1.heightPixels;
    f1 = displayMetrics1.density;
    Math.min(i / f1, j / f1);
    if (f0.k.l(this, D, C)) {
      RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165434);
      if (relativeLayout != null)
        relativeLayout.setVisibility(8); 
    } 
    I = (RelativeLayout)findViewById(2131165264);
    J = (RelativeLayout)findViewById(2131165269);
    K = (RelativeLayout)findViewById(2131165270);
    L = (RelativeLayout)findViewById(2131165271);
    M = (RelativeLayout)findViewById(2131165272);
    N = (RelativeLayout)findViewById(2131165273);
    O = (RelativeLayout)findViewById(2131165274);
    P = (RelativeLayout)findViewById(2131165275);
    Q = (RelativeLayout)findViewById(2131165276);
    R = (RelativeLayout)findViewById(2131165265);
    S = (RelativeLayout)findViewById(2131165267);
    T = (RelativeLayout)findViewById(2131165268);
    U = (RelativeLayout)findViewById(2131165266);
    if (y == null) {
      SoundPool soundPool = new SoundPool(10, 3, 0);
      y = soundPool;
      x = soundPool.load((Context)this, 2131361792, 1);
    } 
    this.j = true;
    V = this;
    z = c.c.h(this.h).intValue();
    displayMetrics1 = getResources().getDisplayMetrics();
    f1 = displayMetrics1.heightPixels;
    float f3 = displayMetrics1.density;
    f1 /= f3;
    float f2 = displayMetrics1.widthPixels / f3;
    if (f1 >= f2)
      f1 = f2; 
    G = 200;
    F = 133;
    boolean bool = E;
    if (!bool || f1 >= 360.0F) {
      G = 250;
      F = 166;
    } 
    F = (int)(F * f3);
    G = (int)(G * f3);
    W = C;
    if (bool)
      W = D; 
    Locale.getDefault().getLanguage();
    f1 = f0.k.j(I);
    X = f1;
    g(H, W, f1);
    HorizontalScrollView horizontalScrollView = (HorizontalScrollView)findViewById(2131165343);
    if (horizontalScrollView != null)
      horizontalScrollView.getViewTreeObserver().addOnGlobalLayoutListener(new o(this, horizontalScrollView)); 
    Intent intent = getIntent();
    intent.getAction();
    intent.getData();
  }
  
  public final void onDestroy() {
    SoundPool soundPool = y;
    if (soundPool != null) {
      soundPool.release();
      y = null;
    } 
    super.onDestroy();
  }
  
  public final void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.h = c.c.g().intValue();
    this.g = Integer.valueOf(c.c.d()).intValue();
    String str1 = this.c.getString("checkers_gameState", null);
    String str2 = this.c.getString("checkers_bordHistory", null);
    if (str1 != null && str2 != null)
      a((Context)this); 
  }
  
  public final void onPause() {
    long l = f0.k.b;
    l = System.currentTimeMillis() - f0.k.a + l;
    f0.k.b = l;
    this.d.putLong("checkers_gametime", l);
    this.d.commit();
    super.onPause();
  }
  
  public final void onResume() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onResume : ()V
    //   4: aload_0
    //   5: iconst_0
    //   6: putfield a : Z
    //   9: aload_0
    //   10: getfield v : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   13: aload_0
    //   14: getfield c : Landroid/content/SharedPreferences;
    //   17: aload_0
    //   18: getfield d : Landroid/content/SharedPreferences$Editor;
    //   21: invokestatic d : (Lcom/google/firebase/analytics/FirebaseAnalytics;Landroid/content/SharedPreferences;Landroid/content/SharedPreferences$Editor;)V
    //   24: aload_0
    //   25: aload_0
    //   26: ldc_w 2131165436
    //   29: invokevirtual findViewById : (I)Landroid/view/View;
    //   32: checkcast android/widget/RelativeLayout
    //   35: getstatic com/dimcoms/checkers/MenuActivity.E : Z
    //   38: iconst_0
    //   39: invokestatic a : (Landroid/content/Context;Landroid/widget/RelativeLayout;ZZ)V
    //   42: aload_0
    //   43: ldc_w 2131165343
    //   46: invokevirtual findViewById : (I)Landroid/view/View;
    //   49: checkcast android/widget/HorizontalScrollView
    //   52: astore #5
    //   54: getstatic com/dimcoms/checkers/MenuActivity.I : Landroid/widget/RelativeLayout;
    //   57: astore #6
    //   59: aload #6
    //   61: ifnull -> 102
    //   64: aload #6
    //   66: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   69: checkcast android/view/ViewGroup$MarginLayoutParams
    //   72: astore #6
    //   74: aload #6
    //   76: ifnull -> 102
    //   79: aload #6
    //   81: getfield width : I
    //   84: i2f
    //   85: fstore_1
    //   86: aload #6
    //   88: getfield leftMargin : I
    //   91: i2f
    //   92: fstore_2
    //   93: fload_1
    //   94: fload_2
    //   95: fadd
    //   96: fload_2
    //   97: fadd
    //   98: fstore_1
    //   99: goto -> 106
    //   102: ldc_w 100.0
    //   105: fstore_1
    //   106: getstatic com/dimcoms/checkers/MenuActivity.I : Landroid/widget/RelativeLayout;
    //   109: invokestatic j : (Landroid/widget/RelativeLayout;)F
    //   112: fstore_2
    //   113: getstatic com/dimcoms/checkers/MenuActivity.W : I
    //   116: i2f
    //   117: fload_1
    //   118: fsub
    //   119: f2i
    //   120: iconst_2
    //   121: idiv
    //   122: istore #4
    //   124: ldc_w 'Type.xml'
    //   127: invokestatic c : (Ljava/lang/String;)Z
    //   130: ifeq -> 496
    //   133: ldc_w 'Type.xml'
    //   136: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   139: astore #6
    //   141: aload #6
    //   143: ifnull -> 496
    //   146: aload #6
    //   148: ldc '3'
    //   150: invokevirtual equals : (Ljava/lang/Object;)Z
    //   153: ifeq -> 176
    //   156: fload_2
    //   157: ldc_w 3.0
    //   160: fmul
    //   161: iload #4
    //   163: i2f
    //   164: fsub
    //   165: f2i
    //   166: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   169: aload_0
    //   170: invokevirtual n : ()V
    //   173: goto -> 2033
    //   176: aload #6
    //   178: ldc '0'
    //   180: invokevirtual equals : (Ljava/lang/Object;)Z
    //   183: ifeq -> 204
    //   186: fload_2
    //   187: fconst_1
    //   188: fmul
    //   189: iload #4
    //   191: i2f
    //   192: fsub
    //   193: f2i
    //   194: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   197: aload_0
    //   198: invokevirtual k : ()V
    //   201: goto -> 2033
    //   204: aload #6
    //   206: ldc '1'
    //   208: invokevirtual equals : (Ljava/lang/Object;)Z
    //   211: ifeq -> 232
    //   214: fload_2
    //   215: fconst_2
    //   216: fmul
    //   217: iload #4
    //   219: i2f
    //   220: fsub
    //   221: f2i
    //   222: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   225: aload_0
    //   226: invokevirtual l : ()V
    //   229: goto -> 2033
    //   232: aload #6
    //   234: ldc '2'
    //   236: invokevirtual equals : (Ljava/lang/Object;)Z
    //   239: ifeq -> 253
    //   242: iconst_0
    //   243: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   246: aload_0
    //   247: invokevirtual m : ()V
    //   250: goto -> 2033
    //   253: aload #6
    //   255: ldc '4'
    //   257: invokevirtual equals : (Ljava/lang/Object;)Z
    //   260: ifeq -> 283
    //   263: fload_2
    //   264: ldc_w 4.0
    //   267: fmul
    //   268: iload #4
    //   270: i2f
    //   271: fsub
    //   272: f2i
    //   273: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   276: aload_0
    //   277: invokevirtual o : ()V
    //   280: goto -> 2033
    //   283: aload #6
    //   285: ldc '5'
    //   287: invokevirtual equals : (Ljava/lang/Object;)Z
    //   290: ifeq -> 313
    //   293: fload_2
    //   294: ldc_w 5.0
    //   297: fmul
    //   298: iload #4
    //   300: i2f
    //   301: fsub
    //   302: f2i
    //   303: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   306: aload_0
    //   307: invokevirtual p : ()V
    //   310: goto -> 2033
    //   313: aload #6
    //   315: ldc '6'
    //   317: invokevirtual equals : (Ljava/lang/Object;)Z
    //   320: ifeq -> 343
    //   323: fload_2
    //   324: ldc_w 6.0
    //   327: fmul
    //   328: iload #4
    //   330: i2f
    //   331: fsub
    //   332: f2i
    //   333: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   336: aload_0
    //   337: invokevirtual q : ()V
    //   340: goto -> 2033
    //   343: aload #6
    //   345: ldc '7'
    //   347: invokevirtual equals : (Ljava/lang/Object;)Z
    //   350: ifeq -> 373
    //   353: fload_2
    //   354: ldc_w 7.0
    //   357: fmul
    //   358: iload #4
    //   360: i2f
    //   361: fsub
    //   362: f2i
    //   363: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   366: aload_0
    //   367: invokevirtual r : ()V
    //   370: goto -> 2033
    //   373: aload #6
    //   375: ldc '8'
    //   377: invokevirtual equals : (Ljava/lang/Object;)Z
    //   380: ifeq -> 403
    //   383: fload_2
    //   384: ldc_w 8.0
    //   387: fmul
    //   388: iload #4
    //   390: i2f
    //   391: fsub
    //   392: f2i
    //   393: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   396: aload_0
    //   397: invokevirtual s : ()V
    //   400: goto -> 2033
    //   403: aload #6
    //   405: ldc_w '9'
    //   408: invokevirtual equals : (Ljava/lang/Object;)Z
    //   411: ifeq -> 434
    //   414: fload_2
    //   415: ldc_w 9.0
    //   418: fmul
    //   419: iload #4
    //   421: i2f
    //   422: fsub
    //   423: f2i
    //   424: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   427: aload_0
    //   428: invokevirtual h : ()V
    //   431: goto -> 2033
    //   434: aload #6
    //   436: ldc_w '10'
    //   439: invokevirtual equals : (Ljava/lang/Object;)Z
    //   442: ifeq -> 465
    //   445: fload_2
    //   446: ldc_w 10.0
    //   449: fmul
    //   450: iload #4
    //   452: i2f
    //   453: fsub
    //   454: f2i
    //   455: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   458: aload_0
    //   459: invokevirtual i : ()V
    //   462: goto -> 2033
    //   465: aload #6
    //   467: ldc_w '11'
    //   470: invokevirtual equals : (Ljava/lang/Object;)Z
    //   473: ifeq -> 2033
    //   476: fload_2
    //   477: ldc_w 11.0
    //   480: fmul
    //   481: iload #4
    //   483: i2f
    //   484: fsub
    //   485: f2i
    //   486: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   489: aload_0
    //   490: invokevirtual j : ()V
    //   493: goto -> 2033
    //   496: aload_0
    //   497: ldc_w 'phone'
    //   500: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   503: checkcast android/telephony/TelephonyManager
    //   506: invokevirtual getNetworkCountryIso : ()Ljava/lang/String;
    //   509: astore #6
    //   511: iconst_1
    //   512: istore_3
    //   513: aload #6
    //   515: ifnull -> 1668
    //   518: aload #6
    //   520: ldc_w 'gb'
    //   523: invokevirtual equals : (Ljava/lang/Object;)Z
    //   526: ifne -> 1657
    //   529: aload #6
    //   531: ldc_w 'ke'
    //   534: invokevirtual equals : (Ljava/lang/Object;)Z
    //   537: ifne -> 1657
    //   540: aload #6
    //   542: ldc_w 'tz'
    //   545: invokevirtual equals : (Ljava/lang/Object;)Z
    //   548: ifne -> 1657
    //   551: aload #6
    //   553: ldc_w 'pk'
    //   556: invokevirtual equals : (Ljava/lang/Object;)Z
    //   559: ifne -> 1657
    //   562: aload #6
    //   564: ldc_w 'id'
    //   567: invokevirtual equals : (Ljava/lang/Object;)Z
    //   570: ifne -> 1657
    //   573: aload #6
    //   575: ldc_w 'my'
    //   578: invokevirtual equals : (Ljava/lang/Object;)Z
    //   581: ifne -> 1657
    //   584: aload #6
    //   586: ldc_w 'bd'
    //   589: invokevirtual equals : (Ljava/lang/Object;)Z
    //   592: ifne -> 1657
    //   595: aload #6
    //   597: ldc_w 'ie'
    //   600: invokevirtual equals : (Ljava/lang/Object;)Z
    //   603: ifne -> 1657
    //   606: aload #6
    //   608: ldc_w 'np'
    //   611: invokevirtual equals : (Ljava/lang/Object;)Z
    //   614: ifne -> 1657
    //   617: aload #6
    //   619: ldc_w 'au'
    //   622: invokevirtual equals : (Ljava/lang/Object;)Z
    //   625: ifne -> 1657
    //   628: aload #6
    //   630: ldc_w 'nz'
    //   633: invokevirtual equals : (Ljava/lang/Object;)Z
    //   636: ifne -> 1657
    //   639: aload #6
    //   641: ldc_w 'za'
    //   644: invokevirtual equals : (Ljava/lang/Object;)Z
    //   647: ifne -> 1657
    //   650: aload #6
    //   652: ldc_w 'us'
    //   655: invokevirtual equals : (Ljava/lang/Object;)Z
    //   658: ifne -> 1657
    //   661: aload #6
    //   663: ldc_w 'in'
    //   666: invokevirtual equals : (Ljava/lang/Object;)Z
    //   669: ifeq -> 675
    //   672: goto -> 1657
    //   675: aload #6
    //   677: ldc_w 'ma'
    //   680: invokevirtual equals : (Ljava/lang/Object;)Z
    //   683: ifne -> 1637
    //   686: aload #6
    //   688: ldc_w 'pt'
    //   691: invokevirtual equals : (Ljava/lang/Object;)Z
    //   694: ifne -> 1637
    //   697: aload #6
    //   699: ldc_w 'pe'
    //   702: invokevirtual equals : (Ljava/lang/Object;)Z
    //   705: ifne -> 1637
    //   708: aload #6
    //   710: ldc_w 'dz'
    //   713: invokevirtual equals : (Ljava/lang/Object;)Z
    //   716: ifne -> 1637
    //   719: aload #6
    //   721: ldc_w 'tn'
    //   724: invokevirtual equals : (Ljava/lang/Object;)Z
    //   727: ifne -> 1637
    //   730: aload #6
    //   732: ldc_w 'es'
    //   735: invokevirtual equals : (Ljava/lang/Object;)Z
    //   738: ifeq -> 744
    //   741: goto -> 1637
    //   744: aload #6
    //   746: ldc_w 'it'
    //   749: invokevirtual equals : (Ljava/lang/Object;)Z
    //   752: ifeq -> 775
    //   755: ldc_w 5.0
    //   758: fload_2
    //   759: fmul
    //   760: iload #4
    //   762: i2f
    //   763: fsub
    //   764: f2i
    //   765: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   768: aload_0
    //   769: invokevirtual p : ()V
    //   772: goto -> 1670
    //   775: aload #6
    //   777: ldc_w 'az'
    //   780: invokevirtual equals : (Ljava/lang/Object;)Z
    //   783: ifne -> 1617
    //   786: aload #6
    //   788: ldc_w 'kg'
    //   791: invokevirtual equals : (Ljava/lang/Object;)Z
    //   794: ifne -> 1617
    //   797: aload #6
    //   799: ldc_w 'md'
    //   802: invokevirtual equals : (Ljava/lang/Object;)Z
    //   805: ifne -> 1617
    //   808: aload #6
    //   810: ldc_w 'kz'
    //   813: invokevirtual equals : (Ljava/lang/Object;)Z
    //   816: ifne -> 1617
    //   819: aload #6
    //   821: ldc_w 'am'
    //   824: invokevirtual equals : (Ljava/lang/Object;)Z
    //   827: ifne -> 1617
    //   830: aload #6
    //   832: ldc_w 'by'
    //   835: invokevirtual equals : (Ljava/lang/Object;)Z
    //   838: ifne -> 1617
    //   841: aload #6
    //   843: ldc_w 'ge'
    //   846: invokevirtual equals : (Ljava/lang/Object;)Z
    //   849: ifne -> 1617
    //   852: aload #6
    //   854: ldc_w 'tm'
    //   857: invokevirtual equals : (Ljava/lang/Object;)Z
    //   860: ifne -> 1617
    //   863: aload #6
    //   865: ldc_w 'uz'
    //   868: invokevirtual equals : (Ljava/lang/Object;)Z
    //   871: ifne -> 1617
    //   874: aload #6
    //   876: ldc_w 'ua'
    //   879: invokevirtual equals : (Ljava/lang/Object;)Z
    //   882: ifne -> 1617
    //   885: aload #6
    //   887: ldc_w 'ru'
    //   890: invokevirtual equals : (Ljava/lang/Object;)Z
    //   893: ifne -> 1617
    //   896: aload #6
    //   898: ldc_w 'lt'
    //   901: invokevirtual equals : (Ljava/lang/Object;)Z
    //   904: ifne -> 1617
    //   907: aload #6
    //   909: ldc_w 'lv'
    //   912: invokevirtual equals : (Ljava/lang/Object;)Z
    //   915: ifne -> 1617
    //   918: aload #6
    //   920: ldc_w 'ee'
    //   923: invokevirtual equals : (Ljava/lang/Object;)Z
    //   926: ifne -> 1617
    //   929: aload #6
    //   931: ldc_w 'tj'
    //   934: invokevirtual equals : (Ljava/lang/Object;)Z
    //   937: ifne -> 1617
    //   940: aload #6
    //   942: ldc_w 'ro'
    //   945: invokevirtual equals : (Ljava/lang/Object;)Z
    //   948: ifne -> 1617
    //   951: aload #6
    //   953: ldc_w 'bg'
    //   956: invokevirtual equals : (Ljava/lang/Object;)Z
    //   959: ifeq -> 965
    //   962: goto -> 1617
    //   965: aload #6
    //   967: ldc_w 'br'
    //   970: invokevirtual equals : (Ljava/lang/Object;)Z
    //   973: ifne -> 1599
    //   976: aload #6
    //   978: ldc_w 'ph'
    //   981: invokevirtual equals : (Ljava/lang/Object;)Z
    //   984: ifne -> 1599
    //   987: aload #6
    //   989: ldc_w 'pl'
    //   992: invokevirtual equals : (Ljava/lang/Object;)Z
    //   995: ifeq -> 1001
    //   998: goto -> 1599
    //   1001: aload #6
    //   1003: ldc_w 'fr'
    //   1006: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1009: ifne -> 1581
    //   1012: aload #6
    //   1014: ldc_w 'mn'
    //   1017: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1020: ifne -> 1581
    //   1023: aload #6
    //   1025: ldc_w 'la'
    //   1028: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1031: ifne -> 1581
    //   1034: aload #6
    //   1036: ldc_w 'bt'
    //   1039: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1042: ifne -> 1581
    //   1045: aload #6
    //   1047: ldc_w 'kh'
    //   1050: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1053: ifne -> 1581
    //   1056: aload #6
    //   1058: ldc_w 'vn'
    //   1061: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1064: ifne -> 1581
    //   1067: aload #6
    //   1069: ldc_w 'nl'
    //   1072: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1075: ifne -> 1581
    //   1078: aload #6
    //   1080: ldc_w 'cn'
    //   1083: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1086: ifne -> 1581
    //   1089: aload #6
    //   1091: ldc_w 'sr'
    //   1094: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1097: ifne -> 1581
    //   1100: aload #6
    //   1102: ldc_w 'be'
    //   1105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1108: ifne -> 1581
    //   1111: aload #6
    //   1113: ldc_w 'ao'
    //   1116: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1119: ifne -> 1581
    //   1122: aload #6
    //   1124: ldc_w 'mz'
    //   1127: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1130: ifne -> 1581
    //   1133: aload #6
    //   1135: ldc_w 'ca'
    //   1138: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1141: ifne -> 1581
    //   1144: aload #6
    //   1146: ldc_w 'tt'
    //   1149: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1152: ifne -> 1581
    //   1155: aload #6
    //   1157: ldc_w 'cg'
    //   1160: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1163: ifne -> 1581
    //   1166: aload #6
    //   1168: ldc_w 'de'
    //   1171: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1174: ifne -> 1581
    //   1177: aload #6
    //   1179: ldc_w 'no'
    //   1182: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1185: ifne -> 1581
    //   1188: aload #6
    //   1190: ldc_w 'se'
    //   1193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1196: ifne -> 1581
    //   1199: aload #6
    //   1201: ldc_w 'dk'
    //   1204: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1207: ifne -> 1581
    //   1210: aload #6
    //   1212: ldc_w 'dk'
    //   1215: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1218: ifne -> 1581
    //   1221: aload #6
    //   1223: ldc_w 'gl'
    //   1226: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1229: ifne -> 1581
    //   1232: aload #6
    //   1234: ldc_w 'fi'
    //   1237: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1240: ifne -> 1581
    //   1243: aload #6
    //   1245: ldc_w 'cm'
    //   1248: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1251: ifne -> 1581
    //   1254: aload #6
    //   1256: ldc_w 'sn'
    //   1259: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1262: ifne -> 1581
    //   1265: aload #6
    //   1267: ldc_w 'ml'
    //   1270: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1273: ifne -> 1581
    //   1276: aload #6
    //   1278: ldc_w 'ci'
    //   1281: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1284: ifeq -> 1290
    //   1287: goto -> 1581
    //   1290: aload #6
    //   1292: ldc_w 'th'
    //   1295: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1298: ifeq -> 1321
    //   1301: fload_2
    //   1302: ldc_w 6.0
    //   1305: fmul
    //   1306: iload #4
    //   1308: i2f
    //   1309: fsub
    //   1310: f2i
    //   1311: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1314: aload_0
    //   1315: invokevirtual q : ()V
    //   1318: goto -> 1670
    //   1321: aload #6
    //   1323: ldc_w 'tr'
    //   1326: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1329: ifne -> 1561
    //   1332: aload #6
    //   1334: ldc_w 'ir'
    //   1337: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1340: ifne -> 1561
    //   1343: aload #6
    //   1345: ldc_w 'sy'
    //   1348: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1351: ifne -> 1561
    //   1354: aload #6
    //   1356: ldc_w 'kw'
    //   1359: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1362: ifne -> 1561
    //   1365: aload #6
    //   1367: ldc_w 'lb'
    //   1370: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1373: ifne -> 1561
    //   1376: aload #6
    //   1378: ldc_w 'jo'
    //   1381: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1384: ifne -> 1561
    //   1387: aload #6
    //   1389: ldc_w 'iq'
    //   1392: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1395: ifne -> 1561
    //   1398: aload #6
    //   1400: ldc_w 'af'
    //   1403: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1406: ifne -> 1561
    //   1409: aload #6
    //   1411: ldc_w 'gr'
    //   1414: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1417: ifeq -> 1423
    //   1420: goto -> 1561
    //   1423: aload #6
    //   1425: ldc_w 'cz'
    //   1428: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1431: ifne -> 1541
    //   1434: aload #6
    //   1436: ldc_w 'sk'
    //   1439: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1442: ifeq -> 1448
    //   1445: goto -> 1541
    //   1448: aload #6
    //   1450: ldc_w 'pr'
    //   1453: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1456: ifeq -> 1479
    //   1459: ldc_w 9.0
    //   1462: fload_2
    //   1463: fmul
    //   1464: iload #4
    //   1466: i2f
    //   1467: fsub
    //   1468: f2i
    //   1469: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1472: aload_0
    //   1473: invokevirtual h : ()V
    //   1476: goto -> 1670
    //   1479: aload #6
    //   1481: ldc_w 'gh'
    //   1484: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1487: ifeq -> 1510
    //   1490: ldc_w 10.0
    //   1493: fload_2
    //   1494: fmul
    //   1495: iload #4
    //   1497: i2f
    //   1498: fsub
    //   1499: f2i
    //   1500: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1503: aload_0
    //   1504: invokevirtual i : ()V
    //   1507: goto -> 1670
    //   1510: aload #6
    //   1512: ldc_w 'ng'
    //   1515: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1518: ifeq -> 1668
    //   1521: ldc_w 11.0
    //   1524: fload_2
    //   1525: fmul
    //   1526: iload #4
    //   1528: i2f
    //   1529: fsub
    //   1530: f2i
    //   1531: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1534: aload_0
    //   1535: invokevirtual j : ()V
    //   1538: goto -> 1670
    //   1541: fload_2
    //   1542: ldc_w 8.0
    //   1545: fmul
    //   1546: iload #4
    //   1548: i2f
    //   1549: fsub
    //   1550: f2i
    //   1551: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1554: aload_0
    //   1555: invokevirtual s : ()V
    //   1558: goto -> 1670
    //   1561: fload_2
    //   1562: ldc_w 7.0
    //   1565: fmul
    //   1566: iload #4
    //   1568: i2f
    //   1569: fsub
    //   1570: f2i
    //   1571: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1574: aload_0
    //   1575: invokevirtual r : ()V
    //   1578: goto -> 1670
    //   1581: fload_2
    //   1582: fconst_2
    //   1583: fmul
    //   1584: iload #4
    //   1586: i2f
    //   1587: fsub
    //   1588: f2i
    //   1589: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1592: aload_0
    //   1593: invokevirtual l : ()V
    //   1596: goto -> 1670
    //   1599: fload_2
    //   1600: fconst_1
    //   1601: fmul
    //   1602: iload #4
    //   1604: i2f
    //   1605: fsub
    //   1606: f2i
    //   1607: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1610: aload_0
    //   1611: invokevirtual k : ()V
    //   1614: goto -> 1670
    //   1617: fload_2
    //   1618: ldc_w 3.0
    //   1621: fmul
    //   1622: iload #4
    //   1624: i2f
    //   1625: fsub
    //   1626: f2i
    //   1627: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1630: aload_0
    //   1631: invokevirtual n : ()V
    //   1634: goto -> 1670
    //   1637: fload_2
    //   1638: ldc_w 4.0
    //   1641: fmul
    //   1642: iload #4
    //   1644: i2f
    //   1645: fsub
    //   1646: f2i
    //   1647: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1650: aload_0
    //   1651: invokevirtual o : ()V
    //   1654: goto -> 1670
    //   1657: iconst_0
    //   1658: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1661: aload_0
    //   1662: invokevirtual m : ()V
    //   1665: goto -> 1670
    //   1668: iconst_0
    //   1669: istore_3
    //   1670: aload #6
    //   1672: ifnull -> 1679
    //   1675: iload_3
    //   1676: ifne -> 2033
    //   1679: invokestatic getDefault : ()Ljava/util/Locale;
    //   1682: invokevirtual getLanguage : ()Ljava/lang/String;
    //   1685: astore #6
    //   1687: invokestatic getDefault : ()Ljava/util/Locale;
    //   1690: invokevirtual getCountry : ()Ljava/lang/String;
    //   1693: astore #7
    //   1695: aload #6
    //   1697: ldc_w 'ru'
    //   1700: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1703: ifne -> 2016
    //   1706: aload #6
    //   1708: ldc_w 'uk'
    //   1711: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1714: ifne -> 2016
    //   1717: aload #6
    //   1719: ldc_w 'az'
    //   1722: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1725: ifne -> 2016
    //   1728: aload #6
    //   1730: ldc_w 'ky'
    //   1733: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1736: ifne -> 2016
    //   1739: aload #6
    //   1741: ldc_w 'kk'
    //   1744: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1747: ifeq -> 1753
    //   1750: goto -> 2016
    //   1753: aload #6
    //   1755: ldc_w 'en'
    //   1758: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1761: ifne -> 2005
    //   1764: aload #6
    //   1766: ldc_w 'hi'
    //   1769: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1772: ifeq -> 1778
    //   1775: goto -> 2005
    //   1778: aload #6
    //   1780: ldc_w 'pt'
    //   1783: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1786: ifeq -> 1806
    //   1789: aload #7
    //   1791: ldc_w 'PT'
    //   1794: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1797: ifeq -> 1803
    //   1800: goto -> 1817
    //   1803: goto -> 1949
    //   1806: aload #6
    //   1808: ldc_w 'es'
    //   1811: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1814: ifeq -> 1837
    //   1817: fload_2
    //   1818: ldc_w 4.0
    //   1821: fmul
    //   1822: iload #4
    //   1824: i2f
    //   1825: fsub
    //   1826: f2i
    //   1827: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1830: aload_0
    //   1831: invokevirtual o : ()V
    //   1834: goto -> 2033
    //   1837: aload #6
    //   1839: ldc_w 'nl'
    //   1842: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1845: ifne -> 1987
    //   1848: aload #6
    //   1850: ldc_w 'fr'
    //   1853: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1856: ifeq -> 1862
    //   1859: goto -> 1987
    //   1862: aload #6
    //   1864: ldc_w 'th'
    //   1867: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1870: ifeq -> 1893
    //   1873: fload_2
    //   1874: ldc_w 6.0
    //   1877: fmul
    //   1878: iload #4
    //   1880: i2f
    //   1881: fsub
    //   1882: f2i
    //   1883: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1886: aload_0
    //   1887: invokevirtual q : ()V
    //   1890: goto -> 2033
    //   1893: aload #6
    //   1895: ldc_w 'tr'
    //   1898: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1901: ifeq -> 1924
    //   1904: fload_2
    //   1905: ldc_w 7.0
    //   1908: fmul
    //   1909: iload #4
    //   1911: i2f
    //   1912: fsub
    //   1913: f2i
    //   1914: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1917: aload_0
    //   1918: invokevirtual r : ()V
    //   1921: goto -> 2033
    //   1924: aload #6
    //   1926: ldc_w 'cs'
    //   1929: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1932: ifne -> 1967
    //   1935: aload #6
    //   1937: ldc_w 'sk'
    //   1940: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1943: ifeq -> 1803
    //   1946: goto -> 1967
    //   1949: fload_2
    //   1950: fconst_1
    //   1951: fmul
    //   1952: iload #4
    //   1954: i2f
    //   1955: fsub
    //   1956: f2i
    //   1957: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1960: aload_0
    //   1961: invokevirtual k : ()V
    //   1964: goto -> 2033
    //   1967: fload_2
    //   1968: ldc_w 8.0
    //   1971: fmul
    //   1972: iload #4
    //   1974: i2f
    //   1975: fsub
    //   1976: f2i
    //   1977: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1980: aload_0
    //   1981: invokevirtual s : ()V
    //   1984: goto -> 2033
    //   1987: fload_2
    //   1988: fconst_2
    //   1989: fmul
    //   1990: iload #4
    //   1992: i2f
    //   1993: fsub
    //   1994: f2i
    //   1995: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   1998: aload_0
    //   1999: invokevirtual l : ()V
    //   2002: goto -> 2033
    //   2005: iconst_0
    //   2006: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   2009: aload_0
    //   2010: invokevirtual m : ()V
    //   2013: goto -> 2033
    //   2016: fload_2
    //   2017: ldc_w 3.0
    //   2020: fmul
    //   2021: iload #4
    //   2023: i2f
    //   2024: fsub
    //   2025: f2i
    //   2026: putstatic com/dimcoms/checkers/MenuActivity.A : I
    //   2029: aload_0
    //   2030: invokevirtual n : ()V
    //   2033: aload #5
    //   2035: new f0/v
    //   2038: dup
    //   2039: aload #5
    //   2041: invokespecial <init> : (Landroid/widget/HorizontalScrollView;)V
    //   2044: ldc2_w 500
    //   2047: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   2050: pop
    //   2051: aload_0
    //   2052: invokestatic t : (Lcom/dimcoms/checkers/MenuActivity;)V
    //   2055: aload_0
    //   2056: invokestatic f : ()Z
    //   2059: putfield i : Z
    //   2062: aload_0
    //   2063: getfield c : Landroid/content/SharedPreferences;
    //   2066: ldc_w 'checkers_removed_ads'
    //   2069: iconst_0
    //   2070: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   2075: putstatic com/dimcoms/checkers/MenuActivity.w : Z
    //   2078: aload_0
    //   2079: ldc_w 2131165266
    //   2082: invokevirtual findViewById : (I)Landroid/view/View;
    //   2085: checkcast android/widget/RelativeLayout
    //   2088: astore #5
    //   2090: aload #5
    //   2092: ifnull -> 2115
    //   2095: getstatic com/dimcoms/checkers/MenuActivity.w : Z
    //   2098: ifne -> 2106
    //   2101: iconst_0
    //   2102: istore_3
    //   2103: goto -> 2109
    //   2106: bipush #8
    //   2108: istore_3
    //   2109: aload #5
    //   2111: iload_3
    //   2112: invokevirtual setVisibility : (I)V
    //   2115: return
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
  }
  
  public final void onStop() {
    super.onStop();
    this.a = true;
  }
  
  @SuppressLint({"NewApi"})
  public final void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    if (this.b >= 19 && paramBoolean)
      getWindow().getDecorView().setSystemUiVisibility(5894); 
  }
  
  public final void p() {
    this.h = 5;
    ((TextView)findViewById(2131165438)).setText(2131427433);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165273);
    ((RelativeLayout)relativeLayout.findViewById(2131165311)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165338)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public void playClicked(View paramView) {
    int i = this.h;
    Context context = paramView.getContext();
    if (i == 100) {
      Intent intent = new Intent("android.intent.action.VIEW");
      intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.jetstartgames.chess"));
      try {
        context.startActivity(intent);
        return;
      } catch (ActivityNotFoundException activityNotFoundException) {
        return;
      } 
    } 
    a((Context)activityNotFoundException);
    if (this.i) {
      SoundPool soundPool = y;
      if (soundPool != null) {
        soundPool.autoPause();
        y.play(x, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
  }
  
  public final void q() {
    this.h = 6;
    ((TextView)findViewById(2131165438)).setText(2131427438);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165274);
    ((RelativeLayout)relativeLayout.findViewById(2131165312)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165339)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public final void r() {
    this.h = 7;
    ((TextView)findViewById(2131165438)).setText(2131427439);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165275);
    ((RelativeLayout)relativeLayout.findViewById(2131165313)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165340)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public void rateClicked(View paramView) {
    Context context = paramView.getContext();
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.dimcoms.checkers"));
    try {
      context.startActivity(intent);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      return;
    } 
  }
  
  public final void s() {
    this.h = 8;
    ((TextView)findViewById(2131165438)).setText(2131427429);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165276);
    ((RelativeLayout)relativeLayout.findViewById(2131165314)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165341)).setBackgroundResource(2131099818);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(G, F);
    int i = G;
    layoutParams.setMargins(-i / 50, 0, -i / 50, 0);
  }
  
  public void setClicked(View paramView) {
    startActivity(new Intent(paramView.getContext(), SetActivity.class));
    if (this.i) {
      SoundPool soundPool = y;
      if (soundPool != null) {
        soundPool.autoPause();
        y.play(x, 1.0F, 1.0F, 1, 0, 1.0F);
      } 
    } 
  }
  
  public void shareClicked(View paramView) {
    Intent intent = new Intent("android.intent.action.SEND");
    intent.setType("text/plain");
    String str = getString(2131427480);
    intent.putExtra("android.intent.extra.SUBJECT", getString(2131427330));
    intent.putExtra("android.intent.extra.TEXT", str);
    try {
      startActivityForResult(Intent.createChooser(intent, "Share via"), 29419451);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      return;
    } 
  }
  
  public void t100Clicked(View paramView) {
    this.h = 100;
    ((TextView)findViewById(2131165438)).setText(2131427428);
    d();
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2131165266);
    ((RelativeLayout)relativeLayout.findViewById(2131165304)).setVisibility(0);
    ((RelativeLayout)relativeLayout.findViewById(2131165331)).setBackgroundColor(Color.argb(227, 16, 173, 245));
    ((RelativeLayout)relativeLayout.findViewById(2131165331)).setBackgroundResource(2131099819);
    t(this);
  }
  
  public void t10Clicked(View paramView) {
    h();
    c.c.b("Type.xml", String.valueOf(9));
    t(this);
  }
  
  public void t11Clicked(View paramView) {
    i();
    c.c.b("Type.xml", String.valueOf(10));
    t(this);
  }
  
  public void t12Clicked(View paramView) {
    j();
    c.c.b("Type.xml", String.valueOf(11));
    t(this);
  }
  
  public void t1Clicked(View paramView) {
    k();
    c.c.b("Type.xml", String.valueOf(0));
    t(this);
  }
  
  public void t2Clicked(View paramView) {
    l();
    c.c.b("Type.xml", String.valueOf(1));
    t(this);
  }
  
  public void t3Clicked(View paramView) {
    m();
    c.c.b("Type.xml", String.valueOf(2));
    t(this);
  }
  
  public void t4Clicked(View paramView) {
    n();
    c.c.b("Type.xml", String.valueOf(3));
    t(this);
  }
  
  public void t5Clicked(View paramView) {
    o();
    c.c.b("Type.xml", String.valueOf(4));
    t(this);
  }
  
  public void t6Clicked(View paramView) {
    p();
    c.c.b("Type.xml", String.valueOf(5));
    t(this);
  }
  
  public void t7Clicked(View paramView) {
    q();
    c.c.b("Type.xml", String.valueOf(6));
    t(this);
  }
  
  public void t8Clicked(View paramView) {
    r();
    c.c.b("Type.xml", String.valueOf(7));
    t(this);
  }
  
  public void t9Clicked(View paramView) {
    s();
    c.c.b("Type.xml", String.valueOf(8));
    t(this);
  }
  
  public final class a implements Runnable {
    public a(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class b implements Runnable {
    public b(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class c implements Runnable {
    public c(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class d implements Runnable {
    public d(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class e implements Runnable {
    public e(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class f implements Runnable {
    public f(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class g implements Runnable {
    public g(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class h implements Runnable {
    public h(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class i implements Runnable {
    public i(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class j implements Runnable {
    public j(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class k implements Runnable {
    public k(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class l implements View.OnSystemUiVisibilityChangeListener {
    public l(MenuActivity this$0) {}
    
    public final void onSystemUiVisibilityChange(int param1Int) {
      if ((param1Int & 0x4) == 0)
        this.a.setSystemUiVisibility(5894); 
    }
  }
  
  public final class m implements e0.h {
    public final void a(e0.f param1f, List<Purchase> param1List) {
      int i = param1f.a;
    }
  }
  
  public final class n implements e0.d {
    public n(MenuActivity this$0) {}
    
    public final void a(e0.f param1f) {
      if (param1f.a == 0) {
        e0.f f1;
        e0.c c = this.a.e;
        a a = new a(this);
        c.getClass();
        if (!c.e()) {
          f1 = e0.t.i;
        } else if (TextUtils.isEmpty("inapp")) {
          a1.i.f("BillingClient", "Please provide a valid product type.");
          f1 = e0.t.e;
        } else if (f1.i((Callable)new e0.o((e0.c)f1, "inapp", a), 30000L, (Runnable)new e0.k(1, a), f1.g()) == null) {
          f1 = f1.h();
        } else {
          return;
        } 
        a1.q q = a1.s.j;
        a.a(f1, (List<Purchase>)a1.b.m);
      } 
    }
    
    public final void b() {}
    
    public final class a implements e0.g {
      public a(MenuActivity.n this$0) {}
      
      public final void a(e0.f param2f, List<Purchase> param2List) {
        if (param2f.a == 0) {
          boolean bool;
          if (param2List != null) {
            Iterator<Purchase> iterator = param2List.iterator();
            int i = 0;
            label38: while (true) {
              bool = i;
              if (iterator.hasNext()) {
                Purchase purchase = iterator.next();
                if (purchase != null) {
                  JSONArray jSONArray;
                  param2List = new ArrayList<Purchase>();
                  if (purchase.c.has("productIds")) {
                    jSONArray = purchase.c.optJSONArray("productIds");
                    if (jSONArray != null)
                      for (bool = false; bool < jSONArray.length(); bool++)
                        param2List.add(jSONArray.optString(bool));  
                  } else if (((Purchase)jSONArray).c.has("productId")) {
                    param2List.add(((Purchase)jSONArray).c.optString("productId"));
                  } 
                  Iterator<Purchase> iterator1 = param2List.iterator();
                  bool = i;
                  while (true) {
                    i = bool;
                    if (iterator1.hasNext()) {
                      String str = (String)iterator1.next();
                      if (str != null && str.equals(this.a.a.f)) {
                        MenuActivity menuActivity = this.a.a;
                        menuActivity.d.putBoolean("checkers_removed_ads", true);
                        menuActivity.d.commit();
                        MenuActivity.w = true;
                        RelativeLayout relativeLayout = (RelativeLayout)menuActivity.findViewById(2131165266);
                        if (relativeLayout != null)
                          relativeLayout.setVisibility(8); 
                        bool = true;
                      } 
                      continue;
                    } 
                    continue label38;
                  } 
                } 
                continue;
              } 
              break;
            } 
          } else {
            bool = false;
          } 
          if (!bool) {
            MenuActivity menuActivity = this.a.a;
            menuActivity.d.putBoolean("checkers_removed_ads", false);
            menuActivity.d.commit();
            MenuActivity.w = false;
            RelativeLayout relativeLayout = (RelativeLayout)menuActivity.findViewById(2131165266);
            if (relativeLayout != null)
              relativeLayout.setVisibility(0); 
          } 
        } 
      }
    }
  }
  
  public final class a implements e0.g {
    public a(MenuActivity this$0) {}
    
    public final void a(e0.f param1f, List<Purchase> param1List) {
      if (param1f.a == 0) {
        boolean bool;
        if (param1List != null) {
          Iterator<Purchase> iterator = param1List.iterator();
          int i = 0;
          label38: while (true) {
            bool = i;
            if (iterator.hasNext()) {
              Purchase purchase = iterator.next();
              if (purchase != null) {
                JSONArray jSONArray;
                param1List = new ArrayList<Purchase>();
                if (purchase.c.has("productIds")) {
                  jSONArray = purchase.c.optJSONArray("productIds");
                  if (jSONArray != null)
                    for (bool = false; bool < jSONArray.length(); bool++)
                      param1List.add(jSONArray.optString(bool));  
                } else if (((Purchase)jSONArray).c.has("productId")) {
                  param1List.add(((Purchase)jSONArray).c.optString("productId"));
                } 
                Iterator<Purchase> iterator1 = param1List.iterator();
                bool = i;
                while (true) {
                  i = bool;
                  if (iterator1.hasNext()) {
                    String str = (String)iterator1.next();
                    if (str != null && str.equals(this.a.a.f)) {
                      MenuActivity menuActivity = this.a.a;
                      menuActivity.d.putBoolean("checkers_removed_ads", true);
                      menuActivity.d.commit();
                      MenuActivity.w = true;
                      RelativeLayout relativeLayout = (RelativeLayout)menuActivity.findViewById(2131165266);
                      if (relativeLayout != null)
                        relativeLayout.setVisibility(8); 
                      bool = true;
                    } 
                    continue;
                  } 
                  continue label38;
                } 
              } 
              continue;
            } 
            break;
          } 
        } else {
          bool = false;
        } 
        if (!bool) {
          MenuActivity menuActivity = this.a.a;
          menuActivity.d.putBoolean("checkers_removed_ads", false);
          menuActivity.d.commit();
          MenuActivity.w = false;
          RelativeLayout relativeLayout = (RelativeLayout)menuActivity.findViewById(2131165266);
          if (relativeLayout != null)
            relativeLayout.setVisibility(0); 
        } 
      } 
    }
  }
  
  public final class o implements ViewTreeObserver.OnGlobalLayoutListener {
    public o(MenuActivity this$0, HorizontalScrollView param1HorizontalScrollView) {}
    
    public final void onGlobalLayout() {
      ViewTreeObserver viewTreeObserver = this.a.getViewTreeObserver();
      viewTreeObserver.removeOnGlobalLayoutListener(this);
      viewTreeObserver.addOnScrollChangedListener(new a(this));
    }
    
    public final class a implements ViewTreeObserver.OnScrollChangedListener {
      public a(MenuActivity.o this$0) {}
      
      public final void onScrollChanged() {
        int i = this.a.a.getScrollX();
        i = (int)((MenuActivity.W / 2 + i) / MenuActivity.X);
        if (i != MenuActivity.H) {
          MenuActivity.H = i;
          MenuActivity menuActivity = this.a.b;
          float f1 = MenuActivity.W;
          float f2 = MenuActivity.X;
          menuActivity.getClass();
          MenuActivity.g(i, f1, f2);
        } 
      }
    }
  }
  
  public final class a implements ViewTreeObserver.OnScrollChangedListener {
    public a(MenuActivity this$0) {}
    
    public final void onScrollChanged() {
      int i = this.a.a.getScrollX();
      i = (int)((MenuActivity.W / 2 + i) / MenuActivity.X);
      if (i != MenuActivity.H) {
        MenuActivity.H = i;
        MenuActivity menuActivity = this.a.b;
        float f1 = MenuActivity.W;
        float f2 = MenuActivity.X;
        menuActivity.getClass();
        MenuActivity.g(i, f1, f2);
      } 
    }
  }
  
  public final class p implements Runnable {
    public p(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class q implements Runnable {
    public q(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class r implements Runnable {
    public r(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class s implements Runnable {
    public s(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class t implements Runnable {
    public t(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class u implements Runnable {
    public u(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class v implements Runnable {
    public v(MenuActivity this$0) {}
    
    public final void run() {
      Toast toast = this.i.u;
      if (toast != null)
        toast.show(); 
    }
  }
  
  public final class w implements Runnable {
    public w(MenuActivity this$0, RelativeLayout param1RelativeLayout) {}
    
    public final void run() {
      this.i.setBackgroundResource(2131099692);
      Toast toast = this.j.t;
      if (toast != null)
        toast.show(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\MenuActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */