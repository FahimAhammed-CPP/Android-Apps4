package com.dimcoms.checkers;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;
import f0.a0;
import f0.y;
import g0.a0;
import g0.r;
import g0.s;
import g0.t;
import g0.v;
import g0.w;
import g0.y;
import g0.z;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;

public class MainActivity extends Activity implements t {
  public static int A0 = 0;
  
  public static int B0 = 0;
  
  public static int C0 = 0;
  
  public static int D0 = 0;
  
  public static int E0 = 0;
  
  public static int F0 = 0;
  
  public static MainActivity G;
  
  public static int G0 = 0;
  
  public static boolean H = false;
  
  public static int H0 = 0;
  
  public static boolean I = true;
  
  public static SoundPool I0;
  
  public static boolean J = false;
  
  public static String J0 = "";
  
  public static InterstitialAd K;
  
  public static String K0 = "";
  
  public static InterstitialAd L;
  
  public static Bitmap L0;
  
  public static AdView M;
  
  public static int M0 = -7829368;
  
  public static RewardedAd N;
  
  public static boolean N0 = false;
  
  public static RewardedAd O;
  
  public static boolean O0 = true;
  
  public static MySurfaceView2 P;
  
  public static String P0 = "0";
  
  public static int Q = 0;
  
  public static int Q0 = 0;
  
  public static int R = 0;
  
  public static w R0 = new w();
  
  public static RelativeLayout S;
  
  public static int S0 = 0;
  
  public static RelativeLayout T;
  
  public static int T0 = 3;
  
  public static y U;
  
  public static int U0 = 0;
  
  public static y V;
  
  public static boolean V0 = false;
  
  public static boolean W = false;
  
  public static boolean W0 = false;
  
  public static boolean X = false;
  
  public static int Y = 1;
  
  public static boolean Z = true;
  
  public static o a0;
  
  public static boolean b0 = false;
  
  public static boolean c0 = false;
  
  public static ArrayList<v> d0;
  
  public static ArrayList<w> e0;
  
  public static ArrayList<z> f0;
  
  public static g0.b g0;
  
  public static int h0 = 0;
  
  public static boolean i0 = false;
  
  public static int j0 = 1;
  
  public static int k0 = 0;
  
  public static boolean l0 = true;
  
  public static boolean m0 = true;
  
  public static boolean n0 = true;
  
  public static boolean o0 = true;
  
  public static boolean p0 = true;
  
  public static boolean q0 = false;
  
  public static boolean r0 = false;
  
  public static ArrayList<v> s0;
  
  public static ArrayList<w> t0;
  
  public static boolean u0 = true;
  
  public static boolean v0 = false;
  
  public static int w0;
  
  public static int x0;
  
  public static int y0;
  
  public static int z0;
  
  public int A;
  
  public ArrayList<g0.b> B = new ArrayList<g0.b>();
  
  public boolean C;
  
  public boolean D = false;
  
  public boolean E = false;
  
  public FirebaseAnalytics F;
  
  public int a;
  
  public SharedPreferences b;
  
  public SharedPreferences.Editor c;
  
  public InterstitialAd d;
  
  public RewardedAd e;
  
  public String f = "ca-app-pub-2817796843165879/8634270049";
  
  public String g = "ca-app-pub-2817796843165879/8024794055";
  
  public String h = "ca-app-pub-2817796843165879/2045165838";
  
  public float i;
  
  public float j;
  
  public boolean k;
  
  public float l;
  
  public float m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public boolean q = false;
  
  public int r = 0;
  
  public int s = 0;
  
  public g0.a t;
  
  public q u;
  
  public g0.d v;
  
  public boolean w = false;
  
  public r x = null;
  
  public s y = null;
  
  public boolean z = false;
  
  public static boolean e() {
    ArrayList<w> arrayList = e0;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (arrayList != null) {
      if (arrayList.size() == 0)
        return true; 
      if (U0 == 10) {
        g0.b b1 = g0;
        if (b1 != null) {
          arrayList = b1.r;
          ArrayList arrayList1 = b1.l;
          if (arrayList != null && arrayList1 != null) {
            bool1 = bool2;
            if (arrayList.size() != 1) {
              if (arrayList1.size() == 1)
                return true; 
            } else {
              return bool1;
            } 
          } 
        } 
      } 
      bool1 = false;
    } 
    return bool1;
  }
  
  public static void i(boolean paramBoolean) {
    P.setEnabled(paramBoolean ^ true);
    if (paramBoolean || k0 <= 0)
      X = false; 
  }
  
  public static void p() {
    RelativeLayout relativeLayout = S;
    if (relativeLayout != null) {
      relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
      AdView adView = M;
      if (adView != null && !i0)
        adView.setVisibility(8); 
    } 
  }
  
  public final void A() {
    this.x = (r)new g0.l();
    j0 = 10;
    t();
  }
  
  public final void B() {
    this.x = (r)new g0.m();
    j0 = 4;
    t();
  }
  
  public final void C() {
    this.x = (r)new g0.n();
    j0 = 5;
    t();
  }
  
  public final void D() {
    this.x = (r)new g0.o();
    j0 = 7;
    t();
  }
  
  public final void E() {
    this.x = (r)new g0.p();
    j0 = 8;
    t();
  }
  
  public final void F() {
    this.x = (r)new g0.q();
    j0 = 3;
    t();
  }
  
  public final void G() {
    g0.a a1 = this.t;
    if (a1 != null && a1.l && !a1.i) {
      a1.i = true;
      a1.l = false;
      synchronized (a1.n) {
        null.a = true;
      } 
    } 
    if (!this.D)
      runOnUiThread(new b()); 
  }
  
  public final Bitmap H(String paramString) {
    Paint paint = new Paint();
    int i = this.A / 30;
    float f1 = i;
    paint.setTextSize(0.7F * f1);
    paint.setColor(M0);
    paint.setTextAlign(Paint.Align.CENTER);
    Rect rect = new Rect();
    String str = K0;
    paint.getTextBounds(str, 0, str.length(), rect);
    int j = rect.height();
    Bitmap bitmap = Bitmap.createBitmap(this.A, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    canvas.drawBitmap(L0, null, new RectF(0.0F, 0.0F, this.A, f1), paint);
    f1 = (this.A * 3 / 4);
    float f2 = (i - (i - j) / 2);
    canvas.drawText(paramString, f1, f2, paint);
    canvas.drawText(K0, (this.A / 4), f2, paint);
    return bitmap;
  }
  
  public final void I() {
    W = false;
    if (U != null && !isFinishing()) {
      try {
        U.show();
      } catch (Exception exception) {}
      RelativeLayout relativeLayout = T;
      if (relativeLayout != null)
        relativeLayout.setVisibility(8); 
      relativeLayout = S;
      if (relativeLayout != null)
        relativeLayout.setVisibility(0); 
    } 
  }
  
  public final void a(y paramy, boolean paramBoolean) {
    w w1 = paramy.c;
    if (!paramBoolean) {
      d(w1);
      m();
      this.u = new q(this, w1);
      (new Thread(this.u)).start();
    } else {
      this.v.a();
      a.a = this;
      a.i.a((w1.b(0)).a, (w1.b(0)).b);
      for (int i = 1; i < w1.c(); i++) {
        z z = w1.b(i);
        g0.d d1 = this.v;
        int j = z.a;
        int k = z.b;
        d1.h[j][k] = true;
        d1.b();
        MySurfaceView2.W = false;
      } 
      this.v.c();
      a0.sendEmptyMessage(3);
    } 
    P.b();
  }
  
  public final void b() {
    try {
      if (!i0) {
        InterstitialAd interstitialAd = this.d;
        if (interstitialAd != null) {
          interstitialAd.setFullScreenContentCallback(new c(this));
          this.d.show(this);
          return;
        } 
        this.z = true;
        g();
        return;
      } 
      this.z = true;
      return;
    } catch (NoClassDefFoundError|Exception noClassDefFoundError) {
      this.z = true;
      return;
    } 
  }
  
  public void backClicked(View paramView) {
    if (J) {
      J = false;
      i(false);
      X = true;
      Button button = (Button)findViewById(2131165230);
      if (button != null) {
        button.clearAnimation();
        button.setBackgroundResource(2131099806);
      } 
    } 
    if (X) {
      boolean bool = Z;
      int i = k0;
      if (bool) {
        if (i < 2)
          return; 
      } else if (i < 1) {
        return;
      } 
      if (bool) {
        i -= 2;
      } else {
        i--;
      } 
      k0 = i;
      if (i == 0)
        X = false; 
      if (i < this.B.size() && k0 >= 0) {
        boolean bool1;
        O0 = true;
        G();
        g0.b b1 = g0;
        if (b1 != null) {
          i = b1.u;
          bool1 = b1.v;
          bool = b1.w;
        } else {
          bool = false;
          i = 0;
          bool1 = false;
        } 
        b1 = this.B.get(k0);
        g0 = b1;
        b1.u = i + 1;
        b1.v = bool1;
        b1.w = bool;
        this.v = new g0.d(b1);
        i = this.B.size();
        if (Z) {
          this.B.remove(i - 1);
          this.B.remove(i - 2);
        } else {
          this.B.remove(i - 1);
        } 
        m();
        try {
          e0 = this.x.g(g0);
        } catch (g0.f f) {
          PrintStream printStream = System.out;
          StringBuilder stringBuilder = b.b.c("MainPanel backButtonListener ");
          stringBuilder.append(f.getMessage());
          printStream.println(stringBuilder.toString());
        } 
        this.x.d(g0);
        h0 = 0;
        r(false, false);
        P.b();
      } 
      if (l0) {
        SoundPool soundPool = I0;
        if (soundPool != null)
          soundPool.play(A0, 1.0F, 1.0F, 1, 0, 1.0F); 
      } 
    } 
  }
  
  public final boolean c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield x : Lg0/r;
    //   4: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   7: invokevirtual g : (Lg0/b;)Ljava/util/ArrayList;
    //   10: putstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
    //   13: goto -> 48
    //   16: astore_2
    //   17: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   20: astore_3
    //   21: ldc_w 'MainPanel actionPerformed '
    //   24: invokestatic c : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: astore #4
    //   29: aload #4
    //   31: aload_2
    //   32: invokevirtual getMessage : ()Ljava/lang/String;
    //   35: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   38: pop
    //   39: aload_3
    //   40: aload #4
    //   42: invokevirtual toString : ()Ljava/lang/String;
    //   45: invokevirtual println : (Ljava/lang/String;)V
    //   48: getstatic com/dimcoms/checkers/MainActivity.b0 : Z
    //   51: ifeq -> 64
    //   54: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   57: iconst_0
    //   58: putfield t : I
    //   61: goto -> 279
    //   64: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   67: getfield r : Ljava/util/ArrayList;
    //   70: invokevirtual iterator : ()Ljava/util/Iterator;
    //   73: astore_2
    //   74: aload_2
    //   75: invokeinterface hasNext : ()Z
    //   80: ifeq -> 104
    //   83: aload_2
    //   84: invokeinterface next : ()Ljava/lang/Object;
    //   89: checkcast g0/v
    //   92: getfield j : I
    //   95: iconst_2
    //   96: if_icmpne -> 74
    //   99: iconst_1
    //   100: istore_1
    //   101: goto -> 106
    //   104: iconst_0
    //   105: istore_1
    //   106: iload_1
    //   107: ifeq -> 279
    //   110: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   113: getfield l : Ljava/util/ArrayList;
    //   116: invokevirtual iterator : ()Ljava/util/Iterator;
    //   119: astore_2
    //   120: aload_2
    //   121: invokeinterface hasNext : ()Z
    //   126: ifeq -> 150
    //   129: aload_2
    //   130: invokeinterface next : ()Ljava/lang/Object;
    //   135: checkcast g0/v
    //   138: getfield j : I
    //   141: iconst_2
    //   142: if_icmpne -> 120
    //   145: iconst_1
    //   146: istore_1
    //   147: goto -> 152
    //   150: iconst_0
    //   151: istore_1
    //   152: iload_1
    //   153: ifeq -> 279
    //   156: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   159: getfield t : I
    //   162: aload_0
    //   163: getfield x : Lg0/r;
    //   166: invokevirtual m : ()I
    //   169: if_icmple -> 221
    //   172: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   175: getfield r : Ljava/util/ArrayList;
    //   178: invokevirtual size : ()I
    //   181: istore_1
    //   182: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   185: getfield l : Ljava/util/ArrayList;
    //   188: invokevirtual size : ()I
    //   191: iload_1
    //   192: iadd
    //   193: iconst_5
    //   194: if_icmpgt -> 221
    //   197: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   200: iconst_0
    //   201: putfield t : I
    //   204: aload_0
    //   205: iconst_1
    //   206: iconst_0
    //   207: invokevirtual r : (ZZ)V
    //   210: aload_0
    //   211: iconst_1
    //   212: aload_0
    //   213: getfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   216: invokestatic c : (Lcom/dimcoms/checkers/MainActivity;ZLcom/google/firebase/analytics/FirebaseAnalytics;)V
    //   219: iconst_1
    //   220: ireturn
    //   221: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   224: getfield t : I
    //   227: istore_1
    //   228: aload_0
    //   229: getfield x : Lg0/r;
    //   232: invokevirtual l : ()V
    //   235: iload_1
    //   236: bipush #60
    //   238: if_icmple -> 265
    //   241: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   244: iconst_0
    //   245: putfield t : I
    //   248: aload_0
    //   249: iconst_1
    //   250: iconst_0
    //   251: invokevirtual r : (ZZ)V
    //   254: aload_0
    //   255: iconst_1
    //   256: aload_0
    //   257: getfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   260: invokestatic c : (Lcom/dimcoms/checkers/MainActivity;ZLcom/google/firebase/analytics/FirebaseAnalytics;)V
    //   263: iconst_1
    //   264: ireturn
    //   265: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   268: astore_2
    //   269: aload_2
    //   270: aload_2
    //   271: getfield t : I
    //   274: iconst_1
    //   275: iadd
    //   276: putfield t : I
    //   279: invokestatic e : ()Z
    //   282: ifeq -> 302
    //   285: aload_0
    //   286: iconst_1
    //   287: iconst_0
    //   288: invokevirtual r : (ZZ)V
    //   291: aload_0
    //   292: iconst_0
    //   293: aload_0
    //   294: getfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   297: invokestatic c : (Lcom/dimcoms/checkers/MainActivity;ZLcom/google/firebase/analytics/FirebaseAnalytics;)V
    //   300: iconst_1
    //   301: ireturn
    //   302: iconst_0
    //   303: ireturn
    // Exception table:
    //   from	to	target	type
    //   0	13	16	g0/f
  }
  
  public final void d(w paramw) {
    this.v.a();
    for (int i = 0;; i++) {
      g0.d d1;
      if (i < paramw.c()) {
        int j;
        z z = paramw.b(i);
        d1 = this.v;
        if (e()) {
          if (i + 1 == paramw.c()) {
            j = z.a;
          } else {
            j = z.a;
            int k = z.b;
            d1.g[j][k] = true;
            d1.b();
            MySurfaceView2.W = false;
            i++;
          } 
        } else {
          j = z.a;
        } 
        d1.d(j, z.b);
      } else {
        break;
      } 
      d1.b();
      MySurfaceView2.W = false;
    } 
  }
  
  public final void f() {
    // Byte code:
    //   0: getstatic com/dimcoms/checkers/MainActivity.Q0 : I
    //   3: istore_1
    //   4: iload_1
    //   5: ifeq -> 363
    //   8: iload_1
    //   9: bipush #50
    //   11: if_icmpeq -> 363
    //   14: aload_0
    //   15: getfield b : Landroid/content/SharedPreferences;
    //   18: astore #6
    //   20: ldc_w 'checkers_fullUnlocked_'
    //   23: invokestatic c : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: astore #7
    //   28: aload #7
    //   30: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   33: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   36: pop
    //   37: aload #7
    //   39: ldc_w '_'
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: pop
    //   46: aload #7
    //   48: getstatic com/dimcoms/checkers/MainActivity.Q0 : I
    //   51: iconst_1
    //   52: isub
    //   53: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   56: pop
    //   57: aload #7
    //   59: invokevirtual toString : ()Ljava/lang/String;
    //   62: astore #7
    //   64: iconst_0
    //   65: istore #4
    //   67: aload #6
    //   69: aload #7
    //   71: iconst_0
    //   72: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   77: istore_3
    //   78: aload_0
    //   79: getfield b : Landroid/content/SharedPreferences;
    //   82: astore #6
    //   84: ldc_w 'checkers_fullUnlocked_'
    //   87: invokestatic c : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: astore #7
    //   92: aload #7
    //   94: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   97: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload #7
    //   103: ldc_w '_'
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #7
    //   112: getstatic com/dimcoms/checkers/MainActivity.Q0 : I
    //   115: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   118: pop
    //   119: aload #6
    //   121: aload #7
    //   123: invokevirtual toString : ()Ljava/lang/String;
    //   126: iconst_0
    //   127: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   132: istore #5
    //   134: aload_0
    //   135: ldc_w 2131165233
    //   138: invokevirtual findViewById : (I)Landroid/view/View;
    //   141: checkcast android/widget/Button
    //   144: astore #6
    //   146: aload #6
    //   148: ifnull -> 363
    //   151: iload #5
    //   153: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   156: invokevirtual booleanValue : ()Z
    //   159: ifne -> 347
    //   162: iload_3
    //   163: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   166: invokevirtual booleanValue : ()Z
    //   169: ifne -> 347
    //   172: getstatic com/dimcoms/checkers/MainActivity.i0 : Z
    //   175: ifne -> 347
    //   178: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   181: astore #7
    //   183: aload #7
    //   185: ifnull -> 199
    //   188: aload #7
    //   190: getfield w : Z
    //   193: ifeq -> 199
    //   196: goto -> 347
    //   199: aload_0
    //   200: getfield b : Landroid/content/SharedPreferences;
    //   203: astore #7
    //   205: aload_0
    //   206: getfield c : Landroid/content/SharedPreferences$Editor;
    //   209: astore #8
    //   211: iload #4
    //   213: istore_3
    //   214: aload #7
    //   216: ifnull -> 311
    //   219: iload #4
    //   221: istore_3
    //   222: aload #8
    //   224: ifnull -> 311
    //   227: aload #7
    //   229: ldc_w 'hasDailyReward'
    //   232: iconst_0
    //   233: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   238: istore_3
    //   239: invokestatic getDefault : ()Ljava/util/TimeZone;
    //   242: invokestatic getInstance : (Ljava/util/TimeZone;)Ljava/util/Calendar;
    //   245: iconst_5
    //   246: invokevirtual get : (I)I
    //   249: istore_1
    //   250: aload #7
    //   252: ldc_w 'checkers_lastday'
    //   255: iconst_0
    //   256: invokeinterface getInt : (Ljava/lang/String;I)I
    //   261: istore_2
    //   262: iload_2
    //   263: ifne -> 269
    //   266: goto -> 274
    //   269: iload_2
    //   270: iload_1
    //   271: if_icmpeq -> 311
    //   274: aload #8
    //   276: ldc_w 'checkers_lastday'
    //   279: iload_1
    //   280: invokeinterface putInt : (Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    //   285: pop
    //   286: aload #8
    //   288: ldc_w 'hasDailyReward'
    //   291: iconst_1
    //   292: invokeinterface putBoolean : (Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
    //   297: pop
    //   298: aload #8
    //   300: invokeinterface commit : ()Z
    //   305: pop
    //   306: iconst_1
    //   307: istore_3
    //   308: goto -> 311
    //   311: iload_3
    //   312: putstatic com/dimcoms/checkers/MainActivity.W0 : Z
    //   315: aload_0
    //   316: iconst_1
    //   317: putfield D : Z
    //   320: aload_0
    //   321: getfield e : Lcom/google/android/gms/ads/rewarded/RewardedAd;
    //   324: ifnull -> 340
    //   327: getstatic com/dimcoms/checkers/MainActivity.i0 : Z
    //   330: ifne -> 340
    //   333: ldc_w 2131099666
    //   336: istore_1
    //   337: goto -> 356
    //   340: ldc_w 2131099668
    //   343: istore_1
    //   344: goto -> 356
    //   347: aload_0
    //   348: iconst_0
    //   349: putfield D : Z
    //   352: ldc_w 2131099667
    //   355: istore_1
    //   356: aload_0
    //   357: aload #6
    //   359: iload_1
    //   360: invokestatic o : (Landroid/content/Context;Landroid/widget/Button;I)V
    //   363: return
  }
  
  public final void g() {
    this.d = null;
    if (I) {
      L = null;
    } else {
      K = null;
    } 
    AdRequest adRequest = (new AdRequest.Builder()).build();
    InterstitialAd.load((Context)this, this.f, adRequest, new d(this));
  }
  
  public final void h() {
    this.e = null;
    if (I) {
      O = null;
    } else {
      N = null;
    } 
    AdRequest adRequest = (new AdRequest.Builder()).build();
    RewardedAd.load((Context)this, this.g, adRequest, new e(this));
  }
  
  public void hintPressed(View paramView) {
    boolean bool = this.D;
    int i = 0;
    if (!bool) {
      if (O0) {
        O0 = false;
        G();
        Button button = (Button)findViewById(2131165233);
        if (button != null)
          button.setBackgroundResource(2131099670); 
        try {
          e0 = this.x.g(g0);
        } catch (g0.f f) {
          PrintStream printStream = System.out;
          StringBuilder stringBuilder = b.b.c("MainPanel actionPerformed ");
          stringBuilder.append(f.getMessage());
          printStream.println(stringBuilder.toString());
        } 
        ArrayList<w> arrayList = e0;
        if (arrayList != null && arrayList.size() > 0) {
          if (e0.size() == 1) {
            new Hashtable<Object, Object>();
            new Hashtable<Object, Object>();
            new ArrayList();
            new a0();
            a(new y(e0.get(0), Integer.valueOf(0)), true);
          } else {
            n(true);
          } 
        } else {
          O0 = true;
          if (button != null)
            f0.k.o((Context)G, button, 2131099667); 
        } 
      } 
      g0.b b1 = g0;
      if (b1 != null)
        i = b1.v; 
      b1.v = i + 1;
      return;
    } 
    if (!this.E)
      if (this.e != null && !i0) {
        if (!v0) {
          v0 = true;
          w0 = 6;
          try {
            FirebaseAnalytics firebaseAnalytics = this.F;
            if (firebaseAnalytics != null)
              firebaseAnalytics.a(new Bundle(), "rewarded_level_hint_view"); 
          } catch (Error|Exception error) {}
          y y1 = new y((Context)this);
          y1.requestWindowFeature(1);
          y1.setContentView(2131296272);
          Window window = y1.getWindow();
          if (window != null)
            window.setBackgroundDrawableResource(17170445); 
          y1.setCancelable(true);
          V = y1;
          y1.getWindow().setFlags(32, 32);
          y1.setOnCancelListener(new j());
          Button button = (Button)y1.findViewById(2131165448);
          if (button != null)
            button.setOnClickListener(new k(y1)); 
          RelativeLayout relativeLayout2 = (RelativeLayout)y1.findViewById(2131165433);
          if (relativeLayout2 != null)
            relativeLayout2.setVisibility(0); 
          TextView textView1 = (TextView)y1.findViewById(2131165432);
          textView1.setText(2131427484);
          textView1.setGravity(1);
          textView1.setTextSize(1, 18.0F);
          textView1.setTextColor(Color.argb(255, 255, 255, 255));
          textView1.setVisibility(0);
          y1.getWindow().clearFlags(2);
          RelativeLayout relativeLayout1 = S;
          if (relativeLayout1 != null)
            relativeLayout1.setVisibility(0); 
          ((LinearLayout)y1.findViewById(2131165391)).setOnClickListener(new l(this, y1));
          ((LinearLayout)y1.findViewById(2131165380)).setOnClickListener(new m(this, y1));
          View view = y1.findViewById(2131165319);
          TextView textView2 = (TextView)y1.findViewById(2131165320);
          if (view != null && textView2 != null) {
            String str;
            if (W0) {
              view.setBackgroundResource(2131099663);
              str = "#FF000000";
            } else {
              str.setBackgroundResource(2131099664);
              str = "#7F000000";
            } 
            textView2.setTextColor(Color.parseColor(str));
          } 
          y1.getWindow().getDecorView().setSystemUiVisibility(1280);
          y1.show();
          return;
        } 
      } else {
        this.E = true;
        Toast toast = Toast.makeText((Context)this, 2131427356, 1);
        Button button = (Button)findViewById(2131165233);
        if (button != null) {
          button.setBackgroundResource(2131099669);
          (new Handler()).postDelayed(new n(this, button, toast), 400L);
        } 
      }  
  }
  
  public void infoPressed(View paramView) {
    if (!v0)
      f0.a.d(this); 
  }
  
  public final void j(w paramw) {
    g0.b b1 = g0;
    if (b1 != null) {
      this.B.add(new g0.b(b1));
      paramw.a = true;
      if (j0 == 4) {
        b1.o(paramw, true, false);
      } else {
        b1.o(paramw, false, false);
      } 
      k0++;
      g0.d d1 = new g0.d(b1);
      this.v = d1;
      P.setBoardTable(d1);
      try {
        e0 = this.x.g(b1);
      } catch (g0.f f) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = b.b.c("MainPanel actionPerformed ");
        stringBuilder.append(f.getMessage());
        printStream.println(stringBuilder.toString());
      } 
      this.x.d(b1);
    } 
  }
  
  public final void k() {
    this.o = b0;
    if (R0.c() > 2) {
      bool = true;
    } else {
      bool = false;
    } 
    this.p = bool;
    j(R0);
    m();
    boolean bool = c();
    X = true;
    u0 = true;
    O0 = true;
    this.w = false;
    i(false);
    s(bool);
  }
  
  public final void l() {
    boolean bool;
    this.o = b0;
    if (R0.c() > 2) {
      bool = true;
    } else {
      bool = false;
    } 
    this.p = bool;
    j(R0);
    d(R0);
    P.e = 1;
    if (Z) {
      if (b0) {
        g0.t = 0;
      } else {
        g0.b b1 = g0;
        b1.t++;
      } 
      o();
    } else {
      bool = c();
      i(false);
      X = true;
      O0 = true;
      s(bool);
    } 
    u0 = true;
    h0 = 0;
  }
  
  public final void m() {
    P.setBoardTable(this.v);
    P.e = 1;
  }
  
  public void menuClicked(View paramView) {
    f0.a.a(this);
  }
  
  public final void n(boolean paramBoolean) {
    if (!paramBoolean) {
      this.v.a();
      r(false, false);
    } 
    this.y = new s();
    this.t = new g0.a(this.x, new g0.b(g0), this.y, S0, T0, this, paramBoolean);
    (new Thread((Runnable)this.t)).start();
  }
  
  public void newGamePressed(View paramView) {
    if (!v0) {
      v0 = true;
      w0 = 3;
      y y1 = new y((Context)this);
      y1.requestWindowFeature(1);
      y1.setContentView(2131296263);
      Window window = y1.getWindow();
      if (window != null)
        window.setBackgroundDrawableResource(17170445); 
      y1.setCancelable(true);
      V = y1;
      y1.getWindow().setFlags(32, 32);
      y1.setOnCancelListener((DialogInterface.OnCancelListener)new f0.h());
      RelativeLayout relativeLayout2 = (RelativeLayout)y1.findViewById(2131165433);
      if (relativeLayout2 != null)
        relativeLayout2.setVisibility(0); 
      TextView textView = (TextView)y1.findViewById(2131165432);
      textView.setText(2131427332);
      textView.setGravity(1);
      textView.setTextSize(1, 24.0F);
      textView.setTextColor(Color.argb(255, 255, 255, 255));
      textView.setVisibility(0);
      textView = (TextView)y1.findViewById(2131165428);
      textView.setGravity(17);
      textView.setTextSize(1, 15.0F);
      textView.setText(2131427451);
      textView.setTextColor(Color.argb(150, 255, 255, 255));
      y1.getWindow().clearFlags(2);
      RelativeLayout relativeLayout1 = S;
      if (relativeLayout1 != null)
        relativeLayout1.setVisibility(0); 
      ImageView imageView = (ImageView)y1.findViewById(2131165356);
      imageView.setVisibility(0);
      imageView.setImageResource(2131099718);
      int i = (int)TypedValue.applyDimension(1, 50.0F, getResources().getDisplayMetrics());
      int j = (int)TypedValue.applyDimension(1, 50.0F, getResources().getDisplayMetrics());
      ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
      layoutParams.width = i;
      layoutParams.height = j;
      imageView.setLayoutParams(layoutParams);
      Button button = (Button)y1.findViewById(2131165391);
      button.setText(2131427347);
      button.setVisibility(0);
      a.a = this;
      a.b = (Dialog)y1;
      button.setOnClickListener(a.c);
      button.setBackgroundResource(2131099810);
      button = (Button)y1.findViewById(2131165380);
      button.setText(2131427336);
      button.setVisibility(0);
      button.setOnClickListener((View.OnClickListener)new f0.i(y1));
      button.setBackgroundResource(2131099808);
      y1.show();
    } 
  }
  
  public final void o() {
    y y1;
    Integer integer = Integer.valueOf(0);
    O0 = false;
    this.w = true;
    i(true);
    G();
    try {
      e0 = this.x.g(g0);
    } catch (g0.f f) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = b.b.c("MainPanel actionPerformed ");
      stringBuilder.append(f.getMessage());
      printStream.println(stringBuilder.toString());
    } 
    if (e()) {
      r(true, false);
      f0.a.c(this, false, this.F);
      return;
    } 
    if (e0.size() == 1) {
      new Hashtable<Object, Object>();
      new Hashtable<Object, Object>();
      new ArrayList();
      new a0();
      a(new y(e0.get(0), integer), false);
      return;
    } 
    int j = k0;
    int i = j + 1;
    if (!o0)
      i = j + 2; 
    if (j <= 1) {
      if (U0 == 7 && (P0.equals("2") || P0.equals("3") || P0.equals("4") || P0.equals("5") || P0.equals("6") || P0.equals("7") || P0.equals("8") || P0.equals("9"))) {
        n(false);
        return;
      } 
      w w1 = g0.f(e0, k0);
      new Hashtable<Object, Object>();
      new Hashtable<Object, Object>();
      new ArrayList();
      new a0();
      y1 = new y(w1, integer);
    } else if (P0.equals("0")) {
      w w1 = g0.f(e0, k0);
      new Hashtable<Object, Object>();
      new Hashtable<Object, Object>();
      new ArrayList();
      new a0();
      y1 = new y(w1, (Integer)y1);
    } else if (P0.equals("1")) {
      if (i % 4 != 0) {
        n(false);
        return;
      } 
      w w1 = g0.f(e0, k0);
      new Hashtable<Object, Object>();
      new Hashtable<Object, Object>();
      new ArrayList();
      new a0();
      y1 = new y(w1, (Integer)y1);
    } else {
      if (!P0.equals("2") || i % 10 != 0) {
        n(false);
        return;
      } 
      w w1 = g0.f(e0, k0);
      new Hashtable<Object, Object>();
      new Hashtable<Object, Object>();
      new ArrayList();
      new a0();
      y1 = new y(w1, (Integer)y1);
    } 
    a(y1, false);
  }
  
  public final void onBackPressed() {
    if (!W) {
      f0.a.a(this);
      return;
    } 
    I();
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (paramConfiguration.orientation == 1 && P0.equals("50") && I) {
      V0 = true;
      setRequestedOrientation(6);
    } 
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public final void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: invokevirtual getWindow : ()Landroid/view/Window;
    //   9: sipush #128
    //   12: invokevirtual addFlags : (I)V
    //   15: aload_0
    //   16: invokevirtual getWindow : ()Landroid/view/Window;
    //   19: invokevirtual getDecorView : ()Landroid/view/View;
    //   22: sipush #1280
    //   25: invokevirtual setSystemUiVisibility : (I)V
    //   28: getstatic android/os/Build$VERSION.SDK_INT : I
    //   31: istore #6
    //   33: aload_0
    //   34: iload #6
    //   36: putfield a : I
    //   39: aload_0
    //   40: invokevirtual getWindow : ()Landroid/view/Window;
    //   43: invokevirtual getDecorView : ()Landroid/view/View;
    //   46: sipush #5894
    //   49: invokevirtual setSystemUiVisibility : (I)V
    //   52: aload_0
    //   53: invokevirtual getWindow : ()Landroid/view/Window;
    //   56: invokevirtual getDecorView : ()Landroid/view/View;
    //   59: astore_1
    //   60: aload_1
    //   61: new com/dimcoms/checkers/MainActivity$f
    //   64: dup
    //   65: aload_1
    //   66: invokespecial <init> : (Landroid/view/View;)V
    //   69: invokevirtual setOnSystemUiVisibilityChangeListener : (Landroid/view/View$OnSystemUiVisibilityChangeListener;)V
    //   72: new android/util/DisplayMetrics
    //   75: dup
    //   76: invokespecial <init> : ()V
    //   79: astore_1
    //   80: aload_0
    //   81: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
    //   84: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   89: aload_1
    //   90: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
    //   93: aload_1
    //   94: getfield widthPixels : I
    //   97: putstatic com/dimcoms/checkers/MainActivity.Q : I
    //   100: aload_1
    //   101: getfield heightPixels : I
    //   104: putstatic com/dimcoms/checkers/MainActivity.R : I
    //   107: aload_0
    //   108: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
    //   111: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   116: astore #8
    //   118: new android/util/DisplayMetrics
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: astore #9
    //   127: aload #8
    //   129: aload #9
    //   131: invokevirtual getRealMetrics : (Landroid/util/DisplayMetrics;)V
    //   134: aload #9
    //   136: getfield widthPixels : I
    //   139: istore #4
    //   141: iload #4
    //   143: putstatic com/dimcoms/checkers/MainActivity.Q : I
    //   146: aload #9
    //   148: getfield heightPixels : I
    //   151: istore #5
    //   153: iload #5
    //   155: putstatic com/dimcoms/checkers/MainActivity.R : I
    //   158: iload #4
    //   160: istore_3
    //   161: iload #5
    //   163: istore_2
    //   164: iload #6
    //   166: bipush #24
    //   168: if_icmplt -> 202
    //   171: iload #4
    //   173: istore_3
    //   174: iload #5
    //   176: istore_2
    //   177: aload_0
    //   178: invokevirtual isInMultiWindowMode : ()Z
    //   181: ifeq -> 202
    //   184: aload_1
    //   185: getfield widthPixels : I
    //   188: istore_3
    //   189: iload_3
    //   190: putstatic com/dimcoms/checkers/MainActivity.Q : I
    //   193: aload_1
    //   194: getfield heightPixels : I
    //   197: istore_2
    //   198: iload_2
    //   199: putstatic com/dimcoms/checkers/MainActivity.R : I
    //   202: iload_3
    //   203: iload_2
    //   204: if_icmple -> 215
    //   207: iload_3
    //   208: putstatic com/dimcoms/checkers/MainActivity.R : I
    //   211: iload_2
    //   212: putstatic com/dimcoms/checkers/MainActivity.Q : I
    //   215: aload_0
    //   216: invokevirtual getFilesDir : ()Ljava/io/File;
    //   219: astore_1
    //   220: aload_1
    //   221: ifnull -> 232
    //   224: aload_1
    //   225: invokevirtual getPath : ()Ljava/lang/String;
    //   228: astore_1
    //   229: goto -> 236
    //   232: ldc_w '/data/data/com.jetstartgames.chess/files'
    //   235: astore_1
    //   236: aload_1
    //   237: putstatic f0/k.c : Ljava/lang/String;
    //   240: aload_0
    //   241: aload_0
    //   242: invokestatic getInstance : (Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   245: putfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
    //   248: goto -> 251
    //   251: aload_0
    //   252: invokestatic getDefaultSharedPreferences : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   255: astore_1
    //   256: aload_0
    //   257: aload_1
    //   258: putfield b : Landroid/content/SharedPreferences;
    //   261: aload_0
    //   262: aload_1
    //   263: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   268: putfield c : Landroid/content/SharedPreferences$Editor;
    //   271: new java/util/ArrayList
    //   274: dup
    //   275: invokespecial <init> : ()V
    //   278: putstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
    //   281: new java/util/ArrayList
    //   284: dup
    //   285: invokespecial <init> : ()V
    //   288: putstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   291: iconst_0
    //   292: putstatic com/dimcoms/checkers/MainActivity.v0 : Z
    //   295: iconst_0
    //   296: putstatic com/dimcoms/checkers/MainActivity.J : Z
    //   299: iconst_0
    //   300: putstatic com/dimcoms/checkers/MainActivity.V0 : Z
    //   303: iconst_1
    //   304: putstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   307: invokestatic e : ()I
    //   310: istore_2
    //   311: iload_2
    //   312: putstatic com/dimcoms/checkers/MainActivity.Y : I
    //   315: iload_2
    //   316: ifeq -> 324
    //   319: iload_2
    //   320: iconst_3
    //   321: if_icmpne -> 328
    //   324: iconst_0
    //   325: putstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   328: ldc_w 'Move.xml'
    //   331: invokestatic c : (Ljava/lang/String;)Z
    //   334: ifeq -> 370
    //   337: ldc_w 'Move.xml'
    //   340: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   343: astore_1
    //   344: aload_1
    //   345: ifnonnull -> 351
    //   348: goto -> 370
    //   351: aload_1
    //   352: ldc_w '1'
    //   355: invokevirtual equals : (Ljava/lang/Object;)Z
    //   358: ifeq -> 364
    //   361: goto -> 370
    //   364: iconst_0
    //   365: istore #7
    //   367: goto -> 373
    //   370: iconst_1
    //   371: istore #7
    //   373: iload #7
    //   375: putstatic com/dimcoms/checkers/MainActivity.o0 : Z
    //   378: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   381: ifne -> 391
    //   384: iload #7
    //   386: iconst_1
    //   387: ixor
    //   388: putstatic com/dimcoms/checkers/MainActivity.o0 : Z
    //   391: ldc_w 'Mandatory.xml'
    //   394: invokestatic c : (Ljava/lang/String;)Z
    //   397: ifeq -> 433
    //   400: ldc_w 'Mandatory.xml'
    //   403: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   406: astore_1
    //   407: aload_1
    //   408: ifnonnull -> 414
    //   411: goto -> 433
    //   414: aload_1
    //   415: ldc_w '1'
    //   418: invokevirtual equals : (Ljava/lang/Object;)Z
    //   421: ifeq -> 427
    //   424: goto -> 433
    //   427: iconst_0
    //   428: istore #7
    //   430: goto -> 436
    //   433: iconst_1
    //   434: istore #7
    //   436: iload #7
    //   438: putstatic com/dimcoms/checkers/MainActivity.p0 : Z
    //   441: aload_0
    //   442: getstatic com/dimcoms/checkers/MainActivity.R : I
    //   445: invokestatic j : (Landroid/content/Context;I)Z
    //   448: istore #7
    //   450: iload #7
    //   452: putstatic com/dimcoms/checkers/MainActivity.I : Z
    //   455: iload #7
    //   457: ifeq -> 508
    //   460: ldc_w 'HA.xml'
    //   463: invokestatic c : (Ljava/lang/String;)Z
    //   466: ifeq -> 498
    //   469: ldc_w 'HA.xml'
    //   472: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   475: astore_1
    //   476: aload_1
    //   477: ifnonnull -> 483
    //   480: goto -> 498
    //   483: aload_1
    //   484: ldc_w '1'
    //   487: invokevirtual equals : (Ljava/lang/Object;)Z
    //   490: ifeq -> 498
    //   493: iconst_1
    //   494: istore_2
    //   495: goto -> 500
    //   498: iconst_0
    //   499: istore_2
    //   500: iload_2
    //   501: ifne -> 508
    //   504: iconst_0
    //   505: putstatic com/dimcoms/checkers/MainActivity.I : Z
    //   508: aload_0
    //   509: getfield b : Landroid/content/SharedPreferences;
    //   512: ldc_w 'isMenuFinisfed'
    //   515: iconst_0
    //   516: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   521: putstatic com/dimcoms/checkers/MainActivity.N0 : Z
    //   524: aload_0
    //   525: getfield b : Landroid/content/SharedPreferences;
    //   528: ldc_w 'checkers_removed_ads'
    //   531: iconst_0
    //   532: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   537: putstatic com/dimcoms/checkers/MainActivity.i0 : Z
    //   540: ldc_w 'Helper.xml'
    //   543: invokestatic c : (Ljava/lang/String;)Z
    //   546: ifeq -> 582
    //   549: ldc_w 'Helper.xml'
    //   552: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   555: astore_1
    //   556: aload_1
    //   557: ifnonnull -> 563
    //   560: goto -> 582
    //   563: aload_1
    //   564: ldc_w '1'
    //   567: invokevirtual equals : (Ljava/lang/Object;)Z
    //   570: ifeq -> 576
    //   573: goto -> 582
    //   576: iconst_0
    //   577: istore #7
    //   579: goto -> 585
    //   582: iconst_1
    //   583: istore #7
    //   585: iload #7
    //   587: putstatic com/dimcoms/checkers/MainActivity.m0 : Z
    //   590: ldc_w 'Capture.xml'
    //   593: invokestatic c : (Ljava/lang/String;)Z
    //   596: ifeq -> 632
    //   599: ldc_w 'Capture.xml'
    //   602: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   605: astore_1
    //   606: aload_1
    //   607: ifnonnull -> 613
    //   610: goto -> 632
    //   613: aload_1
    //   614: ldc_w '1'
    //   617: invokevirtual equals : (Ljava/lang/Object;)Z
    //   620: ifeq -> 626
    //   623: goto -> 632
    //   626: iconst_0
    //   627: istore #7
    //   629: goto -> 635
    //   632: iconst_1
    //   633: istore #7
    //   635: iload #7
    //   637: putstatic com/dimcoms/checkers/MainActivity.n0 : Z
    //   640: invokestatic d : ()Ljava/lang/String;
    //   643: astore_1
    //   644: aload_1
    //   645: putstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   648: aload_1
    //   649: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   652: invokevirtual intValue : ()I
    //   655: putstatic com/dimcoms/checkers/MainActivity.Q0 : I
    //   658: invokestatic g : ()Ljava/lang/Integer;
    //   661: invokevirtual intValue : ()I
    //   664: putstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   667: new com/dimcoms/checkers/MainActivity$o
    //   670: dup
    //   671: aload_0
    //   672: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
    //   675: putstatic com/dimcoms/checkers/MainActivity.a0 : Lcom/dimcoms/checkers/MainActivity$o;
    //   678: iconst_0
    //   679: putstatic com/dimcoms/checkers/MainActivity.W0 : Z
    //   682: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   685: istore #7
    //   687: bipush #6
    //   689: istore_3
    //   690: iload #7
    //   692: ifeq -> 733
    //   695: aload_0
    //   696: getfield a : I
    //   699: bipush #18
    //   701: if_icmplt -> 720
    //   704: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   707: ldc_w '50'
    //   710: invokevirtual equals : (Ljava/lang/Object;)Z
    //   713: ifeq -> 720
    //   716: iconst_1
    //   717: putstatic com/dimcoms/checkers/MainActivity.V0 : Z
    //   720: aload_0
    //   721: bipush #6
    //   723: invokevirtual setRequestedOrientation : (I)V
    //   726: ldc_w 2131296257
    //   729: istore_2
    //   730: goto -> 742
    //   733: aload_0
    //   734: iconst_1
    //   735: invokevirtual setRequestedOrientation : (I)V
    //   738: ldc_w 2131296256
    //   741: istore_2
    //   742: aload_0
    //   743: iload_2
    //   744: invokevirtual setContentView : (I)V
    //   747: aload_0
    //   748: putstatic com/dimcoms/checkers/MainActivity.G : Lcom/dimcoms/checkers/MainActivity;
    //   751: aload_0
    //   752: iconst_0
    //   753: putfield D : Z
    //   756: aload_0
    //   757: getstatic com/dimcoms/checkers/MainActivity.R : I
    //   760: getstatic com/dimcoms/checkers/MainActivity.Q : I
    //   763: invokestatic l : (Landroid/app/Activity;II)Z
    //   766: ifeq -> 821
    //   769: aload_0
    //   770: ldc_w 2131165400
    //   773: invokevirtual findViewById : (I)Landroid/view/View;
    //   776: checkcast android/widget/RelativeLayout
    //   779: astore_1
    //   780: aload_1
    //   781: ifnull -> 790
    //   784: aload_1
    //   785: bipush #8
    //   787: invokevirtual setVisibility : (I)V
    //   790: aload_0
    //   791: ldc_w 2131165430
    //   794: invokevirtual findViewById : (I)Landroid/view/View;
    //   797: checkcast android/widget/TextView
    //   800: astore_1
    //   801: aload_1
    //   802: ifnull -> 821
    //   805: aload_1
    //   806: iconst_1
    //   807: invokevirtual setClickable : (Z)V
    //   810: aload_1
    //   811: new com/dimcoms/checkers/MainActivity$g
    //   814: dup
    //   815: invokespecial <init> : ()V
    //   818: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   821: aload_0
    //   822: ldc_w 2131165318
    //   825: invokevirtual findViewById : (I)Landroid/view/View;
    //   828: checkcast com/dimcoms/checkers/MySurfaceView2
    //   831: astore_1
    //   832: aload_1
    //   833: putstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
    //   836: aload_1
    //   837: iconst_0
    //   838: invokevirtual setBackgroundColor : (I)V
    //   841: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
    //   844: iconst_0
    //   845: invokevirtual setWillNotDraw : (Z)V
    //   848: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
    //   851: astore_1
    //   852: aload_0
    //   853: putstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
    //   856: aload_1
    //   857: getstatic com/dimcoms/checkers/a.i : Lcom/dimcoms/checkers/a$g;
    //   860: invokevirtual setMainActivityListener : (Lcom/dimcoms/checkers/MainActivity$p;)V
    //   863: aload_0
    //   864: ldc_w 2131165451
    //   867: invokevirtual findViewById : (I)Landroid/view/View;
    //   870: checkcast android/widget/RelativeLayout
    //   873: astore_1
    //   874: aload_1
    //   875: putstatic com/dimcoms/checkers/MainActivity.S : Landroid/widget/RelativeLayout;
    //   878: aload_1
    //   879: ifnull -> 894
    //   882: aload_1
    //   883: new com/dimcoms/checkers/MainActivity$h
    //   886: dup
    //   887: aload_0
    //   888: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
    //   891: invokevirtual setOnTouchListener : (Landroid/view/View$OnTouchListener;)V
    //   894: aload_0
    //   895: ldc_w 2131165449
    //   898: invokevirtual findViewById : (I)Landroid/view/View;
    //   901: checkcast android/widget/RelativeLayout
    //   904: astore_1
    //   905: aload_1
    //   906: putstatic com/dimcoms/checkers/MainActivity.T : Landroid/widget/RelativeLayout;
    //   909: aload_1
    //   910: ifnull -> 925
    //   913: aload_1
    //   914: new com/dimcoms/checkers/MainActivity$i
    //   917: dup
    //   918: aload_0
    //   919: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
    //   922: invokevirtual setOnTouchListener : (Landroid/view/View$OnTouchListener;)V
    //   925: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   928: ifeq -> 998
    //   931: aload_0
    //   932: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   935: ldc_w 2131099688
    //   938: invokestatic decodeResource : (Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;
    //   941: putstatic com/dimcoms/checkers/MainActivity.L0 : Landroid/graphics/Bitmap;
    //   944: getstatic com/dimcoms/checkers/MainActivity.Q : I
    //   947: istore_2
    //   948: iload_2
    //   949: i2f
    //   950: ldc_w 0.32
    //   953: fmul
    //   954: f2i
    //   955: iload_2
    //   956: iadd
    //   957: istore #4
    //   959: aload_0
    //   960: iload #4
    //   962: putfield A : I
    //   965: iload #4
    //   967: iconst_4
    //   968: idiv
    //   969: istore #5
    //   971: getstatic com/dimcoms/checkers/MainActivity.R : I
    //   974: istore #6
    //   976: iload #5
    //   978: iload #4
    //   980: iadd
    //   981: iload #6
    //   983: if_icmple -> 998
    //   986: aload_0
    //   987: iload #6
    //   989: iload_2
    //   990: isub
    //   991: iconst_2
    //   992: idiv
    //   993: iload_2
    //   994: iadd
    //   995: putfield A : I
    //   998: aload_0
    //   999: iconst_1
    //   1000: putfield C : Z
    //   1003: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   1006: tableswitch default -> 1064, 1 -> 1163, 2 -> 1154, 3 -> 1145, 4 -> 1136, 5 -> 1127, 6 -> 1117, 7 -> 1107, 8 -> 1097, 9 -> 1087, 10 -> 1077, 11 -> 1067
    //   1064: goto -> 1172
    //   1067: aload_0
    //   1068: invokevirtual y : ()V
    //   1071: bipush #12
    //   1073: istore_2
    //   1074: goto -> 1178
    //   1077: aload_0
    //   1078: invokevirtual v : ()V
    //   1081: bipush #11
    //   1083: istore_2
    //   1084: goto -> 1178
    //   1087: aload_0
    //   1088: invokevirtual A : ()V
    //   1091: bipush #10
    //   1093: istore_2
    //   1094: goto -> 1178
    //   1097: aload_0
    //   1098: invokevirtual u : ()V
    //   1101: bipush #9
    //   1103: istore_2
    //   1104: goto -> 1178
    //   1107: aload_0
    //   1108: invokevirtual E : ()V
    //   1111: bipush #8
    //   1113: istore_2
    //   1114: goto -> 1178
    //   1117: aload_0
    //   1118: invokevirtual D : ()V
    //   1121: bipush #7
    //   1123: istore_2
    //   1124: goto -> 1178
    //   1127: aload_0
    //   1128: invokevirtual x : ()V
    //   1131: iload_3
    //   1132: istore_2
    //   1133: goto -> 1178
    //   1136: aload_0
    //   1137: invokevirtual C : ()V
    //   1140: iconst_5
    //   1141: istore_2
    //   1142: goto -> 1178
    //   1145: aload_0
    //   1146: invokevirtual B : ()V
    //   1149: iconst_4
    //   1150: istore_2
    //   1151: goto -> 1178
    //   1154: aload_0
    //   1155: invokevirtual F : ()V
    //   1158: iconst_3
    //   1159: istore_2
    //   1160: goto -> 1178
    //   1163: aload_0
    //   1164: invokevirtual w : ()V
    //   1167: iconst_2
    //   1168: istore_2
    //   1169: goto -> 1178
    //   1172: aload_0
    //   1173: invokevirtual z : ()V
    //   1176: iconst_1
    //   1177: istore_2
    //   1178: iload_2
    //   1179: putstatic com/dimcoms/checkers/MainActivity.j0 : I
    //   1182: iconst_0
    //   1183: putstatic com/dimcoms/checkers/MainActivity.H : Z
    //   1186: aload_0
    //   1187: getfield b : Landroid/content/SharedPreferences;
    //   1190: ldc_w 'checkers_gameState'
    //   1193: aconst_null
    //   1194: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1199: astore #9
    //   1201: aload_0
    //   1202: getfield b : Landroid/content/SharedPreferences;
    //   1205: ldc_w 'checkers_bordHistory'
    //   1208: aconst_null
    //   1209: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1214: astore #8
    //   1216: aload_0
    //   1217: getfield b : Landroid/content/SharedPreferences;
    //   1220: ldc_w 'checkers_currentMove'
    //   1223: iconst_0
    //   1224: invokeinterface getInt : (Ljava/lang/String;I)I
    //   1229: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1232: astore_1
    //   1233: aload #9
    //   1235: ifnull -> 1390
    //   1238: aload #8
    //   1240: ifnull -> 1390
    //   1243: new java/io/ObjectInputStream
    //   1246: dup
    //   1247: new java/io/ByteArrayInputStream
    //   1250: dup
    //   1251: aload #9
    //   1253: invokestatic p : (Ljava/lang/String;)[B
    //   1256: invokespecial <init> : ([B)V
    //   1259: invokespecial <init> : (Ljava/io/InputStream;)V
    //   1262: invokevirtual readObject : ()Ljava/lang/Object;
    //   1265: checkcast g0/b
    //   1268: astore #9
    //   1270: new java/io/ObjectInputStream
    //   1273: dup
    //   1274: new java/io/ByteArrayInputStream
    //   1277: dup
    //   1278: aload #8
    //   1280: invokestatic p : (Ljava/lang/String;)[B
    //   1283: invokespecial <init> : ([B)V
    //   1286: invokespecial <init> : (Ljava/io/InputStream;)V
    //   1289: invokevirtual readObject : ()Ljava/lang/Object;
    //   1292: checkcast java/util/ArrayList
    //   1295: astore #8
    //   1297: aload #9
    //   1299: ifnull -> 1390
    //   1302: aload #8
    //   1304: ifnull -> 1390
    //   1307: aload #8
    //   1309: invokevirtual size : ()I
    //   1312: aload_1
    //   1313: invokevirtual intValue : ()I
    //   1316: if_icmpne -> 1390
    //   1319: aload #9
    //   1321: putstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   1324: aload_0
    //   1325: new g0/d
    //   1328: dup
    //   1329: aload #9
    //   1331: invokespecial <init> : (Lg0/b;)V
    //   1334: putfield v : Lg0/d;
    //   1337: aload_1
    //   1338: invokevirtual intValue : ()I
    //   1341: putstatic com/dimcoms/checkers/MainActivity.k0 : I
    //   1344: aload_0
    //   1345: getfield x : Lg0/r;
    //   1348: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   1351: invokevirtual g : (Lg0/b;)Ljava/util/ArrayList;
    //   1354: putstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
    //   1357: aload_0
    //   1358: getfield x : Lg0/r;
    //   1361: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   1364: invokevirtual d : (Lg0/b;)V
    //   1367: aload_0
    //   1368: aload #8
    //   1370: putfield B : Ljava/util/ArrayList;
    //   1373: aload_0
    //   1374: invokevirtual m : ()V
    //   1377: getstatic com/dimcoms/checkers/MainActivity.k0 : I
    //   1380: ifeq -> 1390
    //   1383: iconst_1
    //   1384: putstatic com/dimcoms/checkers/MainActivity.X : Z
    //   1387: goto -> 1390
    //   1390: aload_0
    //   1391: invokevirtual q : ()V
    //   1394: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   1397: invokestatic valueOf : (I)Ljava/lang/String;
    //   1400: astore_1
    //   1401: aload_1
    //   1402: ldc '0'
    //   1404: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1407: ifeq -> 1420
    //   1410: aload_0
    //   1411: ldc_w 2131427427
    //   1414: invokevirtual getString : (I)Ljava/lang/String;
    //   1417: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1420: aload_1
    //   1421: ldc_w '1'
    //   1424: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1427: ifeq -> 1440
    //   1430: aload_0
    //   1431: ldc_w 2131427432
    //   1434: invokevirtual getString : (I)Ljava/lang/String;
    //   1437: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1440: aload_1
    //   1441: ldc_w '2'
    //   1444: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1447: ifeq -> 1460
    //   1450: aload_0
    //   1451: ldc_w 2131427430
    //   1454: invokevirtual getString : (I)Ljava/lang/String;
    //   1457: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1460: aload_1
    //   1461: ldc_w '3'
    //   1464: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1467: ifeq -> 1480
    //   1470: aload_0
    //   1471: ldc_w 2131427436
    //   1474: invokevirtual getString : (I)Ljava/lang/String;
    //   1477: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1480: aload_1
    //   1481: ldc_w '4'
    //   1484: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1487: ifeq -> 1500
    //   1490: aload_0
    //   1491: ldc_w 2131427437
    //   1494: invokevirtual getString : (I)Ljava/lang/String;
    //   1497: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1500: aload_1
    //   1501: ldc_w '5'
    //   1504: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1507: ifeq -> 1520
    //   1510: aload_0
    //   1511: ldc_w 2131427433
    //   1514: invokevirtual getString : (I)Ljava/lang/String;
    //   1517: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1520: aload_1
    //   1521: ldc_w '6'
    //   1524: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1527: ifeq -> 1540
    //   1530: aload_0
    //   1531: ldc_w 2131427438
    //   1534: invokevirtual getString : (I)Ljava/lang/String;
    //   1537: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1540: aload_1
    //   1541: ldc_w '7'
    //   1544: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1547: ifeq -> 1560
    //   1550: aload_0
    //   1551: ldc_w 2131427439
    //   1554: invokevirtual getString : (I)Ljava/lang/String;
    //   1557: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1560: aload_1
    //   1561: ldc_w '8'
    //   1564: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1567: ifeq -> 1580
    //   1570: aload_0
    //   1571: ldc_w 2131427429
    //   1574: invokevirtual getString : (I)Ljava/lang/String;
    //   1577: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1580: aload_1
    //   1581: ldc_w '9'
    //   1584: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1587: ifeq -> 1600
    //   1590: aload_0
    //   1591: ldc_w 2131427435
    //   1594: invokevirtual getString : (I)Ljava/lang/String;
    //   1597: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1600: aload_1
    //   1601: ldc_w '10'
    //   1604: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1607: ifeq -> 1620
    //   1610: aload_0
    //   1611: ldc_w 2131427431
    //   1614: invokevirtual getString : (I)Ljava/lang/String;
    //   1617: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1620: aload_1
    //   1621: ldc_w '11'
    //   1624: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1627: ifeq -> 1640
    //   1630: aload_0
    //   1631: ldc_w 2131427434
    //   1634: invokevirtual getString : (I)Ljava/lang/String;
    //   1637: putstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1640: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1643: ldc_w '50'
    //   1646: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1649: ifeq -> 1662
    //   1652: aload_0
    //   1653: ldc_w 2131427411
    //   1656: invokevirtual getString : (I)Ljava/lang/String;
    //   1659: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1662: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1665: ldc '0'
    //   1667: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1670: ifeq -> 1683
    //   1673: aload_0
    //   1674: ldc_w 2131427405
    //   1677: invokevirtual getString : (I)Ljava/lang/String;
    //   1680: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1683: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1686: ldc_w '1'
    //   1689: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1692: ifeq -> 1705
    //   1695: aload_0
    //   1696: ldc_w 2131427406
    //   1699: invokevirtual getString : (I)Ljava/lang/String;
    //   1702: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1705: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1708: ldc_w '2'
    //   1711: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1714: ifeq -> 1727
    //   1717: aload_0
    //   1718: ldc_w 2131427407
    //   1721: invokevirtual getString : (I)Ljava/lang/String;
    //   1724: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1727: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1730: ldc_w '3'
    //   1733: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1736: ifeq -> 1749
    //   1739: aload_0
    //   1740: ldc_w 2131427408
    //   1743: invokevirtual getString : (I)Ljava/lang/String;
    //   1746: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1749: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1752: ldc_w '4'
    //   1755: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1758: ifeq -> 1771
    //   1761: aload_0
    //   1762: ldc_w 2131427409
    //   1765: invokevirtual getString : (I)Ljava/lang/String;
    //   1768: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1771: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1774: ldc_w '5'
    //   1777: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1780: ifeq -> 1793
    //   1783: aload_0
    //   1784: ldc_w 2131427410
    //   1787: invokevirtual getString : (I)Ljava/lang/String;
    //   1790: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1793: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1796: ldc_w '6'
    //   1799: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1802: ifeq -> 1815
    //   1805: aload_0
    //   1806: ldc_w 2131427412
    //   1809: invokevirtual getString : (I)Ljava/lang/String;
    //   1812: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1815: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1818: ldc_w '7'
    //   1821: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1824: ifeq -> 1837
    //   1827: aload_0
    //   1828: ldc_w 2131427413
    //   1831: invokevirtual getString : (I)Ljava/lang/String;
    //   1834: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1837: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1840: ldc_w '8'
    //   1843: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1846: ifeq -> 1859
    //   1849: aload_0
    //   1850: ldc_w 2131427414
    //   1853: invokevirtual getString : (I)Ljava/lang/String;
    //   1856: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1859: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1862: ldc_w '9'
    //   1865: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1868: ifeq -> 1881
    //   1871: aload_0
    //   1872: ldc_w 2131427415
    //   1875: invokevirtual getString : (I)Ljava/lang/String;
    //   1878: putstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1881: aload_0
    //   1882: ldc_w 2131165447
    //   1885: invokevirtual findViewById : (I)Landroid/view/View;
    //   1888: checkcast android/widget/TextView
    //   1891: astore_1
    //   1892: aload_1
    //   1893: ifnull -> 1923
    //   1896: getstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1899: astore #8
    //   1901: aload #8
    //   1903: ifnull -> 1923
    //   1906: aload #8
    //   1908: ldc ''
    //   1910: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1913: ifne -> 1923
    //   1916: aload_1
    //   1917: getstatic com/dimcoms/checkers/MainActivity.J0 : Ljava/lang/String;
    //   1920: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1923: aload_0
    //   1924: ldc_w 2131165364
    //   1927: invokevirtual findViewById : (I)Landroid/view/View;
    //   1930: checkcast android/widget/TextView
    //   1933: astore_1
    //   1934: aload_1
    //   1935: ifnull -> 1965
    //   1938: getstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1941: astore #8
    //   1943: aload #8
    //   1945: ifnull -> 1965
    //   1948: aload #8
    //   1950: ldc ''
    //   1952: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1955: ifne -> 1965
    //   1958: aload_1
    //   1959: getstatic com/dimcoms/checkers/MainActivity.K0 : Ljava/lang/String;
    //   1962: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1965: iconst_1
    //   1966: putstatic com/dimcoms/checkers/MainActivity.Z : Z
    //   1969: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   1972: ldc_w '50'
    //   1975: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1978: ifeq -> 1985
    //   1981: iconst_0
    //   1982: putstatic com/dimcoms/checkers/MainActivity.Z : Z
    //   1985: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   1988: ifnonnull -> 2159
    //   1991: new android/media/SoundPool
    //   1994: dup
    //   1995: bipush #10
    //   1997: iconst_3
    //   1998: iconst_0
    //   1999: invokespecial <init> : (III)V
    //   2002: astore_1
    //   2003: aload_1
    //   2004: putstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2007: aload_1
    //   2008: aload_0
    //   2009: ldc_w 2131361801
    //   2012: iconst_1
    //   2013: invokevirtual load : (Landroid/content/Context;II)I
    //   2016: putstatic com/dimcoms/checkers/MainActivity.x0 : I
    //   2019: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2022: aload_0
    //   2023: ldc_w 2131361794
    //   2026: iconst_1
    //   2027: invokevirtual load : (Landroid/content/Context;II)I
    //   2030: putstatic com/dimcoms/checkers/MainActivity.y0 : I
    //   2033: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2036: aload_0
    //   2037: ldc_w 2131361795
    //   2040: iconst_1
    //   2041: invokevirtual load : (Landroid/content/Context;II)I
    //   2044: putstatic com/dimcoms/checkers/MainActivity.z0 : I
    //   2047: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2050: aload_0
    //   2051: ldc_w 2131361792
    //   2054: iconst_1
    //   2055: invokevirtual load : (Landroid/content/Context;II)I
    //   2058: putstatic com/dimcoms/checkers/MainActivity.A0 : I
    //   2061: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2064: aload_0
    //   2065: ldc_w 2131361802
    //   2068: iconst_1
    //   2069: invokevirtual load : (Landroid/content/Context;II)I
    //   2072: putstatic com/dimcoms/checkers/MainActivity.C0 : I
    //   2075: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2078: aload_0
    //   2079: ldc_w 2131361803
    //   2082: iconst_1
    //   2083: invokevirtual load : (Landroid/content/Context;II)I
    //   2086: putstatic com/dimcoms/checkers/MainActivity.D0 : I
    //   2089: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2092: aload_0
    //   2093: ldc_w 2131361799
    //   2096: iconst_1
    //   2097: invokevirtual load : (Landroid/content/Context;II)I
    //   2100: putstatic com/dimcoms/checkers/MainActivity.E0 : I
    //   2103: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2106: aload_0
    //   2107: ldc_w 2131361800
    //   2110: iconst_1
    //   2111: invokevirtual load : (Landroid/content/Context;II)I
    //   2114: putstatic com/dimcoms/checkers/MainActivity.B0 : I
    //   2117: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2120: aload_0
    //   2121: ldc_w 2131361796
    //   2124: iconst_1
    //   2125: invokevirtual load : (Landroid/content/Context;II)I
    //   2128: putstatic com/dimcoms/checkers/MainActivity.F0 : I
    //   2131: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2134: aload_0
    //   2135: ldc_w 2131361798
    //   2138: iconst_1
    //   2139: invokevirtual load : (Landroid/content/Context;II)I
    //   2142: putstatic com/dimcoms/checkers/MainActivity.G0 : I
    //   2145: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
    //   2148: aload_0
    //   2149: ldc_w 2131361793
    //   2152: iconst_1
    //   2153: invokevirtual load : (Landroid/content/Context;II)I
    //   2156: putstatic com/dimcoms/checkers/MainActivity.H0 : I
    //   2159: getstatic com/dimcoms/checkers/MainActivity.i0 : Z
    //   2162: ifne -> 2424
    //   2165: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2168: ifeq -> 2207
    //   2171: getstatic com/dimcoms/checkers/MainActivity.L : Lcom/google/android/gms/ads/interstitial/InterstitialAd;
    //   2174: astore_1
    //   2175: aload_1
    //   2176: ifnonnull -> 2186
    //   2179: aload_0
    //   2180: invokevirtual g : ()V
    //   2183: goto -> 2191
    //   2186: aload_0
    //   2187: aload_1
    //   2188: putfield d : Lcom/google/android/gms/ads/interstitial/InterstitialAd;
    //   2191: getstatic com/dimcoms/checkers/MainActivity.O : Lcom/google/android/gms/ads/rewarded/RewardedAd;
    //   2194: astore #8
    //   2196: aload #8
    //   2198: astore_1
    //   2199: aload #8
    //   2201: ifnonnull -> 2247
    //   2204: goto -> 2240
    //   2207: getstatic com/dimcoms/checkers/MainActivity.K : Lcom/google/android/gms/ads/interstitial/InterstitialAd;
    //   2210: astore_1
    //   2211: aload_1
    //   2212: ifnonnull -> 2222
    //   2215: aload_0
    //   2216: invokevirtual g : ()V
    //   2219: goto -> 2227
    //   2222: aload_0
    //   2223: aload_1
    //   2224: putfield d : Lcom/google/android/gms/ads/interstitial/InterstitialAd;
    //   2227: getstatic com/dimcoms/checkers/MainActivity.N : Lcom/google/android/gms/ads/rewarded/RewardedAd;
    //   2230: astore #8
    //   2232: aload #8
    //   2234: astore_1
    //   2235: aload #8
    //   2237: ifnonnull -> 2247
    //   2240: aload_0
    //   2241: invokevirtual h : ()V
    //   2244: goto -> 2252
    //   2247: aload_0
    //   2248: aload_1
    //   2249: putfield e : Lcom/google/android/gms/ads/rewarded/RewardedAd;
    //   2252: new com/google/android/gms/ads/AdView
    //   2255: dup
    //   2256: aload_0
    //   2257: invokespecial <init> : (Landroid/content/Context;)V
    //   2260: astore_1
    //   2261: aload_1
    //   2262: putstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
    //   2265: aload_1
    //   2266: getstatic com/google/android/gms/ads/AdSize.BANNER : Lcom/google/android/gms/ads/AdSize;
    //   2269: invokevirtual setAdSize : (Lcom/google/android/gms/ads/AdSize;)V
    //   2272: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
    //   2275: aload_0
    //   2276: getfield h : Ljava/lang/String;
    //   2279: invokevirtual setAdUnitId : (Ljava/lang/String;)V
    //   2282: new android/widget/RelativeLayout$LayoutParams
    //   2285: dup
    //   2286: bipush #-2
    //   2288: bipush #-2
    //   2290: invokespecial <init> : (II)V
    //   2293: astore_1
    //   2294: aload_1
    //   2295: bipush #14
    //   2297: iconst_m1
    //   2298: invokevirtual addRule : (II)V
    //   2301: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2304: ifeq -> 2317
    //   2307: aload_1
    //   2308: bipush #12
    //   2310: iconst_m1
    //   2311: invokevirtual addRule : (II)V
    //   2314: goto -> 2384
    //   2317: aload_0
    //   2318: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   2321: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   2324: getfield smallestScreenWidthDp : I
    //   2327: istore_2
    //   2328: iload_2
    //   2329: sipush #600
    //   2332: if_icmplt -> 2345
    //   2335: aload_0
    //   2336: bipush #27
    //   2338: invokestatic f : (Landroid/content/Context;I)I
    //   2341: istore_2
    //   2342: goto -> 2369
    //   2345: iload_2
    //   2346: sipush #360
    //   2349: if_icmplt -> 2362
    //   2352: aload_0
    //   2353: bipush #19
    //   2355: invokestatic f : (Landroid/content/Context;I)I
    //   2358: istore_2
    //   2359: goto -> 2369
    //   2362: aload_0
    //   2363: bipush #9
    //   2365: invokestatic f : (Landroid/content/Context;I)I
    //   2368: istore_2
    //   2369: aload_1
    //   2370: iconst_0
    //   2371: iload_2
    //   2372: iconst_0
    //   2373: iconst_0
    //   2374: invokevirtual setMargins : (IIII)V
    //   2377: aload_1
    //   2378: bipush #10
    //   2380: iconst_m1
    //   2381: invokevirtual addRule : (II)V
    //   2384: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
    //   2387: aload_1
    //   2388: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
    //   2391: getstatic com/dimcoms/checkers/MainActivity.S : Landroid/widget/RelativeLayout;
    //   2394: astore_1
    //   2395: aload_1
    //   2396: ifnull -> 2424
    //   2399: aload_1
    //   2400: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
    //   2403: invokevirtual addView : (Landroid/view/View;)V
    //   2406: new com/google/android/gms/ads/AdRequest$Builder
    //   2409: dup
    //   2410: invokespecial <init> : ()V
    //   2413: invokevirtual build : ()Lcom/google/android/gms/ads/AdRequest;
    //   2416: astore_1
    //   2417: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
    //   2420: aload_1
    //   2421: invokevirtual loadAd : (Lcom/google/android/gms/ads/AdRequest;)V
    //   2424: return
    //   2425: astore_1
    //   2426: goto -> 251
    //   2429: astore_1
    //   2430: goto -> 1390
    //   2433: astore_1
    //   2434: return
    // Exception table:
    //   from	to	target	type
    //   240	248	2425	java/lang/Error
    //   240	248	2425	java/lang/Exception
    //   1243	1297	2429	java/lang/Exception
    //   1307	1387	2429	java/lang/Exception
    //   2159	2175	2433	java/lang/NoClassDefFoundError
    //   2159	2175	2433	java/lang/Exception
    //   2179	2183	2433	java/lang/NoClassDefFoundError
    //   2179	2183	2433	java/lang/Exception
    //   2186	2191	2433	java/lang/NoClassDefFoundError
    //   2186	2191	2433	java/lang/Exception
    //   2191	2196	2433	java/lang/NoClassDefFoundError
    //   2191	2196	2433	java/lang/Exception
    //   2207	2211	2433	java/lang/NoClassDefFoundError
    //   2207	2211	2433	java/lang/Exception
    //   2215	2219	2433	java/lang/NoClassDefFoundError
    //   2215	2219	2433	java/lang/Exception
    //   2222	2227	2433	java/lang/NoClassDefFoundError
    //   2222	2227	2433	java/lang/Exception
    //   2227	2232	2433	java/lang/NoClassDefFoundError
    //   2227	2232	2433	java/lang/Exception
    //   2240	2244	2433	java/lang/NoClassDefFoundError
    //   2240	2244	2433	java/lang/Exception
    //   2247	2252	2433	java/lang/NoClassDefFoundError
    //   2247	2252	2433	java/lang/Exception
    //   2252	2314	2433	java/lang/NoClassDefFoundError
    //   2252	2314	2433	java/lang/Exception
    //   2317	2328	2433	java/lang/NoClassDefFoundError
    //   2317	2328	2433	java/lang/Exception
    //   2335	2342	2433	java/lang/NoClassDefFoundError
    //   2335	2342	2433	java/lang/Exception
    //   2352	2359	2433	java/lang/NoClassDefFoundError
    //   2352	2359	2433	java/lang/Exception
    //   2362	2369	2433	java/lang/NoClassDefFoundError
    //   2362	2369	2433	java/lang/Exception
    //   2369	2384	2433	java/lang/NoClassDefFoundError
    //   2369	2384	2433	java/lang/Exception
    //   2384	2395	2433	java/lang/NoClassDefFoundError
    //   2384	2395	2433	java/lang/Exception
    //   2399	2424	2433	java/lang/NoClassDefFoundError
    //   2399	2424	2433	java/lang/Exception
  }
  
  public final void onDestroy() {
    g0.a a1 = this.t;
    if (a1 != null && !a1.i) {
      a1.i = true;
      a1.l = false;
      synchronized (a1.n) {
        null.a = true;
      } 
    } 
    q q1 = this.u;
    if (q1 != null)
      q1.j = false; 
    SoundPool soundPool = I0;
    if (soundPool != null) {
      soundPool.release();
      I0 = null;
    } 
    super.onDestroy();
  }
  
  public final void onPause() {
    // Byte code:
    //   0: getstatic f0/a.a : Lf0/y;
    //   3: astore #5
    //   5: aload #5
    //   7: ifnull -> 24
    //   10: aload #5
    //   12: invokevirtual isShowing : ()Z
    //   15: ifeq -> 24
    //   18: getstatic f0/a.a : Lf0/y;
    //   21: invokevirtual dismiss : ()V
    //   24: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
    //   27: invokevirtual getClass : ()Ljava/lang/Class;
    //   30: pop
    //   31: getstatic f0/k.b : J
    //   34: lstore_2
    //   35: invokestatic currentTimeMillis : ()J
    //   38: getstatic f0/k.a : J
    //   41: lsub
    //   42: lload_2
    //   43: ladd
    //   44: lstore_2
    //   45: lload_2
    //   46: putstatic f0/k.b : J
    //   49: aload_0
    //   50: getfield c : Landroid/content/SharedPreferences$Editor;
    //   53: ldc_w 'checkers_gametime'
    //   56: lload_2
    //   57: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   62: pop
    //   63: getstatic com/dimcoms/checkers/MainActivity.H : Z
    //   66: istore #4
    //   68: aconst_null
    //   69: astore #6
    //   71: iload #4
    //   73: ifne -> 250
    //   76: getstatic com/dimcoms/checkers/MainActivity.r0 : Z
    //   79: ifne -> 250
    //   82: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   85: ifnull -> 250
    //   88: aload_0
    //   89: getfield B : Ljava/util/ArrayList;
    //   92: astore #5
    //   94: aload #5
    //   96: ifnull -> 250
    //   99: aload #5
    //   101: invokevirtual size : ()I
    //   104: getstatic com/dimcoms/checkers/MainActivity.k0 : I
    //   107: if_icmpne -> 250
    //   110: new java/io/ByteArrayOutputStream
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: astore #5
    //   119: new java/io/ObjectOutputStream
    //   122: dup
    //   123: aload #5
    //   125: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   128: astore #7
    //   130: aload #7
    //   132: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   135: invokevirtual writeObject : (Ljava/lang/Object;)V
    //   138: aload #7
    //   140: invokevirtual flush : ()V
    //   143: aload #5
    //   145: invokevirtual toByteArray : ()[B
    //   148: invokestatic b : ([B)Ljava/lang/String;
    //   151: astore #5
    //   153: new java/io/ByteArrayOutputStream
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore #7
    //   162: new java/io/ObjectOutputStream
    //   165: dup
    //   166: aload #7
    //   168: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   171: astore #8
    //   173: aload #8
    //   175: aload_0
    //   176: getfield B : Ljava/util/ArrayList;
    //   179: invokevirtual writeObject : (Ljava/lang/Object;)V
    //   182: aload #8
    //   184: invokevirtual flush : ()V
    //   187: aload #7
    //   189: invokevirtual toByteArray : ()[B
    //   192: invokestatic b : ([B)Ljava/lang/String;
    //   195: astore #7
    //   197: aload #7
    //   199: astore #6
    //   201: goto -> 207
    //   204: aconst_null
    //   205: astore #5
    //   207: aload_0
    //   208: getfield c : Landroid/content/SharedPreferences$Editor;
    //   211: ldc_w 'checkers_gameState'
    //   214: aload #5
    //   216: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   221: pop
    //   222: aload_0
    //   223: getfield c : Landroid/content/SharedPreferences$Editor;
    //   226: ldc_w 'checkers_bordHistory'
    //   229: aload #6
    //   231: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   236: pop
    //   237: aload_0
    //   238: getfield c : Landroid/content/SharedPreferences$Editor;
    //   241: astore #5
    //   243: getstatic com/dimcoms/checkers/MainActivity.k0 : I
    //   246: istore_1
    //   247: goto -> 286
    //   250: aload_0
    //   251: getfield c : Landroid/content/SharedPreferences$Editor;
    //   254: ldc_w 'checkers_gameState'
    //   257: aconst_null
    //   258: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   263: pop
    //   264: aload_0
    //   265: getfield c : Landroid/content/SharedPreferences$Editor;
    //   268: ldc_w 'checkers_bordHistory'
    //   271: aconst_null
    //   272: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   277: pop
    //   278: aload_0
    //   279: getfield c : Landroid/content/SharedPreferences$Editor;
    //   282: astore #5
    //   284: iconst_0
    //   285: istore_1
    //   286: aload #5
    //   288: ldc_w 'checkers_currentMove'
    //   291: iload_1
    //   292: invokeinterface putInt : (Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    //   297: pop
    //   298: aload_0
    //   299: getfield c : Landroid/content/SharedPreferences$Editor;
    //   302: invokeinterface commit : ()Z
    //   307: pop
    //   308: aload_0
    //   309: invokespecial onPause : ()V
    //   312: return
    //   313: astore #5
    //   315: goto -> 24
    //   318: astore #5
    //   320: goto -> 204
    //   323: astore #7
    //   325: goto -> 207
    // Exception table:
    //   from	to	target	type
    //   18	24	313	java/lang/Exception
    //   110	153	318	java/lang/Exception
    //   153	197	323	java/lang/Exception
  }
  
  public final void onRestoreInstanceState(Bundle paramBundle) {
    super.onRestoreInstanceState(paramBundle);
  }
  
  public final void onResume() {
    if (V0 && P0.equals("50") && I) {
      V0 = false;
      setRequestedOrientation(14);
    } 
    RelativeLayout relativeLayout = S;
    if (relativeLayout != null && !v0) {
      relativeLayout.setBackgroundColor(Color.argb(160, 0, 0, 0));
      S.setVisibility(8);
      AdView adView = M;
      if (adView != null && !i0)
        adView.setVisibility(0); 
    } 
    super.onResume();
    if (!u0 && !this.C)
      if (this.q) {
        l();
      } else {
        k();
      }  
    P.e = 1;
    f0.k.d(this.F, this.b, this.c);
    a0.a((Context)this, (RelativeLayout)findViewById(2131165436), I, Z ^ true);
    f();
    if (P0.equals("0"))
      K0 = getString(2131427405); 
    if (P0.equals("1"))
      K0 = getString(2131427406); 
    if (P0.equals("2"))
      K0 = getString(2131427407); 
    if (P0.equals("3"))
      K0 = getString(2131427408); 
    if (P0.equals("4"))
      K0 = getString(2131427409); 
    if (P0.equals("5"))
      K0 = getString(2131427410); 
    if (P0.equals("6"))
      K0 = getString(2131427412); 
    if (P0.equals("7"))
      K0 = getString(2131427413); 
    if (P0.equals("8"))
      K0 = getString(2131427414); 
    if (P0.equals("9"))
      K0 = getString(2131427415); 
    TextView textView = (TextView)findViewById(2131165364);
    if (textView != null) {
      String str = K0;
      if (str != null && !str.equals(""))
        textView.setText(K0); 
    } 
    r(false, false);
    if (this.C) {
      if (Z && (!o0 ? (k0 % 2 == 0) : (k0 % 2 != 0)))
        o(); 
      this.C = false;
    } 
    if (r0) {
      if (Z && (!o0 ? (k0 % 2 == 0) : (k0 % 2 != 0)))
        o(); 
      r0 = false;
    } 
    l0 = c.c.f();
    if (J) {
      i(true);
      Button button = (Button)findViewById(2131165230);
      Animation animation = AnimationUtils.loadAnimation((Context)this, 2130771968);
      if (button != null && animation != null) {
        button.startAnimation(animation);
        button.setBackgroundResource(2131099807);
        return;
      } 
    } else if (!v0 && (I || f0.k.l(this, R, Q))) {
      f0.a.b(this);
    } 
  }
  
  @SuppressLint({"NewApi"})
  public final void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    if (this.a >= 19 && paramBoolean)
      getWindow().getDecorView().setSystemUiVisibility(5894); 
  }
  
  public final void q() {
    switch (Integer.valueOf(P0).intValue()) {
      default:
        return;
      case 9:
        S0 = 5000;
        T0 = 100;
        this.x.j = false;
        return;
      case 8:
        S0 = 3000;
        T0 = 100;
        this.x.j = false;
        return;
      case 7:
        S0 = 2000;
        T0 = 8;
        this.x.j = false;
        return;
      case 6:
        S0 = 1400;
        T0 = 6;
        this.x.j = false;
        return;
      case 5:
        S0 = 800;
        T0 = 4;
        this.x.j = false;
        return;
      case 4:
        S0 = 600;
        T0 = 3;
        this.x.j = false;
        return;
      case 3:
        S0 = 400;
        T0 = 2;
        this.x.j = false;
        return;
      case 2:
        S0 = 100;
        T0 = 1;
        this.x.j = false;
        return;
      case 1:
        S0 = 50;
        T0 = 1;
        this.x.j = false;
        return;
      case 0:
        break;
    } 
    S0 = 30;
    T0 = 1;
    this.x.j = false;
  }
  
  public final void r(boolean paramBoolean1, boolean paramBoolean2) {
    Resources resources = getResources();
    if (resources != null) {
      String str1;
      String str2;
      if (I) {
        MySurfaceView2 mySurfaceView2;
        if (paramBoolean1) {
          mySurfaceView2 = P;
          str2 = resources.getString(2131427350);
        } else if (paramBoolean2 && n0) {
          mySurfaceView2 = P;
          str2 = getString(2131427388);
        } else if (this.w) {
          mySurfaceView2 = P;
          str2 = str2.getString(2131427482);
        } else {
          StringBuilder stringBuilder;
          if (q0) {
            mySurfaceView2 = P;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2.getString(2131427485));
            stringBuilder.append(": ");
            stringBuilder.append(g0.r.size());
            stringBuilder.append("    ");
            str2 = str2.getString(2131427331);
          } else {
            mySurfaceView2 = P;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2.getString(2131427331));
            stringBuilder.append(": ");
            stringBuilder.append(g0.r.size());
            stringBuilder.append("    ");
            str2 = str2.getString(2131427485);
          } 
          stringBuilder.append(str2);
          stringBuilder.append(": ");
          stringBuilder.append(g0.l.size());
          str2 = stringBuilder.toString();
        } 
        mySurfaceView2.u = f0.k.k(H(str2));
        return;
      } 
      TextView textView = (TextView)findViewById(2131165430);
      if (paramBoolean1) {
        str1 = str2.getString(2131427350);
      } else if (paramBoolean2 && n0) {
        str1 = str2.getString(2131427388);
      } else if (this.w) {
        str1 = str2.getString(2131427482);
      } else {
        StringBuilder stringBuilder;
        if (q0) {
          stringBuilder = new StringBuilder();
          stringBuilder.append(str2.getString(2131427485));
          stringBuilder.append(": ");
          stringBuilder.append(g0.r.size());
          stringBuilder.append("    ");
          str2 = str2.getString(2131427331);
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append(str2.getString(2131427331));
          stringBuilder.append(": ");
          stringBuilder.append(g0.r.size());
          stringBuilder.append("    ");
          str2 = str2.getString(2131427485);
        } 
        stringBuilder.append(str2);
        stringBuilder.append(": ");
        stringBuilder.append(g0.l.size());
        str1 = stringBuilder.toString();
      } 
      if (textView != null && str1 != null)
        runOnUiThread(new a(textView, str1)); 
    } 
  }
  
  public final void s(boolean paramBoolean) {
    byte b1 = 0;
    if (paramBoolean) {
      r(true, false);
      d(R0);
      return;
    } 
    if (b0) {
      r(false, true);
      if (m0) {
        ArrayList<v> arrayList = d0;
        if (arrayList != null) {
          int k = arrayList.size();
          for (int j = 0; j < k; j = m + 1) {
            int m = ((v)arrayList.get(j)).k;
            byte b2 = ((v)arrayList.get(j)).l;
            w w1 = new w();
            w1.a(m, b2);
            r r1 = this.x;
            ArrayList<w> arrayList1 = e0;
            r1.getClass();
            m = j;
            if (r.r(w1, arrayList1, false) == 1) {
              arrayList.remove(j);
              k = arrayList.size();
              m = j - 1;
            } 
          } 
          k = arrayList.size();
          if (k == 1 && n0) {
            a.a = this;
            a.i.a(((v)arrayList.get(0)).k, ((v)arrayList.get(0)).l);
            MySurfaceView2.a0 = true;
            return;
          } 
          P.getClass();
          MySurfaceView2.d0 = true;
          MySurfaceView2.M.setColor(Color.argb(255, 249, 238, 77));
          for (int i = b1; i < k; i++) {
            v v = arrayList.get(i);
            g0.d d1 = this.v;
            byte b2 = v.k;
            b1 = v.l;
            d1.c[b2][b1] = true;
            MySurfaceView2.W = true;
          } 
        } 
      } 
    } else {
      r(false, false);
    } 
  }
  
  public final void t() {
    // Byte code:
    //   0: iconst_1
    //   1: putstatic com/dimcoms/checkers/MainActivity.O0 : Z
    //   4: iconst_0
    //   5: putstatic com/dimcoms/checkers/MainActivity.W0 : Z
    //   8: iconst_0
    //   9: putstatic com/dimcoms/checkers/MainActivity.J : Z
    //   12: aload_0
    //   13: invokevirtual G : ()V
    //   16: aload_0
    //   17: getfield x : Lg0/r;
    //   20: invokevirtual k : ()Lg0/b;
    //   23: putstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   26: aload_0
    //   27: getfield B : Ljava/util/ArrayList;
    //   30: invokevirtual clear : ()V
    //   33: iconst_0
    //   34: putstatic com/dimcoms/checkers/MainActivity.k0 : I
    //   37: aload_0
    //   38: new g0/d
    //   41: dup
    //   42: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   45: invokespecial <init> : (Lg0/b;)V
    //   48: putfield v : Lg0/d;
    //   51: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   54: invokevirtual clear : ()V
    //   57: aload_0
    //   58: invokevirtual m : ()V
    //   61: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
    //   64: astore #7
    //   66: aload #7
    //   68: invokevirtual getClass : ()Ljava/lang/Class;
    //   71: pop
    //   72: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   75: ifeq -> 112
    //   78: aload #7
    //   80: aload #7
    //   82: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   85: ldc_w 2131099657
    //   88: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   91: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   94: putfield r : Landroid/graphics/Bitmap;
    //   97: aload #7
    //   99: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   102: ldc_w 2131099800
    //   105: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   108: astore_3
    //   109: goto -> 143
    //   112: aload #7
    //   114: aload #7
    //   116: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   119: ldc_w 2131099800
    //   122: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   125: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   128: putfield r : Landroid/graphics/Bitmap;
    //   131: aload #7
    //   133: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   136: ldc_w 2131099657
    //   139: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   142: astore_3
    //   143: aload #7
    //   145: aload_3
    //   146: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   149: putfield t : Landroid/graphics/Bitmap;
    //   152: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
    //   155: ldc_w '50'
    //   158: invokevirtual equals : (Ljava/lang/Object;)Z
    //   161: ifeq -> 235
    //   164: new android/graphics/Matrix
    //   167: dup
    //   168: invokespecial <init> : ()V
    //   171: astore_3
    //   172: aload_3
    //   173: ldc_w 180.0
    //   176: aload #7
    //   178: getfield r : Landroid/graphics/Bitmap;
    //   181: invokevirtual getWidth : ()I
    //   184: iconst_2
    //   185: idiv
    //   186: i2f
    //   187: aload #7
    //   189: getfield r : Landroid/graphics/Bitmap;
    //   192: invokevirtual getHeight : ()I
    //   195: iconst_2
    //   196: idiv
    //   197: i2f
    //   198: invokevirtual setRotate : (FFF)V
    //   201: aload #7
    //   203: getfield r : Landroid/graphics/Bitmap;
    //   206: astore #4
    //   208: aload #7
    //   210: aload #4
    //   212: iconst_0
    //   213: iconst_0
    //   214: aload #4
    //   216: invokevirtual getWidth : ()I
    //   219: aload #7
    //   221: getfield r : Landroid/graphics/Bitmap;
    //   224: invokevirtual getHeight : ()I
    //   227: aload_3
    //   228: iconst_0
    //   229: invokestatic createBitmap : (Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;
    //   232: putfield r : Landroid/graphics/Bitmap;
    //   235: aload #7
    //   237: getfield r : Landroid/graphics/Bitmap;
    //   240: astore_3
    //   241: aload_3
    //   242: ifnull -> 254
    //   245: aload #7
    //   247: aload_3
    //   248: invokestatic g : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   251: putfield r : Landroid/graphics/Bitmap;
    //   254: aload #7
    //   256: getfield t : Landroid/graphics/Bitmap;
    //   259: astore_3
    //   260: aload_3
    //   261: ifnull -> 273
    //   264: aload #7
    //   266: aload_3
    //   267: invokestatic g : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   270: putfield t : Landroid/graphics/Bitmap;
    //   273: ldc_w 'Theme.xml'
    //   276: invokestatic c : (Ljava/lang/String;)Z
    //   279: ifeq -> 2917
    //   282: ldc_w 'Theme.xml'
    //   285: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   288: astore #6
    //   290: aload #6
    //   292: ldc '0'
    //   294: invokevirtual equals : (Ljava/lang/Object;)Z
    //   297: ifeq -> 303
    //   300: goto -> 2917
    //   303: aload #6
    //   305: ldc_w '1'
    //   308: invokevirtual equals : (Ljava/lang/Object;)Z
    //   311: istore_2
    //   312: ldc_w 'white_man_3d.png'
    //   315: astore_3
    //   316: ldc_w 'black_man_3d.png'
    //   319: astore #4
    //   321: ldc_w 'board800x800_tr.jpg'
    //   324: astore #5
    //   326: iload_2
    //   327: ifeq -> 690
    //   330: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   333: bipush #8
    //   335: if_icmpne -> 401
    //   338: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   341: istore_1
    //   342: iload_1
    //   343: iconst_4
    //   344: if_icmpeq -> 386
    //   347: iload_1
    //   348: iconst_5
    //   349: if_icmpne -> 355
    //   352: goto -> 386
    //   355: iload_1
    //   356: bipush #7
    //   358: if_icmpne -> 371
    //   361: aload #7
    //   363: invokevirtual getContext : ()Landroid/content/Context;
    //   366: astore #6
    //   368: goto -> 413
    //   371: aload #7
    //   373: invokevirtual getContext : ()Landroid/content/Context;
    //   376: astore #6
    //   378: ldc_w 'board800x800.jpg'
    //   381: astore #5
    //   383: goto -> 413
    //   386: aload #7
    //   388: invokevirtual getContext : ()Landroid/content/Context;
    //   391: astore #6
    //   393: ldc_w 'board800x800_90.jpg'
    //   396: astore #5
    //   398: goto -> 413
    //   401: aload #7
    //   403: invokevirtual getContext : ()Landroid/content/Context;
    //   406: astore #6
    //   408: ldc_w 'board10.jpg'
    //   411: astore #5
    //   413: aload #6
    //   415: aload #5
    //   417: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   420: astore #5
    //   422: aload #7
    //   424: aload #5
    //   426: putfield p : Landroid/graphics/Bitmap;
    //   429: aload #5
    //   431: ifnull -> 473
    //   434: aload #7
    //   436: getfield D : I
    //   439: aload #5
    //   441: invokevirtual getWidth : ()I
    //   444: if_icmpge -> 473
    //   447: aload #7
    //   449: getfield p : Landroid/graphics/Bitmap;
    //   452: astore #5
    //   454: aload #7
    //   456: getfield D : I
    //   459: istore_1
    //   460: aload #7
    //   462: aload #5
    //   464: iload_1
    //   465: iload_1
    //   466: iconst_1
    //   467: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   470: putfield p : Landroid/graphics/Bitmap;
    //   473: aload #7
    //   475: invokevirtual a : ()V
    //   478: aload #7
    //   480: aload #7
    //   482: getfield p : Landroid/graphics/Bitmap;
    //   485: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   488: putfield p : Landroid/graphics/Bitmap;
    //   491: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   494: ifeq -> 556
    //   497: aload #7
    //   499: getfield E : Z
    //   502: ifne -> 556
    //   505: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   508: ifeq -> 527
    //   511: aload #7
    //   513: invokevirtual getContext : ()Landroid/content/Context;
    //   516: ldc_w 'black_man_3d.png'
    //   519: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   522: astore #5
    //   524: goto -> 540
    //   527: aload #7
    //   529: invokevirtual getContext : ()Landroid/content/Context;
    //   532: ldc_w 'white_man_3d.png'
    //   535: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   538: astore #5
    //   540: aload #7
    //   542: aload #5
    //   544: putfield q : Landroid/graphics/Bitmap;
    //   547: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   550: ifeq -> 623
    //   553: goto -> 605
    //   556: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   559: ifeq -> 577
    //   562: aload #7
    //   564: invokevirtual getContext : ()Landroid/content/Context;
    //   567: ldc_w 'black_man.png'
    //   570: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   573: astore_3
    //   574: goto -> 589
    //   577: aload #7
    //   579: invokevirtual getContext : ()Landroid/content/Context;
    //   582: ldc_w 'white_man.png'
    //   585: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   588: astore_3
    //   589: aload #7
    //   591: aload_3
    //   592: putfield q : Landroid/graphics/Bitmap;
    //   595: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   598: ifeq -> 618
    //   601: ldc_w 'white_man.png'
    //   604: astore_3
    //   605: aload #7
    //   607: invokevirtual getContext : ()Landroid/content/Context;
    //   610: aload_3
    //   611: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   614: astore_3
    //   615: goto -> 634
    //   618: ldc_w 'black_man.png'
    //   621: astore #4
    //   623: aload #7
    //   625: invokevirtual getContext : ()Landroid/content/Context;
    //   628: aload #4
    //   630: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   633: astore_3
    //   634: aload #7
    //   636: aload_3
    //   637: putfield s : Landroid/graphics/Bitmap;
    //   640: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   643: bipush #120
    //   645: bipush #23
    //   647: sipush #149
    //   650: bipush #16
    //   652: invokestatic argb : (IIII)I
    //   655: invokevirtual setColor : (I)V
    //   658: aload #7
    //   660: getfield p : Landroid/graphics/Bitmap;
    //   663: ifnull -> 682
    //   666: aload #7
    //   668: getfield q : Landroid/graphics/Bitmap;
    //   671: ifnull -> 682
    //   674: aload #7
    //   676: getfield s : Landroid/graphics/Bitmap;
    //   679: ifnonnull -> 2922
    //   682: aload #7
    //   684: invokevirtual j : ()V
    //   687: goto -> 2922
    //   690: aload #6
    //   692: ldc_w '2'
    //   695: invokevirtual equals : (Ljava/lang/Object;)Z
    //   698: ifeq -> 1061
    //   701: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   704: bipush #8
    //   706: if_icmpne -> 772
    //   709: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   712: istore_1
    //   713: iload_1
    //   714: iconst_4
    //   715: if_icmpeq -> 757
    //   718: iload_1
    //   719: iconst_5
    //   720: if_icmpne -> 726
    //   723: goto -> 757
    //   726: iload_1
    //   727: bipush #7
    //   729: if_icmpne -> 742
    //   732: aload #7
    //   734: invokevirtual getContext : ()Landroid/content/Context;
    //   737: astore #6
    //   739: goto -> 784
    //   742: aload #7
    //   744: invokevirtual getContext : ()Landroid/content/Context;
    //   747: astore #6
    //   749: ldc_w 'board800x800.jpg'
    //   752: astore #5
    //   754: goto -> 784
    //   757: aload #7
    //   759: invokevirtual getContext : ()Landroid/content/Context;
    //   762: astore #6
    //   764: ldc_w 'board800x800_90.jpg'
    //   767: astore #5
    //   769: goto -> 784
    //   772: aload #7
    //   774: invokevirtual getContext : ()Landroid/content/Context;
    //   777: astore #6
    //   779: ldc_w 'board10.jpg'
    //   782: astore #5
    //   784: aload #6
    //   786: aload #5
    //   788: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   791: astore #5
    //   793: aload #7
    //   795: aload #5
    //   797: putfield p : Landroid/graphics/Bitmap;
    //   800: aload #5
    //   802: ifnull -> 844
    //   805: aload #7
    //   807: getfield D : I
    //   810: aload #5
    //   812: invokevirtual getWidth : ()I
    //   815: if_icmpge -> 844
    //   818: aload #7
    //   820: getfield p : Landroid/graphics/Bitmap;
    //   823: astore #5
    //   825: aload #7
    //   827: getfield D : I
    //   830: istore_1
    //   831: aload #7
    //   833: aload #5
    //   835: iload_1
    //   836: iload_1
    //   837: iconst_1
    //   838: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   841: putfield p : Landroid/graphics/Bitmap;
    //   844: aload #7
    //   846: invokevirtual a : ()V
    //   849: aload #7
    //   851: aload #7
    //   853: getfield p : Landroid/graphics/Bitmap;
    //   856: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   859: putfield p : Landroid/graphics/Bitmap;
    //   862: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   865: ifeq -> 927
    //   868: aload #7
    //   870: getfield E : Z
    //   873: ifne -> 927
    //   876: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   879: ifeq -> 898
    //   882: aload #7
    //   884: invokevirtual getContext : ()Landroid/content/Context;
    //   887: ldc_w 'black_man_3d.png'
    //   890: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   893: astore #5
    //   895: goto -> 911
    //   898: aload #7
    //   900: invokevirtual getContext : ()Landroid/content/Context;
    //   903: ldc_w 'white_man_3d.png'
    //   906: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   909: astore #5
    //   911: aload #7
    //   913: aload #5
    //   915: putfield q : Landroid/graphics/Bitmap;
    //   918: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   921: ifeq -> 994
    //   924: goto -> 976
    //   927: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   930: ifeq -> 948
    //   933: aload #7
    //   935: invokevirtual getContext : ()Landroid/content/Context;
    //   938: ldc_w 'black_man.png'
    //   941: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   944: astore_3
    //   945: goto -> 960
    //   948: aload #7
    //   950: invokevirtual getContext : ()Landroid/content/Context;
    //   953: ldc_w 'white_man.png'
    //   956: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   959: astore_3
    //   960: aload #7
    //   962: aload_3
    //   963: putfield q : Landroid/graphics/Bitmap;
    //   966: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   969: ifeq -> 989
    //   972: ldc_w 'white_man.png'
    //   975: astore_3
    //   976: aload #7
    //   978: invokevirtual getContext : ()Landroid/content/Context;
    //   981: aload_3
    //   982: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   985: astore_3
    //   986: goto -> 1005
    //   989: ldc_w 'black_man.png'
    //   992: astore #4
    //   994: aload #7
    //   996: invokevirtual getContext : ()Landroid/content/Context;
    //   999: aload #4
    //   1001: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1004: astore_3
    //   1005: aload #7
    //   1007: aload_3
    //   1008: putfield s : Landroid/graphics/Bitmap;
    //   1011: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   1014: bipush #120
    //   1016: bipush #23
    //   1018: sipush #149
    //   1021: bipush #16
    //   1023: invokestatic argb : (IIII)I
    //   1026: invokevirtual setColor : (I)V
    //   1029: aload #7
    //   1031: getfield p : Landroid/graphics/Bitmap;
    //   1034: ifnull -> 1053
    //   1037: aload #7
    //   1039: getfield q : Landroid/graphics/Bitmap;
    //   1042: ifnull -> 1053
    //   1045: aload #7
    //   1047: getfield s : Landroid/graphics/Bitmap;
    //   1050: ifnonnull -> 2922
    //   1053: aload #7
    //   1055: invokevirtual j : ()V
    //   1058: goto -> 2922
    //   1061: aload #6
    //   1063: ldc_w '3'
    //   1066: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1069: ifeq -> 1432
    //   1072: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   1075: bipush #8
    //   1077: if_icmpne -> 1143
    //   1080: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   1083: istore_1
    //   1084: iload_1
    //   1085: iconst_4
    //   1086: if_icmpeq -> 1128
    //   1089: iload_1
    //   1090: iconst_5
    //   1091: if_icmpne -> 1097
    //   1094: goto -> 1128
    //   1097: iload_1
    //   1098: bipush #7
    //   1100: if_icmpne -> 1113
    //   1103: aload #7
    //   1105: invokevirtual getContext : ()Landroid/content/Context;
    //   1108: astore #6
    //   1110: goto -> 1155
    //   1113: aload #7
    //   1115: invokevirtual getContext : ()Landroid/content/Context;
    //   1118: astore #6
    //   1120: ldc_w 'board800x800.jpg'
    //   1123: astore #5
    //   1125: goto -> 1155
    //   1128: aload #7
    //   1130: invokevirtual getContext : ()Landroid/content/Context;
    //   1133: astore #6
    //   1135: ldc_w 'board800x800_90.jpg'
    //   1138: astore #5
    //   1140: goto -> 1155
    //   1143: aload #7
    //   1145: invokevirtual getContext : ()Landroid/content/Context;
    //   1148: astore #6
    //   1150: ldc_w 'board10.jpg'
    //   1153: astore #5
    //   1155: aload #6
    //   1157: aload #5
    //   1159: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1162: astore #5
    //   1164: aload #7
    //   1166: aload #5
    //   1168: putfield p : Landroid/graphics/Bitmap;
    //   1171: aload #5
    //   1173: ifnull -> 1215
    //   1176: aload #7
    //   1178: getfield D : I
    //   1181: aload #5
    //   1183: invokevirtual getWidth : ()I
    //   1186: if_icmpge -> 1215
    //   1189: aload #7
    //   1191: getfield p : Landroid/graphics/Bitmap;
    //   1194: astore #5
    //   1196: aload #7
    //   1198: getfield D : I
    //   1201: istore_1
    //   1202: aload #7
    //   1204: aload #5
    //   1206: iload_1
    //   1207: iload_1
    //   1208: iconst_1
    //   1209: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   1212: putfield p : Landroid/graphics/Bitmap;
    //   1215: aload #7
    //   1217: invokevirtual a : ()V
    //   1220: aload #7
    //   1222: aload #7
    //   1224: getfield p : Landroid/graphics/Bitmap;
    //   1227: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   1230: putfield p : Landroid/graphics/Bitmap;
    //   1233: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1236: ifeq -> 1298
    //   1239: aload #7
    //   1241: getfield E : Z
    //   1244: ifne -> 1298
    //   1247: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1250: ifeq -> 1269
    //   1253: aload #7
    //   1255: invokevirtual getContext : ()Landroid/content/Context;
    //   1258: ldc_w 'black_man_3d.png'
    //   1261: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1264: astore #5
    //   1266: goto -> 1282
    //   1269: aload #7
    //   1271: invokevirtual getContext : ()Landroid/content/Context;
    //   1274: ldc_w 'white_man_3d.png'
    //   1277: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1280: astore #5
    //   1282: aload #7
    //   1284: aload #5
    //   1286: putfield q : Landroid/graphics/Bitmap;
    //   1289: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1292: ifeq -> 1365
    //   1295: goto -> 1347
    //   1298: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1301: ifeq -> 1319
    //   1304: aload #7
    //   1306: invokevirtual getContext : ()Landroid/content/Context;
    //   1309: ldc_w 'black_man.png'
    //   1312: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1315: astore_3
    //   1316: goto -> 1331
    //   1319: aload #7
    //   1321: invokevirtual getContext : ()Landroid/content/Context;
    //   1324: ldc_w 'white_man.png'
    //   1327: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1330: astore_3
    //   1331: aload #7
    //   1333: aload_3
    //   1334: putfield q : Landroid/graphics/Bitmap;
    //   1337: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1340: ifeq -> 1360
    //   1343: ldc_w 'white_man.png'
    //   1346: astore_3
    //   1347: aload #7
    //   1349: invokevirtual getContext : ()Landroid/content/Context;
    //   1352: aload_3
    //   1353: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1356: astore_3
    //   1357: goto -> 1376
    //   1360: ldc_w 'black_man.png'
    //   1363: astore #4
    //   1365: aload #7
    //   1367: invokevirtual getContext : ()Landroid/content/Context;
    //   1370: aload #4
    //   1372: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1375: astore_3
    //   1376: aload #7
    //   1378: aload_3
    //   1379: putfield s : Landroid/graphics/Bitmap;
    //   1382: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   1385: bipush #120
    //   1387: bipush #23
    //   1389: sipush #149
    //   1392: bipush #16
    //   1394: invokestatic argb : (IIII)I
    //   1397: invokevirtual setColor : (I)V
    //   1400: aload #7
    //   1402: getfield p : Landroid/graphics/Bitmap;
    //   1405: ifnull -> 1424
    //   1408: aload #7
    //   1410: getfield q : Landroid/graphics/Bitmap;
    //   1413: ifnull -> 1424
    //   1416: aload #7
    //   1418: getfield s : Landroid/graphics/Bitmap;
    //   1421: ifnonnull -> 2922
    //   1424: aload #7
    //   1426: invokevirtual j : ()V
    //   1429: goto -> 2922
    //   1432: aload #6
    //   1434: ldc_w '4'
    //   1437: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1440: ifeq -> 1803
    //   1443: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   1446: bipush #8
    //   1448: if_icmpne -> 1514
    //   1451: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   1454: istore_1
    //   1455: iload_1
    //   1456: iconst_4
    //   1457: if_icmpeq -> 1499
    //   1460: iload_1
    //   1461: iconst_5
    //   1462: if_icmpne -> 1468
    //   1465: goto -> 1499
    //   1468: iload_1
    //   1469: bipush #7
    //   1471: if_icmpne -> 1484
    //   1474: aload #7
    //   1476: invokevirtual getContext : ()Landroid/content/Context;
    //   1479: astore #6
    //   1481: goto -> 1526
    //   1484: aload #7
    //   1486: invokevirtual getContext : ()Landroid/content/Context;
    //   1489: astore #6
    //   1491: ldc_w 'board800x800.jpg'
    //   1494: astore #5
    //   1496: goto -> 1526
    //   1499: aload #7
    //   1501: invokevirtual getContext : ()Landroid/content/Context;
    //   1504: astore #6
    //   1506: ldc_w 'board800x800_90.jpg'
    //   1509: astore #5
    //   1511: goto -> 1526
    //   1514: aload #7
    //   1516: invokevirtual getContext : ()Landroid/content/Context;
    //   1519: astore #6
    //   1521: ldc_w 'board10.jpg'
    //   1524: astore #5
    //   1526: aload #6
    //   1528: aload #5
    //   1530: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1533: astore #5
    //   1535: aload #7
    //   1537: aload #5
    //   1539: putfield p : Landroid/graphics/Bitmap;
    //   1542: aload #5
    //   1544: ifnull -> 1586
    //   1547: aload #7
    //   1549: getfield D : I
    //   1552: aload #5
    //   1554: invokevirtual getWidth : ()I
    //   1557: if_icmpge -> 1586
    //   1560: aload #7
    //   1562: getfield p : Landroid/graphics/Bitmap;
    //   1565: astore #5
    //   1567: aload #7
    //   1569: getfield D : I
    //   1572: istore_1
    //   1573: aload #7
    //   1575: aload #5
    //   1577: iload_1
    //   1578: iload_1
    //   1579: iconst_1
    //   1580: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   1583: putfield p : Landroid/graphics/Bitmap;
    //   1586: aload #7
    //   1588: invokevirtual a : ()V
    //   1591: aload #7
    //   1593: aload #7
    //   1595: getfield p : Landroid/graphics/Bitmap;
    //   1598: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   1601: putfield p : Landroid/graphics/Bitmap;
    //   1604: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1607: ifeq -> 1669
    //   1610: aload #7
    //   1612: getfield E : Z
    //   1615: ifne -> 1669
    //   1618: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1621: ifeq -> 1640
    //   1624: aload #7
    //   1626: invokevirtual getContext : ()Landroid/content/Context;
    //   1629: ldc_w 'black_man_3d.png'
    //   1632: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1635: astore #5
    //   1637: goto -> 1653
    //   1640: aload #7
    //   1642: invokevirtual getContext : ()Landroid/content/Context;
    //   1645: ldc_w 'white_man_3d.png'
    //   1648: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1651: astore #5
    //   1653: aload #7
    //   1655: aload #5
    //   1657: putfield q : Landroid/graphics/Bitmap;
    //   1660: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1663: ifeq -> 1736
    //   1666: goto -> 1718
    //   1669: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1672: ifeq -> 1690
    //   1675: aload #7
    //   1677: invokevirtual getContext : ()Landroid/content/Context;
    //   1680: ldc_w 'black_man.png'
    //   1683: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1686: astore_3
    //   1687: goto -> 1702
    //   1690: aload #7
    //   1692: invokevirtual getContext : ()Landroid/content/Context;
    //   1695: ldc_w 'white_man.png'
    //   1698: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1701: astore_3
    //   1702: aload #7
    //   1704: aload_3
    //   1705: putfield q : Landroid/graphics/Bitmap;
    //   1708: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1711: ifeq -> 1731
    //   1714: ldc_w 'white_man.png'
    //   1717: astore_3
    //   1718: aload #7
    //   1720: invokevirtual getContext : ()Landroid/content/Context;
    //   1723: aload_3
    //   1724: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1727: astore_3
    //   1728: goto -> 1747
    //   1731: ldc_w 'black_man.png'
    //   1734: astore #4
    //   1736: aload #7
    //   1738: invokevirtual getContext : ()Landroid/content/Context;
    //   1741: aload #4
    //   1743: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1746: astore_3
    //   1747: aload #7
    //   1749: aload_3
    //   1750: putfield s : Landroid/graphics/Bitmap;
    //   1753: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   1756: bipush #120
    //   1758: bipush #23
    //   1760: sipush #149
    //   1763: bipush #16
    //   1765: invokestatic argb : (IIII)I
    //   1768: invokevirtual setColor : (I)V
    //   1771: aload #7
    //   1773: getfield p : Landroid/graphics/Bitmap;
    //   1776: ifnull -> 1795
    //   1779: aload #7
    //   1781: getfield q : Landroid/graphics/Bitmap;
    //   1784: ifnull -> 1795
    //   1787: aload #7
    //   1789: getfield s : Landroid/graphics/Bitmap;
    //   1792: ifnonnull -> 2922
    //   1795: aload #7
    //   1797: invokevirtual j : ()V
    //   1800: goto -> 2922
    //   1803: aload #6
    //   1805: ldc_w '5'
    //   1808: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1811: ifeq -> 2174
    //   1814: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   1817: bipush #8
    //   1819: if_icmpne -> 1885
    //   1822: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   1825: istore_1
    //   1826: iload_1
    //   1827: iconst_4
    //   1828: if_icmpeq -> 1870
    //   1831: iload_1
    //   1832: iconst_5
    //   1833: if_icmpne -> 1839
    //   1836: goto -> 1870
    //   1839: iload_1
    //   1840: bipush #7
    //   1842: if_icmpne -> 1855
    //   1845: aload #7
    //   1847: invokevirtual getContext : ()Landroid/content/Context;
    //   1850: astore #6
    //   1852: goto -> 1897
    //   1855: aload #7
    //   1857: invokevirtual getContext : ()Landroid/content/Context;
    //   1860: astore #6
    //   1862: ldc_w 'board800x800.jpg'
    //   1865: astore #5
    //   1867: goto -> 1897
    //   1870: aload #7
    //   1872: invokevirtual getContext : ()Landroid/content/Context;
    //   1875: astore #6
    //   1877: ldc_w 'board800x800_90.jpg'
    //   1880: astore #5
    //   1882: goto -> 1897
    //   1885: aload #7
    //   1887: invokevirtual getContext : ()Landroid/content/Context;
    //   1890: astore #6
    //   1892: ldc_w 'board10.jpg'
    //   1895: astore #5
    //   1897: aload #6
    //   1899: aload #5
    //   1901: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   1904: astore #5
    //   1906: aload #7
    //   1908: aload #5
    //   1910: putfield p : Landroid/graphics/Bitmap;
    //   1913: aload #5
    //   1915: ifnull -> 1957
    //   1918: aload #7
    //   1920: getfield D : I
    //   1923: aload #5
    //   1925: invokevirtual getWidth : ()I
    //   1928: if_icmpge -> 1957
    //   1931: aload #7
    //   1933: getfield p : Landroid/graphics/Bitmap;
    //   1936: astore #5
    //   1938: aload #7
    //   1940: getfield D : I
    //   1943: istore_1
    //   1944: aload #7
    //   1946: aload #5
    //   1948: iload_1
    //   1949: iload_1
    //   1950: iconst_1
    //   1951: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   1954: putfield p : Landroid/graphics/Bitmap;
    //   1957: aload #7
    //   1959: invokevirtual a : ()V
    //   1962: aload #7
    //   1964: aload #7
    //   1966: getfield p : Landroid/graphics/Bitmap;
    //   1969: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   1972: putfield p : Landroid/graphics/Bitmap;
    //   1975: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1978: ifeq -> 2040
    //   1981: aload #7
    //   1983: getfield E : Z
    //   1986: ifne -> 2040
    //   1989: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   1992: ifeq -> 2011
    //   1995: aload #7
    //   1997: invokevirtual getContext : ()Landroid/content/Context;
    //   2000: ldc_w 'black_man_3d.png'
    //   2003: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2006: astore #5
    //   2008: goto -> 2024
    //   2011: aload #7
    //   2013: invokevirtual getContext : ()Landroid/content/Context;
    //   2016: ldc_w 'white_man_3d.png'
    //   2019: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2022: astore #5
    //   2024: aload #7
    //   2026: aload #5
    //   2028: putfield q : Landroid/graphics/Bitmap;
    //   2031: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2034: ifeq -> 2107
    //   2037: goto -> 2089
    //   2040: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2043: ifeq -> 2061
    //   2046: aload #7
    //   2048: invokevirtual getContext : ()Landroid/content/Context;
    //   2051: ldc_w 'black_man.png'
    //   2054: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2057: astore_3
    //   2058: goto -> 2073
    //   2061: aload #7
    //   2063: invokevirtual getContext : ()Landroid/content/Context;
    //   2066: ldc_w 'white_man.png'
    //   2069: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2072: astore_3
    //   2073: aload #7
    //   2075: aload_3
    //   2076: putfield q : Landroid/graphics/Bitmap;
    //   2079: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2082: ifeq -> 2102
    //   2085: ldc_w 'white_man.png'
    //   2088: astore_3
    //   2089: aload #7
    //   2091: invokevirtual getContext : ()Landroid/content/Context;
    //   2094: aload_3
    //   2095: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2098: astore_3
    //   2099: goto -> 2118
    //   2102: ldc_w 'black_man.png'
    //   2105: astore #4
    //   2107: aload #7
    //   2109: invokevirtual getContext : ()Landroid/content/Context;
    //   2112: aload #4
    //   2114: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2117: astore_3
    //   2118: aload #7
    //   2120: aload_3
    //   2121: putfield s : Landroid/graphics/Bitmap;
    //   2124: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   2127: bipush #120
    //   2129: bipush #23
    //   2131: sipush #149
    //   2134: bipush #16
    //   2136: invokestatic argb : (IIII)I
    //   2139: invokevirtual setColor : (I)V
    //   2142: aload #7
    //   2144: getfield p : Landroid/graphics/Bitmap;
    //   2147: ifnull -> 2166
    //   2150: aload #7
    //   2152: getfield q : Landroid/graphics/Bitmap;
    //   2155: ifnull -> 2166
    //   2158: aload #7
    //   2160: getfield s : Landroid/graphics/Bitmap;
    //   2163: ifnonnull -> 2922
    //   2166: aload #7
    //   2168: invokevirtual j : ()V
    //   2171: goto -> 2922
    //   2174: aload #6
    //   2176: ldc_w '6'
    //   2179: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2182: ifeq -> 2545
    //   2185: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   2188: bipush #8
    //   2190: if_icmpne -> 2256
    //   2193: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   2196: istore_1
    //   2197: iload_1
    //   2198: iconst_4
    //   2199: if_icmpeq -> 2241
    //   2202: iload_1
    //   2203: iconst_5
    //   2204: if_icmpne -> 2210
    //   2207: goto -> 2241
    //   2210: iload_1
    //   2211: bipush #7
    //   2213: if_icmpne -> 2226
    //   2216: aload #7
    //   2218: invokevirtual getContext : ()Landroid/content/Context;
    //   2221: astore #6
    //   2223: goto -> 2268
    //   2226: aload #7
    //   2228: invokevirtual getContext : ()Landroid/content/Context;
    //   2231: astore #6
    //   2233: ldc_w 'board800x800.jpg'
    //   2236: astore #5
    //   2238: goto -> 2268
    //   2241: aload #7
    //   2243: invokevirtual getContext : ()Landroid/content/Context;
    //   2246: astore #6
    //   2248: ldc_w 'board800x800_90.jpg'
    //   2251: astore #5
    //   2253: goto -> 2268
    //   2256: aload #7
    //   2258: invokevirtual getContext : ()Landroid/content/Context;
    //   2261: astore #6
    //   2263: ldc_w 'board10.jpg'
    //   2266: astore #5
    //   2268: aload #6
    //   2270: aload #5
    //   2272: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2275: astore #5
    //   2277: aload #7
    //   2279: aload #5
    //   2281: putfield p : Landroid/graphics/Bitmap;
    //   2284: aload #5
    //   2286: ifnull -> 2328
    //   2289: aload #7
    //   2291: getfield D : I
    //   2294: aload #5
    //   2296: invokevirtual getWidth : ()I
    //   2299: if_icmpge -> 2328
    //   2302: aload #7
    //   2304: getfield p : Landroid/graphics/Bitmap;
    //   2307: astore #5
    //   2309: aload #7
    //   2311: getfield D : I
    //   2314: istore_1
    //   2315: aload #7
    //   2317: aload #5
    //   2319: iload_1
    //   2320: iload_1
    //   2321: iconst_1
    //   2322: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   2325: putfield p : Landroid/graphics/Bitmap;
    //   2328: aload #7
    //   2330: invokevirtual a : ()V
    //   2333: aload #7
    //   2335: aload #7
    //   2337: getfield p : Landroid/graphics/Bitmap;
    //   2340: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   2343: putfield p : Landroid/graphics/Bitmap;
    //   2346: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2349: ifeq -> 2411
    //   2352: aload #7
    //   2354: getfield E : Z
    //   2357: ifne -> 2411
    //   2360: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2363: ifeq -> 2382
    //   2366: aload #7
    //   2368: invokevirtual getContext : ()Landroid/content/Context;
    //   2371: ldc_w 'black_man_3d.png'
    //   2374: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2377: astore #5
    //   2379: goto -> 2395
    //   2382: aload #7
    //   2384: invokevirtual getContext : ()Landroid/content/Context;
    //   2387: ldc_w 'white_man_3d.png'
    //   2390: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2393: astore #5
    //   2395: aload #7
    //   2397: aload #5
    //   2399: putfield q : Landroid/graphics/Bitmap;
    //   2402: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2405: ifeq -> 2478
    //   2408: goto -> 2460
    //   2411: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2414: ifeq -> 2432
    //   2417: aload #7
    //   2419: invokevirtual getContext : ()Landroid/content/Context;
    //   2422: ldc_w 'black_man.png'
    //   2425: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2428: astore_3
    //   2429: goto -> 2444
    //   2432: aload #7
    //   2434: invokevirtual getContext : ()Landroid/content/Context;
    //   2437: ldc_w 'white_man.png'
    //   2440: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2443: astore_3
    //   2444: aload #7
    //   2446: aload_3
    //   2447: putfield q : Landroid/graphics/Bitmap;
    //   2450: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2453: ifeq -> 2473
    //   2456: ldc_w 'white_man.png'
    //   2459: astore_3
    //   2460: aload #7
    //   2462: invokevirtual getContext : ()Landroid/content/Context;
    //   2465: aload_3
    //   2466: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2469: astore_3
    //   2470: goto -> 2489
    //   2473: ldc_w 'black_man.png'
    //   2476: astore #4
    //   2478: aload #7
    //   2480: invokevirtual getContext : ()Landroid/content/Context;
    //   2483: aload #4
    //   2485: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2488: astore_3
    //   2489: aload #7
    //   2491: aload_3
    //   2492: putfield s : Landroid/graphics/Bitmap;
    //   2495: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   2498: bipush #120
    //   2500: bipush #23
    //   2502: sipush #149
    //   2505: bipush #16
    //   2507: invokestatic argb : (IIII)I
    //   2510: invokevirtual setColor : (I)V
    //   2513: aload #7
    //   2515: getfield p : Landroid/graphics/Bitmap;
    //   2518: ifnull -> 2537
    //   2521: aload #7
    //   2523: getfield q : Landroid/graphics/Bitmap;
    //   2526: ifnull -> 2537
    //   2529: aload #7
    //   2531: getfield s : Landroid/graphics/Bitmap;
    //   2534: ifnonnull -> 2922
    //   2537: aload #7
    //   2539: invokevirtual j : ()V
    //   2542: goto -> 2922
    //   2545: aload #6
    //   2547: ldc_w '7'
    //   2550: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2553: ifeq -> 2927
    //   2556: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   2559: bipush #8
    //   2561: if_icmpne -> 2627
    //   2564: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   2567: istore_1
    //   2568: iload_1
    //   2569: iconst_4
    //   2570: if_icmpeq -> 2612
    //   2573: iload_1
    //   2574: iconst_5
    //   2575: if_icmpne -> 2581
    //   2578: goto -> 2612
    //   2581: iload_1
    //   2582: bipush #7
    //   2584: if_icmpne -> 2597
    //   2587: aload #7
    //   2589: invokevirtual getContext : ()Landroid/content/Context;
    //   2592: astore #6
    //   2594: goto -> 2639
    //   2597: aload #7
    //   2599: invokevirtual getContext : ()Landroid/content/Context;
    //   2602: astore #6
    //   2604: ldc_w 'board800x800.jpg'
    //   2607: astore #5
    //   2609: goto -> 2639
    //   2612: aload #7
    //   2614: invokevirtual getContext : ()Landroid/content/Context;
    //   2617: astore #6
    //   2619: ldc_w 'board800x800_90.jpg'
    //   2622: astore #5
    //   2624: goto -> 2639
    //   2627: aload #7
    //   2629: invokevirtual getContext : ()Landroid/content/Context;
    //   2632: astore #6
    //   2634: ldc_w 'board10.jpg'
    //   2637: astore #5
    //   2639: aload #6
    //   2641: aload #5
    //   2643: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2646: astore #5
    //   2648: aload #7
    //   2650: aload #5
    //   2652: putfield p : Landroid/graphics/Bitmap;
    //   2655: aload #5
    //   2657: ifnull -> 2699
    //   2660: aload #7
    //   2662: getfield D : I
    //   2665: aload #5
    //   2667: invokevirtual getWidth : ()I
    //   2670: if_icmpge -> 2699
    //   2673: aload #7
    //   2675: getfield p : Landroid/graphics/Bitmap;
    //   2678: astore #5
    //   2680: aload #7
    //   2682: getfield D : I
    //   2685: istore_1
    //   2686: aload #7
    //   2688: aload #5
    //   2690: iload_1
    //   2691: iload_1
    //   2692: iconst_1
    //   2693: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   2696: putfield p : Landroid/graphics/Bitmap;
    //   2699: aload #7
    //   2701: invokevirtual a : ()V
    //   2704: aload #7
    //   2706: aload #7
    //   2708: getfield p : Landroid/graphics/Bitmap;
    //   2711: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   2714: putfield p : Landroid/graphics/Bitmap;
    //   2717: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2720: ifeq -> 2782
    //   2723: aload #7
    //   2725: getfield E : Z
    //   2728: ifne -> 2782
    //   2731: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2734: ifeq -> 2753
    //   2737: aload #7
    //   2739: invokevirtual getContext : ()Landroid/content/Context;
    //   2742: ldc_w 'black_man_3d.png'
    //   2745: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2748: astore #5
    //   2750: goto -> 2766
    //   2753: aload #7
    //   2755: invokevirtual getContext : ()Landroid/content/Context;
    //   2758: ldc_w 'white_man_3d.png'
    //   2761: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2764: astore #5
    //   2766: aload #7
    //   2768: aload #5
    //   2770: putfield q : Landroid/graphics/Bitmap;
    //   2773: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2776: ifeq -> 2849
    //   2779: goto -> 2831
    //   2782: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2785: ifeq -> 2803
    //   2788: aload #7
    //   2790: invokevirtual getContext : ()Landroid/content/Context;
    //   2793: ldc_w 'black_man.png'
    //   2796: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2799: astore_3
    //   2800: goto -> 2815
    //   2803: aload #7
    //   2805: invokevirtual getContext : ()Landroid/content/Context;
    //   2808: ldc_w 'white_man.png'
    //   2811: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2814: astore_3
    //   2815: aload #7
    //   2817: aload_3
    //   2818: putfield q : Landroid/graphics/Bitmap;
    //   2821: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   2824: ifeq -> 2844
    //   2827: ldc_w 'white_man.png'
    //   2830: astore_3
    //   2831: aload #7
    //   2833: invokevirtual getContext : ()Landroid/content/Context;
    //   2836: aload_3
    //   2837: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2840: astore_3
    //   2841: goto -> 2860
    //   2844: ldc_w 'black_man.png'
    //   2847: astore #4
    //   2849: aload #7
    //   2851: invokevirtual getContext : ()Landroid/content/Context;
    //   2854: aload #4
    //   2856: invokestatic h : (Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   2859: astore_3
    //   2860: aload #7
    //   2862: aload_3
    //   2863: putfield s : Landroid/graphics/Bitmap;
    //   2866: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   2869: sipush #170
    //   2872: bipush #42
    //   2874: sipush #158
    //   2877: bipush #38
    //   2879: invokestatic argb : (IIII)I
    //   2882: invokevirtual setColor : (I)V
    //   2885: aload #7
    //   2887: getfield p : Landroid/graphics/Bitmap;
    //   2890: ifnull -> 2909
    //   2893: aload #7
    //   2895: getfield q : Landroid/graphics/Bitmap;
    //   2898: ifnull -> 2909
    //   2901: aload #7
    //   2903: getfield s : Landroid/graphics/Bitmap;
    //   2906: ifnonnull -> 2922
    //   2909: aload #7
    //   2911: invokevirtual j : ()V
    //   2914: goto -> 2922
    //   2917: aload #7
    //   2919: invokevirtual j : ()V
    //   2922: aload #7
    //   2924: invokevirtual l : ()V
    //   2927: aload_0
    //   2928: getfield x : Lg0/r;
    //   2931: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2934: invokevirtual g : (Lg0/b;)Ljava/util/ArrayList;
    //   2937: putstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
    //   2940: goto -> 2977
    //   2943: astore_3
    //   2944: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   2947: astore #4
    //   2949: ldc_w 'MainPanel actionPerformed '
    //   2952: invokestatic c : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2955: astore #5
    //   2957: aload #5
    //   2959: aload_3
    //   2960: invokevirtual getMessage : ()Ljava/lang/String;
    //   2963: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2966: pop
    //   2967: aload #4
    //   2969: aload #5
    //   2971: invokevirtual toString : ()Ljava/lang/String;
    //   2974: invokevirtual println : (Ljava/lang/String;)V
    //   2977: aload_0
    //   2978: getfield x : Lg0/r;
    //   2981: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2984: invokevirtual d : (Lg0/b;)V
    //   2987: iconst_0
    //   2988: putstatic com/dimcoms/checkers/MainActivity.X : Z
    //   2991: aload_0
    //   2992: iconst_0
    //   2993: iconst_0
    //   2994: invokevirtual r : (ZZ)V
    //   2997: aload_0
    //   2998: iconst_0
    //   2999: putfield w : Z
    //   3002: iconst_0
    //   3003: invokestatic i : (Z)V
    //   3006: return
    // Exception table:
    //   from	to	target	type
    //   2927	2940	2943	g0/f
  }
  
  public final void u() {
    this.x = (r)new g0.e();
    j0 = 9;
    t();
  }
  
  public final void v() {
    this.x = (r)new g0.g();
    j0 = 11;
    t();
  }
  
  public final void w() {
    this.x = (r)new g0.i();
    j0 = 2;
    t();
  }
  
  public final void x() {
    this.x = (r)new g0.h();
    j0 = 6;
    t();
  }
  
  public final void y() {
    this.x = (r)new g0.j();
    j0 = 12;
    t();
  }
  
  public final void z() {
    this.x = (r)new g0.k();
    j0 = 1;
    t();
  }
  
  public final class a implements Runnable {
    public a(MainActivity this$0, String param1String) {}
    
    public final void run() {
      this.i.setText(this.j);
    }
  }
  
  public final class b implements Runnable {
    public final void run() {
      MainActivity mainActivity = MainActivity.G;
      if (mainActivity != null) {
        Button button = (Button)mainActivity.findViewById(2131165233);
        if (button != null)
          f0.k.o((Context)MainActivity.G, button, 2131099667); 
      } 
    }
  }
  
  public final class c extends FullScreenContentCallback {
    public c(MainActivity this$0) {}
    
    public final void onAdDismissedFullScreenContent() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lcom/dimcoms/checkers/MainActivity;
      //   4: invokevirtual g : ()V
      //   7: aload_0
      //   8: getfield a : Lcom/dimcoms/checkers/MainActivity;
      //   11: getfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
      //   14: astore #4
      //   16: ldc 'AdsWatched.xml'
      //   18: invokestatic c : (Ljava/lang/String;)Z
      //   21: ifeq -> 36
      //   24: ldc 'AdsWatched.xml'
      //   26: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
      //   29: astore_3
      //   30: aload_3
      //   31: astore_2
      //   32: aload_3
      //   33: ifnonnull -> 39
      //   36: ldc '0'
      //   38: astore_2
      //   39: aload_2
      //   40: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
      //   43: invokevirtual intValue : ()I
      //   46: iconst_1
      //   47: iadd
      //   48: istore_1
      //   49: ldc 'AdsWatched.xml'
      //   51: iload_1
      //   52: invokestatic valueOf : (I)Ljava/lang/String;
      //   55: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   58: aload #4
      //   60: ifnull -> 127
      //   63: iload_1
      //   64: bipush #10
      //   66: if_icmpne -> 83
      //   69: ldc 'ads_watched_10'
      //   71: astore_2
      //   72: new android/os/Bundle
      //   75: dup
      //   76: invokespecial <init> : ()V
      //   79: astore_3
      //   80: goto -> 120
      //   83: iload_1
      //   84: bipush #20
      //   86: if_icmpne -> 103
      //   89: ldc 'ads_watched_20'
      //   91: astore_2
      //   92: new android/os/Bundle
      //   95: dup
      //   96: invokespecial <init> : ()V
      //   99: astore_3
      //   100: goto -> 120
      //   103: iload_1
      //   104: bipush #30
      //   106: if_icmpne -> 127
      //   109: ldc 'ads_watched_30'
      //   111: astore_2
      //   112: new android/os/Bundle
      //   115: dup
      //   116: invokespecial <init> : ()V
      //   119: astore_3
      //   120: aload #4
      //   122: aload_3
      //   123: aload_2
      //   124: invokevirtual a : (Landroid/os/Bundle;Ljava/lang/String;)V
      //   127: return
      //   128: astore_2
      //   129: return
      // Exception table:
      //   from	to	target	type
      //   72	80	128	java/lang/Error
      //   72	80	128	java/lang/Exception
      //   92	100	128	java/lang/Error
      //   92	100	128	java/lang/Exception
      //   112	120	128	java/lang/Error
      //   112	120	128	java/lang/Exception
      //   120	127	128	java/lang/Error
      //   120	127	128	java/lang/Exception
    }
    
    public final void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      this.a.g();
      this.a.onPause();
      this.a.onResume();
    }
    
    public final void onAdShowedFullScreenContent() {}
  }
  
  public final class d extends InterstitialAdLoadCallback {
    public d(MainActivity this$0) {}
    
    public final void onAdFailedToLoad(LoadAdError param1LoadAdError) {}
    
    public final void onAdLoaded(Object param1Object) {
      param1Object = param1Object;
      this.a.d = (InterstitialAd)param1Object;
      param1Object.setImmersiveMode(true);
      if (MainActivity.I) {
        MainActivity.L = this.a.d;
        return;
      } 
      MainActivity.K = this.a.d;
    }
  }
  
  public final class e extends RewardedAdLoadCallback {
    public e(MainActivity this$0) {}
    
    public final void onAdFailedToLoad(LoadAdError param1LoadAdError) {}
    
    public final void onAdLoaded(Object param1Object) {
      param1Object = param1Object;
      this.a.e = (RewardedAd)param1Object;
      param1Object.setImmersiveMode(true);
      if (MainActivity.I) {
        MainActivity.O = this.a.e;
      } else {
        MainActivity.N = this.a.e;
      } 
      if (MainActivity.g0 != null && MainActivity.G != null && !MainActivity.g0.w)
        MainActivity.G.f(); 
    }
  }
  
  public final class f implements View.OnSystemUiVisibilityChangeListener {
    public f(MainActivity this$0) {}
    
    public final void onSystemUiVisibilityChange(int param1Int) {
      if ((param1Int & 0x4) == 0)
        this.a.setSystemUiVisibility(5894); 
    }
  }
  
  public final class g implements View.OnClickListener {
    public final void onClick(View param1View) {
      if (MainActivity.G != null && !MainActivity.v0)
        f0.a.d(MainActivity.G); 
    }
  }
  
  public final class h implements View.OnTouchListener {
    public h(MainActivity this$0) {}
    
    public final boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      if (i != 0) {
        if (i != 1) {
          if (i != 2)
            return true; 
          MainActivity mainActivity = this.a;
          if (mainActivity.k) {
            float f3 = mainActivity.i;
            float f1 = mainActivity.j;
            float f4 = param1MotionEvent.getX();
            float f2 = param1MotionEvent.getY();
            f3 -= f4;
            f1 -= f2;
            i = (int)Math.sqrt((f1 * f1 + f3 * f3));
            if (f0.k.m((Context)MainActivity.G, i) > 15) {
              this.a.k = false;
              return true;
            } 
          } 
        } else if (this.a.k && MainActivity.V != null && !MainActivity.G.isFinishing()) {
          try {
            MainActivity.V.cancel();
            return true;
          } catch (Exception exception) {
            return true;
          } 
        } 
      } else {
        this.a.i = param1MotionEvent.getX();
        this.a.j = param1MotionEvent.getY();
        this.a.k = true;
      } 
      return true;
    }
  }
  
  public final class i implements View.OnTouchListener {
    public i(MainActivity this$0) {}
    
    public final boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int j = param1MotionEvent.getAction();
      if (j != 0) {
        if (j != 1) {
          if (j != 2)
            return true; 
          MainActivity mainActivity = this.a;
          if (mainActivity.n) {
            float f3 = mainActivity.l;
            float f1 = mainActivity.m;
            float f4 = param1MotionEvent.getX();
            float f2 = param1MotionEvent.getY();
            f3 -= f4;
            f1 -= f2;
            j = (int)Math.sqrt((f1 * f1 + f3 * f3));
            if (f0.k.m((Context)MainActivity.G, j) > 15) {
              this.a.n = false;
              return true;
            } 
          } 
        } else {
          MainActivity mainActivity = this.a;
          if (mainActivity.n && MainActivity.W) {
            mainActivity.I();
            return true;
          } 
        } 
      } else {
        this.a.l = param1MotionEvent.getX();
        this.a.m = param1MotionEvent.getY();
        this.a.n = true;
      } 
      return true;
    }
  }
  
  public final class j implements DialogInterface.OnCancelListener {
    public final void onCancel(DialogInterface param1DialogInterface) {
      MainActivity.v0 = false;
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(160, 0, 0, 0));
        MainActivity.S.setVisibility(8);
      } 
    }
  }
  
  public final class k implements View.OnClickListener {
    public k(MainActivity this$0) {}
    
    public final void onClick(View param1View) {
      MainActivity.v0 = false;
      try {
        this.a.cancel();
        return;
      } catch (Exception exception) {
        return;
      } 
    }
  }
  
  public final class l implements View.OnClickListener {
    public l(MainActivity this$0, y param1y) {}
    
    public final void onClick(View param1View) {
      MainActivity.v0 = false;
      this.a.dismiss();
      this.b.getClass();
      MainActivity.p();
      try {
        MainActivity mainActivity1 = this.b;
        RewardedAd rewardedAd = mainActivity1.e;
        if (rewardedAd != null && !MainActivity.i0) {
          rewardedAd.setFullScreenContentCallback(new a(this));
          this.b.e.show(mainActivity1, new b(this));
        } else {
          mainActivity1.z = true;
        } 
      } catch (NoClassDefFoundError|Exception noClassDefFoundError) {
        this.b.z = true;
      } 
      MainActivity mainActivity = this.b;
      if (mainActivity.z) {
        mainActivity.z = false;
        mainActivity.onPause();
        this.b.onResume();
      } 
    }
    
    public final class a extends FullScreenContentCallback {
      public a(MainActivity.l this$0) {}
      
      public final void onAdDismissedFullScreenContent() {
        this.a.b.h();
      }
      
      public final void onAdFailedToShowFullScreenContent(AdError param2AdError) {
        this.a.b.h();
        RelativeLayout relativeLayout = MainActivity.S;
        if (relativeLayout != null)
          relativeLayout.setBackgroundColor(Color.argb(160, 0, 0, 0)); 
        relativeLayout = MainActivity.T;
        if (relativeLayout != null)
          relativeLayout.setVisibility(8); 
        this.a.a.show();
      }
      
      public final void onAdShowedFullScreenContent() {}
    }
    
    public final class b implements OnUserEarnedRewardListener {
      public b(MainActivity.l this$0) {}
      
      public final void onUserEarnedReward(RewardItem param2RewardItem) {
        g0.b b1 = MainActivity.g0;
        if (b1 != null)
          b1.w = true; 
        try {
          FirebaseAnalytics firebaseAnalytics = this.a.b.F;
          if (firebaseAnalytics != null)
            firebaseAnalytics.a(new Bundle(), "rewarded_level_hint_earned"); 
          return;
        } catch (Error|Exception error) {
          return;
        } 
      }
    }
  }
  
  public final class a extends FullScreenContentCallback {
    public a(MainActivity this$0) {}
    
    public final void onAdDismissedFullScreenContent() {
      this.a.b.h();
    }
    
    public final void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      this.a.b.h();
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null)
        relativeLayout.setBackgroundColor(Color.argb(160, 0, 0, 0)); 
      relativeLayout = MainActivity.T;
      if (relativeLayout != null)
        relativeLayout.setVisibility(8); 
      this.a.a.show();
    }
    
    public final void onAdShowedFullScreenContent() {}
  }
  
  public final class b implements OnUserEarnedRewardListener {
    public b(MainActivity this$0) {}
    
    public final void onUserEarnedReward(RewardItem param1RewardItem) {
      g0.b b1 = MainActivity.g0;
      if (b1 != null)
        b1.w = true; 
      try {
        FirebaseAnalytics firebaseAnalytics = this.a.b.F;
        if (firebaseAnalytics != null)
          firebaseAnalytics.a(new Bundle(), "rewarded_level_hint_earned"); 
        return;
      } catch (Error|Exception error) {
        return;
      } 
    }
  }
  
  public final class m implements View.OnClickListener {
    public m(MainActivity this$0, y param1y) {}
    
    public final void onClick(View param1View) {
      // Byte code:
      //   0: getstatic com/dimcoms/checkers/MainActivity.W0 : Z
      //   3: ifeq -> 158
      //   6: getstatic com/dimcoms/checkers/MainActivity.l0 : Z
      //   9: ifeq -> 39
      //   12: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
      //   15: astore_1
      //   16: aload_1
      //   17: ifnull -> 39
      //   20: aload_1
      //   21: invokevirtual autoPause : ()V
      //   24: getstatic com/dimcoms/checkers/MainActivity.I0 : Landroid/media/SoundPool;
      //   27: getstatic com/dimcoms/checkers/MainActivity.H0 : I
      //   30: fconst_1
      //   31: fconst_1
      //   32: iconst_1
      //   33: iconst_0
      //   34: fconst_1
      //   35: invokevirtual play : (IFFIIF)I
      //   38: pop
      //   39: aload_0
      //   40: getfield b : Lcom/dimcoms/checkers/MainActivity;
      //   43: getfield c : Landroid/content/SharedPreferences$Editor;
      //   46: ldc 'hasDailyReward'
      //   48: iconst_0
      //   49: invokeinterface putBoolean : (Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;
      //   54: pop
      //   55: aload_0
      //   56: getfield b : Lcom/dimcoms/checkers/MainActivity;
      //   59: getfield c : Landroid/content/SharedPreferences$Editor;
      //   62: invokeinterface commit : ()Z
      //   67: pop
      //   68: iconst_0
      //   69: putstatic com/dimcoms/checkers/MainActivity.W0 : Z
      //   72: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   75: astore_1
      //   76: aload_1
      //   77: ifnull -> 85
      //   80: aload_1
      //   81: iconst_1
      //   82: putfield w : Z
      //   85: aload_0
      //   86: getfield b : Lcom/dimcoms/checkers/MainActivity;
      //   89: getfield F : Lcom/google/firebase/analytics/FirebaseAnalytics;
      //   92: astore_1
      //   93: aload_1
      //   94: ifnull -> 113
      //   97: aload_1
      //   98: new android/os/Bundle
      //   101: dup
      //   102: invokespecial <init> : ()V
      //   105: ldc 'rewarded_level_hint_bonus'
      //   107: invokevirtual a : (Landroid/os/Bundle;Ljava/lang/String;)V
      //   110: goto -> 113
      //   113: aload_0
      //   114: getfield b : Lcom/dimcoms/checkers/MainActivity;
      //   117: ldc 2131165233
      //   119: invokevirtual findViewById : (I)Landroid/view/View;
      //   122: checkcast android/widget/Button
      //   125: astore_1
      //   126: aload_1
      //   127: ifnull -> 147
      //   130: aload_0
      //   131: getfield b : Lcom/dimcoms/checkers/MainActivity;
      //   134: iconst_0
      //   135: putfield D : Z
      //   138: getstatic com/dimcoms/checkers/MainActivity.G : Lcom/dimcoms/checkers/MainActivity;
      //   141: aload_1
      //   142: ldc 2131099667
      //   144: invokestatic o : (Landroid/content/Context;Landroid/widget/Button;I)V
      //   147: iconst_0
      //   148: putstatic com/dimcoms/checkers/MainActivity.v0 : Z
      //   151: aload_0
      //   152: getfield a : Lf0/y;
      //   155: invokevirtual cancel : ()V
      //   158: return
      //   159: astore_1
      //   160: goto -> 113
      //   163: astore_1
      //   164: return
      // Exception table:
      //   from	to	target	type
      //   85	93	159	java/lang/Error
      //   85	93	159	java/lang/Exception
      //   97	110	159	java/lang/Error
      //   97	110	159	java/lang/Exception
      //   151	158	163	java/lang/Exception
    }
  }
  
  public final class n implements Runnable {
    public n(MainActivity this$0, Button param1Button, Toast param1Toast) {}
    
    public final void run() {
      if (MainActivity.G != null) {
        int i;
        MainActivity mainActivity;
        Button button;
        if (this.k.e != null && !MainActivity.i0) {
          mainActivity = MainActivity.G;
          button = this.i;
          i = 2131099666;
        } else {
          mainActivity = MainActivity.G;
          button = this.i;
          i = 2131099668;
        } 
        f0.k.o((Context)mainActivity, button, i);
      } 
      Toast toast = this.j;
      if (toast != null)
        toast.show(); 
      this.k.E = false;
    }
  }
  
  public static final class o extends Handler {
    public final MainActivity a;
    
    public o(MainActivity param1MainActivity) {
      this.a = param1MainActivity;
    }
    
    public final void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5)
              return; 
            MainActivity.P.b();
            return;
          } 
          MainActivity mainActivity1 = this.a;
          mainActivity1.getClass();
          MainActivity.O0 = true;
          MainActivity.i(false);
          Button button = (Button)mainActivity1.findViewById(2131165233);
          if (button != null)
            f0.k.o((Context)mainActivity1, button, 2131099667); 
          if (MainActivity.l0) {
            SoundPool soundPool = MainActivity.I0;
            if (soundPool != null) {
              soundPool.autoPause();
              MainActivity.I0.play(MainActivity.G0, 1.0F, 1.0F, 1, 0, 1.0F);
            } 
          } 
          return;
        } 
        (new a(this.a)).run();
        return;
      } 
      MainActivity mainActivity = this.a;
      w w = MainActivity.R0;
      mainActivity.getClass();
      MainActivity.O0 = false;
      mainActivity.G();
      mainActivity.s = 0;
      if (w.c() > 0) {
        MainActivity.u0 = false;
        MainActivity.s0.clear();
        i = (w.b(mainActivity.s)).a;
        int j = (w.b(mainActivity.s)).b;
        g0.d d = new g0.d(MainActivity.g0);
        mainActivity.r = mainActivity.v.a[i][j];
        MainActivity.P.setBoardTable(d);
        MainActivity.P.e = 3;
        mainActivity.x.d(MainActivity.g0);
        MainActivity.P.F = false;
      } 
      MainActivity.P.b();
    }
    
    public final class a implements Runnable {
      public a(MainActivity.o this$0) {}
      
      public final void run() {
        MainActivity mainActivity = this.i;
        if (mainActivity != null) {
          w w = MainActivity.R0;
          int i = mainActivity.s;
          int k = w.c();
          int j = 0;
          if (i < k) {
            j = (w.b(mainActivity.s)).a;
            i = (w.b(mainActivity.s)).b;
          } else {
            i = 0;
          } 
          mainActivity.s++;
          k = w.c();
          int m = mainActivity.s;
          if (k >= m + 1) {
            if (MainActivity.l0) {
              SoundPool soundPool = MainActivity.I0;
              if (soundPool != null && m != 1)
                soundPool.play(MainActivity.y0, 0.5F, 0.5F, 1, 0, 1.0F); 
            } 
            MySurfaceView2 mySurfaceView2 = MainActivity.P;
            k = (w.b(mainActivity.s)).a;
            m = (w.b(mainActivity.s)).b;
            int n = mainActivity.r;
            int i1 = mainActivity.s;
            mySurfaceView2.getClass();
            if (i1 == 1)
              try {
                mySurfaceView2.w.e(j, i);
              } catch (g0.f f) {
                f.printStackTrace();
              }  
            i1 = k - j;
            int i2 = m - i;
            i1 = (int)Math.round(Math.sqrt(Math.sqrt((i2 * i2 + i1 * i1))) * 200.0D);
            MySurfaceView2.I = i1;
            if (i1 > 0) {
              long l = System.currentTimeMillis();
              mySurfaceView2.a = l;
              mySurfaceView2.b = l + MySurfaceView2.I;
            } 
            if (n != 0) {
              mySurfaceView2.o = mySurfaceView2.c(n);
              mySurfaceView2.l = MySurfaceView2.d(n);
            } 
            float f1 = mySurfaceView2.v;
            n = MySurfaceView2.R;
            float f2 = n;
            float f3 = f1 / f2;
            float f4 = (n - i - 1) * f3;
            mySurfaceView2.i = f4;
            float f5 = j * f1 / f2;
            mySurfaceView2.h = f5;
            mySurfaceView2.k = f3 * (n - m - 1);
            mySurfaceView2.j = k * f1 / f2;
            mySurfaceView2.g = f4;
            mySurfaceView2.f = f5;
            mySurfaceView2.e = 2;
          } else {
            if (((MainActivity)f).q) {
              f.l();
            } else {
              f.k();
            } 
            if (MainActivity.l0 && MainActivity.I0 != null && !MainActivity.e()) {
              float f1;
              SoundPool soundPool;
              if (MainActivity.c0) {
                soundPool = MainActivity.I0;
                i = MainActivity.B0;
                f1 = 0.7F;
              } else if (((MainActivity)soundPool).o) {
                if (((MainActivity)soundPool).p) {
                  soundPool = MainActivity.I0;
                  i = MainActivity.z0;
                  f1 = 1.0F;
                } else {
                  MainActivity.I0.play(MainActivity.y0, 0.5F, 0.5F, 1, 0, 1.0F);
                  MainActivity.P.b();
                } 
              } else {
                MainActivity.I0.play(MainActivity.x0, 1.0F, 1.0F, 1, 0, 1.0F);
                MainActivity.P.b();
              } 
              soundPool.play(i, 0.5F, 0.5F, 1, 0, f1);
            } 
          } 
        } else {
          return;
        } 
        MainActivity.P.b();
      }
    }
  }
  
  public final class a implements Runnable {
    public a(MainActivity this$0) {}
    
    public final void run() {
      MainActivity mainActivity = this.i;
      if (mainActivity != null) {
        w w = MainActivity.R0;
        int i = mainActivity.s;
        int k = w.c();
        int j = 0;
        if (i < k) {
          j = (w.b(mainActivity.s)).a;
          i = (w.b(mainActivity.s)).b;
        } else {
          i = 0;
        } 
        mainActivity.s++;
        k = w.c();
        int m = mainActivity.s;
        if (k >= m + 1) {
          if (MainActivity.l0) {
            SoundPool soundPool = MainActivity.I0;
            if (soundPool != null && m != 1)
              soundPool.play(MainActivity.y0, 0.5F, 0.5F, 1, 0, 1.0F); 
          } 
          MySurfaceView2 mySurfaceView2 = MainActivity.P;
          k = (w.b(mainActivity.s)).a;
          m = (w.b(mainActivity.s)).b;
          int n = mainActivity.r;
          int i1 = mainActivity.s;
          mySurfaceView2.getClass();
          if (i1 == 1)
            try {
              mySurfaceView2.w.e(j, i);
            } catch (g0.f f) {
              f.printStackTrace();
            }  
          i1 = k - j;
          int i2 = m - i;
          i1 = (int)Math.round(Math.sqrt(Math.sqrt((i2 * i2 + i1 * i1))) * 200.0D);
          MySurfaceView2.I = i1;
          if (i1 > 0) {
            long l = System.currentTimeMillis();
            mySurfaceView2.a = l;
            mySurfaceView2.b = l + MySurfaceView2.I;
          } 
          if (n != 0) {
            mySurfaceView2.o = mySurfaceView2.c(n);
            mySurfaceView2.l = MySurfaceView2.d(n);
          } 
          float f1 = mySurfaceView2.v;
          n = MySurfaceView2.R;
          float f2 = n;
          float f3 = f1 / f2;
          float f4 = (n - i - 1) * f3;
          mySurfaceView2.i = f4;
          float f5 = j * f1 / f2;
          mySurfaceView2.h = f5;
          mySurfaceView2.k = f3 * (n - m - 1);
          mySurfaceView2.j = k * f1 / f2;
          mySurfaceView2.g = f4;
          mySurfaceView2.f = f5;
          mySurfaceView2.e = 2;
        } else {
          if (((MainActivity)f).q) {
            f.l();
          } else {
            f.k();
          } 
          if (MainActivity.l0 && MainActivity.I0 != null && !MainActivity.e()) {
            float f1;
            SoundPool soundPool;
            if (MainActivity.c0) {
              soundPool = MainActivity.I0;
              i = MainActivity.B0;
              f1 = 0.7F;
            } else if (((MainActivity)soundPool).o) {
              if (((MainActivity)soundPool).p) {
                soundPool = MainActivity.I0;
                i = MainActivity.z0;
                f1 = 1.0F;
              } else {
                MainActivity.I0.play(MainActivity.y0, 0.5F, 0.5F, 1, 0, 1.0F);
                MainActivity.P.b();
              } 
            } else {
              MainActivity.I0.play(MainActivity.x0, 1.0F, 1.0F, 1, 0, 1.0F);
              MainActivity.P.b();
            } 
            soundPool.play(i, 0.5F, 0.5F, 1, 0, f1);
          } 
        } 
      } else {
        return;
      } 
      MainActivity.P.b();
    }
  }
  
  public static interface p {}
  
  public final class q implements Runnable {
    public w i;
    
    public boolean j = true;
    
    public q(MainActivity this$0, w param1w) {
      this.i = param1w;
    }
    
    public final void run() {
      if (this.j) {
        try {
          Thread.currentThread();
          Thread.sleep(598L);
        } catch (InterruptedException interruptedException) {}
        if (this.j) {
          MainActivity mainActivity = this.k;
          MainActivity.R0 = this.i;
          mainActivity.s = 0;
          mainActivity.q = false;
          MainActivity.a0.sendEmptyMessage(1);
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */