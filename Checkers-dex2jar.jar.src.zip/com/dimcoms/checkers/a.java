package com.dimcoms.checkers;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import f0.k;

public final class a {
  public static MainActivity a;
  
  public static Dialog b;
  
  public static a c = new a();
  
  public static b d = new b();
  
  public static c e = new c();
  
  public static d f = new d();
  
  public static e g = new e();
  
  public static f h = new f();
  
  public static g i = new g();
  
  public static void a() {
    Dialog dialog = b;
    if (dialog != null && dialog.isShowing())
      b.dismiss(); 
  }
  
  public final class a implements View.OnClickListener {
    public final void onClick(View param1View) {
      MainActivity.q q = a.a.u;
      if (q != null)
        q.j = false; 
      if (MainActivity.J) {
        Button button = (Button)a.a.findViewById(2131165230);
        if (button != null) {
          button.clearAnimation();
          button.setBackgroundResource(2131099806);
        } 
      } 
      MainActivity.u0 = true;
      MainActivity.v0 = false;
      MainActivity.g0.t = 0;
      a.a();
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
        if (MainActivity.M != null && !MainActivity.i0)
          MainActivity.M.setVisibility(8); 
      } 
      switch (androidx.lifecycle.b.b(MainActivity.j0)) {
        case 11:
          a.a.y();
          break;
        case 10:
          a.a.v();
          break;
        case 9:
          a.a.A();
          break;
        case 8:
          a.a.u();
          break;
        case 7:
          a.a.E();
          break;
        case 6:
          a.a.D();
          break;
        case 5:
          a.a.x();
          break;
        case 4:
          a.a.C();
          break;
        case 3:
          a.a.B();
          break;
        case 2:
          a.a.F();
          break;
        case 1:
          a.a.w();
          break;
        case 0:
          a.a.z();
          break;
      } 
      a.a.q();
      MainActivity.r0 = true;
      a.a.b();
      MainActivity mainActivity = a.a;
      if (mainActivity.z) {
        mainActivity.z = false;
        mainActivity.onPause();
        a.a.onResume();
      } 
      MainActivity.P.b();
    }
  }
  
  public final class b implements View.OnClickListener {
    public final void onClick(View param1View) {
      MainActivity.v0 = false;
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
        if (MainActivity.M != null && !MainActivity.i0)
          MainActivity.M.setVisibility(8); 
      } 
      a.a();
      MainActivity mainActivity = a.a;
      if (MainActivity.N0) {
        mainActivity.startActivity(new Intent((Context)mainActivity, MenuActivity.class));
        MainActivity.N0 = false;
      } else {
        a.a.b();
      } 
      MainActivity.H = true;
      a.a.finish();
    }
  }
  
  public final class c implements View.OnClickListener {
    public final void onClick(View param1View) {
      k.c();
      MainActivity.v0 = false;
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
        if (MainActivity.M != null && !MainActivity.i0)
          MainActivity.M.setVisibility(8); 
      } 
      a.a();
      MainActivity mainActivity = a.a;
      if (MainActivity.N0) {
        mainActivity.startActivity(new Intent((Context)mainActivity, MenuActivity.class));
        MainActivity.N0 = false;
      } else {
        a.a.b();
      } 
      MainActivity.H = true;
      a.a.finish();
    }
  }
  
  public final class d implements View.OnClickListener {
    public final void onClick(View param1View) {
      // Byte code:
      //   0: invokestatic c : ()V
      //   3: iconst_0
      //   4: putstatic com/dimcoms/checkers/MainActivity.v0 : Z
      //   7: iconst_0
      //   8: putstatic com/dimcoms/checkers/MainActivity.H : Z
      //   11: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   14: iconst_0
      //   15: putfield t : I
      //   18: getstatic com/dimcoms/checkers/MainActivity.S : Landroid/widget/RelativeLayout;
      //   21: astore_1
      //   22: aload_1
      //   23: ifnull -> 59
      //   26: aload_1
      //   27: sipush #200
      //   30: iconst_0
      //   31: iconst_0
      //   32: iconst_0
      //   33: invokestatic argb : (IIII)I
      //   36: invokevirtual setBackgroundColor : (I)V
      //   39: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
      //   42: ifnull -> 59
      //   45: getstatic com/dimcoms/checkers/MainActivity.i0 : Z
      //   48: ifne -> 59
      //   51: getstatic com/dimcoms/checkers/MainActivity.M : Lcom/google/android/gms/ads/AdView;
      //   54: bipush #8
      //   56: invokevirtual setVisibility : (I)V
      //   59: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
      //   62: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
      //   65: invokevirtual intValue : ()I
      //   68: iconst_1
      //   69: iadd
      //   70: istore_2
      //   71: iload_2
      //   72: invokestatic valueOf : (I)Ljava/lang/String;
      //   75: astore_1
      //   76: aload_1
      //   77: putstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
      //   80: iload_2
      //   81: putstatic com/dimcoms/checkers/MainActivity.Q0 : I
      //   84: ldc 'Level.xml'
      //   86: aload_1
      //   87: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   90: getstatic com/dimcoms/checkers/MainActivity.j0 : I
      //   93: invokestatic b : (I)I
      //   96: tableswitch default -> 160, 0 -> 262, 1 -> 253, 2 -> 244, 3 -> 235, 4 -> 226, 5 -> 217, 6 -> 208, 7 -> 199, 8 -> 190, 9 -> 181, 10 -> 172, 11 -> 163
      //   160: goto -> 268
      //   163: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   166: invokevirtual y : ()V
      //   169: goto -> 268
      //   172: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   175: invokevirtual v : ()V
      //   178: goto -> 268
      //   181: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   184: invokevirtual A : ()V
      //   187: goto -> 268
      //   190: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   193: invokevirtual u : ()V
      //   196: goto -> 268
      //   199: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   202: invokevirtual E : ()V
      //   205: goto -> 268
      //   208: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   211: invokevirtual D : ()V
      //   214: goto -> 268
      //   217: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   220: invokevirtual x : ()V
      //   223: goto -> 268
      //   226: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   229: invokevirtual C : ()V
      //   232: goto -> 268
      //   235: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   238: invokevirtual B : ()V
      //   241: goto -> 268
      //   244: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   247: invokevirtual F : ()V
      //   250: goto -> 268
      //   253: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   256: invokevirtual w : ()V
      //   259: goto -> 268
      //   262: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   265: invokevirtual z : ()V
      //   268: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   271: invokevirtual q : ()V
      //   274: iconst_1
      //   275: putstatic com/dimcoms/checkers/MainActivity.r0 : Z
      //   278: ldc 'Rate.xml'
      //   280: invokestatic c : (Ljava/lang/String;)Z
      //   283: ifeq -> 394
      //   286: ldc 'Rate.xml'
      //   288: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
      //   291: astore_1
      //   292: aload_1
      //   293: ifnull -> 307
      //   296: aload_1
      //   297: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
      //   300: invokevirtual intValue : ()I
      //   303: istore_2
      //   304: goto -> 309
      //   307: iconst_0
      //   308: istore_2
      //   309: ldc 'Rate.xml'
      //   311: iload_2
      //   312: iconst_1
      //   313: iadd
      //   314: invokestatic valueOf : (I)Ljava/lang/String;
      //   317: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   320: aload_1
      //   321: ifnonnull -> 327
      //   324: goto -> 401
      //   327: aload_1
      //   328: ldc '3'
      //   330: invokevirtual equals : (Ljava/lang/Object;)Z
      //   333: ifeq -> 341
      //   336: iconst_1
      //   337: istore_2
      //   338: goto -> 403
      //   341: aload_1
      //   342: ldc '10'
      //   344: invokevirtual equals : (Ljava/lang/Object;)Z
      //   347: ifeq -> 401
      //   350: ldc 'Later.xml'
      //   352: invokestatic c : (Ljava/lang/String;)Z
      //   355: ifeq -> 385
      //   358: ldc 'Later.xml'
      //   360: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
      //   363: astore_1
      //   364: aload_1
      //   365: ifnonnull -> 371
      //   368: goto -> 385
      //   371: aload_1
      //   372: ldc '0'
      //   374: invokevirtual equals : (Ljava/lang/Object;)Z
      //   377: ifeq -> 385
      //   380: iconst_1
      //   381: istore_2
      //   382: goto -> 387
      //   385: iconst_0
      //   386: istore_2
      //   387: iload_2
      //   388: ifeq -> 401
      //   391: goto -> 336
      //   394: ldc 'Rate.xml'
      //   396: ldc '1'
      //   398: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   401: iconst_0
      //   402: istore_2
      //   403: iload_2
      //   404: ifeq -> 592
      //   407: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   410: astore_3
      //   411: aload_3
      //   412: invokevirtual getClass : ()Ljava/lang/Class;
      //   415: pop
      //   416: iconst_1
      //   417: putstatic com/dimcoms/checkers/MainActivity.v0 : Z
      //   420: bipush #7
      //   422: putstatic com/dimcoms/checkers/MainActivity.w0 : I
      //   425: getstatic android/os/Build$VERSION.SDK_INT : I
      //   428: bipush #21
      //   430: if_icmplt -> 454
      //   433: new android/app/AlertDialog$Builder
      //   436: dup
      //   437: new android/view/ContextThemeWrapper
      //   440: dup
      //   441: aload_3
      //   442: ldc 16974394
      //   444: invokespecial <init> : (Landroid/content/Context;I)V
      //   447: invokespecial <init> : (Landroid/content/Context;)V
      //   450: astore_1
      //   451: goto -> 472
      //   454: new android/app/AlertDialog$Builder
      //   457: dup
      //   458: new android/view/ContextThemeWrapper
      //   461: dup
      //   462: aload_3
      //   463: ldc 16973939
      //   465: invokespecial <init> : (Landroid/content/Context;I)V
      //   468: invokespecial <init> : (Landroid/content/Context;)V
      //   471: astore_1
      //   472: aload_1
      //   473: iconst_0
      //   474: invokevirtual setCancelable : (Z)Landroid/app/AlertDialog$Builder;
      //   477: pop
      //   478: aload_1
      //   479: ldc 2131427446
      //   481: new f0/n
      //   484: dup
      //   485: aload_3
      //   486: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
      //   489: invokevirtual setNeutralButton : (ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
      //   492: pop
      //   493: aload_1
      //   494: ldc 2131427447
      //   496: new f0/o
      //   499: dup
      //   500: aload_3
      //   501: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
      //   504: invokevirtual setNegativeButton : (ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
      //   507: pop
      //   508: aload_1
      //   509: ldc 2131427448
      //   511: new f0/p
      //   514: dup
      //   515: aload_3
      //   516: invokespecial <init> : (Lcom/dimcoms/checkers/MainActivity;)V
      //   519: invokevirtual setPositiveButton : (ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
      //   522: pop
      //   523: aload_1
      //   524: invokevirtual create : ()Landroid/app/AlertDialog;
      //   527: astore_1
      //   528: aload_1
      //   529: invokevirtual getWindow : ()Landroid/view/Window;
      //   532: iconst_2
      //   533: invokevirtual clearFlags : (I)V
      //   536: aload_1
      //   537: ldc 2131427450
      //   539: invokevirtual setTitle : (I)V
      //   542: aload_1
      //   543: aload_3
      //   544: ldc 2131427449
      //   546: invokevirtual getString : (I)Ljava/lang/String;
      //   549: invokevirtual setMessage : (Ljava/lang/CharSequence;)V
      //   552: aload_1
      //   553: invokevirtual getWindow : ()Landroid/view/Window;
      //   556: bipush #8
      //   558: bipush #8
      //   560: invokevirtual setFlags : (II)V
      //   563: aload_1
      //   564: invokevirtual show : ()V
      //   567: aload_1
      //   568: invokevirtual getWindow : ()Landroid/view/Window;
      //   571: invokevirtual getDecorView : ()Landroid/view/View;
      //   574: sipush #5894
      //   577: invokevirtual setSystemUiVisibility : (I)V
      //   580: aload_1
      //   581: invokevirtual getWindow : ()Landroid/view/Window;
      //   584: bipush #8
      //   586: invokevirtual clearFlags : (I)V
      //   589: goto -> 598
      //   592: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   595: invokevirtual b : ()V
      //   598: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   601: getfield z : Z
      //   604: ifeq -> 648
      //   607: getstatic com/dimcoms/checkers/MainActivity.o0 : Z
      //   610: ifne -> 629
      //   613: getstatic com/dimcoms/checkers/MainActivity.Z : Z
      //   616: ifeq -> 629
      //   619: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   622: invokevirtual o : ()V
      //   625: iconst_0
      //   626: putstatic com/dimcoms/checkers/MainActivity.r0 : Z
      //   629: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   632: astore_1
      //   633: aload_1
      //   634: iconst_0
      //   635: putfield z : Z
      //   638: aload_1
      //   639: invokevirtual onPause : ()V
      //   642: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   645: invokevirtual onResume : ()V
      //   648: invokestatic a : ()V
      //   651: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
      //   654: invokevirtual b : ()V
      //   657: return
    }
  }
  
  public final class e implements View.OnClickListener {
    public final void onClick(View param1View) {
      k.c();
      MainActivity.v0 = false;
      MainActivity.H = false;
      MainActivity.g0.t = 0;
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
        if (MainActivity.M != null && !MainActivity.i0)
          MainActivity.M.setVisibility(8); 
      } 
      switch (androidx.lifecycle.b.b(MainActivity.j0)) {
        case 11:
          a.a.y();
          break;
        case 10:
          a.a.v();
          break;
        case 9:
          a.a.A();
          break;
        case 8:
          a.a.u();
          break;
        case 7:
          a.a.E();
          break;
        case 6:
          a.a.D();
          break;
        case 5:
          a.a.x();
          break;
        case 4:
          a.a.C();
          break;
        case 3:
          a.a.B();
          break;
        case 2:
          a.a.F();
          break;
        case 1:
          a.a.w();
          break;
        case 0:
          a.a.z();
          break;
      } 
      a.a.q();
      MainActivity.r0 = true;
      a.a.b();
      if (a.a.z) {
        if (!MainActivity.o0 && MainActivity.Z) {
          a.a.o();
          MainActivity.r0 = false;
        } 
        MainActivity mainActivity = a.a;
        mainActivity.z = false;
        mainActivity.onPause();
        a.a.onResume();
      } 
      a.a();
      MainActivity.P.b();
    }
  }
  
  public final class f implements View.OnClickListener {
    public final void onClick(View param1View) {
      MainActivity.v0 = false;
      RelativeLayout relativeLayout = MainActivity.S;
      if (relativeLayout != null) {
        relativeLayout.setBackgroundColor(Color.argb(200, 0, 0, 0));
        if (MainActivity.M != null && !MainActivity.i0)
          MainActivity.M.setVisibility(8); 
      } 
      a.a();
      Intent intent = new Intent((Context)a.a, SetActivity.class);
      intent.putExtra("type", MainActivity.U0);
      a.a.startActivity(intent);
      MainActivity.H = true;
      a.a.finish();
    }
  }
  
  public final class g implements MainActivity.p {
    public final void a(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: iload_1
      //   1: iflt -> 2806
      //   4: iload_2
      //   5: iflt -> 2806
      //   8: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
      //   11: istore_3
      //   12: iload_1
      //   13: iload_3
      //   14: if_icmpge -> 2806
      //   17: iload_2
      //   18: iload_3
      //   19: if_icmplt -> 23
      //   22: return
      //   23: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   26: iload_1
      //   27: iload_2
      //   28: invokevirtual a : (II)V
      //   31: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   34: getfield x : Lg0/r;
      //   37: astore #10
      //   39: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   42: astore #11
      //   44: getstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
      //   47: astore #12
      //   49: aload #10
      //   51: invokevirtual getClass : ()Ljava/lang/Class;
      //   54: pop
      //   55: aload #11
      //   57: aload #12
      //   59: iconst_1
      //   60: invokestatic r : (Lg0/w;Ljava/util/ArrayList;Z)I
      //   63: istore #4
      //   65: iload #4
      //   67: istore_3
      //   68: iload #4
      //   70: iconst_1
      //   71: if_icmpne -> 647
      //   74: getstatic com/dimcoms/checkers/MainActivity.j0 : I
      //   77: istore_3
      //   78: iload_3
      //   79: bipush #8
      //   81: if_icmpeq -> 90
      //   84: iload_3
      //   85: bipush #7
      //   87: if_icmpne -> 110
      //   90: new g0/d
      //   93: dup
      //   94: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   97: invokespecial <init> : (Lg0/b;)V
      //   100: astore #10
      //   102: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   105: aload #10
      //   107: putfield v : Lg0/d;
      //   110: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
      //   113: iconst_0
      //   114: putfield F : Z
      //   117: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   120: getfield v : Lg0/d;
      //   123: invokevirtual a : ()V
      //   126: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   129: getfield v : Lg0/d;
      //   132: astore #10
      //   134: iconst_0
      //   135: istore_3
      //   136: iload_3
      //   137: aload #10
      //   139: getfield j : I
      //   142: if_icmpge -> 185
      //   145: iconst_0
      //   146: istore #4
      //   148: iload #4
      //   150: aload #10
      //   152: getfield j : I
      //   155: if_icmpge -> 178
      //   158: aload #10
      //   160: getfield e : [[Z
      //   163: iload_3
      //   164: aaload
      //   165: iload #4
      //   167: iconst_0
      //   168: bastore
      //   169: iload #4
      //   171: iconst_1
      //   172: iadd
      //   173: istore #4
      //   175: goto -> 148
      //   178: iload_3
      //   179: iconst_1
      //   180: iadd
      //   181: istore_3
      //   182: goto -> 136
      //   185: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   188: getfield v : Lg0/d;
      //   191: astore #10
      //   193: iconst_0
      //   194: istore_3
      //   195: iload_3
      //   196: aload #10
      //   198: getfield j : I
      //   201: if_icmpge -> 244
      //   204: iconst_0
      //   205: istore #4
      //   207: iload #4
      //   209: aload #10
      //   211: getfield j : I
      //   214: if_icmpge -> 237
      //   217: aload #10
      //   219: getfield f : [[Z
      //   222: iload_3
      //   223: aaload
      //   224: iload #4
      //   226: iconst_0
      //   227: bastore
      //   228: iload #4
      //   230: iconst_1
      //   231: iadd
      //   232: istore #4
      //   234: goto -> 207
      //   237: iload_3
      //   238: iconst_1
      //   239: iadd
      //   240: istore_3
      //   241: goto -> 195
      //   244: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   247: getfield v : Lg0/d;
      //   250: astore #10
      //   252: iconst_0
      //   253: istore_3
      //   254: iload_3
      //   255: aload #10
      //   257: getfield j : I
      //   260: if_icmpge -> 303
      //   263: iconst_0
      //   264: istore #4
      //   266: iload #4
      //   268: aload #10
      //   270: getfield j : I
      //   273: if_icmpge -> 296
      //   276: aload #10
      //   278: getfield h : [[Z
      //   281: iload_3
      //   282: aaload
      //   283: iload #4
      //   285: iconst_0
      //   286: bastore
      //   287: iload #4
      //   289: iconst_1
      //   290: iadd
      //   291: istore #4
      //   293: goto -> 266
      //   296: iload_3
      //   297: iconst_1
      //   298: iadd
      //   299: istore_3
      //   300: goto -> 254
      //   303: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   306: invokevirtual clear : ()V
      //   309: new g0/w
      //   312: dup
      //   313: invokespecial <init> : ()V
      //   316: astore #10
      //   318: aload #10
      //   320: putstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   323: aload #10
      //   325: iload_1
      //   326: iload_2
      //   327: invokevirtual a : (II)V
      //   330: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   333: getfield x : Lg0/r;
      //   336: astore #10
      //   338: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   341: astore #11
      //   343: getstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
      //   346: astore #12
      //   348: aload #10
      //   350: invokevirtual getClass : ()Ljava/lang/Class;
      //   353: pop
      //   354: aload #11
      //   356: aload #12
      //   358: iconst_0
      //   359: invokestatic r : (Lg0/w;Ljava/util/ArrayList;Z)I
      //   362: istore #6
      //   364: iload #6
      //   366: istore_3
      //   367: getstatic com/dimcoms/checkers/MainActivity.m0 : Z
      //   370: ifeq -> 647
      //   373: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   376: getfield v : Lg0/d;
      //   379: invokevirtual c : ()V
      //   382: iload #6
      //   384: istore_3
      //   385: getstatic com/dimcoms/checkers/MainActivity.b0 : Z
      //   388: ifeq -> 647
      //   391: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   394: iconst_0
      //   395: iconst_1
      //   396: invokevirtual r : (ZZ)V
      //   399: getstatic com/dimcoms/checkers/MainActivity.d0 : Ljava/util/ArrayList;
      //   402: astore #10
      //   404: iload #6
      //   406: istore_3
      //   407: aload #10
      //   409: ifnull -> 647
      //   412: aload #10
      //   414: invokevirtual size : ()I
      //   417: istore #4
      //   419: iconst_0
      //   420: istore_3
      //   421: iload_3
      //   422: iload #4
      //   424: if_icmpge -> 534
      //   427: aload #10
      //   429: iload_3
      //   430: invokevirtual get : (I)Ljava/lang/Object;
      //   433: checkcast g0/v
      //   436: getfield k : B
      //   439: istore #5
      //   441: aload #10
      //   443: iload_3
      //   444: invokevirtual get : (I)Ljava/lang/Object;
      //   447: checkcast g0/v
      //   450: getfield l : B
      //   453: istore #7
      //   455: new g0/w
      //   458: dup
      //   459: invokespecial <init> : ()V
      //   462: astore #11
      //   464: aload #11
      //   466: iload #5
      //   468: iload #7
      //   470: invokevirtual a : (II)V
      //   473: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   476: getfield x : Lg0/r;
      //   479: astore #12
      //   481: getstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
      //   484: astore #13
      //   486: aload #12
      //   488: invokevirtual getClass : ()Ljava/lang/Class;
      //   491: pop
      //   492: iload_3
      //   493: istore #5
      //   495: aload #11
      //   497: aload #13
      //   499: iconst_0
      //   500: invokestatic r : (Lg0/w;Ljava/util/ArrayList;Z)I
      //   503: iconst_1
      //   504: if_icmpne -> 526
      //   507: aload #10
      //   509: iload_3
      //   510: invokevirtual remove : (I)Ljava/lang/Object;
      //   513: pop
      //   514: aload #10
      //   516: invokevirtual size : ()I
      //   519: istore #4
      //   521: iload_3
      //   522: iconst_1
      //   523: isub
      //   524: istore #5
      //   526: iload #5
      //   528: iconst_1
      //   529: iadd
      //   530: istore_3
      //   531: goto -> 421
      //   534: aload #10
      //   536: invokevirtual size : ()I
      //   539: istore #5
      //   541: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
      //   544: invokevirtual getClass : ()Ljava/lang/Class;
      //   547: pop
      //   548: iconst_1
      //   549: putstatic com/dimcoms/checkers/MySurfaceView2.d0 : Z
      //   552: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
      //   555: sipush #255
      //   558: sipush #249
      //   561: sipush #238
      //   564: bipush #77
      //   566: invokestatic argb : (IIII)I
      //   569: invokevirtual setColor : (I)V
      //   572: iconst_0
      //   573: istore #4
      //   575: iload #6
      //   577: istore_3
      //   578: iload #4
      //   580: iload #5
      //   582: if_icmpge -> 647
      //   585: aload #10
      //   587: iload #4
      //   589: invokevirtual get : (I)Ljava/lang/Object;
      //   592: checkcast g0/v
      //   595: astore #11
      //   597: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   600: getfield v : Lg0/d;
      //   603: astore #12
      //   605: aload #11
      //   607: getfield k : B
      //   610: istore_3
      //   611: aload #11
      //   613: getfield l : B
      //   616: istore #7
      //   618: aload #12
      //   620: getfield c : [[Z
      //   623: iload_3
      //   624: aaload
      //   625: iload #7
      //   627: iconst_1
      //   628: bastore
      //   629: getstatic com/dimcoms/checkers/MainActivity.G : Lcom/dimcoms/checkers/MainActivity;
      //   632: astore #11
      //   634: iconst_1
      //   635: putstatic com/dimcoms/checkers/MySurfaceView2.W : Z
      //   638: iload #4
      //   640: iconst_1
      //   641: iadd
      //   642: istore #4
      //   644: goto -> 575
      //   647: iload_3
      //   648: iconst_1
      //   649: if_icmpne -> 1292
      //   652: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   655: getfield v : Lg0/d;
      //   658: getfield a : [[I
      //   661: iload_1
      //   662: aaload
      //   663: iload_2
      //   664: iaload
      //   665: istore #5
      //   667: iload #5
      //   669: ifeq -> 1292
      //   672: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
      //   675: ldc '50'
      //   677: invokevirtual equals : (Ljava/lang/Object;)Z
      //   680: istore #9
      //   682: iconst_5
      //   683: istore #4
      //   685: iload #9
      //   687: ifne -> 702
      //   690: iload #5
      //   692: iconst_2
      //   693: if_icmpeq -> 749
      //   696: iload #5
      //   698: iconst_4
      //   699: if_icmpeq -> 749
      //   702: getstatic com/dimcoms/checkers/MainActivity.P0 : Ljava/lang/String;
      //   705: ldc '50'
      //   707: invokevirtual equals : (Ljava/lang/Object;)Z
      //   710: ifeq -> 1292
      //   713: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   716: getfield s : Z
      //   719: ifeq -> 737
      //   722: iload #5
      //   724: iconst_2
      //   725: if_icmpeq -> 749
      //   728: iload #5
      //   730: iconst_4
      //   731: if_icmpne -> 1292
      //   734: goto -> 749
      //   737: iload #5
      //   739: iconst_3
      //   740: if_icmpeq -> 749
      //   743: iload #5
      //   745: iconst_5
      //   746: if_icmpne -> 1292
      //   749: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   752: getfield v : Lg0/d;
      //   755: getfield f : [[Z
      //   758: iload_1
      //   759: aaload
      //   760: iload_2
      //   761: iconst_1
      //   762: bastore
      //   763: iconst_1
      //   764: putstatic com/dimcoms/checkers/MySurfaceView2.e0 : Z
      //   767: getstatic com/dimcoms/checkers/MainActivity.b0 : Z
      //   770: ifeq -> 1292
      //   773: getstatic com/dimcoms/checkers/MainActivity.n0 : Z
      //   776: ifeq -> 1292
      //   779: getstatic com/dimcoms/checkers/MainActivity.p0 : Z
      //   782: ifeq -> 788
      //   785: iconst_2
      //   786: istore #4
      //   788: getstatic com/dimcoms/checkers/MainActivity.h0 : I
      //   791: istore #5
      //   793: iload #5
      //   795: iload #4
      //   797: if_icmpge -> 810
      //   800: iload #5
      //   802: iconst_1
      //   803: iadd
      //   804: putstatic com/dimcoms/checkers/MainActivity.h0 : I
      //   807: goto -> 1292
      //   810: iconst_0
      //   811: putstatic com/dimcoms/checkers/MainActivity.h0 : I
      //   814: getstatic com/dimcoms/checkers/MainActivity.v0 : Z
      //   817: ifne -> 1292
      //   820: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   823: astore #10
      //   825: iconst_1
      //   826: putstatic com/dimcoms/checkers/MainActivity.v0 : Z
      //   829: bipush #8
      //   831: putstatic com/dimcoms/checkers/MainActivity.w0 : I
      //   834: new f0/y
      //   837: dup
      //   838: aload #10
      //   840: invokespecial <init> : (Landroid/content/Context;)V
      //   843: astore #11
      //   845: aload #11
      //   847: iconst_1
      //   848: invokevirtual requestWindowFeature : (I)Z
      //   851: pop
      //   852: aload #11
      //   854: ldc 2131296263
      //   856: invokevirtual setContentView : (I)V
      //   859: aload #11
      //   861: invokevirtual getWindow : ()Landroid/view/Window;
      //   864: astore #12
      //   866: aload #12
      //   868: ifnull -> 878
      //   871: aload #12
      //   873: ldc 17170445
      //   875: invokevirtual setBackgroundDrawableResource : (I)V
      //   878: aload #11
      //   880: iconst_1
      //   881: invokevirtual setCancelable : (Z)V
      //   884: aload #11
      //   886: putstatic com/dimcoms/checkers/MainActivity.V : Lf0/y;
      //   889: aload #11
      //   891: invokevirtual getWindow : ()Landroid/view/Window;
      //   894: bipush #32
      //   896: bipush #32
      //   898: invokevirtual setFlags : (II)V
      //   901: aload #11
      //   903: new f0/b
      //   906: dup
      //   907: invokespecial <init> : ()V
      //   910: invokevirtual setOnCancelListener : (Landroid/content/DialogInterface$OnCancelListener;)V
      //   913: aload #11
      //   915: ldc 2131165433
      //   917: invokevirtual findViewById : (I)Landroid/view/View;
      //   920: checkcast android/widget/RelativeLayout
      //   923: astore #12
      //   925: aload #12
      //   927: ifnull -> 936
      //   930: aload #12
      //   932: iconst_0
      //   933: invokevirtual setVisibility : (I)V
      //   936: aload #11
      //   938: ldc_w 2131165432
      //   941: invokevirtual findViewById : (I)Landroid/view/View;
      //   944: checkcast android/widget/TextView
      //   947: astore #12
      //   949: aload #12
      //   951: ldc_w 2131427388
      //   954: invokevirtual setText : (I)V
      //   957: aload #12
      //   959: iconst_1
      //   960: invokevirtual setGravity : (I)V
      //   963: aload #12
      //   965: iconst_1
      //   966: ldc_w 24.0
      //   969: invokevirtual setTextSize : (IF)V
      //   972: aload #12
      //   974: sipush #255
      //   977: sipush #255
      //   980: sipush #255
      //   983: sipush #255
      //   986: invokestatic argb : (IIII)I
      //   989: invokevirtual setTextColor : (I)V
      //   992: aload #12
      //   994: iconst_0
      //   995: invokevirtual setVisibility : (I)V
      //   998: aload #11
      //   1000: ldc_w 2131165428
      //   1003: invokevirtual findViewById : (I)Landroid/view/View;
      //   1006: checkcast android/widget/TextView
      //   1009: astore #12
      //   1011: aload #12
      //   1013: bipush #17
      //   1015: invokevirtual setGravity : (I)V
      //   1018: aload #12
      //   1020: iconst_1
      //   1021: ldc_w 15.0
      //   1024: invokevirtual setTextSize : (IF)V
      //   1027: aload #12
      //   1029: ldc_w 2131427389
      //   1032: invokevirtual setText : (I)V
      //   1035: aload #12
      //   1037: sipush #150
      //   1040: sipush #255
      //   1043: sipush #255
      //   1046: sipush #255
      //   1049: invokestatic argb : (IIII)I
      //   1052: invokevirtual setTextColor : (I)V
      //   1055: aload #11
      //   1057: invokevirtual getWindow : ()Landroid/view/Window;
      //   1060: iconst_2
      //   1061: invokevirtual clearFlags : (I)V
      //   1064: getstatic com/dimcoms/checkers/MainActivity.S : Landroid/widget/RelativeLayout;
      //   1067: astore #12
      //   1069: aload #12
      //   1071: ifnull -> 1080
      //   1074: aload #12
      //   1076: iconst_0
      //   1077: invokevirtual setVisibility : (I)V
      //   1080: aload #11
      //   1082: ldc_w 2131165356
      //   1085: invokevirtual findViewById : (I)Landroid/view/View;
      //   1088: checkcast android/widget/ImageView
      //   1091: astore #12
      //   1093: aload #12
      //   1095: iconst_0
      //   1096: invokevirtual setVisibility : (I)V
      //   1099: aload #12
      //   1101: ldc_w 2131099789
      //   1104: invokevirtual setImageResource : (I)V
      //   1107: iconst_1
      //   1108: ldc_w 50.0
      //   1111: aload #10
      //   1113: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   1116: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
      //   1119: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
      //   1122: f2i
      //   1123: istore #4
      //   1125: iconst_1
      //   1126: ldc_w 50.0
      //   1129: aload #10
      //   1131: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   1134: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
      //   1137: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
      //   1140: f2i
      //   1141: istore #5
      //   1143: aload #12
      //   1145: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   1148: astore #13
      //   1150: aload #13
      //   1152: iload #4
      //   1154: putfield width : I
      //   1157: aload #13
      //   1159: iload #5
      //   1161: putfield height : I
      //   1164: aload #12
      //   1166: aload #13
      //   1168: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   1171: aload #11
      //   1173: ldc_w 2131165391
      //   1176: invokevirtual findViewById : (I)Landroid/view/View;
      //   1179: checkcast android/widget/Button
      //   1182: astore #12
      //   1184: aload #12
      //   1186: ldc_w 2131427340
      //   1189: invokevirtual setText : (I)V
      //   1192: aload #12
      //   1194: iconst_0
      //   1195: invokevirtual setVisibility : (I)V
      //   1198: aload #12
      //   1200: new f0/c
      //   1203: dup
      //   1204: aload #11
      //   1206: invokespecial <init> : (Lf0/y;)V
      //   1209: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
      //   1212: aload #12
      //   1214: ldc_w 2131099810
      //   1217: invokevirtual setBackgroundResource : (I)V
      //   1220: aload #11
      //   1222: ldc_w 2131165380
      //   1225: invokevirtual findViewById : (I)Landroid/view/View;
      //   1228: checkcast android/widget/Button
      //   1231: astore #12
      //   1233: aload #12
      //   1235: ldc_w 2131427342
      //   1238: invokevirtual setText : (I)V
      //   1241: aload #12
      //   1243: iconst_0
      //   1244: invokevirtual setVisibility : (I)V
      //   1247: aload #10
      //   1249: putstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   1252: aload #11
      //   1254: putstatic com/dimcoms/checkers/a.b : Landroid/app/Dialog;
      //   1257: aload #12
      //   1259: getstatic com/dimcoms/checkers/a.h : Lcom/dimcoms/checkers/a$f;
      //   1262: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
      //   1265: aload #12
      //   1267: ldc_w 2131099808
      //   1270: invokevirtual setBackgroundResource : (I)V
      //   1273: aload #11
      //   1275: invokevirtual show : ()V
      //   1278: iconst_0
      //   1279: putstatic com/dimcoms/checkers/MainActivity.p0 : Z
      //   1282: ldc_w 'Mandatory.xml'
      //   1285: iconst_0
      //   1286: invokestatic valueOf : (I)Ljava/lang/String;
      //   1289: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   1292: iload_3
      //   1293: iconst_2
      //   1294: if_icmpne -> 2750
      //   1297: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   1300: getfield v : Lg0/d;
      //   1303: astore #13
      //   1305: aload #13
      //   1307: iload_1
      //   1308: iload_2
      //   1309: invokevirtual d : (II)V
      //   1312: aload #13
      //   1314: invokevirtual b : ()V
      //   1317: getstatic com/dimcoms/checkers/MainActivity.G : Lcom/dimcoms/checkers/MainActivity;
      //   1320: astore #10
      //   1322: iconst_0
      //   1323: putstatic com/dimcoms/checkers/MySurfaceView2.W : Z
      //   1326: aload #13
      //   1328: invokevirtual c : ()V
      //   1331: aload #13
      //   1333: getfield h : [[Z
      //   1336: iload_1
      //   1337: aaload
      //   1338: iload_2
      //   1339: iconst_0
      //   1340: bastore
      //   1341: iconst_0
      //   1342: istore_3
      //   1343: iload_3
      //   1344: aload #13
      //   1346: getfield j : I
      //   1349: if_icmpge -> 1392
      //   1352: iconst_0
      //   1353: istore #4
      //   1355: iload #4
      //   1357: aload #13
      //   1359: getfield j : I
      //   1362: if_icmpge -> 1385
      //   1365: aload #13
      //   1367: getfield e : [[Z
      //   1370: iload_3
      //   1371: aaload
      //   1372: iload #4
      //   1374: iconst_0
      //   1375: bastore
      //   1376: iload #4
      //   1378: iconst_1
      //   1379: iadd
      //   1380: istore #4
      //   1382: goto -> 1355
      //   1385: iload_3
      //   1386: iconst_1
      //   1387: iadd
      //   1388: istore_3
      //   1389: goto -> 1343
      //   1392: aload #13
      //   1394: getfield e : [[Z
      //   1397: iload_1
      //   1398: aaload
      //   1399: iload_2
      //   1400: iconst_1
      //   1401: bastore
      //   1402: new g0/z
      //   1405: dup
      //   1406: iload_1
      //   1407: iload_2
      //   1408: invokespecial <init> : (II)V
      //   1411: astore #10
      //   1413: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   1416: aload #10
      //   1418: invokevirtual add : (Ljava/lang/Object;)Z
      //   1421: pop
      //   1422: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   1425: iconst_0
      //   1426: invokevirtual b : (I)Lg0/z;
      //   1429: getfield a : I
      //   1432: istore_3
      //   1433: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   1436: iconst_0
      //   1437: invokevirtual b : (I)Lg0/z;
      //   1440: getfield b : I
      //   1443: istore #4
      //   1445: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   1448: iload_3
      //   1449: iload #4
      //   1451: invokevirtual h : (II)Lg0/v;
      //   1454: astore #10
      //   1456: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   1459: invokevirtual size : ()I
      //   1462: iconst_1
      //   1463: if_icmpne -> 2181
      //   1466: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   1469: getfield x : Lg0/r;
      //   1472: astore #14
      //   1474: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   1477: astore #12
      //   1479: aload #14
      //   1481: invokevirtual getClass : ()Ljava/lang/Class;
      //   1484: pop
      //   1485: aload #14
      //   1487: aload #10
      //   1489: aload #12
      //   1491: iconst_1
      //   1492: invokevirtual f : (Lg0/v;Lg0/b;Z)Ljava/util/ArrayList;
      //   1495: astore #11
      //   1497: aload #14
      //   1499: getfield k : Z
      //   1502: ifne -> 1512
      //   1505: aload #11
      //   1507: astore #10
      //   1509: goto -> 2176
      //   1512: aload #11
      //   1514: astore #10
      //   1516: getstatic com/dimcoms/checkers/MainActivity.n0 : Z
      //   1519: ifeq -> 2176
      //   1522: aload #11
      //   1524: astore #10
      //   1526: aload #11
      //   1528: ifnull -> 2176
      //   1531: aload #11
      //   1533: invokevirtual size : ()I
      //   1536: iconst_1
      //   1537: isub
      //   1538: istore_3
      //   1539: iconst_0
      //   1540: istore #5
      //   1542: iload_3
      //   1543: iflt -> 1648
      //   1546: aload #11
      //   1548: iload_3
      //   1549: invokevirtual get : (I)Ljava/lang/Object;
      //   1552: checkcast g0/w
      //   1555: invokevirtual c : ()I
      //   1558: iload #5
      //   1560: if_icmpge -> 1577
      //   1563: aload #11
      //   1565: iload_3
      //   1566: invokevirtual remove : (I)Ljava/lang/Object;
      //   1569: pop
      //   1570: iload #5
      //   1572: istore #4
      //   1574: goto -> 2807
      //   1577: iload #5
      //   1579: istore #4
      //   1581: aload #11
      //   1583: iload_3
      //   1584: invokevirtual get : (I)Ljava/lang/Object;
      //   1587: checkcast g0/w
      //   1590: invokevirtual c : ()I
      //   1593: iload #5
      //   1595: if_icmple -> 2807
      //   1598: aload #11
      //   1600: iload_3
      //   1601: invokevirtual get : (I)Ljava/lang/Object;
      //   1604: checkcast g0/w
      //   1607: invokevirtual c : ()I
      //   1610: istore #6
      //   1612: aload #11
      //   1614: invokevirtual size : ()I
      //   1617: iconst_1
      //   1618: isub
      //   1619: istore #5
      //   1621: iload #6
      //   1623: istore #4
      //   1625: iload #5
      //   1627: iload_3
      //   1628: if_icmple -> 2807
      //   1631: aload #11
      //   1633: iload #5
      //   1635: invokevirtual remove : (I)Ljava/lang/Object;
      //   1638: pop
      //   1639: iload #5
      //   1641: iconst_1
      //   1642: isub
      //   1643: istore #5
      //   1645: goto -> 1621
      //   1648: aload #11
      //   1650: astore #10
      //   1652: aload #14
      //   1654: instanceof g0/h
      //   1657: ifeq -> 2176
      //   1660: aload #11
      //   1662: invokevirtual size : ()I
      //   1665: iconst_1
      //   1666: isub
      //   1667: istore_3
      //   1668: iload_3
      //   1669: iflt -> 2825
      //   1672: aload #11
      //   1674: iload_3
      //   1675: invokevirtual get : (I)Ljava/lang/Object;
      //   1678: checkcast g0/w
      //   1681: astore #10
      //   1683: aload #10
      //   1685: invokevirtual c : ()I
      //   1688: ifle -> 2818
      //   1691: aload #10
      //   1693: iconst_0
      //   1694: invokevirtual b : (I)Lg0/z;
      //   1697: astore #10
      //   1699: aload #12
      //   1701: aload #10
      //   1703: getfield a : I
      //   1706: aload #10
      //   1708: getfield b : I
      //   1711: invokevirtual h : (II)Lg0/v;
      //   1714: getfield j : I
      //   1717: iconst_2
      //   1718: if_icmpne -> 2818
      //   1721: iconst_1
      //   1722: istore_3
      //   1723: goto -> 1726
      //   1726: iload_3
      //   1727: ifeq -> 1801
      //   1730: aload #11
      //   1732: invokevirtual size : ()I
      //   1735: iconst_1
      //   1736: isub
      //   1737: istore_3
      //   1738: iload_3
      //   1739: iflt -> 1801
      //   1742: aload #11
      //   1744: iload_3
      //   1745: invokevirtual get : (I)Ljava/lang/Object;
      //   1748: checkcast g0/w
      //   1751: astore #10
      //   1753: aload #10
      //   1755: invokevirtual c : ()I
      //   1758: ifle -> 2830
      //   1761: aload #10
      //   1763: iconst_0
      //   1764: invokevirtual b : (I)Lg0/z;
      //   1767: astore #10
      //   1769: aload #12
      //   1771: aload #10
      //   1773: getfield a : I
      //   1776: aload #10
      //   1778: getfield b : I
      //   1781: invokevirtual h : (II)Lg0/v;
      //   1784: getfield j : I
      //   1787: iconst_1
      //   1788: if_icmpne -> 2830
      //   1791: aload #11
      //   1793: iload_3
      //   1794: invokevirtual remove : (I)Ljava/lang/Object;
      //   1797: pop
      //   1798: goto -> 2830
      //   1801: new java/util/ArrayList
      //   1804: dup
      //   1805: invokespecial <init> : ()V
      //   1808: astore #14
      //   1810: aload #11
      //   1812: invokevirtual size : ()I
      //   1815: iconst_1
      //   1816: isub
      //   1817: istore #4
      //   1819: iconst_0
      //   1820: istore #5
      //   1822: iload #4
      //   1824: iflt -> 1972
      //   1827: aload #11
      //   1829: iload #4
      //   1831: invokevirtual get : (I)Ljava/lang/Object;
      //   1834: checkcast g0/w
      //   1837: astore #10
      //   1839: iconst_0
      //   1840: istore #7
      //   1842: iconst_0
      //   1843: istore_3
      //   1844: iload #7
      //   1846: aload #10
      //   1848: invokevirtual c : ()I
      //   1851: iconst_1
      //   1852: isub
      //   1853: if_icmpge -> 1929
      //   1856: aload #10
      //   1858: iload #7
      //   1860: invokevirtual b : (I)Lg0/z;
      //   1863: astore #15
      //   1865: iload #7
      //   1867: iconst_1
      //   1868: iadd
      //   1869: istore #7
      //   1871: aload #10
      //   1873: iload #7
      //   1875: invokevirtual b : (I)Lg0/z;
      //   1878: astore #16
      //   1880: iload_3
      //   1881: istore #6
      //   1883: aload #12
      //   1885: aload #16
      //   1887: getfield a : I
      //   1890: aload #15
      //   1892: getfield a : I
      //   1895: iadd
      //   1896: iconst_2
      //   1897: idiv
      //   1898: aload #16
      //   1900: getfield b : I
      //   1903: aload #15
      //   1905: getfield b : I
      //   1908: iadd
      //   1909: iconst_2
      //   1910: idiv
      //   1911: invokevirtual h : (II)Lg0/v;
      //   1914: getfield j : I
      //   1917: iconst_2
      //   1918: if_icmpne -> 2837
      //   1921: iload_3
      //   1922: iconst_1
      //   1923: iadd
      //   1924: istore #6
      //   1926: goto -> 2837
      //   1929: iload_3
      //   1930: iload #5
      //   1932: if_icmpne -> 1943
      //   1935: aload #14
      //   1937: aload #10
      //   1939: invokevirtual add : (Ljava/lang/Object;)Z
      //   1942: pop
      //   1943: iload #5
      //   1945: istore #6
      //   1947: iload_3
      //   1948: iload #5
      //   1950: if_icmple -> 2843
      //   1953: aload #14
      //   1955: invokevirtual clear : ()V
      //   1958: aload #14
      //   1960: aload #10
      //   1962: invokevirtual add : (Ljava/lang/Object;)Z
      //   1965: pop
      //   1966: iload_3
      //   1967: istore #6
      //   1969: goto -> 2843
      //   1972: new java/util/ArrayList
      //   1975: dup
      //   1976: invokespecial <init> : ()V
      //   1979: astore #10
      //   1981: aload #14
      //   1983: invokevirtual size : ()I
      //   1986: iconst_1
      //   1987: isub
      //   1988: istore #6
      //   1990: iconst_0
      //   1991: istore #4
      //   1993: iload #6
      //   1995: iflt -> 2154
      //   1998: aload #14
      //   2000: iload #6
      //   2002: invokevirtual get : (I)Ljava/lang/Object;
      //   2005: checkcast g0/w
      //   2008: astore #15
      //   2010: iconst_0
      //   2011: istore_3
      //   2012: iload_3
      //   2013: aload #15
      //   2015: invokevirtual c : ()I
      //   2018: iconst_1
      //   2019: isub
      //   2020: if_icmpge -> 2862
      //   2023: aload #15
      //   2025: iload_3
      //   2026: invokevirtual b : (I)Lg0/z;
      //   2029: astore #16
      //   2031: iload_3
      //   2032: iconst_1
      //   2033: iadd
      //   2034: istore #5
      //   2036: aload #15
      //   2038: iload #5
      //   2040: invokevirtual b : (I)Lg0/z;
      //   2043: astore #17
      //   2045: aload #12
      //   2047: aload #17
      //   2049: getfield a : I
      //   2052: aload #16
      //   2054: getfield a : I
      //   2057: iadd
      //   2058: iconst_2
      //   2059: idiv
      //   2060: aload #17
      //   2062: getfield b : I
      //   2065: aload #16
      //   2067: getfield b : I
      //   2070: iadd
      //   2071: iconst_2
      //   2072: idiv
      //   2073: invokevirtual h : (II)Lg0/v;
      //   2076: getfield j : I
      //   2079: iconst_2
      //   2080: if_icmpne -> 2856
      //   2083: goto -> 2086
      //   2086: iload #4
      //   2088: istore #5
      //   2090: iload #6
      //   2092: aload #14
      //   2094: invokevirtual size : ()I
      //   2097: iconst_1
      //   2098: isub
      //   2099: if_icmpne -> 2105
      //   2102: iload_3
      //   2103: istore #5
      //   2105: iload_3
      //   2106: iload #5
      //   2108: if_icmpne -> 2119
      //   2111: aload #10
      //   2113: aload #15
      //   2115: invokevirtual add : (Ljava/lang/Object;)Z
      //   2118: pop
      //   2119: iload #5
      //   2121: istore #4
      //   2123: iload_3
      //   2124: iload #5
      //   2126: if_icmpge -> 2145
      //   2129: aload #10
      //   2131: invokevirtual clear : ()V
      //   2134: aload #10
      //   2136: aload #15
      //   2138: invokevirtual add : (Ljava/lang/Object;)Z
      //   2141: pop
      //   2142: iload_3
      //   2143: istore #4
      //   2145: iload #6
      //   2147: iconst_1
      //   2148: isub
      //   2149: istore #6
      //   2151: goto -> 1993
      //   2154: goto -> 2176
      //   2157: astore #12
      //   2159: aload #11
      //   2161: astore #10
      //   2163: goto -> 2171
      //   2166: astore #12
      //   2168: aconst_null
      //   2169: astore #10
      //   2171: aload #12
      //   2173: invokevirtual printStackTrace : ()V
      //   2176: aload #10
      //   2178: putstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2181: getstatic com/dimcoms/checkers/MainActivity.m0 : Z
      //   2184: ifeq -> 2581
      //   2187: iconst_0
      //   2188: istore_3
      //   2189: iload_3
      //   2190: aload #13
      //   2192: getfield j : I
      //   2195: if_icmpge -> 2246
      //   2198: iconst_0
      //   2199: istore #4
      //   2201: iload #4
      //   2203: aload #13
      //   2205: getfield j : I
      //   2208: if_icmpge -> 2239
      //   2211: aload #13
      //   2213: getfield h : [[Z
      //   2216: iload_3
      //   2217: aaload
      //   2218: iload #4
      //   2220: baload
      //   2221: iconst_1
      //   2222: if_icmpne -> 2230
      //   2225: iconst_1
      //   2226: istore_3
      //   2227: goto -> 2248
      //   2230: iload #4
      //   2232: iconst_1
      //   2233: iadd
      //   2234: istore #4
      //   2236: goto -> 2201
      //   2239: iload_3
      //   2240: iconst_1
      //   2241: iadd
      //   2242: istore_3
      //   2243: goto -> 2189
      //   2246: iconst_0
      //   2247: istore_3
      //   2248: iload_3
      //   2249: ifne -> 2581
      //   2252: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2255: ifnull -> 2581
      //   2258: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2261: invokevirtual size : ()I
      //   2264: istore #8
      //   2266: iconst_0
      //   2267: istore #4
      //   2269: iload #4
      //   2271: iload #8
      //   2273: if_icmpge -> 2400
      //   2276: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2279: invokevirtual size : ()I
      //   2282: istore #5
      //   2284: iconst_0
      //   2285: istore_3
      //   2286: iload_3
      //   2287: iload #5
      //   2289: if_icmpge -> 2391
      //   2292: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2295: iload_3
      //   2296: invokevirtual get : (I)Ljava/lang/Object;
      //   2299: checkcast g0/w
      //   2302: iload #4
      //   2304: invokevirtual b : (I)Lg0/z;
      //   2307: astore #10
      //   2309: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2312: iload #4
      //   2314: invokevirtual get : (I)Ljava/lang/Object;
      //   2317: checkcast g0/z
      //   2320: getfield a : I
      //   2323: aload #10
      //   2325: getfield a : I
      //   2328: if_icmpne -> 2360
      //   2331: iload #5
      //   2333: istore #6
      //   2335: iload_3
      //   2336: istore #7
      //   2338: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2341: iload #4
      //   2343: invokevirtual get : (I)Ljava/lang/Object;
      //   2346: checkcast g0/z
      //   2349: getfield b : I
      //   2352: aload #10
      //   2354: getfield b : I
      //   2357: if_icmpeq -> 2379
      //   2360: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2363: iload_3
      //   2364: invokevirtual remove : (I)Ljava/lang/Object;
      //   2367: pop
      //   2368: iload_3
      //   2369: iconst_1
      //   2370: isub
      //   2371: istore #7
      //   2373: iload #5
      //   2375: iconst_1
      //   2376: isub
      //   2377: istore #6
      //   2379: iload #7
      //   2381: iconst_1
      //   2382: iadd
      //   2383: istore_3
      //   2384: iload #6
      //   2386: istore #5
      //   2388: goto -> 2286
      //   2391: iload #4
      //   2393: iconst_1
      //   2394: iadd
      //   2395: istore #4
      //   2397: goto -> 2269
      //   2400: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2403: invokevirtual size : ()I
      //   2406: istore #6
      //   2408: iconst_0
      //   2409: istore_3
      //   2410: iload_3
      //   2411: iload #6
      //   2413: if_icmpge -> 2581
      //   2416: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
      //   2419: iload_3
      //   2420: invokevirtual get : (I)Ljava/lang/Object;
      //   2423: checkcast g0/w
      //   2426: astore #10
      //   2428: aload #10
      //   2430: invokevirtual c : ()I
      //   2433: istore #7
      //   2435: iconst_0
      //   2436: istore #4
      //   2438: iload #4
      //   2440: iload #7
      //   2442: if_icmpge -> 2574
      //   2445: aload #10
      //   2447: iload #4
      //   2449: invokevirtual b : (I)Lg0/z;
      //   2452: astore #11
      //   2454: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2457: invokevirtual size : ()I
      //   2460: istore #8
      //   2462: iconst_0
      //   2463: istore #5
      //   2465: iload #5
      //   2467: iload #8
      //   2469: if_icmpge -> 2531
      //   2472: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2475: iload #5
      //   2477: invokevirtual get : (I)Ljava/lang/Object;
      //   2480: checkcast g0/z
      //   2483: getfield a : I
      //   2486: aload #11
      //   2488: getfield a : I
      //   2491: if_icmpne -> 2522
      //   2494: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2497: iload #5
      //   2499: invokevirtual get : (I)Ljava/lang/Object;
      //   2502: checkcast g0/z
      //   2505: getfield b : I
      //   2508: aload #11
      //   2510: getfield b : I
      //   2513: if_icmpne -> 2522
      //   2516: iconst_0
      //   2517: istore #5
      //   2519: goto -> 2534
      //   2522: iload #5
      //   2524: iconst_1
      //   2525: iadd
      //   2526: istore #5
      //   2528: goto -> 2465
      //   2531: iconst_1
      //   2532: istore #5
      //   2534: iload #5
      //   2536: ifeq -> 2565
      //   2539: aload #11
      //   2541: getfield a : I
      //   2544: istore #5
      //   2546: aload #11
      //   2548: getfield b : I
      //   2551: istore #8
      //   2553: aload #13
      //   2555: getfield d : [[Z
      //   2558: iload #5
      //   2560: aaload
      //   2561: iload #8
      //   2563: iconst_1
      //   2564: bastore
      //   2565: iload #4
      //   2567: iconst_1
      //   2568: iadd
      //   2569: istore #4
      //   2571: goto -> 2438
      //   2574: iload_3
      //   2575: iconst_1
      //   2576: iadd
      //   2577: istore_3
      //   2578: goto -> 2410
      //   2581: getstatic com/dimcoms/checkers/MainActivity.j0 : I
      //   2584: istore_3
      //   2585: iload_3
      //   2586: bipush #8
      //   2588: if_icmpeq -> 2597
      //   2591: iload_3
      //   2592: bipush #7
      //   2594: if_icmpne -> 2735
      //   2597: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2600: invokevirtual size : ()I
      //   2603: istore_3
      //   2604: iload_3
      //   2605: iconst_1
      //   2606: if_icmple -> 2735
      //   2609: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   2612: invokevirtual c : ()I
      //   2615: iload_3
      //   2616: if_icmplt -> 2735
      //   2619: getstatic com/dimcoms/checkers/MainActivity.R0 : Lg0/w;
      //   2622: iload_3
      //   2623: iconst_2
      //   2624: isub
      //   2625: invokevirtual b : (I)Lg0/z;
      //   2628: astore #11
      //   2630: aload #13
      //   2632: getfield i : Lg0/b;
      //   2635: astore #10
      //   2637: iload_3
      //   2638: iconst_2
      //   2639: if_icmpne -> 2654
      //   2642: new g0/b
      //   2645: dup
      //   2646: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   2649: invokespecial <init> : (Lg0/b;)V
      //   2652: astore #10
      //   2654: aload #10
      //   2656: aload #11
      //   2658: getfield a : I
      //   2661: aload #11
      //   2663: getfield b : I
      //   2666: iload_1
      //   2667: iload_2
      //   2668: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
      //   2671: getfield s : Z
      //   2674: iconst_1
      //   2675: ixor
      //   2676: iconst_1
      //   2677: iconst_1
      //   2678: invokevirtual c : (IIIIZZZ)V
      //   2681: new g0/d
      //   2684: dup
      //   2685: aload #10
      //   2687: aload #13
      //   2689: getfield b : [[Z
      //   2692: aload #13
      //   2694: getfield c : [[Z
      //   2697: aload #13
      //   2699: getfield d : [[Z
      //   2702: aload #13
      //   2704: getfield e : [[Z
      //   2707: aload #13
      //   2709: getfield f : [[Z
      //   2712: aload #13
      //   2714: getfield g : [[Z
      //   2717: aload #13
      //   2719: getfield h : [[Z
      //   2722: invokespecial <init> : (Lg0/b;[[Z[[Z[[Z[[Z[[Z[[Z[[Z)V
      //   2725: astore #10
      //   2727: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   2730: aload #10
      //   2732: putfield v : Lg0/d;
      //   2735: getstatic com/dimcoms/checkers/MainActivity.P : Lcom/dimcoms/checkers/MySurfaceView2;
      //   2738: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   2741: getfield v : Lg0/d;
      //   2744: invokevirtual setBoardTable : (Lg0/d;)V
      //   2747: goto -> 2800
      //   2750: iload_3
      //   2751: iconst_3
      //   2752: if_icmpne -> 2800
      //   2755: iconst_0
      //   2756: putstatic com/dimcoms/checkers/MainActivity.O0 : Z
      //   2759: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   2762: invokevirtual G : ()V
      //   2765: getstatic com/dimcoms/checkers/MainActivity.f0 : Ljava/util/ArrayList;
      //   2768: invokevirtual clear : ()V
      //   2771: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   2774: astore #10
      //   2776: aload #10
      //   2778: iconst_0
      //   2779: putfield s : I
      //   2782: aload #10
      //   2784: iconst_1
      //   2785: putfield q : Z
      //   2788: iconst_1
      //   2789: invokestatic i : (Z)V
      //   2792: getstatic com/dimcoms/checkers/MainActivity.a0 : Lcom/dimcoms/checkers/MainActivity$o;
      //   2795: iconst_1
      //   2796: invokevirtual sendEmptyMessage : (I)Z
      //   2799: pop
      //   2800: getstatic com/dimcoms/checkers/a.a : Lcom/dimcoms/checkers/MainActivity;
      //   2803: invokevirtual m : ()V
      //   2806: return
      //   2807: iload_3
      //   2808: iconst_1
      //   2809: isub
      //   2810: istore_3
      //   2811: iload #4
      //   2813: istore #5
      //   2815: goto -> 1542
      //   2818: iload_3
      //   2819: iconst_1
      //   2820: isub
      //   2821: istore_3
      //   2822: goto -> 1668
      //   2825: iconst_0
      //   2826: istore_3
      //   2827: goto -> 1726
      //   2830: iload_3
      //   2831: iconst_1
      //   2832: isub
      //   2833: istore_3
      //   2834: goto -> 1738
      //   2837: iload #6
      //   2839: istore_3
      //   2840: goto -> 1844
      //   2843: iload #4
      //   2845: iconst_1
      //   2846: isub
      //   2847: istore #4
      //   2849: iload #6
      //   2851: istore #5
      //   2853: goto -> 1822
      //   2856: iload #5
      //   2858: istore_3
      //   2859: goto -> 2012
      //   2862: iconst_0
      //   2863: istore_3
      //   2864: goto -> 2086
      // Exception table:
      //   from	to	target	type
      //   1485	1497	2166	g0/f
      //   1497	1505	2157	g0/f
      //   1516	1522	2157	g0/f
      //   1531	1539	2157	g0/f
      //   1546	1570	2157	g0/f
      //   1581	1621	2157	g0/f
      //   1631	1639	2157	g0/f
      //   1652	1668	2157	g0/f
      //   1672	1721	2157	g0/f
      //   1730	1738	2157	g0/f
      //   1742	1798	2157	g0/f
      //   1801	1819	2157	g0/f
      //   1827	1839	2157	g0/f
      //   1844	1865	2157	g0/f
      //   1871	1880	2157	g0/f
      //   1883	1921	2157	g0/f
      //   1935	1943	2157	g0/f
      //   1953	1966	2157	g0/f
      //   1972	1990	2157	g0/f
      //   1998	2010	2157	g0/f
      //   2012	2031	2157	g0/f
      //   2036	2083	2157	g0/f
      //   2090	2102	2157	g0/f
      //   2111	2119	2157	g0/f
      //   2129	2142	2157	g0/f
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */