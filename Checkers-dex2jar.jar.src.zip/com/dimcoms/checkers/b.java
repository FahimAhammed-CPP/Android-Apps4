package com.dimcoms.checkers;

import android.graphics.Color;

public final class b extends Thread {
  public final void run() {
    int i = 255;
    while (true) {
      int j;
      try {
        Thread.sleep(5L);
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
      if (MySurfaceView2.d0) {
        MySurfaceView2.d0 = false;
        i = -255;
      } 
      if (i <= -255) {
        try {
          Thread.sleep(2000L);
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
        j = 255;
      } else {
        j = i - 1;
      } 
      MySurfaceView2.M.setColor(Color.argb(Math.abs(j), 249, 238, 77));
      i = j;
      if (MySurfaceView2.W) {
        MainActivity.a0.sendEmptyMessage(5);
        i = j;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */