package com.dimcoms.checkers;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceView;
import androidx.lifecycle.b;
import g0.d;

public class MySurfaceView2 extends SurfaceView {
  public static int[] H;
  
  public static int I;
  
  public static Paint J = new Paint();
  
  public static Paint K = new Paint();
  
  public static Paint L = new Paint();
  
  public static Paint M = new Paint();
  
  public static Paint N = new Paint();
  
  public static Paint O = new Paint();
  
  public static Paint P = new Paint();
  
  public static Paint Q = new Paint();
  
  public static int R = 8;
  
  public static Matrix S = null;
  
  public static int T;
  
  public static int U;
  
  public static int V;
  
  public static boolean W = false;
  
  public static boolean a0 = false;
  
  public static b b0 = null;
  
  public static c c0 = null;
  
  public static boolean d0 = false;
  
  public static boolean e0 = false;
  
  public float A;
  
  public float B;
  
  public float C;
  
  public int D;
  
  public boolean E;
  
  public boolean F;
  
  public Handler G;
  
  public long a;
  
  public long b;
  
  public long c;
  
  public long d;
  
  public int e = 0;
  
  public float f = 0.0F;
  
  public float g = 0.0F;
  
  public float h = 0.0F;
  
  public float i = 0.0F;
  
  public float j = 0.0F;
  
  public float k = 0.0F;
  
  public int l = 0;
  
  public int m = 220;
  
  public long n = 0L;
  
  public Bitmap o = null;
  
  public Bitmap p = null;
  
  public Bitmap q = null;
  
  public Bitmap r = null;
  
  public Bitmap s = null;
  
  public Bitmap t = null;
  
  public Bitmap u = null;
  
  public float v = 0.0F;
  
  public d w = null;
  
  public MainActivity.p x;
  
  public boolean y = true;
  
  public Paint z = new Paint();
  
  public MySurfaceView2(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    new Paint();
    this.A = 0.0F;
    this.B = 0.0F;
    this.E = false;
    this.F = false;
    this.G = new Handler();
    boolean bool = MainActivity.P0.equals("50");
    this.E = bool;
    if (MainActivity.I && !bool) {
      setBackgroundColor(0);
      setZOrderOnTop(true);
      getHolder().setFormat(-2);
    } 
    this.z.setAntiAlias(true);
    this.z.setColor(Color.argb(200, 220, 0, 20));
    J.setAntiAlias(true);
    J.setFilterBitmap(true);
    J.setDither(true);
    L.setColor(Color.argb(120, 23, 149, 16));
    L.setAntiAlias(true);
    L.setFilterBitmap(true);
    L.setDither(true);
    M.setColor(Color.argb(255, 249, 238, 77));
    M.setAntiAlias(true);
    M.setFilterBitmap(true);
    M.setDither(true);
    N.setColor(Color.argb(150, 200, 0, 18));
    N.setAntiAlias(true);
    N.setFilterBitmap(true);
    N.setDither(true);
    O.setColor(Color.argb(150, 200, 0, 18));
    O.setAntiAlias(true);
    O.setFilterBitmap(true);
    O.setDither(true);
    P.setColor(Color.argb(200, 23, 61, 107));
    P.setAntiAlias(true);
    P.setFilterBitmap(true);
    P.setDither(true);
    Q.setColor(Color.argb(255, 42, 175, 247));
    Q.setAntiAlias(true);
    Q.setFilterBitmap(true);
    Q.setDither(true);
    W = false;
    if (b0 == null) {
      b b1 = new b();
      b0 = b1;
      b1.start();
    } 
    if (c0 == null) {
      c c1 = new c();
      c0 = c1;
      c1.start();
    } 
    K.setAntiAlias(true);
    K.setFilterBitmap(true);
    K.setDither(true);
    K.setColor(-16777216);
    K.setStyle(Paint.Style.STROKE);
    K.setStrokeWidth(0.5F);
    int i = MainActivity.Q;
    this.D = i;
    int j = MainActivity.R;
    if (i > j)
      this.D = j; 
    T = MainActivity.Q;
    U = MainActivity.R;
    V = T;
    bool = MainActivity.I;
    if (bool && !this.E) {
      i = T;
      j = (int)(i * 0.32F) + i;
      V = j;
      int k = j / 4;
      int m = U;
      if (k + j > m)
        V = (m - i) / 2 + i; 
    } else {
      i = V;
      j = i / 4;
      if (j + i > U)
        V = i - j; 
    } 
    if (bool && !this.E) {
      Matrix matrix = new Matrix();
      S = matrix;
      i = V;
      float f1 = i;
      float f2 = f1 / 8.25F;
      j = T;
      float f3 = (int)(j - f1 / 1.32F);
      float f4 = (j - i / 30);
      matrix.setPolyToPoly(new float[] { 0.0F, 0.0F, f1, 0.0F, f1, f1, 0.0F, f1 }, 0, new float[] { f2, f3, f1 - f2, f3, f1, f4, 0.0F, f4 }, 0, 4);
    } 
  }
  
  public static int d(int paramInt) {
    int[] arrayOfInt = k();
    if (paramInt != 0)
      return arrayOfInt[paramInt - 1]; 
    throw null;
  }
  
  public static void f(Canvas paramCanvas, Bitmap paramBitmap, int paramInt, RectF paramRectF, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 719
    //   4: aload_0
    //   5: ifnull -> 719
    //   8: aload_3
    //   9: getfield left : F
    //   12: fstore #6
    //   14: aload_3
    //   15: getfield top : F
    //   18: fstore #10
    //   20: aload_3
    //   21: getfield right : F
    //   24: fstore #7
    //   26: aload_3
    //   27: getfield bottom : F
    //   30: fstore #5
    //   32: new android/graphics/Matrix
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: astore_3
    //   40: bipush #8
    //   42: newarray float
    //   44: astore #12
    //   46: iload #4
    //   48: ifeq -> 104
    //   51: aload #12
    //   53: iconst_0
    //   54: fload #6
    //   56: fastore
    //   57: aload #12
    //   59: iconst_1
    //   60: fload #10
    //   62: fastore
    //   63: aload #12
    //   65: iconst_2
    //   66: fload #7
    //   68: fastore
    //   69: aload #12
    //   71: iconst_3
    //   72: fload #10
    //   74: fastore
    //   75: aload #12
    //   77: iconst_4
    //   78: fload #7
    //   80: fastore
    //   81: aload #12
    //   83: iconst_5
    //   84: fload #5
    //   86: fastore
    //   87: aload #12
    //   89: bipush #6
    //   91: fload #6
    //   93: fastore
    //   94: aload #12
    //   96: bipush #7
    //   98: fload #5
    //   100: fastore
    //   101: goto -> 208
    //   104: fload #7
    //   106: fload #6
    //   108: fsub
    //   109: ldc_w 15.0
    //   112: fdiv
    //   113: fstore #8
    //   115: fload #6
    //   117: fload #8
    //   119: fadd
    //   120: fstore #6
    //   122: aload #12
    //   124: iconst_0
    //   125: fload #6
    //   127: fastore
    //   128: fload #5
    //   130: fload #10
    //   132: fsub
    //   133: fstore #9
    //   135: fload #9
    //   137: ldc_w 15.0
    //   140: fdiv
    //   141: fload #10
    //   143: fadd
    //   144: fstore #10
    //   146: aload #12
    //   148: iconst_1
    //   149: fload #10
    //   151: fastore
    //   152: fload #7
    //   154: fload #8
    //   156: fsub
    //   157: fstore #7
    //   159: aload #12
    //   161: iconst_2
    //   162: fload #7
    //   164: fastore
    //   165: aload #12
    //   167: iconst_3
    //   168: fload #10
    //   170: fastore
    //   171: aload #12
    //   173: iconst_4
    //   174: fload #7
    //   176: fastore
    //   177: fload #5
    //   179: fload #9
    //   181: ldc_w 7.0
    //   184: fdiv
    //   185: fsub
    //   186: fstore #5
    //   188: aload #12
    //   190: iconst_5
    //   191: fload #5
    //   193: fastore
    //   194: aload #12
    //   196: bipush #6
    //   198: fload #6
    //   200: fastore
    //   201: aload #12
    //   203: bipush #7
    //   205: fload #5
    //   207: fastore
    //   208: iconst_0
    //   209: aload_1
    //   210: invokevirtual getWidth : ()I
    //   213: bipush #25
    //   215: idiv
    //   216: isub
    //   217: i2f
    //   218: fstore #5
    //   220: aload_1
    //   221: invokevirtual getWidth : ()I
    //   224: i2f
    //   225: fstore #6
    //   227: iconst_0
    //   228: aload_1
    //   229: invokevirtual getWidth : ()I
    //   232: bipush #25
    //   234: idiv
    //   235: isub
    //   236: i2f
    //   237: fstore #7
    //   239: aload_1
    //   240: invokevirtual getWidth : ()I
    //   243: i2f
    //   244: fstore #8
    //   246: aload_1
    //   247: invokevirtual getHeight : ()I
    //   250: istore #11
    //   252: aload_1
    //   253: invokevirtual getWidth : ()I
    //   256: bipush #10
    //   258: idiv
    //   259: iload #11
    //   261: iadd
    //   262: i2f
    //   263: fstore #9
    //   265: aload_1
    //   266: invokevirtual getHeight : ()I
    //   269: istore #11
    //   271: aload_3
    //   272: bipush #8
    //   274: newarray float
    //   276: dup
    //   277: iconst_0
    //   278: fconst_0
    //   279: fastore
    //   280: dup
    //   281: iconst_1
    //   282: fload #5
    //   284: fastore
    //   285: dup
    //   286: iconst_2
    //   287: fload #6
    //   289: fastore
    //   290: dup
    //   291: iconst_3
    //   292: fload #7
    //   294: fastore
    //   295: dup
    //   296: iconst_4
    //   297: fload #8
    //   299: fastore
    //   300: dup
    //   301: iconst_5
    //   302: fload #9
    //   304: fastore
    //   305: dup
    //   306: bipush #6
    //   308: fconst_0
    //   309: fastore
    //   310: dup
    //   311: bipush #7
    //   313: aload_1
    //   314: invokevirtual getWidth : ()I
    //   317: bipush #10
    //   319: idiv
    //   320: iload #11
    //   322: iadd
    //   323: i2f
    //   324: fastore
    //   325: iconst_0
    //   326: aload #12
    //   328: iconst_0
    //   329: iconst_4
    //   330: invokevirtual setPolyToPoly : ([FI[FII)Z
    //   333: pop
    //   334: iload #4
    //   336: ifeq -> 710
    //   339: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   342: bipush #8
    //   344: if_icmpne -> 491
    //   347: iload_2
    //   348: ifne -> 373
    //   351: aload_3
    //   352: ldc_w -10.0
    //   355: aload_1
    //   356: invokevirtual getWidth : ()I
    //   359: iconst_2
    //   360: idiv
    //   361: i2f
    //   362: aload_1
    //   363: invokevirtual getHeight : ()I
    //   366: iconst_2
    //   367: idiv
    //   368: i2f
    //   369: invokevirtual preRotate : (FFF)Z
    //   372: pop
    //   373: iload_2
    //   374: iconst_1
    //   375: if_icmpne -> 400
    //   378: aload_3
    //   379: ldc_w -5.0
    //   382: aload_1
    //   383: invokevirtual getWidth : ()I
    //   386: iconst_2
    //   387: idiv
    //   388: i2f
    //   389: aload_1
    //   390: invokevirtual getHeight : ()I
    //   393: iconst_2
    //   394: idiv
    //   395: i2f
    //   396: invokevirtual preRotate : (FFF)Z
    //   399: pop
    //   400: iload_2
    //   401: iconst_2
    //   402: if_icmpne -> 427
    //   405: aload_3
    //   406: ldc_w -2.5
    //   409: aload_1
    //   410: invokevirtual getWidth : ()I
    //   413: iconst_2
    //   414: idiv
    //   415: i2f
    //   416: aload_1
    //   417: invokevirtual getHeight : ()I
    //   420: iconst_2
    //   421: idiv
    //   422: i2f
    //   423: invokevirtual preRotate : (FFF)Z
    //   426: pop
    //   427: iload_2
    //   428: iconst_5
    //   429: if_icmpne -> 454
    //   432: aload_3
    //   433: ldc_w 2.5
    //   436: aload_1
    //   437: invokevirtual getWidth : ()I
    //   440: iconst_2
    //   441: idiv
    //   442: i2f
    //   443: aload_1
    //   444: invokevirtual getHeight : ()I
    //   447: iconst_2
    //   448: idiv
    //   449: i2f
    //   450: invokevirtual preRotate : (FFF)Z
    //   453: pop
    //   454: iload_2
    //   455: bipush #6
    //   457: if_icmpne -> 482
    //   460: aload_3
    //   461: ldc_w 5.0
    //   464: aload_1
    //   465: invokevirtual getWidth : ()I
    //   468: iconst_2
    //   469: idiv
    //   470: i2f
    //   471: aload_1
    //   472: invokevirtual getHeight : ()I
    //   475: iconst_2
    //   476: idiv
    //   477: i2f
    //   478: invokevirtual preRotate : (FFF)Z
    //   481: pop
    //   482: iload_2
    //   483: bipush #7
    //   485: if_icmpne -> 710
    //   488: goto -> 688
    //   491: iload_2
    //   492: ifne -> 517
    //   495: aload_3
    //   496: ldc_w -10.0
    //   499: aload_1
    //   500: invokevirtual getWidth : ()I
    //   503: iconst_2
    //   504: idiv
    //   505: i2f
    //   506: aload_1
    //   507: invokevirtual getHeight : ()I
    //   510: iconst_2
    //   511: idiv
    //   512: i2f
    //   513: invokevirtual preRotate : (FFF)Z
    //   516: pop
    //   517: iload_2
    //   518: iconst_1
    //   519: if_icmpne -> 544
    //   522: aload_3
    //   523: ldc_w -7.5
    //   526: aload_1
    //   527: invokevirtual getWidth : ()I
    //   530: iconst_2
    //   531: idiv
    //   532: i2f
    //   533: aload_1
    //   534: invokevirtual getHeight : ()I
    //   537: iconst_2
    //   538: idiv
    //   539: i2f
    //   540: invokevirtual preRotate : (FFF)Z
    //   543: pop
    //   544: iload_2
    //   545: iconst_2
    //   546: if_icmpne -> 571
    //   549: aload_3
    //   550: ldc_w -5.0
    //   553: aload_1
    //   554: invokevirtual getWidth : ()I
    //   557: iconst_2
    //   558: idiv
    //   559: i2f
    //   560: aload_1
    //   561: invokevirtual getHeight : ()I
    //   564: iconst_2
    //   565: idiv
    //   566: i2f
    //   567: invokevirtual preRotate : (FFF)Z
    //   570: pop
    //   571: iload_2
    //   572: iconst_3
    //   573: if_icmpne -> 598
    //   576: aload_3
    //   577: ldc_w -2.5
    //   580: aload_1
    //   581: invokevirtual getWidth : ()I
    //   584: iconst_2
    //   585: idiv
    //   586: i2f
    //   587: aload_1
    //   588: invokevirtual getHeight : ()I
    //   591: iconst_2
    //   592: idiv
    //   593: i2f
    //   594: invokevirtual preRotate : (FFF)Z
    //   597: pop
    //   598: iload_2
    //   599: bipush #6
    //   601: if_icmpne -> 626
    //   604: aload_3
    //   605: ldc_w 2.5
    //   608: aload_1
    //   609: invokevirtual getWidth : ()I
    //   612: iconst_2
    //   613: idiv
    //   614: i2f
    //   615: aload_1
    //   616: invokevirtual getHeight : ()I
    //   619: iconst_2
    //   620: idiv
    //   621: i2f
    //   622: invokevirtual preRotate : (FFF)Z
    //   625: pop
    //   626: iload_2
    //   627: bipush #7
    //   629: if_icmpne -> 654
    //   632: aload_3
    //   633: ldc_w 5.0
    //   636: aload_1
    //   637: invokevirtual getWidth : ()I
    //   640: iconst_2
    //   641: idiv
    //   642: i2f
    //   643: aload_1
    //   644: invokevirtual getHeight : ()I
    //   647: iconst_2
    //   648: idiv
    //   649: i2f
    //   650: invokevirtual preRotate : (FFF)Z
    //   653: pop
    //   654: iload_2
    //   655: bipush #8
    //   657: if_icmpne -> 682
    //   660: aload_3
    //   661: ldc_w 7.5
    //   664: aload_1
    //   665: invokevirtual getWidth : ()I
    //   668: iconst_2
    //   669: idiv
    //   670: i2f
    //   671: aload_1
    //   672: invokevirtual getHeight : ()I
    //   675: iconst_2
    //   676: idiv
    //   677: i2f
    //   678: invokevirtual preRotate : (FFF)Z
    //   681: pop
    //   682: iload_2
    //   683: bipush #9
    //   685: if_icmpne -> 710
    //   688: aload_3
    //   689: ldc_w 10.0
    //   692: aload_1
    //   693: invokevirtual getWidth : ()I
    //   696: iconst_2
    //   697: idiv
    //   698: i2f
    //   699: aload_1
    //   700: invokevirtual getHeight : ()I
    //   703: iconst_2
    //   704: idiv
    //   705: i2f
    //   706: invokevirtual preRotate : (FFF)Z
    //   709: pop
    //   710: aload_0
    //   711: aload_1
    //   712: aload_3
    //   713: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   716: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
    //   719: return
  }
  
  public static Bitmap g(Bitmap paramBitmap) {
    Matrix matrix = new Matrix();
    float f1 = (0 - paramBitmap.getWidth() / 15);
    float f2 = (0 - paramBitmap.getWidth() / 15);
    int i = paramBitmap.getWidth();
    float f3 = (paramBitmap.getWidth() / 15 + i);
    float f4 = (0 - paramBitmap.getWidth() / 15);
    float f5 = paramBitmap.getWidth();
    float f6 = paramBitmap.getHeight();
    float f7 = paramBitmap.getHeight();
    matrix.setPolyToPoly(new float[] { 0.0F, 0.0F, paramBitmap.getWidth(), 0.0F, paramBitmap.getWidth(), paramBitmap.getHeight(), 0.0F, paramBitmap.getHeight() }, 0, new float[] { f1, f2, f3, f4, f5, f6, 0.0F, f7 }, 0, 4);
    return Bitmap.createBitmap(paramBitmap, 0, 0, paramBitmap.getWidth(), paramBitmap.getHeight(), matrix, true);
  }
  
  public static void i(RectF paramRectF) {
    float f1 = paramRectF.right;
    float f2 = paramRectF.left;
    float f3 = (f1 - f2) / 15.0F;
    paramRectF.left = f2 + f3;
    paramRectF.right = f1 - f3;
    paramRectF.top += f3;
    paramRectF.bottom -= f3;
  }
  
  public static int[] k() {
    int[] arrayOfInt2 = H;
    int[] arrayOfInt1 = arrayOfInt2;
    if (arrayOfInt2 == null) {
      arrayOfInt1 = new int[(b.c(5)).length];
      arrayOfInt1[2] = 3;
      arrayOfInt1[4] = 5;
      arrayOfInt1[0] = 1;
      arrayOfInt1[1] = 2;
      arrayOfInt1[3] = 4;
      H = arrayOfInt1;
    } 
    return arrayOfInt1;
  }
  
  public final void a() {
    int i = MainActivity.U0;
    if (i == 10 || i == 11) {
      if (MainActivity.q0) {
        Matrix matrix = new Matrix();
        matrix.setRotate(-90.0F);
        Bitmap bitmap = this.p;
        if (bitmap != null) {
          this.p = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), this.p.getHeight(), matrix, false);
          return;
        } 
      } else {
        Matrix matrix = new Matrix();
        matrix.setRotate(90.0F);
        Bitmap bitmap = this.p;
        if (bitmap != null) {
          this.p = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), this.p.getHeight(), matrix, false);
          return;
        } 
      } 
      return;
    } 
    if (!MainActivity.q0) {
      Matrix matrix = new Matrix();
      matrix.setRotate(180.0F);
      Bitmap bitmap = this.p;
      if (bitmap != null) {
        this.p = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), this.p.getHeight(), matrix, false);
        return;
      } 
    } 
  }
  
  public final void b() {
    this.G.post(new a(this));
  }
  
  public final Bitmap c(int paramInt) {
    int[] arrayOfInt = k();
    if (paramInt != 0) {
      paramInt = arrayOfInt[paramInt - 1];
      return (paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : this.q) : this.s) : this.q) : this.s;
    } 
    throw null;
  }
  
  public final void e(Canvas paramCanvas) {
    for (int i = 0; i < R; i++) {
      for (int j = 0; j < R; j++) {
        d d1 = this.w;
        h(paramCanvas, i, j, d1.a[i][j], d1.b[i][j], d1.c[i][j], d1.d[i][j], d1.e[i][j], d1.f[i][j], false, d1.g[i][j], d1.h[i][j]);
      } 
    } 
  }
  
  public final void h(Canvas paramCanvas, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 2766
    //   4: aload_0
    //   5: iload #4
    //   7: invokevirtual c : (I)Landroid/graphics/Bitmap;
    //   10: astore #26
    //   12: aload_0
    //   13: getfield v : F
    //   16: fstore #14
    //   18: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   21: istore #21
    //   23: iload #21
    //   25: i2f
    //   26: fstore #15
    //   28: fload #14
    //   30: fload #15
    //   32: fdiv
    //   33: fstore #13
    //   35: iload #21
    //   37: iload_3
    //   38: isub
    //   39: iconst_1
    //   40: isub
    //   41: i2f
    //   42: fstore #17
    //   44: aload_0
    //   45: getfield C : F
    //   48: fstore #16
    //   50: fload #13
    //   52: fload #17
    //   54: fmul
    //   55: fload #16
    //   57: fadd
    //   58: fstore #13
    //   60: iload_2
    //   61: i2f
    //   62: fload #14
    //   64: fmul
    //   65: fload #15
    //   67: fdiv
    //   68: fload #16
    //   70: fadd
    //   71: fstore #14
    //   73: aload_0
    //   74: getfield v : F
    //   77: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   80: i2f
    //   81: fdiv
    //   82: fstore #15
    //   84: new android/graphics/RectF
    //   87: dup
    //   88: fload #14
    //   90: fload #13
    //   92: fload #15
    //   94: fload #14
    //   96: fadd
    //   97: fload #15
    //   99: fload #13
    //   101: fadd
    //   102: invokespecial <init> : (FFFF)V
    //   105: astore #23
    //   107: aload_0
    //   108: getfield v : F
    //   111: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   114: i2f
    //   115: fdiv
    //   116: fstore #15
    //   118: new android/graphics/RectF
    //   121: dup
    //   122: fload #14
    //   124: fload #13
    //   126: fload #15
    //   128: fload #14
    //   130: fadd
    //   131: fload #15
    //   133: fload #13
    //   135: fadd
    //   136: invokespecial <init> : (FFFF)V
    //   139: astore #27
    //   141: aload #23
    //   143: astore #24
    //   145: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   148: ifeq -> 346
    //   151: aload #23
    //   153: astore #24
    //   155: aload_0
    //   156: getfield E : Z
    //   159: ifne -> 346
    //   162: iconst_2
    //   163: newarray float
    //   165: astore #23
    //   167: aload #23
    //   169: iconst_0
    //   170: fload #14
    //   172: fastore
    //   173: aload #23
    //   175: iconst_1
    //   176: fload #13
    //   178: fastore
    //   179: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   182: aload #23
    //   184: invokevirtual mapPoints : ([F)V
    //   187: aload_0
    //   188: getfield v : F
    //   191: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   194: i2f
    //   195: fdiv
    //   196: fstore #15
    //   198: iconst_2
    //   199: newarray float
    //   201: astore #24
    //   203: aload #24
    //   205: iconst_0
    //   206: fload #14
    //   208: fload #15
    //   210: fadd
    //   211: fastore
    //   212: aload #24
    //   214: iconst_1
    //   215: fload #15
    //   217: fload #13
    //   219: fadd
    //   220: fastore
    //   221: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   224: aload #24
    //   226: invokevirtual mapPoints : ([F)V
    //   229: aload #23
    //   231: iconst_0
    //   232: faload
    //   233: fstore #17
    //   235: aload #23
    //   237: iconst_1
    //   238: faload
    //   239: fstore #14
    //   241: aload #24
    //   243: iconst_0
    //   244: faload
    //   245: fstore #18
    //   247: aload #24
    //   249: iconst_1
    //   250: faload
    //   251: fstore #15
    //   253: ldc_w 0.95
    //   256: iload_3
    //   257: i2f
    //   258: ldc_w 0.03
    //   261: fmul
    //   262: fsub
    //   263: fstore #13
    //   265: aload_0
    //   266: getfield v : F
    //   269: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   272: i2f
    //   273: fdiv
    //   274: fload #13
    //   276: fmul
    //   277: fstore #16
    //   279: fload #18
    //   281: fload #17
    //   283: fsub
    //   284: fload #16
    //   286: fsub
    //   287: fconst_2
    //   288: fdiv
    //   289: fload #17
    //   291: fadd
    //   292: fstore #17
    //   294: fload #15
    //   296: fload #14
    //   298: fsub
    //   299: fload #16
    //   301: fsub
    //   302: fconst_2
    //   303: fdiv
    //   304: fload #14
    //   306: fadd
    //   307: fstore #14
    //   309: aload_0
    //   310: getfield v : F
    //   313: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   316: i2f
    //   317: fdiv
    //   318: fload #13
    //   320: fmul
    //   321: fstore #13
    //   323: new android/graphics/RectF
    //   326: dup
    //   327: fload #17
    //   329: fload #14
    //   331: fload #13
    //   333: fload #17
    //   335: fadd
    //   336: fload #13
    //   338: fload #14
    //   340: fadd
    //   341: invokespecial <init> : (FFFF)V
    //   344: astore #24
    //   346: new android/graphics/RectF
    //   349: dup
    //   350: aload #27
    //   352: getfield left : F
    //   355: aload #27
    //   357: getfield top : F
    //   360: aload #27
    //   362: getfield right : F
    //   365: aload #27
    //   367: getfield bottom : F
    //   370: invokespecial <init> : (FFFF)V
    //   373: astore #25
    //   375: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   378: istore #22
    //   380: iload #22
    //   382: ifeq -> 405
    //   385: aload_0
    //   386: getfield E : Z
    //   389: ifne -> 405
    //   392: aload #25
    //   394: getfield right : F
    //   397: fstore #14
    //   399: fconst_2
    //   400: fstore #13
    //   402: goto -> 415
    //   405: aload #25
    //   407: getfield right : F
    //   410: fstore #14
    //   412: fconst_1
    //   413: fstore #13
    //   415: fload #14
    //   417: fload #13
    //   419: fadd
    //   420: fstore #14
    //   422: aload #25
    //   424: fload #14
    //   426: putfield right : F
    //   429: aload #25
    //   431: getfield bottom : F
    //   434: fload #13
    //   436: fadd
    //   437: fstore #13
    //   439: aload #25
    //   441: fload #13
    //   443: putfield bottom : F
    //   446: iload #5
    //   448: ifeq -> 674
    //   451: iload #22
    //   453: ifeq -> 662
    //   456: aload_0
    //   457: getfield E : Z
    //   460: ifne -> 662
    //   463: bipush #8
    //   465: newarray float
    //   467: astore #23
    //   469: aload #25
    //   471: getfield left : F
    //   474: fstore #15
    //   476: aload #23
    //   478: iconst_0
    //   479: fload #15
    //   481: fastore
    //   482: aload #25
    //   484: getfield top : F
    //   487: fstore #16
    //   489: aload #23
    //   491: iconst_1
    //   492: fload #16
    //   494: fastore
    //   495: aload #23
    //   497: iconst_2
    //   498: fload #14
    //   500: fastore
    //   501: aload #23
    //   503: iconst_3
    //   504: fload #16
    //   506: fastore
    //   507: aload #23
    //   509: iconst_4
    //   510: fload #14
    //   512: fastore
    //   513: aload #23
    //   515: iconst_5
    //   516: fload #13
    //   518: fastore
    //   519: aload #23
    //   521: bipush #6
    //   523: fload #15
    //   525: fastore
    //   526: aload #23
    //   528: bipush #7
    //   530: fload #13
    //   532: fastore
    //   533: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   536: aload #23
    //   538: invokevirtual mapPoints : ([F)V
    //   541: aload #23
    //   543: iconst_0
    //   544: faload
    //   545: fstore #13
    //   547: aload #23
    //   549: iconst_1
    //   550: faload
    //   551: fstore #14
    //   553: aload #23
    //   555: iconst_2
    //   556: faload
    //   557: fstore #15
    //   559: aload #23
    //   561: iconst_3
    //   562: faload
    //   563: fstore #16
    //   565: aload #23
    //   567: iconst_4
    //   568: faload
    //   569: fstore #17
    //   571: aload #23
    //   573: iconst_5
    //   574: faload
    //   575: fstore #18
    //   577: aload #23
    //   579: bipush #6
    //   581: faload
    //   582: fstore #19
    //   584: aload #23
    //   586: bipush #7
    //   588: faload
    //   589: fstore #20
    //   591: new android/graphics/Path
    //   594: dup
    //   595: invokespecial <init> : ()V
    //   598: astore #23
    //   600: aload #23
    //   602: fload #13
    //   604: fload #14
    //   606: invokevirtual moveTo : (FF)V
    //   609: aload #23
    //   611: fload #15
    //   613: fload #16
    //   615: invokevirtual lineTo : (FF)V
    //   618: aload #23
    //   620: fload #17
    //   622: fload #18
    //   624: invokevirtual lineTo : (FF)V
    //   627: aload #23
    //   629: fload #19
    //   631: fload #20
    //   633: invokevirtual lineTo : (FF)V
    //   636: aload #23
    //   638: fload #13
    //   640: fload #14
    //   642: invokevirtual lineTo : (FF)V
    //   645: aload #23
    //   647: invokevirtual close : ()V
    //   650: aload_1
    //   651: aload #23
    //   653: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   656: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   659: goto -> 674
    //   662: aload_1
    //   663: aload #25
    //   665: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   668: invokevirtual drawRect : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   671: goto -> 674
    //   674: aload #25
    //   676: astore #23
    //   678: iload #12
    //   680: ifeq -> 995
    //   683: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   686: ifeq -> 965
    //   689: aload_0
    //   690: getfield E : Z
    //   693: ifne -> 965
    //   696: aload #25
    //   698: getfield left : F
    //   701: fstore #15
    //   703: aload #25
    //   705: getfield right : F
    //   708: fstore #16
    //   710: fload #15
    //   712: fload #16
    //   714: fadd
    //   715: fconst_2
    //   716: fdiv
    //   717: fstore #13
    //   719: aload #25
    //   721: getfield top : F
    //   724: aload #25
    //   726: getfield bottom : F
    //   729: fadd
    //   730: fconst_2
    //   731: fdiv
    //   732: fstore #14
    //   734: fload #16
    //   736: fload #15
    //   738: fsub
    //   739: ldc_w 11.0
    //   742: fdiv
    //   743: fstore #15
    //   745: new android/graphics/RectF
    //   748: dup
    //   749: fload #13
    //   751: fload #15
    //   753: fsub
    //   754: fload #14
    //   756: fload #15
    //   758: fsub
    //   759: fload #13
    //   761: fload #15
    //   763: fadd
    //   764: fload #14
    //   766: fload #15
    //   768: fadd
    //   769: invokespecial <init> : (FFFF)V
    //   772: astore #23
    //   774: bipush #8
    //   776: newarray float
    //   778: astore #25
    //   780: aload #23
    //   782: getfield left : F
    //   785: fstore #13
    //   787: aload #25
    //   789: iconst_0
    //   790: fload #13
    //   792: fastore
    //   793: aload #23
    //   795: getfield top : F
    //   798: fstore #14
    //   800: aload #25
    //   802: iconst_1
    //   803: fload #14
    //   805: fastore
    //   806: aload #23
    //   808: getfield right : F
    //   811: fstore #15
    //   813: aload #25
    //   815: iconst_2
    //   816: fload #15
    //   818: fastore
    //   819: aload #25
    //   821: iconst_3
    //   822: fload #14
    //   824: fastore
    //   825: aload #25
    //   827: iconst_4
    //   828: fload #15
    //   830: fastore
    //   831: aload #23
    //   833: getfield bottom : F
    //   836: fstore #14
    //   838: aload #25
    //   840: iconst_5
    //   841: fload #14
    //   843: fastore
    //   844: aload #25
    //   846: bipush #6
    //   848: fload #13
    //   850: fastore
    //   851: aload #25
    //   853: bipush #7
    //   855: fload #14
    //   857: fastore
    //   858: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   861: aload #25
    //   863: invokevirtual mapPoints : ([F)V
    //   866: aload #25
    //   868: iconst_0
    //   869: faload
    //   870: fstore #13
    //   872: aload #25
    //   874: iconst_1
    //   875: faload
    //   876: fstore #14
    //   878: aload #25
    //   880: iconst_2
    //   881: faload
    //   882: fstore #15
    //   884: aload #25
    //   886: iconst_3
    //   887: faload
    //   888: fstore #16
    //   890: aload #25
    //   892: iconst_4
    //   893: faload
    //   894: fstore #17
    //   896: aload #25
    //   898: iconst_5
    //   899: faload
    //   900: fstore #18
    //   902: aload #25
    //   904: bipush #6
    //   906: faload
    //   907: fstore #19
    //   909: aload #25
    //   911: bipush #7
    //   913: faload
    //   914: fstore #20
    //   916: new android/graphics/RectF
    //   919: dup
    //   920: fload #13
    //   922: fload #19
    //   924: fadd
    //   925: fconst_2
    //   926: fdiv
    //   927: fload #14
    //   929: fload #16
    //   931: fadd
    //   932: fconst_2
    //   933: fdiv
    //   934: fload #15
    //   936: fload #17
    //   938: fadd
    //   939: fconst_2
    //   940: fdiv
    //   941: fload #18
    //   943: fload #20
    //   945: fadd
    //   946: fconst_2
    //   947: fdiv
    //   948: invokespecial <init> : (FFFF)V
    //   951: astore #23
    //   953: aload_1
    //   954: aload #23
    //   956: getstatic com/dimcoms/checkers/MySurfaceView2.Q : Landroid/graphics/Paint;
    //   959: invokevirtual drawOval : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   962: goto -> 995
    //   965: aload_1
    //   966: aload #25
    //   968: invokevirtual centerX : ()F
    //   971: aload #25
    //   973: invokevirtual centerY : ()F
    //   976: aload #25
    //   978: invokevirtual width : ()F
    //   981: ldc_w 10.0
    //   984: fdiv
    //   985: getstatic com/dimcoms/checkers/MySurfaceView2.Q : Landroid/graphics/Paint;
    //   988: invokevirtual drawCircle : (FFFLandroid/graphics/Paint;)V
    //   991: aload #25
    //   993: astore #23
    //   995: iload #11
    //   997: ifeq -> 1235
    //   1000: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1003: ifeq -> 1226
    //   1006: aload_0
    //   1007: getfield E : Z
    //   1010: ifne -> 1226
    //   1013: bipush #8
    //   1015: newarray float
    //   1017: astore #25
    //   1019: aload #23
    //   1021: getfield left : F
    //   1024: fstore #13
    //   1026: aload #25
    //   1028: iconst_0
    //   1029: fload #13
    //   1031: fastore
    //   1032: aload #23
    //   1034: getfield top : F
    //   1037: fstore #14
    //   1039: aload #25
    //   1041: iconst_1
    //   1042: fload #14
    //   1044: fastore
    //   1045: aload #23
    //   1047: getfield right : F
    //   1050: fstore #15
    //   1052: aload #25
    //   1054: iconst_2
    //   1055: fload #15
    //   1057: fastore
    //   1058: aload #25
    //   1060: iconst_3
    //   1061: fload #14
    //   1063: fastore
    //   1064: aload #25
    //   1066: iconst_4
    //   1067: fload #15
    //   1069: fastore
    //   1070: aload #23
    //   1072: getfield bottom : F
    //   1075: fstore #14
    //   1077: aload #25
    //   1079: iconst_5
    //   1080: fload #14
    //   1082: fastore
    //   1083: aload #25
    //   1085: bipush #6
    //   1087: fload #13
    //   1089: fastore
    //   1090: aload #25
    //   1092: bipush #7
    //   1094: fload #14
    //   1096: fastore
    //   1097: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   1100: aload #25
    //   1102: invokevirtual mapPoints : ([F)V
    //   1105: aload #25
    //   1107: iconst_0
    //   1108: faload
    //   1109: fstore #13
    //   1111: aload #25
    //   1113: iconst_1
    //   1114: faload
    //   1115: fstore #14
    //   1117: aload #25
    //   1119: iconst_2
    //   1120: faload
    //   1121: fstore #15
    //   1123: aload #25
    //   1125: iconst_3
    //   1126: faload
    //   1127: fstore #16
    //   1129: aload #25
    //   1131: iconst_4
    //   1132: faload
    //   1133: fstore #17
    //   1135: aload #25
    //   1137: iconst_5
    //   1138: faload
    //   1139: fstore #18
    //   1141: aload #25
    //   1143: bipush #6
    //   1145: faload
    //   1146: fstore #19
    //   1148: aload #25
    //   1150: bipush #7
    //   1152: faload
    //   1153: fstore #20
    //   1155: new android/graphics/Path
    //   1158: dup
    //   1159: invokespecial <init> : ()V
    //   1162: astore #25
    //   1164: aload #25
    //   1166: fload #13
    //   1168: fload #14
    //   1170: invokevirtual moveTo : (FF)V
    //   1173: aload #25
    //   1175: fload #15
    //   1177: fload #16
    //   1179: invokevirtual lineTo : (FF)V
    //   1182: aload #25
    //   1184: fload #17
    //   1186: fload #18
    //   1188: invokevirtual lineTo : (FF)V
    //   1191: aload #25
    //   1193: fload #19
    //   1195: fload #20
    //   1197: invokevirtual lineTo : (FF)V
    //   1200: aload #25
    //   1202: fload #13
    //   1204: fload #14
    //   1206: invokevirtual lineTo : (FF)V
    //   1209: aload #25
    //   1211: invokevirtual close : ()V
    //   1214: aload_1
    //   1215: aload #25
    //   1217: getstatic com/dimcoms/checkers/MySurfaceView2.P : Landroid/graphics/Paint;
    //   1220: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   1223: goto -> 1235
    //   1226: aload_1
    //   1227: aload #23
    //   1229: getstatic com/dimcoms/checkers/MySurfaceView2.P : Landroid/graphics/Paint;
    //   1232: invokevirtual drawRect : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   1235: iload #6
    //   1237: ifeq -> 1652
    //   1240: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1243: ifeq -> 1562
    //   1246: aload_0
    //   1247: getfield E : Z
    //   1250: ifne -> 1562
    //   1253: aload #23
    //   1255: getfield right : F
    //   1258: aload #23
    //   1260: getfield left : F
    //   1263: fsub
    //   1264: ldc_w 15.0
    //   1267: fdiv
    //   1268: fstore #14
    //   1270: aload #23
    //   1272: getfield left : F
    //   1275: fstore #13
    //   1277: fload #14
    //   1279: fconst_2
    //   1280: fdiv
    //   1281: fstore #14
    //   1283: new android/graphics/RectF
    //   1286: dup
    //   1287: fload #13
    //   1289: fload #14
    //   1291: fadd
    //   1292: aload #23
    //   1294: getfield top : F
    //   1297: fload #14
    //   1299: fadd
    //   1300: aload #23
    //   1302: getfield right : F
    //   1305: fload #14
    //   1307: fsub
    //   1308: aload #23
    //   1310: getfield bottom : F
    //   1313: fload #14
    //   1315: fsub
    //   1316: invokespecial <init> : (FFFF)V
    //   1319: astore #25
    //   1321: bipush #8
    //   1323: newarray float
    //   1325: astore #28
    //   1327: aload #25
    //   1329: getfield left : F
    //   1332: fstore #13
    //   1334: aload #28
    //   1336: iconst_0
    //   1337: fload #13
    //   1339: fastore
    //   1340: aload #25
    //   1342: getfield top : F
    //   1345: fstore #14
    //   1347: aload #28
    //   1349: iconst_1
    //   1350: fload #14
    //   1352: fastore
    //   1353: aload #25
    //   1355: getfield right : F
    //   1358: fstore #15
    //   1360: aload #28
    //   1362: iconst_2
    //   1363: fload #15
    //   1365: fastore
    //   1366: aload #28
    //   1368: iconst_3
    //   1369: fload #14
    //   1371: fastore
    //   1372: aload #28
    //   1374: iconst_4
    //   1375: fload #15
    //   1377: fastore
    //   1378: aload #25
    //   1380: getfield bottom : F
    //   1383: fstore #14
    //   1385: aload #28
    //   1387: iconst_5
    //   1388: fload #14
    //   1390: fastore
    //   1391: aload #28
    //   1393: bipush #6
    //   1395: fload #13
    //   1397: fastore
    //   1398: aload #28
    //   1400: bipush #7
    //   1402: fload #14
    //   1404: fastore
    //   1405: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   1408: aload #28
    //   1410: invokevirtual mapPoints : ([F)V
    //   1413: aload #28
    //   1415: iconst_0
    //   1416: faload
    //   1417: fstore #13
    //   1419: aload #28
    //   1421: iconst_1
    //   1422: faload
    //   1423: fstore #14
    //   1425: aload #28
    //   1427: iconst_2
    //   1428: faload
    //   1429: fstore #15
    //   1431: aload #28
    //   1433: iconst_3
    //   1434: faload
    //   1435: fstore #16
    //   1437: aload #28
    //   1439: iconst_4
    //   1440: faload
    //   1441: fstore #17
    //   1443: aload #28
    //   1445: iconst_5
    //   1446: faload
    //   1447: fstore #18
    //   1449: aload #28
    //   1451: bipush #6
    //   1453: faload
    //   1454: fstore #19
    //   1456: aload #28
    //   1458: bipush #7
    //   1460: faload
    //   1461: fstore #20
    //   1463: new android/graphics/Path
    //   1466: dup
    //   1467: invokespecial <init> : ()V
    //   1470: astore #25
    //   1472: aload #25
    //   1474: fload #13
    //   1476: fload #14
    //   1478: invokevirtual moveTo : (FF)V
    //   1481: aload #25
    //   1483: fload #15
    //   1485: fload #16
    //   1487: invokevirtual lineTo : (FF)V
    //   1490: aload #25
    //   1492: fload #17
    //   1494: fload #18
    //   1496: invokevirtual lineTo : (FF)V
    //   1499: aload #25
    //   1501: fload #19
    //   1503: fload #20
    //   1505: invokevirtual lineTo : (FF)V
    //   1508: aload #25
    //   1510: fload #13
    //   1512: fload #14
    //   1514: invokevirtual lineTo : (FF)V
    //   1517: aload #25
    //   1519: invokevirtual close : ()V
    //   1522: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1525: getstatic android/graphics/Paint$Style.STROKE : Landroid/graphics/Paint$Style;
    //   1528: invokevirtual setStyle : (Landroid/graphics/Paint$Style;)V
    //   1531: fload #17
    //   1533: fload #19
    //   1535: fsub
    //   1536: ldc_w 15.0
    //   1539: fdiv
    //   1540: fstore #13
    //   1542: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1545: fload #13
    //   1547: invokevirtual setStrokeWidth : (F)V
    //   1550: aload_1
    //   1551: aload #25
    //   1553: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1556: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   1559: goto -> 1652
    //   1562: aload #23
    //   1564: getfield right : F
    //   1567: aload #23
    //   1569: getfield left : F
    //   1572: fsub
    //   1573: ldc_w 15.0
    //   1576: fdiv
    //   1577: fstore #14
    //   1579: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1582: getstatic android/graphics/Paint$Style.STROKE : Landroid/graphics/Paint$Style;
    //   1585: invokevirtual setStyle : (Landroid/graphics/Paint$Style;)V
    //   1588: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1591: fload #14
    //   1593: invokevirtual setStrokeWidth : (F)V
    //   1596: aload #23
    //   1598: getfield left : F
    //   1601: fstore #13
    //   1603: fload #14
    //   1605: fconst_2
    //   1606: fdiv
    //   1607: fstore #14
    //   1609: aload_1
    //   1610: new android/graphics/RectF
    //   1613: dup
    //   1614: fload #13
    //   1616: fload #14
    //   1618: fadd
    //   1619: aload #23
    //   1621: getfield top : F
    //   1624: fload #14
    //   1626: fadd
    //   1627: aload #23
    //   1629: getfield right : F
    //   1632: fload #14
    //   1634: fsub
    //   1635: aload #23
    //   1637: getfield bottom : F
    //   1640: fload #14
    //   1642: fsub
    //   1643: invokespecial <init> : (FFFF)V
    //   1646: getstatic com/dimcoms/checkers/MySurfaceView2.M : Landroid/graphics/Paint;
    //   1649: invokevirtual drawRect : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   1652: aload #23
    //   1654: astore #25
    //   1656: iload #7
    //   1658: ifeq -> 1988
    //   1661: aload #23
    //   1663: astore #25
    //   1665: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1668: invokevirtual size : ()I
    //   1671: ifne -> 1988
    //   1674: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   1677: ifeq -> 1957
    //   1680: aload_0
    //   1681: getfield E : Z
    //   1684: ifne -> 1957
    //   1687: aload #23
    //   1689: getfield left : F
    //   1692: fstore #15
    //   1694: aload #23
    //   1696: getfield right : F
    //   1699: fstore #16
    //   1701: fload #15
    //   1703: fload #16
    //   1705: fadd
    //   1706: fconst_2
    //   1707: fdiv
    //   1708: fstore #13
    //   1710: aload #23
    //   1712: getfield top : F
    //   1715: aload #23
    //   1717: getfield bottom : F
    //   1720: fadd
    //   1721: fconst_2
    //   1722: fdiv
    //   1723: fstore #14
    //   1725: fload #16
    //   1727: fload #15
    //   1729: fsub
    //   1730: ldc_w 11.0
    //   1733: fdiv
    //   1734: fstore #15
    //   1736: new android/graphics/RectF
    //   1739: dup
    //   1740: fload #13
    //   1742: fload #15
    //   1744: fsub
    //   1745: fload #14
    //   1747: fload #15
    //   1749: fsub
    //   1750: fload #13
    //   1752: fload #15
    //   1754: fadd
    //   1755: fload #14
    //   1757: fload #15
    //   1759: fadd
    //   1760: invokespecial <init> : (FFFF)V
    //   1763: astore #23
    //   1765: bipush #8
    //   1767: newarray float
    //   1769: astore #25
    //   1771: aload #23
    //   1773: getfield left : F
    //   1776: fstore #13
    //   1778: aload #25
    //   1780: iconst_0
    //   1781: fload #13
    //   1783: fastore
    //   1784: aload #23
    //   1786: getfield top : F
    //   1789: fstore #14
    //   1791: aload #25
    //   1793: iconst_1
    //   1794: fload #14
    //   1796: fastore
    //   1797: aload #23
    //   1799: getfield right : F
    //   1802: fstore #15
    //   1804: aload #25
    //   1806: iconst_2
    //   1807: fload #15
    //   1809: fastore
    //   1810: aload #25
    //   1812: iconst_3
    //   1813: fload #14
    //   1815: fastore
    //   1816: aload #25
    //   1818: iconst_4
    //   1819: fload #15
    //   1821: fastore
    //   1822: aload #23
    //   1824: getfield bottom : F
    //   1827: fstore #14
    //   1829: aload #25
    //   1831: iconst_5
    //   1832: fload #14
    //   1834: fastore
    //   1835: aload #25
    //   1837: bipush #6
    //   1839: fload #13
    //   1841: fastore
    //   1842: aload #25
    //   1844: bipush #7
    //   1846: fload #14
    //   1848: fastore
    //   1849: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   1852: aload #25
    //   1854: invokevirtual mapPoints : ([F)V
    //   1857: aload #25
    //   1859: iconst_0
    //   1860: faload
    //   1861: fstore #13
    //   1863: aload #25
    //   1865: iconst_1
    //   1866: faload
    //   1867: fstore #14
    //   1869: aload #25
    //   1871: iconst_2
    //   1872: faload
    //   1873: fstore #15
    //   1875: aload #25
    //   1877: iconst_3
    //   1878: faload
    //   1879: fstore #16
    //   1881: aload #25
    //   1883: iconst_4
    //   1884: faload
    //   1885: fstore #17
    //   1887: aload #25
    //   1889: iconst_5
    //   1890: faload
    //   1891: fstore #18
    //   1893: aload #25
    //   1895: bipush #6
    //   1897: faload
    //   1898: fstore #19
    //   1900: aload #25
    //   1902: bipush #7
    //   1904: faload
    //   1905: fstore #20
    //   1907: new android/graphics/RectF
    //   1910: dup
    //   1911: fload #13
    //   1913: fload #19
    //   1915: fadd
    //   1916: fconst_2
    //   1917: fdiv
    //   1918: fload #14
    //   1920: fload #16
    //   1922: fadd
    //   1923: fconst_2
    //   1924: fdiv
    //   1925: fload #15
    //   1927: fload #17
    //   1929: fadd
    //   1930: fconst_2
    //   1931: fdiv
    //   1932: fload #18
    //   1934: fload #20
    //   1936: fadd
    //   1937: fconst_2
    //   1938: fdiv
    //   1939: invokespecial <init> : (FFFF)V
    //   1942: astore #25
    //   1944: aload_1
    //   1945: aload #25
    //   1947: aload_0
    //   1948: getfield z : Landroid/graphics/Paint;
    //   1951: invokevirtual drawOval : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   1954: goto -> 1988
    //   1957: aload_1
    //   1958: aload #23
    //   1960: invokevirtual centerX : ()F
    //   1963: aload #23
    //   1965: invokevirtual centerY : ()F
    //   1968: aload #23
    //   1970: invokevirtual width : ()F
    //   1973: ldc_w 10.0
    //   1976: fdiv
    //   1977: aload_0
    //   1978: getfield z : Landroid/graphics/Paint;
    //   1981: invokevirtual drawCircle : (FFFLandroid/graphics/Paint;)V
    //   1984: aload #23
    //   1986: astore #25
    //   1988: iload #8
    //   1990: ifeq -> 2335
    //   1993: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   1996: bipush #125
    //   1998: invokevirtual setAlpha : (I)V
    //   2001: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
    //   2004: astore #23
    //   2006: aload #23
    //   2008: ifnull -> 2326
    //   2011: aload #23
    //   2013: invokevirtual size : ()I
    //   2016: ifle -> 2326
    //   2019: getstatic com/dimcoms/checkers/MainActivity.t0 : Ljava/util/ArrayList;
    //   2022: iconst_0
    //   2023: invokevirtual get : (I)Ljava/lang/Object;
    //   2026: checkcast g0/w
    //   2029: astore #23
    //   2031: aload #23
    //   2033: ifnull -> 2326
    //   2036: aload #23
    //   2038: iconst_0
    //   2039: invokevirtual b : (I)Lg0/z;
    //   2042: astore #23
    //   2044: aload #23
    //   2046: getfield a : I
    //   2049: istore #21
    //   2051: iload #21
    //   2053: iload_2
    //   2054: if_icmpne -> 2066
    //   2057: iload_3
    //   2058: aload #23
    //   2060: getfield b : I
    //   2063: if_icmpeq -> 2326
    //   2066: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2069: iload #21
    //   2071: aload #23
    //   2073: getfield b : I
    //   2076: invokevirtual h : (II)Lg0/v;
    //   2079: astore #23
    //   2081: aload #23
    //   2083: ifnull -> 2326
    //   2086: aload #23
    //   2088: getfield j : I
    //   2091: istore #21
    //   2093: iload #21
    //   2095: iconst_2
    //   2096: if_icmpeq -> 2152
    //   2099: aload_0
    //   2100: getfield F : Z
    //   2103: ifne -> 2152
    //   2106: getstatic com/dimcoms/checkers/MainActivity.j0 : I
    //   2109: iconst_4
    //   2110: if_icmpne -> 2152
    //   2113: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2116: getfield s : Z
    //   2119: istore #5
    //   2121: iload #5
    //   2123: ifeq -> 2138
    //   2126: iload_3
    //   2127: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   2130: iconst_1
    //   2131: isub
    //   2132: if_icmpeq -> 2147
    //   2135: goto -> 2138
    //   2138: iload #5
    //   2140: ifne -> 2152
    //   2143: iload_3
    //   2144: ifne -> 2152
    //   2147: aload_0
    //   2148: iconst_1
    //   2149: putfield F : Z
    //   2152: iload #21
    //   2154: istore_3
    //   2155: aload_0
    //   2156: getfield F : Z
    //   2159: ifeq -> 2164
    //   2162: iconst_2
    //   2163: istore_3
    //   2164: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2167: getfield s : Z
    //   2170: ifeq -> 2182
    //   2173: aload_0
    //   2174: getfield s : Landroid/graphics/Bitmap;
    //   2177: astore #23
    //   2179: goto -> 2188
    //   2182: aload_0
    //   2183: getfield q : Landroid/graphics/Bitmap;
    //   2186: astore #23
    //   2188: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2191: ifeq -> 2253
    //   2194: aload_0
    //   2195: getfield E : Z
    //   2198: ifne -> 2253
    //   2201: aload_1
    //   2202: aload #23
    //   2204: iload_2
    //   2205: aload #24
    //   2207: iconst_1
    //   2208: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   2211: iload_3
    //   2212: iconst_2
    //   2213: if_icmpne -> 2326
    //   2216: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2219: getfield s : Z
    //   2222: ifeq -> 2234
    //   2225: aload_0
    //   2226: getfield t : Landroid/graphics/Bitmap;
    //   2229: astore #23
    //   2231: goto -> 2240
    //   2234: aload_0
    //   2235: getfield r : Landroid/graphics/Bitmap;
    //   2238: astore #23
    //   2240: aload_1
    //   2241: aload #23
    //   2243: iload_2
    //   2244: aload #24
    //   2246: iconst_0
    //   2247: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   2250: goto -> 2326
    //   2253: aload #23
    //   2255: ifnull -> 2270
    //   2258: aload_1
    //   2259: aload #23
    //   2261: aconst_null
    //   2262: aload #27
    //   2264: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2267: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2270: iload_3
    //   2271: iconst_2
    //   2272: if_icmpne -> 2326
    //   2275: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   2278: getfield s : Z
    //   2281: ifeq -> 2298
    //   2284: aload_0
    //   2285: getfield t : Landroid/graphics/Bitmap;
    //   2288: astore #23
    //   2290: aload #23
    //   2292: ifnull -> 2326
    //   2295: goto -> 2309
    //   2298: aload_0
    //   2299: getfield r : Landroid/graphics/Bitmap;
    //   2302: astore #23
    //   2304: aload #23
    //   2306: ifnull -> 2326
    //   2309: aload #27
    //   2311: invokestatic i : (Landroid/graphics/RectF;)V
    //   2314: aload_1
    //   2315: aload #23
    //   2317: aconst_null
    //   2318: aload #27
    //   2320: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2323: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2326: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2329: sipush #255
    //   2332: invokevirtual setAlpha : (I)V
    //   2335: iload #9
    //   2337: ifeq -> 2575
    //   2340: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2343: ifeq -> 2566
    //   2346: aload_0
    //   2347: getfield E : Z
    //   2350: ifne -> 2566
    //   2353: bipush #8
    //   2355: newarray float
    //   2357: astore #23
    //   2359: aload #25
    //   2361: getfield left : F
    //   2364: fstore #13
    //   2366: aload #23
    //   2368: iconst_0
    //   2369: fload #13
    //   2371: fastore
    //   2372: aload #25
    //   2374: getfield top : F
    //   2377: fstore #14
    //   2379: aload #23
    //   2381: iconst_1
    //   2382: fload #14
    //   2384: fastore
    //   2385: aload #25
    //   2387: getfield right : F
    //   2390: fstore #15
    //   2392: aload #23
    //   2394: iconst_2
    //   2395: fload #15
    //   2397: fastore
    //   2398: aload #23
    //   2400: iconst_3
    //   2401: fload #14
    //   2403: fastore
    //   2404: aload #23
    //   2406: iconst_4
    //   2407: fload #15
    //   2409: fastore
    //   2410: aload #25
    //   2412: getfield bottom : F
    //   2415: fstore #14
    //   2417: aload #23
    //   2419: iconst_5
    //   2420: fload #14
    //   2422: fastore
    //   2423: aload #23
    //   2425: bipush #6
    //   2427: fload #13
    //   2429: fastore
    //   2430: aload #23
    //   2432: bipush #7
    //   2434: fload #14
    //   2436: fastore
    //   2437: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   2440: aload #23
    //   2442: invokevirtual mapPoints : ([F)V
    //   2445: aload #23
    //   2447: iconst_0
    //   2448: faload
    //   2449: fstore #13
    //   2451: aload #23
    //   2453: iconst_1
    //   2454: faload
    //   2455: fstore #14
    //   2457: aload #23
    //   2459: iconst_2
    //   2460: faload
    //   2461: fstore #15
    //   2463: aload #23
    //   2465: iconst_3
    //   2466: faload
    //   2467: fstore #16
    //   2469: aload #23
    //   2471: iconst_4
    //   2472: faload
    //   2473: fstore #17
    //   2475: aload #23
    //   2477: iconst_5
    //   2478: faload
    //   2479: fstore #18
    //   2481: aload #23
    //   2483: bipush #6
    //   2485: faload
    //   2486: fstore #19
    //   2488: aload #23
    //   2490: bipush #7
    //   2492: faload
    //   2493: fstore #20
    //   2495: new android/graphics/Path
    //   2498: dup
    //   2499: invokespecial <init> : ()V
    //   2502: astore #23
    //   2504: aload #23
    //   2506: fload #13
    //   2508: fload #14
    //   2510: invokevirtual moveTo : (FF)V
    //   2513: aload #23
    //   2515: fload #15
    //   2517: fload #16
    //   2519: invokevirtual lineTo : (FF)V
    //   2522: aload #23
    //   2524: fload #17
    //   2526: fload #18
    //   2528: invokevirtual lineTo : (FF)V
    //   2531: aload #23
    //   2533: fload #19
    //   2535: fload #20
    //   2537: invokevirtual lineTo : (FF)V
    //   2540: aload #23
    //   2542: fload #13
    //   2544: fload #14
    //   2546: invokevirtual lineTo : (FF)V
    //   2549: aload #23
    //   2551: invokevirtual close : ()V
    //   2554: aload_1
    //   2555: aload #23
    //   2557: getstatic com/dimcoms/checkers/MySurfaceView2.N : Landroid/graphics/Paint;
    //   2560: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   2563: goto -> 2575
    //   2566: aload_1
    //   2567: aload #25
    //   2569: getstatic com/dimcoms/checkers/MySurfaceView2.N : Landroid/graphics/Paint;
    //   2572: invokevirtual drawRect : (Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2575: aload #26
    //   2577: ifnull -> 2766
    //   2580: iload #10
    //   2582: ifeq -> 2595
    //   2585: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2588: aload_0
    //   2589: getfield m : I
    //   2592: invokevirtual setAlpha : (I)V
    //   2595: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   2598: ifeq -> 2666
    //   2601: aload_0
    //   2602: getfield E : Z
    //   2605: ifne -> 2666
    //   2608: aload_1
    //   2609: aload #26
    //   2611: iload_2
    //   2612: aload #24
    //   2614: iconst_1
    //   2615: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   2618: iload #4
    //   2620: invokestatic d : (I)I
    //   2623: iconst_4
    //   2624: if_icmpne -> 2642
    //   2627: aload_1
    //   2628: aload_0
    //   2629: getfield t : Landroid/graphics/Bitmap;
    //   2632: iload_2
    //   2633: aload #24
    //   2635: iconst_0
    //   2636: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   2639: goto -> 2642
    //   2642: iload #4
    //   2644: invokestatic d : (I)I
    //   2647: iconst_5
    //   2648: if_icmpne -> 2752
    //   2651: aload_1
    //   2652: aload_0
    //   2653: getfield r : Landroid/graphics/Bitmap;
    //   2656: iload_2
    //   2657: aload #24
    //   2659: iconst_0
    //   2660: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   2663: goto -> 2752
    //   2666: aload_1
    //   2667: aload #26
    //   2669: aconst_null
    //   2670: aload #27
    //   2672: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2675: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2678: iload #4
    //   2680: invokestatic d : (I)I
    //   2683: iconst_4
    //   2684: if_icmpne -> 2715
    //   2687: aload_0
    //   2688: getfield t : Landroid/graphics/Bitmap;
    //   2691: astore #23
    //   2693: aload #23
    //   2695: ifnull -> 2715
    //   2698: aload #27
    //   2700: invokestatic i : (Landroid/graphics/RectF;)V
    //   2703: aload_1
    //   2704: aload #23
    //   2706: aconst_null
    //   2707: aload #27
    //   2709: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2712: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2715: iload #4
    //   2717: invokestatic d : (I)I
    //   2720: iconst_5
    //   2721: if_icmpne -> 2752
    //   2724: aload_0
    //   2725: getfield r : Landroid/graphics/Bitmap;
    //   2728: astore #23
    //   2730: aload #23
    //   2732: ifnull -> 2752
    //   2735: aload #27
    //   2737: invokestatic i : (Landroid/graphics/RectF;)V
    //   2740: aload_1
    //   2741: aload #23
    //   2743: aconst_null
    //   2744: aload #27
    //   2746: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2749: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   2752: iload #10
    //   2754: ifeq -> 2766
    //   2757: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   2760: sipush #255
    //   2763: invokevirtual setAlpha : (I)V
    //   2766: return
  }
  
  public final void j() {
    // Byte code:
    //   0: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   3: bipush #8
    //   5: if_icmpne -> 70
    //   8: getstatic com/dimcoms/checkers/MainActivity.U0 : I
    //   11: istore_1
    //   12: iload_1
    //   13: iconst_4
    //   14: if_icmpeq -> 57
    //   17: iload_1
    //   18: iconst_5
    //   19: if_icmpne -> 25
    //   22: goto -> 57
    //   25: iload_1
    //   26: bipush #7
    //   28: if_icmpne -> 44
    //   31: aload_0
    //   32: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   35: astore #4
    //   37: ldc_w 2131099662
    //   40: istore_1
    //   41: goto -> 80
    //   44: aload_0
    //   45: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   48: astore #4
    //   50: ldc_w 2131099660
    //   53: istore_1
    //   54: goto -> 80
    //   57: aload_0
    //   58: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   61: astore #4
    //   63: ldc_w 2131099661
    //   66: istore_1
    //   67: goto -> 80
    //   70: aload_0
    //   71: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   74: astore #4
    //   76: ldc_w 2131099659
    //   79: istore_1
    //   80: aload_0
    //   81: aload #4
    //   83: iload_1
    //   84: invokestatic decodeResource : (Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;
    //   87: putfield p : Landroid/graphics/Bitmap;
    //   90: aload_0
    //   91: getfield p : Landroid/graphics/Bitmap;
    //   94: astore #4
    //   96: aload #4
    //   98: ifnull -> 136
    //   101: aload_0
    //   102: getfield D : I
    //   105: aload #4
    //   107: invokevirtual getWidth : ()I
    //   110: if_icmpge -> 136
    //   113: aload_0
    //   114: getfield p : Landroid/graphics/Bitmap;
    //   117: astore #4
    //   119: aload_0
    //   120: getfield D : I
    //   123: istore_1
    //   124: aload_0
    //   125: aload #4
    //   127: iload_1
    //   128: iload_1
    //   129: iconst_1
    //   130: invokestatic createScaledBitmap : (Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   133: putfield p : Landroid/graphics/Bitmap;
    //   136: aload_0
    //   137: invokevirtual a : ()V
    //   140: aload_0
    //   141: aload_0
    //   142: getfield p : Landroid/graphics/Bitmap;
    //   145: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   148: putfield p : Landroid/graphics/Bitmap;
    //   151: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   154: ifeq -> 227
    //   157: aload_0
    //   158: getfield E : Z
    //   161: ifne -> 227
    //   164: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   167: istore_3
    //   168: ldc_w 2131099654
    //   171: istore_1
    //   172: ldc_w 2131099797
    //   175: istore_2
    //   176: iload_3
    //   177: ifeq -> 195
    //   180: aload_0
    //   181: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   184: ldc_w 2131099654
    //   187: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   190: astore #4
    //   192: goto -> 207
    //   195: aload_0
    //   196: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   199: ldc_w 2131099797
    //   202: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   205: astore #4
    //   207: aload_0
    //   208: aload #4
    //   210: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   213: putfield q : Landroid/graphics/Bitmap;
    //   216: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   219: ifeq -> 300
    //   222: iload_2
    //   223: istore_1
    //   224: goto -> 287
    //   227: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   230: istore_3
    //   231: ldc_w 2131099653
    //   234: istore_1
    //   235: ldc_w 2131099796
    //   238: istore_2
    //   239: iload_3
    //   240: ifeq -> 258
    //   243: aload_0
    //   244: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   247: ldc_w 2131099653
    //   250: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   253: astore #4
    //   255: goto -> 270
    //   258: aload_0
    //   259: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   262: ldc_w 2131099796
    //   265: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   268: astore #4
    //   270: aload_0
    //   271: aload #4
    //   273: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   276: putfield q : Landroid/graphics/Bitmap;
    //   279: getstatic com/dimcoms/checkers/MainActivity.q0 : Z
    //   282: ifeq -> 300
    //   285: iload_2
    //   286: istore_1
    //   287: aload_0
    //   288: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   291: iload_1
    //   292: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   295: astore #4
    //   297: goto -> 310
    //   300: aload_0
    //   301: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   304: iload_1
    //   305: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   308: astore #4
    //   310: aload_0
    //   311: aload #4
    //   313: invokestatic g : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    //   316: putfield s : Landroid/graphics/Bitmap;
    //   319: getstatic com/dimcoms/checkers/MySurfaceView2.L : Landroid/graphics/Paint;
    //   322: bipush #120
    //   324: bipush #23
    //   326: sipush #149
    //   329: bipush #16
    //   331: invokestatic argb : (IIII)I
    //   334: invokevirtual setColor : (I)V
    //   337: aload_0
    //   338: getfield p : Landroid/graphics/Bitmap;
    //   341: ifnull -> 358
    //   344: aload_0
    //   345: getfield q : Landroid/graphics/Bitmap;
    //   348: ifnull -> 358
    //   351: aload_0
    //   352: getfield s : Landroid/graphics/Bitmap;
    //   355: ifnonnull -> 364
    //   358: getstatic com/dimcoms/checkers/MainActivity.G : Lcom/dimcoms/checkers/MainActivity;
    //   361: invokevirtual finish : ()V
    //   364: return
    //   365: astore #4
    //   367: return
    // Exception table:
    //   from	to	target	type
    //   358	364	365	java/lang/Exception
  }
  
  public final void l() {
    if (MainActivity.I && !this.E) {
      Bitmap bitmap = this.p;
      if (bitmap != null) {
        Matrix matrix = new Matrix();
        int i = V;
        float f1 = i;
        float f2 = f1 / 8.25F;
        int j = T;
        float f3 = (int)(j - f1 / 1.32F);
        float f4 = (j - i / 30);
        matrix.setPolyToPoly(new float[] { 0.0F, 0.0F, bitmap.getWidth(), 0.0F, bitmap.getWidth(), bitmap.getHeight(), 0.0F, bitmap.getHeight() }, 0, new float[] { f2, f3, f1 - f2, f3, f1, f4, 0.0F, f4 }, 0, 4);
        this.p = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
      } 
      bitmap = this.s;
      if (bitmap != null)
        this.s = g(bitmap); 
      bitmap = this.q;
      if (bitmap != null)
        this.q = g(bitmap); 
    } 
  }
  
  public final void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic currentTimeMillis : ()J
    //   4: putfield n : J
    //   7: aload_1
    //   8: ifnull -> 1462
    //   11: aload_0
    //   12: getfield v : F
    //   15: fconst_0
    //   16: fcmpl
    //   17: ifne -> 48
    //   20: getstatic com/dimcoms/checkers/MySurfaceView2.V : I
    //   23: i2f
    //   24: ldc_w 0.963
    //   27: fmul
    //   28: fstore #6
    //   30: aload_0
    //   31: fload #6
    //   33: putfield v : F
    //   36: aload_0
    //   37: fload #6
    //   39: ldc_w 27.6
    //   42: fdiv
    //   43: fconst_2
    //   44: fdiv
    //   45: putfield C : F
    //   48: getstatic com/dimcoms/checkers/MySurfaceView2.V : I
    //   51: i2f
    //   52: fstore #6
    //   54: new android/graphics/RectF
    //   57: dup
    //   58: fconst_0
    //   59: fconst_0
    //   60: fload #6
    //   62: fload #6
    //   64: invokespecial <init> : (FFFF)V
    //   67: astore #23
    //   69: aload #23
    //   71: astore #22
    //   73: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   76: ifeq -> 191
    //   79: aload #23
    //   81: astore #22
    //   83: aload_0
    //   84: getfield E : Z
    //   87: ifne -> 191
    //   90: getstatic com/dimcoms/checkers/MySurfaceView2.T : I
    //   93: istore #14
    //   95: iload #14
    //   97: i2f
    //   98: fstore #6
    //   100: getstatic com/dimcoms/checkers/MySurfaceView2.V : I
    //   103: istore #15
    //   105: fload #6
    //   107: iload #15
    //   109: i2f
    //   110: ldc_w 1.32
    //   113: fdiv
    //   114: fsub
    //   115: f2i
    //   116: i2f
    //   117: fstore #6
    //   119: iload #14
    //   121: iload #15
    //   123: bipush #30
    //   125: idiv
    //   126: isub
    //   127: i2f
    //   128: fstore #7
    //   130: new android/graphics/RectF
    //   133: dup
    //   134: fconst_0
    //   135: fload #6
    //   137: getstatic com/dimcoms/checkers/MySurfaceView2.V : I
    //   140: i2f
    //   141: fload #7
    //   143: invokespecial <init> : (FFFF)V
    //   146: astore #22
    //   148: new android/graphics/RectF
    //   151: dup
    //   152: fconst_0
    //   153: fload #7
    //   155: getstatic com/dimcoms/checkers/MySurfaceView2.V : I
    //   158: i2f
    //   159: getstatic com/dimcoms/checkers/MySurfaceView2.T : I
    //   162: i2f
    //   163: invokespecial <init> : (FFFF)V
    //   166: astore #23
    //   168: aload_0
    //   169: getfield u : Landroid/graphics/Bitmap;
    //   172: astore #24
    //   174: aload #24
    //   176: ifnull -> 191
    //   179: aload_1
    //   180: aload #24
    //   182: aconst_null
    //   183: aload #23
    //   185: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   188: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   191: aload_0
    //   192: getfield p : Landroid/graphics/Bitmap;
    //   195: astore #23
    //   197: aload #23
    //   199: ifnull -> 214
    //   202: aload_1
    //   203: aload #23
    //   205: aconst_null
    //   206: aload #22
    //   208: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   211: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   214: aload_0
    //   215: getfield e : I
    //   218: istore #14
    //   220: iload #14
    //   222: iconst_1
    //   223: if_icmpeq -> 973
    //   226: iload #14
    //   228: iconst_2
    //   229: if_icmpeq -> 249
    //   232: iload #14
    //   234: iconst_3
    //   235: if_icmpeq -> 241
    //   238: goto -> 1110
    //   241: aload_0
    //   242: aload_1
    //   243: invokevirtual e : (Landroid/graphics/Canvas;)V
    //   246: goto -> 1110
    //   249: aload_0
    //   250: aload_1
    //   251: invokevirtual e : (Landroid/graphics/Canvas;)V
    //   254: aload_0
    //   255: getfield n : J
    //   258: lstore #16
    //   260: aload_0
    //   261: getfield a : J
    //   264: lstore #18
    //   266: lload #16
    //   268: lload #18
    //   270: lsub
    //   271: l2d
    //   272: dstore_2
    //   273: aload_0
    //   274: getfield b : J
    //   277: lload #18
    //   279: lsub
    //   280: l2d
    //   281: dstore #4
    //   283: dload_2
    //   284: invokestatic isNaN : (D)Z
    //   287: pop
    //   288: dload #4
    //   290: invokestatic isNaN : (D)Z
    //   293: pop
    //   294: dload_2
    //   295: invokestatic isNaN : (D)Z
    //   298: pop
    //   299: dload #4
    //   301: invokestatic isNaN : (D)Z
    //   304: pop
    //   305: dload_2
    //   306: invokestatic isNaN : (D)Z
    //   309: pop
    //   310: dload #4
    //   312: invokestatic isNaN : (D)Z
    //   315: pop
    //   316: dload_2
    //   317: invokestatic isNaN : (D)Z
    //   320: pop
    //   321: dload #4
    //   323: invokestatic isNaN : (D)Z
    //   326: pop
    //   327: dload_2
    //   328: dload #4
    //   330: ddiv
    //   331: dstore #4
    //   333: dload #4
    //   335: dstore_2
    //   336: dload #4
    //   338: dconst_1
    //   339: dcmpl
    //   340: ifle -> 345
    //   343: dconst_1
    //   344: dstore_2
    //   345: aload_0
    //   346: getfield h : F
    //   349: fstore #6
    //   351: aload_0
    //   352: getfield j : F
    //   355: fload #6
    //   357: fsub
    //   358: f2d
    //   359: dstore #4
    //   361: dload #4
    //   363: invokestatic isNaN : (D)Z
    //   366: pop
    //   367: dload #4
    //   369: invokestatic isNaN : (D)Z
    //   372: pop
    //   373: dload #4
    //   375: invokestatic isNaN : (D)Z
    //   378: pop
    //   379: dload #4
    //   381: invokestatic isNaN : (D)Z
    //   384: pop
    //   385: aload_0
    //   386: fload #6
    //   388: dload #4
    //   390: dload_2
    //   391: dmul
    //   392: invokestatic round : (D)J
    //   395: l2i
    //   396: i2f
    //   397: fadd
    //   398: putfield f : F
    //   401: aload_0
    //   402: getfield i : F
    //   405: fstore #6
    //   407: aload_0
    //   408: getfield k : F
    //   411: fload #6
    //   413: fsub
    //   414: f2d
    //   415: dstore #4
    //   417: dload #4
    //   419: invokestatic isNaN : (D)Z
    //   422: pop
    //   423: dload #4
    //   425: invokestatic isNaN : (D)Z
    //   428: pop
    //   429: dload #4
    //   431: invokestatic isNaN : (D)Z
    //   434: pop
    //   435: dload #4
    //   437: invokestatic isNaN : (D)Z
    //   440: pop
    //   441: aload_0
    //   442: fload #6
    //   444: dload #4
    //   446: dload_2
    //   447: dmul
    //   448: invokestatic round : (D)J
    //   451: l2i
    //   452: i2f
    //   453: fadd
    //   454: putfield g : F
    //   457: aload_0
    //   458: getfield f : F
    //   461: fstore #6
    //   463: aload_0
    //   464: getfield C : F
    //   467: fstore #7
    //   469: aload_0
    //   470: getfield g : F
    //   473: fstore #8
    //   475: aload_0
    //   476: getfield v : F
    //   479: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   482: i2f
    //   483: fdiv
    //   484: fstore #9
    //   486: new android/graphics/RectF
    //   489: dup
    //   490: fload #6
    //   492: fload #7
    //   494: fadd
    //   495: fload #8
    //   497: fload #7
    //   499: fadd
    //   500: fload #6
    //   502: fload #9
    //   504: fadd
    //   505: fload #7
    //   507: fadd
    //   508: fload #9
    //   510: fload #8
    //   512: fadd
    //   513: fload #7
    //   515: fadd
    //   516: invokespecial <init> : (FFFF)V
    //   519: astore #24
    //   521: aload_0
    //   522: getfield o : Landroid/graphics/Bitmap;
    //   525: astore #23
    //   527: aload #23
    //   529: ifnull -> 1110
    //   532: getstatic com/dimcoms/checkers/MainActivity.I : Z
    //   535: ifeq -> 879
    //   538: aload_0
    //   539: getfield E : Z
    //   542: ifne -> 879
    //   545: iconst_2
    //   546: newarray float
    //   548: astore #22
    //   550: aload_0
    //   551: getfield f : F
    //   554: fstore #6
    //   556: aload_0
    //   557: getfield C : F
    //   560: fstore #7
    //   562: aload #22
    //   564: iconst_0
    //   565: fload #6
    //   567: fload #7
    //   569: fadd
    //   570: fastore
    //   571: aload #22
    //   573: iconst_1
    //   574: aload_0
    //   575: getfield g : F
    //   578: fload #7
    //   580: fadd
    //   581: fastore
    //   582: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   585: aload #22
    //   587: invokevirtual mapPoints : ([F)V
    //   590: aload_0
    //   591: getfield v : F
    //   594: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   597: i2f
    //   598: fdiv
    //   599: fstore #6
    //   601: aload_0
    //   602: getfield f : F
    //   605: fstore #7
    //   607: aload_0
    //   608: getfield C : F
    //   611: fstore #8
    //   613: aload_0
    //   614: getfield g : F
    //   617: fstore #9
    //   619: iconst_2
    //   620: newarray float
    //   622: astore #23
    //   624: aload #23
    //   626: iconst_0
    //   627: fload #7
    //   629: fload #6
    //   631: fadd
    //   632: fload #8
    //   634: fadd
    //   635: fastore
    //   636: aload #23
    //   638: iconst_1
    //   639: fload #6
    //   641: fload #9
    //   643: fadd
    //   644: fload #8
    //   646: fadd
    //   647: fastore
    //   648: getstatic com/dimcoms/checkers/MySurfaceView2.S : Landroid/graphics/Matrix;
    //   651: aload #23
    //   653: invokevirtual mapPoints : ([F)V
    //   656: aload #22
    //   658: iconst_0
    //   659: faload
    //   660: fstore #10
    //   662: aload #22
    //   664: iconst_1
    //   665: faload
    //   666: fstore #6
    //   668: aload #23
    //   670: iconst_0
    //   671: faload
    //   672: fstore #11
    //   674: aload #23
    //   676: iconst_1
    //   677: faload
    //   678: fstore #7
    //   680: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   683: i2f
    //   684: fstore #8
    //   686: aload_0
    //   687: getfield g : F
    //   690: fstore #9
    //   692: aload_0
    //   693: getfield v : F
    //   696: fload #8
    //   698: fdiv
    //   699: fstore #13
    //   701: fload #8
    //   703: fload #9
    //   705: fload #13
    //   707: fdiv
    //   708: fsub
    //   709: fconst_1
    //   710: fsub
    //   711: fstore #8
    //   713: aload_0
    //   714: getfield f : F
    //   717: fload #13
    //   719: fdiv
    //   720: fstore #9
    //   722: ldc_w 0.95
    //   725: ldc_w 0.03
    //   728: fload #8
    //   730: fmul
    //   731: fsub
    //   732: fstore #12
    //   734: fload #13
    //   736: fload #12
    //   738: fmul
    //   739: fstore #13
    //   741: fload #11
    //   743: fload #10
    //   745: fsub
    //   746: fload #13
    //   748: fsub
    //   749: fconst_2
    //   750: fdiv
    //   751: fload #10
    //   753: fadd
    //   754: fstore #10
    //   756: fload #7
    //   758: fload #6
    //   760: fsub
    //   761: fload #13
    //   763: fsub
    //   764: fconst_2
    //   765: fdiv
    //   766: fload #6
    //   768: fadd
    //   769: fstore #6
    //   771: aload_0
    //   772: getfield v : F
    //   775: getstatic com/dimcoms/checkers/MySurfaceView2.R : I
    //   778: i2f
    //   779: fdiv
    //   780: fload #12
    //   782: fmul
    //   783: fstore #7
    //   785: new android/graphics/RectF
    //   788: dup
    //   789: fload #10
    //   791: fload #6
    //   793: fload #7
    //   795: fload #10
    //   797: fadd
    //   798: fload #7
    //   800: fload #6
    //   802: fadd
    //   803: invokespecial <init> : (FFFF)V
    //   806: astore #22
    //   808: fload #9
    //   810: invokestatic round : (F)I
    //   813: istore #14
    //   815: fload #8
    //   817: invokestatic round : (F)I
    //   820: pop
    //   821: aload_1
    //   822: aload_0
    //   823: getfield o : Landroid/graphics/Bitmap;
    //   826: iload #14
    //   828: aload #22
    //   830: iconst_1
    //   831: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   834: aload_0
    //   835: getfield l : I
    //   838: iconst_4
    //   839: if_icmpne -> 855
    //   842: aload_1
    //   843: aload_0
    //   844: getfield t : Landroid/graphics/Bitmap;
    //   847: iload #14
    //   849: aload #22
    //   851: iconst_0
    //   852: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   855: aload_0
    //   856: getfield l : I
    //   859: iconst_5
    //   860: if_icmpne -> 1110
    //   863: aload_1
    //   864: aload_0
    //   865: getfield r : Landroid/graphics/Bitmap;
    //   868: iload #14
    //   870: aload #22
    //   872: iconst_0
    //   873: invokestatic f : (Landroid/graphics/Canvas;Landroid/graphics/Bitmap;ILandroid/graphics/RectF;Z)V
    //   876: goto -> 1110
    //   879: aload_0
    //   880: getfield l : I
    //   883: istore #14
    //   885: iload #14
    //   887: iconst_4
    //   888: if_icmpne -> 917
    //   891: aload_1
    //   892: aload #23
    //   894: aconst_null
    //   895: aload #24
    //   897: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   900: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   903: aload_0
    //   904: getfield t : Landroid/graphics/Bitmap;
    //   907: astore #22
    //   909: aload #22
    //   911: ifnull -> 1110
    //   914: goto -> 953
    //   917: aload #23
    //   919: astore #22
    //   921: iload #14
    //   923: iconst_5
    //   924: if_icmpne -> 958
    //   927: aload_1
    //   928: aload #23
    //   930: aconst_null
    //   931: aload #24
    //   933: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   936: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   939: aload_0
    //   940: getfield r : Landroid/graphics/Bitmap;
    //   943: astore #22
    //   945: aload #22
    //   947: ifnull -> 1110
    //   950: goto -> 914
    //   953: aload #24
    //   955: invokestatic i : (Landroid/graphics/RectF;)V
    //   958: aload_1
    //   959: aload #22
    //   961: aconst_null
    //   962: aload #24
    //   964: getstatic com/dimcoms/checkers/MySurfaceView2.J : Landroid/graphics/Paint;
    //   967: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V
    //   970: goto -> 1110
    //   973: aload_0
    //   974: aload_1
    //   975: invokevirtual e : (Landroid/graphics/Canvas;)V
    //   978: invokestatic e : ()Z
    //   981: ifeq -> 1113
    //   984: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   987: invokevirtual isEmpty : ()Z
    //   990: ifne -> 1110
    //   993: aload_0
    //   994: sipush #150
    //   997: putfield m : I
    //   1000: iconst_0
    //   1001: istore #15
    //   1003: iload #15
    //   1005: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1008: invokevirtual size : ()I
    //   1011: if_icmpge -> 1110
    //   1014: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1017: iload #15
    //   1019: invokevirtual get : (I)Ljava/lang/Object;
    //   1022: checkcast g0/v
    //   1025: astore #22
    //   1027: aload #22
    //   1029: getfield j : I
    //   1032: istore #14
    //   1034: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   1037: getfield s : Z
    //   1040: ifne -> 1061
    //   1043: iload #14
    //   1045: iconst_2
    //   1046: if_icmpeq -> 1055
    //   1049: iconst_3
    //   1050: istore #14
    //   1052: goto -> 1076
    //   1055: iconst_5
    //   1056: istore #14
    //   1058: goto -> 1076
    //   1061: iload #14
    //   1063: iconst_2
    //   1064: if_icmpeq -> 1073
    //   1067: iconst_2
    //   1068: istore #14
    //   1070: goto -> 1076
    //   1073: iconst_4
    //   1074: istore #14
    //   1076: aload_0
    //   1077: aload_1
    //   1078: aload #22
    //   1080: getfield k : B
    //   1083: aload #22
    //   1085: getfield l : B
    //   1088: iload #14
    //   1090: iconst_0
    //   1091: iconst_0
    //   1092: iconst_0
    //   1093: iconst_0
    //   1094: iconst_0
    //   1095: iconst_1
    //   1096: iconst_0
    //   1097: iconst_0
    //   1098: invokevirtual h : (Landroid/graphics/Canvas;IIIZZZZZZZZ)V
    //   1101: iload #15
    //   1103: iconst_1
    //   1104: iadd
    //   1105: istore #15
    //   1107: goto -> 1003
    //   1110: goto -> 1359
    //   1113: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1116: invokevirtual isEmpty : ()Z
    //   1119: ifne -> 1359
    //   1122: aload_0
    //   1123: getfield n : J
    //   1126: lstore #16
    //   1128: aload_0
    //   1129: getfield c : J
    //   1132: lstore #18
    //   1134: lload #16
    //   1136: lload #18
    //   1138: lsub
    //   1139: l2d
    //   1140: dstore_2
    //   1141: aload_0
    //   1142: getfield d : J
    //   1145: lstore #20
    //   1147: lload #20
    //   1149: lload #18
    //   1151: lsub
    //   1152: l2d
    //   1153: dstore #4
    //   1155: dload_2
    //   1156: invokestatic isNaN : (D)Z
    //   1159: pop
    //   1160: dload #4
    //   1162: invokestatic isNaN : (D)Z
    //   1165: pop
    //   1166: dload_2
    //   1167: invokestatic isNaN : (D)Z
    //   1170: pop
    //   1171: dload #4
    //   1173: invokestatic isNaN : (D)Z
    //   1176: pop
    //   1177: dload_2
    //   1178: invokestatic isNaN : (D)Z
    //   1181: pop
    //   1182: dload #4
    //   1184: invokestatic isNaN : (D)Z
    //   1187: pop
    //   1188: dload_2
    //   1189: invokestatic isNaN : (D)Z
    //   1192: pop
    //   1193: dload #4
    //   1195: invokestatic isNaN : (D)Z
    //   1198: pop
    //   1199: sipush #220
    //   1202: dload_2
    //   1203: dload #4
    //   1205: ddiv
    //   1206: ldc2_w 220.0
    //   1209: dmul
    //   1210: d2i
    //   1211: isub
    //   1212: istore #14
    //   1214: aload_0
    //   1215: iload #14
    //   1217: putfield m : I
    //   1220: lload #16
    //   1222: lload #20
    //   1224: lcmp
    //   1225: ifge -> 1346
    //   1228: iload #14
    //   1230: ifgt -> 1236
    //   1233: goto -> 1346
    //   1236: iconst_0
    //   1237: istore #15
    //   1239: iload #15
    //   1241: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1244: invokevirtual size : ()I
    //   1247: if_icmpge -> 1359
    //   1250: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1253: iload #15
    //   1255: invokevirtual get : (I)Ljava/lang/Object;
    //   1258: checkcast g0/v
    //   1261: astore #22
    //   1263: aload #22
    //   1265: getfield j : I
    //   1268: istore #14
    //   1270: getstatic com/dimcoms/checkers/MainActivity.g0 : Lg0/b;
    //   1273: getfield s : Z
    //   1276: ifne -> 1297
    //   1279: iload #14
    //   1281: iconst_2
    //   1282: if_icmpeq -> 1291
    //   1285: iconst_3
    //   1286: istore #14
    //   1288: goto -> 1312
    //   1291: iconst_5
    //   1292: istore #14
    //   1294: goto -> 1312
    //   1297: iload #14
    //   1299: iconst_2
    //   1300: if_icmpeq -> 1309
    //   1303: iconst_2
    //   1304: istore #14
    //   1306: goto -> 1312
    //   1309: iconst_4
    //   1310: istore #14
    //   1312: aload_0
    //   1313: aload_1
    //   1314: aload #22
    //   1316: getfield k : B
    //   1319: aload #22
    //   1321: getfield l : B
    //   1324: iload #14
    //   1326: iconst_0
    //   1327: iconst_0
    //   1328: iconst_0
    //   1329: iconst_0
    //   1330: iconst_0
    //   1331: iconst_1
    //   1332: iconst_0
    //   1333: iconst_0
    //   1334: invokevirtual h : (Landroid/graphics/Canvas;IIIZZZZZZZZ)V
    //   1337: iload #15
    //   1339: iconst_1
    //   1340: iadd
    //   1341: istore #15
    //   1343: goto -> 1239
    //   1346: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1349: invokevirtual clear : ()V
    //   1352: aload_0
    //   1353: sipush #220
    //   1356: putfield m : I
    //   1359: aload_0
    //   1360: getfield e : I
    //   1363: iconst_3
    //   1364: if_icmpne -> 1394
    //   1367: aload_0
    //   1368: iconst_1
    //   1369: putfield e : I
    //   1372: aload_0
    //   1373: getfield x : Lcom/dimcoms/checkers/MainActivity$p;
    //   1376: checkcast com/dimcoms/checkers/a$g
    //   1379: invokevirtual getClass : ()Ljava/lang/Class;
    //   1382: pop
    //   1383: getstatic com/dimcoms/checkers/MainActivity.a0 : Lcom/dimcoms/checkers/MainActivity$o;
    //   1386: iconst_2
    //   1387: invokevirtual sendEmptyMessage : (I)Z
    //   1390: pop
    //   1391: goto -> 1394
    //   1394: aload_0
    //   1395: getfield e : I
    //   1398: iconst_2
    //   1399: if_icmpne -> 1462
    //   1402: aload_0
    //   1403: getfield n : J
    //   1406: aload_0
    //   1407: getfield b : J
    //   1410: lcmp
    //   1411: iflt -> 1462
    //   1414: invokestatic currentTimeMillis : ()J
    //   1417: lstore #16
    //   1419: aload_0
    //   1420: lload #16
    //   1422: putfield c : J
    //   1425: aload_0
    //   1426: lload #16
    //   1428: ldc2_w 250
    //   1431: ladd
    //   1432: putfield d : J
    //   1435: aload_0
    //   1436: iconst_1
    //   1437: putfield e : I
    //   1440: aload_0
    //   1441: getfield x : Lcom/dimcoms/checkers/MainActivity$p;
    //   1444: checkcast com/dimcoms/checkers/a$g
    //   1447: invokevirtual getClass : ()Ljava/lang/Class;
    //   1450: pop
    //   1451: getstatic com/dimcoms/checkers/MainActivity.a0 : Lcom/dimcoms/checkers/MainActivity$o;
    //   1454: iconst_2
    //   1455: invokevirtual sendEmptyMessage : (I)Z
    //   1458: pop
    //   1459: goto -> 1462
    //   1462: aload_0
    //   1463: getfield e : I
    //   1466: istore #14
    //   1468: iload #14
    //   1470: iconst_1
    //   1471: if_icmpeq -> 1487
    //   1474: iload #14
    //   1476: iconst_2
    //   1477: if_icmpeq -> 1511
    //   1480: iload #14
    //   1482: iconst_3
    //   1483: if_icmpeq -> 1511
    //   1486: return
    //   1487: getstatic com/dimcoms/checkers/MainActivity.s0 : Ljava/util/ArrayList;
    //   1490: invokevirtual isEmpty : ()Z
    //   1493: ifne -> 1516
    //   1496: getstatic com/dimcoms/checkers/MainActivity.e0 : Ljava/util/ArrayList;
    //   1499: astore_1
    //   1500: aload_1
    //   1501: ifnull -> 1530
    //   1504: aload_1
    //   1505: invokevirtual size : ()I
    //   1508: ifeq -> 1530
    //   1511: aload_0
    //   1512: invokevirtual b : ()V
    //   1515: return
    //   1516: getstatic com/dimcoms/checkers/MySurfaceView2.a0 : Z
    //   1519: ifeq -> 1530
    //   1522: aload_0
    //   1523: invokevirtual b : ()V
    //   1526: iconst_0
    //   1527: putstatic com/dimcoms/checkers/MySurfaceView2.a0 : Z
    //   1530: return
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    if (MainActivity.I && !this.E) {
      setMeasuredDimension(V, T);
      return;
    } 
    paramInt1 = V;
    setMeasuredDimension(paramInt1, paramInt1);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.y) {
      this.A = paramMotionEvent.getX();
      this.B = paramMotionEvent.getY();
      if (MainActivity.I && !this.E) {
        Matrix matrix = new Matrix();
        S.invert(matrix);
        float[] arrayOfFloat = new float[2];
        arrayOfFloat[0] = paramMotionEvent.getX();
        arrayOfFloat[1] = paramMotionEvent.getY();
        matrix.mapPoints(arrayOfFloat);
        this.A = arrayOfFloat[0];
        this.B = arrayOfFloat[1];
      } 
      float f1 = this.A;
      int j = (int)f1;
      float f2 = this.B;
      int i = (int)f2;
      float f4 = j;
      float f3 = this.C;
      if (f4 > f3) {
        j = V;
        if (f4 < j - f3) {
          f4 = i;
          if (f4 > f3 && f4 < j - f3) {
            f4 = this.v;
            i = R;
            j = (int)((f1 - f3) / f4 / i);
            int k = (int)((f2 - f3) / f4 / i);
            if (paramMotionEvent.getAction() != 0)
              return true; 
            ((a.g)this.x).a(j, i - k - 1);
            b();
          } 
        } 
      } 
    } 
    return true;
  }
  
  public void setBoardTable(d paramd) {
    this.w = paramd;
    if (paramd != null)
      R = paramd.j; 
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(true);
    this.y = paramBoolean;
  }
  
  public void setMainActivityListener(MainActivity.p paramp) {
    this.x = paramp;
  }
  
  public final class a implements Runnable {
    public a(MySurfaceView2 this$0) {}
    
    public final void run() {
      this.i.invalidate();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\MySurfaceView2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */