package com.dimcoms.checkers;

import android.graphics.Color;

public final class c extends Thread {
  public final void run() {
    int i = 0;
    while (true) {
      if (MySurfaceView2.e0) {
        i = 150;
        MySurfaceView2.e0 = false;
      } 
      try {
        Thread.sleep(5L);
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
      int j = i;
      if (i > 0)
        j = i - 1; 
      MySurfaceView2.N.setColor(Color.argb(Math.abs(j), 200, 0, 18));
      i = j;
      if (j > 0) {
        MainActivity.a0.sendEmptyMessage(5);
        i = j;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\dimcoms\checkers\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */