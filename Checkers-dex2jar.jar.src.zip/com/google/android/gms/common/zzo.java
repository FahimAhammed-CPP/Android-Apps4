package com.google.android.gms.common;

import android.content.Context;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import m0.q;
import t0.b;
import u0.a;
import u0.b;

public final class zzo extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzo> CREATOR = (Parcelable.Creator<zzo>)new q();
  
  public final String i;
  
  public final boolean j;
  
  public final boolean k;
  
  public final Context l;
  
  public final boolean m;
  
  public zzo(String paramString, boolean paramBoolean1, boolean paramBoolean2, IBinder paramIBinder, boolean paramBoolean3) {
    this.i = paramString;
    this.j = paramBoolean1;
    this.k = paramBoolean2;
    this.l = (Context)b.b1(a.a.a1(paramIBinder));
    this.m = paramBoolean3;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.j(paramParcel, 1, this.i);
    b.d(paramParcel, 2, this.j);
    b.d(paramParcel, 3, this.k);
    b.f(paramParcel, 4, (IBinder)new b(this.l));
    b.d(paramParcel, 5, this.m);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\zzo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */