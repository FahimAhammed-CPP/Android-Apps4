package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable;
import c.c;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import javax.annotation.Nullable;
import m0.r;
import t0.b;

public final class zzq extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzq> CREATOR = (Parcelable.Creator<zzq>)new r();
  
  public final boolean i;
  
  @Nullable
  public final String j;
  
  public final int k;
  
  public final int l;
  
  public zzq(boolean paramBoolean, String paramString, int paramInt1, int paramInt2) {
    this.i = paramBoolean;
    this.j = paramString;
    this.k = b.q(paramInt1) - 1;
    this.l = c.k(paramInt2) - 1;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.d(paramParcel, 1, this.i);
    b.j(paramParcel, 2, this.j);
    b.g(paramParcel, 3, this.k);
    b.g(paramParcel, 4, this.l);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\zzq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */