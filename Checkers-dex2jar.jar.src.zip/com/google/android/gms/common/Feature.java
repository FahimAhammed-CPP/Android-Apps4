package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import m0.g;
import p0.d;
import t0.b;

public class Feature extends AbstractSafeParcelable {
  public static final Parcelable.Creator<Feature> CREATOR = (Parcelable.Creator<Feature>)new g();
  
  public final String i;
  
  @Deprecated
  public final int j;
  
  public final long k;
  
  public Feature(int paramInt, String paramString, long paramLong) {
    this.i = paramString;
    this.j = paramInt;
    this.k = paramLong;
  }
  
  public final long b() {
    long l2 = this.k;
    long l1 = l2;
    if (l2 == -1L)
      l1 = this.j; 
    return l1;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof Feature) {
      paramObject = paramObject;
      String str = this.i;
      if (((str != null && str.equals(((Feature)paramObject).i)) || (this.i == null && ((Feature)paramObject).i == null)) && b() == paramObject.b())
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { this.i, Long.valueOf(b()) });
  }
  
  public final String toString() {
    d.a a = new d.a(this);
    a.a("name", this.i);
    a.a("version", Long.valueOf(b()));
    return a.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.j(paramParcel, 1, this.i);
    b.g(paramParcel, 2, this.j);
    b.h(paramParcel, 3, b());
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\Feature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */