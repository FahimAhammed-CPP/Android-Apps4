package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import m0.f;
import p0.d;
import t0.b;

public final class ConnectionResult extends AbstractSafeParcelable {
  public static final Parcelable.Creator<ConnectionResult> CREATOR;
  
  public static final ConnectionResult m = new ConnectionResult(0);
  
  public final int i;
  
  public final int j;
  
  public final PendingIntent k;
  
  public final String l;
  
  static {
    CREATOR = (Parcelable.Creator<ConnectionResult>)new f();
  }
  
  public ConnectionResult() {}
  
  public ConnectionResult(int paramInt) {
    this(1, paramInt, null, null);
  }
  
  public ConnectionResult(int paramInt1, int paramInt2, PendingIntent paramPendingIntent, String paramString) {
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramPendingIntent;
    this.l = paramString;
  }
  
  public ConnectionResult(int paramInt, PendingIntent paramPendingIntent) {
    this(1, paramInt, paramPendingIntent, null);
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof ConnectionResult))
      return false; 
    paramObject = paramObject;
    return (this.j == ((ConnectionResult)paramObject).j && d.a(this.k, ((ConnectionResult)paramObject).k) && d.a(this.l, ((ConnectionResult)paramObject).l));
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.j), this.k, this.l });
  }
  
  public final String toString() {
    String str;
    d.a a = new d.a(this);
    int i = this.j;
    if (i != 99) {
      if (i != 1500) {
        StringBuilder stringBuilder;
        switch (i) {
          default:
            switch (i) {
              default:
                stringBuilder = new StringBuilder();
                stringBuilder.append("UNKNOWN_ERROR_CODE(");
                stringBuilder.append(i);
                stringBuilder.append(")");
                str = stringBuilder.toString();
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 24:
                str = "API_DISABLED_FOR_CONNECTION";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 23:
                str = "API_DISABLED";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 22:
                str = "RESOLUTION_ACTIVITY_NOT_FOUND";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 21:
                str = "API_VERSION_UPDATE_REQUIRED";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 20:
                str = "RESTRICTED_PROFILE";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 19:
                str = "SERVICE_MISSING_PERMISSION";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 18:
                str = "SERVICE_UPDATING";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 17:
                str = "SIGN_IN_FAILED";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 16:
                str = "API_UNAVAILABLE";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 15:
                str = "INTERRUPTED";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 14:
                str = "TIMEOUT";
                a.a("statusCode", str);
                a.a("resolution", this.k);
                a.a("message", this.l);
                return a.toString();
              case 13:
                break;
            } 
            break;
          case 11:
            str = "LICENSE_CHECK_FAILED";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 10:
            str = "DEVELOPER_ERROR";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 9:
            str = "SERVICE_INVALID";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 8:
            str = "INTERNAL_ERROR";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 7:
            str = "NETWORK_ERROR";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 6:
            str = "RESOLUTION_REQUIRED";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 5:
            str = "INVALID_ACCOUNT";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 4:
            str = "SIGN_IN_REQUIRED";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 3:
            str = "SERVICE_DISABLED";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 2:
            str = "SERVICE_VERSION_UPDATE_REQUIRED";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 1:
            str = "SERVICE_MISSING";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case 0:
            str = "SUCCESS";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
          case -1:
            str = "UNKNOWN";
            a.a("statusCode", str);
            a.a("resolution", this.k);
            a.a("message", this.l);
            return a.toString();
        } 
        str = "CANCELED";
      } else {
        str = "DRIVE_EXTERNAL_STORAGE_REQUIRED";
      } 
    } else {
      str = "UNFINISHED";
    } 
    a.a("statusCode", str);
    a.a("resolution", this.k);
    a.a("message", this.l);
    return a.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.i);
    b.g(paramParcel, 2, this.j);
    b.i(paramParcel, 3, (Parcelable)this.k, paramInt);
    b.j(paramParcel, 4, this.l);
    b.v(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\ConnectionResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */