package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import p0.v;

public class GetServiceRequest extends AbstractSafeParcelable {
  public static final Parcelable.Creator<GetServiceRequest> CREATOR = (Parcelable.Creator<GetServiceRequest>)new v();
  
  public static final Scope[] w = new Scope[0];
  
  public static final Feature[] x = new Feature[0];
  
  public final int i;
  
  public final int j;
  
  public int k;
  
  public String l;
  
  public IBinder m;
  
  public Scope[] n;
  
  public Bundle o;
  
  public Account p;
  
  public Feature[] q;
  
  public Feature[] r;
  
  public boolean s;
  
  public int t;
  
  public boolean u;
  
  public String v;
  
  public GetServiceRequest(int paramInt1, int paramInt2, int paramInt3, String paramString1, IBinder paramIBinder, Scope[] paramArrayOfScope, Bundle paramBundle, Account paramAccount, Feature[] paramArrayOfFeature1, Feature[] paramArrayOfFeature2, boolean paramBoolean1, int paramInt4, boolean paramBoolean2, String paramString2) {
    b b;
    Scope[] arrayOfScope = paramArrayOfScope;
    if (paramArrayOfScope == null)
      arrayOfScope = w; 
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    Feature[] arrayOfFeature = paramArrayOfFeature1;
    if (paramArrayOfFeature1 == null)
      arrayOfFeature = x; 
    paramArrayOfFeature1 = paramArrayOfFeature2;
    if (paramArrayOfFeature2 == null)
      paramArrayOfFeature1 = x; 
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramInt3;
    if ("com.google.android.gms".equals(paramString1)) {
      this.l = "com.google.android.gms";
    } else {
      this.l = paramString1;
    } 
    if (paramInt1 < 2) {
      paramArrayOfFeature2 = null;
      paramAccount = null;
      Feature[] arrayOfFeature1 = paramArrayOfFeature2;
      if (paramIBinder != null) {
        paramInt1 = b.a.a;
        IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.internal.IAccountAccessor");
        if (iInterface instanceof b) {
          b = (b)iInterface;
        } else {
          b = new c((IBinder)b);
        } 
        paramInt1 = a.b;
        Feature[] arrayOfFeature2 = paramArrayOfFeature2;
        if (b != null) {
          long l = Binder.clearCallingIdentity();
          try {
            Account account = b.zzb();
          } catch (RemoteException remoteException) {
            Log.w("AccountAccessor", "Remote account accessor probably died");
          } finally {
            Binder.restoreCallingIdentity(l);
          } 
        } 
      } 
      this.p = (Account)arrayOfFeature1;
    } else {
      this.m = (IBinder)b;
      this.p = paramAccount;
    } 
    this.n = arrayOfScope;
    this.o = bundle;
    this.q = arrayOfFeature;
    this.r = paramArrayOfFeature1;
    this.s = paramBoolean1;
    this.t = paramInt4;
    this.u = paramBoolean2;
    this.v = paramString2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    v.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\GetServiceRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */