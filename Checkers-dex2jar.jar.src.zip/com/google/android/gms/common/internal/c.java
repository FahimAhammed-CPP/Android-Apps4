package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.IBinder;
import android.os.Parcel;
import y0.a;

public final class c extends a implements b {
  public c(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.common.internal.IAccountAccessor", 0);
  }
  
  public final Account zzb() {
    Parcel parcel = Z0(a1(), 2);
    Account account = (Account)y0.c.a(parcel, Account.CREATOR);
    parcel.recycle();
    return account;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */