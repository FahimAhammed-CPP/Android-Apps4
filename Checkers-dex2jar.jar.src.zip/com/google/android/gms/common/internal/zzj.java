package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import p0.t;
import t0.b;

public final class zzj extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzj> CREATOR = (Parcelable.Creator<zzj>)new t();
  
  public Bundle i;
  
  public Feature[] j;
  
  public int k;
  
  public ConnectionTelemetryConfiguration l;
  
  public zzj() {}
  
  public zzj(Bundle paramBundle, Feature[] paramArrayOfFeature, int paramInt, ConnectionTelemetryConfiguration paramConnectionTelemetryConfiguration) {
    this.i = paramBundle;
    this.j = paramArrayOfFeature;
    this.k = paramInt;
    this.l = paramConnectionTelemetryConfiguration;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.m(paramParcel, 20293);
    b.e(paramParcel, 1, this.i);
    b.l(paramParcel, 2, (Parcelable[])this.j, paramInt);
    b.g(paramParcel, 3, this.k);
    b.i(paramParcel, 4, (Parcelable)this.l, paramInt);
    b.v(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\zzj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */