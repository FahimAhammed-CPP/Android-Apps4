package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import p0.u;
import t0.b;

public class ConnectionTelemetryConfiguration extends AbstractSafeParcelable {
  public static final Parcelable.Creator<ConnectionTelemetryConfiguration> CREATOR = (Parcelable.Creator<ConnectionTelemetryConfiguration>)new u();
  
  public final RootTelemetryConfiguration i;
  
  public final boolean j;
  
  public final boolean k;
  
  public final int[] l;
  
  public final int m;
  
  public final int[] n;
  
  public ConnectionTelemetryConfiguration(RootTelemetryConfiguration paramRootTelemetryConfiguration, boolean paramBoolean1, boolean paramBoolean2, int[] paramArrayOfint1, int paramInt, int[] paramArrayOfint2) {
    this.i = paramRootTelemetryConfiguration;
    this.j = paramBoolean1;
    this.k = paramBoolean2;
    this.l = paramArrayOfint1;
    this.m = paramInt;
    this.n = paramArrayOfint2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.m(paramParcel, 20293);
    b.i(paramParcel, 1, (Parcelable)this.i, paramInt);
    b.d(paramParcel, 2, this.j);
    b.d(paramParcel, 3, this.k);
    int[] arrayOfInt = this.l;
    if (arrayOfInt != null) {
      paramInt = b.m(paramParcel, 4);
      paramParcel.writeIntArray(arrayOfInt);
      b.v(paramParcel, paramInt);
    } 
    b.g(paramParcel, 5, this.m);
    arrayOfInt = this.n;
    if (arrayOfInt != null) {
      paramInt = b.m(paramParcel, 6);
      paramParcel.writeIntArray(arrayOfInt);
      b.v(paramParcel, paramInt);
    } 
    b.v(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\ConnectionTelemetryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */