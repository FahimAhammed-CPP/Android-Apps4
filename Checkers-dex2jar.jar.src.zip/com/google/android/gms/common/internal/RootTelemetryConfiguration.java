package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import p0.m;
import t0.b;

public class RootTelemetryConfiguration extends AbstractSafeParcelable {
  public static final Parcelable.Creator<RootTelemetryConfiguration> CREATOR = (Parcelable.Creator<RootTelemetryConfiguration>)new m();
  
  public final int i;
  
  public final boolean j;
  
  public final boolean k;
  
  public final int l;
  
  public final int m;
  
  public RootTelemetryConfiguration(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3) {
    this.i = paramInt1;
    this.j = paramBoolean1;
    this.k = paramBoolean2;
    this.l = paramInt2;
    this.m = paramInt3;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.i);
    b.d(paramParcel, 2, this.j);
    b.d(paramParcel, 3, this.k);
    b.g(paramParcel, 4, this.l);
    b.g(paramParcel, 5, this.m);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\RootTelemetryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */