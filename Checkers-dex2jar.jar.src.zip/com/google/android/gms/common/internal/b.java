package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.IInterface;

public interface b extends IInterface {
  Account zzb();
  
  public static abstract class a extends y0.b implements b {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\internal\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */