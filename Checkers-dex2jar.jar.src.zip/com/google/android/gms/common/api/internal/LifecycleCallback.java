package com.google.android.gms.common.api.internal;

import androidx.annotation.Keep;
import o0.b;
import o0.c;

public class LifecycleCallback {
  @Keep
  private static c getChimeraLifecycleFragmentImpl(b paramb) {
    throw new IllegalStateException("Method not available in SDK.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\api\internal\LifecycleCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */