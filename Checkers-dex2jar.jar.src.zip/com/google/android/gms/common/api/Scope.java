package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import n0.a;
import p0.e;
import t0.b;

public final class Scope extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<Scope> CREATOR = (Parcelable.Creator<Scope>)new a();
  
  public final int i;
  
  public final String j;
  
  public Scope(int paramInt, String paramString) {
    e.e(paramString, "scopeUri must not be null or empty");
    this.i = paramInt;
    this.j = paramString;
  }
  
  public final boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof Scope) ? false : this.j.equals(((Scope)paramObject).j));
  }
  
  public final int hashCode() {
    return this.j.hashCode();
  }
  
  public final String toString() {
    return this.j;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.i);
    b.j(paramParcel, 2, this.j);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\api\Scope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */