package com.google.android.gms.common;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import javax.annotation.Nullable;
import m0.l;
import m0.m;
import m0.s;
import p0.c0;
import p0.d0;
import p0.e0;
import t0.b;
import u0.a;
import u0.b;

public final class zzs extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzs> CREATOR = (Parcelable.Creator<zzs>)new s();
  
  public final String i;
  
  @Nullable
  public final l j;
  
  public final boolean k;
  
  public final boolean l;
  
  public zzs(String paramString, @Nullable IBinder paramIBinder, boolean paramBoolean1, boolean paramBoolean2) {
    String str1;
    this.i = paramString;
    String str2 = null;
    if (paramIBinder == null) {
      paramString = str2;
    } else {
      try {
        c0 c0;
        byte[] arrayOfByte;
        int i = d0.a;
        IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.internal.ICertData");
        if (iInterface instanceof e0) {
          e0 e0 = (e0)iInterface;
        } else {
          c0 = new c0(paramIBinder);
        } 
        a a = c0.zzd();
        if (a == null) {
          a = null;
        } else {
          arrayOfByte = (byte[])b.b1(a);
        } 
        if (arrayOfByte != null) {
          m m = new m(arrayOfByte);
        } else {
          Log.e("GoogleCertificatesQuery", "Could not unwrap certificate");
          str1 = str2;
        } 
      } catch (RemoteException remoteException) {
        Log.e("GoogleCertificatesQuery", "Could not unwrap certificate", (Throwable)remoteException);
        str1 = str2;
      } 
    } 
    this.j = (l)str1;
    this.k = paramBoolean1;
    this.l = paramBoolean2;
  }
  
  public zzs(String paramString, @Nullable l paraml, boolean paramBoolean1, boolean paramBoolean2) {
    this.i = paramString;
    this.j = paraml;
    this.k = paramBoolean1;
    this.l = paramBoolean2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.j(paramParcel, 1, this.i);
    l l2 = this.j;
    l l1 = l2;
    if (l2 == null) {
      Log.w("GoogleCertificatesQuery", "certificate binder is null");
      l1 = null;
    } 
    b.f(paramParcel, 2, (IBinder)l1);
    b.d(paramParcel, 3, this.k);
    b.d(paramParcel, 4, this.l);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\common\zzs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */