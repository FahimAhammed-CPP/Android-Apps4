package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import android.text.TextUtils;
import android.webkit.WebView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.internal.client.zzej;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;
import p0.e;
import u0.b;
import w0.a8;
import w0.l6;
import w0.l8;

public class MobileAds {
  public static final String ERROR_DOMAIN = "com.google.android.gms.ads";
  
  public static void disableMediationAdapterInitialization(Context paramContext) {
    zzej.zzf().zzl(paramContext);
  }
  
  public static void enableSameAppKey(boolean paramBoolean) {
    zzej.zzf().zzm(paramBoolean);
  }
  
  public static InitializationStatus getInitializationStatus() {
    return zzej.zzf().zze();
  }
  
  public static RequestConfiguration getRequestConfiguration() {
    return zzej.zzf().zzc();
  }
  
  public static VersionInfo getVersion() {
    zzej.zzf();
    String[] arrayOfString = TextUtils.split("21.4.0", "\\.");
    if (arrayOfString.length != 3)
      return new VersionInfo(0, 0, 0); 
    try {
      return new VersionInfo(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]));
    } catch (NumberFormatException numberFormatException) {
      return new VersionInfo(0, 0, 0);
    } 
  }
  
  @Deprecated
  public static String getVersionString() {
    return zzej.zzf().zzh();
  }
  
  public static void initialize(Context paramContext) {
    zzej.zzf().zzn(paramContext, null, null);
  }
  
  public static void initialize(Context paramContext, OnInitializationCompleteListener paramOnInitializationCompleteListener) {
    zzej.zzf().zzn(paramContext, null, paramOnInitializationCompleteListener);
  }
  
  public static void openAdInspector(Context paramContext, OnAdInspectorClosedListener paramOnAdInspectorClosedListener) {
    zzej.zzf().zzq(paramContext, paramOnAdInspectorClosedListener);
  }
  
  public static void openDebugMenu(Context paramContext, String paramString) {
    zzej.zzf().zzr(paramContext, paramString);
  }
  
  public static void registerRtbAdapter(Class<? extends RtbAdapter> paramClass) {
    zzej.zzf().zzs(paramClass);
  }
  
  public static void registerWebView(WebView paramWebView) {
    zzej.zzf();
    e.c("#008 Must be called on the main UI thread.");
    if (paramWebView == null) {
      l8.c("The webview to be registered cannot be null.");
      return;
    } 
    a8 a8 = l6.a(paramWebView.getContext());
    if (a8 == null) {
      l8.f("Internal error, query info generator is null.");
      return;
    } 
    try {
      a8.g(new b(paramWebView));
      return;
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return;
    } 
  }
  
  public static void setAppMuted(boolean paramBoolean) {
    zzej.zzf().zzt(paramBoolean);
  }
  
  public static void setAppVolume(float paramFloat) {
    zzej.zzf().zzu(paramFloat);
  }
  
  public static void setRequestConfiguration(RequestConfiguration paramRequestConfiguration) {
    zzej.zzf().zzv(paramRequestConfiguration);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\MobileAds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */