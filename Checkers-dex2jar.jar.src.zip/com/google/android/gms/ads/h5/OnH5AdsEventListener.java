package com.google.android.gms.ads.h5;

public interface OnH5AdsEventListener {
  void onH5AdsEvent(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\h5\OnH5AdsEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */