package com.google.android.gms.ads.h5;

import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import w0.c3;
import w0.s2;

public final class H5AdsWebViewClient extends s2 {
  public final c3 a;
  
  public H5AdsWebViewClient(Context paramContext, WebView paramWebView) {
    this.a = new c3(paramContext, paramWebView);
  }
  
  public final WebViewClient a() {
    return (WebViewClient)this.a;
  }
  
  public void clearAdObjects() {
    this.a.b.clearAdObjects();
  }
  
  public WebViewClient getDelegateWebViewClient() {
    return this.a.a;
  }
  
  public void setDelegateWebViewClient(WebViewClient paramWebViewClient) {
    boolean bool;
    c3 c31 = this.a;
    c31.getClass();
    if (paramWebViewClient != c31) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      c31.a = paramWebViewClient;
      return;
    } 
    throw new IllegalArgumentException("Delegate cannot be itself.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\h5\H5AdsWebViewClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */