package com.google.android.gms.ads.h5;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzba;
import w0.b3;
import w0.l8;
import w0.n;
import w0.s;
import w0.t3;
import w0.w3;
import w0.x2;
import w0.z;

public final class H5AdsRequestHandler {
  public final b3 a;
  
  public H5AdsRequestHandler(Context paramContext, OnH5AdsEventListener paramOnH5AdsEventListener) {
    this.a = new b3(paramContext, paramOnH5AdsEventListener);
  }
  
  public void clearAdObjects() {
    b3 b31 = this.a;
    b31.getClass();
    n n = z.i;
    if (!((Boolean)zzba.zzc().a((s)n)).booleanValue())
      return; 
    if (b31.c == null)
      b31.c = zzay.zza().zzl(b31.a, (w3)new t3(), b31.b); 
    x2 x2 = b31.c;
    if (x2 != null)
      try {
        x2.zze();
        return;
      } catch (RemoteException remoteException) {
        l8.h((Exception)remoteException);
      }  
  }
  
  public boolean handleH5AdsRequest(String paramString) {
    b3 b31 = this.a;
    b31.getClass();
    if (b3.a(paramString)) {
      if (b31.c == null)
        b31.c = zzay.zza().zzl(b31.a, (w3)new t3(), b31.b); 
      x2 x2 = b31.c;
      if (x2 != null) {
        try {
          x2.b(paramString);
        } catch (RemoteException remoteException) {
          l8.h((Exception)remoteException);
        } 
        return true;
      } 
    } 
    return false;
  }
  
  public boolean shouldInterceptRequest(String paramString) {
    return b3.a(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\h5\H5AdsRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */