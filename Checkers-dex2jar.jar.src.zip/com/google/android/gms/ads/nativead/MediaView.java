package com.google.android.gms.ads.nativead;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.MediaContent;
import u0.a;
import u0.b;
import w0.i1;
import w0.l8;
import w0.x0;

public class MediaView extends FrameLayout {
  public MediaContent a;
  
  public boolean b;
  
  public ImageView.ScaleType c;
  
  public boolean d;
  
  public zzb e;
  
  public zzc f;
  
  public MediaView(Context paramContext) {
    super(paramContext);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  @TargetApi(21)
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public MediaContent getMediaContent() {
    return this.a;
  }
  
  public void setImageScaleType(ImageView.ScaleType paramScaleType) {
    this.d = true;
    this.c = paramScaleType;
    zzc zzc1 = this.f;
    if (zzc1 != null) {
      x0 x0 = zzc1.zza.b;
      if (x0 == null)
        return; 
      if (paramScaleType != null)
        try {
          x0.zzbB((a)new b(paramScaleType));
          return;
        } catch (RemoteException remoteException) {
          l8.d("Unable to call setMediaViewImageScaleType on delegate", (Throwable)remoteException);
        }  
    } 
  }
  
  public void setMediaContent(MediaContent paramMediaContent) {
    this.b = true;
    this.a = paramMediaContent;
    zzb zzb1 = this.e;
    if (zzb1 != null)
      zzb1.zza.b(paramMediaContent); 
    if (paramMediaContent == null)
      return; 
    try {
      i1 i1 = paramMediaContent.zza();
      if (i1 != null && !i1.G0((a)new b(this)))
        removeAllViews(); 
      return;
    } catch (RemoteException remoteException) {
      removeAllViews();
      l8.d("", (Throwable)remoteException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\nativead\MediaView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */