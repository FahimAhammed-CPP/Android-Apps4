package com.google.android.gms.ads.nativead;

import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.ads.internal.client.zzay;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import u0.a;
import u0.b;
import w0.d1;
import w0.l8;

public final class NativeAdViewHolder {
  public static WeakHashMap zza = new WeakHashMap<Object, Object>();
  
  @NotOnlyInitialized
  public d1 a;
  
  public WeakReference b;
  
  public NativeAdViewHolder(View paramView, Map<String, View> paramMap1, Map<String, View> paramMap2) {
    if (paramView != null) {
      if (paramView instanceof NativeAdView) {
        l8.c("The provided containerView is of type of NativeAdView, which cannot be usedwith NativeAdViewHolder.");
        return;
      } 
      if (zza.get(paramView) != null) {
        l8.c("The provided containerView is already in use with another NativeAdViewHolder.");
        return;
      } 
      zza.put(paramView, this);
      this.b = new WeakReference<View>(paramView);
      if (paramMap1 == null) {
        paramMap1 = new HashMap<String, View>();
      } else {
        paramMap1 = new HashMap<String, View>(paramMap1);
      } 
      if (paramMap2 == null) {
        paramMap2 = new HashMap<String, View>();
      } else {
        paramMap2 = new HashMap<String, View>(paramMap2);
      } 
      this.a = zzay.zza().zzi(paramView, (HashMap)paramMap1, (HashMap)paramMap2);
      return;
    } 
    throw new NullPointerException("ContainerView must not be null");
  }
  
  public final void setClickConfirmingView(View paramView) {
    try {
      this.a.zzb((a)new b(paramView));
      return;
    } catch (RemoteException remoteException) {
      l8.d("Unable to call setClickConfirmingView on delegate", (Throwable)remoteException);
      return;
    } 
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    a a = paramNativeAd.a();
    WeakReference<View> weakReference = this.b;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (weakReference == null) {
      l8.f("NativeAdViewHolder.setNativeAd containerView doesn't exist, returning");
      return;
    } 
    if (!zza.containsKey(weakReference))
      zza.put(weakReference, this); 
    d1 d11 = this.a;
    if (d11 != null)
      try {
        d11.zzc(a);
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to call setNativeAd on delegate", (Throwable)remoteException);
      }  
  }
  
  public void unregisterNativeAd() {
    d1 d11 = this.a;
    if (d11 != null)
      try {
        d11.zzd();
      } catch (RemoteException remoteException) {
        l8.d("Unable to call unregisterNativeAd on delegate", (Throwable)remoteException);
      }  
    WeakReference<View> weakReference = this.b;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (weakReference != null)
      zza.remove(weakReference); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */