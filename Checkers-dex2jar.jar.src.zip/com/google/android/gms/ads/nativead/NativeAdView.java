package com.google.android.gms.ads.nativead;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzep;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;
import u0.a;
import u0.b;
import w0.l8;
import w0.n;
import w0.s;
import w0.x0;
import w0.z;

public final class NativeAdView extends FrameLayout {
  @NotOnlyInitialized
  public final FrameLayout a;
  
  @NotOnlyInitialized
  public final x0 b;
  
  public NativeAdView(Context paramContext) {
    super(paramContext);
    this.a = c(paramContext);
    this.b = d();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.a = c(paramContext);
    this.b = d();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.a = c(paramContext);
    this.b = d();
  }
  
  @TargetApi(21)
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.a = c(paramContext);
    this.b = d();
  }
  
  public final View a(String paramString) {
    x0 x01 = this.b;
    if (x01 != null)
      try {
        a a = x01.zzb(paramString);
        if (a != null)
          return (View)b.b1(a); 
      } catch (RemoteException remoteException) {
        l8.d("Unable to call getAssetView on delegate", (Throwable)remoteException);
      }  
    return null;
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    super.bringChildToFront((View)this.a);
  }
  
  public final void bringChildToFront(View paramView) {
    super.bringChildToFront(paramView);
    FrameLayout frameLayout = this.a;
    if (frameLayout != paramView)
      super.bringChildToFront((View)frameLayout); 
  }
  
  public final FrameLayout c(Context paramContext) {
    FrameLayout frameLayout = new FrameLayout(paramContext);
    frameLayout.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    addView((View)frameLayout);
    return frameLayout;
  }
  
  @RequiresNonNull({"overlayFrame"})
  public final x0 d() {
    return isInEditMode() ? null : zzay.zza().zzh(this.a.getContext(), this, this.a);
  }
  
  public void destroy() {
    x0 x01 = this.b;
    if (x01 != null)
      try {
        x01.zzc();
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to destroy native ad view", (Throwable)remoteException);
      }  
  }
  
  public final boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    if (this.b != null) {
      n n = z.q;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue())
        try {
          this.b.zzd((a)new b(paramMotionEvent));
        } catch (RemoteException remoteException) {
          l8.d("Unable to call handleTouchEvent on delegate", (Throwable)remoteException);
        }  
    } 
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  public final void e(String paramString, View paramView) {
    x0 x01 = this.b;
    if (x01 != null)
      try {
        x01.zzby(paramString, (a)new b(paramView));
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to call setAssetView on delegate", (Throwable)remoteException);
      }  
  }
  
  public AdChoicesView getAdChoicesView() {
    View view = a("3011");
    return (view instanceof AdChoicesView) ? (AdChoicesView)view : null;
  }
  
  public final View getAdvertiserView() {
    return a("3005");
  }
  
  public final View getBodyView() {
    return a("3004");
  }
  
  public final View getCallToActionView() {
    return a("3002");
  }
  
  public final View getHeadlineView() {
    return a("3001");
  }
  
  public final View getIconView() {
    return a("3003");
  }
  
  public final View getImageView() {
    return a("3008");
  }
  
  public final MediaView getMediaView() {
    View view = a("3010");
    if (view instanceof MediaView)
      return (MediaView)view; 
    if (view != null)
      l8.b("View is not an instance of MediaView"); 
    return null;
  }
  
  public final View getPriceView() {
    return a("3007");
  }
  
  public final View getStarRatingView() {
    return a("3009");
  }
  
  public final View getStoreView() {
    return a("3006");
  }
  
  public final void onVisibilityChanged(View paramView, int paramInt) {
    super.onVisibilityChanged(paramView, paramInt);
    x0 x01 = this.b;
    if (x01 != null)
      try {
        x01.zze((a)new b(paramView), paramInt);
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to call onVisibilityChanged on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void removeAllViews() {
    super.removeAllViews();
    addView((View)this.a);
  }
  
  public final void removeView(View paramView) {
    if (this.a == paramView)
      return; 
    super.removeView(paramView);
  }
  
  public void setAdChoicesView(AdChoicesView paramAdChoicesView) {
    e("3011", (View)paramAdChoicesView);
  }
  
  public final void setAdvertiserView(View paramView) {
    e("3005", paramView);
  }
  
  public final void setBodyView(View paramView) {
    e("3004", paramView);
  }
  
  public final void setCallToActionView(View paramView) {
    e("3002", paramView);
  }
  
  public final void setClickConfirmingView(View paramView) {
    x0 x01 = this.b;
    if (x01 != null)
      try {
        x01.zzbz((a)new b(paramView));
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to call setClickConfirmingView on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void setHeadlineView(View paramView) {
    e("3001", paramView);
  }
  
  public final void setIconView(View paramView) {
    e("3003", paramView);
  }
  
  public final void setImageView(View paramView) {
    e("3008", paramView);
  }
  
  public final void setMediaView(MediaView paramMediaView) {
    e("3010", (View)paramMediaView);
    if (paramMediaView == null)
      return; 
    synchronized (new zzb(this)) {
      paramMediaView.e = null;
      if (paramMediaView.b) {
        MediaContent mediaContent = paramMediaView.a;
        null.zza.b(mediaContent);
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/google/android/gms/ads/nativead/MediaView}, name=paramMediaView} */
      synchronized (new zzc(this)) {
        paramMediaView.f = null;
        if (paramMediaView.d) {
          ImageView.ScaleType scaleType = paramMediaView.c;
          x0 x01 = null.zza.b;
          if (x01 != null && scaleType != null)
            try {
              x01.zzbB((a)new b(scaleType));
            } catch (RemoteException remoteException) {
              l8.d("Unable to call setMediaViewImageScaleType on delegate", (Throwable)remoteException);
            }  
        } 
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/google/android/gms/ads/nativead/MediaView}, name=paramMediaView} */
        return;
      } 
    } 
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    x0 x01 = this.b;
    if (x01 != null)
      try {
        x01.zzbC(paramNativeAd.a());
        return;
      } catch (RemoteException remoteException) {
        l8.d("Unable to call setNativeAd on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void setPriceView(View paramView) {
    e("3007", paramView);
  }
  
  public final void setStarRatingView(View paramView) {
    e("3009", paramView);
  }
  
  public final void setStoreView(View paramView) {
    e("3006", paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */