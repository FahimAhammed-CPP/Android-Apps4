package com.google.android.gms.ads.nativead;

import com.google.android.gms.ads.VideoOptions;

public final class NativeAdOptions {
  public static final int ADCHOICES_BOTTOM_LEFT = 3;
  
  public static final int ADCHOICES_BOTTOM_RIGHT = 2;
  
  public static final int ADCHOICES_TOP_LEFT = 0;
  
  public static final int ADCHOICES_TOP_RIGHT = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_ANY = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE = 2;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT = 3;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_SQUARE = 4;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_UNKNOWN = 0;
  
  public static final int SWIPE_GESTURE_DIRECTION_DOWN = 8;
  
  public static final int SWIPE_GESTURE_DIRECTION_LEFT = 2;
  
  public static final int SWIPE_GESTURE_DIRECTION_RIGHT = 1;
  
  public static final int SWIPE_GESTURE_DIRECTION_UP = 4;
  
  public final boolean a;
  
  public final int b;
  
  public final boolean c;
  
  public final int d;
  
  public final VideoOptions e;
  
  public final boolean f;
  
  public final boolean g;
  
  public final int h;
  
  public int getAdChoicesPlacement() {
    return this.d;
  }
  
  public int getMediaAspectRatio() {
    return this.b;
  }
  
  public VideoOptions getVideoOptions() {
    return this.e;
  }
  
  public boolean shouldRequestMultipleImages() {
    return this.c;
  }
  
  public boolean shouldReturnUrlsForImageAssets() {
    return this.a;
  }
  
  public final int zza() {
    return this.h;
  }
  
  public final boolean zzb() {
    return this.g;
  }
  
  public final boolean zzc() {
    return this.f;
  }
  
  public static @interface AdChoicesPlacement {}
  
  public static final class Builder {
    public boolean a = false;
    
    public int b = 0;
    
    public boolean c = false;
    
    public VideoOptions d;
    
    public int e = 1;
    
    public boolean f = false;
    
    public boolean g = false;
    
    public int h = 0;
    
    public NativeAdOptions build() {
      return new NativeAdOptions(this);
    }
    
    public Builder enableCustomClickGestureDirection(@SwipeGestureDirection int param1Int, boolean param1Boolean) {
      this.g = param1Boolean;
      this.h = param1Int;
      return this;
    }
    
    public Builder setAdChoicesPlacement(@AdChoicesPlacement int param1Int) {
      this.e = param1Int;
      return this;
    }
    
    public Builder setMediaAspectRatio(@NativeMediaAspectRatio int param1Int) {
      this.b = param1Int;
      return this;
    }
    
    public Builder setRequestCustomMuteThisAd(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    public Builder setRequestMultipleImages(boolean param1Boolean) {
      this.c = param1Boolean;
      return this;
    }
    
    public Builder setReturnUrlsForImageAssets(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
    
    public Builder setVideoOptions(VideoOptions param1VideoOptions) {
      this.d = param1VideoOptions;
      return this;
    }
  }
  
  public static @interface NativeMediaAspectRatio {}
  
  public static @interface SwipeGestureDirection {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */