package com.google.android.gms.ads;

import android.content.Context;
import android.util.AttributeSet;

public final class AdView extends BaseAdView {
  public AdView(Context paramContext) {
    super(paramContext);
    if (paramContext != null)
      return; 
    throw new NullPointerException("Context cannot be null");
  }
  
  public AdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public AdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public final VideoController zza() {
    return this.a.zzf();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */