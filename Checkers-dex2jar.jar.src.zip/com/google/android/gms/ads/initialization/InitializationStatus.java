package com.google.android.gms.ads.initialization;

import java.util.Map;

public interface InitializationStatus {
  Map<String, AdapterStatus> getAdapterStatusMap();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\initialization\InitializationStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */