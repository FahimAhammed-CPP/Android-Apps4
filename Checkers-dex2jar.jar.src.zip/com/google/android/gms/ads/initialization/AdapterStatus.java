package com.google.android.gms.ads.initialization;

public interface AdapterStatus {
  String getDescription();
  
  State getInitializationState();
  
  int getLatency();
  
  public enum State {
    NOT_READY, READY;
    
    static {
      State state1 = new State(0, "NOT_READY");
      NOT_READY = state1;
      State state2 = new State(1, "READY");
      READY = state2;
      i = new State[] { state1, state2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\initialization\AdapterStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */