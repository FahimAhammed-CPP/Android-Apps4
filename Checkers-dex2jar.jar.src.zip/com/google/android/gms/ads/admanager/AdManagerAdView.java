package com.google.android.gms.ads.admanager;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.BaseAdView;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzbu;
import p0.e;
import w0.f0;
import w0.g8;
import w0.n;
import w0.s;
import w0.z;

public final class AdManagerAdView extends BaseAdView {
  public AdManagerAdView(Context paramContext) {
    super(paramContext);
    if (paramContext != null)
      return; 
    throw new NullPointerException("Context cannot be null");
  }
  
  public AdManagerAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    if (paramContext != null)
      return; 
    throw new NullPointerException("Context cannot be null");
  }
  
  public AdManagerAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt, null);
    if (paramContext != null)
      return; 
    throw new NullPointerException("Context cannot be null");
  }
  
  public AdSize[] getAdSizes() {
    return this.a.zzB();
  }
  
  public AppEventListener getAppEventListener() {
    return this.a.zzh();
  }
  
  public VideoController getVideoController() {
    return this.a.zzf();
  }
  
  public VideoOptions getVideoOptions() {
    return this.a.zzg();
  }
  
  public void loadAd(AdManagerAdRequest paramAdManagerAdRequest) {
    e.c("#008 Must be called on the main UI thread.");
    z.a(getContext());
    if (((Boolean)f0.f.c()).booleanValue()) {
      n n = z.p;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zzb(this, paramAdManagerAdRequest));
        return;
      } 
    } 
    this.a.zzm(paramAdManagerAdRequest.zza());
  }
  
  public void recordManualImpression() {
    this.a.zzo();
  }
  
  public void setAdSizes(AdSize... paramVarArgs) {
    if (paramVarArgs != null && paramVarArgs.length > 0) {
      this.a.zzt(paramVarArgs);
      return;
    } 
    throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
  }
  
  public void setAppEventListener(AppEventListener paramAppEventListener) {
    this.a.zzv(paramAppEventListener);
  }
  
  public void setManualImpressionsEnabled(boolean paramBoolean) {
    this.a.zzw(paramBoolean);
  }
  
  public void setVideoOptions(VideoOptions paramVideoOptions) {
    this.a.zzy(paramVideoOptions);
  }
  
  public final boolean zzb(zzbu paramzzbu) {
    return this.a.zzz(paramzzbu);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\admanager\AdManagerAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */