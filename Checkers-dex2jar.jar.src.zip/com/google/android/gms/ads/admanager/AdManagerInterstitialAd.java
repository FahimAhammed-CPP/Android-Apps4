package com.google.android.gms.ads.admanager;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import p0.e;
import w0.f0;
import w0.g8;
import w0.n;
import w0.p3;
import w0.s;
import w0.z;

public abstract class AdManagerInterstitialAd extends InterstitialAd {
  public static void load(Context paramContext, String paramString, AdManagerAdRequest paramAdManagerAdRequest, AdManagerInterstitialAdLoadCallback paramAdManagerInterstitialAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdManagerAdRequest != null) {
          if (paramAdManagerInterstitialAdLoadCallback != null) {
            e.c("#008 Must be called on the main UI thread.");
            z.a(paramContext);
            if (((Boolean)f0.i.c()).booleanValue()) {
              n n = z.p;
              if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
                g8.b.execute(new zzc(paramContext, paramString, paramAdManagerAdRequest, paramAdManagerInterstitialAdLoadCallback));
                return;
              } 
            } 
            (new p3(paramContext, paramString)).a(paramAdManagerAdRequest.zza(), paramAdManagerInterstitialAdLoadCallback);
            return;
          } 
          throw new NullPointerException("LoadCallback cannot be null.");
        } 
        throw new NullPointerException("AdManagerAdRequest cannot be null.");
      } 
      throw new NullPointerException("AdUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public abstract AppEventListener getAppEventListener();
  
  public abstract void setAppEventListener(AppEventListener paramAppEventListener);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\admanager\AdManagerInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */