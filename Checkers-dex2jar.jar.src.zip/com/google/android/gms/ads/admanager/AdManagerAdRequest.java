package com.google.android.gms.ads.admanager;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.query.AdInfo;
import java.util.List;

public final class AdManagerAdRequest extends AdRequest {
  public Bundle getCustomTargeting() {
    return this.a.zze();
  }
  
  public String getPublisherProvidedId() {
    return this.a.zzm();
  }
  
  public final zzdx zza() {
    return this.a;
  }
  
  public static final class Builder extends AdRequest.Builder {
    public Builder addCategoryExclusion(String param1String) {
      this.a.zzq(param1String);
      return this;
    }
    
    public Builder addCustomTargeting(String param1String1, String param1String2) {
      this.a.zzs(param1String1, param1String2);
      return this;
    }
    
    public Builder addCustomTargeting(String param1String, List<String> param1List) {
      if (param1List != null)
        this.a.zzs(param1String, TextUtils.join(",", param1List)); 
      return this;
    }
    
    public AdManagerAdRequest build() {
      return new AdManagerAdRequest(this);
    }
    
    @Deprecated
    public Builder setAdInfo(AdInfo param1AdInfo) {
      this.a.zzy(param1AdInfo);
      return this;
    }
    
    public Builder setAdString(String param1String) {
      this.a.zzz(param1String);
      return this;
    }
    
    public Builder setPublisherProvidedId(String param1String) {
      this.a.zzG(param1String);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\admanager\AdManagerAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */