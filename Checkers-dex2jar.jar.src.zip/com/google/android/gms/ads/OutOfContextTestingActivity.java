package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.widget.LinearLayout;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdj;
import u0.a;
import u0.b;
import w0.t3;
import w0.w3;

public final class OutOfContextTestingActivity extends Activity {
  public static final String AD_UNIT_KEY = "adUnit";
  
  public static final String CLASS_NAME = "com.google.android.gms.ads.OutOfContextTestingActivity";
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    zzdj zzdj = zzay.zza().zzf((Context)this, (w3)new t3());
    if (zzdj == null) {
      finish();
      return;
    } 
    setContentView(R.layout.admob_empty_layout);
    LinearLayout linearLayout = (LinearLayout)findViewById(R.id.layout);
    Intent intent = getIntent();
    if (intent == null) {
      finish();
      return;
    } 
    String str = intent.getStringExtra("adUnit");
    if (str == null) {
      finish();
      return;
    } 
    try {
      zzdj.zze(str, (a)new b(this), (a)new b(linearLayout));
      return;
    } catch (RemoteException remoteException) {
      finish();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\OutOfContextTestingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */