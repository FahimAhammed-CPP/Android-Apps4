package com.google.android.gms.ads.search;

import android.os.Bundle;
import com.google.android.gms.ads.internal.client.zzdw;
import com.google.android.gms.ads.mediation.NetworkExtras;

public final class zzb {
  public final zzdw a = new zzdw();
  
  public String b;
  
  public final zzb zzb(Class paramClass, Bundle paramBundle) {
    this.a.zzr(paramClass, paramBundle);
    return this;
  }
  
  public final zzb zzc(NetworkExtras paramNetworkExtras) {
    this.a.zzv(paramNetworkExtras);
    return this;
  }
  
  public final zzb zzd(Class paramClass, Bundle paramBundle) {
    this.a.zzu(paramClass, paramBundle);
    return this;
  }
  
  public final zzb zze(String paramString) {
    this.b = paramString;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\search\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */