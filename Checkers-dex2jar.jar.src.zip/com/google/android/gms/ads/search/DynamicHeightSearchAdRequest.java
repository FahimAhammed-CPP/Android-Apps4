package com.google.android.gms.ads.search;

import android.content.Context;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;

public final class DynamicHeightSearchAdRequest {
  public final SearchAdRequest a;
  
  public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> paramClass) {
    return this.a.getCustomEventExtrasBundle(paramClass);
  }
  
  public <T extends MediationAdapter> Bundle getNetworkExtrasBundle(Class<T> paramClass) {
    return this.a.getNetworkExtrasBundle(paramClass);
  }
  
  public String getQuery() {
    return this.a.getQuery();
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.a.isTestDevice(paramContext);
  }
  
  public static final class Builder {
    public final zzb a = new zzb();
    
    public final Bundle b = new Bundle();
    
    public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> param1Class, Bundle param1Bundle) {
      this.a.zzb(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addNetworkExtras(NetworkExtras param1NetworkExtras) {
      this.a.zzc(param1NetworkExtras);
      return this;
    }
    
    public Builder addNetworkExtrasBundle(Class<? extends MediationAdapter> param1Class, Bundle param1Bundle) {
      this.a.zzd(param1Class, param1Bundle);
      return this;
    }
    
    public DynamicHeightSearchAdRequest build() {
      this.a.zzd(AdMobAdapter.class, this.b);
      return new DynamicHeightSearchAdRequest(this);
    }
    
    public Builder setAdBorderSelectors(String param1String) {
      this.b.putString("csa_adBorderSelectors", param1String);
      return this;
    }
    
    public Builder setAdTest(boolean param1Boolean) {
      String str;
      Bundle bundle = this.b;
      if (true != param1Boolean) {
        str = "off";
      } else {
        str = "on";
      } 
      bundle.putString("csa_adtest", str);
      return this;
    }
    
    public Builder setAdjustableLineHeight(int param1Int) {
      this.b.putString("csa_adjustableLineHeight", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setAdvancedOptionValue(String param1String1, String param1String2) {
      this.b.putString(param1String1, param1String2);
      return this;
    }
    
    public Builder setAttributionSpacingBelow(int param1Int) {
      this.b.putString("csa_attributionSpacingBelow", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setBorderSelections(String param1String) {
      this.b.putString("csa_borderSelections", param1String);
      return this;
    }
    
    public Builder setChannel(String param1String) {
      this.b.putString("csa_channel", param1String);
      return this;
    }
    
    public Builder setColorAdBorder(String param1String) {
      this.b.putString("csa_colorAdBorder", param1String);
      return this;
    }
    
    public Builder setColorAdSeparator(String param1String) {
      this.b.putString("csa_colorAdSeparator", param1String);
      return this;
    }
    
    public Builder setColorAnnotation(String param1String) {
      this.b.putString("csa_colorAnnotation", param1String);
      return this;
    }
    
    public Builder setColorAttribution(String param1String) {
      this.b.putString("csa_colorAttribution", param1String);
      return this;
    }
    
    public Builder setColorBackground(String param1String) {
      this.b.putString("csa_colorBackground", param1String);
      return this;
    }
    
    public Builder setColorBorder(String param1String) {
      this.b.putString("csa_colorBorder", param1String);
      return this;
    }
    
    public Builder setColorDomainLink(String param1String) {
      this.b.putString("csa_colorDomainLink", param1String);
      return this;
    }
    
    public Builder setColorText(String param1String) {
      this.b.putString("csa_colorText", param1String);
      return this;
    }
    
    public Builder setColorTitleLink(String param1String) {
      this.b.putString("csa_colorTitleLink", param1String);
      return this;
    }
    
    public Builder setCssWidth(int param1Int) {
      this.b.putString("csa_width", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setDetailedAttribution(boolean param1Boolean) {
      this.b.putString("csa_detailedAttribution", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setFontFamily(String param1String) {
      this.b.putString("csa_fontFamily", param1String);
      return this;
    }
    
    public Builder setFontFamilyAttribution(String param1String) {
      this.b.putString("csa_fontFamilyAttribution", param1String);
      return this;
    }
    
    public Builder setFontSizeAnnotation(int param1Int) {
      this.b.putString("csa_fontSizeAnnotation", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setFontSizeAttribution(int param1Int) {
      this.b.putString("csa_fontSizeAttribution", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setFontSizeDescription(int param1Int) {
      this.b.putString("csa_fontSizeDescription", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setFontSizeDomainLink(int param1Int) {
      this.b.putString("csa_fontSizeDomainLink", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setFontSizeTitle(int param1Int) {
      this.b.putString("csa_fontSizeTitle", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setHostLanguage(String param1String) {
      this.b.putString("csa_hl", param1String);
      return this;
    }
    
    public Builder setIsClickToCallEnabled(boolean param1Boolean) {
      this.b.putString("csa_clickToCall", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsLocationEnabled(boolean param1Boolean) {
      this.b.putString("csa_location", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsPlusOnesEnabled(boolean param1Boolean) {
      this.b.putString("csa_plusOnes", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsSellerRatingsEnabled(boolean param1Boolean) {
      this.b.putString("csa_sellerRatings", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsSiteLinksEnabled(boolean param1Boolean) {
      this.b.putString("csa_siteLinks", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsTitleBold(boolean param1Boolean) {
      this.b.putString("csa_titleBold", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setIsTitleUnderlined(boolean param1Boolean) {
      this.b.putString("csa_noTitleUnderline", Boolean.toString(param1Boolean ^ true));
      return this;
    }
    
    public Builder setLocationColor(String param1String) {
      this.b.putString("csa_colorLocation", param1String);
      return this;
    }
    
    public Builder setLocationFontSize(int param1Int) {
      this.b.putString("csa_fontSizeLocation", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setLongerHeadlines(boolean param1Boolean) {
      this.b.putString("csa_longerHeadlines", Boolean.toString(param1Boolean));
      return this;
    }
    
    public Builder setNumber(int param1Int) {
      this.b.putString("csa_number", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setPage(int param1Int) {
      this.b.putString("csa_adPage", Integer.toString(param1Int));
      return this;
    }
    
    public Builder setQuery(String param1String) {
      this.a.zze(param1String);
      return this;
    }
    
    public Builder setStyleId(String param1String) {
      this.b.putString("csa_styleId", param1String);
      return this;
    }
    
    public Builder setVerticalSpacing(int param1Int) {
      this.b.putString("csa_verticalSpacing", Integer.toString(param1Int));
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\search\DynamicHeightSearchAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */