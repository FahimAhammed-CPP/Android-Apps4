package com.google.android.gms.ads.search;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.internal.client.zzea;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import w0.l8;

public final class SearchAdView extends ViewGroup {
  @NotOnlyInitialized
  public final zzea a = new zzea(this);
  
  public SearchAdView(Context paramContext) {
    super(paramContext);
  }
  
  public SearchAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public SearchAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void destroy() {
    this.a.zzk();
  }
  
  public AdListener getAdListener() {
    return this.a.zza();
  }
  
  public AdSize getAdSize() {
    return this.a.zzb();
  }
  
  public String getAdUnitId() {
    return this.a.zzj();
  }
  
  public void loadAd(DynamicHeightSearchAdRequest paramDynamicHeightSearchAdRequest) {
    if (AdSize.SEARCH.equals(getAdSize())) {
      this.a.zzm(paramDynamicHeightSearchAdRequest.a.a);
      return;
    } 
    throw new IllegalStateException("You must use AdSize.SEARCH for a DynamicHeightSearchAdRequest");
  }
  
  public void loadAd(SearchAdRequest paramSearchAdRequest) {
    this.a.zzm(paramSearchAdRequest.a);
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      i = view.getMeasuredWidth();
      j = view.getMeasuredHeight();
    } else {
      try {
        AdSize adSize = getAdSize();
      } catch (NullPointerException nullPointerException) {
        l8.d("Unable to retrieve ad size.", nullPointerException);
        nullPointerException = null;
      } 
      if (nullPointerException != null) {
        Context context = getContext();
        i = nullPointerException.getWidthInPixels(context);
        j = nullPointerException.getHeightInPixels(context);
      } else {
        j = 0;
      } 
    } 
    i = Math.max(i, getSuggestedMinimumWidth());
    int j = Math.max(j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(i, paramInt1), View.resolveSize(j, paramInt2));
  }
  
  public void pause() {
    this.a.zzn();
  }
  
  public void resume() {
    this.a.zzp();
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.a.zzr(paramAdListener);
  }
  
  public void setAdSize(AdSize paramAdSize) {
    this.a.zzs(new AdSize[] { paramAdSize });
  }
  
  public void setAdUnitId(String paramString) {
    this.a.zzu(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\search\SearchAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */