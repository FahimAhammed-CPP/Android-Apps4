package com.google.android.gms.ads;

public final class R {
  public static final class attr {
    public static final int adSize = 2130837504;
    
    public static final int adSizes = 2130837505;
    
    public static final int adUnitId = 2130837506;
  }
  
  public static final class id {
    public static final int layout = 2131165362;
  }
  
  public static final class layout {
    public static final int admob_empty_layout = 2131296262;
  }
  
  public static final class style {
    public static final int Theme_IAPTheme = 2131492873;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130837504, 2130837505, 2130837506 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */