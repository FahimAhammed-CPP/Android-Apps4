package com.google.android.gms.ads;

public enum AdFormat {
  BANNER, INTERSTITIAL, NATIVE, REWARDED, REWARDED_INTERSTITIAL, UNKNOWN;
  
  static {
    AdFormat adFormat1 = new AdFormat(0, "BANNER");
    BANNER = adFormat1;
    AdFormat adFormat2 = new AdFormat(1, "INTERSTITIAL");
    INTERSTITIAL = adFormat2;
    AdFormat adFormat3 = new AdFormat(2, "REWARDED");
    REWARDED = adFormat3;
    AdFormat adFormat4 = new AdFormat(3, "REWARDED_INTERSTITIAL");
    REWARDED_INTERSTITIAL = adFormat4;
    AdFormat adFormat5 = new AdFormat(4, "NATIVE");
    NATIVE = adFormat5;
    AdFormat adFormat6 = new AdFormat(5, "UNKNOWN");
    UNKNOWN = adFormat6;
    i = new AdFormat[] { adFormat1, adFormat2, adFormat3, adFormat4, adFormat5, adFormat6 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */