package com.google.android.gms.ads.query;

public abstract class QueryInfoGenerationCallback {
  public void onFailure(String paramString) {}
  
  public void onSuccess(QueryInfo paramQueryInfo) {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\QueryInfoGenerationCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */