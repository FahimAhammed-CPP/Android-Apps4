package com.google.android.gms.ads.query;

import org.json.JSONException;
import org.json.JSONObject;
import w0.l8;

@Deprecated
public class AdInfo {
  public final QueryInfo a;
  
  public final String b;
  
  public AdInfo(QueryInfo paramQueryInfo, String paramString) {
    this.a = paramQueryInfo;
    this.b = paramString;
  }
  
  public static String getRequestId(String paramString) {
    if (paramString == null) {
      paramString = "adString passed to AdInfo.getRequestId() cannot be null. Returning empty string.";
      l8.f(paramString);
      return "";
    } 
    try {
      JSONObject jSONObject = new JSONObject(paramString);
      return jSONObject.optString("request_id", "");
    } catch (JSONException jSONException) {}
    l8.f((String)jSONException);
    return "";
  }
  
  public String getAdString() {
    return this.b;
  }
  
  public QueryInfo getQueryInfo() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\AdInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */