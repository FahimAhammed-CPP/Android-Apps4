package com.google.android.gms.ads.query;

import android.net.Uri;
import java.util.List;

public abstract class UpdateImpressionUrlsCallback {
  public void onFailure(String paramString) {}
  
  public void onSuccess(List<Uri> paramList) {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\UpdateImpressionUrlsCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */