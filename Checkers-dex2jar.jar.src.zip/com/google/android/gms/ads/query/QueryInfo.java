package com.google.android.gms.ads.query;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.internal.client.zzem;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.internal.ads.zzcfq;
import u0.b;
import w0.a8;
import w0.f0;
import w0.g8;
import w0.k6;
import w0.l6;
import w0.n;
import w0.s;
import w0.z;

public class QueryInfo {
  public final zzem a;
  
  public QueryInfo(zzem paramzzem) {
    this.a = paramzzem;
  }
  
  public static void generate(Context paramContext, AdFormat paramAdFormat, AdRequest paramAdRequest, QueryInfoGenerationCallback paramQueryInfoGenerationCallback) {
    String str;
    zzdx zzdx;
    z.a(paramContext);
    if (((Boolean)f0.j.c()).booleanValue()) {
      n n = z.p;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zza(paramContext, paramAdFormat, paramAdRequest, paramQueryInfoGenerationCallback));
        return;
      } 
    } 
    if (paramAdRequest == null) {
      paramAdRequest = null;
    } else {
      zzdx = paramAdRequest.zza();
    } 
    a8 a8 = l6.a(paramContext);
    if (a8 == null) {
      str = "Internal Error, query info generator is null.";
    } else {
      zzl zzl;
      b b = new b(str);
      if (zzdx == null) {
        zzl = (new zzm()).zza();
      } else {
        zzl = zzp.zza.zza((Context)zzl, zzdx);
      } 
      zzcfq zzcfq = new zzcfq(null, paramAdFormat.name(), null, zzl);
      try {
        a8.q(b, zzcfq, new k6(paramQueryInfoGenerationCallback));
        return;
      } catch (RemoteException remoteException) {
        str = "Internal Error.";
      } 
    } 
    paramQueryInfoGenerationCallback.onFailure(str);
  }
  
  public String getQuery() {
    return this.a.zzb();
  }
  
  public Bundle getQueryBundle() {
    return this.a.zza();
  }
  
  public String getRequestId() {
    return this.a.zzd();
  }
  
  public final zzem zza() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\QueryInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */