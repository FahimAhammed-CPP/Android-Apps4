package com.google.android.gms.ads.query;

import android.net.Uri;
import android.os.RemoteException;
import android.view.MotionEvent;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import u0.b;
import w0.a8;
import w0.l8;
import w0.m6;
import w0.n6;
import w0.o6;
import w0.p6;
import w0.q6;
import w0.r6;

public final class ReportingInfo {
  public final r6 a;
  
  public void recordClick(List<Uri> paramList) {
    r6 r61 = this.a;
    r61.getClass();
    if (paramList == null || paramList.isEmpty()) {
      l8.f("No click urls were passed to recordClick");
      return;
    } 
    if (r61.b == null)
      l8.f("Failed to get internal reporting info generator in recordClick."); 
    try {
      r61.b.Q(paramList, new b(r61.a), new p6(paramList));
      return;
    } catch (RemoteException remoteException) {
      l8.c("RemoteException recording click: ".concat(remoteException.toString()));
      return;
    } 
  }
  
  public void recordImpression(List<Uri> paramList) {
    String str;
    r6 r61 = this.a;
    r61.getClass();
    if (paramList == null || paramList.isEmpty()) {
      str = "No impression urls were passed to recordImpression";
    } else {
      a8 a8 = r61.b;
      if (a8 != null)
        try {
          a8.P((List)str, new b(r61.a), new o6((List)str));
          return;
        } catch (RemoteException remoteException) {
          l8.c("RemoteException recording impression urls: ".concat(remoteException.toString()));
          return;
        }  
      str = "Failed to get internal reporting info generator from recordImpression.";
    } 
    l8.f(str);
  }
  
  public void reportTouchEvent(MotionEvent paramMotionEvent) {
    a8 a8 = this.a.b;
    if (a8 != null)
      try {
        a8.d(new b(paramMotionEvent));
        return;
      } catch (RemoteException remoteException) {
        l8.c("Failed to call remote method.");
        return;
      }  
    l8.b("Failed to get internal reporting info generator.");
  }
  
  public void updateClickUrl(Uri paramUri, UpdateClickUrlCallback paramUpdateClickUrlCallback) {
    r6 r61 = this.a;
    if (r61.b == null)
      paramUpdateClickUrlCallback.onFailure("Failed to get internal reporting info generator."); 
    try {
      r61.b.p0(new ArrayList(Arrays.asList((Object[])new Uri[] { paramUri }, )), new b(r61.a), new n6(paramUpdateClickUrlCallback));
      return;
    } catch (RemoteException remoteException) {
      paramUpdateClickUrlCallback.onFailure("Internal error: ".concat(remoteException.toString()));
      return;
    } 
  }
  
  public void updateImpressionUrls(List<Uri> paramList, UpdateImpressionUrlsCallback paramUpdateImpressionUrlsCallback) {
    r6 r61 = this.a;
    if (r61.b == null)
      paramUpdateImpressionUrlsCallback.onFailure("Failed to get internal reporting info generator."); 
    try {
      r61.b.D0(paramList, new b(r61.a), new m6(paramUpdateImpressionUrlsCallback));
      return;
    } catch (RemoteException remoteException) {
      paramUpdateImpressionUrlsCallback.onFailure("Internal error: ".concat(remoteException.toString()));
      return;
    } 
  }
  
  public static final class Builder {
    public final q6 a;
    
    public Builder(View param1View) {
      q6 q61 = new q6();
      this.a = q61;
      q61.a = param1View;
    }
    
    public ReportingInfo build() {
      return new ReportingInfo(this);
    }
    
    public Builder setAssetViews(Map<String, View> param1Map) {
      q6 q61 = this.a;
      q61.b.clear();
      for (Map.Entry<String, View> entry : param1Map.entrySet()) {
        View view = (View)entry.getValue();
        if (view != null)
          q61.b.put(entry.getKey(), new WeakReference<View>(view)); 
      } 
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\ReportingInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */