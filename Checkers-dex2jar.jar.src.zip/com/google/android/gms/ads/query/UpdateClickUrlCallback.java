package com.google.android.gms.ads.query;

import android.net.Uri;

public abstract class UpdateClickUrlCallback {
  public void onFailure(String paramString) {}
  
  public void onSuccess(Uri paramUri) {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\query\UpdateClickUrlCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */