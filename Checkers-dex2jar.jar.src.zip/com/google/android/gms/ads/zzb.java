package com.google.android.gms.ads;

public final class zzb {
  public static int zza(AdSize paramAdSize) {
    return paramAdSize.f;
  }
  
  public static int zzb(AdSize paramAdSize) {
    return paramAdSize.h;
  }
  
  public static AdSize zzc(int paramInt1, int paramInt2, String paramString) {
    return new AdSize(paramInt1, paramInt2, paramString);
  }
  
  public static AdSize zzd(int paramInt1, int paramInt2) {
    AdSize adSize = new AdSize(paramInt1, paramInt2);
    adSize.e = true;
    adSize.f = paramInt2;
    return adSize;
  }
  
  public static AdSize zze(int paramInt1, int paramInt2) {
    AdSize adSize = new AdSize(paramInt1, paramInt2);
    adSize.g = true;
    adSize.h = paramInt2;
    return adSize;
  }
  
  public static boolean zzf(AdSize paramAdSize) {
    return paramAdSize.d;
  }
  
  public static boolean zzg(AdSize paramAdSize) {
    return paramAdSize.e;
  }
  
  public static boolean zzh(AdSize paramAdSize) {
    return paramAdSize.g;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */