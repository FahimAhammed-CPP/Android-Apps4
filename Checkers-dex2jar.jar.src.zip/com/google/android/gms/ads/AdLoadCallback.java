package com.google.android.gms.ads;

public abstract class AdLoadCallback<AdT> {
  public void onAdFailedToLoad(LoadAdError paramLoadAdError) {}
  
  public void onAdLoaded(AdT paramAdT) {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdLoadCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */