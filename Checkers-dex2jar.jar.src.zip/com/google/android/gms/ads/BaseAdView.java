package com.google.android.gms.ads;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.admanager.AppEventListener;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzea;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import p0.e;
import w0.f0;
import w0.g8;
import w0.l8;
import w0.n;
import w0.s;
import w0.z;

public abstract class BaseAdView extends ViewGroup {
  @NotOnlyInitialized
  public final zzea a = new zzea(this, 0);
  
  public BaseAdView(Context paramContext) {
    super(paramContext);
  }
  
  public BaseAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
  }
  
  public BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1);
  }
  
  public BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt, Object paramObject) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void destroy() {
    z.a(getContext());
    if (((Boolean)f0.e.c()).booleanValue()) {
      n n = z.m;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zze(this));
        return;
      } 
    } 
    this.a.zzk();
  }
  
  public AdListener getAdListener() {
    return this.a.zza();
  }
  
  public AdSize getAdSize() {
    return this.a.zzb();
  }
  
  public String getAdUnitId() {
    return this.a.zzj();
  }
  
  public OnPaidEventListener getOnPaidEventListener() {
    return this.a.zzc();
  }
  
  public ResponseInfo getResponseInfo() {
    return this.a.zzd();
  }
  
  public boolean isLoading() {
    return this.a.zzA();
  }
  
  public void loadAd(AdRequest paramAdRequest) {
    e.c("#008 Must be called on the main UI thread.");
    z.a(getContext());
    if (((Boolean)f0.f.c()).booleanValue()) {
      n n = z.p;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zzc(this, paramAdRequest));
        return;
      } 
    } 
    this.a.zzm(paramAdRequest.zza());
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      i = view.getMeasuredWidth();
      j = view.getMeasuredHeight();
    } else {
      try {
        AdSize adSize = getAdSize();
      } catch (NullPointerException nullPointerException) {
        l8.d("Unable to retrieve ad size.", nullPointerException);
        nullPointerException = null;
      } 
      if (nullPointerException != null) {
        Context context = getContext();
        i = nullPointerException.getWidthInPixels(context);
        j = nullPointerException.getHeightInPixels(context);
      } else {
        j = 0;
      } 
    } 
    i = Math.max(i, getSuggestedMinimumWidth());
    int j = Math.max(j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(i, paramInt1), View.resolveSize(j, paramInt2));
  }
  
  public void pause() {
    z.a(getContext());
    if (((Boolean)f0.g.c()).booleanValue()) {
      n n = z.n;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zzd(this));
        return;
      } 
    } 
    this.a.zzn();
  }
  
  public void resume() {
    z.a(getContext());
    if (((Boolean)f0.h.c()).booleanValue()) {
      n n = z.l;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zzf(this));
        return;
      } 
    } 
    this.a.zzp();
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.a.zzr(paramAdListener);
    if (paramAdListener == null) {
      this.a.zzq(null);
      return;
    } 
    if (paramAdListener instanceof zza)
      this.a.zzq((zza)paramAdListener); 
    if (paramAdListener instanceof AppEventListener)
      this.a.zzv((AppEventListener)paramAdListener); 
  }
  
  public void setAdSize(AdSize paramAdSize) {
    this.a.zzs(new AdSize[] { paramAdSize });
  }
  
  public void setAdUnitId(String paramString) {
    this.a.zzu(paramString);
  }
  
  public void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener) {
    this.a.zzx(paramOnPaidEventListener);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\BaseAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */