package com.google.android.gms.ads;

import java.util.Locale;

public class VersionInfo {
  public int a;
  
  public int b;
  
  public int c;
  
  public VersionInfo(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  public int getMajorVersion() {
    return this.a;
  }
  
  public int getMicroVersion() {
    return this.c;
  }
  
  public int getMinorVersion() {
    return this.b;
  }
  
  public String toString() {
    return String.format(Locale.US, "%d.%d.%d", new Object[] { Integer.valueOf(this.a), Integer.valueOf(this.b), Integer.valueOf(this.c) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\VersionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */