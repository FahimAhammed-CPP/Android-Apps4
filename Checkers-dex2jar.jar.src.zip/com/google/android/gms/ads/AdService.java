package com.google.android.gms.ads;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzay;
import w0.l8;
import w0.t3;
import w0.w3;

public class AdService extends IntentService {
  public AdService() {
    super("AdService");
  }
  
  public final void onHandleIntent(Intent paramIntent) {
    try {
      zzay.zza().zzm((Context)this, (w3)new t3()).o(paramIntent);
      return;
    } catch (RemoteException remoteException) {
      l8.c("RemoteException calling handleNotificationIntent: ".concat(remoteException.toString()));
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */