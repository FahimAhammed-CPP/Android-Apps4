package com.google.android.gms.ads.rewarded;

import g1.a;

public interface RewardItem {
  public static final RewardItem DEFAULT_REWARD = (RewardItem)new a();
  
  int getAmount();
  
  String getType();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\rewarded\RewardItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */