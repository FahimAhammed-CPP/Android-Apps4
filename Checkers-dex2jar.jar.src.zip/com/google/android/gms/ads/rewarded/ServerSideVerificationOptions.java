package com.google.android.gms.ads.rewarded;

public class ServerSideVerificationOptions {
  public final String a;
  
  public final String b;
  
  public String getCustomData() {
    return this.b;
  }
  
  public String getUserId() {
    return this.a;
  }
  
  public static final class Builder {
    public String a = "";
    
    public String b = "";
    
    public ServerSideVerificationOptions build() {
      return new ServerSideVerificationOptions(this);
    }
    
    public Builder setCustomData(String param1String) {
      this.b = param1String;
      return this;
    }
    
    public Builder setUserId(String param1String) {
      this.a = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\rewarded\ServerSideVerificationOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */