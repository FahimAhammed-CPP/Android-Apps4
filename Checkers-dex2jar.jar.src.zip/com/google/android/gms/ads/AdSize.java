package com.google.android.gms.ads;

import android.content.Context;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import androidx.lifecycle.a;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzq;
import w0.i8;
import w0.l8;
import w0.w8;

public final class AdSize {
  public static final int AUTO_HEIGHT = -2;
  
  public static final AdSize BANNER = new AdSize(320, 50, "320x50_mb");
  
  public static final AdSize FLUID;
  
  public static final AdSize FULL_BANNER = new AdSize(468, 60, "468x60_as");
  
  public static final int FULL_WIDTH = -1;
  
  public static final AdSize INVALID;
  
  public static final AdSize LARGE_BANNER = new AdSize(320, 100, "320x100_as");
  
  public static final AdSize LEADERBOARD = new AdSize(728, 90, "728x90_as");
  
  public static final AdSize MEDIUM_RECTANGLE = new AdSize(300, 250, "300x250_as");
  
  public static final AdSize SEARCH;
  
  @Deprecated
  public static final AdSize SMART_BANNER;
  
  public static final AdSize WIDE_SKYSCRAPER = new AdSize(160, 600, "160x600_as");
  
  public static final AdSize zza;
  
  public final int a;
  
  public final int b;
  
  public final String c;
  
  public boolean d;
  
  public boolean e;
  
  public int f;
  
  public boolean g;
  
  public int h;
  
  static {
    SMART_BANNER = new AdSize(-1, -2, "smart_banner");
    FLUID = new AdSize(-3, -4, "fluid");
    INVALID = new AdSize(0, 0, "invalid");
    zza = new AdSize(50, 50, "50x50_mb");
    SEARCH = new AdSize(-3, 0, "search_v2");
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2, stringBuilder.toString());
  }
  
  public AdSize(int paramInt1, int paramInt2, String paramString) {
    if (paramInt1 >= 0 || paramInt1 == -1 || paramInt1 == -3) {
      if (paramInt2 >= 0 || paramInt2 == -2 || paramInt2 == -4) {
        this.a = paramInt1;
        this.b = paramInt2;
        this.c = paramString;
        return;
      } 
      throw new IllegalArgumentException(a.b("Invalid height for AdSize: ", paramInt2));
    } 
    throw new IllegalArgumentException(a.b("Invalid width for AdSize: ", paramInt1));
  }
  
  public static AdSize a(int paramInt1, int paramInt2) {
    if (paramInt2 == -1)
      return INVALID; 
    AdSize adSize = new AdSize(paramInt1, 0);
    adSize.h = paramInt2;
    adSize.g = true;
    return adSize;
  }
  
  public static AdSize getCurrentOrientationAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = i8.f(paramContext, paramInt, 0);
    adSize.d = true;
    return adSize;
  }
  
  public static AdSize getCurrentOrientationInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = i8.e(paramContext, 0);
    if (i == -1)
      return INVALID; 
    AdSize adSize = new AdSize(paramInt, 0);
    adSize.f = i;
    adSize.e = true;
    return adSize;
  }
  
  public static AdSize getCurrentOrientationInterscrollerAdSize(Context paramContext, int paramInt) {
    return a(paramInt, i8.e(paramContext, 0));
  }
  
  public static AdSize getInlineAdaptiveBannerAdSize(int paramInt1, int paramInt2) {
    AdSize adSize = new AdSize(paramInt1, 0);
    adSize.f = paramInt2;
    adSize.e = true;
    if (paramInt2 < 32) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The maximum height set for the inline adaptive ad size was ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" dp, which is below the minimum recommended value of 32 dp.");
      l8.f(stringBuilder.toString());
    } 
    return adSize;
  }
  
  public static AdSize getLandscapeAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = i8.f(paramContext, paramInt, 2);
    adSize.d = true;
    return adSize;
  }
  
  public static AdSize getLandscapeInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = i8.e(paramContext, 2);
    AdSize adSize = new AdSize(paramInt, 0);
    if (i == -1)
      return INVALID; 
    adSize.f = i;
    adSize.e = true;
    return adSize;
  }
  
  public static AdSize getLandscapeInterscrollerAdSize(Context paramContext, int paramInt) {
    return a(paramInt, i8.e(paramContext, 2));
  }
  
  public static AdSize getPortraitAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = i8.f(paramContext, paramInt, 1);
    adSize.d = true;
    return adSize;
  }
  
  public static AdSize getPortraitInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = i8.e(paramContext, 1);
    AdSize adSize = new AdSize(paramInt, 0);
    if (i == -1)
      return INVALID; 
    adSize.f = i;
    adSize.e = true;
    return adSize;
  }
  
  public static AdSize getPortraitInterscrollerAdSize(Context paramContext, int paramInt) {
    return a(paramInt, i8.e(paramContext, 1));
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof AdSize))
      return false; 
    paramObject = paramObject;
    return (this.a == ((AdSize)paramObject).a && this.b == ((AdSize)paramObject).b && this.c.equals(((AdSize)paramObject).c));
  }
  
  public int getHeight() {
    return this.b;
  }
  
  public int getHeightInPixels(Context paramContext) {
    int i = this.b;
    if (i != -4 && i != -3) {
      DisplayMetrics displayMetrics;
      if (i != -2) {
        zzay.zzb();
        i = this.b;
        w8 w8 = i8.a;
        displayMetrics = paramContext.getResources().getDisplayMetrics();
        return (int)TypedValue.applyDimension(1, i, displayMetrics);
      } 
      return zzq.zza(displayMetrics.getResources().getDisplayMetrics());
    } 
    return -1;
  }
  
  public int getWidth() {
    return this.a;
  }
  
  public int getWidthInPixels(Context paramContext) {
    int i = this.a;
    if (i != -3) {
      if (i != -1) {
        zzay.zzb();
        i = this.a;
        w8 w8 = i8.a;
        displayMetrics = paramContext.getResources().getDisplayMetrics();
        return (int)TypedValue.applyDimension(1, i, displayMetrics);
      } 
      DisplayMetrics displayMetrics = displayMetrics.getResources().getDisplayMetrics();
      Parcelable.Creator creator = zzq.CREATOR;
      return displayMetrics.widthPixels;
    } 
    return -1;
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public boolean isAutoHeight() {
    return (this.b == -2);
  }
  
  public boolean isFluid() {
    return (this.a == -3 && this.b == -4);
  }
  
  public boolean isFullWidth() {
    return (this.a == -1);
  }
  
  public String toString() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */