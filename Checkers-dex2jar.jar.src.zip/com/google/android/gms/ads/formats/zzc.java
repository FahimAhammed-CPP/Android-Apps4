package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzc implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = a.m(paramParcel);
    boolean bool = false;
    IBinder iBinder = null;
    while (paramParcel.dataPosition() < i) {
      int j = paramParcel.readInt();
      char c = (char)j;
      if (c != '\001') {
        if (c != '\002') {
          a.l(paramParcel, j);
          continue;
        } 
        iBinder = a.h(paramParcel, j);
        continue;
      } 
      bool = a.g(paramParcel, j);
    } 
    a.f(paramParcel, i);
    return new AdManagerAdViewOptions(bool, iBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */