package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.VideoOptions;

@Deprecated
public final class NativeAdOptions {
  public static final int ADCHOICES_BOTTOM_LEFT = 3;
  
  public static final int ADCHOICES_BOTTOM_RIGHT = 2;
  
  public static final int ADCHOICES_TOP_LEFT = 0;
  
  public static final int ADCHOICES_TOP_RIGHT = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_ANY = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE = 2;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT = 3;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_SQUARE = 4;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_UNKNOWN = 0;
  
  @Deprecated
  public static final int ORIENTATION_ANY = 0;
  
  @Deprecated
  public static final int ORIENTATION_LANDSCAPE = 2;
  
  @Deprecated
  public static final int ORIENTATION_PORTRAIT = 1;
  
  public final boolean a;
  
  public final int b;
  
  public final int c;
  
  public final boolean d;
  
  public final int e;
  
  public final VideoOptions f;
  
  public final boolean g;
  
  public int getAdChoicesPlacement() {
    return this.e;
  }
  
  @Deprecated
  public int getImageOrientation() {
    return this.b;
  }
  
  public int getMediaAspectRatio() {
    return this.c;
  }
  
  public VideoOptions getVideoOptions() {
    return this.f;
  }
  
  public boolean shouldRequestMultipleImages() {
    return this.d;
  }
  
  public boolean shouldReturnUrlsForImageAssets() {
    return this.a;
  }
  
  public final boolean zza() {
    return this.g;
  }
  
  public static @interface AdChoicesPlacement {}
  
  public static final class Builder {
    public boolean a = false;
    
    public int b = -1;
    
    public int c = 0;
    
    public boolean d = false;
    
    public VideoOptions e;
    
    public int f = 1;
    
    public boolean g = false;
    
    public NativeAdOptions build() {
      return new NativeAdOptions(this);
    }
    
    public Builder setAdChoicesPlacement(@AdChoicesPlacement int param1Int) {
      this.f = param1Int;
      return this;
    }
    
    @Deprecated
    public Builder setImageOrientation(int param1Int) {
      this.b = param1Int;
      return this;
    }
    
    public Builder setMediaAspectRatio(@NativeMediaAspectRatio int param1Int) {
      this.c = param1Int;
      return this;
    }
    
    public Builder setRequestCustomMuteThisAd(boolean param1Boolean) {
      this.g = param1Boolean;
      return this;
    }
    
    public Builder setRequestMultipleImages(boolean param1Boolean) {
      this.d = param1Boolean;
      return this;
    }
    
    public Builder setReturnUrlsForImageAssets(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
    
    public Builder setVideoOptions(VideoOptions param1VideoOptions) {
      this.e = param1VideoOptions;
      return this;
    }
  }
  
  public static @interface NativeMediaAspectRatio {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\NativeAdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */