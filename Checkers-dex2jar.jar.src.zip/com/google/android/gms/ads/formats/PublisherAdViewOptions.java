package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zzca;
import com.google.android.gms.ads.internal.client.zzcb;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;
import w0.b2;
import w0.c2;

@Deprecated
public final class PublisherAdViewOptions extends AbstractSafeParcelable {
  public static final Parcelable.Creator<PublisherAdViewOptions> CREATOR = new zzf();
  
  public final boolean i;
  
  public final zzcb j;
  
  public final IBinder k;
  
  public PublisherAdViewOptions(boolean paramBoolean, IBinder paramIBinder1, IBinder paramIBinder2) {
    this.i = paramBoolean;
    if (paramIBinder1 != null) {
      zzcb zzcb1 = zzca.zzd(paramIBinder1);
    } else {
      paramIBinder1 = null;
    } 
    this.j = (zzcb)paramIBinder1;
    this.k = paramIBinder2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    IBinder iBinder;
    paramInt = b.m(paramParcel, 20293);
    b.d(paramParcel, 1, this.i);
    zzcb zzcb1 = this.j;
    if (zzcb1 == null) {
      zzcb1 = null;
    } else {
      iBinder = zzcb1.asBinder();
    } 
    b.f(paramParcel, 2, iBinder);
    b.f(paramParcel, 3, this.k);
    b.v(paramParcel, paramInt);
  }
  
  public final zzcb zza() {
    return this.j;
  }
  
  public final c2 zzb() {
    IBinder iBinder = this.k;
    return (iBinder == null) ? null : b2.zzc(iBinder);
  }
  
  public final boolean zzc() {
    return this.i;
  }
  
  @Deprecated
  public static final class Builder {
    public ShouldDelayBannerRenderingListener a;
    
    public Builder setShouldDelayBannerRenderingListener(ShouldDelayBannerRenderingListener param1ShouldDelayBannerRenderingListener) {
      this.a = param1ShouldDelayBannerRenderingListener;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\PublisherAdViewOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */