package com.google.android.gms.ads.formats;

import java.util.WeakHashMap;

@Deprecated
public final class zze {
  public static final WeakHashMap zza = new WeakHashMap<Object, Object>();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */