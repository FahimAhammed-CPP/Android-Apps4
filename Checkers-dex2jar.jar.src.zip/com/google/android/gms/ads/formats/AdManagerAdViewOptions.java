package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zzfj;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;
import w0.b2;
import w0.c2;

public final class AdManagerAdViewOptions extends AbstractSafeParcelable {
  public static final Parcelable.Creator<AdManagerAdViewOptions> CREATOR = new zzc();
  
  public final boolean i;
  
  public final IBinder j;
  
  public AdManagerAdViewOptions(boolean paramBoolean, IBinder paramIBinder) {
    this.i = paramBoolean;
    this.j = paramIBinder;
  }
  
  public boolean getManualImpressionsEnabled() {
    return this.i;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.d(paramParcel, 1, getManualImpressionsEnabled());
    b.f(paramParcel, 2, this.j);
    b.v(paramParcel, paramInt);
  }
  
  public final c2 zza() {
    IBinder iBinder = this.j;
    return (iBinder == null) ? null : b2.zzc(iBinder);
  }
  
  public static final class Builder {
    public boolean a = false;
    
    public ShouldDelayBannerRenderingListener b;
    
    public AdManagerAdViewOptions build() {
      return new AdManagerAdViewOptions(this);
    }
    
    public Builder setManualImpressionsEnabled(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
    
    public Builder setShouldDelayBannerRenderingListener(ShouldDelayBannerRenderingListener param1ShouldDelayBannerRenderingListener) {
      this.b = param1ShouldDelayBannerRenderingListener;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\AdManagerAdViewOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */