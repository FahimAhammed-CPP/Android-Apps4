package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzf implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = a.m(paramParcel);
    IBinder iBinder2 = null;
    IBinder iBinder1 = null;
    boolean bool;
    for (bool = false; paramParcel.dataPosition() < i; bool = a.g(paramParcel, j)) {
      int j = paramParcel.readInt();
      char c = (char)j;
      if (c != '\001') {
        if (c != '\002') {
          if (c != '\003') {
            a.l(paramParcel, j);
            continue;
          } 
          iBinder1 = a.h(paramParcel, j);
          continue;
        } 
        iBinder2 = a.h(paramParcel, j);
        continue;
      } 
    } 
    a.f(paramParcel, i);
    return new PublisherAdViewOptions(bool, iBinder2, iBinder1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\formats\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */