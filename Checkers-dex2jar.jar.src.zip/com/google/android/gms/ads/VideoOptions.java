package com.google.android.gms.ads;

import com.google.android.gms.ads.internal.client.zzfl;

public final class VideoOptions {
  public final boolean a;
  
  public final boolean b;
  
  public final boolean c;
  
  public VideoOptions(zzfl paramzzfl) {
    this.a = paramzzfl.zza;
    this.b = paramzzfl.zzb;
    this.c = paramzzfl.zzc;
  }
  
  public boolean getClickToExpandRequested() {
    return this.c;
  }
  
  public boolean getCustomControlsRequested() {
    return this.b;
  }
  
  public boolean getStartMuted() {
    return this.a;
  }
  
  public static final class Builder {
    public boolean a = true;
    
    public boolean b = false;
    
    public boolean c = false;
    
    public VideoOptions build() {
      return new VideoOptions(this);
    }
    
    public Builder setClickToExpandRequested(boolean param1Boolean) {
      this.c = param1Boolean;
      return this;
    }
    
    public Builder setCustomControlsRequested(boolean param1Boolean) {
      this.b = param1Boolean;
      return this;
    }
    
    public Builder setStartMuted(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\VideoOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */