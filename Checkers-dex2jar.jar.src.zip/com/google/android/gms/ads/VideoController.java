package com.google.android.gms.ads;

import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzdq;
import com.google.android.gms.ads.internal.client.zzdt;
import com.google.android.gms.ads.internal.client.zzfk;
import javax.annotation.concurrent.GuardedBy;
import w0.l8;

public final class VideoController {
  public static final int PLAYBACK_STATE_ENDED = 3;
  
  public static final int PLAYBACK_STATE_PAUSED = 2;
  
  public static final int PLAYBACK_STATE_PLAYING = 1;
  
  public static final int PLAYBACK_STATE_READY = 5;
  
  public static final int PLAYBACK_STATE_UNKNOWN = 0;
  
  public final Object a = new Object();
  
  @GuardedBy("lock")
  public zzdq b;
  
  @GuardedBy("lock")
  public VideoLifecycleCallbacks c;
  
  public int getPlaybackState() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 == null)
        return 0; 
      try {
        return zzdq1.zzh();
      } catch (RemoteException remoteException) {
        l8.d("Unable to call getPlaybackState on video controller.", (Throwable)remoteException);
        return 0;
      } 
    } 
  }
  
  public VideoLifecycleCallbacks getVideoLifecycleCallbacks() {
    synchronized (this.a) {
      return this.c;
    } 
  }
  
  public boolean hasVideoContent() {
    synchronized (this.a) {
      if (this.b != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public boolean isClickToExpandEnabled() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 == null)
        return false; 
      try {
        return zzdq1.zzo();
      } catch (RemoteException remoteException) {
        l8.d("Unable to call isClickToExpandEnabled.", (Throwable)remoteException);
        return false;
      } 
    } 
  }
  
  public boolean isCustomControlsEnabled() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 == null)
        return false; 
      try {
        return zzdq1.zzp();
      } catch (RemoteException remoteException) {
        l8.d("Unable to call isUsingCustomPlayerControls.", (Throwable)remoteException);
        return false;
      } 
    } 
  }
  
  public boolean isMuted() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 == null)
        return true; 
      try {
        return zzdq1.zzq();
      } catch (RemoteException remoteException) {
        l8.d("Unable to call isMuted on video controller.", (Throwable)remoteException);
        return true;
      } 
    } 
  }
  
  public void mute(boolean paramBoolean) {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 != null) {
        try {
          zzdq1.zzj(paramBoolean);
        } catch (RemoteException remoteException) {
          l8.d("Unable to call mute on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void pause() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 != null) {
        try {
          zzdq1.zzk();
        } catch (RemoteException remoteException) {
          l8.d("Unable to call pause on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void play() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 != null) {
        try {
          zzdq1.zzl();
        } catch (RemoteException remoteException) {
          l8.d("Unable to call play on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void setVideoLifecycleCallbacks(VideoLifecycleCallbacks paramVideoLifecycleCallbacks) {
    synchronized (this.a) {
      this.c = paramVideoLifecycleCallbacks;
      zzdq zzdq1 = this.b;
      if (zzdq1 != null) {
        if (paramVideoLifecycleCallbacks == null) {
          paramVideoLifecycleCallbacks = null;
        } else {
          try {
            zzfk zzfk = new zzfk(paramVideoLifecycleCallbacks);
            zzdq1.zzm((zzdt)zzfk);
          } catch (RemoteException remoteException) {
            l8.d("Unable to call setVideoLifecycleCallbacks on video controller.", (Throwable)remoteException);
          } 
          return;
        } 
      } else {
        return;
      } 
      zzdq1.zzm((zzdt)remoteException);
    } 
  }
  
  public void stop() {
    synchronized (this.a) {
      zzdq zzdq1 = this.b;
      if (zzdq1 != null) {
        try {
          zzdq1.zzn();
        } catch (RemoteException remoteException) {
          l8.d("Unable to call stop on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public final zzdq zza() {
    synchronized (this.a) {
      return this.b;
    } 
  }
  
  public final void zzb(zzdq paramzzdq) {
    synchronized (this.a) {
      this.b = paramzzdq;
      VideoLifecycleCallbacks videoLifecycleCallbacks = this.c;
      if (videoLifecycleCallbacks != null)
        setVideoLifecycleCallbacks(videoLifecycleCallbacks); 
      return;
    } 
  }
  
  public static abstract class VideoLifecycleCallbacks {
    public void onVideoEnd() {}
    
    public void onVideoMute(boolean param1Boolean) {}
    
    public void onVideoPause() {}
    
    public void onVideoPlay() {}
    
    public void onVideoStart() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\VideoController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */