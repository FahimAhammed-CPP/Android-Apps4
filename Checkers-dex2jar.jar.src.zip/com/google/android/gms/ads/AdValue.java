package com.google.android.gms.ads;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class AdValue {
  public final int a;
  
  public final String b;
  
  public final long c;
  
  public AdValue(int paramInt, String paramString, long paramLong) {
    this.a = paramInt;
    this.b = paramString;
    this.c = paramLong;
  }
  
  public static AdValue zza(int paramInt, String paramString, long paramLong) {
    return new AdValue(paramInt, paramString, paramLong);
  }
  
  public String getCurrencyCode() {
    return this.b;
  }
  
  public int getPrecisionType() {
    return this.a;
  }
  
  public long getValueMicros() {
    return this.c;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface PrecisionType {
    public static final int ESTIMATED = 1;
    
    public static final int PRECISE = 3;
    
    public static final int PUBLISHER_PROVIDED = 2;
    
    public static final int UNKNOWN = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */