package com.google.android.gms.ads;

import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.internal.client.zzu;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import w0.l8;

public final class ResponseInfo {
  public final zzdn a;
  
  public final ArrayList b;
  
  public AdapterResponseInfo c;
  
  public ResponseInfo(zzdn paramzzdn) {
    this.a = paramzzdn;
    this.b = new ArrayList();
    if (paramzzdn != null)
      try {
        List list = paramzzdn.zzj();
        if (list != null) {
          Iterator<zzu> iterator = list.iterator();
          while (iterator.hasNext()) {
            AdapterResponseInfo adapterResponseInfo = AdapterResponseInfo.zza(iterator.next());
            if (adapterResponseInfo != null)
              this.b.add(adapterResponseInfo); 
          } 
        } 
      } catch (RemoteException remoteException) {
        l8.d("Could not forward getAdapterResponseInfo to ResponseInfo.", (Throwable)remoteException);
      }  
    paramzzdn = this.a;
    if (paramzzdn == null)
      return; 
    try {
      zzu zzu = paramzzdn.zzf();
      if (zzu != null)
        this.c = AdapterResponseInfo.zza(zzu); 
      return;
    } catch (RemoteException remoteException) {
      l8.d("Could not forward getLoadedAdapterResponse to ResponseInfo.", (Throwable)remoteException);
      return;
    } 
  }
  
  public static ResponseInfo zza(zzdn paramzzdn) {
    return (paramzzdn != null) ? new ResponseInfo(paramzzdn) : null;
  }
  
  public static ResponseInfo zzb(zzdn paramzzdn) {
    return new ResponseInfo(paramzzdn);
  }
  
  public List<AdapterResponseInfo> getAdapterResponses() {
    return this.b;
  }
  
  public AdapterResponseInfo getLoadedAdapterResponseInfo() {
    return this.c;
  }
  
  public String getMediationAdapterClassName() {
    try {
      zzdn zzdn1 = this.a;
      if (zzdn1 != null)
        return zzdn1.zzg(); 
    } catch (RemoteException remoteException) {
      l8.d("Could not forward getMediationAdapterClassName to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  public Bundle getResponseExtras() {
    try {
      zzdn zzdn1 = this.a;
      if (zzdn1 != null)
        return zzdn1.zze(); 
    } catch (RemoteException remoteException) {
      l8.d("Could not forward getResponseExtras to ResponseInfo.", (Throwable)remoteException);
    } 
    return new Bundle();
  }
  
  public String getResponseId() {
    try {
      zzdn zzdn1 = this.a;
      if (zzdn1 != null)
        return zzdn1.zzi(); 
    } catch (RemoteException remoteException) {
      l8.d("Could not forward getResponseId to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  public String toString() {
    try {
      return zzd().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final zzdn zzc() {
    return this.a;
  }
  
  public final JSONObject zzd() {
    JSONObject jSONObject = new JSONObject();
    String str = getResponseId();
    if (str == null) {
      jSONObject.put("Response ID", "null");
    } else {
      jSONObject.put("Response ID", str);
    } 
    str = getMediationAdapterClassName();
    if (str == null) {
      jSONObject.put("Mediation Adapter Class Name", "null");
    } else {
      jSONObject.put("Mediation Adapter Class Name", str);
    } 
    JSONArray jSONArray = new JSONArray();
    Iterator<AdapterResponseInfo> iterator = this.b.iterator();
    while (iterator.hasNext())
      jSONArray.put(((AdapterResponseInfo)iterator.next()).zzb()); 
    jSONObject.put("Adapter Responses", jSONArray);
    AdapterResponseInfo adapterResponseInfo = this.c;
    if (adapterResponseInfo != null)
      jSONObject.put("Loaded Adapter Response", adapterResponseInfo.zzb()); 
    Bundle bundle = getResponseExtras();
    if (bundle != null)
      jSONObject.put("Response Extras", zzay.zzb().h(bundle)); 
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\ResponseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */