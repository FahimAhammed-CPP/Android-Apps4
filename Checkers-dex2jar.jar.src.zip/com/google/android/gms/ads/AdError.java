package com.google.android.gms.ads;

import com.google.android.gms.ads.internal.client.zze;
import org.json.JSONException;
import org.json.JSONObject;

public class AdError {
  public static final String UNDEFINED_DOMAIN = "undefined";
  
  public final int a;
  
  public final String b;
  
  public final String c;
  
  public final AdError d;
  
  public AdError(int paramInt, String paramString1, String paramString2) {
    this(paramInt, paramString1, paramString2, null);
  }
  
  public AdError(int paramInt, String paramString1, String paramString2, AdError paramAdError) {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramAdError;
  }
  
  public AdError getCause() {
    return this.d;
  }
  
  public int getCode() {
    return this.a;
  }
  
  public String getDomain() {
    return this.c;
  }
  
  public String getMessage() {
    return this.b;
  }
  
  public String toString() {
    try {
      return zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final zze zza() {
    zze zze;
    if (this.d == null) {
      zze = null;
    } else {
      AdError adError = this.d;
      zze = new zze(adError.a, adError.b, adError.c, null, null);
    } 
    return new zze(this.a, this.b, this.c, zze, null);
  }
  
  public JSONObject zzb() {
    String str;
    JSONObject jSONObject1;
    JSONObject jSONObject2 = new JSONObject();
    jSONObject2.put("Code", this.a);
    jSONObject2.put("Message", this.b);
    jSONObject2.put("Domain", this.c);
    AdError adError = this.d;
    if (adError == null) {
      str = "null";
    } else {
      jSONObject1 = str.zzb();
    } 
    jSONObject2.put("Cause", jSONObject1);
    return jSONObject2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */