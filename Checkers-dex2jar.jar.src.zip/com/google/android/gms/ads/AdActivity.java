package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.internal.client.zzay;
import u0.b;
import w0.a6;
import w0.l8;

public final class AdActivity extends Activity {
  public static final String CLASS_NAME = "com.google.android.gms.ads.AdActivity";
  
  public a6 a;
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.H0(paramInt1, paramInt2, paramIntent); 
    } catch (Exception exception) {
      l8.h(exception);
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public final void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lw0/a6;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 28
    //   9: aload_2
    //   10: invokeinterface m : ()Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifeq -> 47
    //   20: goto -> 28
    //   23: astore_2
    //   24: aload_2
    //   25: invokestatic h : (Ljava/lang/Exception;)V
    //   28: aload_0
    //   29: invokespecial onBackPressed : ()V
    //   32: aload_0
    //   33: getfield a : Lw0/a6;
    //   36: astore_2
    //   37: aload_2
    //   38: ifnull -> 47
    //   41: aload_2
    //   42: invokeinterface zzh : ()V
    //   47: return
    //   48: astore_2
    //   49: aload_2
    //   50: invokestatic h : (Ljava/lang/Exception;)V
    //   53: return
    // Exception table:
    //   from	to	target	type
    //   0	5	23	android/os/RemoteException
    //   9	16	23	android/os/RemoteException
    //   32	37	48	android/os/RemoteException
    //   41	47	48	android/os/RemoteException
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.d(new b(paramConfiguration)); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    a6 a61 = zzay.zza().zzo(this);
    this.a = a61;
    if (a61 != null) {
      try {
        a61.d0(paramBundle);
        return;
      } catch (RemoteException remoteException) {}
    } else {
      paramBundle = null;
    } 
    l8.h((Exception)paramBundle);
    finish();
  }
  
  public final void onDestroy() {
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.zzl(); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
    } 
    super.onDestroy();
  }
  
  public final void onPause() {
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.zzn(); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
    } 
    super.onPause();
  }
  
  public final void onRestart() {
    super.onRestart();
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.zzo(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onResume() {
    super.onResume();
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.n(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.I0(paramBundle); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
    } 
    super.onSaveInstanceState(paramBundle);
  }
  
  public final void onStart() {
    super.onStart();
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.Q0(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
      return;
    } 
  }
  
  public final void onStop() {
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.x(); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      finish();
    } 
    super.onStop();
  }
  
  public final void onUserLeaveHint() {
    super.onUserLeaveHint();
    try {
      a6 a61 = this.a;
      if (a61 != null)
        a61.K0(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void setContentView(int paramInt) {
    super.setContentView(paramInt);
    a6 a61 = this.a;
    if (a61 != null)
      try {
        a61.f();
        return;
      } catch (RemoteException remoteException) {
        l8.h((Exception)remoteException);
      }  
  }
  
  public final void setContentView(View paramView) {
    super.setContentView(paramView);
    a6 a61 = this.a;
    if (a61 != null)
      try {
        a61.f();
        return;
      } catch (RemoteException remoteException) {
        l8.h((Exception)remoteException);
      }  
  }
  
  public final void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
    a6 a61 = this.a;
    if (a61 != null)
      try {
        a61.f();
        return;
      } catch (RemoteException remoteException) {
        l8.h((Exception)remoteException);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */