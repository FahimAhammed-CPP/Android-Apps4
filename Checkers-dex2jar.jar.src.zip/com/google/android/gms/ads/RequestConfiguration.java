package com.google.android.gms.ads;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import w0.l8;

public class RequestConfiguration {
  public static final String MAX_AD_CONTENT_RATING_G = "G";
  
  public static final String MAX_AD_CONTENT_RATING_MA = "MA";
  
  public static final String MAX_AD_CONTENT_RATING_PG = "PG";
  
  public static final String MAX_AD_CONTENT_RATING_T = "T";
  
  public static final String MAX_AD_CONTENT_RATING_UNSPECIFIED = "";
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE = 0;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE = 1;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_UNSPECIFIED = -1;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_FALSE = 0;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE = 1;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_UNSPECIFIED = -1;
  
  public static final List zza = Arrays.asList(new String[] { "MA", "T", "PG", "G" });
  
  public final int a;
  
  public final int b;
  
  @Nullable
  public final String c;
  
  public final List d;
  
  public String getMaxAdContentRating() {
    String str2 = this.c;
    String str1 = str2;
    if (str2 == null)
      str1 = ""; 
    return str1;
  }
  
  public int getTagForChildDirectedTreatment() {
    return this.a;
  }
  
  public int getTagForUnderAgeOfConsent() {
    return this.b;
  }
  
  public List<String> getTestDeviceIds() {
    return new ArrayList<String>(this.d);
  }
  
  public Builder toBuilder() {
    Builder builder = new Builder();
    builder.setTagForChildDirectedTreatment(this.a);
    builder.setTagForUnderAgeOfConsent(this.b);
    builder.setMaxAdContentRating(this.c);
    builder.setTestDeviceIds(this.d);
    return builder;
  }
  
  public static class Builder {
    public int a = -1;
    
    public int b = -1;
    
    @Nullable
    public String c = null;
    
    public final ArrayList d = new ArrayList();
    
    public RequestConfiguration build() {
      return new RequestConfiguration(this.a, this.b, this.c, this.d);
    }
    
    public Builder setMaxAdContentRating(@Nullable String param1String) {
      if (param1String == null || "".equals(param1String)) {
        String str1 = null;
        this.c = str1;
        return this;
      } 
      String str = param1String;
      if (!"G".equals(param1String)) {
        str = param1String;
        if (!"PG".equals(param1String)) {
          str = param1String;
          if (!"T".equals(param1String))
            if ("MA".equals(param1String)) {
              str = param1String;
            } else {
              l8.f("Invalid value passed to setMaxAdContentRating: ".concat(param1String));
              return this;
            }  
        } 
      } 
      this.c = str;
      return this;
    }
    
    public Builder setTagForChildDirectedTreatment(int param1Int) {
      if (param1Int == -1 || param1Int == 0 || param1Int == 1) {
        this.a = param1Int;
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid value passed to setTagForChildDirectedTreatment: ");
      stringBuilder.append(param1Int);
      l8.f(stringBuilder.toString());
      return this;
    }
    
    public Builder setTagForUnderAgeOfConsent(int param1Int) {
      if (param1Int == -1 || param1Int == 0 || param1Int == 1) {
        this.b = param1Int;
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid value passed to setTagForUnderAgeOfConsent: ");
      stringBuilder.append(param1Int);
      l8.f(stringBuilder.toString());
      return this;
    }
    
    public Builder setTestDeviceIds(@Nullable List<String> param1List) {
      this.d.clear();
      if (param1List != null)
        this.d.addAll(param1List); 
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface MaxAdContentRating {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TagForChildDirectedTreatment {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TagForUnderAgeOfConsent {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\RequestConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */