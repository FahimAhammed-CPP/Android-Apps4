package com.google.android.gms.ads.appopen;

import android.app.Activity;
import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdLoadCallback;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzbu;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzw;
import p0.e;
import w0.e;
import w0.f0;
import w0.g8;
import w0.l;
import w0.l8;
import w0.n;
import w0.s;
import w0.t3;
import w0.w3;
import w0.z;

public abstract class AppOpenAd {
  public static final int APP_OPEN_AD_ORIENTATION_LANDSCAPE = 2;
  
  public static final int APP_OPEN_AD_ORIENTATION_PORTRAIT = 1;
  
  public static void load(Context paramContext, String paramString, AdRequest paramAdRequest, @AppOpenAdOrientation int paramInt, AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdRequest != null) {
          e.c("#008 Must be called on the main UI thread.");
          z.a(paramContext);
          if (((Boolean)f0.d.c()).booleanValue()) {
            n n = z.p;
            if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
              g8.b.execute(new zzb(paramContext, paramString, paramAdRequest, paramInt, paramAppOpenAdLoadCallback));
              return;
            } 
          } 
          zzdx zzdx = paramAdRequest.zza();
          t3 t3 = new t3();
          zzp zzp = zzp.zza;
          try {
            zzq zzq = zzq.zzb();
            zzbu zzbu = zzay.zza().zzd(paramContext, zzq, paramString, (w3)t3);
            zzw zzw = new zzw(paramInt);
            if (zzbu != null) {
              zzbu.zzI(zzw);
              zzbu.zzH((l)new e(paramAppOpenAdLoadCallback, paramString));
              zzbu.zzaa(zzp.zza(paramContext, zzdx));
              return;
            } 
          } catch (RemoteException remoteException) {
            l8.h((Exception)remoteException);
          } 
          return;
        } 
        throw new NullPointerException("AdRequest cannot be null.");
      } 
      throw new NullPointerException("adUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public static void load(Context paramContext, String paramString, AdManagerAdRequest paramAdManagerAdRequest, @AppOpenAdOrientation int paramInt, AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdManagerAdRequest != null) {
          e.c("#008 Must be called on the main UI thread.");
          z.a(paramContext);
          if (((Boolean)f0.d.c()).booleanValue()) {
            n n = z.p;
            if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
              g8.b.execute(new zza(paramContext, paramString, paramAdManagerAdRequest, paramInt, paramAppOpenAdLoadCallback));
              return;
            } 
          } 
          zzdx zzdx = paramAdManagerAdRequest.zza();
          t3 t3 = new t3();
          zzp zzp = zzp.zza;
          try {
            zzq zzq = zzq.zzb();
            zzbu zzbu = zzay.zza().zzd(paramContext, zzq, paramString, (w3)t3);
            zzw zzw = new zzw(paramInt);
            if (zzbu != null) {
              zzbu.zzI(zzw);
              zzbu.zzH((l)new e(paramAppOpenAdLoadCallback, paramString));
              zzbu.zzaa(zzp.zza(paramContext, zzdx));
              return;
            } 
          } catch (RemoteException remoteException) {
            l8.h((Exception)remoteException);
          } 
          return;
        } 
        throw new NullPointerException("AdManagerAdRequest cannot be null.");
      } 
      throw new NullPointerException("adUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public abstract String getAdUnitId();
  
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  public abstract ResponseInfo getResponseInfo();
  
  public abstract void setFullScreenContentCallback(FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void show(Activity paramActivity);
  
  public static abstract class AppOpenAdLoadCallback extends AdLoadCallback<AppOpenAd> {}
  
  public static @interface AppOpenAdOrientation {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\appopen\AppOpenAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */