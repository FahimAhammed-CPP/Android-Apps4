package com.google.android.gms.ads;

import android.content.Context;
import java.util.List;

public class MediationUtils {
  public static AdSize findClosestSize(Context paramContext, AdSize paramAdSize, List<AdSize> paramList) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #11
    //   3: aconst_null
    //   4: astore #12
    //   6: aload_2
    //   7: ifnull -> 351
    //   10: aload_1
    //   11: ifnonnull -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: aload_1
    //   17: astore #10
    //   19: aload_1
    //   20: getfield e : Z
    //   23: ifne -> 81
    //   26: aload_1
    //   27: astore #10
    //   29: aload_1
    //   30: getfield g : Z
    //   33: ifne -> 81
    //   36: aload_0
    //   37: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   40: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   43: getfield density : F
    //   46: fstore #5
    //   48: new com/google/android/gms/ads/AdSize
    //   51: dup
    //   52: aload_1
    //   53: aload_0
    //   54: invokevirtual getWidthInPixels : (Landroid/content/Context;)I
    //   57: i2f
    //   58: fload #5
    //   60: fdiv
    //   61: invokestatic round : (F)I
    //   64: aload_1
    //   65: aload_0
    //   66: invokevirtual getHeightInPixels : (Landroid/content/Context;)I
    //   69: i2f
    //   70: fload #5
    //   72: fdiv
    //   73: invokestatic round : (F)I
    //   76: invokespecial <init> : (II)V
    //   79: astore #10
    //   81: aload_2
    //   82: invokeinterface iterator : ()Ljava/util/Iterator;
    //   87: astore_2
    //   88: aload #12
    //   90: astore_0
    //   91: aload_0
    //   92: astore #11
    //   94: aload_2
    //   95: invokeinterface hasNext : ()Z
    //   100: ifeq -> 351
    //   103: aload_2
    //   104: invokeinterface next : ()Ljava/lang/Object;
    //   109: checkcast com/google/android/gms/ads/AdSize
    //   112: astore_1
    //   113: aload_1
    //   114: ifnull -> 91
    //   117: aload #10
    //   119: invokevirtual getWidth : ()I
    //   122: istore #8
    //   124: aload_1
    //   125: invokevirtual getWidth : ()I
    //   128: istore #6
    //   130: aload #10
    //   132: invokevirtual getHeight : ()I
    //   135: istore #9
    //   137: aload_1
    //   138: invokevirtual getHeight : ()I
    //   141: istore #7
    //   143: iload #8
    //   145: i2d
    //   146: dstore_3
    //   147: dload_3
    //   148: invokestatic isNaN : (D)Z
    //   151: pop
    //   152: dload_3
    //   153: invokestatic isNaN : (D)Z
    //   156: pop
    //   157: dload_3
    //   158: ldc2_w 0.5
    //   161: dmul
    //   162: iload #6
    //   164: i2d
    //   165: dcmpl
    //   166: ifgt -> 91
    //   169: iload #8
    //   171: iload #6
    //   173: if_icmplt -> 91
    //   176: aload #10
    //   178: getfield g : Z
    //   181: ifeq -> 249
    //   184: aload #10
    //   186: getfield h : I
    //   189: istore #8
    //   191: getstatic w0/z.e : Lw0/o;
    //   194: astore #11
    //   196: invokestatic zzc : ()Lw0/x;
    //   199: aload #11
    //   201: invokevirtual a : (Lw0/s;)Ljava/lang/Object;
    //   204: checkcast java/lang/Integer
    //   207: invokevirtual intValue : ()I
    //   210: iload #6
    //   212: if_icmpgt -> 91
    //   215: getstatic w0/z.f : Lw0/o;
    //   218: astore #11
    //   220: invokestatic zzc : ()Lw0/x;
    //   223: aload #11
    //   225: invokevirtual a : (Lw0/s;)Ljava/lang/Object;
    //   228: checkcast java/lang/Integer
    //   231: invokevirtual intValue : ()I
    //   234: iload #7
    //   236: if_icmpgt -> 91
    //   239: iload #8
    //   241: iload #7
    //   243: if_icmplt -> 91
    //   246: goto -> 306
    //   249: aload #10
    //   251: getfield e : Z
    //   254: ifeq -> 270
    //   257: aload #10
    //   259: getfield f : I
    //   262: iload #7
    //   264: if_icmplt -> 91
    //   267: goto -> 306
    //   270: iload #9
    //   272: i2d
    //   273: dstore_3
    //   274: dload_3
    //   275: invokestatic isNaN : (D)Z
    //   278: pop
    //   279: dload_3
    //   280: invokestatic isNaN : (D)Z
    //   283: pop
    //   284: dload_3
    //   285: ldc2_w 0.7
    //   288: dmul
    //   289: iload #7
    //   291: i2d
    //   292: dcmpl
    //   293: ifgt -> 91
    //   296: iload #9
    //   298: iload #7
    //   300: if_icmpge -> 306
    //   303: goto -> 91
    //   306: aload_0
    //   307: ifnonnull -> 313
    //   310: goto -> 346
    //   313: aload_0
    //   314: invokevirtual getWidth : ()I
    //   317: istore #6
    //   319: aload_0
    //   320: invokevirtual getHeight : ()I
    //   323: istore #7
    //   325: aload_1
    //   326: invokevirtual getWidth : ()I
    //   329: istore #8
    //   331: iload #7
    //   333: iload #6
    //   335: imul
    //   336: aload_1
    //   337: invokevirtual getHeight : ()I
    //   340: iload #8
    //   342: imul
    //   343: if_icmpgt -> 91
    //   346: aload_1
    //   347: astore_0
    //   348: goto -> 91
    //   351: aload #11
    //   353: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\MediationUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */