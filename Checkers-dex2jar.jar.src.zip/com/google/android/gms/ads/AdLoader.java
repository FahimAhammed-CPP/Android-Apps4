package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import com.google.android.gms.ads.formats.OnAdManagerAdViewLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzbh;
import com.google.android.gms.ads.internal.client.zzbn;
import com.google.android.gms.ads.internal.client.zzbq;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.internal.client.zzeu;
import com.google.android.gms.ads.internal.client.zzfl;
import com.google.android.gms.ads.internal.client.zzg;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeCustomFormatAd;
import com.google.android.gms.internal.ads.zzblw;
import w0.f0;
import w0.g8;
import w0.k2;
import w0.l2;
import w0.l5;
import w0.l8;
import w0.m2;
import w0.m5;
import w0.n;
import w0.n5;
import w0.o2;
import w0.p2;
import w0.p5;
import w0.q1;
import w0.s;
import w0.t1;
import w0.w1;
import w0.z;
import w0.z1;

public class AdLoader {
  public final zzp a;
  
  public final Context b;
  
  public final zzbn c;
  
  public AdLoader(Context paramContext, zzbn paramzzbn, zzp paramzzp) {
    this.b = paramContext;
    this.c = paramzzbn;
    this.a = paramzzp;
  }
  
  public final void a(zzdx paramzzdx) {
    z.a(this.b);
    if (((Boolean)f0.c.c()).booleanValue()) {
      n n = z.p;
      if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
        g8.b.execute(new zza(this, paramzzdx));
        return;
      } 
    } 
    try {
      this.c.zzg(this.a.zza(this.b, paramzzdx));
      return;
    } catch (RemoteException remoteException) {
      l8.d("Failed to load ad.", (Throwable)remoteException);
      return;
    } 
  }
  
  public boolean isLoading() {
    try {
      return this.c.zzi();
    } catch (RemoteException remoteException) {
      l8.g("Failed to check if ad is loading.", (Throwable)remoteException);
      return false;
    } 
  }
  
  public void loadAd(AdRequest paramAdRequest) {
    a(paramAdRequest.zza());
  }
  
  public void loadAd(AdManagerAdRequest paramAdManagerAdRequest) {
    a(((AdRequest)paramAdManagerAdRequest).a);
  }
  
  public void loadAds(AdRequest paramAdRequest, int paramInt) {
    zzdx zzdx = paramAdRequest.zza();
    try {
      this.c.zzh(this.a.zza(this.b, zzdx), paramInt);
      return;
    } catch (RemoteException remoteException) {
      l8.d("Failed to load ads.", (Throwable)remoteException);
      return;
    } 
  }
  
  public static class Builder {
    public final Context a;
    
    public final zzbq b;
    
    public Builder(Context param1Context, String param1String) {}
    
    public AdLoader build() {
      try {
        return new AdLoader(this.a, this.b.zze(), zzp.zza);
      } catch (RemoteException remoteException) {
        l8.d("Failed to build AdLoader.", (Throwable)remoteException);
        zzeu zzeu = new zzeu();
        return new AdLoader(this.a, zzeu.zzc(), zzp.zza);
      } 
    }
    
    public Builder forAdManagerAdView(OnAdManagerAdViewLoadedListener param1OnAdManagerAdViewLoadedListener, AdSize... param1VarArgs) {
      if (param1VarArgs != null && param1VarArgs.length > 0)
        try {
          zzq zzq = new zzq(this.a, param1VarArgs);
          this.b.zzj((w1)new o2(param1OnAdManagerAdViewLoadedListener), zzq);
          return this;
        } catch (RemoteException remoteException) {
          l8.g("Failed to add Google Ad Manager banner ad listener", (Throwable)remoteException);
          return this;
        }  
      throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
    }
    
    public Builder forCustomFormatAd(String param1String, NativeCustomFormatAd.OnCustomFormatAdLoadedListener param1OnCustomFormatAdLoadedListener, NativeCustomFormatAd.OnCustomClickListener param1OnCustomClickListener) {
      n5 n5 = new n5(param1OnCustomFormatAdLoadedListener, param1OnCustomClickListener);
      try {
        l5 l5;
        zzbq zzbq1 = this.b;
        param1OnCustomFormatAdLoadedListener = null;
        m5 m5 = new m5(n5);
        if (param1OnCustomClickListener != null)
          l5 = new l5(n5); 
        zzbq1.zzh(param1String, (t1)m5, (q1)l5);
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to add custom format ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder forCustomTemplateAd(String param1String, NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener param1OnCustomTemplateAdLoadedListener, NativeCustomTemplateAd.OnCustomClickListener param1OnCustomClickListener) {
      m2 m2 = new m2(param1OnCustomTemplateAdLoadedListener, param1OnCustomClickListener);
      try {
        k2 k2;
        zzbq zzbq1 = this.b;
        param1OnCustomTemplateAdLoadedListener = null;
        l2 l2 = new l2(m2);
        if (param1OnCustomClickListener != null)
          k2 = new k2(m2); 
        zzbq1.zzh(param1String, (t1)l2, (q1)k2);
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to add custom template ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder forNativeAd(NativeAd.OnNativeAdLoadedListener param1OnNativeAdLoadedListener) {
      try {
        this.b.zzk((z1)new p5(param1OnNativeAdLoadedListener));
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to add google native ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder forUnifiedNativeAd(UnifiedNativeAd.OnUnifiedNativeAdLoadedListener param1OnUnifiedNativeAdLoadedListener) {
      try {
        this.b.zzk((z1)new p2(param1OnUnifiedNativeAdLoadedListener));
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to add google native ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder withAdListener(AdListener param1AdListener) {
      try {
        this.b.zzl((zzbh)new zzg(param1AdListener));
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to set AdListener.", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder withAdManagerAdViewOptions(AdManagerAdViewOptions param1AdManagerAdViewOptions) {
      try {
        this.b.zzm(param1AdManagerAdViewOptions);
        return this;
      } catch (RemoteException remoteException) {
        l8.g("Failed to specify Ad Manager banner ad options", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder withNativeAdOptions(NativeAdOptions param1NativeAdOptions) {
      int i;
      int j;
      boolean bool1;
      boolean bool2;
      zzbq zzbq1;
      try {
        zzbq1 = this.b;
        bool1 = param1NativeAdOptions.shouldReturnUrlsForImageAssets();
        i = param1NativeAdOptions.getImageOrientation();
        bool2 = param1NativeAdOptions.shouldRequestMultipleImages();
        j = param1NativeAdOptions.getAdChoicesPlacement();
        if (param1NativeAdOptions.getVideoOptions() != null) {
          zzfl zzfl1 = new zzfl(param1NativeAdOptions.getVideoOptions());
          zzbq1.zzo(new zzblw(4, bool1, i, bool2, j, zzfl1, param1NativeAdOptions.zza(), param1NativeAdOptions.getMediaAspectRatio(), 0, false));
          return this;
        } 
      } catch (RemoteException remoteException) {
        l8.g("Failed to specify native ad options", (Throwable)remoteException);
        return this;
      } 
      zzfl zzfl = null;
      zzbq1.zzo(new zzblw(4, bool1, i, bool2, j, zzfl, remoteException.zza(), remoteException.getMediaAspectRatio(), 0, false));
      return this;
    }
    
    public Builder withNativeAdOptions(NativeAdOptions param1NativeAdOptions) {
      int i;
      boolean bool1;
      boolean bool2;
      zzbq zzbq1;
      try {
        zzbq1 = this.b;
        bool1 = param1NativeAdOptions.shouldReturnUrlsForImageAssets();
        bool2 = param1NativeAdOptions.shouldRequestMultipleImages();
        i = param1NativeAdOptions.getAdChoicesPlacement();
        if (param1NativeAdOptions.getVideoOptions() != null) {
          zzfl zzfl1 = new zzfl(param1NativeAdOptions.getVideoOptions());
          zzbq1.zzo(new zzblw(4, bool1, -1, bool2, i, zzfl1, param1NativeAdOptions.zzc(), param1NativeAdOptions.getMediaAspectRatio(), param1NativeAdOptions.zza(), param1NativeAdOptions.zzb()));
          return this;
        } 
      } catch (RemoteException remoteException) {
        l8.g("Failed to specify native ad options", (Throwable)remoteException);
        return this;
      } 
      zzfl zzfl = null;
      zzbq1.zzo(new zzblw(4, bool1, -1, bool2, i, zzfl, remoteException.zzc(), remoteException.getMediaAspectRatio(), remoteException.zza(), remoteException.zzb()));
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */