package com.google.android.gms.ads.rewardedinterstitial;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions;
import p0.e;
import w0.f0;
import w0.g8;
import w0.n;
import w0.s;
import w0.w7;
import w0.z;

public abstract class RewardedInterstitialAd {
  public static void load(Context paramContext, String paramString, AdRequest paramAdRequest, RewardedInterstitialAdLoadCallback paramRewardedInterstitialAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdRequest != null) {
          if (paramRewardedInterstitialAdLoadCallback != null) {
            e.c("#008 Must be called on the main UI thread.");
            z.a(paramContext);
            if (((Boolean)f0.k.c()).booleanValue()) {
              n n = z.p;
              if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
                g8.b.execute(new zza(paramContext, paramString, paramAdRequest, paramRewardedInterstitialAdLoadCallback));
                return;
              } 
            } 
            (new w7(paramContext, paramString)).a(paramAdRequest.zza(), paramRewardedInterstitialAdLoadCallback);
            return;
          } 
          throw new NullPointerException("LoadCallback cannot be null.");
        } 
        throw new NullPointerException("AdRequest cannot be null.");
      } 
      throw new NullPointerException("AdUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public static void load(Context paramContext, String paramString, AdManagerAdRequest paramAdManagerAdRequest, RewardedInterstitialAdLoadCallback paramRewardedInterstitialAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdManagerAdRequest != null) {
          if (paramRewardedInterstitialAdLoadCallback != null) {
            e.c("#008 Must be called on the main UI thread.");
            z.a(paramContext);
            if (((Boolean)f0.k.c()).booleanValue()) {
              n n = z.p;
              if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
                g8.b.execute(new zzb(paramContext, paramString, paramAdManagerAdRequest, paramRewardedInterstitialAdLoadCallback));
                return;
              } 
            } 
            (new w7(paramContext, paramString)).a(paramAdManagerAdRequest.zza(), paramRewardedInterstitialAdLoadCallback);
            return;
          } 
          throw new NullPointerException("LoadCallback cannot be null.");
        } 
        throw new NullPointerException("AdManagerAdRequest cannot be null.");
      } 
      throw new NullPointerException("AdUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public abstract Bundle getAdMetadata();
  
  public abstract String getAdUnitId();
  
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  public abstract OnAdMetadataChangedListener getOnAdMetadataChangedListener();
  
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  public abstract ResponseInfo getResponseInfo();
  
  public abstract RewardItem getRewardItem();
  
  public abstract void setFullScreenContentCallback(FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnAdMetadataChangedListener(OnAdMetadataChangedListener paramOnAdMetadataChangedListener);
  
  public abstract void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void setServerSideVerificationOptions(ServerSideVerificationOptions paramServerSideVerificationOptions);
  
  public abstract void show(Activity paramActivity, OnUserEarnedRewardListener paramOnUserEarnedRewardListener);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\rewardedinterstitial\RewardedInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */