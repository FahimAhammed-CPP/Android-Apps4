package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.os.SystemClock;
import i0.a;
import java.util.HashMap;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.GuardedBy;
import m0.a;
import p0.e;
import x0.e;

@ParametersAreNonnullByDefault
public class AdvertisingIdClient {
  @GuardedBy("this")
  public a a;
  
  @GuardedBy("this")
  public e b;
  
  @GuardedBy("this")
  public boolean c;
  
  public final Object d = new Object();
  
  @GuardedBy("mAutoDisconnectTaskLock")
  public a e;
  
  @GuardedBy("this")
  public final Context f;
  
  public final long g;
  
  public AdvertisingIdClient(Context paramContext) {
    this(paramContext, 30000L, false, false);
  }
  
  public AdvertisingIdClient(Context paramContext, long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    e.g(paramContext);
    Context context = paramContext;
    if (paramBoolean1) {
      Context context1 = paramContext.getApplicationContext();
      context = paramContext;
      if (context1 != null)
        context = context1; 
    } 
    this.f = context;
    this.c = false;
    this.g = paramLong;
  }
  
  public static void b(Info paramInfo, long paramLong, Throwable paramThrowable) {
    if (Math.random() <= 0.0D) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      String str = "1";
      hashMap.put("app_context", "1");
      if (paramInfo != null) {
        if (true != paramInfo.isLimitAdTrackingEnabled())
          str = "0"; 
        hashMap.put("limit_ad_tracking", str);
        String str1 = paramInfo.getId();
        if (str1 != null)
          hashMap.put("ad_id_size", Integer.toString(str1.length())); 
      } 
      if (paramThrowable != null)
        hashMap.put("error", paramThrowable.getClass().getName()); 
      hashMap.put("tag", "AdvertisingIdClient");
      hashMap.put("time_spent", Long.toString(paramLong));
      (new a(hashMap)).start();
    } 
  }
  
  public static Info getAdvertisingIdInfo(Context paramContext) {
    AdvertisingIdClient advertisingIdClient = new AdvertisingIdClient(paramContext, -1L, true, false);
    try {
      long l = SystemClock.elapsedRealtime();
      advertisingIdClient.a(false);
      Info info = advertisingIdClient.c();
      b(info, SystemClock.elapsedRealtime() - l, null);
      return info;
    } finally {
      null = null;
    } 
  }
  
  public static boolean getIsAdIdFakeForDebugLogging(Context paramContext) {
    // Byte code:
    //   0: new com/google/android/gms/ads/identifier/AdvertisingIdClient
    //   3: dup
    //   4: aload_0
    //   5: ldc2_w -1
    //   8: iconst_0
    //   9: iconst_0
    //   10: invokespecial <init> : (Landroid/content/Context;JZZ)V
    //   13: astore_0
    //   14: aload_0
    //   15: iconst_0
    //   16: invokevirtual a : (Z)V
    //   19: ldc 'Calling this from your main thread can lead to deadlock'
    //   21: invokestatic f : (Ljava/lang/String;)V
    //   24: aload_0
    //   25: monitorenter
    //   26: aload_0
    //   27: getfield c : Z
    //   30: ifne -> 110
    //   33: aload_0
    //   34: getfield d : Ljava/lang/Object;
    //   37: astore_2
    //   38: aload_2
    //   39: monitorenter
    //   40: aload_0
    //   41: getfield e : Li0/a;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnull -> 95
    //   49: aload_3
    //   50: getfield l : Z
    //   53: ifeq -> 95
    //   56: aload_2
    //   57: monitorexit
    //   58: aload_0
    //   59: iconst_0
    //   60: invokevirtual a : (Z)V
    //   63: aload_0
    //   64: getfield c : Z
    //   67: ifeq -> 73
    //   70: goto -> 110
    //   73: new java/io/IOException
    //   76: dup
    //   77: ldc 'AdvertisingIdClient cannot reconnect.'
    //   79: invokespecial <init> : (Ljava/lang/String;)V
    //   82: athrow
    //   83: astore_2
    //   84: new java/io/IOException
    //   87: dup
    //   88: ldc 'AdvertisingIdClient cannot reconnect.'
    //   90: aload_2
    //   91: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   94: athrow
    //   95: new java/io/IOException
    //   98: dup
    //   99: ldc 'AdvertisingIdClient is not connected.'
    //   101: invokespecial <init> : (Ljava/lang/String;)V
    //   104: athrow
    //   105: astore_3
    //   106: aload_2
    //   107: monitorexit
    //   108: aload_3
    //   109: athrow
    //   110: aload_0
    //   111: getfield a : Lm0/a;
    //   114: invokestatic g : (Ljava/lang/Object;)V
    //   117: aload_0
    //   118: getfield b : Lx0/e;
    //   121: invokestatic g : (Ljava/lang/Object;)V
    //   124: aload_0
    //   125: getfield b : Lx0/e;
    //   128: invokeinterface zzd : ()Z
    //   133: istore_1
    //   134: aload_0
    //   135: monitorexit
    //   136: aload_0
    //   137: invokevirtual d : ()V
    //   140: aload_0
    //   141: invokevirtual zza : ()V
    //   144: iload_1
    //   145: ireturn
    //   146: astore_2
    //   147: ldc 'AdvertisingIdClient'
    //   149: ldc 'GMS remote exception '
    //   151: aload_2
    //   152: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   155: pop
    //   156: new java/io/IOException
    //   159: dup
    //   160: ldc 'Remote exception'
    //   162: invokespecial <init> : (Ljava/lang/String;)V
    //   165: athrow
    //   166: astore_2
    //   167: aload_0
    //   168: monitorexit
    //   169: aload_2
    //   170: athrow
    //   171: astore_2
    //   172: aload_0
    //   173: invokevirtual zza : ()V
    //   176: aload_2
    //   177: athrow
    // Exception table:
    //   from	to	target	type
    //   14	26	171	finally
    //   26	40	166	finally
    //   40	45	105	finally
    //   49	58	105	finally
    //   58	63	83	java/lang/Exception
    //   58	63	166	finally
    //   63	70	166	finally
    //   73	83	166	finally
    //   84	95	166	finally
    //   95	105	105	finally
    //   106	108	105	finally
    //   108	110	166	finally
    //   110	124	166	finally
    //   124	134	146	android/os/RemoteException
    //   124	134	166	finally
    //   134	136	166	finally
    //   136	140	171	finally
    //   147	166	166	finally
    //   167	169	166	finally
    //   169	171	171	finally
  }
  
  public static void setShouldSkipGmsCoreVersionCheck(boolean paramBoolean) {}
  
  public final void a(boolean paramBoolean) {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic f : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifeq -> 18
    //   14: aload_0
    //   15: invokevirtual zza : ()V
    //   18: aload_0
    //   19: getfield f : Landroid/content/Context;
    //   22: astore #4
    //   24: aload #4
    //   26: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   29: ldc 'com.android.vending'
    //   31: iconst_0
    //   32: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   35: pop
    //   36: getstatic m0/b.b : Lm0/b;
    //   39: invokevirtual getClass : ()Ljava/lang/Class;
    //   42: pop
    //   43: aload #4
    //   45: ldc 12451000
    //   47: invokestatic b : (Landroid/content/Context;I)I
    //   50: istore_2
    //   51: iload_2
    //   52: ifeq -> 73
    //   55: iload_2
    //   56: iconst_2
    //   57: if_icmpne -> 63
    //   60: goto -> 73
    //   63: new java/io/IOException
    //   66: dup
    //   67: ldc 'Google Play services not available'
    //   69: invokespecial <init> : (Ljava/lang/String;)V
    //   72: athrow
    //   73: new m0/a
    //   76: dup
    //   77: invokespecial <init> : ()V
    //   80: astore #5
    //   82: new android/content/Intent
    //   85: dup
    //   86: ldc 'com.google.android.gms.ads.identifier.service.START'
    //   88: invokespecial <init> : (Ljava/lang/String;)V
    //   91: astore #6
    //   93: aload #6
    //   95: ldc 'com.google.android.gms'
    //   97: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   100: pop
    //   101: invokestatic b : ()Lr0/a;
    //   104: aload #4
    //   106: aload #6
    //   108: aload #5
    //   110: iconst_1
    //   111: invokevirtual a : (Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   114: istore_3
    //   115: iload_3
    //   116: ifeq -> 225
    //   119: aload_0
    //   120: aload #5
    //   122: putfield a : Lm0/a;
    //   125: aload #5
    //   127: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   130: invokevirtual a : (Ljava/util/concurrent/TimeUnit;)Landroid/os/IBinder;
    //   133: astore #4
    //   135: getstatic x0/d.a : I
    //   138: istore_2
    //   139: aload #4
    //   141: ldc_w 'com.google.android.gms.ads.identifier.internal.IAdvertisingIdService'
    //   144: invokeinterface queryLocalInterface : (Ljava/lang/String;)Landroid/os/IInterface;
    //   149: astore #5
    //   151: aload #5
    //   153: instanceof x0/e
    //   156: ifeq -> 169
    //   159: aload #5
    //   161: checkcast x0/e
    //   164: astore #4
    //   166: goto -> 180
    //   169: new x0/c
    //   172: dup
    //   173: aload #4
    //   175: invokespecial <init> : (Landroid/os/IBinder;)V
    //   178: astore #4
    //   180: aload_0
    //   181: aload #4
    //   183: putfield b : Lx0/e;
    //   186: aload_0
    //   187: iconst_1
    //   188: putfield c : Z
    //   191: iload_1
    //   192: ifeq -> 199
    //   195: aload_0
    //   196: invokevirtual d : ()V
    //   199: aload_0
    //   200: monitorexit
    //   201: return
    //   202: astore #4
    //   204: new java/io/IOException
    //   207: dup
    //   208: aload #4
    //   210: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   213: athrow
    //   214: new java/io/IOException
    //   217: dup
    //   218: ldc_w 'Interrupted exception'
    //   221: invokespecial <init> : (Ljava/lang/String;)V
    //   224: athrow
    //   225: new java/io/IOException
    //   228: dup
    //   229: ldc_w 'Connection failure'
    //   232: invokespecial <init> : (Ljava/lang/String;)V
    //   235: athrow
    //   236: astore #4
    //   238: new java/io/IOException
    //   241: dup
    //   242: aload #4
    //   244: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   247: athrow
    //   248: new m0/c
    //   251: dup
    //   252: invokespecial <init> : ()V
    //   255: athrow
    //   256: aload_0
    //   257: monitorexit
    //   258: aload #4
    //   260: athrow
    //   261: astore #4
    //   263: goto -> 248
    //   266: astore #4
    //   268: goto -> 214
    //   271: astore #4
    //   273: goto -> 256
    // Exception table:
    //   from	to	target	type
    //   7	18	271	finally
    //   18	24	271	finally
    //   24	36	261	android/content/pm/PackageManager$NameNotFoundException
    //   24	36	271	finally
    //   36	51	271	finally
    //   63	73	271	finally
    //   73	101	271	finally
    //   101	115	236	finally
    //   119	125	271	finally
    //   125	166	266	java/lang/InterruptedException
    //   125	166	202	finally
    //   169	180	266	java/lang/InterruptedException
    //   169	180	202	finally
    //   180	191	271	finally
    //   195	199	271	finally
    //   199	201	271	finally
    //   204	214	271	finally
    //   214	225	271	finally
    //   225	236	271	finally
    //   238	248	271	finally
    //   248	256	271	finally
    //   256	258	271	finally
  }
  
  public final Info c() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic f : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifne -> 91
    //   14: aload_0
    //   15: getfield d : Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield e : Li0/a;
    //   25: astore_2
    //   26: aload_2
    //   27: ifnull -> 76
    //   30: aload_2
    //   31: getfield l : Z
    //   34: ifeq -> 76
    //   37: aload_1
    //   38: monitorexit
    //   39: aload_0
    //   40: iconst_0
    //   41: invokevirtual a : (Z)V
    //   44: aload_0
    //   45: getfield c : Z
    //   48: ifeq -> 54
    //   51: goto -> 91
    //   54: new java/io/IOException
    //   57: dup
    //   58: ldc 'AdvertisingIdClient cannot reconnect.'
    //   60: invokespecial <init> : (Ljava/lang/String;)V
    //   63: athrow
    //   64: astore_1
    //   65: new java/io/IOException
    //   68: dup
    //   69: ldc 'AdvertisingIdClient cannot reconnect.'
    //   71: aload_1
    //   72: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   75: athrow
    //   76: new java/io/IOException
    //   79: dup
    //   80: ldc 'AdvertisingIdClient is not connected.'
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: athrow
    //   86: astore_2
    //   87: aload_1
    //   88: monitorexit
    //   89: aload_2
    //   90: athrow
    //   91: aload_0
    //   92: getfield a : Lm0/a;
    //   95: invokestatic g : (Ljava/lang/Object;)V
    //   98: aload_0
    //   99: getfield b : Lx0/e;
    //   102: invokestatic g : (Ljava/lang/Object;)V
    //   105: new com/google/android/gms/ads/identifier/AdvertisingIdClient$Info
    //   108: dup
    //   109: aload_0
    //   110: getfield b : Lx0/e;
    //   113: invokeinterface zzc : ()Ljava/lang/String;
    //   118: aload_0
    //   119: getfield b : Lx0/e;
    //   122: invokeinterface zze : ()Z
    //   127: invokespecial <init> : (Ljava/lang/String;Z)V
    //   130: astore_1
    //   131: aload_0
    //   132: monitorexit
    //   133: aload_0
    //   134: invokevirtual d : ()V
    //   137: aload_1
    //   138: areturn
    //   139: astore_1
    //   140: ldc 'AdvertisingIdClient'
    //   142: ldc 'GMS remote exception '
    //   144: aload_1
    //   145: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   148: pop
    //   149: new java/io/IOException
    //   152: dup
    //   153: ldc 'Remote exception'
    //   155: invokespecial <init> : (Ljava/lang/String;)V
    //   158: athrow
    //   159: astore_1
    //   160: aload_0
    //   161: monitorexit
    //   162: aload_1
    //   163: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	159	finally
    //   21	26	86	finally
    //   30	39	86	finally
    //   39	44	64	java/lang/Exception
    //   39	44	159	finally
    //   44	51	159	finally
    //   54	64	159	finally
    //   65	76	159	finally
    //   76	86	86	finally
    //   87	89	86	finally
    //   89	91	159	finally
    //   91	105	159	finally
    //   105	131	139	android/os/RemoteException
    //   105	131	159	finally
    //   131	133	159	finally
    //   140	159	159	finally
    //   160	162	159	finally
  }
  
  public final void d() {
    synchronized (this.d) {
      a a1 = this.e;
      if (a1 != null) {
        a1.k.countDown();
        try {
          this.e.join();
        } catch (InterruptedException interruptedException) {}
      } 
      long l = this.g;
      if (l > 0L)
        this.e = new a(this, l); 
      return;
    } 
  }
  
  public final void finalize() {
    zza();
    super.finalize();
  }
  
  public Info getInfo() {
    return c();
  }
  
  public void start() {
    a(true);
  }
  
  public final void zza() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic f : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield f : Landroid/content/Context;
    //   11: ifnull -> 79
    //   14: aload_0
    //   15: getfield a : Lm0/a;
    //   18: astore_1
    //   19: aload_1
    //   20: ifnonnull -> 26
    //   23: goto -> 79
    //   26: aload_0
    //   27: getfield c : Z
    //   30: ifeq -> 61
    //   33: invokestatic b : ()Lr0/a;
    //   36: aload_0
    //   37: getfield f : Landroid/content/Context;
    //   40: aload_0
    //   41: getfield a : Lm0/a;
    //   44: invokevirtual c : (Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   47: goto -> 61
    //   50: astore_1
    //   51: ldc 'AdvertisingIdClient'
    //   53: ldc_w 'AdvertisingIdClient unbindService failed.'
    //   56: aload_1
    //   57: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   60: pop
    //   61: aload_0
    //   62: iconst_0
    //   63: putfield c : Z
    //   66: aload_0
    //   67: aconst_null
    //   68: putfield b : Lx0/e;
    //   71: aload_0
    //   72: aconst_null
    //   73: putfield a : Lm0/a;
    //   76: aload_0
    //   77: monitorexit
    //   78: return
    //   79: aload_0
    //   80: monitorexit
    //   81: return
    //   82: astore_1
    //   83: aload_0
    //   84: monitorexit
    //   85: aload_1
    //   86: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	82	finally
    //   26	47	50	finally
    //   51	61	82	finally
    //   61	78	82	finally
    //   79	81	82	finally
    //   83	85	82	finally
  }
  
  public static final class Info {
    public final String a;
    
    public final boolean b;
    
    @Deprecated
    public Info(String param1String, boolean param1Boolean) {
      this.a = param1String;
      this.b = param1Boolean;
    }
    
    public String getId() {
      return this.a;
    }
    
    public boolean isLimitAdTrackingEnabled() {
      return this.b;
    }
    
    public String toString() {
      String str = this.a;
      boolean bool = this.b;
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 7);
      stringBuilder.append("{");
      stringBuilder.append(str);
      stringBuilder.append("}");
      stringBuilder.append(bool);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\identifier\AdvertisingIdClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */