package com.google.android.gms.ads.identifier;

import android.util.Log;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public final class zzc {
  public static final void zza(String paramString) {
    try {
      HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(paramString)).openConnection();
      try {
        int i = httpURLConnection.getResponseCode();
        if (i < 200 || i >= 300) {
          StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 65);
          stringBuilder.append("Received non-success response code ");
          stringBuilder.append(i);
          stringBuilder.append(" from pinging URL: ");
          stringBuilder.append(paramString);
          Log.w("HttpUrlPinger", stringBuilder.toString());
        } 
        return;
      } finally {
        httpURLConnection.disconnect();
      } 
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      String str = indexOutOfBoundsException.getMessage();
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 32 + String.valueOf(str).length());
      stringBuilder.append("Error while parsing ping URL: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      Log.w("HttpUrlPinger", stringBuilder.toString(), indexOutOfBoundsException);
      return;
    } catch (IOException iOException) {
      String str = iOException.getMessage();
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 27 + String.valueOf(str).length());
      stringBuilder.append("Error while pinging URL: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      Log.w("HttpUrlPinger", stringBuilder.toString(), iOException);
      return;
    } catch (RuntimeException runtimeException) {
      String str = runtimeException.getMessage();
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 27 + String.valueOf(str).length());
      stringBuilder.append("Error while pinging URL: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      Log.w("HttpUrlPinger", stringBuilder.toString(), runtimeException);
      return;
    } finally {}
    throw paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\identifier\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */