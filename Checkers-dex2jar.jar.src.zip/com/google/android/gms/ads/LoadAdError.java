package com.google.android.gms.ads;

import org.json.JSONException;
import org.json.JSONObject;

public final class LoadAdError extends AdError {
  public final ResponseInfo e;
  
  public LoadAdError(int paramInt, String paramString1, String paramString2, AdError paramAdError, ResponseInfo paramResponseInfo) {
    super(paramInt, paramString1, paramString2, paramAdError);
    this.e = paramResponseInfo;
  }
  
  public ResponseInfo getResponseInfo() {
    return this.e;
  }
  
  public String toString() {
    try {
      return zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final JSONObject zzb() {
    String str;
    JSONObject jSONObject1;
    JSONObject jSONObject2 = super.zzb();
    ResponseInfo responseInfo = getResponseInfo();
    if (responseInfo == null) {
      str = "null";
    } else {
      jSONObject1 = str.zzd();
    } 
    jSONObject2.put("Response Info", jSONObject1);
    return jSONObject2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\LoadAdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */