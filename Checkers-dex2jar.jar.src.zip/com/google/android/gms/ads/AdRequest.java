package com.google.android.gms.ads;

import android.content.Context;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.zzdw;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.mediation.MediationExtrasReceiver;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.ads.query.AdInfo;
import java.util.Date;
import java.util.List;
import java.util.Set;
import p0.e;
import w0.l8;

public class AdRequest {
  public static final String DEVICE_ID_EMULATOR = "B3EEABB8EE11C2BE770B684D95219ECB";
  
  public static final int ERROR_CODE_APP_ID_MISSING = 8;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_AD_STRING = 11;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_MEDIATION_NO_FILL = 9;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  public static final int ERROR_CODE_REQUEST_ID_MISMATCH = 10;
  
  public static final int GENDER_FEMALE = 2;
  
  public static final int GENDER_MALE = 1;
  
  public static final int GENDER_UNKNOWN = 0;
  
  public static final int MAX_CONTENT_URL_LENGTH = 512;
  
  public final zzdx a;
  
  public AdRequest(Builder paramBuilder) {
    this.a = new zzdx(paramBuilder.a, null);
  }
  
  public String getContentUrl() {
    return this.a.zzl();
  }
  
  public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> paramClass) {
    return this.a.zzd(paramClass);
  }
  
  public Bundle getCustomTargeting() {
    return this.a.zze();
  }
  
  public Set<String> getKeywords() {
    return this.a.zzr();
  }
  
  public List<String> getNeighboringContentUrls() {
    return this.a.zzp();
  }
  
  public <T extends MediationExtrasReceiver> Bundle getNetworkExtrasBundle(Class<T> paramClass) {
    return this.a.zzf(paramClass);
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.a.zzt(paramContext);
  }
  
  public zzdx zza() {
    return this.a;
  }
  
  public static class Builder {
    public final zzdw a;
    
    public Builder() {
      zzdw zzdw1 = new zzdw();
      this.a = zzdw1;
      zzdw1.zzw("B3EEABB8EE11C2BE770B684D95219ECB");
    }
    
    public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> param1Class, Bundle param1Bundle) {
      this.a.zzr(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addKeyword(String param1String) {
      this.a.zzt(param1String);
      return this;
    }
    
    public Builder addNetworkExtrasBundle(Class<? extends MediationExtrasReceiver> param1Class, Bundle param1Bundle) {
      this.a.zzu(param1Class, param1Bundle);
      if (param1Class.equals(AdMobAdapter.class) && param1Bundle.getBoolean("_emulatorLiveAds"))
        this.a.zzx("B3EEABB8EE11C2BE770B684D95219ECB"); 
      return this;
    }
    
    public AdRequest build() {
      return new AdRequest(this);
    }
    
    @Deprecated
    public Builder setAdInfo(AdInfo param1AdInfo) {
      this.a.zzy(param1AdInfo);
      return this;
    }
    
    public Builder setAdString(String param1String) {
      this.a.zzz(param1String);
      return this;
    }
    
    public Builder setContentUrl(String param1String) {
      if (param1String != null) {
        boolean bool;
        e.e(param1String, "Content URL must be non-empty.");
        if (param1String.length() <= 512) {
          bool = true;
        } else {
          bool = false;
        } 
        int i = param1String.length();
        if (bool) {
          this.a.zzB(param1String);
          return this;
        } 
        throw new IllegalArgumentException(String.format("Content URL must not exceed %d in length.  Provided length was %d.", new Object[] { Integer.valueOf(512), Integer.valueOf(i) }));
      } 
      throw new NullPointerException("Content URL must be non-null.");
    }
    
    public Builder setHttpTimeoutMillis(int param1Int) {
      this.a.zzD(param1Int);
      return this;
    }
    
    public Builder setNeighboringContentUrls(List<String> param1List) {
      if (param1List == null) {
        l8.f("neighboring content URLs list should not be null");
        return this;
      } 
      this.a.zzF(param1List);
      return this;
    }
    
    public Builder setRequestAgent(String param1String) {
      this.a.zzH(param1String);
      return this;
    }
    
    @Deprecated
    public final Builder zza(String param1String) {
      this.a.zzw(param1String);
      return this;
    }
    
    @Deprecated
    public final Builder zzb(Date param1Date) {
      this.a.zzA(param1Date);
      return this;
    }
    
    @Deprecated
    public final Builder zzc(int param1Int) {
      this.a.zzC(param1Int);
      return this;
    }
    
    @Deprecated
    public final Builder zzd(boolean param1Boolean) {
      this.a.zzE(param1Boolean);
      return this;
    }
    
    @Deprecated
    public final Builder zze(boolean param1Boolean) {
      this.a.zzI(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */