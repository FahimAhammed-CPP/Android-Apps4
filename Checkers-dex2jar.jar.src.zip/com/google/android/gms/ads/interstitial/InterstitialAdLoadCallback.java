package com.google.android.gms.ads.interstitial;

import com.google.android.gms.ads.AdLoadCallback;

public abstract class InterstitialAdLoadCallback extends AdLoadCallback<InterstitialAd> {}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interstitial\InterstitialAdLoadCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */