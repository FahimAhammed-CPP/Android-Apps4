package com.google.android.gms.ads.interstitial;

import android.app.Activity;
import android.content.Context;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.internal.client.zzba;
import p0.e;
import w0.f0;
import w0.g8;
import w0.n;
import w0.p3;
import w0.s;
import w0.z;

public abstract class InterstitialAd {
  public static void load(Context paramContext, String paramString, AdRequest paramAdRequest, InterstitialAdLoadCallback paramInterstitialAdLoadCallback) {
    if (paramContext != null) {
      if (paramString != null) {
        if (paramAdRequest != null) {
          if (paramInterstitialAdLoadCallback != null) {
            e.c("#008 Must be called on the main UI thread.");
            z.a(paramContext);
            if (((Boolean)f0.i.c()).booleanValue()) {
              n n = z.p;
              if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
                g8.b.execute(new zza(paramContext, paramString, paramAdRequest, paramInterstitialAdLoadCallback));
                return;
              } 
            } 
            (new p3(paramContext, paramString)).a(paramAdRequest.zza(), paramInterstitialAdLoadCallback);
            return;
          } 
          throw new NullPointerException("LoadCallback cannot be null.");
        } 
        throw new NullPointerException("AdRequest cannot be null.");
      } 
      throw new NullPointerException("AdUnitId cannot be null.");
    } 
    throw new NullPointerException("Context cannot be null.");
  }
  
  public abstract String getAdUnitId();
  
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  public abstract ResponseInfo getResponseInfo();
  
  public abstract void setFullScreenContentCallback(FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void show(Activity paramActivity);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interstitial\InterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */