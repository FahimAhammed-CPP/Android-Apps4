package com.google.android.gms.ads;

import android.os.Bundle;
import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.ads.internal.client.zzu;
import org.json.JSONException;
import org.json.JSONObject;

public final class AdapterResponseInfo {
  public final zzu a;
  
  public final AdError b;
  
  public AdapterResponseInfo(zzu paramzzu) {
    AdError adError;
    this.a = paramzzu;
    zze zze = paramzzu.zzc;
    if (zze == null) {
      zze = null;
    } else {
      adError = zze.zza();
    } 
    this.b = adError;
  }
  
  public static AdapterResponseInfo zza(zzu paramzzu) {
    return (paramzzu != null) ? new AdapterResponseInfo(paramzzu) : null;
  }
  
  public AdError getAdError() {
    return this.b;
  }
  
  public String getAdSourceId() {
    return this.a.zzf;
  }
  
  public String getAdSourceInstanceId() {
    return this.a.zzh;
  }
  
  public String getAdSourceInstanceName() {
    return this.a.zzg;
  }
  
  public String getAdSourceName() {
    return this.a.zze;
  }
  
  public String getAdapterClassName() {
    return this.a.zza;
  }
  
  public Bundle getCredentials() {
    return this.a.zzd;
  }
  
  public long getLatencyMillis() {
    return this.a.zzb;
  }
  
  public String toString() {
    try {
      return zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final JSONObject zzb() {
    JSONObject jSONObject1 = new JSONObject();
    jSONObject1.put("Adapter", this.a.zza);
    jSONObject1.put("Latency", this.a.zzb);
    String str = getAdSourceName();
    if (str == null) {
      jSONObject1.put("Ad Source Name", "null");
    } else {
      jSONObject1.put("Ad Source Name", str);
    } 
    str = getAdSourceId();
    if (str == null) {
      jSONObject1.put("Ad Source ID", "null");
    } else {
      jSONObject1.put("Ad Source ID", str);
    } 
    str = getAdSourceInstanceName();
    if (str == null) {
      jSONObject1.put("Ad Source Instance Name", "null");
    } else {
      jSONObject1.put("Ad Source Instance Name", str);
    } 
    str = getAdSourceInstanceId();
    if (str == null) {
      jSONObject1.put("Ad Source Instance ID", "null");
    } else {
      jSONObject1.put("Ad Source Instance ID", str);
    } 
    JSONObject jSONObject2 = new JSONObject();
    for (String str1 : this.a.zzd.keySet())
      jSONObject2.put(str1, this.a.zzd.get(str1)); 
    jSONObject1.put("Credentials", jSONObject2);
    AdError adError = this.b;
    if (adError == null) {
      jSONObject1.put("Ad Error", "null");
      return jSONObject1;
    } 
    jSONObject1.put("Ad Error", adError.zzb());
    return jSONObject1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\AdapterResponseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */