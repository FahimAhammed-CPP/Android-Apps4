package com.google.android.gms.ads;

import android.graphics.drawable.Drawable;
import w0.i1;

public interface MediaContent {
  float getAspectRatio();
  
  float getCurrentTime();
  
  float getDuration();
  
  Drawable getMainImage();
  
  VideoController getVideoController();
  
  boolean hasVideoContent();
  
  void setMainImage(Drawable paramDrawable);
  
  i1 zza();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\MediaContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */