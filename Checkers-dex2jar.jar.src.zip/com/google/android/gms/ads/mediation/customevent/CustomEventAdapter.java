package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeMediationAdRequest;
import com.google.android.gms.common.annotation.KeepName;
import e0.u;
import e0.z;
import k0.a;
import w0.l8;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {
  public static final AdError e = new AdError(0, "Could not instantiate custom event adapter", "com.google.android.gms.ads");
  
  public View a;
  
  public CustomEventBanner b;
  
  public CustomEventInterstitial c;
  
  public CustomEventNative d;
  
  public static Object a(Class<Class<?>> paramClass, String paramString) {
    paramString.getClass();
    try {
      return paramClass.cast(Class.forName(paramString).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
    } finally {
      paramClass = null;
      String str = paramClass.getMessage();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not instantiate custom event adapter: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      l8.f(stringBuilder.toString());
    } 
  }
  
  public View getBannerView() {
    return this.a;
  }
  
  public void onDestroy() {
    CustomEventBanner customEventBanner = this.b;
    if (customEventBanner != null)
      customEventBanner.onDestroy(); 
    CustomEventInterstitial customEventInterstitial = this.c;
    if (customEventInterstitial != null)
      customEventInterstitial.onDestroy(); 
    CustomEventNative customEventNative = this.d;
    if (customEventNative != null)
      customEventNative.onDestroy(); 
  }
  
  public void onPause() {
    CustomEventBanner customEventBanner = this.b;
    if (customEventBanner != null)
      customEventBanner.onPause(); 
    CustomEventInterstitial customEventInterstitial = this.c;
    if (customEventInterstitial != null)
      customEventInterstitial.onPause(); 
    CustomEventNative customEventNative = this.d;
    if (customEventNative != null)
      customEventNative.onPause(); 
  }
  
  public void onResume() {
    CustomEventBanner customEventBanner = this.b;
    if (customEventBanner != null)
      customEventBanner.onResume(); 
    CustomEventInterstitial customEventInterstitial = this.c;
    if (customEventInterstitial != null)
      customEventInterstitial.onResume(); 
    CustomEventNative customEventNative = this.d;
    if (customEventNative != null)
      customEventNative.onResume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    CustomEventBanner customEventBanner = (CustomEventBanner)a(CustomEventBanner.class, paramBundle1.getString("class_name"));
    this.b = customEventBanner;
    if (customEventBanner == null) {
      paramMediationBannerListener.onAdFailedToLoad(this, e);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventBanner = this.b;
    customEventBanner.getClass();
    customEventBanner.requestBannerAd(paramContext, (CustomEventBannerListener)new z(this, paramMediationBannerListener), paramBundle1.getString("parameter"), paramAdSize, paramMediationAdRequest, paramBundle2);
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    CustomEventInterstitial customEventInterstitial = (CustomEventInterstitial)a(CustomEventInterstitial.class, paramBundle1.getString("class_name"));
    this.c = customEventInterstitial;
    if (customEventInterstitial == null) {
      paramMediationInterstitialListener.onAdFailedToLoad(this, e);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventInterstitial = this.c;
    customEventInterstitial.getClass();
    customEventInterstitial.requestInterstitialAd(paramContext, (CustomEventInterstitialListener)new a(this, this, paramMediationInterstitialListener), paramBundle1.getString("parameter"), paramMediationAdRequest, paramBundle2);
  }
  
  public void requestNativeAd(Context paramContext, MediationNativeListener paramMediationNativeListener, Bundle paramBundle1, NativeMediationAdRequest paramNativeMediationAdRequest, Bundle paramBundle2) {
    CustomEventNative customEventNative1;
    Bundle bundle;
    CustomEventNative customEventNative2 = (CustomEventNative)a(CustomEventNative.class, paramBundle1.getString("class_name"));
    this.d = customEventNative2;
    if (customEventNative2 == null) {
      paramMediationNativeListener.onAdFailedToLoad(this, e);
      return;
    } 
    customEventNative2 = null;
    if (paramBundle2 == null) {
      customEventNative1 = customEventNative2;
    } else {
      bundle = customEventNative1.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventNative2 = this.d;
    customEventNative2.getClass();
    customEventNative2.requestNativeAd(paramContext, (CustomEventNativeListener)new u(this, paramMediationNativeListener, 0), paramBundle1.getString("parameter"), paramNativeMediationAdRequest, bundle);
  }
  
  public void showInterstitial() {
    CustomEventInterstitial customEventInterstitial = this.c;
    if (customEventInterstitial != null)
      customEventInterstitial.showInterstitial(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */