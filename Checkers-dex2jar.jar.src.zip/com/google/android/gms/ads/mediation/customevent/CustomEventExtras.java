package com.google.android.gms.ads.mediation.customevent;

import java.util.HashMap;

@Deprecated
public final class CustomEventExtras {
  public final HashMap a = new HashMap<Object, Object>();
  
  public Object getExtra(String paramString) {
    return this.a.get(paramString);
  }
  
  public void setExtra(String paramString, Object paramObject) {
    this.a.put(paramString, paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */