package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.formats.NativeAd;
import java.util.List;
import java.util.Map;

public abstract class UnifiedNativeAdMapper {
  public String a;
  
  public List b;
  
  public String c;
  
  public NativeAd.Image d;
  
  public String e;
  
  public String f;
  
  public Double g;
  
  public String h;
  
  public String i;
  
  public VideoController j;
  
  public boolean k;
  
  public View l;
  
  public View m;
  
  public Object n;
  
  public Bundle o = new Bundle();
  
  public boolean p;
  
  public boolean q;
  
  public float r;
  
  public View getAdChoicesContent() {
    return this.l;
  }
  
  public final String getAdvertiser() {
    return this.f;
  }
  
  public final String getBody() {
    return this.c;
  }
  
  public final String getCallToAction() {
    return this.e;
  }
  
  public float getCurrentTime() {
    return 0.0F;
  }
  
  public float getDuration() {
    return 0.0F;
  }
  
  public final Bundle getExtras() {
    return this.o;
  }
  
  public final String getHeadline() {
    return this.a;
  }
  
  public final NativeAd.Image getIcon() {
    return this.d;
  }
  
  public final List<NativeAd.Image> getImages() {
    return this.b;
  }
  
  public float getMediaContentAspectRatio() {
    return this.r;
  }
  
  public final boolean getOverrideClickHandling() {
    return this.q;
  }
  
  public final boolean getOverrideImpressionRecording() {
    return this.p;
  }
  
  public final String getPrice() {
    return this.i;
  }
  
  public final Double getStarRating() {
    return this.g;
  }
  
  public final String getStore() {
    return this.h;
  }
  
  public void handleClick(View paramView) {}
  
  public boolean hasVideoContent() {
    return this.k;
  }
  
  public void recordImpression() {}
  
  public void setAdChoicesContent(View paramView) {
    this.l = paramView;
  }
  
  public final void setAdvertiser(String paramString) {
    this.f = paramString;
  }
  
  public final void setBody(String paramString) {
    this.c = paramString;
  }
  
  public final void setCallToAction(String paramString) {
    this.e = paramString;
  }
  
  public final void setExtras(Bundle paramBundle) {
    this.o = paramBundle;
  }
  
  public void setHasVideoContent(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public final void setHeadline(String paramString) {
    this.a = paramString;
  }
  
  public final void setIcon(NativeAd.Image paramImage) {
    this.d = paramImage;
  }
  
  public final void setImages(List<NativeAd.Image> paramList) {
    this.b = paramList;
  }
  
  public void setMediaContentAspectRatio(float paramFloat) {
    this.r = paramFloat;
  }
  
  public void setMediaView(View paramView) {
    this.m = paramView;
  }
  
  public final void setOverrideClickHandling(boolean paramBoolean) {
    this.q = paramBoolean;
  }
  
  public final void setOverrideImpressionRecording(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public final void setPrice(String paramString) {
    this.i = paramString;
  }
  
  public final void setStarRating(Double paramDouble) {
    this.g = paramDouble;
  }
  
  public final void setStore(String paramString) {
    this.h = paramString;
  }
  
  public void trackViews(View paramView, Map<String, View> paramMap1, Map<String, View> paramMap2) {}
  
  public void untrackView(View paramView) {}
  
  public final View zza() {
    return this.m;
  }
  
  public final VideoController zzb() {
    return this.j;
  }
  
  public final Object zzc() {
    return this.n;
  }
  
  public final void zzd(Object paramObject) {
    this.n = paramObject;
  }
  
  public final void zze(VideoController paramVideoController) {
    this.j = paramVideoController;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\UnifiedNativeAdMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */