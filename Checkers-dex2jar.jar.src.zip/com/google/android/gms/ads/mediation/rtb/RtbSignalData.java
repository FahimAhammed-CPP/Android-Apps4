package com.google.android.gms.ads.mediation.rtb;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import java.util.List;

public class RtbSignalData {
  public final Context a;
  
  public final List b;
  
  public final Bundle c;
  
  public final AdSize d;
  
  public RtbSignalData(Context paramContext, List<MediationConfiguration> paramList, Bundle paramBundle, AdSize paramAdSize) {
    this.a = paramContext;
    this.b = paramList;
    this.c = paramBundle;
    this.d = paramAdSize;
  }
  
  public AdSize getAdSize() {
    return this.d;
  }
  
  @Deprecated
  public MediationConfiguration getConfiguration() {
    List list = this.b;
    return (list != null && list.size() > 0) ? this.b.get(0) : null;
  }
  
  public List<MediationConfiguration> getConfigurations() {
    return this.b;
  }
  
  public Context getContext() {
    return this.a;
  }
  
  public Bundle getNetworkExtras() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\rtb\RtbSignalData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */