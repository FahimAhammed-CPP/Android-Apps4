package com.google.android.gms.ads.mediation;

@Deprecated
public interface MediationAdapter extends MediationExtrasReceiver {
  void onDestroy();
  
  void onPause();
  
  void onResume();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */