package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class MediationInterstitialAdConfiguration extends MediationAdConfiguration {
  public MediationInterstitialAdConfiguration(Context paramContext, String paramString1, Bundle paramBundle1, Bundle paramBundle2, boolean paramBoolean, Location paramLocation, int paramInt1, int paramInt2, String paramString2, String paramString3) {
    super(paramContext, paramString1, paramBundle1, paramBundle2, paramBoolean, paramLocation, paramInt1, paramInt2, paramString2, paramString3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationInterstitialAdConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */