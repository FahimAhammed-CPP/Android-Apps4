package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import com.google.android.gms.ads.AdFormat;

public class MediationConfiguration {
  public static final String CUSTOM_EVENT_SERVER_PARAMETER_FIELD = "parameter";
  
  public final AdFormat a;
  
  public final Bundle b;
  
  public MediationConfiguration(AdFormat paramAdFormat, Bundle paramBundle) {
    this.a = paramAdFormat;
    this.b = paramBundle;
  }
  
  public AdFormat getFormat() {
    return this.a;
  }
  
  public Bundle getServerParameters() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */