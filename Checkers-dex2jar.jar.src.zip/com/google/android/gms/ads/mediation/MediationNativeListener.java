package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;

@Deprecated
public interface MediationNativeListener {
  void onAdClicked(MediationNativeAdapter paramMediationNativeAdapter);
  
  void onAdClosed(MediationNativeAdapter paramMediationNativeAdapter);
  
  @Deprecated
  void onAdFailedToLoad(MediationNativeAdapter paramMediationNativeAdapter, int paramInt);
  
  void onAdFailedToLoad(MediationNativeAdapter paramMediationNativeAdapter, AdError paramAdError);
  
  void onAdImpression(MediationNativeAdapter paramMediationNativeAdapter);
  
  void onAdLeftApplication(MediationNativeAdapter paramMediationNativeAdapter);
  
  void onAdLoaded(MediationNativeAdapter paramMediationNativeAdapter, UnifiedNativeAdMapper paramUnifiedNativeAdMapper);
  
  void onAdOpened(MediationNativeAdapter paramMediationNativeAdapter);
  
  void onVideoEnd(MediationNativeAdapter paramMediationNativeAdapter);
  
  void zzc(MediationNativeAdapter paramMediationNativeAdapter, NativeCustomTemplateAd paramNativeCustomTemplateAd);
  
  void zze(MediationNativeAdapter paramMediationNativeAdapter, NativeCustomTemplateAd paramNativeCustomTemplateAd, String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationNativeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */