package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.AdError;

@Deprecated
public interface MediationBannerListener {
  void onAdClicked(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdClosed(MediationBannerAdapter paramMediationBannerAdapter);
  
  @Deprecated
  void onAdFailedToLoad(MediationBannerAdapter paramMediationBannerAdapter, int paramInt);
  
  void onAdFailedToLoad(MediationBannerAdapter paramMediationBannerAdapter, AdError paramAdError);
  
  void onAdLeftApplication(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdLoaded(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdOpened(MediationBannerAdapter paramMediationBannerAdapter);
  
  void zzd(MediationBannerAdapter paramMediationBannerAdapter, String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationBannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */