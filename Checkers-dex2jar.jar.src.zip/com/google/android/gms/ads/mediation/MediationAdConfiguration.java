package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class MediationAdConfiguration {
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE = 0;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE = 1;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_UNSPECIFIED = -1;
  
  public final String a;
  
  public final Bundle b;
  
  public final Bundle c;
  
  public final Context d;
  
  public final boolean e;
  
  public final int f;
  
  public final int g;
  
  public final String h;
  
  public final String i;
  
  public MediationAdConfiguration(Context paramContext, String paramString1, Bundle paramBundle1, Bundle paramBundle2, boolean paramBoolean, Location paramLocation, int paramInt1, int paramInt2, String paramString2, String paramString3) {
    this.a = paramString1;
    this.b = paramBundle1;
    this.c = paramBundle2;
    this.d = paramContext;
    this.e = paramBoolean;
    this.f = paramInt1;
    this.g = paramInt2;
    this.h = paramString2;
    this.i = paramString3;
  }
  
  public String getBidResponse() {
    return this.a;
  }
  
  public Context getContext() {
    return this.d;
  }
  
  public String getMaxAdContentRating() {
    return this.h;
  }
  
  public Bundle getMediationExtras() {
    return this.c;
  }
  
  public Bundle getServerParameters() {
    return this.b;
  }
  
  public String getWatermark() {
    return this.i;
  }
  
  public boolean isTestRequest() {
    return this.e;
  }
  
  public int taggedForChildDirectedTreatment() {
    return this.f;
  }
  
  public int taggedForUnderAgeTreatment() {
    return this.g;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TagForChildDirectedTreatment {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationAdConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */