package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import w0.b;
import w0.c;

public abstract class zzds extends b implements zzdt {
  public zzds() {
    super("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            boolean bool = false;
            if (paramInt != 5)
              return false; 
            ClassLoader classLoader = c.a;
            if (paramParcel1.readInt() != 0)
              bool = true; 
            c.b(paramParcel1);
            zzf(bool);
          } else {
            zze();
          } 
        } else {
          zzg();
        } 
      } else {
        zzh();
      } 
    } else {
      zzi();
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */