package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public final class zzm {
  public Bundle a = new Bundle();
  
  public List b = new ArrayList();
  
  public boolean c = false;
  
  public int d = -1;
  
  public final Bundle e = new Bundle();
  
  public final Bundle f = new Bundle();
  
  public final ArrayList g = new ArrayList();
  
  public int h = -1;
  
  public String i = null;
  
  public final ArrayList j = new ArrayList();
  
  public int k = 60000;
  
  public final zzl zza() {
    return new zzl(8, -1L, this.a, -1, this.b, this.c, this.d, false, null, null, null, null, this.e, this.f, this.g, null, null, false, null, this.h, this.i, this.j, this.k, null);
  }
  
  public final zzm zzb(Bundle paramBundle) {
    this.a = paramBundle;
    return this;
  }
  
  public final zzm zzc(int paramInt) {
    this.k = paramInt;
    return this;
  }
  
  public final zzm zzd(boolean paramBoolean) {
    this.c = paramBoolean;
    return this;
  }
  
  public final zzm zze(List paramList) {
    this.b = paramList;
    return this;
  }
  
  public final zzm zzf(String paramString) {
    this.i = paramString;
    return this;
  }
  
  public final zzm zzg(int paramInt) {
    this.d = paramInt;
    return this;
  }
  
  public final zzm zzh(int paramInt) {
    this.h = paramInt;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */