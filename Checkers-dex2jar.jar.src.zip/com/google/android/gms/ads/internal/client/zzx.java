package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzx implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int j = a.m(paramParcel);
    int i;
    for (i = 0; paramParcel.dataPosition() < j; i = a.i(paramParcel, k)) {
      int k = paramParcel.readInt();
      if ((char)k != '\002') {
        a.l(paramParcel, k);
        continue;
      } 
    } 
    a.f(paramParcel, j);
    return new zzw(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */