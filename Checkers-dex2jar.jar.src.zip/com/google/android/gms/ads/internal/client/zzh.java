package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdLoadCallback;

public final class zzh extends zzbj {
  public final AdLoadCallback a;
  
  public final Object b;
  
  public zzh(AdLoadCallback paramAdLoadCallback, Object paramObject) {
    this.a = paramAdLoadCallback;
    this.b = paramObject;
  }
  
  public final void zzb(zze paramzze) {
    AdLoadCallback adLoadCallback = this.a;
    if (adLoadCallback != null)
      adLoadCallback.onAdFailedToLoad(paramzze.zzb()); 
  }
  
  public final void zzc() {
    AdLoadCallback adLoadCallback = this.a;
    if (adLoadCallback != null) {
      Object object = this.b;
      if (object != null)
        adLoadCallback.onAdLoaded(object); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */