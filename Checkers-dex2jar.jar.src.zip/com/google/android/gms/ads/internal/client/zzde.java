package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import w0.a;
import w0.c;

public final class zzde extends a implements zzdg {
  public zzde(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOnPaidEventListener");
  }
  
  public final void zze(zzs paramzzs) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzzs);
    b1(parcel, 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzde.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */