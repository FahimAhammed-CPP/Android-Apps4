package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.b;

public abstract class zzcr extends b implements zzcs {
  public zzcr() {
    super("com.google.android.gms.ads.internal.client.IMuteThisAdListener");
  }
  
  public static zzcs zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMuteThisAdListener");
    return (iInterface instanceof zzcs) ? (zzcs)iInterface : new zzcq(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt == 1) {
      zze();
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */