package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import u0.a;
import w0.a;
import w0.c;
import w0.w3;

public final class zzdk extends a {
  public zzdk(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOutOfContextTesterCreator");
  }
  
  public final zzdj zze(a parama, w3 paramw3, int paramInt) {
    zzdj zzdj;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 1);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOutOfContextTester");
      if (iInterface instanceof zzdj) {
        zzdj = (zzdj)iInterface;
      } else {
        zzdj = new zzdh((IBinder)zzdj);
      } 
    } 
    parcel1.recycle();
    return zzdj;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */