package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.text.TextUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzem {
  public final String a;
  
  public final Bundle b;
  
  public final String c;
  
  public zzem(String paramString1, Bundle paramBundle, String paramString2) {
    this.a = paramString1;
    this.b = paramBundle;
    this.c = paramString2;
  }
  
  public final Bundle zza() {
    return this.b;
  }
  
  public final String zzb() {
    return this.a;
  }
  
  public final String zzd() {
    if (TextUtils.isEmpty(this.c))
      return ""; 
    try {
      return (new JSONObject(this.c)).optString("request_id", "");
    } catch (JSONException jSONException) {
      return "";
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */