package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import u0.a;
import w0.a6;
import w0.a8;
import w0.b;
import w0.c;
import w0.d1;
import w0.g7;
import w0.t5;
import w0.u2;
import w0.v2;
import w0.v3;
import w0.w3;
import w0.w6;
import w0.x0;
import w0.x2;

public abstract class zzcd extends b implements zzce {
  public zzcd() {
    super("com.google.android.gms.ads.internal.client.IClientApi");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    zzdj zzdj;
    x2 x2;
    t5 t5;
    a8 a8;
    zzbu zzbu3;
    g7 g7;
    d1 d1;
    zzbu zzbu2;
    zzco zzco;
    a6 a6;
    w6 w6;
    x0 x0;
    zzbq zzbq;
    zzbu zzbu1;
    u2 u2;
    a a1;
    w3 w33;
    a a5;
    w3 w32;
    zzq zzq3;
    String str2;
    a a4;
    zzq zzq2;
    w3 w31;
    a a3;
    String str1;
    zzq zzq1;
    w3 w36;
    String str5;
    w3 w35;
    a a7;
    String str4;
    w3 w34;
    String str3;
    IBinder iBinder;
    w3 w37;
    a a2 = null;
    switch (paramInt) {
      default:
        return false;
      case 17:
        a2 = a.a.a1(paramParcel1.readStrongBinder());
        w33 = v3.a1(paramParcel1.readStrongBinder());
        paramInt = paramParcel1.readInt();
        c.b(paramParcel1);
        zzdj = zzh(a2, w33, paramInt);
        break;
      case 16:
        a5 = a.a.a1(zzdj.readStrongBinder());
        w36 = v3.a1(zzdj.readStrongBinder());
        paramInt = zzdj.readInt();
        iBinder = zzdj.readStrongBinder();
        if (iBinder != null) {
          IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.h5.client.IH5AdsEventListener");
          if (iInterface instanceof v2) {
            v2 v2 = (v2)iInterface;
          } else {
            u2 = new u2(iBinder);
          } 
        } 
        c.b((Parcel)zzdj);
        x2 = zzk(a5, w36, paramInt, (v2)u2);
        break;
      case 15:
        a1 = a.a.a1(x2.readStrongBinder());
        w32 = v3.a1(x2.readStrongBinder());
        paramInt = x2.readInt();
        c.b((Parcel)x2);
        t5 = zzl(a1, w32, paramInt);
        break;
      case 14:
        a1 = a.a.a1(t5.readStrongBinder());
        w32 = v3.a1(t5.readStrongBinder());
        paramInt = t5.readInt();
        c.b((Parcel)t5);
        a8 = zzp(a1, w32, paramInt);
        break;
      case 13:
        a1 = a.a.a1(a8.readStrongBinder());
        zzq3 = (zzq)c.a((Parcel)a8, zzq.CREATOR);
        str5 = a8.readString();
        w37 = v3.a1(a8.readStrongBinder());
        paramInt = a8.readInt();
        c.b((Parcel)a8);
        zzbu3 = zzc(a1, zzq3, str5, w37, paramInt);
        break;
      case 12:
        a1 = a.a.a1(zzbu3.readStrongBinder());
        str2 = zzbu3.readString();
        w35 = v3.a1(zzbu3.readStrongBinder());
        paramInt = zzbu3.readInt();
        c.b((Parcel)zzbu3);
        g7 = zzo(a1, str2, w35, paramInt);
        break;
      case 11:
        a1 = a.a.a1(g7.readStrongBinder());
        a4 = a.a.a1(g7.readStrongBinder());
        a7 = a.a.a1(g7.readStrongBinder());
        c.b((Parcel)g7);
        d1 = zzj(a1, a4, a7);
        break;
      case 10:
        a1 = a.a.a1(d1.readStrongBinder());
        zzq2 = (zzq)c.a((Parcel)d1, zzq.CREATOR);
        str4 = d1.readString();
        paramInt = d1.readInt();
        c.b((Parcel)d1);
        zzbu2 = zzf(a1, zzq2, str4, paramInt);
        break;
      case 9:
        a1 = a.a.a1(zzbu2.readStrongBinder());
        paramInt = zzbu2.readInt();
        c.b((Parcel)zzbu2);
        zzco = zzg(a1, paramInt);
        break;
      case 8:
        a1 = a.a.a1(zzco.readStrongBinder());
        c.b((Parcel)zzco);
        a6 = zzm(a1);
        break;
      case 6:
        a1 = a.a.a1(a6.readStrongBinder());
        w31 = v3.a1(a6.readStrongBinder());
        paramInt = a6.readInt();
        c.b((Parcel)a6);
        w6 = zzn(a1, w31, paramInt);
        break;
      case 5:
        a1 = a.a.a1(w6.readStrongBinder());
        a3 = a.a.a1(w6.readStrongBinder());
        c.b((Parcel)w6);
        x0 = zzi(a1, a3);
        break;
      case 4:
      case 7:
        a.a.a1(x0.readStrongBinder());
        c.b((Parcel)x0);
        paramParcel2.writeNoException();
        c.e(paramParcel2, null);
        return true;
      case 3:
        a1 = a.a.a1(x0.readStrongBinder());
        str1 = x0.readString();
        w34 = v3.a1(x0.readStrongBinder());
        paramInt = x0.readInt();
        c.b((Parcel)x0);
        zzbq = zzb(a1, str1, w34, paramInt);
        break;
      case 2:
        a1 = a.a.a1(zzbq.readStrongBinder());
        zzq1 = (zzq)c.a((Parcel)zzbq, zzq.CREATOR);
        str3 = zzbq.readString();
        w37 = v3.a1(zzbq.readStrongBinder());
        paramInt = zzbq.readInt();
        c.b((Parcel)zzbq);
        zzbu1 = zze(a1, zzq1, str3, w37, paramInt);
        break;
      case 1:
        a1 = a.a.a1(zzbu1.readStrongBinder());
        zzq1 = (zzq)c.a((Parcel)zzbu1, zzq.CREATOR);
        str3 = zzbu1.readString();
        w37 = v3.a1(zzbu1.readStrongBinder());
        paramInt = zzbu1.readInt();
        c.b((Parcel)zzbu1);
        zzbu1 = zzd(a1, zzq1, str3, w37, paramInt);
        break;
    } 
    paramParcel2.writeNoException();
    c.e(paramParcel2, zzbu1);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */