package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.b;

public abstract class zzdc extends b implements zzdd {
  public zzdc() {
    super("com.google.android.gms.ads.internal.client.IOnAdMetadataChangedListener");
  }
  
  public static zzdd zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOnAdMetadataChangedListener");
    return (iInterface instanceof zzdd) ? (zzdd)iInterface : new zzdb(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt == 1) {
      zze();
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */