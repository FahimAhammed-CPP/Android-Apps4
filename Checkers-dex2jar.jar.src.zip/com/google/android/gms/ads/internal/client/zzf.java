package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzf implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    String str1;
    zze zze;
    String str2;
    int j = a.m(paramParcel);
    IBinder iBinder4 = null;
    IBinder iBinder1 = iBinder4;
    IBinder iBinder2 = iBinder1;
    IBinder iBinder3 = iBinder2;
    int i;
    for (i = 0; paramParcel.dataPosition() < j; i = a.i(paramParcel, k)) {
      int k = paramParcel.readInt();
      char c = (char)k;
      if (c != '\001') {
        if (c != '\002') {
          if (c != '\003') {
            if (c != '\004') {
              if (c != '\005') {
                a.l(paramParcel, k);
                continue;
              } 
              iBinder3 = a.h(paramParcel, k);
              continue;
            } 
            zze = (zze)a.b(paramParcel, k, zze.CREATOR);
            continue;
          } 
          str1 = a.c(paramParcel, k);
          continue;
        } 
        str2 = a.c(paramParcel, k);
        continue;
      } 
    } 
    a.f(paramParcel, j);
    return new zze(i, str2, str1, zze, iBinder3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */