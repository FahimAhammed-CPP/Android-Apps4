package com.google.android.gms.ads.internal.client;

import android.os.IInterface;

public interface zzbe extends IInterface {
  void zzb();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */