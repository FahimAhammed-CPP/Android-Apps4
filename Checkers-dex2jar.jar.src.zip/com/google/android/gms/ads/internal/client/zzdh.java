package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import u0.a;
import w0.a;
import w0.c;

public final class zzdh extends a implements zzdj {
  public zzdh(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOutOfContextTester");
  }
  
  public final void zze(String paramString, a parama1, a parama2) {
    Parcel parcel = Z0();
    parcel.writeString(paramString);
    c.e(parcel, (IInterface)parama1);
    c.e(parcel, (IInterface)parama2);
    b1(parcel, 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */