package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;
import w0.a;
import w0.c;

public final class zzdl extends a implements zzdn {
  public zzdl(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IResponseInfo");
  }
  
  public final Bundle zze() {
    Parcel parcel = a1(Z0(), 5);
    Bundle bundle = (Bundle)c.a(parcel, Bundle.CREATOR);
    parcel.recycle();
    return bundle;
  }
  
  public final zzu zzf() {
    Parcel parcel = a1(Z0(), 4);
    zzu zzu = (zzu)c.a(parcel, zzu.CREATOR);
    parcel.recycle();
    return zzu;
  }
  
  public final String zzg() {
    Parcel parcel = a1(Z0(), 1);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final String zzh() {
    Parcel parcel = a1(Z0(), 6);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final String zzi() {
    Parcel parcel = a1(Z0(), 2);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final List zzj() {
    Parcel parcel = a1(Z0(), 3);
    ArrayList arrayList = parcel.createTypedArrayList(zzu.CREATOR);
    parcel.recycle();
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */