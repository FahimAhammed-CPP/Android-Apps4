package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzblw;
import com.google.android.gms.internal.ads.zzbsi;
import w0.b;
import w0.c;
import w0.k1;
import w0.l1;
import w0.m1;
import w0.n1;
import w0.n3;
import w0.o1;
import w0.o3;
import w0.q1;
import w0.r1;
import w0.t1;
import w0.u1;
import w0.w1;
import w0.x1;
import w0.z1;

public abstract class zzbp extends b implements zzbq {
  public zzbp() {
    super("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    n3 n3;
    zzbsi zzbsi;
    IBinder iBinder7;
    x1 x1;
    PublisherAdViewOptions publisherAdViewOptions;
    IBinder iBinder6;
    u1 u1;
    IBinder iBinder5;
    zzcf zzcf;
    zzblw zzblw;
    IBinder iBinder4;
    r1 r1;
    IBinder iBinder3;
    m1 m1;
    IBinder iBinder2;
    k1 k1;
    IBinder iBinder1;
    IInterface iInterface;
    zzq zzq;
    o1 o1;
    String str;
    IBinder iBinder9 = null;
    IBinder iBinder10 = null;
    IBinder iBinder11 = null;
    IBinder iBinder8 = null;
    IBinder iBinder12 = null;
    IBinder iBinder13 = null;
    IBinder iBinder14 = null;
    AdManagerAdViewOptions adManagerAdViewOptions = null;
    switch (paramInt) {
      default:
        return false;
      case 15:
        adManagerAdViewOptions = (AdManagerAdViewOptions)c.a(paramParcel1, AdManagerAdViewOptions.CREATOR);
        c.b(paramParcel1);
        zzm(adManagerAdViewOptions);
        paramParcel2.writeNoException();
        return true;
      case 14:
        iBinder8 = paramParcel1.readStrongBinder();
        if (iBinder8 != null) {
          iInterface = iBinder8.queryLocalInterface("com.google.android.gms.ads.internal.instream.client.IInstreamAdLoadCallback");
          if (iInterface instanceof o3) {
            o3 o3 = (o3)iInterface;
          } else {
            n3 = new n3(iBinder8);
          } 
        } 
        c.b(paramParcel1);
        zzi((o3)n3);
        paramParcel2.writeNoException();
        return true;
      case 13:
        zzbsi = (zzbsi)c.a(paramParcel1, zzbsi.CREATOR);
        c.b(paramParcel1);
        zzn(zzbsi);
        paramParcel2.writeNoException();
        return true;
      case 10:
        iBinder7 = paramParcel1.readStrongBinder();
        if (iBinder7 == null) {
          iBinder7 = iBinder9;
        } else {
          z1 z1;
          IInterface iInterface1 = iBinder7.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnUnifiedNativeAdLoadedListener");
          if (iInterface1 instanceof z1) {
            z1 = (z1)iInterface1;
          } else {
            x1 = new x1((IBinder)z1);
          } 
        } 
        c.b(paramParcel1);
        zzk((z1)x1);
        paramParcel2.writeNoException();
        return true;
      case 9:
        publisherAdViewOptions = (PublisherAdViewOptions)c.a(paramParcel1, PublisherAdViewOptions.CREATOR);
        c.b(paramParcel1);
        zzp(publisherAdViewOptions);
        paramParcel2.writeNoException();
        return true;
      case 8:
        iBinder6 = paramParcel1.readStrongBinder();
        if (iBinder6 == null) {
          iBinder6 = iBinder10;
        } else {
          w1 w1;
          IInterface iInterface1 = iBinder6.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnPublisherAdViewLoadedListener");
          if (iInterface1 instanceof w1) {
            w1 = (w1)iInterface1;
          } else {
            u1 = new u1((IBinder)w1);
          } 
        } 
        zzq = (zzq)c.a(paramParcel1, zzq.CREATOR);
        c.b(paramParcel1);
        zzj((w1)u1, zzq);
        paramParcel2.writeNoException();
        return true;
      case 7:
        iBinder5 = paramParcel1.readStrongBinder();
        if (iBinder5 == null) {
          iBinder5 = iBinder11;
        } else {
          IInterface iInterface1 = iBinder5.queryLocalInterface("com.google.android.gms.ads.internal.client.ICorrelationIdProvider");
          if (iInterface1 instanceof zzcf) {
            zzcf = (zzcf)iInterface1;
          } else {
            zzcf = new zzcf((IBinder)zzcf);
          } 
        } 
        c.b(paramParcel1);
        zzq(zzcf);
        paramParcel2.writeNoException();
        return true;
      case 6:
        zzblw = (zzblw)c.a(paramParcel1, zzblw.CREATOR);
        c.b(paramParcel1);
        zzo(zzblw);
        paramParcel2.writeNoException();
        return true;
      case 5:
        str = paramParcel1.readString();
        iBinder4 = paramParcel1.readStrongBinder();
        if (iBinder4 == null) {
          iBinder4 = null;
        } else {
          t1 t1;
          IInterface iInterface1 = iBinder4.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnCustomTemplateAdLoadedListener");
          if (iInterface1 instanceof t1) {
            t1 = (t1)iInterface1;
          } else {
            r1 = new r1((IBinder)t1);
          } 
        } 
        iBinder10 = paramParcel1.readStrongBinder();
        if (iBinder10 != null) {
          IInterface iInterface1 = iBinder10.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnCustomClickListener");
          if (iInterface1 instanceof q1) {
            q1 q1 = (q1)iInterface1;
          } else {
            o1 = new o1(iBinder10);
          } 
        } 
        c.b(paramParcel1);
        zzh(str, (t1)r1, (q1)o1);
        paramParcel2.writeNoException();
        return true;
      case 4:
        iBinder3 = paramParcel1.readStrongBinder();
        if (iBinder3 == null) {
          iBinder3 = iBinder12;
        } else {
          n1 n1;
          IInterface iInterface1 = iBinder3.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnContentAdLoadedListener");
          if (iInterface1 instanceof n1) {
            n1 = (n1)iInterface1;
          } else {
            m1 = new m1((IBinder)n1);
          } 
        } 
        c.b(paramParcel1);
        zzg((n1)m1);
        paramParcel2.writeNoException();
        return true;
      case 3:
        iBinder2 = paramParcel1.readStrongBinder();
        if (iBinder2 == null) {
          iBinder2 = iBinder13;
        } else {
          l1 l1;
          IInterface iInterface1 = iBinder2.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IOnAppInstallAdLoadedListener");
          if (iInterface1 instanceof l1) {
            l1 = (l1)iInterface1;
          } else {
            k1 = new k1((IBinder)l1);
          } 
        } 
        c.b(paramParcel1);
        zzf((l1)k1);
        paramParcel2.writeNoException();
        return true;
      case 2:
        iBinder1 = paramParcel1.readStrongBinder();
        if (iBinder1 == null) {
          iBinder1 = iBinder14;
        } else {
          IInterface iInterface1 = iBinder1.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdListener");
          if (iInterface1 instanceof zzbh) {
            iInterface = iInterface1;
          } else {
            iInterface = new zzbf((IBinder)iInterface);
          } 
        } 
        c.b(paramParcel1);
        zzl((zzbh)iInterface);
        paramParcel2.writeNoException();
        return true;
      case 1:
        break;
    } 
    zzbn zzbn = zze();
    paramParcel2.writeNoException();
    c.e(paramParcel2, zzbn);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */