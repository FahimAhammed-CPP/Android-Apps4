package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import w0.a;
import w0.c;

public final class zzbl extends a implements zzbn {
  public zzbl(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoader");
  }
  
  public final String zze() {
    throw null;
  }
  
  public final String zzf() {
    throw null;
  }
  
  public final void zzg(zzl paramzzl) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzzl);
    b1(parcel, 1);
  }
  
  public final void zzh(zzl paramzzl, int paramInt) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzzl);
    parcel.writeInt(paramInt);
    b1(parcel, 5);
  }
  
  public final boolean zzi() {
    boolean bool;
    Parcel parcel = a1(Z0(), 3);
    ClassLoader classLoader = c.a;
    if (parcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */