package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;

public final class zzff extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzff> CREATOR = new zzfg();
  
  public final int zza;
  
  public final int zzb;
  
  public zzff(int paramInt1, int paramInt2) {
    this.zza = paramInt1;
    this.zzb = paramInt2;
  }
  
  public zzff(RequestConfiguration paramRequestConfiguration) {
    this.zza = paramRequestConfiguration.getTagForChildDirectedTreatment();
    this.zzb = paramRequestConfiguration.getTagForUnderAgeOfConsent();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.zza);
    b.g(paramParcel, 2, this.zzb);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzff.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */