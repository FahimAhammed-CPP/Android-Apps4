package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzd implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = a.m(paramParcel);
    String str2 = null;
    String str1 = null;
    while (paramParcel.dataPosition() < i) {
      int j = paramParcel.readInt();
      char c = (char)j;
      if (c != '\001') {
        if (c != '\002') {
          a.l(paramParcel, j);
          continue;
        } 
        str1 = a.c(paramParcel, j);
        continue;
      } 
      str2 = a.c(paramParcel, j);
    } 
    a.f(paramParcel, i);
    return new zzc(str2, str1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */