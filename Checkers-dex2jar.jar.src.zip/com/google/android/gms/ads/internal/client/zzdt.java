package com.google.android.gms.ads.internal.client;

import android.os.IInterface;

public interface zzdt extends IInterface {
  void zze();
  
  void zzf(boolean paramBoolean);
  
  void zzg();
  
  void zzh();
  
  void zzi();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */