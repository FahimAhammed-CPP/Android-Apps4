package com.google.android.gms.ads.internal.client;

import android.os.IInterface;

public interface zzcw extends IInterface {
  String zze();
  
  String zzf();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */