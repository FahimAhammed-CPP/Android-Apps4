package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import w0.a;

public final class zzcq extends a implements zzcs {
  public zzcq(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMuteThisAdListener");
  }
  
  public final void zze() {
    b1(Z0(), 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */