package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import w0.a;
import w0.c;
import w0.v3;
import w0.w3;

public final class zzcj extends a implements zzcl {
  public zzcj(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.ILiteSdkInfo");
  }
  
  public final w3 getAdapterCreator() {
    Parcel parcel = a1(Z0(), 2);
    w3 w3 = v3.a1(parcel.readStrongBinder());
    parcel.recycle();
    return w3;
  }
  
  public final zzen getLiteSdkVersion() {
    Parcel parcel = a1(Z0(), 1);
    zzen zzen = (zzen)c.a(parcel, zzen.CREATOR);
    parcel.recycle();
    return zzen;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */