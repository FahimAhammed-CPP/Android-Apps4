package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.FullScreenContentCallback;

public final class zzbb extends zzch {
  public final FullScreenContentCallback a;
  
  public zzbb(FullScreenContentCallback paramFullScreenContentCallback) {
    this.a = paramFullScreenContentCallback;
  }
  
  public final void zzb() {
    FullScreenContentCallback fullScreenContentCallback = this.a;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdClicked(); 
  }
  
  public final void zzc() {
    FullScreenContentCallback fullScreenContentCallback = this.a;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdDismissedFullScreenContent(); 
  }
  
  public final void zzd(zze paramzze) {
    FullScreenContentCallback fullScreenContentCallback = this.a;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdFailedToShowFullScreenContent(paramzze.zza()); 
  }
  
  public final void zze() {
    FullScreenContentCallback fullScreenContentCallback = this.a;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdImpression(); 
  }
  
  public final void zzf() {
    FullScreenContentCallback fullScreenContentCallback = this.a;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdShowedFullScreenContent(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */