package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzfi implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = a.m(paramParcel);
    String str;
    for (str = null; paramParcel.dataPosition() < i; str = a.c(paramParcel, j)) {
      int j = paramParcel.readInt();
      if ((char)j != '\017') {
        a.l(paramParcel, j);
        continue;
      } 
    } 
    a.f(paramParcel, i);
    return new zzfh(str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */