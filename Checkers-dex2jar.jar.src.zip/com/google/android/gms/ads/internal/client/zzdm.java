package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;
import w0.b;
import w0.c;

public abstract class zzdm extends b implements zzdn {
  public zzdm() {
    super("com.google.android.gms.ads.internal.client.IResponseInfo");
  }
  
  public static zzdn zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IResponseInfo");
    return (iInterface instanceof zzdn) ? (zzdn)iInterface : new zzdl(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    String str2;
    Bundle bundle;
    zzu zzu;
    List list;
    String str1;
    switch (paramInt) {
      default:
        return false;
      case 6:
        str2 = zzh();
        break;
      case 5:
        bundle = zze();
        paramParcel2.writeNoException();
        c.d(paramParcel2, (Parcelable)bundle);
        return true;
      case 4:
        zzu = zzf();
        paramParcel2.writeNoException();
        c.d(paramParcel2, (Parcelable)zzu);
        return true;
      case 3:
        list = zzj();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(list);
        return true;
      case 2:
        str1 = zzi();
        break;
      case 1:
        str1 = zzg();
        break;
    } 
    paramParcel2.writeNoException();
    paramParcel2.writeString(str1);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */