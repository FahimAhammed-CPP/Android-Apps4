package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.query.AdInfo;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import w0.i8;
import w0.w8;

public final class zzp {
  public static final zzp zza = new zzp();
  
  public final zzl zza(Context paramContext, zzdx paramzzdx) {
    long l;
    Date date = paramzzdx.zzo();
    if (date != null) {
      l = date.getTime();
    } else {
      l = -1L;
    } 
    String str2 = paramzzdx.zzl();
    int k = paramzzdx.zza();
    Set<?> set = paramzzdx.zzr();
    if (!set.isEmpty()) {
      List<?> list1 = Collections.unmodifiableList(new ArrayList(set));
    } else {
      set = null;
    } 
    boolean bool1 = paramzzdx.zzt(paramContext);
    Bundle bundle = paramzzdx.zzf(AdMobAdapter.class);
    AdInfo adInfo = paramzzdx.zzi();
    if (adInfo != null) {
      String str;
      QueryInfo queryInfo = adInfo.getQueryInfo();
      if (queryInfo != null) {
        str = (queryInfo.zza()).c;
      } else {
        str = "";
      } 
      zzc zzc = new zzc(paramzzdx.zzi().getAdString(), str);
    } else {
      adInfo = null;
    } 
    String str3 = paramzzdx.zzm();
    SearchAdRequest searchAdRequest = paramzzdx.zzj();
    if (searchAdRequest != null) {
      zzfh zzfh = new zzfh(searchAdRequest);
    } else {
      searchAdRequest = null;
    } 
    paramContext = paramContext.getApplicationContext();
    if (paramContext != null) {
      String str = paramContext.getPackageName();
      zzay.zzb();
      StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
      w8 w8 = i8.a;
      int m = 0;
      while (true) {
        int n = m + 1;
        if (n < arrayOfStackTraceElement.length) {
          StackTraceElement stackTraceElement = arrayOfStackTraceElement[m];
          String str4 = stackTraceElement.getClassName();
          if ("loadAd".equalsIgnoreCase(stackTraceElement.getMethodName()) && (i8.b.equalsIgnoreCase(str4) || i8.c.equalsIgnoreCase(str4) || i8.d.equalsIgnoreCase(str4) || i8.e.equalsIgnoreCase(str4) || i8.f.equalsIgnoreCase(str4) || i8.g.equalsIgnoreCase(str4))) {
            String str5 = arrayOfStackTraceElement[n].getClassName();
            break;
          } 
          m = n;
          continue;
        } 
        arrayOfStackTraceElement = null;
        break;
      } 
      if (str != null) {
        StringTokenizer stringTokenizer = new StringTokenizer(str, ".");
        StringBuilder stringBuilder = new StringBuilder();
        if (stringTokenizer.hasMoreElements()) {
          stringBuilder.append(stringTokenizer.nextToken());
          for (m = 2; m > 0 && stringTokenizer.hasMoreElements(); m--) {
            stringBuilder.append(".");
            stringBuilder.append(stringTokenizer.nextToken());
          } 
          str = stringBuilder.toString();
        } 
        if (arrayOfStackTraceElement != null && !arrayOfStackTraceElement.contains(str)) {
          boolean bool = paramzzdx.zzs();
          RequestConfiguration requestConfiguration1 = zzej.zzf().zzc();
          m = Math.max(paramzzdx.zzc(), requestConfiguration1.getTagForChildDirectedTreatment());
          int n = Math.max(-1, requestConfiguration1.getTagForUnderAgeOfConsent());
          String str4 = Collections.<String>max(Arrays.asList(new String[] { null, requestConfiguration1.getMaxAdContentRating() }, ), zzo.zza);
          List list1 = paramzzdx.zzp();
          return new zzl(8, l, bundle, k, (List)set, bool1, m, false, str3, (zzfh)searchAdRequest, null, str2, paramzzdx.zzg(), paramzzdx.zze(), Collections.unmodifiableList(new ArrayList(paramzzdx.zzq())), paramzzdx.zzn(), (String)arrayOfStackTraceElement, bool, (zzc)adInfo, n, str4, list1, paramzzdx.zzb(), paramzzdx.zzk());
        } 
      } 
      arrayOfStackTraceElement = null;
    } else {
      paramContext = null;
    } 
    boolean bool2 = paramzzdx.zzs();
    RequestConfiguration requestConfiguration = zzej.zzf().zzc();
    int i = Math.max(paramzzdx.zzc(), requestConfiguration.getTagForChildDirectedTreatment());
    int j = Math.max(-1, requestConfiguration.getTagForUnderAgeOfConsent());
    String str1 = Collections.<String>max(Arrays.asList(new String[] { null, requestConfiguration.getMaxAdContentRating() }, ), zzo.zza);
    List list = paramzzdx.zzp();
    return new zzl(8, l, bundle, k, (List)set, bool1, i, false, str3, (zzfh)searchAdRequest, null, str2, paramzzdx.zzg(), paramzzdx.zze(), Collections.unmodifiableList(new ArrayList(paramzzdx.zzq())), paramzzdx.zzn(), (String)paramContext, bool2, (zzc)adInfo, j, str1, list, paramzzdx.zzb(), paramzzdx.zzk());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */