package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzfg implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int k = a.m(paramParcel);
    int j = 0;
    int i = 0;
    while (paramParcel.dataPosition() < k) {
      int m = paramParcel.readInt();
      char c = (char)m;
      if (c != '\001') {
        if (c != '\002') {
          a.l(paramParcel, m);
          continue;
        } 
        i = a.i(paramParcel, m);
        continue;
      } 
      j = a.i(paramParcel, m);
    } 
    a.f(paramParcel, k);
    return new zzff(j, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */