package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONObject;
import t0.b;

@ParametersAreNonnullByDefault
public final class zzs extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzs> CREATOR = new zzt();
  
  public final int zza;
  
  public final int zzb;
  
  public final String zzc;
  
  public final long zzd;
  
  public zzs(int paramInt1, int paramInt2, String paramString, long paramLong) {
    this.zza = paramInt1;
    this.zzb = paramInt2;
    this.zzc = paramString;
    this.zzd = paramLong;
  }
  
  public static zzs zza(JSONObject paramJSONObject) {
    return new zzs(paramJSONObject.getInt("type_num"), paramJSONObject.getInt("precision_num"), paramJSONObject.getString("currency"), paramJSONObject.getLong("value"));
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.zza);
    b.g(paramParcel, 2, this.zzb);
    b.j(paramParcel, 3, this.zzc);
    b.h(paramParcel, 4, this.zzd);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */