package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.MuteThisAdReason;
import w0.l8;

public final class zzcx implements MuteThisAdReason {
  public final String a;
  
  public final zzcw b;
  
  public zzcx(zzcw paramzzcw) {
    this.b = paramzzcw;
    try {
      String str = paramzzcw.zze();
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      remoteException = null;
    } 
    this.a = (String)remoteException;
  }
  
  public final String getDescription() {
    return this.a;
  }
  
  public final String toString() {
    return this.a;
  }
  
  public final zzcw zza() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */