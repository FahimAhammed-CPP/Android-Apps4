package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import w0.b;
import w0.c;
import w0.w3;

public abstract class zzck extends b implements zzcl {
  public zzck() {
    super("com.google.android.gms.ads.internal.client.ILiteSdkInfo");
  }
  
  public static zzcl asInterface(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.ILiteSdkInfo");
    return (iInterface instanceof zzcl) ? (zzcl)iInterface : new zzcj(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt != 1) {
      if (paramInt != 2)
        return false; 
      w3 w3 = getAdapterCreator();
      paramParcel2.writeNoException();
      c.e(paramParcel2, (IInterface)w3);
      return true;
    } 
    zzen zzen = getLiteSdkVersion();
    paramParcel2.writeNoException();
    c.d(paramParcel2, (Parcelable)zzen);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */