package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.b;
import w0.c;

public abstract class zzca extends b implements zzcb {
  public zzca() {
    super("com.google.android.gms.ads.internal.client.IAppEventListener");
  }
  
  public static zzcb zzd(IBinder paramIBinder) {
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAppEventListener");
    return (iInterface instanceof zzcb) ? (zzcb)iInterface : new zzbz(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt == 1) {
      String str1 = paramParcel1.readString();
      String str2 = paramParcel1.readString();
      c.b(paramParcel1);
      zzc(str1, str2);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzca.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */