package com.google.android.gms.ads.internal.client;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import p0.d;
import t0.b;
import w0.m8;

public final class zzl extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzl> CREATOR = new zzn();
  
  public final int zza;
  
  @Deprecated
  public final long zzb;
  
  public final Bundle zzc;
  
  @Deprecated
  public final int zzd;
  
  public final List zze;
  
  public final boolean zzf;
  
  public final int zzg;
  
  public final boolean zzh;
  
  public final String zzi;
  
  public final zzfh zzj;
  
  public final Location zzk;
  
  public final String zzl;
  
  public final Bundle zzm;
  
  public final Bundle zzn;
  
  public final List zzo;
  
  public final String zzp;
  
  public final String zzq;
  
  @Deprecated
  public final boolean zzr;
  
  public final zzc zzs;
  
  public final int zzt;
  
  public final String zzu;
  
  public final List zzv;
  
  public final int zzw;
  
  public final String zzx;
  
  public zzl(int paramInt1, long paramLong, Bundle paramBundle1, int paramInt2, List paramList1, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, String paramString1, zzfh paramzzfh, Location paramLocation, String paramString2, Bundle paramBundle2, Bundle paramBundle3, List paramList2, String paramString3, String paramString4, boolean paramBoolean3, zzc paramzzc, int paramInt4, String paramString5, List paramList3, int paramInt5, String paramString6) {
    this.zza = paramInt1;
    this.zzb = paramLong;
    if (paramBundle1 == null)
      paramBundle1 = new Bundle(); 
    this.zzc = paramBundle1;
    this.zzd = paramInt2;
    this.zze = paramList1;
    this.zzf = paramBoolean1;
    this.zzg = paramInt3;
    this.zzh = paramBoolean2;
    this.zzi = paramString1;
    this.zzj = paramzzfh;
    this.zzk = paramLocation;
    this.zzl = paramString2;
    if (paramBundle2 == null)
      paramBundle2 = new Bundle(); 
    this.zzm = paramBundle2;
    this.zzn = paramBundle3;
    this.zzo = paramList2;
    this.zzp = paramString3;
    this.zzq = paramString4;
    this.zzr = paramBoolean3;
    this.zzs = paramzzc;
    this.zzt = paramInt4;
    this.zzu = paramString5;
    if (paramList3 == null)
      paramList3 = new ArrayList(); 
    this.zzv = paramList3;
    this.zzw = paramInt5;
    this.zzx = paramString6;
  }
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof zzl))
      return false; 
    paramObject = paramObject;
    return (this.zza == ((zzl)paramObject).zza && this.zzb == ((zzl)paramObject).zzb && m8.b(this.zzc, ((zzl)paramObject).zzc) && this.zzd == ((zzl)paramObject).zzd && d.a(this.zze, ((zzl)paramObject).zze) && this.zzf == ((zzl)paramObject).zzf && this.zzg == ((zzl)paramObject).zzg && this.zzh == ((zzl)paramObject).zzh && d.a(this.zzi, ((zzl)paramObject).zzi) && d.a(this.zzj, ((zzl)paramObject).zzj) && d.a(this.zzk, ((zzl)paramObject).zzk) && d.a(this.zzl, ((zzl)paramObject).zzl) && m8.b(this.zzm, ((zzl)paramObject).zzm) && m8.b(this.zzn, ((zzl)paramObject).zzn) && d.a(this.zzo, ((zzl)paramObject).zzo) && d.a(this.zzp, ((zzl)paramObject).zzp) && d.a(this.zzq, ((zzl)paramObject).zzq) && this.zzr == ((zzl)paramObject).zzr && this.zzt == ((zzl)paramObject).zzt && d.a(this.zzu, ((zzl)paramObject).zzu) && d.a(this.zzv, ((zzl)paramObject).zzv) && this.zzw == ((zzl)paramObject).zzw && d.a(this.zzx, ((zzl)paramObject).zzx));
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { 
          Integer.valueOf(this.zza), Long.valueOf(this.zzb), this.zzc, Integer.valueOf(this.zzd), this.zze, Boolean.valueOf(this.zzf), Integer.valueOf(this.zzg), Boolean.valueOf(this.zzh), this.zzi, this.zzj, 
          this.zzk, this.zzl, this.zzm, this.zzn, this.zzo, this.zzp, this.zzq, Boolean.valueOf(this.zzr), Integer.valueOf(this.zzt), this.zzu, 
          this.zzv, Integer.valueOf(this.zzw), this.zzx });
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.zza);
    b.h(paramParcel, 2, this.zzb);
    b.e(paramParcel, 3, this.zzc);
    b.g(paramParcel, 4, this.zzd);
    b.k(paramParcel, 5, this.zze);
    b.d(paramParcel, 6, this.zzf);
    b.g(paramParcel, 7, this.zzg);
    b.d(paramParcel, 8, this.zzh);
    b.j(paramParcel, 9, this.zzi);
    b.i(paramParcel, 10, (Parcelable)this.zzj, paramInt);
    b.i(paramParcel, 11, (Parcelable)this.zzk, paramInt);
    b.j(paramParcel, 12, this.zzl);
    b.e(paramParcel, 13, this.zzm);
    b.e(paramParcel, 14, this.zzn);
    b.k(paramParcel, 15, this.zzo);
    b.j(paramParcel, 16, this.zzp);
    b.j(paramParcel, 17, this.zzq);
    b.d(paramParcel, 18, this.zzr);
    b.i(paramParcel, 19, (Parcelable)this.zzs, paramInt);
    b.g(paramParcel, 20, this.zzt);
    b.j(paramParcel, 21, this.zzu);
    b.k(paramParcel, 22, this.zzv);
    b.g(paramParcel, 23, this.zzw);
    b.j(paramParcel, 24, this.zzx);
    b.v(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */