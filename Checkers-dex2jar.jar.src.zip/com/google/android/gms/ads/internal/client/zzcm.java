package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.ads.zzbrw;
import java.util.ArrayList;
import java.util.List;
import u0.a;
import w0.a;
import w0.c;
import w0.j3;
import w0.w3;

public final class zzcm extends a implements zzco {
  public zzcm(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
  }
  
  public final float zze() {
    Parcel parcel = a1(Z0(), 7);
    float f = parcel.readFloat();
    parcel.recycle();
    return f;
  }
  
  public final String zzf() {
    Parcel parcel = a1(Z0(), 9);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final List zzg() {
    Parcel parcel = a1(Z0(), 13);
    ArrayList arrayList = parcel.createTypedArrayList(zzbrw.CREATOR);
    parcel.recycle();
    return arrayList;
  }
  
  public final void zzh(String paramString) {
    Parcel parcel = Z0();
    parcel.writeString(paramString);
    b1(parcel, 10);
  }
  
  public final void zzi() {
    b1(Z0(), 15);
  }
  
  public final void zzj(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void zzk() {
    b1(Z0(), 1);
  }
  
  public final void zzl(String paramString, a parama) {
    Parcel parcel = Z0();
    parcel.writeString(null);
    c.e(parcel, (IInterface)parama);
    b1(parcel, 6);
  }
  
  public final void zzm(zzda paramzzda) {
    Parcel parcel = Z0();
    c.e(parcel, paramzzda);
    b1(parcel, 16);
  }
  
  public final void zzn(a parama, String paramString) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)parama);
    parcel.writeString(paramString);
    b1(parcel, 5);
  }
  
  public final void zzo(w3 paramw3) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)paramw3);
    b1(parcel, 11);
  }
  
  public final void zzp(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void zzq(float paramFloat) {
    Parcel parcel = Z0();
    parcel.writeFloat(paramFloat);
    b1(parcel, 2);
  }
  
  public final void zzr(String paramString) {
    throw null;
  }
  
  public final void zzs(j3 paramj3) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)paramj3);
    b1(parcel, 12);
  }
  
  public final void zzt(zzff paramzzff) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzzff);
    b1(parcel, 14);
  }
  
  public final boolean zzu() {
    boolean bool;
    Parcel parcel = a1(Z0(), 8);
    ClassLoader classLoader = c.a;
    if (parcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */