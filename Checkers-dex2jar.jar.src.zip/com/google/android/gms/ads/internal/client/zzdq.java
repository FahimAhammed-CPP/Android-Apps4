package com.google.android.gms.ads.internal.client;

import android.os.IInterface;

public interface zzdq extends IInterface {
  float zze();
  
  float zzf();
  
  float zzg();
  
  int zzh();
  
  zzdt zzi();
  
  void zzj(boolean paramBoolean);
  
  void zzk();
  
  void zzl();
  
  void zzm(zzdt paramzzdt);
  
  void zzn();
  
  boolean zzo();
  
  boolean zzp();
  
  boolean zzq();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */