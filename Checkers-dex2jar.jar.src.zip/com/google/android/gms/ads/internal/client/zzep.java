package com.google.android.gms.ads.internal.client;

import android.graphics.drawable.Drawable;
import android.os.RemoteException;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.VideoController;
import u0.a;
import u0.b;
import w0.i1;
import w0.l8;
import w0.r0;

public final class zzep implements MediaContent {
  public final r0 a;
  
  public final VideoController b = new VideoController();
  
  public final i1 c;
  
  public zzep(r0 paramr0, i1 parami1) {
    this.a = paramr0;
    this.c = parami1;
  }
  
  public final float getAspectRatio() {
    try {
      return this.a.zze();
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final float getCurrentTime() {
    try {
      return this.a.zzf();
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final float getDuration() {
    try {
      return this.a.zzg();
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final Drawable getMainImage() {
    try {
      a a = this.a.zzi();
      if (a != null)
        return (Drawable)b.b1(a); 
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
    } 
    return null;
  }
  
  public final VideoController getVideoController() {
    try {
      if (this.a.zzh() != null)
        this.b.zzb(this.a.zzh()); 
    } catch (RemoteException remoteException) {
      l8.d("Exception occurred while getting video controller", (Throwable)remoteException);
    } 
    return this.b;
  }
  
  public final boolean hasVideoContent() {
    try {
      return this.a.zzk();
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return false;
    } 
  }
  
  public final void setMainImage(Drawable paramDrawable) {
    try {
      this.a.d(new b(paramDrawable));
      return;
    } catch (RemoteException remoteException) {
      l8.d("", (Throwable)remoteException);
      return;
    } 
  }
  
  public final i1 zza() {
    return this.c;
  }
  
  public final r0 zzb() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzep.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */