package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzv implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    zze zze;
    Bundle bundle;
    int i = a.m(paramParcel);
    String str7 = null;
    String str1 = str7;
    String str2 = str1;
    String str3 = str2;
    String str4 = str3;
    String str5 = str4;
    String str6 = str5;
    long l = 0L;
    while (paramParcel.dataPosition() < i) {
      int j = paramParcel.readInt();
      switch ((char)j) {
        default:
          a.l(paramParcel, j);
          continue;
        case '\b':
          str6 = a.c(paramParcel, j);
          continue;
        case '\007':
          str5 = a.c(paramParcel, j);
          continue;
        case '\006':
          str4 = a.c(paramParcel, j);
          continue;
        case '\005':
          str3 = a.c(paramParcel, j);
          continue;
        case '\004':
          bundle = a.a(paramParcel, j);
          continue;
        case '\003':
          zze = (zze)a.b(paramParcel, j, zze.CREATOR);
          continue;
        case '\002':
          l = a.j(paramParcel, j);
          continue;
        case '\001':
          break;
      } 
      str7 = a.c(paramParcel, j);
    } 
    a.f(paramParcel, i);
    return new zzu(str7, l, zze, bundle, str3, str4, str5, str6);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */