package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import u0.a;
import u0.b;
import u0.c;
import w0.l8;

public final class zzeq extends c {
  public zzeq() {
    super("com.google.android.gms.ads.MobileAdsSettingManagerCreatorImpl");
  }
  
  public final zzco zza(Context paramContext) {
    try {
      zzco zzco;
      b b = new b(paramContext);
      IBinder iBinder = ((zzcp)b(paramContext)).zze((a)b, 223712000);
      if (iBinder == null)
        return null; 
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
      if (iInterface instanceof zzco) {
        zzco = (zzco)iInterface;
      } else {
        zzco = new zzcm((IBinder)zzco);
      } 
    } catch (RemoteException remoteException) {
      l8.g("Could not get remote MobileAdsSettingManager.", (Throwable)remoteException);
      return null;
    } catch (u0.c.a a) {}
    return (zzco)a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */