package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;

public class zzaz extends AdListener {
  public final Object a = new Object();
  
  public AdListener b;
  
  public final void onAdClicked() {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdClicked(); 
      return;
    } 
  }
  
  public final void onAdClosed() {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdClosed(); 
      return;
    } 
  }
  
  public void onAdFailedToLoad(LoadAdError paramLoadAdError) {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdFailedToLoad(paramLoadAdError); 
      return;
    } 
  }
  
  public final void onAdImpression() {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdImpression(); 
      return;
    } 
  }
  
  public void onAdLoaded() {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdLoaded(); 
      return;
    } 
  }
  
  public final void onAdOpened() {
    synchronized (this.a) {
      AdListener adListener = this.b;
      if (adListener != null)
        adListener.onAdOpened(); 
      return;
    } 
  }
  
  public final void zza(AdListener paramAdListener) {
    synchronized (this.a) {
      this.b = paramAdListener;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzaz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */