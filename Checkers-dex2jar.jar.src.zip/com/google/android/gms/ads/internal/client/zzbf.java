package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import w0.a;
import w0.c;

public final class zzbf extends a implements zzbh {
  public zzbf(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdListener");
  }
  
  public final void zzc() {
    b1(Z0(), 6);
  }
  
  public final void zzd() {
    b1(Z0(), 1);
  }
  
  public final void zze(int paramInt) {
    Parcel parcel = Z0();
    parcel.writeInt(paramInt);
    b1(parcel, 2);
  }
  
  public final void zzf(zze paramzze) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzze);
    b1(parcel, 8);
  }
  
  public final void zzg() {
    b1(Z0(), 7);
  }
  
  public final void zzh() {
    b1(Z0(), 3);
  }
  
  public final void zzi() {
    b1(Z0(), 4);
  }
  
  public final void zzj() {
    b1(Z0(), 5);
  }
  
  public final void zzk() {
    b1(Z0(), 9);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */