package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import w0.a;
import w0.c;

public final class zzbi extends a implements zzbk {
  public zzbi(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoadCallback");
  }
  
  public final void zzb(zze paramzze) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzze);
    b1(parcel, 2);
  }
  
  public final void zzc() {
    b1(Z0(), 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */