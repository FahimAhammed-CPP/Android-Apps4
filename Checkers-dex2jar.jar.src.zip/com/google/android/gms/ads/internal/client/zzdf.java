package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.b;
import w0.c;

public abstract class zzdf extends b implements zzdg {
  public zzdf() {
    super("com.google.android.gms.ads.internal.client.IOnPaidEventListener");
  }
  
  public static zzdg zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOnPaidEventListener");
    return (iInterface instanceof zzdg) ? (zzdg)iInterface : new zzde(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt == 1) {
      zzs zzs = (zzs)c.a(paramParcel1, zzs.CREATOR);
      c.b(paramParcel1);
      zze(zzs);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */