package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzfm implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = a.m(paramParcel);
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    while (paramParcel.dataPosition() < i) {
      int j = paramParcel.readInt();
      char c = (char)j;
      if (c != '\002') {
        if (c != '\003') {
          if (c != '\004') {
            a.l(paramParcel, j);
            continue;
          } 
          bool1 = a.g(paramParcel, j);
          continue;
        } 
        bool2 = a.g(paramParcel, j);
        continue;
      } 
      bool3 = a.g(paramParcel, j);
    } 
    a.f(paramParcel, i);
    return new zzfl(bool3, bool2, bool1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */