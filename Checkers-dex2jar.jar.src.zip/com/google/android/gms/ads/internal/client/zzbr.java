package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import u0.a;
import w0.a;
import w0.c;
import w0.w3;

public final class zzbr extends a {
  public zzbr(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoaderBuilderCreator");
  }
  
  public final IBinder zze(a parama, String paramString, w3 paramw3, int paramInt) {
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 1);
    IBinder iBinder = parcel1.readStrongBinder();
    parcel1.recycle();
    return iBinder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */