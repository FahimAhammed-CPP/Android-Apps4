package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import w0.a;

public final class zzcu extends a implements zzcw {
  public zzcu(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMuteThisAdReason");
  }
  
  public final String zze() {
    Parcel parcel = a1(Z0(), 1);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final String zzf() {
    Parcel parcel = a1(Z0(), 2);
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */