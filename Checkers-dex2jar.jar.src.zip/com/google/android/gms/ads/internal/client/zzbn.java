package com.google.android.gms.ads.internal.client;

import android.os.IInterface;

public interface zzbn extends IInterface {
  String zze();
  
  String zzf();
  
  void zzg(zzl paramzzl);
  
  void zzh(zzl paramzzl, int paramInt);
  
  boolean zzi();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */