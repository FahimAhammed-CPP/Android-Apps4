package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.query.AdInfo;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import w0.i8;

public final class zzdx {
  public final Date a;
  
  public final String b;
  
  public final ArrayList c;
  
  public final int d;
  
  public final Set e;
  
  public final Bundle f;
  
  public final Map g;
  
  public final String h;
  
  public final String i;
  
  @NotOnlyInitialized
  public final SearchAdRequest j;
  
  public final int k;
  
  public final Set l;
  
  public final Bundle m;
  
  public final Set n;
  
  public final boolean o;
  
  public final AdInfo p;
  
  public final String q;
  
  public final int r;
  
  public zzdx(zzdw paramzzdw, SearchAdRequest paramSearchAdRequest) {
    this.a = paramzzdw.g;
    this.b = paramzzdw.h;
    this.c = paramzzdw.i;
    this.d = paramzzdw.j;
    this.e = Collections.unmodifiableSet(paramzzdw.a);
    this.f = paramzzdw.b;
    this.g = Collections.unmodifiableMap(paramzzdw.c);
    this.h = paramzzdw.k;
    this.i = paramzzdw.l;
    this.j = paramSearchAdRequest;
    this.k = paramzzdw.m;
    this.l = Collections.unmodifiableSet(paramzzdw.d);
    this.m = paramzzdw.e;
    this.n = Collections.unmodifiableSet(paramzzdw.f);
    this.o = paramzzdw.n;
    this.p = paramzzdw.o;
    this.q = paramzzdw.p;
    this.r = paramzzdw.q;
  }
  
  @Deprecated
  public final int zza() {
    return this.d;
  }
  
  public final int zzb() {
    return this.r;
  }
  
  public final int zzc() {
    return this.k;
  }
  
  public final Bundle zzd(Class paramClass) {
    Bundle bundle = this.f.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
    return (bundle != null) ? bundle.getBundle(paramClass.getName()) : null;
  }
  
  public final Bundle zze() {
    return this.m;
  }
  
  public final Bundle zzf(Class paramClass) {
    return this.f.getBundle(paramClass.getName());
  }
  
  public final Bundle zzg() {
    return this.f;
  }
  
  @Deprecated
  public final NetworkExtras zzh(Class paramClass) {
    return (NetworkExtras)this.g.get(paramClass);
  }
  
  public final AdInfo zzi() {
    return this.p;
  }
  
  public final SearchAdRequest zzj() {
    return this.j;
  }
  
  public final String zzk() {
    return this.q;
  }
  
  public final String zzl() {
    return this.b;
  }
  
  public final String zzm() {
    return this.h;
  }
  
  public final String zzn() {
    return this.i;
  }
  
  @Deprecated
  public final Date zzo() {
    return this.a;
  }
  
  public final List zzp() {
    return new ArrayList(this.c);
  }
  
  public final Set zzq() {
    return this.n;
  }
  
  public final Set zzr() {
    return this.e;
  }
  
  @Deprecated
  public final boolean zzs() {
    return this.o;
  }
  
  public final boolean zzt(Context paramContext) {
    RequestConfiguration requestConfiguration = zzej.zzf().zzc();
    zzay.zzb();
    String str = i8.l(paramContext);
    return (this.l.contains(str) || requestConfiguration.getTestDeviceIds().contains(str));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */