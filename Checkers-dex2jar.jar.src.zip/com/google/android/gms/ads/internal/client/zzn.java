package com.google.android.gms.ads.internal.client;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import q0.a;

public final class zzn implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    ArrayList arrayList1;
    zzfh zzfh;
    Location location;
    Bundle bundle1;
    Bundle bundle2;
    ArrayList arrayList2;
    zzc zzc;
    ArrayList arrayList3;
    Bundle bundle3;
    int i1 = a.m(paramParcel);
    String str15 = null;
    String str1 = str15;
    String str2 = str1;
    String str3 = str2;
    String str4 = str3;
    String str5 = str4;
    String str6 = str5;
    String str7 = str6;
    String str8 = str7;
    String str9 = str8;
    String str10 = str9;
    String str11 = str10;
    String str12 = str11;
    String str13 = str12;
    String str14 = str13;
    long l = 0L;
    int n = 0;
    int m = 0;
    boolean bool3 = false;
    int k = 0;
    boolean bool2 = false;
    boolean bool1 = false;
    int j = 0;
    int i = 0;
    while (paramParcel.dataPosition() < i1) {
      int i2 = paramParcel.readInt();
      switch ((char)i2) {
        default:
          a.l(paramParcel, i2);
          continue;
        case '\030':
          str14 = a.c(paramParcel, i2);
          continue;
        case '\027':
          i = a.i(paramParcel, i2);
          continue;
        case '\026':
          arrayList3 = a.d(paramParcel, i2);
          continue;
        case '\025':
          str12 = a.c(paramParcel, i2);
          continue;
        case '\024':
          j = a.i(paramParcel, i2);
          continue;
        case '\023':
          zzc = (zzc)a.b(paramParcel, i2, zzc.CREATOR);
          continue;
        case '\022':
          bool1 = a.g(paramParcel, i2);
          continue;
        case '\021':
          str10 = a.c(paramParcel, i2);
          continue;
        case '\020':
          str9 = a.c(paramParcel, i2);
          continue;
        case '\017':
          arrayList2 = a.d(paramParcel, i2);
          continue;
        case '\016':
          bundle2 = a.a(paramParcel, i2);
          continue;
        case '\r':
          bundle1 = a.a(paramParcel, i2);
          continue;
        case '\f':
          str5 = a.c(paramParcel, i2);
          continue;
        case '\013':
          location = (Location)a.b(paramParcel, i2, Location.CREATOR);
          continue;
        case '\n':
          zzfh = (zzfh)a.b(paramParcel, i2, zzfh.CREATOR);
          continue;
        case '\t':
          str2 = a.c(paramParcel, i2);
          continue;
        case '\b':
          bool2 = a.g(paramParcel, i2);
          continue;
        case '\007':
          k = a.i(paramParcel, i2);
          continue;
        case '\006':
          bool3 = a.g(paramParcel, i2);
          continue;
        case '\005':
          arrayList1 = a.d(paramParcel, i2);
          continue;
        case '\004':
          m = a.i(paramParcel, i2);
          continue;
        case '\003':
          bundle3 = a.a(paramParcel, i2);
          continue;
        case '\002':
          l = a.j(paramParcel, i2);
          continue;
        case '\001':
          break;
      } 
      n = a.i(paramParcel, i2);
    } 
    a.f(paramParcel, i1);
    return new zzl(n, l, bundle3, m, arrayList1, bool3, k, bool2, str2, zzfh, location, str5, bundle1, bundle2, arrayList2, str9, str10, bool1, zzc, j, str12, arrayList3, i, str14);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */