package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import u0.a;
import u0.b;
import u0.c;
import w0.l8;
import w0.n;
import w0.o8;
import w0.p8;
import w0.s;
import w0.u6;
import w0.w3;
import w0.z;

public final class zzk extends c {
  public zzk() {
    super("com.google.android.gms.ads.AdManagerCreatorImpl");
  }
  
  public final zzbu zza(Context paramContext, zzq paramzzq, String paramString, w3 paramw3, int paramInt) {
    zzbu zzbu;
    IInterface iInterface;
    z.a(paramContext);
    n n = z.k;
    if (((Boolean)zzba.zzc().a((s)n)).booleanValue()) {
      try {
        zzbu zzbu1;
        b b = new b(paramContext);
        IBinder iBinder = ((zzbv)p8.a(paramContext, "com.google.android.gms.ads.ChimeraAdManagerCreatorImpl", zzj.zza)).zze((a)b, paramzzq, paramString, paramw3, 223712000, paramInt);
        if (iBinder == null)
          return null; 
        iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
        if (iInterface instanceof zzbu) {
          zzbu1 = (zzbu)iInterface;
          zzbu = zzbu1;
        } else {
          zzbu1 = new zzbs((IBinder)zzbu1);
          zzbu = zzbu1;
        } 
      } catch (o8 o8) {
        u6.b((Context)zzbu).a("AdManagerCreator.newAdManagerByDynamiteLoader", (Throwable)o8);
        l8.h((Exception)o8);
        return null;
      } catch (RemoteException remoteException) {
      
      } catch (NullPointerException nullPointerException) {}
    } else {
      try {
        zzbu zzbu1;
        b b = new b(zzbu);
        IBinder iBinder = ((zzbv)b((Context)zzbu)).zze((a)b, (zzq)nullPointerException, (String)iInterface, paramw3, 223712000, paramInt);
        if (iBinder == null)
          return null; 
        IInterface iInterface1 = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
        if (iInterface1 instanceof zzbu) {
          zzbu1 = (zzbu)iInterface1;
        } else {
          zzbu1 = new zzbs((IBinder)zzbu1);
        } 
      } catch (RemoteException remoteException) {
        if (l8.i(3))
          Log.d("Ads", "Could not create remote AdManager.", (Throwable)remoteException); 
        return null;
      } catch (u0.c.a a) {}
      return (zzbu)a;
    } 
    return (zzbu)a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */