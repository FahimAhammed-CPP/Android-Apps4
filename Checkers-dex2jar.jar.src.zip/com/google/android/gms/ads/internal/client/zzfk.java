package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.VideoController;

public final class zzfk extends zzds {
  public final VideoController.VideoLifecycleCallbacks a;
  
  public zzfk(VideoController.VideoLifecycleCallbacks paramVideoLifecycleCallbacks) {
    this.a = paramVideoLifecycleCallbacks;
  }
  
  public final void zze() {
    this.a.onVideoEnd();
  }
  
  public final void zzf(boolean paramBoolean) {
    this.a.onVideoMute(paramBoolean);
  }
  
  public final void zzg() {
    this.a.onVideoPause();
  }
  
  public final void zzh() {
    this.a.onVideoPlay();
  }
  
  public final void zzi() {
    this.a.onVideoStart();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */