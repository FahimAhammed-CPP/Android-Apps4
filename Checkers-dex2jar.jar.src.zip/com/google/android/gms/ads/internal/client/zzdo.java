package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.a;
import w0.c;

public final class zzdo extends a implements zzdq {
  public zzdo(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IVideoController");
  }
  
  public final float zze() {
    throw null;
  }
  
  public final float zzf() {
    throw null;
  }
  
  public final float zzg() {
    throw null;
  }
  
  public final int zzh() {
    Parcel parcel = a1(Z0(), 5);
    int i = parcel.readInt();
    parcel.recycle();
    return i;
  }
  
  public final zzdt zzi() {
    zzdt zzdt;
    Parcel parcel = a1(Z0(), 11);
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
      if (iInterface instanceof zzdt) {
        zzdt = (zzdt)iInterface;
      } else {
        zzdt = new zzdr((IBinder)zzdt);
      } 
    } 
    parcel.recycle();
    return zzdt;
  }
  
  public final void zzj(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void zzk() {
    b1(Z0(), 2);
  }
  
  public final void zzl() {
    b1(Z0(), 1);
  }
  
  public final void zzm(zzdt paramzzdt) {
    Parcel parcel = Z0();
    c.e(parcel, paramzzdt);
    b1(parcel, 8);
  }
  
  public final void zzn() {
    b1(Z0(), 13);
  }
  
  public final boolean zzo() {
    boolean bool;
    Parcel parcel = a1(Z0(), 12);
    ClassLoader classLoader = c.a;
    if (parcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    parcel.recycle();
    return bool;
  }
  
  public final boolean zzp() {
    boolean bool;
    Parcel parcel = a1(Z0(), 10);
    ClassLoader classLoader = c.a;
    if (parcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    parcel.recycle();
    return bool;
  }
  
  public final boolean zzq() {
    boolean bool;
    Parcel parcel = a1(Z0(), 4);
    ClassLoader classLoader = c.a;
    if (parcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */