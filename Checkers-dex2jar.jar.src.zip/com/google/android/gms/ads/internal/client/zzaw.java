package com.google.android.gms.ads.internal.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.h5.OnH5AdsEventListener;
import j0.a;
import j0.b;
import j0.c;
import j0.d;
import j0.e;
import j0.g;
import j0.i;
import j0.j;
import j0.l;
import j0.m;
import j0.n;
import java.util.HashMap;
import w0.a6;
import w0.a8;
import w0.d1;
import w0.g7;
import w0.i2;
import w0.i8;
import w0.j2;
import w0.l8;
import w0.q7;
import w0.t5;
import w0.v6;
import w0.w3;
import w0.x0;
import w0.x2;
import w0.x5;

public final class zzaw {
  public final zzk a;
  
  public final zzi b;
  
  public final zzeq c;
  
  public final i2 d;
  
  public final x5 e;
  
  public final j2 f;
  
  public v6 g;
  
  public zzaw(zzk paramzzk, zzi paramzzi, zzeq paramzzeq, i2 parami2, q7 paramq7, x5 paramx5, j2 paramj2) {
    this.a = paramzzk;
    this.b = paramzzi;
    this.c = paramzzeq;
    this.d = parami2;
    this.e = paramx5;
    this.f = paramj2;
  }
  
  public final zzbq zzc(Context paramContext, String paramString, w3 paramw3) {
    return (zzbq)(new j(this, paramContext, paramString, paramw3)).d(paramContext, false);
  }
  
  public final zzbu zzd(Context paramContext, zzq paramzzq, String paramString, w3 paramw3) {
    return (zzbu)(new g(this, paramContext, paramzzq, paramString, paramw3)).d(paramContext, false);
  }
  
  public final zzbu zze(Context paramContext, zzq paramzzq, String paramString, w3 paramw3) {
    return (zzbu)(new i(this, paramContext, paramzzq, paramString, paramw3)).d(paramContext, false);
  }
  
  public final zzdj zzf(Context paramContext, w3 paramw3) {
    return (zzdj)(new b(paramContext, paramw3)).d(paramContext, false);
  }
  
  public final x0 zzh(Context paramContext, FrameLayout paramFrameLayout1, FrameLayout paramFrameLayout2) {
    return (x0)(new l(this, paramFrameLayout1, paramFrameLayout2, paramContext)).d(paramContext, false);
  }
  
  public final d1 zzi(View paramView, HashMap paramHashMap1, HashMap paramHashMap2) {
    return (d1)(new m(this, paramView, paramHashMap1, paramHashMap2)).d(paramView.getContext(), false);
  }
  
  public final x2 zzl(Context paramContext, w3 paramw3, OnH5AdsEventListener paramOnH5AdsEventListener) {
    return (x2)(new e(paramContext, paramw3, paramOnH5AdsEventListener)).d(paramContext, false);
  }
  
  public final t5 zzm(Context paramContext, w3 paramw3) {
    return (t5)(new d(paramContext, paramw3)).d(paramContext, false);
  }
  
  public final a6 zzo(Activity paramActivity) {
    a a = new a(this, paramActivity);
    Intent intent = paramActivity.getIntent();
    boolean bool2 = intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar");
    boolean bool1 = false;
    if (!bool2) {
      l8.c("useClientJar flag not found in activity intent extras.");
    } else {
      bool1 = intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
    } 
    return (a6)a.d((Context)paramActivity, bool1);
  }
  
  public final g7 zzq(Context paramContext, String paramString, w3 paramw3) {
    return (g7)(new n(paramContext, paramString, paramw3)).d(paramContext, false);
  }
  
  public final a8 zzr(Context paramContext, w3 paramw3) {
    return (a8)(new c(paramContext, paramw3)).d(paramContext, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzaw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */