package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzt implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int k = a.m(paramParcel);
    String str = null;
    long l = 0L;
    int j = 0;
    int i = 0;
    while (paramParcel.dataPosition() < k) {
      int m = paramParcel.readInt();
      char c = (char)m;
      if (c != '\001') {
        if (c != '\002') {
          if (c != '\003') {
            if (c != '\004') {
              a.l(paramParcel, m);
              continue;
            } 
            l = a.j(paramParcel, m);
            continue;
          } 
          str = a.c(paramParcel, m);
          continue;
        } 
        i = a.i(paramParcel, m);
        continue;
      } 
      j = a.i(paramParcel, m);
    } 
    a.f(paramParcel, k);
    return new zzs(j, i, str, l);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */