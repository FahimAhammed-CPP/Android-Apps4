package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import androidx.lifecycle.g;
import com.google.android.gms.ads.AdInspectorError;
import com.google.android.gms.ads.OnAdInspectorClosedListener;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.internal.ads.zzbrw;
import j0.k;
import j0.r;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;
import p0.e;
import u0.a;
import u0.b;
import w0.k3;
import w0.l8;
import w0.r3;
import w0.s3;
import w0.z8;

public final class zzej {
  @GuardedBy("InternalMobileAds.class")
  public static zzej i;
  
  public final Object a = new Object();
  
  @GuardedBy("stateLock")
  public final ArrayList b = new ArrayList();
  
  @GuardedBy("stateLock")
  public boolean c = false;
  
  @GuardedBy("stateLock")
  public boolean d = false;
  
  public final Object e = new Object();
  
  @GuardedBy("settingManagerLock")
  public zzco f;
  
  @Nullable
  public OnAdInspectorClosedListener g = null;
  
  public RequestConfiguration h = (new RequestConfiguration.Builder()).build();
  
  public static g a(List paramList) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (zzbrw zzbrw : paramList) {
      AdapterStatus.State state;
      String str = zzbrw.i;
      if (zzbrw.j) {
        state = AdapterStatus.State.READY;
      } else {
        state = AdapterStatus.State.NOT_READY;
      } 
      hashMap.put(str, new k3(state, zzbrw.l, zzbrw.k));
    } 
    return new g(hashMap);
  }
  
  public static zzej zzf() {
    // Byte code:
    //   0: ldc com/google/android/gms/ads/internal/client/zzej
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/ads/internal/client/zzej.i : Lcom/google/android/gms/ads/internal/client/zzej;
    //   6: ifnonnull -> 19
    //   9: new com/google/android/gms/ads/internal/client/zzej
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic com/google/android/gms/ads/internal/client/zzej.i : Lcom/google/android/gms/ads/internal/client/zzej;
    //   19: getstatic com/google/android/gms/ads/internal/client/zzej.i : Lcom/google/android/gms/ads/internal/client/zzej;
    //   22: astore_0
    //   23: ldc com/google/android/gms/ads/internal/client/zzej
    //   25: monitorexit
    //   26: aload_0
    //   27: areturn
    //   28: astore_0
    //   29: ldc com/google/android/gms/ads/internal/client/zzej
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	28	finally
    //   19	26	28	finally
    //   29	32	28	finally
  }
  
  @GuardedBy("settingManagerLock")
  public final void b(Context paramContext) {
    try {
      if (s3.b == null)
        s3.b = new s3(); 
      s3 s3 = s3.b;
      if (s3.a.compareAndSet(false, true))
        (new Thread((Runnable)new r3(s3, paramContext, null))).start(); 
      this.f.zzk();
      this.f.zzl(null, (a)new b(null));
      return;
    } catch (RemoteException remoteException) {
      l8.g("MobileAdsSettingManager initialization failed", (Throwable)remoteException);
      return;
    } 
  }
  
  @GuardedBy("settingManagerLock")
  public final void c(Context paramContext) {
    if (this.f == null)
      this.f = (zzco)(new k(zzay.zza(), paramContext)).d(paramContext, false); 
  }
  
  public final float zza() {
    synchronized (this.e) {
      zzco zzco1 = this.f;
      float f = 1.0F;
      if (zzco1 == null)
        return 1.0F; 
      try {
        float f1 = zzco1.zze();
        f = f1;
      } catch (RemoteException remoteException) {
        l8.d("Unable to get app volume.", (Throwable)remoteException);
      } 
      return f;
    } 
  }
  
  public final RequestConfiguration zzc() {
    return this.h;
  }
  
  public final InitializationStatus zze() {
    synchronized (this.e) {
      boolean bool;
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      e.i(bool, "MobileAds.initialize() must be called prior to getting initialization status.");
      try {
        return (InitializationStatus)a(this.f.zzg());
      } catch (RemoteException remoteException) {}
      l8.c("Unable to get Initialization status.");
      return new zzeb(this);
    } 
  }
  
  @Deprecated
  public final String zzh() {
    synchronized (this.e) {
      boolean bool;
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      e.i(bool, "MobileAds.initialize() must be called prior to getting version string.");
      try {
        String str2 = this.f.zzf();
        int i = z8.a;
        String str1 = str2;
        if (str2 == null)
          str1 = ""; 
        return str1;
      } catch (RemoteException remoteException) {
        l8.d("Unable to get version string.", (Throwable)remoteException);
        return "";
      } 
    } 
  }
  
  public final void zzl(Context paramContext) {
    synchronized (this.e) {
      c(paramContext);
      try {
        this.f.zzi();
      } catch (RemoteException remoteException) {
        l8.c("Unable to disable mediation adapter initialization.");
      } 
      return;
    } 
  }
  
  public final void zzm(boolean paramBoolean) {
    synchronized (this.e) {
      boolean bool;
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      e.i(bool, "MobileAds.initialize() must be called prior to enable/disable Same App Key.");
      try {
        this.f.zzj(paramBoolean);
      } catch (RemoteException remoteException) {
        String str;
        if (true != paramBoolean) {
          str = "disable";
        } else {
          str = "enable";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to ");
        stringBuilder.append(str);
        stringBuilder.append(" Same App Key.");
        l8.d(stringBuilder.toString(), (Throwable)remoteException);
        if (remoteException.getMessage() != null && remoteException.getMessage().toLowerCase(Locale.ROOT).contains("paid"))
          throw new IllegalStateException(remoteException); 
      } 
      return;
    } 
  }
  
  public final void zzn(Context paramContext, @Nullable String paramString, @Nullable OnInitializationCompleteListener paramOnInitializationCompleteListener) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifeq -> 30
    //   14: aload_3
    //   15: ifnull -> 27
    //   18: aload_0
    //   19: getfield b : Ljava/util/ArrayList;
    //   22: aload_3
    //   23: invokevirtual add : (Ljava/lang/Object;)Z
    //   26: pop
    //   27: aload_2
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: getfield d : Z
    //   34: ifeq -> 54
    //   37: aload_3
    //   38: ifnull -> 51
    //   41: aload_3
    //   42: aload_0
    //   43: invokevirtual zze : ()Lcom/google/android/gms/ads/initialization/InitializationStatus;
    //   46: invokeinterface onInitializationComplete : (Lcom/google/android/gms/ads/initialization/InitializationStatus;)V
    //   51: aload_2
    //   52: monitorexit
    //   53: return
    //   54: aload_0
    //   55: iconst_1
    //   56: putfield c : Z
    //   59: aload_3
    //   60: ifnull -> 72
    //   63: aload_0
    //   64: getfield b : Ljava/util/ArrayList;
    //   67: aload_3
    //   68: invokevirtual add : (Ljava/lang/Object;)Z
    //   71: pop
    //   72: aload_2
    //   73: monitorexit
    //   74: aload_1
    //   75: ifnull -> 342
    //   78: aload_0
    //   79: getfield e : Ljava/lang/Object;
    //   82: astore_2
    //   83: aload_2
    //   84: monitorenter
    //   85: aload_0
    //   86: aload_1
    //   87: invokevirtual c : (Landroid/content/Context;)V
    //   90: aload_0
    //   91: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   94: new j0/s
    //   97: dup
    //   98: aload_0
    //   99: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzej;)V
    //   102: invokeinterface zzs : (Lw0/j3;)V
    //   107: aload_0
    //   108: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   111: new w0/t3
    //   114: dup
    //   115: invokespecial <init> : ()V
    //   118: invokeinterface zzo : (Lw0/w3;)V
    //   123: aload_0
    //   124: getfield h : Lcom/google/android/gms/ads/RequestConfiguration;
    //   127: invokevirtual getTagForChildDirectedTreatment : ()I
    //   130: iconst_m1
    //   131: if_icmpne -> 145
    //   134: aload_0
    //   135: getfield h : Lcom/google/android/gms/ads/RequestConfiguration;
    //   138: invokevirtual getTagForUnderAgeOfConsent : ()I
    //   141: iconst_m1
    //   142: if_icmpeq -> 198
    //   145: aload_0
    //   146: getfield h : Lcom/google/android/gms/ads/RequestConfiguration;
    //   149: astore #4
    //   151: aload_0
    //   152: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   155: new com/google/android/gms/ads/internal/client/zzff
    //   158: dup
    //   159: aload #4
    //   161: invokespecial <init> : (Lcom/google/android/gms/ads/RequestConfiguration;)V
    //   164: invokeinterface zzt : (Lcom/google/android/gms/ads/internal/client/zzff;)V
    //   169: goto -> 198
    //   172: astore_1
    //   173: goto -> 338
    //   176: astore #4
    //   178: ldc_w 'Unable to set request configuration parcel.'
    //   181: aload #4
    //   183: invokestatic d : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   186: goto -> 198
    //   189: astore #4
    //   191: ldc 'MobileAdsSettingManager initialization failed'
    //   193: aload #4
    //   195: invokestatic g : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   198: aload_1
    //   199: invokestatic a : (Landroid/content/Context;)V
    //   202: getstatic w0/f0.a : Lw0/c0;
    //   205: invokevirtual c : ()Ljava/lang/Object;
    //   208: checkcast java/lang/Boolean
    //   211: invokevirtual booleanValue : ()Z
    //   214: ifeq -> 265
    //   217: getstatic w0/z.o : Lw0/n;
    //   220: astore #4
    //   222: invokestatic zzc : ()Lw0/x;
    //   225: aload #4
    //   227: invokevirtual a : (Lw0/s;)Ljava/lang/Object;
    //   230: checkcast java/lang/Boolean
    //   233: invokevirtual booleanValue : ()Z
    //   236: ifeq -> 265
    //   239: ldc_w 'Initializing on bg thread'
    //   242: invokestatic b : (Ljava/lang/String;)V
    //   245: getstatic w0/g8.a : Ljava/util/concurrent/ThreadPoolExecutor;
    //   248: new com/google/android/gms/ads/internal/client/zzec
    //   251: dup
    //   252: aload_0
    //   253: aload_1
    //   254: aconst_null
    //   255: aload_3
    //   256: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzej;Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/ads/initialization/OnInitializationCompleteListener;)V
    //   259: invokevirtual execute : (Ljava/lang/Runnable;)V
    //   262: goto -> 335
    //   265: getstatic w0/f0.b : Lw0/c0;
    //   268: invokevirtual c : ()Ljava/lang/Object;
    //   271: checkcast java/lang/Boolean
    //   274: invokevirtual booleanValue : ()Z
    //   277: ifeq -> 324
    //   280: getstatic w0/z.o : Lw0/n;
    //   283: astore #4
    //   285: invokestatic zzc : ()Lw0/x;
    //   288: aload #4
    //   290: invokevirtual a : (Lw0/s;)Ljava/lang/Object;
    //   293: checkcast java/lang/Boolean
    //   296: invokevirtual booleanValue : ()Z
    //   299: ifeq -> 324
    //   302: getstatic w0/g8.b : Ljava/util/concurrent/ExecutorService;
    //   305: new com/google/android/gms/ads/internal/client/zzed
    //   308: dup
    //   309: aload_0
    //   310: aload_1
    //   311: aconst_null
    //   312: aload_3
    //   313: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzej;Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/ads/initialization/OnInitializationCompleteListener;)V
    //   316: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   321: goto -> 335
    //   324: ldc_w 'Initializing on calling thread'
    //   327: invokestatic b : (Ljava/lang/String;)V
    //   330: aload_0
    //   331: aload_1
    //   332: invokevirtual b : (Landroid/content/Context;)V
    //   335: aload_2
    //   336: monitorexit
    //   337: return
    //   338: aload_2
    //   339: monitorexit
    //   340: aload_1
    //   341: athrow
    //   342: new java/lang/IllegalArgumentException
    //   345: dup
    //   346: ldc_w 'Context cannot be null.'
    //   349: invokespecial <init> : (Ljava/lang/String;)V
    //   352: athrow
    //   353: astore_1
    //   354: aload_2
    //   355: monitorexit
    //   356: aload_1
    //   357: athrow
    // Exception table:
    //   from	to	target	type
    //   7	14	353	finally
    //   18	27	353	finally
    //   27	29	353	finally
    //   30	37	353	finally
    //   41	51	353	finally
    //   51	53	353	finally
    //   54	59	353	finally
    //   63	72	353	finally
    //   72	74	353	finally
    //   85	145	189	android/os/RemoteException
    //   85	145	172	finally
    //   145	151	189	android/os/RemoteException
    //   145	151	172	finally
    //   151	169	176	android/os/RemoteException
    //   151	169	172	finally
    //   178	186	189	android/os/RemoteException
    //   178	186	172	finally
    //   191	198	172	finally
    //   198	262	172	finally
    //   265	321	172	finally
    //   324	335	172	finally
    //   335	337	172	finally
    //   338	340	172	finally
    //   354	356	353	finally
  }
  
  public final void zzq(Context paramContext, OnAdInspectorClosedListener paramOnAdInspectorClosedListener) {
    synchronized (this.e) {
      c(paramContext);
      this.g = paramOnAdInspectorClosedListener;
      try {
        this.f.zzm((zzda)new r());
      } catch (RemoteException remoteException) {
        l8.c("Unable to open the ad inspector.");
        if (paramOnAdInspectorClosedListener != null)
          paramOnAdInspectorClosedListener.onAdInspectorClosed(new AdInspectorError(0, "Ad inspector had an internal error.", "com.google.android.gms.ads")); 
      } 
      return;
    } 
  }
  
  public final void zzr(Context paramContext, String paramString) {
    synchronized (this.e) {
      boolean bool;
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      e.i(bool, "MobileAds.initialize() must be called prior to opening debug menu.");
      try {
        this.f.zzn((a)new b(paramContext), paramString);
      } catch (RemoteException remoteException) {
        l8.d("Unable to open debug menu.", (Throwable)remoteException);
      } 
      return;
    } 
  }
  
  public final void zzs(Class paramClass) {
    Object object = this.e;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      this.f.zzh(paramClass.getCanonicalName());
    } catch (RemoteException remoteException) {
      l8.d("Unable to register RtbAdapter", (Throwable)remoteException);
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final void zzt(boolean paramBoolean) {
    synchronized (this.e) {
      boolean bool;
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      e.i(bool, "MobileAds.initialize() must be called prior to setting app muted state.");
      try {
        this.f.zzp(paramBoolean);
      } catch (RemoteException remoteException) {
        l8.d("Unable to set app mute state.", (Throwable)remoteException);
      } 
      return;
    } 
  }
  
  public final void zzu(float paramFloat) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: fload_1
    //   3: fconst_0
    //   4: fcmpg
    //   5: iflt -> 19
    //   8: fload_1
    //   9: fconst_1
    //   10: fcmpg
    //   11: ifgt -> 19
    //   14: iconst_1
    //   15: istore_2
    //   16: goto -> 21
    //   19: iconst_0
    //   20: istore_2
    //   21: iload_2
    //   22: ldc_w 'The app volume must be a value between 0 and 1 inclusive.'
    //   25: invokestatic b : (ZLjava/lang/String;)V
    //   28: aload_0
    //   29: getfield e : Ljava/lang/Object;
    //   32: astore #4
    //   34: aload #4
    //   36: monitorenter
    //   37: iload_3
    //   38: istore_2
    //   39: aload_0
    //   40: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   43: ifnull -> 48
    //   46: iconst_1
    //   47: istore_2
    //   48: iload_2
    //   49: ldc_w 'MobileAds.initialize() must be called prior to setting the app volume.'
    //   52: invokestatic i : (ZLjava/lang/String;)V
    //   55: aload_0
    //   56: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   59: fload_1
    //   60: invokeinterface zzq : (F)V
    //   65: goto -> 78
    //   68: astore #5
    //   70: ldc_w 'Unable to set app volume.'
    //   73: aload #5
    //   75: invokestatic d : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   78: aload #4
    //   80: monitorexit
    //   81: return
    //   82: astore #5
    //   84: aload #4
    //   86: monitorexit
    //   87: aload #5
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   39	46	82	finally
    //   48	55	82	finally
    //   55	65	68	android/os/RemoteException
    //   55	65	82	finally
    //   70	78	82	finally
    //   78	81	82	finally
    //   84	87	82	finally
  }
  
  public final void zzv(RequestConfiguration paramRequestConfiguration) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 10
    //   4: iconst_1
    //   5: istore #4
    //   7: goto -> 13
    //   10: iconst_0
    //   11: istore #4
    //   13: iload #4
    //   15: ldc_w 'Null passed to setRequestConfiguration.'
    //   18: invokestatic b : (ZLjava/lang/String;)V
    //   21: aload_0
    //   22: getfield e : Ljava/lang/Object;
    //   25: astore #5
    //   27: aload #5
    //   29: monitorenter
    //   30: aload_0
    //   31: getfield h : Lcom/google/android/gms/ads/RequestConfiguration;
    //   34: astore #6
    //   36: aload_0
    //   37: aload_1
    //   38: putfield h : Lcom/google/android/gms/ads/RequestConfiguration;
    //   41: aload_0
    //   42: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   45: ifnonnull -> 52
    //   48: aload #5
    //   50: monitorexit
    //   51: return
    //   52: aload #6
    //   54: invokevirtual getTagForChildDirectedTreatment : ()I
    //   57: aload_1
    //   58: invokevirtual getTagForChildDirectedTreatment : ()I
    //   61: if_icmpne -> 80
    //   64: aload #6
    //   66: invokevirtual getTagForUnderAgeOfConsent : ()I
    //   69: istore_2
    //   70: aload_1
    //   71: invokevirtual getTagForUnderAgeOfConsent : ()I
    //   74: istore_3
    //   75: iload_2
    //   76: iload_3
    //   77: if_icmpeq -> 108
    //   80: aload_0
    //   81: getfield f : Lcom/google/android/gms/ads/internal/client/zzco;
    //   84: new com/google/android/gms/ads/internal/client/zzff
    //   87: dup
    //   88: aload_1
    //   89: invokespecial <init> : (Lcom/google/android/gms/ads/RequestConfiguration;)V
    //   92: invokeinterface zzt : (Lcom/google/android/gms/ads/internal/client/zzff;)V
    //   97: goto -> 108
    //   100: astore_1
    //   101: ldc_w 'Unable to set request configuration parcel.'
    //   104: aload_1
    //   105: invokestatic d : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   108: aload #5
    //   110: monitorexit
    //   111: return
    //   112: astore_1
    //   113: aload #5
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    // Exception table:
    //   from	to	target	type
    //   30	51	112	finally
    //   52	75	112	finally
    //   80	97	100	android/os/RemoteException
    //   80	97	112	finally
    //   101	108	112	finally
    //   108	111	112	finally
    //   113	116	112	finally
  }
  
  public final boolean zzw() {
    synchronized (this.e) {
      zzco zzco1 = this.f;
      boolean bool = false;
      if (zzco1 == null)
        return false; 
      try {
        boolean bool1 = zzco1.zzu();
        bool = bool1;
      } catch (RemoteException remoteException) {
        l8.d("Unable to get app mute state.", (Throwable)remoteException);
      } 
      return bool;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzej.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */