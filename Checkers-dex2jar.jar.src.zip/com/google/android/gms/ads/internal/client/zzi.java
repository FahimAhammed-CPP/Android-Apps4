package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import u0.a;
import u0.b;
import u0.c;
import w0.l8;
import w0.w3;

public final class zzi extends c {
  public zzi() {
    super("com.google.android.gms.ads.AdLoaderBuilderCreatorImpl");
  }
  
  public final zzbq zza(Context paramContext, String paramString, w3 paramw3) {
    try {
      zzbq zzbq;
      b b = new b(paramContext);
      IBinder iBinder = ((zzbr)b(paramContext)).zze((a)b, paramString, paramw3, 223712000);
      if (iBinder == null)
        return null; 
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      if (iInterface instanceof zzbq) {
        zzbq = (zzbq)iInterface;
      } else {
        zzbq = new zzbo((IBinder)zzbq);
      } 
    } catch (RemoteException remoteException) {
      l8.g("Could not create remote builder for AdLoader.", (Throwable)remoteException);
      return null;
    } catch (u0.c.a a) {}
    return (zzbq)a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */