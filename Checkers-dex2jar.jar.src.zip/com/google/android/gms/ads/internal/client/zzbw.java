package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import w0.a;

public final class zzbw extends a implements zzby {
  public zzbw(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdMetadataListener");
  }
  
  public final void zze() {
    b1(Z0(), 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */