package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;

public final class zzen extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzen> CREATOR = new zzeo();
  
  public final int i;
  
  public final int j;
  
  public final String k;
  
  public zzen() {
    this(223712200, 223712000, "21.4.0");
  }
  
  public zzen(int paramInt1, int paramInt2, String paramString) {
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramString;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 1, this.i);
    b.g(paramParcel, 2, this.j);
    b.j(paramParcel, 3, this.k);
    b.v(paramParcel, paramInt);
  }
  
  public final int zza() {
    return this.j;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */