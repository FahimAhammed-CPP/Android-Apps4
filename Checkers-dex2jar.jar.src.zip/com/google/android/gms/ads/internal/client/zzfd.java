package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;

public final class zzfd extends zzdc {
  public final OnAdMetadataChangedListener a;
  
  public zzfd(OnAdMetadataChangedListener paramOnAdMetadataChangedListener) {
    this.a = paramOnAdMetadataChangedListener;
  }
  
  public final void zze() {
    OnAdMetadataChangedListener onAdMetadataChangedListener = this.a;
    if (onAdMetadataChangedListener != null)
      onAdMetadataChangedListener.onAdMetadataChanged(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */