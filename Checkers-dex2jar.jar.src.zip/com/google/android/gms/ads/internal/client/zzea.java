package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.admanager.AppEventListener;
import com.google.android.gms.ads.zzb;
import j0.p;
import java.util.concurrent.atomic.AtomicBoolean;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import u0.a;
import u0.b;
import w0.d;
import w0.i8;
import w0.l8;
import w0.t3;

public final class zzea {
  public final t3 a = new t3();
  
  public final zzp b;
  
  public final AtomicBoolean c;
  
  public final VideoController d = new VideoController();
  
  public final p e = new p(this);
  
  public zza f;
  
  public AdListener g;
  
  public AdSize[] h;
  
  public AppEventListener i;
  
  public zzbu j;
  
  public VideoOptions k;
  
  public String l;
  
  @NotOnlyInitialized
  public final ViewGroup m;
  
  public int n;
  
  public boolean o;
  
  public OnPaidEventListener p;
  
  public zzea(ViewGroup paramViewGroup) {
    this(paramViewGroup, null, false, zzp.zza, 0);
  }
  
  public zzea(ViewGroup paramViewGroup, int paramInt) {
    this(paramViewGroup, null, false, zzp.zza, paramInt);
  }
  
  public zzea(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean) {
    this(paramViewGroup, paramAttributeSet, paramBoolean, zzp.zza, 0);
  }
  
  public zzea(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean, int paramInt) {
    this(paramViewGroup, paramAttributeSet, paramBoolean, zzp.zza, paramInt);
  }
  
  public zzea(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean, zzp paramzzp, int paramInt) {
    this.m = paramViewGroup;
    this.b = paramzzp;
    this.j = null;
    boolean bool = false;
    this.c = new AtomicBoolean(false);
    this.n = paramInt;
    if (paramAttributeSet != null) {
      Context context = paramViewGroup.getContext();
      try {
        zzy zzy = new zzy(context, paramAttributeSet);
        this.h = zzy.zzb(paramBoolean);
        this.l = zzy.zza();
        if (paramViewGroup.isInEditMode()) {
          zzq zzq;
          i8 i8 = zzay.zzb();
          AdSize adSize = this.h[0];
          paramInt = this.n;
          if (adSize.equals(AdSize.INVALID)) {
            zzq = zzq.zze();
          } else {
            zzq = new zzq(context, (AdSize)zzq);
            paramBoolean = bool;
            if (paramInt == 1)
              paramBoolean = true; 
            zzq.zzj = paramBoolean;
          } 
          i8.getClass();
          i8.d(paramViewGroup, zzq, "Ads by Google", -16777216, -1);
          return;
        } 
      } catch (IllegalArgumentException illegalArgumentException) {
        i8 i8 = zzay.zzb();
        zzq zzq = new zzq(context, AdSize.BANNER);
        String str2 = illegalArgumentException.getMessage();
        String str1 = illegalArgumentException.getMessage();
        i8.getClass();
        if (str1 != null)
          l8.f(str1); 
        i8.d(paramViewGroup, zzq, str2, -65536, -16777216);
      } 
    } 
  }
  
  public static zzq a(Context paramContext, AdSize[] paramArrayOfAdSize, int paramInt) {
    int j = paramArrayOfAdSize.length;
    boolean bool = false;
    for (int i = 0; i < j; i++) {
      if (paramArrayOfAdSize[i].equals(AdSize.INVALID))
        return zzq.zze(); 
    } 
    zzq zzq = new zzq(paramContext, paramArrayOfAdSize);
    if (paramInt == 1)
      bool = true; 
    zzq.zzj = bool;
    return zzq;
  }
  
  public final boolean zzA() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        return zzbu1.zzY(); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
    } 
    return false;
  }
  
  public final AdSize[] zzB() {
    return this.h;
  }
  
  public final AdListener zza() {
    return this.g;
  }
  
  public final AdSize zzb() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null) {
        zzq zzq = zzbu1.zzg();
        if (zzq != null)
          return zzb.zzc(zzq.zze, zzq.zzb, zzq.zza); 
      } 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
    } 
    AdSize[] arrayOfAdSize = this.h;
    return (arrayOfAdSize != null) ? arrayOfAdSize[0] : null;
  }
  
  public final OnPaidEventListener zzc() {
    return this.p;
  }
  
  public final ResponseInfo zzd() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null) {
        zzdn zzdn1 = zzbu1.zzk();
        return ResponseInfo.zza(zzdn1);
      } 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
    } 
    zzdn zzdn = null;
    return ResponseInfo.zza(zzdn);
  }
  
  public final VideoController zzf() {
    return this.d;
  }
  
  public final VideoOptions zzg() {
    return this.k;
  }
  
  public final AppEventListener zzh() {
    return this.i;
  }
  
  public final zzdq zzi() {
    zzbu zzbu1 = this.j;
    if (zzbu1 != null)
      try {
        return zzbu1.zzl();
      } catch (RemoteException remoteException) {
        l8.h((Exception)remoteException);
      }  
    return null;
  }
  
  public final String zzj() {
    if (this.l == null) {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        try {
          this.l = zzbu1.zzr();
        } catch (RemoteException remoteException) {
          l8.h((Exception)remoteException);
        }  
    } 
    return this.l;
  }
  
  public final void zzk() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzx(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzm(zzdx paramzzdx) {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   4: ifnonnull -> 357
    //   7: aload_0
    //   8: getfield h : [Lcom/google/android/gms/ads/AdSize;
    //   11: ifnull -> 346
    //   14: aload_0
    //   15: getfield l : Ljava/lang/String;
    //   18: ifnull -> 346
    //   21: aload_0
    //   22: getfield m : Landroid/view/ViewGroup;
    //   25: invokevirtual getContext : ()Landroid/content/Context;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: getfield h : [Lcom/google/android/gms/ads/AdSize;
    //   34: aload_0
    //   35: getfield n : I
    //   38: invokestatic a : (Landroid/content/Context;[Lcom/google/android/gms/ads/AdSize;I)Lcom/google/android/gms/ads/internal/client/zzq;
    //   41: astore_3
    //   42: ldc 'search_v2'
    //   44: aload_3
    //   45: getfield zza : Ljava/lang/String;
    //   48: invokevirtual equals : (Ljava/lang/Object;)Z
    //   51: ifeq -> 79
    //   54: new j0/h
    //   57: dup
    //   58: invokestatic zza : ()Lcom/google/android/gms/ads/internal/client/zzaw;
    //   61: aload_2
    //   62: aload_3
    //   63: aload_0
    //   64: getfield l : Ljava/lang/String;
    //   67: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzaw;Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzq;Ljava/lang/String;)V
    //   70: aload_2
    //   71: iconst_0
    //   72: invokevirtual d : (Landroid/content/Context;Z)Ljava/lang/Object;
    //   75: astore_2
    //   76: goto -> 105
    //   79: new j0/f
    //   82: dup
    //   83: invokestatic zza : ()Lcom/google/android/gms/ads/internal/client/zzaw;
    //   86: aload_2
    //   87: aload_3
    //   88: aload_0
    //   89: getfield l : Ljava/lang/String;
    //   92: aload_0
    //   93: getfield a : Lw0/t3;
    //   96: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzaw;Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzq;Ljava/lang/String;Lw0/t3;)V
    //   99: aload_2
    //   100: iconst_0
    //   101: invokevirtual d : (Landroid/content/Context;Z)Ljava/lang/Object;
    //   104: astore_2
    //   105: aload_2
    //   106: checkcast com/google/android/gms/ads/internal/client/zzbu
    //   109: astore_2
    //   110: aload_0
    //   111: aload_2
    //   112: putfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   115: aload_2
    //   116: new com/google/android/gms/ads/internal/client/zzg
    //   119: dup
    //   120: aload_0
    //   121: getfield e : Lj0/p;
    //   124: invokespecial <init> : (Lcom/google/android/gms/ads/AdListener;)V
    //   127: invokeinterface zzD : (Lcom/google/android/gms/ads/internal/client/zzbh;)V
    //   132: aload_0
    //   133: getfield f : Lcom/google/android/gms/ads/internal/client/zza;
    //   136: astore_2
    //   137: aload_2
    //   138: ifnull -> 158
    //   141: aload_0
    //   142: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   145: new com/google/android/gms/ads/internal/client/zzb
    //   148: dup
    //   149: aload_2
    //   150: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zza;)V
    //   153: invokeinterface zzC : (Lcom/google/android/gms/ads/internal/client/zzbe;)V
    //   158: aload_0
    //   159: getfield i : Lcom/google/android/gms/ads/admanager/AppEventListener;
    //   162: astore_2
    //   163: aload_2
    //   164: ifnull -> 184
    //   167: aload_0
    //   168: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   171: new w0/d
    //   174: dup
    //   175: aload_2
    //   176: invokespecial <init> : (Lcom/google/android/gms/ads/admanager/AppEventListener;)V
    //   179: invokeinterface zzG : (Lcom/google/android/gms/ads/internal/client/zzcb;)V
    //   184: aload_0
    //   185: getfield k : Lcom/google/android/gms/ads/VideoOptions;
    //   188: ifnull -> 211
    //   191: aload_0
    //   192: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   195: new com/google/android/gms/ads/internal/client/zzfl
    //   198: dup
    //   199: aload_0
    //   200: getfield k : Lcom/google/android/gms/ads/VideoOptions;
    //   203: invokespecial <init> : (Lcom/google/android/gms/ads/VideoOptions;)V
    //   206: invokeinterface zzU : (Lcom/google/android/gms/ads/internal/client/zzfl;)V
    //   211: aload_0
    //   212: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   215: new com/google/android/gms/ads/internal/client/zzfe
    //   218: dup
    //   219: aload_0
    //   220: getfield p : Lcom/google/android/gms/ads/OnPaidEventListener;
    //   223: invokespecial <init> : (Lcom/google/android/gms/ads/OnPaidEventListener;)V
    //   226: invokeinterface zzP : (Lcom/google/android/gms/ads/internal/client/zzdg;)V
    //   231: aload_0
    //   232: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   235: aload_0
    //   236: getfield o : Z
    //   239: invokeinterface zzN : (Z)V
    //   244: aload_0
    //   245: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   248: astore_2
    //   249: aload_2
    //   250: ifnonnull -> 256
    //   253: goto -> 357
    //   256: aload_2
    //   257: invokeinterface zzn : ()Lu0/a;
    //   262: astore_2
    //   263: aload_2
    //   264: ifnull -> 357
    //   267: getstatic w0/f0.f : Lw0/c0;
    //   270: invokevirtual c : ()Ljava/lang/Object;
    //   273: checkcast java/lang/Boolean
    //   276: invokevirtual booleanValue : ()Z
    //   279: ifeq -> 321
    //   282: getstatic w0/z.p : Lw0/n;
    //   285: astore_3
    //   286: invokestatic zzc : ()Lw0/x;
    //   289: aload_3
    //   290: invokevirtual a : (Lw0/s;)Ljava/lang/Object;
    //   293: checkcast java/lang/Boolean
    //   296: invokevirtual booleanValue : ()Z
    //   299: ifeq -> 321
    //   302: getstatic w0/i8.a : Lw0/w8;
    //   305: new com/google/android/gms/ads/internal/client/zzdy
    //   308: dup
    //   309: aload_0
    //   310: aload_2
    //   311: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzea;Lu0/a;)V
    //   314: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   317: pop
    //   318: goto -> 357
    //   321: aload_0
    //   322: getfield m : Landroid/view/ViewGroup;
    //   325: aload_2
    //   326: invokestatic b1 : (Lu0/a;)Ljava/lang/Object;
    //   329: checkcast android/view/View
    //   332: invokevirtual addView : (Landroid/view/View;)V
    //   335: goto -> 357
    //   338: astore_2
    //   339: aload_2
    //   340: invokestatic h : (Ljava/lang/Exception;)V
    //   343: goto -> 357
    //   346: new java/lang/IllegalStateException
    //   349: dup
    //   350: ldc_w 'The ad size and ad unit ID must be set before loadAd is called.'
    //   353: invokespecial <init> : (Ljava/lang/String;)V
    //   356: athrow
    //   357: aload_0
    //   358: getfield j : Lcom/google/android/gms/ads/internal/client/zzbu;
    //   361: astore_2
    //   362: aload_2
    //   363: invokevirtual getClass : ()Ljava/lang/Class;
    //   366: pop
    //   367: aload_2
    //   368: aload_0
    //   369: getfield b : Lcom/google/android/gms/ads/internal/client/zzp;
    //   372: aload_0
    //   373: getfield m : Landroid/view/ViewGroup;
    //   376: invokevirtual getContext : ()Landroid/content/Context;
    //   379: aload_1
    //   380: invokevirtual zza : (Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzdx;)Lcom/google/android/gms/ads/internal/client/zzl;
    //   383: invokeinterface zzaa : (Lcom/google/android/gms/ads/internal/client/zzl;)Z
    //   388: pop
    //   389: return
    //   390: astore_1
    //   391: aload_1
    //   392: invokestatic h : (Ljava/lang/Exception;)V
    //   395: return
    // Exception table:
    //   from	to	target	type
    //   0	76	390	android/os/RemoteException
    //   79	105	390	android/os/RemoteException
    //   105	137	390	android/os/RemoteException
    //   141	158	390	android/os/RemoteException
    //   158	163	390	android/os/RemoteException
    //   167	184	390	android/os/RemoteException
    //   184	211	390	android/os/RemoteException
    //   211	249	390	android/os/RemoteException
    //   256	263	338	android/os/RemoteException
    //   267	318	338	android/os/RemoteException
    //   321	335	338	android/os/RemoteException
    //   339	343	390	android/os/RemoteException
    //   346	357	390	android/os/RemoteException
    //   357	362	390	android/os/RemoteException
    //   367	389	390	android/os/RemoteException
  }
  
  public final void zzn() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzz(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzo() {
    if (this.c.getAndSet(true))
      return; 
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzA(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzp() {
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzB(); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzq(zza paramzza) {
    try {
      this.f = paramzza;
      zzbu zzbu1 = this.j;
      if (zzbu1 != null) {
        if (paramzza != null) {
          zzb zzb = new zzb(paramzza);
        } else {
          paramzza = null;
        } 
        zzbu1.zzC((zzbe)paramzza);
      } 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzr(AdListener paramAdListener) {
    this.g = paramAdListener;
    this.e.zza(paramAdListener);
  }
  
  public final void zzs(AdSize... paramVarArgs) {
    if (this.h == null) {
      zzt(paramVarArgs);
      return;
    } 
    throw new IllegalStateException("The ad size can only be set once on AdView.");
  }
  
  public final void zzt(AdSize... paramVarArgs) {
    this.h = paramVarArgs;
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzF(a(this.m.getContext(), this.h, this.n)); 
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
    } 
    this.m.requestLayout();
  }
  
  public final void zzu(String paramString) {
    if (this.l == null) {
      this.l = paramString;
      return;
    } 
    throw new IllegalStateException("The ad unit ID can only be set once on AdView.");
  }
  
  public final void zzv(AppEventListener paramAppEventListener) {
    try {
      this.i = paramAppEventListener;
      zzbu zzbu1 = this.j;
      if (zzbu1 != null) {
        if (paramAppEventListener != null) {
          d d = new d(paramAppEventListener);
        } else {
          paramAppEventListener = null;
        } 
        zzbu1.zzG((zzcb)paramAppEventListener);
      } 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzw(boolean paramBoolean) {
    this.o = paramBoolean;
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzN(paramBoolean); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzx(OnPaidEventListener paramOnPaidEventListener) {
    try {
      this.p = paramOnPaidEventListener;
      zzbu zzbu1 = this.j;
      if (zzbu1 != null)
        zzbu1.zzP(new zzfe(paramOnPaidEventListener)); 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final void zzy(VideoOptions paramVideoOptions) {
    this.k = paramVideoOptions;
    try {
      zzbu zzbu1 = this.j;
      if (zzbu1 != null) {
        zzfl zzfl;
        if (paramVideoOptions == null) {
          paramVideoOptions = null;
        } else {
          zzfl = new zzfl(paramVideoOptions);
        } 
        zzbu1.zzU(zzfl);
      } 
      return;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return;
    } 
  }
  
  public final boolean zzz(zzbu paramzzbu) {
    try {
      a a = paramzzbu.zzn();
      if (a == null)
        return false; 
      if (((View)b.b1(a)).getParent() != null)
        return false; 
      this.m.addView((View)b.b1(a));
      this.j = paramzzbu;
      return true;
    } catch (RemoteException remoteException) {
      l8.h((Exception)remoteException);
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzea.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */