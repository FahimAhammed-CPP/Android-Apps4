package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import q0.a;

public final class zzr implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    String str;
    int n = a.m(paramParcel);
    zzq[] arrayOfZzq2 = null;
    zzq[] arrayOfZzq1 = arrayOfZzq2;
    int m = 0;
    int k = 0;
    boolean bool9 = false;
    int j = 0;
    int i = 0;
    boolean bool8 = false;
    boolean bool7 = false;
    boolean bool6 = false;
    boolean bool5 = false;
    boolean bool4 = false;
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    while (paramParcel.dataPosition() < n) {
      int i1 = paramParcel.readInt();
      switch ((char)i1) {
        default:
          a.l(paramParcel, i1);
          continue;
        case '\020':
          bool1 = a.g(paramParcel, i1);
          continue;
        case '\017':
          bool2 = a.g(paramParcel, i1);
          continue;
        case '\016':
          bool3 = a.g(paramParcel, i1);
          continue;
        case '\r':
          bool4 = a.g(paramParcel, i1);
          continue;
        case '\f':
          bool5 = a.g(paramParcel, i1);
          continue;
        case '\013':
          bool6 = a.g(paramParcel, i1);
          continue;
        case '\n':
          bool7 = a.g(paramParcel, i1);
          continue;
        case '\t':
          bool8 = a.g(paramParcel, i1);
          continue;
        case '\b':
          arrayOfZzq1 = (zzq[])a.e(paramParcel, i1, zzq.CREATOR);
          continue;
        case '\007':
          i = a.i(paramParcel, i1);
          continue;
        case '\006':
          j = a.i(paramParcel, i1);
          continue;
        case '\005':
          bool9 = a.g(paramParcel, i1);
          continue;
        case '\004':
          k = a.i(paramParcel, i1);
          continue;
        case '\003':
          m = a.i(paramParcel, i1);
          continue;
        case '\002':
          break;
      } 
      str = a.c(paramParcel, i1);
    } 
    a.f(paramParcel, n);
    return new zzq(str, m, k, bool9, j, i, arrayOfZzq1, bool8, bool7, bool6, bool5, bool4, bool3, bool2, bool1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */