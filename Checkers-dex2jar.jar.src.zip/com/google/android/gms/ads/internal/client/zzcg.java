package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import w0.a;
import w0.c;

public final class zzcg extends a implements zzci {
  public zzcg(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IFullScreenContentCallback");
  }
  
  public final void zzb() {
    b1(Z0(), 5);
  }
  
  public final void zzc() {
    b1(Z0(), 3);
  }
  
  public final void zzd(zze paramzze) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzze);
    b1(parcel, 1);
  }
  
  public final void zze() {
    b1(Z0(), 4);
  }
  
  public final void zzf() {
    b1(Z0(), 2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */