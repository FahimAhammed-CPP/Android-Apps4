package com.google.android.gms.ads.internal.client;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

public final class zzek extends ContentProvider {
  public final void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic a : (Landroid/content/Context;)Lt0/d;
    //   4: sipush #128
    //   7: aload_1
    //   8: invokevirtual getPackageName : ()Ljava/lang/String;
    //   11: invokevirtual a : (ILjava/lang/String;)Landroid/content/pm/ApplicationInfo;
    //   14: getfield metaData : Landroid/os/Bundle;
    //   17: astore #5
    //   19: goto -> 47
    //   22: astore #5
    //   24: ldc 'Failed to load metadata: Package name not found.'
    //   26: astore #6
    //   28: goto -> 37
    //   31: astore #5
    //   33: ldc 'Failed to load metadata: Null pointer exception.'
    //   35: astore #6
    //   37: aload #6
    //   39: aload #5
    //   41: invokestatic d : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   44: aconst_null
    //   45: astore #5
    //   47: getstatic w0/s3.b : Lw0/s3;
    //   50: ifnonnull -> 63
    //   53: new w0/s3
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: putstatic w0/s3.b : Lw0/s3;
    //   63: getstatic w0/s3.b : Lw0/s3;
    //   66: astore #6
    //   68: aload #5
    //   70: ifnonnull -> 81
    //   73: ldc 'Metadata was null.'
    //   75: invokestatic c : (Ljava/lang/String;)V
    //   78: goto -> 227
    //   81: aload #5
    //   83: ldc 'com.google.android.gms.ads.APPLICATION_ID'
    //   85: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   88: checkcast java/lang/String
    //   91: astore #7
    //   93: aload #5
    //   95: ldc 'com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT'
    //   97: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast java/lang/Boolean
    //   103: astore #8
    //   105: aload #5
    //   107: ldc 'com.google.android.gms.ads.INTEGRATION_MANAGER'
    //   109: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   112: checkcast java/lang/String
    //   115: astore #9
    //   117: aload #7
    //   119: ifnull -> 206
    //   122: aload #7
    //   124: ldc '^ca-app-pub-[0-9]{16}~[0-9]{10}$'
    //   126: invokevirtual matches : (Ljava/lang/String;)Z
    //   129: ifeq -> 196
    //   132: ldc 'Publisher provided Google AdMob App ID in manifest: '
    //   134: aload #7
    //   136: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   139: invokestatic b : (Ljava/lang/String;)V
    //   142: aload #8
    //   144: ifnull -> 155
    //   147: aload #8
    //   149: invokevirtual booleanValue : ()Z
    //   152: ifne -> 227
    //   155: aload #6
    //   157: getfield a : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   160: iconst_0
    //   161: iconst_1
    //   162: invokevirtual compareAndSet : (ZZ)Z
    //   165: ifne -> 171
    //   168: goto -> 227
    //   171: new java/lang/Thread
    //   174: dup
    //   175: new w0/r3
    //   178: dup
    //   179: aload #6
    //   181: aload_1
    //   182: aload #7
    //   184: invokespecial <init> : (Lw0/s3;Landroid/content/Context;Ljava/lang/String;)V
    //   187: invokespecial <init> : (Ljava/lang/Runnable;)V
    //   190: invokevirtual start : ()V
    //   193: goto -> 227
    //   196: new java/lang/IllegalStateException
    //   199: dup
    //   200: ldc '\\n\\n******************************************************************************\\n* Invalid application ID. Follow instructions here:                          *\\n* https://googlemobileadssdk.page.link/admob-android-update-manifest         *\\n* to find your app ID.                                                       *\\n* Google Ad Manager publishers should follow instructions here:              *\\n* https://googlemobileadssdk.page.link/ad-manager-android-update-manifest.   *\\n******************************************************************************\\n\\n'
    //   202: invokespecial <init> : (Ljava/lang/String;)V
    //   205: athrow
    //   206: aload #9
    //   208: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   211: ifne -> 280
    //   214: ldc 'The Google Mobile Ads SDK is integrated by '
    //   216: aload #9
    //   218: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   221: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   224: invokestatic b : (Ljava/lang/String;)V
    //   227: aload #5
    //   229: ifnonnull -> 235
    //   232: goto -> 273
    //   235: aload #5
    //   237: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_INITIALIZATION'
    //   239: iconst_0
    //   240: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   243: istore_3
    //   244: aload #5
    //   246: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_AD_LOADING'
    //   248: iconst_0
    //   249: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   252: istore #4
    //   254: iload_3
    //   255: ifeq -> 263
    //   258: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_INITIALIZATION is enabled'
    //   260: invokestatic b : (Ljava/lang/String;)V
    //   263: iload #4
    //   265: ifeq -> 273
    //   268: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_AD_LOADING is enabled'
    //   270: invokestatic b : (Ljava/lang/String;)V
    //   273: aload_0
    //   274: aload_1
    //   275: aload_2
    //   276: invokespecial attachInfo : (Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   279: return
    //   280: new java/lang/IllegalStateException
    //   283: dup
    //   284: ldc '\\n\\n******************************************************************************\\n* The Google Mobile Ads SDK was initialized incorrectly. AdMob publishers    *\\n* should follow the instructions here:                                       *\\n* https://googlemobileadssdk.page.link/admob-android-update-manifest         *\\n* to add a valid App ID inside the AndroidManifest.                          *\\n* Google Ad Manager publishers should follow instructions here:              *\\n* https://googlemobileadssdk.page.link/ad-manager-android-update-manifest.   *\\n******************************************************************************\\n\\n'
    //   286: invokespecial <init> : (Ljava/lang/String;)V
    //   289: athrow
    //   290: astore_1
    //   291: new java/lang/IllegalStateException
    //   294: dup
    //   295: ldc 'The com.google.android.gms.ads.INTEGRATION_MANAGER metadata must have a String value.'
    //   297: aload_1
    //   298: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   301: athrow
    //   302: astore_1
    //   303: new java/lang/IllegalStateException
    //   306: dup
    //   307: ldc 'The com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT metadata must have a boolean value.'
    //   309: aload_1
    //   310: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   313: athrow
    //   314: astore_1
    //   315: new java/lang/IllegalStateException
    //   318: dup
    //   319: ldc 'The com.google.android.gms.ads.APPLICATION_ID metadata must have a String value.'
    //   321: aload_1
    //   322: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   325: athrow
    // Exception table:
    //   from	to	target	type
    //   0	19	31	java/lang/NullPointerException
    //   0	19	22	android/content/pm/PackageManager$NameNotFoundException
    //   81	93	314	java/lang/ClassCastException
    //   93	105	302	java/lang/ClassCastException
    //   105	117	290	java/lang/ClassCastException
  }
  
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public final String getType(Uri paramUri) {
    return null;
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public final boolean onCreate() {
    return false;
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    return null;
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzek.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */