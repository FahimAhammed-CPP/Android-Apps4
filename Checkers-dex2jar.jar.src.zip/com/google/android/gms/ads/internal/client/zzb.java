package com.google.android.gms.ads.internal.client;

public final class zzb extends zzbd {
  public final zza a;
  
  public zzb(zza paramzza) {
    this.a = paramzza;
  }
  
  public final void zzb() {
    this.a.onAdClicked();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */