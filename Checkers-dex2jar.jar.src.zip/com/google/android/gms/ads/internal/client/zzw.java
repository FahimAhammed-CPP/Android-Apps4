package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdOrientation;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;

public final class zzw extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzw> CREATOR = new zzx();
  
  @AppOpenAdOrientation
  public final int zza;
  
  public zzw(@AppOpenAdOrientation int paramInt) {
    this.zza = paramInt;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.g(paramParcel, 2, this.zza);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */