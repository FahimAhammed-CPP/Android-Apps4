package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import w0.a;

public final class zzbc extends a implements zzbe {
  public zzbc(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdClickListener");
  }
  
  public final void zzb() {
    b1(Z0(), 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */