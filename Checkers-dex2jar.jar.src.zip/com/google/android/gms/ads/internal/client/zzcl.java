package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import w0.w3;

public interface zzcl extends IInterface {
  w3 getAdapterCreator();
  
  zzen getLiteSdkVersion();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */