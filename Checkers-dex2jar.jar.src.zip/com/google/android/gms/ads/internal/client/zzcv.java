package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import w0.b;

public abstract class zzcv extends b implements zzcw {
  public zzcv() {
    super("com.google.android.gms.ads.internal.client.IMuteThisAdReason");
  }
  
  public static zzcw zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMuteThisAdReason");
    return (iInterface instanceof zzcw) ? (zzcw)iInterface : new zzcu(paramIBinder);
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    String str;
    if (paramInt != 1) {
      if (paramInt != 2)
        return false; 
      str = zzf();
    } else {
      str = zze();
    } 
    paramParcel2.writeNoException();
    paramParcel2.writeString(str);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */