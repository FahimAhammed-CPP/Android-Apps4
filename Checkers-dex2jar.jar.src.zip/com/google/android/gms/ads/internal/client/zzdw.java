package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.query.AdInfo;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import p0.e;
import w0.l8;

public final class zzdw {
  public final HashSet a = new HashSet();
  
  public final Bundle b = new Bundle();
  
  public final HashMap c = new HashMap<Object, Object>();
  
  public final HashSet d = new HashSet();
  
  public final Bundle e = new Bundle();
  
  public final HashSet f = new HashSet();
  
  public Date g;
  
  public String h;
  
  public final ArrayList i = new ArrayList();
  
  public int j = -1;
  
  public String k;
  
  public String l;
  
  public int m = -1;
  
  public boolean n;
  
  public AdInfo o;
  
  public String p;
  
  public int q = 60000;
  
  @Deprecated
  public final void zzA(Date paramDate) {
    this.g = paramDate;
  }
  
  public final void zzB(String paramString) {
    this.h = paramString;
  }
  
  @Deprecated
  public final void zzC(int paramInt) {
    this.j = paramInt;
  }
  
  public final void zzD(int paramInt) {
    this.q = paramInt;
  }
  
  @Deprecated
  public final void zzE(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public final void zzF(List paramList) {
    this.i.clear();
    for (String str : paramList) {
      if (TextUtils.isEmpty(str)) {
        l8.f("neighboring content URL should not be null or empty");
        continue;
      } 
      this.i.add(str);
    } 
  }
  
  public final void zzG(String paramString) {
    this.k = paramString;
  }
  
  public final void zzH(String paramString) {
    this.l = paramString;
  }
  
  @Deprecated
  public final void zzI(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void zzq(String paramString) {
    this.f.add(paramString);
  }
  
  public final void zzr(Class paramClass, Bundle paramBundle) {
    if (this.b.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter") == null)
      this.b.putBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter", new Bundle()); 
    Bundle bundle = this.b.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
    e.g(bundle);
    bundle.putBundle(paramClass.getName(), paramBundle);
  }
  
  public final void zzs(String paramString1, String paramString2) {
    this.e.putString(paramString1, paramString2);
  }
  
  public final void zzt(String paramString) {
    this.a.add(paramString);
  }
  
  public final void zzu(Class paramClass, Bundle paramBundle) {
    this.b.putBundle(paramClass.getName(), paramBundle);
  }
  
  @Deprecated
  public final void zzv(NetworkExtras paramNetworkExtras) {
    this.c.put(paramNetworkExtras.getClass(), paramNetworkExtras);
  }
  
  public final void zzw(String paramString) {
    this.d.add(paramString);
  }
  
  public final void zzx(String paramString) {
    this.d.remove("B3EEABB8EE11C2BE770B684D95219ECB");
  }
  
  public final void zzy(AdInfo paramAdInfo) {
    this.o = paramAdInfo;
  }
  
  public final void zzz(String paramString) {
    this.p = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */