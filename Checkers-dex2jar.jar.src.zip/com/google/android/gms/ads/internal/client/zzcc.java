package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import u0.a;
import w0.a;
import w0.a6;
import w0.a8;
import w0.c;
import w0.c1;
import w0.d1;
import w0.d3;
import w0.f7;
import w0.g7;
import w0.r5;
import w0.s5;
import w0.t5;
import w0.v2;
import w0.w0;
import w0.w2;
import w0.w3;
import w0.w6;
import w0.x0;
import w0.x2;
import w0.y5;
import w0.y7;
import w0.z5;
import w0.z7;

public final class zzcc extends a implements zzce {
  public zzcc(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IClientApi");
  }
  
  public final zzbq zzb(a parama, String paramString, w3 paramw3, int paramInt) {
    zzbq zzbq;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 3);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      if (iInterface instanceof zzbq) {
        zzbq = (zzbq)iInterface;
      } else {
        zzbq = new zzbo((IBinder)zzbq);
      } 
    } 
    parcel1.recycle();
    return zzbq;
  }
  
  public final zzbu zzc(a parama, zzq paramzzq, String paramString, w3 paramw3, int paramInt) {
    zzbu zzbu;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.c(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 13);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbu) {
        zzbu = (zzbu)iInterface;
      } else {
        zzbu = new zzbs((IBinder)zzbu);
      } 
    } 
    parcel1.recycle();
    return zzbu;
  }
  
  public final zzbu zzd(a parama, zzq paramzzq, String paramString, w3 paramw3, int paramInt) {
    zzbu zzbu;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.c(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 1);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbu) {
        zzbu = (zzbu)iInterface;
      } else {
        zzbu = new zzbs((IBinder)zzbu);
      } 
    } 
    parcel1.recycle();
    return zzbu;
  }
  
  public final zzbu zze(a parama, zzq paramzzq, String paramString, w3 paramw3, int paramInt) {
    zzbu zzbu;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.c(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbu) {
        zzbu = (zzbu)iInterface;
      } else {
        zzbu = new zzbs((IBinder)zzbu);
      } 
    } 
    parcel1.recycle();
    return zzbu;
  }
  
  public final zzbu zzf(a parama, zzq paramzzq, String paramString, int paramInt) {
    zzbu zzbu;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.c(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 10);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbu) {
        zzbu = (zzbu)iInterface;
      } else {
        zzbu = new zzbs((IBinder)zzbu);
      } 
    } 
    parcel1.recycle();
    return zzbu;
  }
  
  public final zzco zzg(a parama, int paramInt) {
    zzco zzco;
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)parama);
    parcel.writeInt(223712000);
    parcel = a1(parcel, 9);
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
      if (iInterface instanceof zzco) {
        zzco = (zzco)iInterface;
      } else {
        zzco = new zzcm((IBinder)zzco);
      } 
    } 
    parcel.recycle();
    return zzco;
  }
  
  public final zzdj zzh(a parama, w3 paramw3, int paramInt) {
    zzdj zzdj;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 17);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOutOfContextTester");
      if (iInterface instanceof zzdj) {
        zzdj = (zzdj)iInterface;
      } else {
        zzdj = new zzdh((IBinder)zzdj);
      } 
    } 
    parcel1.recycle();
    return zzdj;
  }
  
  public final x0 zzi(a parama1, a parama2) {
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama1);
    c.e(parcel2, (IInterface)parama2);
    Parcel parcel1 = a1(parcel2, 5);
    x0 x0 = w0.zzbD(parcel1.readStrongBinder());
    parcel1.recycle();
    return x0;
  }
  
  public final d1 zzj(a parama1, a parama2, a parama3) {
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama1);
    c.e(parcel2, (IInterface)parama2);
    c.e(parcel2, (IInterface)parama3);
    Parcel parcel1 = a1(parcel2, 11);
    d1 d1 = c1.zze(parcel1.readStrongBinder());
    parcel1.recycle();
    return d1;
  }
  
  public final x2 zzk(a parama, w3 paramw3, int paramInt, v2 paramv2) {
    w2 w2;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    c.e(parcel2, (IInterface)paramv2);
    Parcel parcel1 = a1(parcel2, 16);
    IBinder iBinder = parcel1.readStrongBinder();
    paramInt = d3.a;
    if (iBinder == null) {
      iBinder = null;
    } else {
      x2 x2;
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.h5.client.IH5AdsManager");
      if (iInterface instanceof x2) {
        x2 = (x2)iInterface;
      } else {
        w2 = new w2((IBinder)x2);
      } 
    } 
    parcel1.recycle();
    return (x2)w2;
  }
  
  public final t5 zzl(a parama, w3 paramw3, int paramInt) {
    r5 r5;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 15);
    IBinder iBinder = parcel1.readStrongBinder();
    paramInt = s5.a;
    if (iBinder == null) {
      iBinder = null;
    } else {
      t5 t5;
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.offline.IOfflineUtils");
      if (iInterface instanceof t5) {
        t5 = (t5)iInterface;
      } else {
        r5 = new r5((IBinder)t5);
      } 
    } 
    parcel1.recycle();
    return (t5)r5;
  }
  
  public final a6 zzm(a parama) {
    y5 y5;
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)parama);
    parcel = a1(parcel, 8);
    IBinder iBinder = parcel.readStrongBinder();
    int i = z5.a;
    if (iBinder == null) {
      iBinder = null;
    } else {
      a6 a6;
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.overlay.client.IAdOverlay");
      if (iInterface instanceof a6) {
        a6 = (a6)iInterface;
      } else {
        y5 = new y5((IBinder)a6);
      } 
    } 
    parcel.recycle();
    return (a6)y5;
  }
  
  public final w6 zzn(a parama, w3 paramw3, int paramInt) {
    throw null;
  }
  
  public final g7 zzo(a parama, String paramString, w3 paramw3, int paramInt) {
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    parcel2.writeString(paramString);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 12);
    g7 g7 = f7.zzq(parcel1.readStrongBinder());
    parcel1.recycle();
    return g7;
  }
  
  public final a8 zzp(a parama, w3 paramw3, int paramInt) {
    y7 y7;
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    c.e(parcel2, (IInterface)paramw3);
    parcel2.writeInt(223712000);
    Parcel parcel1 = a1(parcel2, 14);
    IBinder iBinder = parcel1.readStrongBinder();
    paramInt = z7.a;
    if (iBinder == null) {
      iBinder = null;
    } else {
      a8 a8;
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.signals.ISignalGenerator");
      if (iInterface instanceof a8) {
        a8 = (a8)iInterface;
      } else {
        y7 = new y7((IBinder)a8);
      } 
    } 
    parcel1.recycle();
    return (a8)y7;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */