package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;

public final class zzq extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzq> CREATOR = new zzr();
  
  public final String zza;
  
  public final int zzb;
  
  public final int zzc;
  
  public final boolean zzd;
  
  public final int zze;
  
  public final int zzf;
  
  public final zzq[] zzg;
  
  public final boolean zzh;
  
  public final boolean zzi;
  
  public boolean zzj;
  
  public boolean zzk;
  
  public boolean zzl;
  
  public boolean zzm;
  
  public boolean zzn;
  
  public boolean zzo;
  
  public zzq() {
    this("interstitial_mb", 0, 0, true, 0, 0, null, false, false, false, false, false, false, false, false);
  }
  
  public zzq(Context paramContext, AdSize paramAdSize) {
    this(paramContext, new AdSize[] { paramAdSize });
  }
  
  public zzq(Context paramContext, AdSize[] paramArrayOfAdSize) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_2
    //   5: iconst_0
    //   6: aaload
    //   7: astore #16
    //   9: aload_0
    //   10: iconst_0
    //   11: putfield zzd : Z
    //   14: aload #16
    //   16: invokevirtual isFluid : ()Z
    //   19: istore #14
    //   21: aload_0
    //   22: iload #14
    //   24: putfield zzi : Z
    //   27: aload_0
    //   28: aload #16
    //   30: invokestatic zzf : (Lcom/google/android/gms/ads/AdSize;)Z
    //   33: putfield zzm : Z
    //   36: aload_0
    //   37: aload #16
    //   39: invokestatic zzg : (Lcom/google/android/gms/ads/AdSize;)Z
    //   42: putfield zzn : Z
    //   45: aload #16
    //   47: invokestatic zzh : (Lcom/google/android/gms/ads/AdSize;)Z
    //   50: istore #15
    //   52: aload_0
    //   53: iload #15
    //   55: putfield zzo : Z
    //   58: iload #14
    //   60: ifeq -> 87
    //   63: getstatic com/google/android/gms/ads/AdSize.BANNER : Lcom/google/android/gms/ads/AdSize;
    //   66: astore #17
    //   68: aload_0
    //   69: aload #17
    //   71: invokevirtual getWidth : ()I
    //   74: putfield zze : I
    //   77: aload #17
    //   79: invokevirtual getHeight : ()I
    //   82: istore #7
    //   84: goto -> 153
    //   87: aload_0
    //   88: getfield zzn : Z
    //   91: ifeq -> 113
    //   94: aload_0
    //   95: aload #16
    //   97: invokevirtual getWidth : ()I
    //   100: putfield zze : I
    //   103: aload #16
    //   105: invokestatic zza : (Lcom/google/android/gms/ads/AdSize;)I
    //   108: istore #7
    //   110: goto -> 153
    //   113: iload #15
    //   115: ifeq -> 137
    //   118: aload_0
    //   119: aload #16
    //   121: invokevirtual getWidth : ()I
    //   124: putfield zze : I
    //   127: aload #16
    //   129: invokestatic zzb : (Lcom/google/android/gms/ads/AdSize;)I
    //   132: istore #7
    //   134: goto -> 153
    //   137: aload_0
    //   138: aload #16
    //   140: invokevirtual getWidth : ()I
    //   143: putfield zze : I
    //   146: aload #16
    //   148: invokevirtual getHeight : ()I
    //   151: istore #7
    //   153: aload_0
    //   154: iload #7
    //   156: putfield zzb : I
    //   159: aload_0
    //   160: getfield zze : I
    //   163: iconst_m1
    //   164: if_icmpne -> 173
    //   167: iconst_1
    //   168: istore #10
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #10
    //   176: iload #7
    //   178: bipush #-2
    //   180: if_icmpne -> 189
    //   183: iconst_1
    //   184: istore #11
    //   186: goto -> 192
    //   189: iconst_0
    //   190: istore #11
    //   192: aload_1
    //   193: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   196: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   199: astore #17
    //   201: iload #10
    //   203: ifeq -> 486
    //   206: invokestatic zzb : ()Lw0/i8;
    //   209: pop
    //   210: aload_1
    //   211: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   214: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   217: getfield orientation : I
    //   220: iconst_2
    //   221: if_icmpeq -> 227
    //   224: goto -> 407
    //   227: aload_1
    //   228: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   231: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   234: astore #18
    //   236: aload #18
    //   238: getfield heightPixels : I
    //   241: i2f
    //   242: aload #18
    //   244: getfield density : F
    //   247: fdiv
    //   248: f2i
    //   249: sipush #600
    //   252: if_icmpge -> 407
    //   255: invokestatic zzb : ()Lw0/i8;
    //   258: pop
    //   259: aload_1
    //   260: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   263: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   266: astore #18
    //   268: aload_1
    //   269: ldc 'window'
    //   271: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   274: checkcast android/view/WindowManager
    //   277: astore #19
    //   279: aload #19
    //   281: ifnull -> 407
    //   284: aload #19
    //   286: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   291: astore #19
    //   293: aload #19
    //   295: aload #18
    //   297: invokevirtual getRealMetrics : (Landroid/util/DisplayMetrics;)V
    //   300: aload #18
    //   302: getfield heightPixels : I
    //   305: istore #8
    //   307: aload #18
    //   309: getfield widthPixels : I
    //   312: istore #9
    //   314: aload #19
    //   316: aload #18
    //   318: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
    //   321: aload #18
    //   323: getfield heightPixels : I
    //   326: istore #12
    //   328: aload #18
    //   330: getfield widthPixels : I
    //   333: istore #13
    //   335: iload #12
    //   337: iload #8
    //   339: if_icmpne -> 407
    //   342: iload #13
    //   344: iload #9
    //   346: if_icmpne -> 407
    //   349: aload #17
    //   351: getfield widthPixels : I
    //   354: istore #9
    //   356: invokestatic zzb : ()Lw0/i8;
    //   359: pop
    //   360: aload_1
    //   361: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   364: ldc 'navigation_bar_width'
    //   366: ldc 'dimen'
    //   368: ldc 'android'
    //   370: invokevirtual getIdentifier : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   373: istore #8
    //   375: iload #8
    //   377: ifle -> 394
    //   380: aload_1
    //   381: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   384: iload #8
    //   386: invokevirtual getDimensionPixelSize : (I)I
    //   389: istore #8
    //   391: goto -> 397
    //   394: iconst_0
    //   395: istore #8
    //   397: iload #9
    //   399: iload #8
    //   401: isub
    //   402: istore #8
    //   404: goto -> 414
    //   407: aload #17
    //   409: getfield widthPixels : I
    //   412: istore #8
    //   414: aload_0
    //   415: iload #8
    //   417: putfield zzf : I
    //   420: iload #8
    //   422: i2f
    //   423: aload #17
    //   425: getfield density : F
    //   428: fdiv
    //   429: f2d
    //   430: dstore_3
    //   431: dload_3
    //   432: d2i
    //   433: istore #8
    //   435: iload #8
    //   437: i2d
    //   438: dstore #5
    //   440: dload_3
    //   441: invokestatic isNaN : (D)Z
    //   444: pop
    //   445: dload #5
    //   447: invokestatic isNaN : (D)Z
    //   450: pop
    //   451: dload_3
    //   452: invokestatic isNaN : (D)Z
    //   455: pop
    //   456: dload #5
    //   458: invokestatic isNaN : (D)Z
    //   461: pop
    //   462: iload #8
    //   464: istore #9
    //   466: dload_3
    //   467: dload #5
    //   469: dsub
    //   470: ldc2_w 0.01
    //   473: dcmpl
    //   474: iflt -> 521
    //   477: iload #8
    //   479: iconst_1
    //   480: iadd
    //   481: istore #9
    //   483: goto -> 521
    //   486: aload_0
    //   487: getfield zze : I
    //   490: istore #9
    //   492: invokestatic zzb : ()Lw0/i8;
    //   495: pop
    //   496: aload_0
    //   497: getfield zze : I
    //   500: istore #8
    //   502: getstatic w0/i8.a : Lw0/w8;
    //   505: astore #18
    //   507: aload_0
    //   508: iconst_1
    //   509: iload #8
    //   511: i2f
    //   512: aload #17
    //   514: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   517: f2i
    //   518: putfield zzf : I
    //   521: iload #11
    //   523: ifeq -> 578
    //   526: aload #17
    //   528: getfield heightPixels : I
    //   531: i2f
    //   532: aload #17
    //   534: getfield density : F
    //   537: fdiv
    //   538: f2i
    //   539: istore #8
    //   541: iload #8
    //   543: sipush #400
    //   546: if_icmpgt -> 556
    //   549: bipush #32
    //   551: istore #8
    //   553: goto -> 582
    //   556: iload #8
    //   558: sipush #720
    //   561: if_icmpgt -> 571
    //   564: bipush #50
    //   566: istore #8
    //   568: goto -> 582
    //   571: bipush #90
    //   573: istore #8
    //   575: goto -> 582
    //   578: iload #7
    //   580: istore #8
    //   582: invokestatic zzb : ()Lw0/i8;
    //   585: pop
    //   586: getstatic w0/i8.a : Lw0/w8;
    //   589: astore #18
    //   591: aload_0
    //   592: iconst_1
    //   593: iload #8
    //   595: i2f
    //   596: aload #17
    //   598: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   601: f2i
    //   602: putfield zzc : I
    //   605: iload #10
    //   607: ifne -> 714
    //   610: iload #11
    //   612: ifeq -> 618
    //   615: goto -> 714
    //   618: aload_0
    //   619: getfield zzn : Z
    //   622: ifne -> 657
    //   625: aload_0
    //   626: getfield zzo : Z
    //   629: ifeq -> 635
    //   632: goto -> 657
    //   635: iload #14
    //   637: ifeq -> 647
    //   640: ldc '320x50_mb'
    //   642: astore #16
    //   644: goto -> 762
    //   647: aload #16
    //   649: invokevirtual toString : ()Ljava/lang/String;
    //   652: astore #16
    //   654: goto -> 762
    //   657: aload_0
    //   658: getfield zze : I
    //   661: istore #8
    //   663: new java/lang/StringBuilder
    //   666: dup
    //   667: invokespecial <init> : ()V
    //   670: astore #16
    //   672: aload #16
    //   674: iload #8
    //   676: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   679: pop
    //   680: aload #16
    //   682: ldc 'x'
    //   684: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   687: pop
    //   688: aload #16
    //   690: iload #7
    //   692: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   695: pop
    //   696: aload #16
    //   698: ldc '_as'
    //   700: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   703: pop
    //   704: aload #16
    //   706: invokevirtual toString : ()Ljava/lang/String;
    //   709: astore #16
    //   711: goto -> 762
    //   714: new java/lang/StringBuilder
    //   717: dup
    //   718: invokespecial <init> : ()V
    //   721: astore #16
    //   723: aload #16
    //   725: iload #9
    //   727: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   730: pop
    //   731: aload #16
    //   733: ldc 'x'
    //   735: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   738: pop
    //   739: aload #16
    //   741: iload #8
    //   743: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   746: pop
    //   747: aload #16
    //   749: ldc '_as'
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: pop
    //   755: aload #16
    //   757: invokevirtual toString : ()Ljava/lang/String;
    //   760: astore #16
    //   762: aload_0
    //   763: aload #16
    //   765: putfield zza : Ljava/lang/String;
    //   768: aload_2
    //   769: arraylength
    //   770: istore #7
    //   772: iload #7
    //   774: iconst_1
    //   775: if_icmple -> 825
    //   778: aload_0
    //   779: iload #7
    //   781: anewarray com/google/android/gms/ads/internal/client/zzq
    //   784: putfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   787: iconst_0
    //   788: istore #7
    //   790: iload #7
    //   792: aload_2
    //   793: arraylength
    //   794: if_icmpge -> 830
    //   797: aload_0
    //   798: getfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   801: iload #7
    //   803: new com/google/android/gms/ads/internal/client/zzq
    //   806: dup
    //   807: aload_1
    //   808: aload_2
    //   809: iload #7
    //   811: aaload
    //   812: invokespecial <init> : (Landroid/content/Context;Lcom/google/android/gms/ads/AdSize;)V
    //   815: aastore
    //   816: iload #7
    //   818: iconst_1
    //   819: iadd
    //   820: istore #7
    //   822: goto -> 790
    //   825: aload_0
    //   826: aconst_null
    //   827: putfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   830: aload_0
    //   831: iconst_0
    //   832: putfield zzh : Z
    //   835: aload_0
    //   836: iconst_0
    //   837: putfield zzj : Z
    //   840: return
  }
  
  public zzq(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, int paramInt3, int paramInt4, zzq[] paramArrayOfzzq, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9) {
    this.zza = paramString;
    this.zzb = paramInt1;
    this.zzc = paramInt2;
    this.zzd = paramBoolean1;
    this.zze = paramInt3;
    this.zzf = paramInt4;
    this.zzg = paramArrayOfzzq;
    this.zzh = paramBoolean2;
    this.zzi = paramBoolean3;
    this.zzj = paramBoolean4;
    this.zzk = paramBoolean5;
    this.zzl = paramBoolean6;
    this.zzm = paramBoolean7;
    this.zzn = paramBoolean8;
    this.zzo = paramBoolean9;
  }
  
  public static int zza(DisplayMetrics paramDisplayMetrics) {
    float f1 = paramDisplayMetrics.heightPixels;
    float f2 = paramDisplayMetrics.density;
    int i = (int)(f1 / f2);
    if (i <= 400) {
      i = 32;
    } else if (i <= 720) {
      i = 50;
    } else {
      i = 90;
    } 
    return (int)(i * f2);
  }
  
  public static zzq zzb() {
    return new zzq("interstitial_mb", 0, 0, false, 0, 0, null, false, false, false, false, true, false, false, false);
  }
  
  public static zzq zzc() {
    return new zzq("320x50_mb", 0, 0, false, 0, 0, null, true, false, false, false, false, false, false, false);
  }
  
  public static zzq zzd() {
    return new zzq("reward_mb", 0, 0, true, 0, 0, null, false, false, false, false, false, false, false, false);
  }
  
  public static zzq zze() {
    return new zzq("invalid", 0, 0, false, 0, 0, null, false, false, false, true, false, false, false, false);
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.m(paramParcel, 20293);
    b.j(paramParcel, 2, this.zza);
    b.g(paramParcel, 3, this.zzb);
    b.g(paramParcel, 4, this.zzc);
    b.d(paramParcel, 5, this.zzd);
    b.g(paramParcel, 6, this.zze);
    b.g(paramParcel, 7, this.zzf);
    b.l(paramParcel, 8, (Parcelable[])this.zzg, paramInt);
    b.d(paramParcel, 9, this.zzh);
    b.d(paramParcel, 10, this.zzi);
    b.d(paramParcel, 11, this.zzj);
    b.d(paramParcel, 12, this.zzk);
    b.d(paramParcel, 13, this.zzl);
    b.d(paramParcel, 14, this.zzm);
    b.d(paramParcel, 15, this.zzn);
    b.d(paramParcel, 16, this.zzo);
    b.v(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */