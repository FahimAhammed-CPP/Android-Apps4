package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import com.google.android.gms.internal.ads.zzcdf;
import u0.a;
import w0.d7;
import w0.f7;
import w0.i8;
import w0.j7;
import w0.l8;
import w0.n7;
import w0.o7;

public final class zzfc extends f7 {
  public final Bundle zzb() {
    return new Bundle();
  }
  
  public final zzdn zzc() {
    return null;
  }
  
  public final d7 zzd() {
    return null;
  }
  
  public final String zze() {
    return "";
  }
  
  public final void zzf(zzl paramzzl, n7 paramn7) {
    l8.c("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
    i8.a.post(new zzfb(paramn7));
  }
  
  public final void zzg(zzl paramzzl, n7 paramn7) {
    l8.c("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
    i8.a.post(new zzfb(paramn7));
  }
  
  public final void zzh(boolean paramBoolean) {}
  
  public final void zzi(zzdd paramzzdd) {}
  
  public final void zzj(zzdg paramzzdg) {}
  
  public final void zzk(j7 paramj7) {}
  
  public final void zzl(zzcdf paramzzcdf) {}
  
  public final void zzm(a parama) {}
  
  public final void zzn(a parama, boolean paramBoolean) {}
  
  public final boolean zzo() {
    return false;
  }
  
  public final void zzp(o7 paramo7) {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */