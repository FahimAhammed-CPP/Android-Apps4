package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import u0.a;
import w0.b;
import w0.c;

public abstract class zzdi extends b implements zzdj {
  public zzdi() {
    super("com.google.android.gms.ads.internal.client.IOutOfContextTester");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt == 1) {
      String str = paramParcel1.readString();
      a a1 = a.a.a1(paramParcel1.readStrongBinder());
      a a2 = a.a.a1(paramParcel1.readStrongBinder());
      c.b(paramParcel1);
      zze(str, a1, a2);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */