package com.google.android.gms.ads.internal.client;

import java.util.Collections;
import java.util.List;
import u0.a;
import w0.i8;
import w0.j3;
import w0.l8;
import w0.w3;

public final class zzey extends zzcn {
  public j3 a;
  
  public final float zze() {
    return 1.0F;
  }
  
  public final String zzf() {
    return "";
  }
  
  public final List zzg() {
    return Collections.emptyList();
  }
  
  public final void zzh(String paramString) {}
  
  public final void zzi() {}
  
  public final void zzj(boolean paramBoolean) {}
  
  public final void zzk() {
    l8.c("The initialization is not processed because MobileAdsSettingsManager is not created successfully.");
    i8.a.post(new zzex(this));
  }
  
  public final void zzl(String paramString, a parama) {}
  
  public final void zzm(zzda paramzzda) {}
  
  public final void zzn(a parama, String paramString) {}
  
  public final void zzo(w3 paramw3) {}
  
  public final void zzp(boolean paramBoolean) {}
  
  public final void zzq(float paramFloat) {}
  
  public final void zzr(String paramString) {}
  
  public final void zzs(j3 paramj3) {
    this.a = paramj3;
  }
  
  public final void zzt(zzff paramzzff) {}
  
  public final boolean zzu() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */