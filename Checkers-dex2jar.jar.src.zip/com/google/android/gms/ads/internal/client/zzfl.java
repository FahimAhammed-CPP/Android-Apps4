package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import t0.b;

public final class zzfl extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzfl> CREATOR = new zzfm();
  
  public final boolean zza;
  
  public final boolean zzb;
  
  public final boolean zzc;
  
  public zzfl(VideoOptions paramVideoOptions) {
    this(paramVideoOptions.getStartMuted(), paramVideoOptions.getCustomControlsRequested(), paramVideoOptions.getClickToExpandRequested());
  }
  
  public zzfl(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    this.zza = paramBoolean1;
    this.zzb = paramBoolean2;
    this.zzc = paramBoolean3;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.m(paramParcel, 20293);
    b.d(paramParcel, 2, this.zza);
    b.d(paramParcel, 3, this.zzb);
    b.d(paramParcel, 4, this.zzc);
    b.v(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */