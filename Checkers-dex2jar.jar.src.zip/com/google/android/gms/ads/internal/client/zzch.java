package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import w0.b;
import w0.c;

public abstract class zzch extends b implements zzci {
  public zzch() {
    super("com.google.android.gms.ads.internal.client.IFullScreenContentCallback");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            if (paramInt != 5)
              return false; 
            zzb();
          } else {
            zze();
          } 
        } else {
          zzc();
        } 
      } else {
        zzf();
      } 
    } else {
      zze zze = (zze)c.a(paramParcel1, zze.CREATOR);
      c.b(paramParcel1);
      zzd(zze);
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */