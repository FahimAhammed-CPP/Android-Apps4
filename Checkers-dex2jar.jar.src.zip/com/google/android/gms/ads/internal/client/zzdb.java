package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import w0.a;

public final class zzdb extends a implements zzdd {
  public zzdb(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOnAdMetadataChangedListener");
  }
  
  public final void zze() {
    b1(Z0(), 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */