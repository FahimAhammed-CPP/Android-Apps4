package com.google.android.gms.ads.internal.client;

import android.content.Context;
import w0.t3;
import w0.w3;

public class LiteSdkInfo extends zzck {
  public LiteSdkInfo(Context paramContext) {}
  
  public w3 getAdapterCreator() {
    return (w3)new t3();
  }
  
  public zzen getLiteSdkVersion() {
    return new zzen(223712200, 223712000, "21.4.0");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\LiteSdkInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */