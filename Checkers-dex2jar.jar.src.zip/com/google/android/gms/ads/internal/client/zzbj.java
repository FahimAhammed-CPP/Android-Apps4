package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import w0.b;
import w0.c;

public abstract class zzbj extends b implements zzbk {
  public zzbj() {
    super("com.google.android.gms.ads.internal.client.IAdLoadCallback");
  }
  
  public final boolean Z0(int paramInt, Parcel paramParcel1, Parcel paramParcel2) {
    if (paramInt != 1) {
      if (paramInt != 2)
        return false; 
      zze zze = (zze)c.a(paramParcel1, zze.CREATOR);
      c.b(paramParcel1);
      zzb(zze);
    } else {
      zzc();
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */