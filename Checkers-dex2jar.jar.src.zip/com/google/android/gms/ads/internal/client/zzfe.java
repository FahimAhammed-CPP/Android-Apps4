package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.OnPaidEventListener;

public final class zzfe extends zzdf {
  public final OnPaidEventListener a;
  
  public zzfe(OnPaidEventListener paramOnPaidEventListener) {
    this.a = paramOnPaidEventListener;
  }
  
  public final void zze(zzs paramzzs) {
    OnPaidEventListener onPaidEventListener = this.a;
    if (onPaidEventListener != null)
      onPaidEventListener.onPaidEvent(AdValue.zza(paramzzs.zzb, paramzzs.zzc, paramzzs.zzd)); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */