package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzblw;
import com.google.android.gms.internal.ads.zzbsi;
import w0.a;
import w0.c;
import w0.l1;
import w0.n1;
import w0.o3;
import w0.q1;
import w0.t1;
import w0.w1;
import w0.z1;

public final class zzbo extends a implements zzbq {
  public zzbo(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
  }
  
  public final zzbn zze() {
    zzbn zzbn;
    Parcel parcel = a1(Z0(), 1);
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoader");
      if (iInterface instanceof zzbn) {
        zzbn = (zzbn)iInterface;
      } else {
        zzbn = new zzbl((IBinder)zzbn);
      } 
    } 
    parcel.recycle();
    return zzbn;
  }
  
  public final void zzf(l1 paraml1) {
    throw null;
  }
  
  public final void zzg(n1 paramn1) {
    throw null;
  }
  
  public final void zzh(String paramString, t1 paramt1, q1 paramq1) {
    Parcel parcel = Z0();
    parcel.writeString(paramString);
    c.e(parcel, (IInterface)paramt1);
    c.e(parcel, (IInterface)paramq1);
    b1(parcel, 5);
  }
  
  public final void zzi(o3 paramo3) {
    throw null;
  }
  
  public final void zzj(w1 paramw1, zzq paramzzq) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)paramw1);
    c.c(parcel, (Parcelable)paramzzq);
    b1(parcel, 8);
  }
  
  public final void zzk(z1 paramz1) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)paramz1);
    b1(parcel, 10);
  }
  
  public final void zzl(zzbh paramzzbh) {
    Parcel parcel = Z0();
    c.e(parcel, paramzzbh);
    b1(parcel, 2);
  }
  
  public final void zzm(AdManagerAdViewOptions paramAdManagerAdViewOptions) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramAdManagerAdViewOptions);
    b1(parcel, 15);
  }
  
  public final void zzn(zzbsi paramzzbsi) {
    throw null;
  }
  
  public final void zzo(zzblw paramzzblw) {
    Parcel parcel = Z0();
    c.c(parcel, (Parcelable)paramzzblw);
    b1(parcel, 6);
  }
  
  public final void zzp(PublisherAdViewOptions paramPublisherAdViewOptions) {
    throw null;
  }
  
  public final void zzq(zzcf paramzzcf) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */