package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.formats.ShouldDelayBannerRenderingListener;
import u0.a;
import u0.b;
import w0.b2;

public final class zzfj extends b2 {
  public final ShouldDelayBannerRenderingListener a;
  
  public zzfj(ShouldDelayBannerRenderingListener paramShouldDelayBannerRenderingListener) {
    this.a = paramShouldDelayBannerRenderingListener;
  }
  
  public final boolean zzb(a parama) {
    return this.a.shouldDelayBannerRendering((Runnable)b.b1(parama));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */