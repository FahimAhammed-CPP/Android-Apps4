package com.google.android.gms.ads.internal.util;

import android.content.Context;
import java.util.concurrent.Callable;
import w0.l8;
import w0.u6;

public final class zzcb {
  @Deprecated
  public static Object zza(Context paramContext, Callable<Callable> paramCallable) {
    try {
    
    } finally {
      paramCallable = null;
      l8.d("Unexpected exception.", (Throwable)paramCallable);
      u6.b(paramContext).a("StrictModeUtil.runWithLaxStrictMode", (Throwable)paramCallable);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzcb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */