package com.google.android.gms.ads.internal.util;

import android.os.IInterface;
import android.os.Parcel;
import u0.a;
import w0.a;
import w0.c;

public final class zzbp extends a implements zzbr {
  public final void zze(a parama) {
    Parcel parcel = Z0();
    c.e(parcel, (IInterface)parama);
    b1(parcel, 2);
  }
  
  public final boolean zzf(a parama, String paramString1, String paramString2) {
    Parcel parcel2 = Z0();
    c.e(parcel2, (IInterface)parama);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    boolean bool = true;
    Parcel parcel1 = a1(parcel2, 1);
    if (parcel1.readInt() == 0)
      bool = false; 
    parcel1.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */