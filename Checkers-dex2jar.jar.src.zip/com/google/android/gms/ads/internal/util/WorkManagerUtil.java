package com.google.android.gms.ads.internal.util;

import a0.b;
import android.content.Context;
import androidx.work.a;
import androidx.work.b;
import c0.b;
import com.google.android.gms.ads.internal.offline.buffering.OfflineNotificationPoster;
import com.google.android.gms.ads.internal.offline.buffering.OfflinePingSender;
import java.util.Collections;
import java.util.HashMap;
import q.b;
import q.i;
import q.j;
import q.o;
import r.k;
import u0.a;
import u0.b;
import w0.l8;
import z.p;

public class WorkManagerUtil extends zzbq {
  public final void zze(a parama) {
    Context context = (Context)b.b1(parama);
    try {
      k.c(context.getApplicationContext(), new a(new a.a()));
    } catch (IllegalStateException illegalStateException) {}
    try {
      k k = k.b(context);
      k.getClass();
      b b1 = new b(k);
      ((b)k.d).a((Runnable)b1);
      b.a a1 = new b.a();
      a1.a = i.j;
      b b = new b(a1);
      j.a a2 = new j.a(OfflinePingSender.class);
      ((o.a)a2).b.j = b;
      ((o.a)a2).c.add("offline_ping_sender_work");
      k.a(Collections.singletonList(a2.a()));
      return;
    } catch (IllegalStateException illegalStateException) {
      l8.g("Failed to instantiate WorkManager.", illegalStateException);
      return;
    } 
  }
  
  public final boolean zzf(a parama, String paramString1, String paramString2) {
    Context context = (Context)b.b1(parama);
    try {
      k.c(context.getApplicationContext(), new a(new a.a()));
    } catch (IllegalStateException illegalStateException) {}
    b.a a2 = new b.a();
    a2.a = i.j;
    b b1 = new b(a2);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("uri", paramString1);
    hashMap.put("gws_query_id", paramString2);
    b b = new b(hashMap);
    b.b(b);
    j.a a1 = new j.a(OfflineNotificationPoster.class);
    p p = ((o.a)a1).b;
    p.j = b1;
    p.e = b;
    ((o.a)a1).c.add("offline_notification_work");
    j j = a1.a();
    try {
      k k = k.b(context);
      k.getClass();
      k.a(Collections.singletonList(j));
      return true;
    } catch (IllegalStateException illegalStateException) {
      l8.g("Failed to instantiate WorkManager.", illegalStateException);
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interna\\util\WorkManagerUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */