package com.google.android.gms.ads.internal.util;

import android.os.IInterface;
import u0.a;

public interface zzbr extends IInterface {
  void zze(a parama);
  
  boolean zzf(a parama, String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */