package com.google.android.gms.ads.internal.offline.buffering;

import android.content.Context;
import android.os.RemoteException;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.android.gms.ads.internal.client.zzay;
import w0.t3;
import w0.t5;
import w0.w3;

public class OfflinePingSender extends Worker {
  public final t5 g;
  
  public OfflinePingSender(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.g = zzay.zza().zzm(paramContext, (w3)new t3());
  }
  
  public final ListenableWorker.a doWork() {
    try {
      this.g.zzf();
      return (ListenableWorker.a)new ListenableWorker.a.c();
    } catch (RemoteException remoteException) {
      return (ListenableWorker.a)new ListenableWorker.a.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\offline\buffering\OfflinePingSender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */