package com.google.android.gms.ads.internal.offline.buffering;

import android.content.Context;
import android.os.RemoteException;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.android.gms.ads.internal.client.zzay;
import u0.b;
import w0.t3;
import w0.t5;
import w0.w3;

public class OfflineNotificationPoster extends Worker {
  public final t5 g;
  
  public OfflineNotificationPoster(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.g = zzay.zza().zzm(paramContext, (w3)new t3());
  }
  
  public final ListenableWorker.a doWork() {
    Object object1 = (getInputData()).a.get("uri");
    boolean bool = object1 instanceof String;
    String str = null;
    if (bool) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    Object object2 = (getInputData()).a.get("gws_query_id");
    if (object2 instanceof String)
      str = (String)object2; 
    try {
      this.g.T0(new b(getApplicationContext()), (String)object1, str);
      return (ListenableWorker.a)new ListenableWorker.a.c();
    } catch (RemoteException remoteException) {
      return (ListenableWorker.a)new ListenableWorker.a.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\android\gms\ads\internal\offline\buffering\OfflineNotificationPoster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */