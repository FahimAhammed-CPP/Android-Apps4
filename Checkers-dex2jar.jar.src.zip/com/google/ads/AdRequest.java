package com.google.ads;

@Deprecated
public final class AdRequest {
  public static final String LOGTAG = "Ads";
  
  public static final String TEST_EMULATOR = "B3EEABB8EE11C2BE770B684D95219ECB";
  
  public static final String VERSION = "0.0.0";
  
  public enum ErrorCode {
    INTERNAL_ERROR, INVALID_REQUEST, NETWORK_ERROR, NO_FILL;
    
    public final String i;
    
    static {
      ErrorCode errorCode1 = new ErrorCode(0, "INVALID_REQUEST", "Invalid Ad request.");
      INVALID_REQUEST = errorCode1;
      ErrorCode errorCode2 = new ErrorCode(1, "NO_FILL", "Ad request successful, but no ad returned due to lack of ad inventory.");
      NO_FILL = errorCode2;
      ErrorCode errorCode3 = new ErrorCode(2, "NETWORK_ERROR", "A network error occurred.");
      NETWORK_ERROR = errorCode3;
      ErrorCode errorCode4 = new ErrorCode(3, "INTERNAL_ERROR", "There was an internal error.");
      INTERNAL_ERROR = errorCode4;
      j = new ErrorCode[] { errorCode1, errorCode2, errorCode3, errorCode4 };
    }
    
    ErrorCode(String param1String1) {
      this.i = param1String1;
    }
    
    public String toString() {
      return this.i;
    }
  }
  
  public enum Gender {
    FEMALE, MALE, UNKNOWN;
    
    static {
      Gender gender1 = new Gender(0, "UNKNOWN");
      UNKNOWN = gender1;
      Gender gender2 = new Gender(1, "MALE");
      MALE = gender2;
      Gender gender3 = new Gender(2, "FEMALE");
      FEMALE = gender3;
      i = new Gender[] { gender1, gender2, gender3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\google\ads\AdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */