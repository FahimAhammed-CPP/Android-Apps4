package com.android.billingclient.api;

import a1.i;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import com.google.android.apps.common.proguard.UsedByReflection;

@UsedByReflection("PlatformActivityProxy")
public class ProxyBillingActivity extends Activity {
  public ResultReceiver a;
  
  public ResultReceiver b;
  
  public boolean c;
  
  public boolean d;
  
  public final Intent a() {
    Intent intent = new Intent("com.android.vending.billing.PURCHASES_UPDATED");
    intent.setPackage(getApplicationContext().getPackageName());
    return intent;
  }
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    Bundle bundle = null;
    ResultReceiver resultReceiver = null;
    if (paramInt1 == 100 || paramInt1 == 110) {
      int j = (i.c(paramIntent, "ProxyBillingActivity")).a;
      int i = paramInt2;
      if (paramInt2 == -1)
        if (j != 0) {
          i = -1;
        } else {
          paramInt2 = 0;
          resultReceiver = this.a;
        }  
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Activity finished with resultCode ");
      stringBuilder.append(i);
      stringBuilder.append(" and billing's responseCode: ");
      stringBuilder.append(j);
      i.f("ProxyBillingActivity", stringBuilder.toString());
      paramInt2 = j;
    } else {
      if (paramInt1 == 101) {
        if (paramIntent == null) {
          i.f("ProxyBillingActivity", "Got null intent!");
        } else {
          paramInt1 = i.a;
          bundle = paramIntent.getExtras();
          if (bundle == null) {
            i.f("ProxyBillingActivity", "Unexpected null bundle received!");
          } else {
            paramInt1 = bundle.getInt("IN_APP_MESSAGE_RESPONSE_CODE", 0);
            ResultReceiver resultReceiver2 = this.b;
          } 
        } 
        paramInt1 = 0;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Got onActivityResult with wrong requestCode: ");
        stringBuilder.append(paramInt1);
        stringBuilder.append("; skipping...");
        i.f("ProxyBillingActivity", stringBuilder.toString());
        this.c = false;
        finish();
      } 
      ResultReceiver resultReceiver1 = this.b;
    } 
    resultReceiver = this.a;
  }
  
  public final void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_1
    //   6: ifnonnull -> 303
    //   9: ldc 'ProxyBillingActivity'
    //   11: ldc 'Launching Play Store billing flow'
    //   13: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)V
    //   16: aload_0
    //   17: invokevirtual getIntent : ()Landroid/content/Intent;
    //   20: ldc 'BUY_INTENT'
    //   22: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   25: ifeq -> 83
    //   28: aload_0
    //   29: invokevirtual getIntent : ()Landroid/content/Intent;
    //   32: ldc 'BUY_INTENT'
    //   34: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   37: checkcast android/app/PendingIntent
    //   40: astore_3
    //   41: aload_3
    //   42: astore_1
    //   43: aload_0
    //   44: invokevirtual getIntent : ()Landroid/content/Intent;
    //   47: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   49: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   52: ifeq -> 176
    //   55: aload_3
    //   56: astore_1
    //   57: aload_0
    //   58: invokevirtual getIntent : ()Landroid/content/Intent;
    //   61: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   63: iconst_0
    //   64: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   67: ifeq -> 176
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield d : Z
    //   75: bipush #110
    //   77: istore_2
    //   78: aload_3
    //   79: astore_1
    //   80: goto -> 179
    //   83: aload_0
    //   84: invokevirtual getIntent : ()Landroid/content/Intent;
    //   87: ldc 'SUBS_MANAGEMENT_INTENT'
    //   89: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   92: ifeq -> 127
    //   95: aload_0
    //   96: invokevirtual getIntent : ()Landroid/content/Intent;
    //   99: ldc 'SUBS_MANAGEMENT_INTENT'
    //   101: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   104: checkcast android/app/PendingIntent
    //   107: astore_1
    //   108: aload_0
    //   109: aload_0
    //   110: invokevirtual getIntent : ()Landroid/content/Intent;
    //   113: ldc 'result_receiver'
    //   115: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   118: checkcast android/os/ResultReceiver
    //   121: putfield a : Landroid/os/ResultReceiver;
    //   124: goto -> 176
    //   127: aload_0
    //   128: invokevirtual getIntent : ()Landroid/content/Intent;
    //   131: ldc 'IN_APP_MESSAGE_INTENT'
    //   133: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   136: ifeq -> 174
    //   139: aload_0
    //   140: invokevirtual getIntent : ()Landroid/content/Intent;
    //   143: ldc 'IN_APP_MESSAGE_INTENT'
    //   145: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   148: checkcast android/app/PendingIntent
    //   151: astore_1
    //   152: aload_0
    //   153: aload_0
    //   154: invokevirtual getIntent : ()Landroid/content/Intent;
    //   157: ldc 'in_app_message_result_receiver'
    //   159: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   162: checkcast android/os/ResultReceiver
    //   165: putfield b : Landroid/os/ResultReceiver;
    //   168: bipush #101
    //   170: istore_2
    //   171: goto -> 179
    //   174: aconst_null
    //   175: astore_1
    //   176: bipush #100
    //   178: istore_2
    //   179: aload_0
    //   180: iconst_1
    //   181: putfield c : Z
    //   184: aload_0
    //   185: aload_1
    //   186: invokevirtual getIntentSender : ()Landroid/content/IntentSender;
    //   189: iload_2
    //   190: new android/content/Intent
    //   193: dup
    //   194: invokespecial <init> : ()V
    //   197: iconst_0
    //   198: iconst_0
    //   199: iconst_0
    //   200: invokevirtual startIntentSenderForResult : (Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    //   203: return
    //   204: astore_1
    //   205: ldc 'ProxyBillingActivity'
    //   207: ldc 'Got exception while trying to start a purchase flow.'
    //   209: aload_1
    //   210: invokestatic g : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   213: aload_0
    //   214: getfield a : Landroid/os/ResultReceiver;
    //   217: astore_1
    //   218: aload_1
    //   219: ifnull -> 232
    //   222: aload_1
    //   223: bipush #6
    //   225: aconst_null
    //   226: invokevirtual send : (ILandroid/os/Bundle;)V
    //   229: goto -> 293
    //   232: aload_0
    //   233: getfield b : Landroid/os/ResultReceiver;
    //   236: astore_1
    //   237: aload_1
    //   238: ifnull -> 250
    //   241: aload_1
    //   242: iconst_0
    //   243: aconst_null
    //   244: invokevirtual send : (ILandroid/os/Bundle;)V
    //   247: goto -> 293
    //   250: aload_0
    //   251: invokevirtual a : ()Landroid/content/Intent;
    //   254: astore_1
    //   255: aload_0
    //   256: getfield d : Z
    //   259: ifeq -> 270
    //   262: aload_1
    //   263: ldc 'IS_FIRST_PARTY_PURCHASE'
    //   265: iconst_1
    //   266: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   269: pop
    //   270: aload_1
    //   271: ldc 'RESPONSE_CODE'
    //   273: bipush #6
    //   275: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   278: pop
    //   279: aload_1
    //   280: ldc 'DEBUG_MESSAGE'
    //   282: ldc 'An internal error occurred.'
    //   284: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   287: pop
    //   288: aload_0
    //   289: aload_1
    //   290: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   293: aload_0
    //   294: iconst_0
    //   295: putfield c : Z
    //   298: aload_0
    //   299: invokevirtual finish : ()V
    //   302: return
    //   303: ldc 'ProxyBillingActivity'
    //   305: ldc 'Launching Play Store billing flow from savedInstanceState'
    //   307: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)V
    //   310: aload_0
    //   311: aload_1
    //   312: ldc 'send_cancelled_broadcast_if_finished'
    //   314: iconst_0
    //   315: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   318: putfield c : Z
    //   321: aload_1
    //   322: ldc 'result_receiver'
    //   324: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   327: ifeq -> 346
    //   330: aload_0
    //   331: aload_1
    //   332: ldc 'result_receiver'
    //   334: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   337: checkcast android/os/ResultReceiver
    //   340: putfield a : Landroid/os/ResultReceiver;
    //   343: goto -> 368
    //   346: aload_1
    //   347: ldc 'in_app_message_result_receiver'
    //   349: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   352: ifeq -> 368
    //   355: aload_0
    //   356: aload_1
    //   357: ldc 'in_app_message_result_receiver'
    //   359: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   362: checkcast android/os/ResultReceiver
    //   365: putfield b : Landroid/os/ResultReceiver;
    //   368: aload_0
    //   369: aload_1
    //   370: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   372: iconst_0
    //   373: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   376: putfield d : Z
    //   379: return
    // Exception table:
    //   from	to	target	type
    //   179	203	204	android/content/IntentSender$SendIntentException
  }
  
  public final void onDestroy() {
    super.onDestroy();
    if (!isFinishing())
      return; 
    if (!this.c)
      return; 
    Intent intent = a();
    intent.putExtra("RESPONSE_CODE", 1);
    intent.putExtra("DEBUG_MESSAGE", "Billing dialog closed.");
    sendBroadcast(intent);
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    ResultReceiver resultReceiver = this.a;
    if (resultReceiver != null)
      paramBundle.putParcelable("result_receiver", (Parcelable)resultReceiver); 
    resultReceiver = this.b;
    if (resultReceiver != null)
      paramBundle.putParcelable("in_app_message_result_receiver", (Parcelable)resultReceiver); 
    paramBundle.putBoolean("send_cancelled_broadcast_if_finished", this.c);
    paramBundle.putBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\android\billingclient\api\ProxyBillingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */