package com.android.billingclient.api;

import android.text.TextUtils;
import org.json.JSONObject;

public final class Purchase {
  public final String a;
  
  public final String b;
  
  public final JSONObject c;
  
  public Purchase(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = new JSONObject(paramString1);
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Purchase))
      return false; 
    paramObject = paramObject;
    return (TextUtils.equals(this.a, ((Purchase)paramObject).a) && TextUtils.equals(this.b, ((Purchase)paramObject).b));
  }
  
  public final int hashCode() {
    return this.a.hashCode();
  }
  
  public final String toString() {
    return "Purchase. Json: ".concat(String.valueOf(this.a));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\android\billingclient\api\Purchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */