package com.android.billingclient.api;

import android.text.TextUtils;
import org.json.JSONObject;

@Deprecated
public final class SkuDetails {
  public final String a;
  
  public final JSONObject b;
  
  public SkuDetails(String paramString) {
    this.a = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.b = jSONObject;
    if (!TextUtils.isEmpty(jSONObject.optString("productId"))) {
      if (!TextUtils.isEmpty(jSONObject.optString("type")))
        return; 
      throw new IllegalArgumentException("SkuType cannot be empty.");
    } 
    throw new IllegalArgumentException("SKU cannot be empty.");
  }
  
  public final String a() {
    return this.b.optString("type");
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SkuDetails))
      return false; 
    paramObject = paramObject;
    return TextUtils.equals(this.a, ((SkuDetails)paramObject).a);
  }
  
  public final int hashCode() {
    return this.a.hashCode();
  }
  
  public final String toString() {
    return "SkuDetails: ".concat(String.valueOf(this.a));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\com\android\billingclient\api\SkuDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */