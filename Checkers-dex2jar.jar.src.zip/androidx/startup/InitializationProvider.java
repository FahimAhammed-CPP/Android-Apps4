package androidx.startup;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import e1.d;
import java.util.HashSet;
import n.a;
import n.b;

public final class InitializationProvider extends ContentProvider {
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final boolean onCreate() {
    Context context = getContext();
    if (context != null) {
      if (a.d == null)
        synchronized (a.e) {
          if (a.d == null)
            a.d = new a(context); 
        }  
      a a = a.d;
      a.getClass();
      try {
        Trace.beginSection("Startup");
        ComponentName componentName = new ComponentName(a.c.getPackageName(), InitializationProvider.class.getName());
        Bundle bundle = (a.c.getPackageManager().getProviderInfo(componentName, 128)).metaData;
        String str = a.c.getString(2131427329);
        if (bundle != null) {
          HashSet hashSet = new HashSet();
          for (String str1 : bundle.keySet()) {
            if (str.equals(bundle.getString(str1, null))) {
              Class<?> clazz = Class.forName(str1);
              if (b.class.isAssignableFrom(clazz)) {
                a.b.add(clazz);
                a.a(clazz, hashSet);
              } 
            } 
          } 
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      
      } catch (ClassNotFoundException classNotFoundException) {
      
      } finally {}
      Trace.endSection();
      return true;
    } 
    d d = new d();
    throw d;
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */