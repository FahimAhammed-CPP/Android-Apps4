package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import i.d;
import i.e;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  public int a = 0;
  
  public final HashMap<Integer, String> b = new HashMap<Integer, String>();
  
  public final a c = new a(this);
  
  public final b d = new b(this);
  
  public final IBinder onBind(Intent paramIntent) {
    return (IBinder)this.d;
  }
  
  public final class a extends RemoteCallbackList<d> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public final void onCallbackDied(IInterface param1IInterface, Object param1Object) {
      d d = (d)param1IInterface;
      this.a.b.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public final class b extends e {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public final void Z0(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.a.c) {
        String str = this.a.b.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.a.c.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.a.c.getBroadcastCookie(i)).intValue();
            String str1 = this.a.b.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((d)this.a.c.getBroadcastItem(i)).V(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.a.c.finishBroadcast();
          } 
        } 
        this.a.c.finishBroadcast();
        return;
      } 
    }
    
    public final int a1(d param1d, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.a.c) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.a;
        int i = multiInstanceInvalidationService2.a + 1;
        multiInstanceInvalidationService2.a = i;
        if (multiInstanceInvalidationService2.c.register((IInterface)param1d, Integer.valueOf(i))) {
          this.a.b.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.a;
        multiInstanceInvalidationService1.a--;
        return 0;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */