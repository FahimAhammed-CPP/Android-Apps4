package androidx.work.impl;

import android.content.Context;
import i.g;
import i.i;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import k.c;
import l.b;
import z.b;
import z.c;
import z.e;
import z.f;
import z.h;
import z.i;
import z.k;
import z.l;
import z.n;
import z.o;
import z.q;
import z.r;
import z.t;
import z.u;

public final class WorkDatabase_Impl extends WorkDatabase {
  public volatile r l;
  
  public volatile c m;
  
  public volatile u n;
  
  public volatile i o;
  
  public volatile l p;
  
  public volatile o q;
  
  public volatile f r;
  
  public final g d() {
    return new g(this, new HashMap<Object, Object>(0), new HashMap<Object, Object>(0), new String[] { "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference" });
  }
  
  public final b e(i.a parama) {
    i i1 = new i(parama, new a(this));
    Context context = parama.b;
    String str = parama.c;
    if (context != null) {
      b.b b = new b.b(context, str, (b.a)i1, false);
      return parama.a.a(b);
    } 
    throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
  }
  
  public final b i() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Lz/c;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield m : Lz/c;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield m : Lz/c;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/c
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield m : Lz/c;
    //   33: aload_0
    //   34: getfield m : Lz/c;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final e j() {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Lz/f;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield r : Lz/f;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield r : Lz/f;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/f
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield r : Lz/f;
    //   33: aload_0
    //   34: getfield r : Lz/f;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final h k() {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lz/i;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield o : Lz/i;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield o : Lz/i;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/i
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield o : Lz/i;
    //   33: aload_0
    //   34: getfield o : Lz/i;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final k l() {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Lz/l;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield p : Lz/l;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield p : Lz/l;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/l
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield p : Lz/l;
    //   33: aload_0
    //   34: getfield p : Lz/l;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final n m() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lz/o;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield q : Lz/o;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield q : Lz/o;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/o
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield q : Lz/o;
    //   33: aload_0
    //   34: getfield q : Lz/o;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final q n() {
    // Byte code:
    //   0: aload_0
    //   1: getfield l : Lz/r;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield l : Lz/r;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield l : Lz/r;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/r
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield l : Lz/r;
    //   33: aload_0
    //   34: getfield l : Lz/r;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final t o() {
    // Byte code:
    //   0: aload_0
    //   1: getfield n : Lz/u;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield n : Lz/u;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield n : Lz/u;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new z/u
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Li/h;)V
    //   30: putfield n : Lz/u;
    //   33: aload_0
    //   34: getfield n : Lz/u;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public final class a extends i.a {
    public a(WorkDatabase_Impl this$0) {}
    
    public final void a(m.a param1a) {
      param1a.d("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
      param1a.d("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
      param1a.d("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
      param1a.d("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
      param1a.d("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
      param1a.d("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      param1a.d("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
    }
    
    public final i.b b(m.a param1a) {
      StringBuilder stringBuilder;
      HashMap<Object, Object> hashMap7 = new HashMap<Object, Object>(2);
      hashMap7.put("work_spec_id", new c.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap7.put("prerequisite_id", new c.a("prerequisite_id", "TEXT", true, 2, null, 1));
      HashSet<c.b> hashSet5 = new HashSet(2);
      hashSet5.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet5.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "prerequisite_id" }, ), Arrays.asList(new String[] { "id" })));
      HashSet<c.d> hashSet6 = new HashSet(2);
      hashSet6.add(new c.d("index_Dependency_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      hashSet6.add(new c.d("index_Dependency_prerequisite_id", false, Arrays.asList(new String[] { "prerequisite_id" })));
      c c8 = new c("Dependency", hashMap7, hashSet5, hashSet6);
      c c14 = c.a(param1a, "Dependency");
      if (!c8.equals(c14)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Dependency(androidx.work.impl.model.Dependency).\n Expected:\n");
        stringBuilder.append(c8);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c14);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap6 = new HashMap<Object, Object>(25);
      hashMap6.put("id", new c.a("id", "TEXT", true, 1, null, 1));
      hashMap6.put("state", new c.a("state", "INTEGER", true, 0, null, 1));
      hashMap6.put("worker_class_name", new c.a("worker_class_name", "TEXT", true, 0, null, 1));
      hashMap6.put("input_merger_class_name", new c.a("input_merger_class_name", "TEXT", false, 0, null, 1));
      hashMap6.put("input", new c.a("input", "BLOB", true, 0, null, 1));
      hashMap6.put("output", new c.a("output", "BLOB", true, 0, null, 1));
      hashMap6.put("initial_delay", new c.a("initial_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("interval_duration", new c.a("interval_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("flex_duration", new c.a("flex_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_attempt_count", new c.a("run_attempt_count", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_policy", new c.a("backoff_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_delay_duration", new c.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("period_start_time", new c.a("period_start_time", "INTEGER", true, 0, null, 1));
      hashMap6.put("minimum_retention_duration", new c.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("schedule_requested_at", new c.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_in_foreground", new c.a("run_in_foreground", "INTEGER", true, 0, null, 1));
      hashMap6.put("out_of_quota_policy", new c.a("out_of_quota_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("required_network_type", new c.a("required_network_type", "INTEGER", false, 0, null, 1));
      hashMap6.put("requires_charging", new c.a("requires_charging", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_device_idle", new c.a("requires_device_idle", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_battery_not_low", new c.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_storage_not_low", new c.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_content_update_delay", new c.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_max_content_delay", new c.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("content_uri_triggers", new c.a("content_uri_triggers", "BLOB", false, 0, null, 1));
      HashSet hashSet = new HashSet(0);
      hashSet6 = new HashSet<c.d>(2);
      hashSet6.add(new c.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList(new String[] { "schedule_requested_at" })));
      hashSet6.add(new c.d("index_WorkSpec_period_start_time", false, Arrays.asList(new String[] { "period_start_time" })));
      c c7 = new c("WorkSpec", hashMap6, hashSet, hashSet6);
      c c13 = c.a((m.a)stringBuilder, "WorkSpec");
      if (!c7.equals(c13)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n");
        stringBuilder.append(c7);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c13);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap5 = new HashMap<Object, Object>(2);
      hashMap5.put("tag", new c.a("tag", "TEXT", true, 1, null, 1));
      hashMap5.put("work_spec_id", new c.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<c.b> hashSet4 = new HashSet(1);
      hashSet4.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<c.d>(1);
      hashSet6.add(new c.d("index_WorkTag_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      c c6 = new c("WorkTag", hashMap5, hashSet4, hashSet6);
      c c12 = c.a((m.a)stringBuilder, "WorkTag");
      if (!c6.equals(c12)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n");
        stringBuilder.append(c6);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c12);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap4 = new HashMap<Object, Object>(2);
      hashMap4.put("work_spec_id", new c.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap4.put("system_id", new c.a("system_id", "INTEGER", true, 0, null, 1));
      HashSet<c.b> hashSet3 = new HashSet(1);
      hashSet3.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      c c5 = new c("SystemIdInfo", hashMap4, hashSet3, new HashSet(0));
      c c11 = c.a((m.a)stringBuilder, "SystemIdInfo");
      if (!c5.equals(c11)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n");
        stringBuilder.append(c5);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c11);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>(2);
      hashMap3.put("name", new c.a("name", "TEXT", true, 1, null, 1));
      hashMap3.put("work_spec_id", new c.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<c.b> hashSet2 = new HashSet(1);
      hashSet2.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<c.d>(1);
      hashSet6.add(new c.d("index_WorkName_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      c c4 = new c("WorkName", hashMap3, hashSet2, hashSet6);
      c c10 = c.a((m.a)stringBuilder, "WorkName");
      if (!c4.equals(c10)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkName(androidx.work.impl.model.WorkName).\n Expected:\n");
        stringBuilder.append(c4);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c10);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(2);
      hashMap2.put("work_spec_id", new c.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap2.put("progress", new c.a("progress", "BLOB", true, 0, null, 1));
      HashSet<c.b> hashSet1 = new HashSet(1);
      hashSet1.add(new c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      c c3 = new c("WorkProgress", hashMap2, hashSet1, new HashSet(0));
      c c9 = c.a((m.a)stringBuilder, "WorkProgress");
      if (!c3.equals(c9)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n");
        stringBuilder.append(c3);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(c9);
        return new i.b(stringBuilder.toString(), false);
      } 
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(2);
      hashMap1.put("key", new c.a("key", "TEXT", true, 1, null, 1));
      hashMap1.put("long_value", new c.a("long_value", "INTEGER", false, 0, null, 1));
      c c2 = new c("Preference", hashMap1, new HashSet(0), new HashSet(0));
      c c1 = c.a((m.a)stringBuilder, "Preference");
      if (!c2.equals(c1)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Preference(androidx.work.impl.model.Preference).\n Expected:\n");
        stringBuilder1.append(c2);
        stringBuilder1.append("\n Found:\n");
        stringBuilder1.append(c1);
        return new i.b(stringBuilder1.toString(), false);
      } 
      return new i.b(null, true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\WorkDatabase_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */