package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import java.util.Collections;
import q.h;
import q.j;
import r.k;

public class DiagnosticsReceiver extends BroadcastReceiver {
  public static final String a = h.e("DiagnosticsRcvr");
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    h.c().a(a, "Requesting diagnostics", new Throwable[0]);
    try {
      k k = k.b(paramContext);
      j j = (new j.a(DiagnosticsWorker.class)).a();
      k.getClass();
      k.a(Collections.singletonList(j));
      return;
    } catch (IllegalStateException illegalStateException) {
      h.c().b(a, "WorkManager is not initialized", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */