package androidx.work.impl;

import i.h;
import java.util.concurrent.TimeUnit;
import z.b;
import z.e;
import z.h;
import z.k;
import z.n;
import z.q;
import z.t;

public abstract class WorkDatabase extends h {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public abstract b i();
  
  public abstract e j();
  
  public abstract h k();
  
  public abstract k l();
  
  public abstract n m();
  
  public abstract q n();
  
  public abstract t o();
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */