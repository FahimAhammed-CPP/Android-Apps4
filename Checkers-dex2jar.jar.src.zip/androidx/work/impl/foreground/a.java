package androidx.work.impl.foreground;

import a0.m;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import c0.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import q.d;
import q.h;
import r.b;
import r.k;
import v.c;
import v.d;
import y.c;
import y.e;
import z.p;

public final class a implements c, b {
  public static final String k = h.e("SystemFgDispatcher");
  
  public Context a;
  
  public k b;
  
  public final c0.a c;
  
  public final Object d;
  
  public String e;
  
  public final LinkedHashMap f;
  
  public final HashMap g;
  
  public final HashSet h;
  
  public final d i;
  
  public a j;
  
  public a(Context paramContext) {
    this.a = paramContext;
    this.d = new Object();
    k k1 = k.b(paramContext);
    this.b = k1;
    c0.a a1 = k1.d;
    this.c = a1;
    this.e = null;
    this.f = new LinkedHashMap<Object, Object>();
    this.h = new HashSet();
    this.g = new HashMap<Object, Object>();
    this.i = new d(this.a, a1, this);
    this.b.f.b(this);
  }
  
  public static Intent b(Context paramContext, String paramString, d paramd) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_NOTIFY");
    intent.putExtra("KEY_NOTIFICATION_ID", paramd.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramd.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramd.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent c(Context paramContext, String paramString, d paramd) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_START_FOREGROUND");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NOTIFICATION_ID", paramd.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramd.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramd.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public final void a(String paramString, boolean paramBoolean) {
    synchronized (this.d) {
      p p = (p)this.g.remove(paramString);
      if (p != null) {
        paramBoolean = this.h.remove(p);
      } else {
        paramBoolean = false;
      } 
      if (paramBoolean)
        this.i.b(this.h); 
      null = this.f.remove(paramString);
      if (paramString.equals(this.e) && this.f.size() > 0) {
        Iterator<Map.Entry> iterator = this.f.entrySet().iterator();
        while (true) {
          Map.Entry entry = iterator.next();
          if (iterator.hasNext())
            continue; 
          this.e = (String)entry.getKey();
          if (this.j != null) {
            d d1 = (d)entry.getValue();
            a a3 = this.j;
            int i = d1.a;
            int j = d1.b;
            Notification notification = d1.c;
            a3 = a3;
            ((SystemForegroundService)a3).b.post((Runnable)new c((SystemForegroundService)a3, i, notification, j));
            a a2 = this.j;
            i = d1.a;
            SystemForegroundService systemForegroundService = (SystemForegroundService)a2;
            systemForegroundService.b.post((Runnable)new e(systemForegroundService, i));
          } 
          break;
        } 
      } 
      a a1 = this.j;
      if (null != null && a1 != null) {
        h.c().a(k, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", new Object[] { Integer.valueOf(((d)null).a), paramString, Integer.valueOf(((d)null).b) }), new Throwable[0]);
        int i = ((d)null).a;
        SystemForegroundService systemForegroundService = (SystemForegroundService)a1;
        systemForegroundService.b.post((Runnable)new e(systemForegroundService, i));
      } 
      return;
    } 
  }
  
  public final void d(ArrayList paramArrayList) {
    if (!paramArrayList.isEmpty())
      for (String str : paramArrayList) {
        h.c().a(k, String.format("Constraints unmet for WorkSpec %s", new Object[] { str }), new Throwable[0]);
        k k1 = this.b;
        c0.a a1 = k1.d;
        m m = new m(k1, str, true);
        ((b)a1).a((Runnable)m);
      }  
  }
  
  public final void e(List<String> paramList) {}
  
  public static interface a {}
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\foreground\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */