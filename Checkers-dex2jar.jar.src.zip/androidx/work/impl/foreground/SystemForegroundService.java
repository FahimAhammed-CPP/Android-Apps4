package androidx.work.impl.foreground;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.f;
import q.h;
import r.d;

public class SystemForegroundService extends f implements a.a {
  public static final String f = h.e("SystemFgService");
  
  public Handler b;
  
  public boolean c;
  
  public a d;
  
  public NotificationManager e;
  
  public final void a() {
    this.b = new Handler(Looper.getMainLooper());
    this.e = (NotificationManager)getApplicationContext().getSystemService("notification");
    a a1 = new a(getApplicationContext());
    this.d = a1;
    if (a1.j != null) {
      h.c().b(a.k, "A callback already exists.", new Throwable[0]);
      return;
    } 
    a1.j = this;
  }
  
  public final void onCreate() {
    super.onCreate();
    a();
  }
  
  public final void onDestroy() {
    super.onDestroy();
    null = this.d;
    null.j = null;
    synchronized (null.d) {
      null.i.c();
      d d = null.b.f;
      synchronized (d.k) {
        d.j.remove(null);
        return;
      } 
    } 
  }
  
  public final int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: iload_3
    //   4: invokespecial onStartCommand : (Landroid/content/Intent;II)I
    //   7: pop
    //   8: aload_0
    //   9: getfield c : Z
    //   12: istore #5
    //   14: iconst_0
    //   15: istore_2
    //   16: iload #5
    //   18: ifeq -> 127
    //   21: invokestatic c : ()Lq/h;
    //   24: getstatic androidx/work/impl/foreground/SystemForegroundService.f : Ljava/lang/String;
    //   27: ldc 'Re-initializing SystemForegroundService after a request to shut-down.'
    //   29: iconst_0
    //   30: anewarray java/lang/Throwable
    //   33: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   36: aload_0
    //   37: getfield d : Landroidx/work/impl/foreground/a;
    //   40: astore #6
    //   42: aload #6
    //   44: aconst_null
    //   45: putfield j : Landroidx/work/impl/foreground/a$a;
    //   48: aload #6
    //   50: getfield d : Ljava/lang/Object;
    //   53: astore #7
    //   55: aload #7
    //   57: monitorenter
    //   58: aload #6
    //   60: getfield i : Lv/d;
    //   63: invokevirtual c : ()V
    //   66: aload #7
    //   68: monitorexit
    //   69: aload #6
    //   71: getfield b : Lr/k;
    //   74: getfield f : Lr/d;
    //   77: astore #8
    //   79: aload #8
    //   81: getfield k : Ljava/lang/Object;
    //   84: astore #7
    //   86: aload #7
    //   88: monitorenter
    //   89: aload #8
    //   91: getfield j : Ljava/util/ArrayList;
    //   94: aload #6
    //   96: invokevirtual remove : (Ljava/lang/Object;)Z
    //   99: pop
    //   100: aload #7
    //   102: monitorexit
    //   103: aload_0
    //   104: invokevirtual a : ()V
    //   107: aload_0
    //   108: iconst_0
    //   109: putfield c : Z
    //   112: goto -> 127
    //   115: astore_1
    //   116: aload #7
    //   118: monitorexit
    //   119: aload_1
    //   120: athrow
    //   121: astore_1
    //   122: aload #7
    //   124: monitorexit
    //   125: aload_1
    //   126: athrow
    //   127: aload_1
    //   128: ifnull -> 760
    //   131: aload_0
    //   132: getfield d : Landroidx/work/impl/foreground/a;
    //   135: astore #6
    //   137: aload #6
    //   139: invokevirtual getClass : ()Ljava/lang/Class;
    //   142: pop
    //   143: aload_1
    //   144: invokevirtual getAction : ()Ljava/lang/String;
    //   147: astore #7
    //   149: ldc 'ACTION_START_FOREGROUND'
    //   151: aload #7
    //   153: invokevirtual equals : (Ljava/lang/Object;)Z
    //   156: ifeq -> 238
    //   159: invokestatic c : ()Lq/h;
    //   162: getstatic androidx/work/impl/foreground/a.k : Ljava/lang/String;
    //   165: ldc 'Started foreground service %s'
    //   167: iconst_1
    //   168: anewarray java/lang/Object
    //   171: dup
    //   172: iconst_0
    //   173: aload_1
    //   174: aastore
    //   175: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   178: iconst_0
    //   179: anewarray java/lang/Throwable
    //   182: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   185: aload_1
    //   186: ldc 'KEY_WORKSPEC_ID'
    //   188: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   191: astore #8
    //   193: aload #6
    //   195: getfield b : Lr/k;
    //   198: getfield c : Landroidx/work/impl/WorkDatabase;
    //   201: astore #9
    //   203: aload #6
    //   205: getfield c : Lc0/a;
    //   208: astore #7
    //   210: new y/b
    //   213: dup
    //   214: aload #6
    //   216: aload #9
    //   218: aload #8
    //   220: invokespecial <init> : (Landroidx/work/impl/foreground/a;Landroidx/work/impl/WorkDatabase;Ljava/lang/String;)V
    //   223: astore #8
    //   225: aload #7
    //   227: checkcast c0/b
    //   230: aload #8
    //   232: invokevirtual a : (Ljava/lang/Runnable;)V
    //   235: goto -> 248
    //   238: ldc 'ACTION_NOTIFY'
    //   240: aload #7
    //   242: invokevirtual equals : (Ljava/lang/Object;)Z
    //   245: ifeq -> 577
    //   248: aload_1
    //   249: ldc 'KEY_NOTIFICATION_ID'
    //   251: iconst_0
    //   252: invokevirtual getIntExtra : (Ljava/lang/String;I)I
    //   255: istore_3
    //   256: aload_1
    //   257: ldc 'KEY_FOREGROUND_SERVICE_TYPE'
    //   259: iconst_0
    //   260: invokevirtual getIntExtra : (Ljava/lang/String;I)I
    //   263: istore #4
    //   265: aload_1
    //   266: ldc 'KEY_WORKSPEC_ID'
    //   268: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   271: astore #7
    //   273: aload_1
    //   274: ldc 'KEY_NOTIFICATION'
    //   276: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   279: checkcast android/app/Notification
    //   282: astore_1
    //   283: invokestatic c : ()Lq/h;
    //   286: getstatic androidx/work/impl/foreground/a.k : Ljava/lang/String;
    //   289: ldc 'Notifying with (id: %s, workSpecId: %s, notificationType: %s)'
    //   291: iconst_3
    //   292: anewarray java/lang/Object
    //   295: dup
    //   296: iconst_0
    //   297: iload_3
    //   298: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   301: aastore
    //   302: dup
    //   303: iconst_1
    //   304: aload #7
    //   306: aastore
    //   307: dup
    //   308: iconst_2
    //   309: iload #4
    //   311: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   314: aastore
    //   315: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   318: iconst_0
    //   319: anewarray java/lang/Throwable
    //   322: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   325: aload_1
    //   326: ifnull -> 760
    //   329: aload #6
    //   331: getfield j : Landroidx/work/impl/foreground/a$a;
    //   334: ifnull -> 760
    //   337: new q/d
    //   340: dup
    //   341: iload_3
    //   342: iload #4
    //   344: aload_1
    //   345: invokespecial <init> : (IILandroid/app/Notification;)V
    //   348: astore #8
    //   350: aload #6
    //   352: getfield f : Ljava/util/LinkedHashMap;
    //   355: aload #7
    //   357: aload #8
    //   359: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   364: pop
    //   365: aload #6
    //   367: getfield e : Ljava/lang/String;
    //   370: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   373: ifeq -> 417
    //   376: aload #6
    //   378: aload #7
    //   380: putfield e : Ljava/lang/String;
    //   383: aload #6
    //   385: getfield j : Landroidx/work/impl/foreground/a$a;
    //   388: checkcast androidx/work/impl/foreground/SystemForegroundService
    //   391: astore #6
    //   393: aload #6
    //   395: getfield b : Landroid/os/Handler;
    //   398: new y/c
    //   401: dup
    //   402: aload #6
    //   404: iload_3
    //   405: aload_1
    //   406: iload #4
    //   408: invokespecial <init> : (Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V
    //   411: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   414: pop
    //   415: iconst_3
    //   416: ireturn
    //   417: aload #6
    //   419: getfield j : Landroidx/work/impl/foreground/a$a;
    //   422: checkcast androidx/work/impl/foreground/SystemForegroundService
    //   425: astore #7
    //   427: aload #7
    //   429: getfield b : Landroid/os/Handler;
    //   432: new y/d
    //   435: dup
    //   436: aload #7
    //   438: iload_3
    //   439: aload_1
    //   440: invokespecial <init> : (Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;)V
    //   443: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   446: pop
    //   447: iload #4
    //   449: ifeq -> 760
    //   452: getstatic android/os/Build$VERSION.SDK_INT : I
    //   455: bipush #29
    //   457: if_icmplt -> 760
    //   460: aload #6
    //   462: getfield f : Ljava/util/LinkedHashMap;
    //   465: invokevirtual entrySet : ()Ljava/util/Set;
    //   468: invokeinterface iterator : ()Ljava/util/Iterator;
    //   473: astore_1
    //   474: aload_1
    //   475: invokeinterface hasNext : ()Z
    //   480: ifeq -> 509
    //   483: iload_2
    //   484: aload_1
    //   485: invokeinterface next : ()Ljava/lang/Object;
    //   490: checkcast java/util/Map$Entry
    //   493: invokeinterface getValue : ()Ljava/lang/Object;
    //   498: checkcast q/d
    //   501: getfield b : I
    //   504: ior
    //   505: istore_2
    //   506: goto -> 474
    //   509: aload #6
    //   511: getfield f : Ljava/util/LinkedHashMap;
    //   514: aload #6
    //   516: getfield e : Ljava/lang/String;
    //   519: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   522: checkcast q/d
    //   525: astore_1
    //   526: aload_1
    //   527: ifnull -> 760
    //   530: aload #6
    //   532: getfield j : Landroidx/work/impl/foreground/a$a;
    //   535: astore #6
    //   537: aload_1
    //   538: getfield a : I
    //   541: istore_3
    //   542: aload_1
    //   543: getfield c : Landroid/app/Notification;
    //   546: astore_1
    //   547: aload #6
    //   549: checkcast androidx/work/impl/foreground/SystemForegroundService
    //   552: astore #6
    //   554: aload #6
    //   556: getfield b : Landroid/os/Handler;
    //   559: new y/c
    //   562: dup
    //   563: aload #6
    //   565: iload_3
    //   566: aload_1
    //   567: iload_2
    //   568: invokespecial <init> : (Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V
    //   571: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   574: pop
    //   575: iconst_3
    //   576: ireturn
    //   577: ldc_w 'ACTION_CANCEL_WORK'
    //   580: aload #7
    //   582: invokevirtual equals : (Ljava/lang/Object;)Z
    //   585: ifeq -> 680
    //   588: invokestatic c : ()Lq/h;
    //   591: getstatic androidx/work/impl/foreground/a.k : Ljava/lang/String;
    //   594: ldc_w 'Stopping foreground work for %s'
    //   597: iconst_1
    //   598: anewarray java/lang/Object
    //   601: dup
    //   602: iconst_0
    //   603: aload_1
    //   604: aastore
    //   605: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   608: iconst_0
    //   609: anewarray java/lang/Throwable
    //   612: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   615: aload_1
    //   616: ldc 'KEY_WORKSPEC_ID'
    //   618: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   621: astore #7
    //   623: aload #7
    //   625: ifnull -> 760
    //   628: aload #7
    //   630: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   633: ifne -> 760
    //   636: aload #6
    //   638: getfield b : Lr/k;
    //   641: astore_1
    //   642: aload #7
    //   644: invokestatic fromString : (Ljava/lang/String;)Ljava/util/UUID;
    //   647: astore #6
    //   649: aload_1
    //   650: invokevirtual getClass : ()Ljava/lang/Class;
    //   653: pop
    //   654: new a0/a
    //   657: dup
    //   658: aload_1
    //   659: aload #6
    //   661: invokespecial <init> : (Lr/k;Ljava/util/UUID;)V
    //   664: astore #6
    //   666: aload_1
    //   667: getfield d : Lc0/a;
    //   670: checkcast c0/b
    //   673: aload #6
    //   675: invokevirtual a : (Ljava/lang/Runnable;)V
    //   678: iconst_3
    //   679: ireturn
    //   680: ldc_w 'ACTION_STOP_FOREGROUND'
    //   683: aload #7
    //   685: invokevirtual equals : (Ljava/lang/Object;)Z
    //   688: ifeq -> 760
    //   691: invokestatic c : ()Lq/h;
    //   694: getstatic androidx/work/impl/foreground/a.k : Ljava/lang/String;
    //   697: ldc_w 'Stopping foreground service'
    //   700: iconst_0
    //   701: anewarray java/lang/Throwable
    //   704: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   707: aload #6
    //   709: getfield j : Landroidx/work/impl/foreground/a$a;
    //   712: astore_1
    //   713: aload_1
    //   714: ifnull -> 760
    //   717: aload_1
    //   718: checkcast androidx/work/impl/foreground/SystemForegroundService
    //   721: astore_1
    //   722: aload_1
    //   723: iconst_1
    //   724: putfield c : Z
    //   727: invokestatic c : ()Lq/h;
    //   730: getstatic androidx/work/impl/foreground/SystemForegroundService.f : Ljava/lang/String;
    //   733: ldc_w 'All commands completed.'
    //   736: iconst_0
    //   737: anewarray java/lang/Throwable
    //   740: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   743: getstatic android/os/Build$VERSION.SDK_INT : I
    //   746: bipush #26
    //   748: if_icmplt -> 756
    //   751: aload_1
    //   752: iconst_1
    //   753: invokevirtual stopForeground : (Z)V
    //   756: aload_1
    //   757: invokevirtual stopSelf : ()V
    //   760: iconst_3
    //   761: ireturn
    // Exception table:
    //   from	to	target	type
    //   58	69	121	finally
    //   89	103	115	finally
    //   116	119	115	finally
    //   122	125	121	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */