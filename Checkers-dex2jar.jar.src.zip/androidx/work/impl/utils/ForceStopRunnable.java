package androidx.work.impl.utils;

import a0.j;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.text.TextUtils;
import android.util.Log;
import androidx.work.a;
import g.a;
import java.util.concurrent.TimeUnit;
import q.h;
import r.j;
import r.k;

public final class ForceStopRunnable implements Runnable {
  public static final String l = h.e("ForceStopRunnable");
  
  public static final long m = TimeUnit.DAYS.toMillis(3650L);
  
  public final Context i;
  
  public final k j;
  
  public int k;
  
  public ForceStopRunnable(Context paramContext, k paramk) {
    this.i = paramContext.getApplicationContext();
    this.j = paramk;
    this.k = 0;
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  public static void c(Context paramContext) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (a.a()) {
      i = 167772160;
    } else {
      i = 134217728;
    } 
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    PendingIntent pendingIntent = PendingIntent.getBroadcast(paramContext, -1, intent, i);
    long l1 = System.currentTimeMillis();
    long l2 = m;
    if (alarmManager != null)
      alarmManager.setExact(0, l1 + l2, pendingIntent); 
  }
  
  public final void a() {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #23
    //   5: if_icmplt -> 24
    //   8: aload_0
    //   9: getfield i : Landroid/content/Context;
    //   12: aload_0
    //   13: getfield j : Lr/k;
    //   16: invokestatic h : (Landroid/content/Context;Lr/k;)Z
    //   19: istore #4
    //   21: goto -> 27
    //   24: iconst_0
    //   25: istore #4
    //   27: aload_0
    //   28: getfield j : Lr/k;
    //   31: getfield c : Landroidx/work/impl/WorkDatabase;
    //   34: astore #6
    //   36: aload #6
    //   38: invokevirtual n : ()Lz/q;
    //   41: astore #8
    //   43: aload #6
    //   45: invokevirtual m : ()Lz/n;
    //   48: astore #7
    //   50: aload #6
    //   52: invokevirtual c : ()V
    //   55: aload #8
    //   57: checkcast z/r
    //   60: astore #8
    //   62: aload #8
    //   64: invokevirtual d : ()Ljava/util/ArrayList;
    //   67: astore #9
    //   69: aload #9
    //   71: invokevirtual isEmpty : ()Z
    //   74: istore #5
    //   76: iconst_1
    //   77: istore_3
    //   78: iload #5
    //   80: iconst_1
    //   81: ixor
    //   82: istore_1
    //   83: iload_1
    //   84: ifeq -> 154
    //   87: aload #9
    //   89: invokevirtual iterator : ()Ljava/util/Iterator;
    //   92: astore #9
    //   94: aload #9
    //   96: invokeinterface hasNext : ()Z
    //   101: ifeq -> 154
    //   104: aload #9
    //   106: invokeinterface next : ()Ljava/lang/Object;
    //   111: checkcast z/p
    //   114: astore #10
    //   116: aload #8
    //   118: getstatic q/m.i : Lq/m;
    //   121: iconst_1
    //   122: anewarray java/lang/String
    //   125: dup
    //   126: iconst_0
    //   127: aload #10
    //   129: getfield a : Ljava/lang/String;
    //   132: aastore
    //   133: invokevirtual p : (Lq/m;[Ljava/lang/String;)I
    //   136: pop
    //   137: aload #8
    //   139: aload #10
    //   141: getfield a : Ljava/lang/String;
    //   144: ldc2_w -1
    //   147: invokevirtual l : (Ljava/lang/String;J)I
    //   150: pop
    //   151: goto -> 94
    //   154: aload #7
    //   156: checkcast z/o
    //   159: invokevirtual b : ()V
    //   162: aload #6
    //   164: invokevirtual h : ()V
    //   167: aload #6
    //   169: invokevirtual f : ()V
    //   172: iload_1
    //   173: ifne -> 189
    //   176: iload #4
    //   178: ifeq -> 184
    //   181: goto -> 189
    //   184: iconst_0
    //   185: istore_1
    //   186: goto -> 191
    //   189: iconst_1
    //   190: istore_1
    //   191: aload_0
    //   192: getfield j : Lr/k;
    //   195: getfield g : La0/h;
    //   198: getfield a : Landroidx/work/impl/WorkDatabase;
    //   201: invokevirtual j : ()Lz/e;
    //   204: checkcast z/f
    //   207: ldc 'reschedule_needed'
    //   209: invokevirtual a : (Ljava/lang/String;)Ljava/lang/Long;
    //   212: astore #6
    //   214: aload #6
    //   216: ifnull -> 234
    //   219: aload #6
    //   221: invokevirtual longValue : ()J
    //   224: lconst_1
    //   225: lcmp
    //   226: ifne -> 234
    //   229: iconst_1
    //   230: istore_2
    //   231: goto -> 236
    //   234: iconst_0
    //   235: istore_2
    //   236: iload_2
    //   237: ifeq -> 306
    //   240: invokestatic c : ()Lq/h;
    //   243: getstatic androidx/work/impl/utils/ForceStopRunnable.l : Ljava/lang/String;
    //   246: ldc 'Rescheduling Workers.'
    //   248: iconst_0
    //   249: anewarray java/lang/Throwable
    //   252: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   255: aload_0
    //   256: getfield j : Lr/k;
    //   259: invokevirtual e : ()V
    //   262: aload_0
    //   263: getfield j : Lr/k;
    //   266: getfield g : La0/h;
    //   269: astore #6
    //   271: aload #6
    //   273: invokevirtual getClass : ()Ljava/lang/Class;
    //   276: pop
    //   277: new z/d
    //   280: dup
    //   281: ldc 'reschedule_needed'
    //   283: lconst_0
    //   284: invokespecial <init> : (Ljava/lang/String;J)V
    //   287: astore #7
    //   289: aload #6
    //   291: getfield a : Landroidx/work/impl/WorkDatabase;
    //   294: invokevirtual j : ()Lz/e;
    //   297: checkcast z/f
    //   300: aload #7
    //   302: invokevirtual b : (Lz/d;)V
    //   305: return
    //   306: ldc 536870912
    //   308: istore_2
    //   309: invokestatic a : ()Z
    //   312: ifeq -> 318
    //   315: ldc 570425344
    //   317: istore_2
    //   318: aload_0
    //   319: getfield i : Landroid/content/Context;
    //   322: astore #6
    //   324: new android/content/Intent
    //   327: dup
    //   328: invokespecial <init> : ()V
    //   331: astore #7
    //   333: aload #7
    //   335: new android/content/ComponentName
    //   338: dup
    //   339: aload #6
    //   341: ldc androidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver
    //   343: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   346: invokevirtual setComponent : (Landroid/content/ComponentName;)Landroid/content/Intent;
    //   349: pop
    //   350: aload #7
    //   352: ldc 'ACTION_FORCE_STOP_RESCHEDULE'
    //   354: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
    //   357: pop
    //   358: aload #6
    //   360: iconst_m1
    //   361: aload #7
    //   363: iload_2
    //   364: invokestatic getBroadcast : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   367: astore #6
    //   369: getstatic android/os/Build$VERSION.SDK_INT : I
    //   372: bipush #30
    //   374: if_icmplt -> 460
    //   377: aload #6
    //   379: ifnull -> 387
    //   382: aload #6
    //   384: invokevirtual cancel : ()V
    //   387: aload_0
    //   388: getfield i : Landroid/content/Context;
    //   391: ldc_w 'activity'
    //   394: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   397: checkcast android/app/ActivityManager
    //   400: aconst_null
    //   401: iconst_0
    //   402: iconst_0
    //   403: invokevirtual getHistoricalProcessExitReasons : (Ljava/lang/String;II)Ljava/util/List;
    //   406: astore #6
    //   408: aload #6
    //   410: ifnull -> 477
    //   413: aload #6
    //   415: invokeinterface isEmpty : ()Z
    //   420: ifne -> 477
    //   423: iconst_0
    //   424: istore_2
    //   425: iload_2
    //   426: aload #6
    //   428: invokeinterface size : ()I
    //   433: if_icmpge -> 477
    //   436: aload #6
    //   438: iload_2
    //   439: invokeinterface get : (I)Ljava/lang/Object;
    //   444: checkcast android/app/ApplicationExitInfo
    //   447: invokevirtual getReason : ()I
    //   450: bipush #10
    //   452: if_icmpne -> 601
    //   455: iload_3
    //   456: istore_2
    //   457: goto -> 512
    //   460: aload #6
    //   462: ifnonnull -> 477
    //   465: aload_0
    //   466: getfield i : Landroid/content/Context;
    //   469: invokestatic c : (Landroid/content/Context;)V
    //   472: iload_3
    //   473: istore_2
    //   474: goto -> 512
    //   477: iconst_0
    //   478: istore_2
    //   479: goto -> 512
    //   482: astore #6
    //   484: goto -> 489
    //   487: astore #6
    //   489: invokestatic c : ()Lq/h;
    //   492: getstatic androidx/work/impl/utils/ForceStopRunnable.l : Ljava/lang/String;
    //   495: ldc_w 'Ignoring exception'
    //   498: iconst_1
    //   499: anewarray java/lang/Throwable
    //   502: dup
    //   503: iconst_0
    //   504: aload #6
    //   506: aastore
    //   507: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   510: iload_3
    //   511: istore_2
    //   512: iload_2
    //   513: ifeq -> 540
    //   516: invokestatic c : ()Lq/h;
    //   519: getstatic androidx/work/impl/utils/ForceStopRunnable.l : Ljava/lang/String;
    //   522: ldc_w 'Application was force-stopped, rescheduling.'
    //   525: iconst_0
    //   526: anewarray java/lang/Throwable
    //   529: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   532: aload_0
    //   533: getfield j : Lr/k;
    //   536: invokevirtual e : ()V
    //   539: return
    //   540: iload_1
    //   541: ifeq -> 584
    //   544: invokestatic c : ()Lq/h;
    //   547: getstatic androidx/work/impl/utils/ForceStopRunnable.l : Ljava/lang/String;
    //   550: ldc_w 'Found unfinished work, scheduling it.'
    //   553: iconst_0
    //   554: anewarray java/lang/Throwable
    //   557: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   560: aload_0
    //   561: getfield j : Lr/k;
    //   564: astore #6
    //   566: aload #6
    //   568: getfield b : Landroidx/work/a;
    //   571: aload #6
    //   573: getfield c : Landroidx/work/impl/WorkDatabase;
    //   576: aload #6
    //   578: getfield e : Ljava/util/List;
    //   581: invokestatic a : (Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V
    //   584: return
    //   585: astore #7
    //   587: aload #6
    //   589: invokevirtual f : ()V
    //   592: goto -> 598
    //   595: aload #7
    //   597: athrow
    //   598: goto -> 595
    //   601: iload_2
    //   602: iconst_1
    //   603: iadd
    //   604: istore_2
    //   605: goto -> 425
    // Exception table:
    //   from	to	target	type
    //   55	76	585	finally
    //   87	94	585	finally
    //   94	151	585	finally
    //   154	167	585	finally
    //   309	315	487	java/lang/SecurityException
    //   309	315	482	java/lang/IllegalArgumentException
    //   318	377	487	java/lang/SecurityException
    //   318	377	482	java/lang/IllegalArgumentException
    //   382	387	487	java/lang/SecurityException
    //   382	387	482	java/lang/IllegalArgumentException
    //   387	408	487	java/lang/SecurityException
    //   387	408	482	java/lang/IllegalArgumentException
    //   413	423	487	java/lang/SecurityException
    //   413	423	482	java/lang/IllegalArgumentException
    //   425	455	487	java/lang/SecurityException
    //   425	455	482	java/lang/IllegalArgumentException
    //   465	472	487	java/lang/SecurityException
    //   465	472	482	java/lang/IllegalArgumentException
  }
  
  public final boolean b() {
    a a = this.j.b;
    a.getClass();
    if (TextUtils.isEmpty(null)) {
      h.c().a(l, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = j.a(this.i, a);
    h.c().a(l, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  public final void run() {
    try {
      boolean bool = b();
      if (!bool)
        return; 
      while (true) {
        j.a(this.i);
        h.c().a(l, "Performing cleanup operations.", new Throwable[0]);
        try {
          a();
          return;
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
        
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        int i = this.k + 1;
        this.k = i;
        if (i < 3) {
          long l = i;
          h.c().a(l, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { (Throwable)sQLiteAccessPermException });
          i = this.k;
          l = i;
          try {
            Thread.sleep(l * 300L);
          } catch (InterruptedException interruptedException) {}
          continue;
        } 
        h.c().b(l, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { interruptedException });
        IllegalStateException illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", interruptedException);
        this.j.b.getClass();
        throw illegalStateException;
      } 
    } finally {
      this.j.d();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    public static final String a = h.e("ForceStopRunnable$Rcvr");
    
    public final void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        h h = h.c();
        String str = a;
        if (((h.a)h).b <= 2)
          Log.v(str, "Rescheduling alarm that keeps track of force-stops."); 
        ForceStopRunnable.c(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */