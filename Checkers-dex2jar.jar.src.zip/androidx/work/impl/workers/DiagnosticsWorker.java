package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.b;
import androidx.work.impl.WorkDatabase;
import i.j;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import l.c;
import q.b;
import q.h;
import r.k;
import t0.b;
import z.g;
import z.h;
import z.i;
import z.k;
import z.l;
import z.p;
import z.q;
import z.r;
import z.t;
import z.u;
import z.v;

public class DiagnosticsWorker extends Worker {
  public static final String g = h.e("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(k paramk, t paramt, h paramh, ArrayList paramArrayList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (p p : paramArrayList) {
      Integer integer;
      ArrayList<String> arrayList1;
      String str1 = p.a;
      g g = ((i)paramh).a(str1);
      str1 = null;
      if (g != null)
        integer = Integer.valueOf(g.b); 
      String str5 = p.a;
      l l = (l)paramk;
      l.getClass();
      j j = j.d(1, "SELECT name FROM workname WHERE work_spec_id=?");
      if (str5 == null) {
        j.f(1);
      } else {
        j.g(1, str5);
      } 
      l.a.b();
      Cursor cursor = l.a.g((c)j);
      try {
        arrayList1 = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList1.add(cursor.getString(0)); 
      } finally {}
      cursor.close();
      j.h();
      String str3 = p.a;
      ArrayList arrayList = ((u)paramt).a(str3);
      String str4 = TextUtils.join(",", arrayList1);
      String str2 = TextUtils.join(",", arrayList);
      stringBuilder.append(String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", new Object[] { p.a, p.c, integer, p.b.name(), str4, str2 }));
    } 
    return stringBuilder.toString();
  }
  
  public final ListenableWorker.a doWork() {
    ArrayList arrayList;
    String str;
    WorkDatabase workDatabase = (k.b(getApplicationContext())).c;
    q q = workDatabase.n();
    k k = workDatabase.l();
    t t = workDatabase.o();
    h h = workDatabase.k();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    r r = (r)q;
    r.getClass();
    j j = j.d(1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC");
    j.e(1, l1 - l2);
    r.a.b();
    Cursor cursor = r.a.g((c)j);
    try {
      int n = b.b(cursor, "required_network_type");
      int i1 = b.b(cursor, "requires_charging");
      int m = b.b(cursor, "requires_device_idle");
      int i6 = b.b(cursor, "requires_battery_not_low");
      int i7 = b.b(cursor, "requires_storage_not_low");
      int i8 = b.b(cursor, "trigger_content_update_delay");
      int i9 = b.b(cursor, "trigger_max_content_delay");
      int i10 = b.b(cursor, "content_uri_triggers");
      int i11 = b.b(cursor, "id");
      int i = b.b(cursor, "state");
      int i2 = b.b(cursor, "worker_class_name");
      int i3 = b.b(cursor, "input_merger_class_name");
      int i4 = b.b(cursor, "input");
      int i5 = b.b(cursor, "output");
      try {
        int i18 = b.b(cursor, "initial_delay");
        int i19 = b.b(cursor, "interval_duration");
        int i22 = b.b(cursor, "flex_duration");
        int i17 = b.b(cursor, "run_attempt_count");
        int i12 = b.b(cursor, "backoff_policy");
        int i13 = b.b(cursor, "backoff_delay_duration");
        int i21 = b.b(cursor, "period_start_time");
        int i15 = b.b(cursor, "minimum_retention_duration");
        int i16 = b.b(cursor, "schedule_requested_at");
        int i14 = b.b(cursor, "run_in_foreground");
        int i20 = b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList1 = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(i11);
            String str2 = cursor.getString(i2);
            b b = new b();
            b.a = v.c(cursor.getInt(n));
            if (cursor.getInt(i1) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.b = bool;
            if (cursor.getInt(m) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.c = bool;
            if (cursor.getInt(i6) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.d = bool;
            if (cursor.getInt(i7) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.e = bool;
            b.f = cursor.getLong(i8);
            b.g = cursor.getLong(i9);
            b.h = v.a(cursor.getBlob(i10));
            p p = new p(str1, str2);
            p.b = v.e(cursor.getInt(i));
            p.d = cursor.getString(i3);
            p.e = b.a(cursor.getBlob(i4));
            p.f = b.a(cursor.getBlob(i5));
            p.g = cursor.getLong(i18);
            p.h = cursor.getLong(i19);
            p.i = cursor.getLong(i22);
            p.k = cursor.getInt(i17);
            p.l = v.b(cursor.getInt(i12));
            p.m = cursor.getLong(i13);
            p.n = cursor.getLong(i21);
            p.o = cursor.getLong(i15);
            p.p = cursor.getLong(i16);
            if (cursor.getInt(i14) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.d(cursor.getInt(i20));
            p.j = b;
            arrayList1.add(p);
            continue;
          } 
          cursor.close();
          j.h();
          ArrayList arrayList2 = r.d();
          arrayList = r.b();
          if (!arrayList1.isEmpty()) {
            h h1 = h.c();
            String str1 = g;
            h1.d(str1, "Recently completed work:\n\n", new Throwable[0]);
            h.c().d(str1, a(k, t, h, arrayList1), new Throwable[0]);
          } 
          if (!arrayList2.isEmpty()) {
            h h1 = h.c();
            String str1 = g;
            h1.d(str1, "Running work:\n\n", new Throwable[0]);
            h.c().d(str1, a(k, t, h, arrayList2), new Throwable[0]);
          } 
          if (!arrayList.isEmpty()) {
            h h1 = h.c();
            str = g;
            h1.d(str, "Enqueued work:\n\n", new Throwable[0]);
            h.c().d(str, a(k, t, h, arrayList), new Throwable[0]);
          } 
          return (ListenableWorker.a)new ListenableWorker.a.c();
        } 
      } finally {}
    } finally {}
    str.close();
    arrayList.h();
    throw q;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */