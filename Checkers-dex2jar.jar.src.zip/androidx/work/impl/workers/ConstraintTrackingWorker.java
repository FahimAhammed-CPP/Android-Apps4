package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import b0.c;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import q.h;
import r.k;
import v.c;
import v.d;
import z.p;
import z.q;
import z.r;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  public static final String k = h.e("ConstraintTrkngWrkr");
  
  public WorkerParameters f;
  
  public final Object g;
  
  public volatile boolean h;
  
  public c<ListenableWorker.a> i;
  
  public ListenableWorker j;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.f = paramWorkerParameters;
    this.g = new Object();
    this.h = false;
    this.i = new c();
  }
  
  public final void a() {
    this.i.i(new ListenableWorker.a.a());
  }
  
  public final void d(ArrayList paramArrayList) {
    h.c().a(k, String.format("Constraints changed for %s", new Object[] { paramArrayList }), new Throwable[0]);
    synchronized (this.g) {
      this.h = true;
      return;
    } 
  }
  
  public final void e(List<String> paramList) {}
  
  public final c0.a getTaskExecutor() {
    return (k.b(getApplicationContext())).d;
  }
  
  public final boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.j;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public final void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.j;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.j.stop(); 
  }
  
  public final f1.a<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (f1.a<ListenableWorker.a>)this.i;
  }
  
  public final class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public final void run() {
      ConstraintTrackingWorker constraintTrackingWorker = this.i;
      Object object = (constraintTrackingWorker.getInputData()).a.get("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (object instanceof String) {
        object = object;
      } else {
        object = null;
      } 
      if (TextUtils.isEmpty((CharSequence)object)) {
        h.c().b(ConstraintTrackingWorker.k, "No worker to delegate to.", new Throwable[0]);
      } else {
        ListenableWorker listenableWorker = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), (String)object, constraintTrackingWorker.f);
        constraintTrackingWorker.j = listenableWorker;
        if (listenableWorker == null) {
          h.c().a(ConstraintTrackingWorker.k, "No worker to delegate to.", new Throwable[0]);
        } else {
          q q = (k.b(constraintTrackingWorker.getApplicationContext())).c.n();
          String str = constraintTrackingWorker.getId().toString();
          p p = ((r)q).i(str);
          if (p != null) {
            d d = new d(constraintTrackingWorker.getApplicationContext(), constraintTrackingWorker.getTaskExecutor(), constraintTrackingWorker);
            d.b(Collections.singletonList(p));
            if (d.a(constraintTrackingWorker.getId().toString())) {
              h.c().a(ConstraintTrackingWorker.k, String.format("Constraints met for delegate %s", new Object[] { object }), new Throwable[0]);
              try {
                return;
              } finally {
                d = null;
                h h = h.c();
                String str1 = ConstraintTrackingWorker.k;
                h.a(str1, String.format("Delegated worker %s threw exception in startWork.", new Object[] { object }), new Throwable[] { (Throwable)d });
              } 
            } 
            h.c().a(ConstraintTrackingWorker.k, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { object }), new Throwable[0]);
            constraintTrackingWorker.i.i(new ListenableWorker.a.b());
            return;
          } 
        } 
      } 
      constraintTrackingWorker.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */