package androidx.work.impl;

import android.content.Context;
import android.os.Build;

public final class a {
  public static a a = new a();
  
  public static b b = new b();
  
  public static c c = new c();
  
  public static d d = new d();
  
  public static e e = new e();
  
  public static f f = new f();
  
  public static g g = new g();
  
  public final class a extends j.a {
    public a() {
      super(1, 2);
    }
    
    public final void a(m.a param1a) {
      param1a.d("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1a.d("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
      param1a.d("DROP TABLE IF EXISTS alarmInfo");
      param1a.d("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
    }
  }
  
  public final class b extends j.a {
    public b() {
      super(3, 4);
    }
    
    public final void a(m.a param1a) {
      if (Build.VERSION.SDK_INT >= 23)
        param1a.d("UPDATE workspec SET schedule_requested_at=0 WHERE state NOT IN (2, 3, 5) AND schedule_requested_at=-1 AND interval_duration<>0"); 
    }
  }
  
  public final class c extends j.a {
    public c() {
      super(4, 5);
    }
    
    public final void a(m.a param1a) {
      param1a.d("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
      param1a.d("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
    }
  }
  
  public final class d extends j.a {
    public d() {
      super(6, 7);
    }
    
    public final void a(m.a param1a) {
      param1a.d("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
    }
  }
  
  public final class e extends j.a {
    public e() {
      super(7, 8);
    }
    
    public final void a(m.a param1a) {
      param1a.d("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)");
    }
  }
  
  public final class f extends j.a {
    public f() {
      super(8, 9);
    }
    
    public final void a(m.a param1a) {
      param1a.d("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  public final class g extends j.a {
    public g() {
      super(11, 12);
    }
    
    public final void a(m.a param1a) {
      param1a.d("ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  public static final class h extends j.a {
    public final Context c;
    
    public h(Context param1Context, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = param1Context;
    }
    
    public final void a(m.a param1a) {
      if (this.b >= 10) {
        param1a.i.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Integer.valueOf(1) });
        return;
      } 
      this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
    }
  }
  
  public static final class i extends j.a {
    public final Context c;
    
    public i(Context param1Context) {
      super(9, 10);
      this.c = param1Context;
    }
    
    public final void a(m.a param1a) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))'
      //   3: invokevirtual d : (Ljava/lang/String;)V
      //   6: aload_0
      //   7: getfield c : Landroid/content/Context;
      //   10: ldc 'androidx.work.util.preferences'
      //   12: iconst_0
      //   13: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   16: astore #8
      //   18: aload #8
      //   20: ldc 'reschedule_needed'
      //   22: invokeinterface contains : (Ljava/lang/String;)Z
      //   27: ifne -> 42
      //   30: aload #8
      //   32: ldc 'last_cancel_all_time_ms'
      //   34: invokeinterface contains : (Ljava/lang/String;)Z
      //   39: ifeq -> 154
      //   42: lconst_0
      //   43: lstore #4
      //   45: aload #8
      //   47: ldc 'last_cancel_all_time_ms'
      //   49: lconst_0
      //   50: invokeinterface getLong : (Ljava/lang/String;J)J
      //   55: lstore #6
      //   57: aload #8
      //   59: ldc 'reschedule_needed'
      //   61: iconst_0
      //   62: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
      //   67: ifeq -> 73
      //   70: lconst_1
      //   71: lstore #4
      //   73: aload_1
      //   74: invokevirtual a : ()V
      //   77: aload_1
      //   78: getfield i : Landroid/database/sqlite/SQLiteDatabase;
      //   81: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   83: iconst_2
      //   84: anewarray java/lang/Object
      //   87: dup
      //   88: iconst_0
      //   89: ldc 'last_cancel_all_time_ms'
      //   91: aastore
      //   92: dup
      //   93: iconst_1
      //   94: lload #6
      //   96: invokestatic valueOf : (J)Ljava/lang/Long;
      //   99: aastore
      //   100: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   103: aload_1
      //   104: getfield i : Landroid/database/sqlite/SQLiteDatabase;
      //   107: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   109: iconst_2
      //   110: anewarray java/lang/Object
      //   113: dup
      //   114: iconst_0
      //   115: ldc 'reschedule_needed'
      //   117: aastore
      //   118: dup
      //   119: iconst_1
      //   120: lload #4
      //   122: invokestatic valueOf : (J)Ljava/lang/Long;
      //   125: aastore
      //   126: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   129: aload #8
      //   131: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   136: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   141: invokeinterface apply : ()V
      //   146: aload_1
      //   147: invokevirtual h : ()V
      //   150: aload_1
      //   151: invokevirtual b : ()V
      //   154: aload_0
      //   155: getfield c : Landroid/content/Context;
      //   158: ldc 'androidx.work.util.id'
      //   160: iconst_0
      //   161: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   164: astore #8
      //   166: aload #8
      //   168: ldc 'next_job_scheduler_id'
      //   170: invokeinterface contains : (Ljava/lang/String;)Z
      //   175: ifne -> 190
      //   178: aload #8
      //   180: ldc 'next_job_scheduler_id'
      //   182: invokeinterface contains : (Ljava/lang/String;)Z
      //   187: ifeq -> 291
      //   190: aload #8
      //   192: ldc 'next_job_scheduler_id'
      //   194: iconst_0
      //   195: invokeinterface getInt : (Ljava/lang/String;I)I
      //   200: istore_2
      //   201: aload #8
      //   203: ldc 'next_alarm_manager_id'
      //   205: iconst_0
      //   206: invokeinterface getInt : (Ljava/lang/String;I)I
      //   211: istore_3
      //   212: aload_1
      //   213: invokevirtual a : ()V
      //   216: aload_1
      //   217: getfield i : Landroid/database/sqlite/SQLiteDatabase;
      //   220: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   222: iconst_2
      //   223: anewarray java/lang/Object
      //   226: dup
      //   227: iconst_0
      //   228: ldc 'next_job_scheduler_id'
      //   230: aastore
      //   231: dup
      //   232: iconst_1
      //   233: iload_2
      //   234: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   237: aastore
      //   238: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   241: aload_1
      //   242: getfield i : Landroid/database/sqlite/SQLiteDatabase;
      //   245: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   247: iconst_2
      //   248: anewarray java/lang/Object
      //   251: dup
      //   252: iconst_0
      //   253: ldc 'next_alarm_manager_id'
      //   255: aastore
      //   256: dup
      //   257: iconst_1
      //   258: iload_3
      //   259: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   262: aastore
      //   263: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   266: aload #8
      //   268: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   273: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   278: invokeinterface apply : ()V
      //   283: aload_1
      //   284: invokevirtual h : ()V
      //   287: aload_1
      //   288: invokevirtual b : ()V
      //   291: return
      //   292: astore #8
      //   294: aload_1
      //   295: invokevirtual b : ()V
      //   298: aload #8
      //   300: athrow
      //   301: astore #8
      //   303: aload_1
      //   304: invokevirtual b : ()V
      //   307: aload #8
      //   309: athrow
      // Exception table:
      //   from	to	target	type
      //   77	150	301	finally
      //   216	287	292	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */