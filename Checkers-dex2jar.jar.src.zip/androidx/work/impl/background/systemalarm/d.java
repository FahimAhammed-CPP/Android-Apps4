package androidx.work.impl.background.systemalarm;

import a0.n;
import a0.t;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import java.util.ArrayList;
import q.h;
import r.b;
import r.k;

public final class d implements b {
  public static final String k = h.e("SystemAlarmDispatcher");
  
  public final Context a;
  
  public final c0.a b;
  
  public final t c;
  
  public final r.d d;
  
  public final k e;
  
  public final a f;
  
  public final Handler g;
  
  public final ArrayList h;
  
  public Intent i;
  
  public c j;
  
  public d(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    this.a = context;
    this.f = new a(context);
    this.c = new t();
    k k1 = k.b(paramContext);
    this.e = k1;
    r.d d1 = k1.f;
    this.d = d1;
    this.b = k1.d;
    d1.b(this);
    this.h = new ArrayList();
    this.i = null;
    this.g = new Handler(Looper.getMainLooper());
  }
  
  public final void a(String paramString, boolean paramBoolean) {
    Context context = this.a;
    String str = a.d;
    Intent intent = new Intent(context, SystemAlarmService.class);
    intent.setAction("ACTION_EXECUTION_COMPLETED");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NEEDS_RESCHEDULE", paramBoolean);
    e(new b(0, intent, this));
  }
  
  public final void b(Intent paramIntent, int paramInt) {
    // Byte code:
    //   0: invokestatic c : ()Lq/h;
    //   3: astore #6
    //   5: getstatic androidx/work/impl/background/systemalarm/d.k : Ljava/lang/String;
    //   8: astore #5
    //   10: iconst_0
    //   11: istore_3
    //   12: aload #6
    //   14: aload #5
    //   16: ldc 'Adding command %s (%s)'
    //   18: iconst_2
    //   19: anewarray java/lang/Object
    //   22: dup
    //   23: iconst_0
    //   24: aload_1
    //   25: aastore
    //   26: dup
    //   27: iconst_1
    //   28: iload_2
    //   29: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   32: aastore
    //   33: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   36: iconst_0
    //   37: anewarray java/lang/Throwable
    //   40: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   43: aload_0
    //   44: invokevirtual c : ()V
    //   47: aload_1
    //   48: invokevirtual getAction : ()Ljava/lang/String;
    //   51: astore #6
    //   53: aload #6
    //   55: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   58: ifeq -> 76
    //   61: invokestatic c : ()Lq/h;
    //   64: aload #5
    //   66: ldc 'Unknown command. Ignoring'
    //   68: iconst_0
    //   69: anewarray java/lang/Throwable
    //   72: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   75: return
    //   76: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   78: aload #6
    //   80: invokevirtual equals : (Ljava/lang/Object;)Z
    //   83: ifeq -> 159
    //   86: aload_0
    //   87: invokevirtual c : ()V
    //   90: aload_0
    //   91: getfield h : Ljava/util/ArrayList;
    //   94: astore #5
    //   96: aload #5
    //   98: monitorenter
    //   99: aload_0
    //   100: getfield h : Ljava/util/ArrayList;
    //   103: invokevirtual iterator : ()Ljava/util/Iterator;
    //   106: astore #6
    //   108: aload #6
    //   110: invokeinterface hasNext : ()Z
    //   115: ifeq -> 147
    //   118: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   120: aload #6
    //   122: invokeinterface next : ()Ljava/lang/Object;
    //   127: checkcast android/content/Intent
    //   130: invokevirtual getAction : ()Ljava/lang/String;
    //   133: invokevirtual equals : (Ljava/lang/Object;)Z
    //   136: ifeq -> 108
    //   139: aload #5
    //   141: monitorexit
    //   142: iconst_1
    //   143: istore_3
    //   144: goto -> 221
    //   147: aload #5
    //   149: monitorexit
    //   150: goto -> 221
    //   153: astore_1
    //   154: aload #5
    //   156: monitorexit
    //   157: aload_1
    //   158: athrow
    //   159: aload_1
    //   160: ldc 'KEY_START_ID'
    //   162: iload_2
    //   163: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   166: pop
    //   167: aload_0
    //   168: getfield h : Ljava/util/ArrayList;
    //   171: astore #5
    //   173: aload #5
    //   175: monitorenter
    //   176: aload_0
    //   177: getfield h : Ljava/util/ArrayList;
    //   180: invokevirtual isEmpty : ()Z
    //   183: istore #4
    //   185: aload_0
    //   186: getfield h : Ljava/util/ArrayList;
    //   189: aload_1
    //   190: invokevirtual add : (Ljava/lang/Object;)Z
    //   193: pop
    //   194: iload #4
    //   196: iconst_1
    //   197: ixor
    //   198: ifne -> 205
    //   201: aload_0
    //   202: invokevirtual f : ()V
    //   205: aload #5
    //   207: monitorexit
    //   208: return
    //   209: astore_1
    //   210: aload #5
    //   212: monitorexit
    //   213: goto -> 218
    //   216: aload_1
    //   217: athrow
    //   218: goto -> 216
    //   221: iload_3
    //   222: ifeq -> 159
    //   225: return
    // Exception table:
    //   from	to	target	type
    //   99	108	153	finally
    //   108	142	153	finally
    //   147	150	153	finally
    //   154	157	153	finally
    //   176	194	209	finally
    //   201	205	209	finally
    //   205	208	209	finally
    //   210	213	209	finally
  }
  
  public final void c() {
    if (this.g.getLooper().getThread() == Thread.currentThread())
      return; 
    throw new IllegalStateException("Needs to be invoked on the main thread.");
  }
  
  public final void d() {
    h.c().a(k, "Destroying SystemAlarmDispatcher", new Throwable[0]);
    null = this.d;
    synchronized (null.k) {
      null.j.remove(this);
      null = this.c;
      if (!((t)null).a.isShutdown())
        ((t)null).a.shutdownNow(); 
      this.j = null;
      return;
    } 
  }
  
  public final void e(Runnable paramRunnable) {
    this.g.post(paramRunnable);
  }
  
  public final void f() {
    c();
    PowerManager.WakeLock wakeLock = n.a(this.a, "ProcessCommand");
    try {
      wakeLock.acquire();
      c0.a a1 = this.e.d;
      a a2 = new a(this);
      ((c0.b)a1).a(a2);
      return;
    } finally {
      wakeLock.release();
    } 
  }
  
  public final class a implements Runnable {
    public a(d this$0) {}
    
    public final void run() {
      ArrayList arrayList;
      d d1;
      synchronized (this.i.h) {
        d.d d2;
        d d3 = this.i;
        d3.i = d3.h.get(0);
        Intent intent = this.i.i;
        if (intent != null) {
          String str1 = intent.getAction();
          int i = this.i.i.getIntExtra("KEY_START_ID", 0);
          h h = h.c();
          String str2 = d.k;
          h.a(str2, String.format("Processing command %s, %s", new Object[] { this.i.i, Integer.valueOf(i) }), new Throwable[0]);
          PowerManager.WakeLock wakeLock = n.a(this.i.a, String.format("%s (%s)", new Object[] { str1, Integer.valueOf(i) }));
          try {
            h.c().a(str2, String.format("Acquiring operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.acquire();
            d d4 = this.i;
            d4.f.d(i, d4.i, d4);
            h.c().a(str2, String.format("Releasing operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.release();
            d1 = this.i;
          } finally {
            str2 = null;
          } 
        } else {
          return;
        } 
        d1.e(d2);
        return;
      } 
    }
  }
  
  public static final class b implements Runnable {
    public final d i;
    
    public final Intent j;
    
    public final int k;
    
    public b(int param1Int, Intent param1Intent, d param1d) {
      this.i = param1d;
      this.j = param1Intent;
      this.k = param1Int;
    }
    
    public final void run() {
      this.i.b(this.j, this.k);
    }
  }
  
  public static interface c {}
  
  public static final class d implements Runnable {
    public final d i;
    
    public d(d param1d) {
      this.i = param1d;
    }
    
    public final void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield i : Landroidx/work/impl/background/systemalarm/d;
      //   4: astore #4
      //   6: aload #4
      //   8: invokevirtual getClass : ()Ljava/lang/Class;
      //   11: pop
      //   12: invokestatic c : ()Lq/h;
      //   15: astore_3
      //   16: getstatic androidx/work/impl/background/systemalarm/d.k : Ljava/lang/String;
      //   19: astore #5
      //   21: aload_3
      //   22: aload #5
      //   24: ldc 'Checking if commands are complete.'
      //   26: iconst_0
      //   27: anewarray java/lang/Throwable
      //   30: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   33: aload #4
      //   35: invokevirtual c : ()V
      //   38: aload #4
      //   40: getfield h : Ljava/util/ArrayList;
      //   43: astore_3
      //   44: aload_3
      //   45: monitorenter
      //   46: aload #4
      //   48: getfield i : Landroid/content/Intent;
      //   51: astore #6
      //   53: iconst_1
      //   54: istore_2
      //   55: aload #6
      //   57: ifnull -> 131
      //   60: invokestatic c : ()Lq/h;
      //   63: aload #5
      //   65: ldc 'Removing command %s'
      //   67: iconst_1
      //   68: anewarray java/lang/Object
      //   71: dup
      //   72: iconst_0
      //   73: aload #4
      //   75: getfield i : Landroid/content/Intent;
      //   78: aastore
      //   79: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   82: iconst_0
      //   83: anewarray java/lang/Throwable
      //   86: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   89: aload #4
      //   91: getfield h : Ljava/util/ArrayList;
      //   94: iconst_0
      //   95: invokevirtual remove : (I)Ljava/lang/Object;
      //   98: checkcast android/content/Intent
      //   101: aload #4
      //   103: getfield i : Landroid/content/Intent;
      //   106: invokevirtual equals : (Ljava/lang/Object;)Z
      //   109: ifeq -> 121
      //   112: aload #4
      //   114: aconst_null
      //   115: putfield i : Landroid/content/Intent;
      //   118: goto -> 131
      //   121: new java/lang/IllegalStateException
      //   124: dup
      //   125: ldc 'Dequeue-d command is not the first.'
      //   127: invokespecial <init> : (Ljava/lang/String;)V
      //   130: athrow
      //   131: aload #4
      //   133: getfield b : Lc0/a;
      //   136: checkcast c0/b
      //   139: getfield a : La0/k;
      //   142: astore #6
      //   144: aload #4
      //   146: getfield f : Landroidx/work/impl/background/systemalarm/a;
      //   149: astore #8
      //   151: aload #8
      //   153: getfield c : Ljava/lang/Object;
      //   156: astore #7
      //   158: aload #7
      //   160: monitorenter
      //   161: aload #8
      //   163: getfield b : Ljava/util/HashMap;
      //   166: invokevirtual isEmpty : ()Z
      //   169: ifne -> 307
      //   172: iconst_1
      //   173: istore_1
      //   174: goto -> 177
      //   177: aload #7
      //   179: monitorexit
      //   180: iload_1
      //   181: ifne -> 273
      //   184: aload #4
      //   186: getfield h : Ljava/util/ArrayList;
      //   189: invokevirtual isEmpty : ()Z
      //   192: ifeq -> 273
      //   195: aload #6
      //   197: getfield k : Ljava/lang/Object;
      //   200: astore #7
      //   202: aload #7
      //   204: monitorenter
      //   205: aload #6
      //   207: getfield i : Ljava/util/ArrayDeque;
      //   210: invokevirtual isEmpty : ()Z
      //   213: ifne -> 312
      //   216: iload_2
      //   217: istore_1
      //   218: goto -> 221
      //   221: aload #7
      //   223: monitorexit
      //   224: iload_1
      //   225: ifne -> 273
      //   228: invokestatic c : ()Lq/h;
      //   231: aload #5
      //   233: ldc 'No more commands & intents.'
      //   235: iconst_0
      //   236: anewarray java/lang/Throwable
      //   239: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   242: aload #4
      //   244: getfield j : Landroidx/work/impl/background/systemalarm/d$c;
      //   247: astore #4
      //   249: aload #4
      //   251: ifnull -> 289
      //   254: aload #4
      //   256: checkcast androidx/work/impl/background/systemalarm/SystemAlarmService
      //   259: invokevirtual b : ()V
      //   262: goto -> 289
      //   265: astore #4
      //   267: aload #7
      //   269: monitorexit
      //   270: aload #4
      //   272: athrow
      //   273: aload #4
      //   275: getfield h : Ljava/util/ArrayList;
      //   278: invokevirtual isEmpty : ()Z
      //   281: ifne -> 289
      //   284: aload #4
      //   286: invokevirtual f : ()V
      //   289: aload_3
      //   290: monitorexit
      //   291: return
      //   292: astore #4
      //   294: aload #7
      //   296: monitorexit
      //   297: aload #4
      //   299: athrow
      //   300: astore #4
      //   302: aload_3
      //   303: monitorexit
      //   304: aload #4
      //   306: athrow
      //   307: iconst_0
      //   308: istore_1
      //   309: goto -> 177
      //   312: iconst_0
      //   313: istore_1
      //   314: goto -> 221
      // Exception table:
      //   from	to	target	type
      //   46	53	300	finally
      //   60	118	300	finally
      //   121	131	300	finally
      //   131	161	300	finally
      //   161	172	292	finally
      //   177	180	292	finally
      //   184	205	300	finally
      //   205	216	265	finally
      //   221	224	265	finally
      //   228	249	300	finally
      //   254	262	300	finally
      //   267	270	265	finally
      //   270	273	300	finally
      //   273	289	300	finally
      //   289	291	300	finally
      //   294	297	292	finally
      //   297	300	300	finally
      //   302	304	300	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemalarm\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */