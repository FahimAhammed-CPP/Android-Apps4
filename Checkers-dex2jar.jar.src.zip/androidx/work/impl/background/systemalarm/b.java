package androidx.work.impl.background.systemalarm;

import android.content.Context;
import q.h;
import v.d;

public final class b {
  public static final String e = h.e("ConstraintsCmdHandler");
  
  public final Context a;
  
  public final int b;
  
  public final d c;
  
  public final d d;
  
  public b(Context paramContext, int paramInt, d paramd) {
    this.a = paramContext;
    this.b = paramInt;
    this.c = paramd;
    this.d = new d(paramContext, paramd.b, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemalarm\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */