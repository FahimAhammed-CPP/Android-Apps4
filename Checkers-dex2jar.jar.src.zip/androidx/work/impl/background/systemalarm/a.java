package androidx.work.impl.background.systemalarm;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import q.b;
import q.h;
import q.i;
import r.b;
import r.k;
import z.g;
import z.i;
import z.p;
import z.r;

public final class a implements b {
  public static final String d = h.e("CommandHandler");
  
  public final Context a;
  
  public final HashMap b;
  
  public final Object c;
  
  public a(Context paramContext) {
    this.a = paramContext;
    this.b = new HashMap<Object, Object>();
    this.c = new Object();
  }
  
  public static Intent b(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_DELAY_MET");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent c(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_SCHEDULE_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public final void a(String paramString, boolean paramBoolean) {
    synchronized (this.c) {
      b b1 = (b)this.b.remove(paramString);
      if (b1 != null)
        b1.a(paramString, paramBoolean); 
      return;
    } 
  }
  
  public final void d(int paramInt, Intent paramIntent, d paramd) {
    b b1;
    WorkDatabase workDatabase;
    String str1;
    Iterator<p> iterator;
    int i;
    Intent intent;
    String str2;
    Context context;
    String str3 = paramIntent.getAction();
    if ("ACTION_CONSTRAINTS_CHANGED".equals(str3)) {
      boolean bool4;
      int k;
      boolean bool5;
      boolean bool6;
      h.c().a(d, String.format("Handling constraints changed %s", new Object[] { paramIntent }), new Throwable[0]);
      Context context1 = this.a;
      b1 = new b(context1, paramInt, paramd);
      ArrayList arrayList = ((r)paramd.e.c.n()).e();
      String str5 = ConstraintProxy.a;
      Iterator iterator1 = arrayList.iterator();
      boolean bool3 = false;
      boolean bool2 = false;
      boolean bool1 = false;
      int j = 0;
      while (true) {
        bool4 = bool3;
        bool5 = bool2;
        bool6 = bool1;
        k = j;
        if (iterator1.hasNext()) {
          b b2 = ((p)iterator1.next()).j;
          bool4 = bool3 | b2.d;
          bool5 = bool2 | b2.b;
          bool6 = bool1 | b2.e;
          if (b2.a != i.i) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          k = j | paramInt;
          bool3 = bool4;
          bool2 = bool5;
          bool1 = bool6;
          j = k;
          if (bool4) {
            bool3 = bool4;
            bool2 = bool5;
            bool1 = bool6;
            j = k;
            if (bool5) {
              bool3 = bool4;
              bool2 = bool5;
              bool1 = bool6;
              j = k;
              if (bool6) {
                bool3 = bool4;
                bool2 = bool5;
                bool1 = bool6;
                j = k;
                if (k != 0)
                  break; 
              } 
            } 
          } 
          continue;
        } 
        break;
      } 
      String str4 = ConstraintProxyUpdateReceiver.a;
      Intent intent1 = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
      intent1.setComponent(new ComponentName(context1, ConstraintProxyUpdateReceiver.class));
      intent1.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", bool4).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", bool5).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", bool6).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", k);
      context1.sendBroadcast(intent1);
      b1.d.b(arrayList);
      ArrayList<p> arrayList1 = new ArrayList(arrayList.size());
      long l = System.currentTimeMillis();
      for (p p : arrayList) {
        String str = p.a;
        if (l >= p.a() && (!p.b() || b1.d.a(str)))
          arrayList1.add(p); 
      } 
      iterator = arrayList1.iterator();
      while (iterator.hasNext()) {
        String str = ((p)iterator.next()).a;
        intent = b(b1.a, str);
        h.c().a(b.e, String.format("Creating a delay_met command for workSpec with id (%s)", new Object[] { str }), new Throwable[0]);
        d d1 = b1.c;
        d1.e(new d.b(b1.b, intent, d1));
      } 
      b1.d.c();
      return;
    } 
    if ("ACTION_RESCHEDULE".equals(intent)) {
      h.c().a(d, String.format("Handling reschedule %s, %s", new Object[] { b1, Integer.valueOf(paramInt) }), new Throwable[0]);
      ((d)iterator).e.e();
      return;
    } 
    Bundle bundle = b1.getExtras();
    if (bundle == null || bundle.isEmpty()) {
      i = 0;
    } else {
      for (i = 0; i < 1; i++) {
        (new String[1])[0] = "KEY_WORKSPEC_ID";
        if (bundle.get((new String[1])[i]) == null)
          // Byte code: goto -> 674 
      } 
      i = 1;
    } 
    if (i == 0) {
      h.c().b(d, String.format("Invalid request for %s, requires %s.", new Object[] { intent, "KEY_WORKSPEC_ID" }), new Throwable[0]);
      return;
    } 
    if ("ACTION_SCHEDULE_WORK".equals(intent)) {
      str2 = b1.getExtras().getString("KEY_WORKSPEC_ID");
      h h = h.c();
      String str = d;
      h.a(str, String.format("Handling schedule work for %s", new Object[] { str2 }), new Throwable[0]);
      workDatabase = ((d)iterator).e.c;
      workDatabase.c();
      try {
        StringBuilder stringBuilder;
        p p = ((r)workDatabase.n()).i(str2);
        if (p == null) {
          h h1 = h.c();
          stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(str2);
          stringBuilder.append(" because it's no longer in the DB");
          h1.f(str, stringBuilder.toString(), new Throwable[0]);
        } else {
          h h1;
          if (((p)stringBuilder).b.a()) {
            h1 = h.c();
            stringBuilder = new StringBuilder();
            stringBuilder.append("Skipping scheduling ");
            stringBuilder.append(str2);
            stringBuilder.append("because it is finished.");
            h1.f(str, stringBuilder.toString(), new Throwable[0]);
          } else {
            long l = stringBuilder.a();
            if (!stringBuilder.b()) {
              h.c().a(str, String.format("Setting up Alarms for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              t.a.b(this.a, ((d)h1).e, str2, l);
            } else {
              h.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              t.a.b(this.a, ((d)h1).e, str2, l);
              intent = new Intent(this.a, SystemAlarmService.class);
              intent.setAction("ACTION_CONSTRAINTS_CHANGED");
              h1.e(new d.b(paramInt, intent, (d)h1));
            } 
            workDatabase.h();
          } 
        } 
        return;
      } finally {
        workDatabase.f();
      } 
    } 
    if ("ACTION_DELAY_MET".equals(intent)) {
      Bundle bundle1 = workDatabase.getExtras();
      synchronized (this.c) {
        str2 = bundle1.getString("KEY_WORKSPEC_ID");
        h h = h.c();
        String str = d;
        h.a(str, String.format("Handing delay met for %s", new Object[] { str2 }), new Throwable[0]);
        if (!this.b.containsKey(str2)) {
          c c = new c(this.a, paramInt, str2, (d)iterator);
          this.b.put(str2, c);
          c.f();
        } else {
          h.c().a(str, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", new Object[] { str2 }), new Throwable[0]);
        } 
        return;
      } 
    } 
    if ("ACTION_STOP_WORK".equals(str2)) {
      str1 = workDatabase.getExtras().getString("KEY_WORKSPEC_ID");
      h.c().a(d, String.format("Handing stopWork work for %s", new Object[] { str1 }), new Throwable[0]);
      ((d)iterator).e.g(str1);
      context = this.a;
      k k = ((d)iterator).e;
      String str = t.a.a;
      i i1 = (i)k.c.k();
      g g = i1.a(str1);
      if (g != null) {
        t.a.a(g.b, context, str1);
        h.c().a(t.a.a, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[] { str1 }), new Throwable[0]);
        i1.c(str1);
      } 
      iterator.a(str1, false);
      return;
    } 
    if ("ACTION_EXECUTION_COMPLETED".equals(context)) {
      Bundle bundle1 = str1.getExtras();
      String str = bundle1.getString("KEY_WORKSPEC_ID");
      boolean bool = bundle1.getBoolean("KEY_NEEDS_RESCHEDULE");
      h.c().a(d, String.format("Handling onExecutionCompleted %s, %s", new Object[] { str1, Integer.valueOf(paramInt) }), new Throwable[0]);
      a(str, bool);
      return;
    } 
    h.c().f(d, String.format("Ignoring intent %s", new Object[] { str1 }), new Throwable[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemalarm\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */