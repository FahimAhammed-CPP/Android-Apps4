package androidx.work.impl.background.systemalarm;

import a0.n;
import a0.t;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import q.h;
import r.b;
import v.c;
import v.d;
import z.p;
import z.q;
import z.r;

public final class c implements c, b, t.b {
  public static final String j = h.e("DelayMetCommandHandler");
  
  public final Context a;
  
  public final int b;
  
  public final String c;
  
  public final d d;
  
  public final d e;
  
  public final Object f;
  
  public int g;
  
  public PowerManager.WakeLock h;
  
  public boolean i;
  
  public c(Context paramContext, int paramInt, String paramString, d paramd) {
    this.a = paramContext;
    this.b = paramInt;
    this.d = paramd;
    this.c = paramString;
    this.e = new d(paramContext, paramd.b, this);
    this.i = false;
    this.g = 0;
    this.f = new Object();
  }
  
  public final void a(String paramString, boolean paramBoolean) {
    h.c().a(j, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    c();
    if (paramBoolean) {
      Intent intent = a.c(this.a, this.c);
      d d1 = this.d;
      d1.e(new d.b(this.b, intent, d1));
    } 
    if (this.i) {
      Intent intent = new Intent(this.a, SystemAlarmService.class);
      intent.setAction("ACTION_CONSTRAINTS_CHANGED");
      d d1 = this.d;
      d1.e(new d.b(this.b, intent, d1));
    } 
  }
  
  public final void b(String paramString) {
    h.c().a(j, String.format("Exceeded time limits on execution for %s", new Object[] { paramString }), new Throwable[0]);
    g();
  }
  
  public final void c() {
    synchronized (this.f) {
      this.e.c();
      this.d.c.b(this.c);
      PowerManager.WakeLock wakeLock = this.h;
      if (wakeLock != null && wakeLock.isHeld()) {
        h.c().a(j, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.h, this.c }), new Throwable[0]);
        this.h.release();
      } 
      return;
    } 
  }
  
  public final void d(ArrayList paramArrayList) {
    g();
  }
  
  public final void e(List<String> paramList) {
    if (!paramList.contains(this.c))
      return; 
    synchronized (this.f) {
      if (this.g == 0) {
        this.g = 1;
        h.c().a(j, String.format("onAllConstraintsMet for %s", new Object[] { this.c }), new Throwable[0]);
        if (this.d.d.f(this.c, null)) {
          this.d.c.a(this.c, this);
        } else {
          c();
        } 
      } else {
        h.c().a(j, String.format("Already started work for %s", new Object[] { this.c }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public final void f() {
    this.h = n.a(this.a, String.format("%s (%s)", new Object[] { this.c, Integer.valueOf(this.b) }));
    h h = h.c();
    String str1 = j;
    h.a(str1, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.h, this.c }), new Throwable[0]);
    this.h.acquire();
    q q = this.d.e.c.n();
    String str2 = this.c;
    p p = ((r)q).i(str2);
    if (p == null) {
      g();
      return;
    } 
    boolean bool = p.b();
    this.i = bool;
    if (!bool) {
      h.c().a(str1, String.format("No constraints for %s", new Object[] { this.c }), new Throwable[0]);
      e(Collections.singletonList(this.c));
      return;
    } 
    this.e.b(Collections.singletonList(p));
  }
  
  public final void g() {
    synchronized (this.f) {
      if (this.g < 2) {
        Intent intent1;
        this.g = 2;
        h h = h.c();
        String str1 = j;
        h.a(str1, String.format("Stopping work for WorkSpec %s", new Object[] { this.c }), new Throwable[0]);
        Context context = this.a;
        String str2 = this.c;
        Intent intent2 = new Intent(context, SystemAlarmService.class);
        intent2.setAction("ACTION_STOP_WORK");
        intent2.putExtra("KEY_WORKSPEC_ID", str2);
        d d1 = this.d;
        d1.e(new d.b(this.b, intent2, d1));
        if (this.d.d.d(this.c)) {
          h.c().a(str1, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.c }), new Throwable[0]);
          intent1 = a.c(this.a, this.c);
          d1 = this.d;
          d1.e(new d.b(this.b, intent1, d1));
        } else {
          h.c().a((String)intent1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.c }), new Throwable[0]);
        } 
      } else {
        h.c().a(j, String.format("Already stopped work for %s", new Object[] { this.c }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemalarm\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */