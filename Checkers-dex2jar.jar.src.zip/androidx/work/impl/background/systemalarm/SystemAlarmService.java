package androidx.work.impl.background.systemalarm;

import a0.n;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.lifecycle.f;
import java.util.HashMap;
import java.util.WeakHashMap;
import q.h;

public class SystemAlarmService extends f implements d.c {
  public static final String d = h.e("SystemAlarmService");
  
  public d b;
  
  public boolean c;
  
  public final void a() {
    d d1 = new d((Context)this);
    this.b = d1;
    if (d1.j != null) {
      h.c().b(d.k, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    d1.j = this;
  }
  
  public final void b() {
    this.c = true;
    h.c().a(d, "All commands completed in dispatcher", new Throwable[0]);
    String str = n.a;
    null = new HashMap<Object, Object>();
    synchronized (n.b) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String str1 = String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          h.c().f(n.a, str1, new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
  
  public final void onCreate() {
    super.onCreate();
    a();
    this.c = false;
  }
  
  public final void onDestroy() {
    super.onDestroy();
    this.c = true;
    this.b.d();
  }
  
  public final int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.c) {
      h.c().d(d, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.b.d();
      a();
      this.c = false;
    } 
    if (paramIntent != null)
      this.b.b(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */