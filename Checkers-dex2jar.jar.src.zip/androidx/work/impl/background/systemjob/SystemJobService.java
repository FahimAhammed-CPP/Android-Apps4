package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.HashMap;
import q.h;
import r.b;
import r.d;
import r.k;

public class SystemJobService extends JobService implements b {
  public static final String c = h.e("SystemJobService");
  
  public k a;
  
  public final HashMap b = new HashMap<Object, Object>();
  
  public final void a(String paramString, boolean paramBoolean) {
    h.c().a(c, String.format("%s executed on JobScheduler", new Object[] { paramString }), new Throwable[0]);
    synchronized (this.b) {
      JobParameters jobParameters = (JobParameters)this.b.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
  
  public final void onCreate() {
    super.onCreate();
    try {
      k k1 = k.b(getApplicationContext());
      this.a = k1;
      k1.f.b(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        h.c().f(c, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public final void onDestroy() {
    super.onDestroy();
    k k1 = this.a;
    if (k1 != null) {
      null = k1.f;
      synchronized (null.k) {
        null.j.remove(this);
        return;
      } 
    } 
  }
  
  public final boolean onStartJob(JobParameters paramJobParameters) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lr/k;
    //   4: ifnonnull -> 30
    //   7: invokestatic c : ()Lq/h;
    //   10: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   13: ldc 'WorkManager is not initialized; requesting retry.'
    //   15: iconst_0
    //   16: anewarray java/lang/Throwable
    //   19: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   22: aload_0
    //   23: aload_1
    //   24: iconst_1
    //   25: invokevirtual jobFinished : (Landroid/app/job/JobParameters;Z)V
    //   28: iconst_0
    //   29: ireturn
    //   30: aconst_null
    //   31: astore #4
    //   33: aload_1
    //   34: invokevirtual getExtras : ()Landroid/os/PersistableBundle;
    //   37: astore_3
    //   38: aload_3
    //   39: ifnull -> 61
    //   42: aload_3
    //   43: ldc 'EXTRA_WORK_SPEC_ID'
    //   45: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   48: ifeq -> 61
    //   51: aload_3
    //   52: ldc 'EXTRA_WORK_SPEC_ID'
    //   54: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   57: astore_3
    //   58: goto -> 63
    //   61: aconst_null
    //   62: astore_3
    //   63: aload_3
    //   64: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   67: ifeq -> 87
    //   70: invokestatic c : ()Lq/h;
    //   73: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   76: ldc 'WorkSpec id not found!'
    //   78: iconst_0
    //   79: anewarray java/lang/Throwable
    //   82: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   85: iconst_0
    //   86: ireturn
    //   87: aload_0
    //   88: getfield b : Ljava/util/HashMap;
    //   91: astore #5
    //   93: aload #5
    //   95: monitorenter
    //   96: aload_0
    //   97: getfield b : Ljava/util/HashMap;
    //   100: aload_3
    //   101: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   104: ifeq -> 138
    //   107: invokestatic c : ()Lq/h;
    //   110: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   113: ldc 'Job is already being executed by SystemJobService: %s'
    //   115: iconst_1
    //   116: anewarray java/lang/Object
    //   119: dup
    //   120: iconst_0
    //   121: aload_3
    //   122: aastore
    //   123: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   126: iconst_0
    //   127: anewarray java/lang/Throwable
    //   130: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   133: aload #5
    //   135: monitorexit
    //   136: iconst_0
    //   137: ireturn
    //   138: invokestatic c : ()Lq/h;
    //   141: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   144: ldc 'onStartJob for %s'
    //   146: iconst_1
    //   147: anewarray java/lang/Object
    //   150: dup
    //   151: iconst_0
    //   152: aload_3
    //   153: aastore
    //   154: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   157: iconst_0
    //   158: anewarray java/lang/Throwable
    //   161: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   164: aload_0
    //   165: getfield b : Ljava/util/HashMap;
    //   168: aload_3
    //   169: aload_1
    //   170: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   173: pop
    //   174: aload #5
    //   176: monitorexit
    //   177: getstatic android/os/Build$VERSION.SDK_INT : I
    //   180: istore_2
    //   181: iload_2
    //   182: bipush #24
    //   184: if_icmplt -> 257
    //   187: new androidx/work/WorkerParameters$a
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: astore #5
    //   196: aload_1
    //   197: invokestatic d : (Landroid/app/job/JobParameters;)[Landroid/net/Uri;
    //   200: ifnull -> 215
    //   203: aload #5
    //   205: aload_1
    //   206: invokestatic d : (Landroid/app/job/JobParameters;)[Landroid/net/Uri;
    //   209: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   212: putfield b : Ljava/util/List;
    //   215: aload_1
    //   216: invokestatic c : (Landroid/app/job/JobParameters;)[Ljava/lang/String;
    //   219: ifnull -> 234
    //   222: aload #5
    //   224: aload_1
    //   225: invokestatic c : (Landroid/app/job/JobParameters;)[Ljava/lang/String;
    //   228: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   231: putfield a : Ljava/util/List;
    //   234: aload #5
    //   236: astore #4
    //   238: iload_2
    //   239: bipush #28
    //   241: if_icmplt -> 257
    //   244: aload #5
    //   246: aload_1
    //   247: invokestatic a : (Landroid/app/job/JobParameters;)Landroid/net/Network;
    //   250: putfield c : Landroid/net/Network;
    //   253: aload #5
    //   255: astore #4
    //   257: aload_0
    //   258: getfield a : Lr/k;
    //   261: aload_3
    //   262: aload #4
    //   264: invokevirtual f : (Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V
    //   267: iconst_1
    //   268: ireturn
    //   269: astore_1
    //   270: aload #5
    //   272: monitorexit
    //   273: aload_1
    //   274: athrow
    //   275: astore_3
    //   276: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   33	38	275	java/lang/NullPointerException
    //   42	58	275	java/lang/NullPointerException
    //   96	136	269	finally
    //   138	177	269	finally
    //   270	273	269	finally
  }
  
  public final boolean onStopJob(JobParameters paramJobParameters) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lr/k;
    //   4: ifnonnull -> 24
    //   7: invokestatic c : ()Lq/h;
    //   10: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   13: ldc 'WorkManager is not initialized; requesting retry.'
    //   15: iconst_0
    //   16: anewarray java/lang/Throwable
    //   19: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   22: iconst_1
    //   23: ireturn
    //   24: aload_1
    //   25: invokevirtual getExtras : ()Landroid/os/PersistableBundle;
    //   28: astore_1
    //   29: aload_1
    //   30: ifnull -> 52
    //   33: aload_1
    //   34: ldc 'EXTRA_WORK_SPEC_ID'
    //   36: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   39: ifeq -> 52
    //   42: aload_1
    //   43: ldc 'EXTRA_WORK_SPEC_ID'
    //   45: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   48: astore_1
    //   49: goto -> 54
    //   52: aconst_null
    //   53: astore_1
    //   54: aload_1
    //   55: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   58: ifeq -> 78
    //   61: invokestatic c : ()Lq/h;
    //   64: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   67: ldc 'WorkSpec id not found!'
    //   69: iconst_0
    //   70: anewarray java/lang/Throwable
    //   73: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   76: iconst_0
    //   77: ireturn
    //   78: invokestatic c : ()Lq/h;
    //   81: getstatic androidx/work/impl/background/systemjob/SystemJobService.c : Ljava/lang/String;
    //   84: ldc 'onStopJob for %s'
    //   86: iconst_1
    //   87: anewarray java/lang/Object
    //   90: dup
    //   91: iconst_0
    //   92: aload_1
    //   93: aastore
    //   94: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   97: iconst_0
    //   98: anewarray java/lang/Throwable
    //   101: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   104: aload_0
    //   105: getfield b : Ljava/util/HashMap;
    //   108: astore_3
    //   109: aload_3
    //   110: monitorenter
    //   111: aload_0
    //   112: getfield b : Ljava/util/HashMap;
    //   115: aload_1
    //   116: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   119: pop
    //   120: aload_3
    //   121: monitorexit
    //   122: aload_0
    //   123: getfield a : Lr/k;
    //   126: aload_1
    //   127: invokevirtual g : (Ljava/lang/String;)V
    //   130: aload_0
    //   131: getfield a : Lr/k;
    //   134: getfield f : Lr/d;
    //   137: astore #4
    //   139: aload #4
    //   141: getfield k : Ljava/lang/Object;
    //   144: astore_3
    //   145: aload_3
    //   146: monitorenter
    //   147: aload #4
    //   149: getfield i : Ljava/util/HashSet;
    //   152: aload_1
    //   153: invokevirtual contains : (Ljava/lang/Object;)Z
    //   156: istore_2
    //   157: aload_3
    //   158: monitorexit
    //   159: iload_2
    //   160: iconst_1
    //   161: ixor
    //   162: ireturn
    //   163: astore_1
    //   164: aload_3
    //   165: monitorexit
    //   166: aload_1
    //   167: athrow
    //   168: astore_1
    //   169: aload_3
    //   170: monitorexit
    //   171: aload_1
    //   172: athrow
    //   173: astore_1
    //   174: goto -> 52
    // Exception table:
    //   from	to	target	type
    //   24	29	173	java/lang/NullPointerException
    //   33	49	173	java/lang/NullPointerException
    //   111	122	168	finally
    //   147	159	163	finally
    //   164	166	163	finally
    //   169	171	168	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */