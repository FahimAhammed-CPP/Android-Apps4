package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import b0.c;

public abstract class Worker extends ListenableWorker {
  public c<ListenableWorker.a> f;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final f1.a<ListenableWorker.a> startWork() {
    this.f = new c();
    getBackgroundExecutor().execute(new a(this));
    return (f1.a<ListenableWorker.a>)this.f;
  }
  
  public final class a implements Runnable {
    public a(Worker this$0) {}
    
    public final void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.i.f.j(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */