package androidx.work;

import a0.q;
import a0.s;
import android.net.Network;
import android.net.Uri;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import q.e;
import q.l;
import q.p;
import q.q;

public final class WorkerParameters {
  public UUID a;
  
  public b b;
  
  public HashSet c;
  
  public a d;
  
  public int e;
  
  public Executor f;
  
  public c0.a g;
  
  public q h;
  
  public l i;
  
  public e j;
  
  public WorkerParameters(UUID paramUUID, b paramb, List<?> paramList, a parama, int paramInt, ExecutorService paramExecutorService, c0.a parama1, p paramp, s params, q paramq) {
    this.a = paramUUID;
    this.b = paramb;
    this.c = new HashSet(paramList);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutorService;
    this.g = parama1;
    this.h = (q)paramp;
    this.i = (l)params;
    this.j = (e)paramq;
  }
  
  public static final class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */