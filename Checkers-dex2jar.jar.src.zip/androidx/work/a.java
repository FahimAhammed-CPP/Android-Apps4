package androidx.work;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import q.g;
import q.p;
import q.q;

public final class a {
  public final ExecutorService a = a(false);
  
  public final ExecutorService b = a(true);
  
  public final p c;
  
  public final g d;
  
  public final r.a e;
  
  public final int f;
  
  public final int g;
  
  public final int h;
  
  public a(a parama) {
    String str = q.a;
    this.c = new p();
    this.d = new g();
    this.e = new r.a();
    this.f = 4;
    this.g = Integer.MAX_VALUE;
    this.h = 20;
  }
  
  public static ExecutorService a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), (ThreadFactory)new q.a(paramBoolean));
  }
  
  public static final class a {}
  
  public static interface b {
    a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */