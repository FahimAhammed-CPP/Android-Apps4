package androidx.work;

import android.content.Context;
import java.util.Collections;
import java.util.List;
import n.b;
import q.h;
import q.n;
import r.k;

public final class WorkManagerInitializer implements b<n> {
  public static final String a = h.e("WrkMgrInitializer");
  
  public final List<Class<? extends b<?>>> a() {
    return Collections.emptyList();
  }
  
  public final k b(Context paramContext) {
    h.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    k.c(paramContext, new a(new a.a()));
    return k.b(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */