package androidx.work;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import q.f;

public final class OverwritingInputMerger extends f {
  public final b a(ArrayList paramArrayList) {
    b.a a = new b.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator iterator = paramArrayList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(Collections.unmodifiableMap(((b)iterator.next()).a)); 
    a.a(hashMap);
    b b = new b(a.a);
    b.b(b);
    return b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */