package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class f extends Service implements d {
  public final i a = new i(this);
  
  public final IBinder onBind(Intent paramIntent) {
    this.a.a(2);
    return null;
  }
  
  public void onCreate() {
    this.a.a(1);
    super.onCreate();
  }
  
  public void onDestroy() {
    i i1 = this.a;
    i1.a(5);
    i1.a(6);
    super.onDestroy();
  }
  
  public final void onStart(Intent paramIntent, int paramInt) {
    this.a.a(2);
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */