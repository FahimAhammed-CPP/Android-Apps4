package androidx.lifecycle;

import android.os.Handler;
import b.c;

public final class i {
  public final e a;
  
  public final Handler b;
  
  public a c;
  
  public i(d paramd) {
    this.a = new e(paramd);
    this.b = new Handler();
  }
  
  public final void a(int paramInt) {
    a a1 = this.c;
    if (a1 != null)
      a1.run(); 
    a1 = new a(this.a, paramInt);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public static final class a implements Runnable {
    public final e i;
    
    public final int j;
    
    public boolean k = false;
    
    public a(e param1e, int param1Int) {
      this.i = param1e;
      this.j = param1Int;
    }
    
    public final void run() {
      if (!this.k) {
        e e1 = this.i;
        int i = this.j;
        e1.getClass();
        c.a a1 = e.a(i);
        if (e1.b != a1) {
          e1.b = a1;
          if (!e1.d) {
            e1.d = true;
            if ((d)e1.c.get() != null) {
              b.a<Object, e.b> a2 = e1.a;
              if (((c)a2).j == 0) {
                e1.e = false;
                e1.d = false;
              } else {
                a2.getClass();
                throw null;
              } 
            } else {
              throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
            } 
          } else {
            e1.e = true;
          } 
        } 
        this.k = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */