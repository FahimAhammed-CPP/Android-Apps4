package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

public abstract class c {
  public c() {
    new AtomicReference();
  }
  
  public enum a {
    i, j, k, l, m;
    
    static {
      a a1 = new a(0, "DESTROYED");
      i = a1;
      a a2 = new a(1, "INITIALIZED");
      j = a2;
      a a3 = new a(2, "CREATED");
      k = a3;
      a a4 = new a(3, "STARTED");
      l = a4;
      a a5 = new a(4, "RESUMED");
      m = a5;
      n = new a[] { a1, a2, a3, a4, a5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */