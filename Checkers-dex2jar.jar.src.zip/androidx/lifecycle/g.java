package androidx.lifecycle;

import com.google.android.gms.ads.initialization.InitializationStatus;
import java.util.HashMap;
import java.util.Map;

public final class g implements InitializationStatus {
  public Map a;
  
  public final Map getAdapterStatusMap() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */