package androidx.lifecycle;

import android.os.Looper;
import b.c;
import java.util.Map;

public abstract class LiveData<T> {
  public static final Object i = new Object();
  
  public final Object a = new Object();
  
  public c<Object, b> b = new c();
  
  public volatile Object c;
  
  public volatile Object d;
  
  public int e;
  
  public boolean f;
  
  public boolean g;
  
  public final a h;
  
  public LiveData() {
    Object object = i;
    this.d = object;
    this.h = new a(this);
    this.c = object;
    this.e = -1;
  }
  
  public static void a(String paramString) {
    boolean bool;
    (a.a.e()).a.getClass();
    if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public class LifecycleBoundObserver extends b {
    public final boolean b() {
      throw null;
    }
  }
  
  public final class a implements Runnable {
    public a(LiveData this$0) {}
    
    public final void run() {
      synchronized (this.i.a) {
        Object object = this.i.d;
        this.i.d = LiveData.i;
        null = this.i;
        null.getClass();
        LiveData.a("setValue");
        ((LiveData)null).e++;
        ((LiveData)null).c = object;
        if (((LiveData)null).f) {
          ((LiveData)null).g = true;
          return;
        } 
        ((LiveData)null).f = true;
        while (true) {
          ((LiveData)null).g = false;
          c<Object, LiveData<T>.b> c = ((LiveData)null).b;
          c.getClass();
          object = new c.d(c);
          c.i.put(object, Boolean.FALSE);
          while (object.hasNext()) {
            LiveData.b b = (LiveData.b)((Map.Entry)object.next()).getValue();
            if (b.a)
              if (!b.b()) {
                b.a();
              } else {
                int i = b.b;
                int j = ((LiveData)null).e;
                if (i < j) {
                  b.b = j;
                  throw null;
                } 
              }  
            if (((LiveData)null).g)
              break; 
          } 
          if (!((LiveData)null).g) {
            ((LiveData)null).f = false;
            return;
          } 
        } 
      } 
    }
  }
  
  public abstract class b {
    public boolean a;
    
    public int b;
    
    public final void a() {
      if (!this.a)
        return; 
      this.a = false;
      throw null;
    }
    
    public abstract boolean b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */