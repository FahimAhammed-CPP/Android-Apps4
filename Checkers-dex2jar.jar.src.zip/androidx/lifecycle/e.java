package androidx.lifecycle;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public final class e extends c {
  public b.a<Object, b> a = new b.a();
  
  public c.a b;
  
  public final WeakReference<d> c;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public ArrayList<c.a> f = new ArrayList<c.a>();
  
  public e(d paramd) {
    this.c = new WeakReference<d>(paramd);
    this.b = c.a.j;
  }
  
  public static c.a a(int paramInt) {
    int[] arrayOfInt = a.a;
    if (paramInt != 0) {
      StringBuilder stringBuilder;
      switch (arrayOfInt[paramInt - 1]) {
        default:
          stringBuilder = b.b.c("Unexpected event value ");
          stringBuilder.append(a.d(paramInt));
          throw new IllegalArgumentException(stringBuilder.toString());
        case 6:
          return c.a.i;
        case 5:
          return c.a.m;
        case 3:
        case 4:
          return c.a.l;
        case 1:
        case 2:
          break;
      } 
      return c.a.k;
    } 
    throw null;
  }
  
  public static final class b {
    public c.a a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\lifecycle\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */