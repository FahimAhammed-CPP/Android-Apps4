package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p.c;

public final class RemoteActionCompat implements c {
  public IconCompat a;
  
  public CharSequence b;
  
  public CharSequence c;
  
  public PendingIntent d;
  
  public boolean e;
  
  public boolean f;
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */