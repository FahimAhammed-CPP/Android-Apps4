package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import p.a;
import p.c;

public class RemoteActionCompatParcelizer {
  public static RemoteActionCompat read(a parama) {
    c c;
    Parcelable parcelable;
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
    IconCompat iconCompat = remoteActionCompat.a;
    if (parama.i(1))
      c = parama.m(); 
    remoteActionCompat.a = (IconCompat)c;
    CharSequence charSequence = remoteActionCompat.b;
    if (parama.i(2))
      charSequence = parama.h(); 
    remoteActionCompat.b = charSequence;
    charSequence = remoteActionCompat.c;
    if (parama.i(3))
      charSequence = parama.h(); 
    remoteActionCompat.c = charSequence;
    PendingIntent pendingIntent = remoteActionCompat.d;
    if (parama.i(4))
      parcelable = parama.k(); 
    remoteActionCompat.d = (PendingIntent)parcelable;
    remoteActionCompat.e = parama.f(5, remoteActionCompat.e);
    remoteActionCompat.f = parama.f(6, remoteActionCompat.f);
    return remoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, a parama) {
    parama.getClass();
    IconCompat iconCompat = paramRemoteActionCompat.a;
    parama.n(1);
    parama.u((c)iconCompat);
    CharSequence charSequence = paramRemoteActionCompat.b;
    parama.n(2);
    parama.q(charSequence);
    charSequence = paramRemoteActionCompat.c;
    parama.n(3);
    parama.q(charSequence);
    PendingIntent pendingIntent = paramRemoteActionCompat.d;
    parama.n(4);
    parama.s((Parcelable)pendingIntent);
    boolean bool = paramRemoteActionCompat.e;
    parama.n(5);
    parama.o(bool);
    bool = paramRemoteActionCompat.f;
    parama.n(6);
    parama.o(bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\core\app\RemoteActionCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */