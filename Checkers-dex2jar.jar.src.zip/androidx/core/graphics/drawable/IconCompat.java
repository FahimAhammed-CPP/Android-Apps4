package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.versionedparcelable.CustomVersionedParcelable;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a = -1;
  
  public Object b;
  
  public byte[] c = null;
  
  public Parcelable d = null;
  
  public int e = 0;
  
  public int f = 0;
  
  public ColorStateList g = null;
  
  public PorterDuff.Mode h = k;
  
  public String i = null;
  
  public String j;
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : I
    //   4: iconst_m1
    //   5: if_icmpne -> 16
    //   8: aload_0
    //   9: getfield b : Ljava/lang/Object;
    //   12: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   15: areturn
    //   16: new java/lang/StringBuilder
    //   19: dup
    //   20: ldc 'Icon(typ='
    //   22: invokespecial <init> : (Ljava/lang/String;)V
    //   25: astore #4
    //   27: aload_0
    //   28: getfield a : I
    //   31: tableswitch default -> 68, 1 -> 104, 2 -> 98, 3 -> 92, 4 -> 86, 5 -> 80, 6 -> 74
    //   68: ldc 'UNKNOWN'
    //   70: astore_3
    //   71: goto -> 107
    //   74: ldc 'URI_MASKABLE'
    //   76: astore_3
    //   77: goto -> 107
    //   80: ldc 'BITMAP_MASKABLE'
    //   82: astore_3
    //   83: goto -> 107
    //   86: ldc 'URI'
    //   88: astore_3
    //   89: goto -> 107
    //   92: ldc 'DATA'
    //   94: astore_3
    //   95: goto -> 107
    //   98: ldc 'RESOURCE'
    //   100: astore_3
    //   101: goto -> 107
    //   104: ldc 'BITMAP'
    //   106: astore_3
    //   107: aload #4
    //   109: aload_3
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: aload_0
    //   115: getfield a : I
    //   118: tableswitch default -> 156, 1 -> 411, 2 -> 221, 3 -> 180, 4 -> 159, 5 -> 411, 6 -> 159
    //   156: goto -> 461
    //   159: aload #4
    //   161: ldc ' uri='
    //   163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: aload #4
    //   169: aload_0
    //   170: getfield b : Ljava/lang/Object;
    //   173: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   176: pop
    //   177: goto -> 461
    //   180: aload #4
    //   182: ldc ' len='
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload #4
    //   190: aload_0
    //   191: getfield e : I
    //   194: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload_0
    //   199: getfield f : I
    //   202: ifeq -> 461
    //   205: aload #4
    //   207: ldc ' off='
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_0
    //   214: getfield f : I
    //   217: istore_1
    //   218: goto -> 454
    //   221: aload #4
    //   223: ldc ' pkg='
    //   225: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload #4
    //   231: aload_0
    //   232: getfield j : Ljava/lang/String;
    //   235: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: pop
    //   239: aload #4
    //   241: ldc ' id='
    //   243: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   246: pop
    //   247: aload_0
    //   248: getfield a : I
    //   251: istore_1
    //   252: iload_1
    //   253: iconst_m1
    //   254: if_icmpne -> 343
    //   257: getstatic android/os/Build$VERSION.SDK_INT : I
    //   260: istore_2
    //   261: iload_2
    //   262: bipush #23
    //   264: if_icmplt -> 343
    //   267: aload_0
    //   268: getfield b : Ljava/lang/Object;
    //   271: checkcast android/graphics/drawable/Icon
    //   274: astore_3
    //   275: iload_2
    //   276: bipush #28
    //   278: if_icmplt -> 289
    //   281: aload_3
    //   282: invokestatic a : (Landroid/graphics/drawable/Icon;)I
    //   285: istore_1
    //   286: goto -> 353
    //   289: aload_3
    //   290: invokevirtual getClass : ()Ljava/lang/Class;
    //   293: ldc 'getResId'
    //   295: iconst_0
    //   296: anewarray java/lang/Class
    //   299: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   302: aload_3
    //   303: iconst_0
    //   304: anewarray java/lang/Object
    //   307: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   310: checkcast java/lang/Integer
    //   313: invokevirtual intValue : ()I
    //   316: istore_1
    //   317: goto -> 353
    //   320: astore_3
    //   321: goto -> 329
    //   324: astore_3
    //   325: goto -> 329
    //   328: astore_3
    //   329: ldc 'IconCompat'
    //   331: ldc 'Unable to get icon resource'
    //   333: aload_3
    //   334: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   337: pop
    //   338: iconst_0
    //   339: istore_1
    //   340: goto -> 353
    //   343: iload_1
    //   344: iconst_2
    //   345: if_icmpne -> 378
    //   348: aload_0
    //   349: getfield e : I
    //   352: istore_1
    //   353: aload #4
    //   355: ldc '0x%08x'
    //   357: iconst_1
    //   358: anewarray java/lang/Object
    //   361: dup
    //   362: iconst_0
    //   363: iload_1
    //   364: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   367: aastore
    //   368: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   371: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: pop
    //   375: goto -> 461
    //   378: new java/lang/StringBuilder
    //   381: dup
    //   382: invokespecial <init> : ()V
    //   385: astore_3
    //   386: aload_3
    //   387: ldc 'called getResId() on '
    //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   392: pop
    //   393: aload_3
    //   394: aload_0
    //   395: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   398: pop
    //   399: new java/lang/IllegalStateException
    //   402: dup
    //   403: aload_3
    //   404: invokevirtual toString : ()Ljava/lang/String;
    //   407: invokespecial <init> : (Ljava/lang/String;)V
    //   410: athrow
    //   411: aload #4
    //   413: ldc ' size='
    //   415: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   418: pop
    //   419: aload #4
    //   421: aload_0
    //   422: getfield b : Ljava/lang/Object;
    //   425: checkcast android/graphics/Bitmap
    //   428: invokevirtual getWidth : ()I
    //   431: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   434: pop
    //   435: aload #4
    //   437: ldc 'x'
    //   439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   442: pop
    //   443: aload_0
    //   444: getfield b : Ljava/lang/Object;
    //   447: checkcast android/graphics/Bitmap
    //   450: invokevirtual getHeight : ()I
    //   453: istore_1
    //   454: aload #4
    //   456: iload_1
    //   457: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   460: pop
    //   461: aload_0
    //   462: getfield g : Landroid/content/res/ColorStateList;
    //   465: ifnull -> 486
    //   468: aload #4
    //   470: ldc ' tint='
    //   472: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   475: pop
    //   476: aload #4
    //   478: aload_0
    //   479: getfield g : Landroid/content/res/ColorStateList;
    //   482: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   485: pop
    //   486: aload_0
    //   487: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   490: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
    //   493: if_acmpeq -> 514
    //   496: aload #4
    //   498: ldc ' mode='
    //   500: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   503: pop
    //   504: aload #4
    //   506: aload_0
    //   507: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   510: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: aload #4
    //   516: ldc ')'
    //   518: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   521: pop
    //   522: aload #4
    //   524: invokevirtual toString : ()Ljava/lang/String;
    //   527: areturn
    // Exception table:
    //   from	to	target	type
    //   289	317	328	java/lang/IllegalAccessException
    //   289	317	324	java/lang/reflect/InvocationTargetException
    //   289	317	320	java/lang/NoSuchMethodException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */