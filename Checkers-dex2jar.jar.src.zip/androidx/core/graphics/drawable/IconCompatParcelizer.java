package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import java.nio.charset.Charset;
import p.a;

public class IconCompatParcelizer {
  public static IconCompat read(a parama) {
    String str1;
    Parcelable parcelable2;
    byte[] arrayOfByte1;
    Parcelable parcelable3;
    IconCompat iconCompat = new IconCompat();
    int i = iconCompat.a;
    if (parama.i(1))
      i = parama.j(); 
    iconCompat.a = i;
    byte[] arrayOfByte2 = iconCompat.c;
    if (parama.i(2))
      arrayOfByte2 = parama.g(); 
    iconCompat.c = arrayOfByte2;
    Parcelable parcelable4 = iconCompat.d;
    if (parama.i(3))
      parcelable4 = parama.k(); 
    iconCompat.d = parcelable4;
    i = iconCompat.e;
    if (parama.i(4))
      i = parama.j(); 
    iconCompat.e = i;
    i = iconCompat.f;
    if (parama.i(5))
      i = parama.j(); 
    iconCompat.f = i;
    ColorStateList colorStateList = iconCompat.g;
    if (parama.i(6))
      parcelable3 = parama.k(); 
    iconCompat.g = (ColorStateList)parcelable3;
    String str2 = iconCompat.i;
    if (parama.i(7))
      str2 = parama.l(); 
    iconCompat.i = str2;
    str2 = iconCompat.j;
    if (!parama.i(8)) {
      str1 = str2;
    } else {
      str1 = str1.l();
    } 
    iconCompat.j = str1;
    iconCompat.h = PorterDuff.Mode.valueOf(iconCompat.i);
    switch (iconCompat.a) {
      default:
        return iconCompat;
      case 3:
        iconCompat.b = iconCompat.c;
        return iconCompat;
      case 2:
      case 4:
      case 6:
        str1 = new String(iconCompat.c, Charset.forName("UTF-16"));
        iconCompat.b = str1;
        if (iconCompat.a == 2 && iconCompat.j == null) {
          iconCompat.j = str1.split(":", -1)[0];
          return iconCompat;
        } 
        return iconCompat;
      case 1:
      case 5:
        parcelable2 = iconCompat.d;
        if (parcelable2 == null) {
          arrayOfByte1 = iconCompat.c;
          iconCompat.b = arrayOfByte1;
          iconCompat.a = 3;
          iconCompat.e = 0;
          iconCompat.f = arrayOfByte1.length;
          return iconCompat;
        } 
        iconCompat.b = arrayOfByte1;
        return iconCompat;
      case -1:
        break;
    } 
    Parcelable parcelable1 = iconCompat.d;
    if (parcelable1 == null)
      throw new IllegalArgumentException("Invalid icon"); 
    iconCompat.b = parcelable1;
    return iconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, a parama) {
    parama.getClass();
    paramIconCompat.i = paramIconCompat.h.name();
    switch (paramIconCompat.a) {
      case 4:
      case 6:
        paramIconCompat.c = paramIconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
        break;
      case 3:
        paramIconCompat.c = (byte[])paramIconCompat.b;
        break;
      case 2:
        paramIconCompat.c = ((String)paramIconCompat.b).getBytes(Charset.forName("UTF-16"));
        break;
      case -1:
      case 1:
      case 5:
        paramIconCompat.d = (Parcelable)paramIconCompat.b;
        break;
    } 
    int i = paramIconCompat.a;
    if (-1 != i) {
      parama.n(1);
      parama.r(i);
    } 
    byte[] arrayOfByte = paramIconCompat.c;
    if (arrayOfByte != null) {
      parama.n(2);
      parama.p(arrayOfByte);
    } 
    Parcelable parcelable = paramIconCompat.d;
    if (parcelable != null) {
      parama.n(3);
      parama.s(parcelable);
    } 
    i = paramIconCompat.e;
    if (i != 0) {
      parama.n(4);
      parama.r(i);
    } 
    i = paramIconCompat.f;
    if (i != 0) {
      parama.n(5);
      parama.r(i);
    } 
    ColorStateList colorStateList = paramIconCompat.g;
    if (colorStateList != null) {
      parama.n(6);
      parama.s((Parcelable)colorStateList);
    } 
    String str2 = paramIconCompat.i;
    if (str2 != null) {
      parama.n(7);
      parama.t(str2);
    } 
    String str1 = paramIconCompat.j;
    if (str1 != null) {
      parama.n(8);
      parama.t(str1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */