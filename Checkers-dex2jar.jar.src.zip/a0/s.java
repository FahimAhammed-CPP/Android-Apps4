package a0;

import androidx.work.impl.WorkDatabase;
import c0.a;
import q.h;
import q.l;

public final class s implements l {
  public static final String c = h.e("WorkProgressUpdater");
  
  public final WorkDatabase a;
  
  public final a b;
  
  public s(WorkDatabase paramWorkDatabase, a parama) {
    this.a = paramWorkDatabase;
    this.b = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */