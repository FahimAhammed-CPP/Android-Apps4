package a0;

import androidx.work.WorkerParameters;
import r.k;

public final class l implements Runnable {
  public k i;
  
  public String j;
  
  public WorkerParameters.a k;
  
  public l(k paramk, String paramString, WorkerParameters.a parama) {
    this.i = paramk;
    this.j = paramString;
    this.k = parama;
  }
  
  public final void run() {
    this.i.f.f(this.j, this.k);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */