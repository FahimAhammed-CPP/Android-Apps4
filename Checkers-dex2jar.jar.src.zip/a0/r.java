package a0;

import androidx.work.b;
import b0.c;
import java.util.UUID;
import q.h;
import z.p;

public final class r implements Runnable {
  public r(s params, UUID paramUUID, b paramb, c paramc) {}
  
  public final void run() {
    String str1 = this.i.toString();
    h h = h.c();
    String str2 = s.c;
    h.a(str2, String.format("Updating progress for %s (%s)", new Object[] { this.i, this.j }), new Throwable[0]);
    this.l.a.c();
    try {
      p p = ((z.r)this.l.a.n()).i(str1);
    } finally {
      str1 = null;
    } 
    this.l.a.f();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */