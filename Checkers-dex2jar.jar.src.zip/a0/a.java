package a0;

import androidx.work.impl.WorkDatabase;
import java.util.UUID;
import r.k;

public final class a extends d {
  public a(k paramk, UUID paramUUID) {}
  
  public final void b() {
    k k1;
    WorkDatabase workDatabase = this.j.c;
    workDatabase.c();
    try {
      d.a(this.j, this.k.toString());
      workDatabase.h();
      workDatabase.f();
      k1 = this.j;
      return;
    } finally {
      k1.f();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */