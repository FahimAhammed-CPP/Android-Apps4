package a0;

import androidx.work.impl.WorkDatabase;
import r.k;
import z.q;
import z.r;

public final class b extends d {
  public b(k paramk) {}
  
  public final void b() {
    k k1;
    WorkDatabase workDatabase = this.j.c;
    workDatabase.c();
    try {
      q q = workDatabase.n();
      str = this.k;
      for (String str : ((r)q).h(str))
        d.a(this.j, str); 
      workDatabase.h();
      workDatabase.f();
      k1 = this.j;
      return;
    } finally {
      k1.f();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */