package a0;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.work.ListenableWorker;
import b0.c;
import java.util.UUID;
import java.util.concurrent.Executor;
import q.d;
import q.e;
import q.h;
import z.p;

public final class o implements Runnable {
  public static final String o = h.e("WorkForegroundRunnable");
  
  public final c<Void> i = new c();
  
  public final Context j;
  
  public final p k;
  
  public final ListenableWorker l;
  
  public final e m;
  
  public final c0.a n;
  
  @SuppressLint({"LambdaLast"})
  public o(Context paramContext, p paramp, ListenableWorker paramListenableWorker, e parame, c0.a parama) {
    this.j = paramContext;
    this.k = paramp;
    this.l = paramListenableWorker;
    this.m = parame;
    this.n = parama;
  }
  
  @SuppressLint({"UnsafeExperimentalUsageError"})
  public final void run() {
    if (!this.k.q || g.a.a()) {
      this.i.i(null);
      return;
    } 
    c c1 = new c();
    ((c0.b)this.n).c.execute(new a(this, c1));
    c1.b(new b(this, c1), (Executor)((c0.b)this.n).c);
  }
  
  public final class a implements Runnable {
    public a(o this$0, c param1c) {}
    
    public final void run() {
      this.i.k(this.j.l.getForegroundInfoAsync());
    }
  }
  
  public final class b implements Runnable {
    public b(o this$0, c param1c) {}
    
    public final void run() {
      try {
        d d = (d)this.i.get();
        if (d != null) {
          h.c().a(o.o, String.format("Updating notification for %s", new Object[] { this.j.k.c }), new Throwable[0]);
          this.j.l.setRunInForeground(true);
          o o1 = this.j;
          c<Void> c1 = o1.i;
          e e = o1.m;
          Context context = o1.j;
          UUID uUID = o1.l.getId();
          q q = (q)e;
          q.getClass();
          c c2 = new c();
          c0.a a = q.a;
          p p = new p(q, c2, uUID, d, context);
          return;
        } 
        throw new IllegalStateException(String.format("Worker was marked important (%s) but did not provide ForegroundInfo", new Object[] { this.j.k.c }));
      } finally {
        Exception exception = null;
        this.j.i.j(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */