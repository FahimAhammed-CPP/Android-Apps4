package a0;

import android.content.Context;
import b0.c;
import java.util.UUID;
import q.d;

public final class p implements Runnable {
  public p(q paramq, c paramc, UUID paramUUID, d paramd, Context paramContext) {}
  
  public final void run() {
    try {
      return;
    } finally {
      Exception exception = null;
      this.i.j(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */