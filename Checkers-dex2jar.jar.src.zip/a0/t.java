package a0;

import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import q.h;

public final class t {
  public static final String e = h.e("WorkTimer");
  
  public final ScheduledExecutorService a;
  
  public final HashMap b;
  
  public final HashMap c;
  
  public final Object d;
  
  public t() {
    a a = new a();
    this.b = new HashMap<Object, Object>();
    this.c = new HashMap<Object, Object>();
    this.d = new Object();
    this.a = Executors.newSingleThreadScheduledExecutor(a);
  }
  
  public final void a(String paramString, b paramb) {
    synchronized (this.d) {
      h.c().a(e, String.format("Starting timer for %s", new Object[] { paramString }), new Throwable[0]);
      b(paramString);
      c c = new c(this, paramString);
      this.b.put(paramString, c);
      this.c.put(paramString, paramb);
      this.a.schedule(c, 600000L, TimeUnit.MILLISECONDS);
      return;
    } 
  }
  
  public final void b(String paramString) {
    synchronized (this.d) {
      if ((c)this.b.remove(paramString) != null) {
        h.c().a(e, String.format("Stopping timer for %s", new Object[] { paramString }), new Throwable[0]);
        this.c.remove(paramString);
      } 
      return;
    } 
  }
  
  public final class a implements ThreadFactory {
    public int a = 0;
    
    public final Thread newThread(Runnable param1Runnable) {
      param1Runnable = Executors.defaultThreadFactory().newThread(param1Runnable);
      StringBuilder stringBuilder = b.b.c("WorkManager-WorkTimer-thread-");
      stringBuilder.append(this.a);
      param1Runnable.setName(stringBuilder.toString());
      this.a++;
      return (Thread)param1Runnable;
    }
  }
  
  public static interface b {
    void b(String param1String);
  }
  
  public static final class c implements Runnable {
    public final t i;
    
    public final String j;
    
    public c(t param1t, String param1String) {
      this.i = param1t;
      this.j = param1String;
    }
    
    public final void run() {
      synchronized (this.i.d) {
        if ((c)this.i.b.remove(this.j) != null) {
          t.b b = (t.b)this.i.c.remove(this.j);
          if (b != null)
            b.b(this.j); 
        } else {
          h.c().a("WrkTimerRunnable", String.format("Timer with %s is already marked as complete.", new Object[] { this.j }), new Throwable[0]);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */