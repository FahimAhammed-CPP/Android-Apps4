package a0;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public final class k implements Executor {
  public final ArrayDeque<a> i;
  
  public final Executor j;
  
  public final Object k;
  
  public volatile Runnable l;
  
  public k(ExecutorService paramExecutorService) {
    this.j = paramExecutorService;
    this.i = new ArrayDeque<a>();
    this.k = new Object();
  }
  
  public final void a() {
    synchronized (this.k) {
      Runnable runnable = this.i.poll();
      this.l = runnable;
      if (runnable != null)
        this.j.execute(this.l); 
      return;
    } 
  }
  
  public final void execute(Runnable paramRunnable) {
    synchronized (this.k) {
      this.i.add(new a(this, paramRunnable));
      if (this.l == null)
        a(); 
      return;
    } 
  }
  
  public static final class a implements Runnable {
    public final k i;
    
    public final Runnable j;
    
    public a(k param1k, Runnable param1Runnable) {
      this.i = param1k;
      this.j = param1Runnable;
    }
    
    public final void run() {
      try {
        this.j.run();
        return;
      } finally {
        this.i.a();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */