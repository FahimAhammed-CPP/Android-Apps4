package a0;

import androidx.work.impl.WorkDatabase;
import java.util.HashSet;
import q.h;
import q.k;
import r.c;
import r.g;
import r.k;

public final class e implements Runnable {
  public static final String k = h.e("EnqueueRunnable");
  
  public final g i;
  
  public final c j;
  
  public e(g paramg) {
    this.i = paramg;
    this.j = new c();
  }
  
  public static boolean a(g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/util/List;
    //   4: astore #15
    //   6: aload #15
    //   8: ifnull -> 104
    //   11: aload #15
    //   13: invokeinterface iterator : ()Ljava/util/Iterator;
    //   18: astore #15
    //   20: iconst_0
    //   21: istore_1
    //   22: iload_1
    //   23: istore #8
    //   25: aload #15
    //   27: invokeinterface hasNext : ()Z
    //   32: ifeq -> 107
    //   35: aload #15
    //   37: invokeinterface next : ()Ljava/lang/Object;
    //   42: checkcast r/g
    //   45: astore #16
    //   47: aload #16
    //   49: getfield h : Z
    //   52: ifne -> 66
    //   55: iload_1
    //   56: aload #16
    //   58: invokestatic a : (Lr/g;)Z
    //   61: ior
    //   62: istore_1
    //   63: goto -> 22
    //   66: invokestatic c : ()Lq/h;
    //   69: getstatic a0/e.k : Ljava/lang/String;
    //   72: ldc 'Already enqueued work ids (%s).'
    //   74: iconst_1
    //   75: anewarray java/lang/Object
    //   78: dup
    //   79: iconst_0
    //   80: ldc ', '
    //   82: aload #16
    //   84: getfield e : Ljava/util/ArrayList;
    //   87: invokestatic join : (Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;
    //   90: aastore
    //   91: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   94: iconst_0
    //   95: anewarray java/lang/Throwable
    //   98: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   101: goto -> 22
    //   104: iconst_0
    //   105: istore #8
    //   107: aload_0
    //   108: invokestatic b : (Lr/g;)Ljava/util/HashSet;
    //   111: astore #16
    //   113: aload_0
    //   114: getfield a : Lr/k;
    //   117: astore #15
    //   119: aload_0
    //   120: getfield d : Ljava/util/List;
    //   123: astore #25
    //   125: aload #16
    //   127: iconst_0
    //   128: anewarray java/lang/String
    //   131: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   136: checkcast [Ljava/lang/String;
    //   139: astore #18
    //   141: aload_0
    //   142: getfield b : Ljava/lang/String;
    //   145: astore #21
    //   147: aload_0
    //   148: getfield c : I
    //   151: istore #11
    //   153: getstatic q/m.i : Lq/m;
    //   156: astore #16
    //   158: getstatic q/m.k : Lq/m;
    //   161: astore #26
    //   163: getstatic q/m.n : Lq/m;
    //   166: astore #22
    //   168: getstatic q/m.l : Lq/m;
    //   171: astore #23
    //   173: invokestatic currentTimeMillis : ()J
    //   176: lstore #12
    //   178: aload #15
    //   180: getfield c : Landroidx/work/impl/WorkDatabase;
    //   183: astore #24
    //   185: aload #18
    //   187: ifnull -> 202
    //   190: aload #18
    //   192: arraylength
    //   193: ifle -> 202
    //   196: iconst_1
    //   197: istore #4
    //   199: goto -> 205
    //   202: iconst_0
    //   203: istore #4
    //   205: iload #4
    //   207: ifeq -> 367
    //   210: aload #18
    //   212: arraylength
    //   213: istore #9
    //   215: iconst_0
    //   216: istore #10
    //   218: iconst_1
    //   219: istore #7
    //   221: iconst_0
    //   222: istore #6
    //   224: iconst_0
    //   225: istore #5
    //   227: iload #7
    //   229: istore_1
    //   230: iload #6
    //   232: istore_2
    //   233: iload #5
    //   235: istore_3
    //   236: iload #10
    //   238: iload #9
    //   240: if_icmpge -> 373
    //   243: aload #18
    //   245: iload #10
    //   247: aaload
    //   248: astore #17
    //   250: aload #24
    //   252: invokevirtual n : ()Lz/q;
    //   255: checkcast z/r
    //   258: aload #17
    //   260: invokevirtual i : (Ljava/lang/String;)Lz/p;
    //   263: astore #19
    //   265: aload #19
    //   267: ifnonnull -> 300
    //   270: invokestatic c : ()Lq/h;
    //   273: getstatic a0/e.k : Ljava/lang/String;
    //   276: ldc 'Prerequisite %s doesn't exist; not enqueuing'
    //   278: iconst_1
    //   279: anewarray java/lang/Object
    //   282: dup
    //   283: iconst_0
    //   284: aload #17
    //   286: aastore
    //   287: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   290: iconst_0
    //   291: anewarray java/lang/Throwable
    //   294: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   297: goto -> 497
    //   300: aload #19
    //   302: getfield b : Lq/m;
    //   305: astore #17
    //   307: aload #17
    //   309: aload #26
    //   311: if_acmpne -> 319
    //   314: iconst_1
    //   315: istore_1
    //   316: goto -> 321
    //   319: iconst_0
    //   320: istore_1
    //   321: iload #7
    //   323: iload_1
    //   324: iand
    //   325: istore #7
    //   327: aload #17
    //   329: aload #23
    //   331: if_acmpne -> 339
    //   334: iconst_1
    //   335: istore_1
    //   336: goto -> 355
    //   339: iload #5
    //   341: istore_1
    //   342: aload #17
    //   344: aload #22
    //   346: if_acmpne -> 355
    //   349: iconst_1
    //   350: istore #6
    //   352: iload #5
    //   354: istore_1
    //   355: iload #10
    //   357: iconst_1
    //   358: iadd
    //   359: istore #10
    //   361: iload_1
    //   362: istore #5
    //   364: goto -> 227
    //   367: iconst_1
    //   368: istore_1
    //   369: iconst_0
    //   370: istore_2
    //   371: iconst_0
    //   372: istore_3
    //   373: aload #21
    //   375: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   378: iconst_1
    //   379: ixor
    //   380: istore #6
    //   382: iload #6
    //   384: ifeq -> 398
    //   387: iload #4
    //   389: ifne -> 398
    //   392: iconst_1
    //   393: istore #5
    //   395: goto -> 401
    //   398: iconst_0
    //   399: istore #5
    //   401: iload #5
    //   403: ifeq -> 1017
    //   406: aload #24
    //   408: invokevirtual n : ()Lz/q;
    //   411: checkcast z/r
    //   414: aload #21
    //   416: invokevirtual j : (Ljava/lang/String;)Ljava/util/ArrayList;
    //   419: astore #19
    //   421: aload #19
    //   423: invokevirtual isEmpty : ()Z
    //   426: ifne -> 1017
    //   429: iload #11
    //   431: iconst_3
    //   432: if_icmpeq -> 589
    //   435: iload #11
    //   437: iconst_4
    //   438: if_icmpne -> 444
    //   441: goto -> 589
    //   444: iload #11
    //   446: iconst_2
    //   447: if_icmpne -> 502
    //   450: aload #19
    //   452: invokevirtual iterator : ()Ljava/util/Iterator;
    //   455: astore #17
    //   457: aload #17
    //   459: invokeinterface hasNext : ()Z
    //   464: ifeq -> 502
    //   467: aload #17
    //   469: invokeinterface next : ()Ljava/lang/Object;
    //   474: checkcast z/p$a
    //   477: getfield b : Lq/m;
    //   480: astore #20
    //   482: aload #20
    //   484: aload #16
    //   486: if_acmpeq -> 497
    //   489: aload #20
    //   491: getstatic q/m.j : Lq/m;
    //   494: if_acmpne -> 457
    //   497: iconst_0
    //   498: istore_1
    //   499: goto -> 1803
    //   502: new a0/c
    //   505: dup
    //   506: aload #15
    //   508: aload #21
    //   510: invokespecial <init> : (Lr/k;Ljava/lang/String;)V
    //   513: invokevirtual run : ()V
    //   516: aload #24
    //   518: invokevirtual n : ()Lz/q;
    //   521: astore #17
    //   523: aload #19
    //   525: invokevirtual iterator : ()Ljava/util/Iterator;
    //   528: astore #19
    //   530: aload #19
    //   532: invokeinterface hasNext : ()Z
    //   537: ifeq -> 568
    //   540: aload #19
    //   542: invokeinterface next : ()Ljava/lang/Object;
    //   547: checkcast z/p$a
    //   550: getfield a : Ljava/lang/String;
    //   553: astore #20
    //   555: aload #17
    //   557: checkcast z/r
    //   560: aload #20
    //   562: invokevirtual a : (Ljava/lang/String;)V
    //   565: goto -> 530
    //   568: iload #6
    //   570: istore #7
    //   572: aload #15
    //   574: astore #17
    //   576: iconst_1
    //   577: istore #5
    //   579: aload #18
    //   581: astore #15
    //   583: iload_1
    //   584: istore #6
    //   586: goto -> 1043
    //   589: aload #24
    //   591: invokevirtual i : ()Lz/b;
    //   594: astore #17
    //   596: new java/util/ArrayList
    //   599: dup
    //   600: invokespecial <init> : ()V
    //   603: astore #20
    //   605: aload #19
    //   607: invokevirtual iterator : ()Ljava/util/Iterator;
    //   610: astore #19
    //   612: iload_1
    //   613: istore #5
    //   615: iload #6
    //   617: istore #4
    //   619: aload #19
    //   621: invokeinterface hasNext : ()Z
    //   626: ifeq -> 872
    //   629: aload #19
    //   631: invokeinterface next : ()Ljava/lang/Object;
    //   636: checkcast z/p$a
    //   639: astore #27
    //   641: aload #27
    //   643: getfield a : Ljava/lang/String;
    //   646: astore #29
    //   648: aload #17
    //   650: checkcast z/c
    //   653: astore #30
    //   655: aload #30
    //   657: invokevirtual getClass : ()Ljava/lang/Class;
    //   660: pop
    //   661: iconst_1
    //   662: ldc 'SELECT COUNT(*)>0 FROM dependency WHERE prerequisite_id=?'
    //   664: invokestatic d : (ILjava/lang/String;)Li/j;
    //   667: astore #28
    //   669: aload #29
    //   671: ifnonnull -> 683
    //   674: aload #28
    //   676: iconst_1
    //   677: invokevirtual f : (I)V
    //   680: goto -> 691
    //   683: aload #28
    //   685: iconst_1
    //   686: aload #29
    //   688: invokevirtual g : (ILjava/lang/String;)V
    //   691: aload #30
    //   693: getfield a : Li/h;
    //   696: invokevirtual b : ()V
    //   699: aload #30
    //   701: getfield a : Li/h;
    //   704: aload #28
    //   706: invokevirtual g : (Ll/c;)Landroid/database/Cursor;
    //   709: astore #29
    //   711: aload #29
    //   713: invokeinterface moveToFirst : ()Z
    //   718: ifeq -> 740
    //   721: aload #29
    //   723: iconst_0
    //   724: invokeinterface getInt : (I)I
    //   729: istore_1
    //   730: iload_1
    //   731: ifeq -> 740
    //   734: iconst_1
    //   735: istore #9
    //   737: goto -> 743
    //   740: iconst_0
    //   741: istore #9
    //   743: aload #29
    //   745: invokeinterface close : ()V
    //   750: aload #28
    //   752: invokevirtual h : ()V
    //   755: iload #5
    //   757: istore #7
    //   759: iload_2
    //   760: istore #6
    //   762: iload_3
    //   763: istore_1
    //   764: iload #9
    //   766: ifne -> 845
    //   769: aload #27
    //   771: getfield b : Lq/m;
    //   774: astore #28
    //   776: aload #28
    //   778: aload #26
    //   780: if_acmpne -> 789
    //   783: iconst_1
    //   784: istore #6
    //   786: goto -> 792
    //   789: iconst_0
    //   790: istore #6
    //   792: aload #28
    //   794: aload #23
    //   796: if_acmpne -> 806
    //   799: iload_2
    //   800: istore_1
    //   801: iconst_1
    //   802: istore_3
    //   803: goto -> 820
    //   806: aload #28
    //   808: aload #22
    //   810: if_acmpne -> 818
    //   813: iconst_1
    //   814: istore_1
    //   815: goto -> 820
    //   818: iload_2
    //   819: istore_1
    //   820: aload #20
    //   822: aload #27
    //   824: getfield a : Ljava/lang/String;
    //   827: invokevirtual add : (Ljava/lang/Object;)Z
    //   830: pop
    //   831: iload_1
    //   832: istore_2
    //   833: iload #5
    //   835: iload #6
    //   837: iand
    //   838: istore #7
    //   840: iload_3
    //   841: istore_1
    //   842: iload_2
    //   843: istore #6
    //   845: iload #7
    //   847: istore #5
    //   849: iload #6
    //   851: istore_2
    //   852: iload_1
    //   853: istore_3
    //   854: goto -> 619
    //   857: astore_0
    //   858: aload #29
    //   860: invokeinterface close : ()V
    //   865: aload #28
    //   867: invokevirtual h : ()V
    //   870: aload_0
    //   871: athrow
    //   872: iload #4
    //   874: istore #6
    //   876: aload #15
    //   878: astore #17
    //   880: iload #11
    //   882: iconst_4
    //   883: if_icmpne -> 959
    //   886: iload_2
    //   887: ifne -> 894
    //   890: iload_3
    //   891: ifeq -> 959
    //   894: aload #24
    //   896: invokevirtual n : ()Lz/q;
    //   899: checkcast z/r
    //   902: astore #15
    //   904: aload #15
    //   906: aload #21
    //   908: invokevirtual j : (Ljava/lang/String;)Ljava/util/ArrayList;
    //   911: invokevirtual iterator : ()Ljava/util/Iterator;
    //   914: astore #19
    //   916: aload #19
    //   918: invokeinterface hasNext : ()Z
    //   923: ifeq -> 947
    //   926: aload #15
    //   928: aload #19
    //   930: invokeinterface next : ()Ljava/lang/Object;
    //   935: checkcast z/p$a
    //   938: getfield a : Ljava/lang/String;
    //   941: invokevirtual a : (Ljava/lang/String;)V
    //   944: goto -> 916
    //   947: invokestatic emptyList : ()Ljava/util/List;
    //   950: astore #15
    //   952: iconst_0
    //   953: istore_1
    //   954: iconst_0
    //   955: istore_3
    //   956: goto -> 965
    //   959: iload_2
    //   960: istore_1
    //   961: aload #20
    //   963: astore #15
    //   965: aload #15
    //   967: aload #18
    //   969: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   974: checkcast [Ljava/lang/String;
    //   977: astore #15
    //   979: aload #15
    //   981: arraylength
    //   982: istore #4
    //   984: iload_1
    //   985: istore_2
    //   986: iload #4
    //   988: ifle -> 1004
    //   991: iconst_1
    //   992: istore #4
    //   994: iload #5
    //   996: istore_1
    //   997: iload #6
    //   999: istore #5
    //   1001: goto -> 1029
    //   1004: iconst_0
    //   1005: istore #4
    //   1007: iload #5
    //   1009: istore_1
    //   1010: iload #6
    //   1012: istore #5
    //   1014: goto -> 1029
    //   1017: iload #6
    //   1019: istore #5
    //   1021: aload #15
    //   1023: astore #17
    //   1025: aload #18
    //   1027: astore #15
    //   1029: iconst_0
    //   1030: istore #9
    //   1032: iload #5
    //   1034: istore #7
    //   1036: iload_1
    //   1037: istore #6
    //   1039: iload #9
    //   1041: istore #5
    //   1043: aload #25
    //   1045: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1050: astore #19
    //   1052: aload #16
    //   1054: astore #18
    //   1056: aload #19
    //   1058: astore #16
    //   1060: iload #5
    //   1062: istore_1
    //   1063: aload #16
    //   1065: invokeinterface hasNext : ()Z
    //   1070: ifeq -> 1803
    //   1073: aload #16
    //   1075: invokeinterface next : ()Ljava/lang/Object;
    //   1080: checkcast q/o
    //   1083: astore #19
    //   1085: aload #19
    //   1087: getfield b : Lz/p;
    //   1090: astore #20
    //   1092: iload #4
    //   1094: ifeq -> 1141
    //   1097: iload #6
    //   1099: ifne -> 1141
    //   1102: iload_3
    //   1103: ifeq -> 1116
    //   1106: aload #20
    //   1108: aload #23
    //   1110: putfield b : Lq/m;
    //   1113: goto -> 1165
    //   1116: iload_2
    //   1117: ifeq -> 1130
    //   1120: aload #20
    //   1122: aload #22
    //   1124: putfield b : Lq/m;
    //   1127: goto -> 1165
    //   1130: aload #20
    //   1132: getstatic q/m.m : Lq/m;
    //   1135: putfield b : Lq/m;
    //   1138: goto -> 1165
    //   1141: aload #20
    //   1143: invokevirtual c : ()Z
    //   1146: ifne -> 1159
    //   1149: aload #20
    //   1151: lload #12
    //   1153: putfield n : J
    //   1156: goto -> 1165
    //   1159: aload #20
    //   1161: lconst_0
    //   1162: putfield n : J
    //   1165: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1168: istore #5
    //   1170: iload #5
    //   1172: bipush #23
    //   1174: if_icmplt -> 1187
    //   1177: iload #5
    //   1179: bipush #25
    //   1181: if_icmpgt -> 1187
    //   1184: goto -> 1266
    //   1187: iload #5
    //   1189: bipush #22
    //   1191: if_icmpgt -> 1390
    //   1194: ldc_w 'androidx.work.impl.background.gcm.GcmScheduler'
    //   1197: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   1200: astore #25
    //   1202: aload #17
    //   1204: getfield e : Ljava/util/List;
    //   1207: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1212: astore #26
    //   1214: aload #26
    //   1216: invokeinterface hasNext : ()Z
    //   1221: ifeq -> 1258
    //   1224: aload #25
    //   1226: aload #26
    //   1228: invokeinterface next : ()Ljava/lang/Object;
    //   1233: checkcast r/e
    //   1236: invokevirtual getClass : ()Ljava/lang/Class;
    //   1239: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   1242: istore #14
    //   1244: iload #14
    //   1246: ifeq -> 1255
    //   1249: iconst_1
    //   1250: istore #5
    //   1252: goto -> 1261
    //   1255: goto -> 1214
    //   1258: iconst_0
    //   1259: istore #5
    //   1261: iload #5
    //   1263: ifeq -> 1387
    //   1266: aload #20
    //   1268: getfield j : Lq/b;
    //   1271: astore #26
    //   1273: aload #20
    //   1275: getfield c : Ljava/lang/String;
    //   1278: astore #25
    //   1280: aload #25
    //   1282: ldc_w androidx/work/impl/workers/ConstraintTrackingWorker
    //   1285: invokevirtual getName : ()Ljava/lang/String;
    //   1288: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1291: ifne -> 1387
    //   1294: aload #26
    //   1296: getfield d : Z
    //   1299: ifne -> 1310
    //   1302: aload #26
    //   1304: getfield e : Z
    //   1307: ifeq -> 1387
    //   1310: new androidx/work/b$a
    //   1313: dup
    //   1314: invokespecial <init> : ()V
    //   1317: astore #26
    //   1319: aload #26
    //   1321: aload #20
    //   1323: getfield e : Landroidx/work/b;
    //   1326: getfield a : Ljava/util/HashMap;
    //   1329: invokevirtual a : (Ljava/util/HashMap;)V
    //   1332: aload #26
    //   1334: getfield a : Ljava/util/HashMap;
    //   1337: ldc_w 'androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME'
    //   1340: aload #25
    //   1342: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1345: pop
    //   1346: aload #20
    //   1348: ldc_w androidx/work/impl/workers/ConstraintTrackingWorker
    //   1351: invokevirtual getName : ()Ljava/lang/String;
    //   1354: putfield c : Ljava/lang/String;
    //   1357: new androidx/work/b
    //   1360: dup
    //   1361: aload #26
    //   1363: getfield a : Ljava/util/HashMap;
    //   1366: invokespecial <init> : (Ljava/util/HashMap;)V
    //   1369: astore #25
    //   1371: aload #25
    //   1373: invokestatic b : (Landroidx/work/b;)[B
    //   1376: pop
    //   1377: aload #20
    //   1379: aload #25
    //   1381: putfield e : Landroidx/work/b;
    //   1384: goto -> 1390
    //   1387: goto -> 1390
    //   1390: aload #20
    //   1392: getfield b : Lq/m;
    //   1395: aload #18
    //   1397: if_acmpne -> 1402
    //   1400: iconst_1
    //   1401: istore_1
    //   1402: aload #24
    //   1404: invokevirtual n : ()Lz/q;
    //   1407: checkcast z/r
    //   1410: astore #25
    //   1412: aload #25
    //   1414: getfield a : Li/h;
    //   1417: invokevirtual b : ()V
    //   1420: aload #25
    //   1422: getfield a : Li/h;
    //   1425: invokevirtual c : ()V
    //   1428: aload #25
    //   1430: getfield b : Lz/r$a;
    //   1433: aload #20
    //   1435: invokevirtual e : (Ljava/lang/Object;)V
    //   1438: aload #25
    //   1440: getfield a : Li/h;
    //   1443: invokevirtual h : ()V
    //   1446: aload #25
    //   1448: getfield a : Li/h;
    //   1451: invokevirtual f : ()V
    //   1454: iload #4
    //   1456: ifeq -> 1572
    //   1459: aload #15
    //   1461: arraylength
    //   1462: istore #9
    //   1464: iconst_0
    //   1465: istore #5
    //   1467: iload #5
    //   1469: iload #9
    //   1471: if_icmpge -> 1572
    //   1474: aload #15
    //   1476: iload #5
    //   1478: aaload
    //   1479: astore #20
    //   1481: new z/a
    //   1484: dup
    //   1485: aload #19
    //   1487: getfield a : Ljava/util/UUID;
    //   1490: invokevirtual toString : ()Ljava/lang/String;
    //   1493: aload #20
    //   1495: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   1498: astore #25
    //   1500: aload #24
    //   1502: invokevirtual i : ()Lz/b;
    //   1505: checkcast z/c
    //   1508: astore #20
    //   1510: aload #20
    //   1512: getfield a : Li/h;
    //   1515: invokevirtual b : ()V
    //   1518: aload #20
    //   1520: getfield a : Li/h;
    //   1523: invokevirtual c : ()V
    //   1526: aload #20
    //   1528: getfield b : Lz/c$a;
    //   1531: aload #25
    //   1533: invokevirtual e : (Ljava/lang/Object;)V
    //   1536: aload #20
    //   1538: getfield a : Li/h;
    //   1541: invokevirtual h : ()V
    //   1544: aload #20
    //   1546: getfield a : Li/h;
    //   1549: invokevirtual f : ()V
    //   1552: iload #5
    //   1554: iconst_1
    //   1555: iadd
    //   1556: istore #5
    //   1558: goto -> 1467
    //   1561: astore_0
    //   1562: aload #20
    //   1564: getfield a : Li/h;
    //   1567: invokevirtual f : ()V
    //   1570: aload_0
    //   1571: athrow
    //   1572: aload #19
    //   1574: getfield c : Ljava/util/Set;
    //   1577: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1582: astore #20
    //   1584: aload #20
    //   1586: invokeinterface hasNext : ()Z
    //   1591: ifeq -> 1695
    //   1594: aload #20
    //   1596: invokeinterface next : ()Ljava/lang/Object;
    //   1601: checkcast java/lang/String
    //   1604: astore #26
    //   1606: aload #24
    //   1608: invokevirtual o : ()Lz/t;
    //   1611: astore #25
    //   1613: new z/s
    //   1616: dup
    //   1617: aload #26
    //   1619: aload #19
    //   1621: getfield a : Ljava/util/UUID;
    //   1624: invokevirtual toString : ()Ljava/lang/String;
    //   1627: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   1630: astore #26
    //   1632: aload #25
    //   1634: checkcast z/u
    //   1637: astore #25
    //   1639: aload #25
    //   1641: getfield a : Li/h;
    //   1644: invokevirtual b : ()V
    //   1647: aload #25
    //   1649: getfield a : Li/h;
    //   1652: invokevirtual c : ()V
    //   1655: aload #25
    //   1657: getfield b : Lz/u$a;
    //   1660: aload #26
    //   1662: invokevirtual e : (Ljava/lang/Object;)V
    //   1665: aload #25
    //   1667: getfield a : Li/h;
    //   1670: invokevirtual h : ()V
    //   1673: aload #25
    //   1675: getfield a : Li/h;
    //   1678: invokevirtual f : ()V
    //   1681: goto -> 1584
    //   1684: astore_0
    //   1685: aload #25
    //   1687: getfield a : Li/h;
    //   1690: invokevirtual f : ()V
    //   1693: aload_0
    //   1694: athrow
    //   1695: iload #7
    //   1697: ifeq -> 1789
    //   1700: aload #24
    //   1702: invokevirtual l : ()Lz/k;
    //   1705: astore #20
    //   1707: new z/j
    //   1710: dup
    //   1711: aload #21
    //   1713: aload #19
    //   1715: getfield a : Ljava/util/UUID;
    //   1718: invokevirtual toString : ()Ljava/lang/String;
    //   1721: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   1724: astore #19
    //   1726: aload #20
    //   1728: checkcast z/l
    //   1731: astore #20
    //   1733: aload #20
    //   1735: getfield a : Li/h;
    //   1738: invokevirtual b : ()V
    //   1741: aload #20
    //   1743: getfield a : Li/h;
    //   1746: invokevirtual c : ()V
    //   1749: aload #20
    //   1751: getfield b : Lz/l$a;
    //   1754: aload #19
    //   1756: invokevirtual e : (Ljava/lang/Object;)V
    //   1759: aload #20
    //   1761: getfield a : Li/h;
    //   1764: invokevirtual h : ()V
    //   1767: aload #20
    //   1769: getfield a : Li/h;
    //   1772: invokevirtual f : ()V
    //   1775: goto -> 1789
    //   1778: astore_0
    //   1779: aload #20
    //   1781: getfield a : Li/h;
    //   1784: invokevirtual f : ()V
    //   1787: aload_0
    //   1788: athrow
    //   1789: goto -> 1063
    //   1792: astore_0
    //   1793: aload #25
    //   1795: getfield a : Li/h;
    //   1798: invokevirtual f : ()V
    //   1801: aload_0
    //   1802: athrow
    //   1803: aload_0
    //   1804: iconst_1
    //   1805: putfield h : Z
    //   1808: iload #8
    //   1810: iload_1
    //   1811: ior
    //   1812: ireturn
    //   1813: astore #25
    //   1815: goto -> 1258
    //   1818: astore #25
    //   1820: goto -> 1258
    // Exception table:
    //   from	to	target	type
    //   711	730	857	finally
    //   1194	1202	1813	java/lang/ClassNotFoundException
    //   1202	1214	1818	java/lang/ClassNotFoundException
    //   1214	1244	1818	java/lang/ClassNotFoundException
    //   1428	1446	1792	finally
    //   1526	1544	1561	finally
    //   1655	1673	1684	finally
    //   1749	1767	1778	finally
  }
  
  public final void run() {
    try {
      g g1 = this.i;
      g1.getClass();
      if (!g.a(g1, new HashSet())) {
        k k;
        WorkDatabase workDatabase = this.i.a.c;
        workDatabase.c();
        try {
          boolean bool = a(this.i);
          workDatabase.h();
          return;
        } finally {
          k.f();
        } 
      } 
      throw new IllegalStateException(String.format("WorkContinuation has cycles (%s)", new Object[] { this.i }));
    } finally {
      Exception exception = null;
      this.j.a((k.a)new k.a.a(exception));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */