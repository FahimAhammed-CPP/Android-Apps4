package a0;

import androidx.work.impl.WorkDatabase;
import c0.a;
import q.e;
import q.h;
import y.a;

public final class q implements e {
  public final a a;
  
  public final a b;
  
  public final z.q c;
  
  static {
    h.e("WMFgUpdater");
  }
  
  public q(WorkDatabase paramWorkDatabase, a parama, a parama1) {
    this.b = parama;
    this.a = parama1;
    this.c = paramWorkDatabase.n();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */