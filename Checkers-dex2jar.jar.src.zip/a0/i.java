package a0;

import android.app.Application;
import android.app.job.JobInfo;
import android.graphics.drawable.Icon;



/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */