package a0;

import q.k;
import r.c;
import r.k;

public abstract class d implements Runnable {
  public final c i = new c();
  
  public static void a(k paramk, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/work/impl/WorkDatabase;
    //   4: astore #5
    //   6: aload #5
    //   8: invokevirtual n : ()Lz/q;
    //   11: astore #4
    //   13: aload #5
    //   15: invokevirtual i : ()Lz/b;
    //   18: astore #5
    //   20: new java/util/LinkedList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #6
    //   29: aload #6
    //   31: aload_1
    //   32: invokevirtual add : (Ljava/lang/Object;)Z
    //   35: pop
    //   36: aload #6
    //   38: invokevirtual isEmpty : ()Z
    //   41: istore_3
    //   42: iconst_1
    //   43: istore_2
    //   44: iload_3
    //   45: ifne -> 127
    //   48: aload #6
    //   50: invokevirtual remove : ()Ljava/lang/Object;
    //   53: checkcast java/lang/String
    //   56: astore #7
    //   58: aload #4
    //   60: checkcast z/r
    //   63: astore #8
    //   65: aload #8
    //   67: aload #7
    //   69: invokevirtual f : (Ljava/lang/String;)Lq/m;
    //   72: astore #9
    //   74: aload #9
    //   76: getstatic q/m.k : Lq/m;
    //   79: if_acmpeq -> 108
    //   82: aload #9
    //   84: getstatic q/m.l : Lq/m;
    //   87: if_acmpeq -> 108
    //   90: aload #8
    //   92: getstatic q/m.n : Lq/m;
    //   95: iconst_1
    //   96: anewarray java/lang/String
    //   99: dup
    //   100: iconst_0
    //   101: aload #7
    //   103: aastore
    //   104: invokevirtual p : (Lq/m;[Ljava/lang/String;)I
    //   107: pop
    //   108: aload #6
    //   110: aload #5
    //   112: checkcast z/c
    //   115: aload #7
    //   117: invokevirtual a : (Ljava/lang/String;)Ljava/util/ArrayList;
    //   120: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   123: pop
    //   124: goto -> 36
    //   127: aload_0
    //   128: getfield f : Lr/d;
    //   131: astore #7
    //   133: aload #7
    //   135: getfield k : Ljava/lang/Object;
    //   138: astore #6
    //   140: aload #6
    //   142: monitorenter
    //   143: invokestatic c : ()Lq/h;
    //   146: getstatic r/d.l : Ljava/lang/String;
    //   149: ldc 'Processor cancelling %s'
    //   151: iconst_1
    //   152: anewarray java/lang/Object
    //   155: dup
    //   156: iconst_0
    //   157: aload_1
    //   158: aastore
    //   159: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   162: iconst_0
    //   163: anewarray java/lang/Throwable
    //   166: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   169: aload #7
    //   171: getfield i : Ljava/util/HashSet;
    //   174: aload_1
    //   175: invokevirtual add : (Ljava/lang/Object;)Z
    //   178: pop
    //   179: aload #7
    //   181: getfield f : Ljava/util/HashMap;
    //   184: aload_1
    //   185: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   188: checkcast r/n
    //   191: astore #5
    //   193: aload #5
    //   195: ifnull -> 293
    //   198: goto -> 201
    //   201: aload #5
    //   203: astore #4
    //   205: aload #5
    //   207: ifnonnull -> 224
    //   210: aload #7
    //   212: getfield g : Ljava/util/HashMap;
    //   215: aload_1
    //   216: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast r/n
    //   222: astore #4
    //   224: aload_1
    //   225: aload #4
    //   227: invokestatic c : (Ljava/lang/String;Lr/n;)Z
    //   230: pop
    //   231: iload_2
    //   232: ifeq -> 240
    //   235: aload #7
    //   237: invokevirtual g : ()V
    //   240: aload #6
    //   242: monitorexit
    //   243: aload_0
    //   244: getfield e : Ljava/util/List;
    //   247: invokeinterface iterator : ()Ljava/util/Iterator;
    //   252: astore_0
    //   253: aload_0
    //   254: invokeinterface hasNext : ()Z
    //   259: ifeq -> 280
    //   262: aload_0
    //   263: invokeinterface next : ()Ljava/lang/Object;
    //   268: checkcast r/e
    //   271: aload_1
    //   272: invokeinterface b : (Ljava/lang/String;)V
    //   277: goto -> 253
    //   280: return
    //   281: astore_0
    //   282: aload #6
    //   284: monitorexit
    //   285: goto -> 290
    //   288: aload_0
    //   289: athrow
    //   290: goto -> 288
    //   293: iconst_0
    //   294: istore_2
    //   295: goto -> 201
    // Exception table:
    //   from	to	target	type
    //   143	193	281	finally
    //   210	224	281	finally
    //   224	231	281	finally
    //   235	240	281	finally
    //   240	243	281	finally
    //   282	285	281	finally
  }
  
  public abstract void b();
  
  public final void run() {
    try {
      return;
    } finally {
      Exception exception = null;
      this.i.a((k.a)new k.a.a(exception));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */