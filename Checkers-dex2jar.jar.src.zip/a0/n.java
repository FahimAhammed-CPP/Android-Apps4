package a0;

import android.content.Context;
import android.os.PowerManager;
import java.util.WeakHashMap;
import q.h;

public final class n {
  public static final String a = h.e("WakeLocks");
  
  public static final WeakHashMap<PowerManager.WakeLock, String> b = new WeakHashMap<PowerManager.WakeLock, String>();
  
  public static PowerManager.WakeLock a(Context paramContext, String paramString) {
    PowerManager powerManager = (PowerManager)paramContext.getApplicationContext().getSystemService("power");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("WorkManager: ");
    stringBuilder.append(paramString);
    paramString = stringBuilder.toString();
    PowerManager.WakeLock wakeLock = powerManager.newWakeLock(1, paramString);
    synchronized (b) {
      null.put(wakeLock, paramString);
      return wakeLock;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */