package a0;

import androidx.work.impl.WorkDatabase;
import q.h;
import r.d;
import r.k;
import z.q;

public final class m implements Runnable {
  public static final String l = h.e("StopWorkRunnable");
  
  public final k i;
  
  public final String j;
  
  public final boolean k;
  
  public m(k paramk, String paramString, boolean paramBoolean) {
    this.i = paramk;
    this.j = paramString;
    this.k = paramBoolean;
  }
  
  public final void run() {
    k k1 = this.i;
    WorkDatabase workDatabase = k1.c;
    d d = k1.f;
    null = workDatabase.n();
    workDatabase.c();
    try {
      String str = this.j;
    } finally {
      workDatabase.f();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\a0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */