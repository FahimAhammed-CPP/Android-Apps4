package c1;

import android.os.Bundle;
import android.os.SystemClock;
import c.b;
import c.c;
import com.google.android.gms.measurement.internal.zzkw;
import d1.c7;
import d1.e4;
import d1.f5;
import d1.l5;
import d1.m4;
import d1.u1;
import d1.w4;
import d1.y2;
import d1.y4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import p0.e;

public final class a extends c {
  public final e4 a;
  
  public final f5 b;
  
  public a(e4 parame4) {
    e.g(parame4);
    this.a = parame4;
    this.b = parame4.t();
  }
  
  public final void a(String paramString) {
    u1 u1 = this.a.l();
    this.a.n.getClass();
    u1.h(paramString, SystemClock.elapsedRealtime());
  }
  
  public final void b(String paramString1, Bundle paramBundle, String paramString2) {
    this.a.t().k(paramString1, paramBundle, paramString2);
  }
  
  public final List c(String paramString1, String paramString2) {
    f5 f51 = this.b;
    if (((m4)f51).a.b().q()) {
      (((m4)f51).a.d()).f.a("Cannot get conditional user properties from analytics worker thread");
      return new ArrayList(0);
    } 
    ((m4)f51).a.getClass();
    if (c.n()) {
      (((m4)f51).a.d()).f.a("Cannot get conditional user properties from main thread");
      return new ArrayList(0);
    } 
    AtomicReference<List> atomicReference = new AtomicReference();
    ((m4)f51).a.b().l(atomicReference, 5000L, "get conditional user properties", (Runnable)new w4(f51, atomicReference, paramString1, paramString2));
    List list = atomicReference.get();
    if (list == null) {
      (((m4)f51).a.d()).f.b("Timed out waiting for get conditional user properties", null);
      return new ArrayList();
    } 
    return c7.q(list);
  }
  
  public final Map d(String paramString1, String paramString2, boolean paramBoolean) {
    b b;
    f5 f51 = this.b;
    if (((m4)f51).a.b().q()) {
      y2 y2 = (((m4)f51).a.d()).f;
      paramString2 = "Cannot get user properties from analytics worker thread";
    } else {
      y2 y2;
      ((m4)f51).a.getClass();
      if (c.n()) {
        y2 = (((m4)f51).a.d()).f;
        paramString2 = "Cannot get user properties from main thread";
      } else {
        AtomicReference<List> atomicReference = new AtomicReference();
        ((m4)f51).a.b().l(atomicReference, 5000L, "get user properties", (Runnable)new y4(f51, atomicReference, (String)y2, paramString2, paramBoolean));
        List list = atomicReference.get();
        if (list == null) {
          (((m4)f51).a.d()).f.b("Timed out waiting for handle get user properties, includeInternal", Boolean.valueOf(paramBoolean));
          return Collections.emptyMap();
        } 
        b = new b(list.size());
        for (zzkw zzkw : list) {
          Object object = zzkw.b();
          if (object != null)
            b.put(zzkw.j, object); 
        } 
        return (Map)b;
      } 
    } 
    b.a(paramString2);
    return Collections.emptyMap();
  }
  
  public final int e(String paramString) {
    f5 f51 = this.b;
    f51.getClass();
    e.d(paramString);
    ((m4)f51).a.getClass();
    return 25;
  }
  
  public final void f(Bundle paramBundle) {
    f5 f51 = this.b;
    ((m4)f51).a.n.getClass();
    f51.r(paramBundle, System.currentTimeMillis());
  }
  
  public final void g(String paramString1, Bundle paramBundle, String paramString2) {
    f5 f51 = this.b;
    ((m4)f51).a.n.getClass();
    f51.m(paramString1, paramString2, paramBundle, true, true, System.currentTimeMillis());
  }
  
  public final long zzb() {
    return this.a.x().j0();
  }
  
  public final String zzh() {
    return this.b.z();
  }
  
  public final String zzi() {
    l5 l5 = (((m4)this.b).a.u()).c;
    return (l5 != null) ? l5.b : null;
  }
  
  public final String zzj() {
    l5 l5 = (((m4)this.b).a.u()).c;
    return (l5 != null) ? l5.a : null;
  }
  
  public final String zzk() {
    return this.b.z();
  }
  
  public final void zzr(String paramString) {
    u1 u1 = this.a.l();
    this.a.n.getClass();
    u1.i(paramString, SystemClock.elapsedRealtime());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */