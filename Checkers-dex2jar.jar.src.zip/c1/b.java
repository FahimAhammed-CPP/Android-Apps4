package c1;

import android.os.Bundle;
import d1.g5;
import java.util.List;
import java.util.Map;

public final class b extends c {
  public final g5 a;
  
  public b(g5 paramg5) {
    this.a = paramg5;
  }
  
  public final void a(String paramString) {
    this.a.a(paramString);
  }
  
  public final void b(String paramString1, Bundle paramBundle, String paramString2) {
    this.a.b(paramString1, paramBundle, paramString2);
  }
  
  public final List c(String paramString1, String paramString2) {
    return this.a.c(paramString1, paramString2);
  }
  
  public final Map d(String paramString1, String paramString2, boolean paramBoolean) {
    return this.a.d(paramString1, paramString2, paramBoolean);
  }
  
  public final int e(String paramString) {
    return this.a.e(paramString);
  }
  
  public final void f(Bundle paramBundle) {
    this.a.f(paramBundle);
  }
  
  public final void g(String paramString1, Bundle paramBundle, String paramString2) {
    this.a.g(paramString1, paramBundle, paramString2);
  }
  
  public final long zzb() {
    return this.a.zzb();
  }
  
  public final String zzh() {
    return this.a.zzh();
  }
  
  public final String zzi() {
    return this.a.zzi();
  }
  
  public final String zzj() {
    return this.a.zzj();
  }
  
  public final String zzk() {
    return this.a.zzk();
  }
  
  public final void zzr(String paramString) {
    this.a.zzr(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */