package c1;

import d1.g5;

public abstract class c implements g5 {}


/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\c1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */