package com.appsflyer;

import com.appsflyer.internal.AFb1bSDK;
import com.appsflyer.internal.AFb1ySDK;
import com.appsflyer.internal.AFc1vSDK;
import com.appsflyer.internal.AFd1pSDK;
import com.appsflyer.internal.components.network.http.ResponseNetwork;
import java.util.Map;

public final class PurchaseHandler {
  private final AFb1bSDK AFKeystoreWrapper;
  
  public final AFc1vSDK valueOf;
  
  public final AFd1pSDK values;
  
  public PurchaseHandler(AFc1vSDK paramAFc1vSDK) {
    this.valueOf = paramAFc1vSDK;
    this.AFKeystoreWrapper = paramAFc1vSDK.AFInAppEventParameterName();
    this.values = paramAFc1vSDK.afDebugLog();
  }
  
  public final boolean AFKeystoreWrapper(Map<String, Object> paramMap, PurchaseValidationCallback paramPurchaseValidationCallback, String... paramVarArgs) {
    boolean bool = AFb1ySDK.AFKeystoreWrapper(paramMap, paramVarArgs, this.AFKeystoreWrapper);
    if (!bool && paramPurchaseValidationCallback != null)
      paramPurchaseValidationCallback.onFailure(new IllegalArgumentException("Invalid Request Data")); 
    return bool;
  }
  
  public static interface PurchaseValidationCallback {
    void onFailure(Throwable param1Throwable);
    
    void onResponse(ResponseNetwork<String> param1ResponseNetwork);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\PurchaseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */