package com.appsflyer.internal;

import android.content.Context;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import com.appsflyer.AFLogger;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public abstract class AFb1jSDK<T> {
  public final AFc1vSDK AFInAppEventParameterName;
  
  private final String[] AFInAppEventType;
  
  public final Context AFKeystoreWrapper;
  
  public final String valueOf;
  
  public final FutureTask<T> values = new FutureTask<T>(new Callable<T>(this) {
        public final T call() {
          return this.values.valueOf() ? this.values.AFInAppEventParameterName() : null;
        }
      });
  
  public AFb1jSDK(Context paramContext, AFc1vSDK paramAFc1vSDK, String paramString, String... paramVarArgs) {
    this.AFKeystoreWrapper = paramContext;
    this.valueOf = paramString;
    this.AFInAppEventType = paramVarArgs;
    this.AFInAppEventParameterName = paramAFc1vSDK;
  }
  
  protected abstract T AFInAppEventParameterName();
  
  public final boolean valueOf() {
    boolean bool = false;
    try {
      ProviderInfo providerInfo = this.AFKeystoreWrapper.getPackageManager().resolveContentProvider(this.valueOf, 128);
      boolean bool1 = bool;
      if (providerInfo != null) {
        boolean bool2 = Arrays.<String>asList(this.AFInAppEventType).contains(AFa1cSDK.values(this.AFKeystoreWrapper.getPackageManager(), ((PackageItemInfo)providerInfo).packageName));
        bool1 = bool;
        if (bool2)
          bool1 = true; 
      } 
      return bool1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
    
    } catch (CertificateException certificateException) {
    
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
    AFLogger.afErrorLog(noSuchAlgorithmException.getMessage(), noSuchAlgorithmException);
    return false;
  }
  
  public T values() {
    try {
      return this.values.get(500L, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interruptedException) {
    
    } catch (ExecutionException executionException) {
    
    } catch (TimeoutException timeoutException) {}
    AFLogger.afErrorLog(timeoutException.getMessage(), timeoutException);
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFb1jSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */