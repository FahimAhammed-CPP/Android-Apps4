package com.appsflyer.internal;

import com.appsflyer.AFLogger;
import com.appsflyer.internal.components.network.http.exceptions.ParsingException;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;

public final class AFc1mSDK<ResponseBody> {
  private final ExecutorService AFInAppEventParameterName;
  
  private final AtomicBoolean AFInAppEventType = new AtomicBoolean(false);
  
  private final AFd1ySDK<ResponseBody> AFKeystoreWrapper;
  
  public final AFc1rSDK valueOf;
  
  private final AFc1gSDK values;
  
  public AFc1mSDK(AFc1rSDK paramAFc1rSDK, ExecutorService paramExecutorService, AFc1gSDK paramAFc1gSDK, AFd1ySDK<ResponseBody> paramAFd1ySDK) {
    this.valueOf = paramAFc1rSDK;
    this.AFInAppEventParameterName = paramExecutorService;
    this.values = paramAFc1gSDK;
    this.AFKeystoreWrapper = paramAFd1ySDK;
  }
  
  public final AFc1aSDK<ResponseBody> AFKeystoreWrapper() throws IOException {
    if (!this.AFInAppEventType.getAndSet(true)) {
      AFc1aSDK aFc1aSDK = this.values.AFInAppEventParameterName(this.valueOf);
      try {
        return new AFc1aSDK(this.AFKeystoreWrapper.AFInAppEventType((String)aFc1aSDK.getBody()), aFc1aSDK.values, aFc1aSDK.valueOf, aFc1aSDK.AFKeystoreWrapper, aFc1aSDK.AFInAppEventParameterName);
      } catch (JSONException jSONException) {
        AFLogger.afErrorLogForExcManagerOnly("could not parse raw response - execute", (Throwable)jSONException);
        throw new ParsingException(jSONException.getMessage(), jSONException, aFc1aSDK);
      } 
    } 
    throw new IllegalStateException("Http call is already executed");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFc1mSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */