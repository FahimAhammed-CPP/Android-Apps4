package com.appsflyer.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.WindowManager;
import com.appsflyer.AFKeystoreWrapper;
import com.appsflyer.AFLogger;
import com.appsflyer.AFVersionDeclaration;
import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerInAppPurchaseValidatorListener;
import com.appsflyer.AppsFlyerLib;
import com.appsflyer.AppsFlyerProperties;
import com.appsflyer.PurchaseHandler;
import com.appsflyer.attribution.AppsFlyerRequestListener;
import com.appsflyer.attribution.RequestError;
import com.appsflyer.deeplink.DeepLinkListener;
import com.appsflyer.deeplink.DeepLinkResult;
import com.appsflyer.internal.platform_extension.PluginInfo;
import com.google.android.gms.common.GoogleApiAvailability;
import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URI;
import java.security.KeyStoreException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AFb1xSDK extends AppsFlyerLib {
  static final String AFInAppEventParameterName = "235";
  
  static AppsFlyerInAppPurchaseValidatorListener AFInAppEventType;
  
  public static final String AFKeystoreWrapper;
  
  private static AFb1xSDK afDebugLog;
  
  private static String afErrorLog = "https://%sstats.%s/stats";
  
  private static int onAppOpenAttribution = 0;
  
  private static int onAttributionFailure = 1;
  
  private static int onResponse;
  
  public static volatile AppsFlyerConversionListener valueOf;
  
  public static final String values;
  
  public AFa1eSDK AFLogger;
  
  private long AFLogger$LogLevel = -1L;
  
  private boolean AFVersionDeclaration = false;
  
  private boolean AppsFlyer2dXConversionCallback;
  
  private String afErrorLogForExcManagerOnly;
  
  String afInfoLog;
  
  private long afRDLog = -1L;
  
  private long afWarnLog = TimeUnit.SECONDS.toMillis(5L);
  
  private Map<Long, String> getLevel;
  
  private Application init;
  
  private boolean onAppOpenAttributionNative = false;
  
  private Map<String, Object> onAttributionFailureNative;
  
  private final AFc1uSDK onConversionDataFail;
  
  private AFb1eSDK onConversionDataSuccess;
  
  private final Executor onDeepLinking = Executors.newSingleThreadExecutor();
  
  private boolean onDeepLinkingNative = false;
  
  private boolean onInstallConversionDataLoadedNative;
  
  private final AFb1uSDK onInstallConversionFailureNative = new AFb1uSDK();
  
  private SharedPreferences onResponseErrorNative;
  
  private String onResponseNative;
  
  static {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(null);
    stringBuilder.append("/androidevent?buildnumber=6.10.3&app_id=");
    values = stringBuilder.toString();
    AFInAppEventType = null;
    valueOf = null;
    afDebugLog = new AFb1xSDK();
    i = onAttributionFailure + 71;
    onResponse = i % 128;
    if (i % 2 == 0)
      bool = false; 
    if (!bool)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public AFb1xSDK() {
    AFVersionDeclaration.init();
    this.onConversionDataFail = new AFc1uSDK();
    AFd1pSDK aFd1pSDK = AFKeystoreWrapper().afDebugLog();
    AFa1zSDK aFa1zSDK = new AFa1zSDK((byte)0);
    aFd1pSDK.valueOf.add(aFa1zSDK);
  }
  
  private static String AFInAppEventParameterName(String paramString) {
    Object object;
    int i = onAttributionFailure + 17;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 52;
    } else {
      i = 53;
    } 
    String str = null;
    if (i != 53) {
      try {
        Class<?> clazz = Class.forName("android.os.SystemProperties");
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[1] = String.class;
        Method method = clazz.getMethod("get", arrayOfClass);
        Object[] arrayOfObject = new Object[0];
        arrayOfObject[1] = paramString;
      } finally {
        paramString = null;
        AFLogger.afErrorLog(paramString.getMessage(), (Throwable)paramString);
      } 
    } else {
      object = Class.forName("android.os.SystemProperties").getMethod("get", new Class[] { String.class }).invoke(null, new Object[] { paramString });
      object = object;
    } 
    i = onResponse + 49;
    onAttributionFailure = i % 128;
    return (String)object;
  }
  
  static void AFInAppEventParameterName() {
    onAppOpenAttribution = 183;
  }
  
  private void AFInAppEventParameterName(Context paramContext, String paramString1, Map<String, Object> paramMap, String paramString2, String paramString3) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: istore #7
    //   5: iload #7
    //   7: bipush #59
    //   9: iadd
    //   10: istore #6
    //   12: iload #6
    //   14: sipush #128
    //   17: irem
    //   18: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   21: aload_2
    //   22: ifnull -> 32
    //   25: bipush #7
    //   27: istore #6
    //   29: goto -> 35
    //   32: iconst_2
    //   33: istore #6
    //   35: iload #6
    //   37: bipush #7
    //   39: if_icmpeq -> 45
    //   42: goto -> 104
    //   45: iload #7
    //   47: bipush #111
    //   49: iadd
    //   50: istore #6
    //   52: iload #6
    //   54: sipush #128
    //   57: irem
    //   58: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   61: iload #6
    //   63: iconst_2
    //   64: irem
    //   65: ifne -> 94
    //   68: aload_2
    //   69: invokevirtual trim : ()Ljava/lang/String;
    //   72: invokevirtual isEmpty : ()Z
    //   75: istore #8
    //   77: bipush #52
    //   79: iconst_0
    //   80: idiv
    //   81: istore #6
    //   83: iload #8
    //   85: ifeq -> 116
    //   88: goto -> 104
    //   91: astore_1
    //   92: aload_1
    //   93: athrow
    //   94: aload_2
    //   95: invokevirtual trim : ()Ljava/lang/String;
    //   98: invokevirtual isEmpty : ()Z
    //   101: ifeq -> 116
    //   104: new com/appsflyer/internal/AFf1vSDK
    //   107: dup
    //   108: invokespecial <init> : ()V
    //   111: astore #9
    //   113: goto -> 125
    //   116: new com/appsflyer/internal/AFf1wSDK
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: astore #9
    //   125: aload_1
    //   126: ifnull -> 136
    //   129: bipush #52
    //   131: istore #6
    //   133: goto -> 140
    //   136: bipush #81
    //   138: istore #6
    //   140: iload #6
    //   142: bipush #52
    //   144: if_icmpeq -> 150
    //   147: goto -> 162
    //   150: aload #9
    //   152: aload_1
    //   153: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   156: checkcast android/app/Application
    //   159: putfield AFKeystoreWrapper : Landroid/app/Application;
    //   162: aload #9
    //   164: aload_2
    //   165: putfield afErrorLog : Ljava/lang/String;
    //   168: aload #9
    //   170: aload_3
    //   171: putfield values : Ljava/util/Map;
    //   174: aload #9
    //   176: aload #4
    //   178: putfield afRDLog : Ljava/lang/String;
    //   181: aload #9
    //   183: aload #5
    //   185: putfield AFInAppEventParameterName : Ljava/lang/String;
    //   188: aload_0
    //   189: aload #9
    //   191: invokespecial values : (Lcom/appsflyer/internal/AFa1sSDK;)V
    //   194: return
    // Exception table:
    //   from	to	target	type
    //   77	83	91	finally
  }
  
  private void AFInAppEventParameterName(AFa1sSDK paramAFa1sSDK) {
    Application application = paramAFa1sSDK.AFKeystoreWrapper;
    if (application == null) {
      i = onResponse + 33;
      onAttributionFailure = i % 128;
      AFLogger.afDebugLog("sendWithEvent - got null context. skipping event/launch.");
      return;
    } 
    SharedPreferences sharedPreferences = valueOf((Context)application);
    AppsFlyerProperties.getInstance().saveProperties(sharedPreferences);
    if (!AFKeystoreWrapper().afWarnLog().valueOf()) {
      StringBuilder stringBuilder = new StringBuilder("sendWithEvent from activity: ");
      stringBuilder.append(application.getClass().getName());
      AFLogger.afInfoLog(stringBuilder.toString());
    } 
    boolean bool = paramAFa1sSDK.AFInAppEventParameterName();
    Map<String, Object> map = AFInAppEventType(paramAFa1sSDK);
    String str = (String)map.get("appsflyerKey");
    application = null;
    int k = 0;
    int j = 0;
    if (str != null) {
      StringBuilder stringBuilder;
      i = onAttributionFailure + 49;
      onResponse = i % 128;
      if (i % 2 == 0) {
        if (str.length() != 0) {
          long l;
          Application application1;
          if (!super.isStopped()) {
            i = 0;
          } else {
            i = 1;
          } 
          if (i != 1) {
            i = onAttributionFailure + 107;
            onResponse = i % 128;
            if (i % 2 == 0) {
              AFLogger.afInfoLog("AppsFlyerLib.sendWithEvent");
            } else {
              AFLogger.afInfoLog("AppsFlyerLib.sendWithEvent");
              try {
                throw null;
              } finally {}
            } 
          } 
          int m = AFKeystoreWrapper(sharedPreferences, false);
          AFf1gSDK aFf1gSDK = new AFf1gSDK((AFc1vSDK)this.onConversionDataFail);
          str = "";
          Intrinsics.checkNotNullParameter(paramAFa1sSDK, "");
          boolean bool1 = paramAFa1sSDK.AFInAppEventParameterName();
          boolean bool2 = paramAFa1sSDK instanceof AFe1dSDK;
          boolean bool3 = paramAFa1sSDK instanceof AFe1bSDK;
          if (paramAFa1sSDK instanceof AFe1cSDK || bool3) {
            String str3 = AFf1gSDK.afRDLog;
            str2 = str3;
            if (str3 == null)
              str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.AFInAppEventType); 
          } else {
            if (bool2) {
              i = 1;
            } else {
              i = 0;
            } 
            if (i != 1) {
              if (bool1) {
                if (m < 2) {
                  String str3 = AFf1gSDK.afDebugLog;
                  str2 = str3;
                  if (str3 == null) {
                    i = onAttributionFailure + 103;
                    onResponse = i % 128;
                    str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.values);
                  } 
                } else {
                  String str3 = AFf1gSDK.afWarnLog;
                  str2 = str3;
                  if (str3 == null)
                    str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.afInfoLog); 
                } 
              } else {
                str2 = AFf1gSDK.getLevel;
                if (str2 == null) {
                  i = 8;
                } else {
                  i = 82;
                } 
                if (i != 82)
                  str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.afErrorLog); 
              } 
            } else {
              String str3 = AFf1gSDK.AFLogger;
              str2 = str3;
              if (str3 == null) {
                i = onResponse + 53;
                onAttributionFailure = i % 128;
                if (i % 2 == 0) {
                  i = 30;
                } else {
                  i = 97;
                } 
                if (i != 30) {
                  str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.AFKeystoreWrapper);
                } else {
                  str2 = aFf1gSDK.AFInAppEventParameterName.AFInAppEventType(AFf1gSDK.AFKeystoreWrapper);
                  try {
                    i = 2 / 0;
                  } finally {}
                } 
              } 
            } 
          } 
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(str2);
          stringBuilder1.append((aFf1gSDK.valueOf.AFInAppEventParameterName()).values.AFKeystoreWrapper.getPackageName());
          String str2 = AFf1gSDK.AFKeystoreWrapper(stringBuilder1.toString(), bool2);
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(str2);
          str2 = aFf1gSDK.valueOf.AFInAppEventParameterName().values();
          if (str2 != null) {
            str2 = "&channel=".concat(String.valueOf(str2));
          } else {
            i = onAttributionFailure + 87;
            onResponse = i % 128;
            application1 = application;
          } 
          if (application1 == null) {
            i = 8;
          } else {
            i = 78;
          } 
          if (i != 78)
            str1 = str; 
          stringBuilder1.append(str1);
          String str1 = stringBuilder1.toString();
          AFInAppEventParameterName(map);
          AFa1ySDK aFa1ySDK = new AFa1ySDK(paramAFa1sSDK.AFInAppEventParameterName(str1).AFInAppEventParameterName(map).AFKeystoreWrapper(m), (byte)0);
          i = k;
          if (bool) {
            AFf1jSDK[] arrayOfAFf1jSDK = AFVersionDeclaration();
            k = arrayOfAFf1jSDK.length;
            i = 0;
            while (j < k) {
              AFf1jSDK aFf1jSDK = arrayOfAFf1jSDK[j];
              if (aFf1jSDK.AFKeystoreWrapper == AFf1jSDK.AFa1wSDK.valueOf) {
                stringBuilder = new StringBuilder("Failed to get ");
                stringBuilder.append(aFf1jSDK.valueOf);
                stringBuilder.append(" referrer, wait ...");
                AFLogger.afDebugLog(stringBuilder.toString());
                i = 1;
              } 
              j++;
            } 
            if (this.onDeepLinkingNative && !afRDLog()) {
              AFLogger.afDebugLog("fetching Facebook deferred AppLink data, wait ...");
              i = 1;
            } 
            if (AFKeystoreWrapper().afWarnLog().values())
              i = 1; 
          } 
          ScheduledExecutorService scheduledExecutorService = AFKeystoreWrapper().values();
          if (i != 0) {
            i = onAttributionFailure + 97;
            onResponse = i % 128;
            l = 500L;
          } else {
            l = 0L;
          } 
          AFInAppEventParameterName(scheduledExecutorService, aFa1ySDK, l, TimeUnit.MILLISECONDS);
          return;
        } 
      } else {
        stringBuilder.length();
        try {
          throw null;
        } finally {}
      } 
    } 
    AFLogger.afDebugLog("Not sending data yet, waiting for dev key");
    null = paramAFa1sSDK.AFInAppEventType;
    if (null != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 1) {
      i = onAttributionFailure + 55;
      onResponse = i % 128;
      if (i % 2 != 0) {
        null.onError(RequestError.NO_DEV_KEY, AFb1aSDK.values);
        try {
          i = 95 / 0;
        } finally {}
      } else {
        null.onError(RequestError.NO_DEV_KEY, AFb1aSDK.values);
      } 
    } 
    int i = onResponse + 79;
    onAttributionFailure = i % 128;
    if (i % 2 != 0)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  private static void AFInAppEventParameterName(String paramString, boolean paramBoolean) {
    int i = onResponse + 101;
    onAttributionFailure = i % 128;
    AppsFlyerProperties.getInstance().set(paramString, paramBoolean);
    i = onResponse + 41;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 90;
    } else {
      i = 56;
    } 
    if (i == 56)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private void AFInAppEventParameterName(Map<String, Object> paramMap) {
    int i = onAttributionFailure + 119;
    onResponse = i % 128;
    boolean bool = false;
    if (((i % 2 != 0) ? !AppsFlyerProperties.getInstance().getBoolean("collectAndroidIdForceByUser", false) : !AppsFlyerProperties.getInstance().getBoolean("collectAndroidIdForceByUser", false)) || AppsFlyerProperties.getInstance().getBoolean("collectIMEIForceByUser", false)) {
      i = 1;
    } else {
      i = onAttributionFailure + 21;
      onResponse = i % 128;
      i = 0;
    } 
    if (i == 0) {
      i = onAttributionFailure + 3;
      onResponse = i % 128;
      if (paramMap.get("advertiserId") != null) {
        i = onResponse + 25;
        onAttributionFailure = i % 128;
        try {
          if (AFb1pSDK.valueOf(this.afInfoLog)) {
            i = 67;
          } else {
            i = 83;
          } 
          if (i != 83) {
            Object object = paramMap.remove("android_id");
            if (object != null) {
              i = onAttributionFailure + 11;
              onResponse = i % 128;
              if (i % 2 != 0) {
                i = bool;
              } else {
                i = 1;
              } 
              if (i == 1) {
                AFLogger.afInfoLog("validateGaidAndIMEI :: removing: android_id");
                i = onAttributionFailure + 9;
                onResponse = i % 128;
              } else {
                AFLogger.afInfoLog("validateGaidAndIMEI :: removing: android_id");
                try {
                  throw new NullPointerException();
                } finally {}
              } 
            } 
          } 
          if (AFb1pSDK.valueOf((AFKeystoreWrapper().afWarnLog()).valueOf) && paramMap.remove("imei") != null)
            AFLogger.afInfoLog("validateGaidAndIMEI :: removing: imei"); 
          return;
        } catch (Exception exception) {
          AFLogger.afErrorLog("failed to remove IMEI or AndroidID key from params; ", exception);
        } 
      } 
    } 
  }
  
  private static void AFInAppEventParameterName(ScheduledExecutorService paramScheduledExecutorService, Runnable paramRunnable, long paramLong, TimeUnit paramTimeUnit) {
    int i = onResponse + 91;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 67;
    } else {
      i = 72;
    } 
    if (i != 67)
      try {
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        return;
      } finally {
        paramScheduledExecutorService = null;
        AFLogger.afErrorLog("scheduleJob failed with Exception", (Throwable)paramScheduledExecutorService);
      }  
    paramScheduledExecutorService.schedule(paramRunnable, paramLong, paramTimeUnit);
    throw new NullPointerException();
  }
  
  private static boolean AFInAppEventParameterName(SharedPreferences paramSharedPreferences) {
    int i = onResponse + 65;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 44;
    } else {
      i = 26;
    } 
    null = paramSharedPreferences.getString("sentSuccessfully", null);
    if (i == 26)
      return Boolean.parseBoolean(null); 
    Boolean.parseBoolean(null);
    try {
      throw null;
    } finally {}
  }
  
  private boolean AFInAppEventParameterName(AFa1sSDK paramAFa1sSDK, SharedPreferences paramSharedPreferences) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: iconst_0
    //   3: invokevirtual AFKeystoreWrapper : (Landroid/content/SharedPreferences;Z)I
    //   6: istore #4
    //   8: iload #4
    //   10: iconst_1
    //   11: if_icmpne -> 85
    //   14: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   17: istore #5
    //   19: iload #5
    //   21: bipush #13
    //   23: iadd
    //   24: istore_3
    //   25: iload_3
    //   26: sipush #128
    //   29: irem
    //   30: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   33: aload_1
    //   34: instanceof com/appsflyer/internal/AFe1cSDK
    //   37: ifne -> 45
    //   40: iconst_0
    //   41: istore_3
    //   42: goto -> 47
    //   45: iconst_1
    //   46: istore_3
    //   47: iload_3
    //   48: iconst_1
    //   49: if_icmpeq -> 85
    //   52: iload #5
    //   54: iconst_1
    //   55: iadd
    //   56: istore_3
    //   57: iload_3
    //   58: sipush #128
    //   61: irem
    //   62: istore_3
    //   63: iload_3
    //   64: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   67: iload_3
    //   68: bipush #29
    //   70: iadd
    //   71: istore_3
    //   72: iload_3
    //   73: sipush #128
    //   76: irem
    //   77: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   80: iconst_1
    //   81: istore_3
    //   82: goto -> 87
    //   85: iconst_0
    //   86: istore_3
    //   87: aload_2
    //   88: ldc_w 'newGPReferrerSent'
    //   91: iconst_0
    //   92: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   97: ifne -> 129
    //   100: iload #4
    //   102: iconst_1
    //   103: if_icmpne -> 112
    //   106: iconst_0
    //   107: istore #4
    //   109: goto -> 115
    //   112: iconst_1
    //   113: istore #4
    //   115: iload #4
    //   117: ifeq -> 123
    //   120: goto -> 129
    //   123: iconst_1
    //   124: istore #4
    //   126: goto -> 132
    //   129: iconst_0
    //   130: istore #4
    //   132: iload #4
    //   134: ifne -> 145
    //   137: iload_3
    //   138: ifeq -> 143
    //   141: iconst_1
    //   142: ireturn
    //   143: iconst_0
    //   144: ireturn
    //   145: iconst_1
    //   146: ireturn
  }
  
  private int AFInAppEventType(SharedPreferences paramSharedPreferences, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #123
    //   5: iadd
    //   6: istore #4
    //   8: iload #4
    //   10: sipush #128
    //   13: irem
    //   14: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   17: iload #4
    //   19: iconst_2
    //   20: irem
    //   21: ifne -> 31
    //   24: bipush #17
    //   26: istore #4
    //   28: goto -> 35
    //   31: bipush #13
    //   33: istore #4
    //   35: iload #4
    //   37: bipush #13
    //   39: if_icmpeq -> 79
    //   42: aload_1
    //   43: aload_2
    //   44: iconst_0
    //   45: invokeinterface getInt : (Ljava/lang/String;I)I
    //   50: istore #5
    //   52: iload_3
    //   53: ifeq -> 63
    //   56: bipush #23
    //   58: istore #6
    //   60: goto -> 66
    //   63: iconst_3
    //   64: istore #6
    //   66: iload #5
    //   68: istore #4
    //   70: iload #6
    //   72: iconst_3
    //   73: if_icmpeq -> 138
    //   76: goto -> 97
    //   79: aload_1
    //   80: aload_2
    //   81: iconst_0
    //   82: invokeinterface getInt : (Ljava/lang/String;I)I
    //   87: istore #5
    //   89: iload #5
    //   91: istore #4
    //   93: iload_3
    //   94: ifeq -> 138
    //   97: iload #5
    //   99: iconst_1
    //   100: iadd
    //   101: istore #4
    //   103: aload_1
    //   104: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   109: aload_2
    //   110: iload #4
    //   112: invokeinterface putInt : (Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    //   117: invokeinterface apply : ()V
    //   122: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   125: iconst_3
    //   126: iadd
    //   127: istore #5
    //   129: iload #5
    //   131: sipush #128
    //   134: irem
    //   135: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   138: aload_0
    //   139: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   142: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   147: invokeinterface afInfoLog : ()Z
    //   152: ifeq -> 162
    //   155: bipush #49
    //   157: istore #5
    //   159: goto -> 166
    //   162: bipush #34
    //   164: istore #5
    //   166: iload #5
    //   168: bipush #34
    //   170: if_icmpeq -> 226
    //   173: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   176: bipush #117
    //   178: iadd
    //   179: istore #5
    //   181: iload #5
    //   183: sipush #128
    //   186: irem
    //   187: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   190: aload_0
    //   191: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   194: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   199: iload #4
    //   201: invokestatic valueOf : (I)Ljava/lang/String;
    //   204: invokeinterface AFInAppEventParameterName : (Ljava/lang/String;)V
    //   209: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   212: bipush #119
    //   214: iadd
    //   215: istore #5
    //   217: iload #5
    //   219: sipush #128
    //   222: irem
    //   223: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   226: iload #4
    //   228: ireturn
  }
  
  public static AFb1xSDK AFInAppEventType() {
    int i = onResponse;
    int j = i + 89;
    onAttributionFailure = j % 128;
    AFb1xSDK aFb1xSDK = afDebugLog;
    i += 81;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0)
      try {
        i = 35 / 0;
        return aFb1xSDK;
      } finally {} 
    return aFb1xSDK;
  }
  
  private static String AFInAppEventType(File paramFile, String paramString) {
    // Byte code:
    //   0: new java/util/Properties
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: new java/io/FileReader
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Ljava/io/File;)V
    //   17: astore_3
    //   18: aload #4
    //   20: aload_3
    //   21: invokevirtual load : (Ljava/io/Reader;)V
    //   24: ldc_w 'Found PreInstall property!'
    //   27: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   30: aload #4
    //   32: aload_1
    //   33: invokevirtual getProperty : (Ljava/lang/String;)Ljava/lang/String;
    //   36: astore_1
    //   37: aload_3
    //   38: invokevirtual close : ()V
    //   41: goto -> 53
    //   44: astore_0
    //   45: aload_0
    //   46: invokevirtual getMessage : ()Ljava/lang/String;
    //   49: aload_0
    //   50: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   53: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   56: bipush #29
    //   58: iadd
    //   59: istore_2
    //   60: iload_2
    //   61: sipush #128
    //   64: irem
    //   65: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   68: iload_2
    //   69: iconst_2
    //   70: irem
    //   71: ifne -> 80
    //   74: bipush #20
    //   76: istore_2
    //   77: goto -> 83
    //   80: bipush #62
    //   82: istore_2
    //   83: iload_2
    //   84: bipush #20
    //   86: if_icmpeq -> 91
    //   89: aload_1
    //   90: areturn
    //   91: bipush #29
    //   93: iconst_0
    //   94: idiv
    //   95: istore_2
    //   96: aload_1
    //   97: areturn
    //   98: astore_0
    //   99: aload_0
    //   100: athrow
    //   101: astore_1
    //   102: aload_3
    //   103: astore_0
    //   104: goto -> 110
    //   107: astore_1
    //   108: aconst_null
    //   109: astore_0
    //   110: aload_0
    //   111: astore_3
    //   112: aload_1
    //   113: invokevirtual getMessage : ()Ljava/lang/String;
    //   116: aload_1
    //   117: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   120: aload_0
    //   121: ifnull -> 189
    //   124: aload_0
    //   125: invokevirtual close : ()V
    //   128: goto -> 189
    //   131: astore_0
    //   132: aload_0
    //   133: invokevirtual getMessage : ()Ljava/lang/String;
    //   136: aload_0
    //   137: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   140: goto -> 189
    //   143: aconst_null
    //   144: astore_1
    //   145: aload_1
    //   146: astore_3
    //   147: new java/lang/StringBuilder
    //   150: dup
    //   151: ldc_w 'PreInstall file wasn't found: '
    //   154: invokespecial <init> : (Ljava/lang/String;)V
    //   157: astore #4
    //   159: aload_1
    //   160: astore_3
    //   161: aload #4
    //   163: aload_0
    //   164: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: aload_1
    //   172: astore_3
    //   173: aload #4
    //   175: invokevirtual toString : ()Ljava/lang/String;
    //   178: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   181: aload_1
    //   182: ifnull -> 189
    //   185: aload_1
    //   186: invokevirtual close : ()V
    //   189: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   192: bipush #11
    //   194: iadd
    //   195: istore_2
    //   196: iload_2
    //   197: sipush #128
    //   200: irem
    //   201: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   204: iload_2
    //   205: iconst_2
    //   206: irem
    //   207: ifeq -> 216
    //   210: bipush #49
    //   212: istore_2
    //   213: goto -> 219
    //   216: bipush #71
    //   218: istore_2
    //   219: iload_2
    //   220: bipush #71
    //   222: if_icmpne -> 227
    //   225: aconst_null
    //   226: areturn
    //   227: new java/lang/NullPointerException
    //   230: dup
    //   231: invokespecial <init> : ()V
    //   234: athrow
    //   235: astore_0
    //   236: aload_0
    //   237: athrow
    //   238: astore_0
    //   239: aload_3
    //   240: ifnull -> 259
    //   243: aload_3
    //   244: invokevirtual close : ()V
    //   247: goto -> 259
    //   250: astore_1
    //   251: aload_1
    //   252: invokevirtual getMessage : ()Ljava/lang/String;
    //   255: aload_1
    //   256: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   259: aload_0
    //   260: athrow
    //   261: astore_1
    //   262: goto -> 143
    //   265: astore_1
    //   266: aload_3
    //   267: astore_1
    //   268: goto -> 145
    // Exception table:
    //   from	to	target	type
    //   0	18	261	java/io/FileNotFoundException
    //   0	18	107	finally
    //   18	37	265	java/io/FileNotFoundException
    //   18	37	101	finally
    //   37	41	44	finally
    //   91	96	98	finally
    //   112	120	238	finally
    //   124	128	131	finally
    //   147	159	238	finally
    //   161	171	238	finally
    //   173	181	238	finally
    //   185	189	131	finally
    //   227	235	235	finally
    //   243	247	250	finally
  }
  
  private static String AFInAppEventType(String paramString) {
    int i = onAttributionFailure + 99;
    onResponse = i % 128;
    paramString = AppsFlyerProperties.getInstance().getString(paramString);
    i = onResponse + 85;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 56;
    } else {
      i = 37;
    } 
    if (i != 56)
      return paramString; 
    try {
      i = 66 / 0;
      return paramString;
    } finally {}
  }
  
  private void AFInAppEventType(Context paramContext, Map<String, Object> paramMap) {
    int i = onResponse + 47;
    onAttributionFailure = i % 128;
    AFc1zSDK.AFa1vSDK aFa1vSDK = AFKeystoreWrapper().AppsFlyer2dXConversionCallback().AFInAppEventType(paramContext);
    paramMap.put("btl", Float.toString(aFa1vSDK.valueOf));
    if (aFa1vSDK.values != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      i = onResponse + 115;
      onAttributionFailure = i % 128;
      if (i % 2 == 0) {
        paramMap.put("btch", aFa1vSDK.values);
        try {
          i = 56 / 0;
        } finally {}
      } else {
        paramMap.put("btch", aFa1vSDK.values);
      } 
    } 
    i = onResponse + 101;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1)
      try {
        i = 64 / 0;
        return;
      } finally {} 
  }
  
  private static void AFInAppEventType(Map<String, Object> paramMap) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #57
    //   5: iadd
    //   6: istore_1
    //   7: iload_1
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   15: iconst_1
    //   16: istore_2
    //   17: iload_1
    //   18: iconst_2
    //   19: irem
    //   20: ifne -> 67
    //   23: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   26: ldc_w 'oneLinkSlug'
    //   29: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   32: astore #5
    //   34: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   37: ldc_w 'onelinkVersion'
    //   40: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   43: astore #4
    //   45: bipush #49
    //   47: iconst_0
    //   48: idiv
    //   49: istore_1
    //   50: aload #4
    //   52: astore_3
    //   53: aload #5
    //   55: ifnull -> 171
    //   58: aload #4
    //   60: astore_3
    //   61: goto -> 100
    //   64: astore_0
    //   65: aload_0
    //   66: athrow
    //   67: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   70: ldc_w 'oneLinkSlug'
    //   73: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   76: astore #5
    //   78: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   81: ldc_w 'onelinkVersion'
    //   84: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   87: astore #4
    //   89: aload #4
    //   91: astore_3
    //   92: aload #5
    //   94: ifnull -> 171
    //   97: aload #4
    //   99: astore_3
    //   100: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   103: bipush #69
    //   105: iadd
    //   106: istore_1
    //   107: iload_1
    //   108: sipush #128
    //   111: irem
    //   112: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   115: iload_1
    //   116: iconst_2
    //   117: irem
    //   118: ifne -> 126
    //   121: iconst_1
    //   122: istore_1
    //   123: goto -> 128
    //   126: iconst_0
    //   127: istore_1
    //   128: iload_1
    //   129: iconst_1
    //   130: if_icmpeq -> 148
    //   133: aload_0
    //   134: ldc_w 'onelink_id'
    //   137: aload #5
    //   139: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   144: pop
    //   145: goto -> 171
    //   148: aload_0
    //   149: ldc_w 'onelink_id'
    //   152: aload #5
    //   154: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   159: pop
    //   160: bipush #71
    //   162: iconst_0
    //   163: idiv
    //   164: istore_1
    //   165: goto -> 171
    //   168: astore_0
    //   169: aload_0
    //   170: athrow
    //   171: aload_3
    //   172: ifnull -> 180
    //   175: iload_2
    //   176: istore_1
    //   177: goto -> 182
    //   180: iconst_0
    //   181: istore_1
    //   182: iload_1
    //   183: ifeq -> 211
    //   186: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   189: iconst_5
    //   190: iadd
    //   191: istore_1
    //   192: iload_1
    //   193: sipush #128
    //   196: irem
    //   197: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   200: aload_0
    //   201: ldc_w 'onelink_ver'
    //   204: aload_3
    //   205: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   210: pop
    //   211: return
    // Exception table:
    //   from	to	target	type
    //   45	50	64	finally
    //   160	165	168	finally
  }
  
  private static void AFInAppEventType(Map<String, Object> paramMap, AFe1fSDK paramAFe1fSDK) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(paramAFe1fSDK.AFInAppEventType);
    paramAFe1fSDK.AFInAppEventType.clear();
    paramAFe1fSDK.AFInAppEventParameterName.valueOf("gcd");
    if (!hashMap.isEmpty()) {
      i = 37;
    } else {
      i = 83;
    } 
    if (i != 37)
      return; 
    int i = onAttributionFailure + 49;
    onResponse = i % 128;
    valueOf(paramMap).put("gcd", hashMap);
    i = onResponse + 47;
    onAttributionFailure = i % 128;
  }
  
  private static boolean AFInAppEventType(File paramFile) {
    int i = onAttributionFailure + 69;
    onResponse = i % 128;
    if (i % 2 == 0) {
      if (paramFile != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 1)
        return true; 
      if (!paramFile.exists()) {
        i = 0;
      } else {
        i = 1;
      } 
      if (i != 1)
        return true; 
      i = onAttributionFailure + 93;
      onResponse = i % 128;
      return false;
    } 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private int AFKeystoreWrapper(SharedPreferences paramSharedPreferences) {
    int i = onResponse + 61;
    onAttributionFailure = i % 128;
    int j = AFInAppEventType(paramSharedPreferences, "appsFlyerAdRevenueCount", true);
    i = onResponse + 103;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return j; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static String AFKeystoreWrapper(String paramString) {
    if (paramString == null)
      return null; 
    if (paramString.matches("fb\\d*?://authorize.*")) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return paramString; 
    int i = onAttributionFailure + 99;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 12;
    } else {
      i = 17;
    } 
    if (i != 12) {
      if (paramString.contains("access_token")) {
        String str = valueOf(paramString);
        if (str.length() == 0) {
          i = onResponse + 23;
          onAttributionFailure = i % 128;
          if (i % 2 != 0)
            return paramString; 
          try {
            throw new NullPointerException();
          } finally {}
        } 
        ArrayList<String> arrayList = new ArrayList();
        if (str.contains("&")) {
          arrayList = new ArrayList(Arrays.asList((Object[])str.split("&")));
          i = onResponse + 45;
          onAttributionFailure = i % 128;
        } else {
          arrayList.add(str);
        } 
        StringBuilder stringBuilder = new StringBuilder();
        Iterator<String> iterator = arrayList.iterator();
        while (true) {
          if (iterator.hasNext()) {
            i = 10;
          } else {
            i = 58;
          } 
          if (i != 10)
            return paramString.replace(str, stringBuilder.toString()); 
          String str1 = iterator.next();
          if (str1.contains("access_token")) {
            iterator.remove();
            continue;
          } 
          if (stringBuilder.length() != 0) {
            i = 53;
          } else {
            i = 44;
          } 
          if (i != 44) {
            stringBuilder.append("&");
          } else if (!str1.startsWith("?")) {
            stringBuilder.append("?");
          } 
          stringBuilder.append(str1);
        } 
      } 
      return paramString;
    } 
    paramString.contains("access_token");
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public static String AFKeystoreWrapper(SimpleDateFormat paramSimpleDateFormat, long paramLong) {
    paramSimpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    String str = paramSimpleDateFormat.format(new Date(paramLong));
    int i = onResponse + 27;
    onAttributionFailure = i % 128;
    return str;
  }
  
  private String AFKeystoreWrapper(SimpleDateFormat paramSimpleDateFormat, Context paramContext) {
    int i = onResponse + 27;
    onAttributionFailure = i % 128;
    String str = valueOf(paramContext).getString("appsFlyerFirstInstall", null);
    if (str == null) {
      i = 40;
    } else {
      i = 89;
    } 
    if (i != 89) {
      String str1;
      if (afRDLog(paramContext)) {
        AFLogger.afDebugLog("AppsFlyer: first launch detected");
        str1 = paramSimpleDateFormat.format(new Date());
      } else {
        i = onAttributionFailure + 51;
        onResponse = i % 128;
        str1 = "";
      } 
      values(paramContext).AFKeystoreWrapper("appsFlyerFirstInstall", str1);
      str = str1;
    } 
    AFLogger.afInfoLog("AppsFlyer: first launch date: ".concat(String.valueOf(str)));
    return str;
  }
  
  private static void AFKeystoreWrapper(int paramInt1, String paramString, int paramInt2, int paramInt3, boolean paramBoolean, Object[] paramArrayOfObject) {
    char[] arrayOfChar;
    String str = paramString;
    if (paramString != null)
      arrayOfChar = paramString.toCharArray(); 
    null = arrayOfChar;
    synchronized (AFg1mSDK.valueOf) {
      arrayOfChar = new char[paramInt3];
      AFg1mSDK.AFInAppEventParameterName = 0;
      while (AFg1mSDK.AFInAppEventParameterName < paramInt3) {
        AFg1mSDK.AFInAppEventType = null[AFg1mSDK.AFInAppEventParameterName];
        arrayOfChar[AFg1mSDK.AFInAppEventParameterName] = (char)(AFg1mSDK.AFInAppEventType + paramInt2);
        int i = AFg1mSDK.AFInAppEventParameterName;
        arrayOfChar[i] = (char)(arrayOfChar[i] - onAppOpenAttribution);
        AFg1mSDK.AFInAppEventParameterName++;
      } 
      if (paramInt1 > 0) {
        AFg1mSDK.AFKeystoreWrapper = paramInt1;
        null = new char[paramInt3];
        System.arraycopy(arrayOfChar, 0, null, 0, paramInt3);
        System.arraycopy(null, 0, arrayOfChar, paramInt3 - AFg1mSDK.AFKeystoreWrapper, AFg1mSDK.AFKeystoreWrapper);
        System.arraycopy(null, AFg1mSDK.AFKeystoreWrapper, arrayOfChar, 0, paramInt3 - AFg1mSDK.AFKeystoreWrapper);
      } 
      null = arrayOfChar;
      if (paramBoolean) {
        null = new char[paramInt3];
        AFg1mSDK.AFInAppEventParameterName = 0;
        while (AFg1mSDK.AFInAppEventParameterName < paramInt3) {
          null[AFg1mSDK.AFInAppEventParameterName] = arrayOfChar[paramInt3 - AFg1mSDK.AFInAppEventParameterName - 1];
          AFg1mSDK.AFInAppEventParameterName++;
        } 
      } 
      String str1 = new String(null);
      paramArrayOfObject[0] = str1;
      return;
    } 
  }
  
  private void AFKeystoreWrapper(Context paramContext, String paramString, Map<String, Object> paramMap) {
    Activity activity;
    AFf1wSDK aFf1wSDK = new AFf1wSDK();
    if (paramContext != null) {
      i = 11;
    } else {
      i = 64;
    } 
    if (i != 64) {
      i = onResponse + 79;
      onAttributionFailure = i % 128;
      aFf1wSDK.AFKeystoreWrapper = (Application)paramContext.getApplicationContext();
    } 
    aFf1wSDK.afErrorLog = paramString;
    aFf1wSDK.values = paramMap;
    if (paramContext instanceof Activity) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1) {
      paramContext = null;
    } else {
      activity = (Activity)paramContext;
    } 
    AFInAppEventType(aFf1wSDK, activity);
    int i = onResponse + 109;
    onAttributionFailure = i % 128;
  }
  
  private static void AFKeystoreWrapper(Context paramContext, Map<String, Object> paramMap, String paramString) {
    int i = onResponse + 49;
    onAttributionFailure = i % 128;
    SharedPreferences sharedPreferences = valueOf(paramContext);
    SharedPreferences.Editor editor = sharedPreferences.edit();
    try {
      String str = sharedPreferences.getString("prev_event_name", null);
      if (str != null) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("prev_event_timestamp", sharedPreferences.getLong("prev_event_timestamp", -1L));
        jSONObject.put("prev_event_name", str);
        paramMap.put("prev_event", jSONObject);
        i = onAttributionFailure + 105;
        onResponse = i % 128;
      } 
      editor.putString("prev_event_name", paramString).putLong("prev_event_timestamp", System.currentTimeMillis()).apply();
      return;
    } catch (Exception exception) {
      AFLogger.afErrorLog("Error while processing previous event.", exception);
      return;
    } 
  }
  
  public static boolean AFKeystoreWrapper(Context paramContext) {
    int i = onAttributionFailure + 41;
    onResponse = i % 128;
    if (i % 2 == 0) {
      try {
        if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(paramContext) == 0) {
          i = 2;
        } else {
          i = 56;
        } 
      } finally {
        Exception exception = null;
      } 
    } else {
      GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(paramContext);
      throw new NullPointerException();
    } 
    try {
      paramContext.getPackageManager().getPackageInfo("com.google.android.gms", 0);
      i = onResponse + 97;
      onAttributionFailure = i % 128;
      if (i % 2 == 0) {
        i = 0;
      } else {
        i = 1;
      } 
      if (i != 0)
        return true; 
      try {
        i = 2 / 0;
        return true;
      } finally {}
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      AFLogger.afErrorLog("WARNING:  Google Play Services is unavailable. ", (Throwable)nameNotFoundException);
      return false;
    } 
  }
  
  private static boolean AFKeystoreWrapper(String paramString, boolean paramBoolean) {
    int i = onAttributionFailure + 31;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return AppsFlyerProperties.getInstance().getBoolean(paramString, paramBoolean); 
    AppsFlyerProperties.getInstance().getBoolean(paramString, paramBoolean);
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static String AFLogger() {
    int i = onResponse + 25;
    onAttributionFailure = i % 128;
    String str = AFInAppEventType("appid");
    i = onResponse + 113;
    onAttributionFailure = i % 128;
    return str;
  }
  
  private void AFLogger(Context paramContext) {
    this.onAttributionFailureNative = new HashMap<String, Object>();
    AFa1rSDK.AFa1vSDK aFa1vSDK = new AFa1rSDK.AFa1vSDK(this, System.currentTimeMillis()) {
        public final void AFInAppEventType(String param1String) {
          AFb1xSDK.values(this.valueOf).put("error", param1String);
        }
        
        public final void values(String param1String1, String param1String2, String param1String3) {
          if (param1String1 != null) {
            AFLogger.afInfoLog("Facebook Deferred AppLink data received: ".concat(String.valueOf(param1String1)));
            AFb1xSDK.values(this.valueOf).put("link", param1String1);
            if (param1String2 != null)
              AFb1xSDK.values(this.valueOf).put("target_url", param1String2); 
            if (param1String3 != null) {
              HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
              HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
              hashMap2.put("promo_code", param1String3);
              hashMap1.put("deeplink_context", hashMap2);
              AFb1xSDK.values(this.valueOf).put("extras", hashMap1);
            } 
          } else {
            AFb1xSDK.values(this.valueOf).put("link", "");
          } 
          long l1 = System.currentTimeMillis();
          long l2 = this.AFInAppEventParameterName;
          AFb1xSDK.values(this.valueOf).put("ttr", String.valueOf(l1 - l2));
        }
      };
    try {
      Class.forName("com.facebook.FacebookSdk").getMethod("sdkInitialize", new Class[] { Context.class }).invoke(null, new Object[] { paramContext });
      Class<?> clazz2 = Class.forName("com.facebook.applinks.AppLinkData");
      Class<?> clazz1 = Class.forName("com.facebook.applinks.AppLinkData$CompletionHandler");
      Method method = clazz2.getMethod("fetchDeferredAppLinkData", new Class[] { Context.class, String.class, clazz1 });
      Object object2 = new Object(clazz2, aFa1vSDK);
      Object object1 = Proxy.newProxyInstance(clazz1.getClassLoader(), new Class[] { clazz1 }, (InvocationHandler)object2);
      object2 = paramContext.getString(paramContext.getResources().getIdentifier("facebook_app_id", "string", paramContext.getPackageName()));
      if (TextUtils.isEmpty((CharSequence)object2)) {
        i = 86;
      } else {
        i = 22;
      } 
      if (i != 86) {
        method.invoke(null, new Object[] { paramContext, object2, object1 });
        i = onResponse + 79;
        onAttributionFailure = i % 128;
        return;
      } 
      int i = onAttributionFailure + 105;
      onResponse = i % 128;
      aFa1vSDK.AFInAppEventType("Facebook app id not defined in resources");
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      AFLogger.afErrorLogForExcManagerOnly("FB method missing error", noSuchMethodException);
      aFa1vSDK.AFInAppEventType(noSuchMethodException.toString());
      return;
    } catch (InvocationTargetException invocationTargetException) {
      AFLogger.afErrorLogForExcManagerOnly("FB invocation error", invocationTargetException);
      aFa1vSDK.AFInAppEventType(invocationTargetException.toString());
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      AFLogger.afErrorLogForExcManagerOnly("FB class missing error", classNotFoundException);
      aFa1vSDK.AFInAppEventType(classNotFoundException.toString());
      return;
    } catch (IllegalAccessException illegalAccessException) {
      AFLogger.afErrorLogForExcManagerOnly("FB illegal access", illegalAccessException);
      aFa1vSDK.AFInAppEventType(illegalAccessException.toString());
      return;
    } 
  }
  
  private String AFLogger$LogLevel(Context paramContext) {
    String str1;
    int i = onAttributionFailure + 43;
    onResponse = i % 128;
    SharedPreferences sharedPreferences = valueOf(paramContext);
    if (sharedPreferences.contains("INSTALL_STORE")) {
      i = 52;
    } else {
      i = 86;
    } 
    String str2 = null;
    if (i != 86) {
      str1 = sharedPreferences.getString("INSTALL_STORE", null);
      i = onResponse + 111;
      onAttributionFailure = i % 128;
      return str1;
    } 
    if (afRDLog((Context)str1)) {
      i = 76;
    } else {
      i = 95;
    } 
    if (i != 95)
      str2 = getLevel((Context)str1); 
    values((Context)str1).AFKeystoreWrapper("INSTALL_STORE", str2);
    return str2;
  }
  
  private String AFVersionDeclaration(Context paramContext) {
    int i;
    SharedPreferences sharedPreferences = valueOf(paramContext);
    String str = AFInAppEventType("preInstallName");
    if (str != null) {
      i = 28;
    } else {
      i = 9;
    } 
    if (i != 9)
      return str; 
    if (sharedPreferences.contains("preInstallName")) {
      i = 21;
    } else {
      i = 63;
    } 
    if (i != 63) {
      str = sharedPreferences.getString("preInstallName", null);
    } else {
      if (afRDLog(paramContext)) {
        i = 68;
      } else {
        i = 18;
      } 
      if (i == 68) {
        i = onAttributionFailure + 107;
        onResponse = i % 128;
        str = afWarnLog(paramContext);
        if (str != null) {
          i = 0;
        } else {
          i = 1;
        } 
        if (i != 0) {
          str = values(paramContext, "AF_PRE_INSTALL_NAME");
        } else {
          i = onResponse + 19;
          onAttributionFailure = i % 128;
          if (i % 2 == 0) {
            i = 61;
          } else {
            i = 50;
          } 
          if (i == 61)
            try {
              throw new NullPointerException();
            } finally {} 
        } 
      } 
      if (str != null)
        values(paramContext).AFKeystoreWrapper("preInstallName", str); 
    } 
    if (str != null)
      valueOf("preInstallName", str); 
    return str;
  }
  
  private AFf1jSDK[] AFVersionDeclaration() {
    int i = onResponse + 87;
    onAttributionFailure = i % 128;
    null = AFKeystoreWrapper().getLevel().AFInAppEventParameterName();
    i = onAttributionFailure + 7;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 20;
    } else {
      i = 52;
    } 
    if (i != 20)
      return null; 
    try {
      i = 28 / 0;
      return null;
    } finally {}
  }
  
  private static File afDebugLog(String paramString) {
    int i = onAttributionFailure + 93;
    int j = i % 128;
    onResponse = j;
    if (paramString != null) {
      i = 57;
    } else {
      i = 16;
    } 
    if (i == 57) {
      i = j + 107;
      onAttributionFailure = i % 128;
    } 
    return null;
  }
  
  private void afDebugLog() {
    int i = onAttributionFailure + 95;
    onResponse = i % 128;
    if (AFd1hSDK.AFLogger())
      return; 
    AFc1vSDK aFc1vSDK = AFKeystoreWrapper();
    null = aFc1vSDK.afDebugLog();
    AFd1hSDK aFd1hSDK = new AFd1hSDK(aFc1vSDK);
    null.AFKeystoreWrapper.execute((Runnable)new Object(null, (AFd1qSDK)aFd1hSDK));
    i = onResponse + 31;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 28;
    } else {
      i = 62;
    } 
    if (i == 62)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static boolean afDebugLog(Context paramContext) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #85
    //   5: iadd
    //   6: istore_1
    //   7: iload_1
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   15: iload_1
    //   16: iconst_2
    //   17: irem
    //   18: ifne -> 37
    //   21: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   24: ldc_w 'collectAndroidIdForceByUser'
    //   27: iconst_1
    //   28: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   31: ifne -> 71
    //   34: goto -> 50
    //   37: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   40: ldc_w 'collectAndroidIdForceByUser'
    //   43: iconst_0
    //   44: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   47: ifne -> 71
    //   50: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   53: ldc_w 'collectIMEIForceByUser'
    //   56: iconst_0
    //   57: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   60: ifeq -> 66
    //   63: goto -> 71
    //   66: iconst_0
    //   67: istore_1
    //   68: goto -> 88
    //   71: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   74: bipush #45
    //   76: iadd
    //   77: istore_1
    //   78: iload_1
    //   79: sipush #128
    //   82: irem
    //   83: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   86: iconst_1
    //   87: istore_1
    //   88: iload_1
    //   89: ifne -> 201
    //   92: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   95: iconst_1
    //   96: iadd
    //   97: istore_1
    //   98: iload_1
    //   99: sipush #128
    //   102: irem
    //   103: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   106: iload_1
    //   107: iconst_2
    //   108: irem
    //   109: ifeq -> 118
    //   112: bipush #32
    //   114: istore_1
    //   115: goto -> 121
    //   118: bipush #26
    //   120: istore_1
    //   121: iload_1
    //   122: bipush #32
    //   124: if_icmpeq -> 136
    //   127: aload_0
    //   128: invokestatic AFKeystoreWrapper : (Landroid/content/Context;)Z
    //   131: ifne -> 164
    //   134: iconst_1
    //   135: ireturn
    //   136: aload_0
    //   137: invokestatic AFKeystoreWrapper : (Landroid/content/Context;)Z
    //   140: istore_2
    //   141: bipush #13
    //   143: iconst_0
    //   144: idiv
    //   145: istore_1
    //   146: iload_2
    //   147: ifne -> 155
    //   150: iconst_0
    //   151: istore_1
    //   152: goto -> 157
    //   155: iconst_1
    //   156: istore_1
    //   157: iload_1
    //   158: iconst_1
    //   159: if_icmpeq -> 164
    //   162: iconst_1
    //   163: ireturn
    //   164: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   167: bipush #21
    //   169: iadd
    //   170: istore_1
    //   171: iload_1
    //   172: sipush #128
    //   175: irem
    //   176: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   179: iload_1
    //   180: iconst_2
    //   181: irem
    //   182: ifeq -> 187
    //   185: iconst_0
    //   186: ireturn
    //   187: new java/lang/NullPointerException
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: athrow
    //   195: astore_0
    //   196: aload_0
    //   197: athrow
    //   198: astore_0
    //   199: aload_0
    //   200: athrow
    //   201: iconst_1
    //   202: ireturn
    // Exception table:
    //   from	to	target	type
    //   141	146	198	finally
    //   187	195	195	finally
  }
  
  private static void afErrorLog(Context paramContext) {
    byte b;
    if (AFa1cSDK.AFKeystoreWrapper()) {
      AFLogger.afRDLog("OPPO device found");
      b = 23;
    } else {
      b = 18;
    } 
    if (Build.VERSION.SDK_INT >= b && !AFKeystoreWrapper("keyPropDisableAFKeystore", true)) {
      StringBuilder stringBuilder = new StringBuilder("OS SDK is=");
      stringBuilder.append(Build.VERSION.SDK_INT);
      stringBuilder.append("; use KeyStore");
      AFLogger.afRDLog(stringBuilder.toString());
      AFKeystoreWrapper aFKeystoreWrapper = new AFKeystoreWrapper(paramContext);
      if (!aFKeystoreWrapper.AFKeystoreWrapper()) {
        aFKeystoreWrapper.values = AFb1wSDK.AFInAppEventParameterName(new WeakReference<Context>(paramContext));
        aFKeystoreWrapper.valueOf = 0;
        aFKeystoreWrapper.AFInAppEventType(aFKeystoreWrapper.AFInAppEventParameterName());
      } else {
        String str = aFKeystoreWrapper.AFInAppEventParameterName();
        synchronized (aFKeystoreWrapper.AFInAppEventType) {
          aFKeystoreWrapper.valueOf++;
          AFLogger.afInfoLog("Deleting key with alias: ".concat(String.valueOf(str)));
          try {
            synchronized (aFKeystoreWrapper.AFInAppEventType) {
              aFKeystoreWrapper.AFInAppEventParameterName.deleteEntry(str);
            } 
          } catch (KeyStoreException keyStoreException) {
            StringBuilder stringBuilder1 = new StringBuilder("Exception ");
            stringBuilder1.append(keyStoreException.getMessage());
            stringBuilder1.append(" occurred");
            AFLogger.afErrorLog(stringBuilder1.toString(), keyStoreException);
          } 
          aFKeystoreWrapper.AFInAppEventType(aFKeystoreWrapper.AFInAppEventParameterName());
          valueOf("KSAppsFlyerId", aFKeystoreWrapper.values());
          valueOf("KSAppsFlyerRICounter", String.valueOf(aFKeystoreWrapper.AFInAppEventType()));
          return;
        } 
      } 
    } else {
      StringBuilder stringBuilder = new StringBuilder("OS SDK is=");
      stringBuilder.append(Build.VERSION.SDK_INT);
      stringBuilder.append("; no KeyStore usage");
      AFLogger.afRDLog(stringBuilder.toString());
      return;
    } 
    valueOf("KSAppsFlyerId", SYNTHETIC_LOCAL_VARIABLE_2.values());
    valueOf("KSAppsFlyerRICounter", String.valueOf(SYNTHETIC_LOCAL_VARIABLE_2.AFInAppEventType()));
  }
  
  private boolean afErrorLog() {
    if (this.afRDLog > 0L) {
      byte b;
      long l = System.currentTimeMillis() - this.afRDLog;
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS Z", Locale.US);
      String str1 = AFKeystoreWrapper(simpleDateFormat, this.afRDLog);
      String str2 = AFKeystoreWrapper(simpleDateFormat, this.AFLogger$LogLevel);
      if (l < this.afWarnLog) {
        b = onResponse + 5;
        onAttributionFailure = b % 128;
        if (b % 2 != 0) {
          if (!super.isStopped()) {
            b = 26;
          } else {
            b = 34;
          } 
          if (b == 26) {
            b = onAttributionFailure + 51;
            onResponse = b % 128;
            AFLogger.afInfoLog(String.format(Locale.US, "Last Launch attempt: %s;\nLast successful Launch event: %s;\nThis launch is blocked: %s ms < %s ms", new Object[] { str1, str2, Long.valueOf(l), Long.valueOf(this.afWarnLog) }));
            return true;
          } 
        } else {
          super.isStopped();
          try {
            throw null;
          } finally {}
        } 
      } 
      if (!super.isStopped()) {
        b = 4;
      } else {
        b = 87;
      } 
      if (b != 4)
        return false; 
      AFLogger.afInfoLog(String.format(Locale.US, "Last Launch attempt: %s;\nLast successful Launch event: %s;\nSending launch (+%s ms)", new Object[] { str1, str2, Long.valueOf(l) }));
      return false;
    } 
    if (!super.isStopped())
      AFLogger.afInfoLog("Sending first launch for this session!"); 
    return false;
  }
  
  private long afErrorLogForExcManagerOnly(Context paramContext) {
    long l2;
    int i = onAttributionFailure + 91;
    onResponse = i % 128;
    boolean bool = false;
    if (i % 2 != 0) {
      l1 = valueOf(paramContext).getLong("AppsFlyerTimePassedSincePrevLaunch", 1L);
      l2 = System.currentTimeMillis();
      values(paramContext).AFInAppEventType("AppsFlyerTimePassedSincePrevLaunch", l2);
      if (l1 > 1L) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 1) {
        i = onResponse + 65;
        onAttributionFailure = i % 128;
        return -1L;
      } 
    } else {
      l1 = valueOf(paramContext).getLong("AppsFlyerTimePassedSincePrevLaunch", 0L);
      l2 = System.currentTimeMillis();
      values(paramContext).AFInAppEventType("AppsFlyerTimePassedSincePrevLaunch", l2);
      if (l1 <= 0L) {
        i = onResponse + 65;
        onAttributionFailure = i % 128;
        return -1L;
      } 
    } 
    long l1 = l2 - l1;
    i = onAttributionFailure + 99;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = bool;
    } else {
      i = 1;
    } 
    return (i != 1) ? (l1 + 1000L) : (l1 / 1000L);
  }
  
  private static void afInfoLog(Context paramContext) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: bipush #19
    //   5: iadd
    //   6: istore_1
    //   7: iload_1
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   15: iconst_0
    //   16: istore_2
    //   17: iload_1
    //   18: iconst_2
    //   19: irem
    //   20: ifeq -> 54
    //   23: aload_0
    //   24: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   27: aload_0
    //   28: invokevirtual getPackageName : ()Ljava/lang/String;
    //   31: iconst_0
    //   32: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   35: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   38: getfield flags : I
    //   41: ldc_w 32768
    //   44: ixor
    //   45: ifeq -> 200
    //   48: bipush #50
    //   50: istore_1
    //   51: goto -> 203
    //   54: aload_0
    //   55: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   58: aload_0
    //   59: invokevirtual getPackageName : ()Ljava/lang/String;
    //   62: iconst_0
    //   63: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   66: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   69: getfield flags : I
    //   72: ldc_w 32768
    //   75: iand
    //   76: ifeq -> 212
    //   79: iconst_1
    //   80: istore_1
    //   81: goto -> 214
    //   84: aload_0
    //   85: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   88: ldc_w 'appsflyer_backup_rules'
    //   91: ldc_w 'xml'
    //   94: aload_0
    //   95: invokevirtual getPackageName : ()Ljava/lang/String;
    //   98: invokevirtual getIdentifier : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   101: ifeq -> 221
    //   104: iload_2
    //   105: istore_1
    //   106: goto -> 109
    //   109: iload_1
    //   110: ifeq -> 137
    //   113: ldc_w ''allowBackup' is set to true; appsflyer_backup_rules.xml not detected.\\nAppsFlyer shared preferences should be excluded from auto backup by adding: <exclude domain="sharedpref" path="appsflyer-data"/> to the Application's <full-backup-content> rules'
    //   116: invokestatic valueOf : (Ljava/lang/String;)V
    //   119: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   122: bipush #113
    //   124: iadd
    //   125: istore_1
    //   126: iload_1
    //   127: sipush #128
    //   130: irem
    //   131: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   134: goto -> 145
    //   137: ldc_w 'appsflyer_backup_rules.xml detected, using AppsFlyer defined backup rules for AppsFlyer SDK data'
    //   140: iconst_1
    //   141: invokestatic afInfoLog : (Ljava/lang/String;Z)V
    //   144: return
    //   145: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   148: bipush #73
    //   150: iadd
    //   151: istore_1
    //   152: iload_1
    //   153: sipush #128
    //   156: irem
    //   157: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   160: iload_1
    //   161: iconst_2
    //   162: irem
    //   163: ifeq -> 167
    //   166: return
    //   167: new java/lang/NullPointerException
    //   170: dup
    //   171: invokespecial <init> : ()V
    //   174: athrow
    //   175: astore_0
    //   176: aload_0
    //   177: athrow
    //   178: astore_0
    //   179: ldc_w 'checkBackupRules Exception'
    //   182: aload_0
    //   183: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   186: ldc_w 'checkBackupRules Exception: '
    //   189: aload_0
    //   190: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   193: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   196: invokestatic afRDLog : (Ljava/lang/String;)V
    //   199: return
    //   200: bipush #47
    //   202: istore_1
    //   203: iload_1
    //   204: bipush #47
    //   206: if_icmpeq -> 145
    //   209: goto -> 84
    //   212: iconst_0
    //   213: istore_1
    //   214: iload_1
    //   215: ifeq -> 145
    //   218: goto -> 84
    //   221: iconst_1
    //   222: istore_1
    //   223: goto -> 109
    // Exception table:
    //   from	to	target	type
    //   23	48	178	java/lang/Exception
    //   54	79	178	java/lang/Exception
    //   84	104	178	java/lang/Exception
    //   113	119	178	java/lang/Exception
    //   137	144	178	java/lang/Exception
    //   167	175	175	finally
  }
  
  private boolean afInfoLog() {
    int i = onResponse + 25;
    onAttributionFailure = i % 128;
    boolean bool = AFKeystoreWrapper().AFInAppEventParameterName().AFInAppEventType("AF_PREINSTALL_DISABLED");
    i = onResponse + 77;
    onAttributionFailure = i % 128;
    return bool;
  }
  
  private boolean afRDLog() {
    int i = onResponse + 55;
    i %= 128;
    onAttributionFailure = i;
    Map<String, Object> map = this.onAttributionFailureNative;
    if (map != null) {
      i += 67;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 0;
      } else {
        i = 1;
      } 
      boolean bool = map.isEmpty();
      if (i != 0) {
        if (!bool) {
          i = 40;
        } else {
          i = 58;
        } 
        if (i != 40)
          return false; 
      } else {
        try {
          i = 74 / 0;
          if (!bool)
            return true; 
        } finally {}
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  private static boolean afRDLog(Context paramContext) {
    int i = onResponse + 89;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 47;
    } else {
      i = 20;
    } 
    if (i == 20) {
      if (!valueOf(paramContext).contains("appsFlyerCount")) {
        i = 0;
      } else {
        i = 1;
      } 
      if (i != 1) {
        i = onResponse + 71;
        onAttributionFailure = i % 128;
        return true;
      } 
      return false;
    } 
    valueOf(paramContext).contains("appsFlyerCount");
    try {
      throw null;
    } finally {}
  }
  
  private String afWarnLog(Context paramContext) {
    int i;
    File file2 = afDebugLog(AFInAppEventParameterName("ro.appsflyer.preinstall.path"));
    File file1 = file2;
    if (AFInAppEventType(file2))
      file1 = afDebugLog(values(paramContext, "AF_PRE_INSTALL_PATH")); 
    file2 = file1;
    if (AFInAppEventType(file1))
      file2 = afDebugLog("/data/local/tmp/pre_install.appsflyer"); 
    if (AFInAppEventType(file2)) {
      i = 55;
    } else {
      i = 31;
    } 
    if (i == 55) {
      i = onResponse + 49;
      onAttributionFailure = i % 128;
      file2 = afDebugLog("/etc/pre_install.appsflyer");
    } 
    if (AFInAppEventType(file2)) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onAttributionFailure + 103;
      onResponse = i % 128;
      return null;
    } 
    return AFInAppEventType(file2, paramContext.getPackageName());
  }
  
  private String getLevel(Context paramContext) {
    String str2 = AppsFlyerProperties.getInstance().getString("api_store_value");
    if (str2 != null) {
      int j = onAttributionFailure + 89;
      onResponse = j % 128;
      if (j % 2 != 0) {
        j = 75;
      } else {
        j = 57;
      } 
      if (j != 75)
        return str2; 
      try {
        j = 10 / 0;
        return str2;
      } finally {}
    } 
    String str1 = values(paramContext, "AF_STORE");
    int i = onAttributionFailure + 19;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 45;
    } else {
      i = 49;
    } 
    if (i != 49)
      try {
        i = 69 / 0;
        return str1;
      } finally {} 
    return str1;
  }
  
  private static boolean onInstallConversionFailureNative(Context paramContext) {
    int i;
    Iterator<NetworkInterface> iterator;
    if (paramContext != null) {
      i = 54;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onResponse + 69;
      onAttributionFailure = i % 128;
      if (Build.VERSION.SDK_INT >= 23) {
        i = onAttributionFailure + 59;
        onResponse = i % 128;
        if (i % 2 != 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 1) {
          try {
            ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
            Network[] arrayOfNetwork = connectivityManager.getAllNetworks();
            i = arrayOfNetwork.length;
          } catch (Exception null) {
            AFLogger.afErrorLog("Failed collecting ivc data", exception);
            return false;
          } 
        } else {
          ConnectivityManager connectivityManager = (ConnectivityManager)exception.getSystemService("connectivity");
          Network[] arrayOfNetwork = connectivityManager.getAllNetworks();
          i = arrayOfNetwork.length;
        } 
      } else {
        ArrayList<String> arrayList = new ArrayList();
        try {
          iterator = Collections.<NetworkInterface>list(NetworkInterface.getNetworkInterfaces()).iterator();
          while (true) {
            if (iterator.hasNext()) {
              i = 21;
            } else {
              i = 13;
            } 
            if (i != 21)
              return arrayList.contains("tun0"); 
            NetworkInterface networkInterface = iterator.next();
            if (networkInterface.isUp())
              arrayList.add(networkInterface.getName()); 
          } 
        } catch (Exception exception) {
          AFLogger.afErrorLog("Failed collecting ivc data", exception);
        } 
        return false;
      } 
    } else {
      return false;
    } 
    int j = 0;
    while (true) {
      if (j < i) {
        byte b;
        NetworkCapabilities networkCapabilities = iterator.getNetworkCapabilities((Network)exception[j]);
        if (networkCapabilities.hasTransport(4)) {
          b = 61;
        } else {
          b = 21;
        } 
        if (b != 21) {
          boolean bool = networkCapabilities.hasCapability(15);
          if (!bool) {
            b = 1;
          } else {
            b = 0;
          } 
          if (b == 1) {
            i = onAttributionFailure + 27;
            onResponse = i % 128;
            return true;
          } 
        } 
        j++;
        continue;
      } 
      return false;
    } 
  }
  
  public static SharedPreferences valueOf(Context paramContext) {
    // Byte code:
    //   0: ldc com/appsflyer/internal/AFb1xSDK
    //   2: monitorenter
    //   3: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   6: bipush #71
    //   8: iadd
    //   9: istore_1
    //   10: iload_1
    //   11: sipush #128
    //   14: irem
    //   15: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   18: invokestatic AFInAppEventType : ()Lcom/appsflyer/internal/AFb1xSDK;
    //   21: getfield onResponseErrorNative : Landroid/content/SharedPreferences;
    //   24: ifnonnull -> 95
    //   27: bipush #84
    //   29: istore_1
    //   30: goto -> 33
    //   33: iload_1
    //   34: bipush #83
    //   36: if_icmpeq -> 77
    //   39: invokestatic AFInAppEventType : ()Lcom/appsflyer/internal/AFb1xSDK;
    //   42: aload_0
    //   43: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   46: ldc_w 'appsflyer-data'
    //   49: iconst_0
    //   50: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   53: putfield onResponseErrorNative : Landroid/content/SharedPreferences;
    //   56: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   59: bipush #83
    //   61: iadd
    //   62: istore_1
    //   63: iload_1
    //   64: sipush #128
    //   67: irem
    //   68: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   71: iload_1
    //   72: iconst_2
    //   73: irem
    //   74: ifne -> 77
    //   77: invokestatic AFInAppEventType : ()Lcom/appsflyer/internal/AFb1xSDK;
    //   80: getfield onResponseErrorNative : Landroid/content/SharedPreferences;
    //   83: astore_0
    //   84: ldc com/appsflyer/internal/AFb1xSDK
    //   86: monitorexit
    //   87: aload_0
    //   88: areturn
    //   89: astore_0
    //   90: ldc com/appsflyer/internal/AFb1xSDK
    //   92: monitorexit
    //   93: aload_0
    //   94: athrow
    //   95: bipush #83
    //   97: istore_1
    //   98: goto -> 33
    // Exception table:
    //   from	to	target	type
    //   3	27	89	finally
    //   39	71	89	finally
    //   77	84	89	finally
  }
  
  public static String valueOf() {
    int i = onAttributionFailure + 107;
    onResponse = i % 128;
    String str = AFInAppEventType("AppUserId");
    i = onAttributionFailure + 125;
    onResponse = i % 128;
    return str;
  }
  
  private static String valueOf(String paramString) {
    int i = onResponse + 65;
    onAttributionFailure = i % 128;
    int j = paramString.indexOf('?');
    if (j == -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      i = onAttributionFailure;
      j = i + 121;
      onResponse = j % 128;
      i += 69;
      onResponse = i % 128;
      return "";
    } 
    return paramString.substring(j);
  }
  
  @Deprecated
  public static String valueOf(HttpURLConnection paramHttpURLConnection) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: aconst_null
    //   10: astore #4
    //   12: aload_0
    //   13: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   16: astore #5
    //   18: aload #5
    //   20: astore_3
    //   21: aload #5
    //   23: ifnonnull -> 46
    //   26: aload_0
    //   27: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   30: astore_3
    //   31: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   34: bipush #57
    //   36: iadd
    //   37: istore_1
    //   38: iload_1
    //   39: sipush #128
    //   42: irem
    //   43: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   46: new java/io/InputStreamReader
    //   49: dup
    //   50: aload_3
    //   51: invokespecial <init> : (Ljava/io/InputStream;)V
    //   54: astore #5
    //   56: new java/io/BufferedReader
    //   59: dup
    //   60: aload #5
    //   62: invokespecial <init> : (Ljava/io/Reader;)V
    //   65: astore #6
    //   67: iconst_0
    //   68: istore_1
    //   69: aload #6
    //   71: invokevirtual readLine : ()Ljava/lang/String;
    //   74: astore #4
    //   76: aload #4
    //   78: ifnull -> 87
    //   81: bipush #18
    //   83: istore_2
    //   84: goto -> 90
    //   87: bipush #21
    //   89: istore_2
    //   90: iload_2
    //   91: bipush #21
    //   93: if_icmpeq -> 184
    //   96: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   99: bipush #79
    //   101: iadd
    //   102: istore_2
    //   103: iload_2
    //   104: sipush #128
    //   107: irem
    //   108: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   111: iload_2
    //   112: iconst_2
    //   113: irem
    //   114: ifne -> 122
    //   117: iconst_1
    //   118: istore_2
    //   119: goto -> 124
    //   122: iconst_0
    //   123: istore_2
    //   124: iload_2
    //   125: ifeq -> 394
    //   128: bipush #59
    //   130: iconst_0
    //   131: idiv
    //   132: istore_2
    //   133: iload_1
    //   134: ifeq -> 412
    //   137: goto -> 140
    //   140: bipush #10
    //   142: invokestatic valueOf : (C)Ljava/lang/Character;
    //   145: astore_3
    //   146: goto -> 149
    //   149: aload #7
    //   151: aload_3
    //   152: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   155: pop
    //   156: aload #7
    //   158: aload #4
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   167: bipush #21
    //   169: iadd
    //   170: istore_1
    //   171: iload_1
    //   172: sipush #128
    //   175: irem
    //   176: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   179: iconst_1
    //   180: istore_1
    //   181: goto -> 69
    //   184: aload #6
    //   186: invokevirtual close : ()V
    //   189: aload #5
    //   191: invokevirtual close : ()V
    //   194: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   197: bipush #113
    //   199: iadd
    //   200: istore_1
    //   201: iload_1
    //   202: sipush #128
    //   205: irem
    //   206: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   209: goto -> 295
    //   212: astore_3
    //   213: aload #6
    //   215: astore #4
    //   217: goto -> 228
    //   220: astore_3
    //   221: goto -> 228
    //   224: astore_3
    //   225: aconst_null
    //   226: astore #5
    //   228: new java/lang/StringBuilder
    //   231: dup
    //   232: ldc_w 'Could not read connection response from: '
    //   235: invokespecial <init> : (Ljava/lang/String;)V
    //   238: astore #6
    //   240: aload #6
    //   242: aload_0
    //   243: invokevirtual getURL : ()Ljava/net/URL;
    //   246: invokevirtual toString : ()Ljava/lang/String;
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload #6
    //   255: invokevirtual toString : ()Ljava/lang/String;
    //   258: aload_3
    //   259: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   262: aload #4
    //   264: ifnull -> 275
    //   267: aload #4
    //   269: invokevirtual close : ()V
    //   272: goto -> 275
    //   275: aload #5
    //   277: ifnull -> 295
    //   280: aload #5
    //   282: invokevirtual close : ()V
    //   285: goto -> 295
    //   288: ldc_w 'readServerResponse error'
    //   291: aload_0
    //   292: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   295: aload #7
    //   297: invokevirtual toString : ()Ljava/lang/String;
    //   300: astore_0
    //   301: new org/json/JSONObject
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Ljava/lang/String;)V
    //   309: pop
    //   310: aload_0
    //   311: areturn
    //   312: astore_3
    //   313: ldc_w 'error while parsing readServerResponse'
    //   316: aload_3
    //   317: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   320: new org/json/JSONObject
    //   323: dup
    //   324: invokespecial <init> : ()V
    //   327: astore_3
    //   328: aload_3
    //   329: ldc_w 'string_response'
    //   332: aload_0
    //   333: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   336: pop
    //   337: aload_3
    //   338: invokevirtual toString : ()Ljava/lang/String;
    //   341: astore_0
    //   342: aload_0
    //   343: areturn
    //   344: astore_0
    //   345: ldc_w 'RESPONSE_NOT_JSON error'
    //   348: aload_0
    //   349: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   352: new org/json/JSONObject
    //   355: dup
    //   356: invokespecial <init> : ()V
    //   359: invokevirtual toString : ()Ljava/lang/String;
    //   362: areturn
    //   363: astore_0
    //   364: aload #4
    //   366: ifnull -> 426
    //   369: aload #4
    //   371: invokevirtual close : ()V
    //   374: goto -> 426
    //   377: aload #5
    //   379: invokevirtual close : ()V
    //   382: goto -> 392
    //   385: ldc_w 'readServerResponse error'
    //   388: aload_3
    //   389: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   392: aload_0
    //   393: athrow
    //   394: iload_1
    //   395: ifeq -> 403
    //   398: iconst_1
    //   399: istore_1
    //   400: goto -> 405
    //   403: iconst_0
    //   404: istore_1
    //   405: iload_1
    //   406: ifeq -> 412
    //   409: goto -> 140
    //   412: ldc ''
    //   414: astore_3
    //   415: goto -> 149
    //   418: astore_0
    //   419: goto -> 288
    //   422: astore_3
    //   423: goto -> 385
    //   426: aload #5
    //   428: ifnull -> 437
    //   431: bipush #27
    //   433: istore_1
    //   434: goto -> 440
    //   437: bipush #85
    //   439: istore_1
    //   440: iload_1
    //   441: bipush #27
    //   443: if_icmpeq -> 377
    //   446: goto -> 392
    // Exception table:
    //   from	to	target	type
    //   12	18	224	finally
    //   26	31	224	finally
    //   46	56	224	finally
    //   56	67	220	finally
    //   69	76	212	finally
    //   128	133	212	finally
    //   140	146	212	finally
    //   149	164	212	finally
    //   184	194	418	finally
    //   228	262	363	finally
    //   267	272	418	finally
    //   280	285	418	finally
    //   301	310	312	org/json/JSONException
    //   328	342	344	org/json/JSONException
    //   369	374	422	finally
    //   377	382	422	finally
  }
  
  public static Map<String, Object> valueOf(Map<String, Object> paramMap) {
    int i = onResponse + 97;
    onAttributionFailure = i % 128;
    if (paramMap.containsKey("meta")) {
      i = 61;
    } else {
      i = 78;
    } 
    if (i != 78) {
      paramMap = (Map<String, Object>)paramMap.get("meta");
      i = onAttributionFailure + 103;
      onResponse = i % 128;
      return paramMap;
    } 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    paramMap.put("meta", hashMap);
    return (Map)hashMap;
  }
  
  private void valueOf(Context paramContext, String paramString) {
    int i;
    AFe1bSDK aFe1bSDK = new AFe1bSDK();
    if (paramContext != null) {
      ((AFa1sSDK)aFe1bSDK).AFKeystoreWrapper = (Application)paramContext.getApplicationContext();
      i = onResponse + 65;
      onAttributionFailure = i % 128;
    } 
    AFa1sSDK aFa1sSDK = aFe1bSDK.AFKeystoreWrapper((AFKeystoreWrapper().AFInAppEventParameterName()).AFInAppEventType.AFKeystoreWrapper("appsFlyerCount", 0));
    aFa1sSDK.afRDLog = paramString;
    if (paramString != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = onResponse + 31;
      onAttributionFailure = i % 128;
      if (i % 2 == 0) {
        i = 60;
      } else {
        i = 97;
      } 
      int j = paramString.length();
      if (i != 60) {
        if (j > 5) {
          i = 57;
        } else {
          i = 50;
        } 
        if (i != 57)
          return; 
      } else {
        if (j > 2) {
          i = 19;
        } else {
          i = 59;
        } 
        if (i != 19)
          return; 
      } 
      if (AFInAppEventParameterName(aFa1sSDK, valueOf(paramContext)))
        AFInAppEventParameterName(AFKeystoreWrapper().values(), new AFa1vSDK(aFa1sSDK, (byte)0), 5L, TimeUnit.MILLISECONDS); 
    } 
  }
  
  private static void valueOf(Context paramContext, Map<String, Object> paramMap) {
    String str;
    int i = onResponse + 121;
    onAttributionFailure = i % 128;
    WindowManager windowManager = (WindowManager)paramContext.getSystemService("window");
    if (windowManager != null) {
      i = 13;
    } else {
      i = 65;
    } 
    if (i != 13)
      return; 
    i = onResponse + 65;
    onAttributionFailure = i % 128;
    i = windowManager.getDefaultDisplay().getRotation();
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            str = "";
          } else {
            i = onAttributionFailure + 117;
            onResponse = i % 128;
            str = "lr";
          } 
        } else {
          str = "pr";
        } 
      } else {
        str = "l";
      } 
    } else {
      str = "p";
    } 
    paramMap.put("sc_o", str);
  }
  
  private void valueOf(Context paramContext, boolean paramBoolean, Map<String, Object> paramMap, int paramInt) {
    byte b;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("cpu_abi", AFInAppEventParameterName("ro.product.cpu.abi"));
    hashMap.put("cpu_abi2", AFInAppEventParameterName("ro.product.cpu.abi2"));
    hashMap.put("arch", AFInAppEventParameterName("os.arch"));
    hashMap.put("build_display_id", AFInAppEventParameterName("ro.build.display.id"));
    if (paramBoolean) {
      b = 61;
    } else {
      b = 95;
    } 
    boolean bool = true;
    if (b == 61) {
      AFInAppEventType(paramContext, (Map)hashMap);
      if (paramInt <= 2) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (paramInt != 0) {
        paramInt = onAttributionFailure + 47;
        onResponse = paramInt % 128;
        hashMap.putAll(AFa1dSDK.AFInAppEventType(paramContext).values());
      } 
    } 
    hashMap.put("dim", AFc1lSDK.values(paramContext));
    paramMap.put("deviceData", hashMap);
    paramInt = onAttributionFailure + 125;
    onResponse = paramInt % 128;
    if (paramInt % 2 != 0) {
      paramInt = bool;
    } else {
      paramInt = 0;
    } 
    if (paramInt == 0)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  private static void valueOf(String paramString1, String paramString2) {
    int i = onResponse + 87;
    onAttributionFailure = i % 128;
    AppsFlyerProperties.getInstance().set(paramString1, paramString2);
    i = onResponse + 33;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 86;
    } else {
      i = 0;
    } 
    if (i == 0)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  private int values(SharedPreferences paramSharedPreferences, boolean paramBoolean) {
    int i = onResponse + 65;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i == 1) {
      i = AFInAppEventType(paramSharedPreferences, "appsFlyerInAppEventCount", paramBoolean);
      int j = onResponse + 95;
      onAttributionFailure = j % 128;
      return i;
    } 
    AFInAppEventType(paramSharedPreferences, "appsFlyerInAppEventCount", paramBoolean);
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private AFe1zSDK.AFa1zSDK values(Map<String, String> paramMap) {
    null = new AFe1zSDK.AFa1zSDK(this, paramMap) {
        public final void AFInAppEventType(Map<String, String> param1Map) {
          for (String str : param1Map.keySet())
            this.AFInAppEventType.put(str, param1Map.get(str)); 
          AFb1oSDK.valueOf(this.AFInAppEventType);
        }
        
        public final void AFKeystoreWrapper(String param1String) {
          AFb1oSDK.values(param1String, DeepLinkResult.Error.NETWORK);
        }
      };
    int i = onResponse + 65;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 74;
    } else {
      i = 76;
    } 
    if (i != 74)
      return null; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static String values(Activity paramActivity) {
    String str3 = null;
    String str2 = null;
    String str1 = str3;
    if (paramActivity != null) {
      int j = onAttributionFailure + 105;
      onResponse = j % 128;
      Intent intent = paramActivity.getIntent();
      str1 = str3;
      if (intent != null) {
        j = onAttributionFailure + 23;
        onResponse = j % 128;
        if (j % 2 != 0) {
          j = 0;
        } else {
          j = 1;
        } 
        if (j != 0) {
          str1 = str2;
          try {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
              j = 45;
            } else {
              j = 88;
            } 
            str1 = str3;
          } finally {
            paramActivity = null;
          } 
        } else {
          str1 = str2;
          intent.getExtras();
          str1 = str2;
          throw null;
        } 
      } 
    } 
    int i = onResponse + 79;
    onAttributionFailure = i % 128;
    if (i % 2 == 0)
      try {
        i = 43 / 0;
        return str1;
      } finally {} 
    return str1;
  }
  
  private String values(Context paramContext, String paramString) {
    int i = onAttributionFailure + 23;
    int j = i % 128;
    onResponse = j;
    if (paramContext == null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0) {
      AFInAppEventType(paramContext);
      String str = AFKeystoreWrapper().AFInAppEventParameterName().valueOf(paramString);
      i = onAttributionFailure + 65;
      onResponse = i % 128;
      return str;
    } 
    i = j + 117;
    j = i % 128;
    onAttributionFailure = j;
    if (i % 2 == 0) {
      i = 20;
    } else {
      i = 38;
    } 
    if (i != 20) {
      i = j + 37;
      onResponse = i % 128;
      return null;
    } 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public static String values(AFc1xSDK paramAFc1xSDK, String paramString) {
    int i;
    String str = paramAFc1xSDK.AFInAppEventType("CACHED_CHANNEL", null);
    if (str != null) {
      i = 11;
    } else {
      i = 23;
    } 
    if (i != 23) {
      i = onAttributionFailure;
      int j = i + 95;
      onResponse = j % 128;
      i += 59;
      onResponse = i % 128;
      return str;
    } 
    paramAFc1xSDK.AFKeystoreWrapper("CACHED_CHANNEL", paramString);
    return paramString;
  }
  
  private void values(Context paramContext, AFe1iSDK paramAFe1iSDK) {
    AFInAppEventType(paramContext);
    AFe1fSDK aFe1fSDK = AFKeystoreWrapper().AFLogger();
    null = AFa1oSDK.AFKeystoreWrapper(paramContext);
    boolean bool1 = aFe1fSDK.AFInAppEventParameterName();
    boolean bool = true;
    if (bool1) {
      int j = onResponse + 53;
      onAttributionFailure = j % 128;
      if (j % 2 == 0) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 1) {
        aFe1fSDK.values.put("api_name", paramAFe1iSDK.toString());
        aFe1fSDK.values(null);
      } else {
        aFe1fSDK.values.put("api_name", paramAFe1iSDK.toString());
        aFe1fSDK.values(null);
        try {
          j = 49 / 0;
        } finally {}
      } 
    } 
    aFe1fSDK.AFInAppEventType();
    int i = onAttributionFailure + 79;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = bool;
    } else {
      i = 0;
    } 
    if (i == 0)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private void values(Context paramContext, Map<String, Object> paramMap) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #71
    //   5: iadd
    //   6: istore_3
    //   7: iload_3
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   15: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   18: astore #7
    //   20: iconst_0
    //   21: istore #4
    //   23: aload #7
    //   25: ldc_w 'deviceTrackingDisabled'
    //   28: iconst_0
    //   29: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   32: ifeq -> 41
    //   35: bipush #14
    //   37: istore_3
    //   38: goto -> 44
    //   41: bipush #24
    //   43: istore_3
    //   44: iload_3
    //   45: bipush #14
    //   47: if_icmpeq -> 613
    //   50: aload_0
    //   51: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   54: invokeinterface afErrorLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   59: astore #9
    //   61: aload_0
    //   62: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   65: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   70: aload #9
    //   72: invokevirtual AFKeystoreWrapper : (Lcom/appsflyer/internal/AFc1xSDK;)Ljava/lang/String;
    //   75: astore #8
    //   77: aload #8
    //   79: invokestatic valueOf : (Ljava/lang/String;)Z
    //   82: ifne -> 141
    //   85: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   88: bipush #13
    //   90: iadd
    //   91: istore_3
    //   92: iload_3
    //   93: sipush #128
    //   96: irem
    //   97: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   100: iload_3
    //   101: iconst_2
    //   102: irem
    //   103: ifne -> 129
    //   106: aload_2
    //   107: ldc_w 'imei'
    //   110: aload #8
    //   112: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   117: pop
    //   118: bipush #17
    //   120: iconst_0
    //   121: idiv
    //   122: istore_3
    //   123: goto -> 141
    //   126: astore_1
    //   127: aload_1
    //   128: athrow
    //   129: aload_2
    //   130: ldc_w 'imei'
    //   133: aload #8
    //   135: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   140: pop
    //   141: aload #7
    //   143: ldc_w 'collectAndroidId'
    //   146: iconst_0
    //   147: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   150: istore #6
    //   152: aload #9
    //   154: ldc_w 'androidIdCached'
    //   157: aconst_null
    //   158: invokeinterface AFInAppEventType : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   163: astore #7
    //   165: iload #6
    //   167: ifeq -> 175
    //   170: iconst_1
    //   171: istore_3
    //   172: goto -> 177
    //   175: iconst_0
    //   176: istore_3
    //   177: iload_3
    //   178: ifeq -> 346
    //   181: aload_0
    //   182: getfield afInfoLog : Ljava/lang/String;
    //   185: invokestatic valueOf : (Ljava/lang/String;)Z
    //   188: ifeq -> 346
    //   191: aload_1
    //   192: invokestatic afDebugLog : (Landroid/content/Context;)Z
    //   195: ifeq -> 404
    //   198: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   201: bipush #55
    //   203: iadd
    //   204: istore_3
    //   205: iload_3
    //   206: sipush #128
    //   209: irem
    //   210: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   213: aload_1
    //   214: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   217: ldc_w 'android_id'
    //   220: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   223: astore #8
    //   225: aload #8
    //   227: ifnull -> 235
    //   230: iconst_1
    //   231: istore_3
    //   232: goto -> 237
    //   235: iconst_0
    //   236: istore_3
    //   237: iload_3
    //   238: ifeq -> 248
    //   241: aload #8
    //   243: astore #7
    //   245: goto -> 407
    //   248: aload #7
    //   250: ifnull -> 285
    //   253: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   256: bipush #19
    //   258: iadd
    //   259: istore_3
    //   260: iload_3
    //   261: sipush #128
    //   264: irem
    //   265: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   268: ldc_w 'use cached AndroidId: '
    //   271: aload #7
    //   273: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   276: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   279: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   282: goto -> 343
    //   285: aconst_null
    //   286: astore #7
    //   288: goto -> 343
    //   291: astore #8
    //   293: aload #7
    //   295: ifnull -> 330
    //   298: ldc_w 'use cached AndroidId: '
    //   301: aload #7
    //   303: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   306: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   309: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   312: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   315: bipush #119
    //   317: iadd
    //   318: istore_3
    //   319: iload_3
    //   320: sipush #128
    //   323: irem
    //   324: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   327: goto -> 333
    //   330: aconst_null
    //   331: astore #7
    //   333: aload #8
    //   335: invokevirtual getMessage : ()Ljava/lang/String;
    //   338: aload #8
    //   340: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   343: goto -> 407
    //   346: aload_0
    //   347: getfield afInfoLog : Ljava/lang/String;
    //   350: astore #7
    //   352: aload #7
    //   354: ifnull -> 404
    //   357: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   360: bipush #9
    //   362: iadd
    //   363: istore #5
    //   365: iload #5
    //   367: sipush #128
    //   370: irem
    //   371: istore_3
    //   372: iload_3
    //   373: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   376: iload #5
    //   378: iconst_2
    //   379: irem
    //   380: ifne -> 399
    //   383: iload_3
    //   384: bipush #87
    //   386: iadd
    //   387: istore_3
    //   388: iload_3
    //   389: sipush #128
    //   392: irem
    //   393: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   396: goto -> 407
    //   399: aconst_null
    //   400: athrow
    //   401: astore_1
    //   402: aload_1
    //   403: athrow
    //   404: aconst_null
    //   405: astore #7
    //   407: aload #7
    //   409: ifnull -> 418
    //   412: bipush #90
    //   414: istore_3
    //   415: goto -> 421
    //   418: bipush #32
    //   420: istore_3
    //   421: iload_3
    //   422: bipush #90
    //   424: if_icmpeq -> 436
    //   427: ldc_w 'Android ID was not collected.'
    //   430: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   433: goto -> 493
    //   436: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   439: bipush #89
    //   441: iadd
    //   442: istore #5
    //   444: iload #5
    //   446: sipush #128
    //   449: irem
    //   450: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   453: iload #4
    //   455: istore_3
    //   456: iload #5
    //   458: iconst_2
    //   459: irem
    //   460: ifne -> 465
    //   463: iconst_1
    //   464: istore_3
    //   465: iload_3
    //   466: ifne -> 578
    //   469: aload #9
    //   471: ldc_w 'androidIdCached'
    //   474: aload #7
    //   476: invokeinterface AFKeystoreWrapper : (Ljava/lang/String;Ljava/lang/String;)V
    //   481: aload_2
    //   482: ldc_w 'android_id'
    //   485: aload #7
    //   487: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   492: pop
    //   493: aload_1
    //   494: invokestatic AFInAppEventParameterName : (Landroid/content/Context;)Lcom/appsflyer/internal/AFc1qSDK$AFa1vSDK;
    //   497: astore #7
    //   499: aload #7
    //   501: ifnull -> 577
    //   504: new java/util/HashMap
    //   507: dup
    //   508: invokespecial <init> : ()V
    //   511: astore_1
    //   512: aload_1
    //   513: ldc_w 'isManual'
    //   516: aload #7
    //   518: getfield AFKeystoreWrapper : Ljava/lang/Boolean;
    //   521: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   526: pop
    //   527: aload_1
    //   528: ldc_w 'val'
    //   531: aload #7
    //   533: getfield AFInAppEventParameterName : Ljava/lang/String;
    //   536: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   541: pop
    //   542: aload #7
    //   544: getfield AFInAppEventType : Ljava/lang/Boolean;
    //   547: astore #7
    //   549: aload #7
    //   551: ifnull -> 566
    //   554: aload_1
    //   555: ldc_w 'isLat'
    //   558: aload #7
    //   560: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   565: pop
    //   566: aload_2
    //   567: ldc_w 'oaid'
    //   570: aload_1
    //   571: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   576: pop
    //   577: return
    //   578: aload #9
    //   580: ldc_w 'androidIdCached'
    //   583: aload #7
    //   585: invokeinterface AFKeystoreWrapper : (Ljava/lang/String;Ljava/lang/String;)V
    //   590: aload_2
    //   591: ldc_w 'android_id'
    //   594: aload #7
    //   596: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   601: pop
    //   602: new java/lang/NullPointerException
    //   605: dup
    //   606: invokespecial <init> : ()V
    //   609: athrow
    //   610: astore_1
    //   611: aload_1
    //   612: athrow
    //   613: aload_2
    //   614: ldc_w 'deviceTrackingDisabled'
    //   617: ldc_w 'true'
    //   620: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   625: pop
    //   626: return
    // Exception table:
    //   from	to	target	type
    //   118	123	126	finally
    //   213	225	291	java/lang/Exception
    //   268	282	291	java/lang/Exception
    //   399	401	401	finally
    //   602	610	610	finally
  }
  
  private static void values(AppsFlyerConversionListener paramAppsFlyerConversionListener) {
    int i = onResponse + 23;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0) {
      if (paramAppsFlyerConversionListener == null)
        return; 
    } else {
      try {
        i = 76 / 0;
        if (paramAppsFlyerConversionListener == null)
          return; 
        valueOf = paramAppsFlyerConversionListener;
        i = onAttributionFailure + 37;
        onResponse = i % 128;
        return;
      } finally {}
    } 
    valueOf = paramAppsFlyerConversionListener;
    i = onAttributionFailure + 37;
    onResponse = i % 128;
  }
  
  private void values(AFa1sSDK paramAFa1sSDK) {
    boolean bool1;
    int i = onResponse + 15;
    onAttributionFailure = i % 128;
    String str = paramAFa1sSDK.afErrorLog;
    boolean bool2 = false;
    if (str == null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (values()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 != true) {
      if (i != 0) {
        i = 27;
      } else {
        i = 36;
      } 
      if (i == 27) {
        i = onAttributionFailure + 93;
        onResponse = i % 128;
        if (AppsFlyerProperties.getInstance().getBoolean("launchProtectEnabled", true)) {
          i = 92;
        } else {
          i = 68;
        } 
        if (i != 92) {
          AFLogger.afInfoLog("Allowing multiple launches within a 5 second time window.");
        } else if (afErrorLog()) {
          i = onAttributionFailure + 43;
          onResponse = i % 128;
          if (i % 2 != 0) {
            i = 30;
          } else {
            i = 37;
          } 
          if (i == 37) {
            null = paramAFa1sSDK.AFInAppEventType;
            if (null != null)
              null.onError(RequestError.EVENT_TIMEOUT, AFb1aSDK.AFInAppEventType); 
            i = onResponse + 45;
            onAttributionFailure = i % 128;
            if (i % 2 == 0) {
              i = bool2;
            } else {
              i = 1;
            } 
            if (i != 0)
              return; 
            try {
              throw new NullPointerException();
            } finally {}
          } 
          null = paramAFa1sSDK.AFInAppEventType;
          try {
            throw new NullPointerException();
          } finally {}
        } 
        this.afRDLog = System.currentTimeMillis();
      } 
      AFInAppEventParameterName(AFKeystoreWrapper().values(), new AFa1vSDK(paramAFa1sSDK, (byte)0), 0L, TimeUnit.MILLISECONDS);
      i = onResponse + 119;
      onAttributionFailure = i % 128;
      if (i % 2 != 0)
        return; 
      try {
        throw null;
      } finally {}
    } 
    i = onResponse + 43;
    onAttributionFailure = i % 128;
    AFLogger.afInfoLog("CustomerUserId not set, reporting is disabled", true);
  }
  
  private static void values(String paramString) {
    try {
      if ((new JSONObject(paramString)).has("pid")) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 1) {
        AFLogger.afWarnLog("Cannot set preinstall attribution data without a media source");
        i = onResponse + 121;
        onAttributionFailure = i % 128;
        return;
      } 
      int i = onAttributionFailure + 103;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 74;
      } else {
        i = 44;
      } 
      if (i == 44) {
        valueOf("preInstallName", paramString);
        return;
      } 
      valueOf("preInstallName", paramString);
      try {
        throw null;
      } finally {}
    } catch (JSONException jSONException) {
      AFLogger.afErrorLog("Error parsing JSON for preinstall", (Throwable)jSONException);
      return;
    } 
  }
  
  private void values(Map<String, Object> paramMap, boolean paramBoolean) {
    paramMap.put("platformextension", this.onInstallConversionFailureNative.AFKeystoreWrapper());
    if (paramBoolean) {
      i = 73;
    } else {
      i = 27;
    } 
    if (i != 27) {
      i = onAttributionFailure + 125;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 1) {
        paramMap.put("platform_extension_v2", AFKeystoreWrapper().init().AFInAppEventType());
      } else {
        paramMap.put("platform_extension_v2", AFKeystoreWrapper().init().AFInAppEventType());
        try {
          i = 79 / 0;
          i = onResponse + 113;
          onAttributionFailure = i % 128;
          return;
        } finally {}
      } 
    } else {
      return;
    } 
    int i = onResponse + 113;
    onAttributionFailure = i % 128;
  }
  
  private static void values(JSONObject paramJSONObject) {
    ArrayList<Long> arrayList = new ArrayList();
    Iterator<String> iterator1 = paramJSONObject.keys();
    label61: while (iterator1.hasNext()) {
      String str = iterator1.next();
      try {
        JSONArray jSONArray = new JSONArray((String)paramJSONObject.get(str));
        int i = 0;
        while (true) {
          int j = jSONArray.length();
          if (i < j) {
            j = 0;
          } else {
            j = 1;
          } 
          if (j != 0) {
            i = onResponse + 119;
            onAttributionFailure = i % 128;
            continue label61;
          } 
          arrayList.add(Long.valueOf(jSONArray.getLong(i)));
          i++;
          j = onResponse + 73;
          onAttributionFailure = j % 128;
        } 
      } catch (JSONException jSONException) {
        AFLogger.afErrorLogForExcManagerOnly("error at timeStampArr", (Throwable)jSONException);
      } 
    } 
    Collections.sort(arrayList);
    Iterator<String> iterator2 = paramJSONObject.keys();
    label68: while (true) {
      iterator1 = null;
      label67: while (iterator2.hasNext()) {
        int i = onResponse + 81;
        onAttributionFailure = i % 128;
        if (iterator1 == null) {
          String str = iterator2.next();
          Iterator<String> iterator = iterator1;
          try {
            JSONArray jSONArray = new JSONArray((String)paramJSONObject.get(str));
            i = 0;
            while (true) {
              iterator = iterator1;
              int j = jSONArray.length();
              if (i < j) {
                j = 33;
              } else {
                j = 2;
              } 
              if (j != 33)
                continue label67; 
              j = onResponse + 17;
              onAttributionFailure = j % 128;
              iterator = iterator1;
              if (jSONArray.getLong(i) != ((Long)arrayList.get(0)).longValue()) {
                iterator = iterator1;
                long l1 = jSONArray.getLong(i);
                iterator = iterator1;
                long l2 = ((Long)arrayList.get(1)).longValue();
                if (l1 != l2) {
                  j = 64;
                } else {
                  j = 31;
                } 
                if (j != 31) {
                  j = onAttributionFailure + 75;
                  onResponse = j % 128;
                  iterator = iterator1;
                  l1 = jSONArray.getLong(i);
                  iterator = iterator1;
                  l2 = ((Long)arrayList.get(arrayList.size() - 1)).longValue();
                  if (l1 == l2) {
                    j = 1;
                  } else {
                    j = 0;
                  } 
                  if (j != 1) {
                    i++;
                    String str1 = str;
                    continue;
                  } 
                  continue label68;
                } 
                continue label68;
              } 
              continue label68;
            } 
          } catch (JSONException jSONException) {
            AFLogger.afErrorLogForExcManagerOnly("error at manageExtraReferrers", (Throwable)jSONException);
            iterator1 = iterator;
          } 
        } 
      } 
      break;
    } 
    if (iterator1 != null) {
      int i = onResponse + 113;
      onAttributionFailure = i % 128;
      paramJSONObject.remove((String)iterator1);
    } 
  }
  
  @Deprecated
  public final String AFInAppEventParameterName(Context paramContext) {
    int i = onAttributionFailure + 97;
    onResponse = i % 128;
    AFInAppEventType(paramContext);
    String str = AFKeystoreWrapper().AFInAppEventParameterName().values();
    i = onResponse + 125;
    onAttributionFailure = i % 128;
    return str;
  }
  
  final void AFInAppEventParameterName(WeakReference<Context> paramWeakReference) {
    int i = onResponse + 103;
    onAttributionFailure = i % 128;
    if (i % 2 != 0) {
      if (paramWeakReference.get() == null)
        return; 
      AFLogger.afInfoLog("app went to background");
      SharedPreferences sharedPreferences = valueOf(paramWeakReference.get());
      AppsFlyerProperties.getInstance().saveProperties(sharedPreferences);
      long l = (AFKeystoreWrapper().AFLogger()).AFLogger$LogLevel;
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      String str = (AFKeystoreWrapper().afWarnLog()).AFInAppEventType;
      byte b = 73;
      if (str == null) {
        i = 73;
      } else {
        i = 23;
      } 
      if (i != 73) {
        String str1;
        String str2 = AFInAppEventType("KSAppsFlyerId");
        if (AppsFlyerProperties.getInstance().getBoolean("deviceTrackingDisabled", false)) {
          i = 64;
        } else {
          i = 47;
        } 
        if (i == 64)
          hashMap.put("deviceTrackingDisabled", "true"); 
        AFc1qSDK.AFa1vSDK aFa1vSDK = AFa1bSDK.values(((Context)paramWeakReference.get()).getContentResolver());
        if (aFa1vSDK != null) {
          i = onResponse + 65;
          onAttributionFailure = i % 128;
          hashMap.put("amazon_aid", aFa1vSDK.AFInAppEventParameterName);
          hashMap.put("amazon_aid_limit", String.valueOf(aFa1vSDK.AFInAppEventType));
          i = onResponse + 51;
          onAttributionFailure = i % 128;
        } 
        String str3 = AppsFlyerProperties.getInstance().getString("advertiserId");
        if (str3 != null) {
          i = 76;
        } else {
          i = 60;
        } 
        if (i != 60)
          hashMap.put("advertiserId", str3); 
        hashMap.put("app_id", ((Context)paramWeakReference.get()).getPackageName());
        hashMap.put("devkey", str);
        hashMap.put("uid", AFb1wSDK.AFInAppEventParameterName(paramWeakReference));
        hashMap.put("time_in_app", String.valueOf(l));
        hashMap.put("statType", "user_closed_app");
        hashMap.put("platform", "Android");
        hashMap.put("launch_counter", Integer.toString(AFKeystoreWrapper(sharedPreferences, false)));
        hashMap.put("channel", AFInAppEventParameterName(paramWeakReference.get()));
        if (str2 != null) {
          i = b;
        } else {
          i = 60;
        } 
        if (i != 60) {
          str1 = str2;
        } else {
          str1 = "";
        } 
        hashMap.put("originalAppsflyerId", str1);
        if (this.onAppOpenAttributionNative) {
          AFf1xSDK aFf1xSDK = new AFf1xSDK();
          ((AFe1aSDK)aFf1xSDK).AFLogger$LogLevel = super.isStopped();
          null = new AFd1cSDK(aFf1xSDK.AFKeystoreWrapper((AFKeystoreWrapper().AFInAppEventParameterName()).AFInAppEventType.AFKeystoreWrapper("appsFlyerCount", 0)).AFInAppEventParameterName(hashMap).AFInAppEventParameterName(String.format(afErrorLog, new Object[] { AppsFlyerLib.getInstance().getHostPrefix(), AFInAppEventType().getHostName() })), AFKeystoreWrapper());
          AFd1pSDK aFd1pSDK = AFKeystoreWrapper().afDebugLog();
          aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)null));
          return;
        } 
        AFLogger.afDebugLog("Stats call is disabled, ignore ...");
        return;
      } 
      AFLogger.afWarnLog("[callStats] AppsFlyer's SDK cannot send any event without providing DevKey.");
      return;
    } 
    null.get();
    try {
      throw null;
    } finally {}
  }
  
  final Map<String, Object> AFInAppEventType(AFa1sSDK paramAFa1sSDK) {
    // Byte code:
    //   0: aload_0
    //   1: astore #19
    //   3: aload_1
    //   4: getfield AFKeystoreWrapper : Landroid/app/Application;
    //   7: astore #17
    //   9: aload_0
    //   10: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   13: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   18: getfield AFInAppEventType : Ljava/lang/String;
    //   21: astore #22
    //   23: aload_1
    //   24: getfield afErrorLog : Ljava/lang/String;
    //   27: astore #16
    //   29: aload_1
    //   30: getfield values : Ljava/util/Map;
    //   33: ifnonnull -> 48
    //   36: new java/util/HashMap
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #18
    //   45: goto -> 54
    //   48: aload_1
    //   49: getfield values : Ljava/util/Map;
    //   52: astore #18
    //   54: new org/json/JSONObject
    //   57: dup
    //   58: aload #18
    //   60: invokespecial <init> : (Ljava/util/Map;)V
    //   63: invokevirtual toString : ()Ljava/lang/String;
    //   66: astore #21
    //   68: aload_1
    //   69: getfield afRDLog : Ljava/lang/String;
    //   72: astore #23
    //   74: aload #17
    //   76: invokestatic valueOf : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   79: astore #18
    //   81: aload_1
    //   82: invokevirtual AFInAppEventParameterName : ()Z
    //   85: istore #7
    //   87: aload_1
    //   88: getfield AFInAppEventParameterName : Ljava/lang/String;
    //   91: astore #20
    //   93: aload_1
    //   94: getfield valueOf : Ljava/util/Map;
    //   97: astore #31
    //   99: aload #17
    //   101: aload #31
    //   103: invokestatic AFInAppEventType : (Landroid/content/Context;Ljava/util/Map;)Lcom/appsflyer/internal/AFc1qSDK$AFa1vSDK;
    //   106: pop
    //   107: getstatic com/appsflyer/internal/AFa1bSDK.AFInAppEventType : Ljava/lang/Boolean;
    //   110: astore_1
    //   111: aload_1
    //   112: ifnull -> 142
    //   115: aload_1
    //   116: invokevirtual booleanValue : ()Z
    //   119: ifne -> 142
    //   122: aload #31
    //   124: invokestatic valueOf : (Ljava/util/Map;)Ljava/util/Map;
    //   127: ldc_w 'ad_ids_disabled'
    //   130: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   133: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   138: pop
    //   139: goto -> 142
    //   142: new java/util/Date
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: invokevirtual getTime : ()J
    //   152: lstore #10
    //   154: lconst_0
    //   155: invokestatic getPackedPositionType : (J)I
    //   158: istore #4
    //   160: invokestatic myTid : ()I
    //   163: istore #5
    //   165: invokestatic elapsedRealtime : ()J
    //   168: lstore #12
    //   170: iconst_1
    //   171: anewarray java/lang/Object
    //   174: astore_1
    //   175: iload #4
    //   177: iconst_5
    //   178: iadd
    //   179: ldc_w '￿\\n￵￼￷￷\\n\\t￻'
    //   182: iload #5
    //   184: bipush #22
    //   186: ishr
    //   187: sipush #289
    //   190: iadd
    //   191: bipush #13
    //   193: lload #12
    //   195: lconst_0
    //   196: lcmp
    //   197: isub
    //   198: iconst_1
    //   199: aload_1
    //   200: invokestatic AFKeystoreWrapper : (ILjava/lang/String;IIZ[Ljava/lang/Object;)V
    //   203: aload #31
    //   205: aload_1
    //   206: iconst_0
    //   207: aaload
    //   208: checkcast java/lang/String
    //   211: invokevirtual intern : ()Ljava/lang/String;
    //   214: lload #10
    //   216: invokestatic toString : (J)Ljava/lang/String;
    //   219: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   224: pop
    //   225: aload #17
    //   227: lload #10
    //   229: invokestatic AFKeystoreWrapper : (Landroid/content/Context;J)Ljava/lang/String;
    //   232: astore_1
    //   233: aload_1
    //   234: ifnull -> 249
    //   237: aload #31
    //   239: ldc_w 'cksm_v1'
    //   242: aload_1
    //   243: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   248: pop
    //   249: aload_0
    //   250: invokevirtual isStopped : ()Z
    //   253: ifne -> 298
    //   256: new java/lang/StringBuilder
    //   259: dup
    //   260: ldc_w '******* sendTrackingWithEvent: '
    //   263: invokespecial <init> : (Ljava/lang/String;)V
    //   266: astore #24
    //   268: iload #7
    //   270: ifeq -> 5785
    //   273: ldc_w 'Launch'
    //   276: astore_1
    //   277: goto -> 280
    //   280: aload #24
    //   282: aload_1
    //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: pop
    //   287: aload #24
    //   289: invokevirtual toString : ()Ljava/lang/String;
    //   292: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   295: goto -> 304
    //   298: ldc_w 'Reporting has been stopped'
    //   301: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   304: aload_0
    //   305: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   308: invokeinterface AFLogger$LogLevel : ()Lcom/appsflyer/internal/AFb1zSDK;
    //   313: invokeinterface AFKeystoreWrapper : ()V
    //   318: aload #17
    //   320: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   323: aload #17
    //   325: invokevirtual getPackageName : ()Ljava/lang/String;
    //   328: sipush #4096
    //   331: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   334: getfield requestedPermissions : [Ljava/lang/String;
    //   337: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   340: astore_1
    //   341: aload_1
    //   342: ldc_w 'android.permission.INTERNET'
    //   345: invokeinterface contains : (Ljava/lang/Object;)Z
    //   350: ifne -> 359
    //   353: ldc_w 'Permission android.permission.INTERNET is missing in the AndroidManifest.xml'
    //   356: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   359: aload_1
    //   360: ldc_w 'android.permission.ACCESS_NETWORK_STATE'
    //   363: invokeinterface contains : (Ljava/lang/Object;)Z
    //   368: ifne -> 377
    //   371: ldc_w 'Permission android.permission.ACCESS_NETWORK_STATE is missing in the AndroidManifest.xml'
    //   374: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   377: getstatic android/os/Build$VERSION.SDK_INT : I
    //   380: bipush #32
    //   382: if_icmple -> 414
    //   385: aload_1
    //   386: ldc_w 'com.google.android.gms.permission.AD_ID'
    //   389: invokeinterface contains : (Ljava/lang/Object;)Z
    //   394: ifne -> 414
    //   397: ldc_w 'Permission com.google.android.gms.permission.AD_ID is missing in the AndroidManifest.xml'
    //   400: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   403: goto -> 414
    //   406: astore_1
    //   407: ldc_w 'Exception while validation permissions. '
    //   410: aload_1
    //   411: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   414: iconst_0
    //   415: iconst_0
    //   416: invokestatic getDeadChar : (II)I
    //   419: istore #4
    //   421: invokestatic getKeyRepeatTimeout : ()I
    //   424: istore #5
    //   426: iconst_0
    //   427: invokestatic blue : (I)I
    //   430: istore #6
    //   432: iconst_1
    //   433: anewarray java/lang/Object
    //   436: astore_1
    //   437: iload #4
    //   439: iconst_1
    //   440: iadd
    //   441: ldc ' '
    //   443: sipush #232
    //   446: iload #5
    //   448: bipush #16
    //   450: ishr
    //   451: isub
    //   452: iload #6
    //   454: iconst_1
    //   455: iadd
    //   456: iconst_0
    //   457: aload_1
    //   458: invokestatic AFKeystoreWrapper : (ILjava/lang/String;IIZ[Ljava/lang/Object;)V
    //   461: aload #31
    //   463: ldc_w 'af_events_api'
    //   466: aload_1
    //   467: iconst_0
    //   468: aaload
    //   469: checkcast java/lang/String
    //   472: invokevirtual intern : ()Ljava/lang/String;
    //   475: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   480: pop
    //   481: invokestatic getMaximumFlingVelocity : ()I
    //   484: istore #4
    //   486: iconst_0
    //   487: iconst_0
    //   488: invokestatic combineMeasuredStates : (II)I
    //   491: istore #5
    //   493: invokestatic getPressedStateDuration : ()I
    //   496: istore #6
    //   498: iconst_1
    //   499: anewarray java/lang/Object
    //   502: astore_1
    //   503: iload #4
    //   505: bipush #16
    //   507: ishr
    //   508: iconst_5
    //   509: iadd
    //   510: ldc_w '�￺￻'
    //   513: sipush #286
    //   516: iload #5
    //   518: isub
    //   519: iconst_5
    //   520: iload #6
    //   522: bipush #16
    //   524: ishr
    //   525: isub
    //   526: iconst_1
    //   527: aload_1
    //   528: invokestatic AFKeystoreWrapper : (ILjava/lang/String;IIZ[Ljava/lang/Object;)V
    //   531: aload #31
    //   533: aload_1
    //   534: iconst_0
    //   535: aaload
    //   536: checkcast java/lang/String
    //   539: invokevirtual intern : ()Ljava/lang/String;
    //   542: getstatic android/os/Build.BRAND : Ljava/lang/String;
    //   545: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   550: pop
    //   551: aload #31
    //   553: ldc_w 'device'
    //   556: getstatic android/os/Build.DEVICE : Ljava/lang/String;
    //   559: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   564: pop
    //   565: aload #31
    //   567: ldc_w 'product'
    //   570: getstatic android/os/Build.PRODUCT : Ljava/lang/String;
    //   573: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   578: pop
    //   579: aload #31
    //   581: ldc_w 'sdk'
    //   584: getstatic android/os/Build$VERSION.SDK_INT : I
    //   587: invokestatic toString : (I)Ljava/lang/String;
    //   590: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   595: pop
    //   596: aload #31
    //   598: ldc_w 'model'
    //   601: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   604: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   609: pop
    //   610: aload #31
    //   612: ldc_w 'deviceType'
    //   615: getstatic android/os/Build.TYPE : Ljava/lang/String;
    //   618: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   623: pop
    //   624: aload #17
    //   626: aload #31
    //   628: invokestatic valueOf : (Landroid/content/Context;Ljava/util/Map;)V
    //   631: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   634: astore #32
    //   636: new com/appsflyer/internal/AFb1hSDK
    //   639: dup
    //   640: aload #17
    //   642: invokespecial <init> : (Landroid/content/Context;)V
    //   645: astore #28
    //   647: aload_0
    //   648: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   651: invokeinterface AFLogger : ()Lcom/appsflyer/internal/AFe1fSDK;
    //   656: astore #24
    //   658: iload #7
    //   660: ifeq -> 1112
    //   663: aload #17
    //   665: invokestatic afRDLog : (Landroid/content/Context;)Z
    //   668: ifeq -> 800
    //   671: aload #32
    //   673: invokevirtual isOtherSdkStringDisabled : ()Z
    //   676: ifne -> 712
    //   679: aload #31
    //   681: ldc_w 'batteryLevel'
    //   684: aload_0
    //   685: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   688: invokeinterface AppsFlyer2dXConversionCallback : ()Lcom/appsflyer/internal/AFc1zSDK;
    //   693: aload #17
    //   695: invokeinterface AFInAppEventType : (Landroid/content/Context;)Lcom/appsflyer/internal/AFc1zSDK$AFa1vSDK;
    //   700: getfield valueOf : F
    //   703: invokestatic valueOf : (F)Ljava/lang/String;
    //   706: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   711: pop
    //   712: aload #17
    //   714: invokestatic afErrorLog : (Landroid/content/Context;)V
    //   717: getstatic android/os/Build$VERSION.SDK_INT : I
    //   720: bipush #23
    //   722: if_icmplt -> 740
    //   725: aload #17
    //   727: ldc_w android/app/UiModeManager
    //   730: invokevirtual getSystemService : (Ljava/lang/Class;)Ljava/lang/Object;
    //   733: checkcast android/app/UiModeManager
    //   736: astore_1
    //   737: goto -> 752
    //   740: aload #17
    //   742: ldc_w 'uimode'
    //   745: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   748: checkcast android/app/UiModeManager
    //   751: astore_1
    //   752: aload_1
    //   753: ifnull -> 778
    //   756: aload_1
    //   757: invokevirtual getCurrentModeType : ()I
    //   760: iconst_4
    //   761: if_icmpne -> 778
    //   764: aload #31
    //   766: ldc_w 'tv'
    //   769: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   772: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   777: pop
    //   778: aload #17
    //   780: invokestatic valueOf : (Landroid/content/Context;)Z
    //   783: ifeq -> 800
    //   786: aload #31
    //   788: ldc_w 'inst_app'
    //   791: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   794: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   799: pop
    //   800: aload #31
    //   802: ldc_w 'timepassedsincelastlaunch'
    //   805: aload #19
    //   807: aload #17
    //   809: invokespecial afErrorLogForExcManagerOnly : (Landroid/content/Context;)J
    //   812: invokestatic toString : (J)Ljava/lang/String;
    //   815: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   820: pop
    //   821: aload #31
    //   823: invokestatic AFInAppEventType : (Ljava/util/Map;)V
    //   826: aload #31
    //   828: aload #24
    //   830: invokestatic AFInAppEventType : (Ljava/util/Map;Lcom/appsflyer/internal/AFe1fSDK;)V
    //   833: aload #19
    //   835: getfield onResponseNative : Ljava/lang/String;
    //   838: astore_1
    //   839: aload_1
    //   840: ifnull -> 855
    //   843: aload #31
    //   845: ldc_w 'phone'
    //   848: aload_1
    //   849: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   854: pop
    //   855: aload #23
    //   857: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   860: istore #8
    //   862: iload #8
    //   864: ifne -> 880
    //   867: aload #31
    //   869: ldc_w 'referrer'
    //   872: aload #23
    //   874: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   879: pop
    //   880: aload #18
    //   882: ldc_w 'extraReferrers'
    //   885: aconst_null
    //   886: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   891: astore_1
    //   892: aload_1
    //   893: ifnull -> 908
    //   896: aload #31
    //   898: ldc_w 'extraReferrers'
    //   901: aload_1
    //   902: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   907: pop
    //   908: aload #32
    //   910: aload #17
    //   912: invokevirtual getReferrer : (Landroid/content/Context;)Ljava/lang/String;
    //   915: astore_1
    //   916: aload_1
    //   917: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   920: ifne -> 948
    //   923: aload #31
    //   925: ldc_w 'referrer'
    //   928: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   933: ifnonnull -> 948
    //   936: aload #31
    //   938: ldc_w 'referrer'
    //   941: aload_1
    //   942: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   947: pop
    //   948: aload #24
    //   950: getfield AFLogger$LogLevel : J
    //   953: lstore #10
    //   955: lload #10
    //   957: lconst_0
    //   958: lcmp
    //   959: ifeq -> 978
    //   962: aload #31
    //   964: ldc_w 'prev_session_dur'
    //   967: lload #10
    //   969: invokestatic valueOf : (J)Ljava/lang/Long;
    //   972: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   977: pop
    //   978: getstatic com/appsflyer/internal/AFb1fSDK.values : Landroid/app/Application;
    //   981: astore_1
    //   982: aload_1
    //   983: ifnonnull -> 994
    //   986: ldc2_w -1
    //   989: lstore #10
    //   991: goto -> 1011
    //   994: getstatic com/appsflyer/internal/AFb1fSDK.values : Landroid/app/Application;
    //   997: invokestatic valueOf : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   1000: ldc_w 'exception_number'
    //   1003: lconst_0
    //   1004: invokeinterface getLong : (Ljava/lang/String;J)J
    //   1009: lstore #10
    //   1011: aload #31
    //   1013: ldc_w 'exception_number'
    //   1016: lload #10
    //   1018: invokestatic valueOf : (J)Ljava/lang/Long;
    //   1021: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1026: pop
    //   1027: aload #19
    //   1029: getfield onConversionDataSuccess : Lcom/appsflyer/internal/AFb1eSDK;
    //   1032: astore_1
    //   1033: aload_1
    //   1034: ifnull -> 1121
    //   1037: aload_1
    //   1038: getfield AFKeystoreWrapper : Ljava/util/Map;
    //   1041: invokeinterface isEmpty : ()Z
    //   1046: istore #8
    //   1048: iload #8
    //   1050: ifne -> 1068
    //   1053: aload #31
    //   1055: ldc_w 'partner_data'
    //   1058: aload_1
    //   1059: getfield AFKeystoreWrapper : Ljava/util/Map;
    //   1062: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1067: pop
    //   1068: aload_1
    //   1069: getfield AFInAppEventType : Ljava/util/Map;
    //   1072: invokeinterface isEmpty : ()Z
    //   1077: ifne -> 1121
    //   1080: aload #31
    //   1082: invokestatic valueOf : (Ljava/util/Map;)Ljava/util/Map;
    //   1085: ldc_w 'partner_data'
    //   1088: aload_1
    //   1089: getfield AFInAppEventType : Ljava/util/Map;
    //   1092: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1097: pop
    //   1098: aload_1
    //   1099: new java/util/HashMap
    //   1102: dup
    //   1103: invokespecial <init> : ()V
    //   1106: putfield AFInAppEventType : Ljava/util/Map;
    //   1109: goto -> 1121
    //   1112: aload #17
    //   1114: aload #31
    //   1116: aload #16
    //   1118: invokestatic AFKeystoreWrapper : (Landroid/content/Context;Ljava/util/Map;Ljava/lang/String;)V
    //   1121: ldc_w 'KSAppsFlyerId'
    //   1124: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1127: astore_1
    //   1128: ldc_w 'KSAppsFlyerRICounter'
    //   1131: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1134: astore #23
    //   1136: aload_1
    //   1137: ifnull -> 1181
    //   1140: aload #23
    //   1142: ifnull -> 1181
    //   1145: aload #23
    //   1147: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1150: invokevirtual intValue : ()I
    //   1153: ifle -> 1181
    //   1156: aload #31
    //   1158: ldc_w 'reinstallCounter'
    //   1161: aload #23
    //   1163: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1168: pop
    //   1169: aload #31
    //   1171: ldc_w 'originalAppsflyerId'
    //   1174: aload_1
    //   1175: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1180: pop
    //   1181: ldc_w 'additionalCustomData'
    //   1184: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1187: astore_1
    //   1188: aload_1
    //   1189: ifnull -> 1204
    //   1192: aload #31
    //   1194: ldc_w 'customData'
    //   1197: aload_1
    //   1198: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1203: pop
    //   1204: aload #17
    //   1206: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   1209: aload #17
    //   1211: invokevirtual getPackageName : ()Ljava/lang/String;
    //   1214: invokevirtual getInstallerPackageName : (Ljava/lang/String;)Ljava/lang/String;
    //   1217: astore_1
    //   1218: aload_1
    //   1219: ifnull -> 1245
    //   1222: aload #31
    //   1224: ldc_w 'installer_package'
    //   1227: aload_1
    //   1228: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1233: pop
    //   1234: goto -> 1245
    //   1237: astore_1
    //   1238: ldc_w 'Exception while getting the app's installer package. '
    //   1241: aload_1
    //   1242: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1245: aload #32
    //   1247: ldc_w 'sdkExtension'
    //   1250: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1253: astore_1
    //   1254: aload_1
    //   1255: ifnull -> 1277
    //   1258: aload_1
    //   1259: invokevirtual length : ()I
    //   1262: ifle -> 1277
    //   1265: aload #31
    //   1267: ldc_w 'sdkExtension'
    //   1270: aload_1
    //   1271: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1276: pop
    //   1277: aload #19
    //   1279: aload #17
    //   1281: invokevirtual AFInAppEventParameterName : (Landroid/content/Context;)Ljava/lang/String;
    //   1284: astore_1
    //   1285: aload #19
    //   1287: aload #17
    //   1289: invokevirtual values : (Landroid/content/Context;)Lcom/appsflyer/internal/AFc1xSDK;
    //   1292: aload_1
    //   1293: invokestatic values : (Lcom/appsflyer/internal/AFc1xSDK;Ljava/lang/String;)Ljava/lang/String;
    //   1296: astore #23
    //   1298: aload #23
    //   1300: ifnull -> 5791
    //   1303: aload #23
    //   1305: aload_1
    //   1306: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1309: ifeq -> 1315
    //   1312: goto -> 5791
    //   1315: aload #31
    //   1317: ldc_w 'af_latestchannel'
    //   1320: aload_1
    //   1321: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1326: pop
    //   1327: aload #19
    //   1329: aload #17
    //   1331: invokespecial AFLogger$LogLevel : (Landroid/content/Context;)Ljava/lang/String;
    //   1334: astore_1
    //   1335: aload_1
    //   1336: ifnull -> 1357
    //   1339: aload #31
    //   1341: ldc_w 'af_installstore'
    //   1344: aload_1
    //   1345: invokestatic getDefault : ()Ljava/util/Locale;
    //   1348: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1351: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1356: pop
    //   1357: aload #19
    //   1359: aload #17
    //   1361: invokespecial AFVersionDeclaration : (Landroid/content/Context;)Ljava/lang/String;
    //   1364: astore_1
    //   1365: aload_1
    //   1366: ifnull -> 1387
    //   1369: aload #31
    //   1371: ldc_w 'af_preinstall_name'
    //   1374: aload_1
    //   1375: invokestatic getDefault : ()Ljava/util/Locale;
    //   1378: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1381: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1386: pop
    //   1387: aload #19
    //   1389: aload #17
    //   1391: invokespecial getLevel : (Landroid/content/Context;)Ljava/lang/String;
    //   1394: astore_1
    //   1395: aload_1
    //   1396: ifnull -> 1417
    //   1399: aload #31
    //   1401: ldc_w 'af_currentstore'
    //   1404: aload_1
    //   1405: invokestatic getDefault : ()Ljava/util/Locale;
    //   1408: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1411: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1416: pop
    //   1417: aload #22
    //   1419: ifnull -> 1446
    //   1422: aload #22
    //   1424: invokevirtual length : ()I
    //   1427: ifle -> 1446
    //   1430: aload #31
    //   1432: ldc_w 'appsflyerKey'
    //   1435: aload #22
    //   1437: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1442: pop
    //   1443: goto -> 1482
    //   1446: aload_0
    //   1447: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   1450: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   1455: getfield AFInAppEventType : Ljava/lang/String;
    //   1458: astore_1
    //   1459: aload_1
    //   1460: ifnull -> 5754
    //   1463: aload_1
    //   1464: invokevirtual length : ()I
    //   1467: ifle -> 5754
    //   1470: aload #31
    //   1472: ldc_w 'appsflyerKey'
    //   1475: aload_1
    //   1476: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1481: pop
    //   1482: invokestatic valueOf : ()Ljava/lang/String;
    //   1485: astore_1
    //   1486: aload_1
    //   1487: ifnull -> 1502
    //   1490: aload #31
    //   1492: ldc_w 'appUserId'
    //   1495: aload_1
    //   1496: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1501: pop
    //   1502: aload #32
    //   1504: ldc_w 'userEmails'
    //   1507: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1510: astore_1
    //   1511: aload_1
    //   1512: ifnull -> 1530
    //   1515: aload #31
    //   1517: ldc_w 'user_emails'
    //   1520: aload_1
    //   1521: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1526: pop
    //   1527: goto -> 1556
    //   1530: ldc_w 'userEmail'
    //   1533: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1536: astore_1
    //   1537: aload_1
    //   1538: ifnull -> 1556
    //   1541: aload #31
    //   1543: ldc_w 'sha1_el'
    //   1546: aload_1
    //   1547: invokestatic values : (Ljava/lang/String;)Ljava/lang/String;
    //   1550: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1555: pop
    //   1556: aload #16
    //   1558: ifnull -> 1587
    //   1561: aload #31
    //   1563: ldc_w 'eventName'
    //   1566: aload #16
    //   1568: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1573: pop
    //   1574: aload #31
    //   1576: ldc_w 'eventValue'
    //   1579: aload #21
    //   1581: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1586: pop
    //   1587: invokestatic AFLogger : ()Ljava/lang/String;
    //   1590: ifnull -> 1610
    //   1593: aload #31
    //   1595: ldc_w 'appid'
    //   1598: ldc_w 'appid'
    //   1601: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1604: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1609: pop
    //   1610: ldc_w 'currencyCode'
    //   1613: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1616: astore_1
    //   1617: aload_1
    //   1618: ifnull -> 1677
    //   1621: aload_1
    //   1622: invokevirtual length : ()I
    //   1625: iconst_3
    //   1626: if_icmpeq -> 1665
    //   1629: new java/lang/StringBuilder
    //   1632: dup
    //   1633: ldc_w 'WARNING: currency code should be 3 characters!!! ''
    //   1636: invokespecial <init> : (Ljava/lang/String;)V
    //   1639: astore #21
    //   1641: aload #21
    //   1643: aload_1
    //   1644: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1647: pop
    //   1648: aload #21
    //   1650: ldc_w '' is not a legal value.'
    //   1653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1656: pop
    //   1657: aload #21
    //   1659: invokevirtual toString : ()Ljava/lang/String;
    //   1662: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   1665: aload #31
    //   1667: ldc_w 'currency'
    //   1670: aload_1
    //   1671: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1676: pop
    //   1677: ldc_w 'IS_UPDATE'
    //   1680: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   1683: astore_1
    //   1684: aload_1
    //   1685: ifnull -> 1700
    //   1688: aload #31
    //   1690: ldc_w 'isUpdate'
    //   1693: aload_1
    //   1694: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1699: pop
    //   1700: aload #31
    //   1702: ldc_w 'af_preinstalled'
    //   1705: aload #19
    //   1707: aload #17
    //   1709: invokevirtual isPreInstalledApp : (Landroid/content/Context;)Z
    //   1712: invokestatic toString : (Z)Ljava/lang/String;
    //   1715: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1720: pop
    //   1721: aload #32
    //   1723: ldc_w 'collectFacebookAttrId'
    //   1726: iconst_1
    //   1727: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   1730: istore #8
    //   1732: iload #8
    //   1734: ifeq -> 1811
    //   1737: aload #17
    //   1739: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   1742: astore_1
    //   1743: aload_1
    //   1744: ldc_w 'com.facebook.katana'
    //   1747: iconst_0
    //   1748: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   1751: pop
    //   1752: aload #19
    //   1754: aload #17
    //   1756: invokevirtual getAttributionId : (Landroid/content/Context;)Ljava/lang/String;
    //   1759: astore_1
    //   1760: goto -> 1795
    //   1763: astore_1
    //   1764: goto -> 1778
    //   1767: astore_1
    //   1768: ldc_w 'Exception while collecting facebook's attribution ID. '
    //   1771: aload_1
    //   1772: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1775: goto -> 5803
    //   1778: ldc_w 'com.facebook.katana not found'
    //   1781: aload_1
    //   1782: iconst_1
    //   1783: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;Z)V
    //   1786: ldc_w 'Exception while collecting facebook's attribution ID. '
    //   1789: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   1792: goto -> 5803
    //   1795: aload_1
    //   1796: ifnull -> 1811
    //   1799: aload #31
    //   1801: ldc_w 'fb'
    //   1804: aload_1
    //   1805: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1810: pop
    //   1811: aload #19
    //   1813: aload #17
    //   1815: aload #31
    //   1817: invokespecial values : (Landroid/content/Context;Ljava/util/Map;)V
    //   1820: new java/lang/ref/WeakReference
    //   1823: dup
    //   1824: aload #17
    //   1826: invokespecial <init> : (Ljava/lang/Object;)V
    //   1829: invokestatic AFInAppEventParameterName : (Ljava/lang/ref/WeakReference;)Ljava/lang/String;
    //   1832: astore_1
    //   1833: aload_1
    //   1834: ifnull -> 1884
    //   1837: aload #31
    //   1839: ldc_w 'uid'
    //   1842: aload_1
    //   1843: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1848: pop
    //   1849: goto -> 1884
    //   1852: astore_1
    //   1853: new java/lang/StringBuilder
    //   1856: dup
    //   1857: ldc_w 'ERROR: could not get uid '
    //   1860: invokespecial <init> : (Ljava/lang/String;)V
    //   1863: astore #21
    //   1865: aload #21
    //   1867: aload_1
    //   1868: invokevirtual getMessage : ()Ljava/lang/String;
    //   1871: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1874: pop
    //   1875: aload #21
    //   1877: invokevirtual toString : ()Ljava/lang/String;
    //   1880: aload_1
    //   1881: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1884: aload #31
    //   1886: ldc_w 'lang'
    //   1889: invokestatic getDefault : ()Ljava/util/Locale;
    //   1892: invokevirtual getDisplayLanguage : ()Ljava/lang/String;
    //   1895: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1900: pop
    //   1901: goto -> 1912
    //   1904: astore_1
    //   1905: ldc_w 'Exception while collecting display language name. '
    //   1908: aload_1
    //   1909: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1912: aload #31
    //   1914: ldc_w 'lang_code'
    //   1917: invokestatic getDefault : ()Ljava/util/Locale;
    //   1920: invokevirtual getLanguage : ()Ljava/lang/String;
    //   1923: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1928: pop
    //   1929: goto -> 1940
    //   1932: astore_1
    //   1933: ldc_w 'Exception while collecting display language code. '
    //   1936: aload_1
    //   1937: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1940: aload #31
    //   1942: ldc_w 'country'
    //   1945: invokestatic getDefault : ()Ljava/util/Locale;
    //   1948: invokevirtual getCountry : ()Ljava/lang/String;
    //   1951: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1956: pop
    //   1957: goto -> 1968
    //   1960: astore_1
    //   1961: ldc_w 'Exception while collecting country name. '
    //   1964: aload_1
    //   1965: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1968: aload #19
    //   1970: aload #31
    //   1972: iload #7
    //   1974: invokespecial values : (Ljava/util/Map;Z)V
    //   1977: aload #19
    //   1979: aload #17
    //   1981: aload #31
    //   1983: invokevirtual AFKeystoreWrapper : (Landroid/content/Context;Ljava/util/Map;)V
    //   1986: new java/text/SimpleDateFormat
    //   1989: dup
    //   1990: ldc_w 'yyyy-MM-dd_HHmmssZ'
    //   1993: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   1996: invokespecial <init> : (Ljava/lang/String;Ljava/util/Locale;)V
    //   1999: astore_1
    //   2000: aload #31
    //   2002: ldc_w 'installDate'
    //   2005: aload_1
    //   2006: aload #17
    //   2008: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   2011: aload #17
    //   2013: invokevirtual getPackageName : ()Ljava/lang/String;
    //   2016: iconst_0
    //   2017: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   2020: getfield firstInstallTime : J
    //   2023: invokestatic AFKeystoreWrapper : (Ljava/text/SimpleDateFormat;J)Ljava/lang/String;
    //   2026: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2031: pop
    //   2032: goto -> 2045
    //   2035: astore #21
    //   2037: ldc_w 'Exception while collecting install date. '
    //   2040: aload #21
    //   2042: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   2045: aload #17
    //   2047: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   2050: aload #17
    //   2052: invokevirtual getPackageName : ()Ljava/lang/String;
    //   2055: iconst_0
    //   2056: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   2059: astore #21
    //   2061: aload #18
    //   2063: ldc_w 'versionCode'
    //   2066: iconst_0
    //   2067: invokeinterface getInt : (Ljava/lang/String;I)I
    //   2072: istore #4
    //   2074: aload #21
    //   2076: getfield versionCode : I
    //   2079: iload #4
    //   2081: if_icmple -> 2104
    //   2084: aload #19
    //   2086: aload #17
    //   2088: invokevirtual values : (Landroid/content/Context;)Lcom/appsflyer/internal/AFc1xSDK;
    //   2091: ldc_w 'versionCode'
    //   2094: aload #21
    //   2096: getfield versionCode : I
    //   2099: invokeinterface valueOf : (Ljava/lang/String;I)V
    //   2104: aload_0
    //   2105: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   2108: invokeinterface AFInAppEventParameterName : ()Lcom/appsflyer/internal/AFb1bSDK;
    //   2113: astore #22
    //   2115: aload #31
    //   2117: ldc_w 'app_version_code'
    //   2120: aload #21
    //   2122: getfield versionCode : I
    //   2125: invokestatic toString : (I)Ljava/lang/String;
    //   2128: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2133: pop
    //   2134: aload #31
    //   2136: ldc_w 'app_version_name'
    //   2139: aload #22
    //   2141: getfield values : Lcom/appsflyer/internal/AFc1wSDK;
    //   2144: getfield AFKeystoreWrapper : Landroid/content/Context;
    //   2147: aload #22
    //   2149: getfield values : Lcom/appsflyer/internal/AFc1wSDK;
    //   2152: getfield AFKeystoreWrapper : Landroid/content/Context;
    //   2155: invokevirtual getPackageName : ()Ljava/lang/String;
    //   2158: invokestatic AFInAppEventParameterName : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   2161: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2166: pop
    //   2167: aload #31
    //   2169: ldc_w 'targetSDKver'
    //   2172: aload #22
    //   2174: getfield values : Lcom/appsflyer/internal/AFc1wSDK;
    //   2177: getfield AFKeystoreWrapper : Landroid/content/Context;
    //   2180: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   2183: getfield targetSdkVersion : I
    //   2186: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   2189: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2194: pop
    //   2195: aload #21
    //   2197: getfield firstInstallTime : J
    //   2200: lstore #10
    //   2202: aload #21
    //   2204: getfield lastUpdateTime : J
    //   2207: lstore #12
    //   2209: aload #31
    //   2211: ldc_w 'date1'
    //   2214: new java/text/SimpleDateFormat
    //   2217: dup
    //   2218: ldc_w 'yyyy-MM-dd_HHmmssZ'
    //   2221: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   2224: invokespecial <init> : (Ljava/lang/String;Ljava/util/Locale;)V
    //   2227: new java/util/Date
    //   2230: dup
    //   2231: lload #10
    //   2233: invokespecial <init> : (J)V
    //   2236: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   2239: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2244: pop
    //   2245: aload #31
    //   2247: ldc_w 'date2'
    //   2250: new java/text/SimpleDateFormat
    //   2253: dup
    //   2254: ldc_w 'yyyy-MM-dd_HHmmssZ'
    //   2257: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   2260: invokespecial <init> : (Ljava/lang/String;Ljava/util/Locale;)V
    //   2263: new java/util/Date
    //   2266: dup
    //   2267: lload #12
    //   2269: invokespecial <init> : (J)V
    //   2272: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   2275: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2280: pop
    //   2281: aload #19
    //   2283: aload_1
    //   2284: aload #17
    //   2286: invokespecial AFKeystoreWrapper : (Ljava/text/SimpleDateFormat;Landroid/content/Context;)Ljava/lang/String;
    //   2289: astore_1
    //   2290: invokestatic getPressedStateDuration : ()I
    //   2293: istore #4
    //   2295: ldc ''
    //   2297: bipush #48
    //   2299: iconst_0
    //   2300: invokestatic indexOf : (Ljava/lang/CharSequence;CI)I
    //   2303: istore #5
    //   2305: invokestatic getWindowTouchSlop : ()I
    //   2308: istore #6
    //   2310: iconst_1
    //   2311: anewarray java/lang/Object
    //   2314: astore #21
    //   2316: bipush #12
    //   2318: iload #4
    //   2320: bipush #16
    //   2322: ishr
    //   2323: isub
    //   2324: ldc_w '￞�\\b￻￦\\r\\f ￿￻'
    //   2327: sipush #284
    //   2330: iload #5
    //   2332: isub
    //   2333: iload #6
    //   2335: bipush #8
    //   2337: ishr
    //   2338: bipush #15
    //   2340: iadd
    //   2341: iconst_1
    //   2342: aload #21
    //   2344: invokestatic AFKeystoreWrapper : (ILjava/lang/String;IIZ[Ljava/lang/Object;)V
    //   2347: aload #31
    //   2349: aload #21
    //   2351: iconst_0
    //   2352: aaload
    //   2353: checkcast java/lang/String
    //   2356: invokevirtual intern : ()Ljava/lang/String;
    //   2359: aload_1
    //   2360: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2365: pop
    //   2366: goto -> 2386
    //   2369: astore_1
    //   2370: goto -> 2378
    //   2373: astore_1
    //   2374: goto -> 2378
    //   2377: astore_1
    //   2378: ldc_w 'Exception while collecting app version data '
    //   2381: aload_1
    //   2382: iconst_1
    //   2383: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;Z)V
    //   2386: aload #19
    //   2388: aload #17
    //   2390: invokestatic AFKeystoreWrapper : (Landroid/content/Context;)Z
    //   2393: putfield AppsFlyer2dXConversionCallback : Z
    //   2396: new java/lang/StringBuilder
    //   2399: dup
    //   2400: ldc_w 'didConfigureTokenRefreshService='
    //   2403: invokespecial <init> : (Ljava/lang/String;)V
    //   2406: astore_1
    //   2407: aload_1
    //   2408: aload #19
    //   2410: getfield AppsFlyer2dXConversionCallback : Z
    //   2413: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   2416: pop
    //   2417: aload_1
    //   2418: invokevirtual toString : ()Ljava/lang/String;
    //   2421: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   2424: aload #19
    //   2426: getfield AppsFlyer2dXConversionCallback : Z
    //   2429: ifne -> 2446
    //   2432: aload #31
    //   2434: ldc_w 'tokenRefreshConfigured'
    //   2437: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   2440: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2445: pop
    //   2446: iload #7
    //   2448: ifeq -> 2539
    //   2451: aload #19
    //   2453: getfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   2456: ifnull -> 2520
    //   2459: aload #31
    //   2461: ldc_w 'af_deeplink'
    //   2464: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2469: ifnull -> 2481
    //   2472: ldc_w 'Skip 'af' payload as deeplink was found by path'
    //   2475: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   2478: goto -> 2520
    //   2481: new org/json/JSONObject
    //   2484: dup
    //   2485: aload #19
    //   2487: getfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   2490: invokespecial <init> : (Ljava/lang/String;)V
    //   2493: astore_1
    //   2494: aload_1
    //   2495: ldc_w 'isPush'
    //   2498: ldc_w 'true'
    //   2501: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   2504: pop
    //   2505: aload #31
    //   2507: ldc_w 'af_deeplink'
    //   2510: aload_1
    //   2511: invokevirtual toString : ()Ljava/lang/String;
    //   2514: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2519: pop
    //   2520: aload #19
    //   2522: aconst_null
    //   2523: putfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   2526: aload #31
    //   2528: ldc_w 'open_referrer'
    //   2531: aload #20
    //   2533: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2538: pop
    //   2539: iload #7
    //   2541: ifne -> 5856
    //   2544: iload #7
    //   2546: istore #8
    //   2548: aload #18
    //   2550: astore #23
    //   2552: aload #17
    //   2554: astore #20
    //   2556: aload #16
    //   2558: astore #19
    //   2560: aload #17
    //   2562: invokestatic AFInAppEventType : (Landroid/content/Context;)Lcom/appsflyer/internal/AFa1dSDK;
    //   2565: astore_1
    //   2566: iload #7
    //   2568: istore #8
    //   2570: aload #18
    //   2572: astore #23
    //   2574: aload #17
    //   2576: astore #20
    //   2578: aload #16
    //   2580: astore #19
    //   2582: new java/util/concurrent/ConcurrentHashMap
    //   2585: dup
    //   2586: invokespecial <init> : ()V
    //   2589: astore #22
    //   2591: iload #7
    //   2593: istore #8
    //   2595: aload #18
    //   2597: astore #23
    //   2599: aload #17
    //   2601: astore #20
    //   2603: aload #16
    //   2605: astore #19
    //   2607: aload_1
    //   2608: invokevirtual AFKeystoreWrapper : ()Ljava/util/List;
    //   2611: astore_1
    //   2612: iload #7
    //   2614: istore #8
    //   2616: aload #18
    //   2618: astore #23
    //   2620: aload #17
    //   2622: astore #20
    //   2624: aload #16
    //   2626: astore #19
    //   2628: aload_1
    //   2629: invokeinterface isEmpty : ()Z
    //   2634: ifne -> 5009
    //   2637: iload #7
    //   2639: istore #8
    //   2641: aload #18
    //   2643: astore #23
    //   2645: aload #17
    //   2647: astore #20
    //   2649: aload #16
    //   2651: astore #19
    //   2653: new com/appsflyer/internal/AFa1uSDK
    //   2656: dup
    //   2657: invokespecial <init> : ()V
    //   2660: pop
    //   2661: ldc_w 'n'
    //   2664: astore #25
    //   2666: ldc_w 'uk'
    //   2669: astore #24
    //   2671: iload #7
    //   2673: istore #8
    //   2675: aload #18
    //   2677: astore #23
    //   2679: aload #17
    //   2681: astore #20
    //   2683: aload #16
    //   2685: astore #19
    //   2687: new java/util/HashMap
    //   2690: dup
    //   2691: invokespecial <init> : ()V
    //   2694: astore #29
    //   2696: iload #7
    //   2698: istore #8
    //   2700: aload #18
    //   2702: astore #23
    //   2704: aload #17
    //   2706: astore #20
    //   2708: aload #16
    //   2710: astore #19
    //   2712: aload_1
    //   2713: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2718: astore #26
    //   2720: aload #16
    //   2722: astore #21
    //   2724: aload #17
    //   2726: astore_1
    //   2727: aload #18
    //   2729: astore #16
    //   2731: iload #7
    //   2733: istore #8
    //   2735: aload #16
    //   2737: astore #23
    //   2739: aload_1
    //   2740: astore #20
    //   2742: aload #21
    //   2744: astore #19
    //   2746: aload #26
    //   2748: invokeinterface hasNext : ()Z
    //   2753: ifeq -> 5849
    //   2756: iload #7
    //   2758: istore #8
    //   2760: aload #16
    //   2762: astore #23
    //   2764: aload_1
    //   2765: astore #20
    //   2767: aload #21
    //   2769: astore #19
    //   2771: aload #26
    //   2773: invokeinterface next : ()Ljava/lang/Object;
    //   2778: checkcast java/util/Map
    //   2781: astore #17
    //   2783: iload #7
    //   2785: istore #8
    //   2787: aload #16
    //   2789: astore #23
    //   2791: aload_1
    //   2792: astore #20
    //   2794: aload #21
    //   2796: astore #19
    //   2798: new java/util/HashMap
    //   2801: dup
    //   2802: invokespecial <init> : ()V
    //   2805: astore #33
    //   2807: iload #7
    //   2809: istore #8
    //   2811: aload #16
    //   2813: astore #23
    //   2815: aload_1
    //   2816: astore #20
    //   2818: aload #21
    //   2820: astore #19
    //   2822: aload #17
    //   2824: ldc_w 'sVS'
    //   2827: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2832: astore #18
    //   2834: aload #21
    //   2836: astore #19
    //   2838: aload #18
    //   2840: ifnull -> 2849
    //   2843: iconst_1
    //   2844: istore #4
    //   2846: goto -> 2852
    //   2849: iconst_0
    //   2850: istore #4
    //   2852: aload #17
    //   2854: ldc_w 'sVE'
    //   2857: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2862: astore #18
    //   2864: aload #18
    //   2866: ifnull -> 2875
    //   2869: iconst_1
    //   2870: istore #5
    //   2872: goto -> 2878
    //   2875: iconst_0
    //   2876: istore #5
    //   2878: iload #4
    //   2880: ifeq -> 2896
    //   2883: iload #5
    //   2885: ifeq -> 2896
    //   2888: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.AFInAppEventType : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   2891: astore #23
    //   2893: goto -> 2929
    //   2896: iload #4
    //   2898: ifeq -> 2924
    //   2901: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.values : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   2904: astore #23
    //   2906: goto -> 2929
    //   2909: astore #18
    //   2911: aload #16
    //   2913: astore #17
    //   2915: aload_1
    //   2916: astore #16
    //   2918: aload #18
    //   2920: astore_1
    //   2921: goto -> 5113
    //   2924: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.AFKeystoreWrapper : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   2927: astore #23
    //   2929: aload #23
    //   2931: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.AFKeystoreWrapper : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   2934: if_acmpeq -> 4891
    //   2937: aload #17
    //   2939: ldc_w 'sT'
    //   2942: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2947: checkcast java/lang/Integer
    //   2950: astore #34
    //   2952: aload #17
    //   2954: ldc_w 'sN'
    //   2957: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2962: checkcast java/lang/String
    //   2965: astore #18
    //   2967: aload #18
    //   2969: ifnull -> 2987
    //   2972: aload #33
    //   2974: aload #25
    //   2976: aload #18
    //   2978: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2983: pop
    //   2984: goto -> 2999
    //   2987: aload #33
    //   2989: aload #25
    //   2991: aload #24
    //   2993: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2998: pop
    //   2999: invokestatic values : ()[Lcom/appsflyer/internal/AFa1uSDK$AFa1wSDK;
    //   3002: aload #34
    //   3004: invokevirtual intValue : ()I
    //   3007: aaload
    //   3008: astore #18
    //   3010: new java/util/ArrayList
    //   3013: dup
    //   3014: aload #17
    //   3016: ldc_w 'sVS'
    //   3019: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   3024: invokestatic AFInAppEventParameterName : (Ljava/lang/Object;)Ljava/util/List;
    //   3027: invokespecial <init> : (Ljava/util/Collection;)V
    //   3030: astore #30
    //   3032: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.AFInAppEventType : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   3035: astore #20
    //   3037: aload #23
    //   3039: aload #20
    //   3041: if_acmpne -> 3065
    //   3044: aload #30
    //   3046: aload #17
    //   3048: ldc_w 'sVE'
    //   3051: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   3056: invokestatic AFInAppEventParameterName : (Ljava/lang/Object;)Ljava/util/List;
    //   3059: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   3064: pop
    //   3065: getstatic com/appsflyer/internal/AFa1uSDK$AFa1wSDK.AFInAppEventParameterName : Lcom/appsflyer/internal/AFa1uSDK$AFa1wSDK;
    //   3068: astore #17
    //   3070: aload #18
    //   3072: aload #17
    //   3074: if_acmpne -> 3849
    //   3077: new java/util/ArrayList
    //   3080: dup
    //   3081: invokespecial <init> : ()V
    //   3084: astore #35
    //   3086: aload #30
    //   3088: iconst_0
    //   3089: invokeinterface get : (I)Ljava/lang/Object;
    //   3094: checkcast java/math/BigDecimal
    //   3097: astore #17
    //   3099: aload #30
    //   3101: iconst_1
    //   3102: invokeinterface get : (I)Ljava/lang/Object;
    //   3107: checkcast java/math/BigDecimal
    //   3110: astore #36
    //   3112: iload #7
    //   3114: istore #9
    //   3116: aload #17
    //   3118: invokevirtual doubleValue : ()D
    //   3121: dstore_2
    //   3122: aload #16
    //   3124: astore #21
    //   3126: aload_1
    //   3127: astore #27
    //   3129: aload #19
    //   3131: astore #20
    //   3133: aload #27
    //   3135: astore #18
    //   3137: iload #9
    //   3139: istore #8
    //   3141: aload #21
    //   3143: astore #17
    //   3145: aload #36
    //   3147: invokevirtual doubleValue : ()D
    //   3150: dload_2
    //   3151: invokestatic atan2 : (DD)D
    //   3154: ldc2_w 57.29577951308232
    //   3157: dmul
    //   3158: invokestatic valueOf : (D)Ljava/math/BigDecimal;
    //   3161: astore #37
    //   3163: aload #19
    //   3165: astore #20
    //   3167: aload #27
    //   3169: astore #18
    //   3171: iload #9
    //   3173: istore #8
    //   3175: aload #21
    //   3177: astore #17
    //   3179: new java/text/DecimalFormat
    //   3182: dup
    //   3183: ldc_w '##.#'
    //   3186: invokespecial <init> : (Ljava/lang/String;)V
    //   3189: astore #36
    //   3191: aload #19
    //   3193: astore #20
    //   3195: aload #27
    //   3197: astore #18
    //   3199: iload #9
    //   3201: istore #8
    //   3203: aload #21
    //   3205: astore #17
    //   3207: aload #36
    //   3209: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   3212: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   3215: aload #19
    //   3217: astore #20
    //   3219: aload #27
    //   3221: astore #18
    //   3223: iload #9
    //   3225: istore #8
    //   3227: aload #21
    //   3229: astore #17
    //   3231: aload #35
    //   3233: aload #36
    //   3235: aload #37
    //   3237: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   3240: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   3243: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3246: invokeinterface add : (Ljava/lang/Object;)Z
    //   3251: pop
    //   3252: aload #19
    //   3254: astore #20
    //   3256: aload #27
    //   3258: astore #18
    //   3260: iload #9
    //   3262: istore #8
    //   3264: aload #21
    //   3266: astore #17
    //   3268: aload #30
    //   3270: iconst_2
    //   3271: invokeinterface get : (I)Ljava/lang/Object;
    //   3276: checkcast java/math/BigDecimal
    //   3279: astore #36
    //   3281: aload #19
    //   3283: astore #20
    //   3285: aload #27
    //   3287: astore #18
    //   3289: iload #9
    //   3291: istore #8
    //   3293: aload #21
    //   3295: astore #17
    //   3297: new java/text/DecimalFormat
    //   3300: dup
    //   3301: ldc_w '##.#'
    //   3304: invokespecial <init> : (Ljava/lang/String;)V
    //   3307: astore #38
    //   3309: aload #19
    //   3311: astore #20
    //   3313: aload #27
    //   3315: astore #18
    //   3317: iload #9
    //   3319: istore #8
    //   3321: aload #21
    //   3323: astore #17
    //   3325: aload #38
    //   3327: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   3330: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   3333: aload #19
    //   3335: astore #20
    //   3337: aload #27
    //   3339: astore #18
    //   3341: iload #9
    //   3343: istore #8
    //   3345: aload #21
    //   3347: astore #17
    //   3349: aload #35
    //   3351: aload #38
    //   3353: aload #36
    //   3355: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   3358: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   3361: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3364: invokeinterface add : (Ljava/lang/Object;)Z
    //   3369: pop
    //   3370: aload #19
    //   3372: astore #20
    //   3374: aload #27
    //   3376: astore #18
    //   3378: iload #9
    //   3380: istore #8
    //   3382: aload #21
    //   3384: astore #17
    //   3386: new java/util/ArrayList
    //   3389: dup
    //   3390: invokespecial <init> : ()V
    //   3393: astore #36
    //   3395: aload #19
    //   3397: astore #20
    //   3399: aload #27
    //   3401: astore #18
    //   3403: iload #9
    //   3405: istore #8
    //   3407: aload #21
    //   3409: astore #17
    //   3411: aload #30
    //   3413: invokeinterface size : ()I
    //   3418: iconst_5
    //   3419: if_icmple -> 5812
    //   3422: aload #19
    //   3424: astore #20
    //   3426: aload #27
    //   3428: astore #18
    //   3430: iload #9
    //   3432: istore #8
    //   3434: aload #21
    //   3436: astore #17
    //   3438: aload #30
    //   3440: iconst_3
    //   3441: invokeinterface get : (I)Ljava/lang/Object;
    //   3446: checkcast java/math/BigDecimal
    //   3449: astore #38
    //   3451: aload #19
    //   3453: astore #20
    //   3455: aload #27
    //   3457: astore #18
    //   3459: iload #9
    //   3461: istore #8
    //   3463: aload #21
    //   3465: astore #17
    //   3467: aload #30
    //   3469: iconst_4
    //   3470: invokeinterface get : (I)Ljava/lang/Object;
    //   3475: checkcast java/math/BigDecimal
    //   3478: astore #39
    //   3480: aload #19
    //   3482: astore #20
    //   3484: aload #27
    //   3486: astore #18
    //   3488: iload #9
    //   3490: istore #8
    //   3492: aload #21
    //   3494: astore #17
    //   3496: aload #38
    //   3498: invokevirtual doubleValue : ()D
    //   3501: dstore_2
    //   3502: aload #19
    //   3504: astore #20
    //   3506: aload #27
    //   3508: astore #18
    //   3510: iload #9
    //   3512: istore #8
    //   3514: aload #21
    //   3516: astore #17
    //   3518: aload #39
    //   3520: invokevirtual doubleValue : ()D
    //   3523: dload_2
    //   3524: invokestatic atan2 : (DD)D
    //   3527: ldc2_w 57.29577951308232
    //   3530: dmul
    //   3531: invokestatic valueOf : (D)Ljava/math/BigDecimal;
    //   3534: aload #37
    //   3536: invokevirtual subtract : (Ljava/math/BigDecimal;)Ljava/math/BigDecimal;
    //   3539: astore #37
    //   3541: aload #19
    //   3543: astore #20
    //   3545: aload #27
    //   3547: astore #18
    //   3549: iload #9
    //   3551: istore #8
    //   3553: aload #21
    //   3555: astore #17
    //   3557: new java/text/DecimalFormat
    //   3560: dup
    //   3561: ldc_w '##.#'
    //   3564: invokespecial <init> : (Ljava/lang/String;)V
    //   3567: astore #38
    //   3569: aload #19
    //   3571: astore #20
    //   3573: aload #27
    //   3575: astore #18
    //   3577: iload #9
    //   3579: istore #8
    //   3581: aload #21
    //   3583: astore #17
    //   3585: aload #38
    //   3587: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   3590: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   3593: aload #19
    //   3595: astore #20
    //   3597: aload #27
    //   3599: astore #18
    //   3601: iload #9
    //   3603: istore #8
    //   3605: aload #21
    //   3607: astore #17
    //   3609: aload #36
    //   3611: aload #38
    //   3613: aload #37
    //   3615: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   3618: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   3621: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3624: invokeinterface add : (Ljava/lang/Object;)Z
    //   3629: pop
    //   3630: aload #19
    //   3632: astore #20
    //   3634: aload #27
    //   3636: astore #18
    //   3638: iload #9
    //   3640: istore #8
    //   3642: aload #21
    //   3644: astore #17
    //   3646: aload #30
    //   3648: iconst_5
    //   3649: invokeinterface get : (I)Ljava/lang/Object;
    //   3654: checkcast java/math/BigDecimal
    //   3657: aload #30
    //   3659: iconst_2
    //   3660: invokeinterface get : (I)Ljava/lang/Object;
    //   3665: checkcast java/math/BigDecimal
    //   3668: invokevirtual subtract : (Ljava/math/BigDecimal;)Ljava/math/BigDecimal;
    //   3671: astore #30
    //   3673: aload #19
    //   3675: astore #20
    //   3677: aload #27
    //   3679: astore #18
    //   3681: iload #9
    //   3683: istore #8
    //   3685: aload #21
    //   3687: astore #17
    //   3689: new java/text/DecimalFormat
    //   3692: dup
    //   3693: ldc_w '##.#'
    //   3696: invokespecial <init> : (Ljava/lang/String;)V
    //   3699: astore #37
    //   3701: aload #19
    //   3703: astore #20
    //   3705: aload #27
    //   3707: astore #18
    //   3709: iload #9
    //   3711: istore #8
    //   3713: aload #21
    //   3715: astore #17
    //   3717: aload #37
    //   3719: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   3722: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   3725: aload #19
    //   3727: astore #20
    //   3729: aload #27
    //   3731: astore #18
    //   3733: iload #9
    //   3735: istore #8
    //   3737: aload #21
    //   3739: astore #17
    //   3741: aload #36
    //   3743: aload #37
    //   3745: aload #30
    //   3747: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   3750: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   3753: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3756: invokeinterface add : (Ljava/lang/Object;)Z
    //   3761: pop
    //   3762: goto -> 3765
    //   3765: aload #19
    //   3767: astore #20
    //   3769: aload #27
    //   3771: astore #18
    //   3773: iload #9
    //   3775: istore #8
    //   3777: aload #21
    //   3779: astore #17
    //   3781: new java/util/ArrayList
    //   3784: dup
    //   3785: invokespecial <init> : ()V
    //   3788: astore #30
    //   3790: aload #19
    //   3792: astore #20
    //   3794: aload #27
    //   3796: astore #18
    //   3798: iload #9
    //   3800: istore #8
    //   3802: aload #21
    //   3804: astore #17
    //   3806: aload #30
    //   3808: aload #35
    //   3810: invokeinterface add : (Ljava/lang/Object;)Z
    //   3815: pop
    //   3816: aload #19
    //   3818: astore #20
    //   3820: aload #27
    //   3822: astore #18
    //   3824: iload #9
    //   3826: istore #8
    //   3828: aload #21
    //   3830: astore #17
    //   3832: aload #30
    //   3834: aload #36
    //   3836: invokeinterface add : (Ljava/lang/Object;)Z
    //   3841: pop
    //   3842: aload #30
    //   3844: astore #21
    //   3846: goto -> 4771
    //   3849: iload #7
    //   3851: istore #9
    //   3853: aload #16
    //   3855: astore #21
    //   3857: aload_1
    //   3858: astore #27
    //   3860: aload #19
    //   3862: astore #20
    //   3864: aload #27
    //   3866: astore #18
    //   3868: iload #9
    //   3870: istore #8
    //   3872: aload #21
    //   3874: astore #17
    //   3876: new java/util/ArrayList
    //   3879: dup
    //   3880: invokespecial <init> : ()V
    //   3883: astore #35
    //   3885: aload #19
    //   3887: astore #20
    //   3889: aload #27
    //   3891: astore #18
    //   3893: iload #9
    //   3895: istore #8
    //   3897: aload #21
    //   3899: astore #17
    //   3901: aload #30
    //   3903: invokeinterface size : ()I
    //   3908: iconst_5
    //   3909: if_icmple -> 5820
    //   3912: aload #19
    //   3914: astore #20
    //   3916: aload #27
    //   3918: astore #18
    //   3920: iload #9
    //   3922: istore #8
    //   3924: aload #21
    //   3926: astore #17
    //   3928: aload #30
    //   3930: iconst_3
    //   3931: invokeinterface get : (I)Ljava/lang/Object;
    //   3936: checkcast java/math/BigDecimal
    //   3939: aload #30
    //   3941: iconst_0
    //   3942: invokeinterface get : (I)Ljava/lang/Object;
    //   3947: checkcast java/math/BigDecimal
    //   3950: invokevirtual subtract : (Ljava/math/BigDecimal;)Ljava/math/BigDecimal;
    //   3953: astore #36
    //   3955: aload #19
    //   3957: astore #20
    //   3959: aload #27
    //   3961: astore #18
    //   3963: iload #9
    //   3965: istore #8
    //   3967: aload #21
    //   3969: astore #17
    //   3971: new java/text/DecimalFormat
    //   3974: dup
    //   3975: ldc_w '##.#'
    //   3978: invokespecial <init> : (Ljava/lang/String;)V
    //   3981: astore #37
    //   3983: aload #19
    //   3985: astore #20
    //   3987: aload #27
    //   3989: astore #18
    //   3991: iload #9
    //   3993: istore #8
    //   3995: aload #21
    //   3997: astore #17
    //   3999: aload #37
    //   4001: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4004: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4007: aload #19
    //   4009: astore #20
    //   4011: aload #27
    //   4013: astore #18
    //   4015: iload #9
    //   4017: istore #8
    //   4019: aload #21
    //   4021: astore #17
    //   4023: aload #35
    //   4025: aload #37
    //   4027: aload #36
    //   4029: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4032: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4035: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4038: invokeinterface add : (Ljava/lang/Object;)Z
    //   4043: pop
    //   4044: aload #19
    //   4046: astore #20
    //   4048: aload #27
    //   4050: astore #18
    //   4052: iload #9
    //   4054: istore #8
    //   4056: aload #21
    //   4058: astore #17
    //   4060: aload #30
    //   4062: iconst_4
    //   4063: invokeinterface get : (I)Ljava/lang/Object;
    //   4068: checkcast java/math/BigDecimal
    //   4071: aload #30
    //   4073: iconst_1
    //   4074: invokeinterface get : (I)Ljava/lang/Object;
    //   4079: checkcast java/math/BigDecimal
    //   4082: invokevirtual subtract : (Ljava/math/BigDecimal;)Ljava/math/BigDecimal;
    //   4085: astore #36
    //   4087: aload #19
    //   4089: astore #20
    //   4091: aload #27
    //   4093: astore #18
    //   4095: iload #9
    //   4097: istore #8
    //   4099: aload #21
    //   4101: astore #17
    //   4103: new java/text/DecimalFormat
    //   4106: dup
    //   4107: ldc_w '##.#'
    //   4110: invokespecial <init> : (Ljava/lang/String;)V
    //   4113: astore #37
    //   4115: aload #19
    //   4117: astore #20
    //   4119: aload #27
    //   4121: astore #18
    //   4123: iload #9
    //   4125: istore #8
    //   4127: aload #21
    //   4129: astore #17
    //   4131: aload #37
    //   4133: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4136: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4139: aload #19
    //   4141: astore #20
    //   4143: aload #27
    //   4145: astore #18
    //   4147: iload #9
    //   4149: istore #8
    //   4151: aload #21
    //   4153: astore #17
    //   4155: aload #35
    //   4157: aload #37
    //   4159: aload #36
    //   4161: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4164: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4167: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4170: invokeinterface add : (Ljava/lang/Object;)Z
    //   4175: pop
    //   4176: aload #19
    //   4178: astore #20
    //   4180: aload #27
    //   4182: astore #18
    //   4184: iload #9
    //   4186: istore #8
    //   4188: aload #21
    //   4190: astore #17
    //   4192: aload #30
    //   4194: iconst_5
    //   4195: invokeinterface get : (I)Ljava/lang/Object;
    //   4200: checkcast java/math/BigDecimal
    //   4203: aload #30
    //   4205: iconst_2
    //   4206: invokeinterface get : (I)Ljava/lang/Object;
    //   4211: checkcast java/math/BigDecimal
    //   4214: invokevirtual subtract : (Ljava/math/BigDecimal;)Ljava/math/BigDecimal;
    //   4217: astore #36
    //   4219: aload #19
    //   4221: astore #20
    //   4223: aload #27
    //   4225: astore #18
    //   4227: iload #9
    //   4229: istore #8
    //   4231: aload #21
    //   4233: astore #17
    //   4235: new java/text/DecimalFormat
    //   4238: dup
    //   4239: ldc_w '##.#'
    //   4242: invokespecial <init> : (Ljava/lang/String;)V
    //   4245: astore #37
    //   4247: aload #19
    //   4249: astore #20
    //   4251: aload #27
    //   4253: astore #18
    //   4255: iload #9
    //   4257: istore #8
    //   4259: aload #21
    //   4261: astore #17
    //   4263: aload #37
    //   4265: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4268: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4271: aload #19
    //   4273: astore #20
    //   4275: aload #27
    //   4277: astore #18
    //   4279: iload #9
    //   4281: istore #8
    //   4283: aload #21
    //   4285: astore #17
    //   4287: aload #35
    //   4289: aload #37
    //   4291: aload #36
    //   4293: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4296: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4299: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4302: invokeinterface add : (Ljava/lang/Object;)Z
    //   4307: pop
    //   4308: goto -> 4311
    //   4311: aload #19
    //   4313: astore #20
    //   4315: aload #27
    //   4317: astore #18
    //   4319: iload #9
    //   4321: istore #8
    //   4323: aload #21
    //   4325: astore #17
    //   4327: new java/util/ArrayList
    //   4330: dup
    //   4331: invokespecial <init> : ()V
    //   4334: astore #36
    //   4336: aload #19
    //   4338: astore #20
    //   4340: aload #27
    //   4342: astore #18
    //   4344: iload #9
    //   4346: istore #8
    //   4348: aload #21
    //   4350: astore #17
    //   4352: aload #30
    //   4354: iconst_0
    //   4355: invokeinterface get : (I)Ljava/lang/Object;
    //   4360: checkcast java/math/BigDecimal
    //   4363: astore #37
    //   4365: aload #19
    //   4367: astore #20
    //   4369: aload #27
    //   4371: astore #18
    //   4373: iload #9
    //   4375: istore #8
    //   4377: aload #21
    //   4379: astore #17
    //   4381: new java/text/DecimalFormat
    //   4384: dup
    //   4385: ldc_w '##.#'
    //   4388: invokespecial <init> : (Ljava/lang/String;)V
    //   4391: astore #38
    //   4393: aload #19
    //   4395: astore #20
    //   4397: aload #27
    //   4399: astore #18
    //   4401: iload #9
    //   4403: istore #8
    //   4405: aload #21
    //   4407: astore #17
    //   4409: aload #38
    //   4411: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4414: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4417: aload #19
    //   4419: astore #20
    //   4421: aload #27
    //   4423: astore #18
    //   4425: iload #9
    //   4427: istore #8
    //   4429: aload #21
    //   4431: astore #17
    //   4433: aload #36
    //   4435: aload #38
    //   4437: aload #37
    //   4439: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4442: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4445: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4448: invokeinterface add : (Ljava/lang/Object;)Z
    //   4453: pop
    //   4454: aload #19
    //   4456: astore #20
    //   4458: aload #27
    //   4460: astore #18
    //   4462: iload #9
    //   4464: istore #8
    //   4466: aload #21
    //   4468: astore #17
    //   4470: aload #30
    //   4472: iconst_1
    //   4473: invokeinterface get : (I)Ljava/lang/Object;
    //   4478: checkcast java/math/BigDecimal
    //   4481: astore #37
    //   4483: aload #19
    //   4485: astore #20
    //   4487: aload #27
    //   4489: astore #18
    //   4491: iload #9
    //   4493: istore #8
    //   4495: aload #21
    //   4497: astore #17
    //   4499: new java/text/DecimalFormat
    //   4502: dup
    //   4503: ldc_w '##.#'
    //   4506: invokespecial <init> : (Ljava/lang/String;)V
    //   4509: astore #38
    //   4511: aload #19
    //   4513: astore #20
    //   4515: aload #27
    //   4517: astore #18
    //   4519: iload #9
    //   4521: istore #8
    //   4523: aload #21
    //   4525: astore #17
    //   4527: aload #38
    //   4529: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4532: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4535: aload #19
    //   4537: astore #20
    //   4539: aload #27
    //   4541: astore #18
    //   4543: iload #9
    //   4545: istore #8
    //   4547: aload #21
    //   4549: astore #17
    //   4551: aload #36
    //   4553: aload #38
    //   4555: aload #37
    //   4557: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4560: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4563: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4566: invokeinterface add : (Ljava/lang/Object;)Z
    //   4571: pop
    //   4572: aload #19
    //   4574: astore #20
    //   4576: aload #27
    //   4578: astore #18
    //   4580: iload #9
    //   4582: istore #8
    //   4584: aload #21
    //   4586: astore #17
    //   4588: aload #30
    //   4590: iconst_2
    //   4591: invokeinterface get : (I)Ljava/lang/Object;
    //   4596: checkcast java/math/BigDecimal
    //   4599: astore #30
    //   4601: aload #19
    //   4603: astore #20
    //   4605: aload #27
    //   4607: astore #18
    //   4609: iload #9
    //   4611: istore #8
    //   4613: aload #21
    //   4615: astore #17
    //   4617: new java/text/DecimalFormat
    //   4620: dup
    //   4621: ldc_w '##.#'
    //   4624: invokespecial <init> : (Ljava/lang/String;)V
    //   4627: astore #37
    //   4629: aload #19
    //   4631: astore #20
    //   4633: aload #27
    //   4635: astore #18
    //   4637: iload #9
    //   4639: istore #8
    //   4641: aload #21
    //   4643: astore #17
    //   4645: aload #37
    //   4647: getstatic java/math/RoundingMode.DOWN : Ljava/math/RoundingMode;
    //   4650: invokevirtual setRoundingMode : (Ljava/math/RoundingMode;)V
    //   4653: aload #19
    //   4655: astore #20
    //   4657: aload #27
    //   4659: astore #18
    //   4661: iload #9
    //   4663: istore #8
    //   4665: aload #21
    //   4667: astore #17
    //   4669: aload #36
    //   4671: aload #37
    //   4673: aload #30
    //   4675: invokevirtual format : (Ljava/lang/Object;)Ljava/lang/String;
    //   4678: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)D
    //   4681: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4684: invokeinterface add : (Ljava/lang/Object;)Z
    //   4689: pop
    //   4690: aload #19
    //   4692: astore #20
    //   4694: aload #27
    //   4696: astore #18
    //   4698: iload #9
    //   4700: istore #8
    //   4702: aload #21
    //   4704: astore #17
    //   4706: new java/util/ArrayList
    //   4709: dup
    //   4710: invokespecial <init> : ()V
    //   4713: astore #30
    //   4715: aload #19
    //   4717: astore #20
    //   4719: aload #27
    //   4721: astore #18
    //   4723: iload #9
    //   4725: istore #8
    //   4727: aload #21
    //   4729: astore #17
    //   4731: aload #30
    //   4733: aload #36
    //   4735: invokeinterface add : (Ljava/lang/Object;)Z
    //   4740: pop
    //   4741: aload #19
    //   4743: astore #20
    //   4745: aload #27
    //   4747: astore #18
    //   4749: iload #9
    //   4751: istore #8
    //   4753: aload #21
    //   4755: astore #17
    //   4757: aload #30
    //   4759: aload #35
    //   4761: invokeinterface add : (Ljava/lang/Object;)Z
    //   4766: pop
    //   4767: aload #30
    //   4769: astore #21
    //   4771: aload #19
    //   4773: astore #20
    //   4775: aload_1
    //   4776: astore #18
    //   4778: iload #7
    //   4780: istore #8
    //   4782: aload #16
    //   4784: astore #17
    //   4786: aload #33
    //   4788: ldc_w 'v'
    //   4791: aload #21
    //   4793: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   4798: pop
    //   4799: aload #19
    //   4801: astore #20
    //   4803: aload_1
    //   4804: astore #18
    //   4806: iload #7
    //   4808: istore #8
    //   4810: aload #16
    //   4812: astore #17
    //   4814: aload #29
    //   4816: invokestatic values : ()[Lcom/appsflyer/internal/AFa1uSDK$AFa1xSDK;
    //   4819: aload #34
    //   4821: invokevirtual intValue : ()I
    //   4824: aaload
    //   4825: getfield values : Ljava/lang/String;
    //   4828: aload #33
    //   4830: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   4835: pop
    //   4836: aload #19
    //   4838: astore #20
    //   4840: aload_1
    //   4841: astore #18
    //   4843: iload #7
    //   4845: istore #8
    //   4847: aload #16
    //   4849: astore #17
    //   4851: aload #23
    //   4853: getstatic com/appsflyer/internal/AFa1uSDK$AFa1ySDK.values : Lcom/appsflyer/internal/AFa1uSDK$AFa1ySDK;
    //   4856: if_acmpne -> 5823
    //   4859: aload #19
    //   4861: astore #20
    //   4863: aload_1
    //   4864: astore #18
    //   4866: iload #7
    //   4868: istore #8
    //   4870: aload #16
    //   4872: astore #17
    //   4874: aload #29
    //   4876: ldc_w 'er'
    //   4879: ldc_w 'no_svs'
    //   4882: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   4887: pop
    //   4888: goto -> 5823
    //   4891: iload #7
    //   4893: istore #9
    //   4895: aload #16
    //   4897: astore #23
    //   4899: aload_1
    //   4900: astore #24
    //   4902: aload #19
    //   4904: astore #20
    //   4906: aload #24
    //   4908: astore #18
    //   4910: iload #9
    //   4912: istore #8
    //   4914: aload #23
    //   4916: astore #17
    //   4918: new java/util/HashMap
    //   4921: dup
    //   4922: invokespecial <init> : ()V
    //   4925: astore #25
    //   4927: aload #19
    //   4929: astore #20
    //   4931: aload #24
    //   4933: astore #18
    //   4935: iload #9
    //   4937: istore #8
    //   4939: aload #23
    //   4941: astore #17
    //   4943: aload #25
    //   4945: ldc_w 'er'
    //   4948: ldc_w 'na'
    //   4951: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   4956: pop
    //   4957: aload #25
    //   4959: astore #24
    //   4961: goto -> 4964
    //   4964: aload #16
    //   4966: astore #23
    //   4968: aload #21
    //   4970: astore #19
    //   4972: aload #19
    //   4974: astore #20
    //   4976: aload_1
    //   4977: astore #18
    //   4979: iload #7
    //   4981: istore #8
    //   4983: aload #23
    //   4985: astore #17
    //   4987: aload #22
    //   4989: ldc_w 'sensors'
    //   4992: aload #24
    //   4994: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   4999: pop
    //   5000: aload_1
    //   5001: astore #16
    //   5003: aload #23
    //   5005: astore_1
    //   5006: goto -> 5057
    //   5009: aload #18
    //   5011: astore_1
    //   5012: aload #17
    //   5014: astore #19
    //   5016: aload #16
    //   5018: astore #21
    //   5020: aload #21
    //   5022: astore #20
    //   5024: aload #19
    //   5026: astore #18
    //   5028: iload #7
    //   5030: istore #8
    //   5032: aload_1
    //   5033: astore #17
    //   5035: aload #22
    //   5037: ldc_w 'sensors'
    //   5040: ldc_w 'na'
    //   5043: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5048: pop
    //   5049: aload #19
    //   5051: astore #16
    //   5053: aload #21
    //   5055: astore #19
    //   5057: aload #19
    //   5059: astore #20
    //   5061: aload #16
    //   5063: astore #18
    //   5065: iload #7
    //   5067: istore #8
    //   5069: aload_1
    //   5070: astore #17
    //   5072: aload #31
    //   5074: aload #22
    //   5076: invokeinterface putAll : (Ljava/util/Map;)V
    //   5081: goto -> 5156
    //   5084: astore_1
    //   5085: aload #20
    //   5087: astore #19
    //   5089: goto -> 5105
    //   5092: astore_1
    //   5093: goto -> 5773
    //   5096: astore_1
    //   5097: aload #23
    //   5099: astore #17
    //   5101: aload #20
    //   5103: astore #18
    //   5105: iload #8
    //   5107: istore #7
    //   5109: aload #18
    //   5111: astore #16
    //   5113: ldc_w 'error while getting sensors data'
    //   5116: aload_1
    //   5117: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   5120: new java/lang/StringBuilder
    //   5123: dup
    //   5124: ldc_w 'Unexpected exception from AFSensorManager: '
    //   5127: invokespecial <init> : (Ljava/lang/String;)V
    //   5130: astore #18
    //   5132: aload #18
    //   5134: aload_1
    //   5135: invokevirtual getMessage : ()Ljava/lang/String;
    //   5138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5141: pop
    //   5142: aload #18
    //   5144: invokevirtual toString : ()Ljava/lang/String;
    //   5147: invokestatic afRDLog : (Ljava/lang/String;)V
    //   5150: aload #17
    //   5152: astore_1
    //   5153: goto -> 5156
    //   5156: ldc_w 'advertiserId'
    //   5159: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   5162: ifnonnull -> 5876
    //   5165: aload #16
    //   5167: aload #31
    //   5169: invokestatic AFInAppEventType : (Landroid/content/Context;Ljava/util/Map;)Lcom/appsflyer/internal/AFc1qSDK$AFa1vSDK;
    //   5172: pop
    //   5173: ldc_w 'advertiserId'
    //   5176: invokestatic AFInAppEventType : (Ljava/lang/String;)Ljava/lang/String;
    //   5179: ifnull -> 5870
    //   5182: iconst_1
    //   5183: istore #8
    //   5185: goto -> 5188
    //   5188: aload #31
    //   5190: ldc_w 'GAID_retry'
    //   5193: iload #8
    //   5195: invokestatic valueOf : (Z)Ljava/lang/String;
    //   5198: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5203: pop
    //   5204: goto -> 5207
    //   5207: aload #16
    //   5209: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   5212: invokestatic values : (Landroid/content/ContentResolver;)Lcom/appsflyer/internal/AFc1qSDK$AFa1vSDK;
    //   5215: astore #17
    //   5217: aload #17
    //   5219: ifnull -> 5257
    //   5222: aload #31
    //   5224: ldc_w 'amazon_aid'
    //   5227: aload #17
    //   5229: getfield AFInAppEventParameterName : Ljava/lang/String;
    //   5232: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5237: pop
    //   5238: aload #31
    //   5240: ldc_w 'amazon_aid_limit'
    //   5243: aload #17
    //   5245: getfield AFInAppEventType : Ljava/lang/Boolean;
    //   5248: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   5251: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5256: pop
    //   5257: aload #31
    //   5259: ldc_w 'registeredUninstall'
    //   5262: aload_1
    //   5263: invokestatic AFKeystoreWrapper : (Landroid/content/SharedPreferences;)Z
    //   5266: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   5269: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5274: pop
    //   5275: aload_0
    //   5276: aload_1
    //   5277: iload #7
    //   5279: invokevirtual AFKeystoreWrapper : (Landroid/content/SharedPreferences;Z)I
    //   5282: istore #4
    //   5284: aload #31
    //   5286: ldc_w 'counter'
    //   5289: iload #4
    //   5291: invokestatic toString : (I)Ljava/lang/String;
    //   5294: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5299: pop
    //   5300: aload #19
    //   5302: ifnull -> 5879
    //   5305: iconst_1
    //   5306: istore #8
    //   5308: goto -> 5311
    //   5311: aload #31
    //   5313: ldc_w 'iaecounter'
    //   5316: aload_0
    //   5317: aload_1
    //   5318: iload #8
    //   5320: invokespecial values : (Landroid/content/SharedPreferences;Z)I
    //   5323: invokestatic toString : (I)Ljava/lang/String;
    //   5326: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5331: pop
    //   5332: iload #7
    //   5334: ifeq -> 5349
    //   5337: iload #4
    //   5339: iconst_1
    //   5340: if_icmpne -> 5349
    //   5343: aload #32
    //   5345: iconst_1
    //   5346: putfield values : Z
    //   5349: aload_1
    //   5350: invokestatic AFInAppEventParameterName : (Landroid/content/SharedPreferences;)Z
    //   5353: ifne -> 5885
    //   5356: iconst_1
    //   5357: istore #8
    //   5359: goto -> 5362
    //   5362: aload #31
    //   5364: ldc_w 'isFirstCall'
    //   5367: iload #8
    //   5369: invokestatic toString : (Z)Ljava/lang/String;
    //   5372: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5377: pop
    //   5378: aload_0
    //   5379: aload #16
    //   5381: iload #7
    //   5383: aload #31
    //   5385: iload #4
    //   5387: invokespecial valueOf : (Landroid/content/Context;ZLjava/util/Map;I)V
    //   5390: new com/appsflyer/internal/AFb1ySDK
    //   5393: dup
    //   5394: invokespecial <init> : ()V
    //   5397: pop
    //   5398: aload #31
    //   5400: ldc_w 'af_v'
    //   5403: aload #31
    //   5405: invokestatic AFKeystoreWrapper : (Ljava/util/Map;)Ljava/lang/String;
    //   5408: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5413: pop
    //   5414: new com/appsflyer/internal/AFb1ySDK
    //   5417: dup
    //   5418: invokespecial <init> : ()V
    //   5421: pop
    //   5422: aload #31
    //   5424: ldc_w 'af_v2'
    //   5427: aload #31
    //   5429: invokestatic AFInAppEventParameterName : (Ljava/util/Map;)Ljava/lang/String;
    //   5432: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5437: pop
    //   5438: aload #31
    //   5440: ldc_w 'ivc'
    //   5443: aload #16
    //   5445: invokestatic onInstallConversionFailureNative : (Landroid/content/Context;)Z
    //   5448: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   5451: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5456: pop
    //   5457: aload_1
    //   5458: ldc_w 'is_stop_tracking_used'
    //   5461: invokeinterface contains : (Ljava/lang/String;)Z
    //   5466: ifeq -> 5493
    //   5469: aload #31
    //   5471: ldc_w 'istu'
    //   5474: aload_1
    //   5475: ldc_w 'is_stop_tracking_used'
    //   5478: iconst_0
    //   5479: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   5484: invokestatic valueOf : (Z)Ljava/lang/String;
    //   5487: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5492: pop
    //   5493: new java/util/HashMap
    //   5496: dup
    //   5497: invokespecial <init> : ()V
    //   5500: astore_1
    //   5501: aload_1
    //   5502: ldc_w 'mcc'
    //   5505: aload #16
    //   5507: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   5510: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   5513: getfield mcc : I
    //   5516: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   5519: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5524: pop
    //   5525: aload_1
    //   5526: ldc_w 'mnc'
    //   5529: aload #16
    //   5531: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   5534: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   5537: getfield mnc : I
    //   5540: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   5543: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5548: pop
    //   5549: aload #31
    //   5551: ldc_w 'cell'
    //   5554: aload_1
    //   5555: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5560: pop
    //   5561: aload #31
    //   5563: ldc_w 'sig'
    //   5566: aload #28
    //   5568: getfield AFInAppEventType : Landroid/app/Application;
    //   5571: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   5574: aload #28
    //   5576: getfield AFInAppEventType : Landroid/app/Application;
    //   5579: invokevirtual getPackageName : ()Ljava/lang/String;
    //   5582: invokestatic values : (Landroid/content/pm/PackageManager;Ljava/lang/String;)Ljava/lang/String;
    //   5585: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5590: pop
    //   5591: aload #31
    //   5593: ldc_w 'last_boot_time'
    //   5596: invokestatic currentTimeMillis : ()J
    //   5599: invokestatic elapsedRealtime : ()J
    //   5602: lsub
    //   5603: invokestatic valueOf : (J)Ljava/lang/Long;
    //   5606: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5611: pop
    //   5612: new android/os/StatFs
    //   5615: dup
    //   5616: invokestatic getDataDirectory : ()Ljava/io/File;
    //   5619: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   5622: invokespecial <init> : (Ljava/lang/String;)V
    //   5625: astore_1
    //   5626: aload_1
    //   5627: invokevirtual getBlockSizeLong : ()J
    //   5630: lstore #10
    //   5632: aload_1
    //   5633: invokevirtual getAvailableBlocksLong : ()J
    //   5636: lstore #14
    //   5638: aload_1
    //   5639: invokevirtual getBlockCountLong : ()J
    //   5642: lstore #12
    //   5644: ldc2_w 2.0
    //   5647: ldc2_w 20.0
    //   5650: invokestatic pow : (DD)D
    //   5653: dstore_2
    //   5654: lload #14
    //   5656: lload #10
    //   5658: lmul
    //   5659: l2d
    //   5660: dload_2
    //   5661: ddiv
    //   5662: d2l
    //   5663: lstore #14
    //   5665: lload #12
    //   5667: lload #10
    //   5669: lmul
    //   5670: l2d
    //   5671: dload_2
    //   5672: ddiv
    //   5673: d2l
    //   5674: lstore #10
    //   5676: new java/lang/StringBuilder
    //   5679: dup
    //   5680: invokespecial <init> : ()V
    //   5683: astore_1
    //   5684: aload_1
    //   5685: lload #14
    //   5687: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   5690: pop
    //   5691: aload_1
    //   5692: ldc_w '/'
    //   5695: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   5698: pop
    //   5699: aload_1
    //   5700: lload #10
    //   5702: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   5705: pop
    //   5706: aload #31
    //   5708: ldc_w 'disk'
    //   5711: aload_1
    //   5712: invokevirtual toString : ()Ljava/lang/String;
    //   5715: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5720: pop
    //   5721: aload_0
    //   5722: getfield AFLogger : Lcom/appsflyer/internal/AFa1eSDK;
    //   5725: astore_1
    //   5726: aload_1
    //   5727: ifnull -> 5782
    //   5730: aload_1
    //   5731: getfield AFKeystoreWrapper : [Ljava/lang/String;
    //   5734: astore_1
    //   5735: aload_1
    //   5736: ifnull -> 5782
    //   5739: aload #31
    //   5741: ldc_w 'sharing_filter'
    //   5744: aload_1
    //   5745: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   5750: pop
    //   5751: aload #31
    //   5753: areturn
    //   5754: ldc_w 'AppsFlyer dev key is missing!!! Please use  AppsFlyerLib.getInstance().setAppsFlyerKey(...) to set it. '
    //   5757: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   5760: ldc_w 'AppsFlyer will not track this event.'
    //   5763: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   5766: aconst_null
    //   5767: areturn
    //   5768: astore_1
    //   5769: goto -> 5773
    //   5772: astore_1
    //   5773: aload_1
    //   5774: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
    //   5777: aload_1
    //   5778: iconst_1
    //   5779: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;Z)V
    //   5782: aload #31
    //   5784: areturn
    //   5785: aload #16
    //   5787: astore_1
    //   5788: goto -> 280
    //   5791: aload #23
    //   5793: ifnonnull -> 1327
    //   5796: aload_1
    //   5797: ifnull -> 1327
    //   5800: goto -> 1315
    //   5803: aconst_null
    //   5804: astore_1
    //   5805: goto -> 1795
    //   5808: astore_1
    //   5809: goto -> 1778
    //   5812: goto -> 3765
    //   5815: astore #17
    //   5817: goto -> 5832
    //   5820: goto -> 4311
    //   5823: aload #19
    //   5825: astore #21
    //   5827: goto -> 2731
    //   5830: astore #17
    //   5832: aload_1
    //   5833: astore #18
    //   5835: aload #17
    //   5837: astore_1
    //   5838: iload #7
    //   5840: istore #8
    //   5842: aload #16
    //   5844: astore #17
    //   5846: goto -> 5105
    //   5849: aload #29
    //   5851: astore #24
    //   5853: goto -> 4964
    //   5856: aload #18
    //   5858: astore_1
    //   5859: aload #16
    //   5861: astore #19
    //   5863: aload #17
    //   5865: astore #16
    //   5867: goto -> 5156
    //   5870: iconst_0
    //   5871: istore #8
    //   5873: goto -> 5188
    //   5876: goto -> 5207
    //   5879: iconst_0
    //   5880: istore #8
    //   5882: goto -> 5311
    //   5885: iconst_0
    //   5886: istore #8
    //   5888: goto -> 5362
    // Exception table:
    //   from	to	target	type
    //   249	268	5772	finally
    //   280	295	5772	finally
    //   298	304	5772	finally
    //   304	318	5772	finally
    //   318	359	406	java/lang/Exception
    //   318	359	5772	finally
    //   359	377	406	java/lang/Exception
    //   359	377	5772	finally
    //   377	403	406	java/lang/Exception
    //   377	403	5772	finally
    //   407	414	5772	finally
    //   414	658	5772	finally
    //   663	712	5772	finally
    //   712	737	5772	finally
    //   740	752	5772	finally
    //   756	778	5772	finally
    //   778	800	5772	finally
    //   800	839	5772	finally
    //   843	855	5772	finally
    //   855	862	5772	finally
    //   867	880	5772	finally
    //   880	892	5772	finally
    //   896	908	5772	finally
    //   908	948	5772	finally
    //   948	955	5772	finally
    //   962	978	5772	finally
    //   978	982	5772	finally
    //   994	1011	5772	finally
    //   1011	1033	5772	finally
    //   1037	1048	5772	finally
    //   1053	1068	5772	finally
    //   1068	1109	5772	finally
    //   1112	1121	5772	finally
    //   1121	1136	5772	finally
    //   1145	1181	5772	finally
    //   1181	1188	5772	finally
    //   1192	1204	5772	finally
    //   1204	1218	1237	java/lang/Exception
    //   1204	1218	5772	finally
    //   1222	1234	1237	java/lang/Exception
    //   1222	1234	5772	finally
    //   1238	1245	5772	finally
    //   1245	1254	5772	finally
    //   1258	1277	5772	finally
    //   1277	1298	5772	finally
    //   1303	1312	5772	finally
    //   1315	1327	5772	finally
    //   1327	1335	5772	finally
    //   1339	1357	5772	finally
    //   1357	1365	5772	finally
    //   1369	1387	5772	finally
    //   1387	1395	5772	finally
    //   1399	1417	5772	finally
    //   1422	1443	5772	finally
    //   1446	1459	5772	finally
    //   1463	1482	5772	finally
    //   1482	1486	5772	finally
    //   1490	1502	5772	finally
    //   1502	1511	5772	finally
    //   1515	1527	5772	finally
    //   1530	1537	5772	finally
    //   1541	1556	5772	finally
    //   1561	1587	5772	finally
    //   1587	1610	5772	finally
    //   1610	1617	5772	finally
    //   1621	1665	5772	finally
    //   1665	1677	5772	finally
    //   1677	1684	5772	finally
    //   1688	1700	5772	finally
    //   1700	1732	5772	finally
    //   1737	1743	5808	android/content/pm/PackageManager$NameNotFoundException
    //   1737	1743	1767	finally
    //   1743	1760	1763	android/content/pm/PackageManager$NameNotFoundException
    //   1743	1760	1767	finally
    //   1768	1775	5772	finally
    //   1778	1792	5772	finally
    //   1799	1811	5772	finally
    //   1811	1820	5772	finally
    //   1820	1833	1852	java/lang/Exception
    //   1820	1833	5772	finally
    //   1837	1849	1852	java/lang/Exception
    //   1837	1849	5772	finally
    //   1853	1884	5772	finally
    //   1884	1901	1904	java/lang/Exception
    //   1884	1901	5772	finally
    //   1905	1912	5772	finally
    //   1912	1929	1932	java/lang/Exception
    //   1912	1929	5772	finally
    //   1933	1940	5772	finally
    //   1940	1957	1960	java/lang/Exception
    //   1940	1957	5772	finally
    //   1961	1968	5772	finally
    //   1968	2000	5772	finally
    //   2000	2032	2035	java/lang/Exception
    //   2000	2032	5772	finally
    //   2037	2045	5772	finally
    //   2045	2104	2377	finally
    //   2104	2209	2377	finally
    //   2209	2366	2369	finally
    //   2378	2386	5772	finally
    //   2386	2446	5772	finally
    //   2451	2478	5772	finally
    //   2481	2520	5772	finally
    //   2520	2539	5772	finally
    //   2560	2566	5096	java/lang/Exception
    //   2560	2566	5092	finally
    //   2582	2591	5096	java/lang/Exception
    //   2582	2591	5092	finally
    //   2607	2612	5096	java/lang/Exception
    //   2607	2612	5092	finally
    //   2628	2637	5096	java/lang/Exception
    //   2628	2637	5092	finally
    //   2653	2661	5096	java/lang/Exception
    //   2653	2661	5092	finally
    //   2687	2696	5096	java/lang/Exception
    //   2687	2696	5092	finally
    //   2712	2720	5096	java/lang/Exception
    //   2712	2720	5092	finally
    //   2746	2756	5096	java/lang/Exception
    //   2746	2756	5092	finally
    //   2771	2783	5096	java/lang/Exception
    //   2771	2783	5092	finally
    //   2798	2807	5096	java/lang/Exception
    //   2798	2807	5092	finally
    //   2822	2834	5096	java/lang/Exception
    //   2822	2834	5092	finally
    //   2852	2864	5830	java/lang/Exception
    //   2852	2864	5092	finally
    //   2888	2893	2909	java/lang/Exception
    //   2888	2893	5772	finally
    //   2901	2906	2909	java/lang/Exception
    //   2901	2906	5772	finally
    //   2924	2929	5830	java/lang/Exception
    //   2924	2929	5092	finally
    //   2929	2967	5830	java/lang/Exception
    //   2929	2967	5092	finally
    //   2972	2984	2909	java/lang/Exception
    //   2972	2984	5092	finally
    //   2987	2999	5830	java/lang/Exception
    //   2987	2999	5092	finally
    //   2999	3037	5830	java/lang/Exception
    //   2999	3037	5092	finally
    //   3044	3065	2909	java/lang/Exception
    //   3044	3065	5092	finally
    //   3065	3070	5830	java/lang/Exception
    //   3065	3070	5092	finally
    //   3077	3112	5830	java/lang/Exception
    //   3077	3112	5092	finally
    //   3116	3122	5815	java/lang/Exception
    //   3116	3122	5092	finally
    //   3145	3163	5084	java/lang/Exception
    //   3145	3163	5092	finally
    //   3179	3191	5084	java/lang/Exception
    //   3179	3191	5092	finally
    //   3207	3215	5084	java/lang/Exception
    //   3207	3215	5092	finally
    //   3231	3252	5084	java/lang/Exception
    //   3231	3252	5092	finally
    //   3268	3281	5084	java/lang/Exception
    //   3268	3281	5092	finally
    //   3297	3309	5084	java/lang/Exception
    //   3297	3309	5092	finally
    //   3325	3333	5084	java/lang/Exception
    //   3325	3333	5092	finally
    //   3349	3370	5084	java/lang/Exception
    //   3349	3370	5092	finally
    //   3386	3395	5084	java/lang/Exception
    //   3386	3395	5092	finally
    //   3411	3422	5084	java/lang/Exception
    //   3411	3422	5092	finally
    //   3438	3451	5084	java/lang/Exception
    //   3438	3451	5092	finally
    //   3467	3480	5084	java/lang/Exception
    //   3467	3480	5092	finally
    //   3496	3502	5084	java/lang/Exception
    //   3496	3502	5092	finally
    //   3518	3541	5084	java/lang/Exception
    //   3518	3541	5092	finally
    //   3557	3569	5084	java/lang/Exception
    //   3557	3569	5092	finally
    //   3585	3593	5084	java/lang/Exception
    //   3585	3593	5092	finally
    //   3609	3630	5084	java/lang/Exception
    //   3609	3630	5092	finally
    //   3646	3673	5084	java/lang/Exception
    //   3646	3673	5092	finally
    //   3689	3701	5084	java/lang/Exception
    //   3689	3701	5092	finally
    //   3717	3725	5084	java/lang/Exception
    //   3717	3725	5092	finally
    //   3741	3762	5084	java/lang/Exception
    //   3741	3762	5092	finally
    //   3781	3790	5084	java/lang/Exception
    //   3781	3790	5092	finally
    //   3806	3816	5084	java/lang/Exception
    //   3806	3816	5092	finally
    //   3832	3842	5084	java/lang/Exception
    //   3832	3842	5092	finally
    //   3876	3885	5084	java/lang/Exception
    //   3876	3885	5092	finally
    //   3901	3912	5084	java/lang/Exception
    //   3901	3912	5092	finally
    //   3928	3955	5084	java/lang/Exception
    //   3928	3955	5092	finally
    //   3971	3983	5084	java/lang/Exception
    //   3971	3983	5092	finally
    //   3999	4007	5084	java/lang/Exception
    //   3999	4007	5092	finally
    //   4023	4044	5084	java/lang/Exception
    //   4023	4044	5092	finally
    //   4060	4087	5084	java/lang/Exception
    //   4060	4087	5092	finally
    //   4103	4115	5084	java/lang/Exception
    //   4103	4115	5092	finally
    //   4131	4139	5084	java/lang/Exception
    //   4131	4139	5092	finally
    //   4155	4176	5084	java/lang/Exception
    //   4155	4176	5092	finally
    //   4192	4219	5084	java/lang/Exception
    //   4192	4219	5092	finally
    //   4235	4247	5084	java/lang/Exception
    //   4235	4247	5092	finally
    //   4263	4271	5084	java/lang/Exception
    //   4263	4271	5092	finally
    //   4287	4308	5084	java/lang/Exception
    //   4287	4308	5092	finally
    //   4327	4336	5084	java/lang/Exception
    //   4327	4336	5092	finally
    //   4352	4365	5084	java/lang/Exception
    //   4352	4365	5092	finally
    //   4381	4393	5084	java/lang/Exception
    //   4381	4393	5092	finally
    //   4409	4417	5084	java/lang/Exception
    //   4409	4417	5092	finally
    //   4433	4454	5084	java/lang/Exception
    //   4433	4454	5092	finally
    //   4470	4483	5084	java/lang/Exception
    //   4470	4483	5092	finally
    //   4499	4511	5084	java/lang/Exception
    //   4499	4511	5092	finally
    //   4527	4535	5084	java/lang/Exception
    //   4527	4535	5092	finally
    //   4551	4572	5084	java/lang/Exception
    //   4551	4572	5092	finally
    //   4588	4601	5084	java/lang/Exception
    //   4588	4601	5092	finally
    //   4617	4629	5084	java/lang/Exception
    //   4617	4629	5092	finally
    //   4645	4653	5084	java/lang/Exception
    //   4645	4653	5092	finally
    //   4669	4690	5084	java/lang/Exception
    //   4669	4690	5092	finally
    //   4706	4715	5084	java/lang/Exception
    //   4706	4715	5092	finally
    //   4731	4741	5084	java/lang/Exception
    //   4731	4741	5092	finally
    //   4757	4767	5084	java/lang/Exception
    //   4757	4767	5092	finally
    //   4786	4799	5084	java/lang/Exception
    //   4786	4799	5092	finally
    //   4814	4836	5084	java/lang/Exception
    //   4814	4836	5092	finally
    //   4851	4859	5084	java/lang/Exception
    //   4851	4859	5092	finally
    //   4874	4888	5084	java/lang/Exception
    //   4874	4888	5092	finally
    //   4918	4927	5084	java/lang/Exception
    //   4918	4927	5092	finally
    //   4943	4957	5084	java/lang/Exception
    //   4943	4957	5092	finally
    //   4987	5000	5084	java/lang/Exception
    //   4987	5000	5092	finally
    //   5035	5049	5084	java/lang/Exception
    //   5035	5049	5092	finally
    //   5072	5081	5084	java/lang/Exception
    //   5072	5081	5092	finally
    //   5113	5150	5092	finally
    //   5156	5182	5092	finally
    //   5188	5204	5092	finally
    //   5207	5217	5092	finally
    //   5222	5257	5092	finally
    //   5257	5275	5092	finally
    //   5275	5300	5768	finally
    //   5311	5332	5768	finally
    //   5343	5349	5768	finally
    //   5349	5356	5768	finally
    //   5362	5493	5768	finally
    //   5493	5726	5768	finally
    //   5730	5735	5768	finally
    //   5739	5751	5768	finally
    //   5754	5766	5768	finally
  }
  
  public final void AFInAppEventType(Context paramContext) {
    int i;
    AFc1uSDK aFc1uSDK = this.onConversionDataFail;
    if (paramContext != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = onAttributionFailure + 75;
      onResponse = i % 128;
      AFc1wSDK aFc1wSDK = aFc1uSDK.AFKeystoreWrapper;
      if (paramContext != null) {
        i = 57;
      } else {
        i = 71;
      } 
      if (i != 57)
        return; 
      i = onResponse + 55;
      onAttributionFailure = i % 128;
      aFc1wSDK.AFKeystoreWrapper = paramContext.getApplicationContext();
    } 
  }
  
  public final void AFInAppEventType(Context paramContext, String paramString) {
    JSONObject jSONObject;
    JSONArray jSONArray;
    int i = onAttributionFailure + 91;
    onResponse = i % 128;
    if (i % 2 == 0) {
      AFLogger.afDebugLog("received a new (extra) referrer: ".concat(String.valueOf(paramString)));
      try {
        long l = System.currentTimeMillis();
        String str = valueOf(paramContext).getString("extraReferrers", null);
        if (str == null) {
          jSONObject = new JSONObject();
          jSONArray = new JSONArray();
          i = onResponse + 51;
          onAttributionFailure = i % 128;
        } else {
          JSONArray jSONArray1;
          JSONObject jSONObject1 = new JSONObject((String)jSONObject);
          if (jSONObject1.has(paramString)) {
            jSONArray1 = new JSONArray((String)jSONObject1.get(paramString));
          } else {
            jSONArray1 = new JSONArray();
          } 
          jSONArray = jSONArray1;
          jSONObject = jSONObject1;
        } 
        i = jSONArray.length();
        if (i < 5L) {
          i = 0;
        } else {
          i = 1;
        } 
        if (i != 1) {
          i = onResponse + 3;
          onAttributionFailure = i % 128;
          jSONArray.put(l);
        } 
        if (jSONObject.length() >= 4L) {
          i = 54;
        } else {
          i = 62;
        } 
      } catch (JSONException jSONException) {
        AFLogger.afErrorLogForExcManagerOnly("error at addReferrer", (Throwable)jSONException);
        return;
      } finally {}
    } else {
      AFLogger.afDebugLog("received a new (extra) referrer: ".concat(String.valueOf(paramString)));
      System.currentTimeMillis();
      valueOf(paramContext).getString("extraReferrers", null);
      throw null;
    } 
    if (i == 54)
      values(jSONObject); 
    jSONObject.put(paramString, jSONArray.toString());
    values(paramContext).AFKeystoreWrapper("extraReferrers", jSONObject.toString());
    i = onResponse + 37;
    onAttributionFailure = i % 128;
  }
  
  final void AFInAppEventType(AFa1sSDK paramAFa1sSDK, Activity paramActivity) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: bipush #49
    //   5: iadd
    //   6: istore_3
    //   7: iload_3
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   15: aload_1
    //   16: getfield AFKeystoreWrapper : Landroid/app/Application;
    //   19: astore #6
    //   21: aload_2
    //   22: ifnull -> 30
    //   25: iconst_3
    //   26: istore_3
    //   27: goto -> 32
    //   30: iconst_2
    //   31: istore_3
    //   32: ldc ''
    //   34: astore #5
    //   36: iload_3
    //   37: iconst_3
    //   38: if_icmpeq -> 44
    //   41: goto -> 68
    //   44: aload_2
    //   45: invokevirtual getIntent : ()Landroid/content/Intent;
    //   48: ifnull -> 68
    //   51: aload_2
    //   52: invokestatic AFInAppEventType : (Landroid/app/Activity;)Landroid/net/Uri;
    //   55: astore_2
    //   56: aload_2
    //   57: ifnull -> 68
    //   60: aload_2
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: astore_2
    //   65: goto -> 71
    //   68: ldc ''
    //   70: astore_2
    //   71: aload_0
    //   72: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   75: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   80: getfield AFInAppEventType : Ljava/lang/String;
    //   83: astore #7
    //   85: iconst_1
    //   86: istore #4
    //   88: iconst_1
    //   89: istore_3
    //   90: aload #7
    //   92: ifnonnull -> 178
    //   95: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   98: bipush #31
    //   100: iadd
    //   101: istore #4
    //   103: iload #4
    //   105: sipush #128
    //   108: irem
    //   109: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   112: iload #4
    //   114: iconst_2
    //   115: irem
    //   116: ifeq -> 156
    //   119: ldc_w '[LogEvent/Launch] AppsFlyer's SDK cannot send any event without providing DevKey.'
    //   122: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   125: aload_1
    //   126: getfield AFInAppEventType : Lcom/appsflyer/attribution/AppsFlyerRequestListener;
    //   129: astore_1
    //   130: aload_1
    //   131: ifnull -> 137
    //   134: goto -> 139
    //   137: iconst_0
    //   138: istore_3
    //   139: iload_3
    //   140: ifeq -> 155
    //   143: aload_1
    //   144: getstatic com/appsflyer/attribution/RequestError.NO_DEV_KEY : I
    //   147: getstatic com/appsflyer/internal/AFb1aSDK.values : Ljava/lang/String;
    //   150: invokeinterface onError : (ILjava/lang/String;)V
    //   155: return
    //   156: ldc_w '[LogEvent/Launch] AppsFlyer's SDK cannot send any event without providing DevKey.'
    //   159: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   162: aload_1
    //   163: getfield AFInAppEventType : Lcom/appsflyer/attribution/AppsFlyerRequestListener;
    //   166: astore_1
    //   167: new java/lang/NullPointerException
    //   170: dup
    //   171: invokespecial <init> : ()V
    //   174: athrow
    //   175: astore_1
    //   176: aload_1
    //   177: athrow
    //   178: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   181: aload #6
    //   183: invokevirtual getReferrer : (Landroid/content/Context;)Ljava/lang/String;
    //   186: astore #6
    //   188: aload #6
    //   190: ifnonnull -> 199
    //   193: iload #4
    //   195: istore_3
    //   196: goto -> 201
    //   199: iconst_0
    //   200: istore_3
    //   201: iload_3
    //   202: ifeq -> 223
    //   205: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   208: bipush #57
    //   210: iadd
    //   211: istore_3
    //   212: iload_3
    //   213: sipush #128
    //   216: irem
    //   217: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   220: goto -> 227
    //   223: aload #6
    //   225: astore #5
    //   227: aload_1
    //   228: aload #5
    //   230: putfield afRDLog : Ljava/lang/String;
    //   233: aload_1
    //   234: aload_2
    //   235: putfield AFInAppEventParameterName : Ljava/lang/String;
    //   238: aload_0
    //   239: aload_1
    //   240: invokespecial values : (Lcom/appsflyer/internal/AFa1sSDK;)V
    //   243: return
    // Exception table:
    //   from	to	target	type
    //   167	175	175	finally
  }
  
  public final int AFKeystoreWrapper(SharedPreferences paramSharedPreferences, boolean paramBoolean) {
    int i = onResponse + 47;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 48;
    } else {
      i = 66;
    } 
    if (i != 48) {
      i = AFInAppEventType(paramSharedPreferences, "appsFlyerCount", paramBoolean);
      int j = onAttributionFailure + 1;
      onResponse = j % 128;
      return i;
    } 
    AFInAppEventType(paramSharedPreferences, "appsFlyerCount", paramBoolean);
    try {
      throw null;
    } finally {}
  }
  
  public final AFc1vSDK AFKeystoreWrapper() {
    int i = onResponse;
    int j = i + 119;
    onAttributionFailure = j % 128;
    AFc1uSDK aFc1uSDK = this.onConversionDataFail;
    i += 27;
    onAttributionFailure = i % 128;
    return (AFc1vSDK)aFc1uSDK;
  }
  
  public final void AFKeystoreWrapper(Context paramContext, Intent paramIntent) {
    int i = onAttributionFailure + 69;
    onResponse = i % 128;
    if (paramIntent.getStringExtra("appsflyer_preinstall") != null) {
      i = onAttributionFailure + 117;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 15;
      } else {
        i = 32;
      } 
      if (i != 15) {
        values(paramIntent.getStringExtra("appsflyer_preinstall"));
      } else {
        values(paramIntent.getStringExtra("appsflyer_preinstall"));
        try {
          throw new NullPointerException();
        } finally {}
      } 
    } 
    AFLogger.afInfoLog("****** onReceive called *******");
    AppsFlyerProperties.getInstance();
    String str = paramIntent.getStringExtra("referrer");
    AFLogger.afInfoLog("Play store referrer: ".concat(String.valueOf(str)));
    if (str != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      values(paramContext).AFKeystoreWrapper("referrer", str);
      AppsFlyerProperties appsFlyerProperties = AppsFlyerProperties.getInstance();
      appsFlyerProperties.set("AF_REFERRER", str);
      appsFlyerProperties.valueOf = str;
      if (AppsFlyerProperties.getInstance().AFKeystoreWrapper()) {
        AFLogger.afInfoLog("onReceive: isLaunchCalled");
        values(paramContext, AFe1iSDK.AFKeystoreWrapper);
        valueOf(paramContext, str);
      } 
    } 
  }
  
  public final void AFKeystoreWrapper(Context paramContext, Map<String, ? super String> paramMap) {
    int i = onResponse + 121;
    onAttributionFailure = i % 128;
    boolean bool = false;
    boolean bool1 = AFKeystoreWrapper("disableCollectNetworkData", false);
    null = AFKeystoreWrapper().onInstallConversionFailureNative().valueOf(paramContext);
    paramMap.put("network", null.AFInAppEventType);
    if (!bool1 && null.AFInAppEventParameterName != null) {
      i = onAttributionFailure + 13;
      onResponse = i % 128;
      paramMap.put("operator", null.AFInAppEventParameterName);
    } 
    if (!bool1) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onResponse + 53;
      onAttributionFailure = i % 128;
      if (null.AFKeystoreWrapper != null) {
        i = 6;
      } else {
        i = 17;
      } 
      if (i == 6)
        paramMap.put("carrier", null.AFKeystoreWrapper); 
    } 
    i = onAttributionFailure + 29;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = bool;
    } else {
      i = 1;
    } 
    if (i == 1)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  public final void addPushNotificationDeepLinkPath(String... paramVarArgs) {
    List<List<String>> list;
    List<String> list1;
    int i = onAttributionFailure + 7;
    onResponse = i % 128;
    if (i % 2 != 0) {
      list1 = Arrays.asList(paramVarArgs);
      null = (AFKeystoreWrapper().onAppOpenAttributionNative()).afRDLog;
      boolean bool = null.contains(list1);
      try {
        i = 11 / 0;
        if (!bool) {
          i = 63;
        } else {
          i = 8;
        } 
        if (i != 63)
          return; 
      } finally {}
    } else {
      list1 = Arrays.asList(paramVarArgs);
      list = (AFKeystoreWrapper().onAppOpenAttributionNative()).afRDLog;
      if (!list.contains(list1)) {
        i = 93;
      } else {
        i = 64;
      } 
      if (i != 93)
        return; 
    } 
    list.add(list1);
    i = onResponse + 101;
    onAttributionFailure = i % 128;
  }
  
  public final void anonymizeUser(boolean paramBoolean) {
    int i = onAttributionFailure + 121;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0) {
      AFKeystoreWrapper().AFVersionDeclaration().values("anonymizeUser", new String[] { String.valueOf(paramBoolean) });
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("anonymizeUser", new String[] { String.valueOf(paramBoolean) });
    } 
    AppsFlyerProperties.getInstance().set("deviceTrackingDisabled", paramBoolean);
  }
  
  public final void appendParametersToDeepLinkingURL(String paramString, Map<String, String> paramMap) {
    int i = onResponse + 85;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 21;
    } else {
      i = 48;
    } 
    if (i == 48) {
      AFa1tSDK aFa1tSDK1 = AFKeystoreWrapper().onAppOpenAttributionNative();
      aFa1tSDK1.AFInAppEventParameterName = paramString;
      aFa1tSDK1.valueOf = paramMap;
      i = onResponse + 59;
      onAttributionFailure = i % 128;
      if (i % 2 == 0) {
        i = 18;
      } else {
        i = 95;
      } 
      if (i != 18)
        return; 
      try {
        throw null;
      } finally {}
    } 
    AFa1tSDK aFa1tSDK = AFKeystoreWrapper().onAppOpenAttributionNative();
    aFa1tSDK.AFInAppEventParameterName = paramString;
    aFa1tSDK.valueOf = paramMap;
    try {
      throw null;
    } finally {}
  }
  
  public final void enableFacebookDeferredApplinks(boolean paramBoolean) {
    int i = onResponse;
    int j = i + 1;
    onAttributionFailure = j % 128;
    this.onDeepLinkingNative = paramBoolean;
    i += 25;
    onAttributionFailure = i % 128;
  }
  
  public final String getAppsFlyerUID(Context paramContext) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #119
    //   5: iadd
    //   6: istore_2
    //   7: iload_2
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   15: iload_2
    //   16: iconst_2
    //   17: irem
    //   18: ifne -> 26
    //   21: iconst_0
    //   22: istore_2
    //   23: goto -> 28
    //   26: iconst_1
    //   27: istore_2
    //   28: iload_2
    //   29: ifeq -> 75
    //   32: aload_0
    //   33: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   36: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   41: ldc_w 'getAppsFlyerUID'
    //   44: iconst_0
    //   45: anewarray java/lang/String
    //   48: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   53: aload_1
    //   54: ifnonnull -> 63
    //   57: bipush #30
    //   59: istore_2
    //   60: goto -> 66
    //   63: bipush #41
    //   65: istore_2
    //   66: iload_2
    //   67: bipush #30
    //   69: if_icmpeq -> 100
    //   72: goto -> 134
    //   75: aload_0
    //   76: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   79: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   84: ldc_w 'getAppsFlyerUID'
    //   87: iconst_0
    //   88: anewarray java/lang/String
    //   91: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   96: aload_1
    //   97: ifnonnull -> 134
    //   100: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   103: bipush #97
    //   105: iadd
    //   106: istore_2
    //   107: iload_2
    //   108: sipush #128
    //   111: irem
    //   112: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   115: iload_2
    //   116: iconst_2
    //   117: irem
    //   118: ifne -> 123
    //   121: aconst_null
    //   122: areturn
    //   123: new java/lang/NullPointerException
    //   126: dup
    //   127: invokespecial <init> : ()V
    //   130: athrow
    //   131: astore_1
    //   132: aload_1
    //   133: athrow
    //   134: aload_0
    //   135: aload_1
    //   136: invokevirtual AFInAppEventType : (Landroid/content/Context;)V
    //   139: new java/lang/ref/WeakReference
    //   142: dup
    //   143: aload_0
    //   144: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   147: invokeinterface AFInAppEventParameterName : ()Lcom/appsflyer/internal/AFb1bSDK;
    //   152: getfield values : Lcom/appsflyer/internal/AFc1wSDK;
    //   155: getfield AFKeystoreWrapper : Landroid/content/Context;
    //   158: invokespecial <init> : (Ljava/lang/Object;)V
    //   161: invokestatic AFInAppEventParameterName : (Ljava/lang/ref/WeakReference;)Ljava/lang/String;
    //   164: astore_1
    //   165: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   168: bipush #115
    //   170: iadd
    //   171: istore_2
    //   172: iload_2
    //   173: sipush #128
    //   176: irem
    //   177: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   180: iload_2
    //   181: iconst_2
    //   182: irem
    //   183: ifne -> 188
    //   186: aload_1
    //   187: areturn
    //   188: aconst_null
    //   189: athrow
    //   190: astore_1
    //   191: aload_1
    //   192: athrow
    // Exception table:
    //   from	to	target	type
    //   123	131	131	finally
    //   188	190	190	finally
  }
  
  public final String getAttributionId(Context paramContext) {
    try {
      null = (new AFa1aSDK(paramContext, AFKeystoreWrapper())).AFKeystoreWrapper();
      int i = onAttributionFailure + 13;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 95;
      } else {
        i = 23;
      } 
    } finally {
      paramContext = null;
      AFLogger.afErrorLog("Could not collect facebook attribution id. ", (Throwable)paramContext);
    } 
  }
  
  public final String getHostName() {
    int i = onAttributionFailure + 5;
    onResponse = i % 128;
    null = AFKeystoreWrapper().onInstallConversionDataLoadedNative().AFInAppEventParameterName();
    i = onAttributionFailure + 111;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 3;
    } else {
      i = 95;
    } 
    if (i != 3)
      return null; 
    try {
      throw null;
    } finally {}
  }
  
  public final String getHostPrefix() {
    int i = onResponse + 99;
    onAttributionFailure = i % 128;
    null = AFKeystoreWrapper().onInstallConversionDataLoadedNative().values();
    i = onAttributionFailure + 77;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0)
      return null; 
    try {
      throw null;
    } finally {}
  }
  
  public final String getOutOfStore(Context paramContext) {
    String str = AppsFlyerProperties.getInstance().getString("api_store_value");
    if (str != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1) {
      String str1 = values(paramContext, "AF_STORE");
      if (str1 != null) {
        i = 18;
      } else {
        i = 45;
      } 
      if (i != 45)
        return str1; 
      AFLogger.afInfoLog("No out-of-store value set");
      i = onResponse + 119;
      onAttributionFailure = i % 128;
      return null;
    } 
    int i = onAttributionFailure + 125;
    onResponse = i % 128;
    return str;
  }
  
  public final String getSdkVersion() {
    int i = onAttributionFailure + 35;
    onResponse = i % 128;
    AFc1vSDK aFc1vSDK = AFKeystoreWrapper();
    aFc1vSDK.AFVersionDeclaration().values("getSdkVersion", new String[0]);
    aFc1vSDK.AFInAppEventParameterName();
    null = AFb1bSDK.AFKeystoreWrapper();
    i = onResponse + 29;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 3;
    } else {
      i = 88;
    } 
    if (i != 3)
      return null; 
    try {
      throw null;
    } finally {}
  }
  
  public final AppsFlyerLib init(String paramString, AppsFlyerConversionListener paramAppsFlyerConversionListener, Context paramContext) {
    String str;
    int i = onAttributionFailure + 15;
    onResponse = i % 128;
    if (i % 2 != 0) {
      boolean bool = this.onInstallConversionDataLoadedNative;
      try {
        i = 94 / 0;
        if (bool)
          return this; 
      } finally {}
    } else if (this.onInstallConversionDataLoadedNative) {
      return this;
    } 
    this.onInstallConversionDataLoadedNative = true;
    (AFKeystoreWrapper().afWarnLog()).AFInAppEventType = paramString;
    AFc1rSDK.values(paramString);
    if (paramContext != null) {
      this.init = (Application)paramContext.getApplicationContext();
      AFInAppEventType(paramContext);
      (AFKeystoreWrapper().AFLogger()).AFKeystoreWrapper = System.currentTimeMillis();
      AFKeystoreWrapper().onDeepLinkingNative().AFKeystoreWrapper();
      AFb1xSDK$.ExternalSyntheticLambda1 externalSyntheticLambda1 = new AFb1xSDK$.ExternalSyntheticLambda1(this);
      AFKeystoreWrapper().afRDLog().AFInAppEventParameterName((AFe1ySDK)externalSyntheticLambda1);
      AFf1kSDK aFf1kSDK = AFKeystoreWrapper().getLevel();
      AFf1mSDK aFf1mSDK = new AFf1mSDK(new Runnable(this) {
            public final void run() {
              AFb1xSDK.valueOf(AFb1xSDK.AFKeystoreWrapper(this.AFKeystoreWrapper).values(), (Runnable)new AFb1xSDK$3$.ExternalSyntheticLambda0(this), TimeUnit.MILLISECONDS);
            }
          });
      Runnable runnable = new Runnable(this, aFf1mSDK) {
          public final void run() {
            SharedPreferences sharedPreferences = AFb1xSDK.valueOf((Context)AFb1xSDK.valueOf(this.values));
            AFb1xSDK aFb1xSDK = this.values;
            boolean bool = false;
            int i = aFb1xSDK.AFKeystoreWrapper(sharedPreferences, false);
            boolean bool1 = sharedPreferences.getBoolean("newGPReferrerSent", false);
            if (((AFf1jSDK)this.AFKeystoreWrapper).AFKeystoreWrapper == AFf1jSDK.AFa1wSDK.AFInAppEventType)
              bool = true; 
            if (i == 1 && (bool || bool1)) {
              AFb1xSDK aFb1xSDK1 = this.values;
              AFe1cSDK aFe1cSDK = new AFe1cSDK();
              Application application = AFb1xSDK.valueOf(this.values);
              if (application != null)
                ((AFa1sSDK)aFe1cSDK).AFKeystoreWrapper = (Application)application.getApplicationContext(); 
              AFb1xSDK.AFKeystoreWrapper(aFb1xSDK1, (AFa1sSDK)aFe1cSDK);
            } 
          }
        };
      aFf1kSDK.AFKeystoreWrapper((AFf1jSDK)aFf1mSDK);
      aFf1kSDK.AFKeystoreWrapper((AFf1jSDK)new AFf1hSDK(runnable));
      aFf1kSDK.AFKeystoreWrapper((AFf1jSDK)new AFf1nSDK(runnable, AFKeystoreWrapper()));
      aFf1kSDK.AFKeystoreWrapper((AFf1jSDK)new AFf1iSDK(runnable, AFKeystoreWrapper()));
      if (!afInfoLog()) {
        Application application = this.init;
        AFc1vSDK aFc1vSDK = AFKeystoreWrapper();
        Intent intent = new Intent("com.appsflyer.referrer.INSTALL_PROVIDER");
        List list = application.getPackageManager().queryIntentContentProviders(intent, 0);
        if (list == null || list.isEmpty()) {
          i = onResponse + 109;
          onAttributionFailure = i % 128;
        } else {
          ArrayList<AFf1lSDK> arrayList = new ArrayList();
          Iterator iterator = list.iterator();
          while (iterator.hasNext()) {
            i = onResponse + 67;
            onAttributionFailure = i % 128;
            if (i % 2 == 0) {
              i = 1;
            } else {
              i = 0;
            } 
            if (i != 1) {
              ProviderInfo providerInfo = ((ResolveInfo)iterator.next()).providerInfo;
              if (providerInfo != null) {
                arrayList.add(new AFf1lSDK(providerInfo, runnable, aFc1vSDK));
                continue;
              } 
              AFLogger.afWarnLog("[Preinstall]: com.appsflyer.referrer.INSTALL_PROVIDER Action is set for non ContentProvider component");
              continue;
            } 
            null = ((ResolveInfo)iterator.next()).providerInfo;
            try {
              throw new NullPointerException();
            } finally {}
          } 
          if (!arrayList.isEmpty()) {
            aFf1kSDK.AFInAppEventParameterName.addAll(arrayList);
            StringBuilder stringBuilder = new StringBuilder("[Preinstall]: Detected ");
            stringBuilder.append(arrayList.size());
            stringBuilder.append(" valid preinstall provider(s)");
            AFLogger.afDebugLog(stringBuilder.toString());
          } 
        } 
      } 
      AFf1jSDK[] arrayOfAFf1jSDK = aFf1kSDK.AFInAppEventParameterName();
      int j = arrayOfAFf1jSDK.length;
      i = 0;
      while (i < j) {
        arrayOfAFf1jSDK[i].values((Context)this.init);
        i++;
        int k = onAttributionFailure + 21;
        onResponse = k % 128;
      } 
      this.onConversionDataFail.afWarnLog().AFInAppEventType();
      AFb1fSDK.values = this.init;
    } else {
      AFLogger.afWarnLog("context is null, Google Install Referrer will be not initialized");
    } 
    AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
    if (paramAppsFlyerConversionListener == null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      str = "null";
    } else {
      str = "conversionDataListener";
    } 
    aFb1sSDK.values("init", new String[] { paramString, str });
    AFLogger.AFInAppEventType(String.format("Initializing AppsFlyer SDK: (v%s.%s)", new Object[] { "6.10.3", AFInAppEventParameterName }));
    valueOf = paramAppsFlyerConversionListener;
    return this;
  }
  
  public final boolean isPreInstalledApp(Context paramContext) {
    try {
      int i = (paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 0)).flags;
      if ((i & 0x1) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        i = onAttributionFailure + 111;
        onResponse = i % 128;
        return true;
      } 
      i = onAttributionFailure + 105;
      onResponse = i % 128;
      return false;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      AFLogger.afErrorLog("Could not check if app is pre installed", (Throwable)nameNotFoundException);
      return false;
    } 
  }
  
  @Deprecated
  public final boolean isStopped() {
    int i = onAttributionFailure + 25;
    onResponse = i % 128;
    boolean bool = AFKeystoreWrapper().afWarnLog().valueOf();
    i = onResponse + 59;
    onAttributionFailure = i % 128;
    return bool;
  }
  
  public final void logEvent(Context paramContext, String paramString, Map<String, Object> paramMap) {
    int i = onResponse + 59;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 53;
    } else {
      i = 59;
    } 
    super.logEvent(paramContext, paramString, paramMap, null);
    if (i == 59) {
      i = onAttributionFailure + 71;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 79;
      } else {
        i = 26;
      } 
      if (i != 79)
        return; 
      try {
        throw null;
      } finally {}
    } 
    try {
      throw null;
    } finally {}
  }
  
  public final void logEvent(Context paramContext, String paramString, Map<String, Object> paramMap, AppsFlyerRequestListener paramAppsFlyerRequestListener) {
    Activity activity;
    String str = null;
    if (paramMap == null) {
      paramMap = null;
    } else {
      paramMap = new HashMap<String, Object>(paramMap);
    } 
    AFInAppEventType(paramContext);
    AFf1wSDK aFf1wSDK = new AFf1wSDK();
    if (paramContext != null)
      aFf1wSDK.AFKeystoreWrapper = (Application)paramContext.getApplicationContext(); 
    aFf1wSDK.afErrorLog = paramString;
    aFf1wSDK.AFInAppEventType = paramAppsFlyerRequestListener;
    if (paramMap != null && paramMap.containsKey("af_touch_obj")) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      Object object = paramMap.get("af_touch_obj");
      if (object instanceof android.view.MotionEvent) {
        object = object;
        HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
        hashMap1.put("x", Float.valueOf(object.getX()));
        hashMap1.put("y", Float.valueOf(object.getY()));
        hashMap.put("loc", hashMap1);
        hashMap.put("pf", Float.valueOf(object.getPressure()));
        hashMap.put("rad", Float.valueOf(object.getTouchMajor() / 2.0F));
      } else {
        hashMap.put("error", "Parsing failed due to invalid input in 'af_touch_obj'.");
        AFLogger.valueOf("Parsing failed due to invalid input in 'af_touch_obj'.");
      } 
      Map<String, HashMap<Object, Object>> map = Collections.singletonMap("tch_data", hashMap);
      paramMap.remove("af_touch_obj");
      aFf1wSDK.AFInAppEventParameterName(map);
    } 
    aFf1wSDK.values = paramMap;
    AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
    if (aFf1wSDK.values == null) {
      paramMap = new HashMap<String, Object>();
    } else {
      paramMap = aFf1wSDK.values;
    } 
    aFb1sSDK.values("logEvent", new String[] { paramString, (new JSONObject(paramMap)).toString() });
    if (paramString == null)
      values(paramContext, AFe1iSDK.AFInAppEventParameterName); 
    paramString = str;
    if (paramContext instanceof Activity)
      activity = (Activity)paramContext; 
    AFInAppEventType(aFf1wSDK, activity);
  }
  
  public final void logLocation(Context paramContext, double paramDouble1, double paramDouble2) {
    AFKeystoreWrapper().AFVersionDeclaration().values("logLocation", new String[] { String.valueOf(paramDouble1), String.valueOf(paramDouble2) });
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("af_long", Double.toString(paramDouble2));
    hashMap.put("af_lat", Double.toString(paramDouble1));
    AFKeystoreWrapper(paramContext, "af_location_coordinates", (Map)hashMap);
    int i = onAttributionFailure + 37;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1)
      try {
        i = 59 / 0;
        return;
      } finally {} 
  }
  
  public final void logSession(Context paramContext) {
    int i = onResponse + 15;
    onAttributionFailure = i % 128;
    AFKeystoreWrapper().AFVersionDeclaration().values("logSession", new String[0]);
    AFKeystoreWrapper().AFVersionDeclaration().AFInAppEventType();
    values(paramContext, AFe1iSDK.values);
    AFKeystoreWrapper(paramContext, (String)null, (Map<String, Object>)null);
    i = onAttributionFailure + 43;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 9;
    } else {
      i = 86;
    } 
    if (i != 9)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void onPause(Context paramContext) {
    int i = onAttributionFailure + 55;
    onResponse = i % 128;
    AFKeystoreWrapper().onResponseNative().AFKeystoreWrapper(paramContext);
    i = onResponse + 29;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 97;
    } else {
      i = 90;
    } 
    if (i == 90)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  @Deprecated
  public final void performOnAppAttribution(Context paramContext, URI paramURI) {
    StringBuilder stringBuilder2;
    int i;
    if (paramURI != null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onResponse + 113;
      onAttributionFailure = i % 128;
      if (!paramURI.toString().isEmpty()) {
        if (paramContext == null) {
          stringBuilder2 = new StringBuilder("Context is \"");
          stringBuilder2.append(paramContext);
          stringBuilder2.append("\"");
          AFb1oSDK.values(stringBuilder2.toString(), DeepLinkResult.Error.NETWORK);
          return;
        } 
        AFKeystoreWrapper().onAppOpenAttributionNative();
        AFa1tSDK.AFKeystoreWrapper(paramContext, new HashMap<Object, Object>(), Uri.parse(stringBuilder2.toString()));
        i = onResponse + 39;
        onAttributionFailure = i % 128;
        if (i % 2 == 0) {
          i = 63;
        } else {
          i = 6;
        } 
        if (i != 63)
          return; 
        try {
          throw new NullPointerException();
        } finally {}
      } 
    } 
    StringBuilder stringBuilder1 = new StringBuilder("Link is \"");
    stringBuilder1.append(stringBuilder2);
    stringBuilder1.append("\"");
    AFb1oSDK.values(stringBuilder1.toString(), DeepLinkResult.Error.NETWORK);
  }
  
  public final void performOnDeepLinking(Intent paramIntent, Context paramContext) {
    int i = onAttributionFailure + 105;
    i %= 128;
    onResponse = i;
    if (paramIntent == null) {
      i += 65;
      onAttributionFailure = i % 128;
      AFb1oSDK.values("performOnDeepLinking was called with null intent", DeepLinkResult.Error.DEVELOPER_ERROR);
      i = onAttributionFailure + 99;
      onResponse = i % 128;
      if (i % 2 != 0) {
        i = 52;
      } else {
        i = 7;
      } 
      if (i == 7)
        return; 
      try {
        throw new NullPointerException();
      } finally {}
    } 
    if (paramContext == null) {
      i = 32;
    } else {
      i = 54;
    } 
    if (i != 32) {
      paramContext = paramContext.getApplicationContext();
      AFInAppEventType(paramContext);
      AFKeystoreWrapper().AFInAppEventType().execute((Runnable)new AFb1xSDK$.ExternalSyntheticLambda0(this, paramContext, paramIntent));
      return;
    } 
    AFb1oSDK.values("performOnDeepLinking was called with null context", DeepLinkResult.Error.DEVELOPER_ERROR);
  }
  
  public final void registerConversionListener(Context paramContext, AppsFlyerConversionListener paramAppsFlyerConversionListener) {
    int i = onResponse + 31;
    onAttributionFailure = i % 128;
    AFKeystoreWrapper().AFVersionDeclaration().values("registerConversionListener", new String[0]);
    values(paramAppsFlyerConversionListener);
    i = onAttributionFailure + 91;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 83;
    } else {
      i = 33;
    } 
    if (i == 33)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void registerValidatorListener(Context paramContext, AppsFlyerInAppPurchaseValidatorListener paramAppsFlyerInAppPurchaseValidatorListener) {
    null = AFKeystoreWrapper().AFVersionDeclaration();
    int i = 0;
    null.values("registerValidatorListener", new String[0]);
    AFLogger.afDebugLog("registerValidatorListener called");
    if (paramAppsFlyerInAppPurchaseValidatorListener != null)
      i = 1; 
    if (i != 1) {
      i = onResponse + 17;
      onAttributionFailure = i % 128;
      AFLogger.afDebugLog("registerValidatorListener null listener");
      return;
    } 
    AFInAppEventType = paramAppsFlyerInAppPurchaseValidatorListener;
    i = onResponse + 99;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 82;
    } else {
      i = 49;
    } 
    if (i == 49)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  public final void sendAdRevenue(Context paramContext, Map<String, Object> paramMap) {
    AFInAppEventType(paramContext);
    AFe1dSDK aFe1dSDK = new AFe1dSDK();
    boolean bool = false;
    if (paramContext != null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      ((AFa1sSDK)aFe1dSDK).AFKeystoreWrapper = (Application)paramContext.getApplicationContext();
      i = onResponse + 57;
      onAttributionFailure = i % 128;
    } 
    int i = AFKeystoreWrapper(valueOf(paramContext));
    aFe1dSDK.AFInAppEventType().put("ad_network", paramMap);
    aFe1dSDK.AFInAppEventType().put("adrevenue_counter", Integer.valueOf(i));
    if (paramContext instanceof Activity) {
      i = bool;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onAttributionFailure + 13;
      onResponse = i % 128;
      Activity activity = (Activity)paramContext;
    } else {
      i = onResponse + 49;
      onAttributionFailure = i % 128;
      paramContext = null;
    } 
    AFInAppEventType((AFa1sSDK)aFe1dSDK, (Activity)paramContext);
  }
  
  public final void sendInAppPurchaseData(Context paramContext, Map<String, Object> paramMap, PurchaseHandler.PurchaseValidationCallback paramPurchaseValidationCallback) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: bipush #87
    //   5: iadd
    //   6: istore #4
    //   8: iload #4
    //   10: sipush #128
    //   13: irem
    //   14: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   17: iload #4
    //   19: iconst_2
    //   20: irem
    //   21: ifeq -> 31
    //   24: bipush #50
    //   26: istore #4
    //   28: goto -> 35
    //   31: bipush #28
    //   33: istore #4
    //   35: iload #4
    //   37: bipush #28
    //   39: if_icmpeq -> 84
    //   42: aload_0
    //   43: aload_1
    //   44: invokevirtual AFInAppEventType : (Landroid/content/Context;)V
    //   47: aload_0
    //   48: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   51: invokeinterface afInfoLog : ()Lcom/appsflyer/PurchaseHandler;
    //   56: astore_1
    //   57: iconst_0
    //   58: anewarray java/lang/String
    //   61: astore #5
    //   63: aload #5
    //   65: iconst_0
    //   66: ldc_w 'purchases'
    //   69: aastore
    //   70: aload_1
    //   71: aload_2
    //   72: aload_3
    //   73: aload #5
    //   75: invokevirtual AFKeystoreWrapper : (Ljava/util/Map;Lcom/appsflyer/PurchaseHandler$PurchaseValidationCallback;[Ljava/lang/String;)Z
    //   78: ifeq -> 155
    //   81: goto -> 118
    //   84: aload_0
    //   85: aload_1
    //   86: invokevirtual AFInAppEventType : (Landroid/content/Context;)V
    //   89: aload_0
    //   90: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   93: invokeinterface afInfoLog : ()Lcom/appsflyer/PurchaseHandler;
    //   98: astore_1
    //   99: aload_1
    //   100: aload_2
    //   101: aload_3
    //   102: iconst_1
    //   103: anewarray java/lang/String
    //   106: dup
    //   107: iconst_0
    //   108: ldc_w 'purchases'
    //   111: aastore
    //   112: invokevirtual AFKeystoreWrapper : (Ljava/util/Map;Lcom/appsflyer/PurchaseHandler$PurchaseValidationCallback;[Ljava/lang/String;)Z
    //   115: ifeq -> 155
    //   118: new com/appsflyer/internal/AFd1eSDK
    //   121: dup
    //   122: aload_2
    //   123: aload_3
    //   124: aload_1
    //   125: getfield valueOf : Lcom/appsflyer/internal/AFc1vSDK;
    //   128: invokespecial <init> : (Ljava/util/Map;Lcom/appsflyer/PurchaseHandler$PurchaseValidationCallback;Lcom/appsflyer/internal/AFc1vSDK;)V
    //   131: astore_2
    //   132: aload_1
    //   133: getfield values : Lcom/appsflyer/internal/AFd1pSDK;
    //   136: astore_1
    //   137: aload_1
    //   138: getfield AFKeystoreWrapper : Ljava/util/concurrent/Executor;
    //   141: new com/appsflyer/internal/AFd1pSDK$5
    //   144: dup
    //   145: aload_1
    //   146: aload_2
    //   147: invokespecial <init> : (Lcom/appsflyer/internal/AFd1pSDK;Lcom/appsflyer/internal/AFd1qSDK;)V
    //   150: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   155: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   158: bipush #73
    //   160: iadd
    //   161: istore #4
    //   163: iload #4
    //   165: sipush #128
    //   168: irem
    //   169: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   172: return
  }
  
  public final void sendPurchaseData(Context paramContext, Map<String, Object> paramMap, PurchaseHandler.PurchaseValidationCallback paramPurchaseValidationCallback) {
    int i = onAttributionFailure + 53;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    AFInAppEventType(paramContext);
    PurchaseHandler purchaseHandler = AFKeystoreWrapper().afInfoLog();
    AFInAppEventType((Context)purchaseHandler);
    purchaseHandler = AFKeystoreWrapper().afInfoLog();
    if ((i != 0) ? purchaseHandler.AFKeystoreWrapper(paramMap, paramPurchaseValidationCallback, new String[] { "subscriptions" }) : purchaseHandler.AFKeystoreWrapper(paramMap, paramPurchaseValidationCallback, new String[] { "subscriptions" })) {
      AFd1mSDK aFd1mSDK = new AFd1mSDK(paramMap, paramPurchaseValidationCallback, purchaseHandler.valueOf);
      AFd1pSDK aFd1pSDK = purchaseHandler.values;
      aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)aFd1mSDK));
    } 
    i = onAttributionFailure + 41;
    onResponse = i % 128;
  }
  
  public final void sendPushNotificationData(Activity paramActivity) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 10
    //   4: bipush #37
    //   6: istore_2
    //   7: goto -> 13
    //   10: bipush #62
    //   12: istore_2
    //   13: iload_2
    //   14: bipush #62
    //   16: if_icmpeq -> 150
    //   19: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   22: bipush #51
    //   24: iadd
    //   25: istore_2
    //   26: iload_2
    //   27: sipush #128
    //   30: irem
    //   31: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   34: iload_2
    //   35: iconst_2
    //   36: irem
    //   37: ifne -> 46
    //   40: bipush #42
    //   42: istore_2
    //   43: goto -> 49
    //   46: bipush #35
    //   48: istore_2
    //   49: iload_2
    //   50: bipush #42
    //   52: if_icmpeq -> 134
    //   55: aload_1
    //   56: invokevirtual getIntent : ()Landroid/content/Intent;
    //   59: ifnull -> 150
    //   62: aload_0
    //   63: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   66: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   71: astore #16
    //   73: aload_1
    //   74: invokevirtual getLocalClassName : ()Ljava/lang/String;
    //   77: astore #14
    //   79: new java/lang/StringBuilder
    //   82: dup
    //   83: ldc_w 'activity_intent_'
    //   86: invokespecial <init> : (Ljava/lang/String;)V
    //   89: astore #15
    //   91: aload #15
    //   93: aload_1
    //   94: invokevirtual getIntent : ()Landroid/content/Intent;
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload #16
    //   106: ldc_w 'sendPushNotificationData'
    //   109: iconst_2
    //   110: anewarray java/lang/String
    //   113: dup
    //   114: iconst_0
    //   115: aload #14
    //   117: aastore
    //   118: dup
    //   119: iconst_1
    //   120: aload #15
    //   122: invokevirtual toString : ()Ljava/lang/String;
    //   125: aastore
    //   126: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   131: goto -> 248
    //   134: aload_1
    //   135: invokevirtual getIntent : ()Landroid/content/Intent;
    //   138: pop
    //   139: new java/lang/NullPointerException
    //   142: dup
    //   143: invokespecial <init> : ()V
    //   146: athrow
    //   147: astore_1
    //   148: aload_1
    //   149: athrow
    //   150: aload_1
    //   151: ifnull -> 221
    //   154: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   157: bipush #65
    //   159: iadd
    //   160: istore_2
    //   161: iload_2
    //   162: sipush #128
    //   165: irem
    //   166: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   169: aload_0
    //   170: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   173: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   178: ldc_w 'sendPushNotificationData'
    //   181: iconst_2
    //   182: anewarray java/lang/String
    //   185: dup
    //   186: iconst_0
    //   187: aload_1
    //   188: invokevirtual getLocalClassName : ()Ljava/lang/String;
    //   191: aastore
    //   192: dup
    //   193: iconst_1
    //   194: ldc_w 'activity_intent_null'
    //   197: aastore
    //   198: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   203: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   206: bipush #39
    //   208: iadd
    //   209: istore_2
    //   210: iload_2
    //   211: sipush #128
    //   214: irem
    //   215: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   218: goto -> 248
    //   221: aload_0
    //   222: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   225: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   230: ldc_w 'sendPushNotificationData'
    //   233: iconst_1
    //   234: anewarray java/lang/String
    //   237: dup
    //   238: iconst_0
    //   239: ldc_w 'activity_null'
    //   242: aastore
    //   243: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   248: aload_1
    //   249: invokestatic values : (Landroid/app/Activity;)Ljava/lang/String;
    //   252: astore #14
    //   254: aload_0
    //   255: aload #14
    //   257: putfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   260: aload #14
    //   262: ifnull -> 271
    //   265: bipush #78
    //   267: istore_2
    //   268: goto -> 274
    //   271: bipush #96
    //   273: istore_2
    //   274: iload_2
    //   275: bipush #96
    //   277: if_icmpeq -> 814
    //   280: invokestatic currentTimeMillis : ()J
    //   283: lstore_3
    //   284: aload_0
    //   285: getfield getLevel : Ljava/util/Map;
    //   288: ifnonnull -> 314
    //   291: ldc_w 'pushes: initializing pushes history..'
    //   294: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   297: aload_0
    //   298: new java/util/concurrent/ConcurrentHashMap
    //   301: dup
    //   302: invokespecial <init> : ()V
    //   305: putfield getLevel : Ljava/util/Map;
    //   308: lload_3
    //   309: lstore #7
    //   311: goto -> 715
    //   314: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   317: ldc_w 'pushPayloadMaxAging'
    //   320: ldc2_w 1800000
    //   323: invokevirtual getLong : (Ljava/lang/String;J)J
    //   326: lstore #9
    //   328: aload_0
    //   329: getfield getLevel : Ljava/util/Map;
    //   332: invokeinterface keySet : ()Ljava/util/Set;
    //   337: invokeinterface iterator : ()Ljava/util/Iterator;
    //   342: astore #17
    //   344: lload_3
    //   345: lstore #7
    //   347: lload #7
    //   349: lstore #5
    //   351: lload #5
    //   353: lstore #7
    //   355: aload #17
    //   357: invokeinterface hasNext : ()Z
    //   362: ifeq -> 715
    //   365: aload #17
    //   367: invokeinterface next : ()Ljava/lang/Object;
    //   372: checkcast java/lang/Long
    //   375: astore #16
    //   377: new org/json/JSONObject
    //   380: dup
    //   381: aload_0
    //   382: getfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   385: invokespecial <init> : (Ljava/lang/String;)V
    //   388: astore #14
    //   390: new org/json/JSONObject
    //   393: dup
    //   394: aload_0
    //   395: getfield getLevel : Ljava/util/Map;
    //   398: aload #16
    //   400: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   405: checkcast java/lang/String
    //   408: invokespecial <init> : (Ljava/lang/String;)V
    //   411: astore #15
    //   413: aload #14
    //   415: ldc_w 'pid'
    //   418: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   421: aload #15
    //   423: ldc_w 'pid'
    //   426: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   429: invokevirtual equals : (Ljava/lang/Object;)Z
    //   432: istore #13
    //   434: iload #13
    //   436: ifeq -> 596
    //   439: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   442: bipush #103
    //   444: iadd
    //   445: istore_2
    //   446: iload_2
    //   447: sipush #128
    //   450: irem
    //   451: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   454: iload_2
    //   455: iconst_2
    //   456: irem
    //   457: ifeq -> 568
    //   460: aload #14
    //   462: ldc_w 'c'
    //   465: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   468: aload #15
    //   470: ldc_w 'c'
    //   473: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   476: invokevirtual equals : (Ljava/lang/Object;)Z
    //   479: ifeq -> 596
    //   482: new java/lang/StringBuilder
    //   485: dup
    //   486: ldc_w 'PushNotificationMeasurement: A previous payload with same PID and campaign was already acknowledged! (old: '
    //   489: invokespecial <init> : (Ljava/lang/String;)V
    //   492: astore #16
    //   494: aload #16
    //   496: aload #15
    //   498: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   501: pop
    //   502: aload #16
    //   504: ldc_w ', new: '
    //   507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   510: pop
    //   511: aload #16
    //   513: aload #14
    //   515: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   518: pop
    //   519: aload #16
    //   521: ldc_w ')'
    //   524: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   527: pop
    //   528: aload #16
    //   530: invokevirtual toString : ()Ljava/lang/String;
    //   533: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   536: aload_0
    //   537: aconst_null
    //   538: putfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   541: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   544: bipush #79
    //   546: iadd
    //   547: istore_2
    //   548: iload_2
    //   549: sipush #128
    //   552: irem
    //   553: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   556: iload_2
    //   557: iconst_2
    //   558: irem
    //   559: ifne -> 563
    //   562: return
    //   563: aconst_null
    //   564: athrow
    //   565: astore_1
    //   566: aload_1
    //   567: athrow
    //   568: aload #14
    //   570: ldc_w 'c'
    //   573: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   576: aload #15
    //   578: ldc_w 'c'
    //   581: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   584: invokevirtual equals : (Ljava/lang/Object;)Z
    //   587: pop
    //   588: new java/lang/NullPointerException
    //   591: dup
    //   592: invokespecial <init> : ()V
    //   595: athrow
    //   596: lload_3
    //   597: aload #16
    //   599: invokevirtual longValue : ()J
    //   602: lsub
    //   603: lload #9
    //   605: lcmp
    //   606: ifle -> 621
    //   609: aload_0
    //   610: getfield getLevel : Ljava/util/Map;
    //   613: aload #16
    //   615: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   620: pop
    //   621: aload #16
    //   623: invokevirtual longValue : ()J
    //   626: lstore #11
    //   628: lload #5
    //   630: lstore #7
    //   632: lload #11
    //   634: lload #5
    //   636: lcmp
    //   637: ifgt -> 347
    //   640: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   643: bipush #7
    //   645: iadd
    //   646: istore_2
    //   647: iload_2
    //   648: sipush #128
    //   651: irem
    //   652: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   655: aload #16
    //   657: invokevirtual longValue : ()J
    //   660: lstore #7
    //   662: goto -> 347
    //   665: astore #14
    //   667: goto -> 675
    //   670: astore #14
    //   672: lload_3
    //   673: lstore #5
    //   675: new java/lang/StringBuilder
    //   678: dup
    //   679: ldc_w 'Error while handling push notification measurement: '
    //   682: invokespecial <init> : (Ljava/lang/String;)V
    //   685: astore #15
    //   687: aload #15
    //   689: aload #14
    //   691: invokevirtual getClass : ()Ljava/lang/Class;
    //   694: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   697: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   700: pop
    //   701: aload #15
    //   703: invokevirtual toString : ()Ljava/lang/String;
    //   706: aload #14
    //   708: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   711: lload #5
    //   713: lstore #7
    //   715: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   718: ldc_w 'pushPayloadHistorySize'
    //   721: iconst_2
    //   722: invokevirtual getInt : (Ljava/lang/String;I)I
    //   725: istore_2
    //   726: aload_0
    //   727: getfield getLevel : Ljava/util/Map;
    //   730: invokeinterface size : ()I
    //   735: iload_2
    //   736: if_icmpne -> 791
    //   739: new java/lang/StringBuilder
    //   742: dup
    //   743: ldc_w 'pushes: removing oldest overflowing push (oldest push:'
    //   746: invokespecial <init> : (Ljava/lang/String;)V
    //   749: astore #14
    //   751: aload #14
    //   753: lload #7
    //   755: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   758: pop
    //   759: aload #14
    //   761: ldc_w ')'
    //   764: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   767: pop
    //   768: aload #14
    //   770: invokevirtual toString : ()Ljava/lang/String;
    //   773: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   776: aload_0
    //   777: getfield getLevel : Ljava/util/Map;
    //   780: lload #7
    //   782: invokestatic valueOf : (J)Ljava/lang/Long;
    //   785: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   790: pop
    //   791: aload_0
    //   792: getfield getLevel : Ljava/util/Map;
    //   795: lload_3
    //   796: invokestatic valueOf : (J)Ljava/lang/Long;
    //   799: aload_0
    //   800: getfield afErrorLogForExcManagerOnly : Ljava/lang/String;
    //   803: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   808: pop
    //   809: aload_0
    //   810: aload_1
    //   811: invokevirtual start : (Landroid/content/Context;)V
    //   814: return
    // Exception table:
    //   from	to	target	type
    //   139	147	147	finally
    //   314	344	670	finally
    //   355	434	665	finally
    //   460	541	665	finally
    //   563	565	565	finally
    //   568	596	665	finally
    //   596	621	665	finally
    //   621	628	665	finally
    //   655	662	665	finally
  }
  
  public final void setAdditionalData(Map<String, Object> paramMap) {
    int i = onResponse + 85;
    onAttributionFailure = i % 128;
    if (paramMap != null) {
      AFKeystoreWrapper().AFVersionDeclaration().values("setAdditionalData", new String[] { paramMap.toString() });
      JSONObject jSONObject = new JSONObject(paramMap);
      AppsFlyerProperties.getInstance().setCustomData(jSONObject.toString());
    } 
    i = onResponse + 29;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1)
      try {
        i = 50 / 0;
        return;
      } finally {} 
  }
  
  public final void setAndroidIdData(String paramString) {
    int i = onResponse + 35;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
      String[] arrayOfString = new String[1];
      arrayOfString[1] = paramString;
      aFb1sSDK.values("setAndroidIdData", arrayOfString);
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("setAndroidIdData", new String[] { paramString });
    } 
    this.afInfoLog = paramString;
    i = onAttributionFailure + 121;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 24;
    } else {
      i = 14;
    } 
    if (i != 24)
      return; 
    try {
      i = 43 / 0;
      return;
    } finally {}
  }
  
  public final void setAppId(String paramString) {
    int i = onResponse + 61;
    onAttributionFailure = i % 128;
    AFKeystoreWrapper().AFVersionDeclaration().values("setAppId", new String[] { paramString });
    valueOf("appid", paramString);
    i = onAttributionFailure + 55;
    onResponse = i % 128;
  }
  
  public final void setAppInviteOneLink(String paramString) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: istore_2
    //   4: iconst_3
    //   5: istore #4
    //   7: iload_2
    //   8: iconst_3
    //   9: iadd
    //   10: istore_2
    //   11: iload_2
    //   12: sipush #128
    //   15: irem
    //   16: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   19: iconst_0
    //   20: istore_3
    //   21: iload_2
    //   22: iconst_2
    //   23: irem
    //   24: ifeq -> 32
    //   27: iconst_0
    //   28: istore_2
    //   29: goto -> 34
    //   32: iconst_1
    //   33: istore_2
    //   34: iload_2
    //   35: iconst_1
    //   36: if_icmpeq -> 93
    //   39: aload_0
    //   40: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   43: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   48: astore #6
    //   50: iconst_0
    //   51: anewarray java/lang/String
    //   54: astore #7
    //   56: aload #7
    //   58: iconst_0
    //   59: aload_1
    //   60: aastore
    //   61: aload #6
    //   63: ldc_w 'setAppInviteOneLink'
    //   66: aload #7
    //   68: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   73: ldc_w 'setAppInviteOneLink = '
    //   76: aload_1
    //   77: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   80: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   83: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   86: aload_1
    //   87: ifnull -> 256
    //   90: goto -> 150
    //   93: aload_0
    //   94: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   97: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   102: ldc_w 'setAppInviteOneLink'
    //   105: iconst_1
    //   106: anewarray java/lang/String
    //   109: dup
    //   110: iconst_0
    //   111: aload_1
    //   112: aastore
    //   113: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   118: ldc_w 'setAppInviteOneLink = '
    //   121: aload_1
    //   122: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   125: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   128: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   131: iload #4
    //   133: istore_2
    //   134: aload_1
    //   135: ifnull -> 141
    //   138: bipush #46
    //   140: istore_2
    //   141: iload_2
    //   142: bipush #46
    //   144: if_icmpeq -> 150
    //   147: goto -> 256
    //   150: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   153: bipush #73
    //   155: iadd
    //   156: istore_2
    //   157: iload_2
    //   158: sipush #128
    //   161: irem
    //   162: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   165: iload_2
    //   166: iconst_2
    //   167: irem
    //   168: ifeq -> 176
    //   171: iconst_1
    //   172: istore_2
    //   173: goto -> 178
    //   176: iconst_0
    //   177: istore_2
    //   178: iload_2
    //   179: ifeq -> 228
    //   182: aload_1
    //   183: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   186: ldc_w 'oneLinkSlug'
    //   189: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   192: invokevirtual equals : (Ljava/lang/Object;)Z
    //   195: istore #5
    //   197: bipush #84
    //   199: iconst_0
    //   200: idiv
    //   201: istore_2
    //   202: iload #5
    //   204: ifne -> 213
    //   207: bipush #66
    //   209: istore_2
    //   210: goto -> 216
    //   213: bipush #52
    //   215: istore_2
    //   216: iload_2
    //   217: bipush #66
    //   219: if_icmpeq -> 256
    //   222: goto -> 283
    //   225: astore_1
    //   226: aload_1
    //   227: athrow
    //   228: iload_3
    //   229: istore_2
    //   230: aload_1
    //   231: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   234: ldc_w 'oneLinkSlug'
    //   237: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   240: invokevirtual equals : (Ljava/lang/Object;)Z
    //   243: ifne -> 248
    //   246: iconst_1
    //   247: istore_2
    //   248: iload_2
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 283
    //   256: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   259: ldc_w 'onelinkDomain'
    //   262: invokevirtual remove : (Ljava/lang/String;)V
    //   265: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   268: ldc_w 'onelinkVersion'
    //   271: invokevirtual remove : (Ljava/lang/String;)V
    //   274: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   277: ldc_w 'onelinkScheme'
    //   280: invokevirtual remove : (Ljava/lang/String;)V
    //   283: ldc_w 'oneLinkSlug'
    //   286: aload_1
    //   287: invokestatic valueOf : (Ljava/lang/String;Ljava/lang/String;)V
    //   290: return
    // Exception table:
    //   from	to	target	type
    //   197	202	225	finally
  }
  
  public final void setCollectAndroidID(boolean paramBoolean) {
    int i = onResponse + 107;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 93;
    } else {
      i = 63;
    } 
    if (i != 93) {
      AFKeystoreWrapper().AFVersionDeclaration().values("setCollectAndroidID", new String[] { String.valueOf(paramBoolean) });
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("setCollectAndroidID", new String[] { String.valueOf(paramBoolean) });
    } 
    valueOf("collectAndroidId", Boolean.toString(paramBoolean));
    valueOf("collectAndroidIdForceByUser", Boolean.toString(paramBoolean));
  }
  
  public final void setCollectIMEI(boolean paramBoolean) {
    int i = onResponse + 81;
    onAttributionFailure = i % 128;
    null = AFKeystoreWrapper().AFVersionDeclaration();
    i = 0;
    null.values("setCollectIMEI", new String[] { String.valueOf(paramBoolean) });
    valueOf("collectIMEI", Boolean.toString(paramBoolean));
    valueOf("collectIMEIForceByUser", Boolean.toString(paramBoolean));
    int j = onAttributionFailure + 93;
    onResponse = j % 128;
    if (j % 2 != 0)
      i = 1; 
    if (i != 1)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  @Deprecated
  public final void setCollectOaid(boolean paramBoolean) {
    int i = onAttributionFailure + 47;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 30;
    } else {
      i = 42;
    } 
    if (i != 42) {
      AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
      String[] arrayOfString = new String[0];
      arrayOfString[1] = String.valueOf(paramBoolean);
      aFb1sSDK.values("setCollectOaid", arrayOfString);
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("setCollectOaid", new String[] { String.valueOf(paramBoolean) });
    } 
    valueOf("collectOAID", Boolean.toString(paramBoolean));
    i = onAttributionFailure + 101;
    onResponse = i % 128;
  }
  
  public final void setCurrencyCode(String paramString) {
    int i = onAttributionFailure + 35;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 65;
    } else {
      i = 47;
    } 
    if (i != 47) {
      AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
      String[] arrayOfString = new String[1];
      arrayOfString[1] = paramString;
      aFb1sSDK.values("setCurrencyCode", arrayOfString);
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("setCurrencyCode", new String[] { paramString });
    } 
    AppsFlyerProperties.getInstance().set("currencyCode", paramString);
    i = onAttributionFailure + 17;
    onResponse = i % 128;
  }
  
  public final void setCustomerIdAndLogSession(String paramString, Context paramContext) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   3: bipush #35
    //   5: iadd
    //   6: istore_3
    //   7: iload_3
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   15: iload_3
    //   16: iconst_2
    //   17: irem
    //   18: ifne -> 26
    //   21: iconst_0
    //   22: istore_3
    //   23: goto -> 28
    //   26: iconst_1
    //   27: istore_3
    //   28: iload_3
    //   29: iconst_1
    //   30: if_icmpeq -> 63
    //   33: bipush #94
    //   35: iconst_0
    //   36: idiv
    //   37: istore_3
    //   38: aload_2
    //   39: ifnull -> 48
    //   42: bipush #24
    //   44: istore_3
    //   45: goto -> 51
    //   48: bipush #40
    //   50: istore_3
    //   51: iload_3
    //   52: bipush #40
    //   54: if_icmpeq -> 282
    //   57: goto -> 67
    //   60: astore_1
    //   61: aload_1
    //   62: athrow
    //   63: aload_2
    //   64: ifnull -> 282
    //   67: aload_0
    //   68: invokevirtual values : ()Z
    //   71: ifeq -> 263
    //   74: aload_0
    //   75: aload_1
    //   76: invokevirtual setCustomerUserId : (Ljava/lang/String;)V
    //   79: new java/lang/StringBuilder
    //   82: dup
    //   83: ldc_w 'CustomerUserId set: '
    //   86: invokespecial <init> : (Ljava/lang/String;)V
    //   89: astore #4
    //   91: aload #4
    //   93: aload_1
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: pop
    //   98: aload #4
    //   100: ldc_w ' - Initializing AppsFlyer Tacking'
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload #4
    //   109: invokevirtual toString : ()Ljava/lang/String;
    //   112: iconst_1
    //   113: invokestatic afInfoLog : (Ljava/lang/String;Z)V
    //   116: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   119: aload_2
    //   120: invokevirtual getReferrer : (Landroid/content/Context;)Ljava/lang/String;
    //   123: astore #4
    //   125: aload_0
    //   126: aload_2
    //   127: getstatic com/appsflyer/internal/AFe1iSDK.valueOf : Lcom/appsflyer/internal/AFe1iSDK;
    //   130: invokespecial values : (Landroid/content/Context;Lcom/appsflyer/internal/AFe1iSDK;)V
    //   133: aload_0
    //   134: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   137: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   142: getfield AFInAppEventType : Ljava/lang/String;
    //   145: astore_1
    //   146: aload #4
    //   148: astore_1
    //   149: aload #4
    //   151: ifnonnull -> 186
    //   154: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   157: bipush #61
    //   159: iadd
    //   160: istore_3
    //   161: iload_3
    //   162: sipush #128
    //   165: irem
    //   166: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   169: iload_3
    //   170: iconst_2
    //   171: irem
    //   172: ifne -> 181
    //   175: ldc ''
    //   177: astore_1
    //   178: goto -> 186
    //   181: aconst_null
    //   182: athrow
    //   183: astore_1
    //   184: aload_1
    //   185: athrow
    //   186: aload_2
    //   187: instanceof android/app/Activity
    //   190: ifeq -> 253
    //   193: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   196: bipush #85
    //   198: iadd
    //   199: istore_3
    //   200: iload_3
    //   201: sipush #128
    //   204: irem
    //   205: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   208: iload_3
    //   209: iconst_2
    //   210: irem
    //   211: ifeq -> 219
    //   214: iconst_0
    //   215: istore_3
    //   216: goto -> 221
    //   219: iconst_1
    //   220: istore_3
    //   221: iload_3
    //   222: iconst_1
    //   223: if_icmpeq -> 245
    //   226: aload_2
    //   227: checkcast android/app/Activity
    //   230: invokevirtual getIntent : ()Landroid/content/Intent;
    //   233: pop
    //   234: bipush #95
    //   236: iconst_0
    //   237: idiv
    //   238: istore_3
    //   239: goto -> 253
    //   242: astore_1
    //   243: aload_1
    //   244: athrow
    //   245: aload_2
    //   246: checkcast android/app/Activity
    //   249: invokevirtual getIntent : ()Landroid/content/Intent;
    //   252: pop
    //   253: aload_0
    //   254: aload_2
    //   255: aconst_null
    //   256: aconst_null
    //   257: aload_1
    //   258: aconst_null
    //   259: invokespecial AFInAppEventParameterName : (Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    //   262: return
    //   263: aload_0
    //   264: aload_1
    //   265: invokevirtual setCustomerUserId : (Ljava/lang/String;)V
    //   268: ldc_w 'waitForCustomerUserId is false; setting CustomerUserID: '
    //   271: aload_1
    //   272: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   275: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   278: iconst_1
    //   279: invokestatic afInfoLog : (Ljava/lang/String;Z)V
    //   282: return
    // Exception table:
    //   from	to	target	type
    //   33	38	60	finally
    //   181	183	183	finally
    //   234	239	242	finally
  }
  
  public final void setCustomerUserId(String paramString) {
    int i = onAttributionFailure + 79;
    onResponse = i % 128;
    AFKeystoreWrapper().AFVersionDeclaration().values("setCustomerUserId", new String[] { paramString });
    AFLogger.afInfoLog("setCustomerUserId = ".concat(String.valueOf(paramString)));
    valueOf("AppUserId", paramString);
    AFInAppEventParameterName("waitForCustomerId", false);
    i = onAttributionFailure + 103;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 46;
    } else {
      i = 67;
    } 
    if (i != 46)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void setDebugLog(boolean paramBoolean) {
    AFLogger.LogLevel logLevel;
    int i = onAttributionFailure + 21;
    onResponse = i % 128;
    if (paramBoolean) {
      i = 34;
    } else {
      i = 78;
    } 
    if (i != 34) {
      logLevel = AFLogger.LogLevel.NONE;
    } else {
      logLevel = AFLogger.LogLevel.DEBUG;
      i = onResponse + 119;
      onAttributionFailure = i % 128;
    } 
    super.setLogLevel(logLevel);
  }
  
  public final void setDisableAdvertisingIdentifiers(boolean paramBoolean) {
    int i = onAttributionFailure + 49;
    onResponse = i % 128;
    AFLogger.afDebugLog("setDisableAdvertisingIdentifiers: ".concat(String.valueOf(paramBoolean)));
    if (!paramBoolean) {
      i = 57;
    } else {
      i = 21;
    } 
    paramBoolean = false;
    boolean bool = false;
    if (i == 57) {
      i = onAttributionFailure + 119;
      int j = i % 128;
      onResponse = j;
      if (i % 2 != 0) {
        i = 0;
      } else {
        i = 11;
      } 
      if (i != 11) {
        paramBoolean = bool;
      } else {
        paramBoolean = true;
      } 
      i = j + 5;
      onAttributionFailure = i % 128;
    } 
    AFa1bSDK.AFInAppEventType = Boolean.valueOf(paramBoolean);
    AppsFlyerProperties.getInstance().remove("advertiserIdEnabled");
    AppsFlyerProperties.getInstance().remove("advertiserId");
    i = onResponse + 35;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 57;
    } else {
      i = 76;
    } 
    if (i != 57)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void setDisableNetworkData(boolean paramBoolean) {
    int i = onResponse + 17;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 82;
    } else {
      i = 30;
    } 
    if (i == 30) {
      AFLogger.afDebugLog("setDisableNetworkData: ".concat(String.valueOf(paramBoolean)));
      AFInAppEventParameterName("disableCollectNetworkData", paramBoolean);
      i = onAttributionFailure + 11;
      onResponse = i % 128;
      return;
    } 
    AFLogger.afDebugLog("setDisableNetworkData: ".concat(String.valueOf(paramBoolean)));
    AFInAppEventParameterName("disableCollectNetworkData", paramBoolean);
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void setExtension(String paramString) {
    int i = onAttributionFailure + 77;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 3;
    } else {
      i = 90;
    } 
    if (i != 3) {
      AFKeystoreWrapper().AFVersionDeclaration().values("setExtension", new String[] { paramString });
    } else {
      AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
      String[] arrayOfString = new String[0];
      arrayOfString[1] = paramString;
      aFb1sSDK.values("setExtension", arrayOfString);
    } 
    AppsFlyerProperties.getInstance().set("sdkExtension", paramString);
    i = onResponse + 35;
    onAttributionFailure = i % 128;
  }
  
  public final void setHost(String paramString1, String paramString2) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: bipush #65
    //   5: iadd
    //   6: istore_3
    //   7: iload_3
    //   8: sipush #128
    //   11: irem
    //   12: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   15: iload_3
    //   16: iconst_2
    //   17: irem
    //   18: ifeq -> 43
    //   21: aload_2
    //   22: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Z
    //   25: istore #4
    //   27: bipush #62
    //   29: iconst_0
    //   30: idiv
    //   31: istore_3
    //   32: iload #4
    //   34: ifne -> 148
    //   37: goto -> 50
    //   40: astore_1
    //   41: aload_1
    //   42: athrow
    //   43: aload_2
    //   44: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Z
    //   47: ifne -> 148
    //   50: aload_1
    //   51: ifnull -> 129
    //   54: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   57: bipush #103
    //   59: iadd
    //   60: istore_3
    //   61: iload_3
    //   62: sipush #128
    //   65: irem
    //   66: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   69: iload_3
    //   70: iconst_2
    //   71: irem
    //   72: ifeq -> 81
    //   75: bipush #68
    //   77: istore_3
    //   78: goto -> 84
    //   81: bipush #16
    //   83: istore_3
    //   84: iload_3
    //   85: bipush #16
    //   87: if_icmpeq -> 106
    //   90: aload_1
    //   91: invokevirtual trim : ()Ljava/lang/String;
    //   94: astore_1
    //   95: bipush #63
    //   97: iconst_0
    //   98: idiv
    //   99: istore_3
    //   100: goto -> 111
    //   103: astore_1
    //   104: aload_1
    //   105: athrow
    //   106: aload_1
    //   107: invokevirtual trim : ()Ljava/lang/String;
    //   110: astore_1
    //   111: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   114: bipush #77
    //   116: iadd
    //   117: istore_3
    //   118: iload_3
    //   119: sipush #128
    //   122: irem
    //   123: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   126: goto -> 132
    //   129: ldc ''
    //   131: astore_1
    //   132: new com/appsflyer/internal/AFd1zSDK
    //   135: dup
    //   136: aload_1
    //   137: aload_2
    //   138: invokevirtual trim : ()Ljava/lang/String;
    //   141: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   144: invokestatic values : (Lcom/appsflyer/internal/AFd1zSDK;)V
    //   147: return
    //   148: ldc_w 'hostname was empty or null - call for setHost is skipped'
    //   151: invokestatic afWarnLog : (Ljava/lang/String;)V
    //   154: return
    // Exception table:
    //   from	to	target	type
    //   27	32	40	finally
    //   95	100	103	finally
  }
  
  public final void setImeiData(String paramString) {
    int i = onResponse + 15;
    onAttributionFailure = i % 128;
    AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
    i = 1;
    aFb1sSDK.values("setImeiData", new String[] { paramString });
    (AFKeystoreWrapper().afWarnLog()).valueOf = paramString;
    int j = onResponse + 113;
    onAttributionFailure = j % 128;
    if (j % 2 != 0)
      i = 0; 
    if (i != 0)
      try {
        i = 63 / 0;
        return;
      } finally {} 
  }
  
  public final void setIsUpdate(boolean paramBoolean) {
    int i = onResponse + 89;
    onAttributionFailure = i % 128;
    null = AFKeystoreWrapper().AFVersionDeclaration();
    i = 1;
    null.values("setIsUpdate", new String[] { String.valueOf(paramBoolean) });
    AppsFlyerProperties.getInstance().set("IS_UPDATE", paramBoolean);
    int j = onResponse + 99;
    onAttributionFailure = j % 128;
    if (j % 2 == 0)
      i = 0; 
    if (i != 0)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  public final void setLogLevel(AFLogger.LogLevel paramLogLevel) {
    boolean bool2;
    int i = onAttributionFailure + 89;
    onResponse = i % 128;
    i = paramLogLevel.getLevel();
    int j = AFLogger.LogLevel.NONE.getLevel();
    boolean bool1 = false;
    if (i > j) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    AFKeystoreWrapper().AFVersionDeclaration().values("log", new String[] { String.valueOf(bool2) });
    AppsFlyerProperties.getInstance().set("logLevel", paramLogLevel.getLevel());
    j = onAttributionFailure + 73;
    onResponse = j % 128;
    i = bool1;
    if (j % 2 != 0)
      i = 1; 
    if (i != 1)
      return; 
    try {
      throw null;
    } finally {}
  }
  
  public final void setMinTimeBetweenSessions(int paramInt) {
    int i = onResponse + 91;
    onAttributionFailure = i % 128;
    this.afWarnLog = TimeUnit.SECONDS.toMillis(paramInt);
    paramInt = onResponse + 3;
    onAttributionFailure = paramInt % 128;
    if (paramInt % 2 == 0) {
      paramInt = 75;
    } else {
      paramInt = 32;
    } 
    if (paramInt != 75)
      return; 
    try {
      paramInt = 42 / 0;
      return;
    } finally {}
  }
  
  public final void setOaidData(String paramString) {
    int i = onResponse + 97;
    onAttributionFailure = i % 128;
    boolean bool = true;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
      String[] arrayOfString = new String[0];
      arrayOfString[0] = paramString;
      aFb1sSDK.values("setOaidData", arrayOfString);
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("setOaidData", new String[] { paramString });
    } 
    AFa1bSDK.values = paramString;
    i = onResponse + 105;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = bool;
    } else {
      i = 0;
    } 
    if (i == 0)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void setOneLinkCustomDomain(String... paramVarArgs) {
    int i = onResponse + 113;
    onAttributionFailure = i % 128;
    AFLogger.afDebugLog(String.format("setOneLinkCustomDomain %s", new Object[] { Arrays.toString((Object[])paramVarArgs) }));
    AFa1tSDK.AFKeystoreWrapper = paramVarArgs;
    i = onResponse + 1;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 74;
    } else {
      i = 79;
    } 
    if (i != 79)
      try {
        i = 99 / 0;
        return;
      } finally {} 
  }
  
  public final void setOutOfStore(String paramString) {
    if (paramString != null) {
      i = 42;
    } else {
      i = 74;
    } 
    if (i != 74) {
      paramString = paramString.toLowerCase(Locale.getDefault());
      AppsFlyerProperties.getInstance().set("api_store_value", paramString);
      paramString = "Store API set with value: ".concat(String.valueOf(paramString));
      i = 1;
      AFLogger.afInfoLog(paramString, true);
      int j = onResponse + 109;
      onAttributionFailure = j % 128;
      if (j % 2 == 0)
        i = 0; 
      if (i != 0)
        return; 
      try {
        throw null;
      } finally {}
    } 
    AFLogger.valueOf("Cannot set setOutOfStore with null");
    int i = onResponse + 103;
    onAttributionFailure = i % 128;
  }
  
  public final void setPartnerData(String paramString, Map<String, Object> paramMap) {
    int i;
    if (this.onConversionDataSuccess == null)
      this.onConversionDataSuccess = new AFb1eSDK(); 
    AFb1eSDK aFb1eSDK = this.onConversionDataSuccess;
    if (paramString != null) {
      i = 58;
    } else {
      i = 24;
    } 
    if (i != 24) {
      i = onAttributionFailure + 53;
      onResponse = i % 128;
      if (!paramString.isEmpty()) {
        if (paramMap != null) {
          i = 62;
        } else {
          i = 64;
        } 
        if (i == 62) {
          if (paramMap.isEmpty()) {
            i = 1;
          } else {
            i = 0;
          } 
          if (i != 1) {
            StringBuilder stringBuilder = new StringBuilder("Setting partner data for ");
            stringBuilder.append(paramString);
            stringBuilder.append(": ");
            stringBuilder.append(paramMap);
            AFLogger.afDebugLog(stringBuilder.toString());
            i = (new JSONObject(paramMap)).toString().length();
            if (i > 1000) {
              AFLogger.afWarnLog("Partner data 1000 characters limit exceeded");
              paramMap = new HashMap<String, Object>();
              paramMap.put("error", "limit exceeded: ".concat(String.valueOf(i)));
              aFb1eSDK.AFInAppEventType.put(paramString, paramMap);
              i = onResponse + 33;
              onAttributionFailure = i % 128;
              return;
            } 
            aFb1eSDK.AFKeystoreWrapper.put(paramString, paramMap);
            aFb1eSDK.AFInAppEventType.remove(paramString);
            return;
          } 
        } 
        if (aFb1eSDK.AFKeystoreWrapper.remove(paramString) == null) {
          paramString = "Partner data is missing or `null`";
        } else {
          paramString = "Cleared partner data for ".concat(String.valueOf(paramString));
        } 
        AFLogger.afWarnLog(paramString);
        return;
      } 
    } 
    AFLogger.afWarnLog("Partner ID is missing or `null`");
  }
  
  public final void setPhoneNumber(String paramString) {
    int i = onResponse + 55;
    onAttributionFailure = i % 128;
    this.onResponseNative = AFb1ySDK.AFKeystoreWrapper(paramString);
    i = onAttributionFailure + 121;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0)
      return; 
    try {
      i = 38 / 0;
      return;
    } finally {}
  }
  
  public final void setPluginInfo(PluginInfo paramPluginInfo) {
    int i = onAttributionFailure + 77;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0) {
      Objects.requireNonNull(paramPluginInfo);
      AFKeystoreWrapper().init().AFKeystoreWrapper(paramPluginInfo);
      return;
    } 
    Objects.requireNonNull(paramPluginInfo);
    AFKeystoreWrapper().init().AFKeystoreWrapper(paramPluginInfo);
    try {
      throw null;
    } finally {}
  }
  
  public final void setPreinstallAttribution(String paramString1, String paramString2, String paramString3) {
    int i;
    AFLogger.afDebugLog("setPreinstallAttribution API called");
    JSONObject jSONObject = new JSONObject();
    if (paramString1 != null)
      try {
        jSONObject.put("pid", paramString1);
        i = onAttributionFailure + 19;
        onResponse = i % 128;
      } catch (JSONException jSONException) {} 
    byte b = 0;
    if (paramString2 != null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (!i)
      jSONObject.put("c", paramString2); 
    if (paramString3 != null) {
      i = b;
    } else {
      i = 1;
    } 
    if (!i) {
      jSONObject.put("af_siteid", paramString3);
      i = onAttributionFailure + 39;
      onResponse = i % 128;
    } 
    if (jSONObject.has("pid")) {
      i = onResponse + 103;
      onAttributionFailure = i % 128;
      valueOf("preInstallName", jSONObject.toString());
      i = onResponse + 19;
      onAttributionFailure = i % 128;
      return;
    } 
    AFLogger.afWarnLog("Cannot set preinstall attribution data without a media source");
  }
  
  public final void setResolveDeepLinkURLs(String... paramVarArgs) {
    int i = onAttributionFailure + 71;
    onResponse = i % 128;
    AFLogger.afDebugLog(String.format("setResolveDeepLinkURLs %s", new Object[] { Arrays.toString((Object[])paramVarArgs) }));
    AFa1tSDK.AFInAppEventType.clear();
    AFa1tSDK.AFInAppEventType.addAll(Arrays.asList(paramVarArgs));
    i = onResponse + 71;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1)
      try {
        i = 40 / 0;
        return;
      } finally {} 
  }
  
  @Deprecated
  public final void setSharingFilter(String... paramVarArgs) {
    int i = onAttributionFailure + 107;
    onResponse = i % 128;
    super.setSharingFilterForPartners(paramVarArgs);
    i = onResponse + 77;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return; 
    try {
      i = 13 / 0;
      return;
    } finally {}
  }
  
  @Deprecated
  public final void setSharingFilterForAllPartners() {
    int i = onAttributionFailure + 21;
    onResponse = i % 128;
    super.setSharingFilterForPartners(new String[] { "all" });
    i = onResponse + 119;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void setSharingFilterForPartners(String... paramVarArgs) {
    this.AFLogger = new AFa1eSDK(paramVarArgs);
    int i = onResponse + 71;
    onAttributionFailure = i % 128;
  }
  
  public final void setUserEmails(AppsFlyerProperties.EmailsCryptType paramEmailsCryptType, String... paramVarArgs) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: aload_2
    //   5: arraylength
    //   6: iconst_1
    //   7: iadd
    //   8: invokespecial <init> : (I)V
    //   11: astore #6
    //   13: aload #6
    //   15: aload_1
    //   16: invokevirtual toString : ()Ljava/lang/String;
    //   19: invokeinterface add : (Ljava/lang/Object;)Z
    //   24: pop
    //   25: aload #6
    //   27: aload_2
    //   28: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   31: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   36: pop
    //   37: aload_0
    //   38: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   41: invokeinterface AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1sSDK;
    //   46: ldc_w 'setUserEmails'
    //   49: aload #6
    //   51: aload_2
    //   52: arraylength
    //   53: iconst_1
    //   54: iadd
    //   55: anewarray java/lang/String
    //   58: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   63: checkcast [Ljava/lang/String;
    //   66: invokeinterface values : (Ljava/lang/String;[Ljava/lang/String;)V
    //   71: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   74: ldc_w 'userEmailsCryptType'
    //   77: aload_1
    //   78: invokevirtual getValue : ()I
    //   81: invokevirtual set : (Ljava/lang/String;I)V
    //   84: new java/util/HashMap
    //   87: dup
    //   88: invokespecial <init> : ()V
    //   91: astore #8
    //   93: new java/util/ArrayList
    //   96: dup
    //   97: invokespecial <init> : ()V
    //   100: astore #7
    //   102: aload_2
    //   103: arraylength
    //   104: istore #5
    //   106: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   109: bipush #69
    //   111: iadd
    //   112: istore_3
    //   113: iload_3
    //   114: sipush #128
    //   117: irem
    //   118: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   121: iconst_0
    //   122: istore_3
    //   123: aconst_null
    //   124: astore #6
    //   126: iload_3
    //   127: iload #5
    //   129: if_icmpge -> 138
    //   132: iconst_5
    //   133: istore #4
    //   135: goto -> 142
    //   138: bipush #77
    //   140: istore #4
    //   142: iload #4
    //   144: iconst_5
    //   145: if_icmpeq -> 181
    //   148: aload #8
    //   150: aload #6
    //   152: aload #7
    //   154: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   159: pop
    //   160: new org/json/JSONObject
    //   163: dup
    //   164: aload #8
    //   166: invokespecial <init> : (Ljava/util/Map;)V
    //   169: astore_1
    //   170: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   173: aload_1
    //   174: invokevirtual toString : ()Ljava/lang/String;
    //   177: invokevirtual setUserEmails : (Ljava/lang/String;)V
    //   180: return
    //   181: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   184: bipush #109
    //   186: iadd
    //   187: istore #4
    //   189: iload #4
    //   191: sipush #128
    //   194: irem
    //   195: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   198: iload #4
    //   200: iconst_2
    //   201: irem
    //   202: ifne -> 278
    //   205: aload_2
    //   206: iload_3
    //   207: aaload
    //   208: astore #6
    //   210: getstatic com/appsflyer/internal/AFb1xSDK$10.values : [I
    //   213: aload_1
    //   214: invokevirtual ordinal : ()I
    //   217: iaload
    //   218: iconst_2
    //   219: if_icmpeq -> 241
    //   222: aload #7
    //   224: aload #6
    //   226: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Ljava/lang/String;
    //   229: invokevirtual add : (Ljava/lang/Object;)Z
    //   232: pop
    //   233: ldc_w 'sha256_el_arr'
    //   236: astore #6
    //   238: goto -> 271
    //   241: aload #7
    //   243: aload #6
    //   245: invokevirtual add : (Ljava/lang/Object;)Z
    //   248: pop
    //   249: getstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   252: bipush #15
    //   254: iadd
    //   255: istore #4
    //   257: iload #4
    //   259: sipush #128
    //   262: irem
    //   263: putstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   266: ldc_w 'plain_el_arr'
    //   269: astore #6
    //   271: iload_3
    //   272: iconst_1
    //   273: iadd
    //   274: istore_3
    //   275: goto -> 126
    //   278: aload_2
    //   279: iload_3
    //   280: aaload
    //   281: astore_2
    //   282: getstatic com/appsflyer/internal/AFb1xSDK$10.values : [I
    //   285: aload_1
    //   286: invokevirtual ordinal : ()I
    //   289: iaload
    //   290: istore_3
    //   291: new java/lang/NullPointerException
    //   294: dup
    //   295: invokespecial <init> : ()V
    //   298: athrow
    //   299: astore_1
    //   300: aload_1
    //   301: athrow
    // Exception table:
    //   from	to	target	type
    //   291	299	299	finally
  }
  
  public final void setUserEmails(String... paramVarArgs) {
    int i = onAttributionFailure + 119;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 51;
    } else {
      i = 2;
    } 
    if (i != 51) {
      AFKeystoreWrapper().AFVersionDeclaration().values("setUserEmails", paramVarArgs);
      super.setUserEmails(AppsFlyerProperties.EmailsCryptType.NONE, paramVarArgs);
      i = onResponse + 37;
      onAttributionFailure = i % 128;
      return;
    } 
    AFKeystoreWrapper().AFVersionDeclaration().values("setUserEmails", paramVarArgs);
    super.setUserEmails(AppsFlyerProperties.EmailsCryptType.NONE, paramVarArgs);
    try {
      throw null;
    } finally {}
  }
  
  public final void start(Context paramContext) {
    int i = onResponse + 19;
    onAttributionFailure = i % 128;
    super.start(paramContext, null);
    i = onAttributionFailure + 95;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i == 1)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void start(Context paramContext, String paramString) {
    int i = onResponse + 99;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 48;
    } else {
      i = 78;
    } 
    super.start(paramContext, paramString, null);
    if (i != 48)
      return; 
    try {
      i = 44 / 0;
      return;
    } finally {}
  }
  
  public final void start(Context paramContext, String paramString, AppsFlyerRequestListener paramAppsFlyerRequestListener) {
    int i = onAttributionFailure + 103;
    onResponse = i % 128;
    if (AFKeystoreWrapper().onResponseNative().AFKeystoreWrapper())
      return; 
    boolean bool1 = this.onInstallConversionDataLoadedNative;
    boolean bool = false;
    if (!bool1) {
      AFLogger.afWarnLog("ERROR: AppsFlyer SDK is not initialized! The API call 'start()' must be called after the 'init(String, AppsFlyerConversionListener)' API method, which should be called on the Application's onCreate.");
      if (paramString == null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        if (paramAppsFlyerRequestListener != null)
          paramAppsFlyerRequestListener.onError(RequestError.NO_DEV_KEY, AFb1aSDK.values); 
        return;
      } 
    } 
    AFInAppEventType(paramContext);
    AFe1fSDK aFe1fSDK = AFKeystoreWrapper().AFLogger();
    aFe1fSDK.values(AFa1oSDK.AFKeystoreWrapper(paramContext));
    this.init = (Application)paramContext.getApplicationContext();
    AFKeystoreWrapper().AFVersionDeclaration().values("start", new String[] { paramString });
    String str = AFInAppEventParameterName;
    AFLogger.afInfoLog(String.format("Starting AppsFlyer: (v%s.%s)", new Object[] { "6.10.3", str }));
    StringBuilder stringBuilder = new StringBuilder("Build Number: ");
    stringBuilder.append(str);
    AFLogger.afInfoLog(stringBuilder.toString());
    AppsFlyerProperties.getInstance().loadProperties(this.init.getApplicationContext());
    if (!TextUtils.isEmpty(paramString)) {
      i = 22;
    } else {
      i = 58;
    } 
    if (i != 58) {
      (AFKeystoreWrapper().afWarnLog()).AFInAppEventType = paramString;
      AFc1rSDK.values(paramString);
      i = onResponse + 31;
      onAttributionFailure = i % 128;
    } else {
      if (TextUtils.isEmpty((AFKeystoreWrapper().afWarnLog()).AFInAppEventType)) {
        i = 30;
      } else {
        i = 5;
      } 
      if (i != 5) {
        i = onResponse + 1;
        onAttributionFailure = i % 128;
        AFLogger.afWarnLog("ERROR: AppsFlyer SDK is not initialized! You must provide AppsFlyer Dev-Key either in the 'init' API method (should be called on Application's onCreate),or in the start() API (should be called on Activity's onCreate).");
        if (paramAppsFlyerRequestListener != null) {
          i = bool;
        } else {
          i = 1;
        } 
        if (i != 0)
          return; 
        paramAppsFlyerRequestListener.onError(RequestError.NO_DEV_KEY, AFb1aSDK.values);
        return;
      } 
    } 
    AFKeystoreWrapper().afRDLog().AFInAppEventParameterName(null);
    afDebugLog();
    afInfoLog(this.init.getBaseContext());
    if (this.onDeepLinkingNative) {
      AFLogger(this.init.getApplicationContext());
      i = onAttributionFailure + 105;
      onResponse = i % 128;
    } 
    AFc1uSDK aFc1uSDK = this.onConversionDataFail;
    if (aFc1uSDK.AFInAppEventType == null)
      aFc1uSDK.AFInAppEventType = (AFb1gSDK)new AFb1dSDK(aFc1uSDK.valueOf(), aFc1uSDK.onAppOpenAttributionNative()); 
    aFc1uSDK.AFInAppEventType.AFKeystoreWrapper(paramContext, new AFb1gSDK.AFa1zSDK(this, aFe1fSDK, paramAppsFlyerRequestListener) {
          public final void AFInAppEventType(Activity param1Activity) {
            this.AFKeystoreWrapper.AFInAppEventType();
            this.AFInAppEventParameterName.AFKeystoreWrapper().afRDLog().AFInAppEventParameterName(null);
            AFb1xSDK.AFInAppEventParameterName(this.AFInAppEventParameterName);
            int i = this.AFInAppEventParameterName.AFKeystoreWrapper(AFb1xSDK.valueOf((Context)param1Activity), false);
            AFLogger.afInfoLog("onBecameForeground");
            if (i < 2) {
              AFa1dSDK aFa1dSDK = AFa1dSDK.AFInAppEventType((Context)param1Activity);
              aFa1dSDK.AFInAppEventType.post(aFa1dSDK.afRDLog);
              aFa1dSDK.AFInAppEventType.post(aFa1dSDK.values);
            } 
            AFf1vSDK aFf1vSDK = new AFf1vSDK();
            this.AFInAppEventParameterName.AFKeystoreWrapper().onAppOpenAttributionNative().AFInAppEventType(aFf1vSDK.AFInAppEventType(), param1Activity.getIntent(), (Context)param1Activity.getApplication());
            AFb1xSDK aFb1xSDK = this.AFInAppEventParameterName;
            if (param1Activity != null)
              ((AFa1sSDK)aFf1vSDK).AFKeystoreWrapper = (Application)param1Activity.getApplicationContext(); 
            ((AFa1sSDK)aFf1vSDK).AFInAppEventType = this.values;
            aFb1xSDK.AFInAppEventType((AFa1sSDK)aFf1vSDK, param1Activity);
          }
          
          public final void AFInAppEventType(Context param1Context) {
            AFLogger.afInfoLog("onBecameBackground");
            AFe1fSDK aFe1fSDK = this.AFKeystoreWrapper;
            long l = System.currentTimeMillis();
            if (aFe1fSDK.AFLogger != 0L) {
              long l1 = l - aFe1fSDK.AFLogger;
              l = l1;
              if (l1 > 0L) {
                l = l1;
                if (l1 < 1000L)
                  l = 1000L; 
              } 
              aFe1fSDK.AFLogger$LogLevel = TimeUnit.MILLISECONDS.toSeconds(l);
              aFe1fSDK.AFInAppEventParameterName.AFInAppEventType("prev_session_dur", aFe1fSDK.AFLogger$LogLevel);
            } else {
              AFLogger.afInfoLog("Metrics: fg ts is missing");
            } 
            AFLogger.afInfoLog("callStatsBackground background call");
            this.AFInAppEventParameterName.AFInAppEventParameterName(new WeakReference<Context>(param1Context));
            this.AFInAppEventParameterName.AFKeystoreWrapper().onDeepLinkingNative().AFInAppEventType();
            AFb1sSDK aFb1sSDK = this.AFInAppEventParameterName.AFKeystoreWrapper().AFVersionDeclaration();
            if (aFb1sSDK.afInfoLog()) {
              aFb1sSDK.valueOf();
              if (param1Context != null && !AppsFlyerLib.getInstance().isStopped())
                aFb1sSDK.values(param1Context.getPackageName(), param1Context.getPackageManager(), this.AFInAppEventParameterName.AFKeystoreWrapper()); 
              aFb1sSDK.AFInAppEventParameterName();
            } else {
              AFLogger.afDebugLog("RD status is OFF");
            } 
            AFa1dSDK.AFInAppEventType(param1Context).AFInAppEventParameterName();
          }
        });
  }
  
  public final void stop(boolean paramBoolean, Context paramContext) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   3: bipush #89
    //   5: iadd
    //   6: istore #5
    //   8: iload #5
    //   10: sipush #128
    //   13: irem
    //   14: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   17: iconst_0
    //   18: istore #4
    //   20: iconst_0
    //   21: istore_3
    //   22: iload #5
    //   24: iconst_2
    //   25: irem
    //   26: ifeq -> 87
    //   29: aload_0
    //   30: aload_2
    //   31: invokevirtual AFInAppEventType : (Landroid/content/Context;)V
    //   34: aload_0
    //   35: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   38: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   43: iload_1
    //   44: putfield AFKeystoreWrapper : Z
    //   47: aload_0
    //   48: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   51: invokeinterface AFLogger$LogLevel : ()Lcom/appsflyer/internal/AFb1zSDK;
    //   56: invokeinterface values : ()V
    //   61: bipush #48
    //   63: iconst_0
    //   64: idiv
    //   65: istore #4
    //   67: iload_1
    //   68: ifeq -> 74
    //   71: goto -> 76
    //   74: iconst_1
    //   75: istore_3
    //   76: iload_3
    //   77: iconst_1
    //   78: if_icmpeq -> 150
    //   81: goto -> 136
    //   84: astore_2
    //   85: aload_2
    //   86: athrow
    //   87: aload_0
    //   88: aload_2
    //   89: invokevirtual AFInAppEventType : (Landroid/content/Context;)V
    //   92: aload_0
    //   93: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   96: invokeinterface afWarnLog : ()Lcom/appsflyer/internal/AFe1kSDK;
    //   101: iload_1
    //   102: putfield AFKeystoreWrapper : Z
    //   105: aload_0
    //   106: invokevirtual AFKeystoreWrapper : ()Lcom/appsflyer/internal/AFc1vSDK;
    //   109: invokeinterface AFLogger$LogLevel : ()Lcom/appsflyer/internal/AFb1zSDK;
    //   114: invokeinterface values : ()V
    //   119: iload #4
    //   121: istore_3
    //   122: iload_1
    //   123: ifeq -> 128
    //   126: iconst_1
    //   127: istore_3
    //   128: iload_3
    //   129: iconst_1
    //   130: if_icmpeq -> 136
    //   133: goto -> 150
    //   136: aload_0
    //   137: aload_2
    //   138: invokevirtual values : (Landroid/content/Context;)Lcom/appsflyer/internal/AFc1xSDK;
    //   141: ldc_w 'is_stop_tracking_used'
    //   144: iconst_1
    //   145: invokeinterface AFInAppEventType : (Ljava/lang/String;Z)V
    //   150: getstatic com/appsflyer/internal/AFb1xSDK.onAttributionFailure : I
    //   153: bipush #93
    //   155: iadd
    //   156: istore_3
    //   157: iload_3
    //   158: sipush #128
    //   161: irem
    //   162: putstatic com/appsflyer/internal/AFb1xSDK.onResponse : I
    //   165: iload_3
    //   166: iconst_2
    //   167: irem
    //   168: ifne -> 172
    //   171: return
    //   172: aconst_null
    //   173: athrow
    //   174: astore_2
    //   175: aload_2
    //   176: athrow
    // Exception table:
    //   from	to	target	type
    //   61	67	84	finally
    //   172	174	174	finally
  }
  
  public final void subscribeForDeepLink(DeepLinkListener paramDeepLinkListener) {
    int i = onAttributionFailure + 89;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 56;
    } else {
      i = 24;
    } 
    if (i == 24) {
      super.subscribeForDeepLink(paramDeepLinkListener, TimeUnit.SECONDS.toMillis(3L));
      i = onAttributionFailure + 53;
      onResponse = i % 128;
      return;
    } 
    super.subscribeForDeepLink(paramDeepLinkListener, TimeUnit.SECONDS.toMillis(3L));
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void subscribeForDeepLink(DeepLinkListener paramDeepLinkListener, long paramLong) {
    int i = onResponse + 55;
    onAttributionFailure = i % 128;
    (AFKeystoreWrapper().onAppOpenAttributionNative()).values = paramDeepLinkListener;
    AFb1qSDK.afErrorLogForExcManagerOnly = paramLong;
    i = onAttributionFailure + 41;
    onResponse = i % 128;
  }
  
  public final void unregisterConversionListener() {
    int i = onAttributionFailure + 27;
    onResponse = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0) {
      AFKeystoreWrapper().AFVersionDeclaration().values("unregisterConversionListener", new String[0]);
    } else {
      AFKeystoreWrapper().AFVersionDeclaration().values("unregisterConversionListener", new String[0]);
    } 
    valueOf = null;
  }
  
  public final void updateServerUninstallToken(Context paramContext, String paramString) {
    AFInAppEventType(paramContext);
    AFe1mSDK aFe1mSDK = new AFe1mSDK(paramContext);
    if (paramString == null || paramString.trim().isEmpty()) {
      AFLogger.afWarnLog("[register] Firebase Token is either empty or null and was not registered.");
      return;
    } 
    AFLogger.afInfoLog("[register] Firebase Refreshed Token = ".concat(String.valueOf(paramString)));
    AFb1tSDK aFb1tSDK = aFe1mSDK.valueOf();
    if (aFb1tSDK == null || !paramString.equals(aFb1tSDK.AFKeystoreWrapper)) {
      boolean bool;
      long l = System.currentTimeMillis();
      if (aFb1tSDK == null || l - aFb1tSDK.valueOf > TimeUnit.SECONDS.toMillis(2L)) {
        bool = true;
      } else {
        bool = false;
      } 
      aFb1tSDK = new AFb1tSDK(paramString, l, bool ^ true);
      aFe1mSDK.AFKeystoreWrapper.AFKeystoreWrapper("afUninstallToken", aFb1tSDK.AFKeystoreWrapper);
      aFe1mSDK.AFKeystoreWrapper.AFInAppEventType("afUninstallToken_received_time", aFb1tSDK.valueOf);
      aFe1mSDK.AFKeystoreWrapper.AFInAppEventType("afUninstallToken_queued", aFb1tSDK.AFInAppEventParameterName());
      if (bool)
        AFe1mSDK.AFKeystoreWrapper(paramString); 
    } 
  }
  
  public final void validateAndLogInAppPurchase(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, String> paramMap) {
    AppsFlyerInAppPurchaseValidatorListener appsFlyerInAppPurchaseValidatorListener;
    String str1;
    AFb1sSDK aFb1sSDK = AFKeystoreWrapper().AFVersionDeclaration();
    if (paramMap == null) {
      str1 = "";
    } else {
      str1 = paramMap.toString();
    } 
    aFb1sSDK.values("validateAndTrackInAppPurchase", new String[] { paramString1, paramString2, paramString3, paramString4, paramString5, str1 });
    if (!super.isStopped()) {
      StringBuilder stringBuilder = new StringBuilder("Validate in app called with parameters: ");
      stringBuilder.append(paramString3);
      stringBuilder.append(" ");
      stringBuilder.append(paramString4);
      stringBuilder.append(" ");
      stringBuilder.append(paramString5);
      AFLogger.afInfoLog(stringBuilder.toString());
    } 
    if (paramString1 == null || paramString4 == null || paramString2 == null || paramString5 == null || paramString3 == null) {
      appsFlyerInAppPurchaseValidatorListener = AFInAppEventType;
      if (appsFlyerInAppPurchaseValidatorListener != null)
        appsFlyerInAppPurchaseValidatorListener.onValidateInAppFailure("Please provide purchase parameters"); 
      return;
    } 
    Context context = appsFlyerInAppPurchaseValidatorListener.getApplicationContext();
    String str2 = (AFKeystoreWrapper().afWarnLog()).AFInAppEventType;
    if (appsFlyerInAppPurchaseValidatorListener instanceof Activity) {
      Intent intent = ((Activity)appsFlyerInAppPurchaseValidatorListener).getIntent();
    } else {
      appsFlyerInAppPurchaseValidatorListener = null;
    } 
    (new Thread((Runnable)new AFa1fSDK(context, str2, paramString1, paramString2, paramString3, paramString4, paramString5, paramMap, (Intent)appsFlyerInAppPurchaseValidatorListener))).start();
  }
  
  public final void valueOf(Context paramContext, Map<String, Object> paramMap, Uri paramUri) {
    AFInAppEventType(paramContext);
    if (!paramMap.containsKey("af_deeplink")) {
      String str1;
      int i = onResponse + 73;
      onAttributionFailure = i % 128;
      String str2 = AFKeystoreWrapper(paramUri.toString());
      AFa1tSDK aFa1tSDK = AFKeystoreWrapper().onAppOpenAttributionNative();
      if (aFa1tSDK.AFInAppEventParameterName != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 1) {
        str1 = str2;
      } else {
        str1 = str2;
        if (aFa1tSDK.valueOf != null) {
          if (str2.contains(aFa1tSDK.AFInAppEventParameterName)) {
            i = 13;
          } else {
            i = 49;
          } 
          if (i != 13) {
            str1 = str2;
          } else {
            Uri.Builder builder1 = Uri.parse(str2).buildUpon();
            Uri.Builder builder2 = Uri.EMPTY.buildUpon();
            Iterator<Map.Entry> iterator = aFa1tSDK.valueOf.entrySet().iterator();
            i = onResponse + 11;
            onAttributionFailure = i % 128;
            while (true) {
              if (iterator.hasNext()) {
                i = 0;
              } else {
                i = 1;
              } 
              if (i != 0) {
                str1 = builder1.build().toString();
                paramMap.put("appended_query_params", builder2.build().getEncodedQuery());
                break;
              } 
              Map.Entry entry = iterator.next();
              str1.appendQueryParameter((String)entry.getKey(), (String)entry.getValue());
              builder2.appendQueryParameter((String)entry.getKey(), (String)entry.getValue());
            } 
          } 
        } 
      } 
      paramMap.put("af_deeplink", str1);
    } 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("link", paramUri.toString());
    AFe1zSDK aFe1zSDK = new AFe1zSDK(AFKeystoreWrapper(), UUID.randomUUID(), paramUri);
    if (aFe1zSDK.AFLogger$LogLevel())
      paramMap.put("isBrandedDomain", Boolean.TRUE); 
    AFa1cSDK.values(paramContext, hashMap, paramUri);
    if (aFe1zSDK.afWarnLog()) {
      aFe1zSDK.afRDLog = values((Map)hashMap);
      AFd1pSDK aFd1pSDK = AFKeystoreWrapper().afDebugLog();
      aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)aFe1zSDK));
      int i = onResponse + 95;
      onAttributionFailure = i % 128;
      return;
    } 
    AFb1oSDK.valueOf(hashMap);
  }
  
  public final AFc1xSDK values(Context paramContext) {
    int i = onResponse + 29;
    onAttributionFailure = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1) {
      AFInAppEventType(paramContext);
      return AFKeystoreWrapper().afErrorLog();
    } 
    AFInAppEventType(paramContext);
    AFKeystoreWrapper().afErrorLog();
    try {
      throw null;
    } finally {}
  }
  
  public final boolean values() {
    int i;
    boolean bool = false;
    if (AFKeystoreWrapper("waitForCustomerId", false)) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = onAttributionFailure + 97;
      onResponse = i % 128;
      if (i % 2 == 0) {
        if (valueOf() == null) {
          int j = onAttributionFailure + 1;
          onResponse = j % 128;
          i = bool;
          if (j % 2 != 0)
            i = 1; 
          return i ^ 0x1;
        } 
      } else {
        valueOf();
        try {
          throw null;
        } finally {}
      } 
    } 
    return false;
  }
  
  public final void waitForCustomerUserId(boolean paramBoolean) {
    int i = onAttributionFailure + 123;
    onResponse = i % 128;
    if (i % 2 != 0);
    AFLogger.afInfoLog("initAfterCustomerUserID: ".concat(String.valueOf(paramBoolean)), true);
    AFInAppEventParameterName("waitForCustomerId", paramBoolean);
  }
  
  static {
    AFInAppEventParameterName();
  }
  
  static {
    int i = Process.myTid();
    boolean bool = true;
    int j = TextUtils.lastIndexOf("", '0');
    float f = TypedValue.complexToFraction(0, 0.0F, 0.0F);
    Object[] arrayOfObject = new Object[1];
    AFKeystoreWrapper(1 - (i >> 22), "\000", j + 230, 1 - (f cmp 0.0F), false, arrayOfObject);
    null = "6.10.3".substring(0, "6.10.3".lastIndexOf(((String)arrayOfObject[0]).intern()));
    AFKeystoreWrapper = null;
  }
  
  final class AFa1vSDK implements Runnable {
    private final AFa1sSDK valueOf;
    
    private AFa1vSDK(AFb1xSDK this$0, AFa1sSDK param1AFa1sSDK) {
      this.valueOf = param1AFa1sSDK;
    }
    
    public final void run() {
      AFb1xSDK.AFKeystoreWrapper(this.AFKeystoreWrapper, this.valueOf);
    }
  }
  
  final class AFa1ySDK implements Runnable {
    private final AFa1sSDK AFInAppEventType;
    
    private AFa1ySDK(AFb1xSDK this$0, AFa1sSDK param1AFa1sSDK) {
      this.AFInAppEventType = param1AFa1sSDK;
    }
    
    public final void run() {
      AFd1cSDK aFd1cSDK;
      if (this.AFInAppEventType.AFInAppEventParameterName()) {
        AFd1dSDK aFd1dSDK = new AFd1dSDK(this.AFInAppEventType, this.valueOf.AFKeystoreWrapper());
        aFd1dSDK.afWarnLog = AFb1xSDK.values(this.valueOf);
      } else {
        aFd1cSDK = new AFd1cSDK(this.AFInAppEventType, this.valueOf.AFKeystoreWrapper());
      } 
      AFd1pSDK aFd1pSDK = this.valueOf.AFKeystoreWrapper().afDebugLog();
      aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)aFd1cSDK));
    }
  }
  
  final class AFa1zSDK implements AFd1wSDK {
    private AFa1zSDK(AFb1xSDK this$0) {}
    
    private static boolean AFInAppEventType() {
      return (AFb1xSDK.valueOf != null);
    }
    
    public final void AFInAppEventParameterName(AFd1qSDK<?> param1AFd1qSDK) {
      if (param1AFd1qSDK instanceof AFd1dSDK) {
        AFd1cSDK aFd1cSDK = (AFd1cSDK)param1AFd1qSDK;
        this.AFInAppEventParameterName.AFKeystoreWrapper().AFLogger().AFInAppEventParameterName(aFd1cSDK.afRDLog.afInfoLog);
      } 
    }
    
    public final void AFInAppEventType(AFd1qSDK<?> param1AFd1qSDK) {}
    
    public final void valueOf(AFd1qSDK<?> param1AFd1qSDK, AFd1tSDK param1AFd1tSDK) {
      JSONObject jSONObject;
      AFb1xSDK aFb1xSDK;
      if (param1AFd1qSDK instanceof AFd1cSDK) {
        AFd1cSDK aFd1cSDK = (AFd1cSDK)param1AFd1qSDK;
        boolean bool = param1AFd1qSDK instanceof AFd1dSDK;
        if (bool && AFInAppEventType()) {
          AFd1dSDK aFd1dSDK = (AFd1dSDK)param1AFd1qSDK;
          AFd1tSDK aFd1tSDK1 = ((AFd1qSDK)aFd1dSDK).AFInAppEventType;
          AFd1tSDK aFd1tSDK2 = AFd1tSDK.AFInAppEventType;
          boolean bool2 = true;
          boolean bool1 = bool2;
          if (aFd1tSDK1 != aFd1tSDK2)
            if (((AFd1qSDK)aFd1dSDK).AFInAppEventParameterName == 1) {
              bool1 = bool2;
            } else {
              bool1 = false;
            }  
          if (bool1) {
            AFe1hSDK aFe1hSDK = new AFe1hSDK(aFd1dSDK, this.AFInAppEventParameterName.AFKeystoreWrapper().afErrorLog());
            AFd1pSDK aFd1pSDK = this.AFInAppEventParameterName.AFKeystoreWrapper().afDebugLog();
            aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)aFe1hSDK));
          } 
        } 
        if (param1AFd1tSDK == AFd1tSDK.AFInAppEventType) {
          aFb1xSDK = this.AFInAppEventParameterName;
          aFb1xSDK.values((Context)AFb1xSDK.valueOf(aFb1xSDK)).AFKeystoreWrapper("sentSuccessfully", "true");
          if (!(param1AFd1qSDK instanceof AFd1bSDK)) {
            AFb1tSDK aFb1tSDK = (new AFe1mSDK((Context)AFb1xSDK.valueOf(this.AFInAppEventParameterName))).valueOf();
            if (aFb1tSDK != null && aFb1tSDK.AFInAppEventParameterName()) {
              String str = aFb1tSDK.AFKeystoreWrapper;
              AFLogger.afDebugLog("Resending Uninstall token to AF servers: ".concat(String.valueOf(str)));
              AFe1mSDK.AFKeystoreWrapper(str);
            } 
          } 
          AFc1aSDK aFc1aSDK = ((AFd1iSDK)aFd1cSDK).afInfoLog;
          if (aFc1aSDK != null) {
            jSONObject = AFb1nSDK.AFInAppEventParameterName((String)aFc1aSDK.getBody());
            if (jSONObject != null)
              AFb1xSDK.values(this.AFInAppEventParameterName, jSONObject.optBoolean("send_background", false)); 
          } 
          if (bool)
            AFb1xSDK.values(this.AFInAppEventParameterName, System.currentTimeMillis()); 
        } 
        return;
      } 
      if (jSONObject instanceof AFe1hSDK && aFb1xSDK != AFd1tSDK.AFInAppEventType) {
        AFe1lSDK aFe1lSDK = new AFe1lSDK(this.AFInAppEventParameterName.AFKeystoreWrapper());
        AFd1pSDK aFd1pSDK = this.AFInAppEventParameterName.AFKeystoreWrapper().afDebugLog();
        aFd1pSDK.AFKeystoreWrapper.execute((Runnable)new Object(aFd1pSDK, (AFd1qSDK)aFe1lSDK));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFb1xSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */