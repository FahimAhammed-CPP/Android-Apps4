package com.appsflyer.internal;

import android.os.Bundle;
import com.appsflyer.AFLogger;
import com.appsflyer.AppsFlyerProperties;

public final class AFb1bSDK {
  private static String AFInAppEventParameterName = "235";
  
  public final AFc1xSDK AFInAppEventType;
  
  private Bundle valueOf = null;
  
  public final AFc1wSDK values;
  
  public AFb1bSDK(AFc1wSDK paramAFc1wSDK, AFc1xSDK paramAFc1xSDK) {
    this.values = paramAFc1wSDK;
    this.AFInAppEventType = paramAFc1xSDK;
  }
  
  public static String AFKeystoreWrapper() {
    StringBuilder stringBuilder = new StringBuilder("version: 6.10.3 (build ");
    stringBuilder.append(AFInAppEventParameterName);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public static String valueOf() {
    return AppsFlyerProperties.getInstance().getString("AppUserId");
  }
  
  public final boolean AFInAppEventType(String paramString) {
    paramString = valueOf(paramString);
    return (paramString != null) ? Boolean.parseBoolean(paramString) : false;
  }
  
  public final String valueOf(String paramString) {
    try {
      return null;
    } finally {
      paramString = null;
      StringBuilder stringBuilder = new StringBuilder("Could not load manifest metadata!");
      stringBuilder.append(paramString.getMessage());
      AFLogger.afErrorLog(stringBuilder.toString(), (Throwable)paramString);
    } 
  }
  
  public final String values() {
    String str2 = AppsFlyerProperties.getInstance().getString("channel");
    String str1 = str2;
    if (str2 == null)
      str1 = valueOf("CHANNEL"); 
    str2 = str1;
    if (str1 != null) {
      str2 = str1;
      if (str1.equals(""))
        str2 = null; 
    } 
    return str2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFb1bSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */