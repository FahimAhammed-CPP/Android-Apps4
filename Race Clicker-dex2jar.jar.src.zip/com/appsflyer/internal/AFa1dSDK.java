package com.appsflyer.internal;

import android.content.Context;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class AFa1dSDK {
  private static final BitSet AFLogger;
  
  private static volatile AFa1dSDK afDebugLog;
  
  boolean AFInAppEventParameterName;
  
  final Handler AFInAppEventType;
  
  final Object AFKeystoreWrapper = new Object();
  
  private final SensorManager AFLogger$LogLevel;
  
  private boolean AFVersionDeclaration;
  
  private final Map<AFa1jSDK, Map<String, Object>> afErrorLog;
  
  private long afErrorLogForExcManagerOnly;
  
  private final Map<AFa1jSDK, AFa1jSDK> afInfoLog;
  
  final Runnable afRDLog;
  
  private final Runnable afWarnLog;
  
  private int getLevel;
  
  final Runnable valueOf;
  
  final Runnable values;
  
  static {
    BitSet bitSet = new BitSet(6);
    AFLogger = bitSet;
    bitSet.set(1);
    bitSet.set(2);
    bitSet.set(4);
  }
  
  private AFa1dSDK(SensorManager paramSensorManager, Handler paramHandler) {
    BitSet bitSet = AFLogger;
    this.afInfoLog = new HashMap<AFa1jSDK, AFa1jSDK>(bitSet.size());
    this.afErrorLog = new ConcurrentHashMap<AFa1jSDK, Map<String, Object>>(bitSet.size());
    this.values = new Runnable(this) {
        public final void run() {
          synchronized (this.AFKeystoreWrapper.AFKeystoreWrapper) {
            AFa1dSDK aFa1dSDK = this.AFKeystoreWrapper;
            aFa1dSDK.AFInAppEventType.post(new Runnable(aFa1dSDK) {
                  public final void run() {
                    try {
                    
                    } finally {
                      Exception exception = null;
                    } 
                    AFa1dSDK.valueOf(this.values, true);
                  }
                });
            this.AFKeystoreWrapper.AFInAppEventType.postDelayed(AFa1dSDK.valueOf(this.AFKeystoreWrapper), 100L);
            this.AFKeystoreWrapper.AFInAppEventParameterName = true;
            return;
          } 
        }
      };
    this.valueOf = new Runnable(this) {
        public final void run() {
          synchronized (this.values.AFKeystoreWrapper) {
            AFa1dSDK aFa1dSDK = this.values;
            aFa1dSDK.AFInAppEventType.post(new Runnable(aFa1dSDK) {
                  public final void run() {
                    try {
                      if (!AFa1dSDK.AFInAppEventParameterName(this.AFInAppEventParameterName).isEmpty())
                        for (AFa1jSDK aFa1jSDK : AFa1dSDK.AFInAppEventParameterName(this.AFInAppEventParameterName).values()) {
                          AFa1dSDK.values(this.AFInAppEventParameterName).unregisterListener((SensorEventListener)aFa1jSDK);
                          aFa1jSDK.AFInAppEventType(AFa1dSDK.AFKeystoreWrapper(this.AFInAppEventParameterName), true);
                        }  
                    } finally {
                      Exception exception = null;
                    } 
                    AFa1dSDK.valueOf(this.AFInAppEventParameterName, false);
                  }
                });
            return;
          } 
        }
      };
    this.afRDLog = new Runnable(this) {
        public final void run() {
          synchronized (this.values.AFKeystoreWrapper) {
            if (this.values.AFInAppEventParameterName) {
              this.values.AFInAppEventType.removeCallbacks(this.values.values);
              this.values.AFInAppEventType.removeCallbacks(this.values.valueOf);
              AFa1dSDK aFa1dSDK = this.values;
              aFa1dSDK.AFInAppEventType.post(new Runnable(aFa1dSDK) {
                    public final void run() {
                      try {
                        if (!AFa1dSDK.AFInAppEventParameterName(this.AFInAppEventParameterName).isEmpty())
                          for (AFa1jSDK aFa1jSDK : AFa1dSDK.AFInAppEventParameterName(this.AFInAppEventParameterName).values()) {
                            AFa1dSDK.values(this.AFInAppEventParameterName).unregisterListener((SensorEventListener)aFa1jSDK);
                            aFa1jSDK.AFInAppEventType(AFa1dSDK.AFKeystoreWrapper(this.AFInAppEventParameterName), true);
                          }  
                      } finally {
                        Exception exception = null;
                      } 
                      AFa1dSDK.valueOf(this.AFInAppEventParameterName, false);
                    }
                  });
              this.values.AFInAppEventParameterName = false;
            } 
            return;
          } 
        }
      };
    this.getLevel = 1;
    this.afErrorLogForExcManagerOnly = 0L;
    this.afWarnLog = new Runnable(this) {
        public final void run() {
          synchronized (this.AFInAppEventType.AFKeystoreWrapper) {
            if (AFa1dSDK.AFInAppEventType(this.AFInAppEventType) == 0)
              AFa1dSDK.valueOf(this.AFInAppEventType, 1); 
            this.AFInAppEventType.AFInAppEventType.postDelayed(this.AFInAppEventType.valueOf, AFa1dSDK.AFInAppEventType(this.AFInAppEventType) * 500L);
            return;
          } 
        }
      };
    this.AFLogger$LogLevel = paramSensorManager;
    this.AFInAppEventType = paramHandler;
  }
  
  static AFa1dSDK AFInAppEventType(Context paramContext) {
    if (afDebugLog != null)
      return afDebugLog; 
    SensorManager sensorManager = (SensorManager)paramContext.getApplicationContext().getSystemService("sensor");
    HandlerThread handlerThread = new HandlerThread("internal");
    handlerThread.start();
    return AFKeystoreWrapper(sensorManager, new Handler(handlerThread.getLooper()));
  }
  
  private static AFa1dSDK AFKeystoreWrapper(SensorManager paramSensorManager, Handler paramHandler) {
    // Byte code:
    //   0: getstatic com/appsflyer/internal/AFa1dSDK.afDebugLog : Lcom/appsflyer/internal/AFa1dSDK;
    //   3: ifnonnull -> 39
    //   6: ldc com/appsflyer/internal/AFa1dSDK
    //   8: monitorenter
    //   9: getstatic com/appsflyer/internal/AFa1dSDK.afDebugLog : Lcom/appsflyer/internal/AFa1dSDK;
    //   12: ifnonnull -> 27
    //   15: new com/appsflyer/internal/AFa1dSDK
    //   18: dup
    //   19: aload_0
    //   20: aload_1
    //   21: invokespecial <init> : (Landroid/hardware/SensorManager;Landroid/os/Handler;)V
    //   24: putstatic com/appsflyer/internal/AFa1dSDK.afDebugLog : Lcom/appsflyer/internal/AFa1dSDK;
    //   27: ldc com/appsflyer/internal/AFa1dSDK
    //   29: monitorexit
    //   30: goto -> 39
    //   33: astore_0
    //   34: ldc com/appsflyer/internal/AFa1dSDK
    //   36: monitorexit
    //   37: aload_0
    //   38: athrow
    //   39: getstatic com/appsflyer/internal/AFa1dSDK.afDebugLog : Lcom/appsflyer/internal/AFa1dSDK;
    //   42: areturn
    // Exception table:
    //   from	to	target	type
    //   9	27	33	finally
    //   27	30	33	finally
  }
  
  private static boolean AFKeystoreWrapper(int paramInt) {
    return (paramInt >= 0 && AFLogger.get(paramInt));
  }
  
  private List<Map<String, Object>> valueOf() {
    synchronized (this.AFKeystoreWrapper) {
      if (!this.afInfoLog.isEmpty() && this.AFVersionDeclaration) {
        Iterator<AFa1jSDK> iterator = this.afInfoLog.values().iterator();
        while (iterator.hasNext())
          ((AFa1jSDK)iterator.next()).AFInAppEventType(this.afErrorLog, false); 
      } 
      if (this.afErrorLog.isEmpty())
        return new CopyOnWriteArrayList(Collections.emptyList()); 
      return new CopyOnWriteArrayList(this.afErrorLog.values());
    } 
  }
  
  final void AFInAppEventParameterName() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield AFInAppEventType : Landroid/os/Handler;
    //   6: aload_0
    //   7: getfield afRDLog : Ljava/lang/Runnable;
    //   10: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   13: pop
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  final List<Map<String, Object>> AFKeystoreWrapper() {
    Iterator<AFa1jSDK> iterator = this.afInfoLog.values().iterator();
    while (iterator.hasNext())
      ((AFa1jSDK)iterator.next()).AFInAppEventType(this.afErrorLog, true); 
    Map<AFa1jSDK, Map<String, Object>> map = this.afErrorLog;
    return (map == null || map.isEmpty()) ? new CopyOnWriteArrayList<Map<String, Object>>(Collections.emptyList()) : new CopyOnWriteArrayList<Map<String, Object>>(this.afErrorLog.values());
  }
  
  final Map<String, Object> values() {
    ConcurrentHashMap<Object, Object> concurrentHashMap = new ConcurrentHashMap<Object, Object>();
    List<Map<String, Object>> list = valueOf();
    if (!list.isEmpty()) {
      concurrentHashMap.put("sensors", list);
      return (Map)concurrentHashMap;
    } 
    list = AFKeystoreWrapper();
    if (!list.isEmpty())
      concurrentHashMap.put("sensors", list); 
    return (Map)concurrentHashMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFa1dSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */