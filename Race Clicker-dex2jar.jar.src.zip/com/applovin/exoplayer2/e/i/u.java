package com.applovin.exoplayer2.e.i;

import com.applovin.exoplayer2.e.a;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.y;
import java.io.IOException;

final class u extends a {
  public u(ag paramag, long paramLong1, long paramLong2) {
    super((a.d)new a.b(), new a(paramag, null), paramLong1, 0L, paramLong1 + 1L, 0L, paramLong2, 188L, 1000);
  }
  
  private static int b(byte[] paramArrayOfbyte, int paramInt) {
    byte b1 = paramArrayOfbyte[paramInt];
    byte b2 = paramArrayOfbyte[paramInt + 1];
    byte b3 = paramArrayOfbyte[paramInt + 2];
    return paramArrayOfbyte[paramInt + 3] & 0xFF | (b1 & 0xFF) << 24 | (b2 & 0xFF) << 16 | (b3 & 0xFF) << 8;
  }
  
  private static final class a implements a.f {
    private final ag a;
    
    private final y b;
    
    private a(ag param1ag) {
      this.a = param1ag;
      this.b = new y();
    }
    
    private a.e a(y param1y, long param1Long1, long param1Long2) {
      int j = -1;
      long l = -9223372036854775807L;
      int i = -1;
      while (param1y.a() >= 4) {
        if (u.a(param1y.d(), param1y.c()) != 442) {
          param1y.e(1);
          continue;
        } 
        param1y.e(4);
        long l2 = v.a(param1y);
        int k = i;
        long l1 = l;
        if (l2 != -9223372036854775807L) {
          l1 = this.a.b(l2);
          if (l1 > param1Long1)
            return (l == -9223372036854775807L) ? a.e.a(l1, param1Long2) : a.e.a(param1Long2 + i); 
          if (100000L + l1 > param1Long1)
            return a.e.a(param1Long2 + param1y.c()); 
          k = param1y.c();
        } 
        a(param1y);
        j = param1y.c();
        i = k;
        l = l1;
      } 
      return (l != -9223372036854775807L) ? a.e.b(l, param1Long2 + j) : a.e.a;
    }
    
    private static void a(y param1y) {
      int i = param1y.b();
      if (param1y.a() < 10) {
        param1y.d(i);
        return;
      } 
      param1y.e(9);
      int j = param1y.h() & 0x7;
      if (param1y.a() < j) {
        param1y.d(i);
        return;
      } 
      param1y.e(j);
      if (param1y.a() < 4) {
        param1y.d(i);
        return;
      } 
      if (u.a(param1y.d(), param1y.c()) == 443) {
        param1y.e(4);
        j = param1y.i();
        if (param1y.a() < j) {
          param1y.d(i);
          return;
        } 
        param1y.e(j);
      } 
      while (param1y.a() >= 4) {
        j = u.a(param1y.d(), param1y.c());
        if (j != 442) {
          if (j == 441)
            return; 
          if (j >>> 8 != 1)
            return; 
          param1y.e(4);
          if (param1y.a() < 2) {
            param1y.d(i);
            return;
          } 
          j = param1y.i();
          param1y.d(Math.min(param1y.b(), param1y.c() + j));
        } 
      } 
    }
    
    public a.e a(i param1i, long param1Long) throws IOException {
      long l = param1i.c();
      int j = (int)Math.min(20000L, param1i.d() - l);
      this.b.a(j);
      param1i.d(this.b.d(), 0, j);
      return a(this.b, param1Long, l);
    }
    
    public void a() {
      this.b.a(ai.f);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\e\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */