package com.applovin.exoplayer2.b;

import android.media.AudioTrack;
import android.os.SystemClock;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.l.ai;
import java.lang.reflect.Method;

final class j {
  private long A;
  
  private long B;
  
  private long C;
  
  private boolean D;
  
  private long E;
  
  private long F;
  
  private final a a;
  
  private final long[] b;
  
  private AudioTrack c;
  
  private int d;
  
  private int e;
  
  private i f;
  
  private int g;
  
  private boolean h;
  
  private long i;
  
  private float j;
  
  private boolean k;
  
  private long l;
  
  private long m;
  
  private Method n;
  
  private long o;
  
  private boolean p;
  
  private boolean q;
  
  private long r;
  
  private long s;
  
  private long t;
  
  private long u;
  
  private int v;
  
  private int w;
  
  private long x;
  
  private long y;
  
  private long z;
  
  public j(a parama) {
    this.a = (a)com.applovin.exoplayer2.l.a.b(parama);
    if (ai.a >= 18)
      try {
        Class[] arrayOfClass = (Class[])null;
        this.n = AudioTrack.class.getMethod("getLatency", null);
      } catch (NoSuchMethodException noSuchMethodException) {} 
    this.b = new long[10];
  }
  
  private void a(long paramLong1, long paramLong2) {
    i i1 = (i)com.applovin.exoplayer2.l.a.b(this.f);
    if (!i1.a(paramLong1))
      return; 
    long l1 = i1.e();
    long l2 = i1.f();
    if (Math.abs(l1 - paramLong1) > 5000000L) {
      this.a.b(l2, l1, paramLong1, paramLong2);
      i1.a();
      return;
    } 
    if (Math.abs(h(l2) - paramLong2) > 5000000L) {
      this.a.a(l2, l1, paramLong1, paramLong2);
      i1.a();
      return;
    } 
    i1.b();
  }
  
  private static boolean a(int paramInt) {
    return (ai.a < 23 && (paramInt == 5 || paramInt == 6));
  }
  
  private void e() {
    long l1 = h();
    if (l1 == 0L)
      return; 
    long l2 = System.nanoTime() / 1000L;
    if (l2 - this.m >= 30000L) {
      long[] arrayOfLong = this.b;
      int k = this.v;
      arrayOfLong[k] = l1 - l2;
      this.v = (k + 1) % 10;
      k = this.w;
      if (k < 10)
        this.w = k + 1; 
      this.m = l2;
      this.l = 0L;
      k = 0;
      while (true) {
        int m = this.w;
        if (k < m) {
          this.l += this.b[k] / m;
          k++;
          continue;
        } 
        break;
      } 
    } 
    if (this.h)
      return; 
    a(l2, l1);
    g(l2);
  }
  
  private void f() {
    this.l = 0L;
    this.w = 0;
    this.v = 0;
    this.m = 0L;
    this.C = 0L;
    this.F = 0L;
    this.k = false;
  }
  
  private void g(long paramLong) {
    if (this.q) {
      Method method = this.n;
      if (method != null && paramLong - this.r >= 500000L) {
        try {
          long l = ((Integer)ai.a(method.invoke(com.applovin.exoplayer2.l.a.b(this.c), new Object[0]))).intValue() * 1000L - this.i;
          this.o = l;
          l = Math.max(l, 0L);
          this.o = l;
          if (l > 5000000L) {
            this.a.b(l);
            this.o = 0L;
          } 
        } catch (Exception exception) {
          this.n = null;
        } 
        this.r = paramLong;
      } 
    } 
  }
  
  private boolean g() {
    return (this.h && ((AudioTrack)com.applovin.exoplayer2.l.a.b(this.c)).getPlayState() == 2 && i() == 0L);
  }
  
  private long h() {
    return h(i());
  }
  
  private long h(long paramLong) {
    return paramLong * 1000000L / this.g;
  }
  
  private long i() {
    AudioTrack audioTrack = (AudioTrack)com.applovin.exoplayer2.l.a.b(this.c);
    if (this.x != -9223372036854775807L) {
      long l = (SystemClock.elapsedRealtime() * 1000L - this.x) * this.g / 1000000L;
      return Math.min(this.A, this.z + l);
    } 
    int k = audioTrack.getPlayState();
    if (k == 1)
      return 0L; 
    long l2 = audioTrack.getPlaybackHeadPosition() & 0xFFFFFFFFL;
    long l1 = l2;
    if (this.h) {
      if (k == 2 && l2 == 0L)
        this.u = this.s; 
      l1 = l2 + this.u;
    } 
    if (ai.a <= 29) {
      if (l1 == 0L && this.s > 0L && k == 3) {
        if (this.y == -9223372036854775807L)
          this.y = SystemClock.elapsedRealtime(); 
        return this.s;
      } 
      this.y = -9223372036854775807L;
    } 
    if (this.s > l1)
      this.t++; 
    this.s = l1;
    return l1 + (this.t << 32L);
  }
  
  public long a(boolean paramBoolean) {
    long l1;
    if (((AudioTrack)com.applovin.exoplayer2.l.a.b(this.c)).getPlayState() == 3)
      e(); 
    long l3 = System.nanoTime() / 1000L;
    i i1 = (i)com.applovin.exoplayer2.l.a.b(this.f);
    boolean bool = i1.c();
    if (bool) {
      l1 = h(i1.f()) + ai.a(l3 - i1.e(), this.j);
    } else {
      long l;
      if (this.w == 0) {
        l = h();
      } else {
        l = this.l + l3;
      } 
      l1 = l;
      if (!paramBoolean)
        l1 = Math.max(0L, l - this.o); 
    } 
    if (this.D != bool) {
      this.F = this.C;
      this.E = this.B;
    } 
    long l4 = l3 - this.F;
    long l2 = l1;
    if (l4 < 1000000L) {
      l2 = this.E;
      long l = ai.a(l4, this.j);
      l4 = l4 * 1000L / 1000000L;
      l2 = (l1 * l4 + (1000L - l4) * (l2 + l)) / 1000L;
    } 
    if (!this.k) {
      l1 = this.B;
      if (l2 > l1) {
        this.k = true;
        l4 = ai.b(h.a(l2 - l1), this.j);
        l1 = System.currentTimeMillis();
        l4 = h.a(l4);
        this.a.a(l1 - l4);
      } 
    } 
    this.C = l3;
    this.B = l2;
    this.D = bool;
    return l2;
  }
  
  public void a() {
    ((i)com.applovin.exoplayer2.l.a.b(this.f)).d();
  }
  
  public void a(float paramFloat) {
    this.j = paramFloat;
    i i1 = this.f;
    if (i1 != null)
      i1.d(); 
  }
  
  public void a(AudioTrack paramAudioTrack, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    long l;
    this.c = paramAudioTrack;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = new i(paramAudioTrack);
    this.g = paramAudioTrack.getSampleRate();
    if (paramBoolean && a(paramInt1)) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.h = paramBoolean;
    paramBoolean = ai.d(paramInt1);
    this.q = paramBoolean;
    if (paramBoolean) {
      l = h((paramInt3 / paramInt2));
    } else {
      l = -9223372036854775807L;
    } 
    this.i = l;
    this.s = 0L;
    this.t = 0L;
    this.u = 0L;
    this.p = false;
    this.x = -9223372036854775807L;
    this.y = -9223372036854775807L;
    this.r = 0L;
    this.o = 0L;
    this.j = 1.0F;
  }
  
  public boolean a(long paramLong) {
    int k = ((AudioTrack)com.applovin.exoplayer2.l.a.b(this.c)).getPlayState();
    if (this.h) {
      if (k == 2) {
        this.p = false;
        return false;
      } 
      if (k == 1 && i() == 0L)
        return false; 
    } 
    boolean bool1 = this.p;
    boolean bool2 = f(paramLong);
    this.p = bool2;
    if (bool1 && !bool2 && k != 1)
      this.a.a(this.e, h.a(this.i)); 
    return true;
  }
  
  public int b(long paramLong) {
    int k = (int)(paramLong - i() * this.d);
    return this.e - k;
  }
  
  public boolean b() {
    return (((AudioTrack)com.applovin.exoplayer2.l.a.b(this.c)).getPlayState() == 3);
  }
  
  public long c(long paramLong) {
    return h.a(h(paramLong - i()));
  }
  
  public boolean c() {
    f();
    if (this.x == -9223372036854775807L) {
      ((i)com.applovin.exoplayer2.l.a.b(this.f)).d();
      return true;
    } 
    return false;
  }
  
  public void d() {
    f();
    this.c = null;
    this.f = null;
  }
  
  public boolean d(long paramLong) {
    return (this.y != -9223372036854775807L && paramLong > 0L && SystemClock.elapsedRealtime() - this.y >= 200L);
  }
  
  public void e(long paramLong) {
    this.z = i();
    this.x = SystemClock.elapsedRealtime() * 1000L;
    this.A = paramLong;
  }
  
  public boolean f(long paramLong) {
    return (paramLong > i() || g());
  }
  
  public static interface a {
    void a(int param1Int, long param1Long);
    
    void a(long param1Long);
    
    void a(long param1Long1, long param1Long2, long param1Long3, long param1Long4);
    
    void b(long param1Long);
    
    void b(long param1Long1, long param1Long2, long param1Long3, long param1Long4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\b\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */