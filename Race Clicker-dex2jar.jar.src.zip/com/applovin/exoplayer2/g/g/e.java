package com.applovin.exoplayer2.g.g;

import android.os.Parcel;
import android.os.Parcelable;

public final class e extends b {
  public static final Parcelable.Creator<e> CREATOR = new Parcelable.Creator<e>() {
      public e a(Parcel param1Parcel) {
        return new e();
      }
      
      public e[] a(int param1Int) {
        return new e[param1Int];
      }
    };
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {}
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\g\g\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */