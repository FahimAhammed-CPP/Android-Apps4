package com.applovin.exoplayer2.h;

import android.util.SparseArray;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.h;

final class ab<V> {
  private int a;
  
  private final SparseArray<V> b = new SparseArray();
  
  private final h<V> c;
  
  public ab() {
    this((h<V>)new ab$.ExternalSyntheticLambda0());
  }
  
  public ab(h<V> paramh) {
    this.c = paramh;
    this.a = -1;
  }
  
  public V a() {
    SparseArray<V> sparseArray = this.b;
    return (V)sparseArray.valueAt(sparseArray.size() - 1);
  }
  
  public V a(int paramInt) {
    if (this.a == -1)
      this.a = 0; 
    while (true) {
      int i = this.a;
      if (i > 0 && paramInt < this.b.keyAt(i)) {
        this.a--;
        continue;
      } 
      break;
    } 
    while (this.a < this.b.size() - 1 && paramInt >= this.b.keyAt(this.a + 1))
      this.a++; 
    return (V)this.b.valueAt(this.a);
  }
  
  public void a(int paramInt, V paramV) {
    int i = this.a;
    boolean bool = false;
    if (i == -1) {
      boolean bool1;
      if (this.b.size() == 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      a.b(bool1);
      this.a = 0;
    } 
    if (this.b.size() > 0) {
      SparseArray<V> sparseArray = this.b;
      i = sparseArray.keyAt(sparseArray.size() - 1);
      boolean bool1 = bool;
      if (paramInt >= i)
        bool1 = true; 
      a.a(bool1);
      if (i == paramInt) {
        h<V> h1 = this.c;
        SparseArray<V> sparseArray1 = this.b;
        h1.accept(sparseArray1.valueAt(sparseArray1.size() - 1));
      } 
    } 
    this.b.append(paramInt, paramV);
  }
  
  public void b() {
    for (int i = 0; i < this.b.size(); i++)
      this.c.accept(this.b.valueAt(i)); 
    this.a = -1;
    this.b.clear();
  }
  
  public void b(int paramInt) {
    int i = 0;
    while (i < this.b.size() - 1) {
      SparseArray<V> sparseArray = this.b;
      int j = i + 1;
      if (paramInt >= sparseArray.keyAt(j)) {
        this.c.accept(this.b.valueAt(i));
        this.b.removeAt(i);
        i = this.a;
        if (i > 0)
          this.a = i - 1; 
        i = j;
      } 
    } 
  }
  
  public void c(int paramInt) {
    for (int i = this.b.size() - 1; i >= 0 && paramInt < this.b.keyAt(i); i--) {
      this.c.accept(this.b.valueAt(i));
      this.b.removeAt(i);
    } 
    if (this.b.size() > 0) {
      paramInt = Math.min(this.a, this.b.size() - 1);
    } else {
      paramInt = -1;
    } 
    this.a = paramInt;
  }
  
  public boolean c() {
    return (this.b.size() == 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\h\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */