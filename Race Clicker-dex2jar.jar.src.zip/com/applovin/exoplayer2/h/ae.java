package com.applovin.exoplayer2.h;

import android.net.Uri;
import com.applovin.exoplayer2.ai;

public class ae extends ai {
  public final Uri c;
  
  public ae(String paramString, Uri paramUri) {
    super(paramString, null, false, 1);
    this.c = paramUri;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\h\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */