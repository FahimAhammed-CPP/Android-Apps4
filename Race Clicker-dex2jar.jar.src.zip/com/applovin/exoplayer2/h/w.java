package com.applovin.exoplayer2.h;

import android.os.Looper;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.d.e;
import com.applovin.exoplayer2.d.f;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.d.h;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.h;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.io.IOException;

public class w implements x {
  private boolean A;
  
  private v B;
  
  private v C;
  
  private int D;
  
  private boolean E;
  
  private boolean F;
  
  private long G;
  
  private boolean H;
  
  private final v a;
  
  private final a b;
  
  private final ab<b> c;
  
  private final h d;
  
  private final g.a e;
  
  private final Looper f;
  
  private c g;
  
  private v h;
  
  private f i;
  
  private int j;
  
  private int[] k;
  
  private long[] l;
  
  private int[] m;
  
  private int[] n;
  
  private long[] o;
  
  private x.a[] p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private long u;
  
  private long v;
  
  private long w;
  
  private boolean x;
  
  private boolean y;
  
  private boolean z;
  
  protected w(com.applovin.exoplayer2.k.b paramb, Looper paramLooper, h paramh, g.a parama) {
    this.f = paramLooper;
    this.d = paramh;
    this.e = parama;
    this.a = new v(paramb);
    this.b = new a();
    this.j = 1000;
    this.k = new int[1000];
    this.l = new long[1000];
    this.o = new long[1000];
    this.n = new int[1000];
    this.m = new int[1000];
    this.p = new x.a[1000];
    this.c = new ab<b>((h<b>)new w$.ExternalSyntheticLambda0());
    this.u = Long.MIN_VALUE;
    this.v = Long.MIN_VALUE;
    this.w = Long.MIN_VALUE;
    this.z = true;
    this.y = true;
  }
  
  private int a(int paramInt1, int paramInt2, long paramLong, boolean paramBoolean) {
    int j = -1;
    int k = 0;
    int i = paramInt1;
    paramInt1 = k;
    while (paramInt1 < paramInt2) {
      long l = this.o[i];
      if (l <= paramLong) {
        if (!paramBoolean || (this.n[i] & 0x1) != 0) {
          if (l == paramLong)
            return paramInt1; 
          j = paramInt1;
        } 
        k = i + 1;
        i = k;
        if (k == this.j)
          i = 0; 
        paramInt1++;
      } 
    } 
    return j;
  }
  
  private int a(com.applovin.exoplayer2.w paramw, g paramg, boolean paramBoolean1, boolean paramBoolean2, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: iconst_0
    //   4: putfield c : Z
    //   7: aload_0
    //   8: invokespecial o : ()Z
    //   11: ifne -> 82
    //   14: iload #4
    //   16: ifne -> 72
    //   19: aload_0
    //   20: getfield x : Z
    //   23: ifeq -> 29
    //   26: goto -> 72
    //   29: aload_0
    //   30: getfield C : Lcom/applovin/exoplayer2/v;
    //   33: astore_2
    //   34: aload_2
    //   35: ifnull -> 67
    //   38: iload_3
    //   39: ifne -> 50
    //   42: aload_2
    //   43: aload_0
    //   44: getfield h : Lcom/applovin/exoplayer2/v;
    //   47: if_acmpeq -> 67
    //   50: aload_0
    //   51: aload_2
    //   52: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   55: checkcast com/applovin/exoplayer2/v
    //   58: aload_1
    //   59: invokespecial a : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/w;)V
    //   62: aload_0
    //   63: monitorexit
    //   64: bipush #-5
    //   66: ireturn
    //   67: aload_0
    //   68: monitorexit
    //   69: bipush #-3
    //   71: ireturn
    //   72: aload_2
    //   73: iconst_4
    //   74: invokevirtual a_ : (I)V
    //   77: aload_0
    //   78: monitorexit
    //   79: bipush #-4
    //   81: ireturn
    //   82: aload_0
    //   83: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   86: aload_0
    //   87: invokevirtual f : ()I
    //   90: invokevirtual a : (I)Ljava/lang/Object;
    //   93: checkcast com/applovin/exoplayer2/h/w$b
    //   96: getfield a : Lcom/applovin/exoplayer2/v;
    //   99: astore #7
    //   101: iload_3
    //   102: ifne -> 227
    //   105: aload #7
    //   107: aload_0
    //   108: getfield h : Lcom/applovin/exoplayer2/v;
    //   111: if_acmpeq -> 117
    //   114: goto -> 227
    //   117: aload_0
    //   118: aload_0
    //   119: getfield t : I
    //   122: invokespecial f : (I)I
    //   125: istore #6
    //   127: aload_0
    //   128: iload #6
    //   130: invokespecial c : (I)Z
    //   133: ifne -> 146
    //   136: aload_2
    //   137: iconst_1
    //   138: putfield c : Z
    //   141: aload_0
    //   142: monitorexit
    //   143: bipush #-3
    //   145: ireturn
    //   146: aload_2
    //   147: aload_0
    //   148: getfield n : [I
    //   151: iload #6
    //   153: iaload
    //   154: invokevirtual a_ : (I)V
    //   157: aload_2
    //   158: aload_0
    //   159: getfield o : [J
    //   162: iload #6
    //   164: laload
    //   165: putfield d : J
    //   168: aload_2
    //   169: getfield d : J
    //   172: aload_0
    //   173: getfield u : J
    //   176: lcmp
    //   177: ifge -> 186
    //   180: aload_2
    //   181: ldc -2147483648
    //   183: invokevirtual b : (I)V
    //   186: aload #5
    //   188: aload_0
    //   189: getfield m : [I
    //   192: iload #6
    //   194: iaload
    //   195: putfield a : I
    //   198: aload #5
    //   200: aload_0
    //   201: getfield l : [J
    //   204: iload #6
    //   206: laload
    //   207: putfield b : J
    //   210: aload #5
    //   212: aload_0
    //   213: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   216: iload #6
    //   218: aaload
    //   219: putfield c : Lcom/applovin/exoplayer2/e/x$a;
    //   222: aload_0
    //   223: monitorexit
    //   224: bipush #-4
    //   226: ireturn
    //   227: aload_0
    //   228: aload #7
    //   230: aload_1
    //   231: invokespecial a : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/w;)V
    //   234: aload_0
    //   235: monitorexit
    //   236: bipush #-5
    //   238: ireturn
    //   239: astore_1
    //   240: aload_0
    //   241: monitorexit
    //   242: aload_1
    //   243: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	239	finally
    //   19	26	239	finally
    //   29	34	239	finally
    //   42	50	239	finally
    //   50	62	239	finally
    //   72	77	239	finally
    //   82	101	239	finally
    //   105	114	239	finally
    //   117	141	239	finally
    //   146	186	239	finally
    //   186	222	239	finally
    //   227	234	239	finally
  }
  
  public static w a(com.applovin.exoplayer2.k.b paramb, Looper paramLooper, h paramh, g.a parama) {
    return new w(paramb, (Looper)com.applovin.exoplayer2.l.a.b(paramLooper), (h)com.applovin.exoplayer2.l.a.b(paramh), (g.a)com.applovin.exoplayer2.l.a.b(parama));
  }
  
  private void a(long paramLong1, int paramInt1, long paramLong2, int paramInt2, x.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore #8
    //   8: iload #8
    //   10: ifle -> 572
    //   13: aload_0
    //   14: iload #8
    //   16: iconst_1
    //   17: isub
    //   18: invokespecial f : (I)I
    //   21: istore #8
    //   23: aload_0
    //   24: getfield l : [J
    //   27: iload #8
    //   29: laload
    //   30: aload_0
    //   31: getfield m : [I
    //   34: iload #8
    //   36: iaload
    //   37: i2l
    //   38: ladd
    //   39: lload #4
    //   41: lcmp
    //   42: ifgt -> 566
    //   45: iconst_1
    //   46: istore #9
    //   48: goto -> 51
    //   51: iload #9
    //   53: invokestatic a : (Z)V
    //   56: goto -> 572
    //   59: aload_0
    //   60: iload #9
    //   62: putfield x : Z
    //   65: aload_0
    //   66: aload_0
    //   67: getfield w : J
    //   70: lload_1
    //   71: invokestatic max : (JJ)J
    //   74: putfield w : J
    //   77: aload_0
    //   78: aload_0
    //   79: getfield q : I
    //   82: invokespecial f : (I)I
    //   85: istore #8
    //   87: aload_0
    //   88: getfield o : [J
    //   91: iload #8
    //   93: lload_1
    //   94: lastore
    //   95: aload_0
    //   96: getfield l : [J
    //   99: iload #8
    //   101: lload #4
    //   103: lastore
    //   104: aload_0
    //   105: getfield m : [I
    //   108: iload #8
    //   110: iload #6
    //   112: iastore
    //   113: aload_0
    //   114: getfield n : [I
    //   117: iload #8
    //   119: iload_3
    //   120: iastore
    //   121: aload_0
    //   122: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   125: iload #8
    //   127: aload #7
    //   129: aastore
    //   130: aload_0
    //   131: getfield k : [I
    //   134: iload #8
    //   136: aload_0
    //   137: getfield D : I
    //   140: iastore
    //   141: aload_0
    //   142: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   145: invokevirtual c : ()Z
    //   148: ifne -> 174
    //   151: aload_0
    //   152: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   155: invokevirtual a : ()Ljava/lang/Object;
    //   158: checkcast com/applovin/exoplayer2/h/w$b
    //   161: getfield a : Lcom/applovin/exoplayer2/v;
    //   164: aload_0
    //   165: getfield C : Lcom/applovin/exoplayer2/v;
    //   168: invokevirtual equals : (Ljava/lang/Object;)Z
    //   171: ifne -> 251
    //   174: aload_0
    //   175: getfield d : Lcom/applovin/exoplayer2/d/h;
    //   178: astore #7
    //   180: aload #7
    //   182: ifnull -> 215
    //   185: aload #7
    //   187: aload_0
    //   188: getfield f : Landroid/os/Looper;
    //   191: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   194: checkcast android/os/Looper
    //   197: aload_0
    //   198: getfield e : Lcom/applovin/exoplayer2/d/g$a;
    //   201: aload_0
    //   202: getfield C : Lcom/applovin/exoplayer2/v;
    //   205: invokeinterface a : (Landroid/os/Looper;Lcom/applovin/exoplayer2/d/g$a;Lcom/applovin/exoplayer2/v;)Lcom/applovin/exoplayer2/d/h$a;
    //   210: astore #7
    //   212: goto -> 220
    //   215: getstatic com/applovin/exoplayer2/d/h$a.b : Lcom/applovin/exoplayer2/d/h$a;
    //   218: astore #7
    //   220: aload_0
    //   221: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   224: aload_0
    //   225: invokevirtual c : ()I
    //   228: new com/applovin/exoplayer2/h/w$b
    //   231: dup
    //   232: aload_0
    //   233: getfield C : Lcom/applovin/exoplayer2/v;
    //   236: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   239: checkcast com/applovin/exoplayer2/v
    //   242: aload #7
    //   244: aconst_null
    //   245: invokespecial <init> : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/d/h$a;Lcom/applovin/exoplayer2/h/w$1;)V
    //   248: invokevirtual a : (ILjava/lang/Object;)V
    //   251: aload_0
    //   252: getfield q : I
    //   255: iconst_1
    //   256: iadd
    //   257: istore_3
    //   258: aload_0
    //   259: iload_3
    //   260: putfield q : I
    //   263: aload_0
    //   264: getfield j : I
    //   267: istore #6
    //   269: iload_3
    //   270: iload #6
    //   272: if_icmpne -> 556
    //   275: iload #6
    //   277: sipush #1000
    //   280: iadd
    //   281: istore_3
    //   282: iload_3
    //   283: newarray int
    //   285: astore #7
    //   287: iload_3
    //   288: newarray long
    //   290: astore #10
    //   292: iload_3
    //   293: newarray long
    //   295: astore #11
    //   297: iload_3
    //   298: newarray int
    //   300: astore #12
    //   302: iload_3
    //   303: newarray int
    //   305: astore #13
    //   307: iload_3
    //   308: anewarray com/applovin/exoplayer2/e/x$a
    //   311: astore #14
    //   313: aload_0
    //   314: getfield s : I
    //   317: istore #8
    //   319: iload #6
    //   321: iload #8
    //   323: isub
    //   324: istore #6
    //   326: aload_0
    //   327: getfield l : [J
    //   330: iload #8
    //   332: aload #10
    //   334: iconst_0
    //   335: iload #6
    //   337: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   340: aload_0
    //   341: getfield o : [J
    //   344: aload_0
    //   345: getfield s : I
    //   348: aload #11
    //   350: iconst_0
    //   351: iload #6
    //   353: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   356: aload_0
    //   357: getfield n : [I
    //   360: aload_0
    //   361: getfield s : I
    //   364: aload #12
    //   366: iconst_0
    //   367: iload #6
    //   369: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   372: aload_0
    //   373: getfield m : [I
    //   376: aload_0
    //   377: getfield s : I
    //   380: aload #13
    //   382: iconst_0
    //   383: iload #6
    //   385: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   388: aload_0
    //   389: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   392: aload_0
    //   393: getfield s : I
    //   396: aload #14
    //   398: iconst_0
    //   399: iload #6
    //   401: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   404: aload_0
    //   405: getfield k : [I
    //   408: aload_0
    //   409: getfield s : I
    //   412: aload #7
    //   414: iconst_0
    //   415: iload #6
    //   417: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   420: aload_0
    //   421: getfield s : I
    //   424: istore #8
    //   426: aload_0
    //   427: getfield l : [J
    //   430: iconst_0
    //   431: aload #10
    //   433: iload #6
    //   435: iload #8
    //   437: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   440: aload_0
    //   441: getfield o : [J
    //   444: iconst_0
    //   445: aload #11
    //   447: iload #6
    //   449: iload #8
    //   451: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   454: aload_0
    //   455: getfield n : [I
    //   458: iconst_0
    //   459: aload #12
    //   461: iload #6
    //   463: iload #8
    //   465: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   468: aload_0
    //   469: getfield m : [I
    //   472: iconst_0
    //   473: aload #13
    //   475: iload #6
    //   477: iload #8
    //   479: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   482: aload_0
    //   483: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   486: iconst_0
    //   487: aload #14
    //   489: iload #6
    //   491: iload #8
    //   493: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   496: aload_0
    //   497: getfield k : [I
    //   500: iconst_0
    //   501: aload #7
    //   503: iload #6
    //   505: iload #8
    //   507: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   510: aload_0
    //   511: aload #10
    //   513: putfield l : [J
    //   516: aload_0
    //   517: aload #11
    //   519: putfield o : [J
    //   522: aload_0
    //   523: aload #12
    //   525: putfield n : [I
    //   528: aload_0
    //   529: aload #13
    //   531: putfield m : [I
    //   534: aload_0
    //   535: aload #14
    //   537: putfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   540: aload_0
    //   541: aload #7
    //   543: putfield k : [I
    //   546: aload_0
    //   547: iconst_0
    //   548: putfield s : I
    //   551: aload_0
    //   552: iload_3
    //   553: putfield j : I
    //   556: aload_0
    //   557: monitorexit
    //   558: return
    //   559: astore #7
    //   561: aload_0
    //   562: monitorexit
    //   563: aload #7
    //   565: athrow
    //   566: iconst_0
    //   567: istore #9
    //   569: goto -> 51
    //   572: ldc 536870912
    //   574: iload_3
    //   575: iand
    //   576: ifeq -> 585
    //   579: iconst_1
    //   580: istore #9
    //   582: goto -> 59
    //   585: iconst_0
    //   586: istore #9
    //   588: goto -> 59
    // Exception table:
    //   from	to	target	type
    //   2	8	559	finally
    //   13	45	559	finally
    //   51	56	559	finally
    //   59	174	559	finally
    //   174	180	559	finally
    //   185	212	559	finally
    //   215	220	559	finally
    //   220	251	559	finally
    //   251	269	559	finally
    //   282	319	559	finally
    //   326	556	559	finally
  }
  
  private void a(v paramv, com.applovin.exoplayer2.w paramw) {
    boolean bool;
    e e1;
    v v2;
    v v1 = this.h;
    if (v1 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      v1 = null;
    } else {
      e1 = v1.o;
    } 
    this.h = paramv;
    e e2 = paramv.o;
    h h1 = this.d;
    if (h1 != null) {
      v2 = paramv.a(h1.a(paramv));
    } else {
      v2 = paramv;
    } 
    paramw.b = v2;
    paramw.a = this.i;
    if (this.d == null)
      return; 
    if (!bool && ai.a(e1, e2))
      return; 
    f f2 = this.i;
    f f1 = this.d.b((Looper)com.applovin.exoplayer2.l.a.b(this.f), this.e, paramv);
    this.i = f1;
    paramw.a = f1;
    if (f2 != null)
      f2.b(this.e); 
  }
  
  private long b(int paramInt) {
    int i = c() - paramInt;
    boolean bool2 = false;
    if (i >= 0 && i <= this.q - this.t) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool1);
    int j = this.q - i;
    this.q = j;
    this.w = Math.max(this.v, e(j));
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.x)
        bool1 = true; 
    } 
    this.x = bool1;
    this.c.c(paramInt);
    paramInt = this.q;
    if (paramInt != 0) {
      paramInt = f(paramInt - 1);
      return this.l[paramInt] + this.m[paramInt];
    } 
    return 0L;
  }
  
  private long b(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore #6
    //   8: iload #6
    //   10: ifeq -> 105
    //   13: aload_0
    //   14: getfield o : [J
    //   17: astore #9
    //   19: aload_0
    //   20: getfield s : I
    //   23: istore #7
    //   25: lload_1
    //   26: aload #9
    //   28: iload #7
    //   30: laload
    //   31: lcmp
    //   32: ifge -> 38
    //   35: goto -> 105
    //   38: iload #6
    //   40: istore #5
    //   42: iload #4
    //   44: ifeq -> 70
    //   47: aload_0
    //   48: getfield t : I
    //   51: istore #8
    //   53: iload #6
    //   55: istore #5
    //   57: iload #8
    //   59: iload #6
    //   61: if_icmpeq -> 70
    //   64: iload #8
    //   66: iconst_1
    //   67: iadd
    //   68: istore #5
    //   70: aload_0
    //   71: iload #7
    //   73: iload #5
    //   75: lload_1
    //   76: iload_3
    //   77: invokespecial a : (IIJZ)I
    //   80: istore #5
    //   82: iload #5
    //   84: iconst_m1
    //   85: if_icmpne -> 94
    //   88: aload_0
    //   89: monitorexit
    //   90: ldc2_w -1
    //   93: lreturn
    //   94: aload_0
    //   95: iload #5
    //   97: invokespecial d : (I)J
    //   100: lstore_1
    //   101: aload_0
    //   102: monitorexit
    //   103: lload_1
    //   104: lreturn
    //   105: aload_0
    //   106: monitorexit
    //   107: ldc2_w -1
    //   110: lreturn
    //   111: astore #9
    //   113: aload_0
    //   114: monitorexit
    //   115: aload #9
    //   117: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	111	finally
    //   13	25	111	finally
    //   47	53	111	finally
    //   70	82	111	finally
    //   94	101	111	finally
  }
  
  private boolean b(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore_3
    //   7: iconst_1
    //   8: istore #6
    //   10: iload_3
    //   11: ifne -> 38
    //   14: aload_0
    //   15: getfield v : J
    //   18: lstore #4
    //   20: lload_1
    //   21: lload #4
    //   23: lcmp
    //   24: ifle -> 30
    //   27: goto -> 33
    //   30: iconst_0
    //   31: istore #6
    //   33: aload_0
    //   34: monitorexit
    //   35: iload #6
    //   37: ireturn
    //   38: aload_0
    //   39: invokevirtual i : ()J
    //   42: lstore #4
    //   44: lload #4
    //   46: lload_1
    //   47: lcmp
    //   48: iflt -> 55
    //   51: aload_0
    //   52: monitorexit
    //   53: iconst_0
    //   54: ireturn
    //   55: aload_0
    //   56: lload_1
    //   57: invokespecial c : (J)I
    //   60: istore_3
    //   61: aload_0
    //   62: aload_0
    //   63: getfield r : I
    //   66: iload_3
    //   67: iadd
    //   68: invokespecial b : (I)J
    //   71: pop2
    //   72: aload_0
    //   73: monitorexit
    //   74: iconst_1
    //   75: ireturn
    //   76: astore #7
    //   78: aload_0
    //   79: monitorexit
    //   80: aload #7
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	76	finally
    //   14	20	76	finally
    //   38	44	76	finally
    //   55	72	76	finally
  }
  
  private int c(long paramLong) {
    int j = this.q;
    int i = f(j - 1);
    while (j > this.t && this.o[i] >= paramLong) {
      int k = j - 1;
      int m = i - 1;
      j = k;
      i = m;
      if (m == -1) {
        i = this.j - 1;
        j = k;
      } 
    } 
    return j;
  }
  
  private boolean c(int paramInt) {
    f f1 = this.i;
    return (f1 == null || f1.c() == 4 || ((this.n[paramInt] & 0x40000000) == 0 && this.i.d()));
  }
  
  private boolean c(v paramv) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield z : Z
    //   7: aload_1
    //   8: aload_0
    //   9: getfield C : Lcom/applovin/exoplayer2/v;
    //   12: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   15: istore_2
    //   16: iload_2
    //   17: ifeq -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: iconst_0
    //   23: ireturn
    //   24: aload_0
    //   25: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   28: invokevirtual c : ()Z
    //   31: ifne -> 74
    //   34: aload_0
    //   35: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   38: invokevirtual a : ()Ljava/lang/Object;
    //   41: checkcast com/applovin/exoplayer2/h/w$b
    //   44: getfield a : Lcom/applovin/exoplayer2/v;
    //   47: aload_1
    //   48: invokevirtual equals : (Ljava/lang/Object;)Z
    //   51: ifeq -> 74
    //   54: aload_0
    //   55: aload_0
    //   56: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   59: invokevirtual a : ()Ljava/lang/Object;
    //   62: checkcast com/applovin/exoplayer2/h/w$b
    //   65: getfield a : Lcom/applovin/exoplayer2/v;
    //   68: putfield C : Lcom/applovin/exoplayer2/v;
    //   71: goto -> 79
    //   74: aload_0
    //   75: aload_1
    //   76: putfield C : Lcom/applovin/exoplayer2/v;
    //   79: aload_0
    //   80: aload_0
    //   81: getfield C : Lcom/applovin/exoplayer2/v;
    //   84: getfield l : Ljava/lang/String;
    //   87: aload_0
    //   88: getfield C : Lcom/applovin/exoplayer2/v;
    //   91: getfield i : Ljava/lang/String;
    //   94: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Z
    //   97: putfield E : Z
    //   100: aload_0
    //   101: iconst_0
    //   102: putfield F : Z
    //   105: aload_0
    //   106: monitorexit
    //   107: iconst_1
    //   108: ireturn
    //   109: astore_1
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	109	finally
    //   24	71	109	finally
    //   74	79	109	finally
    //   79	105	109	finally
  }
  
  private long d(int paramInt) {
    this.v = Math.max(this.v, e(paramInt));
    this.q -= paramInt;
    int i = this.r + paramInt;
    this.r = i;
    int j = this.s + paramInt;
    this.s = j;
    int k = this.j;
    if (j >= k)
      this.s = j - k; 
    paramInt = this.t - paramInt;
    this.t = paramInt;
    if (paramInt < 0)
      this.t = 0; 
    this.c.b(i);
    if (this.q == 0) {
      i = this.s;
      paramInt = i;
      if (i == 0)
        paramInt = this.j; 
      return this.l[--paramInt] + this.m[paramInt];
    } 
    return this.l[this.s];
  }
  
  private long e(int paramInt) {
    long l = Long.MIN_VALUE;
    if (paramInt == 0)
      return Long.MIN_VALUE; 
    int i = f(paramInt - 1);
    for (int j = 0; j < paramInt; j++) {
      l = Math.max(l, this.o[i]);
      if ((this.n[i] & 0x1) != 0)
        return l; 
      int k = i - 1;
      i = k;
      if (k == -1)
        i = this.j - 1; 
    } 
    return l;
  }
  
  private int f(int paramInt) {
    paramInt = this.s + paramInt;
    int i = this.j;
    return (paramInt < i) ? paramInt : (paramInt - i);
  }
  
  private void l() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield t : I
    //   7: aload_0
    //   8: getfield a : Lcom/applovin/exoplayer2/h/v;
    //   11: invokevirtual b : ()V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  private long m() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore_1
    //   7: iload_1
    //   8: ifne -> 17
    //   11: aload_0
    //   12: monitorexit
    //   13: ldc2_w -1
    //   16: lreturn
    //   17: aload_0
    //   18: iload_1
    //   19: invokespecial d : (I)J
    //   22: lstore_2
    //   23: aload_0
    //   24: monitorexit
    //   25: lload_2
    //   26: lreturn
    //   27: astore #4
    //   29: aload_0
    //   30: monitorexit
    //   31: aload #4
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	27	finally
    //   17	23	27	finally
  }
  
  private void n() {
    f f1 = this.i;
    if (f1 != null) {
      f1.b(this.e);
      this.i = null;
      this.h = null;
    } 
  }
  
  private boolean o() {
    return (this.t != this.q);
  }
  
  public final int a(g paramg, int paramInt1, boolean paramBoolean, int paramInt2) throws IOException {
    return this.a.a(paramg, paramInt1, paramBoolean);
  }
  
  public int a(com.applovin.exoplayer2.w paramw, g paramg, int paramInt, boolean paramBoolean) {
    boolean bool2;
    boolean bool1 = false;
    if ((paramInt & 0x2) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    int i = a(paramw, paramg, bool2, paramBoolean, this.b);
    if (i == -4 && !paramg.c()) {
      if ((paramInt & 0x1) != 0)
        bool1 = true; 
      if ((paramInt & 0x4) == 0)
        if (bool1) {
          this.a.b(paramg, this.b);
        } else {
          this.a.a(paramg, this.b);
        }  
      if (!bool1)
        this.t++; 
    } 
    return i;
  }
  
  public void a() {
    a(true);
    n();
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: iflt -> 49
    //   6: aload_0
    //   7: getfield t : I
    //   10: iload_1
    //   11: iadd
    //   12: aload_0
    //   13: getfield q : I
    //   16: if_icmpgt -> 49
    //   19: iconst_1
    //   20: istore_2
    //   21: goto -> 24
    //   24: iload_2
    //   25: invokestatic a : (Z)V
    //   28: aload_0
    //   29: aload_0
    //   30: getfield t : I
    //   33: iload_1
    //   34: iadd
    //   35: putfield t : I
    //   38: aload_0
    //   39: monitorexit
    //   40: return
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_3
    //   44: athrow
    //   45: astore_3
    //   46: goto -> 41
    //   49: iconst_0
    //   50: istore_2
    //   51: goto -> 24
    // Exception table:
    //   from	to	target	type
    //   6	19	45	finally
    //   24	38	45	finally
  }
  
  public final void a(long paramLong) {
    this.u = paramLong;
  }
  
  public void a(long paramLong, int paramInt1, int paramInt2, int paramInt3, x.a parama) {
    boolean bool;
    if (this.A)
      a((v)com.applovin.exoplayer2.l.a.a(this.B)); 
    int i = paramInt1 & 0x1;
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.y) {
      if (!bool)
        return; 
      this.y = false;
    } 
    paramLong = this.G + paramLong;
    if (this.E) {
      if (paramLong < this.u)
        return; 
      if (i == 0) {
        if (!this.F) {
          StringBuilder stringBuilder = new StringBuilder("Overriding unexpected non-sync sample for format: ");
          stringBuilder.append(this.C);
          q.c("SampleQueue", stringBuilder.toString());
          this.F = true;
        } 
        paramInt1 |= 0x1;
      } 
    } 
    if (this.H)
      if (bool) {
        if (!b(paramLong))
          return; 
        this.H = false;
      } else {
        return;
      }  
    a(paramLong, paramInt1, this.a.c() - paramInt2 - paramInt3, paramInt2, parama);
  }
  
  public final void a(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    this.a.a(b(paramLong, paramBoolean1, paramBoolean2));
  }
  
  public final void a(c paramc) {
    this.g = paramc;
  }
  
  public final void a(y paramy, int paramInt1, int paramInt2) {
    this.a.a(paramy, paramInt1);
  }
  
  public final void a(v paramv) {
    v v1 = b(paramv);
    this.A = false;
    this.B = paramv;
    boolean bool = c(v1);
    c c1 = this.g;
    if (c1 != null && bool)
      c1.a(v1); 
  }
  
  public void a(boolean paramBoolean) {
    this.a.a();
    this.q = 0;
    this.r = 0;
    this.s = 0;
    this.t = 0;
    this.y = true;
    this.u = Long.MIN_VALUE;
    this.v = Long.MIN_VALUE;
    this.w = Long.MIN_VALUE;
    this.x = false;
    this.c.b();
    if (paramBoolean) {
      this.B = null;
      this.C = null;
      this.z = true;
    } 
  }
  
  public final boolean a(long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial l : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield t : I
    //   11: invokespecial f : (I)I
    //   14: istore #4
    //   16: aload_0
    //   17: invokespecial o : ()Z
    //   20: ifeq -> 100
    //   23: lload_1
    //   24: aload_0
    //   25: getfield o : [J
    //   28: iload #4
    //   30: laload
    //   31: lcmp
    //   32: iflt -> 100
    //   35: lload_1
    //   36: aload_0
    //   37: getfield w : J
    //   40: lcmp
    //   41: ifle -> 51
    //   44: iload_3
    //   45: ifne -> 51
    //   48: goto -> 100
    //   51: aload_0
    //   52: iload #4
    //   54: aload_0
    //   55: getfield q : I
    //   58: aload_0
    //   59: getfield t : I
    //   62: isub
    //   63: lload_1
    //   64: iconst_1
    //   65: invokespecial a : (IIJZ)I
    //   68: istore #4
    //   70: iload #4
    //   72: iconst_m1
    //   73: if_icmpne -> 80
    //   76: aload_0
    //   77: monitorexit
    //   78: iconst_0
    //   79: ireturn
    //   80: aload_0
    //   81: lload_1
    //   82: putfield u : J
    //   85: aload_0
    //   86: aload_0
    //   87: getfield t : I
    //   90: iload #4
    //   92: iadd
    //   93: putfield t : I
    //   96: aload_0
    //   97: monitorexit
    //   98: iconst_1
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore #5
    //   106: aload_0
    //   107: monitorexit
    //   108: aload #5
    //   110: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	104	finally
    //   51	70	104	finally
    //   80	96	104	finally
  }
  
  public final int b(long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield t : I
    //   7: invokespecial f : (I)I
    //   10: istore #4
    //   12: aload_0
    //   13: invokespecial o : ()Z
    //   16: ifeq -> 101
    //   19: lload_1
    //   20: aload_0
    //   21: getfield o : [J
    //   24: iload #4
    //   26: laload
    //   27: lcmp
    //   28: ifge -> 34
    //   31: goto -> 101
    //   34: lload_1
    //   35: aload_0
    //   36: getfield w : J
    //   39: lcmp
    //   40: ifle -> 67
    //   43: iload_3
    //   44: ifeq -> 67
    //   47: aload_0
    //   48: getfield q : I
    //   51: istore #4
    //   53: aload_0
    //   54: getfield t : I
    //   57: istore #5
    //   59: aload_0
    //   60: monitorexit
    //   61: iload #4
    //   63: iload #5
    //   65: isub
    //   66: ireturn
    //   67: aload_0
    //   68: iload #4
    //   70: aload_0
    //   71: getfield q : I
    //   74: aload_0
    //   75: getfield t : I
    //   78: isub
    //   79: lload_1
    //   80: iconst_1
    //   81: invokespecial a : (IIJZ)I
    //   84: istore #4
    //   86: iload #4
    //   88: iconst_m1
    //   89: if_icmpne -> 96
    //   92: aload_0
    //   93: monitorexit
    //   94: iconst_0
    //   95: ireturn
    //   96: aload_0
    //   97: monitorexit
    //   98: iload #4
    //   100: ireturn
    //   101: aload_0
    //   102: monitorexit
    //   103: iconst_0
    //   104: ireturn
    //   105: astore #6
    //   107: aload_0
    //   108: monitorexit
    //   109: aload #6
    //   111: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	105	finally
    //   34	43	105	finally
    //   47	59	105	finally
    //   67	86	105	finally
  }
  
  protected v b(v paramv) {
    v v1 = paramv;
    if (this.G != 0L) {
      v1 = paramv;
      if (paramv.p != Long.MAX_VALUE)
        v1 = paramv.a().a(paramv.p + this.G).a(); 
    } 
    return v1;
  }
  
  public final void b() {
    a(false);
  }
  
  public boolean b(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial o : ()Z
    //   6: istore_2
    //   7: iconst_1
    //   8: istore_3
    //   9: iload_2
    //   10: ifne -> 63
    //   13: iload_3
    //   14: istore_2
    //   15: iload_1
    //   16: ifne -> 59
    //   19: iload_3
    //   20: istore_2
    //   21: aload_0
    //   22: getfield x : Z
    //   25: ifne -> 59
    //   28: aload_0
    //   29: getfield C : Lcom/applovin/exoplayer2/v;
    //   32: astore #4
    //   34: aload #4
    //   36: ifnull -> 57
    //   39: aload_0
    //   40: getfield h : Lcom/applovin/exoplayer2/v;
    //   43: astore #5
    //   45: aload #4
    //   47: aload #5
    //   49: if_acmpeq -> 57
    //   52: iload_3
    //   53: istore_2
    //   54: goto -> 59
    //   57: iconst_0
    //   58: istore_2
    //   59: aload_0
    //   60: monitorexit
    //   61: iload_2
    //   62: ireturn
    //   63: aload_0
    //   64: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   67: aload_0
    //   68: invokevirtual f : ()I
    //   71: invokevirtual a : (I)Ljava/lang/Object;
    //   74: checkcast com/applovin/exoplayer2/h/w$b
    //   77: getfield a : Lcom/applovin/exoplayer2/v;
    //   80: astore #4
    //   82: aload_0
    //   83: getfield h : Lcom/applovin/exoplayer2/v;
    //   86: astore #5
    //   88: aload #4
    //   90: aload #5
    //   92: if_acmpeq -> 99
    //   95: aload_0
    //   96: monitorexit
    //   97: iconst_1
    //   98: ireturn
    //   99: aload_0
    //   100: aload_0
    //   101: aload_0
    //   102: getfield t : I
    //   105: invokespecial f : (I)I
    //   108: invokespecial c : (I)Z
    //   111: istore_1
    //   112: aload_0
    //   113: monitorexit
    //   114: iload_1
    //   115: ireturn
    //   116: astore #4
    //   118: aload_0
    //   119: monitorexit
    //   120: aload #4
    //   122: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	116	finally
    //   21	34	116	finally
    //   39	45	116	finally
    //   63	88	116	finally
    //   99	112	116	finally
  }
  
  public final int c() {
    return this.r + this.q;
  }
  
  public void d() {
    k();
    n();
  }
  
  public void e() throws IOException {
    f f1 = this.i;
    if (f1 != null) {
      if (f1.c() != 1)
        return; 
      throw (f.a)com.applovin.exoplayer2.l.a.b(this.i.e());
    } 
  }
  
  public final int f() {
    return this.r + this.t;
  }
  
  public final v g() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield z : Z
    //   6: ifeq -> 14
    //   9: aconst_null
    //   10: astore_1
    //   11: goto -> 19
    //   14: aload_0
    //   15: getfield C : Lcom/applovin/exoplayer2/v;
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	23	finally
    //   14	19	23	finally
  }
  
  public final long h() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield w : J
    //   6: lstore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: lload_1
    //   10: lreturn
    //   11: astore_3
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_3
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final long i() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield v : J
    //   6: aload_0
    //   7: aload_0
    //   8: getfield t : I
    //   11: invokespecial e : (I)J
    //   14: invokestatic max : (JJ)J
    //   17: lstore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: lload_1
    //   21: lreturn
    //   22: astore_3
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_3
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	22	finally
  }
  
  public final boolean j() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield x : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final void k() {
    this.a.a(m());
  }
  
  static final class a {
    public int a;
    
    public long b;
    
    public x.a c;
  }
  
  private static final class b {
    public final v a;
    
    public final h.a b;
    
    private b(v param1v, h.a param1a) {
      this.a = param1v;
      this.b = param1a;
    }
  }
  
  public static interface c {
    void a(v param1v);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\h\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */