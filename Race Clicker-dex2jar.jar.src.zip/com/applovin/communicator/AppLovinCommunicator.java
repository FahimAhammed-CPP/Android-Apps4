package com.applovin.communicator;

import android.content.Context;
import com.applovin.impl.communicator.MessagingServiceImpl;
import com.applovin.impl.communicator.a;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.y;
import java.util.Collections;
import java.util.List;

public final class AppLovinCommunicator {
  private static AppLovinCommunicator a;
  
  private static final Object b = new Object();
  
  private o c;
  
  private y d;
  
  private final a e = new a();
  
  private final MessagingServiceImpl f = new MessagingServiceImpl();
  
  private void a(String paramString) {
    if (this.d != null && y.a())
      this.d.b("AppLovinCommunicator", paramString); 
  }
  
  public static AppLovinCommunicator getInstance(Context paramContext) {
    synchronized (b) {
      if (a == null)
        a = new AppLovinCommunicator(); 
      return a;
    } 
  }
  
  public void a(o paramo) {
    this.c = paramo;
    this.d = paramo.F();
    StringBuilder stringBuilder = new StringBuilder("Attached SDK instance: ");
    stringBuilder.append(paramo);
    stringBuilder.append("...");
    a(stringBuilder.toString());
  }
  
  public AppLovinCommunicatorMessagingService getMessagingService() {
    return (AppLovinCommunicatorMessagingService)this.f;
  }
  
  public boolean hasSubscriber(String paramString) {
    return this.e.a(paramString);
  }
  
  public boolean respondsToTopic(String paramString) {
    return this.c.X().c(paramString);
  }
  
  public void subscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, String paramString) {
    subscribe(paramAppLovinCommunicatorSubscriber, Collections.singletonList(paramString));
  }
  
  public void subscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, List<String> paramList) {
    for (String str : paramList) {
      if (!this.e.a(paramAppLovinCommunicatorSubscriber, str)) {
        StringBuilder stringBuilder = new StringBuilder("Unable to subscribe ");
        stringBuilder.append(paramAppLovinCommunicatorSubscriber);
        stringBuilder.append(" to topic: ");
        stringBuilder.append(str);
        a(stringBuilder.toString());
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("AppLovinCommunicator{sdk=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void unsubscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, String paramString) {
    unsubscribe(paramAppLovinCommunicatorSubscriber, Collections.singletonList(paramString));
  }
  
  public void unsubscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, List<String> paramList) {
    for (String str : paramList) {
      StringBuilder stringBuilder = new StringBuilder("Unsubscribing ");
      stringBuilder.append(paramAppLovinCommunicatorSubscriber);
      stringBuilder.append(" from topic: ");
      stringBuilder.append(str);
      a(stringBuilder.toString());
      this.e.b(paramAppLovinCommunicatorSubscriber, str);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\communicator\AppLovinCommunicator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */