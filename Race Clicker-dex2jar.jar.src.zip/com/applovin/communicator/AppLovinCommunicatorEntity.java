package com.applovin.communicator;

public interface AppLovinCommunicatorEntity {
  String getCommunicatorId();
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\communicator\AppLovinCommunicatorEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */