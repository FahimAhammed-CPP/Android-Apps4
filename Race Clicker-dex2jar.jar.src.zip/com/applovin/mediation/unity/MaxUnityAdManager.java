package com.applovin.mediation.unity;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxAdReviewListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxAdWaterfallInfo;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxNetworkResponseInfo;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxAppOpenAd;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.mediation.ads.MaxRewardedAd;
import com.applovin.mediation.ads.MaxRewardedInterstitialAd;
import com.applovin.sdk.AppLovinCFError;
import com.applovin.sdk.AppLovinCFService;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.applovin.sdk.AppLovinSdkSettings;
import com.applovin.sdk.AppLovinSdkUtils;
import com.applovin.sdk.AppLovinUserService;
import com.applovin.sdk.AppLovinVariableService;
import com.safedk.android.internal.special.SpecialsBridge;
import com.unity3d.player.UnityPlayer;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import org.json.JSONArray;
import org.json.JSONObject;

public class MaxUnityAdManager implements MaxAdListener, MaxAdViewAdListener, MaxRewardedAdListener, MaxAdRevenueListener, MaxAdReviewListener, AppLovinVariableService.OnVariablesUpdateListener, AppLovinUserService.OnConsentDialogDismissListener, AppLovinCFService.OnCFCompletionCallback {
  private static final Point DEFAULT_AD_VIEW_OFFSET = new Point(0, 0);
  
  private static final String DEFAULT_AD_VIEW_POSITION = "top_left";
  
  private static final String SDK_TAG = "AppLovinSdk";
  
  private static final String TAG = "MaxUnityAdManager";
  
  private static final String VERSION = "5.11.3";
  
  private static BackgroundCallback backgroundCallback;
  
  private static WeakReference<Activity> currentActivity;
  
  private static MaxUnityAdManager instance;
  
  private static final ScheduledThreadPoolExecutor sThreadPoolExecutor = new ScheduledThreadPoolExecutor(3, new SdkThreadFactory());
  
  private final Map<String, MaxAd> mAdInfoMap;
  
  private final Object mAdInfoMapLock;
  
  private final List<String> mAdUnitIdsToShowAfterCreate;
  
  private final Map<String, MaxAdFormat> mAdViewAdFormats;
  
  private final Map<String, String> mAdViewCustomDataToSetAfterCreate;
  
  private final Map<String, Map<String, String>> mAdViewExtraParametersToSetAfterCreate;
  
  private final Map<String, Map<String, Object>> mAdViewLocalExtraParametersToSetAfterCreate;
  
  private final Map<String, Point> mAdViewOffsets;
  
  private final Map<String, String> mAdViewPositions;
  
  private final Map<String, Integer> mAdViewWidths;
  
  private final Map<String, MaxAdView> mAdViews;
  
  private final Map<String, MaxAppOpenAd> mAppOpenAds;
  
  private final Map<String, Integer> mCrossPromoAdViewHeights;
  
  private final Map<String, Integer> mCrossPromoAdViewRotations;
  
  private final Set<String> mDisabledAdaptiveBannerAdUnitIds;
  
  private final Set<String> mDisabledAutoRefreshAdViewAdUnitIds;
  
  private final Map<String, MaxInterstitialAd> mInterstitials;
  
  private Integer mPublisherBannerBackgroundColor = null;
  
  private final Map<String, MaxRewardedAd> mRewardedAds;
  
  private final Map<String, MaxRewardedInterstitialAd> mRewardedInterstitialAds;
  
  private View mSafeAreaBackground;
  
  private AppLovinSdk sdk;
  
  public MaxUnityAdManager() {
    this(null);
  }
  
  private MaxUnityAdManager(Activity paramActivity) {
    currentActivity = new WeakReference<Activity>(paramActivity);
    this.mInterstitials = new HashMap<String, MaxInterstitialAd>(2);
    this.mAppOpenAds = new HashMap<String, MaxAppOpenAd>(2);
    this.mRewardedAds = new HashMap<String, MaxRewardedAd>(2);
    this.mRewardedInterstitialAds = new HashMap<String, MaxRewardedInterstitialAd>(2);
    this.mAdViews = new HashMap<String, MaxAdView>(2);
    this.mAdViewAdFormats = new HashMap<String, MaxAdFormat>(2);
    this.mAdViewPositions = new HashMap<String, String>(2);
    this.mAdViewOffsets = new HashMap<String, Point>(2);
    this.mAdViewWidths = new HashMap<String, Integer>(2);
    this.mCrossPromoAdViewHeights = new HashMap<String, Integer>(2);
    this.mCrossPromoAdViewRotations = new HashMap<String, Integer>(2);
    this.mAdInfoMap = new HashMap<String, MaxAd>();
    this.mAdInfoMapLock = new Object();
    this.mAdViewExtraParametersToSetAfterCreate = new HashMap<String, Map<String, String>>(1);
    this.mAdViewLocalExtraParametersToSetAfterCreate = new HashMap<String, Map<String, Object>>(1);
    this.mAdViewCustomDataToSetAfterCreate = new HashMap<String, String>(1);
    this.mAdUnitIdsToShowAfterCreate = new ArrayList<String>(2);
    this.mDisabledAdaptiveBannerAdUnitIds = new HashSet<String>(2);
    this.mDisabledAutoRefreshAdViewAdUnitIds = new HashSet<String>(2);
    AppLovinSdkUtils.runOnUiThread(true, new Runnable() {
          public void run() {
            MaxUnityAdManager.access$102(MaxUnityAdManager.this, new View((Context)MaxUnityAdManager.getCurrentActivity()));
            MaxUnityAdManager.this.mSafeAreaBackground.setVisibility(8);
            MaxUnityAdManager.this.mSafeAreaBackground.setBackgroundColor(0);
            MaxUnityAdManager.this.mSafeAreaBackground.setClickable(false);
            FrameLayout frameLayout = new FrameLayout((Context)MaxUnityAdManager.getCurrentActivity());
            frameLayout.addView(MaxUnityAdManager.this.mSafeAreaBackground, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(0, 0));
            MaxUnityAdManager.getCurrentActivity().addContentView((View)frameLayout, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
          }
        });
    getCurrentActivity().getWindow().getDecorView().getRootView().addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
          public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
            if (param1Int1 != param1Int5 || param1Int3 != param1Int7 || param1Int4 != param1Int8 || param1Int2 != param1Int6) {
              param1Int1 = 1;
            } else {
              param1Int1 = 0;
            } 
            if (param1Int1 == 0)
              return; 
            for (Map.Entry entry : MaxUnityAdManager.this.mAdViewAdFormats.entrySet())
              MaxUnityAdManager.this.positionAdView((String)entry.getKey(), (MaxAdFormat)entry.getValue()); 
          }
        });
  }
  
  private void createAdView(final String adUnitId, final MaxAdFormat adFormat, final String adViewPosition, final Point adViewOffsetPixels) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Creating ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\" and position: \"");
            stringBuilder2.append(adViewPosition);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            if (MaxUnityAdManager.this.mAdViews.get(adUnitId) != null) {
              stringBuilder2 = new StringBuilder("Trying to create a ");
              stringBuilder2.append(adFormat.getLabel());
              stringBuilder2.append(" that was already created. This will cause the current ad to be hidden.");
              Log.w("MaxUnityAdManager", stringBuilder2.toString());
            } 
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat, adViewPosition, adViewOffsetPixels);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            MaxUnityAdManager.this.mSafeAreaBackground.setVisibility(8);
            stringBuilder1.setVisibility(8);
            if (stringBuilder1.getParent() == null) {
              Activity activity = MaxUnityAdManager.getCurrentActivity();
              RelativeLayout relativeLayout = new RelativeLayout((Context)activity);
              activity.addContentView((View)relativeLayout, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
              relativeLayout.addView((View)stringBuilder1);
              MaxUnityAdManager.this.mAdViewAdFormats.put(adUnitId, adFormat);
              MaxUnityAdManager.this.positionAdView(adUnitId, adFormat);
            } 
            if (!MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.containsKey("adaptive_banner") && (adFormat == MaxAdFormat.BANNER || adFormat == MaxAdFormat.LEADER))
              stringBuilder1.setExtraParameter("adaptive_banner", "true"); 
            if (MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.containsKey(adUnitId)) {
              Map map = (Map)MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.get(adUnitId);
              if (map != null) {
                for (Map.Entry entry : map.entrySet()) {
                  stringBuilder1.setExtraParameter((String)entry.getKey(), (String)entry.getValue());
                  MaxUnityAdManager.this.maybeHandleExtraParameterChanges(adUnitId, adFormat, (String)entry.getKey(), (String)entry.getValue());
                } 
                MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.remove(adUnitId);
              } 
            } 
            if (MaxUnityAdManager.this.mAdViewLocalExtraParametersToSetAfterCreate.containsKey(adUnitId)) {
              Map map = (Map)MaxUnityAdManager.this.mAdViewLocalExtraParametersToSetAfterCreate.get(adUnitId);
              if (map != null) {
                for (Map.Entry entry : map.entrySet())
                  stringBuilder1.setLocalExtraParameter((String)entry.getKey(), entry.getValue()); 
                MaxUnityAdManager.this.mAdViewLocalExtraParametersToSetAfterCreate.remove(adUnitId);
              } 
            } 
            if (MaxUnityAdManager.this.mAdViewCustomDataToSetAfterCreate.containsKey(adUnitId)) {
              stringBuilder1.setCustomData((String)MaxUnityAdManager.this.mAdViewCustomDataToSetAfterCreate.get(adUnitId));
              MaxUnityAdManager.this.mAdViewCustomDataToSetAfterCreate.remove(adUnitId);
            } 
            stringBuilder1.loadAd();
            if (MaxUnityAdManager.this.mDisabledAutoRefreshAdViewAdUnitIds.contains(adUnitId))
              stringBuilder1.stopAutoRefresh(); 
            if (MaxUnityAdManager.this.mAdUnitIdsToShowAfterCreate.contains(adUnitId)) {
              MaxUnityAdManager.this.showAdView(adUnitId, adFormat);
              MaxUnityAdManager.this.mAdUnitIdsToShowAfterCreate.remove(adUnitId);
            } 
          }
        });
  }
  
  private JSONObject createAdWaterfallInfo(MaxAdWaterfallInfo paramMaxAdWaterfallInfo) {
    JSONObject jSONObject = new JSONObject();
    if (paramMaxAdWaterfallInfo == null)
      return jSONObject; 
    JsonUtils.putString(jSONObject, "name", paramMaxAdWaterfallInfo.getName());
    JsonUtils.putString(jSONObject, "testName", paramMaxAdWaterfallInfo.getTestName());
    JSONArray jSONArray = new JSONArray();
    Iterator<MaxNetworkResponseInfo> iterator = paramMaxAdWaterfallInfo.getNetworkResponses().iterator();
    while (iterator.hasNext())
      jSONArray.put(createNetworkResponseInfo(iterator.next())); 
    JsonUtils.putJsonArray(jSONObject, "networkResponses", jSONArray);
    JsonUtils.putString(jSONObject, "latencyMillis", String.valueOf(paramMaxAdWaterfallInfo.getLatencyMillis()));
    return jSONObject;
  }
  
  private JSONObject createNetworkResponseInfo(MaxNetworkResponseInfo paramMaxNetworkResponseInfo) {
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "adLoadState", Integer.toString(paramMaxNetworkResponseInfo.getAdLoadState().ordinal()));
    if (paramMaxNetworkResponseInfo.getMediatedNetwork() != null) {
      JSONObject jSONObject1 = new JSONObject();
      JsonUtils.putString(jSONObject1, "name", paramMaxNetworkResponseInfo.getMediatedNetwork().getName());
      JsonUtils.putString(jSONObject1, "adapterClassName", paramMaxNetworkResponseInfo.getMediatedNetwork().getAdapterClassName());
      JsonUtils.putString(jSONObject1, "adapterVersion", paramMaxNetworkResponseInfo.getMediatedNetwork().getAdapterVersion());
      JsonUtils.putString(jSONObject1, "sdkVersion", paramMaxNetworkResponseInfo.getMediatedNetwork().getSdkVersion());
      JsonUtils.putJSONObject(jSONObject, "mediatedNetwork", jSONObject1);
    } 
    JsonUtils.putJSONObject(jSONObject, "credentials", BundleUtils.toJSONObject(paramMaxNetworkResponseInfo.getCredentials()));
    JsonUtils.putBoolean(jSONObject, "isBidding", paramMaxNetworkResponseInfo.isBidding());
    MaxError maxError = paramMaxNetworkResponseInfo.getError();
    if (maxError != null) {
      JSONObject jSONObject1 = new JSONObject();
      JsonUtils.putString(jSONObject1, "errorMessage", maxError.getMessage());
      JsonUtils.putString(jSONObject1, "adLoadFailureInfo", maxError.getAdLoadFailureInfo());
      JsonUtils.putString(jSONObject1, "errorCode", Integer.toString(maxError.getCode()));
      JsonUtils.putJSONObject(jSONObject, "error", jSONObject1);
    } 
    JsonUtils.putString(jSONObject, "latencyMillis", String.valueOf(paramMaxNetworkResponseInfo.getLatencyMillis()));
    return jSONObject;
  }
  
  private static void d(String paramString) {
    StringBuilder stringBuilder = new StringBuilder("[MaxUnityAdManager] ");
    stringBuilder.append(paramString);
    Log.d("AppLovinSdk", stringBuilder.toString());
  }
  
  protected static Map<String, String> deserializeParameters(String paramString) {
    if (!TextUtils.isEmpty(paramString))
      try {
        return JsonUtils.toStringMap(JsonUtils.jsonObjectFromJsonString(paramString, new JSONObject()));
      } finally {
        Exception exception = null;
        StringBuilder stringBuilder = new StringBuilder("Failed to deserialize: (");
        stringBuilder.append(paramString);
        stringBuilder.append(") with exception: ");
        stringBuilder.append(exception);
        e(stringBuilder.toString());
      }  
    return Collections.emptyMap();
  }
  
  private void destroyAdView(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Destroying ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            ViewParent viewParent = stringBuilder1.getParent();
            if (viewParent instanceof ViewGroup)
              ((ViewGroup)viewParent).removeView((View)stringBuilder1); 
            stringBuilder1.setListener(null);
            stringBuilder1.setRevenueListener(null);
            stringBuilder1.setAdReviewListener(null);
            SpecialsBridge.maxAdViewDestroy((MaxAdView)stringBuilder1);
            MaxUnityAdManager.this.mAdViews.remove(adUnitId);
            MaxUnityAdManager.this.mAdViewAdFormats.remove(adUnitId);
            MaxUnityAdManager.this.mAdViewPositions.remove(adUnitId);
            MaxUnityAdManager.this.mAdViewOffsets.remove(adUnitId);
            MaxUnityAdManager.this.mAdViewWidths.remove(adUnitId);
            MaxUnityAdManager.this.mCrossPromoAdViewHeights.remove(adUnitId);
            MaxUnityAdManager.this.mCrossPromoAdViewRotations.remove(adUnitId);
            MaxUnityAdManager.this.mDisabledAdaptiveBannerAdUnitIds.remove(adUnitId);
          }
        });
  }
  
  private static void e(String paramString) {
    StringBuilder stringBuilder = new StringBuilder("[MaxUnityAdManager] ");
    stringBuilder.append(paramString);
    Log.e("AppLovinSdk", stringBuilder.toString());
  }
  
  private static void forwardUnityEvent(JSONObject paramJSONObject) {
    forwardUnityEvent(paramJSONObject, false);
  }
  
  private static void forwardUnityEvent(final JSONObject args, final boolean forwardInBackground) {
    sThreadPoolExecutor.execute(new Runnable() {
          public void run() {
            String str = args.toString();
            if (forwardInBackground) {
              MaxUnityAdManager.backgroundCallback.onEvent(str);
              return;
            } 
            UnityPlayer.UnitySendMessage("MaxSdkCallbacks", "ForwardEvent", str);
          }
        });
  }
  
  private MaxAd getAd(String paramString) {
    synchronized (this.mAdInfoMapLock) {
      return this.mAdInfoMap.get(paramString);
    } 
  }
  
  private JSONObject getAdInfo(MaxAd paramMaxAd) {
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "adUnitId", paramMaxAd.getAdUnitId());
    JsonUtils.putString(jSONObject, "adFormat", paramMaxAd.getFormat().getLabel());
    JsonUtils.putString(jSONObject, "networkName", paramMaxAd.getNetworkName());
    JsonUtils.putString(jSONObject, "networkPlacement", paramMaxAd.getNetworkPlacement());
    boolean bool = TextUtils.isEmpty(paramMaxAd.getCreativeId());
    String str2 = "";
    if (!bool) {
      str1 = paramMaxAd.getCreativeId();
    } else {
      str1 = "";
    } 
    JsonUtils.putString(jSONObject, "creativeId", str1);
    if (!TextUtils.isEmpty(paramMaxAd.getPlacement())) {
      str1 = paramMaxAd.getPlacement();
    } else {
      str1 = "";
    } 
    JsonUtils.putString(jSONObject, "placement", str1);
    JsonUtils.putString(jSONObject, "revenue", String.valueOf(paramMaxAd.getRevenue()));
    JsonUtils.putString(jSONObject, "revenuePrecision", paramMaxAd.getRevenuePrecision());
    JsonUtils.putJSONObject(jSONObject, "waterfallInfo", createAdWaterfallInfo(paramMaxAd.getWaterfall()));
    String str1 = str2;
    if (!TextUtils.isEmpty(paramMaxAd.getDspName()))
      str1 = paramMaxAd.getDspName(); 
    JsonUtils.putString(jSONObject, "dspName", str1);
    return jSONObject;
  }
  
  private MaxAdFormat getAdViewAdFormat(String paramString) {
    return this.mAdViewAdFormats.containsKey(paramString) ? this.mAdViewAdFormats.get(paramString) : getDeviceSpecificAdViewAdFormat();
  }
  
  private String getAdViewLayout(String paramString, MaxAdFormat paramMaxAdFormat) {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2 = new StringBuilder("Getting ");
    stringBuilder2.append(paramMaxAdFormat.getLabel());
    stringBuilder2.append(" absolute position with ad unit id \"");
    stringBuilder2.append(paramString);
    stringBuilder2.append("\"");
    d(stringBuilder2.toString());
    MaxAdView maxAdView = retrieveAdView(paramString, paramMaxAdFormat);
    if (maxAdView == null) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramMaxAdFormat.getLabel());
      stringBuilder1.append(" does not exist");
      e(stringBuilder1.toString());
      return "";
    } 
    int[] arrayOfInt = new int[2];
    stringBuilder1.getLocationOnScreen(arrayOfInt);
    int i = AppLovinSdkUtils.pxToDp((Context)getCurrentActivity(), arrayOfInt[0]);
    int j = AppLovinSdkUtils.pxToDp((Context)getCurrentActivity(), arrayOfInt[1]);
    int k = AppLovinSdkUtils.pxToDp((Context)getCurrentActivity(), stringBuilder1.getWidth());
    int m = AppLovinSdkUtils.pxToDp((Context)getCurrentActivity(), stringBuilder1.getHeight());
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "origin_x", String.valueOf(i));
    JsonUtils.putString(jSONObject, "origin_y", String.valueOf(j));
    JsonUtils.putString(jSONObject, "width", String.valueOf(k));
    JsonUtils.putString(jSONObject, "height", String.valueOf(m));
    return jSONObject.toString();
  }
  
  public static float getAdaptiveBannerHeight(float paramFloat) {
    return getDeviceSpecificAdViewAdFormat().getAdaptiveSize((int)paramFloat, (Context)getCurrentActivity()).getHeight();
  }
  
  private static Activity getCurrentActivity() {
    return Utils.getCurrentActivity();
  }
  
  private JSONObject getDefaultAdEventParameters(String paramString, MaxAd paramMaxAd) {
    JSONObject jSONObject = getAdInfo(paramMaxAd);
    JsonUtils.putString(jSONObject, "name", paramString);
    return jSONObject;
  }
  
  private static MaxAdFormat getDeviceSpecificAdViewAdFormat() {
    return AppLovinSdkUtils.isTablet((Context)getCurrentActivity()) ? MaxAdFormat.LEADER : MaxAdFormat.BANNER;
  }
  
  public static MaxUnityAdManager getInstance(Activity paramActivity) {
    if (instance == null) {
      instance = new MaxUnityAdManager(paramActivity);
    } else {
      currentActivity = new WeakReference<Activity>(paramActivity);
    } 
    return instance;
  }
  
  private static Point getOffsetPixels(float paramFloat1, float paramFloat2, Context paramContext) {
    return new Point(AppLovinSdkUtils.dpToPx(paramContext, (int)paramFloat1), AppLovinSdkUtils.dpToPx(paramContext, (int)paramFloat2));
  }
  
  private static Insets getSafeInsets() {
    Insets insets = new Insets();
    if (Build.VERSION.SDK_INT < 28)
      return insets; 
    Window window = getCurrentActivity().getWindow();
    if (window == null)
      return insets; 
    WindowInsets windowInsets = window.getDecorView().getRootWindowInsets();
    if (windowInsets == null)
      return insets; 
    DisplayCutout displayCutout = windowInsets.getDisplayCutout();
    if (displayCutout == null)
      return insets; 
    insets.left = displayCutout.getSafeInsetLeft();
    insets.top = displayCutout.getSafeInsetTop();
    insets.right = displayCutout.getSafeInsetRight();
    insets.bottom = displayCutout.getSafeInsetBottom();
    return insets;
  }
  
  private void hideAdView(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Hiding ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxUnityAdManager.this.mAdUnitIdsToShowAfterCreate.remove(adUnitId);
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            MaxUnityAdManager.this.mSafeAreaBackground.setVisibility(8);
            stringBuilder1.setVisibility(8);
            stringBuilder1.stopAutoRefresh();
          }
        });
  }
  
  private void loadAdView(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder;
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder = new StringBuilder();
              stringBuilder.append(adFormat.getLabel());
              stringBuilder.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder.toString());
              return;
            } 
            if (!MaxUnityAdManager.this.mDisabledAutoRefreshAdViewAdUnitIds.contains(adUnitId)) {
              if (stringBuilder.getVisibility() != 0) {
                stringBuilder = new StringBuilder("Auto-refresh will resume when the ");
                stringBuilder.append(adFormat.getLabel());
                stringBuilder.append(" ad is shown. You should only call LoadBanner() or LoadMRec() if you explicitly pause auto-refresh and want to manually load an ad.");
                MaxUnityAdManager.e(stringBuilder.toString());
                return;
              } 
              stringBuilder = new StringBuilder("You must stop auto-refresh if you want to manually load ");
              stringBuilder.append(adFormat.getLabel());
              stringBuilder.append(" ads.");
              MaxUnityAdManager.e(stringBuilder.toString());
              return;
            } 
            stringBuilder.loadAd();
          }
        });
  }
  
  private void logInvalidAdFormat(MaxAdFormat paramMaxAdFormat) {
    StringBuilder stringBuilder = new StringBuilder("invalid ad format: ");
    stringBuilder.append(paramMaxAdFormat);
    logStackTrace(new IllegalStateException(stringBuilder.toString()));
  }
  
  private void logStackTrace(Exception paramException) {
    e(Log.getStackTraceString(paramException));
  }
  
  private void maybeHandleExtraParameterChanges(String paramString1, MaxAdFormat paramMaxAdFormat, String paramString2, String paramString3) {
    if (MaxAdFormat.MREC != paramMaxAdFormat) {
      if ("force_banner".equalsIgnoreCase(paramString2)) {
        if (Boolean.parseBoolean(paramString3)) {
          paramMaxAdFormat = MaxAdFormat.BANNER;
        } else {
          paramMaxAdFormat = getDeviceSpecificAdViewAdFormat();
        } 
        this.mAdViewAdFormats.put(paramString1, paramMaxAdFormat);
        positionAdView(paramString1, paramMaxAdFormat);
        return;
      } 
      if ("adaptive_banner".equalsIgnoreCase(paramString2)) {
        if (Boolean.parseBoolean(paramString3)) {
          this.mDisabledAdaptiveBannerAdUnitIds.remove(paramString1);
        } else {
          this.mDisabledAdaptiveBannerAdUnitIds.add(paramString1);
        } 
        positionAdView(paramString1, paramMaxAdFormat);
      } 
    } 
  }
  
  private void positionAdView(MaxAd paramMaxAd) {
    positionAdView(paramMaxAd.getAdUnitId(), paramMaxAd.getFormat());
  }
  
  private void positionAdView(final String adUnitId, final MaxAdFormat adFormat) {
    getCurrentActivity().runOnUiThread(new Runnable() {
          public void run() {
            // Byte code:
            //   0: aload_0
            //   1: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   4: aload_0
            //   5: getfield val$adUnitId : Ljava/lang/String;
            //   8: aload_0
            //   9: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   12: invokestatic access$1800 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;Ljava/lang/String;Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/ads/MaxAdView;
            //   15: astore #17
            //   17: aload #17
            //   19: ifnonnull -> 61
            //   22: new java/lang/StringBuilder
            //   25: dup
            //   26: invokespecial <init> : ()V
            //   29: astore #16
            //   31: aload #16
            //   33: aload_0
            //   34: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   37: invokevirtual getLabel : ()Ljava/lang/String;
            //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   43: pop
            //   44: aload #16
            //   46: ldc ' does not exist'
            //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   51: pop
            //   52: aload #16
            //   54: invokevirtual toString : ()Ljava/lang/String;
            //   57: invokestatic access$1000 : (Ljava/lang/String;)V
            //   60: return
            //   61: aload #17
            //   63: invokevirtual getParent : ()Landroid/view/ViewParent;
            //   66: checkcast android/widget/RelativeLayout
            //   69: astore #16
            //   71: aload #16
            //   73: ifnonnull -> 115
            //   76: new java/lang/StringBuilder
            //   79: dup
            //   80: invokespecial <init> : ()V
            //   83: astore #16
            //   85: aload #16
            //   87: aload_0
            //   88: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   91: invokevirtual getLabel : ()Ljava/lang/String;
            //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   97: pop
            //   98: aload #16
            //   100: ldc ''s parent does not exist'
            //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   105: pop
            //   106: aload #16
            //   108: invokevirtual toString : ()Ljava/lang/String;
            //   111: invokestatic access$1000 : (Ljava/lang/String;)V
            //   114: return
            //   115: new android/graphics/Rect
            //   118: dup
            //   119: invokespecial <init> : ()V
            //   122: astore #21
            //   124: aload #16
            //   126: aload #21
            //   128: invokevirtual getWindowVisibleDisplayFrame : (Landroid/graphics/Rect;)V
            //   131: aload_0
            //   132: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   135: invokestatic access$2000 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   138: aload_0
            //   139: getfield val$adUnitId : Ljava/lang/String;
            //   142: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
            //   147: checkcast java/lang/String
            //   150: astore #18
            //   152: aload_0
            //   153: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   156: invokestatic access$2100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   159: aload_0
            //   160: getfield val$adUnitId : Ljava/lang/String;
            //   163: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
            //   168: checkcast android/graphics/Point
            //   171: astore #22
            //   173: invokestatic access$2600 : ()Lcom/applovin/mediation/unity/MaxUnityAdManager$Insets;
            //   176: astore #19
            //   178: aload_0
            //   179: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   182: invokestatic access$2400 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Set;
            //   185: aload_0
            //   186: getfield val$adUnitId : Ljava/lang/String;
            //   189: invokeinterface contains : (Ljava/lang/Object;)Z
            //   194: istore #13
            //   196: aload_0
            //   197: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   200: invokestatic access$1900 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   203: aload_0
            //   204: getfield val$adUnitId : Ljava/lang/String;
            //   207: invokeinterface containsKey : (Ljava/lang/Object;)Z
            //   212: istore #14
            //   214: aload_0
            //   215: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   218: invokestatic access$2200 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   221: aload_0
            //   222: getfield val$adUnitId : Ljava/lang/String;
            //   225: invokeinterface containsKey : (Ljava/lang/Object;)Z
            //   230: istore #15
            //   232: aload_0
            //   233: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   236: invokestatic access$2300 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   239: aload_0
            //   240: getfield val$adUnitId : Ljava/lang/String;
            //   243: invokeinterface containsKey : (Ljava/lang/Object;)Z
            //   248: istore #12
            //   250: iload #14
            //   252: ifeq -> 281
            //   255: aload_0
            //   256: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   259: invokestatic access$1900 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   262: aload_0
            //   263: getfield val$adUnitId : Ljava/lang/String;
            //   266: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
            //   271: checkcast java/lang/Integer
            //   274: invokevirtual intValue : ()I
            //   277: istore_1
            //   278: goto -> 332
            //   281: ldc 'top_center'
            //   283: aload #18
            //   285: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
            //   288: ifne -> 318
            //   291: ldc 'bottom_center'
            //   293: aload #18
            //   295: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
            //   298: ifeq -> 304
            //   301: goto -> 318
            //   304: aload_0
            //   305: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   308: invokevirtual getSize : ()Lcom/applovin/sdk/AppLovinSdkUtils$Size;
            //   311: invokevirtual getWidth : ()I
            //   314: istore_1
            //   315: goto -> 332
            //   318: aload #21
            //   320: invokevirtual width : ()I
            //   323: istore_1
            //   324: invokestatic access$200 : ()Landroid/app/Activity;
            //   327: iload_1
            //   328: invokestatic pxToDp : (Landroid/content/Context;I)I
            //   331: istore_1
            //   332: iload #15
            //   334: ifeq -> 363
            //   337: aload_0
            //   338: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   341: invokestatic access$2200 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   344: aload_0
            //   345: getfield val$adUnitId : Ljava/lang/String;
            //   348: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
            //   353: checkcast java/lang/Integer
            //   356: invokevirtual intValue : ()I
            //   359: istore_2
            //   360: goto -> 417
            //   363: aload_0
            //   364: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   367: getstatic com/applovin/mediation/MaxAdFormat.BANNER : Lcom/applovin/mediation/MaxAdFormat;
            //   370: if_acmpeq -> 383
            //   373: aload_0
            //   374: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   377: getstatic com/applovin/mediation/MaxAdFormat.LEADER : Lcom/applovin/mediation/MaxAdFormat;
            //   380: if_acmpne -> 406
            //   383: iload #13
            //   385: ifne -> 406
            //   388: aload_0
            //   389: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   392: iload_1
            //   393: invokestatic access$200 : ()Landroid/app/Activity;
            //   396: invokevirtual getAdaptiveSize : (ILandroid/content/Context;)Lcom/applovin/sdk/AppLovinSdkUtils$Size;
            //   399: invokevirtual getHeight : ()I
            //   402: istore_2
            //   403: goto -> 417
            //   406: aload_0
            //   407: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   410: invokevirtual getSize : ()Lcom/applovin/sdk/AppLovinSdkUtils$Size;
            //   413: invokevirtual getHeight : ()I
            //   416: istore_2
            //   417: invokestatic access$200 : ()Landroid/app/Activity;
            //   420: iload_1
            //   421: invokestatic dpToPx : (Landroid/content/Context;I)I
            //   424: istore #4
            //   426: invokestatic access$200 : ()Landroid/app/Activity;
            //   429: iload_2
            //   430: invokestatic dpToPx : (Landroid/content/Context;I)I
            //   433: istore #5
            //   435: aload #17
            //   437: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
            //   440: checkcast android/widget/RelativeLayout$LayoutParams
            //   443: astore #20
            //   445: aload #20
            //   447: iload #5
            //   449: putfield height : I
            //   452: aload #17
            //   454: aload #20
            //   456: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
            //   459: aload #17
            //   461: fconst_0
            //   462: invokevirtual setRotation : (F)V
            //   465: aload #17
            //   467: fconst_0
            //   468: invokevirtual setTranslationX : (F)V
            //   471: aload #20
            //   473: iconst_0
            //   474: iconst_0
            //   475: iconst_0
            //   476: iconst_0
            //   477: invokevirtual setMargins : (IIII)V
            //   480: aload #19
            //   482: getfield left : I
            //   485: aload #22
            //   487: getfield x : I
            //   490: iadd
            //   491: istore_3
            //   492: aload #19
            //   494: getfield top : I
            //   497: istore #6
            //   499: aload #22
            //   501: getfield y : I
            //   504: istore #7
            //   506: aload #19
            //   508: getfield right : I
            //   511: istore_2
            //   512: aload #19
            //   514: getfield bottom : I
            //   517: istore #8
            //   519: ldc 'centered'
            //   521: aload #18
            //   523: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
            //   526: ifeq -> 569
            //   529: getstatic com/applovin/mediation/MaxAdFormat.MREC : Lcom/applovin/mediation/MaxAdFormat;
            //   532: aload_0
            //   533: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   536: if_acmpeq -> 556
            //   539: iload #14
            //   541: ifeq -> 547
            //   544: goto -> 556
            //   547: aload #20
            //   549: iconst_m1
            //   550: putfield width : I
            //   553: goto -> 563
            //   556: aload #20
            //   558: iload #4
            //   560: putfield width : I
            //   563: bipush #17
            //   565: istore_1
            //   566: goto -> 903
            //   569: aload #18
            //   571: ldc 'top'
            //   573: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   576: ifeq -> 585
            //   579: bipush #48
            //   581: istore_1
            //   582: goto -> 603
            //   585: aload #18
            //   587: ldc 'bottom'
            //   589: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   592: ifeq -> 601
            //   595: bipush #80
            //   597: istore_1
            //   598: goto -> 603
            //   601: iconst_0
            //   602: istore_1
            //   603: aload #18
            //   605: ldc 'center'
            //   607: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   610: ifeq -> 862
            //   613: iload_1
            //   614: iconst_1
            //   615: ior
            //   616: istore_1
            //   617: getstatic com/applovin/mediation/MaxAdFormat.MREC : Lcom/applovin/mediation/MaxAdFormat;
            //   620: aload_0
            //   621: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   624: if_acmpeq -> 644
            //   627: iload #14
            //   629: ifeq -> 635
            //   632: goto -> 644
            //   635: aload #20
            //   637: iconst_m1
            //   638: putfield width : I
            //   641: goto -> 651
            //   644: aload #20
            //   646: iload #4
            //   648: putfield width : I
            //   651: aload #18
            //   653: ldc 'left'
            //   655: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   658: istore #13
            //   660: aload #18
            //   662: ldc 'right'
            //   664: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   667: istore #14
            //   669: iload #13
            //   671: ifne -> 685
            //   674: iload #14
            //   676: ifeq -> 682
            //   679: goto -> 685
            //   682: goto -> 903
            //   685: iload_1
            //   686: bipush #16
            //   688: ior
            //   689: istore #4
            //   691: getstatic com/applovin/mediation/MaxAdFormat.MREC : Lcom/applovin/mediation/MaxAdFormat;
            //   694: aload_0
            //   695: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   698: if_acmpne -> 726
            //   701: aload #18
            //   703: ldc 'left'
            //   705: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   708: ifeq -> 716
            //   711: iconst_3
            //   712: istore_1
            //   713: goto -> 718
            //   716: iconst_5
            //   717: istore_1
            //   718: iload #4
            //   720: iload_1
            //   721: ior
            //   722: istore_1
            //   723: goto -> 853
            //   726: aload #21
            //   728: invokevirtual width : ()I
            //   731: aload #19
            //   733: getfield left : I
            //   736: isub
            //   737: aload #19
            //   739: getfield right : I
            //   742: isub
            //   743: istore #9
            //   745: aload #21
            //   747: invokevirtual height : ()I
            //   750: aload #19
            //   752: getfield top : I
            //   755: isub
            //   756: aload #19
            //   758: getfield bottom : I
            //   761: isub
            //   762: istore_1
            //   763: iload #9
            //   765: iload_1
            //   766: invokestatic max : (II)I
            //   769: istore #10
            //   771: iload #9
            //   773: iload_1
            //   774: invokestatic min : (II)I
            //   777: istore #11
            //   779: iload_1
            //   780: iload #9
            //   782: if_icmple -> 790
            //   785: iconst_m1
            //   786: istore_1
            //   787: goto -> 792
            //   790: iconst_1
            //   791: istore_1
            //   792: iload_1
            //   793: iload #10
            //   795: iload #11
            //   797: isub
            //   798: imul
            //   799: iconst_2
            //   800: idiv
            //   801: istore_1
            //   802: iload_3
            //   803: iload_1
            //   804: iadd
            //   805: istore_3
            //   806: iload_2
            //   807: iload_1
            //   808: iadd
            //   809: istore_2
            //   810: iload #9
            //   812: iconst_2
            //   813: idiv
            //   814: iload #5
            //   816: iconst_2
            //   817: idiv
            //   818: isub
            //   819: istore #5
            //   821: iload #5
            //   823: istore_1
            //   824: iload #13
            //   826: ifeq -> 833
            //   829: iload #5
            //   831: ineg
            //   832: istore_1
            //   833: aload #17
            //   835: iload_1
            //   836: i2f
            //   837: invokevirtual setTranslationX : (F)V
            //   840: aload #17
            //   842: ldc 90.0
            //   844: invokevirtual setRotation : (F)V
            //   847: iload #4
            //   849: istore_1
            //   850: goto -> 723
            //   853: aload #16
            //   855: iconst_0
            //   856: invokevirtual setBackgroundColor : (I)V
            //   859: goto -> 903
            //   862: aload #20
            //   864: iload #4
            //   866: putfield width : I
            //   869: aload #18
            //   871: ldc 'left'
            //   873: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   876: ifeq -> 886
            //   879: iload_1
            //   880: iconst_3
            //   881: ior
            //   882: istore_1
            //   883: goto -> 903
            //   886: aload #18
            //   888: ldc 'right'
            //   890: invokevirtual contains : (Ljava/lang/CharSequence;)Z
            //   893: ifeq -> 903
            //   896: iload_1
            //   897: iconst_5
            //   898: ior
            //   899: istore_1
            //   900: goto -> 903
            //   903: iload #12
            //   905: ifeq -> 942
            //   908: aload #17
            //   910: aload_0
            //   911: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   914: invokestatic access$2300 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/util/Map;
            //   917: aload_0
            //   918: getfield val$adUnitId : Ljava/lang/String;
            //   921: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
            //   926: checkcast java/lang/Integer
            //   929: invokevirtual intValue : ()I
            //   932: i2f
            //   933: invokevirtual setRotation : (F)V
            //   936: aload #16
            //   938: iconst_0
            //   939: invokevirtual setBackgroundColor : (I)V
            //   942: getstatic com/applovin/mediation/MaxAdFormat.BANNER : Lcom/applovin/mediation/MaxAdFormat;
            //   945: aload_0
            //   946: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   949: if_acmpeq -> 968
            //   952: iload_2
            //   953: istore #4
            //   955: iload_3
            //   956: istore #5
            //   958: getstatic com/applovin/mediation/MaxAdFormat.LEADER : Lcom/applovin/mediation/MaxAdFormat;
            //   961: aload_0
            //   962: getfield val$adFormat : Lcom/applovin/mediation/MaxAdFormat;
            //   965: if_acmpne -> 1180
            //   968: aload_0
            //   969: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   972: invokestatic access$2500 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Ljava/lang/Integer;
            //   975: ifnull -> 1162
            //   978: aload_0
            //   979: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   982: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   985: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
            //   988: checkcast android/widget/FrameLayout$LayoutParams
            //   991: astore #21
            //   993: ldc 'top_center'
            //   995: aload #18
            //   997: invokevirtual equals : (Ljava/lang/Object;)Z
            //   1000: ifeq -> 1057
            //   1003: aload #21
            //   1005: aload #19
            //   1007: getfield top : I
            //   1010: putfield height : I
            //   1013: aload #21
            //   1015: iconst_m1
            //   1016: putfield width : I
            //   1019: aload_0
            //   1020: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   1023: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   1026: aload #17
            //   1028: invokevirtual getVisibility : ()I
            //   1031: invokevirtual setVisibility : (I)V
            //   1034: iload_3
            //   1035: aload #19
            //   1037: getfield left : I
            //   1040: isub
            //   1041: istore_3
            //   1042: iload_2
            //   1043: aload #19
            //   1045: getfield right : I
            //   1048: isub
            //   1049: istore_2
            //   1050: bipush #49
            //   1052: istore #4
            //   1054: goto -> 1136
            //   1057: ldc 'bottom_center'
            //   1059: aload #18
            //   1061: invokevirtual equals : (Ljava/lang/Object;)Z
            //   1064: ifeq -> 1121
            //   1067: aload #21
            //   1069: aload #19
            //   1071: getfield bottom : I
            //   1074: putfield height : I
            //   1077: aload #21
            //   1079: iconst_m1
            //   1080: putfield width : I
            //   1083: aload_0
            //   1084: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   1087: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   1090: aload #17
            //   1092: invokevirtual getVisibility : ()I
            //   1095: invokevirtual setVisibility : (I)V
            //   1098: iload_3
            //   1099: aload #19
            //   1101: getfield left : I
            //   1104: isub
            //   1105: istore_3
            //   1106: iload_2
            //   1107: aload #19
            //   1109: getfield right : I
            //   1112: isub
            //   1113: istore_2
            //   1114: bipush #81
            //   1116: istore #4
            //   1118: goto -> 1136
            //   1121: aload_0
            //   1122: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   1125: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   1128: bipush #8
            //   1130: invokevirtual setVisibility : (I)V
            //   1133: iconst_1
            //   1134: istore #4
            //   1136: aload #21
            //   1138: iload #4
            //   1140: putfield gravity : I
            //   1143: aload_0
            //   1144: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   1147: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   1150: invokevirtual requestLayout : ()V
            //   1153: iload_2
            //   1154: istore #4
            //   1156: iload_3
            //   1157: istore #5
            //   1159: goto -> 1180
            //   1162: aload_0
            //   1163: getfield this$0 : Lcom/applovin/mediation/unity/MaxUnityAdManager;
            //   1166: invokestatic access$100 : (Lcom/applovin/mediation/unity/MaxUnityAdManager;)Landroid/view/View;
            //   1169: bipush #8
            //   1171: invokevirtual setVisibility : (I)V
            //   1174: iload_3
            //   1175: istore #5
            //   1177: iload_2
            //   1178: istore #4
            //   1180: aload #20
            //   1182: iload #5
            //   1184: iload #6
            //   1186: iload #7
            //   1188: iadd
            //   1189: iload #4
            //   1191: iload #8
            //   1193: invokevirtual setMargins : (IIII)V
            //   1196: aload #16
            //   1198: iload_1
            //   1199: invokevirtual setGravity : (I)V
            //   1202: return
          }
        });
  }
  
  private MaxAdView retrieveAdView(String paramString, MaxAdFormat paramMaxAdFormat) {
    return retrieveAdView(paramString, paramMaxAdFormat, null, null);
  }
  
  private MaxAdView retrieveAdView(String paramString1, MaxAdFormat paramMaxAdFormat, String paramString2, Point paramPoint) {
    MaxAdView maxAdView2 = this.mAdViews.get(paramString1);
    MaxAdView maxAdView1 = maxAdView2;
    if (maxAdView2 == null) {
      maxAdView1 = maxAdView2;
      if (paramString2 != null) {
        maxAdView1 = maxAdView2;
        if (paramPoint != null) {
          maxAdView1 = new MaxAdView(paramString1, paramMaxAdFormat, this.sdk, (Context)getCurrentActivity());
          maxAdView1.setListener(this);
          maxAdView1.setRevenueListener(this);
          maxAdView1.setAdReviewListener(this);
          this.mAdViews.put(paramString1, maxAdView1);
          this.mAdViewPositions.put(paramString1, paramString2);
          this.mAdViewOffsets.put(paramString1, paramPoint);
          maxAdView1.setExtraParameter("allow_pause_auto_refresh_immediately", "true");
        } 
      } 
    } 
    return maxAdView1;
  }
  
  private MaxAppOpenAd retrieveAppOpenAd(String paramString) {
    MaxAppOpenAd maxAppOpenAd2 = this.mAppOpenAds.get(paramString);
    MaxAppOpenAd maxAppOpenAd1 = maxAppOpenAd2;
    if (maxAppOpenAd2 == null) {
      maxAppOpenAd1 = new MaxAppOpenAd(paramString, this.sdk);
      maxAppOpenAd1.setListener(this);
      maxAppOpenAd1.setRevenueListener(this);
      this.mAppOpenAds.put(paramString, maxAppOpenAd1);
    } 
    return maxAppOpenAd1;
  }
  
  private MaxInterstitialAd retrieveInterstitial(String paramString) {
    MaxInterstitialAd maxInterstitialAd2 = this.mInterstitials.get(paramString);
    MaxInterstitialAd maxInterstitialAd1 = maxInterstitialAd2;
    if (maxInterstitialAd2 == null) {
      maxInterstitialAd1 = new MaxInterstitialAd(paramString, this.sdk, getCurrentActivity());
      maxInterstitialAd1.setListener(this);
      maxInterstitialAd1.setRevenueListener(this);
      maxInterstitialAd1.setAdReviewListener(this);
      this.mInterstitials.put(paramString, maxInterstitialAd1);
    } 
    return maxInterstitialAd1;
  }
  
  private MaxRewardedAd retrieveRewardedAd(String paramString) {
    MaxRewardedAd maxRewardedAd2 = this.mRewardedAds.get(paramString);
    MaxRewardedAd maxRewardedAd1 = maxRewardedAd2;
    if (maxRewardedAd2 == null) {
      maxRewardedAd1 = MaxRewardedAd.getInstance(paramString, this.sdk, getCurrentActivity());
      maxRewardedAd1.setListener(this);
      maxRewardedAd1.setRevenueListener(this);
      maxRewardedAd1.setAdReviewListener(this);
      this.mRewardedAds.put(paramString, maxRewardedAd1);
    } 
    return maxRewardedAd1;
  }
  
  private MaxRewardedInterstitialAd retrieveRewardedInterstitialAd(String paramString) {
    MaxRewardedInterstitialAd maxRewardedInterstitialAd2 = this.mRewardedInterstitialAds.get(paramString);
    MaxRewardedInterstitialAd maxRewardedInterstitialAd1 = maxRewardedInterstitialAd2;
    if (maxRewardedInterstitialAd2 == null) {
      maxRewardedInterstitialAd1 = new MaxRewardedInterstitialAd(paramString, this.sdk, getCurrentActivity());
      maxRewardedInterstitialAd1.setListener(this);
      maxRewardedInterstitialAd1.setRevenueListener(this);
      maxRewardedInterstitialAd1.setAdReviewListener(this);
      this.mRewardedInterstitialAds.put(paramString, maxRewardedInterstitialAd1);
    } 
    return maxRewardedInterstitialAd1;
  }
  
  private void setAdViewBackgroundColor(final String adUnitId, final MaxAdFormat adFormat, final String hexColorCode) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Setting ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\" to color: ");
            stringBuilder2.append(hexColorCode);
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            int i = Color.parseColor(hexColorCode);
            MaxUnityAdManager.access$2502(MaxUnityAdManager.this, Integer.valueOf(i));
            MaxUnityAdManager.this.mSafeAreaBackground.setBackgroundColor(i);
            stringBuilder1.setBackgroundColor(i);
          }
        });
  }
  
  private void setAdViewCustomData(final String adUnitId, final MaxAdFormat adFormat, final String customData) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView != null) {
              maxAdView.setCustomData(customData);
              return;
            } 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(adFormat.getLabel());
            stringBuilder.append(" does not exist for ad unit ID ");
            stringBuilder.append(adUnitId);
            stringBuilder.append(". Saving custom data to be set when it is created.");
            MaxUnityAdManager.d(stringBuilder.toString());
            MaxUnityAdManager.this.mAdViewCustomDataToSetAfterCreate.put(adUnitId, customData);
          }
        });
  }
  
  private void setAdViewExtraParameter(final String adUnitId, final MaxAdFormat adFormat, final String key, final String value) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder = new StringBuilder("Setting ");
            stringBuilder.append(adFormat.getLabel());
            stringBuilder.append(" extra with key: \"");
            stringBuilder.append(key);
            stringBuilder.append("\" value: ");
            stringBuilder.append(value);
            MaxUnityAdManager.d(stringBuilder.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView != null) {
              maxAdView.setExtraParameter(key, value);
            } else {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist for ad unit ID ");
              stringBuilder1.append(adUnitId);
              stringBuilder1.append(". Saving extra parameter to be set when it is created.");
              MaxUnityAdManager.d(stringBuilder1.toString());
              Map<Object, Object> map2 = (Map)MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.get(adUnitId);
              Map<Object, Object> map1 = map2;
              if (map2 == null) {
                map1 = new HashMap<Object, Object>(1);
                MaxUnityAdManager.this.mAdViewExtraParametersToSetAfterCreate.put(adUnitId, map1);
              } 
              map1.put(key, value);
            } 
            MaxUnityAdManager.this.maybeHandleExtraParameterChanges(adUnitId, adFormat, key, value);
          }
        });
  }
  
  private void setAdViewLocalExtraParameter(final String adUnitId, final MaxAdFormat adFormat, final String key, final Object value) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder2 = new StringBuilder("Setting ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" local extra with key: \"");
            stringBuilder2.append(key);
            stringBuilder2.append("\" value: ");
            stringBuilder2.append(value);
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView != null) {
              maxAdView.setLocalExtraParameter(key, value);
              return;
            } 
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(adFormat.getLabel());
            stringBuilder1.append(" does not exist for ad unit ID ");
            stringBuilder1.append(adUnitId);
            stringBuilder1.append(". Saving local extra parameter to be set when it is created.");
            MaxUnityAdManager.d(stringBuilder1.toString());
            Map<Object, Object> map2 = (Map)MaxUnityAdManager.this.mAdViewLocalExtraParametersToSetAfterCreate.get(adUnitId);
            Map<Object, Object> map1 = map2;
            if (map2 == null) {
              map1 = new HashMap<Object, Object>(1);
              MaxUnityAdManager.this.mAdViewLocalExtraParametersToSetAfterCreate.put(adUnitId, map1);
            } 
            map1.put(key, value);
          }
        });
  }
  
  private void setAdViewPlacement(final String adUnitId, final MaxAdFormat adFormat, final String placement) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Setting placement \"");
            stringBuilder2.append(placement);
            stringBuilder2.append("\" for ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            stringBuilder1.setPlacement(placement);
          }
        });
  }
  
  private void setAdViewWidth(final String adUnitId, final int widthDp, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder = new StringBuilder("Setting width ");
            stringBuilder.append(widthDp);
            stringBuilder.append(" for \"");
            stringBuilder.append(adFormat);
            stringBuilder.append("\" with ad unit identifier \"");
            stringBuilder.append(adUnitId);
            stringBuilder.append("\"");
            MaxUnityAdManager.d(stringBuilder.toString());
            int i = adFormat.getSize().getWidth();
            if (widthDp < i) {
              stringBuilder = new StringBuilder("The provided width: ");
              stringBuilder.append(widthDp);
              stringBuilder.append("dp is smaller than the minimum required width: ");
              stringBuilder.append(i);
              stringBuilder.append("dp for ad format: ");
              stringBuilder.append(adFormat);
              stringBuilder.append(". Please set the width higher than the minimum required.");
              MaxUnityAdManager.e(stringBuilder.toString());
            } 
            MaxUnityAdManager.this.mAdViewWidths.put(adUnitId, Integer.valueOf(widthDp));
            MaxUnityAdManager.this.positionAdView(adUnitId, adFormat);
          }
        });
  }
  
  private void showAdView(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Showing ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" with ad unit id \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist for ad unit id ");
              stringBuilder1.append(adUnitId);
              MaxUnityAdManager.e(stringBuilder1.toString());
              MaxUnityAdManager.this.mAdUnitIdsToShowAfterCreate.add(adUnitId);
              return;
            } 
            MaxUnityAdManager.this.mSafeAreaBackground.setVisibility(0);
            stringBuilder1.setVisibility(0);
            if (!MaxUnityAdManager.this.mDisabledAutoRefreshAdViewAdUnitIds.contains(adUnitId))
              stringBuilder1.startAutoRefresh(); 
          }
        });
  }
  
  private void startAdViewAutoRefresh(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Starting ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" auto refresh for ad unit identifier \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxUnityAdManager.this.mDisabledAutoRefreshAdViewAdUnitIds.remove(adUnitId);
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist for ad unit identifier \"");
              stringBuilder1.append(adUnitId);
              stringBuilder1.append("\"");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            stringBuilder1.startAutoRefresh();
          }
        });
  }
  
  private void stopAdViewAutoRefresh(final String adUnitId, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder1;
            StringBuilder stringBuilder2 = new StringBuilder("Stopping ");
            stringBuilder2.append(adFormat.getLabel());
            stringBuilder2.append(" auto refresh for ad unit identifier \"");
            stringBuilder2.append(adUnitId);
            stringBuilder2.append("\"");
            MaxUnityAdManager.d(stringBuilder2.toString());
            MaxUnityAdManager.this.mDisabledAutoRefreshAdViewAdUnitIds.add(adUnitId);
            MaxAdView maxAdView = MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat);
            if (maxAdView == null) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append(adFormat.getLabel());
              stringBuilder1.append(" does not exist for ad unit identifier \"");
              stringBuilder1.append(adUnitId);
              stringBuilder1.append("\"");
              MaxUnityAdManager.e(stringBuilder1.toString());
              return;
            } 
            stringBuilder1.stopAutoRefresh();
          }
        });
  }
  
  private void updateAdViewPosition(final String adUnitId, final String adViewPosition, final Point offsetPixels, final MaxAdFormat adFormat) {
    Utils.runSafelyOnUiThread(getCurrentActivity(), new Runnable() {
          public void run() {
            StringBuilder stringBuilder = new StringBuilder("Updating ");
            stringBuilder.append(adFormat.getLabel());
            stringBuilder.append(" position to \"");
            stringBuilder.append(adViewPosition);
            stringBuilder.append("\" for ad unit id \"");
            stringBuilder.append(adUnitId);
            stringBuilder.append("\"");
            MaxUnityAdManager.d(stringBuilder.toString());
            if (MaxUnityAdManager.this.retrieveAdView(adUnitId, adFormat) == null) {
              stringBuilder = new StringBuilder();
              stringBuilder.append(adFormat.getLabel());
              stringBuilder.append(" does not exist");
              MaxUnityAdManager.e(stringBuilder.toString());
              return;
            } 
            MaxUnityAdManager.this.mAdViewPositions.put(adUnitId, adViewPosition);
            MaxUnityAdManager.this.mAdViewOffsets.put(adUnitId, offsetPixels);
            MaxUnityAdManager.this.positionAdView(adUnitId, adFormat);
          }
        });
  }
  
  public void createBanner(String paramString, float paramFloat1, float paramFloat2) {
    createAdView(paramString, getAdViewAdFormat(paramString), "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()));
  }
  
  public void createBanner(String paramString1, String paramString2) {
    createAdView(paramString1, getAdViewAdFormat(paramString1), paramString2, DEFAULT_AD_VIEW_OFFSET);
  }
  
  public void createCrossPromoAd(String paramString, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, int paramInt3) {
    this.mAdViewWidths.put(paramString, Integer.valueOf(paramInt1));
    this.mCrossPromoAdViewHeights.put(paramString, Integer.valueOf(paramInt2));
    this.mCrossPromoAdViewRotations.put(paramString, Integer.valueOf(paramInt3));
    createAdView(paramString, MaxAdFormat.CROSS_PROMO, "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()));
  }
  
  public void createMRec(String paramString, float paramFloat1, float paramFloat2) {
    createAdView(paramString, MaxAdFormat.MREC, "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()));
  }
  
  public void createMRec(String paramString1, String paramString2) {
    createAdView(paramString1, MaxAdFormat.MREC, paramString2, DEFAULT_AD_VIEW_OFFSET);
  }
  
  public void destroyBanner(String paramString) {
    destroyAdView(paramString, getAdViewAdFormat(paramString));
  }
  
  public void destroyCrossPromoAd(String paramString) {
    destroyAdView(paramString, MaxAdFormat.CROSS_PROMO);
  }
  
  public void destroyMRec(String paramString) {
    destroyAdView(paramString, MaxAdFormat.MREC);
  }
  
  public String getAdInfo(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return ""; 
    MaxAd maxAd = getAd(paramString);
    return (maxAd == null) ? "" : getAdInfo(maxAd).toString();
  }
  
  public String getAdValue(String paramString1, String paramString2) {
    if (TextUtils.isEmpty(paramString1))
      return ""; 
    MaxAd maxAd = getAd(paramString1);
    return (maxAd == null) ? "" : maxAd.getAdValue(paramString2);
  }
  
  public String getBannerLayout(String paramString) {
    return getAdViewLayout(paramString, getAdViewAdFormat(paramString));
  }
  
  public String getCrossPromoAdLayout(String paramString) {
    return getAdViewLayout(paramString, MaxAdFormat.CROSS_PROMO);
  }
  
  public String getMRecLayout(String paramString) {
    return getAdViewLayout(paramString, MaxAdFormat.MREC);
  }
  
  public void hideBanner(String paramString) {
    hideAdView(paramString, getAdViewAdFormat(paramString));
  }
  
  public void hideCrossPromoAd(String paramString) {
    hideAdView(paramString, MaxAdFormat.CROSS_PROMO);
  }
  
  public void hideMRec(String paramString) {
    hideAdView(paramString, MaxAdFormat.MREC);
  }
  
  public AppLovinSdk initializeSdkWithCompletionHandler(String paramString, AppLovinSdkSettings paramAppLovinSdkSettings, BackgroundCallback paramBackgroundCallback, final Listener listener) {
    backgroundCallback = paramBackgroundCallback;
    Activity activity = getCurrentActivity();
    if (StringUtils.isValidString(paramString)) {
      this.sdk = AppLovinSdk.getInstance(paramString, paramAppLovinSdkSettings, (Context)activity);
    } else {
      this.sdk = AppLovinSdk.getInstance(paramAppLovinSdkSettings, (Context)activity);
    } 
    this.sdk.getVariableService().setOnVariablesUpdateListener(this);
    this.sdk.setPluginVersion("Max-Unity-5.11.3");
    this.sdk.setMediationProvider("max");
    this.sdk.initializeSdk(new AppLovinSdk.SdkInitializationListener() {
          public void onSdkInitialized(AppLovinSdkConfiguration param1AppLovinSdkConfiguration) {
            listener.onSdkInitializationComplete(param1AppLovinSdkConfiguration);
            JSONObject jSONObject = new JSONObject();
            JsonUtils.putString(jSONObject, "name", "OnSdkInitializedEvent");
            JsonUtils.putString(jSONObject, "consentDialogState", Integer.toString(param1AppLovinSdkConfiguration.getConsentDialogState().ordinal()));
            JsonUtils.putString(jSONObject, "countryCode", param1AppLovinSdkConfiguration.getCountryCode());
            JsonUtils.putString(jSONObject, "isSuccessfullyInitialized", String.valueOf(MaxUnityAdManager.this.sdk.isInitialized()));
            JsonUtils.putBoolean(jSONObject, "isTestModeEnabled", param1AppLovinSdkConfiguration.isTestModeEnabled());
            MaxUnityAdManager.forwardUnityEvent(jSONObject);
          }
        });
    return this.sdk;
  }
  
  public boolean isAppOpenAdReady(String paramString) {
    return retrieveAppOpenAd(paramString).isReady();
  }
  
  public boolean isInterstitialReady(String paramString) {
    return retrieveInterstitial(paramString).isReady();
  }
  
  public boolean isRewardedAdReady(String paramString) {
    return retrieveRewardedAd(paramString).isReady();
  }
  
  public boolean isRewardedInterstitialAdReady(String paramString) {
    return retrieveRewardedInterstitialAd(paramString).isReady();
  }
  
  public void loadAppOpenAd(String paramString) {
    retrieveAppOpenAd(paramString).loadAd();
  }
  
  public void loadBanner(String paramString) {
    loadAdView(paramString, getAdViewAdFormat(paramString));
  }
  
  public void loadInterstitial(String paramString) {
    retrieveInterstitial(paramString).loadAd();
  }
  
  public void loadMRec(String paramString) {
    loadAdView(paramString, MaxAdFormat.MREC);
  }
  
  public void loadRewardedAd(String paramString) {
    retrieveRewardedAd(paramString).loadAd();
  }
  
  public void loadRewardedInterstitialAd(String paramString) {
    retrieveRewardedInterstitialAd(paramString).loadAd();
  }
  
  @Deprecated
  public void loadVariables() {
    this.sdk.getVariableService().loadVariables();
  }
  
  public void onAdClicked(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (MaxAdFormat.BANNER == maxAdFormat || MaxAdFormat.LEADER == maxAdFormat) {
      str = "OnBannerAdClickedEvent";
    } else if (MaxAdFormat.MREC == str) {
      str = "OnMRecAdClickedEvent";
    } else if (MaxAdFormat.CROSS_PROMO == str) {
      str = "OnCrossPromoAdClickedEvent";
    } else if (MaxAdFormat.INTERSTITIAL == str) {
      str = "OnInterstitialClickedEvent";
    } else if (MaxAdFormat.APP_OPEN == str) {
      str = "OnAppOpenAdClickedEvent";
    } else if (MaxAdFormat.REWARDED == str) {
      str = "OnRewardedAdClickedEvent";
    } else if (MaxAdFormat.REWARDED_INTERSTITIAL == str) {
      str = "OnRewardedInterstitialAdClickedEvent";
    } else {
      logInvalidAdFormat((MaxAdFormat)str);
      return;
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
  }
  
  public void onAdCollapsed(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (!maxAdFormat.isAdViewAd()) {
      logInvalidAdFormat(maxAdFormat);
      return;
    } 
    if (MaxAdFormat.MREC == maxAdFormat) {
      str = "OnMRecAdCollapsedEvent";
    } else if (MaxAdFormat.CROSS_PROMO == str) {
      str = "OnCrossPromoAdCollapsedEvent";
    } else {
      str = "OnBannerAdCollapsedEvent";
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
  }
  
  public void onAdDisplayFailed(MaxAd paramMaxAd, MaxError paramMaxError) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (!maxAdFormat.isFullscreenAd())
      return; 
    if (MaxAdFormat.INTERSTITIAL == maxAdFormat) {
      str = "OnInterstitialAdFailedToDisplayEvent";
    } else if (MaxAdFormat.APP_OPEN == str) {
      str = "OnAppOpenAdFailedToDisplayEvent";
    } else if (MaxAdFormat.REWARDED == str) {
      str = "OnRewardedAdFailedToDisplayEvent";
    } else {
      str = "OnRewardedInterstitialAdFailedToDisplayEvent";
    } 
    JSONObject jSONObject = getDefaultAdEventParameters(str, paramMaxAd);
    JsonUtils.putString(jSONObject, "errorCode", Integer.toString(paramMaxError.getCode()));
    JsonUtils.putString(jSONObject, "errorMessage", paramMaxError.getMessage());
    JsonUtils.putString(jSONObject, "mediatedNetworkErrorCode", Integer.toString(paramMaxError.getMediatedNetworkErrorCode()));
    JsonUtils.putString(jSONObject, "mediatedNetworkErrorMessage", paramMaxError.getMediatedNetworkErrorMessage());
    JsonUtils.putJSONObject(jSONObject, "waterfallInfo", createAdWaterfallInfo(paramMaxError.getWaterfall()));
    forwardUnityEvent(jSONObject);
  }
  
  public void onAdDisplayed(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (!maxAdFormat.isFullscreenAd())
      return; 
    if (MaxAdFormat.INTERSTITIAL == maxAdFormat) {
      str = "OnInterstitialDisplayedEvent";
    } else if (MaxAdFormat.APP_OPEN == str) {
      str = "OnAppOpenAdDisplayedEvent";
    } else if (MaxAdFormat.REWARDED == str) {
      str = "OnRewardedAdDisplayedEvent";
    } else {
      str = "OnRewardedInterstitialAdDisplayedEvent";
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
  }
  
  public void onAdExpanded(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (!maxAdFormat.isAdViewAd()) {
      logInvalidAdFormat(maxAdFormat);
      return;
    } 
    if (MaxAdFormat.MREC == maxAdFormat) {
      str = "OnMRecAdExpandedEvent";
    } else if (MaxAdFormat.CROSS_PROMO == str) {
      str = "OnCrossPromoAdExpandedEvent";
    } else {
      str = "OnBannerAdExpandedEvent";
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
  }
  
  public void onAdHidden(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (!maxAdFormat.isFullscreenAd())
      return; 
    if (MaxAdFormat.INTERSTITIAL == maxAdFormat) {
      str = "OnInterstitialHiddenEvent";
    } else if (MaxAdFormat.APP_OPEN == str) {
      str = "OnAppOpenAdHiddenEvent";
    } else if (MaxAdFormat.REWARDED == str) {
      str = "OnRewardedAdHiddenEvent";
    } else {
      str = "OnRewardedInterstitialAdHiddenEvent";
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
  }
  
  public void onAdLoadFailed(String paramString, MaxError paramMaxError) {
    StringBuilder stringBuilder;
    String str;
    if (TextUtils.isEmpty(paramString)) {
      logStackTrace(new IllegalArgumentException("adUnitId cannot be null"));
      return;
    } 
    if (this.mAdViews.containsKey(paramString)) {
      MaxAdFormat maxAdFormat = this.mAdViewAdFormats.get(paramString);
      if (MaxAdFormat.MREC == maxAdFormat) {
        str = "OnMRecAdLoadFailedEvent";
      } else if (MaxAdFormat.CROSS_PROMO == str) {
        str = "OnCrossPromoAdLoadFailedEvent";
      } else {
        str = "OnBannerAdLoadFailedEvent";
      } 
    } else if (this.mInterstitials.containsKey(paramString)) {
      str = "OnInterstitialLoadFailedEvent";
    } else if (this.mAppOpenAds.containsKey(paramString)) {
      str = "OnAppOpenAdLoadFailedEvent";
    } else if (this.mRewardedAds.containsKey(paramString)) {
      str = "OnRewardedAdLoadFailedEvent";
    } else if (this.mRewardedInterstitialAds.containsKey(paramString)) {
      str = "OnRewardedInterstitialAdLoadFailedEvent";
    } else {
      stringBuilder = new StringBuilder("invalid adUnitId: ");
      stringBuilder.append(paramString);
      logStackTrace(new IllegalStateException(stringBuilder.toString()));
      return;
    } 
    synchronized (this.mAdInfoMapLock) {
      this.mAdInfoMap.remove(paramString);
      null = new JSONObject();
      JsonUtils.putString((JSONObject)null, "name", str);
      JsonUtils.putString((JSONObject)null, "adUnitId", paramString);
      JsonUtils.putString((JSONObject)null, "errorCode", Integer.toString(stringBuilder.getCode()));
      JsonUtils.putString((JSONObject)null, "errorMessage", stringBuilder.getMessage());
      JsonUtils.putJSONObject((JSONObject)null, "waterfallInfo", createAdWaterfallInfo(stringBuilder.getWaterfall()));
      paramString = stringBuilder.getAdLoadFailureInfo();
      if (TextUtils.isEmpty(paramString))
        paramString = ""; 
      JsonUtils.putString((JSONObject)null, "adLoadFailureInfo", paramString);
      forwardUnityEvent((JSONObject)null);
      return;
    } 
  }
  
  public void onAdLoaded(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (maxAdFormat.isAdViewAd()) {
      String str1;
      if (MaxAdFormat.MREC == maxAdFormat) {
        str1 = "OnMRecAdLoadedEvent";
      } else if (MaxAdFormat.CROSS_PROMO == maxAdFormat) {
        str1 = "OnCrossPromoAdLoadedEvent";
      } else {
        str1 = "OnBannerAdLoadedEvent";
      } 
      positionAdView(paramMaxAd);
      MaxAdView maxAdView = retrieveAdView(paramMaxAd.getAdUnitId(), maxAdFormat);
      str = str1;
      if (maxAdView != null) {
        str = str1;
        if (maxAdView.getVisibility() != 0) {
          maxAdView.stopAutoRefresh();
          str = str1;
        } 
      } 
    } else if (MaxAdFormat.INTERSTITIAL == str) {
      str = "OnInterstitialLoadedEvent";
    } else if (MaxAdFormat.APP_OPEN == str) {
      str = "OnAppOpenAdLoadedEvent";
    } else if (MaxAdFormat.REWARDED == str) {
      str = "OnRewardedAdLoadedEvent";
    } else if (MaxAdFormat.REWARDED_INTERSTITIAL == str) {
      str = "OnRewardedInterstitialAdLoadedEvent";
    } else {
      logInvalidAdFormat((MaxAdFormat)str);
      return;
    } 
    synchronized (this.mAdInfoMapLock) {
      this.mAdInfoMap.put(paramMaxAd.getAdUnitId(), paramMaxAd);
      forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd));
      return;
    } 
  }
  
  public void onAdRevenuePaid(MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (MaxAdFormat.BANNER == maxAdFormat || MaxAdFormat.LEADER == maxAdFormat) {
      str = "OnBannerAdRevenuePaidEvent";
    } else if (MaxAdFormat.MREC == maxAdFormat) {
      str = "OnMRecAdRevenuePaidEvent";
    } else if (MaxAdFormat.CROSS_PROMO == maxAdFormat) {
      str = "OnCrossPromoAdRevenuePaidEvent";
    } else if (MaxAdFormat.INTERSTITIAL == maxAdFormat) {
      str = "OnInterstitialAdRevenuePaidEvent";
    } else if (MaxAdFormat.APP_OPEN == maxAdFormat) {
      str = "OnAppOpenAdRevenuePaidEvent";
    } else if (MaxAdFormat.REWARDED == maxAdFormat) {
      str = "OnRewardedAdRevenuePaidEvent";
    } else if (MaxAdFormat.REWARDED_INTERSTITIAL == maxAdFormat) {
      str = "OnRewardedInterstitialAdRevenuePaidEvent";
    } else {
      logInvalidAdFormat(maxAdFormat);
      return;
    } 
    forwardUnityEvent(getDefaultAdEventParameters(str, paramMaxAd), maxAdFormat.isFullscreenAd());
  }
  
  public void onCreativeIdGenerated(String paramString, MaxAd paramMaxAd) {
    String str;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (MaxAdFormat.BANNER == maxAdFormat || MaxAdFormat.LEADER == maxAdFormat) {
      str = "OnBannerAdReviewCreativeIdGeneratedEvent";
    } else if (MaxAdFormat.MREC == maxAdFormat) {
      str = "OnMRecAdReviewCreativeIdGeneratedEvent";
    } else if (MaxAdFormat.INTERSTITIAL == maxAdFormat) {
      str = "OnInterstitialAdReviewCreativeIdGeneratedEvent";
    } else if (MaxAdFormat.REWARDED == maxAdFormat) {
      str = "OnRewardedAdReviewCreativeIdGeneratedEvent";
    } else if (MaxAdFormat.REWARDED_INTERSTITIAL == maxAdFormat) {
      str = "OnRewardedInterstitialAdReviewCreativeIdGeneratedEvent";
    } else {
      logInvalidAdFormat(maxAdFormat);
      return;
    } 
    JSONObject jSONObject = getDefaultAdEventParameters(str, paramMaxAd);
    JsonUtils.putString(jSONObject, "adReviewCreativeId", paramString);
    forwardUnityEvent(jSONObject, maxAdFormat.isFullscreenAd());
  }
  
  public void onDismiss() {
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "name", "OnSdkConsentDialogDismissedEvent");
    forwardUnityEvent(jSONObject);
  }
  
  public void onFlowCompleted(AppLovinCFError paramAppLovinCFError) {
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "name", "OnSdkConsentFlowCompletedEvent");
    if (paramAppLovinCFError != null) {
      JsonUtils.putInt(jSONObject, "code", paramAppLovinCFError.getCode());
      JsonUtils.putString(jSONObject, "message", paramAppLovinCFError.getMessage());
    } 
    forwardUnityEvent(jSONObject, true);
  }
  
  public void onRewardedVideoCompleted(MaxAd paramMaxAd) {}
  
  public void onRewardedVideoStarted(MaxAd paramMaxAd) {}
  
  public void onUserRewarded(MaxAd paramMaxAd, MaxReward paramMaxReward) {
    String str1;
    boolean bool;
    String str2;
    MaxAdFormat maxAdFormat = paramMaxAd.getFormat();
    if (maxAdFormat != MaxAdFormat.REWARDED && maxAdFormat != MaxAdFormat.REWARDED_INTERSTITIAL) {
      logInvalidAdFormat(maxAdFormat);
      return;
    } 
    if (paramMaxReward != null) {
      str2 = paramMaxReward.getLabel();
    } else {
      str2 = "";
    } 
    if (paramMaxReward != null) {
      bool = paramMaxReward.getAmount();
    } else {
      bool = false;
    } 
    String str3 = Integer.toString(bool);
    if (maxAdFormat == MaxAdFormat.REWARDED) {
      str1 = "OnRewardedAdReceivedRewardEvent";
    } else {
      str1 = "OnRewardedInterstitialAdReceivedRewardEvent";
    } 
    JSONObject jSONObject = getDefaultAdEventParameters(str1, paramMaxAd);
    JsonUtils.putString(jSONObject, "rewardLabel", str2);
    JsonUtils.putString(jSONObject, "rewardAmount", str3);
    forwardUnityEvent(jSONObject);
  }
  
  public void onVariablesUpdate(Bundle paramBundle) {
    JSONObject jSONObject = new JSONObject();
    JsonUtils.putString(jSONObject, "name", "OnVariablesUpdatedEvent");
    forwardUnityEvent(jSONObject);
  }
  
  public void setAppOpenAdExtraParameter(String paramString1, String paramString2, String paramString3) {
    retrieveAppOpenAd(paramString1).setExtraParameter(paramString2, paramString3);
  }
  
  public void setAppOpenAdLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    retrieveAppOpenAd(paramString1).setLocalExtraParameter(paramString2, paramObject);
  }
  
  public void setBannerBackgroundColor(String paramString1, String paramString2) {
    setAdViewBackgroundColor(paramString1, getAdViewAdFormat(paramString1), paramString2);
  }
  
  public void setBannerCustomData(String paramString1, String paramString2) {
    setAdViewCustomData(paramString1, getAdViewAdFormat(paramString1), paramString2);
  }
  
  public void setBannerExtraParameter(String paramString1, String paramString2, String paramString3) {
    setAdViewExtraParameter(paramString1, getAdViewAdFormat(paramString1), paramString2, paramString3);
  }
  
  public void setBannerLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    setAdViewLocalExtraParameter(paramString1, getAdViewAdFormat(paramString1), paramString2, paramObject);
  }
  
  public void setBannerPlacement(String paramString1, String paramString2) {
    setAdViewPlacement(paramString1, getAdViewAdFormat(paramString1), paramString2);
  }
  
  public void setBannerWidth(String paramString, int paramInt) {
    setAdViewWidth(paramString, paramInt, getAdViewAdFormat(paramString));
  }
  
  public void setCrossPromoAdPlacement(String paramString1, String paramString2) {
    setAdViewPlacement(paramString1, MaxAdFormat.CROSS_PROMO, paramString2);
  }
  
  public void setInterstitialExtraParameter(String paramString1, String paramString2, String paramString3) {
    retrieveInterstitial(paramString1).setExtraParameter(paramString2, paramString3);
  }
  
  public void setInterstitialLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    retrieveInterstitial(paramString1).setLocalExtraParameter(paramString2, paramObject);
  }
  
  public void setMRecCustomData(String paramString1, String paramString2) {
    setAdViewCustomData(paramString1, MaxAdFormat.MREC, paramString2);
  }
  
  public void setMRecExtraParameter(String paramString1, String paramString2, String paramString3) {
    setAdViewExtraParameter(paramString1, MaxAdFormat.MREC, paramString2, paramString3);
  }
  
  public void setMRecLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    setAdViewLocalExtraParameter(paramString1, MaxAdFormat.MREC, paramString2, paramObject);
  }
  
  public void setMRecPlacement(String paramString1, String paramString2) {
    setAdViewPlacement(paramString1, MaxAdFormat.MREC, paramString2);
  }
  
  public void setRewardedAdExtraParameter(String paramString1, String paramString2, String paramString3) {
    retrieveRewardedAd(paramString1).setExtraParameter(paramString2, paramString3);
  }
  
  public void setRewardedAdLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    retrieveRewardedAd(paramString1).setLocalExtraParameter(paramString2, paramObject);
  }
  
  public void setRewardedInterstitialAdExtraParameter(String paramString1, String paramString2, String paramString3) {
    retrieveRewardedInterstitialAd(paramString1).setExtraParameter(paramString2, paramString3);
  }
  
  public void setRewardedInterstitialAdLocalExtraParameter(String paramString1, String paramString2, Object paramObject) {
    retrieveRewardedInterstitialAd(paramString1).setLocalExtraParameter(paramString2, paramObject);
  }
  
  public void showAppOpenAd(String paramString1, String paramString2, String paramString3) {
    retrieveAppOpenAd(paramString1).showAd(paramString2, paramString3);
  }
  
  public void showBanner(String paramString) {
    showAdView(paramString, getAdViewAdFormat(paramString));
  }
  
  public void showCrossPromoAd(String paramString) {
    showAdView(paramString, MaxAdFormat.CROSS_PROMO);
  }
  
  public void showInterstitial(String paramString1, String paramString2, String paramString3) {
    retrieveInterstitial(paramString1).showAd(paramString2, paramString3);
  }
  
  public void showMRec(String paramString) {
    showAdView(paramString, MaxAdFormat.MREC);
  }
  
  public void showRewardedAd(String paramString1, String paramString2, String paramString3) {
    retrieveRewardedAd(paramString1).showAd(paramString2, paramString3);
  }
  
  public void showRewardedInterstitialAd(String paramString1, String paramString2, String paramString3) {
    retrieveRewardedInterstitialAd(paramString1).showAd(paramString2, paramString3);
  }
  
  public void startBannerAutoRefresh(String paramString) {
    startAdViewAutoRefresh(paramString, getAdViewAdFormat(paramString));
  }
  
  public void startConsentFlow() {
    this.sdk.getCFService().scf(getCurrentActivity(), this);
  }
  
  public void startMRecAutoRefresh(String paramString) {
    startAdViewAutoRefresh(paramString, MaxAdFormat.MREC);
  }
  
  public void stopBannerAutoRefresh(String paramString) {
    stopAdViewAutoRefresh(paramString, getAdViewAdFormat(paramString));
  }
  
  public void stopMRecAutoRefresh(String paramString) {
    stopAdViewAutoRefresh(paramString, MaxAdFormat.MREC);
  }
  
  public void trackEvent(String paramString1, String paramString2) {
    if (this.sdk == null)
      return; 
    Map<String, String> map = deserializeParameters(paramString2);
    this.sdk.getEventService().trackEvent(paramString1, map);
  }
  
  public void updateBannerPosition(String paramString, float paramFloat1, float paramFloat2) {
    updateAdViewPosition(paramString, "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()), getAdViewAdFormat(paramString));
  }
  
  public void updateBannerPosition(String paramString1, String paramString2) {
    updateAdViewPosition(paramString1, paramString2, DEFAULT_AD_VIEW_OFFSET, getAdViewAdFormat(paramString1));
  }
  
  public void updateCrossPromoAdPosition(String paramString, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, int paramInt3) {
    this.mAdViewWidths.put(paramString, Integer.valueOf(paramInt1));
    this.mCrossPromoAdViewHeights.put(paramString, Integer.valueOf(paramInt2));
    this.mCrossPromoAdViewRotations.put(paramString, Integer.valueOf(paramInt3));
    updateAdViewPosition(paramString, "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()), MaxAdFormat.CROSS_PROMO);
  }
  
  public void updateMRecPosition(String paramString, float paramFloat1, float paramFloat2) {
    updateAdViewPosition(paramString, "top_left", getOffsetPixels(paramFloat1, paramFloat2, (Context)getCurrentActivity()), MaxAdFormat.MREC);
  }
  
  public void updateMRecPosition(String paramString1, String paramString2) {
    updateAdViewPosition(paramString1, paramString2, DEFAULT_AD_VIEW_OFFSET, MaxAdFormat.MREC);
  }
  
  public static interface BackgroundCallback {
    void onEvent(String param1String);
  }
  
  private static class Insets {
    int bottom;
    
    int left;
    
    int right;
    
    int top;
    
    private Insets() {}
  }
  
  public static interface Listener {
    void onSdkInitializationComplete(AppLovinSdkConfiguration param1AppLovinSdkConfiguration);
  }
  
  private static class SdkThreadFactory implements ThreadFactory {
    private SdkThreadFactory() {}
    
    public Thread newThread(Runnable param1Runnable) {
      param1Runnable = new Thread(param1Runnable, "AppLovinSdk:Max-Unity-Plugin:shared");
      param1Runnable.setDaemon(true);
      param1Runnable.setPriority(5);
      param1Runnable.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread param2Thread, Throwable param2Throwable) {
              Log.e("MaxUnityAdManager", "Caught unhandled exception", param2Throwable);
            }
          });
      return (Thread)param1Runnable;
    }
  }
  
  class null implements Thread.UncaughtExceptionHandler {
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      Log.e("MaxUnityAdManager", "Caught unhandled exception", param1Throwable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediatio\\unity\MaxUnityAdManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */