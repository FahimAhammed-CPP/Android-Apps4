package com.applovin.mediation.adapter;

import android.app.Activity;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;

public interface MaxInterstitialAdapter {
  void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener);
  
  void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapter\MaxInterstitialAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */