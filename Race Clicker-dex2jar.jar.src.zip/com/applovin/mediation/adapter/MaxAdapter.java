package com.applovin.mediation.adapter;

import android.app.Activity;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;

public interface MaxAdapter {
  String getAdapterVersion();
  
  String getSdkVersion();
  
  void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, OnCompletionListener paramOnCompletionListener);
  
  boolean isBeta();
  
  void onDestroy();
  
  Boolean shouldCollectSignalsOnUiThread();
  
  Boolean shouldInitializeOnUiThread();
  
  Boolean shouldLoadAdsOnUiThread(MaxAdFormat paramMaxAdFormat);
  
  Boolean shouldShowAdsOnUiThread(MaxAdFormat paramMaxAdFormat);
  
  public enum InitializationStatus {
    DOES_NOT_APPLY, INITIALIZED_FAILURE, INITIALIZED_SUCCESS, INITIALIZED_UNKNOWN, INITIALIZING, NOT_INITIALIZED;
    
    private final int code;
    
    static {
      InitializationStatus initializationStatus1 = new InitializationStatus("NOT_INITIALIZED", 0, -4);
      NOT_INITIALIZED = initializationStatus1;
      InitializationStatus initializationStatus2 = new InitializationStatus("DOES_NOT_APPLY", 1, -3);
      DOES_NOT_APPLY = initializationStatus2;
      InitializationStatus initializationStatus3 = new InitializationStatus("INITIALIZING", 2, -2);
      INITIALIZING = initializationStatus3;
      InitializationStatus initializationStatus4 = new InitializationStatus("INITIALIZED_UNKNOWN", 3, -1);
      INITIALIZED_UNKNOWN = initializationStatus4;
      InitializationStatus initializationStatus5 = new InitializationStatus("INITIALIZED_FAILURE", 4, 0);
      INITIALIZED_FAILURE = initializationStatus5;
      InitializationStatus initializationStatus6 = new InitializationStatus("INITIALIZED_SUCCESS", 5, 1);
      INITIALIZED_SUCCESS = initializationStatus6;
      $VALUES = new InitializationStatus[] { initializationStatus1, initializationStatus2, initializationStatus3, initializationStatus4, initializationStatus5, initializationStatus6 };
    }
    
    InitializationStatus(int param1Int1) {
      this.code = param1Int1;
    }
    
    public int getCode() {
      return this.code;
    }
  }
  
  public static interface OnCompletionListener {
    void onCompletion(MaxAdapter.InitializationStatus param1InitializationStatus, String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapter\MaxAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */