package com.applovin.mediation.nativeAds;

import android.view.View;

public class MaxNativeAdViewBinder {
  protected final int advertiserTextViewId;
  
  protected final int bodyTextViewId;
  
  protected final int callToActionButtonId;
  
  protected final int iconContentViewId;
  
  protected final int iconImageViewId;
  
  protected final int layoutResourceId;
  
  protected final View mainView;
  
  protected final int mediaContentFrameLayoutId;
  
  protected final int mediaContentViewGroupId;
  
  protected final int optionsContentFrameLayoutId;
  
  protected final int optionsContentViewGroupId;
  
  protected final int starRatingContentViewGroupId;
  
  protected final String templateType;
  
  protected final int titleTextViewId;
  
  private MaxNativeAdViewBinder(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, String paramString) {
    this.mainView = paramView;
    this.layoutResourceId = paramInt1;
    this.titleTextViewId = paramInt2;
    this.advertiserTextViewId = paramInt3;
    this.bodyTextViewId = paramInt4;
    this.iconImageViewId = paramInt5;
    this.iconContentViewId = paramInt6;
    this.starRatingContentViewGroupId = paramInt7;
    this.optionsContentViewGroupId = paramInt8;
    this.optionsContentFrameLayoutId = paramInt9;
    this.mediaContentViewGroupId = paramInt10;
    this.mediaContentFrameLayoutId = paramInt11;
    this.callToActionButtonId = paramInt12;
    this.templateType = paramString;
  }
  
  public static class Builder {
    private final View a;
    
    private final int b;
    
    private int c = -1;
    
    private int d = -1;
    
    private int e = -1;
    
    private int f = -1;
    
    private int g = -1;
    
    private int h = -1;
    
    private int i = -1;
    
    private int j = -1;
    
    private int k = -1;
    
    private int l = -1;
    
    private int m = -1;
    
    private String n;
    
    public Builder(int param1Int) {
      this(param1Int, null);
    }
    
    private Builder(int param1Int, View param1View) {
      this.b = param1Int;
      this.a = param1View;
    }
    
    public Builder(View param1View) {
      this(-1, param1View);
    }
    
    public MaxNativeAdViewBinder build() {
      return new MaxNativeAdViewBinder(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.j, this.h, this.i, this.k, this.l, this.m, this.n);
    }
    
    public Builder setAdvertiserTextViewId(int param1Int) {
      this.d = param1Int;
      return this;
    }
    
    public Builder setBodyTextViewId(int param1Int) {
      this.e = param1Int;
      return this;
    }
    
    public Builder setCallToActionButtonId(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    @Deprecated
    protected Builder setIconContentViewId(int param1Int) {
      this.g = param1Int;
      return this;
    }
    
    public Builder setIconImageViewId(int param1Int) {
      this.f = param1Int;
      return this;
    }
    
    @Deprecated
    protected Builder setMediaContentFrameLayoutId(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    public Builder setMediaContentViewGroupId(int param1Int) {
      this.k = param1Int;
      return this;
    }
    
    @Deprecated
    protected Builder setOptionsContentFrameLayoutId(int param1Int) {
      this.i = param1Int;
      return this;
    }
    
    public Builder setOptionsContentViewGroupId(int param1Int) {
      this.h = param1Int;
      return this;
    }
    
    public Builder setStarRatingContentViewGroupId(int param1Int) {
      this.j = param1Int;
      return this;
    }
    
    protected Builder setTemplateType(String param1String) {
      this.n = param1String;
      return this;
    }
    
    public Builder setTitleTextViewId(int param1Int) {
      this.c = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\nativeAds\MaxNativeAdViewBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */