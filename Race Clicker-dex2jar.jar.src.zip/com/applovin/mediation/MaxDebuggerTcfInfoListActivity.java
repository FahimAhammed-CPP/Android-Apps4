package com.applovin.mediation;

import android.view.MotionEvent;
import com.applovin.impl.mediation.debugger.ui.e.a;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public class MaxDebuggerTcfInfoListActivity extends a {
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.applovin", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\MaxDebuggerTcfInfoListActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */