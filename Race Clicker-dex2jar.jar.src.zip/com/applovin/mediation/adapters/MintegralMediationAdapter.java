package com.applovin.mediation.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.mbridge.msdk.interstitialvideo.out.InterstitialVideoListener;
import com.mbridge.msdk.interstitialvideo.out.MBBidInterstitialVideoHandler;
import com.mbridge.msdk.interstitialvideo.out.MBInterstitialVideoHandler;
import com.mbridge.msdk.mbbid.out.BidConstants;
import com.mbridge.msdk.mbbid.out.BidManager;
import com.mbridge.msdk.nativex.view.MBMediaView;
import com.mbridge.msdk.out.BannerAdListener;
import com.mbridge.msdk.out.BannerSize;
import com.mbridge.msdk.out.Campaign;
import com.mbridge.msdk.out.Frame;
import com.mbridge.msdk.out.MBBannerView;
import com.mbridge.msdk.out.MBBidNativeHandler;
import com.mbridge.msdk.out.MBBidRewardVideoHandler;
import com.mbridge.msdk.out.MBConfiguration;
import com.mbridge.msdk.out.MBRewardVideoHandler;
import com.mbridge.msdk.out.MBridgeIds;
import com.mbridge.msdk.out.NativeListener;
import com.mbridge.msdk.out.OnMBMediaViewListener;
import com.mbridge.msdk.out.RewardInfo;
import com.mbridge.msdk.out.RewardVideoListener;
import com.mbridge.msdk.video.bt.module.b.g;
import com.mbridge.msdk.widget.MBAdChoice;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

public class MintegralMediationAdapter extends MediationAdapterBase implements MaxInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter, MaxSignalProvider {
  private static final String APP_ID_PARAMETER = "app_id";
  
  private static final String APP_KEY_PARAMETER = "app_key";
  
  private static final String BAD_REQUEST = "request parameter is null";
  
  private static final int DEFAULT_IMAGE_TASK_TIMEOUT_SECONDS = 5;
  
  private static final String EXCEPTION_APP_ID_EMPTY = "EXCEPTION_APP_ID_EMPTY";
  
  private static final String EXCEPTION_APP_NOT_FOUND = "EXCEPTION_APP_NOT_FOUND";
  
  private static final String EXCEPTION_IV_RECALLNET_INVALIDATE = "EXCEPTION_IV_RECALLNET_INVALIDATE";
  
  private static final String EXCEPTION_RETURN_EMPTY = "EXCEPTION_RETURN_EMPTY";
  
  private static final String EXCEPTION_SIGN_ERROR = "EXCEPTION_SIGN_ERROR";
  
  private static final String EXCEPTION_TIMEOUT = "EXCEPTION_TIMEOUT";
  
  private static final String EXCEPTION_UNIT_ADTYPE_ERROR = "EXCEPTION_UNIT_ADTYPE_ERROR";
  
  private static final String EXCEPTION_UNIT_ID_EMPTY = "EXCEPTION_UNIT_ID_EMPTY";
  
  private static final String EXCEPTION_UNIT_NOT_FOUND = "EXCEPTION_UNIT_NOT_FOUND";
  
  private static final String EXCEPTION_UNIT_NOT_FOUND_IN_APP = "EXCEPTION_UNIT_NOT_FOUND_IN_APP";
  
  private static final String NETWORK_ERROR = "network exception";
  
  private static final String NETWORK_IO_ERROR = "Network error,I/O exception";
  
  private static final String NOT_INITIALIZED = "init error";
  
  private static final String NO_FILL_1 = "no ads available can show";
  
  private static final String NO_FILL_2 = "no ads available";
  
  private static final String NO_FILL_3 = "no server ads available";
  
  private static final String NO_FILL_4 = "no ads source";
  
  private static final String NO_FILL_5 = "load no ad";
  
  private static final String TIMEOUT = "load timeout";
  
  private static final String UNIT_ID_EMPTY = "UnitId is null";
  
  private static final ExecutorService executor;
  
  private static final AtomicBoolean initialized = new AtomicBoolean();
  
  private static final Map<String, MBBidInterstitialVideoHandler> mbBidInterstitialVideoHandlers;
  
  private static final Map<String, MBBidRewardVideoHandler> mbBidRewardVideoHandlers;
  
  private static final Map<String, MBInterstitialVideoHandler> mbInterstitialVideoHandlers;
  
  private static final Map<String, MBRewardVideoHandler> mbRewardVideoHandlers;
  
  private static final MintegralMediationAdapterRouter router;
  
  private static String sSdkVersion;
  
  private List<View> clickableViews;
  
  private MBBannerView mbBannerView;
  
  private MBBidInterstitialVideoHandler mbBidInterstitialVideoHandler;
  
  private MBBidNativeHandler mbBidNativeAdViewHandler;
  
  private MBBidNativeHandler mbBidNativeHandler;
  
  private MBBidRewardVideoHandler mbBidRewardVideoHandler;
  
  private MBInterstitialVideoHandler mbInterstitialVideoHandler;
  
  private MBRewardVideoHandler mbRewardVideoHandler;
  
  private String mbUnitId;
  
  private MaxNativeAd nativeAd;
  
  private Campaign nativeAdCampaign;
  
  private ViewGroup nativeAdContainer;
  
  static {
    executor = Executors.newCachedThreadPool();
    mbInterstitialVideoHandlers = new HashMap<String, MBInterstitialVideoHandler>();
    mbBidInterstitialVideoHandlers = new HashMap<String, MBBidInterstitialVideoHandler>();
    mbRewardVideoHandlers = new HashMap<String, MBRewardVideoHandler>();
    mbBidRewardVideoHandlers = new HashMap<String, MBBidRewardVideoHandler>();
    router = (MintegralMediationAdapterRouter)MediationAdapterRouter.getSharedInstance(MintegralMediationAdapterRouter.class);
  }
  
  public MintegralMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private MaxNativeAdView createMaxNativeAdViewWithNativeAd(MaxNativeAd paramMaxNativeAd, String paramString, Context paramContext) {
    if (paramString.contains("vertical")) {
      if (AppLovinSdk.VERSION_CODE < 9140500)
        log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
      if (paramString.equals("vertical")) {
        if (paramMaxNativeAd.getFormat() == MaxAdFormat.LEADER) {
          paramString = "vertical_leader_template";
        } else {
          paramString = "vertical_media_banner_template";
        } 
        return new MaxNativeAdView(paramMaxNativeAd, paramString, paramContext);
      } 
      return new MaxNativeAdView(paramMaxNativeAd, paramString, paramContext);
    } 
    if (AppLovinSdk.VERSION_CODE < 9140500) {
      if (!AppLovinSdkUtils.isValidString(paramString))
        paramString = "no_body_banner_template"; 
      return new MaxNativeAdView(paramMaxNativeAd, paramString, paramContext);
    } 
    if (!AppLovinSdkUtils.isValidString(paramString))
      paramString = "media_banner_template"; 
    return new MaxNativeAdView(paramMaxNativeAd, paramString, paramContext);
  }
  
  private List<View> getClickableViews(MaxNativeAdView paramMaxNativeAdView) {
    if (AppLovinSdk.VERSION_CODE < 11050300) {
      ArrayList<TextView> arrayList = new ArrayList(5);
      if (paramMaxNativeAdView.getTitleTextView() != null)
        arrayList.add(paramMaxNativeAdView.getTitleTextView()); 
      if (paramMaxNativeAdView.getAdvertiserTextView() != null)
        arrayList.add(paramMaxNativeAdView.getAdvertiserTextView()); 
      if (paramMaxNativeAdView.getBodyTextView() != null)
        arrayList.add(paramMaxNativeAdView.getBodyTextView()); 
      if (paramMaxNativeAdView.getCallToActionButton() != null)
        arrayList.add(paramMaxNativeAdView.getCallToActionButton()); 
      if (paramMaxNativeAdView.getIconImageView() != null)
        arrayList.add(paramMaxNativeAdView.getIconImageView()); 
      return (List)arrayList;
    } 
    return paramMaxNativeAdView.getClickableViews();
  }
  
  private Context getContext(Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private ExecutorService getExecutorServiceToUse() {
    return (AppLovinSdk.VERSION_CODE >= 11000000) ? getCachingExecutorService() : executor;
  }
  
  private BannerSize toBannerSize(MaxAdFormat paramMaxAdFormat) {
    if (paramMaxAdFormat == MaxAdFormat.BANNER || paramMaxAdFormat == MaxAdFormat.LEADER)
      return new BannerSize(3, 0, 0); 
    if (paramMaxAdFormat == MaxAdFormat.MREC)
      return new BannerSize(2, 0, 0); 
    StringBuilder stringBuilder = new StringBuilder("Unsupported ad format: ");
    stringBuilder.append(paramMaxAdFormat);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static MaxAdapterError toMaxError(String paramString) {
    MaxAdapterError maxAdapterError;
    if ("init error".equals(paramString) || paramString.contains("EXCEPTION_IV_RECALLNET_INVALIDATE")) {
      maxAdapterError = MaxAdapterError.NOT_INITIALIZED;
      return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), 0, paramString);
    } 
    if (paramString.contains("no ads available can show") || paramString.contains("no ads available") || paramString.contains("no server ads available") || paramString.contains("no ads source") || paramString.contains("load no ad") || paramString.contains("EXCEPTION_RETURN_EMPTY")) {
      maxAdapterError = MaxAdapterError.NO_FILL;
      return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), 0, paramString);
    } 
    if ("network exception".equalsIgnoreCase(paramString) || paramString.contains("Network error,I/O exception")) {
      maxAdapterError = MaxAdapterError.NO_CONNECTION;
      return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), 0, paramString);
    } 
    if ("request parameter is null".equalsIgnoreCase(paramString)) {
      maxAdapterError = MaxAdapterError.BAD_REQUEST;
    } else {
      if ("load timeout".equalsIgnoreCase(paramString) || paramString.contains("EXCEPTION_TIMEOUT")) {
        MaxAdapterError maxAdapterError1 = MaxAdapterError.TIMEOUT;
        return new MaxAdapterError(maxAdapterError1.getErrorCode(), maxAdapterError1.getErrorMessage(), 0, paramString);
      } 
      if (paramString.contains("EXCEPTION_SIGN_ERROR") || paramString.contains("EXCEPTION_UNIT_NOT_FOUND") || paramString.contains("EXCEPTION_UNIT_ID_EMPTY") || paramString.contains("EXCEPTION_UNIT_NOT_FOUND_IN_APP") || paramString.contains("EXCEPTION_UNIT_ADTYPE_ERROR") || paramString.contains("EXCEPTION_APP_ID_EMPTY") || paramString.contains("EXCEPTION_APP_NOT_FOUND") || paramString.contains("UnitId is null")) {
        MaxAdapterError maxAdapterError1 = MaxAdapterError.INVALID_CONFIGURATION;
        return new MaxAdapterError(maxAdapterError1.getErrorCode(), maxAdapterError1.getErrorMessage(), 0, paramString);
      } 
      maxAdapterError = MaxAdapterError.UNSPECIFIED;
    } 
    return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), 0, paramString);
  }
  
  private static String toMintegralAdType(MaxAdFormat paramMaxAdFormat) {
    return (paramMaxAdFormat == MaxAdFormat.INTERSTITIAL) ? BidConstants.BID_FILTER_VALUE_AD_TYPE_INTERSTITIAL_VIDEO : ((paramMaxAdFormat == MaxAdFormat.REWARDED) ? BidConstants.BID_FILTER_VALUE_AD_TYPE_REWARD_VIDEO : ((paramMaxAdFormat == MaxAdFormat.APP_OPEN) ? BidConstants.BID_FILTER_VALUE_AD_TYPE_SPLASH : ((paramMaxAdFormat == MaxAdFormat.BANNER || paramMaxAdFormat == MaxAdFormat.LEADER || paramMaxAdFormat == MaxAdFormat.MREC) ? BidConstants.BID_FILTER_VALUE_AD_TYPE_BANNER : ((paramMaxAdFormat == MaxAdFormat.NATIVE) ? BidConstants.BID_FILTER_VALUE_AD_TYPE_NATIVE : "-1"))));
  }
  
  public void collectSignal(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, Activity paramActivity, MaxSignalCollectionListener paramMaxSignalCollectionListener) {
    String str1;
    log("Collecting signal...");
    String str2 = paramMaxAdapterSignalCollectionParameters.getAdUnitId();
    if (AppLovinSdkUtils.isValidString(str2)) {
      Bundle bundle2 = BundleUtils.getBundle("credentials", Bundle.EMPTY, paramMaxAdapterSignalCollectionParameters.getServerParameters());
      Bundle bundle1 = BundleUtils.getBundle(str2, Bundle.EMPTY, bundle2);
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>(3);
      hashMap.put(BidConstants.BID_FILTER_KEY_PLACEMENT_ID, BundleUtils.getString("placement_id", "", bundle1));
      hashMap.put(BidConstants.BID_FILTER_KEY_UNIT_ID, BundleUtils.getString("ad_unit_id", "", bundle1));
      hashMap.put(BidConstants.BID_FILTER_KEY_AD_TYPE, toMintegralAdType(paramMaxAdapterSignalCollectionParameters.getAdFormat()));
      str1 = BidManager.getBuyerUid(getContext(paramActivity), hashMap);
    } else {
      str1 = BidManager.getBuyerUid(getContext(paramActivity));
    } 
    paramMaxSignalCollectionListener.onSignalCollected(str1);
  }
  
  public String getAdapterVersion() {
    return "16.5.21.0";
  }
  
  public String getSdkVersion() {
    if (sSdkVersion == null)
      sSdkVersion = getVersionString(MBConfiguration.class, "SDK_VERSION"); 
    return sSdkVersion;
  }
  
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, MaxAdapter.OnCompletionListener paramOnCompletionListener) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, final MaxAdViewAdapterListener listener) {
    NativeAdViewListener nativeAdViewListener;
    MBBidNativeHandler mBBidNativeHandler;
    String str1;
    this.mbUnitId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    String str2 = BundleUtils.getString("placement_id", paramMaxAdapterResponseParameters.getServerParameters());
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder = new StringBuilder("Loading");
    if (bool) {
      str1 = " native ";
    } else {
      str1 = " ";
    } 
    stringBuilder.append(str1);
    stringBuilder.append(paramMaxAdFormat.getLabel());
    stringBuilder.append(" AdView ad for placement: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (bool) {
      Map<String, Integer> map = MBBidNativeHandler.getNativeProperties(str2, this.mbUnitId);
      map.put("ad_num", Integer.valueOf(1));
      map.put("videoSupport", Boolean.valueOf(true));
      nativeAdViewListener = new NativeAdViewListener(paramMaxAdapterResponseParameters, paramMaxAdFormat, getContext(paramActivity), listener);
      mBBidNativeHandler = new MBBidNativeHandler(map, getContext(paramActivity));
      this.mbBidNativeAdViewHandler = mBBidNativeHandler;
      mBBidNativeHandler.setAdListener(nativeAdViewListener);
      this.mbBidNativeAdViewHandler.bidLoad(paramMaxAdapterResponseParameters.getBidResponse());
      return;
    } 
    MBBannerView mBBannerView = new MBBannerView(getContext((Activity)mBBidNativeHandler));
    this.mbBannerView = mBBannerView;
    mBBannerView.init(toBannerSize((MaxAdFormat)nativeAdViewListener), str2, this.mbUnitId);
    this.mbBannerView.setAllowShowCloseBtn(false);
    this.mbBannerView.setRefreshTime(0);
    this.mbBannerView.setBannerAdListener(new BannerAdListener() {
          public void closeFullScreen(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad collapsed");
            listener.onAdViewAdCollapsed();
          }
          
          public void onClick(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad clicked");
            listener.onAdViewAdClicked();
          }
          
          public void onCloseBanner(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad closed");
          }
          
          public void onLeaveApp(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad will leave application");
          }
          
          public void onLoadFailed(MBridgeIds param1MBridgeIds, String param1String) {
            MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Banner ad failed to load: ");
            stringBuilder.append(param1String);
            stringBuilder.append(" for: ");
            stringBuilder.append(param1MBridgeIds);
            mintegralMediationAdapter.log(stringBuilder.toString());
            listener.onAdViewAdLoadFailed(MintegralMediationAdapter.toMaxError(param1String));
          }
          
          public void onLoadSuccessed(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Banner ad loaded for: ");
            stringBuilder.append(param1MBridgeIds);
            mintegralMediationAdapter.log(stringBuilder.toString());
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(MintegralMediationAdapter.this.mbBannerView.getRequestId())) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", MintegralMediationAdapter.this.mbBannerView.getRequestId());
              listener.onAdViewAdLoaded((View)MintegralMediationAdapter.this.mbBannerView, bundle);
              return;
            } 
            listener.onAdViewAdLoaded((View)MintegralMediationAdapter.this.mbBannerView);
          }
          
          public void onLogImpression(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad displayed");
            listener.onAdViewAdDisplayed();
          }
          
          public void showFullScreen(MBridgeIds param1MBridgeIds) {
            MintegralMediationAdapter.this.log("Banner ad expanded");
            listener.onAdViewAdExpanded();
          }
        });
    if (AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse())) {
      this.mbBannerView.loadFromBid(paramMaxAdapterResponseParameters.getBidResponse());
      return;
    } 
    this.mbBannerView.load();
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    MBBidInterstitialVideoHandler mBBidInterstitialVideoHandler;
    byte b;
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().containsKey("is_muted");
    if (paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_muted")) {
      b = 1;
    } else {
      b = 2;
    } 
    this.mbUnitId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    String str = BundleUtils.getString("placement_id", paramMaxAdapterResponseParameters.getServerParameters());
    MintegralMediationAdapterRouter mintegralMediationAdapterRouter = router;
    mintegralMediationAdapterRouter.addInterstitialAdapter((MaxAdapter)this, paramMaxInterstitialAdapterListener, this.mbUnitId);
    if (!TextUtils.isEmpty(paramMaxAdapterResponseParameters.getBidResponse())) {
      StringBuilder stringBuilder1 = new StringBuilder("Loading bidding interstitial ad for unit id: ");
      stringBuilder1.append(this.mbUnitId);
      stringBuilder1.append(" and placement id: ");
      stringBuilder1.append(str);
      stringBuilder1.append("...");
      log(stringBuilder1.toString());
      Map<String, MBBidInterstitialVideoHandler> map1 = mbBidInterstitialVideoHandlers;
      if (map1.containsKey(this.mbUnitId)) {
        this.mbBidInterstitialVideoHandler = map1.get(this.mbUnitId);
      } else {
        mBBidInterstitialVideoHandler = new MBBidInterstitialVideoHandler((Context)paramActivity, str, this.mbUnitId);
        this.mbBidInterstitialVideoHandler = mBBidInterstitialVideoHandler;
        map1.put(this.mbUnitId, mBBidInterstitialVideoHandler);
      } 
      this.mbBidInterstitialVideoHandler.setInterstitialVideoListener(mintegralMediationAdapterRouter.getInterstitialListener());
      if (bool)
        this.mbBidInterstitialVideoHandler.playVideoMute(b); 
      this.mbBidInterstitialVideoHandler.loadFromBid(paramMaxAdapterResponseParameters.getBidResponse());
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Loading mediated interstitial ad for unit id: ");
    stringBuilder.append(this.mbUnitId);
    stringBuilder.append(" and placement id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    Map<String, MBInterstitialVideoHandler> map = mbInterstitialVideoHandlers;
    if (map.containsKey(this.mbUnitId)) {
      this.mbInterstitialVideoHandler = map.get(this.mbUnitId);
    } else {
      MBInterstitialVideoHandler mBInterstitialVideoHandler = new MBInterstitialVideoHandler((Context)mBBidInterstitialVideoHandler, str, this.mbUnitId);
      this.mbInterstitialVideoHandler = mBInterstitialVideoHandler;
      map.put(this.mbUnitId, mBInterstitialVideoHandler);
    } 
    this.mbInterstitialVideoHandler.setInterstitialVideoListener(mintegralMediationAdapterRouter.getInterstitialListener());
    if (this.mbInterstitialVideoHandler.isReady()) {
      log("A mediated interstitial ad is ready already");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(this.mbInterstitialVideoHandler.getRequestId())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.mbInterstitialVideoHandler.getRequestId());
        mintegralMediationAdapterRouter.onAdLoaded(this.mbUnitId, bundle);
        return;
      } 
      mintegralMediationAdapterRouter.onAdLoaded(this.mbUnitId);
      return;
    } 
    if (bool)
      this.mbInterstitialVideoHandler.playVideoMute(b); 
    this.mbInterstitialVideoHandler.load();
  }
  
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    this.mbUnitId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    String str = BundleUtils.getString("placement_id", paramMaxAdapterResponseParameters.getServerParameters());
    StringBuilder stringBuilder = new StringBuilder("Loading bidding native ad for unit id: ");
    stringBuilder.append(this.mbUnitId);
    stringBuilder.append(" and placement id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    Map<String, Integer> map = MBBidNativeHandler.getNativeProperties(str, this.mbUnitId);
    map.put("ad_num", Integer.valueOf(1));
    map.put("videoSupport", Boolean.valueOf(true));
    NativeAdListener nativeAdListener = new NativeAdListener(paramMaxAdapterResponseParameters, getContext(paramActivity), paramMaxNativeAdAdapterListener);
    MBBidNativeHandler mBBidNativeHandler = new MBBidNativeHandler(map, getContext(paramActivity));
    this.mbBidNativeHandler = mBBidNativeHandler;
    mBBidNativeHandler.setAdListener(nativeAdListener);
    this.mbBidNativeHandler.bidLoad(paramMaxAdapterResponseParameters.getBidResponse());
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    MBBidRewardVideoHandler mBBidRewardVideoHandler;
    byte b;
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().containsKey("is_muted");
    if (paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_muted")) {
      b = 1;
    } else {
      b = 2;
    } 
    this.mbUnitId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    String str = BundleUtils.getString("placement_id", paramMaxAdapterResponseParameters.getServerParameters());
    MintegralMediationAdapterRouter mintegralMediationAdapterRouter = router;
    mintegralMediationAdapterRouter.addRewardedAdapter((MaxAdapter)this, paramMaxRewardedAdapterListener, this.mbUnitId);
    if (!TextUtils.isEmpty(paramMaxAdapterResponseParameters.getBidResponse())) {
      StringBuilder stringBuilder1 = new StringBuilder("Loading bidding rewarded ad for unit id: ");
      stringBuilder1.append(this.mbUnitId);
      stringBuilder1.append(" and placement id: ");
      stringBuilder1.append(str);
      stringBuilder1.append("...");
      log(stringBuilder1.toString());
      Map<String, MBBidRewardVideoHandler> map1 = mbBidRewardVideoHandlers;
      if (map1.containsKey(this.mbUnitId)) {
        this.mbBidRewardVideoHandler = map1.get(this.mbUnitId);
      } else {
        mBBidRewardVideoHandler = new MBBidRewardVideoHandler((Context)paramActivity, str, this.mbUnitId);
        this.mbBidRewardVideoHandler = mBBidRewardVideoHandler;
        map1.put(this.mbUnitId, mBBidRewardVideoHandler);
      } 
      this.mbBidRewardVideoHandler.setRewardVideoListener((g)mintegralMediationAdapterRouter.getRewardedListener());
      if (bool)
        this.mbBidRewardVideoHandler.playVideoMute(b); 
      this.mbBidRewardVideoHandler.loadFromBid(paramMaxAdapterResponseParameters.getBidResponse());
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Loading mediated rewarded ad for unit id: ");
    stringBuilder.append(this.mbUnitId);
    stringBuilder.append(" and placement id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    Map<String, MBRewardVideoHandler> map = mbRewardVideoHandlers;
    if (map.containsKey(this.mbUnitId)) {
      this.mbRewardVideoHandler = map.get(this.mbUnitId);
    } else {
      MBRewardVideoHandler mBRewardVideoHandler = new MBRewardVideoHandler((Context)mBBidRewardVideoHandler, str, this.mbUnitId);
      this.mbRewardVideoHandler = mBRewardVideoHandler;
      map.put(this.mbUnitId, mBRewardVideoHandler);
    } 
    this.mbRewardVideoHandler.setRewardVideoListener((g)mintegralMediationAdapterRouter.getRewardedListener());
    if (this.mbRewardVideoHandler.isReady()) {
      log("A mediated rewarded ad is ready already");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(this.mbRewardVideoHandler.getRequestId())) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.mbRewardVideoHandler.getRequestId());
        mintegralMediationAdapterRouter.onAdLoaded(this.mbUnitId, bundle);
        return;
      } 
      mintegralMediationAdapterRouter.onAdLoaded(this.mbUnitId);
      return;
    } 
    if (bool)
      this.mbRewardVideoHandler.playVideoMute(b); 
    this.mbRewardVideoHandler.load();
  }
  
  public void onDestroy() {
    MBInterstitialVideoHandler mBInterstitialVideoHandler = this.mbInterstitialVideoHandler;
    if (mBInterstitialVideoHandler != null) {
      mBInterstitialVideoHandler.setInterstitialVideoListener(null);
      this.mbInterstitialVideoHandler = null;
    } 
    MBBidInterstitialVideoHandler mBBidInterstitialVideoHandler = this.mbBidInterstitialVideoHandler;
    if (mBBidInterstitialVideoHandler != null) {
      mBBidInterstitialVideoHandler.setInterstitialVideoListener(null);
      this.mbBidInterstitialVideoHandler = null;
    } 
    MBRewardVideoHandler mBRewardVideoHandler = this.mbRewardVideoHandler;
    if (mBRewardVideoHandler != null) {
      mBRewardVideoHandler.setRewardVideoListener(null);
      this.mbRewardVideoHandler = null;
    } 
    MBBidRewardVideoHandler mBBidRewardVideoHandler = this.mbBidRewardVideoHandler;
    if (mBBidRewardVideoHandler != null) {
      mBBidRewardVideoHandler.setRewardVideoListener(null);
      this.mbBidRewardVideoHandler = null;
    } 
    MBBannerView mBBannerView = this.mbBannerView;
    if (mBBannerView != null) {
      mBBannerView.release();
      this.mbBannerView = null;
    } 
    MBBidNativeHandler mBBidNativeHandler = this.mbBidNativeHandler;
    if (mBBidNativeHandler != null) {
      mBBidNativeHandler.unregisterView((View)this.nativeAdContainer, this.clickableViews, this.nativeAdCampaign);
      this.mbBidNativeHandler.bidRelease();
      this.mbBidNativeHandler.setAdListener(null);
      this.mbBidNativeHandler = null;
    } 
    mBBidNativeHandler = this.mbBidNativeAdViewHandler;
    if (mBBidNativeHandler != null) {
      mBBidNativeHandler.unregisterView((View)this.nativeAdContainer, this.clickableViews, this.nativeAdCampaign);
      this.mbBidNativeAdViewHandler.bidRelease();
      this.mbBidNativeAdViewHandler.setAdListener(null);
      this.mbBidNativeAdViewHandler = null;
    } 
    MaxNativeAd maxNativeAd = this.nativeAd;
    if (maxNativeAd != null) {
      if (maxNativeAd.getMediaView() instanceof MBMediaView)
        ((MBMediaView)this.nativeAd.getMediaView()).destory(); 
      this.nativeAd = null;
    } 
    this.nativeAdCampaign = null;
    router.removeAdapter((MaxAdapter)this, this.mbUnitId);
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    MintegralMediationAdapterRouter mintegralMediationAdapterRouter = router;
    mintegralMediationAdapterRouter.addShowingAdapter((MaxAdapter)this);
    MBBidInterstitialVideoHandler mBBidInterstitialVideoHandler = this.mbBidInterstitialVideoHandler;
    if (mBBidInterstitialVideoHandler != null && mBBidInterstitialVideoHandler.isBidReady()) {
      log("Showing bidding interstitial...");
      this.mbBidInterstitialVideoHandler.showFromBid();
      return;
    } 
    MBInterstitialVideoHandler mBInterstitialVideoHandler = this.mbInterstitialVideoHandler;
    if (mBInterstitialVideoHandler != null && mBInterstitialVideoHandler.isReady()) {
      log("Showing mediated interstitial...");
      this.mbInterstitialVideoHandler.show();
      return;
    } 
    log("Unable to show interstitial - no ad loaded...");
    mintegralMediationAdapterRouter.onAdDisplayFailed(this.mbUnitId, new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    MintegralMediationAdapterRouter mintegralMediationAdapterRouter = router;
    mintegralMediationAdapterRouter.addShowingAdapter((MaxAdapter)this);
    configureReward(paramMaxAdapterResponseParameters);
    Bundle bundle = paramMaxAdapterResponseParameters.getServerParameters();
    String str1 = bundle.getString("reward_id", "");
    String str2 = bundle.getString("user_id", "");
    MBBidRewardVideoHandler mBBidRewardVideoHandler = this.mbBidRewardVideoHandler;
    if (mBBidRewardVideoHandler != null && mBBidRewardVideoHandler.isBidReady()) {
      log("Showing bidding rewarded ad...");
      this.mbBidRewardVideoHandler.showFromBid(str1, str2);
      return;
    } 
    MBRewardVideoHandler mBRewardVideoHandler = this.mbRewardVideoHandler;
    if (mBRewardVideoHandler != null && mBRewardVideoHandler.isReady()) {
      log("Showing mediated rewarded ad...");
      this.mbRewardVideoHandler.show(str1, str2);
      return;
    } 
    log("Unable to show rewarded ad - no ad loaded...");
    mintegralMediationAdapterRouter.onAdDisplayFailed(this.mbUnitId, new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
  }
  
  private class MaxMintegralNativeAd extends MaxNativeAd {
    public MaxMintegralNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public boolean prepareForInteraction(List<View> param1List, ViewGroup param1ViewGroup) {
      Campaign campaign = MintegralMediationAdapter.this.nativeAdCampaign;
      if (campaign == null) {
        MintegralMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return false;
      } 
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Preparing views for interaction: ");
      stringBuilder.append(param1List);
      stringBuilder.append(" with container: ");
      stringBuilder.append(param1ViewGroup);
      mintegralMediationAdapter.d(stringBuilder.toString());
      if (getFormat() == MaxAdFormat.NATIVE) {
        if (MintegralMediationAdapter.this.mbBidNativeHandler != null) {
          MintegralMediationAdapter.this.mbBidNativeHandler.registerView((View)param1ViewGroup, param1List, campaign);
        } else {
          MintegralMediationAdapter.this.e("Failed to register native ad views: mbBidNativeHandler is null.");
        } 
      } else if (MintegralMediationAdapter.this.mbBidNativeAdViewHandler != null) {
        MintegralMediationAdapter.this.mbBidNativeAdViewHandler.registerView((View)param1ViewGroup, param1List, campaign);
      } else {
        MintegralMediationAdapter.this.e("Failed to register native ad views: mbBidNativeAdViewHandler is null.");
      } 
      MintegralMediationAdapter.access$2002(MintegralMediationAdapter.this, param1ViewGroup);
      MintegralMediationAdapter.access$2102(MintegralMediationAdapter.this, param1List);
      return true;
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      prepareForInteraction(MintegralMediationAdapter.this.getClickableViews(param1MaxNativeAdView), (ViewGroup)param1MaxNativeAdView);
    }
  }
  
  private static class MintegralMediationAdapterRouter extends MediationAdapterRouter {
    private final InterstitialVideoListener interstitialVideoListener = new InterstitialVideoListener() {
        public void onAdClose(MBridgeIds param2MBridgeIds, RewardInfo param2RewardInfo) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial hidden");
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdHidden(param2MBridgeIds.getUnitId());
        }
        
        public void onAdCloseWithIVReward(MBridgeIds param2MBridgeIds, RewardInfo param2RewardInfo) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial with reward hidden");
        }
        
        public void onAdShow(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial displayed");
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdDisplayed(param2MBridgeIds.getUnitId());
        }
        
        public void onEndcardShow(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial endcard shown");
        }
        
        public void onLoadSuccess(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Interstitial successfully loaded but video still needs to be downloaded for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
        }
        
        public void onShowFail(MBridgeIds param2MBridgeIds, String param2String) {
          MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", 0, param2String);
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Interstitial failed to show: ");
          stringBuilder.append(maxAdapterError);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdDisplayFailed(param2MBridgeIds.getUnitId(), maxAdapterError);
        }
        
        public void onVideoAdClicked(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial clicked");
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdClicked(param2MBridgeIds.getUnitId());
        }
        
        public void onVideoComplete(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Interstitial video completed");
        }
        
        public void onVideoLoadFail(MBridgeIds param2MBridgeIds, String param2String) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Interstitial failed to load: ");
          stringBuilder.append(param2String);
          stringBuilder.append(" for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoadFailed(param2MBridgeIds.getUnitId(), MintegralMediationAdapter.toMaxError(param2String));
        }
        
        public void onVideoLoadSuccess(MBridgeIds param2MBridgeIds) {
          String str1;
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Interstitial successfully loaded and video has been downloaded for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          String str2 = param2MBridgeIds.getUnitId();
          MBInterstitialVideoHandler mBInterstitialVideoHandler = (MBInterstitialVideoHandler)MintegralMediationAdapter.mbInterstitialVideoHandlers.get(str2);
          MBBidInterstitialVideoHandler mBBidInterstitialVideoHandler = (MBBidInterstitialVideoHandler)MintegralMediationAdapter.mbBidInterstitialVideoHandlers.get(str2);
          if (mBBidInterstitialVideoHandler != null) {
            str1 = mBBidInterstitialVideoHandler.getRequestId();
          } else {
            str1 = str1.getRequestId();
          } 
          if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(str1)) {
            Bundle bundle = new Bundle(1);
            bundle.putString("creative_id", str1);
            MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoaded(str2, bundle);
            return;
          } 
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoaded(str2);
        }
      };
    
    private final RewardVideoListener rewardVideoListener = new RewardVideoListener() {
        public void onAdClose(MBridgeIds param2MBridgeIds, RewardInfo param2RewardInfo) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Rewarded ad hidden");
          String str = param2MBridgeIds.getUnitId();
          if (param2RewardInfo.isCompleteView()) {
            MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onRewardedAdVideoCompleted(str);
            MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
            mintegralMediationAdapterRouter.onUserRewarded(str, mintegralMediationAdapterRouter.getReward(str));
          } else if (MintegralMediationAdapter.MintegralMediationAdapterRouter.this.shouldAlwaysRewardUser(str)) {
            MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
            mintegralMediationAdapterRouter.onUserRewarded(str, mintegralMediationAdapterRouter.getReward(str));
          } 
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdHidden(str);
        }
        
        public void onAdShow(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Rewarded ad displayed");
          String str = param2MBridgeIds.getUnitId();
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdDisplayed(str);
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onRewardedAdVideoStarted(str);
        }
        
        public void onEndcardShow(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Rewarded ad endcard shown");
        }
        
        public void onLoadSuccess(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Rewarded ad successfully loaded but video still needs to be downloaded for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
        }
        
        public void onShowFail(MBridgeIds param2MBridgeIds, String param2String) {
          MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", 0, param2String);
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Rewarded ad failed to show: ");
          stringBuilder.append(maxAdapterError);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdDisplayFailed(param2MBridgeIds.getUnitId(), maxAdapterError);
        }
        
        public void onVideoAdClicked(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Rewarded ad clicked");
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdClicked(param2MBridgeIds.getUnitId());
        }
        
        public void onVideoComplete(MBridgeIds param2MBridgeIds) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.log("Rewarded ad video completed");
        }
        
        public void onVideoLoadFail(MBridgeIds param2MBridgeIds, String param2String) {
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Rewarded ad failed to load: ");
          stringBuilder.append(param2String);
          stringBuilder.append(" for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoadFailed(param2MBridgeIds.getUnitId(), MintegralMediationAdapter.toMaxError(param2String));
        }
        
        public void onVideoLoadSuccess(MBridgeIds param2MBridgeIds) {
          String str1;
          MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = MintegralMediationAdapter.MintegralMediationAdapterRouter.this;
          StringBuilder stringBuilder = new StringBuilder("Rewarded ad successfully loaded and video has been downloaded for: ");
          stringBuilder.append(param2MBridgeIds);
          mintegralMediationAdapterRouter.log(stringBuilder.toString());
          String str2 = param2MBridgeIds.getUnitId();
          MBRewardVideoHandler mBRewardVideoHandler = (MBRewardVideoHandler)MintegralMediationAdapter.mbRewardVideoHandlers.get(str2);
          MBBidRewardVideoHandler mBBidRewardVideoHandler = (MBBidRewardVideoHandler)MintegralMediationAdapter.mbBidRewardVideoHandlers.get(str2);
          if (mBBidRewardVideoHandler != null) {
            str1 = mBBidRewardVideoHandler.getRequestId();
          } else {
            str1 = str1.getRequestId();
          } 
          if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(str1)) {
            Bundle bundle = new Bundle(1);
            bundle.putString("creative_id", str1);
            MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoaded(str2, bundle);
            return;
          } 
          MintegralMediationAdapter.MintegralMediationAdapterRouter.this.onAdLoaded(str2);
        }
      };
    
    InterstitialVideoListener getInterstitialListener() {
      return this.interstitialVideoListener;
    }
    
    RewardVideoListener getRewardedListener() {
      return this.rewardVideoListener;
    }
    
    void initialize(MaxAdapterInitializationParameters param1MaxAdapterInitializationParameters, Activity param1Activity, MaxAdapter.OnCompletionListener param1OnCompletionListener) {}
  }
  
  class null implements InterstitialVideoListener {
    public void onAdClose(MBridgeIds param1MBridgeIds, RewardInfo param1RewardInfo) {
      this.this$0.log("Interstitial hidden");
      this.this$0.onAdHidden(param1MBridgeIds.getUnitId());
    }
    
    public void onAdCloseWithIVReward(MBridgeIds param1MBridgeIds, RewardInfo param1RewardInfo) {
      this.this$0.log("Interstitial with reward hidden");
    }
    
    public void onAdShow(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Interstitial displayed");
      this.this$0.onAdDisplayed(param1MBridgeIds.getUnitId());
    }
    
    public void onEndcardShow(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Interstitial endcard shown");
    }
    
    public void onLoadSuccess(MBridgeIds param1MBridgeIds) {
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Interstitial successfully loaded but video still needs to be downloaded for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
    }
    
    public void onShowFail(MBridgeIds param1MBridgeIds, String param1String) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", 0, param1String);
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Interstitial failed to show: ");
      stringBuilder.append(maxAdapterError);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      this.this$0.onAdDisplayFailed(param1MBridgeIds.getUnitId(), maxAdapterError);
    }
    
    public void onVideoAdClicked(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Interstitial clicked");
      this.this$0.onAdClicked(param1MBridgeIds.getUnitId());
    }
    
    public void onVideoComplete(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Interstitial video completed");
    }
    
    public void onVideoLoadFail(MBridgeIds param1MBridgeIds, String param1String) {
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Interstitial failed to load: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      this.this$0.onAdLoadFailed(param1MBridgeIds.getUnitId(), MintegralMediationAdapter.toMaxError(param1String));
    }
    
    public void onVideoLoadSuccess(MBridgeIds param1MBridgeIds) {
      String str1;
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Interstitial successfully loaded and video has been downloaded for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      String str2 = param1MBridgeIds.getUnitId();
      MBInterstitialVideoHandler mBInterstitialVideoHandler = (MBInterstitialVideoHandler)MintegralMediationAdapter.mbInterstitialVideoHandlers.get(str2);
      MBBidInterstitialVideoHandler mBBidInterstitialVideoHandler = (MBBidInterstitialVideoHandler)MintegralMediationAdapter.mbBidInterstitialVideoHandlers.get(str2);
      if (mBBidInterstitialVideoHandler != null) {
        str1 = mBBidInterstitialVideoHandler.getRequestId();
      } else {
        str1 = str1.getRequestId();
      } 
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(str1)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", str1);
        this.this$0.onAdLoaded(str2, bundle);
        return;
      } 
      this.this$0.onAdLoaded(str2);
    }
  }
  
  class null implements RewardVideoListener {
    public void onAdClose(MBridgeIds param1MBridgeIds, RewardInfo param1RewardInfo) {
      this.this$0.log("Rewarded ad hidden");
      String str = param1MBridgeIds.getUnitId();
      if (param1RewardInfo.isCompleteView()) {
        this.this$0.onRewardedAdVideoCompleted(str);
        MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
        mintegralMediationAdapterRouter.onUserRewarded(str, mintegralMediationAdapterRouter.getReward(str));
      } else if (this.this$0.shouldAlwaysRewardUser(str)) {
        MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
        mintegralMediationAdapterRouter.onUserRewarded(str, mintegralMediationAdapterRouter.getReward(str));
      } 
      this.this$0.onAdHidden(str);
    }
    
    public void onAdShow(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Rewarded ad displayed");
      String str = param1MBridgeIds.getUnitId();
      this.this$0.onAdDisplayed(str);
      this.this$0.onRewardedAdVideoStarted(str);
    }
    
    public void onEndcardShow(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Rewarded ad endcard shown");
    }
    
    public void onLoadSuccess(MBridgeIds param1MBridgeIds) {
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad successfully loaded but video still needs to be downloaded for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
    }
    
    public void onShowFail(MBridgeIds param1MBridgeIds, String param1String) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", 0, param1String);
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad failed to show: ");
      stringBuilder.append(maxAdapterError);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      this.this$0.onAdDisplayFailed(param1MBridgeIds.getUnitId(), maxAdapterError);
    }
    
    public void onVideoAdClicked(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Rewarded ad clicked");
      this.this$0.onAdClicked(param1MBridgeIds.getUnitId());
    }
    
    public void onVideoComplete(MBridgeIds param1MBridgeIds) {
      this.this$0.log("Rewarded ad video completed");
    }
    
    public void onVideoLoadFail(MBridgeIds param1MBridgeIds, String param1String) {
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad failed to load: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      this.this$0.onAdLoadFailed(param1MBridgeIds.getUnitId(), MintegralMediationAdapter.toMaxError(param1String));
    }
    
    public void onVideoLoadSuccess(MBridgeIds param1MBridgeIds) {
      String str1;
      MintegralMediationAdapter.MintegralMediationAdapterRouter mintegralMediationAdapterRouter = this.this$0;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad successfully loaded and video has been downloaded for: ");
      stringBuilder.append(param1MBridgeIds);
      mintegralMediationAdapterRouter.log(stringBuilder.toString());
      String str2 = param1MBridgeIds.getUnitId();
      MBRewardVideoHandler mBRewardVideoHandler = (MBRewardVideoHandler)MintegralMediationAdapter.mbRewardVideoHandlers.get(str2);
      MBBidRewardVideoHandler mBBidRewardVideoHandler = (MBBidRewardVideoHandler)MintegralMediationAdapter.mbBidRewardVideoHandlers.get(str2);
      if (mBBidRewardVideoHandler != null) {
        str1 = mBBidRewardVideoHandler.getRequestId();
      } else {
        str1 = str1.getRequestId();
      } 
      if (AppLovinSdk.VERSION_CODE >= 9150000 && !TextUtils.isEmpty(str1)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", str1);
        this.this$0.onAdLoaded(str2, bundle);
        return;
      } 
      this.this$0.onAdLoaded(str2);
    }
  }
  
  private class NativeAdListener implements NativeListener.NativeAdListener, OnMBMediaViewListener {
    private final Context context;
    
    private final MaxNativeAdAdapterListener listener;
    
    private final MaxAdapterResponseParameters parameters;
    
    private final String placementId;
    
    private final String unitId;
    
    NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.parameters = param1MaxAdapterResponseParameters;
      this.context = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
      this.unitId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.placementId = BundleUtils.getString("placement_id", param1MaxAdapterResponseParameters.getServerParameters());
    }
    
    private void processNativeAd(final Campaign campaign) {
      MintegralMediationAdapter.this.getExecutorServiceToUse().submit(new Runnable() {
            public void run() {
              final String finalIconImage;
              String str3 = campaign.getIconUrl();
              String str2 = campaign.getImageUrl();
              Future<Drawable> future = MintegralMediationAdapter.this.createDrawableFuture(str3, MintegralMediationAdapter.NativeAdListener.this.context.getResources());
              final MaxNativeAd.MaxNativeAdImage mainImage = new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2));
              str2 = null;
              try {
              
              } finally {
                future = null;
                MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
                StringBuilder stringBuilder = new StringBuilder("Failed to fetch icon image from URL: ");
                stringBuilder.append(str3);
                mintegralMediationAdapter.log(stringBuilder.toString(), (Throwable)future);
              } 
              AppLovinSdkUtils.runOnUiThread(new Runnable() {
                    public void run() {
                      MBMediaView mBMediaView = new MBMediaView(MintegralMediationAdapter.NativeAdListener.this.context);
                      mBMediaView.setNativeAd(campaign);
                      mBMediaView.setOnMediaViewListener(MintegralMediationAdapter.NativeAdListener.this);
                      MBAdChoice mBAdChoice = new MBAdChoice(MintegralMediationAdapter.NativeAdListener.this.context);
                      mBAdChoice.setCampaign(campaign);
                      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
                      if (AppLovinSdk.VERSION_CODE >= 11040399)
                        builder.setMainImage(mainImage); 
                      if (AppLovinSdk.VERSION_CODE >= 11070000)
                        builder.setStarRating(Double.valueOf(campaign.getRating())); 
                      MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
                      MintegralMediationAdapter.NativeAdListener.this.listener.onNativeAdLoaded(MintegralMediationAdapter.this.nativeAd, null);
                    }
                  });
            }
          });
    }
    
    public void onAdClick(Campaign param1Campaign) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad clicked for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdClicked();
    }
    
    public void onAdFramesLoaded(List<Frame> param1List) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad frames loaded for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdLoadError(String param1String) {
      MaxAdapterError maxAdapterError = MintegralMediationAdapter.toMaxError(param1String);
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad failed to load for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      stringBuilder.append(" with error: ");
      stringBuilder.append(maxAdapterError);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoaded(List<Campaign> param1List, int param1Int) {
      MintegralMediationAdapter mintegralMediationAdapter2;
      MintegralMediationAdapter mintegralMediationAdapter1;
      if (param1List == null || param1List.isEmpty()) {
        mintegralMediationAdapter2 = MintegralMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Native ad failed to load for unit id: ");
        stringBuilder1.append(this.unitId);
        stringBuilder1.append(" placement id: ");
        stringBuilder1.append(this.placementId);
        stringBuilder1.append(" with error: no fill");
        mintegralMediationAdapter2.log(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      Campaign campaign = mintegralMediationAdapter2.get(0);
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.parameters.getServerParameters())) && TextUtils.isEmpty(campaign.getAppName())) {
        mintegralMediationAdapter1 = MintegralMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Native ad failed to load for unit id: ");
        stringBuilder1.append(this.unitId);
        stringBuilder1.append(" placement id: ");
        stringBuilder1.append(this.placementId);
        stringBuilder1.append(" with error: missing required assets");
        mintegralMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      MintegralMediationAdapter.access$602(MintegralMediationAdapter.this, (Campaign)mintegralMediationAdapter1);
      MintegralMediationAdapter mintegralMediationAdapter3 = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad loaded for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter3.log(stringBuilder.toString());
      processNativeAd((Campaign)mintegralMediationAdapter1);
    }
    
    public void onEnterFullscreen() {
      MintegralMediationAdapter.this.log("Media view entered fullscreen");
    }
    
    public void onExitFullscreen() {
      MintegralMediationAdapter.this.log("Media view exited fullscreen");
    }
    
    public void onFinishRedirection(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view finished redirection with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onLoggingImpression(int param1Int) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad shown for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onRedirectionFailed(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view redirection failed with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onStartRedirection(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view started redirection with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onVideoAdClicked(Campaign param1Campaign) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view clicked for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdClicked();
    }
    
    public void onVideoStart() {
      MintegralMediationAdapter.this.log("Media view video started");
    }
  }
  
  class null implements Runnable {
    public void run() {
      final String finalIconImage;
      String str3 = campaign.getIconUrl();
      String str2 = campaign.getImageUrl();
      Future<Drawable> future = MintegralMediationAdapter.this.createDrawableFuture(str3, this.this$1.context.getResources());
      final MaxNativeAd.MaxNativeAdImage mainImage = new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2));
      str2 = null;
      try {
      
      } finally {
        future = null;
        MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
        StringBuilder stringBuilder = new StringBuilder("Failed to fetch icon image from URL: ");
        stringBuilder.append(str3);
        mintegralMediationAdapter.log(stringBuilder.toString(), (Throwable)future);
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MBMediaView mBMediaView = new MBMediaView(this.this$2.this$1.context);
              mBMediaView.setNativeAd(campaign);
              mBMediaView.setOnMediaViewListener(this.this$2.this$1);
              MBAdChoice mBAdChoice = new MBAdChoice(this.this$2.this$1.context);
              mBAdChoice.setCampaign(campaign);
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
              if (AppLovinSdk.VERSION_CODE >= 11040399)
                builder.setMainImage(mainImage); 
              if (AppLovinSdk.VERSION_CODE >= 11070000)
                builder.setStarRating(Double.valueOf(campaign.getRating())); 
              MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
              this.this$2.this$1.listener.onNativeAdLoaded(MintegralMediationAdapter.this.nativeAd, null);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MBMediaView mBMediaView = new MBMediaView(this.this$2.this$1.context);
      mBMediaView.setNativeAd(campaign);
      mBMediaView.setOnMediaViewListener(this.this$2.this$1);
      MBAdChoice mBAdChoice = new MBAdChoice(this.this$2.this$1.context);
      mBAdChoice.setCampaign(campaign);
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
      if (AppLovinSdk.VERSION_CODE >= 11040399)
        builder.setMainImage(mainImage); 
      if (AppLovinSdk.VERSION_CODE >= 11070000)
        builder.setStarRating(Double.valueOf(campaign.getRating())); 
      MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
      this.this$2.this$1.listener.onNativeAdLoaded(MintegralMediationAdapter.this.nativeAd, null);
    }
  }
  
  private class NativeAdViewListener implements NativeListener.NativeAdListener, OnMBMediaViewListener {
    private final MaxAdFormat adFormat;
    
    private final Context context;
    
    private final MaxAdViewAdapterListener listener;
    
    private final String placementId;
    
    private final Bundle serverParameters;
    
    private final String unitId;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Context param1Context, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.adFormat = param1MaxAdFormat;
      this.context = param1Context;
      this.listener = param1MaxAdViewAdapterListener;
      this.unitId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.placementId = BundleUtils.getString("placement_id", param1MaxAdapterResponseParameters.getServerParameters());
    }
    
    public void onAdClick(Campaign param1Campaign) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdFramesLoaded(List<Frame> param1List) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad frames loaded for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdLoadError(String param1String) {
      MaxAdapterError maxAdapterError = MintegralMediationAdapter.toMaxError(param1String);
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to load for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      stringBuilder.append(" with error: ");
      stringBuilder.append(maxAdapterError);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdLoaded(List<Campaign> param1List, int param1Int) {
      MintegralMediationAdapter mintegralMediationAdapter2;
      final MintegralMediationAdapter campaign;
      if (param1List == null || param1List.isEmpty()) {
        mintegralMediationAdapter2 = MintegralMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad failed to load for unit id: ");
        stringBuilder1.append(this.unitId);
        stringBuilder1.append(" placement id: ");
        stringBuilder1.append(this.placementId);
        stringBuilder1.append(" with error: no fill");
        mintegralMediationAdapter2.log(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      Campaign campaign = mintegralMediationAdapter2.get(0);
      if (TextUtils.isEmpty(campaign.getAppName())) {
        mintegralMediationAdapter1 = MintegralMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad failed to load for unit id: ");
        stringBuilder1.append(this.unitId);
        stringBuilder1.append(" placement id: ");
        stringBuilder1.append(this.placementId);
        stringBuilder1.append(" with error: missing required assets");
        mintegralMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      MintegralMediationAdapter.access$602(MintegralMediationAdapter.this, (Campaign)mintegralMediationAdapter1);
      MintegralMediationAdapter mintegralMediationAdapter3 = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter3.log(stringBuilder.toString());
      MintegralMediationAdapter.this.getExecutorServiceToUse().submit(new Runnable() {
            public void run() {
              final String finalIconImage;
              String str3 = campaign.getIconUrl();
              String str2 = campaign.getImageUrl();
              Future<Drawable> future = MintegralMediationAdapter.this.createDrawableFuture(str3, MintegralMediationAdapter.NativeAdViewListener.this.context.getResources());
              new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2));
              str2 = null;
              try {
              
              } finally {
                future = null;
                MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
                StringBuilder stringBuilder = new StringBuilder("Failed to fetch icon image from URL: ");
                stringBuilder.append(str3);
                mintegralMediationAdapter.log(stringBuilder.toString(), (Throwable)future);
              } 
              AppLovinSdkUtils.runOnUiThread(new Runnable() {
                    public void run() {
                      MBMediaView mBMediaView = new MBMediaView(MintegralMediationAdapter.NativeAdViewListener.this.context);
                      mBMediaView.setNativeAd(campaign);
                      mBMediaView.setOnMediaViewListener(MintegralMediationAdapter.NativeAdViewListener.this);
                      MBAdChoice mBAdChoice = new MBAdChoice(MintegralMediationAdapter.NativeAdViewListener.this.context);
                      mBAdChoice.setCampaign(campaign);
                      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MintegralMediationAdapter.NativeAdViewListener.this.adFormat).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
                      MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
                      String str = BundleUtils.getString("template", "", MintegralMediationAdapter.NativeAdViewListener.this.serverParameters);
                      MaxNativeAdView maxNativeAdView = MintegralMediationAdapter.this.createMaxNativeAdViewWithNativeAd(MintegralMediationAdapter.this.nativeAd, str, MintegralMediationAdapter.NativeAdViewListener.this.context);
                      MintegralMediationAdapter.this.nativeAd.prepareForInteraction(MintegralMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
                      MintegralMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)maxNativeAdView);
                    }
                  });
            }
          });
    }
    
    public void onEnterFullscreen() {
      MintegralMediationAdapter.this.log("Media view entered fullscreen");
    }
    
    public void onExitFullscreen() {
      MintegralMediationAdapter.this.log("Media view exited fullscreen");
    }
    
    public void onFinishRedirection(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view finished redirection with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onLoggingImpression(int param1Int) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed(null);
    }
    
    public void onRedirectionFailed(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view redirection failed with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onStartRedirection(Campaign param1Campaign, String param1String) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view started redirection with url: ");
      stringBuilder.append(param1String);
      mintegralMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onVideoAdClicked(Campaign param1Campaign) {
      MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Media view clicked for unit id: ");
      stringBuilder.append(this.unitId);
      stringBuilder.append(" placement id: ");
      stringBuilder.append(this.placementId);
      mintegralMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onVideoStart() {
      MintegralMediationAdapter.this.log("Media view video started");
    }
  }
  
  class null implements Runnable {
    public void run() {
      final String finalIconImage;
      String str3 = campaign.getIconUrl();
      String str2 = campaign.getImageUrl();
      Future<Drawable> future = MintegralMediationAdapter.this.createDrawableFuture(str3, this.this$1.context.getResources());
      new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2));
      str2 = null;
      try {
      
      } finally {
        future = null;
        MintegralMediationAdapter mintegralMediationAdapter = MintegralMediationAdapter.this;
        StringBuilder stringBuilder = new StringBuilder("Failed to fetch icon image from URL: ");
        stringBuilder.append(str3);
        mintegralMediationAdapter.log(stringBuilder.toString(), (Throwable)future);
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MBMediaView mBMediaView = new MBMediaView(this.this$2.this$1.context);
              mBMediaView.setNativeAd(campaign);
              mBMediaView.setOnMediaViewListener(this.this$2.this$1);
              MBAdChoice mBAdChoice = new MBAdChoice(this.this$2.this$1.context);
              mBAdChoice.setCampaign(campaign);
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
              MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
              String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
              MaxNativeAdView maxNativeAdView = MintegralMediationAdapter.this.createMaxNativeAdViewWithNativeAd(MintegralMediationAdapter.this.nativeAd, str, this.this$2.this$1.context);
              MintegralMediationAdapter.this.nativeAd.prepareForInteraction(MintegralMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
              this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MBMediaView mBMediaView = new MBMediaView(this.this$2.this$1.context);
      mBMediaView.setNativeAd(campaign);
      mBMediaView.setOnMediaViewListener(this.this$2.this$1);
      MBAdChoice mBAdChoice = new MBAdChoice(this.this$2.this$1.context);
      mBAdChoice.setCampaign(campaign);
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(this.this$2.this$1.adFormat).setTitle(campaign.getAppName()).setBody(campaign.getAppDesc()).setCallToAction(campaign.getAdCall()).setIcon(finalIconImage).setOptionsView((View)mBAdChoice).setMediaView((View)mBMediaView);
      MintegralMediationAdapter.access$1002(MintegralMediationAdapter.this, new MintegralMediationAdapter.MaxMintegralNativeAd(builder));
      String str = BundleUtils.getString("template", "", this.this$2.this$1.serverParameters);
      MaxNativeAdView maxNativeAdView = MintegralMediationAdapter.this.createMaxNativeAdViewWithNativeAd(MintegralMediationAdapter.this.nativeAd, str, this.this$2.this$1.context);
      MintegralMediationAdapter.this.nativeAd.prepareForInteraction(MintegralMediationAdapter.this.getClickableViews(maxNativeAdView), (ViewGroup)maxNativeAdView);
      this.this$2.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapters\MintegralMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */