package com.applovin.mediation.adapters.mintegral;

public final class BuildConfig {
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "standalone";
  
  public static final boolean IS_TEST_APP = false;
  
  public static final String LIBRARY_PACKAGE_NAME = "com.applovin.mediation.adapters.mintegral";
  
  public static final int VERSION_CODE = 16052100;
  
  public static final String VERSION_NAME = "16.5.21.0";
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapters\mintegral\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */