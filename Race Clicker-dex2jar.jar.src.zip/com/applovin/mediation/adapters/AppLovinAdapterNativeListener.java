package com.applovin.mediation.adapters;

import android.text.TextUtils;
import android.view.View;
import com.applovin.impl.sdk.AppLovinError;
import com.applovin.impl.sdk.nativeAd.AppLovinNativeAd;
import com.applovin.impl.sdk.nativeAd.AppLovinNativeAdEventListener;
import com.applovin.impl.sdk.nativeAd.AppLovinNativeAdImpl;
import com.applovin.impl.sdk.nativeAd.AppLovinNativeAdLoadListener;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;

public class AppLovinAdapterNativeListener implements AppLovinNativeAdEventListener, AppLovinNativeAdLoadListener {
  private final MaxNativeAdAdapterListener listener;
  
  private final MaxAdapterResponseParameters parameters;
  
  private final AppLovinMediationAdapter parentAdapter;
  
  public AppLovinAdapterNativeListener(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, AppLovinMediationAdapter paramAppLovinMediationAdapter, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    this.parameters = paramMaxAdapterResponseParameters;
    this.parentAdapter = paramAppLovinMediationAdapter;
    this.listener = paramMaxNativeAdAdapterListener;
  }
  
  public void onNativeAdClicked(AppLovinNativeAd paramAppLovinNativeAd) {
    this.parentAdapter.d("Native ad clicked");
    this.listener.onNativeAdClicked();
  }
  
  public void onNativeAdLoadFailed(AppLovinError paramAppLovinError) {
    AppLovinMediationAdapter appLovinMediationAdapter = this.parentAdapter;
    StringBuilder stringBuilder = new StringBuilder("Native ad failed to load with error: ");
    stringBuilder.append(paramAppLovinError);
    appLovinMediationAdapter.d(stringBuilder.toString());
    this.listener.onNativeAdLoadFailed(AppLovinMediationAdapter.toMaxError(paramAppLovinError));
  }
  
  public void onNativeAdLoaded(AppLovinNativeAd paramAppLovinNativeAd) {
    AppLovinMediationAdapter appLovinMediationAdapter = this.parentAdapter;
    StringBuilder stringBuilder = new StringBuilder("Native ad loaded: ");
    stringBuilder.append(paramAppLovinNativeAd);
    appLovinMediationAdapter.d(stringBuilder.toString());
    if (StringUtils.isValidString(BundleUtils.getString("template", "", this.parameters.getServerParameters())) && TextUtils.isEmpty(paramAppLovinNativeAd.getTitle())) {
      appLovinMediationAdapter = this.parentAdapter;
      stringBuilder = new StringBuilder("Native ad does not have required assets: ");
      stringBuilder.append(paramAppLovinNativeAd);
      appLovinMediationAdapter.e(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(MaxAdapterError.MISSING_REQUIRED_NATIVE_AD_ASSETS);
      return;
    } 
    AppLovinNativeAdImpl appLovinNativeAdImpl = (AppLovinNativeAdImpl)paramAppLovinNativeAd;
    appLovinNativeAdImpl.setEventListener(this);
    this.parentAdapter.loadedNativeAd = paramAppLovinNativeAd;
    AppLovinAdapterNativeAd appLovinAdapterNativeAd = new AppLovinAdapterNativeAd(this.parentAdapter, (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(paramAppLovinNativeAd.getTitle()).setAdvertiser(paramAppLovinNativeAd.getAdvertiser()).setBody(paramAppLovinNativeAd.getBody()).setCallToAction(paramAppLovinNativeAd.getCallToAction()).setIcon(new MaxNativeAd.MaxNativeAdImage(paramAppLovinNativeAd.getIconUri())).setOptionsView((View)paramAppLovinNativeAd.getOptionsView()).setMediaView((View)paramAppLovinNativeAd.getMediaView()).setMainImage(new MaxNativeAd.MaxNativeAdImage(appLovinNativeAdImpl.getMainImageUri())).setMediaContentAspectRatio(paramAppLovinNativeAd.getMediaView().getAspectRatio()).setStarRating(paramAppLovinNativeAd.getStarRating()));
    this.listener.onNativeAdLoaded((MaxNativeAd)appLovinAdapterNativeAd, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapters\AppLovinAdapterNativeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */