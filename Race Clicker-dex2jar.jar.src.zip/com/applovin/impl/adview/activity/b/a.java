package com.applovin.impl.adview.activity.b;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.applovin.adview.AppLovinAdView;
import com.applovin.impl.adview.d;
import com.applovin.impl.adview.j;
import com.applovin.impl.adview.n;
import com.applovin.impl.adview.o;
import com.applovin.impl.adview.p;
import com.applovin.impl.adview.q;
import com.applovin.impl.adview.v;
import com.applovin.impl.sdk.AppLovinBroadcastManager;
import com.applovin.impl.sdk.ad.AppLovinAdImpl;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.b.b;
import com.applovin.impl.sdk.d.d;
import com.applovin.impl.sdk.e.ac;
import com.applovin.impl.sdk.e.d;
import com.applovin.impl.sdk.e.r;
import com.applovin.impl.sdk.e.y;
import com.applovin.impl.sdk.j;
import com.applovin.impl.sdk.k;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.s;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.o;
import com.applovin.impl.sdk.utils.t;
import com.applovin.impl.sdk.utils.w;
import com.applovin.impl.sdk.utils.x;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinAdType;
import com.applovin.sdk.AppLovinAdVideoPlaybackListener;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class a implements AppLovinBroadcastManager.Receiver, b.a {
  private final j.a A;
  
  private final AtomicBoolean B = new AtomicBoolean();
  
  private final AtomicBoolean C = new AtomicBoolean();
  
  private long D;
  
  private boolean E;
  
  private int F = 0;
  
  private final ArrayList<Long> G = new ArrayList<Long>();
  
  private final k H;
  
  private boolean I = false;
  
  protected final e a;
  
  protected final o b;
  
  protected final y c;
  
  protected final d d;
  
  protected Activity e;
  
  protected AppLovinAdView f;
  
  protected v g;
  
  protected final n h;
  
  protected final n i;
  
  protected final long j = SystemClock.elapsedRealtime();
  
  protected long k = -1L;
  
  protected long l;
  
  protected boolean m;
  
  protected int n;
  
  protected boolean o;
  
  protected int p = 0;
  
  protected int q = 0;
  
  protected int r = j.a;
  
  protected boolean s;
  
  protected AppLovinAdClickListener t;
  
  protected AppLovinAdDisplayListener u;
  
  protected AppLovinAdVideoPlaybackListener v;
  
  protected final b w;
  
  protected t x;
  
  private final Handler y = new Handler(Looper.getMainLooper());
  
  private final com.applovin.impl.sdk.utils.a z;
  
  a(e parame, Activity paramActivity, Map<String, Object> paramMap, o paramo, AppLovinAdClickListener paramAppLovinAdClickListener, AppLovinAdDisplayListener paramAppLovinAdDisplayListener, AppLovinAdVideoPlaybackListener paramAppLovinAdVideoPlaybackListener) {
    this.a = parame;
    this.b = paramo;
    this.c = paramo.F();
    this.e = paramActivity;
    this.t = paramAppLovinAdClickListener;
    this.u = paramAppLovinAdDisplayListener;
    this.v = paramAppLovinAdVideoPlaybackListener;
    b b2 = new b(paramActivity, paramo);
    this.w = b2;
    b2.a(this);
    d d1 = new d((AppLovinAdImpl)parame, paramo);
    this.d = d1;
    this.H = new k(paramo);
    b b1 = new b();
    if (((Boolean)paramo.a(com.applovin.impl.sdk.c.b.dd)).booleanValue())
      AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.render_process_gone")); 
    o o1 = new o(paramo.aA(), AppLovinAdSize.INTERSTITIAL, (Context)paramActivity);
    this.f = (AppLovinAdView)o1;
    o1.setAdClickListener(b1);
    this.f.setAdDisplayListener(new AppLovinAdDisplayListener(this) {
          public void adDisplayed(AppLovinAd param1AppLovinAd) {
            y y = this.a.c;
            if (y.a())
              this.a.c.b("AppLovinFullscreenActivity", "Web content rendered"); 
          }
          
          public void adHidden(AppLovinAd param1AppLovinAd) {
            y y = this.a.c;
            if (y.a())
              this.a.c.b("AppLovinFullscreenActivity", "Closing from WebView"); 
            this.a.h();
          }
        });
    this.f.getController().a(d1);
    if (((Boolean)paramo.a(com.applovin.impl.sdk.c.b.ay)).booleanValue()) {
      p p = new p(paramMap, paramo);
      if (p.c())
        this.g = new v(p, (Context)paramActivity); 
    } 
    paramo.v().trackImpression(parame);
    List list = parame.u();
    if (parame.t() >= 0L || list != null) {
      n n2 = new n(parame.v(), paramActivity);
      this.h = n2;
      n2.setVisibility(8);
      n2.setOnClickListener(b1);
    } else {
      this.h = null;
    } 
    n n1 = new n(j.a.b, paramActivity);
    this.i = n1;
    n1.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            this.a.h();
          }
        });
    if (parame.aq()) {
      this.A = new j.a(this) {
          public void a(int param1Int) {
            if (this.a.r != j.a)
              this.a.s = true; 
            d d = this.a.f.getController().s();
            if (j.a(param1Int) && !j.a(this.a.r)) {
              d.a("javascript:al_muteSwitchOn();");
            } else if (param1Int == 2) {
              d.a("javascript:al_muteSwitchOff();");
            } 
            this.a.r = param1Int;
          }
        };
    } else {
      this.A = null;
    } 
    if (((Boolean)paramo.a(com.applovin.impl.sdk.c.b.gd)).booleanValue()) {
      this.z = new com.applovin.impl.sdk.utils.a(this) {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            if (!a.a(this.a).get()) {
              String str = w.b(param1Activity.getApplicationContext());
              if (param1Activity.getClass().getName().equals(str))
                AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
                      public void run() {
                        y.j("AppLovinFullscreenActivity", "Dismissing on-screen ad due to app relaunched via launcher.");
                        try {
                          return;
                        } finally {
                          Exception exception = null;
                          y.c("AppLovinFullscreenActivity", "Failed to dismiss ad.", exception);
                        } 
                      }
                    }); 
            } 
          }
        };
      return;
    } 
    this.z = null;
  }
  
  public static void a(e parame, AppLovinAdClickListener paramAppLovinAdClickListener, AppLovinAdDisplayListener paramAppLovinAdDisplayListener, AppLovinAdVideoPlaybackListener paramAppLovinAdVideoPlaybackListener, Map<String, Object> paramMap, o paramo, Activity paramActivity, a parama) {
    c c;
    e e1;
    StringBuilder stringBuilder;
    boolean bool = parame.aO();
    if (parame instanceof com.applovin.impl.c.a) {
      if (bool) {
        try {
        
        } finally {
          Exception exception = null;
          paramo.F();
          if (y.a())
            paramo.F().a("AppLovinFullscreenActivity", "Failed to create ExoPlayer presenter to show the ad. Falling back to using native media player presenter.", exception); 
        } 
      } else {
        try {
          d d1 = new d((e)c, paramActivity, paramMap, paramo, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } finally {
          c = null;
          stringBuilder = new StringBuilder("Failed to create FullscreenVastVideoAdPresenter with sdk: ");
          stringBuilder.append(paramo);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(c.getMessage());
          parama.a(stringBuilder.toString(), (Throwable)c);
        } 
      } 
    } else if (c.hasVideoUrl()) {
      if (c.aR()) {
        try {
          g g = new g((e)c, paramActivity, paramMap, paramo, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } finally {
          c = null;
          stringBuilder = new StringBuilder("Failed to create FullscreenWebVideoAdPresenter with sdk: ");
          stringBuilder.append(paramo);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(c.getMessage());
          parama.a(stringBuilder.toString(), (Throwable)c);
        } 
      } else if (bool) {
        try {
        
        } finally {
          Exception exception = null;
          paramo.F();
          if (y.a())
            paramo.F().a("AppLovinFullscreenActivity", "Failed to create ExoPlayer presenter to show the ad. Falling back to using native media player presenter.", exception); 
        } 
      } else {
        try {
          f f = new f((e)e1, paramActivity, paramMap, paramo, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } finally {
          e1 = null;
          stringBuilder = new StringBuilder("Failed to create FullscreenVideoAdPresenter with sdk: ");
          stringBuilder.append(paramo);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(e1.getMessage());
          parama.a(stringBuilder.toString(), (Throwable)e1);
        } 
      } 
    } else {
      try {
        return;
      } finally {
        e1 = null;
        stringBuilder = new StringBuilder("Failed to create FullscreenGraphicAdPresenter with sdk: ");
        stringBuilder.append(paramo);
        stringBuilder.append(" and throwable: ");
        stringBuilder.append(e1.getMessage());
        parama.a(stringBuilder.toString(), (Throwable)e1);
      } 
    } 
    e1.c();
    parama.a((a)e1);
  }
  
  private void c() {
    if (this.A != null)
      this.b.Z().a(this.A); 
    if (this.z != null)
      this.b.E().a(this.z); 
  }
  
  public void a(int paramInt, KeyEvent paramKeyEvent) {
    if (this.c != null && y.a()) {
      y y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder("onKeyDown(int, KeyEvent) -  ");
      stringBuilder.append(paramInt);
      stringBuilder.append(", ");
      stringBuilder.append(paramKeyEvent);
      y1.c("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
  }
  
  protected void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2, long paramLong) {
    if (this.B.compareAndSet(false, true)) {
      if (this.a.hasVideoUrl() || u())
        o.a(this.v, (AppLovinAd)this.a, paramInt, paramBoolean2); 
      if (this.a.hasVideoUrl())
        this.d.c(paramInt); 
      long l2 = SystemClock.elapsedRealtime() - this.j;
      this.b.v().trackVideoEnd(this.a, TimeUnit.MILLISECONDS.toSeconds(l2), paramInt, paramBoolean1);
      long l3 = this.k;
      long l1 = -1L;
      if (l3 != -1L)
        l1 = SystemClock.elapsedRealtime() - this.k; 
      this.b.v().trackFullScreenAdClosed(this.a, l1, this.G, paramLong, this.s, this.r);
      if (y.a()) {
        y y1 = this.c;
        StringBuilder stringBuilder = new StringBuilder("Video ad ended at percent: ");
        stringBuilder.append(paramInt);
        stringBuilder.append("%, elapsedTime: ");
        stringBuilder.append(l2);
        stringBuilder.append("ms, skipTimeMillis: ");
        stringBuilder.append(paramLong);
        stringBuilder.append("ms, closeTimeMillis: ");
        stringBuilder.append(l1);
        stringBuilder.append("ms");
        y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
    } 
  }
  
  public abstract void a(long paramLong);
  
  public void a(Configuration paramConfiguration) {
    if (y.a()) {
      y y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder("onConfigurationChanged(Configuration) -  ");
      stringBuilder.append(paramConfiguration);
      y1.c("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
  }
  
  public abstract void a(ViewGroup paramViewGroup);
  
  protected void a(n paramn, long paramLong, Runnable paramRunnable) {
    if (paramLong >= ((Long)this.b.a(com.applovin.impl.sdk.c.b.cK)).longValue())
      return; 
    Runnable runnable = new Runnable(this, paramn, paramRunnable) {
        public void run() {
          AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
                public void run() {
                  x.a((View)this.a.a, 400L, new Runnable(this) {
                        public void run() {
                          this.a.a.a.bringToFront();
                          this.a.a.b.run();
                        }
                      });
                }
              });
        }
      };
    this.b.G().a((d)new ac(this.b, "fadeInCloseButton", runnable), r.b.a, TimeUnit.SECONDS.toMillis(paramLong), true);
  }
  
  protected void a(Runnable paramRunnable, long paramLong) {
    AppLovinSdkUtils.runOnUiThreadDelayed(paramRunnable, paramLong, this.y);
  }
  
  protected void a(String paramString) {
    if (this.a.ab())
      a(paramString, 0L); 
  }
  
  protected void a(String paramString, long paramLong) {
    if (paramLong >= 0L)
      a(new Runnable(this, paramString) {
            public void run() {
              if (StringUtils.isValidString(this.a) && this.b.f != null) {
                d d = this.b.f.getController().s();
                if (d != null)
                  d.a(this.a); 
              } 
            }
          }paramLong); 
  }
  
  protected void a(boolean paramBoolean) {
    List list = w.a(paramBoolean, this.a, this.b, (Context)this.e);
    if (!list.isEmpty()) {
      if (((Boolean)this.b.a(com.applovin.impl.sdk.c.b.gi)).booleanValue()) {
        if (y.a()) {
          y y1 = this.c;
          StringBuilder stringBuilder = new StringBuilder("Dismissing ad due to missing resources: ");
          stringBuilder.append(list);
          y1.e("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        q.a(this.a, this.u, "Missing ad resources", null, null);
        h();
        return;
      } 
      if (y.a()) {
        y y1 = this.c;
        StringBuilder stringBuilder = new StringBuilder("Streaming ad due to missing ad resources: ");
        stringBuilder.append(list);
        y1.e("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
      this.a.a();
    } 
  }
  
  protected void a(boolean paramBoolean, long paramLong) {
    if (this.a.Z()) {
      String str;
      if (paramBoolean) {
        str = "javascript:al_mute();";
      } else {
        str = "javascript:al_unmute();";
      } 
      a(str, paramLong);
    } 
  }
  
  protected void b(long paramLong) {
    if (y.a()) {
      y y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder("Scheduling report reward in ");
      stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(paramLong));
      stringBuilder.append(" seconds...");
      y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
    this.x = t.a(paramLong, this.b, new Runnable(this) {
          public void run() {
            if (!this.a.a.al().getAndSet(true)) {
              y y = new y(this.a.a, this.a.b);
              this.a.b.G().a((d)y, r.b.j);
            } 
          }
        });
  }
  
  protected void b(String paramString) {
    a(paramString, 0L);
  }
  
  protected void b(boolean paramBoolean) {
    a(paramBoolean, ((Long)this.b.a(com.applovin.impl.sdk.c.b.da)).longValue());
    o.a(this.u, (AppLovinAd)this.a);
    this.b.V().a(this.a);
    if (this.a.hasVideoUrl() || u())
      o.a(this.v, (AppLovinAd)this.a); 
    (new com.applovin.impl.adview.activity.b(this.e)).a(this.a);
    this.d.a();
    this.a.setHasShown(true);
  }
  
  public void c(boolean paramBoolean) {
    if (y.a()) {
      y y1 = this.c;
      StringBuilder stringBuilder1 = new StringBuilder("onWindowFocusChanged(boolean) - ");
      stringBuilder1.append(paramBoolean);
      y1.c("AppLovinFullscreenActivity", stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder("javascript:al_onWindowFocusChanged( ");
    stringBuilder.append(paramBoolean);
    stringBuilder.append(" );");
    a(stringBuilder.toString());
  }
  
  public abstract void d();
  
  public abstract void e();
  
  public void f() {
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onResume()"); 
    this.d.d(SystemClock.elapsedRealtime() - this.D);
    a("javascript:al_onAppResumed();");
    r();
    if (this.w.c())
      this.w.a(); 
  }
  
  public void g() {
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onPause()"); 
    this.D = SystemClock.elapsedRealtime();
    a("javascript:al_onAppPaused();");
    if (this.w.c())
      this.w.a(); 
    q();
  }
  
  public void h() {
    this.E = true;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "dismiss()"); 
    e e1 = this.a;
    if (e1 != null)
      e1.o().e(); 
    this.y.removeCallbacksAndMessages(null);
    a("javascript:al_onPoststitialDismiss();", this.a.Y());
    o();
    this.d.c();
    this.H.a();
    if (this.A != null)
      this.b.Z().b(this.A); 
    if (this.z != null)
      this.b.E().b(this.z); 
    if (p()) {
      this.e.finish();
      return;
    } 
    this.b.F();
    if (y.a())
      this.b.F().b("AppLovinFullscreenActivity", "Fullscreen ad shown in container view dismissed, destroying the presenter."); 
    k();
  }
  
  public boolean i() {
    return this.E;
  }
  
  public void j() {
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onStop()"); 
  }
  
  public void k() {
    AppLovinAdView appLovinAdView = this.f;
    if (appLovinAdView != null) {
      ViewParent viewParent = appLovinAdView.getParent();
      this.f.destroy();
      this.f = null;
      if (viewParent instanceof ViewGroup && p())
        ((ViewGroup)viewParent).removeAllViews(); 
    } 
    n();
    o();
    this.t = null;
    this.u = null;
    this.v = null;
    this.e = null;
    AppLovinBroadcastManager.unregisterReceiver(this);
  }
  
  public void l() {
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onBackPressed()"); 
    if (this.I)
      h(); 
    if (this.a.aa())
      b("javascript:onBackPressed();"); 
  }
  
  protected int m() {
    int i = this.a.H();
    if (i > 0)
      return i; 
    if (((Boolean)this.b.a(com.applovin.impl.sdk.c.b.cZ)).booleanValue())
      i = this.n + 1; 
    return i;
  }
  
  protected abstract void n();
  
  protected void o() {
    if (this.C.compareAndSet(false, true)) {
      o.b(this.u, (AppLovinAd)this.a);
      this.b.V().b(this.a);
    } 
  }
  
  public void onReceive(Intent paramIntent, Map<String, Object> paramMap) {
    if ("com.applovin.render_process_gone".equals(paramIntent.getAction()) && !this.m)
      x(); 
  }
  
  protected boolean p() {
    return this.e instanceof com.applovin.adview.AppLovinFullscreenActivity;
  }
  
  protected void q() {
    t t1 = this.x;
    if (t1 != null)
      t1.b(); 
  }
  
  protected void r() {
    t t1 = this.x;
    if (t1 != null)
      t1.c(); 
  }
  
  protected abstract boolean s();
  
  protected abstract boolean t();
  
  protected boolean u() {
    return (AppLovinAdType.INCENTIVIZED == this.a.getType() || AppLovinAdType.AUTO_INCENTIVIZED == this.a.getType());
  }
  
  protected abstract void v();
  
  protected void w() {
    if (this.f != null) {
      if (!this.a.G())
        return; 
      d d1 = this.f.getController().s();
      if (d1 == null)
        return; 
      this.H.a((View)d1, new k.a(this) {
            public void a(View param1View) {
              this.a.b.ag().a(s.a.b, CollectionUtils.map("clcode", this.a.a.getClCode()));
              if (((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.gA)).booleanValue()) {
                this.a.h();
                return;
              } 
              a a1 = this.a;
              a.a(a1, ((Boolean)a1.b.a(com.applovin.impl.sdk.c.b.gB)).booleanValue());
              if (((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.gC)).booleanValue() && this.a.h != null)
                this.a.h.setVisibility(0); 
            }
          });
    } 
  }
  
  public void x() {
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "Handling render process crash"); 
    this.m = true;
  }
  
  public static interface a {
    void a(a param1a);
    
    void a(String param1String, Throwable param1Throwable);
  }
  
  private class b implements View.OnClickListener, AppLovinAdClickListener {
    private b(a this$0) {}
    
    public void adClicked(AppLovinAd param1AppLovinAd) {
      y y = this.a.c;
      if (y.a())
        this.a.c.b("AppLovinFullscreenActivity", "Clicking through graphic"); 
      o.a(this.a.t, param1AppLovinAd);
      this.a.d.b();
      a a1 = this.a;
      a1.q++;
    }
    
    public void onClick(View param1View) {
      List<Integer> list;
      if (param1View == this.a.h && ((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.cL)).booleanValue()) {
        a.b(this.a);
        if (this.a.a.aa()) {
          a a2 = this.a;
          StringBuilder stringBuilder = new StringBuilder("javascript:al_onCloseButtonTapped(");
          stringBuilder.append(a.c(this.a));
          stringBuilder.append(",");
          stringBuilder.append(this.a.p);
          stringBuilder.append(",");
          stringBuilder.append(this.a.q);
          stringBuilder.append(");");
          a2.b(stringBuilder.toString());
        } 
        list = this.a.a.u();
        y y2 = this.a.c;
        if (y.a()) {
          y2 = this.a.c;
          StringBuilder stringBuilder = new StringBuilder("Handling close button tap ");
          stringBuilder.append(a.c(this.a));
          stringBuilder.append(" with multi close delay: ");
          stringBuilder.append(list);
          y2.b("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        if (list == null || list.size() <= a.c(this.a)) {
          this.a.h();
          return;
        } 
        a.d(this.a).add(Long.valueOf(SystemClock.elapsedRealtime() - this.a.k));
        List<j.a> list1 = this.a.a.w();
        if (list1 != null && list1.size() > a.c(this.a))
          this.a.h.a(list1.get(a.c(this.a))); 
        y y1 = this.a.c;
        if (y.a()) {
          y1 = this.a.c;
          StringBuilder stringBuilder = new StringBuilder("Scheduling next close button with delay: ");
          stringBuilder.append(list.get(a.c(this.a)));
          y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        this.a.h.setVisibility(8);
        a a1 = this.a;
        a1.a(a1.h, ((Integer)list.get(a.c(this.a))).intValue(), new Runnable(this) {
              public void run() {
                this.a.a.k = SystemClock.elapsedRealtime();
              }
            });
        return;
      } 
      y y = this.a.c;
      if (y.a()) {
        y = this.a.c;
        StringBuilder stringBuilder = new StringBuilder("Unhandled click on widget: ");
        stringBuilder.append(list);
        y.e("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
    }
  }
  
  class null implements Runnable {
    null(a this$0) {}
    
    public void run() {
      this.a.a.k = SystemClock.elapsedRealtime();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\adview\activity\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */