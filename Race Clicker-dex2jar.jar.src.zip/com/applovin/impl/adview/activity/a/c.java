package com.applovin.impl.adview.activity.a;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import com.applovin.adview.AppLovinAdView;
import com.applovin.impl.adview.a;
import com.applovin.impl.adview.h;
import com.applovin.impl.adview.n;
import com.applovin.impl.adview.u;
import com.applovin.impl.adview.v;
import com.applovin.impl.adview.w;
import com.applovin.impl.c.a;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.w;
import com.applovin.impl.sdk.utils.x;
import com.applovin.sdk.AppLovinSdkUtils;

public class c extends a {
  public c(e parame, Activity paramActivity, o paramo) {
    super(parame, paramActivity, paramo);
  }
  
  public void a(ImageView paramImageView1, n paramn, w paramw, a parama, ProgressBar paramProgressBar, h paramh, View paramView, AppLovinAdView paramAppLovinAdView, v paramv, ImageView paramImageView2, ViewGroup paramViewGroup) {
    View view;
    FrameLayout.LayoutParams layoutParams;
    if (this.c.aS() == e.d.b) {
      layoutParams = new FrameLayout.LayoutParams(-1, -2, 48);
    } else if (this.c.aS() == e.d.c) {
      layoutParams = new FrameLayout.LayoutParams(-1, -2, 80);
    } else if (this.c.aS() == e.d.d) {
      layoutParams = new FrameLayout.LayoutParams(-2, -1, 3);
    } else if (this.c.aS() == e.d.e) {
      layoutParams = new FrameLayout.LayoutParams(-2, -1, 5);
    } else {
      layoutParams = this.e;
    } 
    if (this.c.aP()) {
      paramAppLovinAdView.setLayoutParams((ViewGroup.LayoutParams)this.e);
      this.d.addView((View)paramAppLovinAdView);
      view = new View((Context)this.b);
      view.setLayoutParams((ViewGroup.LayoutParams)this.e);
      view.setBackgroundColor(Color.argb(254, 0, 0, 0));
      view.setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              return true;
            }
          });
      this.d.addView(view);
      paramView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.d.addView(paramView);
    } else {
      paramView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.d.addView(paramView);
      view.setLayoutParams((ViewGroup.LayoutParams)this.e);
      this.d.addView(view);
      view.setVisibility(4);
    } 
    if (paramw != null) {
      u u = this.c.D();
      if (((Boolean)this.a.a(b.gP)).booleanValue()) {
        LinearLayout linearLayout1 = new LinearLayout((Context)this.b);
        linearLayout1.setOrientation(1);
        linearLayout1.setWeightSum(100.0F);
        linearLayout1.setGravity(u.d());
        layoutParams = new FrameLayout.LayoutParams(-1, -1);
        LinearLayout linearLayout2 = new LinearLayout((Context)this.b);
        linearLayout2.setOrientation(0);
        linearLayout2.setWeightSum(100.0F);
        linearLayout2.setGravity(u.d());
        LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(-2, 0, u.b());
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -1, u.a());
        int i = AppLovinSdkUtils.dpToPx((Context)this.b, u.c());
        layoutParams2.setMargins(i, i, i, i);
        linearLayout2.addView((View)paramw, (ViewGroup.LayoutParams)layoutParams2);
        linearLayout1.addView((View)linearLayout2, (ViewGroup.LayoutParams)layoutParams1);
        this.d.addView((View)linearLayout1, (ViewGroup.LayoutParams)layoutParams);
      } else {
        int j;
        double d1 = u.a() / 100.0D;
        double d2 = u.b() / 100.0D;
        if (paramViewGroup != null) {
          i = paramViewGroup.getWidth();
          j = paramViewGroup.getHeight();
        } else {
          Point point = h.a((Context)this.b);
          i = point.x;
          j = point.y;
        } 
        FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams((int)(i * d1), (int)(j * d2), u.d());
        int i = AppLovinSdkUtils.dpToPx((Context)this.b, u.c());
        layoutParams1.setMargins(i, i, i, i);
        this.d.addView((View)paramw, (ViewGroup.LayoutParams)layoutParams1);
      } 
      if (u.i() > 0.0F) {
        paramw.setVisibility(4);
        long l = w.b(u.i());
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramw, u.g()) {
              public void run() {
                x.a((View)this.a, this.b, null);
              }
            }l);
      } 
      if (u.j() > 0.0F) {
        long l = w.b(u.j());
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramw, u.h()) {
              public void run() {
                x.b((View)this.a, this.b, null);
              }
            }l);
      } 
    } 
    if (paramn != null) {
      byte b;
      if (this.c.ah()) {
        b = 3;
      } else {
        b = 5;
      } 
      a(this.c.ac(), 0x30 | b, paramn);
    } 
    if (paramImageView1 != null) {
      int i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cS)).intValue());
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(i, i, ((Integer)this.a.a(b.cU)).intValue());
      i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cT)).intValue());
      layoutParams1.setMargins(i, i, i, i);
      this.d.addView((View)paramImageView1, (ViewGroup.LayoutParams)layoutParams1);
    } 
    if (parama != null)
      this.d.addView((View)parama, (ViewGroup.LayoutParams)this.e); 
    if (paramh != null) {
      int i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cF)).intValue());
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(i, i, ((Integer)this.a.a(b.cE)).intValue());
      i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cD)).intValue());
      layoutParams1.setMargins(i, i, i, i);
      this.d.addView((View)paramh, (ViewGroup.LayoutParams)layoutParams1);
    } 
    if (paramProgressBar != null) {
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(-1, 20, 80);
      layoutParams1.setMargins(0, 0, 0, ((Integer)this.a.a(b.cX)).intValue());
      this.d.addView((View)paramProgressBar, (ViewGroup.LayoutParams)layoutParams1);
    } 
    if (paramImageView2 != null) {
      a a1 = (a)this.c;
      if (a1.aX()) {
        int i = AppLovinSdkUtils.dpToPx((Context)this.b, a1.aW().c());
        int j = AppLovinSdkUtils.dpToPx((Context)this.b, a1.aW().d());
        int k = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.fo)).intValue());
        FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(i, j, 83);
        layoutParams1.setMargins(k, k, k, k);
        this.d.addView((View)paramImageView2, (ViewGroup.LayoutParams)layoutParams1);
      } 
    } 
    if (paramv != null)
      this.d.addView((View)paramv, (ViewGroup.LayoutParams)this.e); 
    if (paramViewGroup != null) {
      paramViewGroup.addView((View)this.d);
      return;
    } 
    this.b.setContentView((View)this.d);
  }
  
  public void a(n paramn, v paramv, View paramView, ProgressBar paramProgressBar) {
    if (paramView != null)
      paramView.setVisibility(0); 
    com.applovin.impl.sdk.utils.c.a(this.d, paramView);
    byte b = 48;
    if (paramn != null) {
      byte b1;
      if (this.c.ag()) {
        b1 = 3;
      } else {
        b1 = 5;
      } 
      a(this.c.ac(), b1 | 0x30, paramn);
    } 
    if (paramProgressBar != null) {
      byte b1 = b;
      if (((Boolean)this.a.a(b.dg)).booleanValue())
        b1 = 80; 
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, 20, b1);
      layoutParams.setMargins(0, 0, 0, ((Integer)this.a.a(b.dh)).intValue());
      this.d.addView((View)paramProgressBar, (ViewGroup.LayoutParams)layoutParams);
    } 
    if (paramv != null)
      this.d.addView((View)paramv, (ViewGroup.LayoutParams)this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\adview\activity\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */