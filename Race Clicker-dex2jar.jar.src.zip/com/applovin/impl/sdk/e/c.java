package com.applovin.impl.sdk.e;

import android.net.Uri;
import android.text.TextUtils;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.d.e;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.y;
import java.io.File;
import java.util.List;

public class c extends a {
  private final String e;
  
  private final e f;
  
  private final List<String> g;
  
  private final boolean h;
  
  private final e i;
  
  private final o j;
  
  private final a k;
  
  public c(String paramString, e parame, e parame1, o paramo, a parama) {
    this(paramString, parame, parame.L(), true, parame1, paramo, parama);
  }
  
  public c(String paramString, e parame, List<String> paramList, boolean paramBoolean, e parame1, o paramo, a parama) {
    super("AsyncTaskCacheResource", paramo);
    this.e = paramString;
    this.f = parame;
    this.g = paramList;
    this.h = paramBoolean;
    this.i = parame1;
    this.j = paramo;
    this.k = parama;
  }
  
  private void a(Uri paramUri) {
    if (this.d.get())
      return; 
    a a1 = this.k;
    if (a1 != null)
      a1.a(paramUri); 
  }
  
  public Boolean b() throws Exception {
    y y1;
    y y2;
    boolean bool = this.d.get();
    Boolean bool1 = Boolean.valueOf(false);
    if (bool)
      return bool1; 
    String str = this.j.S().a(a(), this.e, this.f.O(), this.g, this.h, this.i);
    if (TextUtils.isEmpty(str)) {
      a((Uri)null);
      return bool1;
    } 
    if (this.d.get())
      return bool1; 
    File file = this.j.S().a(str, a());
    if (file == null) {
      y2 = this.c;
      if (y.a()) {
        y2 = this.c;
        String str1 = this.b;
        StringBuilder stringBuilder = new StringBuilder("Unable to retrieve File for cached filename = ");
        stringBuilder.append(str);
        y2.e(str1, stringBuilder.toString());
      } 
      a((Uri)null);
      return bool1;
    } 
    if (this.d.get())
      return bool1; 
    Uri uri = Uri.fromFile((File)y2);
    if (uri == null) {
      y1 = this.c;
      if (y.a())
        this.c.e(this.b, "Unable to extract Uri from file"); 
      a((Uri)null);
      return bool1;
    } 
    if (this.d.get())
      return bool1; 
    a((Uri)y1);
    return Boolean.valueOf(true);
  }
  
  public static interface a {
    void a(Uri param1Uri);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sdk\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */