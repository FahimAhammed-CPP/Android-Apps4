package com.applovin.impl.sdk.utils;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;

public class b {
  public static Activity a(View paramView) {
    if (paramView == null)
      return null; 
    for (Context context = paramView.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext()) {
      if (context instanceof Activity)
        return (Activity)context; 
    } 
    return null;
  }
  
  public static void a(Context paramContext, Class paramClass, com.applovin.impl.sdk.a parama, a parama1) {
    parama.a(new a(paramClass, parama1, parama) {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            if (this.a.isInstance(param1Activity))
              this.b.onActivityCreated(param1Activity); 
          }
          
          public void onActivityDestroyed(Activity param1Activity) {
            if (this.a.isInstance(param1Activity) && !param1Activity.isChangingConfigurations())
              this.c.b(this); 
          }
        });
    safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(paramContext, new Intent(paramContext, paramClass));
  }
  
  public static void a(boolean paramBoolean, Activity paramActivity) {
    if (paramBoolean && h.j()) {
      WindowInsetsController windowInsetsController = paramActivity.getWindow().getInsetsController();
      if (windowInsetsController != null) {
        windowInsetsController.setSystemBarsBehavior(2);
        windowInsetsController.hide(WindowInsets.Type.systemBars());
        return;
      } 
      paramActivity.getWindow().getDecorView().setSystemUiVisibility(5894);
      return;
    } 
    paramActivity.getWindow().getDecorView().setSystemUiVisibility(5894);
  }
  
  public static boolean a(Activity paramActivity) {
    return (paramActivity == null || paramActivity.isFinishing() || paramActivity.isChangingConfigurations() || (h.b() && paramActivity.isDestroyed()));
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.applovin");
    paramContext.startActivity(paramIntent);
  }
  
  public static interface a<T extends Activity> {
    void onActivityCreated(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sd\\utils\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */