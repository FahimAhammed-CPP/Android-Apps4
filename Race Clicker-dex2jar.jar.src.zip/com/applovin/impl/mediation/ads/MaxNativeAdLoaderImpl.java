package com.applovin.impl.mediation.ads;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.a.d;
import com.applovin.impl.mediation.d;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.b;
import com.applovin.impl.sdk.e.ac;
import com.applovin.impl.sdk.e.d;
import com.applovin.impl.sdk.e.r;
import com.applovin.impl.sdk.f;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.o;
import com.applovin.impl.sdk.utils.w;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MaxNativeAdLoaderImpl extends a implements b.a, f.a {
  public static final String KEY_EXTRA_PARAMETER_AD_REQUEST_TYPE = "ad_request_type";
  
  private final a a = new a();
  
  private String b;
  
  private String c;
  
  private d.a d = d.a.a;
  
  private final Object e = new Object();
  
  private MaxNativeAdListener f;
  
  private final Map<String, MaxNativeAdView> g = new HashMap<String, MaxNativeAdView>();
  
  private final Set<d> h = new HashSet<d>();
  
  public MaxNativeAdLoaderImpl(String paramString, o paramo) {
    super(paramString, MaxAdFormat.NATIVE, "MaxNativeAdLoader", paramo);
    paramo.aj().a(this);
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Created new MaxNativeAdLoader (");
      stringBuilder.append(this);
      stringBuilder.append(")");
      y.b(str, stringBuilder.toString());
    } 
  }
  
  private MaxNativeAdView a(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    synchronized (this.e) {
      return this.g.remove(paramString);
    } 
  }
  
  private void a(d paramd) {
    if (!paramd.M().get())
      this.sdk.R().a((g)paramd, this); 
  }
  
  private void a(MaxNativeAdView paramMaxNativeAdView) {
    b b = paramMaxNativeAdView.getAdViewTracker();
    if (b != null)
      if (h.c()) {
        if (paramMaxNativeAdView.isAttachedToWindow()) {
          b.b();
          return;
        } 
      } else if (paramMaxNativeAdView.getParent() != null) {
        b.b();
      }  
  }
  
  private void a(MaxNativeAdView paramMaxNativeAdView, d paramd, MaxNativeAd paramMaxNativeAd) {
    paramd.a(paramMaxNativeAdView);
    a((com.applovin.impl.mediation.a.a)paramd);
    Runnable runnable = new Runnable(this, paramMaxNativeAdView, paramd, paramMaxNativeAd) {
        public void run() {
          y y = this.d.logger;
          if (y.a()) {
            y = this.d.logger;
            String str = this.d.tag;
            StringBuilder stringBuilder = new StringBuilder("Rendering native ad view: ");
            stringBuilder.append(this.a);
            y.b(str, stringBuilder.toString());
          } 
          this.a.render(this.b, MaxNativeAdLoaderImpl.a(this.d), this.d.sdk);
          this.c.setNativeAdView(this.a);
          if (!this.c.prepareForInteraction(this.a.getClickableViews(), (ViewGroup)this.a))
            this.c.prepareViewForInteraction(this.a); 
        }
      };
    if (paramMaxNativeAd.shouldPrepareViewForInteractionOnMainThread()) {
      AppLovinSdkUtils.runOnUiThread(runnable);
      return;
    } 
    this.sdk.G().a((d)new ac(this.sdk, "renderMaxNativeAd", runnable), r.b.k);
  }
  
  private void a(String paramString, MaxNativeAdView paramMaxNativeAdView) {
    if (TextUtils.isEmpty(paramString))
      return; 
    synchronized (this.e) {
      this.g.put(paramString, paramMaxNativeAdView);
      return;
    } 
  }
  
  public void destroy() {
    this.f = null;
    this.sdk.aj().b(this);
    synchronized (this.e) {
      this.g.clear();
      this.h.clear();
      super.destroy();
      return;
    } 
  }
  
  public void destroy(MaxAd paramMaxAd) {
    if (paramMaxAd instanceof d) {
      d d = (d)paramMaxAd;
      if (d.L()) {
        null = this.logger;
        if (y.a()) {
          null = this.logger;
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder("Native ad (");
          stringBuilder.append(d);
          stringBuilder.append(") has already been destroyed");
          null.b(str, stringBuilder.toString());
        } 
        return;
      } 
      synchronized (this.e) {
        this.h.remove(d);
        null = d.I();
        if (null != null) {
          b b = null.getAdViewTracker();
          if (b != null && null.equals(b.c()))
            null.recycle(); 
        } 
        MaxNativeAd maxNativeAd = d.getNativeAd();
        if (maxNativeAd != null && maxNativeAd.getAdViewTracker() != null)
          maxNativeAd.getAdViewTracker().a(); 
        this.sdk.R().a((g)d);
        this.sdk.am().destroyAd((MaxAd)d);
        this.sdk.ar().a(this.adUnitId, d.d());
        return;
      } 
    } 
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Destroy failed on non-native ad(");
      stringBuilder.append(paramMaxAd);
      stringBuilder.append(")");
      y.b(str, stringBuilder.toString());
    } 
  }
  
  public String getPlacement() {
    return this.b;
  }
  
  public void handleNativeAdViewRendered(MaxAd paramMaxAd) {
    y y2;
    y y1;
    MaxNativeAd maxNativeAd = ((d)paramMaxAd).getNativeAd();
    if (maxNativeAd == null) {
      y2 = this.logger;
      if (y.a())
        this.logger.e(this.tag, "Failed to handle native ad rendered. Could not retrieve MaxNativeAd. The ad may have already been destroyed."); 
      return;
    } 
    b b = y2.getAdViewTracker();
    if (b == null) {
      y1 = this.logger;
      if (y.a())
        this.logger.e(this.tag, "Failed to handle native ad rendered. Could not retrieve tracker. Ad might not have been registered via MaxNativeAdLoader.a(...)."); 
      return;
    } 
    y1.b();
  }
  
  public void loadAd(MaxNativeAdView paramMaxNativeAdView) {
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str1 = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Loading native ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("' into '");
      stringBuilder.append(paramMaxNativeAdView);
      stringBuilder.append("' and notifying ");
      stringBuilder.append(this.a);
      stringBuilder.append("...");
      y.b(str1, stringBuilder.toString());
    } 
    Map<String, String> map = this.extraParameters;
    if (paramMaxNativeAdView != null) {
      str = "custom_ad_view";
    } else {
      str = "no_ad_view";
    } 
    map.put("integration_type", str);
    String str = UUID.randomUUID().toString().toLowerCase(Locale.US);
    a(str, paramMaxNativeAdView);
    this.sdk.am().loadAd(this.adUnitId, str, MaxAdFormat.NATIVE, this.d, this.localExtraParameters, this.extraParameters, o.au(), this.a);
  }
  
  public void onAdExpired(g paramg) {
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Ad expired for ad unit id ");
      stringBuilder.append(getAdUnitId());
      y.b(str, stringBuilder.toString());
    } 
    y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdExpired(nativeAd=");
      stringBuilder.append(paramg);
      stringBuilder.append("), listener=");
      stringBuilder.append(this.f);
      y.b(str, stringBuilder.toString());
    } 
    o.b(this.f, (MaxAd)paramg, true, true);
  }
  
  public void onCreativeIdGenerated(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Ljava/util/Set;
    //   4: invokeinterface iterator : ()Ljava/util/Iterator;
    //   9: astore #4
    //   11: aload #4
    //   13: invokeinterface hasNext : ()Z
    //   18: ifeq -> 48
    //   21: aload #4
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: checkcast com/applovin/impl/mediation/a/d
    //   31: astore_3
    //   32: aload_3
    //   33: invokevirtual j : ()Ljava/lang/String;
    //   36: aload_1
    //   37: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   40: ifeq -> 11
    //   43: aload_3
    //   44: astore_1
    //   45: goto -> 50
    //   48: aconst_null
    //   49: astore_1
    //   50: aload_1
    //   51: ifnull -> 94
    //   54: aload_1
    //   55: aload_2
    //   56: invokevirtual b : (Ljava/lang/String;)V
    //   59: aload_0
    //   60: getfield adReviewListener : Lcom/applovin/mediation/MaxAdReviewListener;
    //   63: aload_2
    //   64: aload_1
    //   65: invokestatic a : (Lcom/applovin/mediation/MaxAdReviewListener;Ljava/lang/String;Lcom/applovin/mediation/MaxAd;)V
    //   68: aload_0
    //   69: getfield e : Ljava/lang/Object;
    //   72: astore_2
    //   73: aload_2
    //   74: monitorenter
    //   75: aload_0
    //   76: getfield h : Ljava/util/Set;
    //   79: aload_1
    //   80: invokeinterface remove : (Ljava/lang/Object;)Z
    //   85: pop
    //   86: aload_2
    //   87: monitorexit
    //   88: return
    //   89: astore_1
    //   90: aload_2
    //   91: monitorexit
    //   92: aload_1
    //   93: athrow
    //   94: return
    // Exception table:
    //   from	to	target	type
    //   75	88	89	finally
    //   90	92	89	finally
  }
  
  public void registerClickableViews(List<View> paramList, ViewGroup paramViewGroup, MaxAd paramMaxAd) {
    y y;
    d d = (d)paramMaxAd;
    MaxNativeAd maxNativeAd = d.getNativeAd();
    if (maxNativeAd == null) {
      y = this.logger;
      if (y.a())
        this.logger.e(this.tag, "Failed to register native ad. Could not retrieve MaxNativeAd. The ad may have already been destroyed."); 
      return;
    } 
    this.sdk.ac().a(d);
    a((com.applovin.impl.mediation.a.a)d);
    maxNativeAd.setClickableViews((List)y);
    maxNativeAd.setAdViewTracker(new b(d, paramViewGroup, this.a, this.sdk));
    Runnable runnable = new Runnable(this, maxNativeAd, (List)y, paramViewGroup) {
        public void run() {
          if (!this.a.prepareForInteraction(this.b, this.c))
            y.j(this.d.tag, "Failed to prepare native ad for interaction..."); 
        }
      };
    if (maxNativeAd.shouldPrepareViewForInteractionOnMainThread()) {
      AppLovinSdkUtils.runOnUiThread(runnable);
      return;
    } 
    this.sdk.G().a((d)new ac(this.sdk, "renderMaxNativeAd", runnable), r.b.k);
  }
  
  public boolean render(MaxNativeAdView paramMaxNativeAdView, MaxAd paramMaxAd) {
    y y;
    if (!(paramMaxAd instanceof d)) {
      y.j(this.tag, "Failed to render native ad. `ad` needs to be of type `MediatedNativeAd` to render.");
      return false;
    } 
    if (paramMaxNativeAdView == null) {
      y.j(this.tag, "Failed to render native ad. `adView` to render cannot be null.");
      return false;
    } 
    d d = (d)paramMaxAd;
    MaxNativeAd maxNativeAd = d.getNativeAd();
    if (maxNativeAd == null) {
      y = this.logger;
      if (y.a())
        this.logger.e(this.tag, "Failed to render native ad. Could not retrieve MaxNativeAd. The ad may have already been destroyed."); 
      return false;
    } 
    if (maxNativeAd.isExpired() && !((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.E)).booleanValue()) {
      y.j(this.tag, "Cancelled rendering for expired native ad. Check if an ad is expired before displaying using `MaxAd.getNativeAd().isExpired()`");
      return false;
    } 
    a((MaxNativeAdView)y, d, maxNativeAd);
    a((MaxNativeAdView)y);
    return true;
  }
  
  public void setCustomData(String paramString) {
    w.a(paramString, this.tag);
    this.c = paramString;
  }
  
  public void setLocalExtraParameter(String paramString, Object paramObject) {
    super.setLocalExtraParameter(paramString, paramObject);
    if ("ad_request_type".equalsIgnoreCase(paramString) && paramObject instanceof d.a)
      this.d = (d.a)paramObject; 
  }
  
  public void setNativeAdListener(MaxNativeAdListener paramMaxNativeAdListener) {
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Setting native ad listener: ");
      stringBuilder.append(paramMaxNativeAdListener);
      y.b(str, stringBuilder.toString());
    } 
    this.f = paramMaxNativeAdListener;
  }
  
  public void setPlacement(String paramString) {
    this.b = paramString;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("MaxNativeAdLoader{adUnitId='");
    stringBuilder.append(this.adUnitId);
    stringBuilder.append("', nativeAdListener=");
    stringBuilder.append(this.f);
    stringBuilder.append(", revenueListener=");
    stringBuilder.append(this.revenueListener);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  private class a implements a.a {
    private a(MaxNativeAdLoaderImpl this$0) {}
    
    private void a(MaxNativeAdView param1MaxNativeAdView) {
      b b = param1MaxNativeAdView.getAdViewTracker();
      if (b == null)
        return; 
      d d = b.c();
      if (d != null) {
        y y = this.a.logger;
        if (y.a())
          this.a.logger.b(this.a.tag, "Destroying previous ad"); 
        this.a.destroy((MaxAd)d);
      } 
    }
    
    public void onAdClicked(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdClicked(nativeAd=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(MaxNativeAdLoaderImpl.f(this.a));
        y.b(str, stringBuilder.toString());
      } 
      o.a(MaxNativeAdLoaderImpl.f(this.a), param1MaxAd, true, true);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {}
    
    public void onAdDisplayed(MaxAd param1MaxAd) {}
    
    public void onAdHidden(MaxAd param1MaxAd) {}
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      String str = ((MaxErrorImpl)param1MaxError).getLoadTag();
      MaxNativeAdLoaderImpl.a(this.a, str);
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str1 = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdLoadFailed(adUnitId=");
        stringBuilder.append(param1String);
        stringBuilder.append(", error=");
        stringBuilder.append(param1MaxError);
        stringBuilder.append("), listener=");
        stringBuilder.append(MaxNativeAdLoaderImpl.f(this.a));
        y.b(str1, stringBuilder.toString());
      } 
      o.a(MaxNativeAdLoaderImpl.f(this.a), param1String, param1MaxError, true, true);
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      AppLovinSdkUtils.runOnUiThread(new Runnable(this, param1MaxAd) {
            public void run() {
              y y = this.b.a.logger;
              if (y.a())
                this.b.a.logger.b(this.b.a.tag, "Native ad loaded"); 
              d d = (d)this.a;
              d.e(MaxNativeAdLoaderImpl.b(this.b.a));
              d.f(MaxNativeAdLoaderImpl.c(this.b.a));
              this.b.a.sdk.ac().a(d);
              synchronized (MaxNativeAdLoaderImpl.d(this.b.a)) {
                MaxNativeAdLoaderImpl.e(this.b.a).add(d);
                null = d.d();
                MaxNativeAdView maxNativeAdView = MaxNativeAdLoaderImpl.a(this.b.a, (String)null);
                null = maxNativeAdView;
                if (maxNativeAdView == null) {
                  null = this.b.a.logger;
                  if (y.a())
                    this.b.a.logger.b(this.b.a.tag, "No custom view provided, checking template"); 
                  String str = d.J();
                  null = maxNativeAdView;
                  if (StringUtils.isValidString(str)) {
                    null = this.b.a.logger;
                    if (y.a()) {
                      null = this.b.a.logger;
                      String str1 = this.b.a.tag;
                      StringBuilder stringBuilder = new StringBuilder("Using template: ");
                      stringBuilder.append(str);
                      stringBuilder.append("...");
                      null.b(str1, stringBuilder.toString());
                    } 
                    null = new MaxNativeAdView(str, o.au());
                  } 
                } 
                if (null == null) {
                  null = this.b.a.logger;
                  if (y.a())
                    this.b.a.logger.b(this.b.a.tag, "No native ad view to render. Returning the native ad to be rendered later."); 
                  null = this.b.a.logger;
                  if (y.a()) {
                    null = this.b.a.logger;
                    String str = this.b.a.tag;
                    StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdLoaded(nativeAdView=null, nativeAd=");
                    stringBuilder.append(this.a);
                    stringBuilder.append("), listener=");
                    stringBuilder.append(MaxNativeAdLoaderImpl.f(this.b.a));
                    null.b(str, stringBuilder.toString());
                  } 
                  o.a(MaxNativeAdLoaderImpl.f(this.b.a), null, this.a, true, true);
                  MaxNativeAdLoaderImpl.a(this.b.a, d);
                  return;
                } 
                MaxNativeAdLoaderImpl.a.a(this.b, (MaxNativeAdView)null);
                MaxNativeAdLoaderImpl.a(this.b.a, (MaxNativeAdView)null, d, d.getNativeAd());
                y y1 = this.b.a.logger;
                if (y.a()) {
                  y1 = this.b.a.logger;
                  String str = this.b.a.tag;
                  StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdLoaded(nativeAdView=");
                  stringBuilder.append(null);
                  stringBuilder.append(", nativeAd=");
                  stringBuilder.append(this.a);
                  stringBuilder.append("), listener=");
                  stringBuilder.append(MaxNativeAdLoaderImpl.f(this.b.a));
                  y1.b(str, stringBuilder.toString());
                } 
                o.a(MaxNativeAdLoaderImpl.f(this.b.a), (MaxNativeAdView)null, this.a, true, true);
                MaxNativeAdLoaderImpl.a(this.b.a, d);
                MaxNativeAdLoaderImpl.a(this.b.a, (MaxNativeAdView)null);
                return;
              } 
            }
          });
    }
    
    public void onAdRequestStarted(String param1String) {}
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdRevenueListener.onAdRevenuePaid(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.revenueListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.a.revenueListener, param1MaxAd, true, true);
    }
  }
  
  class null implements Runnable {
    null(MaxNativeAdLoaderImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      y y = this.b.a.logger;
      if (y.a())
        this.b.a.logger.b(this.b.a.tag, "Native ad loaded"); 
      d d = (d)this.a;
      d.e(MaxNativeAdLoaderImpl.b(this.b.a));
      d.f(MaxNativeAdLoaderImpl.c(this.b.a));
      this.b.a.sdk.ac().a(d);
      synchronized (MaxNativeAdLoaderImpl.d(this.b.a)) {
        MaxNativeAdLoaderImpl.e(this.b.a).add(d);
        null = d.d();
        MaxNativeAdView maxNativeAdView = MaxNativeAdLoaderImpl.a(this.b.a, (String)null);
        null = maxNativeAdView;
        if (maxNativeAdView == null) {
          null = this.b.a.logger;
          if (y.a())
            this.b.a.logger.b(this.b.a.tag, "No custom view provided, checking template"); 
          String str = d.J();
          null = maxNativeAdView;
          if (StringUtils.isValidString(str)) {
            null = this.b.a.logger;
            if (y.a()) {
              null = this.b.a.logger;
              String str1 = this.b.a.tag;
              StringBuilder stringBuilder = new StringBuilder("Using template: ");
              stringBuilder.append(str);
              stringBuilder.append("...");
              null.b(str1, stringBuilder.toString());
            } 
            null = new MaxNativeAdView(str, o.au());
          } 
        } 
        if (null == null) {
          null = this.b.a.logger;
          if (y.a())
            this.b.a.logger.b(this.b.a.tag, "No native ad view to render. Returning the native ad to be rendered later."); 
          null = this.b.a.logger;
          if (y.a()) {
            null = this.b.a.logger;
            String str = this.b.a.tag;
            StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdLoaded(nativeAdView=null, nativeAd=");
            stringBuilder.append(this.a);
            stringBuilder.append("), listener=");
            stringBuilder.append(MaxNativeAdLoaderImpl.f(this.b.a));
            null.b(str, stringBuilder.toString());
          } 
          o.a(MaxNativeAdLoaderImpl.f(this.b.a), null, this.a, true, true);
          MaxNativeAdLoaderImpl.a(this.b.a, d);
          return;
        } 
        MaxNativeAdLoaderImpl.a.a(this.b, (MaxNativeAdView)null);
        MaxNativeAdLoaderImpl.a(this.b.a, (MaxNativeAdView)null, d, d.getNativeAd());
        y y1 = this.b.a.logger;
        if (y.a()) {
          y1 = this.b.a.logger;
          String str = this.b.a.tag;
          StringBuilder stringBuilder = new StringBuilder("MaxNativeAdListener.onNativeAdLoaded(nativeAdView=");
          stringBuilder.append(null);
          stringBuilder.append(", nativeAd=");
          stringBuilder.append(this.a);
          stringBuilder.append("), listener=");
          stringBuilder.append(MaxNativeAdLoaderImpl.f(this.b.a));
          y1.b(str, stringBuilder.toString());
        } 
        o.a(MaxNativeAdLoaderImpl.f(this.b.a), (MaxNativeAdView)null, this.a, true, true);
        MaxNativeAdLoaderImpl.a(this.b.a, d);
        MaxNativeAdLoaderImpl.a(this.b.a, (MaxNativeAdView)null);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\ads\MaxNativeAdLoaderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */