package com.applovin.impl.mediation;

import android.text.TextUtils;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.a.f;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.sdk.AppLovinSdk;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

public class f {
  private final Map<String, g> a = Collections.synchronizedMap(new HashMap<String, g>(16));
  
  private final o b;
  
  private final y c;
  
  private final Object d = new Object();
  
  private final Map<String, Class<? extends MaxAdapter>> e = new HashMap<String, Class<? extends MaxAdapter>>();
  
  private final Set<String> f = new HashSet<String>();
  
  private final Object g = new Object();
  
  private final Set<a> h = new HashSet<a>();
  
  public f(o paramo) {
    if (paramo != null) {
      this.b = paramo;
      this.c = paramo.F();
      return;
    } 
    throw new IllegalArgumentException("No sdk specified");
  }
  
  private g a(f paramf, Class<? extends MaxAdapter> paramClass, boolean paramBoolean) {
    try {
      return new g(paramf, (MaxAdapter)paramClass.getConstructor(new Class[] { AppLovinSdk.class }, ).newInstance(new Object[] { this.b.aA() }, ), paramBoolean, this.b);
    } finally {
      paramClass = null;
      StringBuilder stringBuilder = new StringBuilder("Failed to load adapter: ");
      stringBuilder.append(paramf);
      y.c("MediationAdapterManager", stringBuilder.toString(), (Throwable)paramClass);
    } 
  }
  
  private Class<? extends MaxAdapter> a(String paramString) {
    try {
      Class<?> clazz = Class.forName(paramString);
      if (MaxAdapter.class.isAssignableFrom(clazz))
        return clazz.asSubclass(MaxAdapter.class); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(" error: not an instance of '");
      stringBuilder.append(MaxAdapter.class.getName());
      stringBuilder.append("'.");
      y.j("MediationAdapterManager", stringBuilder.toString());
    } finally {}
    return null;
  }
  
  g a(f paramf) {
    return a(paramf, false);
  }
  
  g a(f paramf, boolean paramBoolean) {
    if (paramf != null) {
      String str1 = paramf.ac();
      String str2 = paramf.ab();
      if (TextUtils.isEmpty(str1)) {
        if (y.a()) {
          null = this.c;
          StringBuilder stringBuilder = new StringBuilder("No adapter name provided for ");
          stringBuilder.append(str2);
          stringBuilder.append(", not loading the adapter ");
          null.e("MediationAdapterManager", stringBuilder.toString());
        } 
        return null;
      } 
      if (TextUtils.isEmpty(str2)) {
        if (y.a()) {
          null = this.c;
          StringBuilder stringBuilder = new StringBuilder("Unable to find default className for '");
          stringBuilder.append(str1);
          stringBuilder.append("'");
          null.e("MediationAdapterManager", stringBuilder.toString());
        } 
        return null;
      } 
      if (paramBoolean) {
        g g = this.a.get(str2);
        if (g != null)
          return g; 
      } 
      synchronized (this.d) {
        if (!this.f.contains(str2)) {
          Class<? extends MaxAdapter> clazz;
          if (this.e.containsKey(str2)) {
            clazz = this.e.get(str2);
          } else {
            Class<? extends MaxAdapter> clazz1 = a(str2);
            clazz = clazz1;
            if (clazz1 == null) {
              this.f.add(str2);
              return null;
            } 
          } 
          g g = a((f)null, clazz, paramBoolean);
          if (g != null) {
            if (y.a()) {
              y y1 = this.c;
              StringBuilder stringBuilder = new StringBuilder("Loaded ");
              stringBuilder.append(str1);
              y1.b("MediationAdapterManager", stringBuilder.toString());
            } 
            this.e.put(str2, clazz);
            if (paramBoolean)
              this.a.put(null.ab(), g); 
            return g;
          } 
          if (y.a()) {
            null = this.c;
            StringBuilder stringBuilder = new StringBuilder("Failed to load ");
            stringBuilder.append(str1);
            null.e("MediationAdapterManager", stringBuilder.toString());
          } 
          this.f.add(str2);
          return null;
        } 
        if (y.a()) {
          null = this.c;
          StringBuilder stringBuilder = new StringBuilder("Not attempting to load ");
          stringBuilder.append(str1);
          stringBuilder.append(" due to prior errors");
          null.b("MediationAdapterManager", stringBuilder.toString());
        } 
        return null;
      } 
    } 
    throw new IllegalArgumentException("No adapter spec specified");
  }
  
  public Collection<String> a() {
    synchronized (this.d) {
      HashSet<String> hashSet = new HashSet(this.e.size());
      Iterator<Class<?>> iterator = this.e.values().iterator();
      while (iterator.hasNext())
        hashSet.add(((Class)iterator.next()).getName()); 
      return Collections.unmodifiableSet(hashSet);
    } 
  }
  
  public void a(String paramString1, String paramString2, a parama) {
    synchronized (this.g) {
      this.b.F();
      if (y.a()) {
        y y1 = this.b.F();
        StringBuilder stringBuilder = new StringBuilder("Adding ");
        stringBuilder.append(paramString1);
        stringBuilder.append(" to list of disabled adapters.");
        y1.e("MediationAdapterManager", stringBuilder.toString());
      } 
      a a1 = new a(paramString1, paramString2, parama, this.b);
      this.h.add(a1);
      return;
    } 
  }
  
  public Collection<String> b() {
    synchronized (this.d) {
      return Collections.unmodifiableSet(this.f);
    } 
  }
  
  public Collection<JSONObject> c() {
    synchronized (this.g) {
      ArrayList<JSONObject> arrayList = new ArrayList(this.h.size());
      Iterator<a> iterator = this.h.iterator();
      while (iterator.hasNext())
        arrayList.add(((a)iterator.next()).a()); 
      return arrayList;
    } 
  }
  
  private static class a {
    private final String a;
    
    private final String b;
    
    private final MaxAdFormat c;
    
    private final JSONObject d;
    
    a(String param1String1, String param1String2, a param1a, o param1o) {
      this.a = param1String1;
      this.b = param1String2;
      JSONObject jSONObject = new JSONObject();
      this.d = jSONObject;
      JsonUtils.putString(jSONObject, "class", param1String1);
      JsonUtils.putString(jSONObject, "operation", param1String2);
      if (param1a != null) {
        this.c = param1a.getFormat();
        JsonUtils.putString(jSONObject, "format", param1a.getFormat().getLabel());
        return;
      } 
      this.c = null;
    }
    
    JSONObject a() {
      return this.d;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        a a1 = (a)param1Object;
        if (!this.a.equals(a1.a))
          return false; 
        if (!this.b.equals(a1.b))
          return false; 
        param1Object = this.c;
        MaxAdFormat maxAdFormat = a1.c;
        if (param1Object != null) {
          if (!param1Object.equals(maxAdFormat))
            return false; 
        } else if (maxAdFormat != null) {
          return false;
        } 
        return true;
      } 
      return false;
    }
    
    public int hashCode() {
      byte b;
      int i = this.a.hashCode();
      int j = this.b.hashCode();
      MaxAdFormat maxAdFormat = this.c;
      if (maxAdFormat != null) {
        b = maxAdFormat.hashCode();
      } else {
        b = 0;
      } 
      return (i * 31 + j) * 31 + b;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("DisabledAdapterInfo{className='");
      stringBuilder.append(this.a);
      stringBuilder.append("', operationTag='");
      stringBuilder.append(this.b);
      stringBuilder.append("', format=");
      stringBuilder.append(this.c);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */