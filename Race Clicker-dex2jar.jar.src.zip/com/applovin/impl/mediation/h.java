package com.applovin.impl.mediation;

import com.applovin.impl.mediation.a.a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class h {
  private final List<a> a = Collections.synchronizedList(new ArrayList<a>());
  
  public void a(a parama) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).a(parama); 
  }
  
  public void a(a parama) {
    this.a.add(parama);
  }
  
  public void b(a parama) {
    this.a.remove(parama);
  }
  
  public static interface a {
    void a(a param1a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */