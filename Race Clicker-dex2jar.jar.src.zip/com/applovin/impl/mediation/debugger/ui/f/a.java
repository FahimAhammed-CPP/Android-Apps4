package com.applovin.impl.mediation.debugger.ui.f;

import android.content.Context;
import android.os.Bundle;
import android.text.SpannedString;
import android.view.MotionEvent;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.applovin.communicator.AppLovinCommunicatorMessage;
import com.applovin.impl.mediation.debugger.b.a.c;
import com.applovin.impl.mediation.debugger.b.c.b;
import com.applovin.impl.mediation.debugger.ui.a;
import com.applovin.impl.mediation.debugger.ui.d.c;
import com.applovin.impl.mediation.debugger.ui.d.d;
import com.applovin.impl.mediation.debugger.ui.d.e;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.sdk.R;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import java.util.ArrayList;
import java.util.List;

public class a extends a {
  private o a;
  
  private List<c> b;
  
  private List<c> c;
  
  private d d;
  
  private List<c> e;
  
  private List<c> f;
  
  private ListView g;
  
  public a() {
    this.communicatorTopics.add("network_sdk_version_updated");
  }
  
  private c a(com.applovin.impl.mediation.debugger.ui.d.a parama) {
    return (parama.a() == a.a.ordinal()) ? this.b.get(parama.b()) : this.c.get(parama.b());
  }
  
  private List<c> a(List<c> paramList) {
    ArrayList<com.applovin.impl.mediation.debugger.ui.b.a.a> arrayList = new ArrayList(paramList.size());
    for (c c : paramList) {
      arrayList.add(new com.applovin.impl.mediation.debugger.ui.b.a.a(this, c.c(), (Context)this, c) {
            public int a() {
              return (a.d(this.o).as().c() != null && a.d(this.o).as().c().equals(this.a.a())) ? R.drawable.applovin_ic_check_mark_borderless : 0;
            }
            
            public int b() {
              return (a.d(this.o).as().c() != null && a.d(this.o).as().c().equals(this.a.a())) ? -16776961 : super.b();
            }
            
            public SpannedString k() {
              int i;
              if (c()) {
                i = -16777216;
              } else {
                i = -7829368;
              } 
              return StringUtils.createSpannedString(this.a.b(), i, 18, 1);
            }
          });
    } 
    return (List)arrayList;
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.applovin", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected o getSdk() {
    return this.a;
  }
  
  public void initialize(List<c> paramList1, List<c> paramList2, o paramo) {
    this.a = paramo;
    this.b = paramList1;
    this.c = paramList2;
    this.e = a(paramList1);
    this.f = a(paramList2);
    d d1 = new d(this, (Context)this) {
        protected int a(int param1Int) {
          return (param1Int == a.a.a.ordinal()) ? a.a(this.a).size() : a.b(this.a).size();
        }
        
        protected c b(int param1Int) {
          return (c)((param1Int == a.a.a.ordinal()) ? new e("BIDDERS") : new e("WATERFALL"));
        }
        
        protected List<c> c(int param1Int) {
          return (param1Int == a.a.a.ordinal()) ? a.a(this.a) : a.b(this.a);
        }
        
        protected int e() {
          return a.a.c.ordinal();
        }
        
        protected c n() {
          return (new c.a(c.b.b)).a("Select a network to load ads using your MAX ad unit configuration. Once enabled, this functionality will reset on the next app session.").a();
        }
      };
    this.d = d1;
    d1.a(new d.a(this, paramo) {
          public void onClick(com.applovin.impl.mediation.debugger.ui.d.a param1a, c param1c) {
            c c1 = a.a(this.b, param1a);
            if (StringUtils.isValidString(c1.a()) && StringUtils.isValidString(this.a.as().c()) && c1.a().equals(this.a.as().c())) {
              this.a.as().a(null);
            } else {
              this.a.as().a(c1.a());
            } 
            a.c(this.b).notifyDataSetChanged();
          }
        });
    this.d.notifyDataSetChanged();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setTitle("Select Live Network");
    setContentView(R.layout.mediation_debugger_list_view);
    ListView listView = (ListView)findViewById(R.id.listView);
    this.g = listView;
    listView.setAdapter((ListAdapter)this.d);
  }
  
  public void onMessageReceived(AppLovinCommunicatorMessage paramAppLovinCommunicatorMessage) {
    this.e = a(this.b);
    this.f = a(this.c);
    this.d.m();
  }
  
  enum a {
    a, b, c;
    
    static {
      a a1 = new a("BIDDERS", 0);
      a = a1;
      a a2 = new a("WATERFALL", 1);
      b = a2;
      a a3 = new a("COUNT", 2);
      c = a3;
      d = new a[] { a1, a2, a3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\debugge\\ui\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */