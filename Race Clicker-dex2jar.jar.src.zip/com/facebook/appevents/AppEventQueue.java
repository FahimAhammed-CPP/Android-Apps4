package com.facebook.appevents;

import android.os.Bundle;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.internal.FetchedAppSettings;
import com.facebook.internal.FetchedAppSettingsManager;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;

@Metadata(d1 = {"\000~\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020 \n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\"\n\002\b\003\n\002\030\002\n\002\b\003\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\030\020\022\032\0020\0232\006\020\024\032\0020\0252\006\020\026\032\0020\027H\007J*\020\030\032\004\030\0010\0312\006\020\024\032\0020\0252\006\020\032\032\0020\0332\006\020\034\032\0020\0352\006\020\036\032\0020\037H\007J\036\020 \032\b\022\004\022\0020\0310!2\006\020\t\032\0020\n2\006\020\"\032\0020\037H\007J\020\020#\032\0020\0232\006\020$\032\0020%H\007J\020\020&\032\0020\0232\006\020$\032\0020%H\007J\016\020'\032\b\022\004\022\0020\0250(H\007J0\020)\032\0020\0232\006\020\024\032\0020\0252\006\020*\032\0020\0312\006\020+\032\0020,2\006\020\032\032\0020\0332\006\020\036\032\0020\037H\007J\b\020-\032\0020\023H\007J\032\020.\032\004\030\0010\0372\006\020$\032\0020%2\006\020\t\032\0020\nH\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XD¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000R\016\020\t\032\0020\nX\016¢\006\002\n\000R\016\020\013\032\0020\fX\004¢\006\002\n\000R\024\020\r\032\b\022\002\b\003\030\0010\016X\016¢\006\002\n\000R\026\020\017\032\n \021*\004\030\0010\0200\020X\004¢\006\002\n\000¨\006/"}, d2 = {"Lcom/facebook/appevents/AppEventQueue;", "", "()V", "FLUSH_PERIOD_IN_SECONDS", "", "NO_CONNECTIVITY_ERROR_CODE", "NUM_LOG_EVENTS_TO_TRY_TO_FLUSH_AFTER", "TAG", "", "appEventCollection", "Lcom/facebook/appevents/AppEventCollection;", "flushRunnable", "Ljava/lang/Runnable;", "scheduledFuture", "Ljava/util/concurrent/ScheduledFuture;", "singleThreadExecutor", "Ljava/util/concurrent/ScheduledExecutorService;", "kotlin.jvm.PlatformType", "add", "", "accessTokenAppId", "Lcom/facebook/appevents/AccessTokenAppIdPair;", "appEvent", "Lcom/facebook/appevents/AppEvent;", "buildRequestForSession", "Lcom/facebook/GraphRequest;", "appEvents", "Lcom/facebook/appevents/SessionEventsState;", "limitEventUsage", "", "flushState", "Lcom/facebook/appevents/FlushStatistics;", "buildRequests", "", "flushResults", "flush", "reason", "Lcom/facebook/appevents/FlushReason;", "flushAndWait", "getKeySet", "", "handleResponse", "request", "response", "Lcom/facebook/GraphResponse;", "persistToDisk", "sendEventsToServer", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AppEventQueue {
  private static final int FLUSH_PERIOD_IN_SECONDS = 15;
  
  public static final AppEventQueue INSTANCE = new AppEventQueue();
  
  private static final int NO_CONNECTIVITY_ERROR_CODE = -1;
  
  private static final int NUM_LOG_EVENTS_TO_TRY_TO_FLUSH_AFTER;
  
  private static final String TAG;
  
  private static volatile AppEventCollection appEventCollection;
  
  private static final Runnable flushRunnable;
  
  private static ScheduledFuture<?> scheduledFuture;
  
  private static final ScheduledExecutorService singleThreadExecutor;
  
  static {
    String str = AppEventQueue.class.getName();
    Intrinsics.checkNotNullExpressionValue(str, "AppEventQueue::class.java.name");
    TAG = str;
    NUM_LOG_EVENTS_TO_TRY_TO_FLUSH_AFTER = 100;
    appEventCollection = new AppEventCollection();
    singleThreadExecutor = Executors.newSingleThreadScheduledExecutor();
    flushRunnable = AppEventQueue$flushRunnable$1.INSTANCE;
  }
  
  @JvmStatic
  public static final void add(AccessTokenAppIdPair paramAccessTokenAppIdPair, AppEvent paramAppEvent) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramAccessTokenAppIdPair, "accessTokenAppId");
      return;
    } finally {
      paramAccessTokenAppIdPair = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessTokenAppIdPair, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final GraphRequest buildRequestForSession(AccessTokenAppIdPair paramAccessTokenAppIdPair, SessionEventsState paramSessionEventsState, boolean paramBoolean, FlushStatistics paramFlushStatistics) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramAccessTokenAppIdPair, "accessTokenAppId");
      Intrinsics.checkNotNullParameter(paramSessionEventsState, "appEvents");
      Intrinsics.checkNotNullParameter(paramFlushStatistics, "flushState");
      String str2 = paramAccessTokenAppIdPair.getApplicationId();
      boolean bool = false;
      FetchedAppSettings fetchedAppSettings = FetchedAppSettingsManager.queryAppSettings(str2, false);
      GraphRequest.Companion companion = GraphRequest.Companion;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      str2 = String.format("%s/activities", Arrays.copyOf(new Object[] { str2 }, 1));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      GraphRequest graphRequest = companion.newPostRequest(null, str2, null, null);
      graphRequest.setForceApplicationRequest(true);
      Bundle bundle2 = graphRequest.getParameters();
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putString("access_token", paramAccessTokenAppIdPair.getAccessTokenString());
      String str1 = InternalAppEventsLogger.Companion.getPushNotificationsRegistrationId();
      if (str1 != null)
        bundle1.putString("device_token", str1); 
      str1 = AppEventsLoggerImpl.Companion.getInstallReferrer();
      if (str1 != null)
        bundle1.putString("install_referrer", str1); 
      graphRequest.setParameters(bundle1);
      if (fetchedAppSettings != null)
        bool = fetchedAppSettings.supportsImplicitLogging(); 
      int i = paramSessionEventsState.populateRequest(graphRequest, FacebookSdk.getApplicationContext(), bool, paramBoolean);
      if (i == 0)
        return null; 
      return graphRequest;
    } finally {
      paramAccessTokenAppIdPair = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessTokenAppIdPair, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final List<GraphRequest> buildRequests(AppEventCollection paramAppEventCollection, FlushStatistics paramFlushStatistics) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramAppEventCollection, "appEventCollection");
      Intrinsics.checkNotNullParameter(paramFlushStatistics, "flushResults");
      boolean bool = FacebookSdk.getLimitEventAndDataUsage(FacebookSdk.getApplicationContext());
      return arrayList;
    } finally {
      paramAppEventCollection = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAppEventCollection, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final void flush(FlushReason paramFlushReason) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return; 
    try {
      return;
    } finally {
      paramFlushReason = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFlushReason, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final void flushAndWait(FlushReason paramFlushReason) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramFlushReason, "reason");
      PersistedEvents persistedEvents = AppEventStore.readAndClearStore();
    } finally {
      paramFlushReason = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFlushReason, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final Set<AccessTokenAppIdPair> getKeySet() {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return null; 
    try {
      return appEventCollection.keySet();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final void handleResponse(AccessTokenAppIdPair paramAccessTokenAppIdPair, GraphRequest paramGraphRequest, GraphResponse paramGraphResponse, SessionEventsState paramSessionEventsState, FlushStatistics paramFlushStatistics) {
    boolean bool;
    FlushResult flushResult;
    FacebookRequestError facebookRequestError;
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramAccessTokenAppIdPair, "accessTokenAppId");
      Intrinsics.checkNotNullParameter(paramGraphRequest, "request");
      Intrinsics.checkNotNullParameter(paramGraphResponse, "response");
      Intrinsics.checkNotNullParameter(paramSessionEventsState, "appEvents");
      Intrinsics.checkNotNullParameter(paramFlushStatistics, "flushState");
      facebookRequestError = paramGraphResponse.getError();
      String str = "Success";
      flushResult = FlushResult.SUCCESS;
      bool = true;
    } finally {
      paramAccessTokenAppIdPair = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessTokenAppIdPair, AppEventQueue.class);
    } 
    if (facebookRequestError == null)
      bool = false; 
    paramSessionEventsState.clearInFlightAndStats(bool);
    if (flushResult == FlushResult.NO_CONNECTIVITY)
      FacebookSdk.getExecutor().execute(new AppEventQueue$handleResponse$1(paramAccessTokenAppIdPair, paramSessionEventsState)); 
    if (flushResult != FlushResult.SUCCESS && paramFlushStatistics.getResult() != FlushResult.NO_CONNECTIVITY)
      paramFlushStatistics.setResult(flushResult); 
  }
  
  @JvmStatic
  public static final void persistToDisk() {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, AppEventQueue.class);
    } 
  }
  
  @JvmStatic
  public static final FlushStatistics sendEventsToServer(FlushReason paramFlushReason, AppEventCollection paramAppEventCollection) {
    if (CrashShieldHandler.isObjectCrashing(AppEventQueue.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramFlushReason, "reason");
      Intrinsics.checkNotNullParameter(paramAppEventCollection, "appEventCollection");
      FlushStatistics flushStatistics = new FlushStatistics();
      return null;
    } finally {
      paramFlushReason = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFlushReason, AppEventQueue.class);
    } 
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$add$1 implements Runnable {
    AppEventQueue$add$1(AccessTokenAppIdPair param1AccessTokenAppIdPair, AppEvent param1AppEvent) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "response", "Lcom/facebook/GraphResponse;", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$buildRequestForSession$1 implements GraphRequest.Callback {
    AppEventQueue$buildRequestForSession$1(AccessTokenAppIdPair param1AccessTokenAppIdPair, GraphRequest param1GraphRequest, SessionEventsState param1SessionEventsState, FlushStatistics param1FlushStatistics) {}
    
    public final void onCompleted(GraphResponse param1GraphResponse) {
      Intrinsics.checkNotNullParameter(param1GraphResponse, "response");
      AppEventQueue.handleResponse(this.$accessTokenAppId, this.$postRequest, param1GraphResponse, this.$appEvents, this.$flushState);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$flush$1 implements Runnable {
    AppEventQueue$flush$1(FlushReason param1FlushReason) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$flushRunnable$1 implements Runnable {
    public static final AppEventQueue$flushRunnable$1 INSTANCE = new AppEventQueue$flushRunnable$1();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$handleResponse$1 implements Runnable {
    AppEventQueue$handleResponse$1(AccessTokenAppIdPair param1AccessTokenAppIdPair, SessionEventsState param1SessionEventsState) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AppEventQueue$persistToDisk$1 implements Runnable {
    public static final AppEventQueue$persistToDisk$1 INSTANCE = new AppEventQueue$persistToDisk$1();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\AppEventQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */