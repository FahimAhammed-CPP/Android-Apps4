package com.facebook.appevents;

import android.preference.PreferenceManager;
import android.util.Log;
import com.facebook.FacebookSdk;
import com.facebook.appevents.internal.AppEventUtility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\020\002\n\002\b\004\bÀ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\n\020\013\032\004\030\0010\004H\007J\b\020\f\032\0020\rH\002J\b\020\016\032\0020\rH\007J\022\020\017\032\0020\r2\b\020\020\032\004\030\0010\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004X\004¢\006\002\n\000R\016\020\006\032\0020\007X\016¢\006\002\n\000R\016\020\b\032\0020\tX\004¢\006\002\n\000R\020\020\n\032\004\030\0010\004X\016¢\006\002\n\000¨\006\021"}, d2 = {"Lcom/facebook/appevents/AnalyticsUserIDStore;", "", "()V", "ANALYTICS_USER_ID_KEY", "", "TAG", "initialized", "", "lock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "userID", "getUserID", "initAndWait", "", "initStore", "setUserID", "id", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AnalyticsUserIDStore {
  private static final String ANALYTICS_USER_ID_KEY = "com.facebook.appevents.AnalyticsUserIDStore.userID";
  
  public static final AnalyticsUserIDStore INSTANCE = new AnalyticsUserIDStore();
  
  private static final String TAG = "AnalyticsUserIDStore";
  
  private static volatile boolean initialized;
  
  private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
  
  private static String userID;
  
  @JvmStatic
  public static final String getUserID() {
    if (!initialized) {
      Log.w(TAG, "initStore should have been called before calling setUserID");
      INSTANCE.initAndWait();
    } 
    null = lock;
    null.readLock().lock();
    try {
      return userID;
    } finally {
      lock.readLock().unlock();
    } 
  }
  
  private final void initAndWait() {
    if (initialized)
      return; 
    null = lock;
    null.writeLock().lock();
    try {
      boolean bool = initialized;
      if (bool)
        return; 
      userID = PreferenceManager.getDefaultSharedPreferences(FacebookSdk.getApplicationContext()).getString("com.facebook.appevents.AnalyticsUserIDStore.userID", null);
      initialized = true;
      return;
    } finally {
      lock.writeLock().unlock();
    } 
  }
  
  @JvmStatic
  public static final void initStore() {
    if (initialized)
      return; 
    InternalAppEventsLogger.Companion.getAnalyticsExecutor().execute(AnalyticsUserIDStore$initStore$1.INSTANCE);
  }
  
  @JvmStatic
  public static final void setUserID(String paramString) {
    AppEventUtility.assertIsNotMainThread();
    if (!initialized) {
      Log.w(TAG, "initStore should have been called before calling setUserID");
      INSTANCE.initAndWait();
    } 
    InternalAppEventsLogger.Companion.getAnalyticsExecutor().execute(new AnalyticsUserIDStore$setUserID$1(paramString));
  }
  
  static {
    Intrinsics.checkNotNullExpressionValue("AnalyticsUserIDStore", "AnalyticsUserIDStore::class.java.simpleName");
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AnalyticsUserIDStore$initStore$1 implements Runnable {
    public static final AnalyticsUserIDStore$initStore$1 INSTANCE = new AnalyticsUserIDStore$initStore$1();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class AnalyticsUserIDStore$setUserID$1 implements Runnable {
    AnalyticsUserIDStore$setUserID$1(String param1String) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\AnalyticsUserIDStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */