package com.facebook.appevents;

import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lcom/facebook/appevents/FlushResult;", "", "(Ljava/lang/String;I)V", "SUCCESS", "SERVER_ERROR", "NO_CONNECTIVITY", "UNKNOWN_ERROR", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public enum FlushResult {
  NO_CONNECTIVITY, SERVER_ERROR, SUCCESS, UNKNOWN_ERROR;
  
  static {
    FlushResult flushResult1 = new FlushResult("SUCCESS", 0);
    SUCCESS = flushResult1;
    FlushResult flushResult2 = new FlushResult("SERVER_ERROR", 1);
    SERVER_ERROR = flushResult2;
    FlushResult flushResult3 = new FlushResult("NO_CONNECTIVITY", 2);
    NO_CONNECTIVITY = flushResult3;
    FlushResult flushResult4 = new FlushResult("UNKNOWN_ERROR", 3);
    UNKNOWN_ERROR = flushResult4;
    $VALUES = new FlushResult[] { flushResult1, flushResult2, flushResult3, flushResult4 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\FlushResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */