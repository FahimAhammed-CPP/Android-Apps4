package com.facebook.appevents.aam;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewTreeObserver;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020#\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\004\b\001\030\000 \0332\0020\001:\001\033B\017\b\002\022\006\020\002\032\0020\003¢\006\002\020\004J\034\020\016\032\0020\0172\b\020\020\032\004\030\0010\0212\b\020\022\032\004\030\0010\021H\026J\020\020\023\032\0020\0172\006\020\024\032\0020\021H\002J\020\020\025\032\0020\0172\006\020\024\032\0020\021H\002J\020\020\026\032\0020\0172\006\020\027\032\0020\030H\002J\b\020\031\032\0020\017H\002J\b\020\032\032\0020\017H\002R\024\020\005\032\b\022\004\022\0020\0030\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000R\024\020\t\032\b\022\004\022\0020\0130\nX\004¢\006\002\n\000R\016\020\f\032\0020\rX\004¢\006\002\n\000¨\006\034"}, d2 = {"Lcom/facebook/appevents/aam/MetadataViewObserver;", "Landroid/view/ViewTreeObserver$OnGlobalFocusChangeListener;", "activity", "Landroid/app/Activity;", "(Landroid/app/Activity;)V", "activityWeakReference", "Ljava/lang/ref/WeakReference;", "isTracking", "Ljava/util/concurrent/atomic/AtomicBoolean;", "processedText", "", "", "uiThreadHandler", "Landroid/os/Handler;", "onGlobalFocusChanged", "", "oldView", "Landroid/view/View;", "newView", "process", "view", "processEditText", "runOnUIThread", "runnable", "Ljava/lang/Runnable;", "startTracking", "stopTracking", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class MetadataViewObserver implements ViewTreeObserver.OnGlobalFocusChangeListener {
  public static final Companion Companion = new Companion(null);
  
  private static final int MAX_TEXT_LENGTH = 100;
  
  private static final Map<Integer, MetadataViewObserver> observers = new HashMap<Integer, MetadataViewObserver>();
  
  private final WeakReference<Activity> activityWeakReference;
  
  private final AtomicBoolean isTracking;
  
  private final Set<String> processedText = new LinkedHashSet<String>();
  
  private final Handler uiThreadHandler = new Handler(Looper.getMainLooper());
  
  private MetadataViewObserver(Activity paramActivity) {
    this.activityWeakReference = new WeakReference<Activity>(paramActivity);
    this.isTracking = new AtomicBoolean(false);
  }
  
  private final void process(View paramView) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramView = null;
      CrashShieldHandler.handleThrowable((Throwable)paramView, this);
    } 
  }
  
  private final void processEditText(View paramView) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    if (paramView != null)
      try {
        return;
      } finally {
        paramView = null;
        CrashShieldHandler.handleThrowable((Throwable)paramView, this);
      }  
    throw new NullPointerException("null cannot be cast to non-null type android.widget.EditText");
  }
  
  private final void runOnUIThread(Runnable paramRunnable) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      Thread thread = Thread.currentThread();
      Looper looper = Looper.getMainLooper();
      Intrinsics.checkNotNullExpressionValue(looper, "Looper.getMainLooper()");
      return;
    } finally {
      paramRunnable = null;
      CrashShieldHandler.handleThrowable((Throwable)paramRunnable, this);
    } 
  }
  
  private final void startTracking() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      if (this.isTracking.getAndSet(true))
        return; 
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @JvmStatic
  public static final void startTrackingActivity(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(MetadataViewObserver.class))
      return; 
    try {
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, MetadataViewObserver.class);
    } 
  }
  
  private final void stopTracking() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      if (!this.isTracking.getAndSet(false))
        return; 
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @JvmStatic
  public static final void stopTrackingActivity(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(MetadataViewObserver.class))
      return; 
    try {
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, MetadataViewObserver.class);
    } 
  }
  
  public void onGlobalFocusChanged(View paramView1, View paramView2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    if (paramView1 != null)
      try {
        process(paramView1);
        if (paramView2 != null)
          return; 
      } finally {
        paramView1 = null;
      }  
    if (paramView2 != null) {
      process(paramView2);
      return;
    } 
  }
  
  @Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\020%\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\030\020\b\032\0020\t2\006\020\n\032\0020\t2\006\020\013\032\0020\tH\002J,\020\f\032\0020\r2\022\020\016\032\016\022\004\022\0020\t\022\004\022\0020\t0\0062\006\020\n\032\0020\t2\006\020\013\032\0020\tH\002J\020\020\017\032\0020\r2\006\020\020\032\0020\021H\007J\020\020\022\032\0020\r2\006\020\020\032\0020\021H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\032\020\005\032\016\022\004\022\0020\004\022\004\022\0020\0070\006X\004¢\006\002\n\000¨\006\023"}, d2 = {"Lcom/facebook/appevents/aam/MetadataViewObserver$Companion;", "", "()V", "MAX_TEXT_LENGTH", "", "observers", "", "Lcom/facebook/appevents/aam/MetadataViewObserver;", "preNormalize", "", "key", "value", "putUserData", "", "userData", "startTrackingActivity", "activity", "Landroid/app/Activity;", "stopTrackingActivity", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    private final String preNormalize(String param1String1, String param1String2) {
      String str = param1String2;
      if (Intrinsics.areEqual("r2", param1String1)) {
        CharSequence charSequence = param1String2;
        str = (new Regex("[^\\d.]")).replace(charSequence, "");
      } 
      return str;
    }
    
    private final void putUserData(Map<String, String> param1Map, String param1String1, String param1String2) {
      // Byte code:
      //   0: aload_2
      //   1: invokevirtual hashCode : ()I
      //   4: tableswitch default -> 36, 3585 -> 184, 3586 -> 147, 3587 -> 132, 3588 -> 42
      //   36: aload_3
      //   37: astore #4
      //   39: goto -> 246
      //   42: aload_3
      //   43: astore #4
      //   45: aload_2
      //   46: ldc 'r6'
      //   48: invokevirtual equals : (Ljava/lang/Object;)Z
      //   51: ifeq -> 246
      //   54: aload_3
      //   55: checkcast java/lang/CharSequence
      //   58: astore #5
      //   60: aload_3
      //   61: astore #4
      //   63: aload #5
      //   65: ldc '-'
      //   67: checkcast java/lang/CharSequence
      //   70: iconst_0
      //   71: iconst_2
      //   72: aconst_null
      //   73: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   76: ifeq -> 246
      //   79: new kotlin/text/Regex
      //   82: dup
      //   83: ldc '-'
      //   85: invokespecial <init> : (Ljava/lang/String;)V
      //   88: aload #5
      //   90: iconst_0
      //   91: invokevirtual split : (Ljava/lang/CharSequence;I)Ljava/util/List;
      //   94: checkcast java/util/Collection
      //   97: iconst_0
      //   98: anewarray java/lang/String
      //   101: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
      //   106: astore_3
      //   107: aload_3
      //   108: ifnull -> 122
      //   111: aload_3
      //   112: checkcast [Ljava/lang/String;
      //   115: iconst_0
      //   116: aaload
      //   117: astore #4
      //   119: goto -> 246
      //   122: new java/lang/NullPointerException
      //   125: dup
      //   126: ldc 'null cannot be cast to non-null type kotlin.Array<T>'
      //   128: invokespecial <init> : (Ljava/lang/String;)V
      //   131: athrow
      //   132: aload_3
      //   133: astore #4
      //   135: aload_2
      //   136: ldc 'r5'
      //   138: invokevirtual equals : (Ljava/lang/Object;)Z
      //   141: ifeq -> 246
      //   144: goto -> 159
      //   147: aload_3
      //   148: astore #4
      //   150: aload_2
      //   151: ldc 'r4'
      //   153: invokevirtual equals : (Ljava/lang/Object;)Z
      //   156: ifeq -> 246
      //   159: aload_3
      //   160: checkcast java/lang/CharSequence
      //   163: astore_3
      //   164: new kotlin/text/Regex
      //   167: dup
      //   168: ldc '[^a-z]+'
      //   170: invokespecial <init> : (Ljava/lang/String;)V
      //   173: aload_3
      //   174: ldc ''
      //   176: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;
      //   179: astore #4
      //   181: goto -> 246
      //   184: aload_3
      //   185: astore #4
      //   187: aload_2
      //   188: ldc 'r3'
      //   190: invokevirtual equals : (Ljava/lang/Object;)Z
      //   193: ifeq -> 246
      //   196: aload_3
      //   197: ldc 'm'
      //   199: iconst_0
      //   200: iconst_2
      //   201: aconst_null
      //   202: invokestatic startsWith$default : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   205: ifne -> 242
      //   208: aload_3
      //   209: ldc 'b'
      //   211: iconst_0
      //   212: iconst_2
      //   213: aconst_null
      //   214: invokestatic startsWith$default : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   217: ifne -> 242
      //   220: aload_3
      //   221: ldc 'ge'
      //   223: iconst_0
      //   224: iconst_2
      //   225: aconst_null
      //   226: invokestatic startsWith$default : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   229: ifeq -> 235
      //   232: goto -> 242
      //   235: ldc 'f'
      //   237: astore #4
      //   239: goto -> 246
      //   242: ldc 'm'
      //   244: astore #4
      //   246: aload_1
      //   247: aload_2
      //   248: aload #4
      //   250: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   255: pop
      //   256: return
    }
    
    @JvmStatic
    public final void startTrackingActivity(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      int i = param1Activity.hashCode();
      Map<Integer, Object> map = MetadataViewObserver.access$getObservers$cp();
      Integer integer = Integer.valueOf(i);
      Object object2 = map.get(integer);
      Object object1 = object2;
      if (object2 == null) {
        object1 = new MetadataViewObserver(param1Activity, null);
        map.put(integer, object1);
      } 
      MetadataViewObserver.access$startTracking((MetadataViewObserver)object1);
    }
    
    @JvmStatic
    public final void stopTrackingActivity(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      int i = param1Activity.hashCode();
      MetadataViewObserver metadataViewObserver = (MetadataViewObserver)MetadataViewObserver.access$getObservers$cp().get(Integer.valueOf(i));
      if (metadataViewObserver != null) {
        MetadataViewObserver.access$getObservers$cp().remove(Integer.valueOf(i));
        MetadataViewObserver.access$stopTracking(metadataViewObserver);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class MetadataViewObserver$process$runnable$1 implements Runnable {
    MetadataViewObserver$process$runnable$1(View param1View) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\aam\MetadataViewObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */