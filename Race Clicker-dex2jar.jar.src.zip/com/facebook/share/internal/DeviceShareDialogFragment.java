package com.facebook.share.internal;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.common.R;
import com.facebook.devicerequests.internal.DeviceRequestsHelper;
import com.facebook.internal.Validate;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphContent;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

@Deprecated
public class DeviceShareDialogFragment extends DialogFragment {
  private static final String DEVICE_SHARE_ENDPOINT = "device/share";
  
  private static final String EXTRA_ERROR = "error";
  
  private static final String REQUEST_STATE_KEY = "request_state";
  
  public static final String TAG = "DeviceShareDialogFragment";
  
  private static ScheduledThreadPoolExecutor backgroundExecutor;
  
  private volatile ScheduledFuture codeExpiredFuture;
  
  private TextView confirmationCode;
  
  private volatile RequestState currentRequestState;
  
  private Dialog dialog;
  
  private ProgressBar progressBar;
  
  private ShareContent shareContent;
  
  private void detach() {
    if (isAdded())
      getFragmentManager().beginTransaction().remove((Fragment)this).commit(); 
  }
  
  private void finishActivity(int paramInt, Intent paramIntent) {
    if (this.currentRequestState != null)
      DeviceRequestsHelper.cleanUpAdvertisementService(this.currentRequestState.getUserCode()); 
    FacebookRequestError facebookRequestError = (FacebookRequestError)paramIntent.getParcelableExtra("error");
    if (facebookRequestError != null)
      Toast.makeText(getContext(), facebookRequestError.getErrorMessage(), 0).show(); 
    if (isAdded()) {
      FragmentActivity fragmentActivity = getActivity();
      fragmentActivity.setResult(paramInt, paramIntent);
      fragmentActivity.finish();
    } 
  }
  
  private void finishActivityWithError(FacebookRequestError paramFacebookRequestError) {
    detach();
    Intent intent = new Intent();
    intent.putExtra("error", (Parcelable)paramFacebookRequestError);
    finishActivity(-1, intent);
  }
  
  private static ScheduledThreadPoolExecutor getBackgroundExecutor() {
    // Byte code:
    //   0: ldc com/facebook/share/internal/DeviceShareDialogFragment
    //   2: monitorenter
    //   3: getstatic com/facebook/share/internal/DeviceShareDialogFragment.backgroundExecutor : Ljava/util/concurrent/ScheduledThreadPoolExecutor;
    //   6: ifnonnull -> 20
    //   9: new java/util/concurrent/ScheduledThreadPoolExecutor
    //   12: dup
    //   13: iconst_1
    //   14: invokespecial <init> : (I)V
    //   17: putstatic com/facebook/share/internal/DeviceShareDialogFragment.backgroundExecutor : Ljava/util/concurrent/ScheduledThreadPoolExecutor;
    //   20: getstatic com/facebook/share/internal/DeviceShareDialogFragment.backgroundExecutor : Ljava/util/concurrent/ScheduledThreadPoolExecutor;
    //   23: astore_0
    //   24: ldc com/facebook/share/internal/DeviceShareDialogFragment
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc com/facebook/share/internal/DeviceShareDialogFragment
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	24	29	finally
  }
  
  private Bundle getGraphParametersForShareContent() {
    ShareContent shareContent = this.shareContent;
    return (shareContent == null) ? null : ((shareContent instanceof ShareLinkContent) ? WebDialogParameters.create((ShareLinkContent)shareContent) : ((shareContent instanceof ShareOpenGraphContent) ? WebDialogParameters.create((ShareOpenGraphContent)shareContent) : null));
  }
  
  private void setCurrentRequestState(RequestState paramRequestState) {
    this.currentRequestState = paramRequestState;
    this.confirmationCode.setText(paramRequestState.getUserCode());
    this.confirmationCode.setVisibility(0);
    this.progressBar.setVisibility(8);
    this.codeExpiredFuture = getBackgroundExecutor().schedule(new Runnable() {
          public void run() {
            if (CrashShieldHandler.isObjectCrashing(this))
              return; 
            try {
              return;
            } finally {
              Exception exception = null;
              CrashShieldHandler.handleThrowable(exception, this);
            } 
          }
        }paramRequestState.getExpiresIn(), TimeUnit.SECONDS);
  }
  
  private void startShare() {
    Bundle bundle = getGraphParametersForShareContent();
    if (bundle == null || bundle.size() == 0)
      finishActivityWithError(new FacebookRequestError(0, "", "Failed to get share content")); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Validate.hasAppID());
    stringBuilder.append("|");
    stringBuilder.append(Validate.hasClientToken());
    bundle.putString("access_token", stringBuilder.toString());
    bundle.putString("device_info", DeviceRequestsHelper.getDeviceInfo());
    (new GraphRequest(null, "device/share", bundle, HttpMethod.POST, new GraphRequest.Callback() {
          public void onCompleted(GraphResponse param1GraphResponse) {
            FacebookRequestError facebookRequestError = param1GraphResponse.getError();
            if (facebookRequestError != null) {
              DeviceShareDialogFragment.this.finishActivityWithError(facebookRequestError);
              return;
            } 
            JSONObject jSONObject = param1GraphResponse.getJSONObject();
            DeviceShareDialogFragment.RequestState requestState = new DeviceShareDialogFragment.RequestState();
            try {
              requestState.setUserCode(jSONObject.getString("user_code"));
              requestState.setExpiresIn(jSONObject.getLong("expires_in"));
              DeviceShareDialogFragment.this.setCurrentRequestState(requestState);
              return;
            } catch (JSONException jSONException) {
              DeviceShareDialogFragment.this.finishActivityWithError(new FacebookRequestError(0, "", "Malformed server response"));
              return;
            } 
          }
        })).executeAsync();
  }
  
  public Dialog onCreateDialog(Bundle paramBundle) {
    this.dialog = new Dialog((Context)getActivity(), R.style.com_facebook_auth_dialog);
    View view = getActivity().getLayoutInflater().inflate(R.layout.com_facebook_device_auth_dialog_fragment, null);
    this.progressBar = (ProgressBar)view.findViewById(R.id.progress_bar);
    this.confirmationCode = (TextView)view.findViewById(R.id.confirmation_code);
    ((Button)view.findViewById(R.id.cancel_button)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (CrashShieldHandler.isObjectCrashing(this))
              return; 
            try {
              return;
            } finally {
              param1View = null;
              CrashShieldHandler.handleThrowable((Throwable)param1View, this);
            } 
          }
        });
    ((TextView)view.findViewById(R.id.com_facebook_device_auth_instructions)).setText((CharSequence)Html.fromHtml(getString(R.string.com_facebook_device_auth_instructions)));
    this.dialog.setContentView(view);
    startShare();
    return this.dialog;
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    View view = super.onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
    if (paramBundle != null) {
      RequestState requestState = (RequestState)paramBundle.getParcelable("request_state");
      if (requestState != null)
        setCurrentRequestState(requestState); 
    } 
    return view;
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    super.onDismiss(paramDialogInterface);
    if (this.codeExpiredFuture != null)
      this.codeExpiredFuture.cancel(true); 
    finishActivity(-1, new Intent());
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    if (this.currentRequestState != null)
      paramBundle.putParcelable("request_state", this.currentRequestState); 
  }
  
  public void setShareContent(ShareContent paramShareContent) {
    this.shareContent = paramShareContent;
  }
  
  private static class RequestState implements Parcelable {
    public static final Parcelable.Creator<RequestState> CREATOR = new Parcelable.Creator<RequestState>() {
        public DeviceShareDialogFragment.RequestState createFromParcel(Parcel param2Parcel) {
          return new DeviceShareDialogFragment.RequestState(param2Parcel);
        }
        
        public DeviceShareDialogFragment.RequestState[] newArray(int param2Int) {
          return new DeviceShareDialogFragment.RequestState[param2Int];
        }
      };
    
    private long expiresIn;
    
    private String userCode;
    
    RequestState() {}
    
    protected RequestState(Parcel param1Parcel) {
      this.userCode = param1Parcel.readString();
      this.expiresIn = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public long getExpiresIn() {
      return this.expiresIn;
    }
    
    public String getUserCode() {
      return this.userCode;
    }
    
    public void setExpiresIn(long param1Long) {
      this.expiresIn = param1Long;
    }
    
    public void setUserCode(String param1String) {
      this.userCode = param1String;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.userCode);
      param1Parcel.writeLong(this.expiresIn);
    }
  }
  
  static final class null implements Parcelable.Creator<RequestState> {
    public DeviceShareDialogFragment.RequestState createFromParcel(Parcel param1Parcel) {
      return new DeviceShareDialogFragment.RequestState(param1Parcel);
    }
    
    public DeviceShareDialogFragment.RequestState[] newArray(int param1Int) {
      return new DeviceShareDialogFragment.RequestState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\internal\DeviceShareDialogFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */