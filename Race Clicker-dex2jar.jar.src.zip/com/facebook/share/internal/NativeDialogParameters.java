package com.facebook.share.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.facebook.FacebookException;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import com.facebook.share.model.ShareCameraEffectContent;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareHashtag;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareMediaContent;
import com.facebook.share.model.ShareMessengerGenericTemplateContent;
import com.facebook.share.model.ShareMessengerMediaTemplateContent;
import com.facebook.share.model.ShareMessengerOpenGraphMusicTemplateContent;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.model.ShareStoryContent;
import com.facebook.share.model.ShareVideoContent;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeDialogParameters {
  private static Bundle create(ShareCameraEffectContent paramShareCameraEffectContent, Bundle paramBundle, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareCameraEffectContent, paramBoolean);
    Utility.putNonEmptyString(bundle, "effect_id", paramShareCameraEffectContent.getEffectId());
    if (paramBundle != null)
      bundle.putBundle("effect_textures", paramBundle); 
    try {
      JSONObject jSONObject = CameraEffectJSONUtility.convertToJSON(paramShareCameraEffectContent.getArguments());
      if (jSONObject != null)
        Utility.putNonEmptyString(bundle, "effect_arguments", jSONObject.toString()); 
      return bundle;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder("Unable to create a JSON Object from the provided CameraEffectArguments: ");
      stringBuilder.append(jSONException.getMessage());
      throw new FacebookException(stringBuilder.toString());
    } 
  }
  
  private static Bundle create(ShareLinkContent paramShareLinkContent, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareLinkContent, paramBoolean);
    Utility.putNonEmptyString(bundle, "TITLE", paramShareLinkContent.getContentTitle());
    Utility.putNonEmptyString(bundle, "DESCRIPTION", paramShareLinkContent.getContentDescription());
    Utility.putUri(bundle, "IMAGE", paramShareLinkContent.getImageUrl());
    Utility.putNonEmptyString(bundle, "QUOTE", paramShareLinkContent.getQuote());
    Utility.putUri(bundle, "MESSENGER_LINK", paramShareLinkContent.getContentUrl());
    Utility.putUri(bundle, "TARGET_DISPLAY", paramShareLinkContent.getContentUrl());
    return bundle;
  }
  
  private static Bundle create(ShareMediaContent paramShareMediaContent, List<Bundle> paramList, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareMediaContent, paramBoolean);
    bundle.putParcelableArrayList("MEDIA", new ArrayList<Bundle>(paramList));
    return bundle;
  }
  
  private static Bundle create(ShareMessengerGenericTemplateContent paramShareMessengerGenericTemplateContent, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareMessengerGenericTemplateContent, paramBoolean);
    try {
      MessengerShareContentUtility.addGenericTemplateContent(bundle, paramShareMessengerGenericTemplateContent);
      return bundle;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder("Unable to create a JSON Object from the provided ShareMessengerGenericTemplateContent: ");
      stringBuilder.append(jSONException.getMessage());
      throw new FacebookException(stringBuilder.toString());
    } 
  }
  
  private static Bundle create(ShareMessengerMediaTemplateContent paramShareMessengerMediaTemplateContent, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareMessengerMediaTemplateContent, paramBoolean);
    try {
      MessengerShareContentUtility.addMediaTemplateContent(bundle, paramShareMessengerMediaTemplateContent);
      return bundle;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder("Unable to create a JSON Object from the provided ShareMessengerMediaTemplateContent: ");
      stringBuilder.append(jSONException.getMessage());
      throw new FacebookException(stringBuilder.toString());
    } 
  }
  
  private static Bundle create(ShareMessengerOpenGraphMusicTemplateContent paramShareMessengerOpenGraphMusicTemplateContent, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareMessengerOpenGraphMusicTemplateContent, paramBoolean);
    try {
      MessengerShareContentUtility.addOpenGraphMusicTemplateContent(bundle, paramShareMessengerOpenGraphMusicTemplateContent);
      return bundle;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder("Unable to create a JSON Object from the provided ShareMessengerOpenGraphMusicTemplateContent: ");
      stringBuilder.append(jSONException.getMessage());
      throw new FacebookException(stringBuilder.toString());
    } 
  }
  
  private static Bundle create(ShareOpenGraphContent paramShareOpenGraphContent, JSONObject paramJSONObject, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareOpenGraphContent, paramBoolean);
    Utility.putNonEmptyString(bundle, "PREVIEW_PROPERTY_NAME", (String)(ShareInternalUtility.getFieldNameAndNamespaceFromFullName(paramShareOpenGraphContent.getPreviewPropertyName())).second);
    Utility.putNonEmptyString(bundle, "ACTION_TYPE", paramShareOpenGraphContent.getAction().getActionType());
    Utility.putNonEmptyString(bundle, "ACTION", paramJSONObject.toString());
    return bundle;
  }
  
  private static Bundle create(SharePhotoContent paramSharePhotoContent, List<String> paramList, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramSharePhotoContent, paramBoolean);
    bundle.putStringArrayList("PHOTOS", new ArrayList<String>(paramList));
    return bundle;
  }
  
  private static Bundle create(ShareStoryContent paramShareStoryContent, Bundle paramBundle1, Bundle paramBundle2, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareStoryContent, paramBoolean);
    if (paramBundle1 != null)
      bundle.putParcelable("bg_asset", (Parcelable)paramBundle1); 
    if (paramBundle2 != null)
      bundle.putParcelable("interactive_asset_uri", (Parcelable)paramBundle2); 
    List<?> list = paramShareStoryContent.getBackgroundColorList();
    if (!Utility.isNullOrEmpty(list))
      bundle.putStringArrayList("top_background_color_list", new ArrayList(list)); 
    Utility.putNonEmptyString(bundle, "content_url", paramShareStoryContent.getAttributionLink());
    return bundle;
  }
  
  private static Bundle create(ShareVideoContent paramShareVideoContent, String paramString, boolean paramBoolean) {
    Bundle bundle = createBaseParameters((ShareContent)paramShareVideoContent, paramBoolean);
    Utility.putNonEmptyString(bundle, "TITLE", paramShareVideoContent.getContentTitle());
    Utility.putNonEmptyString(bundle, "DESCRIPTION", paramShareVideoContent.getContentDescription());
    Utility.putNonEmptyString(bundle, "VIDEO", paramString);
    return bundle;
  }
  
  public static Bundle create(UUID paramUUID, ShareContent paramShareContent, boolean paramBoolean) {
    SharePhotoContent sharePhotoContent;
    ShareVideoContent shareVideoContent;
    StringBuilder stringBuilder;
    ShareMediaContent shareMediaContent;
    ShareCameraEffectContent shareCameraEffectContent;
    Validate.notNull(paramShareContent, "shareContent");
    Validate.notNull(paramUUID, "callId");
    if (paramShareContent instanceof ShareLinkContent)
      return create((ShareLinkContent)paramShareContent, paramBoolean); 
    if (paramShareContent instanceof SharePhotoContent) {
      sharePhotoContent = (SharePhotoContent)paramShareContent;
      return create(sharePhotoContent, ShareInternalUtility.getPhotoUrls(sharePhotoContent, paramUUID), paramBoolean);
    } 
    if (sharePhotoContent instanceof ShareVideoContent) {
      shareVideoContent = (ShareVideoContent)sharePhotoContent;
      return create(shareVideoContent, ShareInternalUtility.getVideoUrl(shareVideoContent, paramUUID), paramBoolean);
    } 
    if (shareVideoContent instanceof ShareOpenGraphContent) {
      ShareOpenGraphContent shareOpenGraphContent = (ShareOpenGraphContent)shareVideoContent;
      try {
        return create(shareOpenGraphContent, ShareInternalUtility.removeNamespacesFromOGJsonObject(ShareInternalUtility.toJSONObjectForCall(paramUUID, shareOpenGraphContent), false), paramBoolean);
      } catch (JSONException jSONException) {
        stringBuilder = new StringBuilder("Unable to create a JSON Object from the provided ShareOpenGraphContent: ");
        stringBuilder.append(jSONException.getMessage());
        throw new FacebookException(stringBuilder.toString());
      } 
    } 
    if (stringBuilder instanceof ShareMediaContent) {
      shareMediaContent = (ShareMediaContent)stringBuilder;
      return create(shareMediaContent, ShareInternalUtility.getMediaInfos(shareMediaContent, (UUID)jSONException), paramBoolean);
    } 
    if (shareMediaContent instanceof ShareCameraEffectContent) {
      shareCameraEffectContent = (ShareCameraEffectContent)shareMediaContent;
      return create(shareCameraEffectContent, ShareInternalUtility.getTextureUrlBundle(shareCameraEffectContent, (UUID)jSONException), paramBoolean);
    } 
    if (shareCameraEffectContent instanceof ShareMessengerGenericTemplateContent)
      return create((ShareMessengerGenericTemplateContent)shareCameraEffectContent, paramBoolean); 
    if (shareCameraEffectContent instanceof ShareMessengerOpenGraphMusicTemplateContent)
      return create((ShareMessengerOpenGraphMusicTemplateContent)shareCameraEffectContent, paramBoolean); 
    if (shareCameraEffectContent instanceof ShareMessengerMediaTemplateContent)
      return create((ShareMessengerMediaTemplateContent)shareCameraEffectContent, paramBoolean); 
    if (shareCameraEffectContent instanceof ShareStoryContent) {
      ShareStoryContent shareStoryContent = (ShareStoryContent)shareCameraEffectContent;
      return create(shareStoryContent, ShareInternalUtility.getBackgroundAssetMediaInfo(shareStoryContent, (UUID)jSONException), ShareInternalUtility.getStickerUrl(shareStoryContent, (UUID)jSONException), paramBoolean);
    } 
    return null;
  }
  
  private static Bundle createBaseParameters(ShareContent paramShareContent, boolean paramBoolean) {
    Bundle bundle = new Bundle();
    Utility.putUri(bundle, "LINK", paramShareContent.getContentUrl());
    Utility.putNonEmptyString(bundle, "PLACE", paramShareContent.getPlaceId());
    Utility.putNonEmptyString(bundle, "PAGE", paramShareContent.getPageId());
    Utility.putNonEmptyString(bundle, "REF", paramShareContent.getRef());
    bundle.putBoolean("DATA_FAILURES_FATAL", paramBoolean);
    List<?> list = paramShareContent.getPeopleIds();
    if (!Utility.isNullOrEmpty(list))
      bundle.putStringArrayList("FRIENDS", new ArrayList(list)); 
    ShareHashtag shareHashtag = paramShareContent.getShareHashtag();
    if (shareHashtag != null)
      Utility.putNonEmptyString(bundle, "HASHTAG", shareHashtag.getHashtag()); 
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\internal\NativeDialogParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */