package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

@Deprecated
public final class ShareMessengerOpenGraphMusicTemplateContent extends ShareContent<ShareMessengerOpenGraphMusicTemplateContent, ShareMessengerOpenGraphMusicTemplateContent.Builder> {
  public static final Parcelable.Creator<ShareMessengerOpenGraphMusicTemplateContent> CREATOR = new Parcelable.Creator<ShareMessengerOpenGraphMusicTemplateContent>() {
      public ShareMessengerOpenGraphMusicTemplateContent createFromParcel(Parcel param1Parcel) {
        return new ShareMessengerOpenGraphMusicTemplateContent(param1Parcel);
      }
      
      public ShareMessengerOpenGraphMusicTemplateContent[] newArray(int param1Int) {
        return new ShareMessengerOpenGraphMusicTemplateContent[param1Int];
      }
    };
  
  private final ShareMessengerActionButton button;
  
  private final Uri url;
  
  ShareMessengerOpenGraphMusicTemplateContent(Parcel paramParcel) {
    super(paramParcel);
    this.url = (Uri)paramParcel.readParcelable(Uri.class.getClassLoader());
    this.button = (ShareMessengerActionButton)paramParcel.readParcelable(ShareMessengerActionButton.class.getClassLoader());
  }
  
  private ShareMessengerOpenGraphMusicTemplateContent(Builder paramBuilder) {
    super(paramBuilder);
    this.url = paramBuilder.url;
    this.button = paramBuilder.button;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public ShareMessengerActionButton getButton() {
    return this.button;
  }
  
  public Uri getUrl() {
    return this.url;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.url, paramInt);
    paramParcel.writeParcelable((Parcelable)this.button, paramInt);
  }
  
  public static class Builder extends ShareContent.Builder<ShareMessengerOpenGraphMusicTemplateContent, Builder> {
    private ShareMessengerActionButton button;
    
    private Uri url;
    
    public ShareMessengerOpenGraphMusicTemplateContent build() {
      return new ShareMessengerOpenGraphMusicTemplateContent(this);
    }
    
    public Builder readFrom(ShareMessengerOpenGraphMusicTemplateContent param1ShareMessengerOpenGraphMusicTemplateContent) {
      return (param1ShareMessengerOpenGraphMusicTemplateContent == null) ? this : ((Builder)super.readFrom(param1ShareMessengerOpenGraphMusicTemplateContent)).setUrl(param1ShareMessengerOpenGraphMusicTemplateContent.getUrl()).setButton(param1ShareMessengerOpenGraphMusicTemplateContent.getButton());
    }
    
    public Builder setButton(ShareMessengerActionButton param1ShareMessengerActionButton) {
      this.button = param1ShareMessengerActionButton;
      return this;
    }
    
    public Builder setUrl(Uri param1Uri) {
      this.url = param1Uri;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\model\ShareMessengerOpenGraphMusicTemplateContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */