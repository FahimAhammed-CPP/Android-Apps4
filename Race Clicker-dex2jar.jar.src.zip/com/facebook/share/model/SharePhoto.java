package com.facebook.share.model;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

public final class SharePhoto extends ShareMedia {
  public static final Parcelable.Creator<SharePhoto> CREATOR = new Parcelable.Creator<SharePhoto>() {
      public SharePhoto createFromParcel(Parcel param1Parcel) {
        return new SharePhoto(param1Parcel);
      }
      
      public SharePhoto[] newArray(int param1Int) {
        return new SharePhoto[param1Int];
      }
    };
  
  private final Bitmap bitmap;
  
  private final String caption;
  
  private final Uri imageUrl;
  
  private final boolean userGenerated;
  
  SharePhoto(Parcel paramParcel) {
    super(paramParcel);
    boolean bool;
    this.bitmap = (Bitmap)paramParcel.readParcelable(Bitmap.class.getClassLoader());
    this.imageUrl = (Uri)paramParcel.readParcelable(Uri.class.getClassLoader());
    if (paramParcel.readByte() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.userGenerated = bool;
    this.caption = paramParcel.readString();
  }
  
  private SharePhoto(Builder paramBuilder) {
    super(paramBuilder);
    this.bitmap = paramBuilder.bitmap;
    this.imageUrl = paramBuilder.imageUrl;
    this.userGenerated = paramBuilder.userGenerated;
    this.caption = paramBuilder.caption;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bitmap getBitmap() {
    return this.bitmap;
  }
  
  public String getCaption() {
    return this.caption;
  }
  
  public Uri getImageUrl() {
    return this.imageUrl;
  }
  
  public ShareMedia.Type getMediaType() {
    return ShareMedia.Type.PHOTO;
  }
  
  public boolean getUserGenerated() {
    return this.userGenerated;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeParcelable((Parcelable)this.bitmap, 0);
    paramParcel.writeParcelable((Parcelable)this.imageUrl, 0);
    paramParcel.writeByte((byte)this.userGenerated);
    paramParcel.writeString(this.caption);
  }
  
  public static final class Builder extends ShareMedia.Builder<SharePhoto, Builder> {
    private Bitmap bitmap;
    
    private String caption;
    
    private Uri imageUrl;
    
    private boolean userGenerated;
    
    static List<SharePhoto> readPhotoListFrom(Parcel param1Parcel) {
      List list = readListFrom(param1Parcel);
      ArrayList<SharePhoto> arrayList = new ArrayList();
      for (ShareMedia shareMedia : list) {
        if (shareMedia instanceof SharePhoto)
          arrayList.add((SharePhoto)shareMedia); 
      } 
      return arrayList;
    }
    
    static void writePhotoListTo(Parcel param1Parcel, int param1Int, List<SharePhoto> param1List) {
      ShareMedia[] arrayOfShareMedia = new ShareMedia[param1List.size()];
      for (int i = 0; i < param1List.size(); i++)
        arrayOfShareMedia[i] = param1List.get(i); 
      param1Parcel.writeParcelableArray((Parcelable[])arrayOfShareMedia, param1Int);
    }
    
    public SharePhoto build() {
      return new SharePhoto(this);
    }
    
    Bitmap getBitmap() {
      return this.bitmap;
    }
    
    Uri getImageUrl() {
      return this.imageUrl;
    }
    
    Builder readFrom(Parcel param1Parcel) {
      return readFrom((SharePhoto)param1Parcel.readParcelable(SharePhoto.class.getClassLoader()));
    }
    
    public Builder readFrom(SharePhoto param1SharePhoto) {
      return (param1SharePhoto == null) ? this : ((Builder)super.readFrom(param1SharePhoto)).setBitmap(param1SharePhoto.getBitmap()).setImageUrl(param1SharePhoto.getImageUrl()).setUserGenerated(param1SharePhoto.getUserGenerated()).setCaption(param1SharePhoto.getCaption());
    }
    
    public Builder setBitmap(Bitmap param1Bitmap) {
      this.bitmap = param1Bitmap;
      return this;
    }
    
    public Builder setCaption(String param1String) {
      this.caption = param1String;
      return this;
    }
    
    public Builder setImageUrl(Uri param1Uri) {
      this.imageUrl = param1Uri;
      return this;
    }
    
    public Builder setUserGenerated(boolean param1Boolean) {
      this.userGenerated = param1Boolean;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\model\SharePhoto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */