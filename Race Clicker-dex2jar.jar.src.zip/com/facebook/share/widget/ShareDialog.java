package com.facebook.share.widget;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.appevents.InternalAppEventsLogger;
import com.facebook.internal.AppCall;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.internal.DialogFeature;
import com.facebook.internal.DialogPresenter;
import com.facebook.internal.FacebookDialogBase;
import com.facebook.internal.FragmentWrapper;
import com.facebook.internal.NativeAppCallAttachmentStore;
import com.facebook.internal.Utility;
import com.facebook.share.Sharer;
import com.facebook.share.internal.CameraEffectFeature;
import com.facebook.share.internal.LegacyNativeDialogParameters;
import com.facebook.share.internal.NativeDialogParameters;
import com.facebook.share.internal.OpenGraphActionDialogFeature;
import com.facebook.share.internal.ShareContentValidation;
import com.facebook.share.internal.ShareDialogFeature;
import com.facebook.share.internal.ShareFeedContent;
import com.facebook.share.internal.ShareInternalUtility;
import com.facebook.share.internal.ShareStoryFeature;
import com.facebook.share.internal.WebDialogParameters;
import com.facebook.share.model.ShareCameraEffectContent;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareMediaContent;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.model.ShareStoryContent;
import com.facebook.share.model.ShareVideoContent;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ShareDialog extends FacebookDialogBase<ShareContent, Sharer.Result> implements Sharer {
  private static final int DEFAULT_REQUEST_CODE = CallbackManagerImpl.RequestCodeOffset.Share.toRequestCode();
  
  private static final String FEED_DIALOG = "feed";
  
  private static final String TAG = "ShareDialog";
  
  private static final String WEB_OG_SHARE_DIALOG = "share_open_graph";
  
  public static final String WEB_SHARE_DIALOG = "share";
  
  private boolean isAutomaticMode = true;
  
  private boolean shouldFailOnDataError = false;
  
  public ShareDialog(Activity paramActivity) {
    super(paramActivity, i);
    ShareInternalUtility.registerStaticShareCallback(i);
  }
  
  ShareDialog(Activity paramActivity, int paramInt) {
    super(paramActivity, paramInt);
    ShareInternalUtility.registerStaticShareCallback(paramInt);
  }
  
  public ShareDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  ShareDialog(Fragment paramFragment, int paramInt) {
    this(new FragmentWrapper(paramFragment), paramInt);
  }
  
  public ShareDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  ShareDialog(Fragment paramFragment, int paramInt) {
    this(new FragmentWrapper(paramFragment), paramInt);
  }
  
  private ShareDialog(FragmentWrapper paramFragmentWrapper) {
    super(paramFragmentWrapper, i);
    ShareInternalUtility.registerStaticShareCallback(i);
  }
  
  private ShareDialog(FragmentWrapper paramFragmentWrapper, int paramInt) {
    super(paramFragmentWrapper, paramInt);
    ShareInternalUtility.registerStaticShareCallback(paramInt);
  }
  
  public static boolean canShow(Class<? extends ShareContent> paramClass) {
    return (canShowWebTypeCheck(paramClass) || canShowNative(paramClass));
  }
  
  private static boolean canShowNative(Class<? extends ShareContent> paramClass) {
    DialogFeature dialogFeature = getFeature(paramClass);
    return (dialogFeature != null && DialogPresenter.canPresentNativeDialogWithFeature(dialogFeature));
  }
  
  private static boolean canShowWebCheck(ShareContent paramShareContent) {
    if (!canShowWebTypeCheck((Class)paramShareContent.getClass()))
      return false; 
    if (paramShareContent instanceof ShareOpenGraphContent) {
      ShareOpenGraphContent shareOpenGraphContent = (ShareOpenGraphContent)paramShareContent;
      try {
        ShareInternalUtility.toJSONObjectForWeb(shareOpenGraphContent);
      } catch (Exception exception) {
        Utility.logd(TAG, "canShow returned false because the content of the Opem Graph object can't be shared via the web dialog", exception);
        return false;
      } 
    } 
    return true;
  }
  
  private static boolean canShowWebTypeCheck(Class<? extends ShareContent> paramClass) {
    return (ShareLinkContent.class.isAssignableFrom(paramClass) || ShareOpenGraphContent.class.isAssignableFrom(paramClass) || (SharePhotoContent.class.isAssignableFrom(paramClass) && AccessToken.isCurrentAccessTokenActive()));
  }
  
  private static DialogFeature getFeature(Class<? extends ShareContent> paramClass) {
    return (DialogFeature)(ShareLinkContent.class.isAssignableFrom(paramClass) ? ShareDialogFeature.SHARE_DIALOG : (SharePhotoContent.class.isAssignableFrom(paramClass) ? ShareDialogFeature.PHOTOS : (ShareVideoContent.class.isAssignableFrom(paramClass) ? ShareDialogFeature.VIDEO : (ShareOpenGraphContent.class.isAssignableFrom(paramClass) ? OpenGraphActionDialogFeature.OG_ACTION_DIALOG : (ShareMediaContent.class.isAssignableFrom(paramClass) ? ShareDialogFeature.MULTIMEDIA : (ShareCameraEffectContent.class.isAssignableFrom(paramClass) ? CameraEffectFeature.SHARE_CAMERA_EFFECT : (ShareStoryContent.class.isAssignableFrom(paramClass) ? ShareStoryFeature.SHARE_STORY_ASSET : null)))))));
  }
  
  private void logDialogShare(Context paramContext, ShareContent paramShareContent, Mode paramMode) {
    String str1;
    String str2;
    if (this.isAutomaticMode)
      paramMode = Mode.AUTOMATIC; 
    int i = null.$SwitchMap$com$facebook$share$widget$ShareDialog$Mode[paramMode.ordinal()];
    String str3 = "unknown";
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          str2 = "unknown";
        } else {
          str2 = "native";
        } 
      } else {
        str2 = "web";
      } 
    } else {
      str2 = "automatic";
    } 
    DialogFeature dialogFeature = getFeature((Class)paramShareContent.getClass());
    if (dialogFeature == ShareDialogFeature.SHARE_DIALOG) {
      str1 = "status";
    } else if (dialogFeature == ShareDialogFeature.PHOTOS) {
      str1 = "photo";
    } else if (dialogFeature == ShareDialogFeature.VIDEO) {
      str1 = "video";
    } else {
      str1 = str3;
      if (dialogFeature == OpenGraphActionDialogFeature.OG_ACTION_DIALOG)
        str1 = "open_graph"; 
    } 
    InternalAppEventsLogger internalAppEventsLogger = new InternalAppEventsLogger(paramContext);
    Bundle bundle = new Bundle();
    bundle.putString("fb_share_dialog_show", str2);
    bundle.putString("fb_share_dialog_content_type", str1);
    internalAppEventsLogger.logEventImplicitly("fb_share_dialog_show", bundle);
  }
  
  public static void show(Activity paramActivity, ShareContent paramShareContent) {
    (new ShareDialog(paramActivity)).show(paramShareContent);
  }
  
  public static void show(Fragment paramFragment, ShareContent paramShareContent) {
    show(new FragmentWrapper(paramFragment), paramShareContent);
  }
  
  public static void show(Fragment paramFragment, ShareContent paramShareContent) {
    show(new FragmentWrapper(paramFragment), paramShareContent);
  }
  
  private static void show(FragmentWrapper paramFragmentWrapper, ShareContent paramShareContent) {
    (new ShareDialog(paramFragmentWrapper)).show(paramShareContent);
  }
  
  public boolean canShow(ShareContent paramShareContent, Mode paramMode) {
    Object object = paramMode;
    if (paramMode == Mode.AUTOMATIC)
      object = BASE_AUTOMATIC_MODE; 
    return canShowImpl(paramShareContent, object);
  }
  
  protected AppCall createBaseAppCall() {
    return new AppCall(getRequestCode());
  }
  
  protected List<FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler> getOrderedModeHandlers() {
    ArrayList<NativeHandler> arrayList = new ArrayList();
    arrayList.add(new NativeHandler());
    arrayList.add(new FeedHandler());
    arrayList.add(new WebShareHandler());
    arrayList.add(new CameraEffectHandler());
    arrayList.add(new ShareStoryHandler());
    return (List)arrayList;
  }
  
  public boolean getShouldFailOnDataError() {
    return this.shouldFailOnDataError;
  }
  
  protected void registerCallbackImpl(CallbackManagerImpl paramCallbackManagerImpl, FacebookCallback<Sharer.Result> paramFacebookCallback) {
    ShareInternalUtility.registerSharerCallback(getRequestCode(), (CallbackManager)paramCallbackManagerImpl, paramFacebookCallback);
  }
  
  public void setShouldFailOnDataError(boolean paramBoolean) {
    this.shouldFailOnDataError = paramBoolean;
  }
  
  public void show(ShareContent paramShareContent, Mode paramMode) {
    Object object;
    boolean bool;
    if (paramMode == Mode.AUTOMATIC) {
      bool = true;
    } else {
      bool = false;
    } 
    this.isAutomaticMode = bool;
    if (bool)
      object = BASE_AUTOMATIC_MODE; 
    showImpl(paramShareContent, object);
  }
  
  private class CameraEffectHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private CameraEffectHandler() {
      super(ShareDialog.this);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      return (param1ShareContent instanceof ShareCameraEffectContent && ShareDialog.canShowNative((Class)param1ShareContent.getClass()));
    }
    
    public AppCall createAppCall(final ShareContent content) {
      ShareContentValidation.validateForNativeShare(content);
      final AppCall appCall = ShareDialog.this.createBaseAppCall();
      DialogPresenter.setupAppCallForNativeDialog(appCall, new DialogPresenter.ParameterProvider() {
            public Bundle getLegacyParameters() {
              return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
            
            public Bundle getParameters() {
              return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
          }ShareDialog.getFeature((Class)content.getClass()));
      return appCall;
    }
    
    public Object getMode() {
      return ShareDialog.Mode.NATIVE;
    }
  }
  
  class null implements DialogPresenter.ParameterProvider {
    public Bundle getLegacyParameters() {
      return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
    
    public Bundle getParameters() {
      return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
  }
  
  private class FeedHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private FeedHandler() {
      super(ShareDialog.this);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      return (param1ShareContent instanceof ShareLinkContent || param1ShareContent instanceof ShareFeedContent);
    }
    
    public AppCall createAppCall(ShareContent param1ShareContent) {
      Bundle bundle;
      ShareDialog shareDialog = ShareDialog.this;
      shareDialog.logDialogShare((Context)shareDialog.getActivityContext(), param1ShareContent, ShareDialog.Mode.FEED);
      AppCall appCall = ShareDialog.this.createBaseAppCall();
      if (param1ShareContent instanceof ShareLinkContent) {
        ShareLinkContent shareLinkContent = (ShareLinkContent)param1ShareContent;
        ShareContentValidation.validateForWebShare((ShareContent)shareLinkContent);
        bundle = WebDialogParameters.createForFeed(shareLinkContent);
      } else {
        bundle = WebDialogParameters.createForFeed((ShareFeedContent)bundle);
      } 
      DialogPresenter.setupAppCallForWebDialog(appCall, "feed", bundle);
      return appCall;
    }
    
    public Object getMode() {
      return ShareDialog.Mode.FEED;
    }
  }
  
  public enum Mode {
    AUTOMATIC, FEED, NATIVE, WEB;
    
    static {
      Mode mode1 = new Mode("AUTOMATIC", 0);
      AUTOMATIC = mode1;
      Mode mode2 = new Mode("NATIVE", 1);
      NATIVE = mode2;
      Mode mode3 = new Mode("WEB", 2);
      WEB = mode3;
      Mode mode4 = new Mode("FEED", 3);
      FEED = mode4;
      $VALUES = new Mode[] { mode1, mode2, mode3, mode4 };
    }
  }
  
  private class NativeHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private NativeHandler() {
      super(ShareDialog.this);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (param1ShareContent != null) {
        bool1 = bool2;
        if (!(param1ShareContent instanceof ShareCameraEffectContent)) {
          if (param1ShareContent instanceof ShareStoryContent)
            return false; 
          if (!param1Boolean) {
            if (param1ShareContent.getShareHashtag() != null) {
              bool1 = DialogPresenter.canPresentNativeDialogWithFeature((DialogFeature)ShareDialogFeature.HASHTAG);
            } else {
              bool1 = true;
            } 
            param1Boolean = bool1;
            if (param1ShareContent instanceof ShareLinkContent) {
              param1Boolean = bool1;
              if (!Utility.isNullOrEmpty(((ShareLinkContent)param1ShareContent).getQuote()))
                param1Boolean = bool1 & DialogPresenter.canPresentNativeDialogWithFeature((DialogFeature)ShareDialogFeature.LINK_SHARE_QUOTES); 
            } 
          } else {
            param1Boolean = true;
          } 
          bool1 = bool2;
          if (param1Boolean) {
            bool1 = bool2;
            if (ShareDialog.canShowNative((Class)param1ShareContent.getClass()))
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
    
    public AppCall createAppCall(final ShareContent content) {
      ShareDialog shareDialog = ShareDialog.this;
      shareDialog.logDialogShare((Context)shareDialog.getActivityContext(), content, ShareDialog.Mode.NATIVE);
      ShareContentValidation.validateForNativeShare(content);
      final AppCall appCall = ShareDialog.this.createBaseAppCall();
      DialogPresenter.setupAppCallForNativeDialog(appCall, new DialogPresenter.ParameterProvider() {
            public Bundle getLegacyParameters() {
              return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
            
            public Bundle getParameters() {
              return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
          }ShareDialog.getFeature((Class)content.getClass()));
      return appCall;
    }
    
    public Object getMode() {
      return ShareDialog.Mode.NATIVE;
    }
  }
  
  class null implements DialogPresenter.ParameterProvider {
    public Bundle getLegacyParameters() {
      return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
    
    public Bundle getParameters() {
      return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
  }
  
  private class ShareStoryHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private ShareStoryHandler() {
      super(ShareDialog.this);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      return (param1ShareContent instanceof ShareStoryContent && ShareDialog.canShowNative((Class)param1ShareContent.getClass()));
    }
    
    public AppCall createAppCall(final ShareContent content) {
      ShareContentValidation.validateForStoryShare(content);
      final AppCall appCall = ShareDialog.this.createBaseAppCall();
      DialogPresenter.setupAppCallForNativeDialog(appCall, new DialogPresenter.ParameterProvider() {
            public Bundle getLegacyParameters() {
              return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
            
            public Bundle getParameters() {
              return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
          }ShareDialog.getFeature((Class)content.getClass()));
      return appCall;
    }
    
    public Object getMode() {
      return ShareDialog.Mode.NATIVE;
    }
  }
  
  class null implements DialogPresenter.ParameterProvider {
    public Bundle getLegacyParameters() {
      return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
    
    public Bundle getParameters() {
      return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
  }
  
  private class WebShareHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private WebShareHandler() {
      super(ShareDialog.this);
    }
    
    private SharePhotoContent createAndMapAttachments(SharePhotoContent param1SharePhotoContent, UUID param1UUID) {
      SharePhotoContent.Builder builder = (new SharePhotoContent.Builder()).readFrom(param1SharePhotoContent);
      ArrayList<SharePhoto> arrayList = new ArrayList();
      ArrayList<NativeAppCallAttachmentStore.Attachment> arrayList1 = new ArrayList();
      for (int i = 0; i < param1SharePhotoContent.getPhotos().size(); i++) {
        SharePhoto sharePhoto2 = param1SharePhotoContent.getPhotos().get(i);
        Bitmap bitmap = sharePhoto2.getBitmap();
        SharePhoto sharePhoto1 = sharePhoto2;
        if (bitmap != null) {
          NativeAppCallAttachmentStore.Attachment attachment = NativeAppCallAttachmentStore.createAttachment(param1UUID, bitmap);
          sharePhoto1 = (new SharePhoto.Builder()).readFrom(sharePhoto2).setImageUrl(Uri.parse(attachment.getAttachmentUrl())).setBitmap(null).build();
          arrayList1.add(attachment);
        } 
        arrayList.add(sharePhoto1);
      } 
      builder.setPhotos(arrayList);
      NativeAppCallAttachmentStore.addAttachments(arrayList1);
      return builder.build();
    }
    
    private String getActionName(ShareContent param1ShareContent) {
      return (param1ShareContent instanceof ShareLinkContent || param1ShareContent instanceof SharePhotoContent) ? "share" : ((param1ShareContent instanceof ShareOpenGraphContent) ? "share_open_graph" : null);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      return (param1ShareContent != null && ShareDialog.canShowWebCheck(param1ShareContent));
    }
    
    public AppCall createAppCall(ShareContent param1ShareContent) {
      Bundle bundle;
      ShareDialog shareDialog = ShareDialog.this;
      shareDialog.logDialogShare((Context)shareDialog.getActivityContext(), param1ShareContent, ShareDialog.Mode.WEB);
      AppCall appCall = ShareDialog.this.createBaseAppCall();
      ShareContentValidation.validateForWebShare(param1ShareContent);
      if (param1ShareContent instanceof ShareLinkContent) {
        bundle = WebDialogParameters.create((ShareLinkContent)param1ShareContent);
      } else if (param1ShareContent instanceof SharePhotoContent) {
        bundle = WebDialogParameters.create(createAndMapAttachments((SharePhotoContent)param1ShareContent, appCall.getCallId()));
      } else {
        bundle = WebDialogParameters.create((ShareOpenGraphContent)param1ShareContent);
      } 
      DialogPresenter.setupAppCallForWebDialog(appCall, getActionName(param1ShareContent), bundle);
      return appCall;
    }
    
    public Object getMode() {
      return ShareDialog.Mode.WEB;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\widget\ShareDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */