package com.facebook.share.widget;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.fragment.app.Fragment;
import com.facebook.FacebookCallback;
import com.facebook.internal.AppCall;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.internal.DialogFeature;
import com.facebook.internal.DialogPresenter;
import com.facebook.internal.FacebookDialogBase;
import com.facebook.internal.FragmentWrapper;
import com.facebook.share.internal.AppInviteDialogFeature;
import com.facebook.share.internal.ResultProcessor;
import com.facebook.share.internal.ShareInternalUtility;
import com.facebook.share.model.AppInviteContent;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

@Deprecated
public class AppInviteDialog extends FacebookDialogBase<AppInviteContent, AppInviteDialog.Result> {
  private static final int DEFAULT_REQUEST_CODE = CallbackManagerImpl.RequestCodeOffset.AppInvite.toRequestCode();
  
  private static final String TAG = "AppInviteDialog";
  
  @Deprecated
  public AppInviteDialog(Activity paramActivity) {
    super(paramActivity, DEFAULT_REQUEST_CODE);
  }
  
  @Deprecated
  public AppInviteDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  @Deprecated
  public AppInviteDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  private AppInviteDialog(FragmentWrapper paramFragmentWrapper) {
    super(paramFragmentWrapper, DEFAULT_REQUEST_CODE);
  }
  
  @Deprecated
  public static boolean canShow() {
    return false;
  }
  
  private static boolean canShowNativeDialog() {
    return false;
  }
  
  private static boolean canShowWebFallback() {
    return false;
  }
  
  private static Bundle createParameters(AppInviteContent paramAppInviteContent) {
    Bundle bundle = new Bundle();
    bundle.putString("app_link_url", paramAppInviteContent.getApplinkUrl());
    bundle.putString("preview_image_url", paramAppInviteContent.getPreviewImageUrl());
    bundle.putString("destination", paramAppInviteContent.getDestination().toString());
    String str2 = paramAppInviteContent.getPromotionCode();
    if (str2 == null)
      str2 = ""; 
    String str1 = paramAppInviteContent.getPromotionText();
    if (!TextUtils.isEmpty(str1))
      try {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("promo_code", str2);
        jSONObject.put("promo_text", str1);
        bundle.putString("deeplink_context", jSONObject.toString());
        bundle.putString("promo_code", str2);
        bundle.putString("promo_text", str1);
        return bundle;
      } catch (JSONException jSONException) {
        Log.e("AppInviteDialog", "Json Exception in creating deeplink context");
      }  
    return bundle;
  }
  
  private static DialogFeature getFeature() {
    return (DialogFeature)AppInviteDialogFeature.APP_INVITES_DIALOG;
  }
  
  @Deprecated
  public static void show(Activity paramActivity, AppInviteContent paramAppInviteContent) {
    (new AppInviteDialog(paramActivity)).show(paramAppInviteContent);
  }
  
  @Deprecated
  public static void show(Fragment paramFragment, AppInviteContent paramAppInviteContent) {
    show(new FragmentWrapper(paramFragment), paramAppInviteContent);
  }
  
  @Deprecated
  public static void show(Fragment paramFragment, AppInviteContent paramAppInviteContent) {
    show(new FragmentWrapper(paramFragment), paramAppInviteContent);
  }
  
  private static void show(FragmentWrapper paramFragmentWrapper, AppInviteContent paramAppInviteContent) {
    (new AppInviteDialog(paramFragmentWrapper)).show(paramAppInviteContent);
  }
  
  protected AppCall createBaseAppCall() {
    return new AppCall(getRequestCode());
  }
  
  protected List<FacebookDialogBase<AppInviteContent, Result>.ModeHandler> getOrderedModeHandlers() {
    ArrayList<NativeHandler> arrayList = new ArrayList();
    arrayList.add(new NativeHandler());
    arrayList.add(new WebFallbackHandler());
    return (List)arrayList;
  }
  
  protected void registerCallbackImpl(CallbackManagerImpl paramCallbackManagerImpl, final FacebookCallback<Result> callback) {
    final ResultProcessor resultProcessor;
    if (callback == null) {
      callback = null;
    } else {
      resultProcessor = new ResultProcessor(callback) {
          public void onSuccess(AppCall param1AppCall, Bundle param1Bundle) {
            if ("cancel".equalsIgnoreCase(ShareInternalUtility.getNativeDialogCompletionGesture(param1Bundle))) {
              callback.onCancel();
              return;
            } 
            callback.onSuccess(new AppInviteDialog.Result(param1Bundle));
          }
        };
    } 
    CallbackManagerImpl.Callback callback = new CallbackManagerImpl.Callback() {
        public boolean onActivityResult(int param1Int, Intent param1Intent) {
          return ShareInternalUtility.handleActivityResult(AppInviteDialog.this.getRequestCode(), param1Int, param1Intent, resultProcessor);
        }
      };
    paramCallbackManagerImpl.registerCallback(getRequestCode(), callback);
  }
  
  @Deprecated
  public void show(AppInviteContent paramAppInviteContent) {}
  
  private class NativeHandler extends FacebookDialogBase<AppInviteContent, Result>.ModeHandler {
    private NativeHandler() {
      super(AppInviteDialog.this);
    }
    
    public boolean canShow(AppInviteContent param1AppInviteContent, boolean param1Boolean) {
      return false;
    }
    
    public AppCall createAppCall(final AppInviteContent content) {
      AppCall appCall = AppInviteDialog.this.createBaseAppCall();
      DialogPresenter.setupAppCallForNativeDialog(appCall, new DialogPresenter.ParameterProvider() {
            public Bundle getLegacyParameters() {
              Log.e("AppInviteDialog", "Attempting to present the AppInviteDialog with an outdated Facebook app on the device");
              return new Bundle();
            }
            
            public Bundle getParameters() {
              return AppInviteDialog.createParameters(content);
            }
          }AppInviteDialog.getFeature());
      return appCall;
    }
  }
  
  class null implements DialogPresenter.ParameterProvider {
    public Bundle getLegacyParameters() {
      Log.e("AppInviteDialog", "Attempting to present the AppInviteDialog with an outdated Facebook app on the device");
      return new Bundle();
    }
    
    public Bundle getParameters() {
      return AppInviteDialog.createParameters(content);
    }
  }
  
  @Deprecated
  public static final class Result {
    private final Bundle bundle;
    
    public Result(Bundle param1Bundle) {
      this.bundle = param1Bundle;
    }
    
    public Bundle getData() {
      return this.bundle;
    }
  }
  
  private class WebFallbackHandler extends FacebookDialogBase<AppInviteContent, Result>.ModeHandler {
    private WebFallbackHandler() {
      super(AppInviteDialog.this);
    }
    
    public boolean canShow(AppInviteContent param1AppInviteContent, boolean param1Boolean) {
      return false;
    }
    
    public AppCall createAppCall(AppInviteContent param1AppInviteContent) {
      AppCall appCall = AppInviteDialog.this.createBaseAppCall();
      DialogPresenter.setupAppCallForWebFallbackDialog(appCall, AppInviteDialog.createParameters(param1AppInviteContent), AppInviteDialog.getFeature());
      return appCall;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\widget\AppInviteDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */