package com.facebook.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.facebook.CustomTabMainActivity;
import com.facebook.FacebookActivity;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.InternalAppEventsLogger;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;

public class DialogPresenter {
  public static boolean canPresentNativeDialogWithFeature(DialogFeature paramDialogFeature) {
    return (getProtocolVersionForNativeDialog(paramDialogFeature).getProtocolVersion() != -1);
  }
  
  public static boolean canPresentWebFallbackDialogWithFeature(DialogFeature paramDialogFeature) {
    return (getDialogWebFallbackUri(paramDialogFeature) != null);
  }
  
  private static Uri getDialogWebFallbackUri(DialogFeature paramDialogFeature) {
    String str2 = paramDialogFeature.name();
    String str1 = paramDialogFeature.getAction();
    FetchedAppSettings.DialogFeatureConfig dialogFeatureConfig = FetchedAppSettings.getDialogFeatureConfig(FacebookSdk.getApplicationId(), str1, str2);
    return (dialogFeatureConfig != null) ? dialogFeatureConfig.getFallbackUrl() : null;
  }
  
  public static NativeProtocol.ProtocolVersionQueryResult getProtocolVersionForNativeDialog(DialogFeature paramDialogFeature) {
    String str1 = FacebookSdk.getApplicationId();
    String str2 = paramDialogFeature.getAction();
    return NativeProtocol.getLatestAvailableProtocolVersionForAction(str2, getVersionSpecForFeature(str1, str2, paramDialogFeature));
  }
  
  private static int[] getVersionSpecForFeature(String paramString1, String paramString2, DialogFeature paramDialogFeature) {
    FetchedAppSettings.DialogFeatureConfig dialogFeatureConfig = FetchedAppSettings.getDialogFeatureConfig(paramString1, paramString2, paramDialogFeature.name());
    return (dialogFeatureConfig != null) ? dialogFeatureConfig.getVersionSpec() : new int[] { paramDialogFeature.getMinVersion() };
  }
  
  public static void logDialogActivity(Context paramContext, String paramString1, String paramString2) {
    InternalAppEventsLogger internalAppEventsLogger = new InternalAppEventsLogger(paramContext);
    Bundle bundle = new Bundle();
    bundle.putString("fb_dialog_outcome", paramString2);
    internalAppEventsLogger.logEventImplicitly(paramString1, bundle);
  }
  
  public static void present(AppCall paramAppCall, Activity paramActivity) {
    safedk_Activity_startActivityForResult_206f42f0b65887e835d87ee52d14d221(paramActivity, paramAppCall.getRequestIntent(), paramAppCall.getRequestCode());
    paramAppCall.setPending();
  }
  
  public static void present(AppCall paramAppCall, FragmentWrapper paramFragmentWrapper) {
    safedk_FragmentWrapper_startActivityForResult_51accca8f1bb017fcda2a6aac31602e6(paramFragmentWrapper, paramAppCall.getRequestIntent(), paramAppCall.getRequestCode());
    paramAppCall.setPending();
  }
  
  public static void safedk_Activity_startActivityForResult_206f42f0b65887e835d87ee52d14d221(Activity paramActivity, Intent paramIntent, int paramInt) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.facebook");
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }
  
  public static void safedk_FragmentWrapper_startActivityForResult_51accca8f1bb017fcda2a6aac31602e6(FragmentWrapper paramFragmentWrapper, Intent paramIntent, int paramInt) {
    Logger.d("SafeDK-Special|SafeDK: Call> Lcom/facebook/internal/FragmentWrapper;->startActivityForResult(Landroid/content/Intent;I)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.facebook");
    paramFragmentWrapper.startActivityForResult(paramIntent, paramInt);
  }
  
  public static void setupAppCallForCannotShowError(AppCall paramAppCall) {
    setupAppCallForValidationError(paramAppCall, new FacebookException("Unable to show the provided content via the web or the installed version of the Facebook app. Some dialogs are only supported starting API 14."));
  }
  
  public static void setupAppCallForCustomTabDialog(AppCall paramAppCall, String paramString, Bundle paramBundle) {
    Validate.hasCustomTabRedirectActivity(FacebookSdk.getApplicationContext(), CustomTabUtils.getDefaultRedirectURI());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    Intent intent = new Intent(FacebookSdk.getApplicationContext(), CustomTabMainActivity.class);
    intent.putExtra(CustomTabMainActivity.EXTRA_ACTION, paramString);
    intent.putExtra(CustomTabMainActivity.EXTRA_PARAMS, paramBundle);
    intent.putExtra(CustomTabMainActivity.EXTRA_CHROME_PACKAGE, CustomTabUtils.getChromePackage());
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramString, NativeProtocol.getLatestKnownVersion(), null);
    paramAppCall.setRequestIntent(intent);
  }
  
  public static void setupAppCallForErrorResult(AppCall paramAppCall, FacebookException paramFacebookException) {
    if (paramFacebookException == null)
      return; 
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Intent intent = new Intent();
    intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
    intent.setAction(FacebookActivity.PASS_THROUGH_CANCEL_ACTION);
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), null, NativeProtocol.getLatestKnownVersion(), NativeProtocol.createBundleForException(paramFacebookException));
    paramAppCall.setRequestIntent(intent);
  }
  
  public static void setupAppCallForNativeDialog(AppCall paramAppCall, ParameterProvider paramParameterProvider, DialogFeature paramDialogFeature) {
    Context context = FacebookSdk.getApplicationContext();
    String str = paramDialogFeature.getAction();
    NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = getProtocolVersionForNativeDialog(paramDialogFeature);
    int i = protocolVersionQueryResult.getProtocolVersion();
    if (i != -1) {
      Bundle bundle1;
      if (NativeProtocol.isVersionCompatibleWithBucketedIntent(i)) {
        bundle1 = paramParameterProvider.getParameters();
      } else {
        bundle1 = bundle1.getLegacyParameters();
      } 
      Bundle bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      Intent intent = NativeProtocol.createPlatformActivityIntent(context, paramAppCall.getCallId().toString(), str, protocolVersionQueryResult, bundle2);
      if (intent != null) {
        paramAppCall.setRequestIntent(intent);
        return;
      } 
      throw new FacebookException("Unable to create Intent; this likely means theFacebook app is not installed.");
    } 
    throw new FacebookException("Cannot present this dialog. This likely means that the Facebook app is not installed.");
  }
  
  public static void setupAppCallForValidationError(AppCall paramAppCall, FacebookException paramFacebookException) {
    setupAppCallForErrorResult(paramAppCall, paramFacebookException);
  }
  
  public static void setupAppCallForWebDialog(AppCall paramAppCall, String paramString, Bundle paramBundle) {
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    Bundle bundle = new Bundle();
    bundle.putString("action", paramString);
    bundle.putBundle("params", paramBundle);
    Intent intent = new Intent();
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramString, NativeProtocol.getLatestKnownVersion(), bundle);
    intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
    intent.setAction("FacebookDialogFragment");
    paramAppCall.setRequestIntent(intent);
  }
  
  public static void setupAppCallForWebFallbackDialog(AppCall paramAppCall, Bundle paramBundle, DialogFeature paramDialogFeature) {
    Bundle bundle;
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    String str = paramDialogFeature.name();
    Uri uri = getDialogWebFallbackUri(paramDialogFeature);
    if (uri != null) {
      int i = NativeProtocol.getLatestKnownVersion();
      paramBundle = ServerProtocol.getQueryParamsForPlatformActivityIntentWebFallback(paramAppCall.getCallId().toString(), i, paramBundle);
      if (paramBundle != null) {
        Uri uri1;
        if (uri.isRelative()) {
          uri1 = Utility.buildUri(ServerProtocol.getDialogAuthority(), uri.toString(), paramBundle);
        } else {
          uri1 = Utility.buildUri(uri.getAuthority(), uri.getPath(), (Bundle)uri1);
        } 
        bundle = new Bundle();
        bundle.putString("url", uri1.toString());
        bundle.putBoolean("is_fallback", true);
        Intent intent = new Intent();
        NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramDialogFeature.getAction(), NativeProtocol.getLatestKnownVersion(), bundle);
        intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
        intent.setAction("FacebookDialogFragment");
        paramAppCall.setRequestIntent(intent);
        return;
      } 
      throw new FacebookException("Unable to fetch the app's key-hash");
    } 
    StringBuilder stringBuilder = new StringBuilder("Unable to fetch the Url for the DialogFeature : '");
    stringBuilder.append((String)bundle);
    stringBuilder.append("'");
    throw new FacebookException(stringBuilder.toString());
  }
  
  public static interface ParameterProvider {
    Bundle getLegacyParameters();
    
    Bundle getParameters();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\DialogPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */