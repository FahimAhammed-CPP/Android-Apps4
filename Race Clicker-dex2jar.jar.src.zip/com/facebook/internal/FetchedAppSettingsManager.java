package com.facebook.internal;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.appevents.codeless.internal.UnityReflection;
import com.facebook.appevents.internal.Constants;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Metadata;
import kotlin.UByte$;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\t\n\002\020 \n\002\b\006\n\002\020\b\n\002\b\n\n\002\020%\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\020$\n\002\030\002\n\002\b\t\bÆ\002\030\0002\0020\001:\002BCB\007\b\002¢\006\002\020\002J\020\020.\032\0020/2\006\0200\032\0020$H\007J\020\0201\032\002022\006\0203\032\0020\004H\002J\024\0204\032\004\030\0010!2\b\0203\032\004\030\0010\004H\007J\b\0205\032\0020/H\007J\035\0206\032\0020!2\006\0203\032\0020\0042\006\0207\032\00202H\000¢\006\002\b8J*\0209\032\032\022\004\022\0020\004\022\020\022\016\022\004\022\0020\004\022\004\022\0020;0 0:2\b\020<\032\004\030\00102H\002J\b\020=\032\0020/H\002J\032\020>\032\004\030\0010!2\006\0203\032\0020\0042\006\020?\032\0020&H\007J\020\020@\032\0020/2\006\020A\032\0020&H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\016\020\n\032\0020\004XT¢\006\002\n\000R\016\020\013\032\0020\004XT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\024\020\r\032\b\022\004\022\0020\0040\016X\004¢\006\002\n\000R\016\020\017\032\0020\004XT¢\006\002\n\000R\016\020\020\032\0020\004XT¢\006\002\n\000R\016\020\021\032\0020\004XT¢\006\002\n\000R\016\020\022\032\0020\004XT¢\006\002\n\000R\016\020\023\032\0020\004XT¢\006\002\n\000R\016\020\024\032\0020\025XT¢\006\002\n\000R\016\020\026\032\0020\025XT¢\006\002\n\000R\016\020\027\032\0020\025XT¢\006\002\n\000R\016\020\030\032\0020\025XT¢\006\002\n\000R\016\020\031\032\0020\004XT¢\006\002\n\000R\016\020\032\032\0020\004XT¢\006\002\n\000R\016\020\033\032\0020\004XT¢\006\002\n\000R\016\020\034\032\0020\004XT¢\006\002\n\000R\016\020\035\032\0020\004X\004¢\006\002\n\000R\016\020\036\032\0020\025XT¢\006\002\n\000R\032\020\037\032\016\022\004\022\0020\004\022\004\022\0020!0 X\004¢\006\002\n\000R\024\020\"\032\b\022\004\022\0020$0#X\004¢\006\002\n\000R\016\020%\032\0020&X\016¢\006\002\n\000R\034\020'\032\020\022\f\022\n **\004\030\0010)0)0(X\004¢\006\002\n\000R\016\020+\032\0020&X\016¢\006\002\n\000R\020\020,\032\004\030\0010-X\016¢\006\002\n\000¨\006D"}, d2 = {"Lcom/facebook/internal/FetchedAppSettingsManager;", "", "()V", "APPLICATION_FIELDS", "", "APP_SETTINGS_PREFS_KEY_FORMAT", "APP_SETTINGS_PREFS_STORE", "APP_SETTING_ANDROID_SDK_ERROR_CATEGORIES", "APP_SETTING_APP_EVENTS_AAM_RULE", "APP_SETTING_APP_EVENTS_EVENT_BINDINGS", "APP_SETTING_APP_EVENTS_FEATURE_BITMASK", "APP_SETTING_APP_EVENTS_SESSION_TIMEOUT", "APP_SETTING_DIALOG_CONFIGS", "APP_SETTING_FIELDS", "", "APP_SETTING_NUX_CONTENT", "APP_SETTING_NUX_ENABLED", "APP_SETTING_RESTRICTIVE_EVENT_FILTER_FIELD", "APP_SETTING_SMART_LOGIN_OPTIONS", "APP_SETTING_SUPPORTS_IMPLICIT_SDK_LOGGING", "AUTOMATIC_LOGGING_ENABLED_BITMASK_FIELD", "", "CODELESS_EVENTS_ENABLED_BITMASK_FIELD", "IAP_AUTOMATIC_LOGGING_ENABLED_BITMASK_FIELD", "MONITOR_ENABLED_BITMASK_FIELD", "SDK_UPDATE_MESSAGE", "SMART_LOGIN_BOOKMARK_ICON_URL", "SMART_LOGIN_MENU_ICON_URL", "SUGGESTED_EVENTS_SETTING", "TAG", "TRACK_UNINSTALL_ENABLED_BITMASK_FIELD", "fetchedAppSettings", "", "Lcom/facebook/internal/FetchedAppSettings;", "fetchedAppSettingsCallbacks", "Ljava/util/concurrent/ConcurrentLinkedQueue;", "Lcom/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback;", "isUnityInit", "", "loadingState", "Ljava/util/concurrent/atomic/AtomicReference;", "Lcom/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState;", "kotlin.jvm.PlatformType", "printedSDKUpdatedMessage", "unityEventBindings", "Lorg/json/JSONArray;", "getAppSettingsAsync", "", "callback", "getAppSettingsQueryResponse", "Lorg/json/JSONObject;", "applicationId", "getAppSettingsWithoutQuery", "loadAppSettingsAsync", "parseAppSettingsFromJSON", "settingsJSON", "parseAppSettingsFromJSON$facebook_core_release", "parseDialogConfigurations", "", "Lcom/facebook/internal/FetchedAppSettings$DialogFeatureConfig;", "dialogConfigResponse", "pollCallbacks", "queryAppSettings", "forceRequery", "setIsUnityInit", "flag", "FetchAppSettingState", "FetchedAppSettingsCallback", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class FetchedAppSettingsManager {
  private static final String APPLICATION_FIELDS = "fields";
  
  private static final String APP_SETTINGS_PREFS_KEY_FORMAT = "com.facebook.internal.APP_SETTINGS.%s";
  
  private static final String APP_SETTINGS_PREFS_STORE = "com.facebook.internal.preferences.APP_SETTINGS";
  
  private static final String APP_SETTING_ANDROID_SDK_ERROR_CATEGORIES = "android_sdk_error_categories";
  
  private static final String APP_SETTING_APP_EVENTS_AAM_RULE = "aam_rules";
  
  private static final String APP_SETTING_APP_EVENTS_EVENT_BINDINGS = "auto_event_mapping_android";
  
  private static final String APP_SETTING_APP_EVENTS_FEATURE_BITMASK = "app_events_feature_bitmask";
  
  private static final String APP_SETTING_APP_EVENTS_SESSION_TIMEOUT = "app_events_session_timeout";
  
  private static final String APP_SETTING_DIALOG_CONFIGS = "android_dialog_configs";
  
  private static final List<String> APP_SETTING_FIELDS;
  
  private static final String APP_SETTING_NUX_CONTENT = "gdpv4_nux_content";
  
  private static final String APP_SETTING_NUX_ENABLED = "gdpv4_nux_enabled";
  
  private static final String APP_SETTING_RESTRICTIVE_EVENT_FILTER_FIELD = "restrictive_data_filter_params";
  
  private static final String APP_SETTING_SMART_LOGIN_OPTIONS = "seamless_login";
  
  private static final String APP_SETTING_SUPPORTS_IMPLICIT_SDK_LOGGING = "supports_implicit_sdk_logging";
  
  private static final int AUTOMATIC_LOGGING_ENABLED_BITMASK_FIELD = 8;
  
  private static final int CODELESS_EVENTS_ENABLED_BITMASK_FIELD = 32;
  
  private static final int IAP_AUTOMATIC_LOGGING_ENABLED_BITMASK_FIELD = 16;
  
  public static final FetchedAppSettingsManager INSTANCE = new FetchedAppSettingsManager();
  
  private static final int MONITOR_ENABLED_BITMASK_FIELD = 16384;
  
  private static final String SDK_UPDATE_MESSAGE = "sdk_update_message";
  
  private static final String SMART_LOGIN_BOOKMARK_ICON_URL = "smart_login_bookmark_icon_url";
  
  private static final String SMART_LOGIN_MENU_ICON_URL = "smart_login_menu_icon_url";
  
  private static final String SUGGESTED_EVENTS_SETTING = "suggested_events_setting";
  
  private static final String TAG = "FetchedAppSettingsManager";
  
  private static final int TRACK_UNINSTALL_ENABLED_BITMASK_FIELD = 256;
  
  private static final Map<String, FetchedAppSettings> fetchedAppSettings;
  
  private static final ConcurrentLinkedQueue<FetchedAppSettingsCallback> fetchedAppSettingsCallbacks;
  
  private static boolean isUnityInit;
  
  private static final AtomicReference<FetchAppSettingState> loadingState;
  
  private static boolean printedSDKUpdatedMessage;
  
  private static JSONArray unityEventBindings;
  
  static {
    APP_SETTING_FIELDS = CollectionsKt.listOf((Object[])new String[] { 
          "supports_implicit_sdk_logging", "gdpv4_nux_content", "gdpv4_nux_enabled", "android_dialog_configs", "android_sdk_error_categories", "app_events_session_timeout", "app_events_feature_bitmask", "auto_event_mapping_android", "seamless_login", "smart_login_bookmark_icon_url", 
          "smart_login_menu_icon_url", "restrictive_data_filter_params", "aam_rules", "suggested_events_setting" });
    fetchedAppSettings = new ConcurrentHashMap<String, FetchedAppSettings>();
    loadingState = new AtomicReference<FetchAppSettingState>(FetchAppSettingState.NOT_LOADED);
    fetchedAppSettingsCallbacks = new ConcurrentLinkedQueue<FetchedAppSettingsCallback>();
  }
  
  @JvmStatic
  public static final void getAppSettingsAsync(FetchedAppSettingsCallback paramFetchedAppSettingsCallback) {
    Intrinsics.checkNotNullParameter(paramFetchedAppSettingsCallback, "callback");
    fetchedAppSettingsCallbacks.add(paramFetchedAppSettingsCallback);
    loadAppSettingsAsync();
  }
  
  private final JSONObject getAppSettingsQueryResponse(String paramString) {
    Bundle bundle = new Bundle();
    ArrayList<String> arrayList = new ArrayList();
    arrayList.addAll(APP_SETTING_FIELDS);
    bundle.putString("fields", TextUtils.join(",", arrayList));
    GraphRequest graphRequest = GraphRequest.Companion.newGraphPathRequest(null, paramString, null);
    graphRequest.setForceApplicationRequest(true);
    graphRequest.setSkipClientToken(true);
    graphRequest.setParameters(bundle);
    JSONObject jSONObject = graphRequest.executeAndWait().getJsonObject();
    return (jSONObject != null) ? jSONObject : new JSONObject();
  }
  
  @JvmStatic
  public static final FetchedAppSettings getAppSettingsWithoutQuery(String paramString) {
    return (paramString != null) ? fetchedAppSettings.get(paramString) : null;
  }
  
  @JvmStatic
  public static final void loadAppSettingsAsync() {
    boolean bool;
    Context context = FacebookSdk.getApplicationContext();
    String str1 = FacebookSdk.getApplicationId();
    if (Utility.isNullOrEmpty(str1)) {
      loadingState.set(FetchAppSettingState.ERROR);
      INSTANCE.pollCallbacks();
      return;
    } 
    if (fetchedAppSettings.containsKey(str1)) {
      loadingState.set(FetchAppSettingState.SUCCESS);
      INSTANCE.pollCallbacks();
      return;
    } 
    AtomicReference<FetchAppSettingState> atomicReference = loadingState;
    if (UByte$.ExternalSyntheticBackport0.m(atomicReference, FetchAppSettingState.NOT_LOADED, FetchAppSettingState.LOADING) || UByte$.ExternalSyntheticBackport0.m(atomicReference, FetchAppSettingState.ERROR, FetchAppSettingState.LOADING)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      INSTANCE.pollCallbacks();
      return;
    } 
    StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
    String str2 = String.format("com.facebook.internal.APP_SETTINGS.%s", Arrays.copyOf(new Object[] { str1 }, 1));
    Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
    FacebookSdk.getExecutor().execute(new FetchedAppSettingsManager$loadAppSettingsAsync$1(context, str2, str1));
  }
  
  private final Map<String, Map<String, FetchedAppSettings.DialogFeatureConfig>> parseDialogConfigurations(JSONObject paramJSONObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramJSONObject != null) {
      JSONArray jSONArray = paramJSONObject.optJSONArray("data");
      if (jSONArray != null) {
        int j = jSONArray.length();
        for (int i = 0; i < j; i++) {
          FetchedAppSettings.DialogFeatureConfig.Companion companion = FetchedAppSettings.DialogFeatureConfig.Companion;
          JSONObject jSONObject = jSONArray.optJSONObject(i);
          Intrinsics.checkNotNullExpressionValue(jSONObject, "dialogConfigData.optJSONObject(i)");
          FetchedAppSettings.DialogFeatureConfig dialogFeatureConfig = companion.parseDialogConfig(jSONObject);
          if (dialogFeatureConfig != null) {
            String str = dialogFeatureConfig.getDialogName();
            Map<Object, Object> map2 = (Map)hashMap.get(str);
            Map<Object, Object> map1 = map2;
            if (map2 == null) {
              map1 = new HashMap<Object, Object>();
              hashMap.put(str, map1);
            } 
            map1.put(dialogFeatureConfig.getFeatureName(), dialogFeatureConfig);
          } 
        } 
      } 
    } 
    return (Map)hashMap;
  }
  
  private final void pollCallbacks() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/facebook/internal/FetchedAppSettingsManager.loadingState : Ljava/util/concurrent/atomic/AtomicReference;
    //   5: invokevirtual get : ()Ljava/lang/Object;
    //   8: checkcast com/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState
    //   11: astore_2
    //   12: getstatic com/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState.NOT_LOADED : Lcom/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState;
    //   15: aload_2
    //   16: if_acmpeq -> 143
    //   19: getstatic com/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState.LOADING : Lcom/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState;
    //   22: aload_2
    //   23: if_acmpne -> 29
    //   26: goto -> 143
    //   29: invokestatic getApplicationId : ()Ljava/lang/String;
    //   32: astore_1
    //   33: getstatic com/facebook/internal/FetchedAppSettingsManager.fetchedAppSettings : Ljava/util/Map;
    //   36: aload_1
    //   37: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   42: checkcast com/facebook/internal/FetchedAppSettings
    //   45: astore_3
    //   46: new android/os/Handler
    //   49: dup
    //   50: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   53: invokespecial <init> : (Landroid/os/Looper;)V
    //   56: astore_1
    //   57: getstatic com/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState.ERROR : Lcom/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState;
    //   60: aload_2
    //   61: if_acmpne -> 103
    //   64: getstatic com/facebook/internal/FetchedAppSettingsManager.fetchedAppSettingsCallbacks : Ljava/util/concurrent/ConcurrentLinkedQueue;
    //   67: astore_2
    //   68: aload_2
    //   69: invokevirtual isEmpty : ()Z
    //   72: ifne -> 100
    //   75: aload_1
    //   76: new com/facebook/internal/FetchedAppSettingsManager$pollCallbacks$1
    //   79: dup
    //   80: aload_2
    //   81: invokevirtual poll : ()Ljava/lang/Object;
    //   84: checkcast com/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback
    //   87: invokespecial <init> : (Lcom/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback;)V
    //   90: checkcast java/lang/Runnable
    //   93: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   96: pop
    //   97: goto -> 64
    //   100: aload_0
    //   101: monitorexit
    //   102: return
    //   103: getstatic com/facebook/internal/FetchedAppSettingsManager.fetchedAppSettingsCallbacks : Ljava/util/concurrent/ConcurrentLinkedQueue;
    //   106: astore_2
    //   107: aload_2
    //   108: invokevirtual isEmpty : ()Z
    //   111: ifne -> 140
    //   114: aload_1
    //   115: new com/facebook/internal/FetchedAppSettingsManager$pollCallbacks$2
    //   118: dup
    //   119: aload_2
    //   120: invokevirtual poll : ()Ljava/lang/Object;
    //   123: checkcast com/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback
    //   126: aload_3
    //   127: invokespecial <init> : (Lcom/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback;Lcom/facebook/internal/FetchedAppSettings;)V
    //   130: checkcast java/lang/Runnable
    //   133: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   136: pop
    //   137: goto -> 103
    //   140: aload_0
    //   141: monitorexit
    //   142: return
    //   143: aload_0
    //   144: monitorexit
    //   145: return
    //   146: astore_1
    //   147: aload_0
    //   148: monitorexit
    //   149: aload_1
    //   150: athrow
    // Exception table:
    //   from	to	target	type
    //   2	26	146	finally
    //   29	64	146	finally
    //   64	97	146	finally
    //   103	137	146	finally
  }
  
  @JvmStatic
  public static final FetchedAppSettings queryAppSettings(String paramString, boolean paramBoolean) {
    Intrinsics.checkNotNullParameter(paramString, "applicationId");
    if (!paramBoolean) {
      Map<String, FetchedAppSettings> map = fetchedAppSettings;
      if (map.containsKey(paramString))
        return map.get(paramString); 
    } 
    FetchedAppSettingsManager fetchedAppSettingsManager = INSTANCE;
    JSONObject jSONObject = fetchedAppSettingsManager.getAppSettingsQueryResponse(paramString);
    if (jSONObject != null) {
      FetchedAppSettings fetchedAppSettings = fetchedAppSettingsManager.parseAppSettingsFromJSON$facebook_core_release(paramString, jSONObject);
      if (Intrinsics.areEqual(paramString, FacebookSdk.getApplicationId())) {
        loadingState.set(FetchAppSettingState.SUCCESS);
        fetchedAppSettingsManager.pollCallbacks();
      } 
      return fetchedAppSettings;
    } 
    return null;
  }
  
  @JvmStatic
  public static final void setIsUnityInit(boolean paramBoolean) {
    isUnityInit = paramBoolean;
    JSONArray jSONArray = unityEventBindings;
    if (jSONArray != null && paramBoolean)
      UnityReflection.sendEventMapping(String.valueOf(jSONArray)); 
  }
  
  public final FetchedAppSettings parseAppSettingsFromJSON$facebook_core_release(String paramString, JSONObject paramJSONObject) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    boolean bool5;
    Intrinsics.checkNotNullParameter(paramString, "applicationId");
    Intrinsics.checkNotNullParameter(paramJSONObject, "settingsJSON");
    JSONArray jSONArray1 = paramJSONObject.optJSONArray("android_sdk_error_categories");
    FacebookRequestErrorClassification facebookRequestErrorClassification = FacebookRequestErrorClassification.Companion.createFromJSON(jSONArray1);
    if (facebookRequestErrorClassification == null)
      facebookRequestErrorClassification = FacebookRequestErrorClassification.Companion.getDefaultErrorClassification(); 
    int i = paramJSONObject.optInt("app_events_feature_bitmask", 0);
    if ((i & 0x8) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((i & 0x10) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if ((i & 0x20) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    if ((i & 0x100) != 0) {
      bool4 = true;
    } else {
      bool4 = false;
    } 
    if ((i & 0x4000) != 0) {
      bool5 = true;
    } else {
      bool5 = false;
    } 
    JSONArray jSONArray2 = paramJSONObject.optJSONArray("auto_event_mapping_android");
    unityEventBindings = jSONArray2;
    if (jSONArray2 != null && InternalSettings.isUnityApp()) {
      String str;
      if (jSONArray2 != null) {
        str = jSONArray2.toString();
      } else {
        str = null;
      } 
      UnityReflection.sendEventMapping(str);
    } 
    boolean bool6 = paramJSONObject.optBoolean("supports_implicit_sdk_logging", false);
    String str1 = paramJSONObject.optString("gdpv4_nux_content", "");
    Intrinsics.checkNotNullExpressionValue(str1, "settingsJSON.optString(A…_SETTING_NUX_CONTENT, \"\")");
    boolean bool7 = paramJSONObject.optBoolean("gdpv4_nux_enabled", false);
    i = paramJSONObject.optInt("app_events_session_timeout", Constants.getDefaultAppEventsSessionTimeoutInSeconds());
    EnumSet enumSet = SmartLoginOption.Companion.parseOptions(paramJSONObject.optLong("seamless_login"));
    Map<String, Map<String, FetchedAppSettings.DialogFeatureConfig>> map = parseDialogConfigurations(paramJSONObject.optJSONObject("android_dialog_configs"));
    String str2 = paramJSONObject.optString("smart_login_bookmark_icon_url");
    Intrinsics.checkNotNullExpressionValue(str2, "settingsJSON.optString(S…_LOGIN_BOOKMARK_ICON_URL)");
    String str3 = paramJSONObject.optString("smart_login_menu_icon_url");
    Intrinsics.checkNotNullExpressionValue(str3, "settingsJSON.optString(SMART_LOGIN_MENU_ICON_URL)");
    String str4 = paramJSONObject.optString("sdk_update_message");
    Intrinsics.checkNotNullExpressionValue(str4, "settingsJSON.optString(SDK_UPDATE_MESSAGE)");
    FetchedAppSettings fetchedAppSettings = new FetchedAppSettings(bool6, str1, bool7, i, enumSet, map, bool1, facebookRequestErrorClassification, str2, str3, bool2, bool3, jSONArray2, str4, bool4, bool5, paramJSONObject.optString("aam_rules"), paramJSONObject.optString("suggested_events_setting"), paramJSONObject.optString("restrictive_data_filter_params"));
    fetchedAppSettings.put(paramString, fetchedAppSettings);
    return fetchedAppSettings;
  }
  
  static {
    Intrinsics.checkNotNullExpressionValue("FetchedAppSettingsManager", "FetchedAppSettingsManager::class.java.simpleName");
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lcom/facebook/internal/FetchedAppSettingsManager$FetchAppSettingState;", "", "(Ljava/lang/String;I)V", "NOT_LOADED", "LOADING", "SUCCESS", "ERROR", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public enum FetchAppSettingState {
    ERROR, LOADING, NOT_LOADED, SUCCESS;
    
    static {
      FetchAppSettingState fetchAppSettingState1 = new FetchAppSettingState("NOT_LOADED", 0);
      NOT_LOADED = fetchAppSettingState1;
      FetchAppSettingState fetchAppSettingState2 = new FetchAppSettingState("LOADING", 1);
      LOADING = fetchAppSettingState2;
      FetchAppSettingState fetchAppSettingState3 = new FetchAppSettingState("SUCCESS", 2);
      SUCCESS = fetchAppSettingState3;
      FetchAppSettingState fetchAppSettingState4 = new FetchAppSettingState("ERROR", 3);
      ERROR = fetchAppSettingState4;
      $VALUES = new FetchAppSettingState[] { fetchAppSettingState1, fetchAppSettingState2, fetchAppSettingState3, fetchAppSettingState4 };
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\000\bf\030\0002\0020\001J\b\020\002\032\0020\003H&J\022\020\004\032\0020\0032\b\020\005\032\004\030\0010\006H&¨\006\007"}, d2 = {"Lcom/facebook/internal/FetchedAppSettingsManager$FetchedAppSettingsCallback;", "", "onError", "", "onSuccess", "fetchedAppSettings", "Lcom/facebook/internal/FetchedAppSettings;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static interface FetchedAppSettingsCallback {
    void onError();
    
    void onSuccess(FetchedAppSettings param1FetchedAppSettings);
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class FetchedAppSettingsManager$loadAppSettingsAsync$1 implements Runnable {
    FetchedAppSettingsManager$loadAppSettingsAsync$1(Context param1Context, String param1String1, String param1String2) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class FetchedAppSettingsManager$pollCallbacks$1 implements Runnable {
    FetchedAppSettingsManager$pollCallbacks$1(FetchedAppSettingsManager.FetchedAppSettingsCallback param1FetchedAppSettingsCallback) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class FetchedAppSettingsManager$pollCallbacks$2 implements Runnable {
    FetchedAppSettingsManager$pollCallbacks$2(FetchedAppSettingsManager.FetchedAppSettingsCallback param1FetchedAppSettingsCallback, FetchedAppSettings param1FetchedAppSettings) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\FetchedAppSettingsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */