package com.facebook.internal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.facebook.FacebookException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.FacebookSdk;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.login.DefaultAudience;
import com.facebook.login.LoginTargetApp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\000 \001\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b9\n\002\020\021\n\002\020\b\n\002\b4\n\002\020$\n\002\020 \n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\025\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\036\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\f\n\002\030\002\n\002\b\020\n\002\020\002\n\002\b\r\bÇ\002\030\0002\0020\001:\020Î\001Ï\001Ð\001Ñ\001Ò\001Ó\001Ô\001Õ\001B\007\b\002¢\006\002\020\002J\032\020\032\024\022\004\022\0020\004\022\n\022\b\022\004\022\0020v0u0tH\002J\017\020\001\032\b\022\004\022\0020v0uH\002J\017\020\001\032\b\022\004\022\0020v0uH\002J\023\020\001\032\0030\0012\007\020\001\032\0020vH\002J.\020\001\032\0020?2\020\020\001\032\013\022\004\022\0020?\030\0010\0012\007\020\001\032\0020?2\b\020\001\032\0030\001H\007J\030\020\001\032\005\030\0010\0012\n\020\001\032\005\030\0010\001H\007J\001\020\001\032\005\030\0010\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\020\020\001\032\013\022\006\022\004\030\0010\0040\0012\007\020\001\032\0020\0042\b\020\001\032\0030\0012\b\020\001\032\0030\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\007\020\001\032\0020\0042\t\020\001\032\004\030\0010\0042\b\020\001\032\0030\0012\b\020 \001\032\0030\0012\b\020¡\001\032\0030\001H\007J\001\020¢\001\032\005\030\0010\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\020\020\001\032\013\022\006\022\004\030\0010\0040\0012\007\020\001\032\0020\0042\b\020\001\032\0030\0012\b\020\001\032\0030\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\007\020\001\032\0020\0042\t\020\001\032\004\030\0010\0042\b\020\001\032\0030\0012\b\020 \001\032\0030\0012\b\020¡\001\032\0030\001H\007J\001\020£\001\032\005\030\0010\0012\007\020\001\032\0020v2\007\020\001\032\0020\0042\020\020\001\032\013\022\006\022\004\030\0010\0040\0012\007\020\001\032\0020\0042\b\020\001\032\0030\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\007\020\001\032\0020\0042\b\020¤\001\032\0030\0012\t\020\001\032\004\030\0010\0042\b\020\001\032\0030\0012\b\020¥\001\032\0030¦\0012\b\020 \001\032\0030\0012\b\020¡\001\032\0030\001H\002JD\020§\001\032\005\030\0010\0012\b\020\001\032\0030\0012\t\020¨\001\032\004\030\0010\0042\t\020©\001\032\004\030\0010\0042\n\020ª\001\032\005\030\0010«\0012\n\020¬\001\032\005\030\0010\001H\007J\026\020­\001\032\005\030\0010\0012\b\020\001\032\0030\001H\007J.\020®\001\032\005\030\0010\0012\b\020¯\001\032\0030\0012\n\020°\001\032\005\030\0010\0012\n\020±\001\032\005\030\0010\001H\007J£\001\020²\001\032\t\022\005\022\0030\0010u2\n\020\001\032\005\030\0010\0012\007\020\001\032\0020\0042\020\020\001\032\013\022\006\022\004\030\0010\0040\0012\007\020\001\032\0020\0042\b\020\001\032\0030\0012\b\020\001\032\0030\0012\b\020\001\032\0030\0012\007\020\001\032\0020\0042\007\020\001\032\0020\0042\b\020¤\001\032\0030\0012\t\020\001\032\004\030\0010\0042\b\020\001\032\0030\0012\b\020 \001\032\0030\0012\b\020¡\001\032\0030\001H\007J\026\020³\001\032\005\030\0010\0012\b\020\001\032\0030\001H\007J\031\020´\001\032\t\022\004\022\0020?0\0012\007\020\001\032\0020vH\002J\026\020µ\001\032\005\030\0010\0012\b\020¶\001\032\0030\001H\007J\030\020·\001\032\005\030\0010¸\0012\n\020¶\001\032\005\030\0010\001H\007J\026\020¹\001\032\005\030\0010\0012\b\020º\001\032\0030\001H\007J\030\020»\001\032\005\030\0010\0012\n\020¼\001\032\005\030\0010\001H\007J\035\020½\001\032\0030«\0012\007\020©\001\032\0020\0042\b\020\001\032\0030\001H\007J%\020¾\001\032\0030«\0012\017\020¿\001\032\n\022\004\022\0020v\030\0010u2\b\020\001\032\0030\001H\002J\022\020À\001\032\0020?2\007\020Á\001\032\0020?H\007J\026\020Â\001\032\005\030\0010\0012\b\020¶\001\032\0030\001H\007J\023\020Ã\001\032\0020?2\b\020¶\001\032\0030\001H\007J\026\020Ä\001\032\005\030\0010\0012\b\020º\001\032\0030\001H\007J\024\020Å\001\032\0030\0012\b\020º\001\032\0030\001H\007J\023\020Æ\001\032\0030\0012\007\020Ç\001\032\0020?H\007J?\020È\001\032\0030É\0012\b\020¶\001\032\0030\0012\t\020¨\001\032\004\030\0010\0042\t\020©\001\032\004\030\0010\0042\007\020Ç\001\032\0020?2\n\020Ê\001\032\005\030\0010\001H\007J\n\020Ë\001\032\0030É\001H\007J-\020Ì\001\032\005\030\0010\0012\b\020\001\032\0030\0012\n\020¶\001\032\005\030\0010\0012\t\020\001\032\004\030\0010vH\007J-\020Í\001\032\005\030\0010\0012\b\020\001\032\0030\0012\n\020¶\001\032\005\030\0010\0012\t\020\001\032\004\030\0010vH\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\016\020\n\032\0020\004XT¢\006\002\n\000R\016\020\013\032\0020\004XT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\016\020\r\032\0020\004XT¢\006\002\n\000R\016\020\016\032\0020\004XT¢\006\002\n\000R\016\020\017\032\0020\004XT¢\006\002\n\000R\016\020\020\032\0020\004XT¢\006\002\n\000R\016\020\021\032\0020\004XT¢\006\002\n\000R\016\020\022\032\0020\004XT¢\006\002\n\000R\016\020\023\032\0020\004XT¢\006\002\n\000R\016\020\024\032\0020\004XT¢\006\002\n\000R\016\020\025\032\0020\004XT¢\006\002\n\000R\016\020\026\032\0020\004XT¢\006\002\n\000R\016\020\027\032\0020\004XT¢\006\002\n\000R\016\020\030\032\0020\004XT¢\006\002\n\000R\016\020\031\032\0020\004XT¢\006\002\n\000R\016\020\032\032\0020\004XT¢\006\002\n\000R\016\020\033\032\0020\004XT¢\006\002\n\000R\016\020\034\032\0020\004XT¢\006\002\n\000R\016\020\035\032\0020\004XT¢\006\002\n\000R\016\020\036\032\0020\004XT¢\006\002\n\000R\016\020\037\032\0020\004XT¢\006\002\n\000R\016\020 \032\0020\004XT¢\006\002\n\000R\016\020!\032\0020\004XT¢\006\002\n\000R\016\020\"\032\0020\004XT¢\006\002\n\000R\016\020#\032\0020\004XT¢\006\002\n\000R\016\020$\032\0020\004XT¢\006\002\n\000R\016\020%\032\0020\004XT¢\006\002\n\000R\016\020&\032\0020\004XT¢\006\002\n\000R\016\020'\032\0020\004XT¢\006\002\n\000R\016\020(\032\0020\004XT¢\006\002\n\000R\016\020)\032\0020\004XT¢\006\002\n\000R\016\020*\032\0020\004XT¢\006\002\n\000R\016\020+\032\0020\004XT¢\006\002\n\000R\016\020,\032\0020\004XT¢\006\002\n\000R\016\020-\032\0020\004XT¢\006\002\n\000R\016\020.\032\0020\004XT¢\006\002\n\000R\016\020/\032\0020\004XT¢\006\002\n\000R\016\0200\032\0020\004XT¢\006\002\n\000R\016\0201\032\0020\004XT¢\006\002\n\000R\016\0202\032\0020\004XT¢\006\002\n\000R\016\0203\032\0020\004XT¢\006\002\n\000R\016\0204\032\0020\004XT¢\006\002\n\000R\016\0205\032\0020\004XT¢\006\002\n\000R\016\0206\032\0020\004XT¢\006\002\n\000R\016\0207\032\0020\004XT¢\006\002\n\000R\016\0208\032\0020\004XT¢\006\002\n\000R\016\0209\032\0020\004XT¢\006\002\n\000R\016\020:\032\0020\004XT¢\006\002\n\000R\016\020;\032\0020\004XT¢\006\002\n\000R\016\020<\032\0020\004XT¢\006\002\n\000R\026\020=\032\b\022\004\022\0020?0>X\004¢\006\004\n\002\020@R\016\020A\032\0020?XT¢\006\002\n\000R\016\020B\032\0020?XT¢\006\002\n\000R\016\020C\032\0020?XT¢\006\002\n\000R\016\020D\032\0020?XT¢\006\002\n\000R\016\020E\032\0020?XT¢\006\002\n\000R\016\020F\032\0020?XT¢\006\002\n\000R\016\020G\032\0020?XT¢\006\002\n\000R\016\020H\032\0020?XT¢\006\002\n\000R\016\020I\032\0020?XT¢\006\002\n\000R\016\020J\032\0020?XT¢\006\002\n\000R\016\020K\032\0020?XT¢\006\002\n\000R\016\020L\032\0020?XT¢\006\002\n\000R\016\020M\032\0020?XT¢\006\002\n\000R\016\020N\032\0020\004XT¢\006\002\n\000R\016\020O\032\0020\004XT¢\006\002\n\000R\016\020P\032\0020\004XT¢\006\002\n\000R\016\020Q\032\0020\004XT¢\006\002\n\000R\016\020R\032\0020?XT¢\006\002\n\000R\016\020S\032\0020?XT¢\006\002\n\000R\016\020T\032\0020?XT¢\006\002\n\000R\016\020U\032\0020?XT¢\006\002\n\000R\016\020V\032\0020?XT¢\006\002\n\000R\016\020W\032\0020?XT¢\006\002\n\000R\016\020X\032\0020?XT¢\006\002\n\000R\016\020Y\032\0020?XT¢\006\002\n\000R\016\020Z\032\0020?XT¢\006\002\n\000R\016\020[\032\0020?XT¢\006\002\n\000R\016\020\\\032\0020?XT¢\006\002\n\000R\016\020]\032\0020?XT¢\006\002\n\000R\016\020^\032\0020?XT¢\006\002\n\000R\016\020_\032\0020?XT¢\006\002\n\000R\016\020`\032\0020?XT¢\006\002\n\000R\016\020a\032\0020?XT¢\006\002\n\000R\016\020b\032\0020\004XT¢\006\002\n\000R\016\020c\032\0020\004XT¢\006\002\n\000R\016\020d\032\0020\004XT¢\006\002\n\000R\016\020e\032\0020\004XT¢\006\002\n\000R\016\020f\032\0020\004XT¢\006\002\n\000R\016\020g\032\0020\004XT¢\006\002\n\000R\016\020h\032\0020\004XT¢\006\002\n\000R\016\020i\032\0020\004XT¢\006\002\n\000R\016\020j\032\0020\004XT¢\006\002\n\000R\016\020k\032\0020\004XT¢\006\002\n\000R\016\020l\032\0020\004XT¢\006\002\n\000R\016\020m\032\0020\004XT¢\006\002\n\000R\016\020n\032\0020\004X\004¢\006\002\n\000R\016\020o\032\0020\004XT¢\006\002\n\000R\016\020p\032\0020\004XT¢\006\002\n\000R\016\020q\032\0020\004XT¢\006\002\n\000R\016\020r\032\0020\004XT¢\006\002\n\000R \020s\032\024\022\004\022\0020\004\022\n\022\b\022\004\022\0020v0u0tX\004¢\006\002\n\000R\024\020w\032\b\022\004\022\0020v0uX\004¢\006\002\n\000R\024\020x\032\b\022\004\022\0020v0uX\004¢\006\002\n\000R\032\020y\032\0020?8FX\004¢\006\f\022\004\bz\020\002\032\004\b{\020|R\016\020}\032\0020~X\004¢\006\002\n\000¨\006Ö\001"}, d2 = {"Lcom/facebook/internal/NativeProtocol;", "", "()V", "ACTION_APPINVITE_DIALOG", "", "ACTION_CAMERA_EFFECT", "ACTION_FEED_DIALOG", "ACTION_LIKE_DIALOG", "ACTION_MESSAGE_DIALOG", "ACTION_OGACTIONPUBLISH_DIALOG", "ACTION_OGMESSAGEPUBLISH_DIALOG", "ACTION_SHARE_STORY", "AUDIENCE_EVERYONE", "AUDIENCE_FRIENDS", "AUDIENCE_ME", "BRIDGE_ARG_ACTION_ID_STRING", "BRIDGE_ARG_APP_NAME_STRING", "BRIDGE_ARG_ERROR_BUNDLE", "BRIDGE_ARG_ERROR_CODE", "BRIDGE_ARG_ERROR_DESCRIPTION", "BRIDGE_ARG_ERROR_JSON", "BRIDGE_ARG_ERROR_SUBCODE", "BRIDGE_ARG_ERROR_TYPE", "CONTENT_SCHEME", "ERROR_APPLICATION_ERROR", "ERROR_NETWORK_ERROR", "ERROR_PERMISSION_DENIED", "ERROR_PROTOCOL_ERROR", "ERROR_SERVICE_DISABLED", "ERROR_UNKNOWN_ERROR", "ERROR_USER_CANCELED", "EXTRA_ACCESS_TOKEN", "EXTRA_APPLICATION_ID", "EXTRA_APPLICATION_NAME", "EXTRA_DATA_ACCESS_EXPIRATION_TIME", "EXTRA_DIALOG_COMPLETE_KEY", "EXTRA_DIALOG_COMPLETION_GESTURE_KEY", "EXTRA_EXPIRES_SECONDS_SINCE_EPOCH", "EXTRA_GET_INSTALL_DATA_PACKAGE", "EXTRA_GRAPH_API_VERSION", "EXTRA_LOGGER_REF", "EXTRA_PERMISSIONS", "EXTRA_PROTOCOL_ACTION", "EXTRA_PROTOCOL_BRIDGE_ARGS", "EXTRA_PROTOCOL_CALL_ID", "EXTRA_PROTOCOL_METHOD_ARGS", "EXTRA_PROTOCOL_METHOD_RESULTS", "EXTRA_PROTOCOL_VERSION", "EXTRA_PROTOCOL_VERSIONS", "EXTRA_TOAST_DURATION_MS", "EXTRA_USER_ID", "FACEBOOK_PROXY_AUTH_ACTIVITY", "FACEBOOK_PROXY_AUTH_APP_ID_KEY", "FACEBOOK_PROXY_AUTH_E2E_KEY", "FACEBOOK_PROXY_AUTH_PERMISSIONS_KEY", "FACEBOOK_SDK_VERSION_KEY", "FACEBOOK_TOKEN_REFRESH_ACTIVITY", "IMAGE_URL_KEY", "IMAGE_USER_GENERATED_KEY", "INTENT_ACTION_PLATFORM_ACTIVITY", "INTENT_ACTION_PLATFORM_SERVICE", "KNOWN_PROTOCOL_VERSIONS", "", "", "[Ljava/lang/Integer;", "MESSAGE_GET_ACCESS_TOKEN_REPLY", "MESSAGE_GET_ACCESS_TOKEN_REQUEST", "MESSAGE_GET_AK_SEAMLESS_TOKEN_REPLY", "MESSAGE_GET_AK_SEAMLESS_TOKEN_REQUEST", "MESSAGE_GET_INSTALL_DATA_REPLY", "MESSAGE_GET_INSTALL_DATA_REQUEST", "MESSAGE_GET_LIKE_STATUS_REPLY", "MESSAGE_GET_LIKE_STATUS_REQUEST", "MESSAGE_GET_LOGIN_STATUS_REPLY", "MESSAGE_GET_LOGIN_STATUS_REQUEST", "MESSAGE_GET_PROTOCOL_VERSIONS_REPLY", "MESSAGE_GET_PROTOCOL_VERSIONS_REQUEST", "NO_PROTOCOL_AVAILABLE", "OPEN_GRAPH_CREATE_OBJECT_KEY", "PLATFORM_PROVIDER", "PLATFORM_PROVIDER_VERSIONS", "PLATFORM_PROVIDER_VERSION_COLUMN", "PROTOCOL_VERSION_20121101", "PROTOCOL_VERSION_20130502", "PROTOCOL_VERSION_20130618", "PROTOCOL_VERSION_20131107", "PROTOCOL_VERSION_20140204", "PROTOCOL_VERSION_20140324", "PROTOCOL_VERSION_20140701", "PROTOCOL_VERSION_20141001", "PROTOCOL_VERSION_20141028", "PROTOCOL_VERSION_20141107", "PROTOCOL_VERSION_20141218", "PROTOCOL_VERSION_20160327", "PROTOCOL_VERSION_20170213", "PROTOCOL_VERSION_20170411", "PROTOCOL_VERSION_20170417", "PROTOCOL_VERSION_20171115", "RESULT_ARGS_ACCESS_TOKEN", "RESULT_ARGS_DIALOG_COMPLETE_KEY", "RESULT_ARGS_DIALOG_COMPLETION_GESTURE_KEY", "RESULT_ARGS_EXPIRES_SECONDS_SINCE_EPOCH", "RESULT_ARGS_GRAPH_DOMAIN", "RESULT_ARGS_PERMISSIONS", "RESULT_ARGS_SIGNED_REQUEST", "STATUS_ERROR_CODE", "STATUS_ERROR_DESCRIPTION", "STATUS_ERROR_JSON", "STATUS_ERROR_SUBCODE", "STATUS_ERROR_TYPE", "TAG", "WEB_DIALOG_ACTION", "WEB_DIALOG_IS_FALLBACK", "WEB_DIALOG_PARAMS", "WEB_DIALOG_URL", "actionToAppInfoMap", "", "", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "effectCameraAppInfoList", "facebookAppInfoList", "latestKnownVersion", "getLatestKnownVersion$annotations", "getLatestKnownVersion", "()I", "protocolVersionsAsyncUpdating", "Ljava/util/concurrent/atomic/AtomicBoolean;", "buildActionToAppInfoMap", "buildEffectCameraAppInfoList", "buildFacebookAppList", "buildPlatformProviderVersionURI", "Landroid/net/Uri;", "appInfo", "computeLatestAvailableVersionFromVersionSpec", "allAvailableFacebookAppVersions", "Ljava/util/TreeSet;", "latestSdkVersion", "versionSpec", "", "createBundleForException", "Landroid/os/Bundle;", "e", "Lcom/facebook/FacebookException;", "createFacebookLiteIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "applicationId", "permissions", "", "e2e", "isRerequest", "", "isForPublish", "defaultAudience", "Lcom/facebook/login/DefaultAudience;", "clientState", "authType", "messengerPageId", "resetMessengerState", "isFamilyLogin", "shouldSkipAccountDedupe", "createInstagramIntent", "createNativeAppIntent", "ignoreAppSwitchToLoggedOut", "targetApp", "Lcom/facebook/login/LoginTargetApp;", "createPlatformActivityIntent", "callId", "action", "versionResult", "Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult;", "extras", "createPlatformServiceIntent", "createProtocolResultIntent", "requestIntent", "results", "error", "createProxyAuthIntents", "createTokenRefreshIntent", "fetchAllAvailableProtocolVersionsForAppInfo", "getBridgeArgumentsFromIntent", "intent", "getCallIdFromIntent", "Ljava/util/UUID;", "getErrorDataFromResultIntent", "resultIntent", "getExceptionFromErrorData", "errorData", "getLatestAvailableProtocolVersionForAction", "getLatestAvailableProtocolVersionForAppInfoList", "appInfoList", "getLatestAvailableProtocolVersionForService", "minimumVersion", "getMethodArgumentsFromIntent", "getProtocolVersionFromIntent", "getSuccessResultsFromIntent", "isErrorResult", "isVersionCompatibleWithBucketedIntent", "version", "setupProtocolRequestIntent", "", "params", "updateAllAvailableProtocolVersionsAsync", "validateActivityIntent", "validateServiceIntent", "EffectTestAppInfo", "FBLiteAppInfo", "InstagramAppInfo", "KatanaAppInfo", "MessengerAppInfo", "NativeAppInfo", "ProtocolVersionQueryResult", "WakizashiAppInfo", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class NativeProtocol {
  public static final String ACTION_APPINVITE_DIALOG = "com.facebook.platform.action.request.APPINVITES_DIALOG";
  
  public static final String ACTION_CAMERA_EFFECT = "com.facebook.platform.action.request.CAMERA_EFFECT";
  
  public static final String ACTION_FEED_DIALOG = "com.facebook.platform.action.request.FEED_DIALOG";
  
  public static final String ACTION_LIKE_DIALOG = "com.facebook.platform.action.request.LIKE_DIALOG";
  
  public static final String ACTION_MESSAGE_DIALOG = "com.facebook.platform.action.request.MESSAGE_DIALOG";
  
  public static final String ACTION_OGACTIONPUBLISH_DIALOG = "com.facebook.platform.action.request.OGACTIONPUBLISH_DIALOG";
  
  public static final String ACTION_OGMESSAGEPUBLISH_DIALOG = "com.facebook.platform.action.request.OGMESSAGEPUBLISH_DIALOG";
  
  public static final String ACTION_SHARE_STORY = "com.facebook.platform.action.request.SHARE_STORY";
  
  public static final String AUDIENCE_EVERYONE = "everyone";
  
  public static final String AUDIENCE_FRIENDS = "friends";
  
  public static final String AUDIENCE_ME = "only_me";
  
  public static final String BRIDGE_ARG_ACTION_ID_STRING = "action_id";
  
  public static final String BRIDGE_ARG_APP_NAME_STRING = "app_name";
  
  public static final String BRIDGE_ARG_ERROR_BUNDLE = "error";
  
  public static final String BRIDGE_ARG_ERROR_CODE = "error_code";
  
  public static final String BRIDGE_ARG_ERROR_DESCRIPTION = "error_description";
  
  public static final String BRIDGE_ARG_ERROR_JSON = "error_json";
  
  public static final String BRIDGE_ARG_ERROR_SUBCODE = "error_subcode";
  
  public static final String BRIDGE_ARG_ERROR_TYPE = "error_type";
  
  private static final String CONTENT_SCHEME = "content://";
  
  public static final String ERROR_APPLICATION_ERROR = "ApplicationError";
  
  public static final String ERROR_NETWORK_ERROR = "NetworkError";
  
  public static final String ERROR_PERMISSION_DENIED = "PermissionDenied";
  
  public static final String ERROR_PROTOCOL_ERROR = "ProtocolError";
  
  public static final String ERROR_SERVICE_DISABLED = "ServiceDisabled";
  
  public static final String ERROR_UNKNOWN_ERROR = "UnknownError";
  
  public static final String ERROR_USER_CANCELED = "UserCanceled";
  
  public static final String EXTRA_ACCESS_TOKEN = "com.facebook.platform.extra.ACCESS_TOKEN";
  
  public static final String EXTRA_APPLICATION_ID = "com.facebook.platform.extra.APPLICATION_ID";
  
  public static final String EXTRA_APPLICATION_NAME = "com.facebook.platform.extra.APPLICATION_NAME";
  
  public static final String EXTRA_DATA_ACCESS_EXPIRATION_TIME = "com.facebook.platform.extra.EXTRA_DATA_ACCESS_EXPIRATION_TIME";
  
  public static final String EXTRA_DIALOG_COMPLETE_KEY = "com.facebook.platform.extra.DID_COMPLETE";
  
  public static final String EXTRA_DIALOG_COMPLETION_GESTURE_KEY = "com.facebook.platform.extra.COMPLETION_GESTURE";
  
  public static final String EXTRA_EXPIRES_SECONDS_SINCE_EPOCH = "com.facebook.platform.extra.EXPIRES_SECONDS_SINCE_EPOCH";
  
  public static final String EXTRA_GET_INSTALL_DATA_PACKAGE = "com.facebook.platform.extra.INSTALLDATA_PACKAGE";
  
  public static final String EXTRA_GRAPH_API_VERSION = "com.facebook.platform.extra.GRAPH_API_VERSION";
  
  public static final String EXTRA_LOGGER_REF = "com.facebook.platform.extra.LOGGER_REF";
  
  public static final String EXTRA_PERMISSIONS = "com.facebook.platform.extra.PERMISSIONS";
  
  public static final String EXTRA_PROTOCOL_ACTION = "com.facebook.platform.protocol.PROTOCOL_ACTION";
  
  public static final String EXTRA_PROTOCOL_BRIDGE_ARGS = "com.facebook.platform.protocol.BRIDGE_ARGS";
  
  public static final String EXTRA_PROTOCOL_CALL_ID = "com.facebook.platform.protocol.CALL_ID";
  
  public static final String EXTRA_PROTOCOL_METHOD_ARGS = "com.facebook.platform.protocol.METHOD_ARGS";
  
  public static final String EXTRA_PROTOCOL_METHOD_RESULTS = "com.facebook.platform.protocol.RESULT_ARGS";
  
  public static final String EXTRA_PROTOCOL_VERSION = "com.facebook.platform.protocol.PROTOCOL_VERSION";
  
  public static final String EXTRA_PROTOCOL_VERSIONS = "com.facebook.platform.extra.PROTOCOL_VERSIONS";
  
  public static final String EXTRA_TOAST_DURATION_MS = "com.facebook.platform.extra.EXTRA_TOAST_DURATION_MS";
  
  public static final String EXTRA_USER_ID = "com.facebook.platform.extra.USER_ID";
  
  private static final String FACEBOOK_PROXY_AUTH_ACTIVITY = "com.facebook.katana.ProxyAuth";
  
  public static final String FACEBOOK_PROXY_AUTH_APP_ID_KEY = "client_id";
  
  public static final String FACEBOOK_PROXY_AUTH_E2E_KEY = "e2e";
  
  public static final String FACEBOOK_PROXY_AUTH_PERMISSIONS_KEY = "scope";
  
  public static final String FACEBOOK_SDK_VERSION_KEY = "facebook_sdk_version";
  
  private static final String FACEBOOK_TOKEN_REFRESH_ACTIVITY = "com.facebook.katana.platform.TokenRefreshService";
  
  public static final String IMAGE_URL_KEY = "url";
  
  public static final String IMAGE_USER_GENERATED_KEY = "user_generated";
  
  public static final NativeProtocol INSTANCE;
  
  public static final String INTENT_ACTION_PLATFORM_ACTIVITY = "com.facebook.platform.PLATFORM_ACTIVITY";
  
  public static final String INTENT_ACTION_PLATFORM_SERVICE = "com.facebook.platform.PLATFORM_SERVICE";
  
  private static final Integer[] KNOWN_PROTOCOL_VERSIONS;
  
  public static final int MESSAGE_GET_ACCESS_TOKEN_REPLY = 65537;
  
  public static final int MESSAGE_GET_ACCESS_TOKEN_REQUEST = 65536;
  
  public static final int MESSAGE_GET_AK_SEAMLESS_TOKEN_REPLY = 65545;
  
  public static final int MESSAGE_GET_AK_SEAMLESS_TOKEN_REQUEST = 65544;
  
  public static final int MESSAGE_GET_INSTALL_DATA_REPLY = 65541;
  
  public static final int MESSAGE_GET_INSTALL_DATA_REQUEST = 65540;
  
  public static final int MESSAGE_GET_LIKE_STATUS_REPLY = 65543;
  
  public static final int MESSAGE_GET_LIKE_STATUS_REQUEST = 65542;
  
  public static final int MESSAGE_GET_LOGIN_STATUS_REPLY = 65547;
  
  public static final int MESSAGE_GET_LOGIN_STATUS_REQUEST = 65546;
  
  public static final int MESSAGE_GET_PROTOCOL_VERSIONS_REPLY = 65539;
  
  public static final int MESSAGE_GET_PROTOCOL_VERSIONS_REQUEST = 65538;
  
  public static final int NO_PROTOCOL_AVAILABLE = -1;
  
  public static final String OPEN_GRAPH_CREATE_OBJECT_KEY = "fbsdk:create_object";
  
  private static final String PLATFORM_PROVIDER = ".provider.PlatformProvider";
  
  private static final String PLATFORM_PROVIDER_VERSIONS = ".provider.PlatformProvider/versions";
  
  private static final String PLATFORM_PROVIDER_VERSION_COLUMN = "version";
  
  public static final int PROTOCOL_VERSION_20121101 = 20121101;
  
  public static final int PROTOCOL_VERSION_20130502 = 20130502;
  
  public static final int PROTOCOL_VERSION_20130618 = 20130618;
  
  public static final int PROTOCOL_VERSION_20131107 = 20131107;
  
  public static final int PROTOCOL_VERSION_20140204 = 20140204;
  
  public static final int PROTOCOL_VERSION_20140324 = 20140324;
  
  public static final int PROTOCOL_VERSION_20140701 = 20140701;
  
  public static final int PROTOCOL_VERSION_20141001 = 20141001;
  
  public static final int PROTOCOL_VERSION_20141028 = 20141028;
  
  public static final int PROTOCOL_VERSION_20141107 = 20141107;
  
  public static final int PROTOCOL_VERSION_20141218 = 20141218;
  
  public static final int PROTOCOL_VERSION_20160327 = 20160327;
  
  public static final int PROTOCOL_VERSION_20170213 = 20170213;
  
  public static final int PROTOCOL_VERSION_20170411 = 20170411;
  
  public static final int PROTOCOL_VERSION_20170417 = 20170417;
  
  public static final int PROTOCOL_VERSION_20171115 = 20171115;
  
  public static final String RESULT_ARGS_ACCESS_TOKEN = "access_token";
  
  public static final String RESULT_ARGS_DIALOG_COMPLETE_KEY = "didComplete";
  
  public static final String RESULT_ARGS_DIALOG_COMPLETION_GESTURE_KEY = "completionGesture";
  
  public static final String RESULT_ARGS_EXPIRES_SECONDS_SINCE_EPOCH = "expires_seconds_since_epoch";
  
  public static final String RESULT_ARGS_GRAPH_DOMAIN = "graph_domain";
  
  public static final String RESULT_ARGS_PERMISSIONS = "permissions";
  
  public static final String RESULT_ARGS_SIGNED_REQUEST = "signed request";
  
  public static final String STATUS_ERROR_CODE = "com.facebook.platform.status.ERROR_CODE";
  
  public static final String STATUS_ERROR_DESCRIPTION = "com.facebook.platform.status.ERROR_DESCRIPTION";
  
  public static final String STATUS_ERROR_JSON = "com.facebook.platform.status.ERROR_JSON";
  
  public static final String STATUS_ERROR_SUBCODE = "com.facebook.platform.status.ERROR_SUBCODE";
  
  public static final String STATUS_ERROR_TYPE = "com.facebook.platform.status.ERROR_TYPE";
  
  private static final String TAG;
  
  public static final String WEB_DIALOG_ACTION = "action";
  
  public static final String WEB_DIALOG_IS_FALLBACK = "is_fallback";
  
  public static final String WEB_DIALOG_PARAMS = "params";
  
  public static final String WEB_DIALOG_URL = "url";
  
  private static final Map<String, List<NativeAppInfo>> actionToAppInfoMap;
  
  private static final List<NativeAppInfo> effectCameraAppInfoList;
  
  private static final List<NativeAppInfo> facebookAppInfoList;
  
  private static final AtomicBoolean protocolVersionsAsyncUpdating;
  
  static {
    NativeProtocol nativeProtocol = new NativeProtocol();
    INSTANCE = nativeProtocol;
    String str = NativeProtocol.class.getName();
    Intrinsics.checkNotNullExpressionValue(str, "NativeProtocol::class.java.name");
    TAG = str;
    facebookAppInfoList = nativeProtocol.buildFacebookAppList();
    effectCameraAppInfoList = nativeProtocol.buildEffectCameraAppInfoList();
    actionToAppInfoMap = nativeProtocol.buildActionToAppInfoMap();
    protocolVersionsAsyncUpdating = new AtomicBoolean(false);
    KNOWN_PROTOCOL_VERSIONS = new Integer[] { 
        Integer.valueOf(20170417), Integer.valueOf(20160327), Integer.valueOf(20141218), Integer.valueOf(20141107), Integer.valueOf(20141028), Integer.valueOf(20141001), Integer.valueOf(20140701), Integer.valueOf(20140324), Integer.valueOf(20140204), Integer.valueOf(20131107), 
        Integer.valueOf(20130618), Integer.valueOf(20130502), Integer.valueOf(20121101) };
  }
  
  private final Map<String, List<NativeAppInfo>> buildActionToAppInfoMap() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      ArrayList<MessengerAppInfo> arrayList = new ArrayList();
      arrayList.add(new MessengerAppInfo());
      List<NativeAppInfo> list = facebookAppInfoList;
      hashMap.put("com.facebook.platform.action.request.OGACTIONPUBLISH_DIALOG", list);
      hashMap.put("com.facebook.platform.action.request.FEED_DIALOG", list);
      hashMap.put("com.facebook.platform.action.request.LIKE_DIALOG", list);
      hashMap.put("com.facebook.platform.action.request.APPINVITES_DIALOG", list);
      hashMap.put("com.facebook.platform.action.request.MESSAGE_DIALOG", arrayList);
      hashMap.put("com.facebook.platform.action.request.OGMESSAGEPUBLISH_DIALOG", arrayList);
      return (Map)hashMap;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  private final List<NativeAppInfo> buildEffectCameraAppInfoList() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return null;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  private final List<NativeAppInfo> buildFacebookAppList() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return CollectionsKt.arrayListOf((Object[])new NativeAppInfo[] { new KatanaAppInfo(), new WakizashiAppInfo() });
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  private final Uri buildPlatformProviderVersionURI(NativeAppInfo paramNativeAppInfo) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      StringBuilder stringBuilder = new StringBuilder("content://");
      stringBuilder.append(paramNativeAppInfo.getPackage());
      stringBuilder.append(".provider.PlatformProvider/versions");
      return uri;
    } finally {
      paramNativeAppInfo = null;
      CrashShieldHandler.handleThrowable((Throwable)paramNativeAppInfo, this);
    } 
  }
  
  @JvmStatic
  public static final int computeLatestAvailableVersionFromVersionSpec(TreeSet<Integer> paramTreeSet, int paramInt, int[] paramArrayOfint) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return 0; 
    try {
      Intrinsics.checkNotNullParameter(paramArrayOfint, "versionSpec");
      byte b = -1;
      if (paramTreeSet == null)
        return -1; 
      int j = paramArrayOfint.length - 1;
      Iterator<Integer> iterator = paramTreeSet.descendingIterator();
      int i = -1;
      while (true) {
        int k;
        int n;
        Integer integer;
        int m = b;
        if (iterator.hasNext()) {
          integer = iterator.next();
          Intrinsics.checkNotNullExpressionValue(integer, "fbAppVersion");
          n = Math.max(i, integer.intValue());
          for (k = j; k >= 0 && paramArrayOfint[k] > integer.intValue(); k--);
        } else {
          return m;
        } 
        if (k < 0)
          return -1; 
        j = k;
        i = n;
        if (paramArrayOfint[k] == integer.intValue())
          return m; 
      } 
    } finally {
      paramTreeSet = null;
      CrashShieldHandler.handleThrowable((Throwable)paramTreeSet, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Bundle createBundleForException(FacebookException paramFacebookException) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    if (paramFacebookException == null)
      return null; 
    try {
      Bundle bundle = new Bundle();
      return bundle;
    } finally {
      paramFacebookException = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookException, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent createFacebookLiteIntent(Context paramContext, String paramString1, Collection<String> paramCollection, String paramString2, boolean paramBoolean1, boolean paramBoolean2, DefaultAudience paramDefaultAudience, String paramString3, String paramString4, String paramString5, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramContext, "context");
      Intrinsics.checkNotNullParameter(paramString1, "applicationId");
      Intrinsics.checkNotNullParameter(paramCollection, "permissions");
      Intrinsics.checkNotNullParameter(paramString2, "e2e");
      Intrinsics.checkNotNullParameter(paramDefaultAudience, "defaultAudience");
      Intrinsics.checkNotNullParameter(paramString3, "clientState");
      return validateActivityIntent(paramContext, INSTANCE.createNativeAppIntent(fBLiteAppInfo, paramString1, paramCollection, paramString2, paramBoolean2, paramDefaultAudience, paramString3, paramString4, false, paramString5, paramBoolean3, LoginTargetApp.FACEBOOK, paramBoolean4, paramBoolean5), fBLiteAppInfo);
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent createInstagramIntent(Context paramContext, String paramString1, Collection<String> paramCollection, String paramString2, boolean paramBoolean1, boolean paramBoolean2, DefaultAudience paramDefaultAudience, String paramString3, String paramString4, String paramString5, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramContext, "context");
      Intrinsics.checkNotNullParameter(paramString1, "applicationId");
      Intrinsics.checkNotNullParameter(paramCollection, "permissions");
      Intrinsics.checkNotNullParameter(paramString2, "e2e");
      Intrinsics.checkNotNullParameter(paramDefaultAudience, "defaultAudience");
      Intrinsics.checkNotNullParameter(paramString3, "clientState");
      return validateActivityIntent(paramContext, INSTANCE.createNativeAppIntent(instagramAppInfo, paramString1, paramCollection, paramString2, paramBoolean2, paramDefaultAudience, paramString3, paramString4, false, paramString5, paramBoolean3, LoginTargetApp.INSTAGRAM, paramBoolean4, paramBoolean5), instagramAppInfo);
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  private final Intent createNativeAppIntent(NativeAppInfo paramNativeAppInfo, String paramString1, Collection<String> paramCollection, String paramString2, boolean paramBoolean1, DefaultAudience paramDefaultAudience, String paramString3, String paramString4, boolean paramBoolean2, String paramString5, boolean paramBoolean3, LoginTargetApp paramLoginTargetApp, boolean paramBoolean4, boolean paramBoolean5) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return null;
    } finally {
      paramNativeAppInfo = null;
      CrashShieldHandler.handleThrowable((Throwable)paramNativeAppInfo, this);
    } 
  }
  
  @JvmStatic
  public static final Intent createPlatformActivityIntent(Context paramContext, String paramString1, String paramString2, ProtocolVersionQueryResult paramProtocolVersionQueryResult, Bundle paramBundle) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramContext, "context");
      if (paramProtocolVersionQueryResult == null)
        return null; 
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent createPlatformServiceIntent(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent createProtocolResultIntent(Intent paramIntent, Bundle paramBundle, FacebookException paramFacebookException) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramIntent, "requestIntent");
      return null;
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final List<Intent> createProxyAuthIntents(Context paramContext, String paramString1, Collection<String> paramCollection, String paramString2, boolean paramBoolean1, boolean paramBoolean2, DefaultAudience paramDefaultAudience, String paramString3, String paramString4, boolean paramBoolean3, String paramString5, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramString1, "applicationId");
      Intrinsics.checkNotNullParameter(paramCollection, "permissions");
      Intrinsics.checkNotNullParameter(paramString2, "e2e");
      Intrinsics.checkNotNullParameter(paramDefaultAudience, "defaultAudience");
      Intrinsics.checkNotNullParameter(paramString3, "clientState");
      Intrinsics.checkNotNullParameter(paramString4, "authType");
      List<NativeAppInfo> list = facebookAppInfoList;
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent createTokenRefreshIntent(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  private final TreeSet<Integer> fetchAllAvailableProtocolVersionsForAppInfo(NativeAppInfo paramNativeAppInfo) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   4: ifeq -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: new java/util/TreeSet
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_3
    //   17: invokestatic getApplicationContext : ()Landroid/content/Context;
    //   20: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   23: astore_2
    //   24: aload_0
    //   25: aload_1
    //   26: invokespecial buildPlatformProviderVersionURI : (Lcom/facebook/internal/NativeProtocol$NativeAppInfo;)Landroid/net/Uri;
    //   29: astore #4
    //   31: aconst_null
    //   32: checkcast android/database/Cursor
    //   35: astore #5
    //   37: invokestatic getApplicationContext : ()Landroid/content/Context;
    //   40: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   43: astore #5
    //   45: new java/lang/StringBuilder
    //   48: dup
    //   49: invokespecial <init> : ()V
    //   52: astore #6
    //   54: aload #6
    //   56: aload_1
    //   57: invokevirtual getPackage : ()Ljava/lang/String;
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: pop
    //   64: aload #6
    //   66: ldc_w '.provider.PlatformProvider'
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload #6
    //   75: invokevirtual toString : ()Ljava/lang/String;
    //   78: astore_1
    //   79: aconst_null
    //   80: checkcast android/content/pm/ProviderInfo
    //   83: astore #6
    //   85: aload #5
    //   87: aload_1
    //   88: iconst_0
    //   89: invokevirtual resolveContentProvider : (Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;
    //   92: astore_1
    //   93: goto -> 113
    //   96: astore_1
    //   97: getstatic com/facebook/internal/NativeProtocol.TAG : Ljava/lang/String;
    //   100: ldc_w 'Failed to query content resolver.'
    //   103: aload_1
    //   104: checkcast java/lang/Throwable
    //   107: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   110: pop
    //   111: aconst_null
    //   112: astore_1
    //   113: aload_1
    //   114: ifnull -> 225
    //   117: aload_2
    //   118: aload #4
    //   120: iconst_1
    //   121: anewarray java/lang/String
    //   124: dup
    //   125: iconst_0
    //   126: ldc_w 'version'
    //   129: aastore
    //   130: aconst_null
    //   131: aconst_null
    //   132: aconst_null
    //   133: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   136: astore_1
    //   137: goto -> 178
    //   140: getstatic com/facebook/internal/NativeProtocol.TAG : Ljava/lang/String;
    //   143: ldc_w 'Failed to query content resolver.'
    //   146: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   149: pop
    //   150: goto -> 176
    //   153: getstatic com/facebook/internal/NativeProtocol.TAG : Ljava/lang/String;
    //   156: ldc_w 'Failed to query content resolver.'
    //   159: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   162: pop
    //   163: goto -> 176
    //   166: getstatic com/facebook/internal/NativeProtocol.TAG : Ljava/lang/String;
    //   169: ldc_w 'Failed to query content resolver.'
    //   172: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   175: pop
    //   176: aconst_null
    //   177: astore_1
    //   178: aload_1
    //   179: astore_2
    //   180: aload_1
    //   181: ifnull -> 227
    //   184: aload_1
    //   185: astore_2
    //   186: aload_1
    //   187: invokeinterface moveToNext : ()Z
    //   192: ifeq -> 227
    //   195: aload_3
    //   196: aload_1
    //   197: aload_1
    //   198: ldc_w 'version'
    //   201: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   206: invokeinterface getInt : (I)I
    //   211: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   214: invokevirtual add : (Ljava/lang/Object;)Z
    //   217: pop
    //   218: goto -> 184
    //   221: astore_2
    //   222: goto -> 239
    //   225: aconst_null
    //   226: astore_2
    //   227: aload_2
    //   228: ifnull -> 271
    //   231: aload_2
    //   232: invokeinterface close : ()V
    //   237: aload_3
    //   238: areturn
    //   239: aload_1
    //   240: ifnull -> 249
    //   243: aload_1
    //   244: invokeinterface close : ()V
    //   249: aload_2
    //   250: athrow
    //   251: astore_1
    //   252: aload_1
    //   253: aload_0
    //   254: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   257: aconst_null
    //   258: areturn
    //   259: astore_1
    //   260: goto -> 166
    //   263: astore_1
    //   264: goto -> 153
    //   267: astore_1
    //   268: goto -> 140
    //   271: aload_3
    //   272: areturn
    //   273: astore_2
    //   274: aconst_null
    //   275: astore_1
    //   276: goto -> 239
    // Exception table:
    //   from	to	target	type
    //   9	37	251	finally
    //   37	85	273	finally
    //   85	93	96	java/lang/RuntimeException
    //   85	93	273	finally
    //   97	111	273	finally
    //   117	137	259	java/lang/NullPointerException
    //   117	137	263	java/lang/SecurityException
    //   117	137	267	java/lang/IllegalArgumentException
    //   117	137	273	finally
    //   140	150	273	finally
    //   153	163	273	finally
    //   166	176	273	finally
    //   186	218	221	finally
    //   231	237	251	finally
    //   243	249	251	finally
    //   249	251	251	finally
  }
  
  @JvmStatic
  public static final Bundle getBridgeArgumentsFromIntent(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      return !isVersionCompatibleWithBucketedIntent(getProtocolVersionFromIntent(paramIntent)) ? null : paramIntent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final UUID getCallIdFromIntent(Intent paramIntent) {
    boolean bool = CrashShieldHandler.isObjectCrashing(NativeProtocol.class);
    UUID uUID = null;
    if (bool)
      return null; 
    if (paramIntent == null)
      return null; 
    try {
      Bundle bundle;
      String str1;
      int i = getProtocolVersionFromIntent(paramIntent);
      String str2 = (String)null;
      if (isVersionCompatibleWithBucketedIntent(i)) {
        bundle = paramIntent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
        if (bundle != null) {
          str1 = bundle.getString("action_id");
        } else {
          bundle = null;
        } 
      } else {
        str1 = bundle.getStringExtra("com.facebook.platform.protocol.CALL_ID");
      } 
      return uUID;
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Bundle getErrorDataFromResultIntent(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramIntent, "resultIntent");
      return (bundle != null) ? bundle.getBundle("error") : paramIntent.getExtras();
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final FacebookException getExceptionFromErrorData(Bundle paramBundle) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    if (paramBundle == null)
      return null; 
    try {
      String str2 = paramBundle.getString("error_type");
      String str1 = str2;
      if (str2 == null)
        str1 = paramBundle.getString("com.facebook.platform.status.ERROR_TYPE"); 
      String str3 = paramBundle.getString("error_description");
      return (str1 != null && StringsKt.equals(str1, "UserCanceled", true)) ? (FacebookException)new FacebookOperationCanceledException(str2) : new FacebookException(str2);
    } finally {
      paramBundle = null;
      CrashShieldHandler.handleThrowable((Throwable)paramBundle, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final ProtocolVersionQueryResult getLatestAvailableProtocolVersionForAction(String paramString, int[] paramArrayOfint) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramString, "action");
      Intrinsics.checkNotNullParameter(paramArrayOfint, "versionSpec");
      return INSTANCE.getLatestAvailableProtocolVersionForAppInfoList(list, paramArrayOfint);
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, NativeProtocol.class);
    } 
  }
  
  private final ProtocolVersionQueryResult getLatestAvailableProtocolVersionForAppInfoList(List<? extends NativeAppInfo> paramList, int[] paramArrayOfint) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      updateAllAvailableProtocolVersionsAsync();
      return ProtocolVersionQueryResult.Companion.createEmpty();
    } finally {
      paramList = null;
      CrashShieldHandler.handleThrowable((Throwable)paramList, this);
    } 
  }
  
  @JvmStatic
  public static final int getLatestAvailableProtocolVersionForService(int paramInt) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return 0; 
    try {
      return INSTANCE.getLatestAvailableProtocolVersionForAppInfoList(facebookAppInfoList, new int[] { paramInt }).getProtocolVersion();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, NativeProtocol.class);
    } 
  }
  
  public static final int getLatestKnownVersion() {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return 0; 
    try {
      return KNOWN_PROTOCOL_VERSIONS[0].intValue();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Bundle getMethodArgumentsFromIntent(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      return !isVersionCompatibleWithBucketedIntent(getProtocolVersionFromIntent(paramIntent)) ? paramIntent.getExtras() : paramIntent.getBundleExtra("com.facebook.platform.protocol.METHOD_ARGS");
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final int getProtocolVersionFromIntent(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return 0; 
    try {
      return paramIntent.getIntExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", 0);
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Bundle getSuccessResultsFromIntent(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramIntent, "resultIntent");
      int i = getProtocolVersionFromIntent(paramIntent);
      Bundle bundle2 = paramIntent.getExtras();
      return bundle1;
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final boolean isErrorResult(Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return false; 
    try {
      return (bundle != null) ? bundle.containsKey("error") : paramIntent.hasExtra("com.facebook.platform.status.ERROR_TYPE");
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final boolean isVersionCompatibleWithBucketedIntent(int paramInt) {
    boolean bool = CrashShieldHandler.isObjectCrashing(NativeProtocol.class);
    boolean bool1 = false;
    if (bool)
      return false; 
    try {
      boolean bool2 = ArraysKt.contains((Object[])KNOWN_PROTOCOL_VERSIONS, Integer.valueOf(paramInt));
      return bool;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final void setupProtocolRequestIntent(Intent paramIntent, String paramString1, String paramString2, int paramInt, Bundle paramBundle) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramIntent, "intent");
      String str2 = FacebookSdk.getApplicationId();
      String str1 = FacebookSdk.getApplicationName();
      paramIntent.putExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", paramInt).putExtra("com.facebook.platform.protocol.PROTOCOL_ACTION", paramString2).putExtra("com.facebook.platform.extra.APPLICATION_ID", str2);
      if (isVersionCompatibleWithBucketedIntent(paramInt)) {
        Bundle bundle = new Bundle();
        bundle.putString("action_id", paramString1);
        Utility.putNonEmptyString(bundle, "app_name", str1);
        paramIntent.putExtra("com.facebook.platform.protocol.BRIDGE_ARGS", bundle);
        return;
      } 
      paramIntent.putExtra("com.facebook.platform.protocol.CALL_ID", paramString1);
      return;
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final void updateAllAvailableProtocolVersionsAsync() {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent validateActivityIntent(Context paramContext, Intent paramIntent, NativeAppInfo paramNativeAppInfo) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramContext, "context");
      if (paramIntent == null)
        return null; 
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @JvmStatic
  public static final Intent validateServiceIntent(Context paramContext, Intent paramIntent, NativeAppInfo paramNativeAppInfo) {
    if (CrashShieldHandler.isObjectCrashing(NativeProtocol.class))
      return null; 
    try {
      Intrinsics.checkNotNullParameter(paramContext, "context");
      if (paramIntent == null)
        return null; 
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, NativeProtocol.class);
    } 
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\001\n\000\n\002\020\016\n\000\b\002\030\0002\0020\001B\005¢\006\002\020\002J\n\020\003\032\004\030\0010\004H\026J\b\020\005\032\0020\006H\026¨\006\007"}, d2 = {"Lcom/facebook/internal/NativeProtocol$EffectTestAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class EffectTestAppInfo extends NativeAppInfo {
    public Void getLoginActivity() {
      return null;
    }
    
    public String getPackage() {
      return "com.facebook.arstudio.player";
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\b\002\030\000 \0062\0020\001:\001\006B\005¢\006\002\020\002J\b\020\003\032\0020\004H\026J\b\020\005\032\0020\004H\026¨\006\007"}, d2 = {"Lcom/facebook/internal/NativeProtocol$FBLiteAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class FBLiteAppInfo extends NativeAppInfo {
    public static final Companion Companion = new Companion(null);
    
    public static final String FACEBOOK_LITE_ACTIVITY = "com.facebook.lite.platform.LoginGDPDialogActivity";
    
    public String getLoginActivity() {
      return "com.facebook.lite.platform.LoginGDPDialogActivity";
    }
    
    public String getPackage() {
      return "com.facebook.lite";
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/internal/NativeProtocol$FBLiteAppInfo$Companion;", "", "()V", "FACEBOOK_LITE_ACTIVITY", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/internal/NativeProtocol$FBLiteAppInfo$Companion;", "", "()V", "FACEBOOK_LITE_ACTIVITY", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\b\002\030\0002\0020\001B\005¢\006\002\020\002J\b\020\003\032\0020\004H\026J\b\020\005\032\0020\004H\026J\b\020\006\032\0020\004H\026¨\006\007"}, d2 = {"Lcom/facebook/internal/NativeProtocol$InstagramAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "getResponseType", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class InstagramAppInfo extends NativeAppInfo {
    public String getLoginActivity() {
      return "com.instagram.platform.AppAuthorizeActivity";
    }
    
    public String getPackage() {
      return "com.instagram.android";
    }
    
    public String getResponseType() {
      return "token,signed_request,graph_domain,granted_scopes";
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\000\n\002\020\002\n\000\b\002\030\0002\0020\001B\005¢\006\002\020\002J\b\020\003\032\0020\004H\026J\b\020\005\032\0020\004H\026J\b\020\006\032\0020\007H\002J\b\020\b\032\0020\tH\026¨\006\n"}, d2 = {"Lcom/facebook/internal/NativeProtocol$KatanaAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "isAndroidAPIVersionNotLessThan30", "", "onAvailableVersionsNullOrEmpty", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class KatanaAppInfo extends NativeAppInfo {
    private final boolean isAndroidAPIVersionNotLessThan30() {
      return ((FacebookSdk.getApplicationContext().getApplicationInfo()).targetSdkVersion >= 30);
    }
    
    public String getLoginActivity() {
      return "com.facebook.katana.ProxyAuth";
    }
    
    public String getPackage() {
      return "com.facebook.katana";
    }
    
    public void onAvailableVersionsNullOrEmpty() {
      if (isAndroidAPIVersionNotLessThan30())
        Log.w(NativeProtocol.access$getTAG$p(NativeProtocol.INSTANCE), "Apps that target Android API 30+ (Android 11+) cannot call Facebook native apps unless the package visibility needs are declared. Please follow https://developers.facebook.com/docs/android/troubleshooting/#faq_267321845055988 to make the declaration."); 
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\001\n\000\n\002\020\016\n\000\b\002\030\0002\0020\001B\005¢\006\002\020\002J\n\020\003\032\004\030\0010\004H\026J\b\020\005\032\0020\006H\026¨\006\007"}, d2 = {"Lcom/facebook/internal/NativeProtocol$MessengerAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class MessengerAppInfo extends NativeAppInfo {
    public Void getLoginActivity() {
      return null;
    }
    
    public String getPackage() {
      return "com.facebook.orca";
    }
  }
  
  @Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\020\b\n\000\n\002\020\002\n\000\n\002\020\013\n\002\b\002\n\002\020\016\n\002\b\004\b&\030\0002\0020\001B\005¢\006\002\020\002J\016\020\006\032\0020\0072\006\020\b\032\0020\tJ\016\020\n\032\n\022\004\022\0020\005\030\0010\004J\n\020\013\032\004\030\0010\fH&J\b\020\r\032\0020\fH&J\b\020\016\032\0020\fH\026J\b\020\017\032\0020\007H\026R\026\020\003\032\n\022\004\022\0020\005\030\0010\004X\016¢\006\002\n\000¨\006\020"}, d2 = {"Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "", "()V", "availableVersions", "Ljava/util/TreeSet;", "", "fetchAvailableVersions", "", "force", "", "getAvailableVersions", "getLoginActivity", "", "getPackage", "getResponseType", "onAvailableVersionsNullOrEmpty", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static abstract class NativeAppInfo {
    private TreeSet<Integer> availableVersions;
    
    public final void fetchAvailableVersions(boolean param1Boolean) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: iload_1
      //   3: ifne -> 26
      //   6: aload_0
      //   7: getfield availableVersions : Ljava/util/TreeSet;
      //   10: astore_3
      //   11: aload_3
      //   12: ifnull -> 26
      //   15: aload_3
      //   16: ifnull -> 26
      //   19: aload_3
      //   20: invokevirtual isEmpty : ()Z
      //   23: ifeq -> 37
      //   26: aload_0
      //   27: getstatic com/facebook/internal/NativeProtocol.INSTANCE : Lcom/facebook/internal/NativeProtocol;
      //   30: aload_0
      //   31: invokestatic access$fetchAllAvailableProtocolVersionsForAppInfo : (Lcom/facebook/internal/NativeProtocol;Lcom/facebook/internal/NativeProtocol$NativeAppInfo;)Ljava/util/TreeSet;
      //   34: putfield availableVersions : Ljava/util/TreeSet;
      //   37: aload_0
      //   38: getfield availableVersions : Ljava/util/TreeSet;
      //   41: checkcast java/util/Collection
      //   44: astore_3
      //   45: aload_3
      //   46: ifnull -> 82
      //   49: aload_3
      //   50: invokeinterface isEmpty : ()Z
      //   55: ifeq -> 77
      //   58: goto -> 82
      //   61: iload_2
      //   62: ifeq -> 69
      //   65: aload_0
      //   66: invokevirtual onAvailableVersionsNullOrEmpty : ()V
      //   69: aload_0
      //   70: monitorexit
      //   71: return
      //   72: astore_3
      //   73: aload_0
      //   74: monitorexit
      //   75: aload_3
      //   76: athrow
      //   77: iconst_0
      //   78: istore_2
      //   79: goto -> 61
      //   82: iconst_1
      //   83: istore_2
      //   84: goto -> 61
      // Exception table:
      //   from	to	target	type
      //   6	11	72	finally
      //   19	26	72	finally
      //   26	37	72	finally
      //   37	45	72	finally
      //   49	58	72	finally
      //   65	69	72	finally
    }
    
    public final TreeSet<Integer> getAvailableVersions() {
      TreeSet<Integer> treeSet = this.availableVersions;
      if (treeSet == null || treeSet == null || treeSet.isEmpty())
        fetchAvailableVersions(false); 
      return this.availableVersions;
    }
    
    public abstract String getLoginActivity();
    
    public abstract String getPackage();
    
    public String getResponseType() {
      return "token,signed_request,graph_domain";
    }
    
    public void onAvailableVersionsNullOrEmpty() {}
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\005\030\000 \f2\0020\001:\001\fB\007\b\002¢\006\002\020\002R\"\020\005\032\004\030\0010\0042\b\020\003\032\004\030\0010\004@BX\016¢\006\b\n\000\032\004\b\006\020\007R\036\020\t\032\0020\b2\006\020\003\032\0020\b@BX\016¢\006\b\n\000\032\004\b\n\020\013¨\006\r"}, d2 = {"Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult;", "", "()V", "<set-?>", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "appInfo", "getAppInfo", "()Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "", "protocolVersion", "getProtocolVersion", "()I", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class ProtocolVersionQueryResult {
    public static final Companion Companion = new Companion(null);
    
    private NativeProtocol.NativeAppInfo appInfo;
    
    private int protocolVersion;
    
    private ProtocolVersionQueryResult() {}
    
    @JvmStatic
    public static final ProtocolVersionQueryResult create(NativeProtocol.NativeAppInfo param1NativeAppInfo, int param1Int) {
      return Companion.create(param1NativeAppInfo, param1Int);
    }
    
    @JvmStatic
    public static final ProtocolVersionQueryResult createEmpty() {
      return Companion.createEmpty();
    }
    
    public final NativeProtocol.NativeAppInfo getAppInfo() {
      return this.appInfo;
    }
    
    public final int getProtocolVersion() {
      return this.protocolVersion;
    }
    
    @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\032\020\003\032\0020\0042\b\020\005\032\004\030\0010\0062\006\020\007\032\0020\bH\007J\b\020\t\032\0020\004H\007¨\006\n"}, d2 = {"Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult$Companion;", "", "()V", "create", "Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult;", "nativeAppInfo", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "protocolVersion", "", "createEmpty", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
      
      @JvmStatic
      public final NativeProtocol.ProtocolVersionQueryResult create(NativeProtocol.NativeAppInfo param2NativeAppInfo, int param2Int) {
        NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = new NativeProtocol.ProtocolVersionQueryResult(null);
        protocolVersionQueryResult.appInfo = param2NativeAppInfo;
        protocolVersionQueryResult.protocolVersion = param2Int;
        return protocolVersionQueryResult;
      }
      
      @JvmStatic
      public final NativeProtocol.ProtocolVersionQueryResult createEmpty() {
        NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = new NativeProtocol.ProtocolVersionQueryResult(null);
        protocolVersionQueryResult.protocolVersion = -1;
        return protocolVersionQueryResult;
      }
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\032\020\003\032\0020\0042\b\020\005\032\004\030\0010\0062\006\020\007\032\0020\bH\007J\b\020\t\032\0020\004H\007¨\006\n"}, d2 = {"Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult$Companion;", "", "()V", "create", "Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult;", "nativeAppInfo", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "protocolVersion", "", "createEmpty", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    @JvmStatic
    public final NativeProtocol.ProtocolVersionQueryResult create(NativeProtocol.NativeAppInfo param1NativeAppInfo, int param1Int) {
      NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = new NativeProtocol.ProtocolVersionQueryResult(null);
      protocolVersionQueryResult.appInfo = param1NativeAppInfo;
      protocolVersionQueryResult.protocolVersion = param1Int;
      return protocolVersionQueryResult;
    }
    
    @JvmStatic
    public final NativeProtocol.ProtocolVersionQueryResult createEmpty() {
      NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = new NativeProtocol.ProtocolVersionQueryResult(null);
      protocolVersionQueryResult.protocolVersion = -1;
      return protocolVersionQueryResult;
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\b\002\030\0002\0020\001B\005¢\006\002\020\002J\b\020\003\032\0020\004H\026J\b\020\005\032\0020\004H\026¨\006\006"}, d2 = {"Lcom/facebook/internal/NativeProtocol$WakizashiAppInfo;", "Lcom/facebook/internal/NativeProtocol$NativeAppInfo;", "()V", "getLoginActivity", "", "getPackage", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class WakizashiAppInfo extends NativeAppInfo {
    public String getLoginActivity() {
      return "com.facebook.katana.ProxyAuth";
    }
    
    public String getPackage() {
      return "com.facebook.wakizashi";
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class NativeProtocol$updateAllAvailableProtocolVersionsAsync$1 implements Runnable {
    public static final NativeProtocol$updateAllAvailableProtocolVersionsAsync$1 INSTANCE = new NativeProtocol$updateAllAvailableProtocolVersionsAsync$1();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
        if (bool)
          return; 
        return;
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\NativeProtocol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */