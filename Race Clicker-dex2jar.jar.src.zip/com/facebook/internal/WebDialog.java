package com.facebook.internal;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.facebook.AccessToken;
import com.facebook.FacebookDialogException;
import com.facebook.FacebookException;
import com.facebook.FacebookGraphResponseException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphRequestAsyncTask;
import com.facebook.GraphResponse;
import com.facebook.common.R;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.login.LoginTargetApp;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import org.json.JSONArray;
import org.json.JSONObject;

public class WebDialog extends Dialog {
  private static final int API_EC_DIALOG_CANCEL = 4201;
  
  private static final int BACKGROUND_GRAY = -872415232;
  
  private static final int DEFAULT_THEME = R.style.com_facebook_activity_theme;
  
  static final boolean DISABLE_SSL_CHECK_FOR_TESTING = false;
  
  private static final String DISPLAY_TOUCH = "touch";
  
  private static final String LOG_TAG = "FacebookSDK.WebDialog";
  
  private static final int MAX_PADDING_SCREEN_HEIGHT = 1280;
  
  private static final int MAX_PADDING_SCREEN_WIDTH = 800;
  
  private static final double MIN_SCALE_FACTOR = 0.5D;
  
  private static final int NO_PADDING_SCREEN_HEIGHT = 800;
  
  private static final int NO_PADDING_SCREEN_WIDTH = 480;
  
  private static final String PLATFORM_DIALOG_PATH_REGEX = "^/(v\\d+\\.\\d+/)??dialog/.*";
  
  private static InitCallback initCallback;
  
  private static volatile int webDialogTheme;
  
  private FrameLayout contentFrameLayout;
  
  private ImageView crossImageView;
  
  private String expectedRedirectUrl;
  
  private boolean isDetached;
  
  private boolean isPageFinished;
  
  private boolean listenerCalled;
  
  private OnCompleteListener onCompleteListener;
  
  private ProgressDialog spinner;
  
  private UploadStagingResourcesTask uploadTask;
  
  private String url;
  
  private WebView webView;
  
  private WindowManager.LayoutParams windowParams;
  
  protected WebDialog(Context paramContext, String paramString) {
    this(paramContext, paramString, getWebDialogTheme());
  }
  
  private WebDialog(Context paramContext, String paramString, int paramInt) {
    super(paramContext, i);
    this.expectedRedirectUrl = "fbconnect://success";
    this.listenerCalled = false;
    this.isDetached = false;
    this.isPageFinished = false;
    this.url = paramString;
  }
  
  private WebDialog(Context paramContext, String paramString, Bundle paramBundle, int paramInt, OnCompleteListener paramOnCompleteListener) {
    this(paramContext, paramString, paramBundle, paramInt, LoginTargetApp.FACEBOOK, paramOnCompleteListener);
  }
  
  private WebDialog(Context paramContext, String paramString, Bundle paramBundle, int paramInt, LoginTargetApp paramLoginTargetApp, OnCompleteListener paramOnCompleteListener) {
    super(paramContext, i);
    Uri uri;
    String str2 = "fbconnect://success";
    this.expectedRedirectUrl = "fbconnect://success";
    this.listenerCalled = false;
    this.isDetached = false;
    this.isPageFinished = false;
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    String str1 = str2;
    if (Utility.isChromeOS(paramContext))
      str1 = "fbconnect://chrome_os_success"; 
    this.expectedRedirectUrl = str1;
    bundle.putString("redirect_uri", str1);
    bundle.putString("display", "touch");
    bundle.putString("client_id", FacebookSdk.getApplicationId());
    bundle.putString("sdk", String.format(Locale.ROOT, "android-%s", new Object[] { FacebookSdk.getSdkVersion() }));
    this.onCompleteListener = paramOnCompleteListener;
    if (paramString.equals("share") && bundle.containsKey("media")) {
      this.uploadTask = new UploadStagingResourcesTask(paramString, bundle);
      return;
    } 
    if (null.$SwitchMap$com$facebook$login$LoginTargetApp[paramLoginTargetApp.ordinal()] != 1) {
      String str = ServerProtocol.getDialogAuthority();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(FacebookSdk.getGraphApiVersion());
      stringBuilder.append("/dialog/");
      stringBuilder.append(paramString);
      uri = Utility.buildUri(str, stringBuilder.toString(), bundle);
    } else {
      uri = Utility.buildUri(ServerProtocol.getInstagramDialogAuthority(), "oauth/authorize", bundle);
    } 
    this.url = uri.toString();
  }
  
  private void createCrossImage() {
    ImageView imageView = new ImageView(getContext());
    this.crossImageView = imageView;
    imageView.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (CrashShieldHandler.isObjectCrashing(this))
              return; 
            try {
              return;
            } finally {
              param1View = null;
              CrashShieldHandler.handleThrowable((Throwable)param1View, this);
            } 
          }
        });
    Drawable drawable = getContext().getResources().getDrawable(R.drawable.com_facebook_close);
    this.crossImageView.setImageDrawable(drawable);
    this.crossImageView.setVisibility(4);
  }
  
  private int getScaledSize(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    double d;
    int i = (int)(paramInt1 / paramFloat);
    if (i <= paramInt2) {
      d = 1.0D;
    } else if (i >= paramInt3) {
      d = 0.5D;
    } else {
      d = (paramInt3 - i) / (paramInt3 - paramInt2) * 0.5D + 0.5D;
    } 
    return (int)(paramInt1 * d);
  }
  
  public static int getWebDialogTheme() {
    Validate.sdkInitialized();
    return webDialogTheme;
  }
  
  protected static void initDefaultTheme(Context paramContext) {
    if (paramContext == null)
      return; 
    try {
      ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      if (applicationInfo != null) {
        if (applicationInfo.metaData == null)
          return; 
        if (webDialogTheme == 0)
          setWebDialogTheme(applicationInfo.metaData.getInt("com.facebook.sdk.WebDialogTheme")); 
      } 
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return;
    } 
  }
  
  public static WebDialog newInstance(Context paramContext, String paramString, Bundle paramBundle, int paramInt, OnCompleteListener paramOnCompleteListener) {
    initDefaultTheme(paramContext);
    return new WebDialog(paramContext, paramString, paramBundle, paramInt, LoginTargetApp.FACEBOOK, paramOnCompleteListener);
  }
  
  public static WebDialog newInstance(Context paramContext, String paramString, Bundle paramBundle, int paramInt, LoginTargetApp paramLoginTargetApp, OnCompleteListener paramOnCompleteListener) {
    initDefaultTheme(paramContext);
    return new WebDialog(paramContext, paramString, paramBundle, paramInt, paramLoginTargetApp, paramOnCompleteListener);
  }
  
  public static void setInitCallback(InitCallback paramInitCallback) {
    initCallback = paramInitCallback;
  }
  
  private void setUpWebView(int paramInt) {
    LinearLayout linearLayout = new LinearLayout(getContext());
    WebView webView = new WebView(getContext()) {
        public boolean dispatchTouchEvent(MotionEvent param1MotionEvent) {
          DetectTouchUtils.viewOnTouch("com.facebook", (View)this, param1MotionEvent);
          return super.dispatchTouchEvent(param1MotionEvent);
        }
        
        protected void onMeasure(int param1Int1, int param1Int2) {
          if (!true) {
            setMeasuredDimension(0, 0);
            return;
          } 
          super.onMeasure(param1Int1, param1Int2);
        }
        
        public void onWindowFocusChanged(boolean param1Boolean) {
          try {
            super.onWindowFocusChanged(param1Boolean);
            return;
          } catch (NullPointerException nullPointerException) {
            return;
          } 
        }
      };
    this.webView = webView;
    InitCallback initCallback = initCallback;
    if (initCallback != null)
      initCallback.onInit(webView); 
    this.webView.setVerticalScrollBarEnabled(false);
    this.webView.setHorizontalScrollBarEnabled(false);
    this.webView.setWebViewClient(new DialogWebViewClient());
    this.webView.getSettings().setJavaScriptEnabled(true);
    this.webView.loadUrl(this.url);
    this.webView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    this.webView.setVisibility(4);
    this.webView.getSettings().setSavePassword(false);
    this.webView.getSettings().setSaveFormData(false);
    this.webView.setFocusable(true);
    this.webView.setFocusableInTouchMode(true);
    this.webView.setOnTouchListener(new View.OnTouchListener() {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (!param1View.hasFocus())
              param1View.requestFocus(); 
            return false;
          }
        });
    linearLayout.setPadding(paramInt, paramInt, paramInt, paramInt);
    linearLayout.addView((View)this.webView);
    linearLayout.setBackgroundColor(-872415232);
    this.contentFrameLayout.addView((View)linearLayout);
  }
  
  public static void setWebDialogTheme(int paramInt) {
    if (paramInt == 0)
      paramInt = DEFAULT_THEME; 
    webDialogTheme = paramInt;
  }
  
  public void cancel() {
    if (this.onCompleteListener != null && !this.listenerCalled)
      sendErrorToListener((Throwable)new FacebookOperationCanceledException()); 
  }
  
  public void dismiss() {
    WebView webView = this.webView;
    if (webView != null)
      webView.stopLoading(); 
    if (!this.isDetached) {
      ProgressDialog progressDialog = this.spinner;
      if (progressDialog != null && progressDialog.isShowing())
        this.spinner.dismiss(); 
    } 
    super.dismiss();
  }
  
  public OnCompleteListener getOnCompleteListener() {
    return this.onCompleteListener;
  }
  
  protected WebView getWebView() {
    return this.webView;
  }
  
  protected boolean isListenerCalled() {
    return this.listenerCalled;
  }
  
  protected boolean isPageFinished() {
    return this.isPageFinished;
  }
  
  public void onAttachedToWindow() {
    this.isDetached = false;
    if (Utility.mustFixWindowParamsForAutofill(getContext())) {
      WindowManager.LayoutParams layoutParams = this.windowParams;
      if (layoutParams != null && layoutParams.token == null) {
        this.windowParams.token = (getOwnerActivity().getWindow().getAttributes()).token;
        StringBuilder stringBuilder = new StringBuilder("Set token on onAttachedToWindow(): ");
        stringBuilder.append(this.windowParams.token);
        Utility.logd("FacebookSDK.WebDialog", stringBuilder.toString());
      } 
    } 
    super.onAttachedToWindow();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ProgressDialog progressDialog = new ProgressDialog(getContext());
    this.spinner = progressDialog;
    progressDialog.requestWindowFeature(1);
    this.spinner.setMessage(getContext().getString(R.string.com_facebook_loading));
    this.spinner.setCanceledOnTouchOutside(false);
    this.spinner.setOnCancelListener(new DialogInterface.OnCancelListener() {
          public void onCancel(DialogInterface param1DialogInterface) {
            WebDialog.this.cancel();
          }
        });
    requestWindowFeature(1);
    this.contentFrameLayout = new FrameLayout(getContext());
    resize();
    getWindow().setGravity(17);
    getWindow().setSoftInputMode(16);
    createCrossImage();
    if (this.url != null)
      setUpWebView(this.crossImageView.getDrawable().getIntrinsicWidth() / 2 + 1); 
    this.contentFrameLayout.addView((View)this.crossImageView, new ViewGroup.LayoutParams(-2, -2));
    setContentView((View)this.contentFrameLayout);
  }
  
  public void onDetachedFromWindow() {
    this.isDetached = true;
    super.onDetachedFromWindow();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      WebView webView = this.webView;
      if (webView != null && webView.canGoBack()) {
        this.webView.goBack();
        return true;
      } 
      cancel();
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onStart() {
    super.onStart();
    UploadStagingResourcesTask uploadStagingResourcesTask = this.uploadTask;
    if (uploadStagingResourcesTask != null && uploadStagingResourcesTask.getStatus() == AsyncTask.Status.PENDING) {
      this.uploadTask.execute((Object[])new Void[0]);
      this.spinner.show();
      return;
    } 
    resize();
  }
  
  protected void onStop() {
    UploadStagingResourcesTask uploadStagingResourcesTask = this.uploadTask;
    if (uploadStagingResourcesTask != null) {
      uploadStagingResourcesTask.cancel(true);
      this.spinner.dismiss();
    } 
    super.onStop();
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams) {
    if (paramLayoutParams.token == null)
      this.windowParams = paramLayoutParams; 
    super.onWindowAttributesChanged(paramLayoutParams);
  }
  
  protected Bundle parseResponseUri(String paramString) {
    Uri uri = Uri.parse(paramString);
    Bundle bundle = Utility.parseUrlQueryString(uri.getQuery());
    bundle.putAll(Utility.parseUrlQueryString(uri.getFragment()));
    return bundle;
  }
  
  public void resize() {
    Display display = ((WindowManager)getContext().getSystemService("window")).getDefaultDisplay();
    DisplayMetrics displayMetrics = new DisplayMetrics();
    display.getMetrics(displayMetrics);
    if (displayMetrics.widthPixels < displayMetrics.heightPixels) {
      i = displayMetrics.widthPixels;
    } else {
      i = displayMetrics.heightPixels;
    } 
    if (displayMetrics.widthPixels < displayMetrics.heightPixels) {
      j = displayMetrics.heightPixels;
    } else {
      j = displayMetrics.widthPixels;
    } 
    int i = Math.min(getScaledSize(i, displayMetrics.density, 480, 800), displayMetrics.widthPixels);
    int j = Math.min(getScaledSize(j, displayMetrics.density, 800, 1280), displayMetrics.heightPixels);
    getWindow().setLayout(i, j);
  }
  
  protected void sendErrorToListener(Throwable paramThrowable) {
    if (this.onCompleteListener != null && !this.listenerCalled) {
      FacebookException facebookException;
      this.listenerCalled = true;
      if (paramThrowable instanceof FacebookException) {
        facebookException = (FacebookException)paramThrowable;
      } else {
        facebookException = new FacebookException((Throwable)facebookException);
      } 
      this.onCompleteListener.onComplete(null, facebookException);
      dismiss();
    } 
  }
  
  protected void sendSuccessToListener(Bundle paramBundle) {
    OnCompleteListener onCompleteListener = this.onCompleteListener;
    if (onCompleteListener != null && !this.listenerCalled) {
      this.listenerCalled = true;
      onCompleteListener.onComplete(paramBundle, null);
      dismiss();
    } 
  }
  
  protected void setExpectedRedirectUrl(String paramString) {
    this.expectedRedirectUrl = paramString;
  }
  
  public void setOnCompleteListener(OnCompleteListener paramOnCompleteListener) {
    this.onCompleteListener = paramOnCompleteListener;
  }
  
  public static class Builder {
    private AccessToken accessToken;
    
    private String action;
    
    private String applicationId;
    
    private Context context;
    
    private WebDialog.OnCompleteListener listener;
    
    private Bundle parameters;
    
    private int theme;
    
    public Builder(Context param1Context, String param1String, Bundle param1Bundle) {
      this.accessToken = AccessToken.getCurrentAccessToken();
      if (!AccessToken.isCurrentAccessTokenActive()) {
        String str = Utility.getMetadataApplicationId(param1Context);
        if (str != null) {
          this.applicationId = str;
        } else {
          throw new FacebookException("Attempted to create a builder without a valid access token or a valid default Application ID.");
        } 
      } 
      finishInit(param1Context, param1String, param1Bundle);
    }
    
    public Builder(Context param1Context, String param1String1, String param1String2, Bundle param1Bundle) {
      String str = param1String1;
      if (param1String1 == null)
        str = Utility.getMetadataApplicationId(param1Context); 
      Validate.notNullOrEmpty(str, "applicationId");
      this.applicationId = str;
      finishInit(param1Context, param1String2, param1Bundle);
    }
    
    private void finishInit(Context param1Context, String param1String, Bundle param1Bundle) {
      this.context = param1Context;
      this.action = param1String;
      if (param1Bundle != null) {
        this.parameters = param1Bundle;
        return;
      } 
      this.parameters = new Bundle();
    }
    
    public WebDialog build() {
      AccessToken accessToken = this.accessToken;
      if (accessToken != null) {
        this.parameters.putString("app_id", accessToken.getApplicationId());
        this.parameters.putString("access_token", this.accessToken.getToken());
      } else {
        this.parameters.putString("app_id", this.applicationId);
      } 
      return WebDialog.newInstance(this.context, this.action, this.parameters, this.theme, this.listener);
    }
    
    public String getApplicationId() {
      return this.applicationId;
    }
    
    public Context getContext() {
      return this.context;
    }
    
    public WebDialog.OnCompleteListener getListener() {
      return this.listener;
    }
    
    public Bundle getParameters() {
      return this.parameters;
    }
    
    public int getTheme() {
      return this.theme;
    }
    
    public Builder setOnCompleteListener(WebDialog.OnCompleteListener param1OnCompleteListener) {
      this.listener = param1OnCompleteListener;
      return this;
    }
    
    public Builder setTheme(int param1Int) {
      this.theme = param1Int;
      return this;
    }
  }
  
  private class DialogWebViewClient extends WebViewClient {
    private DialogWebViewClient() {}
    
    public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context param1Context, Intent param1Intent) {
      Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
      if (param1Intent == null)
        return; 
      BrandSafetyUtils.detectAdClick(param1Intent, "com.facebook");
      param1Context.startActivity(param1Intent);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.facebook", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      if (!WebDialog.this.isDetached)
        WebDialog.this.spinner.dismiss(); 
      WebDialog.this.contentFrameLayout.setBackgroundColor(0);
      WebDialog.this.webView.setVisibility(0);
      WebDialog.this.crossImageView.setVisibility(0);
      WebDialog.access$702(WebDialog.this, true);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      StringBuilder stringBuilder = new StringBuilder("Webview loading URL: ");
      stringBuilder.append(param1String);
      Utility.logd("FacebookSDK.WebDialog", stringBuilder.toString());
      super.onPageStarted(param1WebView, param1String, param1Bitmap);
      if (!WebDialog.this.isDetached)
        WebDialog.this.spinner.show(); 
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
      super.onReceivedError(param1WebView, param1Int, param1String1, param1String2);
      WebDialog.this.sendErrorToListener((Throwable)new FacebookDialogException(param1String1, param1Int, param1String2));
    }
    
    public void onReceivedSslError(WebView param1WebView, SslErrorHandler param1SslErrorHandler, SslError param1SslError) {
      super.onReceivedSslError(param1WebView, param1SslErrorHandler, param1SslError);
      param1SslErrorHandler.cancel();
      WebDialog.this.sendErrorToListener((Throwable)new FacebookDialogException(null, -11, null));
    }
    
    public boolean safedk_WebDialog$DialogWebViewClient_shouldOverrideUrlLoading_3cb0a8f079768d040b8ddb58cdcf4909(WebView param1WebView, String param1String) {
      // Byte code:
      //   0: new java/lang/StringBuilder
      //   3: dup
      //   4: ldc 'Redirect URL: '
      //   6: invokespecial <init> : (Ljava/lang/String;)V
      //   9: astore_1
      //   10: aload_1
      //   11: aload_2
      //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   15: pop
      //   16: ldc 'FacebookSDK.WebDialog'
      //   18: aload_1
      //   19: invokevirtual toString : ()Ljava/lang/String;
      //   22: invokestatic logd : (Ljava/lang/String;Ljava/lang/String;)V
      //   25: aload_2
      //   26: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   29: astore_1
      //   30: aload_1
      //   31: invokevirtual getPath : ()Ljava/lang/String;
      //   34: ifnull -> 54
      //   37: ldc '^/(v\d+\.\d+/)??dialog/.*'
      //   39: aload_1
      //   40: invokevirtual getPath : ()Ljava/lang/String;
      //   43: invokestatic matches : (Ljava/lang/String;Ljava/lang/CharSequence;)Z
      //   46: ifeq -> 54
      //   49: iconst_1
      //   50: istore_3
      //   51: goto -> 56
      //   54: iconst_0
      //   55: istore_3
      //   56: aload_2
      //   57: aload_0
      //   58: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   61: invokestatic access$100 : (Lcom/facebook/internal/WebDialog;)Ljava/lang/String;
      //   64: invokevirtual startsWith : (Ljava/lang/String;)Z
      //   67: ifeq -> 277
      //   70: aload_0
      //   71: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   74: aload_2
      //   75: invokevirtual parseResponseUri : (Ljava/lang/String;)Landroid/os/Bundle;
      //   78: astore #5
      //   80: aload #5
      //   82: ldc 'error'
      //   84: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   87: astore_1
      //   88: aload_1
      //   89: astore_2
      //   90: aload_1
      //   91: ifnonnull -> 102
      //   94: aload #5
      //   96: ldc 'error_type'
      //   98: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   101: astore_2
      //   102: aload #5
      //   104: ldc 'error_msg'
      //   106: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   109: astore #4
      //   111: aload #4
      //   113: astore_1
      //   114: aload #4
      //   116: ifnonnull -> 127
      //   119: aload #5
      //   121: ldc 'error_message'
      //   123: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   126: astore_1
      //   127: aload_1
      //   128: astore #4
      //   130: aload_1
      //   131: ifnonnull -> 143
      //   134: aload #5
      //   136: ldc 'error_description'
      //   138: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   141: astore #4
      //   143: aload #5
      //   145: ldc 'error_code'
      //   147: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   150: astore_1
      //   151: aload_1
      //   152: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   155: ifne -> 166
      //   158: aload_1
      //   159: invokestatic parseInt : (Ljava/lang/String;)I
      //   162: istore_3
      //   163: goto -> 168
      //   166: iconst_m1
      //   167: istore_3
      //   168: aload_2
      //   169: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   172: ifeq -> 199
      //   175: aload #4
      //   177: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   180: ifeq -> 199
      //   183: iload_3
      //   184: iconst_m1
      //   185: if_icmpne -> 199
      //   188: aload_0
      //   189: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   192: aload #5
      //   194: invokevirtual sendSuccessToListener : (Landroid/os/Bundle;)V
      //   197: iconst_1
      //   198: ireturn
      //   199: aload_2
      //   200: ifnull -> 230
      //   203: aload_2
      //   204: ldc 'access_denied'
      //   206: invokevirtual equals : (Ljava/lang/Object;)Z
      //   209: ifne -> 221
      //   212: aload_2
      //   213: ldc 'OAuthAccessDeniedException'
      //   215: invokevirtual equals : (Ljava/lang/Object;)Z
      //   218: ifeq -> 230
      //   221: aload_0
      //   222: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   225: invokevirtual cancel : ()V
      //   228: iconst_1
      //   229: ireturn
      //   230: iload_3
      //   231: sipush #4201
      //   234: if_icmpne -> 246
      //   237: aload_0
      //   238: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   241: invokevirtual cancel : ()V
      //   244: iconst_1
      //   245: ireturn
      //   246: new com/facebook/FacebookRequestError
      //   249: dup
      //   250: iload_3
      //   251: aload_2
      //   252: aload #4
      //   254: invokespecial <init> : (ILjava/lang/String;Ljava/lang/String;)V
      //   257: astore_1
      //   258: aload_0
      //   259: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   262: new com/facebook/FacebookServiceException
      //   265: dup
      //   266: aload_1
      //   267: aload #4
      //   269: invokespecial <init> : (Lcom/facebook/FacebookRequestError;Ljava/lang/String;)V
      //   272: invokevirtual sendErrorToListener : (Ljava/lang/Throwable;)V
      //   275: iconst_1
      //   276: ireturn
      //   277: aload_2
      //   278: ldc 'fbconnect://cancel'
      //   280: invokevirtual startsWith : (Ljava/lang/String;)Z
      //   283: ifeq -> 295
      //   286: aload_0
      //   287: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   290: invokevirtual cancel : ()V
      //   293: iconst_1
      //   294: ireturn
      //   295: iload_3
      //   296: ifne -> 336
      //   299: aload_2
      //   300: ldc 'touch'
      //   302: invokevirtual contains : (Ljava/lang/CharSequence;)Z
      //   305: ifeq -> 310
      //   308: iconst_0
      //   309: ireturn
      //   310: aload_0
      //   311: getfield this$0 : Lcom/facebook/internal/WebDialog;
      //   314: invokevirtual getContext : ()Landroid/content/Context;
      //   317: new android/content/Intent
      //   320: dup
      //   321: ldc_w 'android.intent.action.VIEW'
      //   324: aload_2
      //   325: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   328: invokespecial <init> : (Ljava/lang/String;Landroid/net/Uri;)V
      //   331: invokestatic safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6 : (Landroid/content/Context;Landroid/content/Intent;)V
      //   334: iconst_1
      //   335: ireturn
      //   336: iconst_0
      //   337: ireturn
      //   338: astore_1
      //   339: goto -> 166
      //   342: astore_1
      //   343: iconst_0
      //   344: ireturn
      // Exception table:
      //   from	to	target	type
      //   158	163	338	java/lang/NumberFormatException
      //   310	334	342	android/content/ActivityNotFoundException
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.facebook", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.facebook", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      Logger.d("Facebook|SafeDK: Execution> Lcom/facebook/internal/WebDialog$DialogWebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
      boolean bool = safedk_WebDialog$DialogWebViewClient_shouldOverrideUrlLoading_3cb0a8f079768d040b8ddb58cdcf4909(param1WebView, param1String);
      CreativeInfoManager.onOverrideUrlLoading("com.facebook", param1WebView, param1String, bool);
      return bool;
    }
  }
  
  public static interface InitCallback {
    void onInit(WebView param1WebView);
  }
  
  public static interface OnCompleteListener {
    void onComplete(Bundle param1Bundle, FacebookException param1FacebookException);
  }
  
  private class UploadStagingResourcesTask extends AsyncTask<Void, Void, String[]> {
    private String action;
    
    private Exception[] exceptions;
    
    private Bundle parameters;
    
    UploadStagingResourcesTask(String param1String, Bundle param1Bundle) {
      this.action = param1String;
      this.parameters = param1Bundle;
    }
    
    protected String[] doInBackground(Void... param1VarArgs) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return null; 
      try {
        String[] arrayOfString1 = this.parameters.getStringArray("media");
        String[] arrayOfString2 = new String[arrayOfString1.length];
        this.exceptions = new Exception[arrayOfString1.length];
        CountDownLatch countDownLatch = new CountDownLatch(arrayOfString1.length);
        ConcurrentLinkedQueue<GraphRequestAsyncTask> concurrentLinkedQueue = new ConcurrentLinkedQueue();
        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        int i = 0;
        while (true)
          return null; 
      } finally {
        param1VarArgs = null;
        CrashShieldHandler.handleThrowable((Throwable)param1VarArgs, this);
      } 
    }
    
    protected void onPostExecute(String[] param1ArrayOfString) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        WebDialog.this.spinner.dismiss();
        for (Exception exception : this.exceptions) {
          if (exception != null)
            return; 
        } 
        if (param1ArrayOfString == null)
          return; 
        List<String> list = Arrays.asList(param1ArrayOfString);
        if (list.contains(null))
          return; 
        Utility.putJSONValueInBundle(this.parameters, "media", new JSONArray(list));
        String str = ServerProtocol.getDialogAuthority();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(FacebookSdk.getGraphApiVersion());
        stringBuilder.append("/");
        stringBuilder.append("dialog/");
        stringBuilder.append(this.action);
        Uri uri = Utility.buildUri(str, stringBuilder.toString(), this.parameters);
        WebDialog.access$902(WebDialog.this, uri.toString());
        return;
      } finally {
        param1ArrayOfString = null;
        CrashShieldHandler.handleThrowable((Throwable)param1ArrayOfString, this);
      } 
    }
  }
  
  class null implements GraphRequest.Callback {
    public void onCompleted(GraphResponse param1GraphResponse) {
      try {
        FacebookRequestError facebookRequestError = param1GraphResponse.getError();
        String str = "Error staging photo.";
        if (facebookRequestError != null) {
          String str1 = facebookRequestError.getErrorMessage();
          if (str1 != null)
            str = str1; 
          throw new FacebookGraphResponseException(param1GraphResponse, str);
        } 
        JSONObject jSONObject = param1GraphResponse.getJSONObject();
        if (jSONObject != null) {
          String str1 = jSONObject.optString("uri");
          if (str1 != null) {
            results[writeIndex] = str1;
          } else {
            throw new FacebookException("Error staging photo.");
          } 
        } else {
          throw new FacebookException("Error staging photo.");
        } 
      } catch (Exception exception) {
        this.this$1.exceptions[writeIndex] = exception;
      } 
      latch.countDown();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\WebDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */