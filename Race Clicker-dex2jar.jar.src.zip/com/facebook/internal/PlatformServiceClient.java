package com.facebook.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;

public abstract class PlatformServiceClient implements ServiceConnection {
  private final String applicationId;
  
  private final Context context;
  
  private final Handler handler;
  
  private CompletedListener listener;
  
  private final int protocolVersion;
  
  private int replyMessage;
  
  private int requestMessage;
  
  private boolean running;
  
  private Messenger sender;
  
  public PlatformServiceClient(Context paramContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    Context context = paramContext.getApplicationContext();
    if (context != null)
      paramContext = context; 
    this.context = paramContext;
    this.requestMessage = paramInt1;
    this.replyMessage = paramInt2;
    this.applicationId = paramString;
    this.protocolVersion = paramInt3;
    this.handler = new Handler() {
        public void handleMessage(Message param1Message) {
          if (CrashShieldHandler.isObjectCrashing(this))
            return; 
          try {
            return;
          } finally {
            param1Message = null;
            CrashShieldHandler.handleThrowable((Throwable)param1Message, this);
          } 
        }
      };
  }
  
  private void callback(Bundle paramBundle) {
    if (!this.running)
      return; 
    this.running = false;
    CompletedListener completedListener = this.listener;
    if (completedListener != null)
      completedListener.completed(paramBundle); 
  }
  
  private void sendMessage() {
    Bundle bundle = new Bundle();
    bundle.putString("com.facebook.platform.extra.APPLICATION_ID", this.applicationId);
    populateRequestBundle(bundle);
    Message message = Message.obtain(null, this.requestMessage);
    message.arg1 = this.protocolVersion;
    message.setData(bundle);
    message.replyTo = new Messenger(this.handler);
    try {
      this.sender.send(message);
      return;
    } catch (RemoteException remoteException) {
      callback(null);
      return;
    } 
  }
  
  public void cancel() {
    this.running = false;
  }
  
  protected Context getContext() {
    return this.context;
  }
  
  protected void handleMessage(Message paramMessage) {
    if (paramMessage.what == this.replyMessage) {
      Bundle bundle = paramMessage.getData();
      if (bundle.getString("com.facebook.platform.status.ERROR_TYPE") != null) {
        callback(null);
      } else {
        callback(bundle);
      } 
      try {
        this.context.unbindService(this);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        return;
      } 
    } 
  }
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    this.sender = new Messenger(paramIBinder);
    sendMessage();
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    this.sender = null;
    try {
      this.context.unbindService(this);
    } catch (IllegalArgumentException illegalArgumentException) {}
    callback(null);
  }
  
  protected abstract void populateRequestBundle(Bundle paramBundle);
  
  public void setCompletedListener(CompletedListener paramCompletedListener) {
    this.listener = paramCompletedListener;
  }
  
  public boolean start() {
    if (this.running)
      return false; 
    if (NativeProtocol.getLatestAvailableProtocolVersionForService(this.protocolVersion) == -1)
      return false; 
    Intent intent = NativeProtocol.createPlatformServiceIntent(this.context);
    if (intent == null)
      return false; 
    this.running = true;
    this.context.bindService(intent, this, 1);
    return true;
  }
  
  public static interface CompletedListener {
    void completed(Bundle param1Bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\PlatformServiceClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */