package com.facebook.internal;

import com.facebook.FacebookSdk;
import com.facebook.LoggingBehavior;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.security.InvalidParameterException;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

@Metadata(d1 = {"\000Z\n\002\030\002\n\002\020\000\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\013\030\000 )2\0020\001:\b'()*+,-.B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\006\020\026\032\0020\027J\037\020\030\032\004\030\0010\0312\006\020\032\032\0020\0032\n\b\002\020\033\032\004\030\0010\003H\002J\026\020\034\032\0020\0312\006\020\032\032\0020\0032\006\020\035\032\0020\031J\034\020\036\032\0020\0372\006\020\032\032\0020\0032\n\b\002\020\033\032\004\030\0010\003H\007J\b\020 \032\0020\027H\002J\030\020!\032\0020\0272\006\020\032\032\0020\0032\006\020\"\032\0020\013H\002J\006\020#\032\0020$J\b\020%\032\0020\003H\026J\b\020&\032\0020\027H\002R\026\020\007\032\n \t*\004\030\0010\b0\bX\004¢\006\002\n\000R\016\020\n\032\0020\013X\004¢\006\002\n\000R\016\020\f\032\0020\rX\016¢\006\002\n\000R\016\020\016\032\0020\rX\016¢\006\002\n\000R\016\020\017\032\0020\020X\004¢\006\002\n\000R\016\020\004\032\0020\005X\004¢\006\002\n\000R\021\020\021\032\0020\0038F¢\006\006\032\004\b\022\020\023R\016\020\024\032\0020\025X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006/"}, d2 = {"Lcom/facebook/internal/FileLruCache;", "", "tag", "", "limits", "Lcom/facebook/internal/FileLruCache$Limits;", "(Ljava/lang/String;Lcom/facebook/internal/FileLruCache$Limits;)V", "condition", "Ljava/util/concurrent/locks/Condition;", "kotlin.jvm.PlatformType", "directory", "Ljava/io/File;", "isTrimInProgress", "", "isTrimPending", "lastClearCacheTime", "Ljava/util/concurrent/atomic/AtomicLong;", "location", "getLocation", "()Ljava/lang/String;", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "clearCache", "", "get", "Ljava/io/InputStream;", "key", "contentTag", "interceptAndPut", "input", "openPutStream", "Ljava/io/OutputStream;", "postTrim", "renameToTargetAndTrim", "buffer", "sizeInBytesForTest", "", "toString", "trim", "BufferFile", "CloseCallbackOutputStream", "Companion", "CopyingInputStream", "Limits", "ModifiedFile", "StreamCloseCallback", "StreamHeader", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class FileLruCache {
  public static final Companion Companion = new Companion(null);
  
  private static final String HEADER_CACHEKEY_KEY = "key";
  
  private static final String HEADER_CACHE_CONTENT_TAG_KEY = "tag";
  
  private static final String TAG = "FileLruCache";
  
  private static final AtomicLong bufferIndex = new AtomicLong();
  
  private final Condition condition;
  
  private final File directory;
  
  private boolean isTrimInProgress;
  
  private boolean isTrimPending;
  
  private final AtomicLong lastClearCacheTime;
  
  private final Limits limits;
  
  private final ReentrantLock lock;
  
  private final String tag;
  
  public FileLruCache(String paramString, Limits paramLimits) {
    this.tag = paramString;
    this.limits = paramLimits;
    File file = new File(FacebookSdk.getCacheDir(), paramString);
    this.directory = file;
    ReentrantLock reentrantLock = new ReentrantLock();
    this.lock = reentrantLock;
    this.condition = reentrantLock.newCondition();
    this.lastClearCacheTime = new AtomicLong(0L);
    if (file.mkdirs() || file.isDirectory())
      BufferFile.INSTANCE.deleteAll(file); 
  }
  
  private final void postTrim() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (!this.isTrimPending) {
        this.isTrimPending = true;
        FacebookSdk.getExecutor().execute(new FileLruCache$postTrim$$inlined$withLock$lambda$1());
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  private final void renameToTargetAndTrim(String paramString, File paramFile) {
    if (!paramFile.renameTo(new File(this.directory, Utility.md5hash(paramString))))
      paramFile.delete(); 
    postTrim();
  }
  
  private final void trim() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      this.isTrimPending = false;
      this.isTrimInProgress = true;
      Unit unit = Unit.INSTANCE;
      reentrantLock.unlock();
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void clearCache() {
    File[] arrayOfFile = this.directory.listFiles(BufferFile.INSTANCE.excludeBufferFiles());
    this.lastClearCacheTime.set(System.currentTimeMillis());
    if (arrayOfFile != null)
      FacebookSdk.getExecutor().execute(new FileLruCache$clearCache$1(arrayOfFile)); 
  }
  
  public final InputStream get(String paramString) throws IOException {
    return get$default(this, paramString, null, 2, null);
  }
  
  public final InputStream get(String paramString1, String paramString2) throws IOException {
    Intrinsics.checkNotNullParameter(paramString1, "key");
    File file = new File(this.directory, Utility.md5hash(paramString1));
    try {
      FileInputStream fileInputStream = new FileInputStream(file);
      BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream, 8192);
      boolean bool = false;
      try {
        JSONObject jSONObject = StreamHeader.INSTANCE.readHeader(bufferedInputStream);
        if (jSONObject != null) {
          boolean bool1 = Intrinsics.areEqual(jSONObject.optString("key"), paramString1);
          if ((bool1 ^ true) != 0) {
            bufferedInputStream.close();
            return null;
          } 
          paramString1 = jSONObject.optString("tag", null);
          if (paramString2 == null) {
            bool1 = Intrinsics.areEqual(paramString2, paramString1);
            if ((bool1 ^ true) != 0) {
              bufferedInputStream.close();
              return null;
            } 
          } 
          long l = (new Date()).getTime();
          Logger.Companion companion = Logger.Companion;
          LoggingBehavior loggingBehavior = LoggingBehavior.CACHE;
          String str = TAG;
          StringBuilder stringBuilder = new StringBuilder("Setting lastModified to ");
          stringBuilder.append(Long.valueOf(l));
          stringBuilder.append(" for ");
          stringBuilder.append(file.getName());
          companion.log(loggingBehavior, str, stringBuilder.toString());
          file.setLastModified(l);
          try {
            return bufferedInputStream;
          } finally {
            companion = null;
          } 
        } else {
          bufferedInputStream.close();
          return null;
        } 
      } finally {}
      if (!bool)
        bufferedInputStream.close(); 
      throw paramString1;
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  public final String getLocation() {
    String str = this.directory.getPath();
    Intrinsics.checkNotNullExpressionValue(str, "directory.path");
    return str;
  }
  
  public final InputStream interceptAndPut(String paramString, InputStream paramInputStream) throws IOException {
    Intrinsics.checkNotNullParameter(paramString, "key");
    Intrinsics.checkNotNullParameter(paramInputStream, "input");
    return new CopyingInputStream(paramInputStream, openPutStream$default(this, paramString, null, 2, null));
  }
  
  public final OutputStream openPutStream(String paramString) throws IOException {
    return openPutStream$default(this, paramString, null, 2, null);
  }
  
  public final OutputStream openPutStream(String paramString1, String paramString2) throws IOException {
    LoggingBehavior loggingBehavior;
    Intrinsics.checkNotNullParameter(paramString1, "key");
    File file = BufferFile.INSTANCE.newFile(this.directory);
    file.delete();
    if (file.createNewFile())
      try {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        FileLruCache$openPutStream$renameToTargetCallback$1 fileLruCache$openPutStream$renameToTargetCallback$1 = new FileLruCache$openPutStream$renameToTargetCallback$1(System.currentTimeMillis(), file, paramString1);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new CloseCallbackOutputStream(fileOutputStream, fileLruCache$openPutStream$renameToTargetCallback$1), 8192);
        boolean bool4 = false;
        boolean bool3 = false;
        boolean bool1 = bool3;
        boolean bool2 = bool4;
        try {
          JSONObject jSONObject = new JSONObject();
          bool1 = bool3;
          bool2 = bool4;
          jSONObject.put("key", paramString1);
          bool1 = bool3;
          bool2 = bool4;
          if (!Utility.isNullOrEmpty(paramString2)) {
            bool1 = bool3;
            bool2 = bool4;
            jSONObject.put("tag", paramString2);
          } 
          bool1 = bool3;
          bool2 = bool4;
          StreamHeader.INSTANCE.writeHeader(bufferedOutputStream, jSONObject);
          bool2 = true;
          bool1 = true;
          return bufferedOutputStream;
        } catch (JSONException jSONException) {
          bool1 = bool2;
          Logger.Companion companion = Logger.Companion;
          bool1 = bool2;
          LoggingBehavior loggingBehavior1 = LoggingBehavior.CACHE;
          bool1 = bool2;
          String str = TAG;
          bool1 = bool2;
          StringBuilder stringBuilder1 = new StringBuilder("Error creating JSON header for cache file: ");
          bool1 = bool2;
          stringBuilder1.append(jSONException);
          bool1 = bool2;
          companion.log(loggingBehavior1, 5, str, stringBuilder1.toString());
          bool1 = bool2;
          throw (Throwable)new IOException(jSONException.getMessage());
        } finally {}
        if (!bool1)
          bufferedOutputStream.close(); 
        throw paramString1;
      } catch (FileNotFoundException fileNotFoundException) {
        Logger.Companion companion = Logger.Companion;
        loggingBehavior = LoggingBehavior.CACHE;
        String str = TAG;
        StringBuilder stringBuilder1 = new StringBuilder("Error creating buffer output stream: ");
        stringBuilder1.append(fileNotFoundException);
        companion.log(loggingBehavior, 5, str, stringBuilder1.toString());
        throw (Throwable)new IOException(fileNotFoundException.getMessage());
      }  
    StringBuilder stringBuilder = new StringBuilder("Could not create file at ");
    stringBuilder.append(loggingBehavior.getAbsolutePath());
    throw (Throwable)new IOException(stringBuilder.toString());
  }
  
  public final long sizeInBytesForTest() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    while (true) {
      File[] arrayOfFile;
      try {
        if (this.isTrimPending || this.isTrimInProgress) {
          try {
            this.condition.await();
          } catch (InterruptedException interruptedException) {}
          continue;
        } 
        Unit unit = Unit.INSTANCE;
        reentrantLock.unlock();
        arrayOfFile = this.directory.listFiles();
        long l1 = 0L;
        long l2 = l1;
        return l2;
      } finally {
        arrayOfFile.unlock();
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("{FileLruCache: tag:");
    stringBuilder.append(this.tag);
    stringBuilder.append(" file:");
    stringBuilder.append(this.directory.getName());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static {
    Intrinsics.checkNotNullExpressionValue("FileLruCache", "FileLruCache::class.java.simpleName");
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\016\020\b\032\0020\t2\006\020\n\032\0020\013J\006\020\f\032\0020\006J\006\020\r\032\0020\006J\020\020\016\032\0020\0132\b\020\n\032\004\030\0010\013R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000R\016\020\007\032\0020\006X\004¢\006\002\n\000¨\006\017"}, d2 = {"Lcom/facebook/internal/FileLruCache$BufferFile;", "", "()V", "FILE_NAME_PREFIX", "", "filterExcludeBufferFiles", "Ljava/io/FilenameFilter;", "filterExcludeNonBufferFiles", "deleteAll", "", "root", "Ljava/io/File;", "excludeBufferFiles", "excludeNonBufferFiles", "newFile", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class BufferFile {
    private static final String FILE_NAME_PREFIX = "buffer";
    
    public static final BufferFile INSTANCE = new BufferFile();
    
    private static final FilenameFilter filterExcludeBufferFiles = FileLruCache$BufferFile$filterExcludeBufferFiles$1.INSTANCE;
    
    private static final FilenameFilter filterExcludeNonBufferFiles = FileLruCache$BufferFile$filterExcludeNonBufferFiles$1.INSTANCE;
    
    public final void deleteAll(File param1File) {
      Intrinsics.checkNotNullParameter(param1File, "root");
      File[] arrayOfFile = param1File.listFiles(excludeNonBufferFiles());
      if (arrayOfFile != null) {
        int j = arrayOfFile.length;
        for (int i = 0; i < j; i++)
          arrayOfFile[i].delete(); 
      } 
    }
    
    public final FilenameFilter excludeBufferFiles() {
      return filterExcludeBufferFiles;
    }
    
    public final FilenameFilter excludeNonBufferFiles() {
      return filterExcludeNonBufferFiles;
    }
    
    public final File newFile(File param1File) {
      StringBuilder stringBuilder = new StringBuilder("buffer");
      stringBuilder.append(String.valueOf(FileLruCache.bufferIndex.incrementAndGet()));
      return new File(param1File, stringBuilder.toString());
    }
    
    @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "dir", "Ljava/io/File;", "kotlin.jvm.PlatformType", "filename", "", "accept"}, k = 3, mv = {1, 5, 1})
    static final class FileLruCache$BufferFile$filterExcludeBufferFiles$1 implements FilenameFilter {
      public static final FileLruCache$BufferFile$filterExcludeBufferFiles$1 INSTANCE = new FileLruCache$BufferFile$filterExcludeBufferFiles$1();
      
      public final boolean accept(File param2File, String param2String) {
        Intrinsics.checkNotNullExpressionValue(param2String, "filename");
        return StringsKt.startsWith$default(param2String, "buffer", false, 2, null) ^ true;
      }
    }
    
    @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "dir", "Ljava/io/File;", "kotlin.jvm.PlatformType", "filename", "", "accept"}, k = 3, mv = {1, 5, 1})
    static final class FileLruCache$BufferFile$filterExcludeNonBufferFiles$1 implements FilenameFilter {
      public static final FileLruCache$BufferFile$filterExcludeNonBufferFiles$1 INSTANCE = new FileLruCache$BufferFile$filterExcludeNonBufferFiles$1();
      
      public final boolean accept(File param2File, String param2String) {
        Intrinsics.checkNotNullExpressionValue(param2String, "filename");
        return StringsKt.startsWith$default(param2String, "buffer", false, 2, null);
      }
    }
  }
  
  @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "dir", "Ljava/io/File;", "kotlin.jvm.PlatformType", "filename", "", "accept"}, k = 3, mv = {1, 5, 1})
  static final class FileLruCache$BufferFile$filterExcludeBufferFiles$1 implements FilenameFilter {
    public static final FileLruCache$BufferFile$filterExcludeBufferFiles$1 INSTANCE = new FileLruCache$BufferFile$filterExcludeBufferFiles$1();
    
    public final boolean accept(File param1File, String param1String) {
      Intrinsics.checkNotNullExpressionValue(param1String, "filename");
      return StringsKt.startsWith$default(param1String, "buffer", false, 2, null) ^ true;
    }
  }
  
  @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "dir", "Ljava/io/File;", "kotlin.jvm.PlatformType", "filename", "", "accept"}, k = 3, mv = {1, 5, 1})
  static final class FileLruCache$BufferFile$filterExcludeNonBufferFiles$1 implements FilenameFilter {
    public static final FileLruCache$BufferFile$filterExcludeNonBufferFiles$1 INSTANCE = new FileLruCache$BufferFile$filterExcludeNonBufferFiles$1();
    
    public final boolean accept(File param1File, String param1String) {
      Intrinsics.checkNotNullExpressionValue(param1String, "filename");
      return StringsKt.startsWith$default(param1String, "buffer", false, 2, null);
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\020\002\n\002\b\003\n\002\020\022\n\000\n\002\020\b\n\002\b\003\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\001\022\006\020\003\032\0020\004¢\006\002\020\005J\b\020\n\032\0020\013H\026J\b\020\f\032\0020\013H\026J\020\020\r\032\0020\0132\006\020\016\032\0020\017H\026J \020\r\032\0020\0132\006\020\016\032\0020\0172\006\020\020\032\0020\0212\006\020\022\032\0020\021H\026J\020\020\r\032\0020\0132\006\020\023\032\0020\021H\026R\021\020\003\032\0020\004¢\006\b\n\000\032\004\b\006\020\007R\021\020\002\032\0020\001¢\006\b\n\000\032\004\b\b\020\t¨\006\024"}, d2 = {"Lcom/facebook/internal/FileLruCache$CloseCallbackOutputStream;", "Ljava/io/OutputStream;", "innerStream", "callback", "Lcom/facebook/internal/FileLruCache$StreamCloseCallback;", "(Ljava/io/OutputStream;Lcom/facebook/internal/FileLruCache$StreamCloseCallback;)V", "getCallback", "()Lcom/facebook/internal/FileLruCache$StreamCloseCallback;", "getInnerStream", "()Ljava/io/OutputStream;", "close", "", "flush", "write", "buffer", "", "offset", "", "count", "oneByte", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class CloseCallbackOutputStream extends OutputStream {
    private final FileLruCache.StreamCloseCallback callback;
    
    private final OutputStream innerStream;
    
    public CloseCallbackOutputStream(OutputStream param1OutputStream, FileLruCache.StreamCloseCallback param1StreamCloseCallback) {
      this.innerStream = param1OutputStream;
      this.callback = param1StreamCloseCallback;
    }
    
    public void close() throws IOException {
      try {
        this.innerStream.close();
        return;
      } finally {
        this.callback.onClose();
      } 
    }
    
    public void flush() throws IOException {
      this.innerStream.flush();
    }
    
    public final FileLruCache.StreamCloseCallback getCallback() {
      return this.callback;
    }
    
    public final OutputStream getInnerStream() {
      return this.innerStream;
    }
    
    public void write(int param1Int) throws IOException {
      this.innerStream.write(param1Int);
    }
    
    public void write(byte[] param1ArrayOfbyte) throws IOException {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "buffer");
      this.innerStream.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "buffer");
      this.innerStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\021\020\006\032\0020\004¢\006\b\n\000\032\004\b\007\020\bR\016\020\t\032\0020\nX\004¢\006\002\n\000¨\006\013"}, d2 = {"Lcom/facebook/internal/FileLruCache$Companion;", "", "()V", "HEADER_CACHEKEY_KEY", "", "HEADER_CACHE_CONTENT_TAG_KEY", "TAG", "getTAG", "()Ljava/lang/String;", "bufferIndex", "Ljava/util/concurrent/atomic/AtomicLong;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    public final String getTAG() {
      return FileLruCache.TAG;
    }
  }
  
  @Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\020\b\n\000\n\002\020\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\022\n\002\b\004\n\002\020\t\n\002\b\002\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\001\022\006\020\003\032\0020\004¢\006\002\020\005J\b\020\n\032\0020\013H\026J\b\020\f\032\0020\rH\026J\020\020\016\032\0020\r2\006\020\017\032\0020\013H\026J\b\020\020\032\0020\021H\026J\b\020\022\032\0020\013H\026J\020\020\022\032\0020\0132\006\020\023\032\0020\024H\026J \020\022\032\0020\0132\006\020\023\032\0020\0242\006\020\025\032\0020\0132\006\020\026\032\0020\013H\026J\b\020\027\032\0020\rH\026J\020\020\030\032\0020\0312\006\020\032\032\0020\031H\026R\021\020\002\032\0020\001¢\006\b\n\000\032\004\b\006\020\007R\021\020\003\032\0020\004¢\006\b\n\000\032\004\b\b\020\t¨\006\033"}, d2 = {"Lcom/facebook/internal/FileLruCache$CopyingInputStream;", "Ljava/io/InputStream;", "input", "output", "Ljava/io/OutputStream;", "(Ljava/io/InputStream;Ljava/io/OutputStream;)V", "getInput", "()Ljava/io/InputStream;", "getOutput", "()Ljava/io/OutputStream;", "available", "", "close", "", "mark", "readlimit", "markSupported", "", "read", "buffer", "", "offset", "length", "reset", "skip", "", "byteCount", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class CopyingInputStream extends InputStream {
    private final InputStream input;
    
    private final OutputStream output;
    
    public CopyingInputStream(InputStream param1InputStream, OutputStream param1OutputStream) {
      this.input = param1InputStream;
      this.output = param1OutputStream;
    }
    
    public int available() throws IOException {
      return this.input.available();
    }
    
    public void close() throws IOException {
      try {
        this.input.close();
        return;
      } finally {
        this.output.close();
      } 
    }
    
    public final InputStream getInput() {
      return this.input;
    }
    
    public final OutputStream getOutput() {
      return this.output;
    }
    
    public void mark(int param1Int) {
      throw (Throwable)new UnsupportedOperationException();
    }
    
    public boolean markSupported() {
      return false;
    }
    
    public int read() throws IOException {
      int i = this.input.read();
      if (i >= 0)
        this.output.write(i); 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte) throws IOException {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "buffer");
      int i = this.input.read(param1ArrayOfbyte);
      if (i > 0)
        this.output.write(param1ArrayOfbyte, 0, i); 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "buffer");
      param1Int2 = this.input.read(param1ArrayOfbyte, param1Int1, param1Int2);
      if (param1Int2 > 0)
        this.output.write(param1ArrayOfbyte, param1Int1, param1Int2); 
      return param1Int2;
    }
    
    public void reset() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: new java/lang/UnsupportedOperationException
      //   5: dup
      //   6: invokespecial <init> : ()V
      //   9: checkcast java/lang/Throwable
      //   12: athrow
      //   13: astore_1
      //   14: aload_0
      //   15: monitorexit
      //   16: aload_1
      //   17: athrow
      // Exception table:
      //   from	to	target	type
      //   2	13	13	finally
    }
    
    public long skip(long param1Long) throws IOException {
      byte[] arrayOfByte = new byte[1024];
      long l;
      for (l = 0L; l < param1Long; l += i) {
        int i = read(arrayOfByte, 0, (int)Math.min(param1Long - l, 1024L));
        if (i < 0)
          return l; 
      } 
      return l;
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\t\030\0002\0020\001B\005¢\006\002\020\002R$\020\005\032\0020\0042\006\020\003\032\0020\004@FX\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR$\020\n\032\0020\0042\006\020\003\032\0020\004@FX\016¢\006\016\n\000\032\004\b\013\020\007\"\004\b\f\020\t¨\006\r"}, d2 = {"Lcom/facebook/internal/FileLruCache$Limits;", "", "()V", "value", "", "byteCount", "getByteCount", "()I", "setByteCount", "(I)V", "fileCount", "getFileCount", "setFileCount", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Limits {
    private int byteCount = 1048576;
    
    private int fileCount = 1024;
    
    public final int getByteCount() {
      return this.byteCount;
    }
    
    public final int getFileCount() {
      return this.fileCount;
    }
    
    public final void setByteCount(int param1Int) {
      if (param1Int >= 0) {
        this.byteCount = param1Int;
        return;
      } 
      throw (Throwable)new InvalidParameterException("Cache byte-count limit must be >= 0");
    }
    
    public final void setFileCount(int param1Int) {
      if (param1Int >= 0) {
        this.fileCount = param1Int;
        return;
      } 
      throw (Throwable)new InvalidParameterException("Cache file count limit must be >= 0");
    }
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\017\n\000\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\003\n\002\020\b\n\002\b\002\n\002\020\013\n\002\020\000\n\002\b\003\b\002\030\000 \0222\b\022\004\022\0020\0000\001:\001\022B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\021\020\013\032\0020\f2\006\020\r\032\0020\000H\002J\023\020\016\032\0020\0172\b\020\r\032\004\030\0010\020H\002J\b\020\021\032\0020\fH\026R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006R\021\020\007\032\0020\b¢\006\b\n\000\032\004\b\t\020\n¨\006\023"}, d2 = {"Lcom/facebook/internal/FileLruCache$ModifiedFile;", "", "file", "Ljava/io/File;", "(Ljava/io/File;)V", "getFile", "()Ljava/io/File;", "modified", "", "getModified", "()J", "compareTo", "", "another", "equals", "", "", "hashCode", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class ModifiedFile implements Comparable<ModifiedFile> {
    public static final Companion Companion = new Companion(null);
    
    private static final int HASH_MULTIPLIER = 37;
    
    private static final int HASH_SEED = 29;
    
    private final File file;
    
    private final long modified;
    
    public ModifiedFile(File param1File) {
      this.file = param1File;
      this.modified = param1File.lastModified();
    }
    
    public int compareTo(ModifiedFile param1ModifiedFile) {
      Intrinsics.checkNotNullParameter(param1ModifiedFile, "another");
      long l1 = this.modified;
      long l2 = param1ModifiedFile.modified;
      return (l1 < l2) ? -1 : ((l1 > l2) ? 1 : this.file.compareTo(param1ModifiedFile.file));
    }
    
    public boolean equals(Object param1Object) {
      return (param1Object instanceof ModifiedFile && compareTo((ModifiedFile)param1Object) == 0);
    }
    
    public final File getFile() {
      return this.file;
    }
    
    public final long getModified() {
      return this.modified;
    }
    
    public int hashCode() {
      return (1073 + this.file.hashCode()) * 37 + (int)(this.modified % 2147483647L);
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/FileLruCache$ModifiedFile$Companion;", "", "()V", "HASH_MULTIPLIER", "", "HASH_SEED", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/FileLruCache$ModifiedFile$Companion;", "", "()V", "HASH_MULTIPLIER", "", "HASH_SEED", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\bâ\001\030\0002\0020\001J\b\020\002\032\0020\003H&¨\006\004"}, d2 = {"Lcom/facebook/internal/FileLruCache$StreamCloseCallback;", "", "onClose", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static interface StreamCloseCallback {
    void onClose();
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\030\002\n\002\b\002\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\005\032\004\030\0010\0062\006\020\007\032\0020\bJ\026\020\t\032\0020\n2\006\020\007\032\0020\0132\006\020\f\032\0020\006R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\r"}, d2 = {"Lcom/facebook/internal/FileLruCache$StreamHeader;", "", "()V", "HEADER_VERSION", "", "readHeader", "Lorg/json/JSONObject;", "stream", "Ljava/io/InputStream;", "writeHeader", "", "Ljava/io/OutputStream;", "header", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class StreamHeader {
    private static final int HEADER_VERSION = 0;
    
    public static final StreamHeader INSTANCE = new StreamHeader();
    
    public final JSONObject readHeader(InputStream param1InputStream) throws IOException {
      LoggingBehavior loggingBehavior;
      Intrinsics.checkNotNullParameter(param1InputStream, "stream");
      if (param1InputStream.read() != 0)
        return null; 
      int k = 0;
      int j = 0;
      int i = 0;
      while (j < 3) {
        int m = param1InputStream.read();
        if (m == -1) {
          Logger.Companion.log(LoggingBehavior.CACHE, FileLruCache.Companion.getTAG(), "readHeader: stream.read returned -1 while reading header size");
          return null;
        } 
        i = (i << 8) + (m & 0xFF);
        j++;
      } 
      byte[] arrayOfByte = new byte[i];
      for (j = k; j < i; j += k) {
        k = param1InputStream.read(arrayOfByte, j, i - j);
        if (k < 1) {
          Logger.Companion companion = Logger.Companion;
          loggingBehavior = LoggingBehavior.CACHE;
          String str = FileLruCache.Companion.getTAG();
          StringBuilder stringBuilder = new StringBuilder("readHeader: stream.read stopped at ");
          stringBuilder.append(Integer.valueOf(j));
          stringBuilder.append(" when expected ");
          stringBuilder.append(i);
          companion.log(loggingBehavior, str, stringBuilder.toString());
          return null;
        } 
      } 
      JSONTokener jSONTokener = new JSONTokener(new String((byte[])loggingBehavior, Charsets.UTF_8));
      try {
        null = jSONTokener.nextValue();
        if (!(null instanceof JSONObject)) {
          Logger.Companion companion = Logger.Companion;
          LoggingBehavior loggingBehavior1 = LoggingBehavior.CACHE;
          String str = FileLruCache.Companion.getTAG();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("readHeader: expected JSONObject, got ");
          stringBuilder.append(null.getClass().getCanonicalName());
          companion.log(loggingBehavior1, str, stringBuilder.toString());
          return null;
        } 
        return (JSONObject)null;
      } catch (JSONException jSONException) {
        throw (Throwable)new IOException(jSONException.getMessage());
      } 
    }
    
    public final void writeHeader(OutputStream param1OutputStream, JSONObject param1JSONObject) throws IOException {
      Intrinsics.checkNotNullParameter(param1OutputStream, "stream");
      Intrinsics.checkNotNullParameter(param1JSONObject, "header");
      String str = param1JSONObject.toString();
      Intrinsics.checkNotNullExpressionValue(str, "header.toString()");
      Charset charset = Charsets.UTF_8;
      if (str != null) {
        byte[] arrayOfByte = str.getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(arrayOfByte, "(this as java.lang.String).getBytes(charset)");
        param1OutputStream.write(0);
        param1OutputStream.write(arrayOfByte.length >> 16 & 0xFF);
        param1OutputStream.write(arrayOfByte.length >> 8 & 0xFF);
        param1OutputStream.write(arrayOfByte.length >> 0 & 0xFF);
        param1OutputStream.write(arrayOfByte);
        return;
      } 
      throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class FileLruCache$clearCache$1 implements Runnable {
    FileLruCache$clearCache$1(File[] param1ArrayOfFile) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\000\n\002\020\002\n\000*\001\000\b\n\030\0002\0020\001J\b\020\002\032\0020\003H\026¨\006\004"}, d2 = {"com/facebook/internal/FileLruCache$openPutStream$renameToTargetCallback$1", "Lcom/facebook/internal/FileLruCache$StreamCloseCallback;", "onClose", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class FileLruCache$openPutStream$renameToTargetCallback$1 implements StreamCloseCallback {
    FileLruCache$openPutStream$renameToTargetCallback$1(long param1Long, File param1File, String param1String) {}
    
    public void onClose() {
      if (this.$bufferFileCreateTime < FileLruCache.this.lastClearCacheTime.get()) {
        this.$buffer.delete();
        return;
      } 
      FileLruCache.this.renameToTargetAndTrim(this.$key, this.$buffer);
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\002\020\000\032\0020\001H\n¢\006\002\b\002¨\006\003"}, d2 = {"<anonymous>", "", "run", "com/facebook/internal/FileLruCache$postTrim$1$1"}, k = 3, mv = {1, 5, 1})
  static final class FileLruCache$postTrim$$inlined$withLock$lambda$1 implements Runnable {
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\FileLruCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */