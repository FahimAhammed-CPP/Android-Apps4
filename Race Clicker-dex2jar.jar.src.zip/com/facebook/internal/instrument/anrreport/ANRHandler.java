package com.facebook.internal.instrument.anrreport;

import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.internal.Utility;
import com.facebook.internal.instrument.InstrumentData;
import com.facebook.internal.instrument.InstrumentUtility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\007\032\0020\bH\007J\b\020\t\032\0020\bH\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000¨\006\n"}, d2 = {"Lcom/facebook/internal/instrument/anrreport/ANRHandler;", "", "()V", "MAX_ANR_REPORT_NUM", "", "enabled", "Ljava/util/concurrent/atomic/AtomicBoolean;", "enable", "", "sendANRReports", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class ANRHandler {
  public static final ANRHandler INSTANCE = new ANRHandler();
  
  private static final int MAX_ANR_REPORT_NUM = 5;
  
  private static final AtomicBoolean enabled = new AtomicBoolean(false);
  
  @JvmStatic
  public static final void enable() {
    // Byte code:
    //   0: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   2: monitorenter
    //   3: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_0
    //   9: iload_0
    //   10: ifeq -> 17
    //   13: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   15: monitorexit
    //   16: return
    //   17: getstatic com/facebook/internal/instrument/anrreport/ANRHandler.enabled : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   20: iconst_1
    //   21: invokevirtual getAndSet : (Z)Z
    //   24: istore_0
    //   25: iload_0
    //   26: ifeq -> 33
    //   29: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   31: monitorexit
    //   32: return
    //   33: invokestatic getAutoLogAppEventsEnabled : ()Z
    //   36: ifeq -> 42
    //   39: invokestatic sendANRReports : ()V
    //   42: invokestatic start : ()V
    //   45: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   47: monitorexit
    //   48: return
    //   49: astore_1
    //   50: aload_1
    //   51: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   53: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   56: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   58: monitorexit
    //   59: return
    //   60: astore_1
    //   61: ldc com/facebook/internal/instrument/anrreport/ANRHandler
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	60	finally
    //   17	25	49	finally
    //   33	42	49	finally
    //   42	45	49	finally
    //   50	56	60	finally
  }
  
  @JvmStatic
  public static final void sendANRReports() {
    if (CrashShieldHandler.isObjectCrashing(ANRHandler.class))
      return; 
    try {
      if (Utility.isDataProcessingRestricted())
        return; 
      File[] arrayOfFile = InstrumentUtility.listAnrReportFiles();
      ArrayList<InstrumentData> arrayList2 = new ArrayList(arrayOfFile.length);
      int j = arrayOfFile.length;
      for (int i = 0; i < j; i++)
        arrayList2.add(InstrumentData.Builder.load(arrayOfFile[i])); 
      arrayList2 = arrayList2;
      ArrayList<InstrumentData> arrayList1 = new ArrayList();
      for (InstrumentData instrumentData : arrayList2) {
        if (((InstrumentData)instrumentData).isValid())
          arrayList1.add(instrumentData); 
      } 
      List list = CollectionsKt.sortedWith(arrayList1, ANRHandler$sendANRReports$validReports$3.INSTANCE);
      JSONArray jSONArray = new JSONArray();
      Iterator iterator = ((Iterable)RangesKt.until(0, Math.min(list.size(), 5))).iterator();
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, ANRHandler.class);
    } 
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "response", "Lcom/facebook/GraphResponse;", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class ANRHandler$sendANRReports$2 implements GraphRequest.Callback {
    ANRHandler$sendANRReports$2(List param1List) {}
    
    public final void onCompleted(GraphResponse param1GraphResponse) {
      Intrinsics.checkNotNullParameter(param1GraphResponse, "response");
      try {
        if (param1GraphResponse.getError() == null) {
          JSONObject jSONObject = param1GraphResponse.getJsonObject();
          if (jSONObject != null && jSONObject.getBoolean("success") == true) {
            Iterator<InstrumentData> iterator = this.$validReports.iterator();
            while (iterator.hasNext())
              ((InstrumentData)iterator.next()).clear(); 
          } 
        } 
        return;
      } catch (JSONException jSONException) {
        return;
      } 
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\003\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "o1", "Lcom/facebook/internal/instrument/InstrumentData;", "kotlin.jvm.PlatformType", "o2", "compare"}, k = 3, mv = {1, 5, 1})
  static final class ANRHandler$sendANRReports$validReports$3<T> implements Comparator {
    public static final ANRHandler$sendANRReports$validReports$3 INSTANCE = new ANRHandler$sendANRReports$validReports$3();
    
    public final int compare(InstrumentData param1InstrumentData1, InstrumentData param1InstrumentData2) {
      Intrinsics.checkNotNullExpressionValue(param1InstrumentData2, "o2");
      return param1InstrumentData1.compareTo(param1InstrumentData2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\instrument\anrreport\ANRHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */