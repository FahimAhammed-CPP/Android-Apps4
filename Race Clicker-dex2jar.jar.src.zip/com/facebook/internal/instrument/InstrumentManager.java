package com.facebook.internal.instrument;

import com.facebook.FacebookSdk;
import com.facebook.internal.FeatureManager;
import com.facebook.internal.instrument.anrreport.ANRHandler;
import com.facebook.internal.instrument.crashreport.CrashHandler;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.internal.instrument.errorreport.ErrorReportHandler;
import com.facebook.internal.instrument.threadcheck.ThreadCheckHandler;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\003\032\0020\004H\007¨\006\005"}, d2 = {"Lcom/facebook/internal/instrument/InstrumentManager;", "", "()V", "start", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class InstrumentManager {
  public static final InstrumentManager INSTANCE = new InstrumentManager();
  
  @JvmStatic
  public static final void start() {
    if (!FacebookSdk.getAutoLogAppEventsEnabled())
      return; 
    FeatureManager.checkFeature(FeatureManager.Feature.CrashReport, InstrumentManager$start$1.INSTANCE);
    FeatureManager.checkFeature(FeatureManager.Feature.ErrorReport, InstrumentManager$start$2.INSTANCE);
    FeatureManager.checkFeature(FeatureManager.Feature.AnrReport, InstrumentManager$start$3.INSTANCE);
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\013\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "enabled", "", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class InstrumentManager$start$1 implements FeatureManager.Callback {
    public static final InstrumentManager$start$1 INSTANCE = new InstrumentManager$start$1();
    
    public final void onCompleted(boolean param1Boolean) {
      if (param1Boolean) {
        CrashHandler.Companion.enable();
        if (FeatureManager.isEnabled(FeatureManager.Feature.CrashShield)) {
          ExceptionAnalyzer.enable();
          CrashShieldHandler.enable();
        } 
        if (FeatureManager.isEnabled(FeatureManager.Feature.ThreadCheck))
          ThreadCheckHandler.enable(); 
      } 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\013\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "enabled", "", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class InstrumentManager$start$2 implements FeatureManager.Callback {
    public static final InstrumentManager$start$2 INSTANCE = new InstrumentManager$start$2();
    
    public final void onCompleted(boolean param1Boolean) {
      if (param1Boolean)
        ErrorReportHandler.enable(); 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\013\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "enabled", "", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class InstrumentManager$start$3 implements FeatureManager.Callback {
    public static final InstrumentManager$start$3 INSTANCE = new InstrumentManager$start$3();
    
    public final void onCompleted(boolean param1Boolean) {
      if (param1Boolean)
        ANRHandler.enable(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\instrument\InstrumentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */