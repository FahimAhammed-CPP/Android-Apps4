package com.facebook.internal.instrument.errorreport;

import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.internal.Utility;
import com.facebook.internal.instrument.InstrumentUtility;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.Regex;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\020\002\n\000\n\002\020\021\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\005\032\0020\006H\007J\023\020\007\032\b\022\004\022\0020\t0\bH\007¢\006\002\020\nJ\022\020\013\032\0020\0062\b\020\f\032\004\030\0010\rH\007J\b\020\016\032\0020\006H\007R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\017"}, d2 = {"Lcom/facebook/internal/instrument/errorreport/ErrorReportHandler;", "", "()V", "MAX_ERROR_REPORT_NUM", "", "enable", "", "listErrorReportFiles", "", "Ljava/io/File;", "()[Ljava/io/File;", "save", "msg", "", "sendErrorReports", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class ErrorReportHandler {
  public static final ErrorReportHandler INSTANCE = new ErrorReportHandler();
  
  private static final int MAX_ERROR_REPORT_NUM = 1000;
  
  @JvmStatic
  public static final void enable() {
    if (FacebookSdk.getAutoLogAppEventsEnabled())
      sendErrorReports(); 
  }
  
  @JvmStatic
  public static final File[] listErrorReportFiles() {
    File file = InstrumentUtility.getInstrumentReportDir();
    if (file != null) {
      File[] arrayOfFile = file.listFiles(ErrorReportHandler$listErrorReportFiles$1.INSTANCE);
      Intrinsics.checkNotNullExpressionValue(arrayOfFile, "reportDir.listFiles { di…OR_REPORT_PREFIX)))\n    }");
      return arrayOfFile;
    } 
    return new File[0];
  }
  
  @JvmStatic
  public static final void save(String paramString) {
    try {
      (new ErrorReportData(paramString)).save();
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  @JvmStatic
  public static final void sendErrorReports() {
    if (Utility.isDataProcessingRestricted())
      return; 
    File[] arrayOfFile = listErrorReportFiles();
    ArrayList<ErrorReportData> arrayList = new ArrayList();
    int j = arrayOfFile.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      ErrorReportData errorReportData = new ErrorReportData(arrayOfFile[i]);
      if (errorReportData.isValid())
        arrayList.add(errorReportData); 
    } 
    CollectionsKt.sortWith(arrayList, ErrorReportHandler$sendErrorReports$1.INSTANCE);
    JSONArray jSONArray = new JSONArray();
    for (i = bool; i < arrayList.size() && i < 1000; i++)
      jSONArray.put(arrayList.get(i)); 
    InstrumentUtility.sendReports("error_reports", jSONArray, new ErrorReportHandler$sendErrorReports$2(arrayList));
  }
  
  @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "dir", "Ljava/io/File;", "kotlin.jvm.PlatformType", "name", "", "accept"}, k = 3, mv = {1, 5, 1})
  static final class ErrorReportHandler$listErrorReportFiles$1 implements FilenameFilter {
    public static final ErrorReportHandler$listErrorReportFiles$1 INSTANCE = new ErrorReportHandler$listErrorReportFiles$1();
    
    public final boolean accept(File param1File, String param1String) {
      Intrinsics.checkNotNullExpressionValue(param1String, "name");
      CharSequence charSequence = param1String;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str = String.format("^%s[0-9]+.json$", Arrays.copyOf(new Object[] { "error_log_" }, 1));
      Intrinsics.checkNotNullExpressionValue(str, "java.lang.String.format(format, *args)");
      return (new Regex(str)).matches(charSequence);
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\003\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "o1", "Lcom/facebook/internal/instrument/errorreport/ErrorReportData;", "kotlin.jvm.PlatformType", "o2", "compare"}, k = 3, mv = {1, 5, 1})
  static final class ErrorReportHandler$sendErrorReports$1<T> implements Comparator {
    public static final ErrorReportHandler$sendErrorReports$1 INSTANCE = new ErrorReportHandler$sendErrorReports$1();
    
    public final int compare(ErrorReportData param1ErrorReportData1, ErrorReportData param1ErrorReportData2) {
      Intrinsics.checkNotNullExpressionValue(param1ErrorReportData2, "o2");
      return param1ErrorReportData1.compareTo(param1ErrorReportData2);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "response", "Lcom/facebook/GraphResponse;", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class ErrorReportHandler$sendErrorReports$2 implements GraphRequest.Callback {
    ErrorReportHandler$sendErrorReports$2(ArrayList param1ArrayList) {}
    
    public final void onCompleted(GraphResponse param1GraphResponse) {
      Intrinsics.checkNotNullParameter(param1GraphResponse, "response");
      try {
        if (param1GraphResponse.getError() == null) {
          JSONObject jSONObject = param1GraphResponse.getJsonObject();
          if (jSONObject != null && jSONObject.getBoolean("success") == true) {
            Iterator<ErrorReportData> iterator = this.$validReports.iterator();
            while (iterator.hasNext())
              ((ErrorReportData)iterator.next()).clear(); 
          } 
        } 
        return;
      } catch (JSONException jSONException) {
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\instrument\errorreport\ErrorReportHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */