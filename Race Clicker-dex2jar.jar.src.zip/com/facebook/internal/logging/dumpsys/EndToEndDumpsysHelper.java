package com.facebook.internal.logging.dumpsys;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.webkit.WebView;
import android.widget.TextView;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000N\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\021\n\002\b\006\b\007\030\000 \0352\0020\001:\003\033\034\035B\005¢\006\002\020\002JB\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\0202\006\020\021\032\0020\0222\006\020\023\032\0020\0222\006\020\024\032\0020\0252\006\020\026\032\0020\025H\002J+\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\r\032\0020\0162\f\020\027\032\b\022\004\022\0020\f0\030H\002¢\006\002\020\031J(\020\032\032\0020\n2\006\020\r\032\0020\0162\006\020\017\032\0020\0202\006\020\013\032\0020\f2\006\020\026\032\0020\025H\002R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000¨\006\036"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper;", "", "()V", "lithoViewToStringMethod", "Ljava/lang/reflect/Method;", "rootResolver", "Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver;", "webViewDumpHelper", "Lcom/facebook/internal/logging/dumpsys/WebViewDumpHelper;", "dumpViewHierarchy", "", "prefix", "", "writer", "Ljava/io/PrintWriter;", "view", "Landroid/view/View;", "leftOffset", "", "topOffset", "withWebView", "", "withProps", "args", "", "(Ljava/lang/String;Ljava/io/PrintWriter;[Ljava/lang/String;)V", "writeLithoViewSubHierarchy", "Api21Utils", "Api24Utils", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class EndToEndDumpsysHelper {
  private static final String ALL_ROOTS_ARGUMENT = "all-roots";
  
  public static final Companion Companion = new Companion(null);
  
  private static final String E2E_ARGUMENT = "e2e";
  
  private static final String LITHO_VIEW_CLASS = "com.facebook.litho.LithoView";
  
  private static final String LITHO_VIEW_TEST_HELPER_CLASS = "com.facebook.litho.LithoViewTestHelper";
  
  private static final String LITHO_VIEW_TO_STRING_METHOD = "viewToStringForE2E";
  
  private static final String RC_TEXT_VIEW_SIMPLE_CLASS_NAME = "RCTextView";
  
  private static final String TOP_ROOT_ARGUMENT = "top-root";
  
  private static final String WITH_PROPS_ARGUMENT = "props";
  
  private static final String WITH_WEBVIEW_ARGUMENT = "webview";
  
  private static EndToEndDumpsysHelper instance;
  
  private static Method rcTextViewGetTextMethod;
  
  private Method lithoViewToStringMethod;
  
  private final AndroidRootResolver rootResolver = new AndroidRootResolver();
  
  private final WebViewDumpHelper webViewDumpHelper = new WebViewDumpHelper();
  
  private final void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, View paramView, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
      return;
    } 
    paramPrintWriter.print(paramView.getClass().getName());
    paramPrintWriter.print("{");
    paramPrintWriter.print(Integer.toHexString(paramView.hashCode()));
    Companion companion = Companion;
    companion.writeViewFlags(paramPrintWriter, paramView);
    companion.writeViewBounds(paramPrintWriter, paramView, paramInt1, paramInt2);
    companion.writeViewTestId(paramPrintWriter, paramView);
    companion.writeViewText(paramPrintWriter, paramView);
    if (paramBoolean2)
      Api21Utils.INSTANCE.writeExtraProps(paramPrintWriter, paramView); 
    paramPrintWriter.println("}");
    if (companion.isExtendsLithoView(paramView))
      writeLithoViewSubHierarchy(paramPrintWriter, paramView, paramString, paramBoolean2); 
    if (paramBoolean1 && paramView instanceof WebView)
      this.webViewDumpHelper.handle((WebView)paramView); 
    if (!(paramView instanceof ViewGroup))
      return; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    paramInt2 = viewGroup.getChildCount();
    if (paramInt2 <= 0)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    paramString = stringBuilder.toString();
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
      dumpViewHierarchy(paramString, paramPrintWriter, viewGroup.getChildAt(paramInt1), arrayOfInt[0], arrayOfInt[1], paramBoolean1, paramBoolean2); 
  }
  
  private final void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("Top Level Window View Hierarchy:");
    Companion companion = Companion;
    boolean bool1 = companion.hasArgument(paramArrayOfString, "all-roots");
    boolean bool2 = companion.hasArgument(paramArrayOfString, "top-root");
    boolean bool3 = companion.hasArgument(paramArrayOfString, "webview");
    boolean bool4 = companion.hasArgument(paramArrayOfString, "props");
    try {
      List<AndroidRootResolver.Root> list = this.rootResolver.listActiveRoots();
      if (list != null) {
        if (list.isEmpty())
          return; 
        Collections.reverse(list);
        paramArrayOfString = null;
        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams)null;
        for (AndroidRootResolver.Root root : list) {
          if (root != null) {
            View view = root.getView();
            if (view == null || view.getVisibility() != 0)
              continue; 
            if (!bool1 && paramArrayOfString != null && Math.abs((root.getParam()).type - ((WindowManager.LayoutParams)paramArrayOfString).type) != 1)
              break; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(paramString);
            stringBuilder.append("  ");
            dumpViewHierarchy(stringBuilder.toString(), paramPrintWriter, root.getView(), 0, 0, bool3, bool4);
            WindowManager.LayoutParams layoutParams1 = root.getParam();
            if (bool2)
              break; 
          } 
        } 
        this.webViewDumpHelper.dump(paramPrintWriter);
        return;
      } 
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder("Failure in view hierarchy dump: ");
      stringBuilder.append(exception.getMessage());
      paramPrintWriter.println(stringBuilder.toString());
      return;
    } 
  }
  
  @JvmStatic
  public static final boolean maybeDump(String paramString, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    return Companion.maybeDump(paramString, paramPrintWriter, paramArrayOfString);
  }
  
  private final void writeLithoViewSubHierarchy(PrintWriter paramPrintWriter, View paramView, String paramString, boolean paramBoolean) {
    try {
      if (this.lithoViewToStringMethod == null) {
        Class<?> clazz = Class.forName("com.facebook.litho.LithoViewTestHelper");
        Intrinsics.checkNotNullExpressionValue(clazz, "Class.forName(LITHO_VIEW_TEST_HELPER_CLASS)");
        this.lithoViewToStringMethod = clazz.getDeclaredMethod("viewToStringForE2E", new Class[] { View.class, int.class, boolean.class });
      } 
      Method method = this.lithoViewToStringMethod;
      Object object = null;
      if (method != null)
        object = method.invoke(null, new Object[] { paramView, Integer.valueOf(paramString.length() / 2 + 1), Boolean.valueOf(paramBoolean) }); 
      if (object != null) {
        Intrinsics.checkNotNullExpressionValue(paramPrintWriter.append((String)object), "writer.append(lithoViewDump)");
        return;
      } 
      throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
    } catch (Exception exception) {
      paramPrintWriter.append(paramString).append("Failed litho view sub hierarch dump: ").append(Companion.fixString(exception.getMessage(), 100)).println();
      return;
    } 
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\022\020\005\032\004\030\0010\0062\006\020\007\032\0020\bH\002J\026\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\007\032\0020\bR\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000¨\006\r"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Api21Utils;", "", "()V", "keyedTagsField", "Ljava/lang/reflect/Field;", "getTags", "Lorg/json/JSONObject;", "view", "Landroid/view/View;", "writeExtraProps", "", "writer", "Ljava/io/PrintWriter;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class Api21Utils {
    public static final Api21Utils INSTANCE = new Api21Utils();
    
    private static Field keyedTagsField;
    
    static {
      try {
        Field field = View.class.getDeclaredField("mKeyedTags");
        keyedTagsField = field;
        if (field != null)
          field.setAccessible(true); 
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        return;
      } 
    }
    
    private final JSONObject getTags(View param1View) {
      JSONObject jSONObject = (JSONObject)null;
      try {
        if (keyedTagsField == null) {
          Field field1 = View.class.getDeclaredField("mKeyedTags");
          keyedTagsField = field1;
          if (field1 != null)
            field1.setAccessible(true); 
        } 
        Field field = keyedTagsField;
        if (field != null) {
          Object object = field.get(param1View);
        } else {
          field = null;
        } 
        if (field != null) {
          SparseArray sparseArray = (SparseArray)field;
          if (sparseArray != null && sparseArray.size() > 0) {
            JSONObject jSONObject1 = new JSONObject();
            try {
              int j = sparseArray.size();
              int i = 0;
              while (true) {
                if (i < j) {
                  String str = ResourcesUtil.getIdStringQuietly(param1View.getResources(), sparseArray.keyAt(i));
                  try {
                    jSONObject1.put(str, sparseArray.valueAt(i));
                  } catch (JSONException jSONException) {}
                  i++;
                  continue;
                } 
                return jSONObject1;
              } 
            } catch (Exception exception) {}
            return jSONObject1;
          } 
        } else {
          throw new NullPointerException("null cannot be cast to non-null type android.util.SparseArray<*>");
        } 
        return null;
      } catch (Exception exception) {
        return null;
      } 
    }
    
    public final void writeExtraProps(PrintWriter param1PrintWriter, View param1View) {
      Intrinsics.checkNotNullParameter(param1PrintWriter, "writer");
      Intrinsics.checkNotNullParameter(param1View, "view");
      AccessibilityNodeInfo accessibilityNodeInfo = EndToEndDumpsysHelper.Companion.createNodeInfoFromView(param1View);
      if (accessibilityNodeInfo != null) {
        JSONObject jSONObject = new JSONObject();
        try {
          if (param1View instanceof TextView) {
            ColorStateList colorStateList = ((TextView)param1View).getTextColors();
            Intrinsics.checkNotNullExpressionValue(colorStateList, "view.textColors");
            jSONObject.put("textColor", colorStateList.getDefaultColor());
            jSONObject.put("textSize", ((TextView)param1View).getTextSize());
            jSONObject.put("hint", EndToEndDumpsysHelper.Companion.fixString(((TextView)param1View).getHint(), 100));
          } 
          JSONObject jSONObject1 = getTags(param1View);
          if (jSONObject1 != null)
            jSONObject.put("keyedTags", jSONObject1); 
          JSONArray jSONArray = new JSONArray();
          for (AccessibilityNodeInfo.AccessibilityAction accessibilityAction : accessibilityNodeInfo.getActionList()) {
            Intrinsics.checkNotNullExpressionValue(accessibilityAction, "action");
            CharSequence charSequence = accessibilityAction.getLabel();
            if (charSequence != null) {
              charSequence = charSequence;
              if (charSequence != null)
                jSONArray.put(EndToEndDumpsysHelper.Companion.fixString(charSequence, 50)); 
              continue;
            } 
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
          } 
          if (jSONArray.length() > 0)
            jSONObject.put("actions", jSONArray); 
          String str = EndToEndDumpsysHelper.Companion.fixString(accessibilityNodeInfo.getContentDescription(), 50);
          if (str != null) {
            boolean bool;
            if (str.length() > 0) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool)
              jSONObject.put("content-description", str); 
          } 
          jSONObject.put("accessibility-focused", accessibilityNodeInfo.isAccessibilityFocused()).put("checkable", accessibilityNodeInfo.isCheckable()).put("checked", accessibilityNodeInfo.isChecked()).put("class-name", EndToEndDumpsysHelper.Companion.fixString(accessibilityNodeInfo.getClassName(), 50)).put("clickable", accessibilityNodeInfo.isClickable()).put("content-invalid", accessibilityNodeInfo.isContentInvalid()).put("dismissable", accessibilityNodeInfo.isDismissable()).put("editable", accessibilityNodeInfo.isEditable()).put("enabled", accessibilityNodeInfo.isEnabled()).put("focusable", accessibilityNodeInfo.isFocusable()).put("focused", accessibilityNodeInfo.isFocused()).put("long-clickable", accessibilityNodeInfo.isLongClickable()).put("multiline", accessibilityNodeInfo.isMultiLine()).put("password", accessibilityNodeInfo.isPassword()).put("scrollable", accessibilityNodeInfo.isScrollable()).put("selected", accessibilityNodeInfo.isSelected()).put("visible-to-user", accessibilityNodeInfo.isVisibleToUser());
          if (Build.VERSION.SDK_INT >= 24)
            EndToEndDumpsysHelper.Api24Utils.INSTANCE.addExtraProps(jSONObject, accessibilityNodeInfo); 
        } catch (Exception exception) {
          try {
            jSONObject.put("DUMP-ERROR", EndToEndDumpsysHelper.Companion.fixString(exception.getMessage(), 50));
          } catch (JSONException jSONException) {}
        } 
        param1PrintWriter.append(" props=\"").append(jSONObject.toString()).append("\"");
      } 
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Api24Utils;", "", "()V", "addExtraProps", "", "props", "Lorg/json/JSONObject;", "nodeInfo", "Landroid/view/accessibility/AccessibilityNodeInfo;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class Api24Utils {
    public static final Api24Utils INSTANCE = new Api24Utils();
    
    public final void addExtraProps(JSONObject param1JSONObject, AccessibilityNodeInfo param1AccessibilityNodeInfo) throws JSONException {
      Intrinsics.checkNotNullParameter(param1JSONObject, "props");
      Intrinsics.checkNotNullParameter(param1AccessibilityNodeInfo, "nodeInfo");
      if (Build.VERSION.SDK_INT < 24)
        return; 
      param1JSONObject.put("context-clickable", param1AccessibilityNodeInfo.isContextClickable()).put("drawing-order", param1AccessibilityNodeInfo.getDrawingOrder()).put("important-for-accessibility", param1AccessibilityNodeInfo.isImportantForAccessibility());
    }
  }
  
  @Metadata(d1 = {"\000Z\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\t\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\r\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\000\n\002\020\021\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\007\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\024\020\021\032\004\030\0010\0222\b\020\023\032\004\030\0010\024H\002J\032\020\025\032\0020\0042\b\020\026\032\004\030\0010\0272\006\020\030\032\0020\031H\002J\022\020\032\032\004\030\0010\0042\006\020\023\032\0020\024H\003J%\020\033\032\0020\0342\016\020\035\032\n\022\004\022\0020\004\030\0010\0362\006\020\037\032\0020\004H\002¢\006\002\020 J\020\020!\032\0020\0342\006\020\023\032\0020\024H\002J-\020\"\032\0020\0342\006\020#\032\0020\0042\006\020$\032\0020%2\016\020\035\032\n\022\004\022\0020\004\030\0010\036H\007¢\006\002\020&J\030\020'\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J(\020)\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\0242\006\020*\032\0020\0312\006\020+\032\0020\031H\002J\030\020,\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J\030\020-\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J\030\020.\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\003R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\016\020\n\032\0020\004XT¢\006\002\n\000R\016\020\013\032\0020\004XT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\020\020\r\032\004\030\0010\016X\016¢\006\002\n\000R\020\020\017\032\004\030\0010\020X\016¢\006\002\n\000¨\006/"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Companion;", "", "()V", "ALL_ROOTS_ARGUMENT", "", "E2E_ARGUMENT", "LITHO_VIEW_CLASS", "LITHO_VIEW_TEST_HELPER_CLASS", "LITHO_VIEW_TO_STRING_METHOD", "RC_TEXT_VIEW_SIMPLE_CLASS_NAME", "TOP_ROOT_ARGUMENT", "WITH_PROPS_ARGUMENT", "WITH_WEBVIEW_ARGUMENT", "instance", "Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper;", "rcTextViewGetTextMethod", "Ljava/lang/reflect/Method;", "createNodeInfoFromView", "Landroid/view/accessibility/AccessibilityNodeInfo;", "view", "Landroid/view/View;", "fixString", "str", "", "maxLength", "", "getTextFromRcTextView", "hasArgument", "", "args", "", "argument", "([Ljava/lang/String;Ljava/lang/String;)Z", "isExtendsLithoView", "maybeDump", "prefix", "writer", "Ljava/io/PrintWriter;", "(Ljava/lang/String;Ljava/io/PrintWriter;[Ljava/lang/String;)Z", "maybeWriteViewTestIdFromTag", "", "writeViewBounds", "leftOffset", "topOffset", "writeViewFlags", "writeViewTestId", "writeViewText", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    private final AccessibilityNodeInfo createNodeInfoFromView(View param1View) {
      if (param1View == null)
        return null; 
      AccessibilityNodeInfo accessibilityNodeInfo = AccessibilityNodeInfo.obtain();
      try {
        param1View.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        return accessibilityNodeInfo;
      } catch (NullPointerException nullPointerException) {
        if (accessibilityNodeInfo != null)
          accessibilityNodeInfo.recycle(); 
        return null;
      } 
    }
    
    private final String fixString(CharSequence param1CharSequence, int param1Int) {
      if (param1CharSequence != null) {
        boolean bool;
        if (param1CharSequence.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          String str = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(param1CharSequence.toString(), " \n", " ", false, 4, null), "\n", " ", false, 4, null), "\"", "", false, 4, null);
          if (param1CharSequence.length() > param1Int) {
            param1CharSequence = new StringBuilder();
            if (str != null) {
              str = str.substring(0, param1Int);
              Intrinsics.checkNotNullExpressionValue(str, "(this as java.lang.Strin…ing(startIndex, endIndex)");
              param1CharSequence.append(str);
              param1CharSequence.append("...");
              return param1CharSequence.toString();
            } 
            throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
          } 
          return str;
        } 
      } 
      return "";
    }
    
    private final String getTextFromRcTextView(View param1View) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
      if (EndToEndDumpsysHelper.rcTextViewGetTextMethod == null)
        EndToEndDumpsysHelper.rcTextViewGetTextMethod = param1View.getClass().getDeclaredMethod("getText", new Class[0]); 
      Method method = EndToEndDumpsysHelper.rcTextViewGetTextMethod;
      String str = null;
      if (method != null) {
        Object object = method.invoke(param1View, new Object[0]);
      } else {
        param1View = null;
      } 
      if (param1View != null)
        str = param1View.toString(); 
      return str;
    }
    
    private final boolean hasArgument(String[] param1ArrayOfString, String param1String) {
      if (param1ArrayOfString == null)
        return false; 
      int j = param1ArrayOfString.length;
      for (int i = 0; i < j; i++) {
        if (StringsKt.equals(param1String, param1ArrayOfString[i], true))
          return true; 
      } 
      return false;
    }
    
    private final boolean isExtendsLithoView(View param1View) {
      for (Class<?> clazz = param1View.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
        if (Intrinsics.areEqual(clazz.getName(), "com.facebook.litho.LithoView"))
          return true; 
      } 
      return false;
    }
    
    private final void maybeWriteViewTestIdFromTag(PrintWriter param1PrintWriter, View param1View) {
      Object object2 = param1View.getTag();
      Object object1 = object2;
      if (!(object2 instanceof String))
        object1 = null; 
      object1 = object1;
      if (object1 != null) {
        boolean bool;
        object1 = object1;
        if (object1.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          return; 
        param1PrintWriter.print(" app:tag/");
        object2 = this;
        param1PrintWriter.print(fixString((CharSequence)object1, 60));
      } 
    }
    
    private final void writeViewBounds(PrintWriter param1PrintWriter, View param1View, int param1Int1, int param1Int2) {
      int[] arrayOfInt = new int[2];
      param1View.getLocationOnScreen(arrayOfInt);
      param1PrintWriter.print(" ");
      param1PrintWriter.print(arrayOfInt[0] - param1Int1);
      param1PrintWriter.print(",");
      param1PrintWriter.print(arrayOfInt[1] - param1Int2);
      param1PrintWriter.print("-");
      param1PrintWriter.print(arrayOfInt[0] + param1View.getWidth() - param1Int1);
      param1PrintWriter.print(",");
      param1PrintWriter.print(arrayOfInt[1] + param1View.getHeight() - param1Int2);
    }
    
    private final void writeViewFlags(PrintWriter param1PrintWriter, View param1View) {
      param1PrintWriter.print(" ");
      int i = param1View.getVisibility();
      String str5 = "V";
      String str2 = ".";
      if (i != 0) {
        if (i != 4) {
          if (i != 8) {
            param1PrintWriter.print(".");
          } else {
            param1PrintWriter.print("G");
          } 
        } else {
          param1PrintWriter.print("I");
        } 
      } else {
        param1PrintWriter.print("V");
      } 
      boolean bool = param1View.isFocusable();
      String str3 = "F";
      if (bool) {
        str1 = "F";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isEnabled()) {
        str1 = "E";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      param1PrintWriter.print(".");
      bool = param1View.isHorizontalScrollBarEnabled();
      String str4 = "H";
      if (bool) {
        str1 = "H";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isVerticalScrollBarEnabled()) {
        str1 = str5;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isClickable()) {
        str1 = "C";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isLongClickable()) {
        str1 = "L";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      param1PrintWriter.print(" ");
      if (param1View.isFocused()) {
        str1 = str3;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isSelected()) {
        str1 = "S";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isHovered()) {
        str1 = str4;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isActivated()) {
        str1 = "A";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      String str1 = str2;
      if (param1View.isDirty())
        str1 = "D"; 
      param1PrintWriter.print(str1);
    }
    
    private final void writeViewTestId(PrintWriter param1PrintWriter, View param1View) {
      try {
        String str;
        int i = param1View.getId();
        if (i == -1) {
          Companion companion = this;
          maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
          return;
        } 
        param1PrintWriter.append(" #");
        param1PrintWriter.append(Integer.toHexString(i));
        Resources resources = param1View.getResources();
        if (i <= 0 || resources == null) {
          Companion companion = this;
          maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
          return;
        } 
        int j = 0xFF000000 & i;
        if (j != 16777216) {
          if (j != 2130706432) {
            str = resources.getResourcePackageName(i);
            Intrinsics.checkNotNullExpressionValue(str, "resources.getResourcePackageName(id)");
          } else {
            str = "app";
          } 
        } else {
          str = "android";
        } 
        param1PrintWriter.print(" ");
        param1PrintWriter.print(str);
        param1PrintWriter.print(":");
        param1PrintWriter.print(resources.getResourceTypeName(i));
        param1PrintWriter.print("/");
        param1PrintWriter.print(resources.getResourceEntryName(i));
        return;
      } catch (Exception exception) {
        Companion companion = this;
        maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
        return;
      } 
    }
    
    private final void writeViewText(PrintWriter param1PrintWriter, View param1View) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #9
      //   3: aconst_null
      //   4: checkcast java/lang/String
      //   7: astore #10
      //   9: aload_2
      //   10: instanceof android/widget/TextView
      //   13: istore #8
      //   15: iconst_0
      //   16: istore #7
      //   18: iload #8
      //   20: ifeq -> 37
      //   23: aload_2
      //   24: checkcast android/widget/TextView
      //   27: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   30: invokevirtual toString : ()Ljava/lang/String;
      //   33: astore_2
      //   34: goto -> 184
      //   37: aload_2
      //   38: invokevirtual getClass : ()Ljava/lang/Class;
      //   41: invokevirtual getSimpleName : ()Ljava/lang/String;
      //   44: ldc_w 'RCTextView'
      //   47: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   50: ifeq -> 68
      //   53: aload_0
      //   54: checkcast com/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Companion
      //   57: astore #9
      //   59: aload_0
      //   60: aload_2
      //   61: invokespecial getTextFromRcTextView : (Landroid/view/View;)Ljava/lang/String;
      //   64: astore_2
      //   65: goto -> 184
      //   68: aload_2
      //   69: invokevirtual getContentDescription : ()Ljava/lang/CharSequence;
      //   72: astore #10
      //   74: aload #10
      //   76: ifnull -> 86
      //   79: aload #10
      //   81: invokevirtual toString : ()Ljava/lang/String;
      //   84: astore #9
      //   86: aload #9
      //   88: ifnull -> 109
      //   91: aload #9
      //   93: checkcast java/lang/CharSequence
      //   96: invokeinterface length : ()I
      //   101: ifne -> 245
      //   104: iconst_1
      //   105: istore_3
      //   106: goto -> 247
      //   109: aload_2
      //   110: invokevirtual getTag : ()Ljava/lang/Object;
      //   113: astore_2
      //   114: aload_2
      //   115: ifnull -> 321
      //   118: aload_2
      //   119: invokevirtual toString : ()Ljava/lang/String;
      //   122: checkcast java/lang/CharSequence
      //   125: astore_2
      //   126: aload_2
      //   127: invokeinterface length : ()I
      //   132: iconst_1
      //   133: isub
      //   134: istore_3
      //   135: iconst_0
      //   136: istore #4
      //   138: iconst_0
      //   139: istore #5
      //   141: goto -> 254
      //   144: aload_2
      //   145: iload #6
      //   147: invokeinterface charAt : (I)C
      //   152: bipush #32
      //   154: invokestatic compare : (II)I
      //   157: ifgt -> 278
      //   160: iconst_1
      //   161: istore #6
      //   163: goto -> 281
      //   166: aload_2
      //   167: iload #4
      //   169: iload_3
      //   170: iconst_1
      //   171: iadd
      //   172: invokeinterface subSequence : (II)Ljava/lang/CharSequence;
      //   177: invokevirtual toString : ()Ljava/lang/String;
      //   180: astore_2
      //   181: goto -> 184
      //   184: aload_2
      //   185: ifnull -> 242
      //   188: iload #7
      //   190: istore_3
      //   191: aload_2
      //   192: checkcast java/lang/CharSequence
      //   195: invokeinterface length : ()I
      //   200: ifne -> 327
      //   203: iconst_1
      //   204: istore_3
      //   205: goto -> 327
      //   208: aload_1
      //   209: ldc_w ' text="'
      //   212: invokevirtual print : (Ljava/lang/String;)V
      //   215: aload_0
      //   216: checkcast com/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Companion
      //   219: astore #9
      //   221: aload_1
      //   222: aload_0
      //   223: aload_2
      //   224: checkcast java/lang/CharSequence
      //   227: sipush #600
      //   230: invokespecial fixString : (Ljava/lang/CharSequence;I)Ljava/lang/String;
      //   233: invokevirtual print : (Ljava/lang/String;)V
      //   236: aload_1
      //   237: ldc '"'
      //   239: invokevirtual print : (Ljava/lang/String;)V
      //   242: return
      //   243: astore_1
      //   244: return
      //   245: iconst_0
      //   246: istore_3
      //   247: iload_3
      //   248: ifeq -> 321
      //   251: goto -> 109
      //   254: iload #4
      //   256: iload_3
      //   257: if_icmpgt -> 166
      //   260: iload #5
      //   262: ifne -> 272
      //   265: iload #4
      //   267: istore #6
      //   269: goto -> 144
      //   272: iload_3
      //   273: istore #6
      //   275: goto -> 144
      //   278: iconst_0
      //   279: istore #6
      //   281: iload #5
      //   283: ifne -> 306
      //   286: iload #6
      //   288: ifne -> 297
      //   291: iconst_1
      //   292: istore #5
      //   294: goto -> 254
      //   297: iload #4
      //   299: iconst_1
      //   300: iadd
      //   301: istore #4
      //   303: goto -> 254
      //   306: iload #6
      //   308: ifne -> 314
      //   311: goto -> 166
      //   314: iload_3
      //   315: iconst_1
      //   316: isub
      //   317: istore_3
      //   318: goto -> 254
      //   321: aload #9
      //   323: astore_2
      //   324: goto -> 184
      //   327: iload_3
      //   328: ifeq -> 208
      //   331: return
      // Exception table:
      //   from	to	target	type
      //   3	15	243	java/lang/Exception
      //   23	34	243	java/lang/Exception
      //   37	65	243	java/lang/Exception
      //   68	74	243	java/lang/Exception
      //   79	86	243	java/lang/Exception
      //   91	104	243	java/lang/Exception
      //   109	114	243	java/lang/Exception
      //   118	135	243	java/lang/Exception
      //   144	160	243	java/lang/Exception
      //   166	181	243	java/lang/Exception
      //   191	203	243	java/lang/Exception
      //   208	242	243	java/lang/Exception
    }
    
    @JvmStatic
    public final boolean maybeDump(String param1String, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1String, "prefix");
      Intrinsics.checkNotNullParameter(param1PrintWriter, "writer");
      if (param1ArrayOfString != null) {
        boolean bool;
        if (param1ArrayOfString.length == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool ^ true) != 0 && Intrinsics.areEqual("e2e", param1ArrayOfString[0])) {
          if (EndToEndDumpsysHelper.instance == null)
            EndToEndDumpsysHelper.instance = new EndToEndDumpsysHelper(); 
          EndToEndDumpsysHelper endToEndDumpsysHelper = EndToEndDumpsysHelper.instance;
          if (endToEndDumpsysHelper != null)
            endToEndDumpsysHelper.dumpViewHierarchy(param1String, param1PrintWriter, param1ArrayOfString); 
          return true;
        } 
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\logging\dumpsys\EndToEndDumpsysHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */