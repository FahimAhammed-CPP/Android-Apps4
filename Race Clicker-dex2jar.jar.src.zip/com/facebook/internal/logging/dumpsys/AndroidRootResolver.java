package com.facebook.internal.logging.dumpsys;

import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\005\030\000 \0212\0020\001:\004\021\022\023\024B\005¢\006\002\020\002J\020\020\t\032\0020\n2\b\020\013\032\004\030\0010\fJ\b\020\r\032\0020\nH\002J\016\020\016\032\n\022\004\022\0020\020\030\0010\017R\016\020\003\032\0020\004X\016¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R\020\020\007\032\004\030\0010\006X\016¢\006\002\n\000R\020\020\b\032\004\030\0010\001X\016¢\006\002\n\000¨\006\025"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver;", "", "()V", "initialized", "", "paramsField", "Ljava/lang/reflect/Field;", "viewsField", "windowManagerObj", "attachActiveRootListener", "", "listener", "Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Listener;", "initialize", "listActiveRoots", "", "Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Root;", "Companion", "ListenableArrayList", "Listener", "Root", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AndroidRootResolver {
  public static final Companion Companion = new Companion(null);
  
  private static final String GET_DEFAULT_IMPL = "getDefault";
  
  private static final String GET_GLOBAL_INSTANCE = "getInstance";
  
  private static final String TAG = "AndroidRootResolver";
  
  private static final String VIEWS_FIELD = "mViews";
  
  private static final String WINDOW_MANAGER_GLOBAL_CLAZZ = "android.view.WindowManagerGlobal";
  
  private static final String WINDOW_MANAGER_IMPL_CLAZZ = "android.view.WindowManagerImpl";
  
  private static final String WINDOW_PARAMS_FIELD = "mParams";
  
  private boolean initialized;
  
  private Field paramsField;
  
  private Field viewsField;
  
  private Object windowManagerObj;
  
  private final void initialize() {
    this.initialized = true;
    try {
      Class<?> clazz = Class.forName("android.view.WindowManagerGlobal");
      Intrinsics.checkNotNullExpressionValue(clazz, "Class.forName(accessClass)");
      Method method = clazz.getMethod("getInstance", new Class[0]);
      Intrinsics.checkNotNullExpressionValue(method, "clazz.getMethod(instanceMethod)");
      this.windowManagerObj = method.invoke(null, new Object[0]);
      Field field2 = clazz.getDeclaredField("mViews");
      this.viewsField = field2;
      if (field2 != null)
        field2.setAccessible(true); 
      Field field1 = clazz.getDeclaredField("mParams");
      this.paramsField = field1;
      if (field1 != null) {
        field1.setAccessible(true);
        return;
      } 
    } catch (InvocationTargetException invocationTargetException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("could not invoke: %s on %s", Arrays.copyOf(new Object[] { "getInstance", "android.view.WindowManagerGlobal" }, 2));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, invocationTargetException.getCause());
    } catch (ClassNotFoundException classNotFoundException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("could not find class: %s", Arrays.copyOf(new Object[] { "android.view.WindowManagerGlobal" }, 1));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, classNotFoundException);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("could not find field: %s or %s on %s", Arrays.copyOf(new Object[] { "mParams", "mViews", "android.view.WindowManagerGlobal" }, 3));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, noSuchFieldException);
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("could not find method: %s on %s", Arrays.copyOf(new Object[] { "getInstance", "android.view.WindowManagerGlobal" }, 2));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, noSuchMethodException);
      return;
    } catch (RuntimeException runtimeException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("reflective setup failed using obj: %s method: %s field: %s", Arrays.copyOf(new Object[] { "android.view.WindowManagerGlobal", "getInstance", "mViews" }, 3));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, runtimeException);
      return;
    } catch (IllegalAccessException illegalAccessException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("reflective setup failed using obj: %s method: %s field: %s", Arrays.copyOf(new Object[] { "android.view.WindowManagerGlobal", "getInstance", "mViews" }, 3));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, illegalAccessException);
      return;
    } 
  }
  
  public final void attachActiveRootListener(Listener paramListener) {
    if (paramListener == null)
      return; 
    if (!this.initialized)
      initialize(); 
    try {
      boolean bool;
      Field field1 = Field.class.getDeclaredField("accessFlags");
      Intrinsics.checkNotNullExpressionValue(field1, "Field::class.java.getDeclaredField(\"accessFlags\")");
      field1.setAccessible(true);
      Field field2 = this.viewsField;
      if (field2 != null) {
        bool = field2.getModifiers();
      } else {
        bool = false;
      } 
      field1.setInt(field2, bool);
      field1 = this.viewsField;
      if (field1 != null) {
        Object object = field1.get(this.windowManagerObj);
      } else {
        field1 = null;
      } 
    } finally {
      paramListener = null;
    } 
  }
  
  public final List<Root> listActiveRoots() {
    if (!this.initialized)
      initialize(); 
    if (this.windowManagerObj == null) {
      Log.d(TAG, "No reflective access to windowmanager object.");
      return null;
    } 
    if (this.viewsField == null) {
      Log.d(TAG, "No reflective access to mViews");
      return null;
    } 
    if (this.paramsField == null) {
      Log.d(TAG, "No reflective access to mPArams");
      return null;
    } 
    List list = (List)null;
    try {
      Field field = this.viewsField;
      if (field != null) {
        null = field.get(this.windowManagerObj);
      } else {
        field = null;
      } 
      List list1 = (List)field;
      field = this.paramsField;
      if (field != null) {
        null = field.get(this.windowManagerObj);
      } else {
        field = null;
      } 
      List list2 = (List)field;
      ArrayList<Root> arrayList = new ArrayList();
      if (list1 != null) {
        null = list1;
      } else {
        null = CollectionsKt.emptyList();
      } 
      Iterable iterable = (Iterable)null;
      if (list2 != null) {
        null = list2;
      } else {
        null = CollectionsKt.emptyList();
      } 
      for (Pair pair : CollectionsKt.zip(iterable, (Iterable)null))
        arrayList.add(new Root((View)pair.component1(), (WindowManager.LayoutParams)pair.component2())); 
      return arrayList;
    } catch (RuntimeException runtimeException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("Reflective access to %s or %s on %s failed.", Arrays.copyOf(new Object[] { this.viewsField, this.paramsField, this.windowManagerObj }, 3));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, runtimeException);
      return null;
    } catch (IllegalAccessException illegalAccessException) {
      String str1 = TAG;
      StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
      String str2 = String.format("Reflective access to %s or %s on %s failed.", Arrays.copyOf(new Object[] { this.viewsField, this.paramsField, this.windowManagerObj }, 3));
      Intrinsics.checkNotNullExpressionValue(str2, "java.lang.String.format(format, *args)");
      Log.d(str1, str2, illegalAccessException);
      return null;
    } 
  }
  
  static {
    Intrinsics.checkNotNullExpressionValue("AndroidRootResolver", "AndroidRootResolver::class.java.simpleName");
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\007\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004X\004¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\016\020\n\032\0020\004XT¢\006\002\n\000¨\006\013"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Companion;", "", "()V", "GET_DEFAULT_IMPL", "", "GET_GLOBAL_INSTANCE", "TAG", "VIEWS_FIELD", "WINDOW_MANAGER_GLOBAL_CLAZZ", "WINDOW_MANAGER_IMPL_CLAZZ", "WINDOW_PARAMS_FIELD", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\020\b\n\000\n\002\020\002\n\000\030\0002\026\022\006\022\004\030\0010\0020\001j\n\022\006\022\004\030\0010\002`\003B\005¢\006\002\020\004J\022\020\007\032\0020\b2\b\020\t\032\004\030\0010\002H\026J\022\020\n\032\0020\b2\b\020\t\032\004\030\0010\002H\026J\022\020\013\032\004\030\0010\0022\006\020\f\032\0020\rH\026J\020\020\016\032\0020\0172\b\020\005\032\004\030\0010\006R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000¨\006\020"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$ListenableArrayList;", "Ljava/util/ArrayList;", "Landroid/view/View;", "Lkotlin/collections/ArrayList;", "()V", "listener", "Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Listener;", "add", "", "value", "remove", "removeAt", "index", "", "setListener", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class ListenableArrayList extends ArrayList<View> {
    private AndroidRootResolver.Listener listener;
    
    public boolean add(View param1View) {
      boolean bool = super.add(param1View);
      if (bool) {
        AndroidRootResolver.Listener listener = this.listener;
        if (listener != null) {
          if (listener != null)
            listener.onRootAdded(param1View); 
          AndroidRootResolver.Listener listener1 = this.listener;
          if (listener1 != null)
            listener1.onRootsChanged(this); 
        } 
      } 
      return bool;
    }
    
    public boolean remove(View param1View) {
      boolean bool = super.remove(param1View);
      if (bool) {
        AndroidRootResolver.Listener listener = this.listener;
        if (listener != null && param1View instanceof View) {
          if (listener != null)
            listener.onRootRemoved(param1View); 
          AndroidRootResolver.Listener listener1 = this.listener;
          if (listener1 != null)
            listener1.onRootsChanged(this); 
        } 
      } 
      return bool;
    }
    
    public View removeAt(int param1Int) {
      View view = super.remove(param1Int);
      AndroidRootResolver.Listener listener = this.listener;
      if (listener != null) {
        if (listener != null)
          listener.onRootRemoved(view); 
        listener = this.listener;
        if (listener != null)
          listener.onRootsChanged(this); 
      } 
      return view;
    }
    
    public final void setListener(AndroidRootResolver.Listener param1Listener) {
      this.listener = param1Listener;
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\020 \n\000\bf\030\0002\0020\001J\022\020\002\032\0020\0032\b\020\004\032\004\030\0010\005H&J\022\020\006\032\0020\0032\b\020\004\032\004\030\0010\005H&J\032\020\007\032\0020\0032\020\020\b\032\f\022\006\022\004\030\0010\005\030\0010\tH&¨\006\n"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Listener;", "", "onRootAdded", "", "root", "Landroid/view/View;", "onRootRemoved", "onRootsChanged", "roots", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static interface Listener {
    void onRootAdded(View param1View);
    
    void onRootRemoved(View param1View);
    
    void onRootsChanged(List<? extends View> param1List);
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\006\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006R\021\020\004\032\0020\005¢\006\b\n\000\032\004\b\007\020\bR\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\t\020\n¨\006\013"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver$Root;", "", "view", "Landroid/view/View;", "param", "Landroid/view/WindowManager$LayoutParams;", "(Landroid/view/View;Landroid/view/WindowManager$LayoutParams;)V", "getParam", "()Landroid/view/WindowManager$LayoutParams;", "getView", "()Landroid/view/View;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Root {
    private final WindowManager.LayoutParams param;
    
    private final View view;
    
    public Root(View param1View, WindowManager.LayoutParams param1LayoutParams) {
      this.view = param1View;
      this.param = param1LayoutParams;
    }
    
    public final WindowManager.LayoutParams getParam() {
      return this.param;
    }
    
    public final View getView() {
      return this.view;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\logging\dumpsys\AndroidRootResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */