package com.facebook.internal;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\002\b\004\n\002\020\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\n\020\n\032\004\030\0010\004H\007J\020\020\013\032\0020\f2\006\020\r\032\0020\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\020\020\005\032\004\030\0010\004X\016¢\006\002\n\000R\032\020\006\032\0020\0078FX\004¢\006\f\022\004\b\b\020\002\032\004\b\006\020\t¨\006\016"}, d2 = {"Lcom/facebook/internal/InternalSettings;", "", "()V", "UNITY_PREFIX", "", "customUserAgent", "isUnityApp", "", "isUnityApp$annotations", "()Z", "getCustomUserAgent", "setCustomUserAgent", "", "value", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class InternalSettings {
  public static final InternalSettings INSTANCE = new InternalSettings();
  
  private static final String UNITY_PREFIX = "Unity.";
  
  private static volatile String customUserAgent;
  
  @JvmStatic
  public static final String getCustomUserAgent() {
    return customUserAgent;
  }
  
  public static final boolean isUnityApp() {
    String str = customUserAgent;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (str != null) {
      bool1 = bool2;
      if (StringsKt.startsWith$default(str, "Unity.", false, 2, null) == true)
        bool1 = true; 
    } 
    return bool1;
  }
  
  @JvmStatic
  public static final void setCustomUserAgent(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "value");
    customUserAgent = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\InternalSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */