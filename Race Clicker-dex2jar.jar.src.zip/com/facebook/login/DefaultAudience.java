package com.facebook.login;

import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\020\n\000\n\002\020\016\n\002\b\b\b\001\030\0002\b\022\004\022\0020\0000\001B\021\b\002\022\b\020\002\032\004\030\0010\003¢\006\002\020\004R\023\020\002\032\004\030\0010\003¢\006\b\n\000\032\004\b\005\020\006j\002\b\007j\002\b\bj\002\b\tj\002\b\n¨\006\013"}, d2 = {"Lcom/facebook/login/DefaultAudience;", "", "nativeProtocolAudience", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getNativeProtocolAudience", "()Ljava/lang/String;", "NONE", "ONLY_ME", "FRIENDS", "EVERYONE", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public enum DefaultAudience {
  EVERYONE, FRIENDS, NONE, ONLY_ME;
  
  private final String nativeProtocolAudience;
  
  static {
    DefaultAudience defaultAudience1 = new DefaultAudience("NONE", 0, null);
    NONE = defaultAudience1;
    DefaultAudience defaultAudience2 = new DefaultAudience("ONLY_ME", 1, "only_me");
    ONLY_ME = defaultAudience2;
    DefaultAudience defaultAudience3 = new DefaultAudience("FRIENDS", 2, "friends");
    FRIENDS = defaultAudience3;
    DefaultAudience defaultAudience4 = new DefaultAudience("EVERYONE", 3, "everyone");
    EVERYONE = defaultAudience4;
    $VALUES = new DefaultAudience[] { defaultAudience1, defaultAudience2, defaultAudience3, defaultAudience4 };
  }
  
  DefaultAudience(String paramString1) {
    this.nativeProtocolAudience = paramString1;
  }
  
  public final String getNativeProtocolAudience() {
    return this.nativeProtocolAudience;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\login\DefaultAudience.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */