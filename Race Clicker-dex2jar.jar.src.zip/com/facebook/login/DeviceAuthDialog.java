package com.facebook.login;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.DialogFragment;
import com.facebook.AccessToken;
import com.facebook.AccessTokenSource;
import com.facebook.FacebookActivity;
import com.facebook.FacebookException;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphRequestAsyncTask;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.appevents.InternalAppEventsLogger;
import com.facebook.common.R;
import com.facebook.devicerequests.internal.DeviceRequestsHelper;
import com.facebook.internal.FetchedAppSettingsManager;
import com.facebook.internal.SmartLoginOption;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceAuthDialog extends DialogFragment {
  private static final String DEVICE_LOGIN_ENDPOINT = "device/login";
  
  private static final String DEVICE_LOGIN_STATUS_ENDPOINT = "device/login_status";
  
  private static final int LOGIN_ERROR_SUBCODE_AUTHORIZATION_DECLINED = 1349173;
  
  private static final int LOGIN_ERROR_SUBCODE_AUTHORIZATION_PENDING = 1349174;
  
  private static final int LOGIN_ERROR_SUBCODE_CODE_EXPIRED = 1349152;
  
  private static final int LOGIN_ERROR_SUBCODE_EXCESSIVE_POLLING = 1349172;
  
  private static final String REQUEST_STATE_KEY = "request_state";
  
  private AtomicBoolean completed = new AtomicBoolean();
  
  private TextView confirmationCode;
  
  private volatile GraphRequestAsyncTask currentGraphRequestPoll;
  
  private volatile RequestState currentRequestState;
  
  private DeviceAuthMethodHandler deviceAuthMethodHandler;
  
  private TextView instructions;
  
  private boolean isBeingDestroyed = false;
  
  private boolean isRetry = false;
  
  private LoginClient.Request mRequest = null;
  
  private View progressBar;
  
  private volatile ScheduledFuture scheduledPoll;
  
  private void completeLogin(String paramString1, Utility.PermissionsLists paramPermissionsLists, String paramString2, Date paramDate1, Date paramDate2) {
    this.deviceAuthMethodHandler.onSuccess(paramString2, FacebookSdk.getApplicationId(), paramString1, paramPermissionsLists.getGrantedPermissions(), paramPermissionsLists.getDeclinedPermissions(), paramPermissionsLists.getExpiredPermissions(), AccessTokenSource.DEVICE_AUTH, paramDate1, null, paramDate2);
    getDialog().dismiss();
  }
  
  private GraphRequest getPollRequest() {
    Bundle bundle = new Bundle();
    bundle.putString("code", this.currentRequestState.getRequestCode());
    return new GraphRequest(null, "device/login_status", bundle, HttpMethod.POST, new GraphRequest.Callback() {
          public void onCompleted(GraphResponse param1GraphResponse) {
            DeviceAuthDialog deviceAuthDialog;
            if (DeviceAuthDialog.this.completed.get())
              return; 
            FacebookRequestError facebookRequestError = param1GraphResponse.getError();
            if (facebookRequestError != null) {
              int i = facebookRequestError.getSubErrorCode();
              if (i != 1349152) {
                switch (i) {
                  default:
                    DeviceAuthDialog.this.onError(param1GraphResponse.getError().getException());
                    return;
                  case 1349173:
                    DeviceAuthDialog.this.onCancel();
                    return;
                  case 1349172:
                  case 1349174:
                    break;
                } 
                DeviceAuthDialog.this.schedulePoll();
                return;
              } 
              if (DeviceAuthDialog.this.currentRequestState != null)
                DeviceRequestsHelper.cleanUpAdvertisementService(DeviceAuthDialog.this.currentRequestState.getUserCode()); 
              if (DeviceAuthDialog.this.mRequest != null) {
                deviceAuthDialog = DeviceAuthDialog.this;
                deviceAuthDialog.startLogin(deviceAuthDialog.mRequest);
                return;
              } 
              DeviceAuthDialog.this.onCancel();
              return;
            } 
            try {
              JSONObject jSONObject = deviceAuthDialog.getJSONObject();
              DeviceAuthDialog.this.onSuccess(jSONObject.getString("access_token"), Long.valueOf(jSONObject.getLong("expires_in")), Long.valueOf(jSONObject.optLong("data_access_expiration_time")));
              return;
            } catch (JSONException jSONException) {
              DeviceAuthDialog.this.onError(new FacebookException((Throwable)jSONException));
              return;
            } 
          }
        });
  }
  
  private void onSuccess(final String accessToken, final Long expirationTime, Long paramLong2) {
    Bundle bundle = new Bundle();
    bundle.putString("fields", "id,permissions,name");
    long l = expirationTime.longValue();
    Date date2 = null;
    if (l != 0L) {
      Date date = new Date((new Date()).getTime() + expirationTime.longValue() * 1000L);
    } else {
      expirationTime = null;
    } 
    final Date dataAccessExpirationTimeDate = date2;
    if (paramLong2.longValue() != 0L) {
      date1 = date2;
      if (paramLong2 != null)
        date1 = new Date(paramLong2.longValue() * 1000L); 
    } 
    (new GraphRequest(new AccessToken(accessToken, FacebookSdk.getApplicationId(), "0", null, null, null, null, (Date)expirationTime, null, date1), "me", bundle, HttpMethod.GET, new GraphRequest.Callback() {
          public void onCompleted(GraphResponse param1GraphResponse) {
            if (DeviceAuthDialog.this.completed.get())
              return; 
            if (param1GraphResponse.getError() != null) {
              DeviceAuthDialog.this.onError(param1GraphResponse.getError().getException());
              return;
            } 
            try {
              JSONObject jSONObject = param1GraphResponse.getJSONObject();
              String str1 = jSONObject.getString("id");
              Utility.PermissionsLists permissionsLists = Utility.handlePermissionResponse(jSONObject);
              String str2 = jSONObject.getString("name");
              DeviceRequestsHelper.cleanUpAdvertisementService(DeviceAuthDialog.this.currentRequestState.getUserCode());
              if (FetchedAppSettingsManager.getAppSettingsWithoutQuery(FacebookSdk.getApplicationId()).getSmartLoginOptions().contains(SmartLoginOption.RequireConfirm) && !DeviceAuthDialog.this.isRetry) {
                DeviceAuthDialog.access$902(DeviceAuthDialog.this, true);
                DeviceAuthDialog.this.presentConfirmation(str1, permissionsLists, accessToken, str2, expirationTime, dataAccessExpirationTimeDate);
                return;
              } 
              DeviceAuthDialog.this.completeLogin(str1, permissionsLists, accessToken, expirationTime, dataAccessExpirationTimeDate);
              return;
            } catch (JSONException jSONException) {
              DeviceAuthDialog.this.onError(new FacebookException((Throwable)jSONException));
              return;
            } 
          }
        })).executeAsync();
  }
  
  private void poll() {
    this.currentRequestState.setLastPoll((new Date()).getTime());
    this.currentGraphRequestPoll = getPollRequest().executeAsync();
  }
  
  private void presentConfirmation(final String userId, final Utility.PermissionsLists permissions, final String accessToken, String paramString3, final Date expirationTime, final Date dataAccessExpirationTime) {
    String str1 = getResources().getString(R.string.com_facebook_smart_login_confirmation_title);
    String str3 = getResources().getString(R.string.com_facebook_smart_login_confirmation_continue_as);
    String str2 = getResources().getString(R.string.com_facebook_smart_login_confirmation_cancel);
    paramString3 = String.format(str3, new Object[] { paramString3 });
    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
    builder.setMessage(str1).setCancelable(true).setNegativeButton(paramString3, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            DeviceAuthDialog.this.completeLogin(userId, permissions, accessToken, expirationTime, dataAccessExpirationTime);
          }
        }).setPositiveButton(str2, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            View view = DeviceAuthDialog.this.initializeContentView(false);
            DeviceAuthDialog.this.getDialog().setContentView(view);
            DeviceAuthDialog deviceAuthDialog = DeviceAuthDialog.this;
            deviceAuthDialog.startLogin(deviceAuthDialog.mRequest);
          }
        });
    builder.create().show();
  }
  
  private void schedulePoll() {
    this.scheduledPoll = DeviceAuthMethodHandler.getBackgroundExecutor().schedule(new Runnable() {
          public void run() {
            if (CrashShieldHandler.isObjectCrashing(this))
              return; 
            try {
              return;
            } finally {
              Exception exception = null;
              CrashShieldHandler.handleThrowable(exception, this);
            } 
          }
        }this.currentRequestState.getInterval(), TimeUnit.SECONDS);
  }
  
  private void setCurrentRequestState(RequestState paramRequestState) {
    this.currentRequestState = paramRequestState;
    this.confirmationCode.setText(paramRequestState.getUserCode());
    Bitmap bitmap = DeviceRequestsHelper.generateQRCode(paramRequestState.getAuthorizationUri());
    BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
    this.instructions.setCompoundDrawablesWithIntrinsicBounds(null, (Drawable)bitmapDrawable, null, null);
    this.confirmationCode.setVisibility(0);
    this.progressBar.setVisibility(8);
    if (!this.isRetry && DeviceRequestsHelper.startAdvertisementService(paramRequestState.getUserCode()))
      (new InternalAppEventsLogger(getContext())).logEventImplicitly("fb_smart_login_service"); 
    if (paramRequestState.withinLastRefreshWindow()) {
      schedulePoll();
      return;
    } 
    poll();
  }
  
  protected int getLayoutResId(boolean paramBoolean) {
    return paramBoolean ? R.layout.com_facebook_smart_device_dialog_fragment : R.layout.com_facebook_device_auth_dialog_fragment;
  }
  
  protected View initializeContentView(boolean paramBoolean) {
    View view = getActivity().getLayoutInflater().inflate(getLayoutResId(paramBoolean), null);
    this.progressBar = view.findViewById(R.id.progress_bar);
    this.confirmationCode = (TextView)view.findViewById(R.id.confirmation_code);
    ((Button)view.findViewById(R.id.cancel_button)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (CrashShieldHandler.isObjectCrashing(this))
              return; 
            try {
              return;
            } finally {
              param1View = null;
              CrashShieldHandler.handleThrowable((Throwable)param1View, this);
            } 
          }
        });
    TextView textView = (TextView)view.findViewById(R.id.com_facebook_device_auth_instructions);
    this.instructions = textView;
    textView.setText((CharSequence)Html.fromHtml(getString(R.string.com_facebook_device_auth_instructions)));
    return view;
  }
  
  protected void onBackButtonPressed() {}
  
  protected void onCancel() {
    if (!this.completed.compareAndSet(false, true))
      return; 
    if (this.currentRequestState != null)
      DeviceRequestsHelper.cleanUpAdvertisementService(this.currentRequestState.getUserCode()); 
    DeviceAuthMethodHandler deviceAuthMethodHandler = this.deviceAuthMethodHandler;
    if (deviceAuthMethodHandler != null)
      deviceAuthMethodHandler.onCancel(); 
    getDialog().dismiss();
  }
  
  public Dialog onCreateDialog(Bundle paramBundle) {
    boolean bool;
    Dialog dialog = new Dialog((Context)getActivity(), R.style.com_facebook_auth_dialog) {
        public void onBackPressed() {
          DeviceAuthDialog.this.onBackButtonPressed();
          super.onBackPressed();
        }
      };
    if (DeviceRequestsHelper.isAvailable() && !this.isRetry) {
      bool = true;
    } else {
      bool = false;
    } 
    dialog.setContentView(initializeContentView(bool));
    return dialog;
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    View view = super.onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
    this.deviceAuthMethodHandler = (DeviceAuthMethodHandler)((LoginFragment)((FacebookActivity)getActivity()).getCurrentFragment()).getLoginClient().getCurrentHandler();
    if (paramBundle != null) {
      RequestState requestState = (RequestState)paramBundle.getParcelable("request_state");
      if (requestState != null)
        setCurrentRequestState(requestState); 
    } 
    return view;
  }
  
  public void onDestroyView() {
    this.isBeingDestroyed = true;
    this.completed.set(true);
    super.onDestroyView();
    if (this.currentGraphRequestPoll != null)
      this.currentGraphRequestPoll.cancel(true); 
    if (this.scheduledPoll != null)
      this.scheduledPoll.cancel(true); 
    this.progressBar = null;
    this.confirmationCode = null;
    this.instructions = null;
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    super.onDismiss(paramDialogInterface);
    if (!this.isBeingDestroyed)
      onCancel(); 
  }
  
  protected void onError(FacebookException paramFacebookException) {
    if (!this.completed.compareAndSet(false, true))
      return; 
    if (this.currentRequestState != null)
      DeviceRequestsHelper.cleanUpAdvertisementService(this.currentRequestState.getUserCode()); 
    this.deviceAuthMethodHandler.onError((Exception)paramFacebookException);
    getDialog().dismiss();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    if (this.currentRequestState != null)
      paramBundle.putParcelable("request_state", this.currentRequestState); 
  }
  
  public void startLogin(LoginClient.Request paramRequest) {
    this.mRequest = paramRequest;
    Bundle bundle = new Bundle();
    bundle.putString("scope", TextUtils.join(",", paramRequest.getPermissions()));
    String str2 = paramRequest.getDeviceRedirectUriString();
    if (str2 != null)
      bundle.putString("redirect_uri", str2); 
    String str1 = paramRequest.getDeviceAuthTargetUserId();
    if (str1 != null)
      bundle.putString("target_user_id", str1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Validate.hasAppID());
    stringBuilder.append("|");
    stringBuilder.append(Validate.hasClientToken());
    bundle.putString("access_token", stringBuilder.toString());
    bundle.putString("device_info", DeviceRequestsHelper.getDeviceInfo());
    (new GraphRequest(null, "device/login", bundle, HttpMethod.POST, new GraphRequest.Callback() {
          public void onCompleted(GraphResponse param1GraphResponse) {
            if (DeviceAuthDialog.this.isBeingDestroyed)
              return; 
            if (param1GraphResponse.getError() != null) {
              DeviceAuthDialog.this.onError(param1GraphResponse.getError().getException());
              return;
            } 
            JSONObject jSONObject = param1GraphResponse.getJSONObject();
            DeviceAuthDialog.RequestState requestState = new DeviceAuthDialog.RequestState();
            try {
              requestState.setUserCode(jSONObject.getString("user_code"));
              requestState.setRequestCode(jSONObject.getString("code"));
              requestState.setInterval(jSONObject.getLong("interval"));
              DeviceAuthDialog.this.setCurrentRequestState(requestState);
              return;
            } catch (JSONException jSONException) {
              DeviceAuthDialog.this.onError(new FacebookException((Throwable)jSONException));
              return;
            } 
          }
        })).executeAsync();
  }
  
  private static class RequestState implements Parcelable {
    public static final Parcelable.Creator<RequestState> CREATOR = new Parcelable.Creator<RequestState>() {
        public DeviceAuthDialog.RequestState createFromParcel(Parcel param2Parcel) {
          return new DeviceAuthDialog.RequestState(param2Parcel);
        }
        
        public DeviceAuthDialog.RequestState[] newArray(int param2Int) {
          return new DeviceAuthDialog.RequestState[param2Int];
        }
      };
    
    private String authorizationUri;
    
    private long interval;
    
    private long lastPoll;
    
    private String requestCode;
    
    private String userCode;
    
    RequestState() {}
    
    protected RequestState(Parcel param1Parcel) {
      this.authorizationUri = param1Parcel.readString();
      this.userCode = param1Parcel.readString();
      this.requestCode = param1Parcel.readString();
      this.interval = param1Parcel.readLong();
      this.lastPoll = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String getAuthorizationUri() {
      return this.authorizationUri;
    }
    
    public long getInterval() {
      return this.interval;
    }
    
    public String getRequestCode() {
      return this.requestCode;
    }
    
    public String getUserCode() {
      return this.userCode;
    }
    
    public void setInterval(long param1Long) {
      this.interval = param1Long;
    }
    
    public void setLastPoll(long param1Long) {
      this.lastPoll = param1Long;
    }
    
    public void setRequestCode(String param1String) {
      this.requestCode = param1String;
    }
    
    public void setUserCode(String param1String) {
      this.userCode = param1String;
      this.authorizationUri = String.format(Locale.ENGLISH, "https://facebook.com/device?user_code=%1$s&qr=1", new Object[] { param1String });
    }
    
    public boolean withinLastRefreshWindow() {
      long l = this.lastPoll;
      boolean bool = false;
      if (l == 0L)
        return false; 
      if ((new Date()).getTime() - this.lastPoll - this.interval * 1000L < 0L)
        bool = true; 
      return bool;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.authorizationUri);
      param1Parcel.writeString(this.userCode);
      param1Parcel.writeString(this.requestCode);
      param1Parcel.writeLong(this.interval);
      param1Parcel.writeLong(this.lastPoll);
    }
  }
  
  static final class null implements Parcelable.Creator<RequestState> {
    public DeviceAuthDialog.RequestState createFromParcel(Parcel param1Parcel) {
      return new DeviceAuthDialog.RequestState(param1Parcel);
    }
    
    public DeviceAuthDialog.RequestState[] newArray(int param1Int) {
      return new DeviceAuthDialog.RequestState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\login\DeviceAuthDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */