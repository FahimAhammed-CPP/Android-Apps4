package com.facebook.login;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\000\n\002\020\036\n\002\020\016\n\002\b\004\n\002\020\"\n\002\b\004\030\000 \f2\0020\001:\001\fB!\b\027\022\016\020\002\032\n\022\004\022\0020\004\030\0010\003\022\b\b\002\020\005\032\0020\004¢\006\002\020\006R\021\020\005\032\0020\004¢\006\b\n\000\032\004\b\007\020\bR\027\020\002\032\b\022\004\022\0020\0040\t¢\006\b\n\000\032\004\b\n\020\013¨\006\r"}, d2 = {"Lcom/facebook/login/LoginConfiguration;", "", "permissions", "", "", "nonce", "(Ljava/util/Collection;Ljava/lang/String;)V", "getNonce", "()Ljava/lang/String;", "", "getPermissions", "()Ljava/util/Set;", "Companion", "facebook-common_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class LoginConfiguration {
  public static final Companion Companion = new Companion(null);
  
  public static final String OPENID = "openid";
  
  private final String nonce;
  
  private final Set<String> permissions;
  
  public LoginConfiguration(Collection<String> paramCollection) {
    this(paramCollection, null, 2, null);
  }
  
  public LoginConfiguration(Collection<String> paramCollection, String paramString) {
    NonceUtil nonceUtil = NonceUtil.INSTANCE;
    if (NonceUtil.isValidNonce(paramString)) {
      if (paramCollection != null) {
        paramCollection = new HashSet<String>(paramCollection);
      } else {
        paramCollection = new HashSet<String>();
      } 
      paramCollection.add("openid");
      paramCollection = Collections.unmodifiableSet((Set<? extends String>)paramCollection);
      Intrinsics.checkNotNullExpressionValue(paramCollection, "unmodifiableSet(permissions)");
      this.permissions = (Set<String>)paramCollection;
      this.nonce = paramString;
      return;
    } 
    throw (Throwable)new IllegalArgumentException("Failed requirement.".toString());
  }
  
  public final String getNonce() {
    return this.nonce;
  }
  
  public final Set<String> getPermissions() {
    return this.permissions;
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/login/LoginConfiguration$Companion;", "", "()V", "OPENID", "", "facebook-common_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\login\LoginConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */