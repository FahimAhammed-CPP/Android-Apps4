package com.facebook.ads;

import android.content.Context;
import com.facebook.ads.internal.api.InitSettingsBuilder;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

public final class AudienceNetworkAds {
  public static final String TAG = "FBAudienceNetwork";
  
  public static InitSettingsBuilder buildInitSettings(Context paramContext) {
    Preconditions.checkNotNull(paramContext, "Context can not be null.");
    return (InitSettingsBuilder)new InitSettingsBuilder(paramContext);
  }
  
  public static int getAdFormatForPlacement(Context paramContext, String paramString) {
    return DynamicLoaderFactory.makeLoader(paramContext).createAudienceNetworkAdsApi().getAdFormatForPlacement(paramString);
  }
  
  public static void initialize(Context paramContext) {
    Preconditions.checkNotNull(paramContext, "Context can not be null.");
    DynamicLoaderFactory.initialize(paramContext, null, null, false);
  }
  
  public static boolean isInitialized(Context paramContext) {
    return (DynamicLoaderFactory.getDynamicLoader() == null) ? false : DynamicLoaderFactory.makeLoader(paramContext).createAudienceNetworkAdsApi().isInitialized();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface AdFormat {
    public static final int BANNER = 1;
    
    public static final int INTERSTITIAL = 2;
    
    public static final int NATIVE = 4;
    
    public static final int NATIVE_BANNER = 5;
    
    public static final int REWARDED_VIDEO = 6;
    
    public static final int UNKNOWN = 0;
  }
  
  public static interface InitListener {
    void onInitialized(AudienceNetworkAds.InitResult param1InitResult);
  }
  
  public static interface InitResult {
    String getMessage();
    
    boolean isSuccess();
  }
  
  public static interface InitSettingsBuilder {
    void initialize();
    
    InitSettingsBuilder withInitListener(AudienceNetworkAds.InitListener param1InitListener);
    
    InitSettingsBuilder withMediationService(String param1String);
    
    InitSettingsBuilder withPlacementIds(List<String> param1List);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\ads\AudienceNetworkAds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */