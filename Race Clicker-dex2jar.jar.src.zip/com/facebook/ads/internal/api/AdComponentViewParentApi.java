package com.facebook.ads.internal.api;

import android.view.View;

public interface AdComponentViewParentApi extends AdComponentView {
  void bringChildToFront(View paramView);
  
  void onAttachedToWindow();
  
  void onDetachedFromWindow();
  
  void onMeasure(int paramInt1, int paramInt2);
  
  void onVisibilityChanged(View paramView, int paramInt);
  
  void setMeasuredDimension(int paramInt1, int paramInt2);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\ads\internal\api\AdComponentViewParentApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */