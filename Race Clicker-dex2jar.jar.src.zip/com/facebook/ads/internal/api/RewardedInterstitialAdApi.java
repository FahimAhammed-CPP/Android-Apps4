package com.facebook.ads.internal.api;

import com.facebook.ads.ExtraHints;
import com.facebook.ads.FullScreenAd;
import com.facebook.ads.RewardedInterstitialAd;

public interface RewardedInterstitialAdApi extends FullScreenAd {
  RewardedInterstitialAd.RewardedInterstitialAdLoadConfigBuilder buildLoadAdConfig();
  
  RewardedInterstitialAd.RewardedInterstitialAdShowConfigBuilder buildShowAdConfig();
  
  void destroy();
  
  String getPlacementId();
  
  int getVideoDuration();
  
  boolean isAdLoaded();
  
  void loadAd();
  
  void loadAd(RewardedInterstitialAd.RewardedInterstitialLoadAdConfig paramRewardedInterstitialLoadAdConfig);
  
  void registerAdCompanionView(AdCompanionView paramAdCompanionView);
  
  @Deprecated
  void setExtraHints(ExtraHints paramExtraHints);
  
  boolean show();
  
  boolean show(RewardedInterstitialAd.RewardedInterstitialShowAdConfig paramRewardedInterstitialShowAdConfig);
  
  void unregisterAdCompanionView();
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\ads\internal\api\RewardedInterstitialAdApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */