package com.facebook;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.IntCompanionObject;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.Charsets;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(d1 = {"\000\\\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\007\n\002\020\t\n\002\b\t\n\002\020\036\n\002\b\002\n\002\020$\n\002\020\b\n\002\b\006\n\002\030\002\n\002\b\023\n\002\020\"\n\002\b\b\n\002\020\013\n\000\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\005\030\000 M2\0020\001:\001MB\027\b\027\022\006\020\002\032\0020\003\022\006\020\004\032\0020\003¢\006\002\020\005B\002\b\027\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\b\032\0020\003\022\006\020\t\032\0020\003\022\006\020\n\032\0020\013\022\006\020\f\032\0020\013\022\006\020\r\032\0020\003\022\n\b\002\020\016\032\004\030\0010\003\022\n\b\002\020\017\032\004\030\0010\003\022\n\b\002\020\020\032\004\030\0010\003\022\n\b\002\020\021\032\004\030\0010\003\022\n\b\002\020\022\032\004\030\0010\003\022\n\b\002\020\023\032\004\030\0010\003\022\020\b\002\020\024\032\n\022\004\022\0020\003\030\0010\025\022\n\b\002\020\026\032\004\030\0010\003\022\026\b\002\020\027\032\020\022\004\022\0020\003\022\004\022\0020\031\030\0010\030\022\026\b\002\020\032\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030\022\026\b\002\020\033\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030\022\n\b\002\020\034\032\004\030\0010\003\022\n\b\002\020\035\032\004\030\0010\003¢\006\002\020\036B\017\b\020\022\006\020\037\032\0020 ¢\006\002\020!J\b\020;\032\0020\031H\026J\023\020<\032\0020=2\b\020>\032\004\030\0010?H\002J\b\020@\032\0020\031H\026J\030\020A\032\0020=2\006\020B\032\0020C2\006\020\004\032\0020\003H\002J\b\020D\032\0020\003H\007J\r\020E\032\0020CH\001¢\006\002\bFJ\b\020G\032\0020\003H\026J\030\020H\032\0020I2\006\020J\032\0020 2\006\020K\032\0020\031H\026J\026\020L\032\004\030\0010\003*\0020C2\006\020\016\032\0020\003H\002R\021\020\b\032\0020\003¢\006\b\n\000\032\004\b\"\020#R\023\020\022\032\004\030\0010\003¢\006\b\n\000\032\004\b$\020#R\021\020\n\032\0020\013¢\006\b\n\000\032\004\b%\020&R\023\020\021\032\004\030\0010\003¢\006\b\n\000\032\004\b'\020#R\023\020\017\032\004\030\0010\003¢\006\b\n\000\032\004\b(\020#R\021\020\f\032\0020\013¢\006\b\n\000\032\004\b)\020&R\021\020\007\032\0020\003¢\006\b\n\000\032\004\b*\020#R\021\020\006\032\0020\003¢\006\b\n\000\032\004\b+\020#R\023\020\020\032\004\030\0010\003¢\006\b\n\000\032\004\b,\020#R\023\020\016\032\004\030\0010\003¢\006\b\n\000\032\004\b-\020#R\021\020\t\032\0020\003¢\006\b\n\000\032\004\b.\020#R\023\020\023\032\004\030\0010\003¢\006\b\n\000\032\004\b/\020#R\021\020\r\032\0020\003¢\006\b\n\000\032\004\b0\020#R\037\020\027\032\020\022\004\022\0020\003\022\004\022\0020\031\030\0010\030¢\006\b\n\000\032\004\b1\0202R\023\020\026\032\004\030\0010\003¢\006\b\n\000\032\004\b3\020#R\031\020\024\032\n\022\004\022\0020\003\030\00104¢\006\b\n\000\032\004\b5\0206R\023\020\034\032\004\030\0010\003¢\006\b\n\000\032\004\b7\020#R\037\020\032\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030¢\006\b\n\000\032\004\b8\0202R\023\020\035\032\004\030\0010\003¢\006\b\n\000\032\004\b9\020#R\037\020\033\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030¢\006\b\n\000\032\004\b:\0202¨\006N"}, d2 = {"Lcom/facebook/AuthenticationTokenClaims;", "Landroid/os/Parcelable;", "encodedClaims", "", "expectedNonce", "(Ljava/lang/String;Ljava/lang/String;)V", "jti", "iss", "aud", "nonce", "exp", "", "iat", "sub", "name", "givenName", "middleName", "familyName", "email", "picture", "userFriends", "", "userBirthday", "userAgeRange", "", "", "userHometown", "userLocation", "userGender", "userLink", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Collection;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V", "parcel", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "getAud", "()Ljava/lang/String;", "getEmail", "getExp", "()J", "getFamilyName", "getGivenName", "getIat", "getIss", "getJti", "getMiddleName", "getName", "getNonce", "getPicture", "getSub", "getUserAgeRange", "()Ljava/util/Map;", "getUserBirthday", "", "getUserFriends", "()Ljava/util/Set;", "getUserGender", "getUserHometown", "getUserLink", "getUserLocation", "describeContents", "equals", "", "other", "", "hashCode", "isValidClaims", "claimsJson", "Lorg/json/JSONObject;", "toEnCodedString", "toJSONObject", "toJSONObject$facebook_core_release", "toString", "writeToParcel", "", "dest", "flags", "getNullableString", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AuthenticationTokenClaims implements Parcelable {
  public static final Parcelable.Creator<AuthenticationTokenClaims> CREATOR;
  
  public static final Companion Companion = new Companion(null);
  
  public static final long MAX_TIME_SINCE_TOKEN_ISSUED = 600000L;
  
  private final String aud;
  
  private final String email;
  
  private final long exp;
  
  private final String familyName;
  
  private final String givenName;
  
  private final long iat;
  
  private final String iss;
  
  private final String jti;
  
  private final String middleName;
  
  private final String name;
  
  private final String nonce;
  
  private final String picture;
  
  private final String sub;
  
  private final Map<String, Integer> userAgeRange;
  
  private final String userBirthday;
  
  private final Set<String> userFriends;
  
  private final String userGender;
  
  private final Map<String, String> userHometown;
  
  private final String userLink;
  
  private final Map<String, String> userLocation;
  
  static {
    CREATOR = new AuthenticationTokenClaims$Companion$CREATOR$1();
  }
  
  public AuthenticationTokenClaims(Parcel paramParcel) {
    String str = paramParcel.readString();
    Validate.notNullOrEmpty(str, "jti");
    if (str != null) {
      this.jti = str;
      str = paramParcel.readString();
      Validate.notNullOrEmpty(str, "iss");
      if (str != null) {
        this.iss = str;
        str = paramParcel.readString();
        Validate.notNullOrEmpty(str, "aud");
        if (str != null) {
          this.aud = str;
          str = paramParcel.readString();
          Validate.notNullOrEmpty(str, "nonce");
          if (str != null) {
            this.nonce = str;
            this.exp = paramParcel.readLong();
            this.iat = paramParcel.readLong();
            str = paramParcel.readString();
            Validate.notNullOrEmpty(str, "sub");
            if (str != null) {
              this.sub = str;
              this.name = paramParcel.readString();
              this.givenName = paramParcel.readString();
              this.middleName = paramParcel.readString();
              this.familyName = paramParcel.readString();
              this.email = paramParcel.readString();
              this.picture = paramParcel.readString();
              ArrayList<? extends String> arrayList = new ArrayList();
              paramParcel.readStringList(arrayList);
              this.userFriends = Collections.unmodifiableSet(new HashSet<String>(arrayList));
              this.userBirthday = paramParcel.readString();
              HashMap<? extends String, ? extends Integer> hashMap1 = paramParcel.readHashMap(IntCompanionObject.INSTANCE.getClass().getClassLoader());
              boolean bool = hashMap1 instanceof HashMap;
              HashMap hashMap = null;
              if (!bool)
                hashMap1 = null; 
              this.userAgeRange = Collections.unmodifiableMap(hashMap1);
              HashMap<? extends String, ? extends Integer> hashMap2 = paramParcel.readHashMap(StringCompanionObject.INSTANCE.getClass().getClassLoader());
              hashMap1 = hashMap2;
              if (!(hashMap2 instanceof HashMap))
                hashMap1 = null; 
              this.userHometown = Collections.unmodifiableMap(hashMap1);
              hashMap1 = paramParcel.readHashMap(StringCompanionObject.INSTANCE.getClass().getClassLoader());
              if (!(hashMap1 instanceof HashMap))
                hashMap1 = hashMap; 
              this.userLocation = Collections.unmodifiableMap(hashMap1);
              this.userGender = paramParcel.readString();
              this.userLink = paramParcel.readString();
              return;
            } 
            throw (Throwable)new IllegalStateException("Required value was null.".toString());
          } 
          throw (Throwable)new IllegalStateException("Required value was null.".toString());
        } 
        throw (Throwable)new IllegalStateException("Required value was null.".toString());
      } 
      throw (Throwable)new IllegalStateException("Required value was null.".toString());
    } 
    throw (Throwable)new IllegalStateException("Required value was null.".toString());
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2) {
    Validate.notEmpty(paramString1, "encodedClaims");
    byte[] arrayOfByte = Base64.decode(paramString1, 0);
    Intrinsics.checkNotNullExpressionValue(arrayOfByte, "decodedBytes");
    JSONObject jSONObject = new JSONObject(new String(arrayOfByte, Charsets.UTF_8));
    if (isValidClaims(jSONObject, paramString2)) {
      Set<?> set;
      Map<?, ?> map3;
      Map<?, ?> map2;
      String str1;
      Map<?, ?> map1;
      String str2 = jSONObject.getString("jti");
      Intrinsics.checkNotNullExpressionValue(str2, "jsonObj.getString(\"jti\")");
      this.jti = str2;
      str2 = jSONObject.getString("iss");
      Intrinsics.checkNotNullExpressionValue(str2, "jsonObj.getString(\"iss\")");
      this.iss = str2;
      str2 = jSONObject.getString("aud");
      Intrinsics.checkNotNullExpressionValue(str2, "jsonObj.getString(\"aud\")");
      this.aud = str2;
      str2 = jSONObject.getString("nonce");
      Intrinsics.checkNotNullExpressionValue(str2, "jsonObj.getString(\"nonce\")");
      this.nonce = str2;
      this.exp = jSONObject.getLong("exp");
      this.iat = jSONObject.getLong("iat");
      str2 = jSONObject.getString("sub");
      Intrinsics.checkNotNullExpressionValue(str2, "jsonObj.getString(\"sub\")");
      this.sub = str2;
      this.name = getNullableString(jSONObject, "name");
      this.givenName = getNullableString(jSONObject, "givenName");
      this.middleName = getNullableString(jSONObject, "middleName");
      this.familyName = getNullableString(jSONObject, "familyName");
      this.email = getNullableString(jSONObject, "email");
      this.picture = getNullableString(jSONObject, "picture");
      JSONArray jSONArray = jSONObject.optJSONArray("userFriends");
      paramString2 = null;
      if (jSONArray == null) {
        jSONArray = null;
      } else {
        set = Collections.unmodifiableSet(Utility.jsonArrayToSet(jSONArray));
      } 
      this.userFriends = (Set)set;
      this.userBirthday = getNullableString(jSONObject, "userBirthday");
      JSONObject jSONObject3 = jSONObject.optJSONObject("userAgeRange");
      if (jSONObject3 == null) {
        jSONObject3 = null;
      } else {
        map3 = Collections.unmodifiableMap(Utility.convertJSONObjectToHashMap(jSONObject3));
      } 
      this.userAgeRange = (Map)map3;
      JSONObject jSONObject2 = jSONObject.optJSONObject("userHometown");
      if (jSONObject2 == null) {
        jSONObject2 = null;
      } else {
        map2 = Collections.unmodifiableMap(Utility.convertJSONObjectToStringMap(jSONObject2));
      } 
      this.userHometown = (Map)map2;
      JSONObject jSONObject1 = jSONObject.optJSONObject("userLocation");
      if (jSONObject1 == null) {
        str1 = paramString2;
      } else {
        map1 = Collections.unmodifiableMap(Utility.convertJSONObjectToStringMap((JSONObject)str1));
      } 
      this.userLocation = (Map)map1;
      this.userGender = getNullableString(jSONObject, "userGender");
      this.userLink = getNullableString(jSONObject, "userLink");
      return;
    } 
    throw (Throwable)new IllegalArgumentException("Invalid claims".toString());
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, null, null, null, null, null, null, null, null, null, null, null, null, null, 1048448, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, null, null, null, null, null, null, null, null, null, null, null, null, 1048320, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, null, null, null, null, null, null, null, null, null, null, null, 1048064, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, null, null, null, null, null, null, null, null, null, null, 1047552, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, null, null, null, null, null, null, null, null, null, 1046528, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, null, null, null, null, null, null, null, null, 1044480, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, null, null, null, null, null, null, null, 1040384, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, null, null, null, null, null, null, 1032192, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, null, null, null, null, null, 1015808, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, null, null, null, null, 983040, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, null, null, null, 917504, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, paramMap2, null, null, 786432, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2, String paramString13) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, paramMap2, paramString13, null, 524288, null);
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2, String paramString13, String paramString14) {
    Map<?, ?> map;
    Validate.notEmpty(paramString1, "jti");
    Validate.notEmpty(paramString2, "iss");
    Validate.notEmpty(paramString3, "aud");
    Validate.notEmpty(paramString4, "nonce");
    Validate.notEmpty(paramString5, "sub");
    this.jti = paramString1;
    this.iss = paramString2;
    this.aud = paramString3;
    this.nonce = paramString4;
    this.exp = paramLong1;
    this.iat = paramLong2;
    this.sub = paramString5;
    this.name = paramString6;
    this.givenName = paramString7;
    this.middleName = paramString8;
    this.familyName = paramString9;
    this.email = paramString10;
    this.picture = paramString11;
    paramString2 = null;
    if (paramCollection != null) {
      Set<?> set = Collections.unmodifiableSet(new HashSet(paramCollection));
    } else {
      paramString1 = null;
    } 
    this.userFriends = (Set<String>)paramString1;
    this.userBirthday = paramString12;
    if (paramMap != null) {
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap));
    } else {
      paramString1 = null;
    } 
    this.userAgeRange = (Map<String, Integer>)paramString1;
    if (paramMap1 != null) {
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap1));
    } else {
      paramString1 = null;
    } 
    this.userHometown = (Map<String, String>)paramString1;
    paramString1 = paramString2;
    if (paramMap2 != null)
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap2)); 
    this.userLocation = (Map)map;
    this.userGender = paramString13;
    this.userLink = paramString14;
  }
  
  private final String getNullableString(JSONObject paramJSONObject, String paramString) {
    return paramJSONObject.has(paramString) ? paramJSONObject.getString(paramString) : null;
  }
  
  private final boolean isValidClaims(JSONObject paramJSONObject, String paramString) {
    boolean bool;
    if (paramJSONObject == null)
      return false; 
    String str = paramJSONObject.optString("jti");
    Intrinsics.checkNotNullExpressionValue(str, "jti");
    if (str.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return false; 
    try {
      str = paramJSONObject.optString("iss");
      Intrinsics.checkNotNullExpressionValue(str, "iss");
      if (str.length() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        boolean bool1 = Intrinsics.areEqual((new URL(str)).getHost(), "facebook.com");
        if ((bool1 ^ true) != 0)
          return false; 
        str = paramJSONObject.optString("aud");
        Intrinsics.checkNotNullExpressionValue(str, "aud");
        if (str.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          if ((Intrinsics.areEqual(str, FacebookSdk.getApplicationId()) ^ true) != 0)
            return false; 
          long l1 = paramJSONObject.optLong("exp");
          long l2 = 1000L;
          Date date = new Date(l1 * l2);
          if ((new Date()).after(date))
            return false; 
          date = new Date(paramJSONObject.optLong("iat") * l2 + 600000L);
          if ((new Date()).after(date))
            return false; 
          String str2 = paramJSONObject.optString("sub");
          Intrinsics.checkNotNullExpressionValue(str2, "sub");
          if (str2.length() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool)
            return false; 
          String str1 = paramJSONObject.optString("nonce");
          Intrinsics.checkNotNullExpressionValue(str1, "nonce");
          if (str1.length() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          if (!bool)
            return !((Intrinsics.areEqual(str1, paramString) ^ true) != 0); 
        } 
      } 
      return false;
    } catch (MalformedURLException malformedURLException) {
      return false;
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    AuthenticationTokenClaims authenticationTokenClaims = this;
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof AuthenticationTokenClaims))
      return false; 
    String str = this.jti;
    paramObject = paramObject;
    return (Intrinsics.areEqual(str, ((AuthenticationTokenClaims)paramObject).jti) && Intrinsics.areEqual(this.iss, ((AuthenticationTokenClaims)paramObject).iss) && Intrinsics.areEqual(this.aud, ((AuthenticationTokenClaims)paramObject).aud) && Intrinsics.areEqual(this.nonce, ((AuthenticationTokenClaims)paramObject).nonce) && this.exp == ((AuthenticationTokenClaims)paramObject).exp && this.iat == ((AuthenticationTokenClaims)paramObject).iat && Intrinsics.areEqual(this.sub, ((AuthenticationTokenClaims)paramObject).sub) && Intrinsics.areEqual(this.name, ((AuthenticationTokenClaims)paramObject).name) && Intrinsics.areEqual(this.givenName, ((AuthenticationTokenClaims)paramObject).givenName) && Intrinsics.areEqual(this.middleName, ((AuthenticationTokenClaims)paramObject).middleName) && Intrinsics.areEqual(this.familyName, ((AuthenticationTokenClaims)paramObject).familyName) && Intrinsics.areEqual(this.email, ((AuthenticationTokenClaims)paramObject).email) && Intrinsics.areEqual(this.picture, ((AuthenticationTokenClaims)paramObject).picture) && Intrinsics.areEqual(this.userFriends, ((AuthenticationTokenClaims)paramObject).userFriends) && Intrinsics.areEqual(this.userBirthday, ((AuthenticationTokenClaims)paramObject).userBirthday) && Intrinsics.areEqual(this.userAgeRange, ((AuthenticationTokenClaims)paramObject).userAgeRange) && Intrinsics.areEqual(this.userHometown, ((AuthenticationTokenClaims)paramObject).userHometown) && Intrinsics.areEqual(this.userLocation, ((AuthenticationTokenClaims)paramObject).userLocation) && Intrinsics.areEqual(this.userGender, ((AuthenticationTokenClaims)paramObject).userGender) && Intrinsics.areEqual(this.userLink, ((AuthenticationTokenClaims)paramObject).userLink));
  }
  
  public final String getAud() {
    return this.aud;
  }
  
  public final String getEmail() {
    return this.email;
  }
  
  public final long getExp() {
    return this.exp;
  }
  
  public final String getFamilyName() {
    return this.familyName;
  }
  
  public final String getGivenName() {
    return this.givenName;
  }
  
  public final long getIat() {
    return this.iat;
  }
  
  public final String getIss() {
    return this.iss;
  }
  
  public final String getJti() {
    return this.jti;
  }
  
  public final String getMiddleName() {
    return this.middleName;
  }
  
  public final String getName() {
    return this.name;
  }
  
  public final String getNonce() {
    return this.nonce;
  }
  
  public final String getPicture() {
    return this.picture;
  }
  
  public final String getSub() {
    return this.sub;
  }
  
  public final Map<String, Integer> getUserAgeRange() {
    return this.userAgeRange;
  }
  
  public final String getUserBirthday() {
    return this.userBirthday;
  }
  
  public final Set<String> getUserFriends() {
    return this.userFriends;
  }
  
  public final String getUserGender() {
    return this.userGender;
  }
  
  public final Map<String, String> getUserHometown() {
    return this.userHometown;
  }
  
  public final String getUserLink() {
    return this.userLink;
  }
  
  public final Map<String, String> getUserLocation() {
    return this.userLocation;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    byte b5;
    byte b6;
    byte b7;
    byte b8;
    byte b9;
    byte b10;
    byte b11;
    byte b12;
    int j = this.jti.hashCode();
    int k = this.iss.hashCode();
    int m = this.aud.hashCode();
    int n = this.nonce.hashCode();
    int i1 = Long.valueOf(this.exp).hashCode();
    int i2 = Long.valueOf(this.iat).hashCode();
    int i3 = this.sub.hashCode();
    String str3 = this.name;
    int i = 0;
    if (str3 != null) {
      b1 = str3.hashCode();
    } else {
      b1 = 0;
    } 
    str3 = this.givenName;
    if (str3 != null) {
      b2 = str3.hashCode();
    } else {
      b2 = 0;
    } 
    str3 = this.middleName;
    if (str3 != null) {
      b3 = str3.hashCode();
    } else {
      b3 = 0;
    } 
    str3 = this.familyName;
    if (str3 != null) {
      b4 = str3.hashCode();
    } else {
      b4 = 0;
    } 
    str3 = this.email;
    if (str3 != null) {
      b5 = str3.hashCode();
    } else {
      b5 = 0;
    } 
    str3 = this.picture;
    if (str3 != null) {
      b6 = str3.hashCode();
    } else {
      b6 = 0;
    } 
    Set<String> set = this.userFriends;
    if (set != null) {
      b7 = set.hashCode();
    } else {
      b7 = 0;
    } 
    String str2 = this.userBirthday;
    if (str2 != null) {
      b8 = str2.hashCode();
    } else {
      b8 = 0;
    } 
    Map<String, Integer> map1 = this.userAgeRange;
    if (map1 != null) {
      b9 = map1.hashCode();
    } else {
      b9 = 0;
    } 
    Map<String, String> map = this.userHometown;
    if (map != null) {
      b10 = map.hashCode();
    } else {
      b10 = 0;
    } 
    map = this.userLocation;
    if (map != null) {
      b11 = map.hashCode();
    } else {
      b11 = 0;
    } 
    String str1 = this.userGender;
    if (str1 != null) {
      b12 = str1.hashCode();
    } else {
      b12 = 0;
    } 
    str1 = this.userLink;
    if (str1 != null)
      i = str1.hashCode(); 
    return (((((((((((((((((((527 + j) * 31 + k) * 31 + m) * 31 + n) * 31 + i1) * 31 + i2) * 31 + i3) * 31 + b1) * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + b8) * 31 + b9) * 31 + b10) * 31 + b11) * 31 + b12) * 31 + i;
  }
  
  public final String toEnCodedString() {
    String str = toString();
    Charset charset = Charsets.UTF_8;
    if (str != null) {
      byte[] arrayOfByte = str.getBytes(charset);
      Intrinsics.checkNotNullExpressionValue(arrayOfByte, "(this as java.lang.String).getBytes(charset)");
      String str1 = Base64.encodeToString(arrayOfByte, 0);
      Intrinsics.checkNotNullExpressionValue(str1, "Base64.encodeToString(cl…eArray(), Base64.DEFAULT)");
      return str1;
    } 
    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
  }
  
  public final JSONObject toJSONObject$facebook_core_release() {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("jti", this.jti);
    jSONObject.put("iss", this.iss);
    jSONObject.put("aud", this.aud);
    jSONObject.put("nonce", this.nonce);
    jSONObject.put("exp", this.exp);
    jSONObject.put("iat", this.iat);
    String str3 = this.sub;
    if (str3 != null)
      jSONObject.put("sub", str3); 
    str3 = this.name;
    if (str3 != null)
      jSONObject.put("name", str3); 
    str3 = this.givenName;
    if (str3 != null)
      jSONObject.put("givenName", str3); 
    str3 = this.middleName;
    if (str3 != null)
      jSONObject.put("middleName", str3); 
    str3 = this.familyName;
    if (str3 != null)
      jSONObject.put("familyName", str3); 
    str3 = this.email;
    if (str3 != null)
      jSONObject.put("email", str3); 
    str3 = this.picture;
    if (str3 != null)
      jSONObject.put("picture", str3); 
    Set<String> set = this.userFriends;
    if (set != null && (set.isEmpty() ^ true) != 0)
      jSONObject.put("userFriends", new JSONArray(this.userFriends)); 
    String str2 = this.userBirthday;
    if (str2 != null)
      jSONObject.put("userBirthday", str2); 
    Map<String, Integer> map1 = this.userAgeRange;
    if (map1 != null && (map1.isEmpty() ^ true) != 0)
      jSONObject.put("userAgeRange", new JSONObject(this.userAgeRange)); 
    Map<String, String> map = this.userHometown;
    if (map != null && (map.isEmpty() ^ true) != 0)
      jSONObject.put("userHometown", new JSONObject(this.userHometown)); 
    map = this.userLocation;
    if (map != null && (map.isEmpty() ^ true) != 0)
      jSONObject.put("userLocation", new JSONObject(this.userLocation)); 
    String str1 = this.userGender;
    if (str1 != null)
      jSONObject.put("userGender", str1); 
    str1 = this.userLink;
    if (str1 != null)
      jSONObject.put("userLink", str1); 
    return jSONObject;
  }
  
  public String toString() {
    String str = toJSONObject$facebook_core_release().toString();
    Intrinsics.checkNotNullExpressionValue(str, "claimsJsonObject.toString()");
    return str;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    Intrinsics.checkNotNullParameter(paramParcel, "dest");
    paramParcel.writeString(this.jti);
    paramParcel.writeString(this.iss);
    paramParcel.writeString(this.aud);
    paramParcel.writeString(this.nonce);
    paramParcel.writeLong(this.exp);
    paramParcel.writeLong(this.iat);
    paramParcel.writeString(this.sub);
    paramParcel.writeString(this.name);
    paramParcel.writeString(this.givenName);
    paramParcel.writeString(this.middleName);
    paramParcel.writeString(this.familyName);
    paramParcel.writeString(this.email);
    paramParcel.writeString(this.picture);
    if (this.userFriends == null) {
      paramParcel.writeStringList(null);
    } else {
      paramParcel.writeStringList(new ArrayList<String>(this.userFriends));
    } 
    paramParcel.writeString(this.userBirthday);
    paramParcel.writeMap(this.userAgeRange);
    paramParcel.writeMap(this.userHometown);
    paramParcel.writeMap(this.userLocation);
    paramParcel.writeString(this.userGender);
    paramParcel.writeString(this.userLink);
  }
  
  @Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\020\t\n\002\b\002\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\025\020\b\032\0020\0052\006\020\t\032\0020\nH\000¢\006\002\b\013R\026\020\003\032\b\022\004\022\0020\0050\0048\006X\004¢\006\002\n\000R\016\020\006\032\0020\007XT¢\006\002\n\000¨\006\f"}, d2 = {"Lcom/facebook/AuthenticationTokenClaims$Companion;", "", "()V", "CREATOR", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/AuthenticationTokenClaims;", "MAX_TIME_SINCE_TOKEN_ISSUED", "", "createFromJSONObject", "jsonObject", "Lorg/json/JSONObject;", "createFromJSONObject$facebook_core_release", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    public final AuthenticationTokenClaims createFromJSONObject$facebook_core_release(JSONObject param1JSONObject) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'jsonObject'
      //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_1
      //   7: ldc 'jti'
      //   9: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   12: astore #19
      //   14: aload_1
      //   15: ldc 'iss'
      //   17: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   20: astore #20
      //   22: aload_1
      //   23: ldc 'aud'
      //   25: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   28: astore #21
      //   30: aload_1
      //   31: ldc 'nonce'
      //   33: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   36: astore #22
      //   38: aload_1
      //   39: ldc 'exp'
      //   41: invokevirtual getLong : (Ljava/lang/String;)J
      //   44: lstore #4
      //   46: aload_1
      //   47: ldc 'iat'
      //   49: invokevirtual getLong : (Ljava/lang/String;)J
      //   52: lstore #6
      //   54: aload_1
      //   55: ldc 'sub'
      //   57: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   60: astore #23
      //   62: aload_1
      //   63: ldc 'name'
      //   65: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   68: astore #13
      //   70: aload_1
      //   71: ldc 'givenName'
      //   73: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   76: astore #8
      //   78: aload_1
      //   79: ldc 'middleName'
      //   81: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   84: astore #9
      //   86: aload_1
      //   87: ldc 'familyName'
      //   89: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   92: astore #10
      //   94: aload_1
      //   95: ldc 'email'
      //   97: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   100: astore #11
      //   102: aload_1
      //   103: ldc 'picture'
      //   105: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   108: astore #12
      //   110: aload_1
      //   111: ldc 'userFriends'
      //   113: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
      //   116: astore #25
      //   118: aload_1
      //   119: ldc 'userBirthday'
      //   121: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   124: astore #14
      //   126: aload_1
      //   127: ldc 'userAgeRange'
      //   129: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
      //   132: astore #24
      //   134: aload_1
      //   135: ldc 'userHometown'
      //   137: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
      //   140: astore #15
      //   142: aload_1
      //   143: ldc 'userLocation'
      //   145: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
      //   148: astore #16
      //   150: aload_1
      //   151: ldc 'userGender'
      //   153: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   156: astore #17
      //   158: aload_1
      //   159: ldc 'userLink'
      //   161: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   164: astore #18
      //   166: aload #19
      //   168: ldc 'jti'
      //   170: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   173: aload #20
      //   175: ldc 'iss'
      //   177: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   180: aload #21
      //   182: ldc 'aud'
      //   184: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   187: aload #22
      //   189: ldc 'nonce'
      //   191: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   194: aload #23
      //   196: ldc 'sub'
      //   198: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   201: aload #13
      //   203: checkcast java/lang/CharSequence
      //   206: astore_1
      //   207: iconst_0
      //   208: istore_3
      //   209: aload_1
      //   210: ifnull -> 230
      //   213: aload_1
      //   214: invokeinterface length : ()I
      //   219: ifne -> 225
      //   222: goto -> 230
      //   225: iconst_0
      //   226: istore_2
      //   227: goto -> 232
      //   230: iconst_1
      //   231: istore_2
      //   232: aload #13
      //   234: astore_1
      //   235: iload_2
      //   236: ifeq -> 241
      //   239: aconst_null
      //   240: astore_1
      //   241: aload #8
      //   243: checkcast java/lang/CharSequence
      //   246: astore #13
      //   248: aload #13
      //   250: ifnull -> 271
      //   253: aload #13
      //   255: invokeinterface length : ()I
      //   260: ifne -> 266
      //   263: goto -> 271
      //   266: iconst_0
      //   267: istore_2
      //   268: goto -> 273
      //   271: iconst_1
      //   272: istore_2
      //   273: iload_2
      //   274: ifeq -> 283
      //   277: aconst_null
      //   278: astore #8
      //   280: goto -> 283
      //   283: aload #9
      //   285: checkcast java/lang/CharSequence
      //   288: astore #13
      //   290: aload #13
      //   292: ifnull -> 313
      //   295: aload #13
      //   297: invokeinterface length : ()I
      //   302: ifne -> 308
      //   305: goto -> 313
      //   308: iconst_0
      //   309: istore_2
      //   310: goto -> 315
      //   313: iconst_1
      //   314: istore_2
      //   315: iload_2
      //   316: ifeq -> 325
      //   319: aconst_null
      //   320: astore #9
      //   322: goto -> 325
      //   325: aload #10
      //   327: checkcast java/lang/CharSequence
      //   330: astore #13
      //   332: aload #13
      //   334: ifnull -> 355
      //   337: aload #13
      //   339: invokeinterface length : ()I
      //   344: ifne -> 350
      //   347: goto -> 355
      //   350: iconst_0
      //   351: istore_2
      //   352: goto -> 357
      //   355: iconst_1
      //   356: istore_2
      //   357: iload_2
      //   358: ifeq -> 367
      //   361: aconst_null
      //   362: astore #10
      //   364: goto -> 367
      //   367: aload #11
      //   369: checkcast java/lang/CharSequence
      //   372: astore #13
      //   374: aload #13
      //   376: ifnull -> 397
      //   379: aload #13
      //   381: invokeinterface length : ()I
      //   386: ifne -> 392
      //   389: goto -> 397
      //   392: iconst_0
      //   393: istore_2
      //   394: goto -> 399
      //   397: iconst_1
      //   398: istore_2
      //   399: iload_2
      //   400: ifeq -> 406
      //   403: aconst_null
      //   404: astore #11
      //   406: aload #12
      //   408: checkcast java/lang/CharSequence
      //   411: astore #13
      //   413: aload #13
      //   415: ifnull -> 436
      //   418: aload #13
      //   420: invokeinterface length : ()I
      //   425: ifne -> 431
      //   428: goto -> 436
      //   431: iconst_0
      //   432: istore_2
      //   433: goto -> 438
      //   436: iconst_1
      //   437: istore_2
      //   438: iload_2
      //   439: ifeq -> 445
      //   442: aconst_null
      //   443: astore #12
      //   445: aload #25
      //   447: ifnonnull -> 456
      //   450: aconst_null
      //   451: astore #13
      //   453: goto -> 463
      //   456: aload #25
      //   458: invokestatic jsonArrayToStringList : (Lorg/json/JSONArray;)Ljava/util/List;
      //   461: astore #13
      //   463: aload #13
      //   465: checkcast java/util/Collection
      //   468: astore #25
      //   470: aload #14
      //   472: checkcast java/lang/CharSequence
      //   475: astore #13
      //   477: aload #13
      //   479: ifnull -> 500
      //   482: aload #13
      //   484: invokeinterface length : ()I
      //   489: ifne -> 495
      //   492: goto -> 500
      //   495: iconst_0
      //   496: istore_2
      //   497: goto -> 502
      //   500: iconst_1
      //   501: istore_2
      //   502: aload #14
      //   504: astore #13
      //   506: iload_2
      //   507: ifeq -> 513
      //   510: aconst_null
      //   511: astore #13
      //   513: aload #24
      //   515: ifnonnull -> 524
      //   518: aconst_null
      //   519: astore #14
      //   521: goto -> 531
      //   524: aload #24
      //   526: invokestatic convertJSONObjectToHashMap : (Lorg/json/JSONObject;)Ljava/util/Map;
      //   529: astore #14
      //   531: aload #15
      //   533: ifnonnull -> 542
      //   536: aconst_null
      //   537: astore #15
      //   539: goto -> 549
      //   542: aload #15
      //   544: invokestatic convertJSONObjectToStringMap : (Lorg/json/JSONObject;)Ljava/util/Map;
      //   547: astore #15
      //   549: aload #16
      //   551: ifnonnull -> 560
      //   554: aconst_null
      //   555: astore #16
      //   557: goto -> 567
      //   560: aload #16
      //   562: invokestatic convertJSONObjectToStringMap : (Lorg/json/JSONObject;)Ljava/util/Map;
      //   565: astore #16
      //   567: aload #17
      //   569: checkcast java/lang/CharSequence
      //   572: astore #24
      //   574: aload #24
      //   576: ifnull -> 597
      //   579: aload #24
      //   581: invokeinterface length : ()I
      //   586: ifne -> 592
      //   589: goto -> 597
      //   592: iconst_0
      //   593: istore_2
      //   594: goto -> 599
      //   597: iconst_1
      //   598: istore_2
      //   599: iload_2
      //   600: ifeq -> 606
      //   603: aconst_null
      //   604: astore #17
      //   606: aload #18
      //   608: checkcast java/lang/CharSequence
      //   611: astore #24
      //   613: aload #24
      //   615: ifnull -> 630
      //   618: iload_3
      //   619: istore_2
      //   620: aload #24
      //   622: invokeinterface length : ()I
      //   627: ifne -> 632
      //   630: iconst_1
      //   631: istore_2
      //   632: iload_2
      //   633: ifeq -> 639
      //   636: aconst_null
      //   637: astore #18
      //   639: new com/facebook/AuthenticationTokenClaims
      //   642: dup
      //   643: aload #19
      //   645: aload #20
      //   647: aload #21
      //   649: aload #22
      //   651: lload #4
      //   653: lload #6
      //   655: aload #23
      //   657: aload_1
      //   658: aload #8
      //   660: aload #9
      //   662: aload #10
      //   664: aload #11
      //   666: aload #12
      //   668: aload #25
      //   670: aload #13
      //   672: aload #14
      //   674: aload #15
      //   676: aload #16
      //   678: aload #17
      //   680: aload #18
      //   682: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Collection;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
      //   685: areturn
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\021\n\000\n\002\020\b\n\002\b\002*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\020\020\003\032\0020\0022\006\020\004\032\0020\005H\026J\035\020\006\032\n\022\006\022\004\030\0010\0020\0072\006\020\b\032\0020\tH\026¢\006\002\020\n¨\006\013"}, d2 = {"com/facebook/AuthenticationTokenClaims$Companion$CREATOR$1", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/AuthenticationTokenClaims;", "createFromParcel", "source", "Landroid/os/Parcel;", "newArray", "", "size", "", "(I)[Lcom/facebook/AuthenticationTokenClaims;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class AuthenticationTokenClaims$Companion$CREATOR$1 implements Parcelable.Creator<AuthenticationTokenClaims> {
    public AuthenticationTokenClaims createFromParcel(Parcel param1Parcel) {
      Intrinsics.checkNotNullParameter(param1Parcel, "source");
      return new AuthenticationTokenClaims(param1Parcel);
    }
    
    public AuthenticationTokenClaims[] newArray(int param1Int) {
      return new AuthenticationTokenClaims[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\AuthenticationTokenClaims.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */