package com.facebook.common;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130903040;
    
    public static final int actionBarItemBackground = 2130903041;
    
    public static final int actionBarPopupTheme = 2130903042;
    
    public static final int actionBarSize = 2130903043;
    
    public static final int actionBarSplitStyle = 2130903044;
    
    public static final int actionBarStyle = 2130903045;
    
    public static final int actionBarTabBarStyle = 2130903046;
    
    public static final int actionBarTabStyle = 2130903047;
    
    public static final int actionBarTabTextStyle = 2130903048;
    
    public static final int actionBarTheme = 2130903049;
    
    public static final int actionBarWidgetTheme = 2130903050;
    
    public static final int actionButtonStyle = 2130903051;
    
    public static final int actionDropDownStyle = 2130903052;
    
    public static final int actionLayout = 2130903053;
    
    public static final int actionMenuTextAppearance = 2130903054;
    
    public static final int actionMenuTextColor = 2130903055;
    
    public static final int actionModeBackground = 2130903056;
    
    public static final int actionModeCloseButtonStyle = 2130903057;
    
    public static final int actionModeCloseDrawable = 2130903058;
    
    public static final int actionModeCopyDrawable = 2130903059;
    
    public static final int actionModeCutDrawable = 2130903060;
    
    public static final int actionModeFindDrawable = 2130903061;
    
    public static final int actionModePasteDrawable = 2130903062;
    
    public static final int actionModePopupWindowStyle = 2130903063;
    
    public static final int actionModeSelectAllDrawable = 2130903064;
    
    public static final int actionModeShareDrawable = 2130903065;
    
    public static final int actionModeSplitBackground = 2130903066;
    
    public static final int actionModeStyle = 2130903067;
    
    public static final int actionModeWebSearchDrawable = 2130903068;
    
    public static final int actionOverflowButtonStyle = 2130903069;
    
    public static final int actionOverflowMenuStyle = 2130903070;
    
    public static final int actionProviderClass = 2130903071;
    
    public static final int actionViewClass = 2130903072;
    
    public static final int activityChooserViewStyle = 2130903073;
    
    public static final int alertDialogButtonGroupStyle = 2130903116;
    
    public static final int alertDialogCenterButtons = 2130903117;
    
    public static final int alertDialogStyle = 2130903118;
    
    public static final int alertDialogTheme = 2130903119;
    
    public static final int allowStacking = 2130903120;
    
    public static final int alpha = 2130903121;
    
    public static final int alphabeticModifiers = 2130903122;
    
    public static final int arrowHeadLength = 2130903123;
    
    public static final int arrowShaftLength = 2130903124;
    
    public static final int autoCompleteTextViewStyle = 2130903125;
    
    public static final int autoSizeMaxTextSize = 2130903126;
    
    public static final int autoSizeMinTextSize = 2130903127;
    
    public static final int autoSizePresetSizes = 2130903128;
    
    public static final int autoSizeStepGranularity = 2130903129;
    
    public static final int autoSizeTextType = 2130903130;
    
    public static final int background = 2130903131;
    
    public static final int backgroundSplit = 2130903132;
    
    public static final int backgroundStacked = 2130903133;
    
    public static final int backgroundTint = 2130903134;
    
    public static final int backgroundTintMode = 2130903135;
    
    public static final int barLength = 2130903136;
    
    public static final int borderlessButtonStyle = 2130903137;
    
    public static final int buttonBarButtonStyle = 2130903138;
    
    public static final int buttonBarNegativeButtonStyle = 2130903139;
    
    public static final int buttonBarNeutralButtonStyle = 2130903140;
    
    public static final int buttonBarPositiveButtonStyle = 2130903141;
    
    public static final int buttonBarStyle = 2130903142;
    
    public static final int buttonCompat = 2130903143;
    
    public static final int buttonGravity = 2130903144;
    
    public static final int buttonIconDimen = 2130903145;
    
    public static final int buttonPanelSideLayout = 2130903146;
    
    public static final int buttonStyle = 2130903148;
    
    public static final int buttonStyleSmall = 2130903149;
    
    public static final int buttonTint = 2130903150;
    
    public static final int buttonTintMode = 2130903151;
    
    public static final int cardBackgroundColor = 2130903152;
    
    public static final int cardCornerRadius = 2130903153;
    
    public static final int cardElevation = 2130903154;
    
    public static final int cardMaxElevation = 2130903155;
    
    public static final int cardPreventCornerOverlap = 2130903156;
    
    public static final int cardUseCompatPadding = 2130903157;
    
    public static final int cardViewStyle = 2130903158;
    
    public static final int checkboxStyle = 2130903159;
    
    public static final int checkedTextViewStyle = 2130903160;
    
    public static final int closeIcon = 2130903162;
    
    public static final int closeItemLayout = 2130903163;
    
    public static final int collapseContentDescription = 2130903164;
    
    public static final int collapseIcon = 2130903165;
    
    public static final int color = 2130903166;
    
    public static final int colorAccent = 2130903167;
    
    public static final int colorBackgroundFloating = 2130903168;
    
    public static final int colorButtonNormal = 2130903169;
    
    public static final int colorControlActivated = 2130903170;
    
    public static final int colorControlHighlight = 2130903171;
    
    public static final int colorControlNormal = 2130903172;
    
    public static final int colorError = 2130903173;
    
    public static final int colorPrimary = 2130903174;
    
    public static final int colorPrimaryDark = 2130903175;
    
    public static final int colorSwitchThumbNormal = 2130903177;
    
    public static final int com_facebook_auxiliary_view_position = 2130903178;
    
    public static final int com_facebook_foreground_color = 2130903180;
    
    public static final int com_facebook_horizontal_alignment = 2130903181;
    
    public static final int com_facebook_object_id = 2130903185;
    
    public static final int com_facebook_object_type = 2130903186;
    
    public static final int com_facebook_style = 2130903188;
    
    public static final int commitIcon = 2130903190;
    
    public static final int contentDescription = 2130903191;
    
    public static final int contentInsetEnd = 2130903192;
    
    public static final int contentInsetEndWithActions = 2130903193;
    
    public static final int contentInsetLeft = 2130903194;
    
    public static final int contentInsetRight = 2130903195;
    
    public static final int contentInsetStart = 2130903196;
    
    public static final int contentInsetStartWithNavigation = 2130903197;
    
    public static final int contentPadding = 2130903198;
    
    public static final int contentPaddingBottom = 2130903199;
    
    public static final int contentPaddingLeft = 2130903200;
    
    public static final int contentPaddingRight = 2130903201;
    
    public static final int contentPaddingTop = 2130903202;
    
    public static final int controlBackground = 2130903203;
    
    public static final int coordinatorLayoutStyle = 2130903204;
    
    public static final int customNavigationLayout = 2130903206;
    
    public static final int defaultQueryHint = 2130903207;
    
    public static final int dialogCornerRadius = 2130903208;
    
    public static final int dialogPreferredPadding = 2130903209;
    
    public static final int dialogTheme = 2130903210;
    
    public static final int displayOptions = 2130903211;
    
    public static final int divider = 2130903212;
    
    public static final int dividerHorizontal = 2130903213;
    
    public static final int dividerPadding = 2130903214;
    
    public static final int dividerVertical = 2130903215;
    
    public static final int drawableBottomCompat = 2130903216;
    
    public static final int drawableEndCompat = 2130903217;
    
    public static final int drawableLeftCompat = 2130903218;
    
    public static final int drawableRightCompat = 2130903219;
    
    public static final int drawableSize = 2130903220;
    
    public static final int drawableStartCompat = 2130903221;
    
    public static final int drawableTint = 2130903222;
    
    public static final int drawableTintMode = 2130903223;
    
    public static final int drawableTopCompat = 2130903224;
    
    public static final int drawerArrowStyle = 2130903225;
    
    public static final int dropDownListViewStyle = 2130903226;
    
    public static final int dropdownListPreferredItemHeight = 2130903227;
    
    public static final int editTextBackground = 2130903228;
    
    public static final int editTextColor = 2130903229;
    
    public static final int editTextStyle = 2130903230;
    
    public static final int elevation = 2130903231;
    
    public static final int expandActivityOverflowButtonDrawable = 2130903232;
    
    public static final int firstBaselineToTopHeight = 2130903238;
    
    public static final int font = 2130903239;
    
    public static final int fontFamily = 2130903240;
    
    public static final int fontProviderAuthority = 2130903241;
    
    public static final int fontProviderCerts = 2130903242;
    
    public static final int fontProviderFetchStrategy = 2130903243;
    
    public static final int fontProviderFetchTimeout = 2130903244;
    
    public static final int fontProviderPackage = 2130903245;
    
    public static final int fontProviderQuery = 2130903246;
    
    public static final int fontStyle = 2130903248;
    
    public static final int fontVariationSettings = 2130903249;
    
    public static final int fontWeight = 2130903250;
    
    public static final int gapBetweenBars = 2130903251;
    
    public static final int goIcon = 2130903252;
    
    public static final int height = 2130903253;
    
    public static final int hideOnContentScroll = 2130903254;
    
    public static final int homeAsUpIndicator = 2130903255;
    
    public static final int homeLayout = 2130903256;
    
    public static final int icon = 2130903257;
    
    public static final int iconTint = 2130903258;
    
    public static final int iconTintMode = 2130903259;
    
    public static final int iconifiedByDefault = 2130903260;
    
    public static final int imageButtonStyle = 2130903263;
    
    public static final int indeterminateProgressStyle = 2130903264;
    
    public static final int initialActivityCount = 2130903265;
    
    public static final int isLightTheme = 2130903266;
    
    public static final int itemPadding = 2130903267;
    
    public static final int keylines = 2130903268;
    
    public static final int lastBaselineToBottomHeight = 2130903270;
    
    public static final int layout = 2130903271;
    
    public static final int layout_anchor = 2130903273;
    
    public static final int layout_anchorGravity = 2130903274;
    
    public static final int layout_behavior = 2130903275;
    
    public static final int layout_dodgeInsetEdges = 2130903276;
    
    public static final int layout_insetEdge = 2130903277;
    
    public static final int layout_keyline = 2130903278;
    
    public static final int lineHeight = 2130903279;
    
    public static final int listChoiceBackgroundIndicator = 2130903280;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130903281;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130903282;
    
    public static final int listDividerAlertDialog = 2130903283;
    
    public static final int listItemLayout = 2130903284;
    
    public static final int listLayout = 2130903285;
    
    public static final int listMenuViewStyle = 2130903286;
    
    public static final int listPopupWindowStyle = 2130903287;
    
    public static final int listPreferredItemHeight = 2130903288;
    
    public static final int listPreferredItemHeightLarge = 2130903289;
    
    public static final int listPreferredItemHeightSmall = 2130903290;
    
    public static final int listPreferredItemPaddingEnd = 2130903291;
    
    public static final int listPreferredItemPaddingLeft = 2130903292;
    
    public static final int listPreferredItemPaddingRight = 2130903293;
    
    public static final int listPreferredItemPaddingStart = 2130903294;
    
    public static final int logo = 2130903295;
    
    public static final int logoDescription = 2130903296;
    
    public static final int maxButtonHeight = 2130903297;
    
    public static final int measureWithLargestChild = 2130903304;
    
    public static final int menu = 2130903305;
    
    public static final int multiChoiceItemLayout = 2130903306;
    
    public static final int navigationContentDescription = 2130903307;
    
    public static final int navigationIcon = 2130903308;
    
    public static final int navigationMode = 2130903309;
    
    public static final int numericModifiers = 2130903311;
    
    public static final int overlapAnchor = 2130903312;
    
    public static final int paddingBottomNoButtons = 2130903313;
    
    public static final int paddingEnd = 2130903314;
    
    public static final int paddingStart = 2130903315;
    
    public static final int paddingTopNoTitle = 2130903316;
    
    public static final int panelBackground = 2130903317;
    
    public static final int panelMenuListTheme = 2130903318;
    
    public static final int panelMenuListWidth = 2130903319;
    
    public static final int popupMenuStyle = 2130903320;
    
    public static final int popupTheme = 2130903321;
    
    public static final int popupWindowStyle = 2130903322;
    
    public static final int preserveIconSpacing = 2130903323;
    
    public static final int progressBarPadding = 2130903324;
    
    public static final int progressBarStyle = 2130903325;
    
    public static final int queryBackground = 2130903326;
    
    public static final int queryHint = 2130903327;
    
    public static final int radioButtonStyle = 2130903329;
    
    public static final int ratingBarStyle = 2130903330;
    
    public static final int ratingBarStyleIndicator = 2130903331;
    
    public static final int ratingBarStyleSmall = 2130903332;
    
    public static final int searchHintIcon = 2130903336;
    
    public static final int searchIcon = 2130903337;
    
    public static final int searchViewStyle = 2130903338;
    
    public static final int seekBarStyle = 2130903339;
    
    public static final int selectableItemBackground = 2130903340;
    
    public static final int selectableItemBackgroundBorderless = 2130903341;
    
    public static final int showAsAction = 2130903343;
    
    public static final int showDividers = 2130903344;
    
    public static final int showText = 2130903345;
    
    public static final int showTitle = 2130903346;
    
    public static final int singleChoiceItemLayout = 2130903347;
    
    public static final int spinBars = 2130903349;
    
    public static final int spinnerDropDownItemStyle = 2130903350;
    
    public static final int spinnerStyle = 2130903351;
    
    public static final int splitTrack = 2130903352;
    
    public static final int srcCompat = 2130903353;
    
    public static final int state_above_anchor = 2130903355;
    
    public static final int statusBarBackground = 2130903356;
    
    public static final int subMenuArrow = 2130903357;
    
    public static final int submitBackground = 2130903358;
    
    public static final int subtitle = 2130903359;
    
    public static final int subtitleTextAppearance = 2130903360;
    
    public static final int subtitleTextColor = 2130903361;
    
    public static final int subtitleTextStyle = 2130903362;
    
    public static final int suggestionRowLayout = 2130903363;
    
    public static final int switchMinWidth = 2130903364;
    
    public static final int switchPadding = 2130903365;
    
    public static final int switchStyle = 2130903366;
    
    public static final int switchTextAppearance = 2130903367;
    
    public static final int textAllCaps = 2130903368;
    
    public static final int textAppearanceLargePopupMenu = 2130903369;
    
    public static final int textAppearanceListItem = 2130903370;
    
    public static final int textAppearanceListItemSecondary = 2130903371;
    
    public static final int textAppearanceListItemSmall = 2130903372;
    
    public static final int textAppearancePopupMenuHeader = 2130903373;
    
    public static final int textAppearanceSearchResultSubtitle = 2130903374;
    
    public static final int textAppearanceSearchResultTitle = 2130903375;
    
    public static final int textAppearanceSmallPopupMenu = 2130903376;
    
    public static final int textColorAlertDialogListItem = 2130903377;
    
    public static final int textColorSearchUrl = 2130903378;
    
    public static final int textLocale = 2130903379;
    
    public static final int theme = 2130903380;
    
    public static final int thickness = 2130903381;
    
    public static final int thumbTextPadding = 2130903382;
    
    public static final int thumbTint = 2130903383;
    
    public static final int thumbTintMode = 2130903384;
    
    public static final int tickMark = 2130903385;
    
    public static final int tickMarkTint = 2130903386;
    
    public static final int tickMarkTintMode = 2130903387;
    
    public static final int tint = 2130903388;
    
    public static final int tintMode = 2130903389;
    
    public static final int title = 2130903390;
    
    public static final int titleMargin = 2130903391;
    
    public static final int titleMarginBottom = 2130903392;
    
    public static final int titleMarginEnd = 2130903393;
    
    public static final int titleMarginStart = 2130903394;
    
    public static final int titleMarginTop = 2130903395;
    
    public static final int titleMargins = 2130903396;
    
    public static final int titleTextAppearance = 2130903397;
    
    public static final int titleTextColor = 2130903398;
    
    public static final int titleTextStyle = 2130903399;
    
    public static final int toolbarNavigationButtonStyle = 2130903400;
    
    public static final int toolbarStyle = 2130903401;
    
    public static final int tooltipForegroundColor = 2130903402;
    
    public static final int tooltipFrameBackground = 2130903403;
    
    public static final int tooltipText = 2130903404;
    
    public static final int track = 2130903405;
    
    public static final int trackTint = 2130903406;
    
    public static final int trackTintMode = 2130903407;
    
    public static final int ttcIndex = 2130903408;
    
    public static final int viewInflaterClass = 2130903409;
    
    public static final int voiceIcon = 2130903410;
    
    public static final int windowActionBar = 2130903411;
    
    public static final int windowActionBarOverlay = 2130903412;
    
    public static final int windowActionModeOverlay = 2130903413;
    
    public static final int windowFixedHeightMajor = 2130903414;
    
    public static final int windowFixedHeightMinor = 2130903415;
    
    public static final int windowFixedWidthMajor = 2130903416;
    
    public static final int windowFixedWidthMinor = 2130903417;
    
    public static final int windowMinWidthMajor = 2130903418;
    
    public static final int windowMinWidthMinor = 2130903419;
    
    public static final int windowNoTitle = 2130903420;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130968576;
    
    public static final int abc_allow_stacked_button_bar = 2130968577;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130968578;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131034117;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131034118;
    
    public static final int abc_btn_colored_borderless_text_material = 2131034119;
    
    public static final int abc_btn_colored_text_material = 2131034120;
    
    public static final int abc_color_highlight_material = 2131034121;
    
    public static final int abc_hint_foreground_material_dark = 2131034122;
    
    public static final int abc_hint_foreground_material_light = 2131034123;
    
    public static final int abc_input_method_navigation_guard = 2131034124;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131034125;
    
    public static final int abc_primary_text_disable_only_material_light = 2131034126;
    
    public static final int abc_primary_text_material_dark = 2131034127;
    
    public static final int abc_primary_text_material_light = 2131034128;
    
    public static final int abc_search_url_text = 2131034129;
    
    public static final int abc_search_url_text_normal = 2131034130;
    
    public static final int abc_search_url_text_pressed = 2131034131;
    
    public static final int abc_search_url_text_selected = 2131034132;
    
    public static final int abc_secondary_text_material_dark = 2131034133;
    
    public static final int abc_secondary_text_material_light = 2131034134;
    
    public static final int abc_tint_btn_checkable = 2131034135;
    
    public static final int abc_tint_default = 2131034136;
    
    public static final int abc_tint_edittext = 2131034137;
    
    public static final int abc_tint_seek_thumb = 2131034138;
    
    public static final int abc_tint_spinner = 2131034139;
    
    public static final int abc_tint_switch_track = 2131034140;
    
    public static final int accent_material_dark = 2131034141;
    
    public static final int accent_material_light = 2131034142;
    
    public static final int androidx_core_ripple_material_light = 2131034151;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131034152;
    
    public static final int background_floating_material_dark = 2131034179;
    
    public static final int background_floating_material_light = 2131034180;
    
    public static final int background_material_dark = 2131034181;
    
    public static final int background_material_light = 2131034182;
    
    public static final int bright_foreground_disabled_material_dark = 2131034184;
    
    public static final int bright_foreground_disabled_material_light = 2131034185;
    
    public static final int bright_foreground_inverse_material_dark = 2131034186;
    
    public static final int bright_foreground_inverse_material_light = 2131034187;
    
    public static final int bright_foreground_material_dark = 2131034188;
    
    public static final int bright_foreground_material_light = 2131034189;
    
    public static final int browser_actions_bg_grey = 2131034190;
    
    public static final int browser_actions_divider_color = 2131034191;
    
    public static final int browser_actions_text_color = 2131034192;
    
    public static final int browser_actions_title_color = 2131034193;
    
    public static final int button_material_dark = 2131034194;
    
    public static final int button_material_light = 2131034195;
    
    public static final int cardview_dark_background = 2131034196;
    
    public static final int cardview_light_background = 2131034197;
    
    public static final int cardview_shadow_end_color = 2131034198;
    
    public static final int cardview_shadow_start_color = 2131034199;
    
    public static final int com_facebook_blue = 2131034205;
    
    public static final int com_facebook_button_background_color = 2131034206;
    
    public static final int com_facebook_button_background_color_disabled = 2131034207;
    
    public static final int com_facebook_button_background_color_pressed = 2131034208;
    
    public static final int com_facebook_button_text_color = 2131034211;
    
    public static final int com_facebook_device_auth_text = 2131034212;
    
    public static final int com_facebook_likeboxcountview_border_color = 2131034213;
    
    public static final int com_facebook_likeboxcountview_text_color = 2131034214;
    
    public static final int com_facebook_likeview_text_color = 2131034215;
    
    public static final int com_facebook_primary_button_disabled_text_color = 2131034217;
    
    public static final int com_facebook_primary_button_pressed_text_color = 2131034218;
    
    public static final int com_facebook_primary_button_text_color = 2131034219;
    
    public static final int com_smart_login_code = 2131034221;
    
    public static final int dim_foreground_disabled_material_dark = 2131034233;
    
    public static final int dim_foreground_disabled_material_light = 2131034234;
    
    public static final int dim_foreground_material_dark = 2131034235;
    
    public static final int dim_foreground_material_light = 2131034236;
    
    public static final int error_color_material_dark = 2131034237;
    
    public static final int error_color_material_light = 2131034238;
    
    public static final int foreground_material_dark = 2131034239;
    
    public static final int foreground_material_light = 2131034240;
    
    public static final int highlighted_text_material_dark = 2131034244;
    
    public static final int highlighted_text_material_light = 2131034245;
    
    public static final int material_blue_grey_800 = 2131034262;
    
    public static final int material_blue_grey_900 = 2131034263;
    
    public static final int material_blue_grey_950 = 2131034264;
    
    public static final int material_deep_teal_200 = 2131034265;
    
    public static final int material_deep_teal_500 = 2131034266;
    
    public static final int material_grey_100 = 2131034267;
    
    public static final int material_grey_300 = 2131034268;
    
    public static final int material_grey_50 = 2131034269;
    
    public static final int material_grey_600 = 2131034270;
    
    public static final int material_grey_800 = 2131034271;
    
    public static final int material_grey_850 = 2131034272;
    
    public static final int material_grey_900 = 2131034273;
    
    public static final int notification_action_color_filter = 2131034332;
    
    public static final int notification_icon_bg_color = 2131034333;
    
    public static final int notification_material_background_media_default_color = 2131034334;
    
    public static final int primary_dark_material_dark = 2131034335;
    
    public static final int primary_dark_material_light = 2131034336;
    
    public static final int primary_material_dark = 2131034337;
    
    public static final int primary_material_light = 2131034338;
    
    public static final int primary_text_default_material_dark = 2131034339;
    
    public static final int primary_text_default_material_light = 2131034340;
    
    public static final int primary_text_disabled_material_dark = 2131034341;
    
    public static final int primary_text_disabled_material_light = 2131034342;
    
    public static final int ripple_material_dark = 2131034343;
    
    public static final int ripple_material_light = 2131034344;
    
    public static final int secondary_text_default_material_dark = 2131034345;
    
    public static final int secondary_text_default_material_light = 2131034346;
    
    public static final int secondary_text_disabled_material_dark = 2131034347;
    
    public static final int secondary_text_disabled_material_light = 2131034348;
    
    public static final int switch_thumb_disabled_material_dark = 2131034349;
    
    public static final int switch_thumb_disabled_material_light = 2131034350;
    
    public static final int switch_thumb_material_dark = 2131034351;
    
    public static final int switch_thumb_material_light = 2131034352;
    
    public static final int switch_thumb_normal_material_dark = 2131034353;
    
    public static final int switch_thumb_normal_material_light = 2131034354;
    
    public static final int tooltip_background_dark = 2131034355;
    
    public static final int tooltip_background_light = 2131034356;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131099648;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131099649;
    
    public static final int abc_action_bar_default_height_material = 2131099650;
    
    public static final int abc_action_bar_default_padding_end_material = 2131099651;
    
    public static final int abc_action_bar_default_padding_start_material = 2131099652;
    
    public static final int abc_action_bar_elevation_material = 2131099653;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
    
    public static final int abc_action_bar_stacked_max_height = 2131099657;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
    
    public static final int abc_action_button_min_height_material = 2131099661;
    
    public static final int abc_action_button_min_width_material = 2131099662;
    
    public static final int abc_action_button_min_width_overflow_material = 2131099663;
    
    public static final int abc_alert_dialog_button_bar_height = 2131099664;
    
    public static final int abc_alert_dialog_button_dimen = 2131099665;
    
    public static final int abc_button_inset_horizontal_material = 2131099666;
    
    public static final int abc_button_inset_vertical_material = 2131099667;
    
    public static final int abc_button_padding_horizontal_material = 2131099668;
    
    public static final int abc_button_padding_vertical_material = 2131099669;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131099670;
    
    public static final int abc_config_prefDialogWidth = 2131099671;
    
    public static final int abc_control_corner_material = 2131099672;
    
    public static final int abc_control_inset_material = 2131099673;
    
    public static final int abc_control_padding_material = 2131099674;
    
    public static final int abc_dialog_corner_radius_material = 2131099675;
    
    public static final int abc_dialog_fixed_height_major = 2131099676;
    
    public static final int abc_dialog_fixed_height_minor = 2131099677;
    
    public static final int abc_dialog_fixed_width_major = 2131099678;
    
    public static final int abc_dialog_fixed_width_minor = 2131099679;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131099681;
    
    public static final int abc_dialog_min_width_major = 2131099682;
    
    public static final int abc_dialog_min_width_minor = 2131099683;
    
    public static final int abc_dialog_padding_material = 2131099684;
    
    public static final int abc_dialog_padding_top_material = 2131099685;
    
    public static final int abc_dialog_title_divider_material = 2131099686;
    
    public static final int abc_disabled_alpha_material_dark = 2131099687;
    
    public static final int abc_disabled_alpha_material_light = 2131099688;
    
    public static final int abc_dropdownitem_icon_width = 2131099689;
    
    public static final int abc_dropdownitem_text_padding_left = 2131099690;
    
    public static final int abc_dropdownitem_text_padding_right = 2131099691;
    
    public static final int abc_edit_text_inset_bottom_material = 2131099692;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131099693;
    
    public static final int abc_edit_text_inset_top_material = 2131099694;
    
    public static final int abc_floating_window_z = 2131099695;
    
    public static final int abc_list_item_height_large_material = 2131099696;
    
    public static final int abc_list_item_height_material = 2131099697;
    
    public static final int abc_list_item_height_small_material = 2131099698;
    
    public static final int abc_list_item_padding_horizontal_material = 2131099699;
    
    public static final int abc_panel_menu_list_width = 2131099700;
    
    public static final int abc_progress_bar_height_material = 2131099701;
    
    public static final int abc_search_view_preferred_height = 2131099702;
    
    public static final int abc_search_view_preferred_width = 2131099703;
    
    public static final int abc_seekbar_track_background_height_material = 2131099704;
    
    public static final int abc_seekbar_track_progress_height_material = 2131099705;
    
    public static final int abc_select_dialog_padding_start_material = 2131099706;
    
    public static final int abc_switch_padding = 2131099707;
    
    public static final int abc_text_size_body_1_material = 2131099708;
    
    public static final int abc_text_size_body_2_material = 2131099709;
    
    public static final int abc_text_size_button_material = 2131099710;
    
    public static final int abc_text_size_caption_material = 2131099711;
    
    public static final int abc_text_size_display_1_material = 2131099712;
    
    public static final int abc_text_size_display_2_material = 2131099713;
    
    public static final int abc_text_size_display_3_material = 2131099714;
    
    public static final int abc_text_size_display_4_material = 2131099715;
    
    public static final int abc_text_size_headline_material = 2131099716;
    
    public static final int abc_text_size_large_material = 2131099717;
    
    public static final int abc_text_size_medium_material = 2131099718;
    
    public static final int abc_text_size_menu_header_material = 2131099719;
    
    public static final int abc_text_size_menu_material = 2131099720;
    
    public static final int abc_text_size_small_material = 2131099721;
    
    public static final int abc_text_size_subhead_material = 2131099722;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131099723;
    
    public static final int abc_text_size_title_material = 2131099724;
    
    public static final int abc_text_size_title_material_toolbar = 2131099725;
    
    public static final int browser_actions_context_menu_max_width = 2131099772;
    
    public static final int browser_actions_context_menu_min_padding = 2131099773;
    
    public static final int cardview_compat_inset_shadow = 2131099774;
    
    public static final int cardview_default_elevation = 2131099775;
    
    public static final int cardview_default_radius = 2131099776;
    
    public static final int com_facebook_auth_dialog_corner_radius = 2131099777;
    
    public static final int com_facebook_auth_dialog_corner_radius_oversized = 2131099778;
    
    public static final int com_facebook_button_corner_radius = 2131099779;
    
    public static final int com_facebook_likeboxcountview_border_radius = 2131099781;
    
    public static final int com_facebook_likeboxcountview_border_width = 2131099782;
    
    public static final int com_facebook_likeboxcountview_caret_height = 2131099783;
    
    public static final int com_facebook_likeboxcountview_caret_width = 2131099784;
    
    public static final int com_facebook_likeboxcountview_text_padding = 2131099785;
    
    public static final int com_facebook_likeboxcountview_text_size = 2131099786;
    
    public static final int com_facebook_likeview_edge_padding = 2131099787;
    
    public static final int com_facebook_likeview_internal_padding = 2131099788;
    
    public static final int com_facebook_likeview_text_size = 2131099789;
    
    public static final int compat_button_inset_horizontal_material = 2131099793;
    
    public static final int compat_button_inset_vertical_material = 2131099794;
    
    public static final int compat_button_padding_horizontal_material = 2131099795;
    
    public static final int compat_button_padding_vertical_material = 2131099796;
    
    public static final int compat_control_corner_material = 2131099797;
    
    public static final int compat_notification_large_icon_max_height = 2131099798;
    
    public static final int compat_notification_large_icon_max_width = 2131099799;
    
    public static final int disabled_alpha_material_dark = 2131099801;
    
    public static final int disabled_alpha_material_light = 2131099802;
    
    public static final int highlight_alpha_material_colored = 2131099806;
    
    public static final int highlight_alpha_material_dark = 2131099807;
    
    public static final int highlight_alpha_material_light = 2131099808;
    
    public static final int hint_alpha_material_dark = 2131099809;
    
    public static final int hint_alpha_material_light = 2131099810;
    
    public static final int hint_pressed_alpha_material_dark = 2131099811;
    
    public static final int hint_pressed_alpha_material_light = 2131099812;
    
    public static final int notification_action_icon_size = 2131099869;
    
    public static final int notification_action_text_size = 2131099870;
    
    public static final int notification_big_circle_margin = 2131099871;
    
    public static final int notification_content_margin_start = 2131099872;
    
    public static final int notification_large_icon_height = 2131099873;
    
    public static final int notification_large_icon_width = 2131099874;
    
    public static final int notification_main_column_padding_top = 2131099875;
    
    public static final int notification_media_narrow_margin = 2131099876;
    
    public static final int notification_right_icon_size = 2131099877;
    
    public static final int notification_right_side_padding_top = 2131099878;
    
    public static final int notification_small_icon_background_padding = 2131099879;
    
    public static final int notification_small_icon_size_as_large = 2131099880;
    
    public static final int notification_subtext_size = 2131099881;
    
    public static final int notification_top_pad = 2131099882;
    
    public static final int notification_top_pad_large_text = 2131099883;
    
    public static final int subtitle_corner_radius = 2131099884;
    
    public static final int subtitle_outline_width = 2131099885;
    
    public static final int subtitle_shadow_offset = 2131099886;
    
    public static final int subtitle_shadow_radius = 2131099887;
    
    public static final int tooltip_corner_radius = 2131099889;
    
    public static final int tooltip_horizontal_padding = 2131099890;
    
    public static final int tooltip_margin = 2131099891;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131099892;
    
    public static final int tooltip_precise_anchor_threshold = 2131099893;
    
    public static final int tooltip_vertical_padding = 2131099894;
    
    public static final int tooltip_y_offset_non_touch = 2131099895;
    
    public static final int tooltip_y_offset_touch = 2131099896;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131165194;
    
    public static final int abc_action_bar_item_background_material = 2131165195;
    
    public static final int abc_btn_borderless_material = 2131165196;
    
    public static final int abc_btn_check_material = 2131165197;
    
    public static final int abc_btn_check_material_anim = 2131165198;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131165199;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131165200;
    
    public static final int abc_btn_colored_material = 2131165201;
    
    public static final int abc_btn_default_mtrl_shape = 2131165202;
    
    public static final int abc_btn_radio_material = 2131165203;
    
    public static final int abc_btn_radio_material_anim = 2131165204;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131165205;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131165206;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165207;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165208;
    
    public static final int abc_cab_background_internal_bg = 2131165209;
    
    public static final int abc_cab_background_top_material = 2131165210;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131165211;
    
    public static final int abc_control_background_material = 2131165212;
    
    public static final int abc_dialog_material_background = 2131165213;
    
    public static final int abc_edit_text_material = 2131165214;
    
    public static final int abc_ic_ab_back_material = 2131165215;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131165216;
    
    public static final int abc_ic_clear_material = 2131165217;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165218;
    
    public static final int abc_ic_go_search_api_material = 2131165219;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165220;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131165221;
    
    public static final int abc_ic_menu_overflow_material = 2131165222;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165223;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165224;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131165225;
    
    public static final int abc_ic_search_api_material = 2131165226;
    
    public static final int abc_ic_star_black_16dp = 2131165227;
    
    public static final int abc_ic_star_black_36dp = 2131165228;
    
    public static final int abc_ic_star_black_48dp = 2131165229;
    
    public static final int abc_ic_star_half_black_16dp = 2131165230;
    
    public static final int abc_ic_star_half_black_36dp = 2131165231;
    
    public static final int abc_ic_star_half_black_48dp = 2131165232;
    
    public static final int abc_ic_voice_search_api_material = 2131165233;
    
    public static final int abc_item_background_holo_dark = 2131165234;
    
    public static final int abc_item_background_holo_light = 2131165235;
    
    public static final int abc_list_divider_material = 2131165236;
    
    public static final int abc_list_divider_mtrl_alpha = 2131165237;
    
    public static final int abc_list_focused_holo = 2131165238;
    
    public static final int abc_list_longpressed_holo = 2131165239;
    
    public static final int abc_list_pressed_holo_dark = 2131165240;
    
    public static final int abc_list_pressed_holo_light = 2131165241;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131165242;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131165243;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131165244;
    
    public static final int abc_list_selector_disabled_holo_light = 2131165245;
    
    public static final int abc_list_selector_holo_dark = 2131165246;
    
    public static final int abc_list_selector_holo_light = 2131165247;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165248;
    
    public static final int abc_popup_background_mtrl_mult = 2131165249;
    
    public static final int abc_ratingbar_indicator_material = 2131165250;
    
    public static final int abc_ratingbar_material = 2131165251;
    
    public static final int abc_ratingbar_small_material = 2131165252;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131165253;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165254;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165255;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131165256;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131165257;
    
    public static final int abc_seekbar_thumb_material = 2131165258;
    
    public static final int abc_seekbar_tick_mark_material = 2131165259;
    
    public static final int abc_seekbar_track_material = 2131165260;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131165261;
    
    public static final int abc_spinner_textfield_background_material = 2131165262;
    
    public static final int abc_switch_thumb_material = 2131165263;
    
    public static final int abc_switch_track_mtrl_alpha = 2131165264;
    
    public static final int abc_tab_indicator_material = 2131165265;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131165266;
    
    public static final int abc_text_cursor_material = 2131165267;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131165268;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131165269;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131165270;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131165271;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131165272;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131165273;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131165274;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131165275;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131165276;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131165277;
    
    public static final int abc_textfield_search_material = 2131165278;
    
    public static final int abc_vector_test = 2131165279;
    
    public static final int btn_checkbox_checked_mtrl = 2131165418;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165419;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131165420;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165421;
    
    public static final int btn_radio_off_mtrl = 2131165422;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131165423;
    
    public static final int btn_radio_on_mtrl = 2131165424;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131165425;
    
    public static final int com_facebook_auth_dialog_background = 2131165428;
    
    public static final int com_facebook_auth_dialog_cancel_background = 2131165429;
    
    public static final int com_facebook_auth_dialog_header_background = 2131165430;
    
    public static final int com_facebook_button_background = 2131165431;
    
    public static final int com_facebook_button_icon = 2131165432;
    
    public static final int com_facebook_button_like_background = 2131165433;
    
    public static final int com_facebook_button_like_icon_selected = 2131165434;
    
    public static final int com_facebook_close = 2131165438;
    
    public static final int com_facebook_favicon_blue = 2131165439;
    
    public static final int notification_action_background = 2131165637;
    
    public static final int notification_bg = 2131165638;
    
    public static final int notification_bg_low = 2131165639;
    
    public static final int notification_bg_low_normal = 2131165640;
    
    public static final int notification_bg_low_pressed = 2131165641;
    
    public static final int notification_bg_normal = 2131165642;
    
    public static final int notification_bg_normal_pressed = 2131165643;
    
    public static final int notification_icon_background = 2131165644;
    
    public static final int notification_template_icon_bg = 2131165645;
    
    public static final int notification_template_icon_low_bg = 2131165646;
    
    public static final int notification_tile_bg = 2131165647;
    
    public static final int notify_panel_notification_icon_bg = 2131165648;
    
    public static final int tooltip_frame_dark = 2131165652;
    
    public static final int tooltip_frame_light = 2131165653;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131296262;
    
    public static final int accessibility_custom_action_0 = 2131296263;
    
    public static final int accessibility_custom_action_1 = 2131296264;
    
    public static final int accessibility_custom_action_10 = 2131296265;
    
    public static final int accessibility_custom_action_11 = 2131296266;
    
    public static final int accessibility_custom_action_12 = 2131296267;
    
    public static final int accessibility_custom_action_13 = 2131296268;
    
    public static final int accessibility_custom_action_14 = 2131296269;
    
    public static final int accessibility_custom_action_15 = 2131296270;
    
    public static final int accessibility_custom_action_16 = 2131296271;
    
    public static final int accessibility_custom_action_17 = 2131296272;
    
    public static final int accessibility_custom_action_18 = 2131296273;
    
    public static final int accessibility_custom_action_19 = 2131296274;
    
    public static final int accessibility_custom_action_2 = 2131296275;
    
    public static final int accessibility_custom_action_20 = 2131296276;
    
    public static final int accessibility_custom_action_21 = 2131296277;
    
    public static final int accessibility_custom_action_22 = 2131296278;
    
    public static final int accessibility_custom_action_23 = 2131296279;
    
    public static final int accessibility_custom_action_24 = 2131296280;
    
    public static final int accessibility_custom_action_25 = 2131296281;
    
    public static final int accessibility_custom_action_26 = 2131296282;
    
    public static final int accessibility_custom_action_27 = 2131296283;
    
    public static final int accessibility_custom_action_28 = 2131296284;
    
    public static final int accessibility_custom_action_29 = 2131296285;
    
    public static final int accessibility_custom_action_3 = 2131296286;
    
    public static final int accessibility_custom_action_30 = 2131296287;
    
    public static final int accessibility_custom_action_31 = 2131296288;
    
    public static final int accessibility_custom_action_4 = 2131296289;
    
    public static final int accessibility_custom_action_5 = 2131296290;
    
    public static final int accessibility_custom_action_6 = 2131296291;
    
    public static final int accessibility_custom_action_7 = 2131296292;
    
    public static final int accessibility_custom_action_8 = 2131296293;
    
    public static final int accessibility_custom_action_9 = 2131296294;
    
    public static final int action0 = 2131296295;
    
    public static final int action_bar = 2131296296;
    
    public static final int action_bar_activity_content = 2131296297;
    
    public static final int action_bar_container = 2131296298;
    
    public static final int action_bar_root = 2131296299;
    
    public static final int action_bar_spinner = 2131296300;
    
    public static final int action_bar_subtitle = 2131296301;
    
    public static final int action_bar_title = 2131296302;
    
    public static final int action_container = 2131296303;
    
    public static final int action_context_bar = 2131296304;
    
    public static final int action_divider = 2131296305;
    
    public static final int action_image = 2131296306;
    
    public static final int action_menu_divider = 2131296307;
    
    public static final int action_menu_presenter = 2131296308;
    
    public static final int action_mode_bar = 2131296309;
    
    public static final int action_mode_bar_stub = 2131296310;
    
    public static final int action_mode_close_button = 2131296311;
    
    public static final int action_text = 2131296313;
    
    public static final int actions = 2131296314;
    
    public static final int activity_chooser_view_content = 2131296315;
    
    public static final int add = 2131296320;
    
    public static final int alertTitle = 2131296365;
    
    public static final int async = 2131296390;
    
    public static final int blocking = 2131296399;
    
    public static final int bottom = 2131296400;
    
    public static final int box_count = 2131296401;
    
    public static final int browser_actions_header_text = 2131296402;
    
    public static final int browser_actions_menu_item_icon = 2131296403;
    
    public static final int browser_actions_menu_item_text = 2131296404;
    
    public static final int browser_actions_menu_items = 2131296405;
    
    public static final int browser_actions_menu_view = 2131296406;
    
    public static final int button = 2131296407;
    
    public static final int buttonPanel = 2131296408;
    
    public static final int cancel_action = 2131296409;
    
    public static final int cancel_button = 2131296410;
    
    public static final int center = 2131296411;
    
    public static final int checkbox = 2131296414;
    
    public static final int checked = 2131296415;
    
    public static final int chronometer = 2131296416;
    
    public static final int com_facebook_device_auth_instructions = 2131296424;
    
    public static final int com_facebook_fragment_container = 2131296425;
    
    public static final int com_facebook_login_fragment_progress_bar = 2131296426;
    
    public static final int com_facebook_smart_instructions_0 = 2131296427;
    
    public static final int com_facebook_smart_instructions_or = 2131296428;
    
    public static final int confirmation_code = 2131296432;
    
    public static final int content = 2131296443;
    
    public static final int contentPanel = 2131296444;
    
    public static final int custom = 2131296447;
    
    public static final int customPanel = 2131296448;
    
    public static final int decor_content_parent = 2131296450;
    
    public static final int default_activity_button = 2131296451;
    
    public static final int dialog_button = 2131296453;
    
    public static final int edit_query = 2131296457;
    
    public static final int end = 2131296459;
    
    public static final int end_padder = 2131296460;
    
    public static final int expand_activities_button = 2131296468;
    
    public static final int expanded_menu = 2131296469;
    
    public static final int forever = 2131296476;
    
    public static final int group_divider = 2131296479;
    
    public static final int home = 2131296481;
    
    public static final int icon = 2131296513;
    
    public static final int icon_group = 2131296514;
    
    public static final int image = 2131296517;
    
    public static final int info = 2131296520;
    
    public static final int inline = 2131296521;
    
    public static final int italic = 2131296535;
    
    public static final int left = 2131296542;
    
    public static final int line1 = 2131296544;
    
    public static final int line3 = 2131296545;
    
    public static final int listMode = 2131296546;
    
    public static final int list_item = 2131296548;
    
    public static final int media_actions = 2131296709;
    
    public static final int message = 2131296710;
    
    public static final int multiply = 2131296717;
    
    public static final int none = 2131296723;
    
    public static final int normal = 2131296724;
    
    public static final int notification_background = 2131296725;
    
    public static final int notification_main_column = 2131296726;
    
    public static final int notification_main_column_container = 2131296727;
    
    public static final int off = 2131296728;
    
    public static final int on = 2131296729;
    
    public static final int open_graph = 2131296731;
    
    public static final int page = 2131296732;
    
    public static final int parentPanel = 2131296733;
    
    public static final int progress_bar = 2131296741;
    
    public static final int progress_circular = 2131296742;
    
    public static final int progress_horizontal = 2131296743;
    
    public static final int radio = 2131296744;
    
    public static final int right = 2131296751;
    
    public static final int right_icon = 2131296752;
    
    public static final int right_side = 2131296753;
    
    public static final int screen = 2131296754;
    
    public static final int scrollIndicatorDown = 2131296755;
    
    public static final int scrollIndicatorUp = 2131296756;
    
    public static final int scrollView = 2131296757;
    
    public static final int search_badge = 2131296759;
    
    public static final int search_bar = 2131296760;
    
    public static final int search_button = 2131296761;
    
    public static final int search_close_btn = 2131296762;
    
    public static final int search_edit_frame = 2131296763;
    
    public static final int search_go_btn = 2131296764;
    
    public static final int search_mag_icon = 2131296765;
    
    public static final int search_plate = 2131296766;
    
    public static final int search_src_text = 2131296767;
    
    public static final int search_voice_btn = 2131296768;
    
    public static final int select_dialog_listview = 2131296769;
    
    public static final int shortcut = 2131296770;
    
    public static final int spacer = 2131296779;
    
    public static final int split_action_bar = 2131296781;
    
    public static final int src_atop = 2131296782;
    
    public static final int src_in = 2131296783;
    
    public static final int src_over = 2131296784;
    
    public static final int standard = 2131296785;
    
    public static final int start = 2131296786;
    
    public static final int status_bar_latest_event_content = 2131296787;
    
    public static final int submenuarrow = 2131296789;
    
    public static final int submit_area = 2131296790;
    
    public static final int tabMode = 2131296792;
    
    public static final int tag_accessibility_actions = 2131296793;
    
    public static final int tag_accessibility_clickable_spans = 2131296794;
    
    public static final int tag_accessibility_heading = 2131296795;
    
    public static final int tag_accessibility_pane_title = 2131296796;
    
    public static final int tag_screen_reader_focusable = 2131296800;
    
    public static final int tag_transition_group = 2131296802;
    
    public static final int tag_unhandled_key_event_manager = 2131296803;
    
    public static final int tag_unhandled_key_listeners = 2131296804;
    
    public static final int text = 2131296806;
    
    public static final int text2 = 2131296807;
    
    public static final int textSpacerNoButtons = 2131296808;
    
    public static final int textSpacerNoTitle = 2131296809;
    
    public static final int time = 2131296812;
    
    public static final int title = 2131296813;
    
    public static final int titleDividerNoCustom = 2131296814;
    
    public static final int title_template = 2131296815;
    
    public static final int top = 2131296817;
    
    public static final int topPanel = 2131296818;
    
    public static final int unchecked = 2131296819;
    
    public static final int uniform = 2131296821;
    
    public static final int unknown = 2131296823;
    
    public static final int up = 2131296824;
    
    public static final int wrap_content = 2131296831;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131361792;
    
    public static final int abc_config_activityShortDur = 2131361793;
    
    public static final int cancel_button_image_alpha = 2131361796;
    
    public static final int config_tooltipAnimTime = 2131361797;
    
    public static final int status_bar_notification_info_maxnum = 2131361801;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
    
    public static final int fast_out_slow_in = 2131427334;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131492864;
    
    public static final int abc_action_bar_up_container = 2131492865;
    
    public static final int abc_action_menu_item_layout = 2131492866;
    
    public static final int abc_action_menu_layout = 2131492867;
    
    public static final int abc_action_mode_bar = 2131492868;
    
    public static final int abc_action_mode_close_item_material = 2131492869;
    
    public static final int abc_activity_chooser_view = 2131492870;
    
    public static final int abc_activity_chooser_view_list_item = 2131492871;
    
    public static final int abc_alert_dialog_button_bar_material = 2131492872;
    
    public static final int abc_alert_dialog_material = 2131492873;
    
    public static final int abc_alert_dialog_title_material = 2131492874;
    
    public static final int abc_cascading_menu_item_layout = 2131492875;
    
    public static final int abc_dialog_title_material = 2131492876;
    
    public static final int abc_expanded_menu_layout = 2131492877;
    
    public static final int abc_list_menu_item_checkbox = 2131492878;
    
    public static final int abc_list_menu_item_icon = 2131492879;
    
    public static final int abc_list_menu_item_layout = 2131492880;
    
    public static final int abc_list_menu_item_radio = 2131492881;
    
    public static final int abc_popup_menu_header_item_layout = 2131492882;
    
    public static final int abc_popup_menu_item_layout = 2131492883;
    
    public static final int abc_screen_content_include = 2131492884;
    
    public static final int abc_screen_simple = 2131492885;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131492886;
    
    public static final int abc_screen_toolbar = 2131492887;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131492888;
    
    public static final int abc_search_view = 2131492889;
    
    public static final int abc_select_dialog_material = 2131492890;
    
    public static final int abc_tooltip = 2131492891;
    
    public static final int browser_actions_context_menu_page = 2131492911;
    
    public static final int browser_actions_context_menu_row = 2131492912;
    
    public static final int com_facebook_activity_layout = 2131492913;
    
    public static final int com_facebook_device_auth_dialog_fragment = 2131492914;
    
    public static final int com_facebook_login_fragment = 2131492915;
    
    public static final int com_facebook_smart_device_dialog_fragment = 2131492916;
    
    public static final int custom_dialog = 2131492921;
    
    public static final int notification_action = 2131492989;
    
    public static final int notification_action_tombstone = 2131492990;
    
    public static final int notification_media_action = 2131492991;
    
    public static final int notification_media_cancel_action = 2131492992;
    
    public static final int notification_template_big_media = 2131492993;
    
    public static final int notification_template_big_media_custom = 2131492994;
    
    public static final int notification_template_big_media_narrow = 2131492995;
    
    public static final int notification_template_big_media_narrow_custom = 2131492996;
    
    public static final int notification_template_custom_big = 2131492997;
    
    public static final int notification_template_icon_group = 2131492998;
    
    public static final int notification_template_lines_media = 2131492999;
    
    public static final int notification_template_media = 2131493000;
    
    public static final int notification_template_media_custom = 2131493001;
    
    public static final int notification_template_part_chronometer = 2131493002;
    
    public static final int notification_template_part_time = 2131493003;
    
    public static final int select_dialog_item_material = 2131493005;
    
    public static final int select_dialog_multichoice_material = 2131493006;
    
    public static final int select_dialog_singlechoice_material = 2131493007;
    
    public static final int support_simple_spinner_dropdown_item = 2131493009;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131820552;
    
    public static final int abc_action_bar_up_description = 2131820553;
    
    public static final int abc_action_menu_overflow_description = 2131820554;
    
    public static final int abc_action_mode_done = 2131820555;
    
    public static final int abc_activity_chooser_view_see_all = 2131820556;
    
    public static final int abc_activitychooserview_choose_application = 2131820557;
    
    public static final int abc_capital_off = 2131820558;
    
    public static final int abc_capital_on = 2131820559;
    
    public static final int abc_menu_alt_shortcut_label = 2131820560;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131820561;
    
    public static final int abc_menu_delete_shortcut_label = 2131820562;
    
    public static final int abc_menu_enter_shortcut_label = 2131820563;
    
    public static final int abc_menu_function_shortcut_label = 2131820564;
    
    public static final int abc_menu_meta_shortcut_label = 2131820565;
    
    public static final int abc_menu_shift_shortcut_label = 2131820566;
    
    public static final int abc_menu_space_shortcut_label = 2131820567;
    
    public static final int abc_menu_sym_shortcut_label = 2131820568;
    
    public static final int abc_prepend_shortcut_label = 2131820569;
    
    public static final int abc_search_hint = 2131820570;
    
    public static final int abc_searchview_description_clear = 2131820571;
    
    public static final int abc_searchview_description_query = 2131820572;
    
    public static final int abc_searchview_description_search = 2131820573;
    
    public static final int abc_searchview_description_submit = 2131820574;
    
    public static final int abc_searchview_description_voice = 2131820575;
    
    public static final int abc_shareactionprovider_share_with = 2131820576;
    
    public static final int abc_shareactionprovider_share_with_application = 2131820577;
    
    public static final int abc_toolbar_collapse_description = 2131820578;
    
    public static final int com_facebook_device_auth_instructions = 2131820672;
    
    public static final int com_facebook_image_download_unknown_error = 2131820673;
    
    public static final int com_facebook_internet_permission_error_message = 2131820674;
    
    public static final int com_facebook_internet_permission_error_title = 2131820675;
    
    public static final int com_facebook_like_button_liked = 2131820676;
    
    public static final int com_facebook_like_button_not_liked = 2131820677;
    
    public static final int com_facebook_loading = 2131820678;
    
    public static final int com_facebook_loginview_cancel_action = 2131820679;
    
    public static final int com_facebook_loginview_log_in_button = 2131820680;
    
    public static final int com_facebook_loginview_log_in_button_continue = 2131820681;
    
    public static final int com_facebook_loginview_log_in_button_long = 2131820682;
    
    public static final int com_facebook_loginview_log_out_action = 2131820683;
    
    public static final int com_facebook_loginview_log_out_button = 2131820684;
    
    public static final int com_facebook_loginview_logged_in_as = 2131820685;
    
    public static final int com_facebook_loginview_logged_in_using_facebook = 2131820686;
    
    public static final int com_facebook_send_button_text = 2131820687;
    
    public static final int com_facebook_share_button_text = 2131820688;
    
    public static final int com_facebook_smart_device_instructions = 2131820689;
    
    public static final int com_facebook_smart_device_instructions_or = 2131820690;
    
    public static final int com_facebook_smart_login_confirmation_cancel = 2131820691;
    
    public static final int com_facebook_smart_login_confirmation_continue_as = 2131820692;
    
    public static final int com_facebook_smart_login_confirmation_title = 2131820693;
    
    public static final int com_facebook_tooltip_default = 2131820694;
    
    public static final int search_menu_title = 2131820790;
    
    public static final int status_bar_notification_info_overflow = 2131820795;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131886080;
    
    public static final int AlertDialog_AppCompat_Light = 2131886081;
    
    public static final int Animation_AppCompat_Dialog = 2131886082;
    
    public static final int Animation_AppCompat_DropDownUp = 2131886083;
    
    public static final int Animation_AppCompat_Tooltip = 2131886084;
    
    public static final int Base_AlertDialog_AppCompat = 2131886119;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131886120;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131886121;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131886122;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131886123;
    
    public static final int Base_CardView = 2131886124;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131886126;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131886125;
    
    public static final int Base_TextAppearance_AppCompat = 2131886127;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131886128;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131886129;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131886130;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131886131;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131886132;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131886133;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131886134;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131886135;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131886136;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131886137;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131886138;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131886139;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886140;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886141;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131886142;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131886143;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131886144;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131886145;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131886146;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131886147;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131886148;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131886149;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131886150;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131886151;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131886152;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131886153;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131886154;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886155;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886156;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886157;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886158;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886159;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886160;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886161;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131886162;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886163;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131886164;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131886165;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131886166;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886167;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886168;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886169;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131886170;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886171;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886172;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886173;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886174;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131886189;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131886190;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131886191;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131886192;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131886193;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131886194;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131886195;
    
    public static final int Base_Theme_AppCompat = 2131886175;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131886176;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131886177;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131886181;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131886178;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131886179;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131886180;
    
    public static final int Base_Theme_AppCompat_Light = 2131886182;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131886183;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131886184;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131886188;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131886185;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131886186;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131886187;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131886200;
    
    public static final int Base_V21_Theme_AppCompat = 2131886196;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131886197;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131886198;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131886199;
    
    public static final int Base_V22_Theme_AppCompat = 2131886201;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131886202;
    
    public static final int Base_V23_Theme_AppCompat = 2131886203;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131886204;
    
    public static final int Base_V26_Theme_AppCompat = 2131886205;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131886206;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131886207;
    
    public static final int Base_V28_Theme_AppCompat = 2131886208;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131886209;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131886214;
    
    public static final int Base_V7_Theme_AppCompat = 2131886210;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131886211;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131886212;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131886213;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131886215;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131886216;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131886217;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131886218;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131886219;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131886220;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131886221;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131886222;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131886223;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131886224;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131886225;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131886226;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131886227;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131886228;
    
    public static final int Base_Widget_AppCompat_Button = 2131886229;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131886235;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131886236;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131886230;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131886231;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886232;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131886233;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131886234;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131886237;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131886238;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131886239;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131886240;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131886241;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131886242;
    
    public static final int Base_Widget_AppCompat_EditText = 2131886243;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131886244;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131886245;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131886246;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131886247;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131886248;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886249;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131886250;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131886251;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131886252;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131886253;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131886254;
    
    public static final int Base_Widget_AppCompat_ListView = 2131886255;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131886256;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131886257;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131886258;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131886259;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131886260;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131886261;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131886262;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131886263;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131886264;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131886265;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131886266;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131886267;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131886268;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131886269;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131886270;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131886271;
    
    public static final int Base_Widget_AppCompat_TextView = 2131886272;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131886273;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131886274;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131886275;
    
    public static final int CardView = 2131886277;
    
    public static final int CardView_Dark = 2131886278;
    
    public static final int CardView_Light = 2131886279;
    
    public static final int Platform_AppCompat = 2131886283;
    
    public static final int Platform_AppCompat_Light = 2131886284;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131886285;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131886286;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131886287;
    
    public static final int Platform_V21_AppCompat = 2131886288;
    
    public static final int Platform_V21_AppCompat_Light = 2131886289;
    
    public static final int Platform_V25_AppCompat = 2131886290;
    
    public static final int Platform_V25_AppCompat_Light = 2131886291;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131886292;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131886293;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131886294;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131886295;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131886296;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131886297;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131886298;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131886299;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131886300;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131886301;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131886307;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131886302;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131886303;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131886304;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131886305;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131886306;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131886308;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131886309;
    
    public static final int TextAppearance_AppCompat = 2131886311;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131886312;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131886313;
    
    public static final int TextAppearance_AppCompat_Button = 2131886314;
    
    public static final int TextAppearance_AppCompat_Caption = 2131886315;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131886316;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131886317;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131886318;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131886319;
    
    public static final int TextAppearance_AppCompat_Headline = 2131886320;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131886321;
    
    public static final int TextAppearance_AppCompat_Large = 2131886322;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131886323;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131886324;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131886325;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886326;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886327;
    
    public static final int TextAppearance_AppCompat_Medium = 2131886328;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131886329;
    
    public static final int TextAppearance_AppCompat_Menu = 2131886330;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131886331;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131886332;
    
    public static final int TextAppearance_AppCompat_Small = 2131886333;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131886334;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131886335;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131886336;
    
    public static final int TextAppearance_AppCompat_Title = 2131886337;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131886338;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131886339;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886340;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886341;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886342;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886343;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886344;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886345;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131886346;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886347;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131886348;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131886349;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886350;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131886351;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131886352;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131886353;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886354;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886355;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886356;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131886357;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886358;
    
    public static final int TextAppearance_Compat_Notification = 2131886359;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131886360;
    
    public static final int TextAppearance_Compat_Notification_Info_Media = 2131886361;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131886362;
    
    public static final int TextAppearance_Compat_Notification_Line2_Media = 2131886363;
    
    public static final int TextAppearance_Compat_Notification_Media = 2131886364;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131886365;
    
    public static final int TextAppearance_Compat_Notification_Time_Media = 2131886366;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131886367;
    
    public static final int TextAppearance_Compat_Notification_Title_Media = 2131886368;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886369;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886370;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886371;
    
    public static final int ThemeOverlay_AppCompat = 2131886400;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131886401;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131886402;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131886403;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131886404;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131886405;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131886406;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131886407;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131886408;
    
    public static final int Theme_AppCompat = 2131886372;
    
    public static final int Theme_AppCompat_CompactMenu = 2131886373;
    
    public static final int Theme_AppCompat_DayNight = 2131886374;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131886375;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131886376;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131886379;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131886377;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131886378;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131886380;
    
    public static final int Theme_AppCompat_Dialog = 2131886381;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131886384;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131886382;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131886383;
    
    public static final int Theme_AppCompat_Light = 2131886385;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131886386;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131886387;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131886390;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131886388;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131886389;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131886391;
    
    public static final int Theme_AppCompat_NoActionBar = 2131886392;
    
    public static final int Widget_AppCompat_ActionBar = 2131886411;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131886412;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131886413;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131886414;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131886415;
    
    public static final int Widget_AppCompat_ActionButton = 2131886416;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131886417;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131886418;
    
    public static final int Widget_AppCompat_ActionMode = 2131886419;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131886420;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131886421;
    
    public static final int Widget_AppCompat_Button = 2131886422;
    
    public static final int Widget_AppCompat_ButtonBar = 2131886428;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131886429;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131886423;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131886424;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886425;
    
    public static final int Widget_AppCompat_Button_Colored = 2131886426;
    
    public static final int Widget_AppCompat_Button_Small = 2131886427;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131886430;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131886431;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131886432;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131886433;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131886434;
    
    public static final int Widget_AppCompat_EditText = 2131886435;
    
    public static final int Widget_AppCompat_ImageButton = 2131886436;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131886437;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131886438;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131886439;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131886440;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131886441;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131886442;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886443;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131886444;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131886445;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131886446;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131886447;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131886448;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131886449;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131886450;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131886451;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131886452;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131886453;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131886454;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131886455;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131886456;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131886457;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131886458;
    
    public static final int Widget_AppCompat_ListMenuView = 2131886459;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131886460;
    
    public static final int Widget_AppCompat_ListView = 2131886461;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131886462;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131886463;
    
    public static final int Widget_AppCompat_PopupMenu = 2131886464;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131886465;
    
    public static final int Widget_AppCompat_PopupWindow = 2131886466;
    
    public static final int Widget_AppCompat_ProgressBar = 2131886467;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131886468;
    
    public static final int Widget_AppCompat_RatingBar = 2131886469;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131886470;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131886471;
    
    public static final int Widget_AppCompat_SearchView = 2131886472;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131886473;
    
    public static final int Widget_AppCompat_SeekBar = 2131886474;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131886475;
    
    public static final int Widget_AppCompat_Spinner = 2131886476;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131886477;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131886478;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131886479;
    
    public static final int Widget_AppCompat_TextView = 2131886480;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131886481;
    
    public static final int Widget_AppCompat_Toolbar = 2131886482;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131886483;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131886484;
    
    public static final int Widget_Compat_NotificationActionText = 2131886485;
    
    public static final int Widget_Support_CoordinatorLayout = 2131886486;
    
    public static final int com_facebook_activity_theme = 2131886515;
    
    public static final int com_facebook_auth_dialog = 2131886516;
    
    public static final int com_facebook_auth_dialog_instructions_textview = 2131886517;
    
    public static final int com_facebook_button = 2131886518;
    
    public static final int com_facebook_button_like = 2131886519;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130903131, 2130903132, 2130903133, 2130903192, 2130903193, 2130903194, 2130903195, 2130903196, 2130903197, 2130903206, 
        2130903211, 2130903212, 2130903231, 2130903253, 2130903254, 2130903255, 2130903256, 2130903257, 2130903264, 2130903267, 
        2130903295, 2130903309, 2130903321, 2130903324, 2130903325, 2130903359, 2130903362, 2130903390, 2130903399 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130903131, 2130903132, 2130903163, 2130903253, 2130903362, 2130903399 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130903232, 2130903265 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130903145, 2130903146, 2130903284, 2130903285, 2130903306, 2130903346, 2130903347 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130903353, 2130903388, 2130903389 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130903385, 2130903386, 2130903387 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130903126, 2130903127, 2130903128, 2130903129, 2130903130, 2130903216, 2130903217, 2130903218, 2130903219, 
        2130903221, 2130903222, 2130903223, 2130903224, 2130903238, 2130903240, 2130903249, 2130903270, 2130903279, 2130903368, 
        2130903379 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 
        2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 
        2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 
        2130903069, 2130903070, 2130903073, 2130903116, 2130903117, 2130903118, 2130903119, 2130903125, 2130903137, 2130903138, 
        2130903139, 2130903140, 2130903141, 2130903142, 2130903148, 2130903149, 2130903159, 2130903160, 2130903167, 2130903168, 
        2130903169, 2130903170, 2130903171, 2130903172, 2130903173, 2130903174, 2130903175, 2130903177, 2130903203, 2130903208, 
        2130903209, 2130903210, 2130903213, 2130903215, 2130903226, 2130903227, 2130903228, 2130903229, 2130903230, 2130903255, 
        2130903263, 2130903280, 2130903281, 2130903282, 2130903283, 2130903286, 2130903287, 2130903288, 2130903289, 2130903290, 
        2130903291, 2130903292, 2130903293, 2130903294, 2130903317, 2130903318, 2130903319, 2130903320, 2130903322, 2130903329, 
        2130903330, 2130903331, 2130903332, 2130903338, 2130903339, 2130903340, 2130903341, 2130903350, 2130903351, 2130903366, 
        2130903369, 2130903370, 2130903371, 2130903372, 2130903373, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378, 
        2130903400, 2130903401, 2130903402, 2130903403, 2130903409, 2130903411, 2130903412, 2130903413, 2130903414, 2130903415, 
        2130903416, 2130903417, 2130903418, 2130903419, 2130903420 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] ButtonBarLayout = new int[] { 2130903120 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130903152, 2130903153, 2130903154, 2130903155, 2130903156, 2130903157, 2130903198, 2130903199, 
        2130903200, 2130903201, 2130903202 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130903121, 2130903269 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130903143, 2130903150, 2130903151 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] CoordinatorLayout = new int[] { 2130903268, 2130903356 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130903273, 2130903274, 2130903275, 2130903276, 2130903277, 2130903278 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130903123, 2130903124, 2130903136, 2130903166, 2130903220, 2130903251, 2130903349, 2130903381 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130903241, 2130903242, 2130903243, 2130903244, 2130903245, 2130903246, 2130903247 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903239, 2130903248, 2130903249, 2130903250, 2130903408 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903212, 2130903214, 2130903304, 2130903344 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903053, 2130903071, 2130903072, 2130903122, 2130903191, 2130903258, 2130903259, 
        2130903311, 2130903343, 2130903404 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903323, 2130903357 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130903312 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130903355 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130903313, 2130903316 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903162, 2130903190, 2130903207, 2130903252, 2130903260, 2130903271, 
        2130903326, 2130903327, 2130903336, 2130903337, 2130903358, 2130903363, 2130903410 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903321 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130903345, 2130903352, 2130903364, 2130903365, 2130903367, 2130903382, 2130903383, 
        2130903384, 2130903405, 2130903406, 2130903407 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130903240, 2130903249, 2130903368, 2130903379 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130903144, 2130903164, 2130903165, 2130903192, 2130903193, 2130903194, 2130903195, 2130903196, 
        2130903197, 2130903295, 2130903296, 2130903297, 2130903305, 2130903307, 2130903308, 2130903321, 2130903359, 2130903360, 
        2130903361, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 2130903398 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130903314, 2130903315, 2130903380 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130903134, 2130903135 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
    
    public static final int[] com_facebook_like_view = new int[] { 2130903178, 2130903180, 2130903181, 2130903185, 2130903186, 2130903188 };
    
    public static final int com_facebook_like_view_com_facebook_auxiliary_view_position = 0;
    
    public static final int com_facebook_like_view_com_facebook_foreground_color = 1;
    
    public static final int com_facebook_like_view_com_facebook_horizontal_alignment = 2;
    
    public static final int com_facebook_like_view_com_facebook_object_id = 3;
    
    public static final int com_facebook_like_view_com_facebook_object_type = 4;
    
    public static final int com_facebook_like_view_com_facebook_style = 5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\common\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */