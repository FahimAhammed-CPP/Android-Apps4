package com.facebook;

import kotlin.Metadata;

@Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bà\001\030\0002\0020\001J\022\020\002\032\0020\0032\b\020\004\032\004\030\0010\005H&¨\006\006"}, d2 = {"Lcom/facebook/RequestOutputStream;", "", "setCurrentRequest", "", "r", "Lcom/facebook/GraphRequest;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public interface RequestOutputStream {
  void setCurrentRequest(GraphRequest paramGraphRequest);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\RequestOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */