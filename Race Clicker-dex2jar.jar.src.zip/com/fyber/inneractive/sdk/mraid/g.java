package com.fyber.inneractive.sdk.mraid;

public enum g {
  CLOSE, CREATE_CALENDAR_EVENT, EXPAND, GET_CURRENT_POSITION, GET_DEFAULT_POSITION, GET_MAX_SIZE, GET_RESIZE_PROPERTIES, GET_SCREEN_SIZE, OPEN, PLAY_VIDEO, RESIZE, SET_ORIENTATION_PROPERTIES, SET_RESIZE_PROPERTIES, STORE_PICTURE, UNSPECIFIED, USECUSTOMCLOSE;
  
  private String mCommand;
  
  static {
    g g1 = new g("CLOSE", 0, "close");
    CLOSE = g1;
    g g2 = new g("EXPAND", 1, "expand");
    EXPAND = g2;
    g g3 = new g("USECUSTOMCLOSE", 2, "usecustomclose");
    USECUSTOMCLOSE = g3;
    g g4 = new g("OPEN", 3, "open");
    OPEN = g4;
    g g5 = new g("RESIZE", 4, "resize");
    RESIZE = g5;
    g g6 = new g("GET_RESIZE_PROPERTIES", 5, "getResizeProperties");
    GET_RESIZE_PROPERTIES = g6;
    g g7 = new g("SET_RESIZE_PROPERTIES", 6, "setResizeProperties");
    SET_RESIZE_PROPERTIES = g7;
    g g8 = new g("SET_ORIENTATION_PROPERTIES", 7, "setOrientationProperties");
    SET_ORIENTATION_PROPERTIES = g8;
    g g9 = new g("PLAY_VIDEO", 8, "playVideo");
    PLAY_VIDEO = g9;
    g g10 = new g("STORE_PICTURE", 9, "storePicture");
    STORE_PICTURE = g10;
    g g11 = new g("GET_CURRENT_POSITION", 10, "getCurrentPosition");
    GET_CURRENT_POSITION = g11;
    g g12 = new g("GET_DEFAULT_POSITION", 11, "getDefaultPosition");
    GET_DEFAULT_POSITION = g12;
    g g13 = new g("GET_MAX_SIZE", 12, "getMaxSize");
    GET_MAX_SIZE = g13;
    g g14 = new g("GET_SCREEN_SIZE", 13, "getScreenSize");
    GET_SCREEN_SIZE = g14;
    g g15 = new g("CREATE_CALENDAR_EVENT", 14, "createCalendarEvent");
    CREATE_CALENDAR_EVENT = g15;
    g g16 = new g("UNSPECIFIED", 15, "");
    UNSPECIFIED = g16;
    $VALUES = new g[] { 
        g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, 
        g11, g12, g13, g14, g15, g16 };
  }
  
  g(String paramString1) {
    this.mCommand = paramString1;
  }
  
  public static g a(String paramString) {
    for (g g1 : values()) {
      if (g1.mCommand.equals(paramString))
        return g1; 
    } 
    return UNSPECIFIED;
  }
  
  public String e() {
    return this.mCommand;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */