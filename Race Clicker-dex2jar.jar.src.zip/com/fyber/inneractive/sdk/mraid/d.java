package com.fyber.inneractive.sdk.mraid;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.j;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.i;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import java.util.Map;

public class d extends a {
  public d(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.inneractive");
    paramContext.startActivity(paramIntent);
  }
  
  public void a() {
    i i = this.c;
    Map<String, String> map = this.b;
    Context context = i.l();
    boolean bool1 = j.a((new Intent("android.intent.action.INSERT")).setType("vnd.android.cursor.item/event"));
    boolean bool = false;
    if (bool1) {
      try {
        Map map1 = i.a(map);
        Intent intent = (new Intent("android.intent.action.INSERT")).setType("vnd.android.cursor.item/event");
        map1 = map1;
        for (String str : map1.keySet()) {
          Object object = map1.get(str);
          if (object instanceof Long) {
            intent.putExtra(str, ((Long)object).longValue());
            continue;
          } 
          if (object instanceof Integer) {
            intent.putExtra(str, ((Integer)object).intValue());
            continue;
          } 
          intent.putExtra(str, (String)object);
        } 
        intent.setFlags(268435456);
        safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(context, intent);
        bool = true;
      } catch (ActivityNotFoundException activityNotFoundException) {
        IAlog.a("There is no calendar app installed!", new Object[0]);
        i.a(g.CREATE_CALENDAR_EVENT, "Action is unsupported on this device - no calendar app installed");
      } catch (IllegalArgumentException illegalArgumentException) {
        IAlog.a("invalid parameters for create calendar ", new Object[] { illegalArgumentException.getMessage() });
        i.a(g.CREATE_CALENDAR_EVENT, illegalArgumentException.getMessage());
      } catch (Exception exception) {
        IAlog.a("Failed to create calendar event.", new Object[0]);
        i.a(g.CREATE_CALENDAR_EVENT, "could not create calendar event");
      } 
    } else {
      IAlog.a("createCalendarEvent supported for devices post-ICS", new Object[0]);
      i.a(g.CREATE_CALENDAR_EVENT, "Action is unsupported on this device (need Android version Ice Cream Sandwich or above)");
    } 
    if (bool) {
      d0 d0 = ((com.fyber.inneractive.sdk.web.d)i).g;
      if (d0 != null)
        ((i.f)d0).c(); 
    } 
  }
  
  public String c() {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */