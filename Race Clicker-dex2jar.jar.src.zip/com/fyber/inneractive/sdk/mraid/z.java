package com.fyber.inneractive.sdk.mraid;

public class z extends u {
  public final b0 a;
  
  public z(b0 paramb0) {
    this.a = paramb0;
  }
  
  public String a() {
    StringBuilder stringBuilder = new StringBuilder("state: '");
    stringBuilder.append(this.a.toString().toLowerCase());
    stringBuilder.append("'");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */