package com.fyber.inneractive.sdk.mraid;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.q;
import com.fyber.inneractive.sdk.web.d;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.g;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class o extends b {
  public o(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    int k = a("w");
    int j = a("h");
    int i = a("offsetX");
    int n = a("offsetY");
    boolean bool = "true".equals(this.b.get("allowOffscreen"));
    String str = this.b.get("customClosePosition");
    int m = k;
    if (k <= 0)
      m = this.c.Z; 
    int i1 = j;
    if (j <= 0)
      i1 = this.c.a0; 
    i i2 = this.c;
    g g = ((d)i2).b;
    if (g == null)
      return; 
    try {
      RelativeLayout.LayoutParams layoutParams;
      ViewGroup viewGroup = (ViewGroup)g.getRootView().findViewById(16908290);
      i2.R = viewGroup;
      if (viewGroup == null) {
        IAlog.e("Couldn't find content in the view tree", new Object[0]);
        i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
        return;
      } 
      if (i2.O == i.d.DISABLED)
        return; 
      b0 b02 = i2.N;
      if (b02 != b0.DEFAULT && b02 != b0.RESIZED) {
        i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
        return;
      } 
      if (m < 0 && i1 < 0) {
        i2.a(g.RESIZE, "Creative size passed to resize() was invalid.");
        return;
      } 
      i2.c(false);
      i.h h = i2.P;
      if (h == i.h.ALWAYS_VISIBLE || (!i2.X && h != i.h.ALWAYS_HIDDEN))
        i2.d(true); 
      i2.e(false);
      i2.e0 = l.b(i1);
      i2.d0 = l.b(m);
      int i3 = i;
      k = n;
      if (!bool) {
        k = i + m - i2.Z;
        j = i;
        if (k > 0)
          j = i - k; 
        i = j;
        if (j < 0)
          i = 0; 
        k = n + i1 - i2.a0;
        j = n;
        if (k > 0)
          j = n - k; 
        i3 = i;
        k = j;
        if (j < 0) {
          k = 0;
          i3 = i;
        } 
      } 
      ViewGroup.LayoutParams layoutParams1 = ((d)i2).b.getLayoutParams();
      if (layoutParams1 instanceof RelativeLayout.LayoutParams) {
        if (i3 == 0 && k == 0) {
          int[] arrayOfInt = new int[1];
          arrayOfInt[0] = 13;
        } else {
          layoutParams1 = null;
        } 
        layoutParams = q.a(l.b(m), l.b(i1), (int[])layoutParams1);
        layoutParams.leftMargin = i3;
        layoutParams.topMargin = k;
        ((d)i2).b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      } else if (layoutParams instanceof FrameLayout.LayoutParams) {
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(l.b(m), l.b(i1), 17);
        ((d)i2).b.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      } 
      b0 b01 = i2.N;
      b0 b03 = b0.RESIZED;
      if (b01 != b03) {
        i2.N = b03;
        i2.a(new z(b03));
        i = i2.d0;
        if (i != -1 && i2.e0 != -1)
          i2.a(new t(l.c(i), l.c(i2.e0))); 
      } 
      i2.a(g.RESIZE);
      RelativeLayout relativeLayout = i2.a((View)((d)i2).b.getParent());
      g g1 = ((d)i2).b;
      if (g1 != null && relativeLayout != null)
        relativeLayout.setLayoutParams(g1.getLayoutParams()); 
      d0 d0 = ((d)i2).g;
      if (d0 != null) {
        ((i.f)d0).b(i2);
        return;
      } 
    } catch (Exception exception) {
      IAlog.e("Couldn't find content in the view tree", new Object[0]);
      i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
    } 
  }
  
  public boolean b() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */