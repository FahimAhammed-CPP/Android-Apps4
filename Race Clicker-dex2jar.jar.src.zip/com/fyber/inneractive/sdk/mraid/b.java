package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public abstract class b {
  public String a;
  
  public Map<String, String> b;
  
  public i c;
  
  public k0 d;
  
  public b(Map<String, String> paramMap, i parami, k0 paramk0) {
    this.b = paramMap;
    this.d = paramk0;
    this.c = parami;
  }
  
  public int a(String paramString) {
    paramString = this.b.get(paramString);
    if (paramString == null)
      return -1; 
    try {
      return Integer.parseInt(paramString, 10);
    } catch (NumberFormatException numberFormatException) {
      return -1;
    } 
  }
  
  public abstract void a();
  
  public abstract boolean b();
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */