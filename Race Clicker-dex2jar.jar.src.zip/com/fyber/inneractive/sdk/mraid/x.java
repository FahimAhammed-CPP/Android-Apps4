package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.web.i;

public class x extends u {
  public final i.g a;
  
  public x(i.g paramg) {
    this.a = paramg;
  }
  
  public String a() {
    StringBuilder stringBuilder = new StringBuilder("placementType: '");
    stringBuilder.append(this.a.toString().toLowerCase());
    stringBuilder.append("'");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */