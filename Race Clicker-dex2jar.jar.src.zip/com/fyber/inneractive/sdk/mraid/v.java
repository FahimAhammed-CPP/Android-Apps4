package com.fyber.inneractive.sdk.mraid;

public class v extends u {
  public final int a;
  
  public final int b;
  
  public final int c;
  
  public final int d;
  
  public v(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.a = paramInt3;
    this.b = paramInt4;
    this.d = paramInt2;
    this.c = paramInt1;
  }
  
  public String a() {
    StringBuilder stringBuilder = new StringBuilder("currentPosition: { x: ");
    stringBuilder.append(this.c);
    stringBuilder.append(", y: ");
    stringBuilder.append(this.d);
    stringBuilder.append(", width: ");
    stringBuilder.append(this.a);
    stringBuilder.append(", height: ");
    stringBuilder.append(this.b);
    stringBuilder.append(" }");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */