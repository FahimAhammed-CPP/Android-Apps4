package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.x;
import com.fyber.inneractive.sdk.web.d;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class m extends a {
  public m(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    String str = this.b.get("url");
    IAlog.d("IAmraidActionOpen: opening Internal Browser For Url: %s", new Object[] { str });
    i i = this.c;
    if (i != null) {
      x.a a1;
      k0 k0 = this.d;
      d0 d0 = ((d)i).g;
      if (d0 != null) {
        a1 = ((i.f)d0).a(str, k0, null);
      } else {
        String str1;
        x.d d = x.d.FAILED;
        Exception exception = new Exception("No webview listener available");
        if (a1.l() == null) {
          str1 = "null";
        } else {
          str1 = str1.l().getClass().getName();
        } 
        a1 = new x.a(d, exception, str1);
      } 
      if (a1.a == x.d.FAILED) {
        String str1;
        i i1 = this.c;
        g g = g.OPEN;
        Throwable throwable = a1.b;
        if (throwable == null) {
          str1 = "unknown error";
        } else {
          str1 = str1.getMessage();
        } 
        i1.a(g, str1);
      } 
    } 
  }
  
  public String c() {
    return this.b.get("url");
  }
  
  public void d() {
    i i = this.c;
    if (i != null)
      i.a(g.OPEN, "No native click was detected in a timely fashion"); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */