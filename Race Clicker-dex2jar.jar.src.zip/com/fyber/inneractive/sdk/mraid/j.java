package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class j extends b {
  public j(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    i i = this.c;
    i.a(new w(i.b0, i.c0));
  }
  
  public boolean b() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */