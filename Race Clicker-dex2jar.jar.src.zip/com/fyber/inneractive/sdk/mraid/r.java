package com.fyber.inneractive.sdk.mraid;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.j;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.m;
import com.fyber.inneractive.sdk.web.i;
import com.fyber.inneractive.sdk.web.o;
import com.fyber.inneractive.sdk.web.q;
import java.util.Map;

public class r extends a {
  public r(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    String str = this.b.get("uri");
    if (str != null && !"".equals(str)) {
      i i = this.c;
      Context context = i.l();
      if (!j.m()) {
        i.a(g.STORE_PICTURE, "Error downloading file - the device does not have an SD card mounted, or the Android permission is not granted.");
        IAlog.a("Error downloading file. Please check if the Android permission is not granted, or maybe the device does not have an SD card mounted? ", new Object[0]);
        return;
      } 
      if (context instanceof android.app.Activity) {
        (new AlertDialog.Builder(i.l())).setTitle("Save Image").setMessage("Download image to Picture gallery?").setNegativeButton("Cancel", null).setPositiveButton("Okay", (DialogInterface.OnClickListener)new q(i, str)).setCancelable(true).show();
        return;
      } 
      m.b.post((Runnable)new o(i, "Downloading image to Picture gallery..."));
      i.a(str);
      return;
    } 
    this.c.a(g.STORE_PICTURE, "Image can't be stored with null or empty URL");
    IAlog.a("Mraid Store Picture -Invalid URI ", new Object[0]);
  }
  
  public String c() {
    return this.b.get("uri");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */