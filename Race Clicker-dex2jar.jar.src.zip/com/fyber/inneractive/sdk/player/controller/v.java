package com.fyber.inneractive.sdk.player.controller;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.fyber.inneractive.sdk.R;
import com.fyber.inneractive.sdk.util.m0;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;

public class v {
  public final Context a;
  
  public final c b;
  
  public final Dialog c;
  
  public final com.fyber.inneractive.sdk.config.global.features.b d;
  
  public v(Context paramContext, com.fyber.inneractive.sdk.config.global.features.b paramb, c paramc) {
    this.a = paramContext;
    this.d = paramb;
    this.b = paramc;
    this.c = new Dialog(paramContext);
    a();
  }
  
  public final void a() {
    this.c.requestWindowFeature(1);
    this.c.setContentView(R.layout.skip_rewarded_dialog);
    Button button1 = (Button)this.c.findViewById(R.id.keep_watching_button);
    Button button2 = (Button)this.c.findViewById(R.id.close_button);
    TextView textView1 = (TextView)this.c.findViewById(R.id.skip_dialog_title_textview);
    TextView textView2 = (TextView)this.c.findViewById(R.id.skip_dialog_sub_title_textview);
    String str2 = this.a.getString(R.string.skip_rewarded_dialog_keep_watching);
    String str3 = this.a.getString(R.string.skip_rewarded_dialog_close_button);
    String str4 = this.a.getString(R.string.skip_rewarded_dialog_title);
    String str8 = this.a.getString(R.string.skip_rewarded_dialog_sub_title);
    com.fyber.inneractive.sdk.config.global.features.b b1 = this.d;
    String str1 = str2;
    String str6 = str3;
    String str7 = str4;
    String str5 = str8;
    if (b1 != null) {
      str1 = "KEEP WATCHING";
      str5 = b1.a("skip_reward_dialog_keep_watching_button", "KEEP WATCHING");
      if (str5.trim().length() > 0)
        str1 = str5.trim(); 
      if (TextUtils.isEmpty(str1))
        str1 = str2; 
      com.fyber.inneractive.sdk.config.global.features.b b4 = this.d;
      str2 = "CLOSE";
      String str10 = b4.a("skip_reward_dialog_close_button", "CLOSE");
      if (str10.trim().length() > 0)
        str2 = str10.trim(); 
      if (TextUtils.isEmpty(str2))
        str2 = str3; 
      com.fyber.inneractive.sdk.config.global.features.b b3 = this.d;
      str3 = "Close Video?";
      String str9 = b3.a("skip_reward_dialog_title", "Close Video?");
      if (str9.trim().length() > 0)
        str3 = str9.trim(); 
      if (TextUtils.isEmpty(str3))
        str3 = str4; 
      com.fyber.inneractive.sdk.config.global.features.b b2 = this.d;
      str4 = "Reward will not be received before video completion.";
      str5 = b2.a("skip_reward_dialog_sub_title", "Reward will not be received before video completion.");
      if (str5.trim().length() > 0)
        str4 = str5.trim(); 
      if (TextUtils.isEmpty(str4)) {
        str6 = str2;
        str7 = str3;
        str5 = str8;
      } else {
        str5 = str4;
        str7 = str3;
        str6 = str2;
      } 
    } 
    button1.setText(m0.a(str1, 13));
    button2.setText(m0.a(str6, 13));
    textView1.setText(m0.a(str7, 20));
    textView2.setText(m0.a(str5, 100));
    button2.setOnClickListener(new a(this));
    button1.setOnClickListener(new b(this));
  }
  
  public class a implements View.OnClickListener {
    public a(v this$0) {}
    
    public void onClick(View param1View) {
      Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/player/controller/v$a;->onClick(Landroid/view/View;)V");
      CreativeInfoManager.onViewClicked("com.inneractive", param1View);
      safedk_v$a_onClick_d1e81e79588ff2dcac8679196f133a8f(param1View);
    }
    
    public void safedk_v$a_onClick_d1e81e79588ff2dcac8679196f133a8f(View param1View) {
      this.a.c.dismiss();
      r r = (r)this.a.b;
      r.b.f(r.a);
    }
  }
  
  public class b implements View.OnClickListener {
    public b(v this$0) {}
    
    public void onClick(View param1View) {
      Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/player/controller/v$b;->onClick(Landroid/view/View;)V");
      CreativeInfoManager.onViewClicked("com.inneractive", param1View);
      safedk_v$b_onClick_596b882dc627b98b52bf1ef0c9df6b00(param1View);
    }
    
    public void safedk_v$b_onClick_596b882dc627b98b52bf1ef0c9df6b00(View param1View) {
      this.a.c.dismiss();
      this.a.b.getClass();
    }
  }
  
  public static interface c {}
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\controller\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */