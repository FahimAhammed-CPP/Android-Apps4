package com.fyber.inneractive.sdk.player;

import com.fyber.inneractive.sdk.player.controller.g;
import com.fyber.inneractive.sdk.util.IAlog;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public class d {
  public g a;
  
  public ScheduledThreadPoolExecutor b;
  
  public Runnable c;
  
  public boolean d = false;
  
  public d(g paramg) {
    this.a = paramg;
    this.c = new a(this);
  }
  
  public class a implements Runnable {
    public a(d this$0) {}
    
    public void run() {
      d d1 = this.a;
      d1.getClass();
      IAlog.a("player progress monitor: run started", new Object[0]);
      int i = d1.a.c();
      if (!d1.d) {
        int j = i + 0;
        IAlog.a("run: 2 seconds passed? played for %d since last play started", new Object[] { Integer.valueOf(j) });
        if (j >= 2000) {
          IAlog.a("run: setting played 2 seconds flag", new Object[0]);
          d1.d = true;
        } 
      } 
      d1.a.a(i);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */