package com.fyber.inneractive.sdk.player.exoplayer2.extractor.ts;

import com.fyber.inneractive.sdk.player.exoplayer2.extractor.h;
import com.fyber.inneractive.sdk.player.exoplayer2.extractor.n;
import com.fyber.inneractive.sdk.player.exoplayer2.util.i;

public final class k implements h {
  public final s a;
  
  public String b;
  
  public n c;
  
  public a d;
  
  public boolean e;
  
  public final boolean[] f;
  
  public final n g;
  
  public final n h;
  
  public final n i;
  
  public final n j;
  
  public final n k;
  
  public long l;
  
  public long m;
  
  public final com.fyber.inneractive.sdk.player.exoplayer2.util.k n;
  
  public k(s params) {
    this.a = params;
    this.f = new boolean[3];
    this.g = new n(32, 128);
    this.h = new n(33, 128);
    this.i = new n(34, 128);
    this.j = new n(39, 128);
    this.k = new n(40, 128);
    this.n = new com.fyber.inneractive.sdk.player.exoplayer2.util.k();
  }
  
  public void a() {
    i.a(this.f);
    this.g.a();
    this.h.a();
    this.i.a();
    this.j.a();
    this.k.a();
    a a1 = this.d;
    a1.f = false;
    a1.g = false;
    a1.h = false;
    a1.i = false;
    a1.j = false;
    this.l = 0L;
  }
  
  public void a(long paramLong, boolean paramBoolean) {
    this.m = paramLong;
  }
  
  public void a(h paramh, v.d paramd) {
    paramd.a();
    this.b = paramd.b();
    n n1 = paramh.a(paramd.c(), 2);
    this.c = n1;
    this.d = new a(n1);
    this.a.a(paramh, paramd);
  }
  
  public void a(com.fyber.inneractive.sdk.player.exoplayer2.util.k paramk) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (this.e) {
      a a1 = this.d;
      if (a1.f) {
        int i = a1.d;
        int j = paramInt1 + 2 - i;
        if (j < paramInt2) {
          boolean bool;
          if ((paramArrayOfbyte[j] & 0x80) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          a1.g = bool;
          a1.f = false;
        } else {
          a1.d = i + paramInt2 - paramInt1;
        } 
      } 
    } else {
      this.g.a(paramArrayOfbyte, paramInt1, paramInt2);
      this.h.a(paramArrayOfbyte, paramInt1, paramInt2);
      this.i.a(paramArrayOfbyte, paramInt1, paramInt2);
    } 
    this.j.a(paramArrayOfbyte, paramInt1, paramInt2);
    this.k.a(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  public void b() {}
  
  public static final class a {
    public final n a;
    
    public long b;
    
    public boolean c;
    
    public int d;
    
    public long e;
    
    public boolean f;
    
    public boolean g;
    
    public boolean h;
    
    public boolean i;
    
    public boolean j;
    
    public long k;
    
    public long l;
    
    public boolean m;
    
    public a(n param1n) {
      this.a = param1n;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\extractor\ts\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */