package com.fyber.inneractive.sdk.player.exoplayer2.extractor.mp4;

import android.util.Pair;
import com.fyber.inneractive.sdk.player.exoplayer2.i;
import com.fyber.inneractive.sdk.player.exoplayer2.l;
import com.fyber.inneractive.sdk.player.exoplayer2.util.k;
import com.fyber.inneractive.sdk.player.exoplayer2.util.u;

public final class b {
  public static final int a = u.a("vide");
  
  public static final int b = u.a("soun");
  
  public static final int c = u.a("text");
  
  public static final int d = u.a("sbtl");
  
  public static final int e = u.a("subt");
  
  public static final int f = u.a("clcp");
  
  public static final int g = u.a("cenc");
  
  public static final int h = u.a("meta");
  
  public static int a(k paramk) {
    int j = paramk.l();
    int i;
    for (i = j & 0x7F; (j & 0x80) == 128; i = i << 7 | j & 0x7F)
      j = paramk.l(); 
    return i;
  }
  
  public static int a(k paramk, int paramInt1, int paramInt2, b paramb, int paramInt3) {
    int i = paramk.b;
    while (true) {
      boolean bool = false;
      if (i - paramInt1 < paramInt2) {
        boolean bool1;
        paramk.e(i);
        int j = paramk.c();
        if (j > 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        com.fyber.inneractive.sdk.player.exoplayer2.util.a.a(bool1, "childAtomSize should be positive");
        if (paramk.c() == a.W) {
          int m = i + 8;
          Pair pair2 = null;
          byte[] arrayOfByte2 = null;
          byte[] arrayOfByte1 = arrayOfByte2;
          int n = 0;
          while (m - i < j) {
            int i1;
            byte[] arrayOfByte;
            paramk.e(m);
            int i2 = paramk.c();
            int i3 = paramk.c();
            if (i3 == a.c0) {
              Integer integer = Integer.valueOf(paramk.c());
              i1 = n;
            } else if (i3 == a.X) {
              paramk.f(4);
              if (paramk.c() == g) {
                i1 = 1;
                arrayOfByte = arrayOfByte2;
              } else {
                i1 = 0;
                arrayOfByte = arrayOfByte2;
              } 
            } else {
              i1 = n;
              arrayOfByte = arrayOfByte2;
              if (i3 == a.Y) {
                i1 = m + 8;
                while (true) {
                  if (i1 - m < i2) {
                    paramk.e(i1);
                    i3 = paramk.c();
                    if (paramk.c() == a.Z) {
                      paramk.f(6);
                      if (paramk.l() == 1) {
                        bool1 = true;
                      } else {
                        bool1 = false;
                      } 
                      i1 = paramk.l();
                      arrayOfByte1 = new byte[16];
                      System.arraycopy(paramk.a, paramk.b, arrayOfByte1, 0, 16);
                      paramk.b += 16;
                      i i4 = new i(bool1, i1, arrayOfByte1);
                      i1 = n;
                      arrayOfByte = arrayOfByte2;
                      break;
                    } 
                    i1 += i3;
                    continue;
                  } 
                  arrayOfByte1 = null;
                  arrayOfByte = arrayOfByte2;
                  i1 = n;
                  break;
                } 
              } 
            } 
            m += i2;
            n = i1;
            arrayOfByte2 = arrayOfByte;
          } 
          Pair pair1 = pair2;
          if (n != 0) {
            if (arrayOfByte2 != null) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            com.fyber.inneractive.sdk.player.exoplayer2.util.a.a(bool1, "frma atom is mandatory");
            bool1 = bool;
            if (arrayOfByte1 != null)
              bool1 = true; 
            com.fyber.inneractive.sdk.player.exoplayer2.util.a.a(bool1, "schi->tenc atom is mandatory");
            pair1 = Pair.create(arrayOfByte2, arrayOfByte1);
          } 
          if (pair1 != null) {
            paramb.a[paramInt3] = (i)pair1.second;
            return ((Integer)pair1.first).intValue();
          } 
        } 
        i += j;
        continue;
      } 
      return 0;
    } 
  }
  
  public static Pair<String, byte[]> a(k paramk, int paramInt) {
    paramk.e(paramInt + 8 + 4);
    paramk.f(1);
    a(paramk);
    paramk.f(2);
    paramInt = paramk.l();
    if ((paramInt & 0x80) != 0)
      paramk.f(2); 
    if ((paramInt & 0x40) != 0)
      paramk.f(paramk.q()); 
    if ((paramInt & 0x20) != 0)
      paramk.f(2); 
    paramk.f(1);
    a(paramk);
    paramInt = paramk.l();
    if (paramInt != 32) {
      if (paramInt != 33) {
        if (paramInt != 35) {
          if (paramInt != 64) {
            String str4 = null;
            if (paramInt != 107) {
              if (paramInt != 165) {
                if (paramInt != 166) {
                  byte[] arrayOfByte;
                  switch (paramInt) {
                    default:
                      switch (paramInt) {
                        default:
                          paramk.f(12);
                          paramk.f(1);
                          paramInt = a(paramk);
                          arrayOfByte = new byte[paramInt];
                          System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
                          paramk.b += paramInt;
                          return Pair.create(str4, arrayOfByte);
                        case 170:
                        case 171:
                          return Pair.create("audio/vnd.dts.hd", null);
                        case 169:
                        case 172:
                          break;
                      } 
                      return Pair.create("audio/vnd.dts", null);
                    case 102:
                    case 103:
                    case 104:
                      break;
                  } 
                } else {
                  str4 = "audio/eac3";
                } 
              } else {
                str4 = "audio/ac3";
              } 
            } else {
              return Pair.create("audio/mpeg", null);
            } 
          } 
          String str3 = "audio/mp4a-latm";
        } 
        String str2 = "video/hevc";
      } 
      String str1 = "video/avc";
    } 
    String str = "video/mp4v-es";
  }
  
  public static h a(a.a parama, a.b paramb, long paramLong, com.fyber.inneractive.sdk.player.exoplayer2.drm.a parama1, boolean paramBoolean) throws l {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.F : I
    //   4: invokevirtual c : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$a;
    //   7: astore #33
    //   9: aload #33
    //   11: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.T : I
    //   14: invokevirtual d : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$b;
    //   17: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   20: astore #34
    //   22: aload #34
    //   24: bipush #16
    //   26: invokevirtual e : (I)V
    //   29: aload #34
    //   31: invokevirtual c : ()I
    //   34: istore #8
    //   36: iload #8
    //   38: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.b : I
    //   41: if_icmpne -> 50
    //   44: iconst_1
    //   45: istore #8
    //   47: goto -> 122
    //   50: iload #8
    //   52: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.a : I
    //   55: if_icmpne -> 64
    //   58: iconst_2
    //   59: istore #8
    //   61: goto -> 122
    //   64: iload #8
    //   66: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.c : I
    //   69: if_icmpeq -> 119
    //   72: iload #8
    //   74: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.d : I
    //   77: if_icmpeq -> 119
    //   80: iload #8
    //   82: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.e : I
    //   85: if_icmpeq -> 119
    //   88: iload #8
    //   90: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.f : I
    //   93: if_icmpne -> 99
    //   96: goto -> 119
    //   99: iload #8
    //   101: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b.h : I
    //   104: if_icmpne -> 113
    //   107: iconst_4
    //   108: istore #8
    //   110: goto -> 122
    //   113: iconst_m1
    //   114: istore #8
    //   116: goto -> 122
    //   119: iconst_3
    //   120: istore #8
    //   122: iload #8
    //   124: iconst_m1
    //   125: if_icmpne -> 130
    //   128: aconst_null
    //   129: areturn
    //   130: aload_0
    //   131: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.P : I
    //   134: invokevirtual d : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$b;
    //   137: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   140: astore #34
    //   142: aload #34
    //   144: bipush #8
    //   146: invokevirtual e : (I)V
    //   149: aload #34
    //   151: invokevirtual c : ()I
    //   154: invokestatic b : (I)I
    //   157: istore #11
    //   159: iload #11
    //   161: ifne -> 171
    //   164: bipush #8
    //   166: istore #9
    //   168: goto -> 175
    //   171: bipush #16
    //   173: istore #9
    //   175: aload #34
    //   177: iload #9
    //   179: invokevirtual f : (I)V
    //   182: aload #34
    //   184: invokevirtual c : ()I
    //   187: istore #20
    //   189: aload #34
    //   191: iconst_4
    //   192: invokevirtual f : (I)V
    //   195: aload #34
    //   197: getfield b : I
    //   200: istore #12
    //   202: iload #11
    //   204: ifne -> 213
    //   207: iconst_4
    //   208: istore #9
    //   210: goto -> 217
    //   213: bipush #8
    //   215: istore #9
    //   217: iconst_0
    //   218: istore #10
    //   220: iload #10
    //   222: iload #9
    //   224: if_icmpge -> 257
    //   227: aload #34
    //   229: getfield a : [B
    //   232: iload #12
    //   234: iload #10
    //   236: iadd
    //   237: baload
    //   238: iconst_m1
    //   239: if_icmpeq -> 248
    //   242: iconst_0
    //   243: istore #10
    //   245: goto -> 260
    //   248: iload #10
    //   250: iconst_1
    //   251: iadd
    //   252: istore #10
    //   254: goto -> 220
    //   257: iconst_1
    //   258: istore #10
    //   260: ldc2_w -9223372036854775807
    //   263: lstore #30
    //   265: iload #10
    //   267: ifeq -> 285
    //   270: aload #34
    //   272: iload #9
    //   274: invokevirtual f : (I)V
    //   277: ldc2_w -9223372036854775807
    //   280: lstore #28
    //   282: goto -> 321
    //   285: iload #11
    //   287: ifne -> 300
    //   290: aload #34
    //   292: invokevirtual m : ()J
    //   295: lstore #26
    //   297: goto -> 307
    //   300: aload #34
    //   302: invokevirtual p : ()J
    //   305: lstore #26
    //   307: lload #26
    //   309: lstore #28
    //   311: lload #26
    //   313: lconst_0
    //   314: lcmp
    //   315: ifne -> 321
    //   318: goto -> 277
    //   321: aload #34
    //   323: bipush #16
    //   325: invokevirtual f : (I)V
    //   328: aload #34
    //   330: invokevirtual c : ()I
    //   333: istore #9
    //   335: aload #34
    //   337: invokevirtual c : ()I
    //   340: istore #10
    //   342: aload #34
    //   344: iconst_4
    //   345: invokevirtual f : (I)V
    //   348: aload #34
    //   350: invokevirtual c : ()I
    //   353: istore #11
    //   355: aload #34
    //   357: invokevirtual c : ()I
    //   360: istore #12
    //   362: iload #9
    //   364: ifne -> 393
    //   367: iload #10
    //   369: ldc 65536
    //   371: if_icmpne -> 393
    //   374: iload #11
    //   376: ldc -65536
    //   378: if_icmpne -> 393
    //   381: iload #12
    //   383: ifne -> 393
    //   386: bipush #90
    //   388: istore #10
    //   390: goto -> 460
    //   393: iload #9
    //   395: ifne -> 425
    //   398: iload #10
    //   400: ldc -65536
    //   402: if_icmpne -> 425
    //   405: iload #11
    //   407: ldc 65536
    //   409: if_icmpne -> 425
    //   412: iload #12
    //   414: ifne -> 425
    //   417: sipush #270
    //   420: istore #10
    //   422: goto -> 460
    //   425: iload #9
    //   427: ldc -65536
    //   429: if_icmpne -> 457
    //   432: iload #10
    //   434: ifne -> 457
    //   437: iload #11
    //   439: ifne -> 457
    //   442: iload #12
    //   444: ldc -65536
    //   446: if_icmpne -> 457
    //   449: sipush #180
    //   452: istore #10
    //   454: goto -> 460
    //   457: iconst_0
    //   458: istore #10
    //   460: lload_2
    //   461: ldc2_w -9223372036854775807
    //   464: lcmp
    //   465: ifne -> 474
    //   468: lload #28
    //   470: lstore_2
    //   471: goto -> 474
    //   474: aload_1
    //   475: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   478: astore_1
    //   479: aload_1
    //   480: bipush #8
    //   482: invokevirtual e : (I)V
    //   485: aload_1
    //   486: invokevirtual c : ()I
    //   489: invokestatic b : (I)I
    //   492: ifne -> 502
    //   495: bipush #8
    //   497: istore #9
    //   499: goto -> 506
    //   502: bipush #16
    //   504: istore #9
    //   506: aload_1
    //   507: iload #9
    //   509: invokevirtual f : (I)V
    //   512: aload_1
    //   513: invokevirtual m : ()J
    //   516: lstore #28
    //   518: lload_2
    //   519: ldc2_w -9223372036854775807
    //   522: lcmp
    //   523: ifne -> 533
    //   526: lload #30
    //   528: lstore #26
    //   530: goto -> 544
    //   533: lload_2
    //   534: ldc2_w 1000000
    //   537: lload #28
    //   539: invokestatic a : (JJJ)J
    //   542: lstore #26
    //   544: aload #33
    //   546: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.G : I
    //   549: invokevirtual c : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$a;
    //   552: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.H : I
    //   555: invokevirtual c : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$a;
    //   558: astore_1
    //   559: aload #33
    //   561: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.S : I
    //   564: invokevirtual d : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$b;
    //   567: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   570: astore #33
    //   572: aload #33
    //   574: bipush #8
    //   576: invokevirtual e : (I)V
    //   579: aload #33
    //   581: invokevirtual c : ()I
    //   584: invokestatic b : (I)I
    //   587: istore #11
    //   589: iload #11
    //   591: ifne -> 601
    //   594: bipush #8
    //   596: istore #9
    //   598: goto -> 605
    //   601: bipush #16
    //   603: istore #9
    //   605: aload #33
    //   607: iload #9
    //   609: invokevirtual f : (I)V
    //   612: aload #33
    //   614: invokevirtual m : ()J
    //   617: lstore_2
    //   618: iload #11
    //   620: ifne -> 629
    //   623: iconst_4
    //   624: istore #9
    //   626: goto -> 633
    //   629: bipush #8
    //   631: istore #9
    //   633: aload #33
    //   635: iload #9
    //   637: invokevirtual f : (I)V
    //   640: aload #33
    //   642: invokevirtual q : ()I
    //   645: istore #9
    //   647: new java/lang/StringBuilder
    //   650: dup
    //   651: ldc ''
    //   653: invokespecial <init> : (Ljava/lang/String;)V
    //   656: astore #33
    //   658: aload #33
    //   660: iload #9
    //   662: bipush #10
    //   664: ishr
    //   665: bipush #31
    //   667: iand
    //   668: bipush #96
    //   670: iadd
    //   671: i2c
    //   672: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   675: pop
    //   676: aload #33
    //   678: iload #9
    //   680: iconst_5
    //   681: ishr
    //   682: bipush #31
    //   684: iand
    //   685: bipush #96
    //   687: iadd
    //   688: i2c
    //   689: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   692: pop
    //   693: aload #33
    //   695: iload #9
    //   697: bipush #31
    //   699: iand
    //   700: bipush #96
    //   702: iadd
    //   703: i2c
    //   704: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   707: pop
    //   708: lload_2
    //   709: invokestatic valueOf : (J)Ljava/lang/Long;
    //   712: aload #33
    //   714: invokevirtual toString : ()Ljava/lang/String;
    //   717: invokestatic create : (Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;
    //   720: astore #38
    //   722: aload_1
    //   723: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.U : I
    //   726: invokevirtual d : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$b;
    //   729: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   732: astore #41
    //   734: aload #38
    //   736: getfield second : Ljava/lang/Object;
    //   739: checkcast java/lang/String
    //   742: astore #42
    //   744: aload #41
    //   746: bipush #12
    //   748: invokevirtual e : (I)V
    //   751: aload #41
    //   753: invokevirtual c : ()I
    //   756: istore #16
    //   758: new com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b$b
    //   761: dup
    //   762: iload #16
    //   764: invokespecial <init> : (I)V
    //   767: astore #40
    //   769: iconst_0
    //   770: istore #9
    //   772: iload #8
    //   774: istore #15
    //   776: iload #10
    //   778: istore #8
    //   780: iload #9
    //   782: iload #16
    //   784: if_icmpge -> 3591
    //   787: aload #41
    //   789: getfield b : I
    //   792: istore #21
    //   794: aload #41
    //   796: invokevirtual c : ()I
    //   799: istore #10
    //   801: iload #10
    //   803: ifle -> 812
    //   806: iconst_1
    //   807: istore #32
    //   809: goto -> 815
    //   812: iconst_0
    //   813: istore #32
    //   815: ldc 'childAtomSize should be positive'
    //   817: astore #33
    //   819: iload #32
    //   821: ldc 'childAtomSize should be positive'
    //   823: invokestatic a : (ZLjava/lang/Object;)V
    //   826: aload #41
    //   828: invokevirtual c : ()I
    //   831: istore #13
    //   833: iload #13
    //   835: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.c : I
    //   838: if_icmpeq -> 2518
    //   841: iload #13
    //   843: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.d : I
    //   846: if_icmpeq -> 2518
    //   849: iload #13
    //   851: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.a0 : I
    //   854: if_icmpeq -> 2518
    //   857: iload #13
    //   859: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.l0 : I
    //   862: if_icmpeq -> 2518
    //   865: iload #13
    //   867: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.e : I
    //   870: if_icmpeq -> 2518
    //   873: iload #13
    //   875: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.f : I
    //   878: if_icmpeq -> 2518
    //   881: iload #13
    //   883: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.g : I
    //   886: if_icmpeq -> 2518
    //   889: iload #13
    //   891: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.K0 : I
    //   894: if_icmpeq -> 2518
    //   897: iload #13
    //   899: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.L0 : I
    //   902: if_icmpne -> 908
    //   905: goto -> 2518
    //   908: iload #13
    //   910: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.j : I
    //   913: if_icmpeq -> 1307
    //   916: iload #13
    //   918: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.b0 : I
    //   921: if_icmpeq -> 1307
    //   924: iload #13
    //   926: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.o : I
    //   929: if_icmpeq -> 1307
    //   932: iload #13
    //   934: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.q : I
    //   937: if_icmpeq -> 1307
    //   940: iload #13
    //   942: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.s : I
    //   945: if_icmpeq -> 1307
    //   948: iload #13
    //   950: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.v : I
    //   953: if_icmpeq -> 1307
    //   956: iload #13
    //   958: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.t : I
    //   961: if_icmpeq -> 1307
    //   964: iload #13
    //   966: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.u : I
    //   969: if_icmpeq -> 1307
    //   972: iload #13
    //   974: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.y0 : I
    //   977: if_icmpeq -> 1307
    //   980: iload #13
    //   982: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.z0 : I
    //   985: if_icmpeq -> 1307
    //   988: iload #13
    //   990: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.m : I
    //   993: if_icmpeq -> 1307
    //   996: iload #13
    //   998: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.n : I
    //   1001: if_icmpeq -> 1307
    //   1004: iload #13
    //   1006: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.k : I
    //   1009: if_icmpeq -> 1307
    //   1012: iload #13
    //   1014: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.O0 : I
    //   1017: if_icmpne -> 1023
    //   1020: goto -> 1307
    //   1023: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.k0 : I
    //   1026: istore #11
    //   1028: iload #13
    //   1030: iload #11
    //   1032: if_icmpeq -> 1104
    //   1035: iload #13
    //   1037: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.u0 : I
    //   1040: if_icmpeq -> 1104
    //   1043: iload #13
    //   1045: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.v0 : I
    //   1048: if_icmpeq -> 1104
    //   1051: iload #13
    //   1053: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.w0 : I
    //   1056: if_icmpeq -> 1104
    //   1059: iload #13
    //   1061: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.x0 : I
    //   1064: if_icmpne -> 1070
    //   1067: goto -> 1104
    //   1070: iload #13
    //   1072: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.N0 : I
    //   1075: if_icmpne -> 1101
    //   1078: aload #40
    //   1080: iload #20
    //   1082: invokestatic toString : (I)Ljava/lang/String;
    //   1085: ldc_w 'application/x-camera-motion'
    //   1088: aconst_null
    //   1089: iconst_m1
    //   1090: aload #4
    //   1092: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1095: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1098: goto -> 1410
    //   1101: goto -> 1410
    //   1104: aload #41
    //   1106: iload #21
    //   1108: bipush #8
    //   1110: iadd
    //   1111: bipush #8
    //   1113: iadd
    //   1114: invokevirtual e : (I)V
    //   1117: iload #13
    //   1119: iload #11
    //   1121: if_icmpne -> 1138
    //   1124: ldc2_w 9223372036854775807
    //   1127: lstore_2
    //   1128: aconst_null
    //   1129: astore #33
    //   1131: ldc_w 'application/ttml+xml'
    //   1134: astore_1
    //   1135: goto -> 1271
    //   1138: iload #13
    //   1140: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.u0 : I
    //   1143: if_icmpne -> 1208
    //   1146: iload #10
    //   1148: bipush #8
    //   1150: isub
    //   1151: bipush #8
    //   1153: isub
    //   1154: istore #11
    //   1156: iload #11
    //   1158: newarray byte
    //   1160: astore_1
    //   1161: aload #41
    //   1163: getfield a : [B
    //   1166: aload #41
    //   1168: getfield b : I
    //   1171: aload_1
    //   1172: iconst_0
    //   1173: iload #11
    //   1175: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1178: aload #41
    //   1180: aload #41
    //   1182: getfield b : I
    //   1185: iload #11
    //   1187: iadd
    //   1188: putfield b : I
    //   1191: aload_1
    //   1192: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   1195: astore #33
    //   1197: ldc2_w 9223372036854775807
    //   1200: lstore_2
    //   1201: ldc_w 'application/x-quicktime-tx3g'
    //   1204: astore_1
    //   1205: goto -> 1271
    //   1208: iload #13
    //   1210: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.v0 : I
    //   1213: if_icmpne -> 1230
    //   1216: ldc_w 'application/x-mp4-vtt'
    //   1219: astore_1
    //   1220: ldc2_w 9223372036854775807
    //   1223: lstore_2
    //   1224: aconst_null
    //   1225: astore #33
    //   1227: goto -> 1271
    //   1230: iload #13
    //   1232: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.w0 : I
    //   1235: if_icmpne -> 1250
    //   1238: ldc_w 'application/ttml+xml'
    //   1241: astore_1
    //   1242: lconst_0
    //   1243: lstore_2
    //   1244: aconst_null
    //   1245: astore #33
    //   1247: goto -> 1271
    //   1250: iload #13
    //   1252: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.x0 : I
    //   1255: if_icmpne -> 1299
    //   1258: aload #40
    //   1260: iconst_1
    //   1261: putfield d : I
    //   1264: ldc_w 'application/x-mp4-cea-608'
    //   1267: astore_1
    //   1268: goto -> 1220
    //   1271: aload #40
    //   1273: iload #20
    //   1275: invokestatic toString : (I)Ljava/lang/String;
    //   1278: aload_1
    //   1279: aconst_null
    //   1280: iconst_m1
    //   1281: iconst_0
    //   1282: aload #42
    //   1284: iconst_m1
    //   1285: aload #4
    //   1287: lload_2
    //   1288: aload #33
    //   1290: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;ILcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;JLjava/util/List;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1293: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1296: goto -> 1410
    //   1299: new java/lang/IllegalStateException
    //   1302: dup
    //   1303: invokespecial <init> : ()V
    //   1306: athrow
    //   1307: aload #41
    //   1309: iload #21
    //   1311: bipush #8
    //   1313: iadd
    //   1314: bipush #8
    //   1316: iadd
    //   1317: invokevirtual e : (I)V
    //   1320: iload #5
    //   1322: ifeq -> 1342
    //   1325: aload #41
    //   1327: invokevirtual q : ()I
    //   1330: istore #11
    //   1332: aload #41
    //   1334: bipush #6
    //   1336: invokevirtual f : (I)V
    //   1339: goto -> 1352
    //   1342: aload #41
    //   1344: bipush #8
    //   1346: invokevirtual f : (I)V
    //   1349: iconst_0
    //   1350: istore #11
    //   1352: iload #11
    //   1354: ifeq -> 1425
    //   1357: iload #11
    //   1359: iconst_1
    //   1360: if_icmpne -> 1366
    //   1363: goto -> 1425
    //   1366: iload #11
    //   1368: iconst_2
    //   1369: if_icmpne -> 1410
    //   1372: aload #41
    //   1374: bipush #16
    //   1376: invokevirtual f : (I)V
    //   1379: aload #41
    //   1381: invokevirtual i : ()J
    //   1384: invokestatic longBitsToDouble : (J)D
    //   1387: invokestatic round : (D)J
    //   1390: l2i
    //   1391: istore #12
    //   1393: aload #41
    //   1395: invokevirtual o : ()I
    //   1398: istore #11
    //   1400: aload #41
    //   1402: bipush #20
    //   1404: invokevirtual f : (I)V
    //   1407: goto -> 1534
    //   1410: iload #9
    //   1412: istore #11
    //   1414: iload #10
    //   1416: istore #9
    //   1418: iload #11
    //   1420: istore #10
    //   1422: goto -> 3572
    //   1425: aload #41
    //   1427: invokevirtual q : ()I
    //   1430: istore #12
    //   1432: aload #41
    //   1434: bipush #6
    //   1436: invokevirtual f : (I)V
    //   1439: aload #41
    //   1441: getfield a : [B
    //   1444: astore_1
    //   1445: aload #41
    //   1447: getfield b : I
    //   1450: istore #17
    //   1452: iload #17
    //   1454: iconst_1
    //   1455: iadd
    //   1456: istore #14
    //   1458: aload #41
    //   1460: iload #14
    //   1462: putfield b : I
    //   1465: aload_1
    //   1466: iload #17
    //   1468: baload
    //   1469: istore #18
    //   1471: iload #14
    //   1473: iconst_1
    //   1474: iadd
    //   1475: istore #17
    //   1477: aload #41
    //   1479: iload #17
    //   1481: putfield b : I
    //   1484: aload_1
    //   1485: iload #14
    //   1487: baload
    //   1488: sipush #255
    //   1491: iand
    //   1492: iload #18
    //   1494: sipush #255
    //   1497: iand
    //   1498: bipush #8
    //   1500: ishl
    //   1501: ior
    //   1502: istore #14
    //   1504: aload #41
    //   1506: iload #17
    //   1508: iconst_2
    //   1509: iadd
    //   1510: putfield b : I
    //   1513: iload #11
    //   1515: iconst_1
    //   1516: if_icmpne -> 1526
    //   1519: aload #41
    //   1521: bipush #16
    //   1523: invokevirtual f : (I)V
    //   1526: iload #12
    //   1528: istore #11
    //   1530: iload #14
    //   1532: istore #12
    //   1534: aload #41
    //   1536: getfield b : I
    //   1539: istore #17
    //   1541: iload #13
    //   1543: istore #14
    //   1545: iload #13
    //   1547: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.b0 : I
    //   1550: if_icmpne -> 1575
    //   1553: aload #41
    //   1555: iload #21
    //   1557: iload #10
    //   1559: aload #40
    //   1561: iload #9
    //   1563: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IILcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b$b;I)I
    //   1566: istore #14
    //   1568: aload #41
    //   1570: iload #17
    //   1572: invokevirtual e : (I)V
    //   1575: iload #14
    //   1577: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.o : I
    //   1580: if_icmpne -> 1589
    //   1583: ldc 'audio/ac3'
    //   1585: astore_1
    //   1586: goto -> 1744
    //   1589: iload #14
    //   1591: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.q : I
    //   1594: if_icmpne -> 1603
    //   1597: ldc 'audio/eac3'
    //   1599: astore_1
    //   1600: goto -> 1744
    //   1603: iload #14
    //   1605: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.s : I
    //   1608: if_icmpne -> 1617
    //   1611: ldc 'audio/vnd.dts'
    //   1613: astore_1
    //   1614: goto -> 1744
    //   1617: iload #14
    //   1619: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.t : I
    //   1622: if_icmpeq -> 1741
    //   1625: iload #14
    //   1627: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.u : I
    //   1630: if_icmpne -> 1636
    //   1633: goto -> 1741
    //   1636: iload #14
    //   1638: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.v : I
    //   1641: if_icmpne -> 1651
    //   1644: ldc_w 'audio/vnd.dts.hd;profile=lbr'
    //   1647: astore_1
    //   1648: goto -> 1744
    //   1651: iload #14
    //   1653: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.y0 : I
    //   1656: if_icmpne -> 1666
    //   1659: ldc_w 'audio/3gpp'
    //   1662: astore_1
    //   1663: goto -> 1744
    //   1666: iload #14
    //   1668: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.z0 : I
    //   1671: if_icmpne -> 1681
    //   1674: ldc_w 'audio/amr-wb'
    //   1677: astore_1
    //   1678: goto -> 1744
    //   1681: iload #14
    //   1683: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.m : I
    //   1686: if_icmpeq -> 1734
    //   1689: iload #14
    //   1691: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.n : I
    //   1694: if_icmpne -> 1700
    //   1697: goto -> 1734
    //   1700: iload #14
    //   1702: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.k : I
    //   1705: if_icmpne -> 1714
    //   1708: ldc 'audio/mpeg'
    //   1710: astore_1
    //   1711: goto -> 1744
    //   1714: iload #14
    //   1716: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.O0 : I
    //   1719: if_icmpne -> 1729
    //   1722: ldc_w 'audio/alac'
    //   1725: astore_1
    //   1726: goto -> 1744
    //   1729: aconst_null
    //   1730: astore_1
    //   1731: goto -> 1744
    //   1734: ldc_w 'audio/raw'
    //   1737: astore_1
    //   1738: goto -> 1744
    //   1741: ldc 'audio/vnd.dts.hd'
    //   1743: astore_1
    //   1744: aconst_null
    //   1745: astore #34
    //   1747: iload #17
    //   1749: istore #13
    //   1751: iload #11
    //   1753: istore #14
    //   1755: iload #12
    //   1757: istore #11
    //   1759: iload #8
    //   1761: istore #12
    //   1763: aload_1
    //   1764: astore #35
    //   1766: iload #14
    //   1768: istore #8
    //   1770: iload #13
    //   1772: iload #21
    //   1774: isub
    //   1775: iload #10
    //   1777: if_icmpge -> 2416
    //   1780: aload #41
    //   1782: iload #13
    //   1784: invokevirtual e : (I)V
    //   1787: aload #41
    //   1789: invokevirtual c : ()I
    //   1792: istore #19
    //   1794: iload #19
    //   1796: ifle -> 1805
    //   1799: iconst_1
    //   1800: istore #32
    //   1802: goto -> 1808
    //   1805: iconst_0
    //   1806: istore #32
    //   1808: iload #32
    //   1810: aload #33
    //   1812: invokestatic a : (ZLjava/lang/Object;)V
    //   1815: aload #41
    //   1817: invokevirtual c : ()I
    //   1820: istore #14
    //   1822: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.K : I
    //   1825: istore #17
    //   1827: iload #14
    //   1829: iload #17
    //   1831: if_icmpeq -> 2189
    //   1834: iload #5
    //   1836: ifeq -> 1850
    //   1839: iload #14
    //   1841: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.l : I
    //   1844: if_icmpne -> 1850
    //   1847: goto -> 2189
    //   1850: iload #14
    //   1852: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.p : I
    //   1855: if_icmpne -> 1969
    //   1858: aload #41
    //   1860: iload #13
    //   1862: bipush #8
    //   1864: iadd
    //   1865: invokevirtual e : (I)V
    //   1868: iload #20
    //   1870: invokestatic toString : (I)Ljava/lang/String;
    //   1873: astore_1
    //   1874: aload #41
    //   1876: invokevirtual l : ()I
    //   1879: istore #14
    //   1881: getstatic com/fyber/inneractive/sdk/player/exoplayer2/audio/a.b : [I
    //   1884: iload #14
    //   1886: sipush #192
    //   1889: iand
    //   1890: bipush #6
    //   1892: ishr
    //   1893: iaload
    //   1894: istore #18
    //   1896: aload #41
    //   1898: invokevirtual l : ()I
    //   1901: istore #22
    //   1903: getstatic com/fyber/inneractive/sdk/player/exoplayer2/audio/a.d : [I
    //   1906: iload #22
    //   1908: bipush #56
    //   1910: iand
    //   1911: iconst_3
    //   1912: ishr
    //   1913: iaload
    //   1914: istore #17
    //   1916: iload #17
    //   1918: istore #14
    //   1920: iload #22
    //   1922: iconst_4
    //   1923: iand
    //   1924: ifeq -> 1933
    //   1927: iload #17
    //   1929: iconst_1
    //   1930: iadd
    //   1931: istore #14
    //   1933: aload #40
    //   1935: aload_1
    //   1936: ldc 'audio/ac3'
    //   1938: aconst_null
    //   1939: iconst_m1
    //   1940: iconst_m1
    //   1941: iload #14
    //   1943: iload #18
    //   1945: iconst_m1
    //   1946: aconst_null
    //   1947: aload #4
    //   1949: iconst_0
    //   1950: aload #42
    //   1952: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/util/List;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;ILjava/lang/String;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1955: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   1958: iload #8
    //   1960: istore #18
    //   1962: iload #11
    //   1964: istore #17
    //   1966: goto -> 2398
    //   1969: iload #14
    //   1971: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.r : I
    //   1974: if_icmpne -> 2086
    //   1977: aload #41
    //   1979: iload #13
    //   1981: bipush #8
    //   1983: iadd
    //   1984: invokevirtual e : (I)V
    //   1987: iload #20
    //   1989: invokestatic toString : (I)Ljava/lang/String;
    //   1992: astore_1
    //   1993: aload #41
    //   1995: iconst_2
    //   1996: invokevirtual f : (I)V
    //   1999: aload #41
    //   2001: invokevirtual l : ()I
    //   2004: istore #14
    //   2006: getstatic com/fyber/inneractive/sdk/player/exoplayer2/audio/a.b : [I
    //   2009: iload #14
    //   2011: sipush #192
    //   2014: iand
    //   2015: bipush #6
    //   2017: ishr
    //   2018: iaload
    //   2019: istore #18
    //   2021: aload #41
    //   2023: invokevirtual l : ()I
    //   2026: istore #22
    //   2028: getstatic com/fyber/inneractive/sdk/player/exoplayer2/audio/a.d : [I
    //   2031: iload #22
    //   2033: bipush #14
    //   2035: iand
    //   2036: iconst_1
    //   2037: ishr
    //   2038: iaload
    //   2039: istore #17
    //   2041: iload #17
    //   2043: istore #14
    //   2045: iload #22
    //   2047: iconst_1
    //   2048: iand
    //   2049: ifeq -> 2058
    //   2052: iload #17
    //   2054: iconst_1
    //   2055: iadd
    //   2056: istore #14
    //   2058: aload #40
    //   2060: aload_1
    //   2061: ldc 'audio/eac3'
    //   2063: aconst_null
    //   2064: iconst_m1
    //   2065: iconst_m1
    //   2066: iload #14
    //   2068: iload #18
    //   2070: iconst_m1
    //   2071: aconst_null
    //   2072: aload #4
    //   2074: iconst_0
    //   2075: aload #42
    //   2077: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/util/List;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;ILjava/lang/String;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2080: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2083: goto -> 2178
    //   2086: iload #14
    //   2088: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.w : I
    //   2091: if_icmpne -> 2126
    //   2094: aload #40
    //   2096: iload #20
    //   2098: invokestatic toString : (I)Ljava/lang/String;
    //   2101: aload #35
    //   2103: aconst_null
    //   2104: iconst_m1
    //   2105: iconst_m1
    //   2106: iload #8
    //   2108: iload #11
    //   2110: iconst_m1
    //   2111: aconst_null
    //   2112: aload #4
    //   2114: iconst_0
    //   2115: aload #42
    //   2117: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/util/List;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;ILjava/lang/String;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2120: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2123: goto -> 2178
    //   2126: iload #14
    //   2128: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.O0 : I
    //   2131: if_icmpne -> 2178
    //   2134: iload #19
    //   2136: newarray byte
    //   2138: astore #34
    //   2140: aload #41
    //   2142: iload #13
    //   2144: invokevirtual e : (I)V
    //   2147: aload #41
    //   2149: getfield a : [B
    //   2152: aload #41
    //   2154: getfield b : I
    //   2157: aload #34
    //   2159: iconst_0
    //   2160: iload #19
    //   2162: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   2165: aload #41
    //   2167: aload #41
    //   2169: getfield b : I
    //   2172: iload #19
    //   2174: iadd
    //   2175: putfield b : I
    //   2178: iload #8
    //   2180: istore #18
    //   2182: iload #11
    //   2184: istore #17
    //   2186: goto -> 2398
    //   2189: iload #14
    //   2191: iload #17
    //   2193: if_icmpne -> 2206
    //   2196: aload #33
    //   2198: astore_1
    //   2199: iload #13
    //   2201: istore #14
    //   2203: goto -> 2298
    //   2206: aload #41
    //   2208: getfield b : I
    //   2211: istore #14
    //   2213: iconst_0
    //   2214: istore #32
    //   2216: iload #14
    //   2218: iload #13
    //   2220: isub
    //   2221: iload #19
    //   2223: if_icmpge -> 2289
    //   2226: aload #41
    //   2228: iload #14
    //   2230: invokevirtual e : (I)V
    //   2233: aload #41
    //   2235: invokevirtual c : ()I
    //   2238: istore #17
    //   2240: iload #17
    //   2242: ifle -> 2248
    //   2245: iconst_1
    //   2246: istore #32
    //   2248: iload #32
    //   2250: aload #33
    //   2252: invokestatic a : (ZLjava/lang/Object;)V
    //   2255: aload #41
    //   2257: invokevirtual c : ()I
    //   2260: istore #18
    //   2262: aload #33
    //   2264: astore_1
    //   2265: iload #18
    //   2267: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.K : I
    //   2270: if_icmpne -> 2276
    //   2273: goto -> 2203
    //   2276: iload #14
    //   2278: iload #17
    //   2280: iadd
    //   2281: istore #14
    //   2283: aload_1
    //   2284: astore #33
    //   2286: goto -> 2213
    //   2289: aload #33
    //   2291: astore_1
    //   2292: iconst_m1
    //   2293: istore #14
    //   2295: goto -> 2203
    //   2298: iload #8
    //   2300: istore #18
    //   2302: iload #11
    //   2304: istore #17
    //   2306: aload_1
    //   2307: astore #33
    //   2309: iload #14
    //   2311: iconst_m1
    //   2312: if_icmpeq -> 2398
    //   2315: aload #41
    //   2317: iload #14
    //   2319: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;I)Landroid/util/Pair;
    //   2322: astore #33
    //   2324: aload #33
    //   2326: getfield first : Ljava/lang/Object;
    //   2329: checkcast java/lang/String
    //   2332: astore #35
    //   2334: aload #33
    //   2336: getfield second : Ljava/lang/Object;
    //   2339: checkcast [B
    //   2342: astore #34
    //   2344: ldc 'audio/mp4a-latm'
    //   2346: aload #35
    //   2348: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2351: ifeq -> 2387
    //   2354: aload #34
    //   2356: invokestatic a : ([B)Landroid/util/Pair;
    //   2359: astore #33
    //   2361: aload #33
    //   2363: getfield first : Ljava/lang/Object;
    //   2366: checkcast java/lang/Integer
    //   2369: invokevirtual intValue : ()I
    //   2372: istore #11
    //   2374: aload #33
    //   2376: getfield second : Ljava/lang/Object;
    //   2379: checkcast java/lang/Integer
    //   2382: invokevirtual intValue : ()I
    //   2385: istore #8
    //   2387: aload_1
    //   2388: astore #33
    //   2390: iload #11
    //   2392: istore #17
    //   2394: iload #8
    //   2396: istore #18
    //   2398: iload #13
    //   2400: iload #19
    //   2402: iadd
    //   2403: istore #13
    //   2405: iload #18
    //   2407: istore #8
    //   2409: iload #17
    //   2411: istore #11
    //   2413: goto -> 1770
    //   2416: aload #40
    //   2418: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2421: ifnonnull -> 2499
    //   2424: aload #35
    //   2426: ifnull -> 2499
    //   2429: ldc_w 'audio/raw'
    //   2432: aload #35
    //   2434: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2437: ifeq -> 2446
    //   2440: iconst_2
    //   2441: istore #13
    //   2443: goto -> 2449
    //   2446: iconst_m1
    //   2447: istore #13
    //   2449: iload #20
    //   2451: invokestatic toString : (I)Ljava/lang/String;
    //   2454: astore #33
    //   2456: aload #34
    //   2458: ifnonnull -> 2466
    //   2461: aconst_null
    //   2462: astore_1
    //   2463: goto -> 2472
    //   2466: aload #34
    //   2468: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   2471: astore_1
    //   2472: aload #40
    //   2474: aload #33
    //   2476: aload #35
    //   2478: aconst_null
    //   2479: iconst_m1
    //   2480: iconst_m1
    //   2481: iload #8
    //   2483: iload #11
    //   2485: iload #13
    //   2487: aload_1
    //   2488: aload #4
    //   2490: iconst_0
    //   2491: aload #42
    //   2493: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/util/List;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;ILjava/lang/String;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2496: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   2499: iload #10
    //   2501: istore #8
    //   2503: iload #9
    //   2505: istore #10
    //   2507: iload #8
    //   2509: istore #9
    //   2511: iload #12
    //   2513: istore #8
    //   2515: goto -> 1422
    //   2518: iload #8
    //   2520: istore #11
    //   2522: ldc 'childAtomSize should be positive'
    //   2524: astore #39
    //   2526: aload #41
    //   2528: iload #21
    //   2530: bipush #8
    //   2532: iadd
    //   2533: bipush #8
    //   2535: iadd
    //   2536: invokevirtual e : (I)V
    //   2539: aload #41
    //   2541: bipush #16
    //   2543: invokevirtual f : (I)V
    //   2546: aload #41
    //   2548: invokevirtual q : ()I
    //   2551: istore #22
    //   2553: aload #41
    //   2555: invokevirtual q : ()I
    //   2558: istore #23
    //   2560: aload #41
    //   2562: bipush #50
    //   2564: invokevirtual f : (I)V
    //   2567: aload #41
    //   2569: getfield b : I
    //   2572: istore #14
    //   2574: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.a0 : I
    //   2577: istore #8
    //   2579: iload #10
    //   2581: istore #12
    //   2583: iload #13
    //   2585: iload #8
    //   2587: if_icmpne -> 2615
    //   2590: aload #41
    //   2592: iload #21
    //   2594: iload #12
    //   2596: aload #40
    //   2598: iload #9
    //   2600: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IILcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/b$b;I)I
    //   2603: istore #8
    //   2605: aload #41
    //   2607: iload #14
    //   2609: invokevirtual e : (I)V
    //   2612: goto -> 2619
    //   2615: iload #13
    //   2617: istore #8
    //   2619: iload #9
    //   2621: istore #13
    //   2623: iconst_0
    //   2624: istore #18
    //   2626: aconst_null
    //   2627: astore #36
    //   2629: aconst_null
    //   2630: astore #33
    //   2632: fconst_1
    //   2633: fstore #6
    //   2635: aconst_null
    //   2636: astore #35
    //   2638: iconst_m1
    //   2639: istore #17
    //   2641: iload #14
    //   2643: iload #21
    //   2645: isub
    //   2646: iload #12
    //   2648: if_icmpge -> 3502
    //   2651: aload #41
    //   2653: iload #14
    //   2655: invokevirtual e : (I)V
    //   2658: aload #41
    //   2660: getfield b : I
    //   2663: istore #10
    //   2665: aload #41
    //   2667: invokevirtual c : ()I
    //   2670: istore #24
    //   2672: iload #24
    //   2674: ifne -> 2693
    //   2677: aload #41
    //   2679: getfield b : I
    //   2682: iload #21
    //   2684: isub
    //   2685: iload #12
    //   2687: if_icmpne -> 2693
    //   2690: goto -> 3502
    //   2693: iload #24
    //   2695: ifle -> 2704
    //   2698: iconst_1
    //   2699: istore #32
    //   2701: goto -> 2707
    //   2704: iconst_0
    //   2705: istore #32
    //   2707: iload #32
    //   2709: aload #39
    //   2711: invokestatic a : (ZLjava/lang/Object;)V
    //   2714: aload #41
    //   2716: invokevirtual c : ()I
    //   2719: istore #9
    //   2721: iload #9
    //   2723: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.I : I
    //   2726: if_icmpne -> 2800
    //   2729: aload #36
    //   2731: ifnonnull -> 2740
    //   2734: iconst_1
    //   2735: istore #32
    //   2737: goto -> 2743
    //   2740: iconst_0
    //   2741: istore #32
    //   2743: iload #32
    //   2745: invokestatic b : (Z)V
    //   2748: aload #41
    //   2750: iload #10
    //   2752: bipush #8
    //   2754: iadd
    //   2755: invokevirtual e : (I)V
    //   2758: aload #41
    //   2760: invokestatic b : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;)Lcom/fyber/inneractive/sdk/player/exoplayer2/video/a;
    //   2763: astore #33
    //   2765: aload #33
    //   2767: getfield a : Ljava/util/List;
    //   2770: astore_1
    //   2771: aload #40
    //   2773: aload #33
    //   2775: getfield b : I
    //   2778: putfield c : I
    //   2781: iload #18
    //   2783: ifne -> 2793
    //   2786: aload #33
    //   2788: getfield e : F
    //   2791: fstore #6
    //   2793: ldc 'video/avc'
    //   2795: astore #34
    //   2797: goto -> 2864
    //   2800: iload #9
    //   2802: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.J : I
    //   2805: if_icmpne -> 2883
    //   2808: aload #36
    //   2810: ifnonnull -> 2819
    //   2813: iconst_1
    //   2814: istore #32
    //   2816: goto -> 2822
    //   2819: iconst_0
    //   2820: istore #32
    //   2822: iload #32
    //   2824: invokestatic b : (Z)V
    //   2827: aload #41
    //   2829: iload #10
    //   2831: bipush #8
    //   2833: iadd
    //   2834: invokevirtual e : (I)V
    //   2837: aload #41
    //   2839: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;)Lcom/fyber/inneractive/sdk/player/exoplayer2/video/c;
    //   2842: astore #33
    //   2844: aload #33
    //   2846: getfield a : Ljava/util/List;
    //   2849: astore_1
    //   2850: aload #40
    //   2852: aload #33
    //   2854: getfield b : I
    //   2857: putfield c : I
    //   2860: ldc 'video/hevc'
    //   2862: astore #34
    //   2864: aload #35
    //   2866: astore #37
    //   2868: fload #6
    //   2870: fstore #7
    //   2872: iload #18
    //   2874: istore #19
    //   2876: iload #17
    //   2878: istore #9
    //   2880: goto -> 3469
    //   2883: iload #9
    //   2885: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.M0 : I
    //   2888: if_icmpne -> 2932
    //   2891: aload #36
    //   2893: ifnonnull -> 2902
    //   2896: iconst_1
    //   2897: istore #32
    //   2899: goto -> 2905
    //   2902: iconst_0
    //   2903: istore #32
    //   2905: iload #32
    //   2907: invokestatic b : (Z)V
    //   2910: iload #8
    //   2912: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.K0 : I
    //   2915: if_icmpne -> 2925
    //   2918: ldc_w 'video/x-vnd.on2.vp8'
    //   2921: astore_1
    //   2922: goto -> 2963
    //   2925: ldc_w 'video/x-vnd.on2.vp9'
    //   2928: astore_1
    //   2929: goto -> 2963
    //   2932: iload #9
    //   2934: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.h : I
    //   2937: if_icmpne -> 2980
    //   2940: aload #36
    //   2942: ifnonnull -> 2951
    //   2945: iconst_1
    //   2946: istore #32
    //   2948: goto -> 2954
    //   2951: iconst_0
    //   2952: istore #32
    //   2954: iload #32
    //   2956: invokestatic b : (Z)V
    //   2959: ldc_w 'video/3gpp'
    //   2962: astore_1
    //   2963: aload_1
    //   2964: astore #34
    //   2966: aload #33
    //   2968: astore_1
    //   2969: fload #6
    //   2971: fstore #7
    //   2973: aload #35
    //   2975: astore #37
    //   2977: goto -> 2872
    //   2980: iload #9
    //   2982: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.K : I
    //   2985: if_icmpne -> 3038
    //   2988: aload #36
    //   2990: ifnonnull -> 2999
    //   2993: iconst_1
    //   2994: istore #32
    //   2996: goto -> 3002
    //   2999: iconst_0
    //   3000: istore #32
    //   3002: iload #32
    //   3004: invokestatic b : (Z)V
    //   3007: aload #41
    //   3009: iload #10
    //   3011: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;I)Landroid/util/Pair;
    //   3014: astore #33
    //   3016: aload #33
    //   3018: getfield first : Ljava/lang/Object;
    //   3021: checkcast java/lang/String
    //   3024: astore_1
    //   3025: aload #33
    //   3027: getfield second : Ljava/lang/Object;
    //   3030: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   3033: astore #33
    //   3035: goto -> 2963
    //   3038: iload #9
    //   3040: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.j0 : I
    //   3043: if_icmpne -> 3100
    //   3046: aload #41
    //   3048: iload #10
    //   3050: bipush #8
    //   3052: iadd
    //   3053: invokevirtual e : (I)V
    //   3056: aload #41
    //   3058: invokevirtual o : ()I
    //   3061: istore #9
    //   3063: aload #41
    //   3065: invokevirtual o : ()I
    //   3068: istore #10
    //   3070: iload #9
    //   3072: i2f
    //   3073: iload #10
    //   3075: i2f
    //   3076: fdiv
    //   3077: fstore #7
    //   3079: iconst_1
    //   3080: istore #19
    //   3082: aload #36
    //   3084: astore #34
    //   3086: aload #33
    //   3088: astore_1
    //   3089: aload #35
    //   3091: astore #37
    //   3093: iload #17
    //   3095: istore #9
    //   3097: goto -> 3469
    //   3100: iload #9
    //   3102: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.I0 : I
    //   3105: if_icmpne -> 3220
    //   3108: iload #10
    //   3110: bipush #8
    //   3112: iadd
    //   3113: istore #9
    //   3115: iload #9
    //   3117: iload #10
    //   3119: isub
    //   3120: iload #24
    //   3122: if_icmpge -> 3195
    //   3125: aload #41
    //   3127: iload #9
    //   3129: invokevirtual e : (I)V
    //   3132: aload #41
    //   3134: invokevirtual c : ()I
    //   3137: istore #19
    //   3139: aload #41
    //   3141: invokevirtual c : ()I
    //   3144: istore #25
    //   3146: iload #25
    //   3148: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.J0 : I
    //   3151: if_icmpne -> 3185
    //   3154: aload #41
    //   3156: getfield a : [B
    //   3159: iload #9
    //   3161: iload #19
    //   3163: iload #9
    //   3165: iadd
    //   3166: invokestatic copyOfRange : ([BII)[B
    //   3169: astore #37
    //   3171: aload #36
    //   3173: astore #34
    //   3175: aload #33
    //   3177: astore_1
    //   3178: fload #6
    //   3180: fstore #7
    //   3182: goto -> 2872
    //   3185: iload #9
    //   3187: iload #19
    //   3189: iadd
    //   3190: istore #9
    //   3192: goto -> 3115
    //   3195: aconst_null
    //   3196: astore #37
    //   3198: iload #18
    //   3200: istore #19
    //   3202: aload #36
    //   3204: astore #34
    //   3206: aload #33
    //   3208: astore_1
    //   3209: fload #6
    //   3211: fstore #7
    //   3213: iload #17
    //   3215: istore #9
    //   3217: goto -> 3469
    //   3220: iload #8
    //   3222: istore #10
    //   3224: iload #10
    //   3226: istore #8
    //   3228: aload #36
    //   3230: astore #34
    //   3232: aload #33
    //   3234: astore_1
    //   3235: fload #6
    //   3237: fstore #7
    //   3239: aload #35
    //   3241: astore #37
    //   3243: iload #9
    //   3245: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.H0 : I
    //   3248: if_icmpne -> 2872
    //   3251: aload #41
    //   3253: invokevirtual l : ()I
    //   3256: istore #25
    //   3258: aload #41
    //   3260: iconst_3
    //   3261: invokevirtual f : (I)V
    //   3264: iload #18
    //   3266: istore #19
    //   3268: iload #10
    //   3270: istore #8
    //   3272: aload #36
    //   3274: astore #34
    //   3276: aload #33
    //   3278: astore_1
    //   3279: fload #6
    //   3281: fstore #7
    //   3283: aload #35
    //   3285: astore #37
    //   3287: iload #17
    //   3289: istore #9
    //   3291: iload #25
    //   3293: ifne -> 3469
    //   3296: aload #41
    //   3298: invokevirtual l : ()I
    //   3301: istore #8
    //   3303: iload #8
    //   3305: ifeq -> 3443
    //   3308: iload #8
    //   3310: iconst_1
    //   3311: if_icmpeq -> 3414
    //   3314: iload #8
    //   3316: iconst_2
    //   3317: if_icmpeq -> 3385
    //   3320: iload #8
    //   3322: iconst_3
    //   3323: if_icmpeq -> 3356
    //   3326: iload #18
    //   3328: istore #19
    //   3330: iload #10
    //   3332: istore #8
    //   3334: aload #36
    //   3336: astore #34
    //   3338: aload #33
    //   3340: astore_1
    //   3341: fload #6
    //   3343: fstore #7
    //   3345: aload #35
    //   3347: astore #37
    //   3349: iload #17
    //   3351: istore #9
    //   3353: goto -> 3469
    //   3356: iconst_3
    //   3357: istore #9
    //   3359: iload #18
    //   3361: istore #19
    //   3363: iload #10
    //   3365: istore #8
    //   3367: aload #36
    //   3369: astore #34
    //   3371: aload #33
    //   3373: astore_1
    //   3374: fload #6
    //   3376: fstore #7
    //   3378: aload #35
    //   3380: astore #37
    //   3382: goto -> 3469
    //   3385: iconst_2
    //   3386: istore #9
    //   3388: iload #18
    //   3390: istore #19
    //   3392: iload #10
    //   3394: istore #8
    //   3396: aload #36
    //   3398: astore #34
    //   3400: aload #33
    //   3402: astore_1
    //   3403: fload #6
    //   3405: fstore #7
    //   3407: aload #35
    //   3409: astore #37
    //   3411: goto -> 3469
    //   3414: iconst_1
    //   3415: istore #9
    //   3417: iload #18
    //   3419: istore #19
    //   3421: iload #10
    //   3423: istore #8
    //   3425: aload #36
    //   3427: astore #34
    //   3429: aload #33
    //   3431: astore_1
    //   3432: fload #6
    //   3434: fstore #7
    //   3436: aload #35
    //   3438: astore #37
    //   3440: goto -> 3469
    //   3443: iconst_0
    //   3444: istore #9
    //   3446: aload #35
    //   3448: astore #37
    //   3450: fload #6
    //   3452: fstore #7
    //   3454: aload #33
    //   3456: astore_1
    //   3457: aload #36
    //   3459: astore #34
    //   3461: iload #10
    //   3463: istore #8
    //   3465: iload #18
    //   3467: istore #19
    //   3469: iload #14
    //   3471: iload #24
    //   3473: iadd
    //   3474: istore #14
    //   3476: iload #19
    //   3478: istore #18
    //   3480: aload #34
    //   3482: astore #36
    //   3484: aload_1
    //   3485: astore #33
    //   3487: fload #7
    //   3489: fstore #6
    //   3491: aload #37
    //   3493: astore #35
    //   3495: iload #9
    //   3497: istore #17
    //   3499: goto -> 2641
    //   3502: aload #36
    //   3504: ifnonnull -> 3522
    //   3507: iload #13
    //   3509: istore #10
    //   3511: iload #12
    //   3513: istore #9
    //   3515: iload #11
    //   3517: istore #8
    //   3519: goto -> 3572
    //   3522: aload #40
    //   3524: iload #20
    //   3526: invokestatic toString : (I)Ljava/lang/String;
    //   3529: aload #36
    //   3531: aconst_null
    //   3532: iconst_m1
    //   3533: iconst_m1
    //   3534: iload #22
    //   3536: iload #23
    //   3538: ldc_w -1.0
    //   3541: aload #33
    //   3543: iload #11
    //   3545: fload #6
    //   3547: aload #35
    //   3549: iload #17
    //   3551: aconst_null
    //   3552: aload #4
    //   3554: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIFLjava/util/List;IF[BILcom/fyber/inneractive/sdk/player/exoplayer2/video/b;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;)Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   3557: putfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   3560: iload #11
    //   3562: istore #8
    //   3564: iload #12
    //   3566: istore #9
    //   3568: iload #13
    //   3570: istore #10
    //   3572: aload #41
    //   3574: iload #21
    //   3576: iload #9
    //   3578: iadd
    //   3579: invokevirtual e : (I)V
    //   3582: iload #10
    //   3584: iconst_1
    //   3585: iadd
    //   3586: istore #9
    //   3588: goto -> 780
    //   3591: aload_0
    //   3592: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.Q : I
    //   3595: invokevirtual c : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$a;
    //   3598: astore_0
    //   3599: aload_0
    //   3600: ifnull -> 3813
    //   3603: aload_0
    //   3604: getstatic com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a.R : I
    //   3607: invokevirtual d : (I)Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/a$b;
    //   3610: astore_0
    //   3611: aload_0
    //   3612: ifnonnull -> 3618
    //   3615: goto -> 3813
    //   3618: aload_0
    //   3619: getfield P0 : Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;
    //   3622: astore_0
    //   3623: aload_0
    //   3624: bipush #8
    //   3626: invokevirtual e : (I)V
    //   3629: aload_0
    //   3630: invokevirtual c : ()I
    //   3633: invokestatic b : (I)I
    //   3636: istore #9
    //   3638: aload_0
    //   3639: invokevirtual o : ()I
    //   3642: istore #10
    //   3644: iload #10
    //   3646: newarray long
    //   3648: astore_1
    //   3649: iload #10
    //   3651: newarray long
    //   3653: astore #4
    //   3655: iconst_0
    //   3656: istore #8
    //   3658: iload #8
    //   3660: iload #10
    //   3662: if_icmpge -> 3803
    //   3665: iload #9
    //   3667: iconst_1
    //   3668: if_icmpne -> 3679
    //   3671: aload_0
    //   3672: invokevirtual p : ()J
    //   3675: lstore_2
    //   3676: goto -> 3684
    //   3679: aload_0
    //   3680: invokevirtual m : ()J
    //   3683: lstore_2
    //   3684: aload_1
    //   3685: iload #8
    //   3687: lload_2
    //   3688: lastore
    //   3689: iload #9
    //   3691: iconst_1
    //   3692: if_icmpne -> 3703
    //   3695: aload_0
    //   3696: invokevirtual i : ()J
    //   3699: lstore_2
    //   3700: goto -> 3709
    //   3703: aload_0
    //   3704: invokevirtual c : ()I
    //   3707: i2l
    //   3708: lstore_2
    //   3709: aload #4
    //   3711: iload #8
    //   3713: lload_2
    //   3714: lastore
    //   3715: aload_0
    //   3716: getfield a : [B
    //   3719: astore #33
    //   3721: aload_0
    //   3722: getfield b : I
    //   3725: istore #12
    //   3727: iload #12
    //   3729: iconst_1
    //   3730: iadd
    //   3731: istore #11
    //   3733: aload_0
    //   3734: iload #11
    //   3736: putfield b : I
    //   3739: aload #33
    //   3741: iload #12
    //   3743: baload
    //   3744: istore #12
    //   3746: aload_0
    //   3747: iload #11
    //   3749: iconst_1
    //   3750: iadd
    //   3751: putfield b : I
    //   3754: aload #33
    //   3756: iload #11
    //   3758: baload
    //   3759: sipush #255
    //   3762: iand
    //   3763: iload #12
    //   3765: sipush #255
    //   3768: iand
    //   3769: bipush #8
    //   3771: ishl
    //   3772: ior
    //   3773: i2s
    //   3774: iconst_1
    //   3775: if_icmpne -> 3792
    //   3778: aload_0
    //   3779: iconst_2
    //   3780: invokevirtual f : (I)V
    //   3783: iload #8
    //   3785: iconst_1
    //   3786: iadd
    //   3787: istore #8
    //   3789: goto -> 3658
    //   3792: new java/lang/IllegalArgumentException
    //   3795: dup
    //   3796: ldc_w 'Unsupported media rate.'
    //   3799: invokespecial <init> : (Ljava/lang/String;)V
    //   3802: athrow
    //   3803: aload_1
    //   3804: aload #4
    //   3806: invokestatic create : (Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;
    //   3809: astore_0
    //   3810: goto -> 3819
    //   3813: aconst_null
    //   3814: aconst_null
    //   3815: invokestatic create : (Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;
    //   3818: astore_0
    //   3819: aload #40
    //   3821: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   3824: ifnonnull -> 3829
    //   3827: aconst_null
    //   3828: areturn
    //   3829: new com/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/h
    //   3832: dup
    //   3833: iload #20
    //   3835: iload #15
    //   3837: aload #38
    //   3839: getfield first : Ljava/lang/Object;
    //   3842: checkcast java/lang/Long
    //   3845: invokevirtual longValue : ()J
    //   3848: lload #28
    //   3850: lload #26
    //   3852: aload #40
    //   3854: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   3857: aload #40
    //   3859: getfield d : I
    //   3862: aload #40
    //   3864: getfield a : [Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/i;
    //   3867: aload #40
    //   3869: getfield c : I
    //   3872: aload_0
    //   3873: getfield first : Ljava/lang/Object;
    //   3876: checkcast [J
    //   3879: aload_0
    //   3880: getfield second : Ljava/lang/Object;
    //   3883: checkcast [J
    //   3886: invokespecial <init> : (IIJJJLcom/fyber/inneractive/sdk/player/exoplayer2/i;I[Lcom/fyber/inneractive/sdk/player/exoplayer2/extractor/mp4/i;I[J[J)V
    //   3889: areturn
  }
  
  public static interface a {
    int a();
    
    int b();
    
    boolean c();
  }
  
  public static final class b {
    public final i[] a;
    
    public i b;
    
    public int c;
    
    public int d;
    
    public b(int param1Int) {
      this.a = new i[param1Int];
      this.d = 0;
    }
  }
  
  public static final class c implements a {
    public final int a;
    
    public final int b;
    
    public final k c;
    
    public c(a.b param1b) {
      k k1 = param1b.P0;
      this.c = k1;
      k1.e(12);
      this.a = k1.o();
      this.b = k1.o();
    }
    
    public int a() {
      return this.b;
    }
    
    public int b() {
      int j = this.a;
      int i = j;
      if (j == 0)
        i = this.c.o(); 
      return i;
    }
    
    public boolean c() {
      return (this.a != 0);
    }
  }
  
  public static final class d implements a {
    public final k a;
    
    public final int b;
    
    public final int c;
    
    public int d;
    
    public int e;
    
    public d(a.b param1b) {
      k k1 = param1b.P0;
      this.a = k1;
      k1.e(12);
      this.c = k1.o() & 0xFF;
      this.b = k1.o();
    }
    
    public int a() {
      return this.b;
    }
    
    public int b() {
      int i = this.c;
      if (i == 8)
        return this.a.l(); 
      if (i == 16)
        return this.a.q(); 
      i = this.d;
      this.d = i + 1;
      if (i % 2 == 0) {
        i = this.a.l();
        this.e = i;
        return (i & 0xF0) >> 4;
      } 
      return this.e & 0xF;
    }
    
    public boolean c() {
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\extractor\mp4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */