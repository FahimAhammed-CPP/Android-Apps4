package com.fyber.inneractive.sdk.player.exoplayer2.mediacodec;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.SystemClock;
import com.fyber.inneractive.sdk.player.exoplayer2.a;
import com.fyber.inneractive.sdk.player.exoplayer2.d;
import com.fyber.inneractive.sdk.player.exoplayer2.decoder.DecoderCounters;
import com.fyber.inneractive.sdk.player.exoplayer2.drm.c;
import com.fyber.inneractive.sdk.player.exoplayer2.drm.d;
import com.fyber.inneractive.sdk.player.exoplayer2.i;
import com.fyber.inneractive.sdk.player.exoplayer2.j;
import com.fyber.inneractive.sdk.player.exoplayer2.util.u;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public abstract class b extends a {
  public static final byte[] U;
  
  public boolean A;
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public ByteBuffer[] E;
  
  public ByteBuffer[] F;
  
  public long G;
  
  public int H;
  
  public int I;
  
  public boolean J;
  
  public boolean K;
  
  public int L;
  
  public int M;
  
  public boolean N;
  
  public boolean O;
  
  public boolean P;
  
  public boolean Q;
  
  public boolean R;
  
  public boolean S;
  
  public DecoderCounters T;
  
  public final c i;
  
  public final c<d> j;
  
  public final boolean k;
  
  public final com.fyber.inneractive.sdk.player.exoplayer2.decoder.b l;
  
  public final com.fyber.inneractive.sdk.player.exoplayer2.decoder.b m;
  
  public final j n;
  
  public final List<Long> o;
  
  public final MediaCodec.BufferInfo p;
  
  public i q;
  
  public MediaCodec r;
  
  public com.fyber.inneractive.sdk.player.exoplayer2.drm.b<d> s;
  
  public com.fyber.inneractive.sdk.player.exoplayer2.drm.b<d> t;
  
  public boolean u;
  
  public boolean v;
  
  public boolean w;
  
  public boolean x;
  
  public boolean y;
  
  public boolean z;
  
  static {
    int k = u.a;
    byte[] arrayOfByte = new byte[38];
    for (k = 0; k < 38; k++) {
      int m = k * 2;
      arrayOfByte[k] = (byte)((Character.digit("0000016742C00BDA259000000168CE0F13200000016588840DCE7118A0002FBF1C31C3275D78".charAt(m), 16) << 4) + Character.digit("0000016742C00BDA259000000168CE0F13200000016588840DCE7118A0002FBF1C31C3275D78".charAt(m + 1), 16));
    } 
    U = arrayOfByte;
  }
  
  public b(int paramInt, c paramc, c<d> paramc1, boolean paramBoolean) {
    super(paramInt);
    boolean bool;
    if (u.a >= 16) {
      bool = true;
    } else {
      bool = false;
    } 
    com.fyber.inneractive.sdk.player.exoplayer2.util.a.b(bool);
    this.i = (c)com.fyber.inneractive.sdk.player.exoplayer2.util.a.a(paramc);
    this.j = paramc1;
    this.k = paramBoolean;
    this.l = new com.fyber.inneractive.sdk.player.exoplayer2.decoder.b(0);
    this.m = com.fyber.inneractive.sdk.player.exoplayer2.decoder.b.b();
    this.n = new j();
    this.o = new ArrayList<Long>();
    this.p = new MediaCodec.BufferInfo();
    this.L = 0;
    this.M = 0;
  }
  
  public abstract int a(c paramc, i parami) throws d.b;
  
  public a a(c paramc, i parami, boolean paramBoolean) throws d.b {
    return paramc.a(parami.f, paramBoolean);
  }
  
  public void a(long paramLong1, long paramLong2) throws d {
    // Byte code:
    //   0: aload_0
    //   1: getfield Q : Z
    //   4: ifeq -> 12
    //   7: aload_0
    //   8: invokevirtual w : ()V
    //   11: return
    //   12: aload_0
    //   13: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   16: ifnonnull -> 90
    //   19: aload_0
    //   20: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   23: invokevirtual a : ()V
    //   26: aload_0
    //   27: aload_0
    //   28: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   31: aload_0
    //   32: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   35: iconst_1
    //   36: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/j;Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;Z)I
    //   39: istore #5
    //   41: iload #5
    //   43: bipush #-5
    //   45: if_icmpne -> 62
    //   48: aload_0
    //   49: aload_0
    //   50: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   53: getfield a : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   56: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;)V
    //   59: goto -> 90
    //   62: iload #5
    //   64: bipush #-4
    //   66: if_icmpne -> 89
    //   69: aload_0
    //   70: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   73: iconst_4
    //   74: invokevirtual b : (I)Z
    //   77: invokestatic b : (Z)V
    //   80: aload_0
    //   81: iconst_1
    //   82: putfield P : Z
    //   85: aload_0
    //   86: invokevirtual u : ()V
    //   89: return
    //   90: aload_0
    //   91: invokevirtual t : ()V
    //   94: aload_0
    //   95: getfield r : Landroid/media/MediaCodec;
    //   98: ifnull -> 733
    //   101: ldc 'drainAndFeed'
    //   103: invokestatic a : (Ljava/lang/String;)V
    //   106: iconst_1
    //   107: istore #5
    //   109: aload_0
    //   110: getfield I : I
    //   113: ifge -> 528
    //   116: aload_0
    //   117: getfield A : Z
    //   120: ifeq -> 167
    //   123: aload_0
    //   124: getfield O : Z
    //   127: ifeq -> 167
    //   130: aload_0
    //   131: aload_0
    //   132: getfield r : Landroid/media/MediaCodec;
    //   135: aload_0
    //   136: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   139: lconst_0
    //   140: invokevirtual dequeueOutputBuffer : (Landroid/media/MediaCodec$BufferInfo;J)I
    //   143: putfield I : I
    //   146: goto -> 183
    //   149: aload_0
    //   150: invokevirtual u : ()V
    //   153: aload_0
    //   154: getfield Q : Z
    //   157: ifeq -> 706
    //   160: aload_0
    //   161: invokevirtual v : ()V
    //   164: goto -> 706
    //   167: aload_0
    //   168: aload_0
    //   169: getfield r : Landroid/media/MediaCodec;
    //   172: aload_0
    //   173: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   176: lconst_0
    //   177: invokevirtual dequeueOutputBuffer : (Landroid/media/MediaCodec$BufferInfo;J)I
    //   180: putfield I : I
    //   183: aload_0
    //   184: getfield I : I
    //   187: istore #6
    //   189: iload #6
    //   191: iflt -> 392
    //   194: aload_0
    //   195: getfield D : Z
    //   198: ifeq -> 224
    //   201: aload_0
    //   202: iconst_0
    //   203: putfield D : Z
    //   206: aload_0
    //   207: getfield r : Landroid/media/MediaCodec;
    //   210: iload #6
    //   212: iconst_0
    //   213: invokevirtual releaseOutputBuffer : (IZ)V
    //   216: aload_0
    //   217: iconst_m1
    //   218: putfield I : I
    //   221: goto -> 709
    //   224: aload_0
    //   225: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   228: astore #11
    //   230: aload #11
    //   232: getfield flags : I
    //   235: iconst_4
    //   236: iand
    //   237: ifeq -> 252
    //   240: aload_0
    //   241: invokevirtual u : ()V
    //   244: aload_0
    //   245: iconst_m1
    //   246: putfield I : I
    //   249: goto -> 706
    //   252: aload_0
    //   253: getfield F : [Ljava/nio/ByteBuffer;
    //   256: iload #6
    //   258: aaload
    //   259: astore #10
    //   261: aload #10
    //   263: ifnull -> 300
    //   266: aload #10
    //   268: aload #11
    //   270: getfield offset : I
    //   273: invokevirtual position : (I)Ljava/nio/Buffer;
    //   276: pop
    //   277: aload_0
    //   278: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   281: astore #11
    //   283: aload #10
    //   285: aload #11
    //   287: getfield offset : I
    //   290: aload #11
    //   292: getfield size : I
    //   295: iadd
    //   296: invokevirtual limit : (I)Ljava/nio/Buffer;
    //   299: pop
    //   300: aload_0
    //   301: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   304: getfield presentationTimeUs : J
    //   307: lstore #7
    //   309: aload_0
    //   310: getfield o : Ljava/util/List;
    //   313: invokeinterface size : ()I
    //   318: istore #6
    //   320: iconst_0
    //   321: istore #5
    //   323: iload #5
    //   325: iload #6
    //   327: if_icmpge -> 380
    //   330: aload_0
    //   331: getfield o : Ljava/util/List;
    //   334: iload #5
    //   336: invokeinterface get : (I)Ljava/lang/Object;
    //   341: checkcast java/lang/Long
    //   344: invokevirtual longValue : ()J
    //   347: lload #7
    //   349: lcmp
    //   350: ifne -> 371
    //   353: aload_0
    //   354: getfield o : Ljava/util/List;
    //   357: iload #5
    //   359: invokeinterface remove : (I)Ljava/lang/Object;
    //   364: pop
    //   365: iconst_1
    //   366: istore #9
    //   368: goto -> 383
    //   371: iload #5
    //   373: iconst_1
    //   374: iadd
    //   375: istore #5
    //   377: goto -> 323
    //   380: iconst_0
    //   381: istore #9
    //   383: aload_0
    //   384: iload #9
    //   386: putfield J : Z
    //   389: goto -> 528
    //   392: iload #6
    //   394: bipush #-2
    //   396: if_icmpne -> 478
    //   399: aload_0
    //   400: getfield r : Landroid/media/MediaCodec;
    //   403: invokevirtual getOutputFormat : ()Landroid/media/MediaFormat;
    //   406: astore #10
    //   408: aload_0
    //   409: getfield x : Z
    //   412: ifeq -> 449
    //   415: aload #10
    //   417: ldc_w 'width'
    //   420: invokevirtual getInteger : (Ljava/lang/String;)I
    //   423: bipush #32
    //   425: if_icmpne -> 449
    //   428: aload #10
    //   430: ldc_w 'height'
    //   433: invokevirtual getInteger : (Ljava/lang/String;)I
    //   436: bipush #32
    //   438: if_icmpne -> 449
    //   441: aload_0
    //   442: iconst_1
    //   443: putfield D : Z
    //   446: goto -> 709
    //   449: aload_0
    //   450: getfield B : Z
    //   453: ifeq -> 465
    //   456: aload #10
    //   458: ldc_w 'channel-count'
    //   461: iconst_1
    //   462: invokevirtual setInteger : (Ljava/lang/String;I)V
    //   465: aload_0
    //   466: aload_0
    //   467: getfield r : Landroid/media/MediaCodec;
    //   470: aload #10
    //   472: invokevirtual a : (Landroid/media/MediaCodec;Landroid/media/MediaFormat;)V
    //   475: goto -> 709
    //   478: iload #6
    //   480: bipush #-3
    //   482: if_icmpne -> 499
    //   485: aload_0
    //   486: aload_0
    //   487: getfield r : Landroid/media/MediaCodec;
    //   490: invokevirtual getOutputBuffers : ()[Ljava/nio/ByteBuffer;
    //   493: putfield F : [Ljava/nio/ByteBuffer;
    //   496: goto -> 709
    //   499: aload_0
    //   500: getfield y : Z
    //   503: ifeq -> 706
    //   506: aload_0
    //   507: getfield P : Z
    //   510: ifne -> 521
    //   513: aload_0
    //   514: getfield M : I
    //   517: iconst_2
    //   518: if_icmpne -> 706
    //   521: aload_0
    //   522: invokevirtual u : ()V
    //   525: goto -> 706
    //   528: aload_0
    //   529: getfield A : Z
    //   532: ifeq -> 622
    //   535: aload_0
    //   536: getfield O : Z
    //   539: ifeq -> 622
    //   542: aload_0
    //   543: getfield r : Landroid/media/MediaCodec;
    //   546: astore #10
    //   548: aload_0
    //   549: getfield F : [Ljava/nio/ByteBuffer;
    //   552: astore #11
    //   554: aload_0
    //   555: getfield I : I
    //   558: istore #5
    //   560: aload #11
    //   562: iload #5
    //   564: aaload
    //   565: astore #11
    //   567: aload_0
    //   568: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   571: astore #12
    //   573: aload_0
    //   574: lload_1
    //   575: lload_3
    //   576: aload #10
    //   578: aload #11
    //   580: iload #5
    //   582: aload #12
    //   584: getfield flags : I
    //   587: aload #12
    //   589: getfield presentationTimeUs : J
    //   592: aload_0
    //   593: getfield J : Z
    //   596: invokevirtual a : (JJLandroid/media/MediaCodec;Ljava/nio/ByteBuffer;IIJZ)Z
    //   599: istore #9
    //   601: goto -> 681
    //   604: aload_0
    //   605: invokevirtual u : ()V
    //   608: aload_0
    //   609: getfield Q : Z
    //   612: ifeq -> 706
    //   615: aload_0
    //   616: invokevirtual v : ()V
    //   619: goto -> 706
    //   622: aload_0
    //   623: getfield r : Landroid/media/MediaCodec;
    //   626: astore #10
    //   628: aload_0
    //   629: getfield F : [Ljava/nio/ByteBuffer;
    //   632: astore #11
    //   634: aload_0
    //   635: getfield I : I
    //   638: istore #5
    //   640: aload #11
    //   642: iload #5
    //   644: aaload
    //   645: astore #11
    //   647: aload_0
    //   648: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   651: astore #12
    //   653: aload_0
    //   654: lload_1
    //   655: lload_3
    //   656: aload #10
    //   658: aload #11
    //   660: iload #5
    //   662: aload #12
    //   664: getfield flags : I
    //   667: aload #12
    //   669: getfield presentationTimeUs : J
    //   672: aload_0
    //   673: getfield J : Z
    //   676: invokevirtual a : (JJLandroid/media/MediaCodec;Ljava/nio/ByteBuffer;IIJZ)Z
    //   679: istore #9
    //   681: iload #9
    //   683: ifeq -> 706
    //   686: aload_0
    //   687: getfield p : Landroid/media/MediaCodec$BufferInfo;
    //   690: getfield presentationTimeUs : J
    //   693: lstore #7
    //   695: aload_0
    //   696: iconst_m1
    //   697: putfield I : I
    //   700: iconst_1
    //   701: istore #5
    //   703: goto -> 709
    //   706: iconst_0
    //   707: istore #5
    //   709: iload #5
    //   711: ifeq -> 717
    //   714: goto -> 106
    //   717: aload_0
    //   718: invokevirtual s : ()Z
    //   721: ifeq -> 727
    //   724: goto -> 717
    //   727: invokestatic a : ()V
    //   730: goto -> 818
    //   733: aload_0
    //   734: getfield e : Lcom/fyber/inneractive/sdk/player/exoplayer2/source/o;
    //   737: lload_1
    //   738: aload_0
    //   739: getfield f : J
    //   742: lsub
    //   743: invokeinterface a : (J)V
    //   748: aload_0
    //   749: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   752: invokevirtual a : ()V
    //   755: aload_0
    //   756: aload_0
    //   757: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   760: aload_0
    //   761: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   764: iconst_0
    //   765: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/j;Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;Z)I
    //   768: istore #5
    //   770: iload #5
    //   772: bipush #-5
    //   774: if_icmpne -> 791
    //   777: aload_0
    //   778: aload_0
    //   779: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   782: getfield a : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   785: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;)V
    //   788: goto -> 818
    //   791: iload #5
    //   793: bipush #-4
    //   795: if_icmpne -> 818
    //   798: aload_0
    //   799: getfield m : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   802: iconst_4
    //   803: invokevirtual b : (I)Z
    //   806: invokestatic b : (Z)V
    //   809: aload_0
    //   810: iconst_1
    //   811: putfield P : Z
    //   814: aload_0
    //   815: invokevirtual u : ()V
    //   818: aload_0
    //   819: getfield T : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/DecoderCounters;
    //   822: invokevirtual ensureUpdated : ()V
    //   825: return
    //   826: astore #10
    //   828: goto -> 149
    //   831: astore #10
    //   833: goto -> 604
    // Exception table:
    //   from	to	target	type
    //   130	146	826	java/lang/IllegalStateException
    //   542	560	831	java/lang/IllegalStateException
    //   567	601	831	java/lang/IllegalStateException
  }
  
  public void a(long paramLong, boolean paramBoolean) throws d {
    this.P = false;
    this.Q = false;
    if (this.r != null) {
      this.G = -9223372036854775807L;
      this.H = -1;
      this.I = -1;
      this.S = true;
      this.R = false;
      this.J = false;
      this.o.clear();
      this.C = false;
      this.D = false;
      if (this.w || (this.z && this.O)) {
        v();
        t();
      } else if (this.M != 0) {
        v();
        t();
      } else {
        this.r.flush();
        this.N = false;
      } 
      if (this.K && this.q != null)
        this.L = 1; 
    } 
  }
  
  public abstract void a(MediaCodec paramMediaCodec, MediaFormat paramMediaFormat) throws d;
  
  public void a(com.fyber.inneractive.sdk.player.exoplayer2.decoder.b paramb) {}
  
  public void a(i parami) throws d {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   4: astore #4
    //   6: aload_0
    //   7: aload_1
    //   8: putfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   11: aload_1
    //   12: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;
    //   15: astore #5
    //   17: aload #4
    //   19: ifnonnull -> 27
    //   22: aconst_null
    //   23: astore_1
    //   24: goto -> 33
    //   27: aload #4
    //   29: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;
    //   32: astore_1
    //   33: aload #5
    //   35: aload_1
    //   36: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   39: istore_3
    //   40: iconst_1
    //   41: istore_2
    //   42: iload_3
    //   43: iconst_1
    //   44: ixor
    //   45: ifeq -> 133
    //   48: aload_0
    //   49: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   52: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;
    //   55: ifnull -> 128
    //   58: aload_0
    //   59: getfield j : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/c;
    //   62: astore_1
    //   63: aload_1
    //   64: ifnull -> 110
    //   67: aload_1
    //   68: invokestatic myLooper : ()Landroid/os/Looper;
    //   71: aload_0
    //   72: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   75: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;
    //   78: invokeinterface a : (Landroid/os/Looper;Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/a;)Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   83: astore_1
    //   84: aload_0
    //   85: aload_1
    //   86: putfield t : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   89: aload_1
    //   90: aload_0
    //   91: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   94: if_acmpne -> 133
    //   97: aload_0
    //   98: getfield j : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/c;
    //   101: aload_1
    //   102: invokeinterface a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;)V
    //   107: goto -> 133
    //   110: new java/lang/IllegalStateException
    //   113: dup
    //   114: ldc_w 'Media requires a DrmSessionManager'
    //   117: invokespecial <init> : (Ljava/lang/String;)V
    //   120: aload_0
    //   121: getfield c : I
    //   124: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   127: athrow
    //   128: aload_0
    //   129: aconst_null
    //   130: putfield t : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   133: aload_0
    //   134: getfield t : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   137: aload_0
    //   138: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   141: if_acmpne -> 228
    //   144: aload_0
    //   145: getfield r : Landroid/media/MediaCodec;
    //   148: astore_1
    //   149: aload_1
    //   150: ifnull -> 228
    //   153: aload_0
    //   154: aload_1
    //   155: aload_0
    //   156: getfield u : Z
    //   159: aload #4
    //   161: aload_0
    //   162: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   165: invokevirtual a : (Landroid/media/MediaCodec;ZLcom/fyber/inneractive/sdk/player/exoplayer2/i;Lcom/fyber/inneractive/sdk/player/exoplayer2/i;)Z
    //   168: ifeq -> 228
    //   171: aload_0
    //   172: iconst_1
    //   173: putfield K : Z
    //   176: aload_0
    //   177: iconst_1
    //   178: putfield L : I
    //   181: aload_0
    //   182: getfield x : Z
    //   185: ifeq -> 220
    //   188: aload_0
    //   189: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   192: astore_1
    //   193: aload_1
    //   194: getfield j : I
    //   197: aload #4
    //   199: getfield j : I
    //   202: if_icmpne -> 220
    //   205: aload_1
    //   206: getfield k : I
    //   209: aload #4
    //   211: getfield k : I
    //   214: if_icmpne -> 220
    //   217: goto -> 222
    //   220: iconst_0
    //   221: istore_2
    //   222: aload_0
    //   223: iload_2
    //   224: putfield C : Z
    //   227: return
    //   228: aload_0
    //   229: getfield N : Z
    //   232: ifeq -> 241
    //   235: aload_0
    //   236: iconst_1
    //   237: putfield M : I
    //   240: return
    //   241: aload_0
    //   242: invokevirtual v : ()V
    //   245: aload_0
    //   246: invokevirtual t : ()V
    //   249: return
  }
  
  public abstract void a(a parama, MediaCodec paramMediaCodec, i parami, MediaCrypto paramMediaCrypto) throws d.b;
  
  public abstract void a(String paramString, long paramLong1, long paramLong2);
  
  public abstract boolean a(long paramLong1, long paramLong2, MediaCodec paramMediaCodec, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, long paramLong3, boolean paramBoolean) throws d;
  
  public boolean a(MediaCodec paramMediaCodec, boolean paramBoolean, i parami1, i parami2) {
    return false;
  }
  
  public boolean b() {
    return this.Q;
  }
  
  public boolean isReady() {
    if (this.q != null && !this.R) {
      boolean bool;
      if (this.g) {
        bool = this.h;
      } else {
        bool = this.e.isReady();
      } 
      if (bool || this.I >= 0 || (this.G != -9223372036854775807L && SystemClock.elapsedRealtime() < this.G))
        return true; 
    } 
    return false;
  }
  
  public void p() {
    this.q = null;
    try {
      v();
    } finally {
      Exception exception = null;
    } 
  }
  
  public final boolean s() throws d {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Landroid/media/MediaCodec;
    //   4: astore #12
    //   6: aload #12
    //   8: ifnull -> 979
    //   11: aload_0
    //   12: getfield M : I
    //   15: iconst_2
    //   16: if_icmpeq -> 979
    //   19: aload_0
    //   20: getfield P : Z
    //   23: ifeq -> 28
    //   26: iconst_0
    //   27: ireturn
    //   28: aload_0
    //   29: getfield H : I
    //   32: ifge -> 75
    //   35: aload #12
    //   37: lconst_0
    //   38: invokevirtual dequeueInputBuffer : (J)I
    //   41: istore_1
    //   42: aload_0
    //   43: iload_1
    //   44: putfield H : I
    //   47: iload_1
    //   48: ifge -> 53
    //   51: iconst_0
    //   52: ireturn
    //   53: aload_0
    //   54: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   57: astore #12
    //   59: aload #12
    //   61: aload_0
    //   62: getfield E : [Ljava/nio/ByteBuffer;
    //   65: iload_1
    //   66: aaload
    //   67: putfield c : Ljava/nio/ByteBuffer;
    //   70: aload #12
    //   72: invokevirtual a : ()V
    //   75: aload_0
    //   76: getfield M : I
    //   79: iconst_1
    //   80: if_icmpne -> 125
    //   83: aload_0
    //   84: getfield y : Z
    //   87: ifeq -> 93
    //   90: goto -> 118
    //   93: aload_0
    //   94: iconst_1
    //   95: putfield O : Z
    //   98: aload_0
    //   99: getfield r : Landroid/media/MediaCodec;
    //   102: aload_0
    //   103: getfield H : I
    //   106: iconst_0
    //   107: iconst_0
    //   108: lconst_0
    //   109: iconst_4
    //   110: invokevirtual queueInputBuffer : (IIIJI)V
    //   113: aload_0
    //   114: iconst_m1
    //   115: putfield H : I
    //   118: aload_0
    //   119: iconst_2
    //   120: putfield M : I
    //   123: iconst_0
    //   124: ireturn
    //   125: aload_0
    //   126: getfield C : Z
    //   129: ifeq -> 188
    //   132: aload_0
    //   133: iconst_0
    //   134: putfield C : Z
    //   137: aload_0
    //   138: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   141: getfield c : Ljava/nio/ByteBuffer;
    //   144: astore #12
    //   146: getstatic com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/b.U : [B
    //   149: astore #13
    //   151: aload #12
    //   153: aload #13
    //   155: invokevirtual put : ([B)Ljava/nio/ByteBuffer;
    //   158: pop
    //   159: aload_0
    //   160: getfield r : Landroid/media/MediaCodec;
    //   163: aload_0
    //   164: getfield H : I
    //   167: iconst_0
    //   168: aload #13
    //   170: arraylength
    //   171: lconst_0
    //   172: iconst_0
    //   173: invokevirtual queueInputBuffer : (IIIJI)V
    //   176: aload_0
    //   177: iconst_m1
    //   178: putfield H : I
    //   181: aload_0
    //   182: iconst_1
    //   183: putfield N : Z
    //   186: iconst_1
    //   187: ireturn
    //   188: aload_0
    //   189: getfield R : Z
    //   192: ifeq -> 203
    //   195: bipush #-4
    //   197: istore_1
    //   198: iconst_0
    //   199: istore_3
    //   200: goto -> 297
    //   203: aload_0
    //   204: getfield L : I
    //   207: iconst_1
    //   208: if_icmpne -> 272
    //   211: iconst_0
    //   212: istore_1
    //   213: iload_1
    //   214: aload_0
    //   215: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   218: getfield h : Ljava/util/List;
    //   221: invokeinterface size : ()I
    //   226: if_icmpge -> 267
    //   229: aload_0
    //   230: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   233: getfield h : Ljava/util/List;
    //   236: iload_1
    //   237: invokeinterface get : (I)Ljava/lang/Object;
    //   242: checkcast [B
    //   245: astore #12
    //   247: aload_0
    //   248: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   251: getfield c : Ljava/nio/ByteBuffer;
    //   254: aload #12
    //   256: invokevirtual put : ([B)Ljava/nio/ByteBuffer;
    //   259: pop
    //   260: iload_1
    //   261: iconst_1
    //   262: iadd
    //   263: istore_1
    //   264: goto -> 213
    //   267: aload_0
    //   268: iconst_2
    //   269: putfield L : I
    //   272: aload_0
    //   273: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   276: getfield c : Ljava/nio/ByteBuffer;
    //   279: invokevirtual position : ()I
    //   282: istore_3
    //   283: aload_0
    //   284: aload_0
    //   285: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   288: aload_0
    //   289: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   292: iconst_0
    //   293: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/j;Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;Z)I
    //   296: istore_1
    //   297: iload_1
    //   298: bipush #-3
    //   300: if_icmpne -> 305
    //   303: iconst_0
    //   304: ireturn
    //   305: iload_1
    //   306: bipush #-5
    //   308: if_icmpne -> 344
    //   311: aload_0
    //   312: getfield L : I
    //   315: iconst_2
    //   316: if_icmpne -> 331
    //   319: aload_0
    //   320: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   323: invokevirtual a : ()V
    //   326: aload_0
    //   327: iconst_1
    //   328: putfield L : I
    //   331: aload_0
    //   332: aload_0
    //   333: getfield n : Lcom/fyber/inneractive/sdk/player/exoplayer2/j;
    //   336: getfield a : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   339: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;)V
    //   342: iconst_1
    //   343: ireturn
    //   344: aload_0
    //   345: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   348: iconst_4
    //   349: invokevirtual b : (I)Z
    //   352: ifeq -> 441
    //   355: aload_0
    //   356: getfield L : I
    //   359: iconst_2
    //   360: if_icmpne -> 375
    //   363: aload_0
    //   364: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   367: invokevirtual a : ()V
    //   370: aload_0
    //   371: iconst_1
    //   372: putfield L : I
    //   375: aload_0
    //   376: iconst_1
    //   377: putfield P : Z
    //   380: aload_0
    //   381: getfield N : Z
    //   384: ifne -> 393
    //   387: aload_0
    //   388: invokevirtual u : ()V
    //   391: iconst_0
    //   392: ireturn
    //   393: aload_0
    //   394: getfield y : Z
    //   397: ifeq -> 402
    //   400: iconst_0
    //   401: ireturn
    //   402: aload_0
    //   403: iconst_1
    //   404: putfield O : Z
    //   407: aload_0
    //   408: getfield r : Landroid/media/MediaCodec;
    //   411: aload_0
    //   412: getfield H : I
    //   415: iconst_0
    //   416: iconst_0
    //   417: lconst_0
    //   418: iconst_4
    //   419: invokevirtual queueInputBuffer : (IIIJI)V
    //   422: aload_0
    //   423: iconst_m1
    //   424: putfield H : I
    //   427: iconst_0
    //   428: ireturn
    //   429: astore #12
    //   431: aload #12
    //   433: aload_0
    //   434: getfield c : I
    //   437: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   440: athrow
    //   441: aload_0
    //   442: getfield S : Z
    //   445: ifeq -> 481
    //   448: aload_0
    //   449: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   452: iconst_1
    //   453: invokevirtual b : (I)Z
    //   456: ifne -> 481
    //   459: aload_0
    //   460: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   463: invokevirtual a : ()V
    //   466: aload_0
    //   467: getfield L : I
    //   470: iconst_2
    //   471: if_icmpne -> 479
    //   474: aload_0
    //   475: iconst_1
    //   476: putfield L : I
    //   479: iconst_1
    //   480: ireturn
    //   481: aload_0
    //   482: iconst_0
    //   483: putfield S : Z
    //   486: aload_0
    //   487: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   490: ldc_w 1073741824
    //   493: invokevirtual b : (I)Z
    //   496: istore #9
    //   498: aload_0
    //   499: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   502: astore #12
    //   504: aload #12
    //   506: ifnonnull -> 512
    //   509: goto -> 547
    //   512: aload #12
    //   514: invokeinterface a : ()I
    //   519: istore_1
    //   520: iload_1
    //   521: ifeq -> 960
    //   524: iload_1
    //   525: iconst_4
    //   526: if_icmpeq -> 547
    //   529: iload #9
    //   531: ifne -> 541
    //   534: aload_0
    //   535: getfield k : Z
    //   538: ifne -> 547
    //   541: iconst_1
    //   542: istore #8
    //   544: goto -> 550
    //   547: iconst_0
    //   548: istore #8
    //   550: aload_0
    //   551: iload #8
    //   553: putfield R : Z
    //   556: iload #8
    //   558: ifeq -> 563
    //   561: iconst_0
    //   562: ireturn
    //   563: aload_0
    //   564: getfield v : Z
    //   567: ifeq -> 753
    //   570: iload #9
    //   572: ifne -> 753
    //   575: aload_0
    //   576: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   579: getfield c : Ljava/nio/ByteBuffer;
    //   582: astore #12
    //   584: getstatic com/fyber/inneractive/sdk/player/exoplayer2/util/i.a : [B
    //   587: astore #13
    //   589: aload #12
    //   591: invokevirtual position : ()I
    //   594: istore #6
    //   596: iconst_0
    //   597: istore #4
    //   599: iconst_0
    //   600: istore_1
    //   601: iload #4
    //   603: iconst_1
    //   604: iadd
    //   605: istore #5
    //   607: iload #5
    //   609: iload #6
    //   611: if_icmpge -> 727
    //   614: aload #12
    //   616: iload #4
    //   618: invokevirtual get : (I)B
    //   621: sipush #255
    //   624: iand
    //   625: istore #7
    //   627: iload_1
    //   628: iconst_3
    //   629: if_icmpne -> 700
    //   632: iload_1
    //   633: istore_2
    //   634: iload #7
    //   636: iconst_1
    //   637: if_icmpne -> 711
    //   640: iload_1
    //   641: istore_2
    //   642: aload #12
    //   644: iload #5
    //   646: invokevirtual get : (I)B
    //   649: bipush #31
    //   651: iand
    //   652: bipush #7
    //   654: if_icmpne -> 711
    //   657: aload #12
    //   659: invokevirtual duplicate : ()Ljava/nio/ByteBuffer;
    //   662: astore #13
    //   664: aload #13
    //   666: iload #4
    //   668: iconst_3
    //   669: isub
    //   670: invokevirtual position : (I)Ljava/nio/Buffer;
    //   673: pop
    //   674: aload #13
    //   676: iload #6
    //   678: invokevirtual limit : (I)Ljava/nio/Buffer;
    //   681: pop
    //   682: aload #12
    //   684: iconst_0
    //   685: invokevirtual position : (I)Ljava/nio/Buffer;
    //   688: pop
    //   689: aload #12
    //   691: aload #13
    //   693: invokevirtual put : (Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    //   696: pop
    //   697: goto -> 733
    //   700: iload_1
    //   701: istore_2
    //   702: iload #7
    //   704: ifne -> 711
    //   707: iload_1
    //   708: iconst_1
    //   709: iadd
    //   710: istore_2
    //   711: iload_2
    //   712: istore_1
    //   713: iload #7
    //   715: ifeq -> 720
    //   718: iconst_0
    //   719: istore_1
    //   720: iload #5
    //   722: istore #4
    //   724: goto -> 601
    //   727: aload #12
    //   729: invokevirtual clear : ()Ljava/nio/Buffer;
    //   732: pop
    //   733: aload_0
    //   734: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   737: getfield c : Ljava/nio/ByteBuffer;
    //   740: invokevirtual position : ()I
    //   743: ifne -> 748
    //   746: iconst_1
    //   747: ireturn
    //   748: aload_0
    //   749: iconst_0
    //   750: putfield v : Z
    //   753: aload_0
    //   754: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   757: astore #12
    //   759: aload #12
    //   761: getfield d : J
    //   764: lstore #10
    //   766: aload #12
    //   768: ldc_w -2147483648
    //   771: invokevirtual b : (I)Z
    //   774: ifeq -> 792
    //   777: aload_0
    //   778: getfield o : Ljava/util/List;
    //   781: lload #10
    //   783: invokestatic valueOf : (J)Ljava/lang/Long;
    //   786: invokeinterface add : (Ljava/lang/Object;)Z
    //   791: pop
    //   792: aload_0
    //   793: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   796: getfield c : Ljava/nio/ByteBuffer;
    //   799: invokevirtual flip : ()Ljava/nio/Buffer;
    //   802: pop
    //   803: aload_0
    //   804: aload_0
    //   805: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   808: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;)V
    //   811: iload #9
    //   813: ifeq -> 888
    //   816: aload_0
    //   817: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   820: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/a;
    //   823: getfield g : Landroid/media/MediaCodec$CryptoInfo;
    //   826: astore #12
    //   828: iload_3
    //   829: ifne -> 835
    //   832: goto -> 868
    //   835: aload #12
    //   837: getfield numBytesOfClearData : [I
    //   840: ifnonnull -> 851
    //   843: aload #12
    //   845: iconst_1
    //   846: newarray int
    //   848: putfield numBytesOfClearData : [I
    //   851: aload #12
    //   853: getfield numBytesOfClearData : [I
    //   856: astore #13
    //   858: aload #13
    //   860: iconst_0
    //   861: aload #13
    //   863: iconst_0
    //   864: iaload
    //   865: iload_3
    //   866: iadd
    //   867: iastore
    //   868: aload_0
    //   869: getfield r : Landroid/media/MediaCodec;
    //   872: aload_0
    //   873: getfield H : I
    //   876: iconst_0
    //   877: aload #12
    //   879: lload #10
    //   881: iconst_0
    //   882: invokevirtual queueSecureInputBuffer : (IILandroid/media/MediaCodec$CryptoInfo;JI)V
    //   885: goto -> 913
    //   888: aload_0
    //   889: getfield r : Landroid/media/MediaCodec;
    //   892: aload_0
    //   893: getfield H : I
    //   896: iconst_0
    //   897: aload_0
    //   898: getfield l : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/b;
    //   901: getfield c : Ljava/nio/ByteBuffer;
    //   904: invokevirtual limit : ()I
    //   907: lload #10
    //   909: iconst_0
    //   910: invokevirtual queueInputBuffer : (IIIJI)V
    //   913: aload_0
    //   914: iconst_m1
    //   915: putfield H : I
    //   918: aload_0
    //   919: iconst_1
    //   920: putfield N : Z
    //   923: aload_0
    //   924: iconst_0
    //   925: putfield L : I
    //   928: aload_0
    //   929: getfield T : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/DecoderCounters;
    //   932: astore #12
    //   934: aload #12
    //   936: aload #12
    //   938: getfield inputBufferCount : I
    //   941: iconst_1
    //   942: iadd
    //   943: putfield inputBufferCount : I
    //   946: iconst_1
    //   947: ireturn
    //   948: astore #12
    //   950: aload #12
    //   952: aload_0
    //   953: getfield c : I
    //   956: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   959: athrow
    //   960: aload_0
    //   961: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   964: invokeinterface c : ()Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b$a;
    //   969: pop
    //   970: aconst_null
    //   971: aload_0
    //   972: getfield c : I
    //   975: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   978: athrow
    //   979: iconst_0
    //   980: ireturn
    // Exception table:
    //   from	to	target	type
    //   393	400	429	android/media/MediaCodec$CryptoException
    //   402	427	429	android/media/MediaCodec$CryptoException
    //   753	792	948	android/media/MediaCodec$CryptoException
    //   792	811	948	android/media/MediaCodec$CryptoException
    //   816	828	948	android/media/MediaCodec$CryptoException
    //   835	851	948	android/media/MediaCodec$CryptoException
    //   851	858	948	android/media/MediaCodec$CryptoException
    //   868	885	948	android/media/MediaCodec$CryptoException
    //   888	913	948	android/media/MediaCodec$CryptoException
    //   913	946	948	android/media/MediaCodec$CryptoException
  }
  
  public final void t() throws d {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield t : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   12: astore #9
    //   14: aload_0
    //   15: aload #9
    //   17: putfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   20: aload_0
    //   21: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   24: getfield f : Ljava/lang/String;
    //   27: astore #11
    //   29: iconst_0
    //   30: istore #4
    //   32: aload #9
    //   34: ifnull -> 110
    //   37: aload #9
    //   39: invokeinterface a : ()I
    //   44: istore_1
    //   45: iload_1
    //   46: ifeq -> 91
    //   49: iload_1
    //   50: iconst_3
    //   51: if_icmpeq -> 63
    //   54: iload_1
    //   55: iconst_4
    //   56: if_icmpne -> 62
    //   59: goto -> 63
    //   62: return
    //   63: aload_0
    //   64: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   67: invokeinterface b : ()Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/d;
    //   72: invokevirtual getClass : ()Ljava/lang/Class;
    //   75: pop
    //   76: aload_0
    //   77: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   80: aload #11
    //   82: invokeinterface a : (Ljava/lang/String;)Z
    //   87: istore_2
    //   88: goto -> 112
    //   91: aload_0
    //   92: getfield s : Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b;
    //   95: invokeinterface c : ()Lcom/fyber/inneractive/sdk/player/exoplayer2/drm/b$a;
    //   100: pop
    //   101: aconst_null
    //   102: aload_0
    //   103: getfield c : I
    //   106: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   109: athrow
    //   110: iconst_0
    //   111: istore_2
    //   112: aload_0
    //   113: aload_0
    //   114: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/c;
    //   117: aload_0
    //   118: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   121: iload_2
    //   122: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/c;Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Z)Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/a;
    //   125: astore #10
    //   127: aload #10
    //   129: astore #9
    //   131: aload #10
    //   133: ifnonnull -> 233
    //   136: aload #10
    //   138: astore #9
    //   140: iload_2
    //   141: ifeq -> 233
    //   144: aload_0
    //   145: aload_0
    //   146: getfield i : Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/c;
    //   149: aload_0
    //   150: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   153: iconst_0
    //   154: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/c;Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Z)Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/a;
    //   157: astore #10
    //   159: aload #10
    //   161: astore #9
    //   163: aload #10
    //   165: ifnull -> 233
    //   168: new java/lang/StringBuilder
    //   171: dup
    //   172: ldc_w 'Drm session requires secure decoder for '
    //   175: invokespecial <init> : (Ljava/lang/String;)V
    //   178: astore #9
    //   180: aload #9
    //   182: aload #11
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload #9
    //   190: ldc_w ', but no secure decoder available. Trying to proceed with '
    //   193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: pop
    //   197: aload #9
    //   199: aload #10
    //   201: getfield a : Ljava/lang/String;
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload #9
    //   210: ldc_w '.'
    //   213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: pop
    //   217: ldc_w 'MediaCodecRenderer'
    //   220: aload #9
    //   222: invokevirtual toString : ()Ljava/lang/String;
    //   225: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   228: pop
    //   229: aload #10
    //   231: astore #9
    //   233: aload #9
    //   235: ifnull -> 886
    //   238: aload #9
    //   240: getfield a : Ljava/lang/String;
    //   243: astore #10
    //   245: aload_0
    //   246: aload #9
    //   248: getfield b : Z
    //   251: putfield u : Z
    //   254: aload_0
    //   255: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   258: astore #11
    //   260: getstatic com/fyber/inneractive/sdk/player/exoplayer2/util/u.a : I
    //   263: istore_1
    //   264: iload_1
    //   265: bipush #21
    //   267: if_icmpge -> 299
    //   270: aload #11
    //   272: getfield h : Ljava/util/List;
    //   275: invokeinterface isEmpty : ()Z
    //   280: ifeq -> 299
    //   283: ldc_w 'OMX.MTK.VIDEO.DECODER.AVC'
    //   286: aload #10
    //   288: invokevirtual equals : (Ljava/lang/Object;)Z
    //   291: ifeq -> 299
    //   294: iconst_1
    //   295: istore_3
    //   296: goto -> 301
    //   299: iconst_0
    //   300: istore_3
    //   301: aload_0
    //   302: iload_3
    //   303: putfield v : Z
    //   306: iload_1
    //   307: bipush #18
    //   309: if_icmplt -> 388
    //   312: iload_1
    //   313: bipush #18
    //   315: if_icmpne -> 340
    //   318: ldc_w 'OMX.SEC.avc.dec'
    //   321: aload #10
    //   323: invokevirtual equals : (Ljava/lang/Object;)Z
    //   326: ifne -> 388
    //   329: ldc_w 'OMX.SEC.avc.dec.secure'
    //   332: aload #10
    //   334: invokevirtual equals : (Ljava/lang/Object;)Z
    //   337: ifne -> 388
    //   340: iload_1
    //   341: bipush #19
    //   343: if_icmpne -> 383
    //   346: getstatic com/fyber/inneractive/sdk/player/exoplayer2/util/u.d : Ljava/lang/String;
    //   349: ldc_w 'SM-G800'
    //   352: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   355: ifeq -> 383
    //   358: ldc_w 'OMX.Exynos.avc.dec'
    //   361: aload #10
    //   363: invokevirtual equals : (Ljava/lang/Object;)Z
    //   366: ifne -> 388
    //   369: ldc_w 'OMX.Exynos.avc.dec.secure'
    //   372: aload #10
    //   374: invokevirtual equals : (Ljava/lang/Object;)Z
    //   377: ifeq -> 383
    //   380: goto -> 388
    //   383: iconst_0
    //   384: istore_3
    //   385: goto -> 390
    //   388: iconst_1
    //   389: istore_3
    //   390: aload_0
    //   391: iload_3
    //   392: putfield w : Z
    //   395: iload_1
    //   396: bipush #24
    //   398: if_icmpge -> 477
    //   401: ldc_w 'OMX.Nvidia.h264.decode'
    //   404: aload #10
    //   406: invokevirtual equals : (Ljava/lang/Object;)Z
    //   409: ifne -> 423
    //   412: ldc_w 'OMX.Nvidia.h264.decode.secure'
    //   415: aload #10
    //   417: invokevirtual equals : (Ljava/lang/Object;)Z
    //   420: ifeq -> 477
    //   423: getstatic com/fyber/inneractive/sdk/player/exoplayer2/util/u.b : Ljava/lang/String;
    //   426: astore #11
    //   428: ldc_w 'flounder'
    //   431: aload #11
    //   433: invokevirtual equals : (Ljava/lang/Object;)Z
    //   436: ifne -> 472
    //   439: ldc_w 'flounder_lte'
    //   442: aload #11
    //   444: invokevirtual equals : (Ljava/lang/Object;)Z
    //   447: ifne -> 472
    //   450: ldc_w 'grouper'
    //   453: aload #11
    //   455: invokevirtual equals : (Ljava/lang/Object;)Z
    //   458: ifne -> 472
    //   461: ldc_w 'tilapia'
    //   464: aload #11
    //   466: invokevirtual equals : (Ljava/lang/Object;)Z
    //   469: ifeq -> 477
    //   472: iconst_1
    //   473: istore_3
    //   474: goto -> 479
    //   477: iconst_0
    //   478: istore_3
    //   479: aload_0
    //   480: iload_3
    //   481: putfield x : Z
    //   484: iload_1
    //   485: bipush #17
    //   487: if_icmpgt -> 517
    //   490: ldc_w 'OMX.rk.video_decoder.avc'
    //   493: aload #10
    //   495: invokevirtual equals : (Ljava/lang/Object;)Z
    //   498: ifne -> 512
    //   501: ldc_w 'OMX.allwinner.video.decoder.avc'
    //   504: aload #10
    //   506: invokevirtual equals : (Ljava/lang/Object;)Z
    //   509: ifeq -> 517
    //   512: iconst_1
    //   513: istore_3
    //   514: goto -> 519
    //   517: iconst_0
    //   518: istore_3
    //   519: aload_0
    //   520: iload_3
    //   521: putfield y : Z
    //   524: iload_1
    //   525: bipush #23
    //   527: if_icmpgt -> 541
    //   530: ldc_w 'OMX.google.vorbis.decoder'
    //   533: aload #10
    //   535: invokevirtual equals : (Ljava/lang/Object;)Z
    //   538: ifne -> 581
    //   541: iload_1
    //   542: bipush #19
    //   544: if_icmpgt -> 586
    //   547: ldc_w 'hb2000'
    //   550: getstatic com/fyber/inneractive/sdk/player/exoplayer2/util/u.b : Ljava/lang/String;
    //   553: invokevirtual equals : (Ljava/lang/Object;)Z
    //   556: ifeq -> 586
    //   559: ldc_w 'OMX.amlogic.avc.decoder.awesome'
    //   562: aload #10
    //   564: invokevirtual equals : (Ljava/lang/Object;)Z
    //   567: ifne -> 581
    //   570: ldc_w 'OMX.amlogic.avc.decoder.awesome.secure'
    //   573: aload #10
    //   575: invokevirtual equals : (Ljava/lang/Object;)Z
    //   578: ifeq -> 586
    //   581: iconst_1
    //   582: istore_3
    //   583: goto -> 588
    //   586: iconst_0
    //   587: istore_3
    //   588: aload_0
    //   589: iload_3
    //   590: putfield z : Z
    //   593: iload_1
    //   594: bipush #21
    //   596: if_icmpne -> 615
    //   599: ldc_w 'OMX.google.aac.decoder'
    //   602: aload #10
    //   604: invokevirtual equals : (Ljava/lang/Object;)Z
    //   607: ifeq -> 615
    //   610: iconst_1
    //   611: istore_3
    //   612: goto -> 617
    //   615: iconst_0
    //   616: istore_3
    //   617: aload_0
    //   618: iload_3
    //   619: putfield A : Z
    //   622: aload_0
    //   623: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   626: astore #11
    //   628: iload #4
    //   630: istore_3
    //   631: iload_1
    //   632: bipush #18
    //   634: if_icmpgt -> 665
    //   637: iload #4
    //   639: istore_3
    //   640: aload #11
    //   642: getfield r : I
    //   645: iconst_1
    //   646: if_icmpne -> 665
    //   649: iload #4
    //   651: istore_3
    //   652: ldc_w 'OMX.MTK.AUDIO.DECODER.MP3'
    //   655: aload #10
    //   657: invokevirtual equals : (Ljava/lang/Object;)Z
    //   660: ifeq -> 665
    //   663: iconst_1
    //   664: istore_3
    //   665: aload_0
    //   666: iload_3
    //   667: putfield B : Z
    //   670: invokestatic elapsedRealtime : ()J
    //   673: lstore #5
    //   675: new java/lang/StringBuilder
    //   678: dup
    //   679: ldc_w 'createCodec:'
    //   682: invokespecial <init> : (Ljava/lang/String;)V
    //   685: astore #11
    //   687: aload #11
    //   689: aload #10
    //   691: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   694: pop
    //   695: aload #11
    //   697: invokevirtual toString : ()Ljava/lang/String;
    //   700: invokestatic a : (Ljava/lang/String;)V
    //   703: aload_0
    //   704: aload #10
    //   706: invokestatic createByCodecName : (Ljava/lang/String;)Landroid/media/MediaCodec;
    //   709: putfield r : Landroid/media/MediaCodec;
    //   712: invokestatic a : ()V
    //   715: ldc_w 'configureCodec'
    //   718: invokestatic a : (Ljava/lang/String;)V
    //   721: aload_0
    //   722: aload #9
    //   724: aload_0
    //   725: getfield r : Landroid/media/MediaCodec;
    //   728: aload_0
    //   729: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   732: aconst_null
    //   733: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/mediacodec/a;Landroid/media/MediaCodec;Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Landroid/media/MediaCrypto;)V
    //   736: invokestatic a : ()V
    //   739: ldc_w 'startCodec'
    //   742: invokestatic a : (Ljava/lang/String;)V
    //   745: aload_0
    //   746: getfield r : Landroid/media/MediaCodec;
    //   749: invokevirtual start : ()V
    //   752: invokestatic a : ()V
    //   755: invokestatic elapsedRealtime : ()J
    //   758: lstore #7
    //   760: aload_0
    //   761: aload #10
    //   763: lload #7
    //   765: lload #7
    //   767: lload #5
    //   769: lsub
    //   770: invokevirtual a : (Ljava/lang/String;JJ)V
    //   773: aload_0
    //   774: aload_0
    //   775: getfield r : Landroid/media/MediaCodec;
    //   778: invokevirtual getInputBuffers : ()[Ljava/nio/ByteBuffer;
    //   781: putfield E : [Ljava/nio/ByteBuffer;
    //   784: aload_0
    //   785: aload_0
    //   786: getfield r : Landroid/media/MediaCodec;
    //   789: invokevirtual getOutputBuffers : ()[Ljava/nio/ByteBuffer;
    //   792: putfield F : [Ljava/nio/ByteBuffer;
    //   795: aload_0
    //   796: getfield d : I
    //   799: iconst_2
    //   800: if_icmpne -> 815
    //   803: invokestatic elapsedRealtime : ()J
    //   806: ldc2_w 1000
    //   809: ladd
    //   810: lstore #5
    //   812: goto -> 820
    //   815: ldc2_w -9223372036854775807
    //   818: lstore #5
    //   820: aload_0
    //   821: lload #5
    //   823: putfield G : J
    //   826: aload_0
    //   827: iconst_m1
    //   828: putfield H : I
    //   831: aload_0
    //   832: iconst_m1
    //   833: putfield I : I
    //   836: aload_0
    //   837: iconst_1
    //   838: putfield S : Z
    //   841: aload_0
    //   842: getfield T : Lcom/fyber/inneractive/sdk/player/exoplayer2/decoder/DecoderCounters;
    //   845: astore #9
    //   847: aload #9
    //   849: aload #9
    //   851: getfield decoderInitCount : I
    //   854: iconst_1
    //   855: iadd
    //   856: putfield decoderInitCount : I
    //   859: return
    //   860: astore #9
    //   862: new com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/b$a
    //   865: dup
    //   866: aload_0
    //   867: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   870: aload #9
    //   872: iload_2
    //   873: aload #10
    //   875: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Ljava/lang/Throwable;ZLjava/lang/String;)V
    //   878: aload_0
    //   879: getfield c : I
    //   882: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   885: athrow
    //   886: new com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/b$a
    //   889: dup
    //   890: aload_0
    //   891: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   894: aconst_null
    //   895: iload_2
    //   896: ldc_w -49999
    //   899: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Ljava/lang/Throwable;ZI)V
    //   902: aload_0
    //   903: getfield c : I
    //   906: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   909: athrow
    //   910: astore #9
    //   912: new com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/b$a
    //   915: dup
    //   916: aload_0
    //   917: getfield q : Lcom/fyber/inneractive/sdk/player/exoplayer2/i;
    //   920: aload #9
    //   922: iload_2
    //   923: ldc_w -49998
    //   926: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/exoplayer2/i;Ljava/lang/Throwable;ZI)V
    //   929: aload_0
    //   930: getfield c : I
    //   933: invokestatic a : (Ljava/lang/Exception;I)Lcom/fyber/inneractive/sdk/player/exoplayer2/d;
    //   936: athrow
    // Exception table:
    //   from	to	target	type
    //   112	127	910	com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/d$b
    //   144	159	910	com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/d$b
    //   168	229	910	com/fyber/inneractive/sdk/player/exoplayer2/mediacodec/d$b
    //   670	795	860	java/lang/Exception
  }
  
  public final void u() throws d {
    if (this.M == 2) {
      v();
      t();
      return;
    } 
    this.Q = true;
    w();
  }
  
  public void v() {
    if (this.r != null) {
      this.G = -9223372036854775807L;
      this.H = -1;
      this.I = -1;
      this.R = false;
      this.J = false;
      this.o.clear();
      this.E = null;
      this.F = null;
      this.K = false;
      this.N = false;
      this.u = false;
      this.v = false;
      this.w = false;
      this.x = false;
      this.y = false;
      this.z = false;
      this.B = false;
      this.C = false;
      this.D = false;
      this.O = false;
      this.L = 0;
      this.M = 0;
      DecoderCounters decoderCounters = this.T;
      decoderCounters.decoderReleaseCount++;
      this.l.c = null;
      try {
        this.r.stop();
      } finally {
        decoderCounters = null;
      } 
    } 
  }
  
  public void w() throws d {}
  
  public boolean x() {
    return (this.r == null && this.q != null);
  }
  
  public static class a extends Exception {
    public a(i param1i, Throwable param1Throwable, boolean param1Boolean, int param1Int) {
      super(stringBuilder.toString(), param1Throwable);
      String str = param1i.f;
      a(param1Int);
    }
    
    public a(i param1i, Throwable param1Throwable, boolean param1Boolean, String param1String) {
      super(stringBuilder.toString(), param1Throwable);
      String str = param1i.f;
      if (u.a >= 21)
        a(param1Throwable); 
    }
    
    public static String a(int param1Int) {
      String str;
      if (param1Int < 0) {
        str = "neg_";
      } else {
        str = "";
      } 
      StringBuilder stringBuilder = new StringBuilder("com.google.android.exoplayer.MediaCodecTrackRenderer_");
      stringBuilder.append(str);
      stringBuilder.append(Math.abs(param1Int));
      return stringBuilder.toString();
    }
    
    public static String a(Throwable param1Throwable) {
      return (param1Throwable instanceof MediaCodec.CodecException) ? ((MediaCodec.CodecException)param1Throwable).getDiagnosticInfo() : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\mediacodec\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */