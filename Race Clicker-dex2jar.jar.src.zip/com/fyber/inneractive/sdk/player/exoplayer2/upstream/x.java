package com.fyber.inneractive.sdk.player.exoplayer2.upstream;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import com.fyber.inneractive.sdk.player.exoplayer2.util.s;
import com.fyber.inneractive.sdk.player.exoplayer2.util.u;
import java.io.IOException;
import java.util.concurrent.ExecutorService;

public final class x {
  public final ExecutorService a;
  
  public b<? extends c> b;
  
  public IOException c;
  
  public x(String paramString) {
    this.a = u.b(paramString);
  }
  
  public <T extends c> long a(T paramT, a<T> parama, int paramInt) {
    boolean bool;
    Looper looper = Looper.myLooper();
    if (looper != null) {
      bool = true;
    } else {
      bool = false;
    } 
    com.fyber.inneractive.sdk.player.exoplayer2.util.a.b(bool);
    long l = SystemClock.elapsedRealtime();
    (new b<c>(this, looper, (c)paramT, parama, paramInt, l)).a(0L);
    return l;
  }
  
  public void a() {
    this.b.a(false);
  }
  
  public boolean b() {
    return (this.b != null);
  }
  
  public void c() throws IOException {
    b<? extends c> b1;
    IOException iOException = this.c;
    if (iOException == null) {
      b1 = this.b;
      if (b1 != null) {
        int i = b1.c;
        IOException iOException1 = b1.e;
        if (iOException1 != null) {
          if (b1.f <= i)
            return; 
          throw iOException1;
        } 
      } 
      return;
    } 
    throw b1;
  }
  
  public void d() {
    b<? extends c> b1 = this.b;
    if (b1 != null)
      b1.a(true); 
    this.a.shutdown();
  }
  
  public static interface a<T extends c> {
    int a(T param1T, long param1Long1, long param1Long2, IOException param1IOException);
    
    void a(T param1T, long param1Long1, long param1Long2);
    
    void a(T param1T, long param1Long1, long param1Long2, boolean param1Boolean);
  }
  
  public final class b<T extends c> extends Handler implements Runnable {
    public final T a;
    
    public final x.a<T> b;
    
    public final int c;
    
    public final long d;
    
    public IOException e;
    
    public int f;
    
    public volatile Thread g;
    
    public volatile boolean h;
    
    public b(x this$0, Looper param1Looper, T param1T, x.a<T> param1a, int param1Int, long param1Long) {
      super(param1Looper);
      this.a = param1T;
      this.b = param1a;
      this.c = param1Int;
      this.d = param1Long;
    }
    
    public void a(long param1Long) {
      boolean bool;
      if (this.i.b == null) {
        bool = true;
      } else {
        bool = false;
      } 
      com.fyber.inneractive.sdk.player.exoplayer2.util.a.b(bool);
      x x1 = this.i;
      x1.b = this;
      if (param1Long > 0L) {
        sendEmptyMessageDelayed(0, param1Long);
        return;
      } 
      this.e = null;
      x1.a.execute(this);
    }
    
    public void a(boolean param1Boolean) {
      this.h = param1Boolean;
      this.e = null;
      if (hasMessages(0)) {
        removeMessages(0);
        if (!param1Boolean)
          sendEmptyMessage(1); 
      } else {
        this.a.b();
        if (this.g != null)
          this.g.interrupt(); 
      } 
      if (param1Boolean) {
        this.i.b = null;
        long l = SystemClock.elapsedRealtime();
        this.b.a(this.a, l, l - this.d, true);
      } 
    }
    
    public void handleMessage(Message param1Message) {
      x x1;
      IOException iOException;
      if (this.h)
        return; 
      int i = param1Message.what;
      if (i == 0) {
        this.e = null;
        x1 = this.i;
        x1.a.execute(x1.b);
        return;
      } 
      if (i != 4) {
        this.i.b = null;
        long l1 = SystemClock.elapsedRealtime();
        long l2 = l1 - this.d;
        if (this.a.a()) {
          this.b.a(this.a, l1, l2, false);
          return;
        } 
        i = ((Message)x1).what;
        if (i != 1) {
          if (i != 2) {
            if (i != 3)
              return; 
            iOException = (IOException)((Message)x1).obj;
            this.e = iOException;
            i = this.b.a(this.a, l1, l2, iOException);
            if (i == 3) {
              this.i.c = this.e;
              return;
            } 
            if (i != 2) {
              if (i == 1) {
                i = 1;
              } else {
                i = this.f + 1;
              } 
              this.f = i;
              a(Math.min((i - 1) * 1000, 5000));
              return;
            } 
          } else {
            this.b.a(this.a, l1, l2);
            return;
          } 
        } else {
          this.b.a(this.a, l1, l2, false);
        } 
        return;
      } 
      throw (Error)iOException.obj;
    }
    
    public void run() {
      try {
        this.g = Thread.currentThread();
        if (!this.a.a()) {
          null = new StringBuilder("load:");
          null.append(this.a.getClass().getSimpleName());
          s.a(null.toString());
          try {
            this.a.load();
          } finally {
            s.a();
          } 
        } 
        if (!this.h) {
          sendEmptyMessage(2);
          return;
        } 
      } catch (IOException iOException) {
        if (!this.h)
          obtainMessage(3, iOException).sendToTarget(); 
      } catch (InterruptedException interruptedException) {
        com.fyber.inneractive.sdk.player.exoplayer2.util.a.b(this.a.a());
        if (!this.h) {
          sendEmptyMessage(2);
          return;
        } 
      } catch (Exception exception) {
        Log.e("LoadTask", "Unexpected exception loading stream", exception);
        if (!this.h) {
          obtainMessage(3, new x.d(exception)).sendToTarget();
          return;
        } 
      } catch (OutOfMemoryError outOfMemoryError) {
        Log.e("LoadTask", "OutOfMemory error loading stream", outOfMemoryError);
        if (!this.h) {
          obtainMessage(3, new x.d(outOfMemoryError)).sendToTarget();
          return;
        } 
      } catch (Error error) {
        Log.e("LoadTask", "Unexpected error loading stream", error);
        if (!this.h)
          obtainMessage(4, error).sendToTarget(); 
        throw error;
      } 
    }
  }
  
  public static interface c {
    boolean a();
    
    void b();
    
    void load() throws IOException, InterruptedException;
  }
  
  public static final class d extends IOException {
    public d(Throwable param1Throwable) {
      super(stringBuilder.toString(), param1Throwable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer\\upstream\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */