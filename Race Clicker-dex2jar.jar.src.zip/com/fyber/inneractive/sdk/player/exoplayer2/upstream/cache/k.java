package com.fyber.inneractive.sdk.player.exoplayer2.upstream.cache;

import android.os.ConditionVariable;
import com.fyber.inneractive.sdk.player.exoplayer2.util.b;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public final class k implements a {
  public final File a;
  
  public final f b;
  
  public final HashMap<String, g> c;
  
  public final i d;
  
  public final HashMap<String, ArrayList<a.b>> e;
  
  public long f = 0L;
  
  public a.a g;
  
  public k(File paramFile, f paramf, byte[] paramArrayOfbyte) {
    this.a = paramFile;
    this.b = paramf;
    this.c = new HashMap<String, g>();
    this.d = new i(paramFile, null);
    this.e = new HashMap<String, ArrayList<a.b>>();
    ConditionVariable conditionVariable = new ConditionVariable();
    (new a(this, "SimpleCache.initialize()", conditionVariable)).start();
    conditionVariable.block();
  }
  
  public static void a(k paramk) throws a.a {
    if (!paramk.a.exists()) {
      paramk.a.mkdirs();
      return;
    } 
    i i1 = paramk.d;
    com.fyber.inneractive.sdk.player.exoplayer2.util.a.b(i1.f ^ true);
    if (!i1.a()) {
      b b = i1.c;
      b.a.delete();
      b.b.delete();
      i1.a.clear();
      i1.b.clear();
    } 
    File[] arrayOfFile = paramk.a.listFiles();
    if (arrayOfFile == null)
      return; 
    int m = arrayOfFile.length;
    for (int j = 0; j < m; j++) {
      File file = arrayOfFile[j];
      if (!file.getName().equals("cached_content_index.exi")) {
        if (file.length() > 0L) {
          l l = l.a(file, paramk.d);
        } else {
          i1 = null;
        } 
        if (i1 != null) {
          paramk.a((l)i1);
        } else {
          file.delete();
        } 
      } 
    } 
    paramk.d.b();
    paramk.d.c();
  }
  
  public long a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : J
    //   6: lstore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: lload_1
    //   10: lreturn
    //   11: astore_3
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_3
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public long a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   6: getfield a : Ljava/util/HashMap;
    //   9: aload_1
    //   10: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   16: astore_1
    //   17: aload_1
    //   18: ifnonnull -> 28
    //   21: ldc2_w -1
    //   24: lstore_2
    //   25: goto -> 33
    //   28: aload_1
    //   29: getfield d : J
    //   32: lstore_2
    //   33: aload_0
    //   34: monitorexit
    //   35: lload_2
    //   36: lreturn
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	37	finally
    //   28	33	37	finally
  }
  
  public File a(String paramString, long paramLong1, long paramLong2) throws a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/HashMap;
    //   6: aload_1
    //   7: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   10: invokestatic b : (Z)V
    //   13: aload_0
    //   14: getfield a : Ljava/io/File;
    //   17: invokevirtual exists : ()Z
    //   20: ifne -> 35
    //   23: aload_0
    //   24: invokevirtual b : ()V
    //   27: aload_0
    //   28: getfield a : Ljava/io/File;
    //   31: invokevirtual mkdirs : ()Z
    //   34: pop
    //   35: aload_0
    //   36: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/f;
    //   39: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/j
    //   42: aload_0
    //   43: lload #4
    //   45: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a;J)V
    //   48: aload_0
    //   49: getfield a : Ljava/io/File;
    //   52: astore #8
    //   54: aload_0
    //   55: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   58: astore #9
    //   60: aload #9
    //   62: getfield a : Ljava/util/HashMap;
    //   65: aload_1
    //   66: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   69: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   72: astore #7
    //   74: aload #7
    //   76: astore #6
    //   78: aload #7
    //   80: ifnonnull -> 94
    //   83: aload #9
    //   85: aload_1
    //   86: ldc2_w -1
    //   89: invokevirtual a : (Ljava/lang/String;J)Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h;
    //   92: astore #6
    //   94: aload #8
    //   96: aload #6
    //   98: getfield a : I
    //   101: lload_2
    //   102: invokestatic currentTimeMillis : ()J
    //   105: invokestatic a : (Ljava/io/File;IJJ)Ljava/io/File;
    //   108: astore_1
    //   109: aload_0
    //   110: monitorexit
    //   111: aload_1
    //   112: areturn
    //   113: astore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	113	finally
    //   35	74	113	finally
    //   83	94	113	finally
    //   94	109	113	finally
  }
  
  public void a(g paramg) throws a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iconst_1
    //   5: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/g;Z)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  public final void a(g paramg, boolean paramBoolean) throws a.a {
    h h = this.d.a(paramg.a);
    if (h != null) {
      int j;
      if (h.c.remove(paramg)) {
        paramg.e.delete();
        j = 1;
      } else {
        j = 0;
      } 
      if (!j)
        return; 
      this.f -= paramg.c;
      if (paramBoolean && h.c.isEmpty()) {
        this.d.b(h.b);
        this.d.c();
      } 
      ArrayList<a.b> arrayList = this.e.get(paramg.a);
      if (arrayList != null)
        for (j = arrayList.size() - 1; j >= 0; j--)
          ((a.b)arrayList.get(j)).a(this, paramg);  
      j j1 = (j)this.b;
      j1.a.remove(paramg);
      j1.b -= paramg.c;
    } 
  }
  
  public final void a(l paraml) {
    i i1 = this.d;
    String str = ((g)paraml).a;
    h h2 = (h)i1.a.get(str);
    h h1 = h2;
    if (h2 == null)
      h1 = i1.a(str, -1L); 
    h1.c.add(paraml);
    this.f += ((g)paraml).c;
    ArrayList<a.b> arrayList = this.e.get(((g)paraml).a);
    if (arrayList != null)
      for (int j = arrayList.size() - 1; j >= 0; j--)
        ((a.b)arrayList.get(j)).b(this, (g)paraml);  
    ((j)this.b).b(this, (g)paraml);
  }
  
  public void a(File paramFile) throws a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: aload_0
    //   4: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   7: invokestatic a : (Ljava/io/File;Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;)Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l;
    //   10: astore #6
    //   12: iconst_1
    //   13: istore_3
    //   14: aload #6
    //   16: ifnull -> 190
    //   19: iconst_1
    //   20: istore_2
    //   21: goto -> 24
    //   24: iload_2
    //   25: invokestatic b : (Z)V
    //   28: aload_0
    //   29: getfield c : Ljava/util/HashMap;
    //   32: aload #6
    //   34: getfield a : Ljava/lang/String;
    //   37: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   40: invokestatic b : (Z)V
    //   43: aload_1
    //   44: invokevirtual exists : ()Z
    //   47: istore_2
    //   48: iload_2
    //   49: ifne -> 55
    //   52: aload_0
    //   53: monitorexit
    //   54: return
    //   55: aload_1
    //   56: invokevirtual length : ()J
    //   59: lconst_0
    //   60: lcmp
    //   61: ifne -> 72
    //   64: aload_1
    //   65: invokevirtual delete : ()Z
    //   68: pop
    //   69: aload_0
    //   70: monitorexit
    //   71: return
    //   72: aload #6
    //   74: getfield a : Ljava/lang/String;
    //   77: astore_1
    //   78: aload_0
    //   79: monitorenter
    //   80: aload_0
    //   81: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   84: getfield a : Ljava/util/HashMap;
    //   87: aload_1
    //   88: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   91: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   94: astore_1
    //   95: aload_1
    //   96: ifnonnull -> 107
    //   99: ldc2_w -1
    //   102: lstore #4
    //   104: goto -> 113
    //   107: aload_1
    //   108: getfield d : J
    //   111: lstore #4
    //   113: aload_0
    //   114: monitorexit
    //   115: lload #4
    //   117: invokestatic valueOf : (J)Ljava/lang/Long;
    //   120: astore_1
    //   121: aload_1
    //   122: invokevirtual longValue : ()J
    //   125: ldc2_w -1
    //   128: lcmp
    //   129: ifeq -> 160
    //   132: aload #6
    //   134: getfield b : J
    //   137: aload #6
    //   139: getfield c : J
    //   142: ladd
    //   143: aload_1
    //   144: invokevirtual longValue : ()J
    //   147: lcmp
    //   148: ifgt -> 195
    //   151: iload_3
    //   152: istore_2
    //   153: goto -> 156
    //   156: iload_2
    //   157: invokestatic b : (Z)V
    //   160: aload_0
    //   161: aload #6
    //   163: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l;)V
    //   166: aload_0
    //   167: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   170: invokevirtual c : ()V
    //   173: aload_0
    //   174: invokevirtual notifyAll : ()V
    //   177: aload_0
    //   178: monitorexit
    //   179: return
    //   180: astore_1
    //   181: aload_0
    //   182: monitorexit
    //   183: aload_1
    //   184: athrow
    //   185: astore_1
    //   186: aload_0
    //   187: monitorexit
    //   188: aload_1
    //   189: athrow
    //   190: iconst_0
    //   191: istore_2
    //   192: goto -> 24
    //   195: iconst_0
    //   196: istore_2
    //   197: goto -> 156
    // Exception table:
    //   from	to	target	type
    //   2	12	185	finally
    //   24	48	185	finally
    //   55	69	185	finally
    //   72	80	185	finally
    //   80	95	180	finally
    //   107	113	180	finally
    //   113	151	185	finally
    //   156	160	185	finally
    //   160	177	185	finally
    //   181	185	185	finally
  }
  
  public void a(String paramString, long paramLong) throws a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   6: astore #4
    //   8: aload #4
    //   10: getfield a : Ljava/util/HashMap;
    //   13: aload_1
    //   14: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   20: astore #5
    //   22: aload #5
    //   24: ifnull -> 52
    //   27: aload #5
    //   29: getfield d : J
    //   32: lload_2
    //   33: lcmp
    //   34: ifeq -> 60
    //   37: aload #5
    //   39: lload_2
    //   40: putfield d : J
    //   43: aload #4
    //   45: iconst_1
    //   46: putfield f : Z
    //   49: goto -> 60
    //   52: aload #4
    //   54: aload_1
    //   55: lload_2
    //   56: invokevirtual a : (Ljava/lang/String;J)Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h;
    //   59: pop
    //   60: aload_0
    //   61: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   64: invokevirtual c : ()V
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	70	finally
    //   27	49	70	finally
    //   52	60	70	finally
    //   60	67	70	finally
  }
  
  public g b(String paramString, long paramLong) throws InterruptedException, a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: lload_2
    //   5: invokevirtual d : (Ljava/lang/String;J)Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload_0
    //   16: monitorexit
    //   17: aload #4
    //   19: areturn
    //   20: aload_0
    //   21: invokevirtual wait : ()V
    //   24: goto -> 2
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	27	finally
    //   20	24	27	finally
  }
  
  public final void b() throws a.a {
    LinkedList<g> linkedList = new LinkedList();
    Iterator iterator1 = this.d.a.values().iterator();
    while (iterator1.hasNext()) {
      for (g g : ((h)iterator1.next()).c) {
        if (g.e.length() != g.c)
          linkedList.add(g); 
      } 
    } 
    Iterator<g> iterator = linkedList.iterator();
    while (iterator.hasNext())
      a(iterator.next(), false); 
    this.d.b();
    this.d.c();
  }
  
  public void b(g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: aload_0
    //   4: getfield c : Ljava/util/HashMap;
    //   7: aload_1
    //   8: getfield a : Ljava/lang/String;
    //   11: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: if_acmpne -> 38
    //   17: iconst_1
    //   18: istore_2
    //   19: goto -> 22
    //   22: iload_2
    //   23: invokestatic b : (Z)V
    //   26: aload_0
    //   27: invokevirtual notifyAll : ()V
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    //   38: iconst_0
    //   39: istore_2
    //   40: goto -> 22
    // Exception table:
    //   from	to	target	type
    //   2	17	33	finally
    //   22	30	33	finally
  }
  
  public l d(String paramString, long paramLong) throws a.a {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield g : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a$a;
    //   6: astore #5
    //   8: aload #5
    //   10: ifnonnull -> 548
    //   13: aload_0
    //   14: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   17: getfield a : Ljava/util/HashMap;
    //   20: aload_1
    //   21: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   24: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   27: astore #6
    //   29: aload #6
    //   31: ifnonnull -> 55
    //   34: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   37: dup
    //   38: aload_1
    //   39: lload_2
    //   40: ldc2_w -1
    //   43: ldc2_w -9223372036854775807
    //   46: aconst_null
    //   47: invokespecial <init> : (Ljava/lang/String;JJJLjava/io/File;)V
    //   50: astore #5
    //   52: goto -> 219
    //   55: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   58: dup
    //   59: aload #6
    //   61: getfield b : Ljava/lang/String;
    //   64: lload_2
    //   65: ldc2_w -1
    //   68: ldc2_w -9223372036854775807
    //   71: aconst_null
    //   72: invokespecial <init> : (Ljava/lang/String;JJJLjava/io/File;)V
    //   75: astore #7
    //   77: aload #6
    //   79: getfield c : Ljava/util/TreeSet;
    //   82: aload #7
    //   84: invokevirtual floor : (Ljava/lang/Object;)Ljava/lang/Object;
    //   87: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   90: astore #5
    //   92: aload #5
    //   94: ifnull -> 116
    //   97: aload #5
    //   99: getfield b : J
    //   102: aload #5
    //   104: getfield c : J
    //   107: ladd
    //   108: lload_2
    //   109: lcmp
    //   110: ifle -> 116
    //   113: goto -> 187
    //   116: aload #6
    //   118: getfield c : Ljava/util/TreeSet;
    //   121: aload #7
    //   123: invokevirtual ceiling : (Ljava/lang/Object;)Ljava/lang/Object;
    //   126: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   129: astore #5
    //   131: aload #5
    //   133: ifnonnull -> 161
    //   136: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   139: dup
    //   140: aload #6
    //   142: getfield b : Ljava/lang/String;
    //   145: lload_2
    //   146: ldc2_w -1
    //   149: ldc2_w -9223372036854775807
    //   152: aconst_null
    //   153: invokespecial <init> : (Ljava/lang/String;JJJLjava/io/File;)V
    //   156: astore #5
    //   158: goto -> 187
    //   161: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   164: dup
    //   165: aload #6
    //   167: getfield b : Ljava/lang/String;
    //   170: lload_2
    //   171: aload #5
    //   173: getfield b : J
    //   176: lload_2
    //   177: lsub
    //   178: ldc2_w -9223372036854775807
    //   181: aconst_null
    //   182: invokespecial <init> : (Ljava/lang/String;JJJLjava/io/File;)V
    //   185: astore #5
    //   187: aload #5
    //   189: getfield d : Z
    //   192: ifeq -> 556
    //   195: aload #5
    //   197: getfield e : Ljava/io/File;
    //   200: invokevirtual length : ()J
    //   203: aload #5
    //   205: getfield c : J
    //   208: lcmp
    //   209: ifeq -> 556
    //   212: aload_0
    //   213: invokevirtual b : ()V
    //   216: goto -> 55
    //   219: aload #5
    //   221: getfield d : Z
    //   224: ifeq -> 517
    //   227: aload_0
    //   228: getfield d : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/i;
    //   231: getfield a : Ljava/util/HashMap;
    //   234: aload_1
    //   235: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   238: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/h
    //   241: astore #7
    //   243: aload #7
    //   245: getfield c : Ljava/util/TreeSet;
    //   248: aload #5
    //   250: invokevirtual remove : (Ljava/lang/Object;)Z
    //   253: invokestatic b : (Z)V
    //   256: aload #7
    //   258: getfield a : I
    //   261: istore #4
    //   263: aload #5
    //   265: getfield d : Z
    //   268: invokestatic b : (Z)V
    //   271: invokestatic currentTimeMillis : ()J
    //   274: lstore_2
    //   275: aload #5
    //   277: getfield e : Ljava/io/File;
    //   280: invokevirtual getParentFile : ()Ljava/io/File;
    //   283: iload #4
    //   285: aload #5
    //   287: getfield b : J
    //   290: lload_2
    //   291: invokestatic a : (Ljava/io/File;IJJ)Ljava/io/File;
    //   294: astore #6
    //   296: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/l
    //   299: dup
    //   300: aload #5
    //   302: getfield a : Ljava/lang/String;
    //   305: aload #5
    //   307: getfield b : J
    //   310: aload #5
    //   312: getfield c : J
    //   315: lload_2
    //   316: aload #6
    //   318: invokespecial <init> : (Ljava/lang/String;JJJLjava/io/File;)V
    //   321: astore_1
    //   322: aload #5
    //   324: getfield e : Ljava/io/File;
    //   327: aload #6
    //   329: invokevirtual renameTo : (Ljava/io/File;)Z
    //   332: ifeq -> 456
    //   335: aload #7
    //   337: getfield c : Ljava/util/TreeSet;
    //   340: aload_1
    //   341: invokevirtual add : (Ljava/lang/Object;)Z
    //   344: pop
    //   345: aload_0
    //   346: getfield e : Ljava/util/HashMap;
    //   349: aload #5
    //   351: getfield a : Ljava/lang/String;
    //   354: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   357: checkcast java/util/ArrayList
    //   360: astore #6
    //   362: aload #6
    //   364: ifnull -> 409
    //   367: aload #6
    //   369: invokevirtual size : ()I
    //   372: iconst_1
    //   373: isub
    //   374: istore #4
    //   376: iload #4
    //   378: iflt -> 409
    //   381: aload #6
    //   383: iload #4
    //   385: invokevirtual get : (I)Ljava/lang/Object;
    //   388: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a$b
    //   391: aload_0
    //   392: aload #5
    //   394: aload_1
    //   395: invokeinterface a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a;Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/g;Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/g;)V
    //   400: iload #4
    //   402: iconst_1
    //   403: isub
    //   404: istore #4
    //   406: goto -> 376
    //   409: aload_0
    //   410: getfield b : Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/f;
    //   413: checkcast com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/j
    //   416: astore #6
    //   418: aload #6
    //   420: getfield a : Ljava/util/TreeSet;
    //   423: aload #5
    //   425: invokevirtual remove : (Ljava/lang/Object;)Z
    //   428: pop
    //   429: aload #6
    //   431: aload #6
    //   433: getfield b : J
    //   436: aload #5
    //   438: getfield c : J
    //   441: lsub
    //   442: putfield b : J
    //   445: aload #6
    //   447: aload_0
    //   448: aload_1
    //   449: invokevirtual b : (Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a;Lcom/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/g;)V
    //   452: aload_0
    //   453: monitorexit
    //   454: aload_1
    //   455: areturn
    //   456: new java/lang/StringBuilder
    //   459: dup
    //   460: invokespecial <init> : ()V
    //   463: astore_1
    //   464: aload_1
    //   465: ldc_w 'Renaming of '
    //   468: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   471: pop
    //   472: aload_1
    //   473: aload #5
    //   475: getfield e : Ljava/io/File;
    //   478: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   481: pop
    //   482: aload_1
    //   483: ldc_w ' to '
    //   486: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   489: pop
    //   490: aload_1
    //   491: aload #6
    //   493: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   496: pop
    //   497: aload_1
    //   498: ldc_w ' failed.'
    //   501: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   504: pop
    //   505: new com/fyber/inneractive/sdk/player/exoplayer2/upstream/cache/a$a
    //   508: dup
    //   509: aload_1
    //   510: invokevirtual toString : ()Ljava/lang/String;
    //   513: invokespecial <init> : (Ljava/lang/String;)V
    //   516: athrow
    //   517: aload_0
    //   518: getfield c : Ljava/util/HashMap;
    //   521: aload_1
    //   522: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   525: ifne -> 544
    //   528: aload_0
    //   529: getfield c : Ljava/util/HashMap;
    //   532: aload_1
    //   533: aload #5
    //   535: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   538: pop
    //   539: aload_0
    //   540: monitorexit
    //   541: aload #5
    //   543: areturn
    //   544: aload_0
    //   545: monitorexit
    //   546: aconst_null
    //   547: areturn
    //   548: aload #5
    //   550: athrow
    //   551: astore_1
    //   552: aload_0
    //   553: monitorexit
    //   554: aload_1
    //   555: athrow
    //   556: goto -> 219
    // Exception table:
    //   from	to	target	type
    //   2	8	551	finally
    //   13	29	551	finally
    //   34	52	551	finally
    //   55	92	551	finally
    //   97	113	551	finally
    //   116	131	551	finally
    //   136	158	551	finally
    //   161	187	551	finally
    //   187	216	551	finally
    //   219	362	551	finally
    //   367	376	551	finally
    //   381	400	551	finally
    //   409	452	551	finally
    //   456	517	551	finally
    //   517	539	551	finally
    //   548	551	551	finally
  }
  
  public class a extends Thread {
    public a(k this$0, String param1String, ConditionVariable param1ConditionVariable) {
      super(param1String);
    }
    
    public void run() {
      synchronized (this.b) {
        this.a.open();
        try {
          k.a(this.b);
        } catch (a a1) {
          this.b.g = a1;
        } 
        this.b.b.getClass();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer\\upstream\cache\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */