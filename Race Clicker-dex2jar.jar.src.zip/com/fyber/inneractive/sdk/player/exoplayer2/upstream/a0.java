package com.fyber.inneractive.sdk.player.exoplayer2.upstream;

public interface a0<S> {}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer\\upstream\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */