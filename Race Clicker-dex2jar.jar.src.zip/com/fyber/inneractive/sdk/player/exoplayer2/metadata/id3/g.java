package com.fyber.inneractive.sdk.player.exoplayer2.metadata.id3;

import android.util.Log;
import com.fyber.inneractive.sdk.player.exoplayer2.util.k;
import com.fyber.inneractive.sdk.player.exoplayer2.util.u;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public final class g {
  public static final int b = u.a("ID3");
  
  public final a a;
  
  public g() {
    this(null);
  }
  
  public g(a parama) {
    this.a = parama;
  }
  
  public static int a(int paramInt) {
    return (paramInt == 0 || paramInt == 3) ? 1 : 2;
  }
  
  public static int a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    int i = b(paramArrayOfbyte, paramInt1);
    if (paramInt2 != 0) {
      paramInt1 = i;
      if (paramInt2 == 3)
        return i; 
      while (paramInt1 < paramArrayOfbyte.length - 1) {
        if (paramInt1 % 2 == 0 && paramArrayOfbyte[paramInt1 + 1] == 0)
          return paramInt1; 
        paramInt1 = b(paramArrayOfbyte, paramInt1 + 1);
      } 
      return paramArrayOfbyte.length;
    } 
    return i;
  }
  
  public static a a(k paramk, int paramInt1, int paramInt2) throws UnsupportedEncodingException {
    String str1;
    int i = paramk.l();
    String str2 = b(i);
    int j = paramInt1 - 1;
    byte[] arrayOfByte = new byte[j];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, j);
    paramk.b += j;
    if (paramInt2 == 2) {
      StringBuilder stringBuilder = new StringBuilder("image/");
      stringBuilder.append((new String(arrayOfByte, 0, 3, "ISO-8859-1")).toLowerCase(Locale.US));
      String str = stringBuilder.toString();
      str1 = str;
      if (str.equals("image/jpg"))
        str1 = "image/jpeg"; 
      paramInt1 = 2;
    } else {
      paramInt1 = b(arrayOfByte, 0);
      str1 = (new String(arrayOfByte, 0, paramInt1, "ISO-8859-1")).toLowerCase(Locale.US);
      if (str1.indexOf('/') == -1) {
        StringBuilder stringBuilder = new StringBuilder("image/");
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } 
    } 
    paramInt2 = arrayOfByte[paramInt1 + 1];
    paramInt1 += 2;
    int m = a(arrayOfByte, paramInt1, i);
    return new a(str1, new String(arrayOfByte, paramInt1, m - paramInt1, str2), paramInt2 & 0xFF, Arrays.copyOfRange(arrayOfByte, m + a(i), j));
  }
  
  public static b a(k paramk, int paramInt, String paramString) {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new b(paramString, arrayOfByte);
  }
  
  public static c a(k paramk, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, a parama) throws UnsupportedEncodingException {
    int i = paramk.b;
    int j = b(paramk.a, i);
    String str = new String(paramk.a, i, j - i, "ISO-8859-1");
    paramk.e(j + 1);
    j = paramk.c();
    int m = paramk.c();
    long l1 = paramk.m();
    if (l1 == 4294967295L)
      l1 = -1L; 
    long l2 = paramk.m();
    if (l2 == 4294967295L)
      l2 = -1L; 
    ArrayList<h> arrayList = new ArrayList();
    while (paramk.b < i + paramInt1) {
      h h = a(paramInt2, paramk, paramBoolean, paramInt3, parama);
      if (h != null)
        arrayList.add(h); 
    } 
    h[] arrayOfH = new h[arrayList.size()];
    arrayList.toArray(arrayOfH);
    return new c(str, j, m, l1, l2, arrayOfH);
  }
  
  public static e a(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 4)
      return null; 
    int i = paramk.l();
    String str4 = b(i);
    byte[] arrayOfByte1 = new byte[3];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte1, 0, 3);
    paramk.b += 3;
    String str2 = new String(arrayOfByte1, 0, 3);
    paramInt -= 4;
    byte[] arrayOfByte2 = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte2, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte2, 0, i);
    String str3 = new String(arrayOfByte2, 0, j, str4);
    j += a(i);
    if (j < paramInt) {
      str1 = new String(arrayOfByte2, j, a(arrayOfByte2, j, i) - j, str4);
    } else {
      str1 = "";
    } 
    return new e(str2, str3, str1);
  }
  
  public static h a(int paramInt1, k paramk, boolean paramBoolean, int paramInt2, a parama) {
    b b;
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    int n = paramk.l();
    int i1 = paramk.l();
    int i2 = paramk.l();
    if (paramInt1 >= 3) {
      bool4 = paramk.l();
    } else {
      bool4 = false;
    } 
    if (paramInt1 == 4) {
      j = paramk.o();
      i = j;
      if (!paramBoolean)
        i = (j >> 24 & 0xFF) << 21 | j & 0xFF | (j >> 8 & 0xFF) << 7 | (j >> 16 & 0xFF) << 14; 
    } else if (paramInt1 == 3) {
      i = paramk.o();
    } else {
      i = paramk.n();
    } 
    if (paramInt1 >= 3) {
      bool3 = paramk.q();
    } else {
      bool3 = false;
    } 
    if (n == 0 && i1 == 0 && i2 == 0 && !bool4 && i == 0 && !bool3) {
      paramk.e(paramk.c);
      return null;
    } 
    int i3 = paramk.b + i;
    if (i3 > paramk.c) {
      Log.w("Id3Decoder", "Frame size exceeds remaining tag data");
      paramk.e(paramk.c);
      return null;
    } 
    if (parama != null) {
      if (n == 67 && i1 == 79 && i2 == 77 && (bool4 == 77 || paramInt1 == 2)) {
        j = 1;
      } else {
        j = 0;
      } 
      if (!j) {
        paramk.e(i3);
        return null;
      } 
    } 
    if (paramInt1 == 3) {
      if ((bool3 & 0x80) != 0) {
        j = 1;
      } else {
        j = 0;
      } 
      if ((bool3 & 0x40) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool3 & 0x20) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      m = bool1;
      boolean bool = false;
      bool1 = bool2;
      bool3 = j;
      bool2 = bool;
    } else if (paramInt1 == 4) {
      boolean bool;
      if ((bool3 & 0x40) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool3 & 0x8) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if ((bool3 & 0x4) != 0) {
        m = 1;
      } else {
        m = 0;
      } 
      if ((bool3 & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool3 & true) != 0) {
        j = 1;
        bool3 = bool2;
        bool2 = bool;
      } else {
        j = 0;
        bool3 = bool2;
        bool2 = bool;
      } 
    } else {
      bool1 = false;
      j = 0;
      bool3 = false;
      m = 0;
      bool2 = false;
    } 
    if (bool3 || m) {
      Log.w("Id3Decoder", "Skipping unsupported compressed or encrypted frame");
      paramk.e(i3);
      return null;
    } 
    int m = i;
    if (bool1) {
      m = i - 1;
      paramk.f(1);
    } 
    int i = m;
    if (j) {
      i = m - 4;
      paramk.f(4);
    } 
    int j = i;
    if (bool2)
      j = f(paramk, i); 
    if (n == 84 && i1 == 88 && i2 == 88 && (paramInt1 == 2 || bool4 == 88)) {
      try {
        j j1 = d(paramk, j);
        if (j1 == null) {
          StringBuilder stringBuilder = new StringBuilder("Failed to decode frame: id=");
          stringBuilder.append(a(paramInt1, n, i1, i2, bool4));
          stringBuilder.append(", frameSize=");
          stringBuilder.append(j);
          Log.w("Id3Decoder", stringBuilder.toString());
        } 
        paramk.e(i3);
        return (h)j1;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        Log.w("Id3Decoder", "Unsupported character encoding");
        paramk.e(i3);
      } finally {}
      return null;
    } 
    if (n == 84) {
      j j1 = b(paramk, j, a(paramInt1, n, i1, i2, bool4));
    } else if (n == 87 && i1 == 88 && i2 == 88 && (paramInt1 == 2 || bool4 == 88)) {
      k k1 = e(paramk, j);
    } else if (n == 87) {
      k k1 = c(paramk, j, a(paramInt1, n, i1, i2, bool4));
    } else if (n == 80 && i1 == 82 && i2 == 73 && bool4 == 86) {
      i i4 = c(paramk, j);
    } else if (n == 71 && i1 == 69 && i2 == 79 && (bool4 == 66 || paramInt1 == 2)) {
      f f = b(paramk, j);
    } else if ((paramInt1 == 2) ? (n == 80 && i1 == 73 && i2 == 67) : (n == 65 && i1 == 80 && i2 == 73 && bool4 == 67)) {
      a a1 = a(paramk, j, paramInt1);
    } else {
      e e;
      if (n == 67 && i1 == 79 && i2 == 77 && (bool4 == 77 || paramInt1 == 2)) {
        e = a(paramk, j);
      } else {
        c c;
        if (n == 67 && i1 == 72 && i2 == 65 && bool4 == 80) {
          c = a(paramk, j, paramInt1, paramBoolean, paramInt2, (a)e);
        } else if (n == 67 && i1 == 84 && i2 == 79 && bool4 == 67) {
          d d = b(paramk, j, paramInt1, paramBoolean, paramInt2, (a)c);
        } else {
          b = a(paramk, j, a(paramInt1, n, i1, i2, bool4));
        } 
      } 
    } 
    if (b == null) {
      StringBuilder stringBuilder = new StringBuilder("Failed to decode frame: id=");
      stringBuilder.append(a(paramInt1, n, i1, i2, bool4));
      stringBuilder.append(", frameSize=");
      stringBuilder.append(j);
      Log.w("Id3Decoder", stringBuilder.toString());
    } 
    paramk.e(i3);
    return (h)b;
  }
  
  public static String a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    return (paramInt1 == 2) ? String.format(Locale.US, "%c%c%c", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) }) : String.format(Locale.US, "%c%c%c%c", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), Integer.valueOf(paramInt5) });
  }
  
  public static boolean a(k paramk, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : I
    //   4: istore #8
    //   6: aload_0
    //   7: invokevirtual a : ()I
    //   10: istore #4
    //   12: iconst_1
    //   13: istore #7
    //   15: iload #4
    //   17: iload_2
    //   18: if_icmplt -> 340
    //   21: iload_1
    //   22: iconst_3
    //   23: if_icmplt -> 47
    //   26: aload_0
    //   27: invokevirtual c : ()I
    //   30: istore #4
    //   32: aload_0
    //   33: invokevirtual m : ()J
    //   36: lstore #9
    //   38: aload_0
    //   39: invokevirtual q : ()I
    //   42: istore #6
    //   44: goto -> 67
    //   47: aload_0
    //   48: invokevirtual n : ()I
    //   51: istore #4
    //   53: aload_0
    //   54: invokevirtual n : ()I
    //   57: istore #5
    //   59: iload #5
    //   61: i2l
    //   62: lstore #9
    //   64: iconst_0
    //   65: istore #6
    //   67: iload #4
    //   69: ifne -> 92
    //   72: lload #9
    //   74: lconst_0
    //   75: lcmp
    //   76: ifne -> 92
    //   79: iload #6
    //   81: ifne -> 92
    //   84: aload_0
    //   85: iload #8
    //   87: invokevirtual e : (I)V
    //   90: iconst_1
    //   91: ireturn
    //   92: lload #9
    //   94: lstore #11
    //   96: iload_1
    //   97: iconst_4
    //   98: if_icmpne -> 175
    //   101: lload #9
    //   103: lstore #11
    //   105: iload_3
    //   106: ifne -> 175
    //   109: ldc2_w 8421504
    //   112: lload #9
    //   114: land
    //   115: lconst_0
    //   116: lcmp
    //   117: ifeq -> 128
    //   120: aload_0
    //   121: iload #8
    //   123: invokevirtual e : (I)V
    //   126: iconst_0
    //   127: ireturn
    //   128: lload #9
    //   130: bipush #24
    //   132: lshr
    //   133: ldc2_w 255
    //   136: land
    //   137: bipush #21
    //   139: lshl
    //   140: lload #9
    //   142: ldc2_w 255
    //   145: land
    //   146: lload #9
    //   148: bipush #8
    //   150: lshr
    //   151: ldc2_w 255
    //   154: land
    //   155: bipush #7
    //   157: lshl
    //   158: lor
    //   159: lload #9
    //   161: bipush #16
    //   163: lshr
    //   164: ldc2_w 255
    //   167: land
    //   168: bipush #14
    //   170: lshl
    //   171: lor
    //   172: lor
    //   173: lstore #11
    //   175: iload_1
    //   176: iconst_4
    //   177: if_icmpne -> 219
    //   180: iload #6
    //   182: bipush #64
    //   184: iand
    //   185: ifeq -> 194
    //   188: iconst_1
    //   189: istore #5
    //   191: goto -> 197
    //   194: iconst_0
    //   195: istore #5
    //   197: iload #5
    //   199: istore #4
    //   201: iload #6
    //   203: iconst_1
    //   204: iand
    //   205: ifeq -> 268
    //   208: iload #5
    //   210: istore #4
    //   212: iload #7
    //   214: istore #5
    //   216: goto -> 271
    //   219: iload_1
    //   220: iconst_3
    //   221: if_icmpne -> 265
    //   224: iload #6
    //   226: bipush #32
    //   228: iand
    //   229: ifeq -> 238
    //   232: iconst_1
    //   233: istore #5
    //   235: goto -> 241
    //   238: iconst_0
    //   239: istore #5
    //   241: iload #5
    //   243: istore #4
    //   245: iload #6
    //   247: sipush #128
    //   250: iand
    //   251: ifeq -> 268
    //   254: iload #5
    //   256: istore #4
    //   258: iload #7
    //   260: istore #5
    //   262: goto -> 271
    //   265: iconst_0
    //   266: istore #4
    //   268: iconst_0
    //   269: istore #5
    //   271: iload #4
    //   273: istore #6
    //   275: iload #5
    //   277: ifeq -> 286
    //   280: iload #4
    //   282: iconst_4
    //   283: iadd
    //   284: istore #6
    //   286: lload #11
    //   288: iload #6
    //   290: i2l
    //   291: lcmp
    //   292: ifge -> 303
    //   295: aload_0
    //   296: iload #8
    //   298: invokevirtual e : (I)V
    //   301: iconst_0
    //   302: ireturn
    //   303: aload_0
    //   304: invokevirtual a : ()I
    //   307: istore #4
    //   309: iload #4
    //   311: i2l
    //   312: lload #11
    //   314: lcmp
    //   315: ifge -> 326
    //   318: aload_0
    //   319: iload #8
    //   321: invokevirtual e : (I)V
    //   324: iconst_0
    //   325: ireturn
    //   326: lload #11
    //   328: l2i
    //   329: istore #4
    //   331: aload_0
    //   332: iload #4
    //   334: invokevirtual f : (I)V
    //   337: goto -> 6
    //   340: aload_0
    //   341: iload #8
    //   343: invokevirtual e : (I)V
    //   346: iconst_1
    //   347: ireturn
    //   348: astore #13
    //   350: aload_0
    //   351: iload #8
    //   353: invokevirtual e : (I)V
    //   356: aload #13
    //   358: athrow
    // Exception table:
    //   from	to	target	type
    //   6	12	348	finally
    //   26	44	348	finally
    //   47	59	348	finally
    //   303	309	348	finally
    //   331	337	348	finally
  }
  
  public static int b(byte[] paramArrayOfbyte, int paramInt) {
    while (paramInt < paramArrayOfbyte.length) {
      if (paramArrayOfbyte[paramInt] == 0)
        return paramInt; 
      paramInt++;
    } 
    return paramArrayOfbyte.length;
  }
  
  public static d b(k paramk, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, a parama) throws UnsupportedEncodingException {
    boolean bool1;
    boolean bool2;
    int j = paramk.b;
    int i = b(paramk.a, j);
    String str = new String(paramk.a, j, i - j, "ISO-8859-1");
    paramk.e(i + 1);
    int m = paramk.l();
    i = 0;
    if ((m & 0x2) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((m & 0x1) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    m = paramk.l();
    String[] arrayOfString = new String[m];
    while (i < m) {
      int n = paramk.b;
      int i1 = b(paramk.a, n);
      arrayOfString[i] = new String(paramk.a, n, i1 - n, "ISO-8859-1");
      paramk.e(i1 + 1);
      i++;
    } 
    ArrayList<h> arrayList = new ArrayList();
    while (paramk.b < j + paramInt1) {
      h h = a(paramInt2, paramk, paramBoolean, paramInt3, parama);
      if (h != null)
        arrayList.add(h); 
    } 
    h[] arrayOfH = new h[arrayList.size()];
    arrayList.toArray(arrayOfH);
    return new d(str, bool1, bool2, arrayOfString, arrayOfH);
  }
  
  public static f b(k paramk, int paramInt) throws UnsupportedEncodingException {
    int i = paramk.l();
    String str2 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = b(arrayOfByte, 0);
    String str1 = new String(arrayOfByte, 0, j, "ISO-8859-1");
    int m = a(arrayOfByte, ++j, i);
    String str3 = new String(arrayOfByte, j, m - j, str2);
    j = m + a(i);
    m = a(arrayOfByte, j, i);
    return new f(str1, str3, new String(arrayOfByte, j, m - j, str2), Arrays.copyOfRange(arrayOfByte, m + a(i), paramInt));
  }
  
  public static j b(k paramk, int paramInt, String paramString) throws UnsupportedEncodingException {
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new j(paramString, null, new String(arrayOfByte, 0, a(arrayOfByte, 0, i), str));
  }
  
  public static String b(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? "ISO-8859-1" : "UTF-8") : "UTF-16BE") : "UTF-16";
  }
  
  public static i c(k paramk, int paramInt) throws UnsupportedEncodingException {
    byte[] arrayOfByte1;
    byte[] arrayOfByte2 = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte2, 0, paramInt);
    paramk.b += paramInt;
    int i = b(arrayOfByte2, 0);
    String str = new String(arrayOfByte2, 0, i, "ISO-8859-1");
    if (++i < paramInt) {
      arrayOfByte1 = Arrays.copyOfRange(arrayOfByte2, i, paramInt);
    } else {
      arrayOfByte1 = new byte[0];
    } 
    return new i(str, arrayOfByte1);
  }
  
  public static k c(k paramk, int paramInt, String paramString) throws UnsupportedEncodingException {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new k(paramString, null, new String(arrayOfByte, 0, b(arrayOfByte, 0), "ISO-8859-1"));
  }
  
  public static j d(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str3 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte, 0, i);
    String str2 = new String(arrayOfByte, 0, j, str3);
    j += a(i);
    if (j < paramInt) {
      str1 = new String(arrayOfByte, j, a(arrayOfByte, j, i) - j, str3);
    } else {
      str1 = "";
    } 
    return new j("TXXX", str2, str1);
  }
  
  public static k e(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str2 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte, 0, i);
    str2 = new String(arrayOfByte, 0, j, str2);
    i = j + a(i);
    if (i < paramInt) {
      str1 = new String(arrayOfByte, i, b(arrayOfByte, i) - i, "ISO-8859-1");
    } else {
      str1 = "";
    } 
    return new k("WXXX", str2, str1);
  }
  
  public static int f(k paramk, int paramInt) {
    byte[] arrayOfByte = paramk.a;
    int i = paramk.b;
    while (true) {
      int j = i + 1;
      if (j < paramInt) {
        int m = paramInt;
        if ((arrayOfByte[i] & 0xFF) == 255) {
          m = paramInt;
          if (arrayOfByte[j] == 0) {
            System.arraycopy(arrayOfByte, i + 2, arrayOfByte, j, paramInt - i - 2);
            m = paramInt - 1;
          } 
        } 
        i = j;
        paramInt = m;
        continue;
      } 
      return paramInt;
    } 
  }
  
  public com.fyber.inneractive.sdk.player.exoplayer2.metadata.a a(byte[] paramArrayOfbyte, int paramInt) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #10
    //   9: new com/fyber/inneractive/sdk/player/exoplayer2/util/k
    //   12: dup
    //   13: aload_1
    //   14: iload_2
    //   15: invokespecial <init> : ([BI)V
    //   18: astore #11
    //   20: aload #11
    //   22: invokevirtual a : ()I
    //   25: istore_2
    //   26: iconst_0
    //   27: istore #9
    //   29: bipush #10
    //   31: istore #5
    //   33: iload_2
    //   34: bipush #10
    //   36: if_icmpge -> 53
    //   39: ldc 'Id3Decoder'
    //   41: ldc_w 'Data too short to be an ID3 tag'
    //   44: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   47: pop
    //   48: aconst_null
    //   49: astore_1
    //   50: goto -> 360
    //   53: aload #11
    //   55: invokevirtual n : ()I
    //   58: istore_2
    //   59: iload_2
    //   60: getstatic com/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g.b : I
    //   63: if_icmpeq -> 96
    //   66: new java/lang/StringBuilder
    //   69: dup
    //   70: ldc_w 'Unexpected first three bytes of ID3 tag header: '
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: astore_1
    //   77: aload_1
    //   78: iload_2
    //   79: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   82: pop
    //   83: ldc 'Id3Decoder'
    //   85: aload_1
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   92: pop
    //   93: goto -> 48
    //   96: aload #11
    //   98: invokevirtual l : ()I
    //   101: istore #6
    //   103: aload #11
    //   105: iconst_1
    //   106: invokevirtual f : (I)V
    //   109: aload #11
    //   111: invokevirtual l : ()I
    //   114: istore #7
    //   116: aload #11
    //   118: invokevirtual k : ()I
    //   121: istore #4
    //   123: iload #6
    //   125: iconst_2
    //   126: if_icmpne -> 163
    //   129: iload #7
    //   131: bipush #64
    //   133: iand
    //   134: ifeq -> 142
    //   137: iconst_1
    //   138: istore_3
    //   139: goto -> 144
    //   142: iconst_0
    //   143: istore_3
    //   144: iload #4
    //   146: istore_2
    //   147: iload_3
    //   148: ifeq -> 289
    //   151: ldc 'Id3Decoder'
    //   153: ldc_w 'Skipped ID3 tag with majorVersion=2 and undefined compression scheme'
    //   156: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   159: pop
    //   160: goto -> 48
    //   163: iload #6
    //   165: iconst_3
    //   166: if_icmpne -> 213
    //   169: iload #7
    //   171: bipush #64
    //   173: iand
    //   174: ifeq -> 182
    //   177: iconst_1
    //   178: istore_3
    //   179: goto -> 184
    //   182: iconst_0
    //   183: istore_3
    //   184: iload #4
    //   186: istore_2
    //   187: iload_3
    //   188: ifeq -> 289
    //   191: aload #11
    //   193: invokevirtual c : ()I
    //   196: istore_2
    //   197: aload #11
    //   199: iload_2
    //   200: invokevirtual f : (I)V
    //   203: iload #4
    //   205: iload_2
    //   206: iconst_4
    //   207: iadd
    //   208: isub
    //   209: istore_2
    //   210: goto -> 289
    //   213: iload #6
    //   215: iconst_4
    //   216: if_icmpne -> 329
    //   219: iload #7
    //   221: bipush #64
    //   223: iand
    //   224: ifeq -> 232
    //   227: iconst_1
    //   228: istore_2
    //   229: goto -> 234
    //   232: iconst_0
    //   233: istore_2
    //   234: iload #4
    //   236: istore_3
    //   237: iload_2
    //   238: ifeq -> 260
    //   241: aload #11
    //   243: invokevirtual k : ()I
    //   246: istore_2
    //   247: aload #11
    //   249: iload_2
    //   250: iconst_4
    //   251: isub
    //   252: invokevirtual f : (I)V
    //   255: iload #4
    //   257: iload_2
    //   258: isub
    //   259: istore_3
    //   260: iload #7
    //   262: bipush #16
    //   264: iand
    //   265: ifeq -> 274
    //   268: iconst_1
    //   269: istore #4
    //   271: goto -> 277
    //   274: iconst_0
    //   275: istore #4
    //   277: iload_3
    //   278: istore_2
    //   279: iload #4
    //   281: ifeq -> 289
    //   284: iload_3
    //   285: bipush #10
    //   287: isub
    //   288: istore_2
    //   289: iload #6
    //   291: iconst_4
    //   292: if_icmpge -> 310
    //   295: iload #7
    //   297: sipush #128
    //   300: iand
    //   301: ifeq -> 310
    //   304: iconst_1
    //   305: istore #8
    //   307: goto -> 313
    //   310: iconst_0
    //   311: istore #8
    //   313: new com/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$b
    //   316: dup
    //   317: iload #6
    //   319: iload #8
    //   321: iload_2
    //   322: invokespecial <init> : (IZI)V
    //   325: astore_1
    //   326: goto -> 360
    //   329: new java/lang/StringBuilder
    //   332: dup
    //   333: ldc_w 'Skipped ID3 tag with unsupported majorVersion='
    //   336: invokespecial <init> : (Ljava/lang/String;)V
    //   339: astore_1
    //   340: aload_1
    //   341: iload #6
    //   343: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: ldc 'Id3Decoder'
    //   349: aload_1
    //   350: invokevirtual toString : ()Ljava/lang/String;
    //   353: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   356: pop
    //   357: goto -> 48
    //   360: aload_1
    //   361: ifnonnull -> 366
    //   364: aconst_null
    //   365: areturn
    //   366: aload #11
    //   368: getfield b : I
    //   371: istore #6
    //   373: iload #5
    //   375: istore_2
    //   376: aload_1
    //   377: getfield a : I
    //   380: iconst_2
    //   381: if_icmpne -> 387
    //   384: bipush #6
    //   386: istore_2
    //   387: aload_1
    //   388: getfield c : I
    //   391: istore #4
    //   393: iload #4
    //   395: istore_3
    //   396: aload_1
    //   397: getfield b : Z
    //   400: ifeq -> 411
    //   403: aload #11
    //   405: iload #4
    //   407: invokestatic f : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;I)I
    //   410: istore_3
    //   411: aload #11
    //   413: iload #6
    //   415: iload_3
    //   416: iadd
    //   417: invokevirtual d : (I)V
    //   420: iload #9
    //   422: istore #8
    //   424: aload #11
    //   426: aload_1
    //   427: getfield a : I
    //   430: iload_2
    //   431: iconst_0
    //   432: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IIZ)Z
    //   435: ifne -> 498
    //   438: aload_1
    //   439: getfield a : I
    //   442: iconst_4
    //   443: if_icmpne -> 463
    //   446: aload #11
    //   448: iconst_4
    //   449: iload_2
    //   450: iconst_1
    //   451: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IIZ)Z
    //   454: ifeq -> 463
    //   457: iconst_1
    //   458: istore #8
    //   460: goto -> 498
    //   463: new java/lang/StringBuilder
    //   466: dup
    //   467: ldc_w 'Failed to validate ID3 tag with majorVersion='
    //   470: invokespecial <init> : (Ljava/lang/String;)V
    //   473: astore #10
    //   475: aload #10
    //   477: aload_1
    //   478: getfield a : I
    //   481: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   484: pop
    //   485: ldc 'Id3Decoder'
    //   487: aload #10
    //   489: invokevirtual toString : ()Ljava/lang/String;
    //   492: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   495: pop
    //   496: aconst_null
    //   497: areturn
    //   498: aload #11
    //   500: invokevirtual a : ()I
    //   503: iload_2
    //   504: if_icmplt -> 541
    //   507: aload_1
    //   508: getfield a : I
    //   511: aload #11
    //   513: iload #8
    //   515: iload_2
    //   516: aload_0
    //   517: getfield a : Lcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$a;
    //   520: invokestatic a : (ILcom/fyber/inneractive/sdk/player/exoplayer2/util/k;ZILcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$a;)Lcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/h;
    //   523: astore #12
    //   525: aload #12
    //   527: ifnull -> 498
    //   530: aload #10
    //   532: aload #12
    //   534: invokevirtual add : (Ljava/lang/Object;)Z
    //   537: pop
    //   538: goto -> 498
    //   541: new com/fyber/inneractive/sdk/player/exoplayer2/metadata/a
    //   544: dup
    //   545: aload #10
    //   547: invokespecial <init> : (Ljava/util/List;)V
    //   550: areturn
  }
  
  public static interface a {}
  
  public static final class b {
    public final int a;
    
    public final boolean b;
    
    public final int c;
    
    public b(int param1Int1, boolean param1Boolean, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Boolean;
      this.c = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\metadata\id3\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */