package com.fyber.inneractive.sdk.protobuf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public final class u<T extends u.b<T>> {
  public static final u d;
  
  public final g1<T, Object> a = g1.b(16);
  
  public boolean b;
  
  public boolean c;
  
  static {
    u u1 = new u(g1.b(0));
    u1.g();
    d = u1;
  }
  
  public u() {}
  
  public u(g1<T, Object> paramg1) {
    g();
  }
  
  public static int a(r1.b paramb, int paramInt, Object paramObject) {
    int i = l.b(paramInt);
    paramInt = i;
    if (paramb == r1.b.GROUP)
      paramInt = i * 2; 
    return paramInt + a(paramb, paramObject);
  }
  
  public static int a(r1.b paramb, Object paramObject) {
    Logger logger2;
    byte[] arrayOfByte;
    o0 o0;
    int i;
    int j;
    switch (a.b[paramb.ordinal()]) {
      default:
        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
      case 18:
        return (paramObject instanceof y.c) ? l.a(((y.c)paramObject).a()) : l.a(((Integer)paramObject).intValue());
      case 17:
        return l.a(l.b(((Long)paramObject).longValue()));
      case 16:
        return l.c(l.d(((Integer)paramObject).intValue()));
      case 15:
        ((Long)paramObject).longValue();
        logger2 = l.b;
        return 8;
      case 14:
        ((Integer)paramObject).intValue();
        logger2 = l.b;
        return 4;
      case 13:
        return l.c(((Integer)paramObject).intValue());
      case 12:
        if (paramObject instanceof i)
          return l.a((i)paramObject); 
        arrayOfByte = (byte[])paramObject;
        paramObject = l.b;
        i = arrayOfByte.length;
        j = l.c(i);
        return j + i;
      case 11:
        return (paramObject instanceof i) ? l.a((i)paramObject) : l.a((String)paramObject);
      case 10:
        if (paramObject instanceof a0)
          return l.a((b0)paramObject); 
        o0 = (o0)paramObject;
        paramObject = l.b;
        i = o0.getSerializedSize();
        j = l.c(i);
        return j + i;
      case 9:
        o0 = (o0)paramObject;
        paramObject = l.b;
        return o0.getSerializedSize();
      case 8:
        ((Boolean)paramObject).booleanValue();
        logger1 = l.b;
        return 1;
      case 7:
        ((Integer)paramObject).intValue();
        logger1 = l.b;
        return 4;
      case 6:
        ((Long)paramObject).longValue();
        logger1 = l.b;
        return 8;
      case 5:
        return l.a(((Integer)paramObject).intValue());
      case 4:
        return l.a(((Long)paramObject).longValue());
      case 3:
        return l.a(((Long)paramObject).longValue());
      case 2:
        ((Float)paramObject).floatValue();
        logger1 = l.b;
        return 4;
      case 1:
        break;
    } 
    ((Double)paramObject).doubleValue();
    Logger logger1 = l.b;
    return 8;
  }
  
  public static int a(r1.b paramb, boolean paramBoolean) {
    return paramBoolean ? 2 : paramb.f();
  }
  
  public static Object a(Object paramObject) {
    if (paramObject instanceof byte[]) {
      paramObject = paramObject;
      byte[] arrayOfByte = new byte[paramObject.length];
      System.arraycopy(paramObject, 0, arrayOfByte, 0, paramObject.length);
      return arrayOfByte;
    } 
    return paramObject;
  }
  
  public static int b(b<?> paramb, Object paramObject) {
    r1.b b1 = paramb.c();
    int i = paramb.a();
    if (paramb.b()) {
      boolean bool1 = paramb.isPacked();
      boolean bool = false;
      int j = 0;
      if (bool1) {
        Iterator iterator1 = ((List)paramObject).iterator();
        while (iterator1.hasNext())
          j += a(b1, iterator1.next()); 
        return l.b(i) + j + l.c(j);
      } 
      Iterator iterator = ((List)paramObject).iterator();
      for (j = bool; iterator.hasNext(); j += a(b1, i, iterator.next()));
      return j;
    } 
    return a(b1, i, paramObject);
  }
  
  public static <T extends b<T>> u<T> b() {
    return d;
  }
  
  public static <T extends b<T>> boolean b(Map.Entry<T, Object> paramEntry) {
    b b = (b)paramEntry.getKey();
    if (b.d() == r1.c.MESSAGE) {
      Iterator<o0> iterator;
      if (b.b()) {
        iterator = ((List)paramEntry.getValue()).iterator();
        while (iterator.hasNext()) {
          if (!((o0)iterator.next()).isInitialized())
            return false; 
        } 
      } else {
        iterator = iterator.getValue();
        if (iterator instanceof o0) {
          if (!((o0)iterator).isInitialized())
            return false; 
        } else {
          if (iterator instanceof a0)
            return true; 
          throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
        } 
      } 
    } 
    return true;
  }
  
  public final int a(Map.Entry<T, Object> paramEntry) {
    b<?> b = (b)paramEntry.getKey();
    Object object = paramEntry.getValue();
    if (b.d() == r1.c.MESSAGE && !b.b() && !b.isPacked()) {
      a0 a0;
      if (object instanceof a0) {
        int m = ((b)paramEntry.getKey()).a();
        a0 = (a0)object;
        m = l.b(1) * 2 + l.f(2, m);
        int n = l.b(3) + l.a((b0)a0);
        return m + n;
      } 
      int i = ((b)a0.getKey()).a();
      o0 o0 = (o0)object;
      i = l.b(1) * 2 + l.f(2, i);
      int j = l.b(3);
      int k = o0.getSerializedSize();
      j += l.c(k) + k;
      return i + j;
    } 
    return b(b, object);
  }
  
  public u<T> a() {
    u<b> u1 = new u();
    for (int i = 0; i < this.a.b.size(); i++) {
      Map.Entry entry = this.a.a(i);
      u1.c((b)entry.getKey(), entry.getValue());
    } 
    for (Map.Entry entry : this.a.b())
      u1.c((b)entry.getKey(), entry.getValue()); 
    u1.c = this.c;
    return (u)u1;
  }
  
  public Object a(T paramT) {
    o0 o0;
    Object object = this.a.get(paramT);
    paramT = (T)object;
    if (object instanceof a0)
      o0 = ((a0)object).a(null); 
    return o0;
  }
  
  public void a(T paramT, Object paramObject) {
    if (((GeneratedMessageLite.d)paramT).d) {
      List<Object> list;
      d(paramT, paramObject);
      Object object = a(paramT);
      if (object == null) {
        object = new ArrayList();
        this.a.a((Comparable)paramT, object);
        paramT = (T)object;
      } else {
        list = (List)object;
      } 
      list.add(paramObject);
      return;
    } 
    throw new IllegalArgumentException("addRepeatedField() can only be called on repeated fields.");
  }
  
  public void a(u<T> paramu) {
    for (int i = 0; i < paramu.a.b.size(); i++)
      c(paramu.a.a(i)); 
    Iterator<Map.Entry<T, Object>> iterator = paramu.a.b().iterator();
    while (iterator.hasNext())
      c(iterator.next()); 
  }
  
  public int c() {
    int j = 0;
    int i = 0;
    while (j < this.a.b.size()) {
      i += a(this.a.a(j));
      j++;
    } 
    Iterator<Map.Entry<T, Object>> iterator = this.a.b().iterator();
    while (iterator.hasNext())
      i += a(iterator.next()); 
    return i;
  }
  
  public void c(T paramT, Object paramObject) {
    if (paramT.b()) {
      if (paramObject instanceof List) {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll((List)paramObject);
        paramObject = arrayList.iterator();
        while (paramObject.hasNext())
          d(paramT, paramObject.next()); 
        paramObject = arrayList;
      } else {
        throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
      } 
    } else {
      d(paramT, paramObject);
    } 
    if (paramObject instanceof a0)
      this.c = true; 
    this.a.a((Comparable)paramT, paramObject);
  }
  
  public final void c(Map.Entry<T, Object> paramEntry) {
    b b = (b)paramEntry.getKey();
    Object object2 = paramEntry.getValue();
    Object object1 = object2;
    if (object2 instanceof a0)
      object1 = ((a0)object2).a(null); 
    if (b.b()) {
      object = a((T)b);
      object2 = object;
      if (object == null)
        object2 = new ArrayList(); 
      for (Object object : object1)
        ((List<Object>)object2).add(a(object)); 
      this.a.a(b, object2);
      return;
    } 
    if (b.d() == r1.c.MESSAGE) {
      object2 = a((T)b);
      if (object2 == null) {
        this.a.a(b, a(object1));
        return;
      } 
      object1 = ((GeneratedMessageLite.b)b.a(((o0)object2).toBuilder(), (o0)object1)).a();
      this.a.a(b, object1);
      return;
    } 
    this.a.a(b, a(object1));
  }
  
  public int d() {
    int j = 0;
    int i = 0;
    while (j < this.a.b.size()) {
      Map.Entry entry = this.a.a(j);
      i += b((b)entry.getKey(), entry.getValue());
      j++;
    } 
    for (Map.Entry entry : this.a.b())
      i += b((b)entry.getKey(), entry.getValue()); 
    return i;
  }
  
  public final void d(T paramT, Object paramObject) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface c : ()Lcom/fyber/inneractive/sdk/protobuf/r1$b;
    //   6: astore #4
    //   8: getstatic com/fyber/inneractive/sdk/protobuf/y.a : Ljava/nio/charset/Charset;
    //   11: astore #5
    //   13: aload_2
    //   14: invokevirtual getClass : ()Ljava/lang/Class;
    //   17: pop
    //   18: getstatic com/fyber/inneractive/sdk/protobuf/u$a.a : [I
    //   21: aload #4
    //   23: invokevirtual e : ()Lcom/fyber/inneractive/sdk/protobuf/r1$c;
    //   26: invokevirtual ordinal : ()I
    //   29: iaload
    //   30: tableswitch default -> 80, 1 -> 176, 2 -> 168, 3 -> 160, 4 -> 152, 5 -> 144, 6 -> 136, 7 -> 117, 8 -> 100, 9 -> 83
    //   80: goto -> 184
    //   83: aload_2
    //   84: instanceof com/fyber/inneractive/sdk/protobuf/o0
    //   87: ifne -> 131
    //   90: aload_2
    //   91: instanceof com/fyber/inneractive/sdk/protobuf/a0
    //   94: ifeq -> 184
    //   97: goto -> 131
    //   100: aload_2
    //   101: instanceof java/lang/Integer
    //   104: ifne -> 131
    //   107: aload_2
    //   108: instanceof com/fyber/inneractive/sdk/protobuf/y$c
    //   111: ifeq -> 184
    //   114: goto -> 131
    //   117: aload_2
    //   118: instanceof com/fyber/inneractive/sdk/protobuf/i
    //   121: ifne -> 131
    //   124: aload_2
    //   125: instanceof [B
    //   128: ifeq -> 184
    //   131: iconst_1
    //   132: istore_3
    //   133: goto -> 186
    //   136: aload_2
    //   137: instanceof java/lang/String
    //   140: istore_3
    //   141: goto -> 186
    //   144: aload_2
    //   145: instanceof java/lang/Boolean
    //   148: istore_3
    //   149: goto -> 186
    //   152: aload_2
    //   153: instanceof java/lang/Double
    //   156: istore_3
    //   157: goto -> 186
    //   160: aload_2
    //   161: instanceof java/lang/Float
    //   164: istore_3
    //   165: goto -> 186
    //   168: aload_2
    //   169: instanceof java/lang/Long
    //   172: istore_3
    //   173: goto -> 186
    //   176: aload_2
    //   177: instanceof java/lang/Integer
    //   180: istore_3
    //   181: goto -> 186
    //   184: iconst_0
    //   185: istore_3
    //   186: iload_3
    //   187: ifeq -> 191
    //   190: return
    //   191: new java/lang/IllegalArgumentException
    //   194: dup
    //   195: ldc_w 'Wrong object type used with protocol message reflection.\\nField number: %d, field java type: %s, value type: %s\\n'
    //   198: iconst_3
    //   199: anewarray java/lang/Object
    //   202: dup
    //   203: iconst_0
    //   204: aload_1
    //   205: invokeinterface a : ()I
    //   210: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   213: aastore
    //   214: dup
    //   215: iconst_1
    //   216: aload_1
    //   217: invokeinterface c : ()Lcom/fyber/inneractive/sdk/protobuf/r1$b;
    //   222: invokevirtual e : ()Lcom/fyber/inneractive/sdk/protobuf/r1$c;
    //   225: aastore
    //   226: dup
    //   227: iconst_2
    //   228: aload_2
    //   229: invokevirtual getClass : ()Ljava/lang/Class;
    //   232: invokevirtual getName : ()Ljava/lang/String;
    //   235: aastore
    //   236: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   239: invokespecial <init> : (Ljava/lang/String;)V
    //   242: athrow
  }
  
  public boolean e() {
    for (int i = 0; i < this.a.b.size(); i++) {
      if (!b(this.a.a(i)))
        return false; 
    } 
    Iterator<Map.Entry<b, Object>> iterator = this.a.b().iterator();
    while (iterator.hasNext()) {
      if (!b(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof u))
      return false; 
    paramObject = paramObject;
    return this.a.equals(((u)paramObject).a);
  }
  
  public Iterator<Map.Entry<T, Object>> f() {
    return (Iterator<Map.Entry<T, Object>>)(this.c ? new a0.b(this.a.entrySet().iterator()) : this.a.entrySet().iterator());
  }
  
  public void g() {
    if (this.b)
      return; 
    this.a.d();
    this.b = true;
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public static interface b<T extends b<T>> extends Comparable<T> {
    int a();
    
    o0.a a(o0.a param1a, o0 param1o0);
    
    boolean b();
    
    r1.b c();
    
    r1.c d();
    
    boolean isPacked();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobu\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */