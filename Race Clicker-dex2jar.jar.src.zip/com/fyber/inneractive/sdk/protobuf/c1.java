package com.fyber.inneractive.sdk.protobuf;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface c1 {
  i a() throws IOException;
  
  @Deprecated
  <T> T a(d1<T> paramd1, q paramq) throws IOException;
  
  @Deprecated
  <T> T a(Class<T> paramClass, q paramq) throws IOException;
  
  void a(List<Long> paramList) throws IOException;
  
  @Deprecated
  <T> void a(List<T> paramList, d1<T> paramd1, q paramq) throws IOException;
  
  <K, V> void a(Map<K, V> paramMap, h0.a<K, V> parama, q paramq) throws IOException;
  
  int b() throws IOException;
  
  <T> T b(d1<T> paramd1, q paramq) throws IOException;
  
  <T> T b(Class<T> paramClass, q paramq) throws IOException;
  
  void b(List<String> paramList) throws IOException;
  
  <T> void b(List<T> paramList, d1<T> paramd1, q paramq) throws IOException;
  
  int c() throws IOException;
  
  void c(List<Integer> paramList) throws IOException;
  
  int d() throws IOException;
  
  void d(List<Float> paramList) throws IOException;
  
  int e();
  
  void e(List<Integer> paramList) throws IOException;
  
  long f() throws IOException;
  
  void f(List<Integer> paramList) throws IOException;
  
  long g() throws IOException;
  
  void g(List<Long> paramList) throws IOException;
  
  double h() throws IOException;
  
  void h(List<i> paramList) throws IOException;
  
  void i(List<Integer> paramList) throws IOException;
  
  boolean i() throws IOException;
  
  int j() throws IOException;
  
  void j(List<Double> paramList) throws IOException;
  
  float k() throws IOException;
  
  void k(List<Long> paramList) throws IOException;
  
  long l() throws IOException;
  
  void l(List<Boolean> paramList) throws IOException;
  
  int m() throws IOException;
  
  void m(List<Long> paramList) throws IOException;
  
  String n() throws IOException;
  
  void n(List<Long> paramList) throws IOException;
  
  long o() throws IOException;
  
  void o(List<Integer> paramList) throws IOException;
  
  String p() throws IOException;
  
  void p(List<Integer> paramList) throws IOException;
  
  int q() throws IOException;
  
  void q(List<String> paramList) throws IOException;
  
  boolean r() throws IOException;
  
  int s() throws IOException;
  
  long t() throws IOException;
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */