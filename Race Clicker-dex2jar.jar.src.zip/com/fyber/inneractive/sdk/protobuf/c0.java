package com.fyber.inneractive.sdk.protobuf;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public class c0 extends c<String> implements d0, RandomAccess {
  public final List<Object> b;
  
  static {
    (new c0(10)).a = false;
  }
  
  public c0(int paramInt) {
    this(new ArrayList(paramInt));
  }
  
  public c0(ArrayList<Object> paramArrayList) {
    this.b = paramArrayList;
  }
  
  public static String a(Object paramObject) {
    return (paramObject instanceof String) ? (String)paramObject : ((paramObject instanceof i) ? ((i)paramObject).i() : new String((byte[])paramObject, y.a));
  }
  
  public d0 a() {
    return (d0)(this.a ? new n1(this) : this);
  }
  
  public Object a(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public void a(i parami) {
    e();
    this.b.add(parami);
    ((AbstractList)this).modCount++;
  }
  
  public void add(int paramInt, Object paramObject) {
    paramObject = paramObject;
    e();
    this.b.add(paramInt, paramObject);
    ((AbstractList)this).modCount++;
  }
  
  public boolean addAll(int paramInt, Collection<? extends String> paramCollection) {
    e();
    Collection<? extends String> collection = paramCollection;
    if (paramCollection instanceof d0)
      collection = (Collection)((d0)paramCollection).c(); 
    boolean bool = this.b.addAll(paramInt, collection);
    ((AbstractList)this).modCount++;
    return bool;
  }
  
  public boolean addAll(Collection<? extends String> paramCollection) {
    return addAll(this.b.size(), paramCollection);
  }
  
  public y.j b(int paramInt) {
    if (paramInt >= this.b.size()) {
      ArrayList<Object> arrayList = new ArrayList(paramInt);
      arrayList.addAll(this.b);
      return (y.j)new c0(arrayList);
    } 
    throw new IllegalArgumentException();
  }
  
  public List<?> c() {
    return Collections.unmodifiableList(this.b);
  }
  
  public void clear() {
    e();
    this.b.clear();
    ((AbstractList)this).modCount++;
  }
  
  public Object get(int paramInt) {
    Object object = this.b.get(paramInt);
    if (object instanceof String)
      return object; 
    if (object instanceof i) {
      i i = (i)object;
      String str = i.i();
      object = str;
      if (i.e()) {
        this.b.set(paramInt, str);
        object = str;
      } 
    } else {
      byte[] arrayOfByte = (byte[])object;
      String str = new String(arrayOfByte, y.a);
      object = str;
      if (q1.a(arrayOfByte)) {
        this.b.set(paramInt, str);
        object = str;
      } 
    } 
    return object;
  }
  
  public Object remove(int paramInt) {
    e();
    Object object = this.b.remove(paramInt);
    ((AbstractList)this).modCount++;
    return a(object);
  }
  
  public Object set(int paramInt, Object paramObject) {
    paramObject = paramObject;
    e();
    return a(this.b.set(paramInt, paramObject));
  }
  
  public int size() {
    return this.b.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */