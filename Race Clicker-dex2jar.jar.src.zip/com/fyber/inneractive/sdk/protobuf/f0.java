package com.fyber.inneractive.sdk.protobuf;

import java.nio.charset.Charset;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

public final class f0 extends c<Long> implements y.i, RandomAccess, x0 {
  public static final f0 d;
  
  public long[] b;
  
  public int c;
  
  static {
    f0 f01 = new f0(new long[0], 0);
    d = f01;
    f01.a = false;
  }
  
  public f0() {
    this(new long[10], 0);
  }
  
  public f0(long[] paramArrayOflong, int paramInt) {
    this.b = paramArrayOflong;
    this.c = paramInt;
  }
  
  public void a(long paramLong) {
    e();
    int j = this.c;
    long[] arrayOfLong = this.b;
    if (j == arrayOfLong.length) {
      long[] arrayOfLong1 = new long[j * 3 / 2 + 1];
      System.arraycopy(arrayOfLong, 0, arrayOfLong1, 0, j);
      this.b = arrayOfLong1;
    } 
    arrayOfLong = this.b;
    j = this.c;
    this.c = j + 1;
    arrayOfLong[j] = paramLong;
  }
  
  public void add(int paramInt, Object paramObject) {
    long l = ((Long)paramObject).longValue();
    e();
    if (paramInt >= 0) {
      int j = this.c;
      if (paramInt <= j) {
        paramObject = this.b;
        if (j < paramObject.length) {
          System.arraycopy(paramObject, paramInt, paramObject, paramInt + 1, j - paramInt);
        } else {
          long[] arrayOfLong = new long[j * 3 / 2 + 1];
          System.arraycopy(paramObject, 0, arrayOfLong, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfLong, paramInt + 1, this.c - paramInt);
          this.b = arrayOfLong;
        } 
        this.b[paramInt] = l;
        this.c++;
        ((AbstractList)this).modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(e(paramInt));
  }
  
  public boolean add(Object paramObject) {
    a(((Long)paramObject).longValue());
    return true;
  }
  
  public boolean addAll(Collection<? extends Long> paramCollection) {
    e();
    Charset charset = y.a;
    paramCollection.getClass();
    if (!(paramCollection instanceof f0))
      return super.addAll(paramCollection); 
    f0 f01 = (f0)paramCollection;
    int j = f01.c;
    if (j == 0)
      return false; 
    int k = this.c;
    if (Integer.MAX_VALUE - k >= j) {
      j = k + j;
      long[] arrayOfLong = this.b;
      if (j > arrayOfLong.length)
        this.b = Arrays.copyOf(arrayOfLong, j); 
      System.arraycopy(f01.b, 0, this.b, this.c, f01.c);
      this.c = j;
      ((AbstractList)this).modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public final void c(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(e(paramInt));
  }
  
  public boolean contains(Object paramObject) {
    return (indexOf(paramObject) != -1);
  }
  
  public long d(int paramInt) {
    c(paramInt);
    return this.b[paramInt];
  }
  
  public final String e(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof f0))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((f0)paramObject).c)
      return false; 
    paramObject = ((f0)paramObject).b;
    for (int j = 0; j < this.c; j++) {
      if (this.b[j] != paramObject[j])
        return false; 
    } 
    return true;
  }
  
  public y.i f(int paramInt) {
    if (paramInt >= this.c)
      return new f0(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public Object get(int paramInt) {
    c(paramInt);
    return Long.valueOf(this.b[paramInt]);
  }
  
  public int hashCode() {
    int k = 1;
    for (int j = 0; j < this.c; j++)
      k = k * 31 + y.a(this.b[j]); 
    return k;
  }
  
  public int indexOf(Object paramObject) {
    if (!(paramObject instanceof Long))
      return -1; 
    long l = ((Long)paramObject).longValue();
    int k = this.c;
    for (int j = 0; j < k; j++) {
      if (this.b[j] == l)
        return j; 
    } 
    return -1;
  }
  
  public Object remove(int paramInt) {
    e();
    c(paramInt);
    long[] arrayOfLong = this.b;
    long l = arrayOfLong[paramInt];
    int j = this.c;
    if (paramInt < j - 1)
      System.arraycopy(arrayOfLong, paramInt + 1, arrayOfLong, paramInt, j - paramInt - 1); 
    this.c--;
    ((AbstractList)this).modCount++;
    return Long.valueOf(l);
  }
  
  public void removeRange(int paramInt1, int paramInt2) {
    e();
    if (paramInt2 >= paramInt1) {
      long[] arrayOfLong = this.b;
      System.arraycopy(arrayOfLong, paramInt2, arrayOfLong, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      ((AbstractList)this).modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Object set(int paramInt, Object paramObject) {
    long l = ((Long)paramObject).longValue();
    e();
    c(paramInt);
    paramObject = this.b;
    Object object = paramObject[paramInt];
    paramObject[paramInt] = l;
    return Long.valueOf(object);
  }
  
  public int size() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */