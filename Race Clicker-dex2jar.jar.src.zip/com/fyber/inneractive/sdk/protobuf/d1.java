package com.fyber.inneractive.sdk.protobuf;

import java.io.IOException;

public interface d1<T> {
  T a();
  
  void a(T paramT, c1 paramc1, q paramq) throws IOException;
  
  void a(T paramT, s1 params1) throws IOException;
  
  void a(T paramT1, T paramT2);
  
  void a(T paramT, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, e.b paramb) throws IOException;
  
  boolean a(T paramT);
  
  int b(T paramT);
  
  boolean b(T paramT1, T paramT2);
  
  void c(T paramT);
  
  int d(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */