package com.fyber.inneractive.sdk.protobuf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public abstract class e0 {
  public static final e0 a = new b();
  
  public static final e0 b = new c();
  
  public e0() {}
  
  public abstract void a(Object paramObject, long paramLong);
  
  public abstract <L> void a(Object paramObject1, Object paramObject2, long paramLong);
  
  public abstract <L> List<L> b(Object paramObject, long paramLong);
  
  public static final class b extends e0 {
    public static final Class<?> c = Collections.unmodifiableList(Collections.emptyList()).getClass();
    
    public b() {
      super(null);
    }
    
    public static <L> List<L> a(Object param1Object, long param1Long, int param1Int) {
      y.j j;
      n1 n12;
      List list = (List)p1.g(param1Object, param1Long);
      if (list.isEmpty()) {
        ArrayList<L> arrayList;
        if (list instanceof d0) {
          c0 c0 = new c0(param1Int);
        } else if (list instanceof x0 && list instanceof y.j) {
          j = ((y.j)list).b(param1Int);
        } else {
          arrayList = new ArrayList(param1Int);
        } 
        p1.a(param1Object, param1Long, arrayList);
        return arrayList;
      } 
      if (c.isAssignableFrom(list.getClass())) {
        ArrayList arrayList = new ArrayList(list.size() + param1Int);
        arrayList.addAll(list);
        p1.a(param1Object, param1Long, arrayList);
        return arrayList;
      } 
      if (list instanceof n1) {
        c0 c0 = new c0(list.size() + param1Int);
        n12 = (n1)list;
        c0.addAll(c0.b.size(), (Collection<? extends String>)n12);
        p1.a(param1Object, param1Long, c0);
        return c0;
      } 
      n1 n11 = n12;
      if (n12 instanceof x0) {
        n11 = n12;
        if (n12 instanceof y.j) {
          y.j j1 = (y.j)n12;
          n11 = n12;
          if (!j1.d()) {
            j = j1.b(n12.size() + param1Int);
            p1.a(param1Object, param1Long, j);
          } 
        } 
      } 
      return (List<L>)j;
    }
    
    public void a(Object param1Object, long param1Long) {
      List<?> list = (List)p1.g(param1Object, param1Long);
      if (list instanceof d0) {
        list = ((d0)list).a();
      } else {
        if (c.isAssignableFrom(list.getClass()))
          return; 
        if (list instanceof x0 && list instanceof y.j) {
          param1Object = list;
          if (param1Object.d())
            param1Object.b(); 
          return;
        } 
        list = Collections.unmodifiableList(list);
      } 
      p1.a(param1Object, param1Long, list);
    }
    
    public <E> void a(Object param1Object1, Object<?> param1Object2, long param1Long) {
      param1Object2 = (Object<?>)p1.g(param1Object2, param1Long);
      List<?> list = a(param1Object1, param1Long, param1Object2.size());
      int i = list.size();
      int j = param1Object2.size();
      if (i > 0 && j > 0)
        list.addAll((Collection<?>)param1Object2); 
      if (i > 0)
        param1Object2 = (Object<?>)list; 
      p1.a(param1Object1, param1Long, param1Object2);
    }
    
    public <L> List<L> b(Object param1Object, long param1Long) {
      return a(param1Object, param1Long, 10);
    }
  }
  
  public static final class c extends e0 {
    public c() {
      super(null);
    }
    
    public void a(Object param1Object, long param1Long) {
      ((y.j)p1.g(param1Object, param1Long)).b();
    }
    
    public <E> void a(Object param1Object1, Object param1Object2, long param1Long) {
      Object object = p1.g(param1Object1, param1Long);
      y.j j1 = (y.j)p1.g(param1Object2, param1Long);
      int i = object.size();
      int j = j1.size();
      param1Object2 = object;
      if (i > 0) {
        param1Object2 = object;
        if (j > 0) {
          param1Object2 = object;
          if (!object.d())
            param1Object2 = object.b(j + i); 
          param1Object2.addAll((Collection)j1);
        } 
      } 
      object = j1;
      if (i > 0)
        object = param1Object2; 
      p1.a(param1Object1, param1Long, object);
    }
    
    public <L> List<L> b(Object param1Object, long param1Long) {
      y.j j2 = (y.j)p1.g(param1Object, param1Long);
      y.j j1 = j2;
      if (!j2.d()) {
        int i = j2.size();
        if (i == 0) {
          i = 10;
        } else {
          i *= 2;
        } 
        j1 = j2.b(i);
        p1.a(param1Object, param1Long, j1);
      } 
      return (List<L>)j1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */