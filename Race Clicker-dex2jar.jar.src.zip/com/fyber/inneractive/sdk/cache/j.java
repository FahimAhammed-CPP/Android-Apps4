package com.fyber.inneractive.sdk.cache;

public class j<ResultData> {
  public ResultData a;
  
  public String b;
  
  public j(Exception paramException) {}
  
  public j(ResultData paramResultData, String paramString) {
    this.a = paramResultData;
    this.b = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */