package com.fyber.inneractive.sdk.cache;

import com.fyber.inneractive.sdk.network.w;

public class g implements w<String> {
  public g(i parami) {}
  
  public void a(Object paramObject, Exception paramException, boolean paramBoolean) {
    paramObject = paramObject;
    if (paramObject != null)
      this.a.c = (String)paramObject; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */