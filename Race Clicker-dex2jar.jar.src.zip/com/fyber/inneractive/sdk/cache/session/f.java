package com.fyber.inneractive.sdk.cache.session;

import com.fyber.inneractive.sdk.cache.session.enums.b;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class f {
  public HashMap<b, e> a = new a(this);
  
  public JSONObject a() {
    JSONObject jSONObject = new JSONObject();
    try {
      JSONArray jSONArray = new JSONArray();
      Iterator<Map.Entry> iterator = this.a.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Map.Entry entry = iterator.next();
          b b = (b)entry.getKey();
          try {
            String str;
            JSONObject jSONObject1 = new JSONObject();
            jSONObject1.put("type", b.e().value());
            if (b.name().toLowerCase().contains("video")) {
              str = "video";
            } else {
              str = "display";
            } 
            jSONObject1.put("subType", str);
            jSONObject1.put("session_data", ((e)entry.getValue()).a(true, true));
            jSONArray.put(jSONObject1);
          } catch (Exception exception) {}
          continue;
        } 
        jSONObject.put("content", jSONArray);
        return jSONObject;
      } 
    } catch (Exception exception) {
      return jSONObject;
    } 
  }
  
  public class a extends HashMap<b, e> {
    public a(f this$0) {
      for (b b : b.values()) {
        if (b != b.NONE)
          put((K)b, (V)new e()); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */