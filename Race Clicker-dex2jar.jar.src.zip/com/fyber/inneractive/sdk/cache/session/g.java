package com.fyber.inneractive.sdk.cache.session;

import java.util.Comparator;

public class g implements Comparator<e> {
  public g(h paramh) {}
  
  public int compare(Object paramObject1, Object paramObject2) {
    paramObject1 = paramObject1;
    paramObject2 = paramObject2;
    return (paramObject1 != null && paramObject2 != null) ? ((((e)paramObject2).d - ((e)paramObject1).d > 0L) ? 1 : -1) : 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */