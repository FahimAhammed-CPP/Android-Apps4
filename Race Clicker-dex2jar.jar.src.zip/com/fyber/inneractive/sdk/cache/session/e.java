package com.fyber.inneractive.sdk.cache.session;

import com.fyber.inneractive.sdk.cache.session.enums.a;
import org.json.JSONObject;

public class e {
  public int a;
  
  public int b;
  
  public int c;
  
  public long d;
  
  public e() {
    this(0, 0, 0, System.currentTimeMillis());
  }
  
  public e(int paramInt1, int paramInt2, int paramInt3, long paramLong) {
    this.d = paramLong;
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  public static e a(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      long l = paramJSONObject.optLong("time");
      int i = paramJSONObject.optInt("cli", -1);
      int j = paramJSONObject.optInt("imp", -1);
      int k = paramJSONObject.optInt("com", -1);
      if (l != 0L && i >= 0 && j >= 0 && k >= 0)
        return new e(j, i, k, l); 
    } 
    return null;
  }
  
  public JSONObject a(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_3
    //   8: iload_1
    //   9: ifeq -> 23
    //   12: aload_3
    //   13: ldc 'time'
    //   15: aload_0
    //   16: getfield d : J
    //   19: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   22: pop
    //   23: aload_3
    //   24: ldc 'imp'
    //   26: aload_0
    //   27: getfield a : I
    //   30: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   33: pop
    //   34: iload_2
    //   35: ifeq -> 49
    //   38: aload_3
    //   39: ldc 'com'
    //   41: aload_0
    //   42: getfield c : I
    //   45: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   48: pop
    //   49: aload_3
    //   50: ldc 'cli'
    //   52: aload_0
    //   53: getfield b : I
    //   56: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   59: pop
    //   60: aload_3
    //   61: areturn
    //   62: astore #4
    //   64: aload_3
    //   65: areturn
    // Exception table:
    //   from	to	target	type
    //   12	23	62	org/json/JSONException
    //   23	34	62	org/json/JSONException
    //   38	49	62	org/json/JSONException
    //   49	60	62	org/json/JSONException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */