package com.fyber.inneractive.sdk.cache.session;

import java.util.PriorityQueue;

public class h extends PriorityQueue<e> {
  public int a;
  
  public h(int paramInt) {
    super(1, new i());
    this.a = paramInt;
  }
  
  public boolean a(e parame) {
    boolean bool = super.add(parame);
    if (super.size() > this.a)
      poll(); 
    return bool;
  }
  
  public int size() {
    return super.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */