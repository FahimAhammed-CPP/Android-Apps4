package com.fyber.inneractive.sdk.cache.session;

import com.fyber.inneractive.sdk.cache.session.enums.b;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.i;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import org.json.JSONArray;
import org.json.JSONObject;

public class d {
  public f a = new f();
  
  public HashMap<b, h> b;
  
  public final Object c = new Object();
  
  public final Object d = new Object();
  
  public a e;
  
  public d(int paramInt, a parama) {
    this.b = (HashMap<b, h>)new a(this, paramInt);
    this.e = null;
  }
  
  public static JSONObject a(d paramd) {
    paramd.getClass();
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("currentSession", paramd.a.a());
      for (Map.Entry<b, h> entry : paramd.b.entrySet()) {
        JSONArray jSONArray = new JSONArray();
        b b = (b)entry.getKey();
        Iterator<e> iterator = ((PriorityQueue)entry.getValue()).iterator();
        while (iterator.hasNext())
          jSONArray.put(((e)iterator.next()).a(true, true)); 
        jSONObject.put(b.name(), jSONArray);
      } 
      return jSONObject;
    } catch (Exception exception) {
      return jSONObject;
    } 
  }
  
  public int a() {
    byte b;
    i i = IAConfigManager.M.u.b;
    String str = Integer.toString(5);
    if (i.a.containsKey("number_of_sessions"))
      str = (String)i.a.get("number_of_sessions"); 
    try {
      b = Integer.parseInt(str);
    } finally {
      str = null;
    } 
  }
  
  public final void a(b paramb, e parame) {
    synchronized (this.d) {
      h h = this.b.get(paramb);
      if (h != null)
        h.a(parame); 
      return;
    } 
  }
  
  public final void a(f paramf) {
    for (b b : b.values()) {
      if (b != b.NONE) {
        e e = paramf.a.get(b);
        if (e != null && e.a != 0)
          a(b, e); 
      } 
    } 
  }
  
  public static interface a {
    void a(d param1d, boolean param1Boolean, JSONObject param1JSONObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */