package com.fyber.inneractive.sdk.cache.session;

import java.util.Comparator;

public class i implements Comparator<e> {
  public int compare(Object paramObject1, Object paramObject2) {
    paramObject1 = paramObject1;
    paramObject2 = paramObject2;
    return (paramObject1 != null && paramObject2 != null) ? ((((e)paramObject1).d < ((e)paramObject2).d) ? -1 : 1) : 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\session\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */