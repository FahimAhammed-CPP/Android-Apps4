package com.fyber.inneractive.sdk.cache;

public class e implements a<String> {
  public final String a;
  
  public final String b;
  
  public e(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public Object a(String paramString) throws Exception {
    return paramString;
  }
  
  public String a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public String c() {
    return this.b;
  }
  
  public boolean d() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\cache\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */