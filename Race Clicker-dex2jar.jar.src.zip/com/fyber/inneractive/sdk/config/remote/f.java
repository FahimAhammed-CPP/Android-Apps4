package com.fyber.inneractive.sdk.config.remote;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.config.enums.Track;
import java.util.LinkedHashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class f {
  public Set<Track> a = null;
  
  public static f a(JSONObject paramJSONObject) {
    f f1;
    JSONObject jSONObject = null;
    if (paramJSONObject == null)
      return null; 
    JSONArray jSONArray = paramJSONObject.optJSONArray("track");
    paramJSONObject = jSONObject;
    if (jSONArray != null) {
      f1 = new f();
      LinkedHashSet<Track> linkedHashSet = new LinkedHashSet();
      for (int i = 0; i < jSONArray.length(); i++) {
        String str = jSONArray.optString(i);
        if (!TextUtils.isEmpty(str)) {
          Track track = Track.fromValue(str);
          if (track != null)
            linkedHashSet.add(track); 
        } 
      } 
      f1.a = linkedHashSet;
    } 
    return f1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */