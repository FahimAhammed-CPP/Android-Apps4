package com.fyber.inneractive.sdk.config.remote;

import com.fyber.inneractive.sdk.config.enums.UnitDisplayType;
import org.json.JSONObject;

public class b {
  public UnitDisplayType a;
  
  public Boolean b;
  
  public Integer c;
  
  public Integer d;
  
  public static b a(JSONObject paramJSONObject) {
    Integer integer2 = null;
    if (paramJSONObject == null)
      return null; 
    b b1 = new b();
    Integer integer4 = Integer.valueOf(paramJSONObject.optInt("hide", -2147483648));
    Integer integer3 = Integer.valueOf(paramJSONObject.optInt("refresh", -2147483648));
    b1.a = UnitDisplayType.fromValue(paramJSONObject.optString("unitDisplayType"));
    if (paramJSONObject.has("close")) {
      Boolean bool = Boolean.valueOf(paramJSONObject.optBoolean("close", true));
    } else {
      paramJSONObject = null;
    } 
    b1.b = (Boolean)paramJSONObject;
    Integer integer1 = integer4;
    if (integer4.intValue() == Integer.MIN_VALUE)
      integer1 = null; 
    b1.d = integer1;
    if (integer3.intValue() == Integer.MIN_VALUE) {
      integer1 = integer2;
    } else {
      integer1 = integer3;
    } 
    b1.c = integer1;
    return b1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */