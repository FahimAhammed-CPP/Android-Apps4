package com.fyber.inneractive.sdk.config;

import android.content.Context;
import com.fyber.inneractive.sdk.cache.d;
import com.fyber.inneractive.sdk.network.g0;
import com.fyber.inneractive.sdk.network.q0;
import com.fyber.inneractive.sdk.network.w;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class j {
  public final Context a;
  
  public i b = new i();
  
  public List<b> c = new CopyOnWriteArrayList<b>();
  
  public boolean d = false;
  
  public final d e = new d();
  
  public j(Context paramContext) {
    this.a = paramContext;
  }
  
  public i a() {
    return this.b;
  }
  
  public void b() {
    g0 g0 = new g0(new a(this), this.a, (com.fyber.inneractive.sdk.cache.a)this.e);
    IAConfigManager.M.s.a.offer(g0);
    g0.a(q0.QUEUED);
  }
  
  public class a implements w<i> {
    public a(j this$0) {}
    
    public void a(Object param1Object, Exception param1Exception, boolean param1Boolean) {
      i i = (i)param1Object;
      if (i != null) {
        param1Object = this.a;
        param1Object.getClass();
        if (!i.equals(((j)param1Object).b)) {
          ((j)param1Object).d = true;
          ((j)param1Object).b = i;
          Iterator<j.b> iterator = ((j)param1Object).c.iterator();
          while (iterator.hasNext())
            ((j.b)iterator.next()).onGlobalConfigChanged((j)param1Object, ((j)param1Object).b); 
        } 
      } 
    }
  }
  
  public static interface b {
    void onGlobalConfigChanged(j param1j, i param1i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\config\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */