package com.fyber.inneractive.sdk.config.enums;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;

public enum Track {
  ERRORS, NETWORKING, VIEWABILITY;
  
  private static final Map<String, Track> CONSTANTS;
  
  private final String stringValue;
  
  static {
    int i = 0;
    Track track1 = new Track("ERRORS", 0, "errors");
    ERRORS = track1;
    Track track2 = new Track("NETWORKING", 1, "networking");
    NETWORKING = track2;
    Track track3 = new Track("VIEWABILITY", 2, "viewability");
    VIEWABILITY = track3;
    $VALUES = new Track[] { track1, track2, track3 };
    CONSTANTS = new HashMap<String, Track>();
    Track[] arrayOfTrack = values();
    int j = arrayOfTrack.length;
    while (i < j) {
      track2 = arrayOfTrack[i];
      CONSTANTS.put(track2.stringValue, track2);
      i++;
    } 
  }
  
  Track(String paramString1) {
    this.stringValue = paramString1;
  }
  
  public static Track fromValue(String paramString) {
    return TextUtils.isEmpty(paramString) ? null : CONSTANTS.get(paramString);
  }
  
  public String toString() {
    return this.stringValue;
  }
  
  public String value() {
    return this.stringValue;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\config\enums\Track.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */