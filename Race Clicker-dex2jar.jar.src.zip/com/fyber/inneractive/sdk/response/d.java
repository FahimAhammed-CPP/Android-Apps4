package com.fyber.inneractive.sdk.response;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.a0;
import com.fyber.inneractive.sdk.config.enums.UnitDisplayType;
import com.fyber.inneractive.sdk.flow.vast.g;
import com.fyber.inneractive.sdk.flow.vast.i;
import com.fyber.inneractive.sdk.model.vast.b;
import com.fyber.inneractive.sdk.model.vast.e;
import com.fyber.inneractive.sdk.model.vast.g;
import com.fyber.inneractive.sdk.model.vast.o;
import com.fyber.inneractive.sdk.model.vast.r;
import com.fyber.inneractive.sdk.model.vast.u;
import com.fyber.inneractive.sdk.model.vast.v;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.p;
import com.fyber.inneractive.sdk.util.x;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class d extends b {
  public g e;
  
  public a0 f;
  
  public e g;
  
  public List<e> h = new ArrayList<e>();
  
  public int i;
  
  public u j;
  
  public e a() {
    g g1 = new g();
    this.a = g1;
    g g2 = g1;
    this.e = g1;
    return g1;
  }
  
  public void a(e parame, List<e> paramList) throws i {
    com.fyber.inneractive.sdk.flow.vast.d d1 = new com.fyber.inneractive.sdk.flow.vast.d();
    int i = this.f.f.c.intValue();
    int j = this.f.f.b.intValue();
    int k = this.f.f.g.intValue();
    d1.a = i;
    d1.b = j;
    d1.c = k;
    if (UnitDisplayType.VERTICAL.equals(this.f.f.j))
      d1.d = true; 
    if (this.f.f.k.contains(Integer.valueOf(2)))
      d1.e = true; 
    try {
      String str;
      u u1 = this.j;
      if (u1 != null) {
        str = u1.b;
      } else {
        str = "";
      } 
      b b1 = d1.a(parame, paramList, str);
      this.e.K = b1;
    } catch (i i1) {
      g g2 = this.e;
      g2.getClass();
      g2.i = i1.getMessage();
    } 
    g g1 = this.e;
    Map<? extends o, ? extends g> map = d1.f;
    g1.getClass();
    if (map != null)
      g1.L.putAll(map); 
    g1 = this.e;
    List<? extends g> list = d1.g;
    g1.getClass();
    if (list != null)
      g1.M.addAll(list); 
    g1 = this.e;
    list = d1.i;
    g1.getClass();
    if (list != null)
      g1.N.addAll(list); 
    if (IAlog.a == 2) {
      Map map1 = d1.f;
      if (map1.size() > 0) {
        IAlog.d(" VParser: Unsupported media files:", new Object[0]);
        for (o o : map1.keySet()) {
          IAlog.d("VParser: %s", new Object[] { o });
          IAlog.d("VParser: reason = %s", new Object[] { map1.get(o) });
        } 
      } else {
        IAlog.d("VParser: Unsupported media files: none", new Object[0]);
      } 
    } 
  }
  
  public void a(String paramString, a0 parama0) throws Exception {
    this.f = parama0;
    if (parama0 == null || parama0.f == null) {
      this.a.i = "ErrorConfigurationMismatch";
      return;
    } 
    this.e.J = System.currentTimeMillis();
    this.i = IAConfigManager.M.i.b;
    this.e.getClass();
    try {
      b(paramString);
      a(this.g, this.h);
      return;
    } catch (InterruptedException interruptedException) {
      throw interruptedException;
    } catch (i i) {
      this.e.i = i.getMessage();
      this.e.j = i.getCause().getMessage();
      return;
    } catch (Exception exception) {
      this.e.j = String.format("%s", new Object[] { exception.getMessage() });
      g g1 = this.e;
      g1.i = "VastErrorInvalidFile";
      g1.x = exception;
      if (IAlog.a == 2) {
        exception.printStackTrace();
        return;
      } 
      return;
    } 
  }
  
  public void b(String paramString) throws i, Exception {
    try {
      paramString = paramString.replaceFirst("<\\?.*\\?>", "");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      documentBuilderFactory.setCoalescing(true);
      Document document = documentBuilderFactory.newDocumentBuilder().parse(new InputSource(new StringReader(paramString)));
      if (document != null) {
        Node node = document.getFirstChild();
        if (node.getNodeName().equalsIgnoreCase("VAST")) {
          r r = r.a(node);
        } else {
          IAlog.a("XML does not contain a VAST tag as its first child!", new Object[0]);
          throw new Exception("XML does not contain a VAST tag as its first child!");
        } 
      } else {
        document = null;
      } 
      try {
        if (this.j == null) {
          this.j = new u(((r)document).a);
        } else {
          u u1 = new u(((r)document).a);
          if (u1.a(this.j) >= 0)
            this.j = u1; 
        } 
      } catch (com.fyber.inneractive.sdk.model.vast.u.a a) {}
      List<e> list = ((r)document).b;
      if (list != null && list.size() != 0) {
        StringBuilder stringBuilder;
        e e1 = list.get(0);
        v v = e1.b;
        if (v != null) {
          IAlog.a("Vast response parser: found VAST wrapper #%d", new Object[] { Integer.valueOf(this.h.size()) });
          int i = this.h.size();
          int j = this.i;
          if (i < j) {
            this.h.add(e1);
            String str = v.f;
            if (!TextUtils.isEmpty(str)) {
              if (x.f(str)) {
                String str1 = p.a(str, 3000, 5000, 5);
                if (!TextUtils.isEmpty(str1)) {
                  this.e.O.put(str, str1);
                  b(str1);
                  return;
                } 
                throw new i("VastErrorInvalidFile", "Failed getting data from ad tag URI");
              } 
              IAlog.a("Vast response parser: Unsecure Wrapper URL. Aborting! url: %s", new Object[] { str });
              throw new i("VastErrorUnsecure", "Unsecure ad tag URI for wrapper");
            } 
            IAlog.a("Vast response parser: found an empty tag uri in wrapper! aborting!", new Object[0]);
            throw new i("VastErrorInvalidFile", "No ad tag URI for wrapper");
          } 
          IAlog.a("Vast response parser: too many vast wrappers! Only %dallowed. stopping", new Object[] { Integer.valueOf(j) });
          stringBuilder = new StringBuilder("More than ");
          stringBuilder.append(this.i);
          stringBuilder.append(" found");
          throw new i("VastErrorTooManyWrappers", stringBuilder.toString());
        } 
        if (((e)stringBuilder).c != null) {
          this.g = (e)stringBuilder;
          return;
        } 
        throw new i("VastErrorInvalidFile", "A top level ad with no wrapper on inline found!");
      } 
      IAlog.a("Vast response parser: no ads found in model. aborting", new Object[0]);
      throw new i("ErrorNoMediaFiles", "No ads found in model. Empty Vast?");
    } catch (Exception exception) {
      IAlog.a("Failed parsing Vast file! parsing error = %s", new Object[] { exception.getMessage() });
      throw new i("VastErrorInvalidFile", exception.getMessage());
    } 
  }
  
  public boolean b() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\response\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */