package com.fyber.inneractive.sdk.response;

public enum a {
  RETURNED_ADTYPE_HTML, RETURNED_ADTYPE_HTML5_VIDEO, RETURNED_ADTYPE_MOBILE_ADS, RETURNED_ADTYPE_MRAID, RETURNED_ADTYPE_NATIVE, RETURNED_ADTYPE_PMN, RETURNED_ADTYPE_VAST;
  
  private int value;
  
  static {
    a a1 = new a("RETURNED_ADTYPE_HTML", 0, 4);
    RETURNED_ADTYPE_HTML = a1;
    a a2 = new a("RETURNED_ADTYPE_MRAID", 1, 6);
    RETURNED_ADTYPE_MRAID = a2;
    a a3 = new a("RETURNED_ADTYPE_VAST", 2, 8);
    RETURNED_ADTYPE_VAST = a3;
    a a4 = new a("RETURNED_ADTYPE_HTML5_VIDEO", 3, 9);
    RETURNED_ADTYPE_HTML5_VIDEO = a4;
    a a5 = new a("RETURNED_ADTYPE_NATIVE", 4, 10);
    RETURNED_ADTYPE_NATIVE = a5;
    a a6 = new a("RETURNED_ADTYPE_PMN", 5, 11);
    RETURNED_ADTYPE_PMN = a6;
    a a7 = new a("RETURNED_ADTYPE_MOBILE_ADS", 6, 15);
    RETURNED_ADTYPE_MOBILE_ADS = a7;
    $VALUES = new a[] { a1, a2, a3, a4, a5, a6, a7 };
  }
  
  a(int paramInt1) {
    this.value = paramInt1;
  }
  
  public static a a(int paramInt) {
    for (a a1 : values()) {
      if (a1.value == paramInt)
        return a1; 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\response\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */