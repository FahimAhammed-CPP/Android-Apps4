package com.fyber.inneractive.sdk.flow;

import android.os.Handler;
import android.os.HandlerThread;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.b0;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.external.InneractiveAdRequest;
import com.fyber.inneractive.sdk.external.InneractiveError;
import com.fyber.inneractive.sdk.external.InneractiveErrorCode;
import com.fyber.inneractive.sdk.external.InneractiveInfrastructureError;
import com.fyber.inneractive.sdk.interfaces.a;
import com.fyber.inneractive.sdk.network.t;
import com.fyber.inneractive.sdk.response.e;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.m;
import com.fyber.inneractive.sdk.util.q0;
import org.json.JSONArray;

public abstract class h<Response extends e, Content extends q> implements a, a.b {
  public InneractiveAdRequest a;
  
  public Response b;
  
  public Content c;
  
  public a.a d;
  
  public a.b e;
  
  public b0 f;
  
  public s g;
  
  public boolean h = false;
  
  public int i = 0;
  
  public com.fyber.inneractive.sdk.network.timeouts.content.a j;
  
  public b k = new b(this);
  
  public final Runnable l = new a(this);
  
  public int a(int paramInt) {
    com.fyber.inneractive.sdk.network.timeouts.content.a a1 = this.j;
    return (a1 != null) ? a1.a(paramInt) : 0;
  }
  
  public void a() {
    this.k.a();
    d();
    this.a = null;
    this.b = null;
    this.c = null;
    this.d = null;
    this.e = null;
    this.f = null;
  }
  
  public void a(InneractiveAdRequest paramInneractiveAdRequest, e parame, s params, a.a parama, a.b paramb) {
    String str1;
    this.a = paramInneractiveAdRequest;
    this.b = (Response)parame;
    this.d = parama;
    this.e = paramb;
    this.k = new b(this);
    this.g = params;
    String str2 = q0.a(parame);
    if (com.fyber.inneractive.sdk.response.a.a(parame.g) == com.fyber.inneractive.sdk.response.a.RETURNED_ADTYPE_VAST) {
      str1 = "video";
    } else {
      str1 = "display";
    } 
    this.j = new com.fyber.inneractive.sdk.network.timeouts.content.a(str2, str1, (int)parame.I, parame.B, IAConfigManager.M.m, this.g);
    if (this.a == null)
      this.f = (b0)com.fyber.inneractive.sdk.config.a.b(parame.m); 
    try {
      return;
    } finally {
      str1 = null;
      IAlog.e("Failed to start ContentLoader", new Object[] { IAlog.a(this) });
      t.a((Throwable)str1, paramInneractiveAdRequest, parame);
      this.k.a();
      a(new InneractiveInfrastructureError(InneractiveErrorCode.SDK_INTERNAL_ERROR, g.CONTENT_LOADER_START_FAILED));
    } 
  }
  
  public void a(InneractiveError paramInneractiveError) {
    m.a((Runnable)new c(new d((e)this.b, this.a, f(), this.g.c()), paramInneractiveError));
  }
  
  public void a(InneractiveInfrastructureError paramInneractiveInfrastructureError) {
    com.fyber.inneractive.sdk.network.timeouts.content.a a1;
    IAlog.a("%s : IAAdContentLoaderImpl : Handle Retry for error: %s", new Object[] { IAlog.a(this), paramInneractiveInfrastructureError.getErrorCode().toString() });
    this.k.b();
    boolean bool = i();
    IAlog.a("%s : IAAdContentLoaderImpl : should retry: %s", new Object[] { IAlog.a(this), Boolean.valueOf(bool) });
    JSONArray jSONArray = null;
    if (bool) {
      boolean bool1;
      Content content = this.c;
      if (content != null) {
        content.a();
        this.c = null;
      } 
      a1 = this.j;
      if (a1 != null) {
        bool1 = ((com.fyber.inneractive.sdk.network.timeouts.a)a1).e;
      } else {
        bool1 = false;
      } 
      IAlog.a("%s : IAAdContentLoaderImpl : retryLoad : post load ad content retry task with delay: %d", new Object[] { IAlog.a(this), Integer.valueOf(bool1) });
      m.b.postDelayed(this.l, bool1);
      return;
    } 
    a.a a2 = this.d;
    if (a2 != null)
      a2.a((InneractiveInfrastructureError)a1); 
    a();
    InneractiveAdRequest inneractiveAdRequest = this.a;
    Response response = this.b;
    s s1 = this.g;
    if (s1 != null)
      jSONArray = s1.c(); 
    a.a(inneractiveAdRequest, (InneractiveInfrastructureError)a1, (q)this.c, (e)response, jSONArray);
  }
  
  public void b() {
    InneractiveInfrastructureError inneractiveInfrastructureError;
    IAlog.a("%s : IAAdContentLoaderImpl : onTimeout() attempt: %d timeout: %d", new Object[] { IAlog.a(this), Integer.valueOf(this.i - 1), Integer.valueOf(a(this.i - 1)) });
    a.b b1 = this.e;
    if (b1 != null)
      b1.b(); 
    if (i()) {
      inneractiveInfrastructureError = e();
    } else {
      inneractiveInfrastructureError = new InneractiveInfrastructureError(InneractiveErrorCode.IN_FLIGHT_TIMEOUT, g.NO_TIME_TO_LOAD_AD_CONTENT);
    } 
    a((InneractiveError)inneractiveInfrastructureError);
    a(inneractiveInfrastructureError);
  }
  
  public void c() {
    IAlog.a("%s : IAAdContentLoaderImpl : onRetry() attempt: %d timeout: %d", new Object[] { IAlog.a(this), Integer.valueOf(this.i - 1), Integer.valueOf(a(this.i - 1)) });
    a.b b1 = this.e;
    if (b1 != null)
      b1.c(); 
    k();
  }
  
  public void d() {
    IAlog.a("%s: IAAdContentLoaderImpl : cancel load ad content retry task", new Object[] { IAlog.a(this) });
    m.b.removeCallbacks(this.l);
  }
  
  public InneractiveInfrastructureError e() {
    String str;
    g g = g.WEBVIEW_LOAD_TIMEOUT;
    if (com.fyber.inneractive.sdk.response.a.a(((e)this.b).g) == com.fyber.inneractive.sdk.response.a.RETURNED_ADTYPE_VAST) {
      str = "video";
    } else {
      str = "display";
    } 
    if ("video".equalsIgnoreCase(str))
      g = g.VIDEO_AD_LOAD_TIMEOUT; 
    return new InneractiveInfrastructureError(InneractiveErrorCode.LOAD_TIMEOUT, g);
  }
  
  public abstract String f();
  
  public b0 g() {
    InneractiveAdRequest inneractiveAdRequest = this.a;
    return (inneractiveAdRequest == null) ? this.f : inneractiveAdRequest.getSelectedUnitConfig();
  }
  
  public void h() {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Lcom/fyber/inneractive/sdk/flow/b;
    //   4: invokevirtual a : ()V
    //   7: aload_0
    //   8: getfield a : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 24
    //   16: aload_1
    //   17: getfield b : Ljava/lang/String;
    //   20: astore_1
    //   21: goto -> 47
    //   24: aload_0
    //   25: getfield b : Lcom/fyber/inneractive/sdk/response/e;
    //   28: astore_1
    //   29: aload_1
    //   30: ifnull -> 45
    //   33: aload_1
    //   34: getfield z : Ljava/lang/String;
    //   37: astore_1
    //   38: aload_1
    //   39: ifnull -> 45
    //   42: goto -> 47
    //   45: aconst_null
    //   46: astore_1
    //   47: getstatic com/fyber/inneractive/sdk/metrics/c.d : Lcom/fyber/inneractive/sdk/metrics/c;
    //   50: aload_1
    //   51: invokevirtual a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/metrics/f;
    //   54: invokeinterface i : ()Ljava/lang/Long;
    //   59: pop
    //   60: aload_0
    //   61: getfield c : Lcom/fyber/inneractive/sdk/flow/q;
    //   64: astore_2
    //   65: aload_2
    //   66: ifnull -> 74
    //   69: aload_2
    //   70: aload_1
    //   71: invokevirtual a : (Ljava/lang/String;)V
    //   74: aload_0
    //   75: getfield d : Lcom/fyber/inneractive/sdk/interfaces/a$a;
    //   78: astore_1
    //   79: aload_1
    //   80: ifnull -> 93
    //   83: aload_1
    //   84: aload_0
    //   85: getfield a : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   88: invokeinterface a : (Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;)V
    //   93: return
  }
  
  public boolean i() {
    byte b1;
    com.fyber.inneractive.sdk.network.timeouts.content.a a1 = this.j;
    boolean bool = false;
    if (a1 != null) {
      b1 = ((com.fyber.inneractive.sdk.network.timeouts.a)a1).a;
    } else {
      b1 = 0;
    } 
    if (this.i <= b1)
      bool = true; 
    return bool;
  }
  
  public abstract void j();
  
  public final void k() {
    int i = this.i;
    this.i = i + 1;
    i = a(i);
    IAlog.a("%s : IAAdContentLoaderImpl : Start timeout: %d, attempt number: %d", new Object[] { IAlog.a(this), Integer.valueOf(i), Integer.valueOf(this.i - 1) });
    b b1 = this.k;
    if (b1.a == null) {
      HandlerThread handlerThread = new HandlerThread("TimeoutHandlerThread");
      handlerThread.start();
      b1.a = new Handler(handlerThread.getLooper());
    } 
    b1.a.postDelayed(b1.d, i);
    j();
  }
  
  public class a implements Runnable {
    public a(h this$0) {}
    
    public void run() {
      h h1 = this.a;
      h1.getClass();
      IAlog.a("%s : IAAdContentLoaderImpl : retry load ad task started execution", new Object[] { IAlog.a(h1) });
      this.a.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */