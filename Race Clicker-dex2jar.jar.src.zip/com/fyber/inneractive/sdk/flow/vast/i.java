package com.fyber.inneractive.sdk.flow.vast;

public class i extends Error {
  public i(String paramString1, String paramString2) {
    super(paramString1, new Throwable(paramString2));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */