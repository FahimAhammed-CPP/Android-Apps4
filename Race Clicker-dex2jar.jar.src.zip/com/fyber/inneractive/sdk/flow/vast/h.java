package com.fyber.inneractive.sdk.flow.vast;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.model.vast.o;
import com.fyber.inneractive.sdk.model.vast.q;
import java.util.Comparator;

public class h implements Comparator<o> {
  public int a;
  
  public int b;
  
  public int c;
  
  public h(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  public final Integer a(String paramString) {
    q q = q.a(paramString);
    return (q == q.MEDIA_TYPE_MP4) ? Integer.valueOf(3) : ((q == q.MEDIA_TYPE_3GPP) ? Integer.valueOf(2) : ((q == q.MEDIA_TYPE_WEBM) ? Integer.valueOf(1) : Integer.valueOf(-1)));
  }
  
  public int compare(Object paramObject1, Object paramObject2) {
    int m;
    o o = (o)paramObject1;
    paramObject1 = paramObject2;
    if (TextUtils.equals("VPAID", ((o)paramObject1).f))
      return -1; 
    if (TextUtils.equals("VPAID", o.f))
      return 1; 
    paramObject2 = o.e;
    boolean bool = false;
    if (paramObject2 == null) {
      i = 0;
    } else {
      i = paramObject2.intValue();
    } 
    paramObject2 = ((o)paramObject1).e;
    if (paramObject2 == null) {
      j = 0;
    } else {
      j = paramObject2.intValue();
    } 
    int k = this.a;
    if (j > k && i <= k)
      return -1; 
    if (i > k && j <= k)
      return 1; 
    k = a(((o)paramObject1).d).compareTo(a(o.d));
    if (k != 0)
      return k; 
    if (i < j)
      return 1; 
    if (i > j)
      return -1; 
    paramObject2 = o.b;
    if (paramObject2 == null) {
      i = 0;
    } else {
      i = paramObject2.intValue();
    } 
    paramObject2 = o.c;
    if (paramObject2 == null) {
      j = 0;
    } else {
      j = paramObject2.intValue();
    } 
    paramObject2 = ((o)paramObject1).b;
    if (paramObject2 == null) {
      k = 0;
    } else {
      k = paramObject2.intValue();
    } 
    paramObject1 = ((o)paramObject1).c;
    if (paramObject1 == null) {
      m = 0;
    } else {
      m = paramObject1.intValue();
    } 
    int n = this.b * this.c;
    int j = Math.abs(i * j - n);
    k = Math.abs(k * m - n);
    if (j < k)
      return -1; 
    int i = bool;
    return (j > k) ? 1 : i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */