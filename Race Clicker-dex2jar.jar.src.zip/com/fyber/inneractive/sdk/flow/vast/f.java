package com.fyber.inneractive.sdk.flow.vast;

import com.fyber.inneractive.sdk.model.vast.c;
import com.fyber.inneractive.sdk.model.vast.h;
import java.util.Comparator;

public class f implements Comparator<c> {
  public int a;
  
  public int b;
  
  public f(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public Integer a(c paramc) {
    h h = paramc.a;
    return (h == h.Html) ? Integer.valueOf(3) : ((h == h.Iframe) ? Integer.valueOf(2) : ((h == h.Static) ? Integer.valueOf(1) : Integer.valueOf(-1)));
  }
  
  public int compare(Object paramObject1, Object paramObject2) {
    paramObject1 = paramObject1;
    paramObject2 = paramObject2;
    int m = ((c)paramObject1).c;
    int n = ((c)paramObject1).d;
    int i = ((c)paramObject2).c;
    int j = ((c)paramObject2).d;
    int k = this.a * this.b;
    m = Math.abs(m * n - k);
    i = Math.abs(i * j - k);
    if (m < i)
      return -1; 
    if (m <= i) {
      float f1 = Float.valueOf(this.a).floatValue() / Float.valueOf(this.b).floatValue();
      float f3 = Float.valueOf(((c)paramObject1).c).floatValue() / Float.valueOf(((c)paramObject1).d).floatValue();
      float f2 = Float.valueOf(((c)paramObject2).c).floatValue() / Float.valueOf(((c)paramObject2).d).floatValue();
      f3 = Math.abs(f1 - f3);
      f1 = Math.abs(f1 - f2);
      if (f3 < f1)
        return -1; 
      if (f3 <= f1) {
        i = a((c)paramObject2).compareTo(a((c)paramObject1));
        return (i != 0) ? i : 0;
      } 
    } 
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */