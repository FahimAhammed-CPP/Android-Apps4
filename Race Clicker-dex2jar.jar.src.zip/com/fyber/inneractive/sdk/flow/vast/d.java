package com.fyber.inneractive.sdk.flow.vast;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.measurement.f;
import com.fyber.inneractive.sdk.model.vast.b;
import com.fyber.inneractive.sdk.model.vast.c;
import com.fyber.inneractive.sdk.model.vast.e;
import com.fyber.inneractive.sdk.model.vast.f;
import com.fyber.inneractive.sdk.model.vast.g;
import com.fyber.inneractive.sdk.model.vast.h;
import com.fyber.inneractive.sdk.model.vast.i;
import com.fyber.inneractive.sdk.model.vast.j;
import com.fyber.inneractive.sdk.model.vast.o;
import com.fyber.inneractive.sdk.model.vast.s;
import com.fyber.inneractive.sdk.model.vast.t;
import com.fyber.inneractive.sdk.model.vast.v;
import com.fyber.inneractive.sdk.response.i;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.x;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class d {
  public int a = -1;
  
  public int b = -1;
  
  public int c = -1;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public Map<o, g> f = new LinkedHashMap<o, g>();
  
  public List<g> g = new ArrayList<g>();
  
  public final List<g> h = new ArrayList<g>();
  
  public final List<f> i = new ArrayList<f>();
  
  public b a(e parame, List<e> paramList, String paramString) throws i {
    IAlog.a("%sprocess started", new Object[] { "VastProcessor: " });
    if (parame != null && parame.c != null) {
      int i = l.e();
      int j = l.d();
      b b = new b(new h(this.c, i, j), new f(i, j));
      b.a = paramString;
      List list = ((f)parame.c).c;
      if (list != null && !list.isEmpty()) {
        if (paramList != null) {
          Iterator<e> iterator = paramList.iterator();
          while (iterator.hasNext()) {
            v v = ((e)iterator.next()).b;
            if (v != null)
              a(b, (f)v, true); 
          } 
        } 
        a(b, (f)parame.c, false);
        if (b.d.size() == 0) {
          if (this.f.size() == 0)
            throw new i("ErrorNoMediaFiles", "No media files exist after merge"); 
          throw new i("ErrorNoCompatibleMediaFile", "No compatible media files after filtering");
        } 
        if (IAlog.a == 2) {
          IAlog.d("%sLogging merged model media files: ", new Object[] { "VastProcessor: " });
          Iterator<?> iterator = (new ArrayList(b.d)).iterator();
          for (i = 0; iterator.hasNext(); i++) {
            IAlog.d("%s(%d) %s", new Object[] { "VastProcessor: ", Integer.valueOf(i), iterator.next() });
          } 
        } 
        if (IAlog.a == 2) {
          IAlog.d("%sLogging merged model companion ads: ", new Object[] { "VastProcessor: " });
          ArrayList arrayList = new ArrayList(b.g);
          if (arrayList.size() > 0) {
            Iterator<c> iterator = arrayList.iterator();
            for (i = 0; iterator.hasNext(); i++) {
              IAlog.d("%s(%d) %s", new Object[] { "VastProcessor: ", Integer.valueOf(i), ((c)iterator.next()).a() });
            } 
          } else {
            IAlog.d("%sNo companion ads found!", new Object[] { "VastProcessor: " });
          } 
        } 
        return b;
      } 
      throw new i("ErrorNoMediaFiles", "Empty inline with no creatives");
    } 
    IAlog.a("%sno inline found", new Object[] { "VastProcessor: " });
    throw new i("ErrorNoMediaFiles", "Empty inline ad found");
  }
  
  public final void a(b paramb, f paramf, boolean paramBoolean) {
    // Byte code:
    //   0: ldc '%sprocessing ad element: %s'
    //   2: iconst_2
    //   3: anewarray java/lang/Object
    //   6: dup
    //   7: iconst_0
    //   8: ldc 'VastProcessor: '
    //   10: aastore
    //   11: dup
    //   12: iconst_1
    //   13: aload_2
    //   14: aastore
    //   15: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   18: aload_2
    //   19: getfield b : Ljava/util/List;
    //   22: astore #6
    //   24: aload #6
    //   26: ifnull -> 92
    //   29: aload #6
    //   31: invokeinterface iterator : ()Ljava/util/Iterator;
    //   36: astore #6
    //   38: aload #6
    //   40: invokeinterface hasNext : ()Z
    //   45: ifeq -> 92
    //   48: aload #6
    //   50: invokeinterface next : ()Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: astore #7
    //   60: ldc '%sadding impression url: %s'
    //   62: iconst_2
    //   63: anewarray java/lang/Object
    //   66: dup
    //   67: iconst_0
    //   68: ldc 'VastProcessor: '
    //   70: aastore
    //   71: dup
    //   72: iconst_1
    //   73: aload #7
    //   75: aastore
    //   76: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   79: aload_0
    //   80: aload_1
    //   81: getstatic com/fyber/inneractive/sdk/model/vast/t.EVENT_IMPRESSION : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   84: aload #7
    //   86: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/model/vast/t;Ljava/lang/String;)V
    //   89: goto -> 38
    //   92: aload_2
    //   93: getfield a : Ljava/lang/String;
    //   96: astore #6
    //   98: aload #6
    //   100: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   103: ifne -> 134
    //   106: ldc '%sadding error url: %s'
    //   108: iconst_2
    //   109: anewarray java/lang/Object
    //   112: dup
    //   113: iconst_0
    //   114: ldc 'VastProcessor: '
    //   116: aastore
    //   117: dup
    //   118: iconst_1
    //   119: aload #6
    //   121: aastore
    //   122: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   125: aload_1
    //   126: getstatic com/fyber/inneractive/sdk/model/vast/t.EVENT_ERROR : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   129: aload #6
    //   131: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/t;Ljava/lang/String;)V
    //   134: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   137: getfield J : Lcom/fyber/inneractive/sdk/measurement/a;
    //   140: ifnull -> 316
    //   143: aload_2
    //   144: getfield d : Ljava/util/List;
    //   147: invokeinterface iterator : ()Ljava/util/Iterator;
    //   152: astore #6
    //   154: aload #6
    //   156: invokeinterface hasNext : ()Z
    //   161: ifeq -> 316
    //   164: aload #6
    //   166: invokeinterface next : ()Ljava/lang/Object;
    //   171: checkcast com/fyber/inneractive/sdk/measurement/f
    //   174: astore #7
    //   176: aload #7
    //   178: invokevirtual b : ()Z
    //   181: ifeq -> 199
    //   184: aload_1
    //   185: getfield e : Ljava/util/List;
    //   188: aload #7
    //   190: invokeinterface add : (Ljava/lang/Object;)Z
    //   195: pop
    //   196: goto -> 154
    //   199: getstatic com/fyber/inneractive/sdk/model/vast/t.EVENT_VERIFICATION_NOT_EXECUTED : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   202: astore #8
    //   204: aload #8
    //   206: ifnull -> 258
    //   209: aload #7
    //   211: getfield c : Ljava/util/Map;
    //   214: astore #9
    //   216: aload #9
    //   218: ifnonnull -> 224
    //   221: goto -> 258
    //   224: aload #9
    //   226: aload #8
    //   228: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   233: checkcast java/util/List
    //   236: astore #9
    //   238: aload #9
    //   240: ifnonnull -> 246
    //   243: goto -> 258
    //   246: aload #9
    //   248: invokeinterface size : ()I
    //   253: istore #4
    //   255: goto -> 261
    //   258: iconst_0
    //   259: istore #4
    //   261: iload #4
    //   263: ifle -> 301
    //   266: getstatic com/fyber/inneractive/sdk/measurement/g.VERIFICATION_NOT_SUPPORTED : Lcom/fyber/inneractive/sdk/measurement/g;
    //   269: astore #9
    //   271: new com/fyber/inneractive/sdk/measurement/e
    //   274: dup
    //   275: aload #7
    //   277: aload #7
    //   279: aload #8
    //   281: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/t;)Ljava/util/List;
    //   284: aload #9
    //   286: invokespecial <init> : (Lcom/fyber/inneractive/sdk/measurement/f;Ljava/util/List;Lcom/fyber/inneractive/sdk/measurement/g;)V
    //   289: iconst_1
    //   290: anewarray com/fyber/inneractive/sdk/model/vast/t
    //   293: dup
    //   294: iconst_0
    //   295: aload #8
    //   297: aastore
    //   298: invokestatic a : (Lcom/fyber/inneractive/sdk/response/i;[Lcom/fyber/inneractive/sdk/model/vast/t;)V
    //   301: aload_0
    //   302: getfield i : Ljava/util/List;
    //   305: aload #7
    //   307: invokeinterface add : (Ljava/lang/Object;)Z
    //   312: pop
    //   313: goto -> 154
    //   316: aload_2
    //   317: getfield e : Lcom/fyber/inneractive/sdk/model/vast/l;
    //   320: astore #6
    //   322: aload #6
    //   324: ifnull -> 333
    //   327: aload_1
    //   328: aload #6
    //   330: putfield f : Lcom/fyber/inneractive/sdk/model/vast/l;
    //   333: aload_2
    //   334: getfield c : Ljava/util/List;
    //   337: invokeinterface iterator : ()Ljava/util/Iterator;
    //   342: astore #6
    //   344: aload #6
    //   346: invokeinterface hasNext : ()Z
    //   351: ifeq -> 1315
    //   354: aload #6
    //   356: invokeinterface next : ()Ljava/lang/Object;
    //   361: checkcast com/fyber/inneractive/sdk/model/vast/k
    //   364: astore #7
    //   366: aload #7
    //   368: getfield a : Lcom/fyber/inneractive/sdk/model/vast/n;
    //   371: astore #8
    //   373: aload #8
    //   375: ifnull -> 1220
    //   378: aload #8
    //   380: getfield a : Ljava/util/List;
    //   383: astore_2
    //   384: aload_2
    //   385: ifnull -> 907
    //   388: aload_1
    //   389: aload_2
    //   390: invokeinterface size : ()I
    //   395: putfield j : I
    //   398: aload_2
    //   399: invokeinterface iterator : ()Ljava/util/Iterator;
    //   404: astore #9
    //   406: aload #9
    //   408: invokeinterface hasNext : ()Z
    //   413: ifeq -> 907
    //   416: aload #9
    //   418: invokeinterface next : ()Ljava/lang/Object;
    //   423: checkcast com/fyber/inneractive/sdk/model/vast/o
    //   426: astore #10
    //   428: aload #10
    //   430: getfield a : Ljava/lang/String;
    //   433: astore_2
    //   434: getstatic com/fyber/inneractive/sdk/model/vast/p.progressive : Lcom/fyber/inneractive/sdk/model/vast/p;
    //   437: astore #11
    //   439: aload_2
    //   440: aload #11
    //   442: getfield mValue : Ljava/lang/String;
    //   445: invokevirtual equals : (Ljava/lang/Object;)Z
    //   448: ifne -> 470
    //   451: new com/fyber/inneractive/sdk/flow/vast/g
    //   454: dup
    //   455: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSUPPORTED_DELIVERY : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   458: aload #11
    //   460: getfield mValue : Ljava/lang/String;
    //   463: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   466: astore_2
    //   467: goto -> 773
    //   470: aload_0
    //   471: getfield b : I
    //   474: iconst_m1
    //   475: if_icmple -> 484
    //   478: iconst_1
    //   479: istore #4
    //   481: goto -> 487
    //   484: iconst_0
    //   485: istore #4
    //   487: iload #4
    //   489: ifeq -> 593
    //   492: aload #10
    //   494: getfield e : Ljava/lang/Integer;
    //   497: astore_2
    //   498: aload_2
    //   499: ifnull -> 593
    //   502: aload_2
    //   503: invokevirtual intValue : ()I
    //   506: ifeq -> 593
    //   509: aload #10
    //   511: getfield e : Ljava/lang/Integer;
    //   514: invokevirtual intValue : ()I
    //   517: istore #4
    //   519: aload_0
    //   520: getfield a : I
    //   523: istore #5
    //   525: iload #4
    //   527: iload #5
    //   529: if_icmpge -> 551
    //   532: new com/fyber/inneractive/sdk/flow/vast/g
    //   535: dup
    //   536: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.BITRATE_NOT_IN_RANGE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   539: iload #5
    //   541: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   544: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   547: astore_2
    //   548: goto -> 773
    //   551: aload #10
    //   553: getfield e : Ljava/lang/Integer;
    //   556: invokevirtual intValue : ()I
    //   559: istore #4
    //   561: aload_0
    //   562: getfield b : I
    //   565: istore #5
    //   567: iload #4
    //   569: iload #5
    //   571: if_icmple -> 593
    //   574: new com/fyber/inneractive/sdk/flow/vast/g
    //   577: dup
    //   578: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.BITRATE_NOT_IN_RANGE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   581: iload #5
    //   583: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   586: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   589: astore_2
    //   590: goto -> 773
    //   593: aload #10
    //   595: getfield d : Ljava/lang/String;
    //   598: invokestatic a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/model/vast/q;
    //   601: getstatic com/fyber/inneractive/sdk/model/vast/q.UNKNOWN : Lcom/fyber/inneractive/sdk/model/vast/q;
    //   604: if_acmpeq -> 613
    //   607: iconst_1
    //   608: istore #4
    //   610: goto -> 616
    //   613: iconst_0
    //   614: istore #4
    //   616: iload #4
    //   618: ifne -> 636
    //   621: new com/fyber/inneractive/sdk/flow/vast/g
    //   624: dup
    //   625: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSUPPORTED_MIME_TYPE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   628: aconst_null
    //   629: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   632: astore_2
    //   633: goto -> 773
    //   636: aload_0
    //   637: getfield d : Z
    //   640: ifeq -> 677
    //   643: aload #10
    //   645: getfield b : Ljava/lang/Integer;
    //   648: invokevirtual intValue : ()I
    //   651: aload #10
    //   653: getfield c : Ljava/lang/Integer;
    //   656: invokevirtual intValue : ()I
    //   659: if_icmplt -> 677
    //   662: new com/fyber/inneractive/sdk/flow/vast/g
    //   665: dup
    //   666: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.VERTICAL_VIDEO_EXPECTED : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   669: aconst_null
    //   670: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   673: astore_2
    //   674: goto -> 773
    //   677: aload #10
    //   679: getfield f : Ljava/lang/String;
    //   682: astore_2
    //   683: aload_2
    //   684: ifnull -> 719
    //   687: aload_0
    //   688: getfield e : Z
    //   691: ifeq -> 719
    //   694: aload_2
    //   695: ldc_w 'VPAID'
    //   698: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   701: ifeq -> 719
    //   704: new com/fyber/inneractive/sdk/flow/vast/g
    //   707: dup
    //   708: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.FILTERED_BY_APP_OR_UNIT : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   711: aconst_null
    //   712: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   715: astore_2
    //   716: goto -> 773
    //   719: aload #10
    //   721: getfield g : Ljava/lang/String;
    //   724: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   727: ifeq -> 745
    //   730: new com/fyber/inneractive/sdk/flow/vast/g
    //   733: dup
    //   734: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.NO_CONTENT : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   737: aconst_null
    //   738: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   741: astore_2
    //   742: goto -> 773
    //   745: aload #10
    //   747: getfield g : Ljava/lang/String;
    //   750: invokestatic f : (Ljava/lang/String;)Z
    //   753: ifne -> 771
    //   756: new com/fyber/inneractive/sdk/flow/vast/g
    //   759: dup
    //   760: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSECURED_VIDEO_URL : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   763: aconst_null
    //   764: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   767: astore_2
    //   768: goto -> 773
    //   771: aconst_null
    //   772: astore_2
    //   773: aload_2
    //   774: ifnull -> 852
    //   777: ldc_w '%smedia file filtered!: %s'
    //   780: iconst_2
    //   781: anewarray java/lang/Object
    //   784: dup
    //   785: iconst_0
    //   786: ldc 'VastProcessor: '
    //   788: aastore
    //   789: dup
    //   790: iconst_1
    //   791: aload #10
    //   793: aastore
    //   794: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   797: ldc_w '%s-- %s'
    //   800: iconst_2
    //   801: anewarray java/lang/Object
    //   804: dup
    //   805: iconst_0
    //   806: ldc 'VastProcessor: '
    //   808: aastore
    //   809: dup
    //   810: iconst_1
    //   811: aload #10
    //   813: aastore
    //   814: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   817: ldc_w '%s-- %s'
    //   820: iconst_2
    //   821: anewarray java/lang/Object
    //   824: dup
    //   825: iconst_0
    //   826: ldc 'VastProcessor: '
    //   828: aastore
    //   829: dup
    //   830: iconst_1
    //   831: aload_2
    //   832: aastore
    //   833: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   836: aload_0
    //   837: getfield f : Ljava/util/Map;
    //   840: aload #10
    //   842: aload_2
    //   843: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   848: pop
    //   849: goto -> 406
    //   852: ldc_w '%sadding media file: %s'
    //   855: iconst_2
    //   856: anewarray java/lang/Object
    //   859: dup
    //   860: iconst_0
    //   861: ldc 'VastProcessor: '
    //   863: aastore
    //   864: dup
    //   865: iconst_1
    //   866: aload #10
    //   868: aastore
    //   869: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   872: aload_1
    //   873: getfield d : Ljava/util/PriorityQueue;
    //   876: aload #10
    //   878: invokevirtual add : (Ljava/lang/Object;)Z
    //   881: pop
    //   882: aload_1
    //   883: getfield k : Ljava/util/List;
    //   886: aload #10
    //   888: invokeinterface add : (Ljava/lang/Object;)Z
    //   893: pop
    //   894: aload_1
    //   895: aload_1
    //   896: getfield i : I
    //   899: iconst_1
    //   900: iadd
    //   901: putfield i : I
    //   904: goto -> 406
    //   907: aload #8
    //   909: getfield d : Ljava/util/List;
    //   912: astore_2
    //   913: aload_2
    //   914: ifnull -> 957
    //   917: aload_2
    //   918: invokeinterface iterator : ()Ljava/util/Iterator;
    //   923: astore_2
    //   924: aload_2
    //   925: invokeinterface hasNext : ()Z
    //   930: ifeq -> 957
    //   933: aload_2
    //   934: invokeinterface next : ()Ljava/lang/Object;
    //   939: checkcast java/lang/String
    //   942: astore #9
    //   944: aload_0
    //   945: aload_1
    //   946: getstatic com/fyber/inneractive/sdk/model/vast/t.EVENT_CLICK : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   949: aload #9
    //   951: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/model/vast/t;Ljava/lang/String;)V
    //   954: goto -> 924
    //   957: aload #8
    //   959: getfield b : Ljava/util/List;
    //   962: astore_2
    //   963: aload_2
    //   964: ifnull -> 1097
    //   967: aload_2
    //   968: invokeinterface iterator : ()Ljava/util/Iterator;
    //   973: astore_2
    //   974: aload_2
    //   975: invokeinterface hasNext : ()Z
    //   980: ifeq -> 1097
    //   983: aload_2
    //   984: invokeinterface next : ()Ljava/lang/Object;
    //   989: checkcast com/fyber/inneractive/sdk/model/vast/s
    //   992: astore #10
    //   994: aload #10
    //   996: getfield a : Ljava/lang/String;
    //   999: invokestatic a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/model/vast/t;
    //   1002: astore #9
    //   1004: aload #9
    //   1006: getstatic com/fyber/inneractive/sdk/model/vast/t.UNKNOWN : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   1009: if_acmpeq -> 1023
    //   1012: aload_1
    //   1013: aload #9
    //   1015: aload #10
    //   1017: getfield b : Ljava/lang/String;
    //   1020: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/t;Ljava/lang/String;)V
    //   1023: aload #9
    //   1025: getstatic com/fyber/inneractive/sdk/model/vast/t.EVENT_PROGRESS : Lcom/fyber/inneractive/sdk/model/vast/t;
    //   1028: if_acmpne -> 974
    //   1031: aload #10
    //   1033: getfield b : Ljava/lang/String;
    //   1036: astore #9
    //   1038: aload #10
    //   1040: getfield c : Ljava/lang/String;
    //   1043: astore #10
    //   1045: new com/fyber/inneractive/sdk/model/vast/d
    //   1048: dup
    //   1049: aload #9
    //   1051: aload #10
    //   1053: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   1056: astore #11
    //   1058: aload #9
    //   1060: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1063: ifne -> 974
    //   1066: aload #10
    //   1068: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1071: ifne -> 974
    //   1074: aload #11
    //   1076: getfield d : I
    //   1079: ifeq -> 974
    //   1082: aload_1
    //   1083: getfield m : Ljava/util/List;
    //   1086: aload #11
    //   1088: invokeinterface add : (Ljava/lang/Object;)Z
    //   1093: pop
    //   1094: goto -> 974
    //   1097: aload #8
    //   1099: getfield c : Ljava/lang/String;
    //   1102: astore_2
    //   1103: aload_2
    //   1104: ifnull -> 1112
    //   1107: aload_1
    //   1108: aload_2
    //   1109: putfield b : Ljava/lang/String;
    //   1112: aload #8
    //   1114: getfield e : Ljava/lang/String;
    //   1117: astore_2
    //   1118: aload_2
    //   1119: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1122: ifeq -> 1128
    //   1125: goto -> 1220
    //   1128: aload_2
    //   1129: ldc_w ':'
    //   1132: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1135: astore #8
    //   1137: aload #8
    //   1139: ifnull -> 1220
    //   1142: aload #8
    //   1144: arraylength
    //   1145: iconst_3
    //   1146: if_icmple -> 1152
    //   1149: goto -> 1220
    //   1152: aload #8
    //   1154: arraylength
    //   1155: iconst_1
    //   1156: if_icmpne -> 1170
    //   1159: aload_2
    //   1160: invokestatic parseInt : (Ljava/lang/String;)I
    //   1163: pop
    //   1164: goto -> 1220
    //   1167: goto -> 1220
    //   1170: aload #8
    //   1172: arraylength
    //   1173: iconst_2
    //   1174: if_icmpne -> 1196
    //   1177: aload #8
    //   1179: iconst_1
    //   1180: aaload
    //   1181: invokestatic parseInt : (Ljava/lang/String;)I
    //   1184: pop
    //   1185: aload #8
    //   1187: iconst_0
    //   1188: aaload
    //   1189: invokestatic parseInt : (Ljava/lang/String;)I
    //   1192: pop
    //   1193: goto -> 1220
    //   1196: aload #8
    //   1198: iconst_2
    //   1199: aaload
    //   1200: invokestatic parseInt : (Ljava/lang/String;)I
    //   1203: pop
    //   1204: aload #8
    //   1206: iconst_1
    //   1207: aaload
    //   1208: invokestatic parseInt : (Ljava/lang/String;)I
    //   1211: pop
    //   1212: aload #8
    //   1214: iconst_0
    //   1215: aaload
    //   1216: invokestatic parseInt : (Ljava/lang/String;)I
    //   1219: pop
    //   1220: aload #7
    //   1222: getfield b : Ljava/util/List;
    //   1225: astore_2
    //   1226: aload_2
    //   1227: ifnull -> 344
    //   1230: aload_2
    //   1231: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1236: astore_2
    //   1237: aload_2
    //   1238: invokeinterface hasNext : ()Z
    //   1243: ifeq -> 344
    //   1246: aload_2
    //   1247: invokeinterface next : ()Ljava/lang/Object;
    //   1252: checkcast com/fyber/inneractive/sdk/model/vast/g
    //   1255: astore #7
    //   1257: aload_0
    //   1258: aload_1
    //   1259: aload #7
    //   1261: iload_3
    //   1262: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/b;Lcom/fyber/inneractive/sdk/model/vast/g;Z)V
    //   1265: goto -> 1237
    //   1268: astore #8
    //   1270: ldc_w 'Failed processing companion ad: %s error = %s'
    //   1273: iconst_2
    //   1274: anewarray java/lang/Object
    //   1277: dup
    //   1278: iconst_0
    //   1279: aload #7
    //   1281: aastore
    //   1282: dup
    //   1283: iconst_1
    //   1284: aload #8
    //   1286: invokevirtual getMessage : ()Ljava/lang/String;
    //   1289: aastore
    //   1290: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1293: aload #7
    //   1295: aload #8
    //   1297: putfield i : Lcom/fyber/inneractive/sdk/flow/vast/d$a;
    //   1300: aload_0
    //   1301: getfield g : Ljava/util/List;
    //   1304: aload #7
    //   1306: invokeinterface add : (Ljava/lang/Object;)Z
    //   1311: pop
    //   1312: goto -> 1237
    //   1315: return
    //   1316: astore_2
    //   1317: goto -> 1167
    // Exception table:
    //   from	to	target	type
    //   1159	1164	1316	java/lang/NumberFormatException
    //   1177	1193	1316	java/lang/NumberFormatException
    //   1196	1220	1316	java/lang/NumberFormatException
    //   1257	1265	1268	com/fyber/inneractive/sdk/flow/vast/d$a
  }
  
  public void a(b paramb, g paramg, boolean paramBoolean) throws a {
    List<String> list = paramg.h;
    if (list != null) {
      if (paramBoolean)
        this.h.add(paramg); 
      Iterator<String> iterator = list.iterator();
      while (iterator.hasNext()) {
        if (x.f(iterator.next()))
          continue; 
        StringBuilder stringBuilder1 = new StringBuilder("Found non secure click tracking url for companion: ");
        stringBuilder1.append(paramg);
        throw new a(this, stringBuilder1.toString(), 0);
      } 
    } 
    String str = paramg.g;
    if (x.f(str)) {
      boolean bool1;
      Integer integer1 = paramg.a;
      Integer integer2 = paramg.b;
      boolean bool2 = true;
      if (integer1 != null && integer2 != null && integer1.intValue() >= 100 && integer2.intValue() >= 100) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        StringBuilder stringBuilder2;
        String str1 = paramg.c;
        List<s> list1 = paramg.j;
        if (list1 != null)
          for (s s : list1) {
            if (x.f(s.b))
              continue; 
            stringBuilder2 = new StringBuilder("Found non secure tracking event: ");
            stringBuilder2.append(s);
            throw new a(this, stringBuilder2.toString(), 0);
          }  
        bool1 = bool2;
        if (TextUtils.isEmpty(paramg.e)) {
          bool1 = bool2;
          if (TextUtils.isEmpty(paramg.f))
            if (paramg.d != null) {
              bool1 = bool2;
            } else {
              bool1 = false;
            }  
        } 
        if (bool1) {
          String str2 = paramg.e;
          if (x.f(str2)) {
            j j = paramg.d;
            if (j != null) {
              i i = i.a(j.a);
              if (i != null) {
                a((b)stringBuilder2, h.Static, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, j.b, i);
              } else {
                stringBuilder2 = new StringBuilder("Found invalid creative type:");
                stringBuilder2.append(j.a);
                throw new a(this, stringBuilder2.toString(), 0);
              } 
            } 
            if (!TextUtils.isEmpty(str2))
              a((b)stringBuilder2, h.Iframe, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, str2, null); 
            String str3 = paramg.f;
            if (!TextUtils.isEmpty(str3))
              a((b)stringBuilder2, h.Html, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, str3, null); 
            return;
          } 
          stringBuilder2 = new StringBuilder("Found non secure iframe url:");
          stringBuilder2.append(str2);
          throw new a(this, stringBuilder2.toString(), 0);
        } 
        throw new a(this, "None sources of companion avaliable", 0);
      } 
      StringBuilder stringBuilder1 = new StringBuilder("Incompatible size: ");
      stringBuilder1.append(integer1);
      stringBuilder1.append(",");
      stringBuilder1.append(integer2);
      throw new a(this, stringBuilder1.toString(), 16);
    } 
    StringBuilder stringBuilder = new StringBuilder("Found non secure click through url: ");
    stringBuilder.append(str);
    throw new a(this, stringBuilder.toString(), 0);
  }
  
  public void a(b paramb, h paramh, boolean paramBoolean, int paramInt1, int paramInt2, String paramString1, String paramString2, List<String> paramList, List<s> paramList1, String paramString3, i parami) {
    c c = new c(paramh, paramInt1, paramInt2, paramString1);
    c.g = paramString2;
    if (paramList1 != null)
      for (s s : paramList1)
        c.a(t.a(s.a), s.b);  
    if (paramList != null)
      for (String paramString2 : paramList)
        c.a(t.EVENT_CLICK, paramString2);  
    a(c, paramBoolean);
    c.f = paramString3;
    c.b = parami;
    paramb.g.add(c);
    paramb.l.add(c);
  }
  
  public final void a(i parami, t paramt, String paramString) throws i {
    if (x.f(paramString)) {
      ((b)parami).a(paramt, paramString);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("found unsecure tracking event: ");
    stringBuilder.append(paramt.e());
    throw new i("VastErrorUnsecure", stringBuilder.toString());
  }
  
  public boolean a(c paramc, boolean paramBoolean) {
    boolean bool2 = this.h.isEmpty();
    boolean bool1 = false;
    boolean bool = false;
    if (!bool2) {
      g g;
      if (paramBoolean) {
        List<g> list = this.h;
        g = list.remove(list.size() - 1);
      } else {
        g = null;
      } 
      String str = paramc.e;
      Iterator<g> iterator = this.h.iterator();
      paramBoolean = bool;
      while (iterator.hasNext()) {
        g g1 = iterator.next();
        str1 = g1.c;
        if ((str != null && str.equals(str1)) || (str1 == null && paramc.c == g1.a.intValue() && paramc.d == g1.b.intValue())) {
          List list = g1.h;
          if (list != null)
            for (String str1 : list) {
              if (x.f(str1))
                paramc.a(t.EVENT_CLICK, str1); 
            }  
          paramBoolean = true;
        } 
      } 
      bool1 = paramBoolean;
      if (g != null) {
        this.h.add(g);
        bool1 = paramBoolean;
      } 
    } 
    return bool1;
  }
  
  public class a extends Exception {
    public int a;
    
    public a(d this$0, String param1String, int param1Int) {
      super(param1String);
      this.a = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */