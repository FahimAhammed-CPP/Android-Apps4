package com.fyber.inneractive.sdk.flow.vast;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.network.s;

public class c extends e {
  public boolean h = false;
  
  public boolean i = false;
  
  public c(com.fyber.inneractive.sdk.player.controller.c paramc) {
    super(paramc);
  }
  
  public void a(s.a parama) {
    String str = this.e;
    if (!TextUtils.isEmpty(str))
      parama.a(new Object[] { "version", str }); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */