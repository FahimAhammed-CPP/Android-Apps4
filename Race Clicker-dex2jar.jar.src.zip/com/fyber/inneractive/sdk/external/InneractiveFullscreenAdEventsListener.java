package com.fyber.inneractive.sdk.external;

public interface InneractiveFullscreenAdEventsListener extends InneractiveUnitController.EventsListener {
  void onAdClicked(InneractiveAdSpot paramInneractiveAdSpot);
  
  void onAdDismissed(InneractiveAdSpot paramInneractiveAdSpot);
  
  void onAdEnteredErrorState(InneractiveAdSpot paramInneractiveAdSpot, InneractiveUnitController.AdDisplayError paramAdDisplayError);
  
  void onAdImpression(InneractiveAdSpot paramInneractiveAdSpot);
  
  void onAdWillCloseInternalBrowser(InneractiveAdSpot paramInneractiveAdSpot);
  
  void onAdWillOpenExternalApp(InneractiveAdSpot paramInneractiveAdSpot);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\external\InneractiveFullscreenAdEventsListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */