package com.fyber.inneractive.sdk.external;

public interface InneractiveUnitController<EL extends InneractiveUnitController.EventsListener> {
  void addContentController(InneractiveContentController paramInneractiveContentController);
  
  void destroy();
  
  InneractiveAdSpot getAdSpot();
  
  EL getEventsListener();
  
  InneractiveContentController getSelectedContentController();
  
  void setEventsListener(EL paramEL);
  
  public static class AdDisplayError extends Exception {
    public AdDisplayError() {}
    
    public AdDisplayError(String param1String) {
      super(param1String);
    }
    
    public AdDisplayError(String param1String, Throwable param1Throwable) {
      super(param1String, param1Throwable);
    }
    
    public AdDisplayError(String param1String, Throwable param1Throwable, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1String, param1Throwable, param1Boolean1, param1Boolean2);
    }
    
    public AdDisplayError(Throwable param1Throwable) {
      super(param1Throwable);
    }
  }
  
  public static interface EventsListener {
    void onAdClicked(InneractiveAdSpot param1InneractiveAdSpot);
    
    void onAdEnteredErrorState(InneractiveAdSpot param1InneractiveAdSpot, InneractiveUnitController.AdDisplayError param1AdDisplayError);
    
    void onAdImpression(InneractiveAdSpot param1InneractiveAdSpot);
    
    void onAdWillCloseInternalBrowser(InneractiveAdSpot param1InneractiveAdSpot);
    
    void onAdWillOpenExternalApp(InneractiveAdSpot param1InneractiveAdSpot);
  }
  
  public static abstract class EventsListenerAdapter implements EventsListener {
    public void onAdClicked(InneractiveAdSpot param1InneractiveAdSpot) {}
    
    public void onAdImpression(InneractiveAdSpot param1InneractiveAdSpot) {}
    
    public void onAdWillCloseInternalBrowser(InneractiveAdSpot param1InneractiveAdSpot) {}
    
    public void onAdWillOpenExternalApp(InneractiveAdSpot param1InneractiveAdSpot) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\external\InneractiveUnitController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */