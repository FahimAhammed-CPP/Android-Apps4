package com.fyber.inneractive.sdk.ignite;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceAPI;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceCallback;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.global.features.i;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.flow.p;
import com.fyber.inneractive.sdk.network.q;
import com.fyber.inneractive.sdk.network.s;
import com.fyber.inneractive.sdk.network.s0;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.m;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

public class c implements ServiceConnection {
  public Context a;
  
  public IIgniteServiceAPI b;
  
  public String c;
  
  public String d;
  
  public String e;
  
  public String f;
  
  public final Bundle g = new Bundle();
  
  public g h;
  
  public final List<n> i = new CopyOnWriteArrayList<n>();
  
  public boolean j = false;
  
  public boolean k = false;
  
  public boolean l = false;
  
  public long m = 0L;
  
  public final Object n = new Object();
  
  public boolean o = false;
  
  public long p;
  
  public Runnable q;
  
  public boolean r = false;
  
  public h s;
  
  public s t;
  
  public c() {
    h();
  }
  
  public void a() {
    if (e() && !TextUtils.isEmpty(this.e) && !TextUtils.isEmpty(this.f) && !this.r)
      try {
        this.r = true;
        this.g.putInt("sdkFlowTypeKey", 1);
        this.b.authenticate(this.e, this.f, this.g, (IIgniteServiceCallback)this.h.b);
        return;
      } catch (RemoteException remoteException) {
        this.r = false;
        IAlog.a("Failed to authenticate ignite", new Object[0]);
      }  
  }
  
  public void a(s params) {
    this.t = params;
    if (((i)params.a(i.class)).a("enable", false)) {
      String str = g();
      this.c = str;
      if ((TextUtils.isEmpty(str) ^ true) != 0)
        c(); 
      int i = IAConfigManager.M.w.a.b.a("igniteInstallTimeOutInSeconds", 15, 1);
      this.p = TimeUnit.SECONDS.toMillis(i);
    } 
  }
  
  public void a(h paramh) {
    this.s = paramh;
    if (!e()) {
      c();
      return;
    } 
    if (!this.l || f())
      a(); 
  }
  
  public void a(i parami, String paramString) {
    if (!this.j) {
      this.j = true;
      s.a a = new s.a(q.IGNITE_FLOW_FAILED_TO_START, null, null, null);
      JSONObject jSONObject = new JSONObject();
      String str = parami.e();
      try {
        jSONObject.put("error_code", str);
      } catch (Exception exception) {
        IAlog.e("Got exception adding param to json object: %s, %s", new Object[] { "error_code", str });
      } 
      if (!TextUtils.isEmpty(paramString))
        try {
          jSONObject.put("message", paramString);
        } catch (Exception exception) {
          IAlog.e("Got exception adding param to json object: %s, %s", new Object[] { "message", paramString });
        }  
      a.f.put(jSONObject);
      a.a(null);
    } 
  }
  
  public void a(n paramn) {
    this.i.add(paramn);
  }
  
  public void a(String paramString, d paramd) {
    if (!TextUtils.isEmpty(paramString)) {
      IAlog.a("Starting install timeout with %d", new Object[] { Long.valueOf(this.p) });
      e e = new e(this);
      this.q = e;
      m.b.postDelayed(e, this.p);
      if (d() && !f())
        try {
          JSONObject jSONObject1 = new JSONObject();
          JSONObject jSONObject2 = new JSONObject();
          jSONObject2.put("packageName", paramString);
          jSONObject1.put("data", jSONObject2);
          IIgniteServiceAPI iIgniteServiceAPI = this.b;
          String str = jSONObject1.toString();
          Bundle bundle1 = this.g;
          Bundle bundle2 = new Bundle();
          g g1 = this.h;
          b b = new b(this, paramd);
          g1.getClass();
          iIgniteServiceAPI.install(str, bundle1, bundle2, (IIgniteServiceCallback)new o(g1.a, b));
          return;
        } catch (Exception exception) {
          IAlog.a("Failed to install app", new Object[0]);
          return;
        }  
      for (n n : this.i) {
        if (n != null) {
          i i;
          if (f()) {
            i = i.SESSION_EXPIRED;
          } else {
            i = i.NOT_CONNECTED;
          } 
          n.b(null, i.e(), null);
        } 
      } 
    } 
  }
  
  public final boolean a(Exception paramException) {
    return !(paramException instanceof s0 && ((s0)paramException).a == 204);
  }
  
  public void b() {
    Runnable runnable = this.q;
    if (runnable != null) {
      m.b.removeCallbacks(runnable);
      this.q = null;
    } 
  }
  
  public void c() {
    if (g() == null) {
      h h1 = this.s;
      if (h1 != null) {
        h1.a();
        this.s = null;
        return;
      } 
    } 
    if (!TextUtils.isEmpty(this.c) && !e())
      m.a(new a(this, this)); 
  }
  
  public boolean d() {
    return (e() && this.l);
  }
  
  public boolean e() {
    if (this.k) {
      IIgniteServiceAPI iIgniteServiceAPI = this.b;
      if (iIgniteServiceAPI != null && iIgniteServiceAPI.asBinder().isBinderAlive())
        return true; 
    } 
    return false;
  }
  
  public final boolean f() {
    return (this.m > 0L && TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()) > this.m);
  }
  
  public final String g() {
    Intent intent = new Intent("com.digitalturbine.ignite.cl.IgniteRemoteService");
    Context context = this.a;
    if (context != null) {
      List list = context.getPackageManager().queryIntentServices(intent, 0);
      if (list != null && list.size() > 0)
        return ((ResolveInfo)list.get(0)).serviceInfo.packageName; 
    } 
    return null;
  }
  
  public final void h() {
    this.h = new g(new c(this));
  }
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    // Byte code:
    //   0: ldc_w 'onServiceConnected'
    //   3: iconst_0
    //   4: anewarray java/lang/Object
    //   7: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   10: aload_0
    //   11: aload_2
    //   12: invokestatic asInterface : (Landroid/os/IBinder;)Lcom/digitalturbine/ignite/cl/aidl/IIgniteServiceAPI;
    //   15: putfield b : Lcom/digitalturbine/ignite/cl/aidl/IIgniteServiceAPI;
    //   18: aload_0
    //   19: iconst_1
    //   20: putfield k : Z
    //   23: aload_0
    //   24: invokevirtual e : ()Z
    //   27: istore_3
    //   28: aconst_null
    //   29: astore_2
    //   30: iload_3
    //   31: ifeq -> 76
    //   34: new org/json/JSONObject
    //   37: dup
    //   38: aload_0
    //   39: getfield b : Lcom/digitalturbine/ignite/cl/aidl/IIgniteServiceAPI;
    //   42: invokeinterface version : ()Ljava/lang/String;
    //   47: invokespecial <init> : (Ljava/lang/String;)V
    //   50: ldc_w 'data'
    //   53: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   56: ldc_w 'igniteVersion'
    //   59: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   62: astore_1
    //   63: goto -> 78
    //   66: ldc_w 'Failed to resolve ignite version'
    //   69: iconst_0
    //   70: anewarray java/lang/Object
    //   73: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   76: aconst_null
    //   77: astore_1
    //   78: aload_0
    //   79: aload_1
    //   80: putfield d : Ljava/lang/String;
    //   83: aload_0
    //   84: getfield o : Z
    //   87: ifeq -> 95
    //   90: aload_0
    //   91: invokevirtual a : ()V
    //   94: return
    //   95: aload_0
    //   96: iconst_1
    //   97: putfield o : Z
    //   100: invokestatic newBuilder : ()Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest$a;
    //   103: astore #4
    //   105: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   108: getfield c : Ljava/lang/String;
    //   111: astore_1
    //   112: aload #4
    //   114: invokevirtual c : ()V
    //   117: aload #4
    //   119: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   122: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   125: aload_1
    //   126: invokestatic access$100 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   129: getstatic com/fyber/inneractive/sdk/util/l.a : Landroid/app/Application;
    //   132: invokevirtual getPackageName : ()Ljava/lang/String;
    //   135: astore_1
    //   136: aload #4
    //   138: invokevirtual c : ()V
    //   141: aload #4
    //   143: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   146: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   149: aload_1
    //   150: invokestatic access$400 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   153: invokestatic getVersion : ()Ljava/lang/String;
    //   156: astore_1
    //   157: aload #4
    //   159: invokevirtual c : ()V
    //   162: aload #4
    //   164: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   167: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   170: aload_1
    //   171: invokestatic access$1600 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   174: aload_0
    //   175: getfield c : Ljava/lang/String;
    //   178: astore_1
    //   179: aload #4
    //   181: invokevirtual c : ()V
    //   184: aload #4
    //   186: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   189: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   192: aload_1
    //   193: invokestatic access$1000 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   196: aload_0
    //   197: getfield c : Ljava/lang/String;
    //   200: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   203: ifne -> 389
    //   206: aload_0
    //   207: getfield a : Landroid/content/Context;
    //   210: astore_1
    //   211: aload_1
    //   212: ifnull -> 389
    //   215: aload_1
    //   216: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   219: aload_0
    //   220: getfield c : Ljava/lang/String;
    //   223: iconst_0
    //   224: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   227: getfield versionName : Ljava/lang/String;
    //   230: astore_1
    //   231: goto -> 247
    //   234: ldc_w 'Failed to resolve ignite version'
    //   237: iconst_0
    //   238: anewarray java/lang/Object
    //   241: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   244: goto -> 389
    //   247: aload #4
    //   249: invokevirtual c : ()V
    //   252: aload #4
    //   254: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   257: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   260: aload_1
    //   261: invokestatic access$1300 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   264: aload_0
    //   265: getfield a : Landroid/content/Context;
    //   268: invokestatic b : (Landroid/content/Context;)Ljava/lang/String;
    //   271: astore_1
    //   272: aload #4
    //   274: invokevirtual c : ()V
    //   277: aload #4
    //   279: getfield b : Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   282: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   285: aload_1
    //   286: invokestatic access$700 : (Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;Ljava/lang/String;)V
    //   289: aload #4
    //   291: invokevirtual a : ()Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;
    //   294: checkcast com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   297: invokevirtual toByteArray : ()[B
    //   300: astore_1
    //   301: goto -> 316
    //   304: ldc_w 'Failed to build ignite request'
    //   307: iconst_0
    //   308: anewarray java/lang/Object
    //   311: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   314: aload_2
    //   315: astore_1
    //   316: aload_1
    //   317: ifnull -> 376
    //   320: new com/fyber/inneractive/sdk/ignite/d
    //   323: dup
    //   324: aload_0
    //   325: invokespecial <init> : (Lcom/fyber/inneractive/sdk/ignite/c;)V
    //   328: astore_2
    //   329: aload_0
    //   330: getfield t : Lcom/fyber/inneractive/sdk/config/global/s;
    //   333: astore #4
    //   335: new com/fyber/inneractive/sdk/network/k0
    //   338: dup
    //   339: aload_2
    //   340: aload_1
    //   341: invokestatic a : ()Lcom/fyber/inneractive/sdk/network/x;
    //   344: invokevirtual b : ()Lcom/fyber/inneractive/sdk/network/g;
    //   347: aload #4
    //   349: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/w;[BLcom/fyber/inneractive/sdk/network/g;Lcom/fyber/inneractive/sdk/config/global/s;)V
    //   352: astore_1
    //   353: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   356: getfield s : Lcom/fyber/inneractive/sdk/network/y;
    //   359: getfield a : Ljava/util/concurrent/BlockingQueue;
    //   362: aload_1
    //   363: invokeinterface offer : (Ljava/lang/Object;)Z
    //   368: pop
    //   369: aload_1
    //   370: getstatic com/fyber/inneractive/sdk/network/q0.QUEUED : Lcom/fyber/inneractive/sdk/network/q0;
    //   373: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/q0;)V
    //   376: return
    //   377: astore_1
    //   378: goto -> 66
    //   381: astore_1
    //   382: goto -> 304
    //   385: astore_1
    //   386: goto -> 234
    //   389: aconst_null
    //   390: astore_1
    //   391: goto -> 247
    // Exception table:
    //   from	to	target	type
    //   34	63	377	java/lang/Exception
    //   100	211	381	finally
    //   215	231	385	java/lang/Exception
    //   215	231	381	finally
    //   234	244	381	finally
    //   247	301	381	finally
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    IAlog.a("onServiceDisconnected", new Object[0]);
    this.k = false;
    this.m = 0L;
    h h1 = this.s;
    if (h1 != null) {
      h1.a();
      this.s = null;
    } 
  }
  
  public class a implements Runnable {
    public a(c this$0, ServiceConnection param1ServiceConnection) {}
    
    public void run() {
      synchronized (this.b.n) {
        Intent intent = new Intent();
        intent.setClassName(this.b.c, "com.digitalturbine.ignite.cl.IgniteRemoteService");
        Context context = this.b.a;
        if (context != null)
          context.bindService(intent, this.a, 1); 
        return;
      } 
    }
  }
  
  public class b implements g.a {
    public b(c this$0, c.d param1d) {}
  }
  
  public class c implements n {
    public c(c this$0) {}
    
    public void a(String param1String) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.a(param1String); 
      } 
    }
    
    public void a(String param1String, int param1Int, double param1Double) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.a(param1String, param1Int, param1Double); 
      } 
    }
    
    public void a(String param1String1, String param1String2) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.a(param1String1, param1String2); 
      } 
    }
    
    public void a(String param1String1, String param1String2, String param1String3) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.a(param1String1, param1String2, param1String3); 
      } 
    }
    
    public void b(String param1String) {
      this.a.a(i.FAILED_TO_AUTHENTICATE, param1String);
      c.b(this.a, false);
      h h = this.a.s;
      if (h != null) {
        h.a();
        this.a.s = null;
      } 
    }
    
    public void b(String param1String1, String param1String2, String param1String3) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.b(param1String1, param1String2, param1String3); 
      } 
    }
    
    public void c(String param1String) {
      for (n n1 : this.a.i) {
        if (n1 != null)
          n1.c(param1String); 
      } 
    }
    
    public void d(String param1String) {
      // Byte code:
      //   0: aload_1
      //   1: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   4: ifne -> 227
      //   7: ldc 'ignite authenticated successfully'
      //   9: iconst_0
      //   10: anewarray java/lang/Object
      //   13: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   16: aload_0
      //   17: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   20: getfield g : Landroid/os/Bundle;
      //   23: ldc 'clientToken'
      //   25: aload_1
      //   26: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   29: aload_0
      //   30: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   33: iconst_1
      //   34: invokestatic a : (Lcom/fyber/inneractive/sdk/ignite/c;Z)Z
      //   37: pop
      //   38: aload_0
      //   39: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   42: astore #6
      //   44: aload #6
      //   46: invokevirtual getClass : ()Ljava/lang/Class;
      //   49: pop
      //   50: aload_1
      //   51: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   54: istore_2
      //   55: ldc ''
      //   57: astore #5
      //   59: iload_2
      //   60: ifne -> 98
      //   63: new java/lang/String
      //   66: dup
      //   67: aload_1
      //   68: ldc '\.'
      //   70: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
      //   73: iconst_1
      //   74: aaload
      //   75: bipush #8
      //   77: invokestatic decode : (Ljava/lang/String;I)[B
      //   80: ldc 'UTF-8'
      //   82: invokespecial <init> : ([BLjava/lang/String;)V
      //   85: astore_1
      //   86: goto -> 101
      //   89: ldc 'Failed to decode str'
      //   91: iconst_0
      //   92: anewarray java/lang/Object
      //   95: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   98: ldc ''
      //   100: astore_1
      //   101: aload_1
      //   102: invokevirtual isEmpty : ()Z
      //   105: ifne -> 192
      //   108: new org/json/JSONObject
      //   111: dup
      //   112: aload_1
      //   113: invokespecial <init> : (Ljava/lang/String;)V
      //   116: ldc 'exp'
      //   118: invokevirtual optLong : (Ljava/lang/String;)J
      //   121: lstore_3
      //   122: aload #6
      //   124: lload_3
      //   125: putfield m : J
      //   128: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
      //   131: lload_3
      //   132: invokevirtual toMillis : (J)J
      //   135: lstore_3
      //   136: new java/text/SimpleDateFormat
      //   139: dup
      //   140: ldc 'dd/MM/yyyy HH:mm:ss'
      //   142: invokespecial <init> : (Ljava/lang/String;)V
      //   145: astore_1
      //   146: invokestatic getInstance : ()Ljava/util/Calendar;
      //   149: astore #6
      //   151: aload #6
      //   153: lload_3
      //   154: invokevirtual setTimeInMillis : (J)V
      //   157: aload_1
      //   158: aload #6
      //   160: invokevirtual getTime : ()Ljava/util/Date;
      //   163: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
      //   166: astore_1
      //   167: ldc 'Ignite session will exp in: %s'
      //   169: iconst_1
      //   170: anewarray java/lang/Object
      //   173: dup
      //   174: iconst_0
      //   175: aload_1
      //   176: aastore
      //   177: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   180: goto -> 192
      //   183: ldc 'Failed to resolve expiration time'
      //   185: iconst_0
      //   186: anewarray java/lang/Object
      //   189: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   192: aload_0
      //   193: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   196: iconst_0
      //   197: invokestatic b : (Lcom/fyber/inneractive/sdk/ignite/c;Z)Z
      //   200: pop
      //   201: aload_0
      //   202: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   205: getfield s : Lcom/fyber/inneractive/sdk/ignite/h;
      //   208: astore_1
      //   209: aload_1
      //   210: ifnull -> 227
      //   213: aload_1
      //   214: invokeinterface b : ()V
      //   219: aload_0
      //   220: getfield a : Lcom/fyber/inneractive/sdk/ignite/c;
      //   223: aconst_null
      //   224: putfield s : Lcom/fyber/inneractive/sdk/ignite/h;
      //   227: return
      //   228: astore_1
      //   229: goto -> 89
      //   232: astore_1
      //   233: goto -> 183
      //   236: astore_1
      //   237: aload #5
      //   239: astore_1
      //   240: goto -> 167
      // Exception table:
      //   from	to	target	type
      //   63	86	228	java/lang/Exception
      //   108	136	232	java/lang/Exception
      //   136	167	236	java/lang/Exception
      //   167	180	232	java/lang/Exception
    }
  }
  
  public static class d {
    public final String a;
    
    public final p<?> b;
    
    public final k c;
    
    public d(String param1String, k param1k, p<?> param1p) {
      this.a = param1String;
      this.c = param1k;
      this.b = param1p;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */