package com.fyber.inneractive.sdk.ignite;

import com.fyber.inneractive.sdk.protobuf.GeneratedMessageLite;
import com.fyber.inneractive.sdk.protobuf.i;
import com.fyber.inneractive.sdk.protobuf.j;
import com.fyber.inneractive.sdk.protobuf.q;
import com.fyber.inneractive.sdk.protobuf.w0;
import com.fyber.inneractive.sdk.protobuf.z;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class IgniteRequestOuterClass$IgniteRequest extends GeneratedMessageLite<IgniteRequestOuterClass$IgniteRequest, IgniteRequestOuterClass$IgniteRequest.a> {
  public static final int APPID_FIELD_NUMBER = 1;
  
  public static final int APPSIGNATURE_FIELD_NUMBER = 3;
  
  public static final int BUNDLE_FIELD_NUMBER = 2;
  
  private static final IgniteRequestOuterClass$IgniteRequest DEFAULT_INSTANCE;
  
  public static final int IGNITEPACKAGENAME_FIELD_NUMBER = 4;
  
  public static final int IGNITEVERSIONNAME_FIELD_NUMBER = 5;
  
  private static volatile w0<IgniteRequestOuterClass$IgniteRequest> PARSER;
  
  public static final int SDKVERSION_FIELD_NUMBER = 6;
  
  private String appId_ = "";
  
  private String appSignature_ = "";
  
  private int bitField0_;
  
  private String bundle_ = "";
  
  private String ignitePackageName_ = "";
  
  private String igniteVersionName_ = "";
  
  private String sdkVersion_ = "";
  
  static {
    IgniteRequestOuterClass$IgniteRequest igniteRequestOuterClass$IgniteRequest = new IgniteRequestOuterClass$IgniteRequest();
    DEFAULT_INSTANCE = igniteRequestOuterClass$IgniteRequest;
    GeneratedMessageLite.registerDefaultInstance(IgniteRequestOuterClass$IgniteRequest.class, igniteRequestOuterClass$IgniteRequest);
  }
  
  private void clearAppId() {
    this.bitField0_ &= 0xFFFFFFFE;
    this.appId_ = getDefaultInstance().getAppId();
  }
  
  private void clearAppSignature() {
    this.bitField0_ &= 0xFFFFFFFB;
    this.appSignature_ = getDefaultInstance().getAppSignature();
  }
  
  private void clearBundle() {
    this.bitField0_ &= 0xFFFFFFFD;
    this.bundle_ = getDefaultInstance().getBundle();
  }
  
  private void clearIgnitePackageName() {
    this.bitField0_ &= 0xFFFFFFF7;
    this.ignitePackageName_ = getDefaultInstance().getIgnitePackageName();
  }
  
  private void clearIgniteVersionName() {
    this.bitField0_ &= 0xFFFFFFEF;
    this.igniteVersionName_ = getDefaultInstance().getIgniteVersionName();
  }
  
  private void clearSdkVersion() {
    this.bitField0_ &= 0xFFFFFFDF;
    this.sdkVersion_ = getDefaultInstance().getSdkVersion();
  }
  
  public static IgniteRequestOuterClass$IgniteRequest getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static a newBuilder() {
    return (a)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static a newBuilder(IgniteRequestOuterClass$IgniteRequest paramIgniteRequestOuterClass$IgniteRequest) {
    return (a)DEFAULT_INSTANCE.createBuilder(paramIgniteRequestOuterClass$IgniteRequest);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseDelimitedFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(i parami) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(i parami, q paramq) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami, paramq);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(j paramj) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(j paramj, q paramq) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj, paramq);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(InputStream paramInputStream) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(ByteBuffer paramByteBuffer) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(ByteBuffer paramByteBuffer, q paramq) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramq);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(byte[] paramArrayOfbyte) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static IgniteRequestOuterClass$IgniteRequest parseFrom(byte[] paramArrayOfbyte, q paramq) throws z {
    return (IgniteRequestOuterClass$IgniteRequest)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramq);
  }
  
  public static w0<IgniteRequestOuterClass$IgniteRequest> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void setAppId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x1;
    this.appId_ = paramString;
  }
  
  private void setAppIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.appId_ = parami.i();
    this.bitField0_ |= 0x1;
  }
  
  private void setAppSignature(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x4;
    this.appSignature_ = paramString;
  }
  
  private void setAppSignatureBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.appSignature_ = parami.i();
    this.bitField0_ |= 0x4;
  }
  
  private void setBundle(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x2;
    this.bundle_ = paramString;
  }
  
  private void setBundleBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.bundle_ = parami.i();
    this.bitField0_ |= 0x2;
  }
  
  private void setIgnitePackageName(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x8;
    this.ignitePackageName_ = paramString;
  }
  
  private void setIgnitePackageNameBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.ignitePackageName_ = parami.i();
    this.bitField0_ |= 0x8;
  }
  
  private void setIgniteVersionName(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x10;
    this.igniteVersionName_ = paramString;
  }
  
  private void setIgniteVersionNameBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.igniteVersionName_ = parami.i();
    this.bitField0_ |= 0x10;
  }
  
  private void setSdkVersion(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x20;
    this.sdkVersion_ = paramString;
  }
  
  private void setSdkVersionBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.sdkVersion_ = parami.i();
    this.bitField0_ |= 0x20;
  }
  
  public final Object dynamicMethod(GeneratedMessageLite.f paramf, Object<IgniteRequestOuterClass$IgniteRequest> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic com/fyber/inneractive/sdk/ignite/l.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 186, 2 -> 178, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   77: monitorenter
    //   78: getstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
    //   91: dup
    //   92: getstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;
    //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   103: ldc com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;
    //   119: areturn
    //   120: getstatic com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest;
    //   123: ldc_w '     ለ ለለለለለ'
    //   126: bipush #7
    //   128: anewarray java/lang/Object
    //   131: dup
    //   132: iconst_0
    //   133: ldc_w 'bitField0_'
    //   136: aastore
    //   137: dup
    //   138: iconst_1
    //   139: ldc_w 'appId_'
    //   142: aastore
    //   143: dup
    //   144: iconst_2
    //   145: ldc_w 'bundle_'
    //   148: aastore
    //   149: dup
    //   150: iconst_3
    //   151: ldc_w 'appSignature_'
    //   154: aastore
    //   155: dup
    //   156: iconst_4
    //   157: ldc_w 'ignitePackageName_'
    //   160: aastore
    //   161: dup
    //   162: iconst_5
    //   163: ldc_w 'igniteVersionName_'
    //   166: aastore
    //   167: dup
    //   168: bipush #6
    //   170: ldc_w 'sdkVersion_'
    //   173: aastore
    //   174: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   177: areturn
    //   178: new com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest$a
    //   181: dup
    //   182: invokespecial <init> : ()V
    //   185: areturn
    //   186: new com/fyber/inneractive/sdk/ignite/IgniteRequestOuterClass$IgniteRequest
    //   189: dup
    //   190: invokespecial <init> : ()V
    //   193: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public String getAppId() {
    return this.appId_;
  }
  
  public i getAppIdBytes() {
    return i.a(this.appId_);
  }
  
  public String getAppSignature() {
    return this.appSignature_;
  }
  
  public i getAppSignatureBytes() {
    return i.a(this.appSignature_);
  }
  
  public String getBundle() {
    return this.bundle_;
  }
  
  public i getBundleBytes() {
    return i.a(this.bundle_);
  }
  
  public String getIgnitePackageName() {
    return this.ignitePackageName_;
  }
  
  public i getIgnitePackageNameBytes() {
    return i.a(this.ignitePackageName_);
  }
  
  public String getIgniteVersionName() {
    return this.igniteVersionName_;
  }
  
  public i getIgniteVersionNameBytes() {
    return i.a(this.igniteVersionName_);
  }
  
  public String getSdkVersion() {
    return this.sdkVersion_;
  }
  
  public i getSdkVersionBytes() {
    return i.a(this.sdkVersion_);
  }
  
  public boolean hasAppId() {
    return ((this.bitField0_ & 0x1) != 0);
  }
  
  public boolean hasAppSignature() {
    return ((this.bitField0_ & 0x4) != 0);
  }
  
  public boolean hasBundle() {
    return ((this.bitField0_ & 0x2) != 0);
  }
  
  public boolean hasIgnitePackageName() {
    return ((this.bitField0_ & 0x8) != 0);
  }
  
  public boolean hasIgniteVersionName() {
    return ((this.bitField0_ & 0x10) != 0);
  }
  
  public boolean hasSdkVersion() {
    return ((this.bitField0_ & 0x20) != 0);
  }
  
  public static final class a extends GeneratedMessageLite.b<IgniteRequestOuterClass$IgniteRequest, a> {
    public a() {
      super(IgniteRequestOuterClass$IgniteRequest.DEFAULT_INSTANCE);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\IgniteRequestOuterClass$IgniteRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */