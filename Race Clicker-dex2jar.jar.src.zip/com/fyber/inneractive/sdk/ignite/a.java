package com.fyber.inneractive.sdk.ignite;

import android.os.RemoteException;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceCallback;
import com.fyber.inneractive.sdk.util.IAlog;
import org.json.JSONObject;

public class a extends IIgniteServiceCallback.Stub {
  public final n a;
  
  public a(n paramn) {
    this.a = paramn;
  }
  
  public void onError(String paramString) throws RemoteException {
    IAlog.a("AuthenticationCallback onError %s", new Object[] { paramString });
    this.a.b(paramString);
  }
  
  public void onProgress(String paramString) throws RemoteException {
    IAlog.a("AuthenticationCallback onProgress %s", new Object[] { paramString });
  }
  
  public void onScheduled(String paramString) throws RemoteException {
    IAlog.a("AuthenticationCallback onScheduled %s", new Object[] { paramString });
  }
  
  public void onStart(String paramString) throws RemoteException {
    IAlog.a("AuthenticationCallback onStart %s", new Object[] { paramString });
  }
  
  public void onSuccess(String paramString) throws RemoteException {
    IAlog.a("AuthenticationCallback onSuccess %s", new Object[] { paramString });
    try {
      paramString = (new JSONObject(paramString)).getJSONObject("data").getString("token");
    } catch (Exception exception) {
      IAlog.a("Failed to resolve ignite clientToken", new Object[0]);
      exception = null;
    } 
    this.a.d((String)exception);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */