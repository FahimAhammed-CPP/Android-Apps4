package com.fyber.inneractive.sdk.ignite;

import com.fyber.inneractive.sdk.network.w;
import com.fyber.inneractive.sdk.util.IAlog;

public class d implements w<IgniteResponseOuterClass$IgniteResponse> {
  public d(c paramc) {}
  
  public void a(Object paramObject, Exception paramException, boolean paramBoolean) {
    paramObject = paramObject;
    if (paramException == null && paramObject.hasClientId() && paramObject.hasClientSecret()) {
      this.a.e = paramObject.getClientId();
      this.a.f = paramObject.getClientSecret();
      this.a.a();
      return;
    } 
    if (paramException != null) {
      paramObject = paramException.getMessage();
    } else {
      paramObject = "";
    } 
    IAlog.a("Failed to fetch ignite client credentials with error: %s", new Object[] { paramObject });
    if (this.a.a(paramException)) {
      c c1 = this.a;
      i i = i.FAILED_TO_RETRIEVE_CREDENTIALS;
      if (paramException != null) {
        paramObject = paramException.getMessage();
      } else {
        paramObject = null;
      } 
      c1.a(i, (String)paramObject);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */