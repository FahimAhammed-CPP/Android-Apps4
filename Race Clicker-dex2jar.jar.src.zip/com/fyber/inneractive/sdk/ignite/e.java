package com.fyber.inneractive.sdk.ignite;

import com.fyber.inneractive.sdk.util.IAlog;

public class e implements Runnable {
  public e(c paramc) {}
  
  public void run() {
    c c1 = this.a;
    IAlog.a("onInstallTimeout after %d msec", new Object[] { Long.valueOf(c1.p) });
    for (n n : c1.i) {
      if (n != null)
        n.b(null, i.INSTALL_TIMEOUT.e(), null); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */