package com.fyber.inneractive.sdk.ignite;

import com.fyber.inneractive.sdk.protobuf.GeneratedMessageLite;
import com.fyber.inneractive.sdk.protobuf.i;
import com.fyber.inneractive.sdk.protobuf.j;
import com.fyber.inneractive.sdk.protobuf.q;
import com.fyber.inneractive.sdk.protobuf.w0;
import com.fyber.inneractive.sdk.protobuf.z;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class IgniteResponseOuterClass$IgniteResponse extends GeneratedMessageLite<IgniteResponseOuterClass$IgniteResponse, IgniteResponseOuterClass$IgniteResponse.a> {
  public static final int CLIENTID_FIELD_NUMBER = 1;
  
  public static final int CLIENTSECRET_FIELD_NUMBER = 2;
  
  private static final IgniteResponseOuterClass$IgniteResponse DEFAULT_INSTANCE;
  
  private static volatile w0<IgniteResponseOuterClass$IgniteResponse> PARSER;
  
  private int bitField0_;
  
  private String clientId_ = "";
  
  private String clientSecret_ = "";
  
  static {
    IgniteResponseOuterClass$IgniteResponse igniteResponseOuterClass$IgniteResponse = new IgniteResponseOuterClass$IgniteResponse();
    DEFAULT_INSTANCE = igniteResponseOuterClass$IgniteResponse;
    GeneratedMessageLite.registerDefaultInstance(IgniteResponseOuterClass$IgniteResponse.class, igniteResponseOuterClass$IgniteResponse);
  }
  
  private void clearClientId() {
    this.bitField0_ &= 0xFFFFFFFE;
    this.clientId_ = getDefaultInstance().getClientId();
  }
  
  private void clearClientSecret() {
    this.bitField0_ &= 0xFFFFFFFD;
    this.clientSecret_ = getDefaultInstance().getClientSecret();
  }
  
  public static IgniteResponseOuterClass$IgniteResponse getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static a newBuilder() {
    return (a)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static a newBuilder(IgniteResponseOuterClass$IgniteResponse paramIgniteResponseOuterClass$IgniteResponse) {
    return (a)DEFAULT_INSTANCE.createBuilder(paramIgniteResponseOuterClass$IgniteResponse);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseDelimitedFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(i parami) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(i parami, q paramq) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami, paramq);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(j paramj) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(j paramj, q paramq) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj, paramq);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(InputStream paramInputStream) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(ByteBuffer paramByteBuffer) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(ByteBuffer paramByteBuffer, q paramq) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramq);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(byte[] paramArrayOfbyte) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static IgniteResponseOuterClass$IgniteResponse parseFrom(byte[] paramArrayOfbyte, q paramq) throws z {
    return (IgniteResponseOuterClass$IgniteResponse)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramq);
  }
  
  public static w0<IgniteResponseOuterClass$IgniteResponse> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void setClientId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x1;
    this.clientId_ = paramString;
  }
  
  private void setClientIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.clientId_ = parami.i();
    this.bitField0_ |= 0x1;
  }
  
  private void setClientSecret(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x2;
    this.clientSecret_ = paramString;
  }
  
  private void setClientSecretBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.clientSecret_ = parami.i();
    this.bitField0_ |= 0x2;
  }
  
  public final Object dynamicMethod(GeneratedMessageLite.f paramf, Object<IgniteResponseOuterClass$IgniteResponse> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic com/fyber/inneractive/sdk/ignite/m.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 156, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse
    //   77: monitorenter
    //   78: getstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
    //   91: dup
    //   92: getstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse;
    //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   103: ldc com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse;
    //   119: areturn
    //   120: getstatic com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse;
    //   123: ldc '     ለ ለ'
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'bitField0_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'clientId_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'clientSecret_'
    //   143: aastore
    //   144: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse$a
    //   151: dup
    //   152: invokespecial <init> : ()V
    //   155: areturn
    //   156: new com/fyber/inneractive/sdk/ignite/IgniteResponseOuterClass$IgniteResponse
    //   159: dup
    //   160: invokespecial <init> : ()V
    //   163: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public String getClientId() {
    return this.clientId_;
  }
  
  public i getClientIdBytes() {
    return i.a(this.clientId_);
  }
  
  public String getClientSecret() {
    return this.clientSecret_;
  }
  
  public i getClientSecretBytes() {
    return i.a(this.clientSecret_);
  }
  
  public boolean hasClientId() {
    return ((this.bitField0_ & 0x1) != 0);
  }
  
  public boolean hasClientSecret() {
    return ((this.bitField0_ & 0x2) != 0);
  }
  
  public static final class a extends GeneratedMessageLite.b<IgniteResponseOuterClass$IgniteResponse, a> {
    public a() {
      super(IgniteResponseOuterClass$IgniteResponse.DEFAULT_INSTANCE);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\IgniteResponseOuterClass$IgniteResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */