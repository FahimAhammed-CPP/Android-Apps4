package com.fyber.inneractive.sdk.network;

import android.graphics.Bitmap;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.d0;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class m0 extends f0<m0.a> {
  public final String r;
  
  public m0(w<a> paramw, String paramString, s params) {
    super(paramw, x.a().b(), params);
    this.r = paramString;
  }
  
  public b0 a(j paramj, Map<String, List<String>> paramMap, int paramInt) throws Exception {
    b0 b0 = new b0();
    a a = new a(null, null);
    try {
      InputStream inputStream = paramj.c;
      if (inputStream != null) {
        Bitmap bitmap = d0.a(inputStream, a(paramMap));
        if (bitmap != null) {
          paramInt = bitmap.getWidth();
          int i = bitmap.getHeight();
          int k = paramInt * i;
          int[] arrayOfInt = new int[k];
          bitmap.getPixels(arrayOfInt, 0, paramInt, 0, 0, paramInt, i);
          paramInt = -1;
          i = 0;
          while (true) {
            if (i < k) {
              int m;
              int n = arrayOfInt[i];
              if (i != 0) {
                m = paramInt;
                if (n != paramInt) {
                  paramInt = 1;
                  break;
                } 
              } else {
                m = n;
              } 
              i++;
              paramInt = m;
              continue;
            } 
            paramInt = 0;
            break;
          } 
          if (paramInt == 0) {
            IAlog.a("SimpleImageLoader: Got an invalid bitmap", new Object[0]);
            a.b = "Got an invalid bitmap";
          } 
          a.a = bitmap;
          IAlog.a("SimpleImageLoader: Got a valid bitmap %s", new Object[] { this.r });
          b0.a = a;
          return b0;
        } 
      } else {
        b0.a = a;
        return b0;
      } 
      IAlog.a("SimpleImageLoader: Got an invalid bitmap", new Object[0]);
      a.b = "Got an invalid bitmap";
    } catch (Exception exception) {
      IAlog.c("SimpleImageLoader: Exception on load image %s %s", new Object[] { exception.getMessage(), exception.toString() });
      a.b = exception.getMessage();
    } catch (OutOfMemoryError outOfMemoryError) {
      IAlog.c("SimpleImageLoader: OutOfMemoryError on load image %s", new Object[] { outOfMemoryError.getMessage() });
      Bitmap bitmap = a.a;
      if (bitmap != null)
        bitmap.recycle(); 
      a.b = outOfMemoryError.getMessage();
    } 
    b0.a = a;
    return b0;
  }
  
  public String a() {
    return this.r;
  }
  
  public o0 i() {
    return o0.LOW;
  }
  
  public boolean o() {
    return false;
  }
  
  public z r() {
    return z.GET;
  }
  
  public int v() {
    return 0;
  }
  
  public static class a {
    public Bitmap a = null;
    
    public String b = null;
    
    public a(Bitmap param1Bitmap, String param1String) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\fyber\inneractive\sdk\network\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */