package bolts;

import android.net.Uri;
import java.util.Collections;
import java.util.List;

public class AppLink {
  private Uri sourceUrl;
  
  private List<Target> targets;
  
  private Uri webUrl;
  
  public AppLink(Uri paramUri1, List<Target> paramList, Uri paramUri2) {
    this.sourceUrl = paramUri1;
    List<Target> list = paramList;
    if (paramList == null)
      list = Collections.emptyList(); 
    this.targets = list;
    this.webUrl = paramUri2;
  }
  
  public Uri getSourceUrl() {
    return this.sourceUrl;
  }
  
  public List<Target> getTargets() {
    return Collections.unmodifiableList(this.targets);
  }
  
  public Uri getWebUrl() {
    return this.webUrl;
  }
  
  public static class Target {
    private final String appName;
    
    private final String className;
    
    private final String packageName;
    
    private final Uri url;
    
    public Target(String param1String1, String param1String2, Uri param1Uri, String param1String3) {
      this.packageName = param1String1;
      this.className = param1String2;
      this.url = param1Uri;
      this.appName = param1String3;
    }
    
    public String getAppName() {
      return this.appName;
    }
    
    public String getClassName() {
      return this.className;
    }
    
    public String getPackageName() {
      return this.packageName;
    }
    
    public Uri getUrl() {
      return this.url;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\bolts\AppLink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */