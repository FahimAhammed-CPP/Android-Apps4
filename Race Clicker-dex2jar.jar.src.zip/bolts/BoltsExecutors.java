package bolts;

import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

final class BoltsExecutors {
  private static final BoltsExecutors INSTANCE = new BoltsExecutors();
  
  private final ExecutorService background;
  
  private final Executor immediate;
  
  private final ScheduledExecutorService scheduled;
  
  private BoltsExecutors() {
    ExecutorService executorService;
    if (!isAndroidRuntime()) {
      executorService = Executors.newCachedThreadPool();
    } else {
      executorService = AndroidExecutors.newCachedThreadPool();
    } 
    this.background = executorService;
    this.scheduled = Executors.newSingleThreadScheduledExecutor();
    this.immediate = new ImmediateExecutor();
  }
  
  public static ExecutorService background() {
    return INSTANCE.background;
  }
  
  static Executor immediate() {
    return INSTANCE.immediate;
  }
  
  private static boolean isAndroidRuntime() {
    String str = System.getProperty("java.runtime.name");
    return (str == null) ? false : str.toLowerCase(Locale.US).contains("android");
  }
  
  static ScheduledExecutorService scheduled() {
    return INSTANCE.scheduled;
  }
  
  private static class ImmediateExecutor implements Executor {
    private static final int MAX_DEPTH = 15;
    
    private ThreadLocal<Integer> executionDepth = new ThreadLocal<Integer>();
    
    private ImmediateExecutor() {}
    
    private int decrementDepth() {
      Integer integer2 = this.executionDepth.get();
      Integer integer1 = integer2;
      if (integer2 == null)
        integer1 = Integer.valueOf(0); 
      int i = integer1.intValue() - 1;
      if (i == 0) {
        this.executionDepth.remove();
        return i;
      } 
      this.executionDepth.set(Integer.valueOf(i));
      return i;
    }
    
    private int incrementDepth() {
      Integer integer2 = this.executionDepth.get();
      Integer integer1 = integer2;
      if (integer2 == null)
        integer1 = Integer.valueOf(0); 
      int i = integer1.intValue() + 1;
      this.executionDepth.set(Integer.valueOf(i));
      return i;
    }
    
    public void execute(Runnable param1Runnable) {
      if (incrementDepth() <= 15)
        try {
          param1Runnable.run();
          return;
        } finally {
          decrementDepth();
        }  
      BoltsExecutors.background().execute(param1Runnable);
      decrementDepth();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\bolts\BoltsExecutors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */