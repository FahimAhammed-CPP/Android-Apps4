package bolts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Task<TResult> {
  public static final ExecutorService BACKGROUND_EXECUTOR = BoltsExecutors.background();
  
  private static final Executor IMMEDIATE_EXECUTOR = BoltsExecutors.immediate();
  
  private static Task<?> TASK_CANCELLED;
  
  private static Task<Boolean> TASK_FALSE;
  
  private static Task<?> TASK_NULL;
  
  private static Task<Boolean> TASK_TRUE;
  
  public static final Executor UI_THREAD_EXECUTOR = AndroidExecutors.uiThread();
  
  private static volatile UnobservedExceptionHandler unobservedExceptionHandler;
  
  private boolean cancelled;
  
  private boolean complete;
  
  private List<Continuation<TResult, Void>> continuations = new ArrayList<Continuation<TResult, Void>>();
  
  private Exception error;
  
  private boolean errorHasBeenObserved;
  
  private final Object lock = new Object();
  
  private TResult result;
  
  private UnobservedErrorNotifier unobservedErrorNotifier;
  
  static {
    TASK_NULL = new Task(null);
    TASK_TRUE = new Task((TResult)Boolean.valueOf(true));
    TASK_FALSE = new Task((TResult)Boolean.valueOf(false));
    TASK_CANCELLED = new Task(true);
  }
  
  Task() {}
  
  private Task(TResult paramTResult) {
    trySetResult(paramTResult);
  }
  
  private Task(boolean paramBoolean) {
    if (paramBoolean) {
      trySetCancelled();
      return;
    } 
    trySetResult(null);
  }
  
  public static <TResult> Task<TResult> call(Callable<TResult> paramCallable) {
    return call(paramCallable, IMMEDIATE_EXECUTOR, null);
  }
  
  public static <TResult> Task<TResult> call(Callable<TResult> paramCallable, CancellationToken paramCancellationToken) {
    return call(paramCallable, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public static <TResult> Task<TResult> call(Callable<TResult> paramCallable, Executor paramExecutor) {
    return call(paramCallable, paramExecutor, null);
  }
  
  public static <TResult> Task<TResult> call(final Callable<TResult> callable, Executor paramExecutor, final CancellationToken ct) {
    final TaskCompletionSource tcs = new TaskCompletionSource();
    try {
      paramExecutor.execute(new Runnable() {
            public void run() {
              CancellationToken cancellationToken = ct;
              if (cancellationToken != null && cancellationToken.isCancellationRequested()) {
                tcs.setCancelled();
                return;
              } 
              try {
                tcs.setResult(callable.call());
                return;
              } catch (CancellationException cancellationException) {
                tcs.setCancelled();
                return;
              } catch (Exception exception) {
                tcs.setError(exception);
                return;
              } 
            }
          });
    } catch (Exception exception) {
      taskCompletionSource.setError((Exception)new ExecutorException(exception));
    } 
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<TResult> callInBackground(Callable<TResult> paramCallable) {
    return call(paramCallable, BACKGROUND_EXECUTOR, null);
  }
  
  public static <TResult> Task<TResult> callInBackground(Callable<TResult> paramCallable, CancellationToken paramCancellationToken) {
    return call(paramCallable, BACKGROUND_EXECUTOR, paramCancellationToken);
  }
  
  public static <TResult> Task<TResult> cancelled() {
    return (Task)TASK_CANCELLED;
  }
  
  private static <TContinuationResult, TResult> void completeAfterTask(final TaskCompletionSource<TContinuationResult> tcs, final Continuation<TResult, Task<TContinuationResult>> continuation, final Task<TResult> task, Executor paramExecutor, final CancellationToken ct) {
    try {
      paramExecutor.execute(new Runnable() {
            public void run() {
              CancellationToken cancellationToken = ct;
              if (cancellationToken != null && cancellationToken.isCancellationRequested()) {
                tcs.setCancelled();
                return;
              } 
              try {
                Task task = (Task)continuation.then(task);
                if (task == null) {
                  tcs.setResult(null);
                  return;
                } 
                task.continueWith(new Continuation<Void, Void>() {
                      public Void then(Task<TContinuationResult> param2Task) {
                        if (ct != null && ct.isCancellationRequested()) {
                          tcs.setCancelled();
                          return null;
                        } 
                        if (param2Task.isCancelled()) {
                          tcs.setCancelled();
                          return null;
                        } 
                        if (param2Task.isFaulted()) {
                          tcs.setError(param2Task.getError());
                          return null;
                        } 
                        tcs.setResult(param2Task.getResult());
                        return null;
                      }
                    });
                return;
              } catch (CancellationException cancellationException) {
                tcs.setCancelled();
                return;
              } catch (Exception exception) {
                tcs.setError(exception);
                return;
              } 
            }
          });
      return;
    } catch (Exception exception) {
      tcs.setError((Exception)new ExecutorException(exception));
      return;
    } 
  }
  
  private static <TContinuationResult, TResult> void completeImmediately(final TaskCompletionSource<TContinuationResult> tcs, final Continuation<TResult, TContinuationResult> continuation, final Task<TResult> task, Executor paramExecutor, final CancellationToken ct) {
    try {
      paramExecutor.execute(new Runnable() {
            public void run() {
              CancellationToken cancellationToken = ct;
              if (cancellationToken != null && cancellationToken.isCancellationRequested()) {
                tcs.setCancelled();
                return;
              } 
              try {
                cancellationToken = (CancellationToken)continuation.then(task);
                tcs.setResult(cancellationToken);
                return;
              } catch (CancellationException cancellationException) {
                tcs.setCancelled();
                return;
              } catch (Exception exception) {
                tcs.setError(exception);
                return;
              } 
            }
          });
      return;
    } catch (Exception exception) {
      tcs.setError((Exception)new ExecutorException(exception));
      return;
    } 
  }
  
  public static <TResult> TaskCompletionSource create() {
    return new TaskCompletionSource();
  }
  
  public static Task<Void> delay(long paramLong) {
    return delay(paramLong, BoltsExecutors.scheduled(), null);
  }
  
  public static Task<Void> delay(long paramLong, CancellationToken paramCancellationToken) {
    return delay(paramLong, BoltsExecutors.scheduled(), paramCancellationToken);
  }
  
  static Task<Void> delay(long paramLong, ScheduledExecutorService paramScheduledExecutorService, CancellationToken paramCancellationToken) {
    if (paramCancellationToken != null && paramCancellationToken.isCancellationRequested())
      return cancelled(); 
    if (paramLong <= 0L)
      return forResult(null); 
    final TaskCompletionSource tcs = new TaskCompletionSource();
    final ScheduledFuture<?> scheduled = paramScheduledExecutorService.schedule(new Runnable() {
          public void run() {
            tcs.trySetResult(null);
          }
        },  paramLong, TimeUnit.MILLISECONDS);
    if (paramCancellationToken != null)
      paramCancellationToken.register(new Runnable() {
            public void run() {
              scheduled.cancel(true);
              tcs.trySetCancelled();
            }
          }); 
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<TResult> forError(Exception paramException) {
    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
    taskCompletionSource.setError(paramException);
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<TResult> forResult(TResult paramTResult) {
    if (paramTResult == null)
      return (Task)TASK_NULL; 
    if (paramTResult instanceof Boolean)
      return (Task)(((Boolean)paramTResult).booleanValue() ? TASK_TRUE : TASK_FALSE); 
    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
    taskCompletionSource.setResult(paramTResult);
    return taskCompletionSource.getTask();
  }
  
  public static UnobservedExceptionHandler getUnobservedExceptionHandler() {
    return unobservedExceptionHandler;
  }
  
  private void runContinuations() {
    synchronized (this.lock) {
      Iterator<Continuation<TResult, Void>> iterator = this.continuations.iterator();
      while (iterator.hasNext()) {
        Continuation continuation = iterator.next();
        try {
          continuation.then(this);
        } catch (RuntimeException runtimeException) {
          throw runtimeException;
        } catch (Exception exception) {
          throw new RuntimeException(exception);
        } 
      } 
      this.continuations = null;
      return;
    } 
  }
  
  public static void setUnobservedExceptionHandler(UnobservedExceptionHandler paramUnobservedExceptionHandler) {
    unobservedExceptionHandler = paramUnobservedExceptionHandler;
  }
  
  public static Task<Void> whenAll(Collection<? extends Task<?>> paramCollection) {
    if (paramCollection.size() == 0)
      return forResult(null); 
    final TaskCompletionSource allFinished = new TaskCompletionSource();
    final ArrayList causes = new ArrayList();
    final Object errorLock = new Object();
    final AtomicInteger count = new AtomicInteger(paramCollection.size());
    final AtomicBoolean isCancelled = new AtomicBoolean(false);
    Iterator<? extends Task<?>> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      ((Task)iterator.next()).continueWith(new Continuation<Object, Void>() {
            public Void then(Task<Object> param1Task) {
              if (param1Task.isFaulted())
                synchronized (errorLock) {
                  causes.add(param1Task.getError());
                }  
              if (param1Task.isCancelled())
                isCancelled.set(true); 
              if (count.decrementAndGet() == 0) {
                if (causes.size() != 0) {
                  if (causes.size() == 1) {
                    allFinished.setError(causes.get(0));
                    return null;
                  } 
                  AggregateException aggregateException = new AggregateException(String.format("There were %d exceptions.", new Object[] { Integer.valueOf(this.val$causes.size()) }), causes);
                  allFinished.setError((Exception)aggregateException);
                  return null;
                } 
                if (isCancelled.get()) {
                  allFinished.setCancelled();
                  return null;
                } 
                allFinished.setResult(null);
              } 
              return null;
            }
          });
    } 
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<List<TResult>> whenAllResult(final Collection<? extends Task<TResult>> tasks) {
    return whenAll(tasks).onSuccess(new Continuation<Void, List<TResult>>() {
          public List<TResult> then(Task<Void> param1Task) throws Exception {
            if (tasks.size() == 0)
              return Collections.emptyList(); 
            ArrayList<TResult> arrayList = new ArrayList();
            Iterator<Task> iterator = tasks.iterator();
            while (iterator.hasNext())
              arrayList.add(((Task)iterator.next()).getResult()); 
            return arrayList;
          }
        });
  }
  
  public static Task<Task<?>> whenAny(Collection<? extends Task<?>> paramCollection) {
    if (paramCollection.size() == 0)
      return forResult(null); 
    final TaskCompletionSource firstCompleted = new TaskCompletionSource();
    final AtomicBoolean isAnyTaskComplete = new AtomicBoolean(false);
    Iterator<? extends Task<?>> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      ((Task)iterator.next()).continueWith(new Continuation<Object, Void>() {
            public Void then(Task<Object> param1Task) {
              if (isAnyTaskComplete.compareAndSet(false, true)) {
                firstCompleted.setResult(param1Task);
              } else {
                param1Task.getError();
              } 
              return null;
            }
          });
    } 
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<Task<TResult>> whenAnyResult(Collection<? extends Task<TResult>> paramCollection) {
    if (paramCollection.size() == 0)
      return forResult(null); 
    final TaskCompletionSource firstCompleted = new TaskCompletionSource();
    final AtomicBoolean isAnyTaskComplete = new AtomicBoolean(false);
    Iterator<? extends Task<TResult>> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      ((Task)iterator.next()).continueWith(new Continuation<TResult, Void>() {
            public Void then(Task<TResult> param1Task) {
              if (isAnyTaskComplete.compareAndSet(false, true)) {
                firstCompleted.setResult(param1Task);
              } else {
                param1Task.getError();
              } 
              return null;
            }
          });
    } 
    return taskCompletionSource.getTask();
  }
  
  public <TOut> Task<TOut> cast() {
    return this;
  }
  
  public Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation) {
    return continueWhile(paramCallable, paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation, CancellationToken paramCancellationToken) {
    return continueWhile(paramCallable, paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation, Executor paramExecutor) {
    return continueWhile(paramCallable, paramContinuation, paramExecutor, null);
  }
  
  public Task<Void> continueWhile(final Callable<Boolean> predicate, final Continuation<Void, Task<Void>> continuation, final Executor executor, final CancellationToken ct) {
    final Capture predicateContinuation = new Capture();
    capture.set(new Continuation<Void, Task<Void>>() {
          public Task<Void> then(Task<Void> param1Task) throws Exception {
            CancellationToken cancellationToken = ct;
            return (cancellationToken != null && cancellationToken.isCancellationRequested()) ? Task.cancelled() : (((Boolean)predicate.call()).booleanValue() ? Task.forResult(null).onSuccessTask(continuation, executor).onSuccessTask((Continuation)predicateContinuation.get(), executor) : Task.forResult(null));
          }
        });
    return makeVoid().continueWithTask((Continuation<Void, Task<Void>>)capture.get(), executor);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation) {
    return continueWith(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation, CancellationToken paramCancellationToken) {
    return continueWith(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor) {
    return continueWith(paramContinuation, paramExecutor, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(final Continuation<TResult, TContinuationResult> continuation, final Executor executor, final CancellationToken ct) {
    final TaskCompletionSource<TContinuationResult> tcs = new TaskCompletionSource();
    synchronized (this.lock) {
      boolean bool = isCompleted();
      if (!bool)
        this.continuations.add(new Continuation<TResult, Void>() {
              public Void then(Task<TResult> param1Task) {
                Task.completeImmediately(tcs, continuation, param1Task, executor, ct);
                return null;
              }
            }); 
      if (bool)
        completeImmediately(taskCompletionSource, continuation, this, executor, ct); 
      return taskCompletionSource.getTask();
    } 
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    return continueWithTask(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, CancellationToken paramCancellationToken) {
    return continueWithTask(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor) {
    return continueWithTask(paramContinuation, paramExecutor, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(final Continuation<TResult, Task<TContinuationResult>> continuation, final Executor executor, final CancellationToken ct) {
    final TaskCompletionSource<TContinuationResult> tcs = new TaskCompletionSource();
    synchronized (this.lock) {
      boolean bool = isCompleted();
      if (!bool)
        this.continuations.add(new Continuation<TResult, Void>() {
              public Void then(Task<TResult> param1Task) {
                Task.completeAfterTask(tcs, continuation, param1Task, executor, ct);
                return null;
              }
            }); 
      if (bool)
        completeAfterTask(taskCompletionSource, continuation, this, executor, ct); 
      return taskCompletionSource.getTask();
    } 
  }
  
  public Exception getError() {
    synchronized (this.lock) {
      if (this.error != null) {
        this.errorHasBeenObserved = true;
        UnobservedErrorNotifier unobservedErrorNotifier = this.unobservedErrorNotifier;
        if (unobservedErrorNotifier != null) {
          unobservedErrorNotifier.setObserved();
          this.unobservedErrorNotifier = null;
        } 
      } 
      return this.error;
    } 
  }
  
  public TResult getResult() {
    synchronized (this.lock) {
      return this.result;
    } 
  }
  
  public boolean isCancelled() {
    synchronized (this.lock) {
      return this.cancelled;
    } 
  }
  
  public boolean isCompleted() {
    synchronized (this.lock) {
      return this.complete;
    } 
  }
  
  public boolean isFaulted() {
    synchronized (this.lock) {
      if (getError() != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public Task<Void> makeVoid() {
    return continueWithTask(new Continuation<TResult, Task<Void>>() {
          public Task<Void> then(Task<TResult> param1Task) throws Exception {
            return param1Task.isCancelled() ? Task.cancelled() : (param1Task.isFaulted() ? Task.forError(param1Task.getError()) : Task.forResult(null));
          }
        });
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation) {
    return onSuccess(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation, CancellationToken paramCancellationToken) {
    return onSuccess(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor) {
    return onSuccess(paramContinuation, paramExecutor, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(final Continuation<TResult, TContinuationResult> continuation, Executor paramExecutor, final CancellationToken ct) {
    return continueWithTask((Continuation)new Continuation<TResult, Task<Task<TContinuationResult>>>() {
          public Task<TContinuationResult> then(Task<TResult> param1Task) {
            CancellationToken cancellationToken = ct;
            return (cancellationToken != null && cancellationToken.isCancellationRequested()) ? Task.cancelled() : (param1Task.isFaulted() ? Task.forError(param1Task.getError()) : (param1Task.isCancelled() ? Task.cancelled() : param1Task.continueWith(continuation)));
          }
        },  paramExecutor);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    return onSuccessTask(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, CancellationToken paramCancellationToken) {
    return onSuccessTask(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor) {
    return onSuccessTask(paramContinuation, paramExecutor, null);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(final Continuation<TResult, Task<TContinuationResult>> continuation, Executor paramExecutor, final CancellationToken ct) {
    return continueWithTask((Continuation)new Continuation<TResult, Task<Task<TContinuationResult>>>() {
          public Task<TContinuationResult> then(Task<TResult> param1Task) {
            CancellationToken cancellationToken = ct;
            return (cancellationToken != null && cancellationToken.isCancellationRequested()) ? Task.cancelled() : (param1Task.isFaulted() ? Task.forError(param1Task.getError()) : (param1Task.isCancelled() ? Task.cancelled() : param1Task.continueWithTask(continuation)));
          }
        },  paramExecutor);
  }
  
  boolean trySetCancelled() {
    synchronized (this.lock) {
      if (this.complete)
        return false; 
      this.complete = true;
      this.cancelled = true;
      this.lock.notifyAll();
      runContinuations();
      return true;
    } 
  }
  
  boolean trySetError(Exception paramException) {
    synchronized (this.lock) {
      if (this.complete)
        return false; 
      this.complete = true;
      this.error = paramException;
      this.errorHasBeenObserved = false;
      this.lock.notifyAll();
      runContinuations();
      if (!this.errorHasBeenObserved && getUnobservedExceptionHandler() != null)
        this.unobservedErrorNotifier = new UnobservedErrorNotifier(this); 
      return true;
    } 
  }
  
  boolean trySetResult(TResult paramTResult) {
    synchronized (this.lock) {
      if (this.complete)
        return false; 
      this.complete = true;
      this.result = paramTResult;
      this.lock.notifyAll();
      runContinuations();
      return true;
    } 
  }
  
  public void waitForCompletion() throws InterruptedException {
    synchronized (this.lock) {
      if (!isCompleted())
        this.lock.wait(); 
      return;
    } 
  }
  
  public boolean waitForCompletion(long paramLong, TimeUnit paramTimeUnit) throws InterruptedException {
    synchronized (this.lock) {
      if (!isCompleted())
        this.lock.wait(paramTimeUnit.toMillis(paramLong)); 
      return isCompleted();
    } 
  }
  
  public class TaskCompletionSource extends TaskCompletionSource<TResult> {}
  
  public static interface UnobservedExceptionHandler {
    void unobservedException(Task<?> param1Task, UnobservedTaskException param1UnobservedTaskException);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\bolts\Task.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */