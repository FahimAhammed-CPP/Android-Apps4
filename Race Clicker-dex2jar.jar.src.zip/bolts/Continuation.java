package bolts;

public interface Continuation<TTaskResult, TContinuationResult> {
  TContinuationResult then(Task<TTaskResult> paramTask) throws Exception;
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\bolts\Continuation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */