package androidx.recyclerview.widget;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class DiffUtil {
  private static final Comparator<Diagonal> DIAGONAL_COMPARATOR = new Comparator<Diagonal>() {
      public int compare(DiffUtil.Diagonal param1Diagonal1, DiffUtil.Diagonal param1Diagonal2) {
        return param1Diagonal1.x - param1Diagonal2.x;
      }
    };
  
  private static Snake backward(Range paramRange, Callback paramCallback, CenteredArray paramCenteredArray1, CenteredArray paramCenteredArray2, int paramInt) {
    boolean bool;
    if ((paramRange.oldSize() - paramRange.newSize()) % 2 == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int k = paramRange.oldSize();
    int m = paramRange.newSize();
    int j = -paramInt;
    int i;
    for (i = j; i <= paramInt; i += 2) {
      int n;
      int i1;
      int i2;
      if (i == j || (i != paramInt && paramCenteredArray2.get(i + 1) < paramCenteredArray2.get(i - 1))) {
        i1 = paramCenteredArray2.get(i + 1);
        n = i1;
      } else {
        i1 = paramCenteredArray2.get(i - 1);
        n = i1 - 1;
      } 
      int i3 = paramRange.newListEnd - paramRange.oldListEnd - n - i;
      if (paramInt == 0 || n != i1) {
        i2 = i3;
      } else {
        i2 = i3 + 1;
      } 
      while (n > paramRange.oldListStart && i3 > paramRange.newListStart && paramCallback.areItemsTheSame(n - 1, i3 - 1)) {
        n--;
        i3--;
      } 
      paramCenteredArray2.set(i, n);
      if (bool) {
        int i4 = k - m - i;
        if (i4 >= j && i4 <= paramInt && paramCenteredArray1.get(i4) >= n) {
          Snake snake = new Snake();
          snake.startX = n;
          snake.startY = i3;
          snake.endX = i1;
          snake.endY = i2;
          snake.reverse = true;
          return snake;
        } 
      } 
    } 
    return null;
  }
  
  public static DiffResult calculateDiff(Callback paramCallback) {
    return calculateDiff(paramCallback, true);
  }
  
  public static DiffResult calculateDiff(Callback paramCallback, boolean paramBoolean) {
    int i = paramCallback.getOldListSize();
    int j = paramCallback.getNewListSize();
    ArrayList<Diagonal> arrayList = new ArrayList();
    ArrayList<Range> arrayList1 = new ArrayList();
    arrayList1.add(new Range(0, i, 0, j));
    i = (i + j + 1) / 2 * 2 + 1;
    CenteredArray centeredArray1 = new CenteredArray(i);
    CenteredArray centeredArray2 = new CenteredArray(i);
    ArrayList<Range> arrayList2 = new ArrayList();
    while (!arrayList1.isEmpty()) {
      Range range = arrayList1.remove(arrayList1.size() - 1);
      Snake snake = midPoint(range, paramCallback, centeredArray1, centeredArray2);
      if (snake != null) {
        Range range1;
        if (snake.diagonalSize() > 0)
          arrayList.add(snake.toDiagonal()); 
        if (arrayList2.isEmpty()) {
          range1 = new Range();
        } else {
          range1 = arrayList2.remove(arrayList2.size() - 1);
        } 
        range1.oldListStart = range.oldListStart;
        range1.newListStart = range.newListStart;
        range1.oldListEnd = snake.startX;
        range1.newListEnd = snake.startY;
        arrayList1.add(range1);
        range.oldListEnd = range.oldListEnd;
        range.newListEnd = range.newListEnd;
        range.oldListStart = snake.endX;
        range.newListStart = snake.endY;
        arrayList1.add(range);
        continue;
      } 
      arrayList2.add(range);
    } 
    Collections.sort(arrayList, DIAGONAL_COMPARATOR);
    return new DiffResult(paramCallback, arrayList, centeredArray1.backingData(), centeredArray2.backingData(), paramBoolean);
  }
  
  private static Snake forward(Range paramRange, Callback paramCallback, CenteredArray paramCenteredArray1, CenteredArray paramCenteredArray2, int paramInt) {
    int i = Math.abs(paramRange.oldSize() - paramRange.newSize());
    boolean bool = true;
    if (i % 2 != 1)
      bool = false; 
    int m = paramRange.oldSize();
    int n = paramRange.newSize();
    int k = -paramInt;
    int j;
    for (j = k; j <= paramInt; j += 2) {
      int i1;
      int i2;
      if (j == k || (j != paramInt && paramCenteredArray1.get(j + 1) > paramCenteredArray1.get(j - 1))) {
        i1 = paramCenteredArray1.get(j + 1);
        i = i1;
      } else {
        i1 = paramCenteredArray1.get(j - 1);
        i = i1 + 1;
      } 
      int i3 = paramRange.newListStart + i - paramRange.oldListStart - j;
      if (paramInt == 0 || i != i1) {
        i2 = i3;
      } else {
        i2 = i3 - 1;
      } 
      while (i < paramRange.oldListEnd && i3 < paramRange.newListEnd && paramCallback.areItemsTheSame(i, i3)) {
        i++;
        i3++;
      } 
      paramCenteredArray1.set(j, i);
      if (bool) {
        int i4 = m - n - j;
        if (i4 >= k + 1 && i4 <= paramInt - 1 && paramCenteredArray2.get(i4) <= i) {
          Snake snake = new Snake();
          snake.startX = i1;
          snake.startY = i2;
          snake.endX = i;
          snake.endY = i3;
          snake.reverse = false;
          return snake;
        } 
      } 
    } 
    return null;
  }
  
  private static Snake midPoint(Range paramRange, Callback paramCallback, CenteredArray paramCenteredArray1, CenteredArray paramCenteredArray2) {
    if (paramRange.oldSize() >= 1) {
      if (paramRange.newSize() < 1)
        return null; 
      int j = (paramRange.oldSize() + paramRange.newSize() + 1) / 2;
      paramCenteredArray1.set(1, paramRange.oldListStart);
      paramCenteredArray2.set(1, paramRange.oldListEnd);
      int i;
      for (i = 0; i < j; i++) {
        Snake snake = forward(paramRange, paramCallback, paramCenteredArray1, paramCenteredArray2, i);
        if (snake != null)
          return snake; 
        snake = backward(paramRange, paramCallback, paramCenteredArray1, paramCenteredArray2, i);
        if (snake != null)
          return snake; 
      } 
    } 
    return null;
  }
  
  public static abstract class Callback {
    public abstract boolean areContentsTheSame(int param1Int1, int param1Int2);
    
    public abstract boolean areItemsTheSame(int param1Int1, int param1Int2);
    
    public Object getChangePayload(int param1Int1, int param1Int2) {
      return null;
    }
    
    public abstract int getNewListSize();
    
    public abstract int getOldListSize();
  }
  
  static class CenteredArray {
    private final int[] mData;
    
    private final int mMid;
    
    CenteredArray(int param1Int) {
      int[] arrayOfInt = new int[param1Int];
      this.mData = arrayOfInt;
      this.mMid = arrayOfInt.length / 2;
    }
    
    int[] backingData() {
      return this.mData;
    }
    
    public void fill(int param1Int) {
      Arrays.fill(this.mData, param1Int);
    }
    
    int get(int param1Int) {
      return this.mData[param1Int + this.mMid];
    }
    
    void set(int param1Int1, int param1Int2) {
      this.mData[param1Int1 + this.mMid] = param1Int2;
    }
  }
  
  static class Diagonal {
    public final int size;
    
    public final int x;
    
    public final int y;
    
    Diagonal(int param1Int1, int param1Int2, int param1Int3) {
      this.x = param1Int1;
      this.y = param1Int2;
      this.size = param1Int3;
    }
    
    int endX() {
      return this.x + this.size;
    }
    
    int endY() {
      return this.y + this.size;
    }
  }
  
  public static class DiffResult {
    private static final int FLAG_CHANGED = 2;
    
    private static final int FLAG_MASK = 15;
    
    private static final int FLAG_MOVED = 12;
    
    private static final int FLAG_MOVED_CHANGED = 4;
    
    private static final int FLAG_MOVED_NOT_CHANGED = 8;
    
    private static final int FLAG_NOT_CHANGED = 1;
    
    private static final int FLAG_OFFSET = 4;
    
    public static final int NO_POSITION = -1;
    
    private final DiffUtil.Callback mCallback;
    
    private final boolean mDetectMoves;
    
    private final List<DiffUtil.Diagonal> mDiagonals;
    
    private final int[] mNewItemStatuses;
    
    private final int mNewListSize;
    
    private final int[] mOldItemStatuses;
    
    private final int mOldListSize;
    
    DiffResult(DiffUtil.Callback param1Callback, List<DiffUtil.Diagonal> param1List, int[] param1ArrayOfint1, int[] param1ArrayOfint2, boolean param1Boolean) {
      this.mDiagonals = param1List;
      this.mOldItemStatuses = param1ArrayOfint1;
      this.mNewItemStatuses = param1ArrayOfint2;
      Arrays.fill(param1ArrayOfint1, 0);
      Arrays.fill(param1ArrayOfint2, 0);
      this.mCallback = param1Callback;
      this.mOldListSize = param1Callback.getOldListSize();
      this.mNewListSize = param1Callback.getNewListSize();
      this.mDetectMoves = param1Boolean;
      addEdgeDiagonals();
      findMatchingItems();
    }
    
    private void addEdgeDiagonals() {
      DiffUtil.Diagonal diagonal;
      if (this.mDiagonals.isEmpty()) {
        diagonal = null;
      } else {
        diagonal = this.mDiagonals.get(0);
      } 
      if (diagonal == null || diagonal.x != 0 || diagonal.y != 0)
        this.mDiagonals.add(0, new DiffUtil.Diagonal(0, 0, 0)); 
      this.mDiagonals.add(new DiffUtil.Diagonal(this.mOldListSize, this.mNewListSize, 0));
    }
    
    private void findMatchingAddition(int param1Int) {
      int k = this.mDiagonals.size();
      int j = 0;
      int i = 0;
      while (j < k) {
        DiffUtil.Diagonal diagonal = this.mDiagonals.get(j);
        while (i < diagonal.y) {
          if (this.mNewItemStatuses[i] == 0 && this.mCallback.areItemsTheSame(param1Int, i)) {
            if (this.mCallback.areContentsTheSame(param1Int, i)) {
              j = 8;
            } else {
              j = 4;
            } 
            this.mOldItemStatuses[param1Int] = i << 4 | j;
            this.mNewItemStatuses[i] = param1Int << 4 | j;
            return;
          } 
          i++;
        } 
        i = diagonal.endY();
        j++;
      } 
    }
    
    private void findMatchingItems() {
      for (DiffUtil.Diagonal diagonal : this.mDiagonals) {
        for (int i = 0; i < diagonal.size; i++) {
          byte b;
          int j = diagonal.x + i;
          int k = diagonal.y + i;
          if (this.mCallback.areContentsTheSame(j, k)) {
            b = 1;
          } else {
            b = 2;
          } 
          this.mOldItemStatuses[j] = k << 4 | b;
          this.mNewItemStatuses[k] = j << 4 | b;
        } 
      } 
      if (this.mDetectMoves)
        findMoveMatches(); 
    }
    
    private void findMoveMatches() {
      Iterator<DiffUtil.Diagonal> iterator = this.mDiagonals.iterator();
      for (int i = 0; iterator.hasNext(); i = diagonal.endX()) {
        DiffUtil.Diagonal diagonal = iterator.next();
        while (i < diagonal.x) {
          if (this.mOldItemStatuses[i] == 0)
            findMatchingAddition(i); 
          i++;
        } 
      } 
    }
    
    private static DiffUtil.PostponedUpdate getPostponedUpdate(Collection<DiffUtil.PostponedUpdate> param1Collection, int param1Int, boolean param1Boolean) {
      // Byte code:
      //   0: aload_0
      //   1: invokeinterface iterator : ()Ljava/util/Iterator;
      //   6: astore_3
      //   7: aload_3
      //   8: invokeinterface hasNext : ()Z
      //   13: ifeq -> 51
      //   16: aload_3
      //   17: invokeinterface next : ()Ljava/lang/Object;
      //   22: checkcast androidx/recyclerview/widget/DiffUtil$PostponedUpdate
      //   25: astore_0
      //   26: aload_0
      //   27: getfield posInOwnerList : I
      //   30: iload_1
      //   31: if_icmpne -> 7
      //   34: aload_0
      //   35: getfield removal : Z
      //   38: iload_2
      //   39: if_icmpne -> 7
      //   42: aload_3
      //   43: invokeinterface remove : ()V
      //   48: goto -> 53
      //   51: aconst_null
      //   52: astore_0
      //   53: aload_3
      //   54: invokeinterface hasNext : ()Z
      //   59: ifeq -> 107
      //   62: aload_3
      //   63: invokeinterface next : ()Ljava/lang/Object;
      //   68: checkcast androidx/recyclerview/widget/DiffUtil$PostponedUpdate
      //   71: astore #4
      //   73: iload_2
      //   74: ifeq -> 92
      //   77: aload #4
      //   79: aload #4
      //   81: getfield currentPos : I
      //   84: iconst_1
      //   85: isub
      //   86: putfield currentPos : I
      //   89: goto -> 53
      //   92: aload #4
      //   94: aload #4
      //   96: getfield currentPos : I
      //   99: iconst_1
      //   100: iadd
      //   101: putfield currentPos : I
      //   104: goto -> 53
      //   107: aload_0
      //   108: areturn
    }
    
    public int convertNewPositionToOld(int param1Int) {
      if (param1Int >= 0 && param1Int < this.mNewListSize) {
        param1Int = this.mNewItemStatuses[param1Int];
        return ((param1Int & 0xF) == 0) ? -1 : (param1Int >> 4);
      } 
      StringBuilder stringBuilder = new StringBuilder("Index out of bounds - passed position = ");
      stringBuilder.append(param1Int);
      stringBuilder.append(", new list size = ");
      stringBuilder.append(this.mNewListSize);
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    public int convertOldPositionToNew(int param1Int) {
      if (param1Int >= 0 && param1Int < this.mOldListSize) {
        param1Int = this.mOldItemStatuses[param1Int];
        return ((param1Int & 0xF) == 0) ? -1 : (param1Int >> 4);
      } 
      StringBuilder stringBuilder = new StringBuilder("Index out of bounds - passed position = ");
      stringBuilder.append(param1Int);
      stringBuilder.append(", old list size = ");
      stringBuilder.append(this.mOldListSize);
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    public void dispatchUpdatesTo(ListUpdateCallback param1ListUpdateCallback) {
      BatchingListUpdateCallback batchingListUpdateCallback;
      if (param1ListUpdateCallback instanceof BatchingListUpdateCallback) {
        batchingListUpdateCallback = (BatchingListUpdateCallback)param1ListUpdateCallback;
      } else {
        batchingListUpdateCallback = new BatchingListUpdateCallback((ListUpdateCallback)batchingListUpdateCallback);
      } 
      int i = this.mOldListSize;
      ArrayDeque<DiffUtil.PostponedUpdate> arrayDeque = new ArrayDeque();
      int k = this.mOldListSize;
      int j = this.mNewListSize;
      int m;
      for (m = this.mDiagonals.size() - 1; m >= 0; m--) {
        int i1;
        int i2;
        DiffUtil.Diagonal diagonal = this.mDiagonals.get(m);
        int i4 = diagonal.endX();
        int i3 = diagonal.endY();
        int n = k;
        k = i;
        while (true) {
          i2 = 0;
          i = k;
          i1 = j;
          if (n > i4) {
            i = n - 1;
            i1 = this.mOldItemStatuses[i];
            if ((i1 & 0xC) != 0) {
              i2 = i1 >> 4;
              DiffUtil.PostponedUpdate postponedUpdate = getPostponedUpdate(arrayDeque, i2, false);
              if (postponedUpdate != null) {
                int i5 = k - postponedUpdate.currentPos - 1;
                batchingListUpdateCallback.onMoved(i, i5);
                n = i;
                if ((i1 & 0x4) != 0) {
                  batchingListUpdateCallback.onChanged(i5, 1, this.mCallback.getChangePayload(i, i2));
                  n = i;
                } 
                continue;
              } 
              arrayDeque.add(new DiffUtil.PostponedUpdate(i, k - i - 1, true));
              n = i;
              continue;
            } 
            batchingListUpdateCallback.onRemoved(i, 1);
            k--;
            n = i;
            continue;
          } 
          break;
        } 
        while (i1 > i3) {
          j = i1 - 1;
          k = this.mNewItemStatuses[j];
          if ((k & 0xC) != 0) {
            i4 = k >> 4;
            DiffUtil.PostponedUpdate postponedUpdate = getPostponedUpdate(arrayDeque, i4, true);
            if (postponedUpdate == null) {
              arrayDeque.add(new DiffUtil.PostponedUpdate(j, i - n, false));
              i1 = j;
              continue;
            } 
            batchingListUpdateCallback.onMoved(i - postponedUpdate.currentPos - 1, n);
            i1 = j;
            if ((k & 0x4) != 0) {
              batchingListUpdateCallback.onChanged(n, 1, this.mCallback.getChangePayload(i4, j));
              i1 = j;
            } 
            continue;
          } 
          batchingListUpdateCallback.onInserted(n, 1);
          i++;
          i1 = j;
        } 
        n = diagonal.x;
        k = diagonal.y;
        for (j = i2; j < diagonal.size; j++) {
          if ((this.mOldItemStatuses[n] & 0xF) == 2)
            batchingListUpdateCallback.onChanged(n, 1, this.mCallback.getChangePayload(n, k)); 
          n++;
          k++;
        } 
        k = diagonal.x;
        j = diagonal.y;
      } 
      batchingListUpdateCallback.dispatchLastEvent();
    }
    
    public void dispatchUpdatesTo(RecyclerView.Adapter param1Adapter) {
      dispatchUpdatesTo((ListUpdateCallback)new AdapterListUpdateCallback(param1Adapter));
    }
  }
  
  public static abstract class ItemCallback<T> {
    public abstract boolean areContentsTheSame(T param1T1, T param1T2);
    
    public abstract boolean areItemsTheSame(T param1T1, T param1T2);
    
    public Object getChangePayload(T param1T1, T param1T2) {
      return null;
    }
  }
  
  private static class PostponedUpdate {
    int currentPos;
    
    int posInOwnerList;
    
    boolean removal;
    
    PostponedUpdate(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.posInOwnerList = param1Int1;
      this.currentPos = param1Int2;
      this.removal = param1Boolean;
    }
  }
  
  static class Range {
    int newListEnd;
    
    int newListStart;
    
    int oldListEnd;
    
    int oldListStart;
    
    public Range() {}
    
    public Range(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.oldListStart = param1Int1;
      this.oldListEnd = param1Int2;
      this.newListStart = param1Int3;
      this.newListEnd = param1Int4;
    }
    
    int newSize() {
      return this.newListEnd - this.newListStart;
    }
    
    int oldSize() {
      return this.oldListEnd - this.oldListStart;
    }
  }
  
  static class Snake {
    public int endX;
    
    public int endY;
    
    public boolean reverse;
    
    public int startX;
    
    public int startY;
    
    int diagonalSize() {
      return Math.min(this.endX - this.startX, this.endY - this.startY);
    }
    
    boolean hasAdditionOrRemoval() {
      return (this.endY - this.startY != this.endX - this.startX);
    }
    
    boolean isAddition() {
      return (this.endY - this.startY > this.endX - this.startX);
    }
    
    DiffUtil.Diagonal toDiagonal() {
      if (hasAdditionOrRemoval())
        return this.reverse ? new DiffUtil.Diagonal(this.startX, this.startY, diagonalSize()) : (isAddition() ? new DiffUtil.Diagonal(this.startX, this.startY + 1, diagonalSize()) : new DiffUtil.Diagonal(this.startX + 1, this.startY, diagonalSize())); 
      int i = this.startX;
      return new DiffUtil.Diagonal(i, this.startY, this.endX - i);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\recyclerview\widget\DiffUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */