package androidx.privacysandbox.ads.adservices.internal;

import android.os.Build;
import android.os.ext.SdkExtensions;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\bÀ\002\030\0002\0020\001:\001\005B\007\b\002¢\006\002\020\002J\006\020\003\032\0020\004¨\006\006"}, d2 = {"Landroidx/privacysandbox/ads/adservices/internal/AdServicesInfo;", "", "()V", "version", "", "Extensions30Impl", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class AdServicesInfo {
  public static final AdServicesInfo INSTANCE = new AdServicesInfo();
  
  public final int version() {
    return (Build.VERSION.SDK_INT >= 30) ? Extensions30Impl.INSTANCE.getAdServicesVersion() : 0;
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\bÃ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\003\032\0020\004H\007¨\006\005"}, d2 = {"Landroidx/privacysandbox/ads/adservices/internal/AdServicesInfo$Extensions30Impl;", "", "()V", "getAdServicesVersion", "", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  private static final class Extensions30Impl {
    public static final Extensions30Impl INSTANCE = new Extensions30Impl();
    
    public final int getAdServicesVersion() {
      return SdkExtensions.getExtensionVersion(1000000);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\internal\AdServicesInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */