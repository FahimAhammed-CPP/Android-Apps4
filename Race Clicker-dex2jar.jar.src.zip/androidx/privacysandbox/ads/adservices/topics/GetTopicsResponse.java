package androidx.privacysandbox.ads.adservices.topics;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\000\n\002\020 \n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\002\n\002\020\b\n\000\n\002\020\016\n\000\030\0002\0020\001B\023\022\f\020\002\032\b\022\004\022\0020\0040\003¢\006\002\020\005J\023\020\b\032\0020\t2\b\020\n\032\004\030\0010\001H\002J\b\020\013\032\0020\fH\026J\b\020\r\032\0020\016H\026R\027\020\002\032\b\022\004\022\0020\0040\003¢\006\b\n\000\032\004\b\006\020\007¨\006\017"}, d2 = {"Landroidx/privacysandbox/ads/adservices/topics/GetTopicsResponse;", "", "topics", "", "Landroidx/privacysandbox/ads/adservices/topics/Topic;", "(Ljava/util/List;)V", "getTopics", "()Ljava/util/List;", "equals", "", "other", "hashCode", "", "toString", "", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class GetTopicsResponse {
  private final List<Topic> topics;
  
  public GetTopicsResponse(List<Topic> paramList) {
    this.topics = paramList;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof GetTopicsResponse))
      return false; 
    int i = this.topics.size();
    paramObject = paramObject;
    return (i != ((GetTopicsResponse)paramObject).topics.size()) ? false : Intrinsics.areEqual(new HashSet<Topic>(this.topics), new HashSet<Topic>(((GetTopicsResponse)paramObject).topics));
  }
  
  public final List<Topic> getTopics() {
    return this.topics;
  }
  
  public int hashCode() {
    return Objects.hash(new Object[] { this.topics });
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Topics=");
    stringBuilder.append(this.topics);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\topics\GetTopicsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */