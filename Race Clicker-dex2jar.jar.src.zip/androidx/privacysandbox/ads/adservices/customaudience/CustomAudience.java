package androidx.privacysandbox.ads.adservices.customaudience;

import android.net.Uri;
import androidx.privacysandbox.ads.adservices.common.AdData;
import androidx.privacysandbox.ads.adservices.common.AdSelectionSignals;
import androidx.privacysandbox.ads.adservices.common.AdTechIdentifier;
import java.time.Instant;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000N\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\022\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\003\030\0002\0020\001:\001*Bc\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\007\022\006\020\b\032\0020\007\022\f\020\t\032\b\022\004\022\0020\0130\n\022\n\b\002\020\f\032\004\030\0010\r\022\n\b\002\020\016\032\004\030\0010\r\022\n\b\002\020\017\032\004\030\0010\020\022\n\b\002\020\021\032\004\030\0010\022¢\006\002\020\023J\023\020$\032\0020%2\b\020&\032\004\030\0010\001H\002J\b\020'\032\0020(H\026J\b\020)\032\0020\005H\026R\023\020\f\032\004\030\0010\r¢\006\b\n\000\032\004\b\024\020\025R\027\020\t\032\b\022\004\022\0020\0130\n¢\006\b\n\000\032\004\b\026\020\027R\021\020\b\032\0020\007¢\006\b\n\000\032\004\b\030\020\031R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\032\020\033R\021\020\006\032\0020\007¢\006\b\n\000\032\004\b\034\020\031R\023\020\016\032\004\030\0010\r¢\006\b\n\000\032\004\b\035\020\025R\021\020\004\032\0020\005¢\006\b\n\000\032\004\b\036\020\037R\023\020\021\032\004\030\0010\022¢\006\b\n\000\032\004\b \020!R\023\020\017\032\004\030\0010\020¢\006\b\n\000\032\004\b\"\020#¨\006+"}, d2 = {"Landroidx/privacysandbox/ads/adservices/customaudience/CustomAudience;", "", "buyer", "Landroidx/privacysandbox/ads/adservices/common/AdTechIdentifier;", "name", "", "dailyUpdateUri", "Landroid/net/Uri;", "biddingLogicUri", "ads", "", "Landroidx/privacysandbox/ads/adservices/common/AdData;", "activationTime", "Ljava/time/Instant;", "expirationTime", "userBiddingSignals", "Landroidx/privacysandbox/ads/adservices/common/AdSelectionSignals;", "trustedBiddingSignals", "Landroidx/privacysandbox/ads/adservices/customaudience/TrustedBiddingData;", "(Landroidx/privacysandbox/ads/adservices/common/AdTechIdentifier;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;Ljava/util/List;Ljava/time/Instant;Ljava/time/Instant;Landroidx/privacysandbox/ads/adservices/common/AdSelectionSignals;Landroidx/privacysandbox/ads/adservices/customaudience/TrustedBiddingData;)V", "getActivationTime", "()Ljava/time/Instant;", "getAds", "()Ljava/util/List;", "getBiddingLogicUri", "()Landroid/net/Uri;", "getBuyer", "()Landroidx/privacysandbox/ads/adservices/common/AdTechIdentifier;", "getDailyUpdateUri", "getExpirationTime", "getName", "()Ljava/lang/String;", "getTrustedBiddingSignals", "()Landroidx/privacysandbox/ads/adservices/customaudience/TrustedBiddingData;", "getUserBiddingSignals", "()Landroidx/privacysandbox/ads/adservices/common/AdSelectionSignals;", "equals", "", "other", "hashCode", "", "toString", "Builder", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CustomAudience {
  private final Instant activationTime;
  
  private final List<AdData> ads;
  
  private final Uri biddingLogicUri;
  
  private final AdTechIdentifier buyer;
  
  private final Uri dailyUpdateUri;
  
  private final Instant expirationTime;
  
  private final String name;
  
  private final TrustedBiddingData trustedBiddingSignals;
  
  private final AdSelectionSignals userBiddingSignals;
  
  public CustomAudience(AdTechIdentifier paramAdTechIdentifier, String paramString, Uri paramUri1, Uri paramUri2, List<AdData> paramList, Instant paramInstant1, Instant paramInstant2, AdSelectionSignals paramAdSelectionSignals, TrustedBiddingData paramTrustedBiddingData) {
    this.buyer = paramAdTechIdentifier;
    this.name = paramString;
    this.dailyUpdateUri = paramUri1;
    this.biddingLogicUri = paramUri2;
    this.ads = paramList;
    this.activationTime = paramInstant1;
    this.expirationTime = paramInstant2;
    this.userBiddingSignals = paramAdSelectionSignals;
    this.trustedBiddingSignals = paramTrustedBiddingData;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof CustomAudience))
      return false; 
    AdTechIdentifier adTechIdentifier = this.buyer;
    paramObject = paramObject;
    return (Intrinsics.areEqual(adTechIdentifier, ((CustomAudience)paramObject).buyer) && Intrinsics.areEqual(this.name, ((CustomAudience)paramObject).name) && Intrinsics.areEqual(this.activationTime, ((CustomAudience)paramObject).activationTime) && Intrinsics.areEqual(this.expirationTime, ((CustomAudience)paramObject).expirationTime) && Intrinsics.areEqual(this.dailyUpdateUri, ((CustomAudience)paramObject).dailyUpdateUri) && Intrinsics.areEqual(this.userBiddingSignals, ((CustomAudience)paramObject).userBiddingSignals) && Intrinsics.areEqual(this.trustedBiddingSignals, ((CustomAudience)paramObject).trustedBiddingSignals) && Intrinsics.areEqual(this.ads, ((CustomAudience)paramObject).ads));
  }
  
  public final Instant getActivationTime() {
    return this.activationTime;
  }
  
  public final List<AdData> getAds() {
    return this.ads;
  }
  
  public final Uri getBiddingLogicUri() {
    return this.biddingLogicUri;
  }
  
  public final AdTechIdentifier getBuyer() {
    return this.buyer;
  }
  
  public final Uri getDailyUpdateUri() {
    return this.dailyUpdateUri;
  }
  
  public final Instant getExpirationTime() {
    return this.expirationTime;
  }
  
  public final String getName() {
    return this.name;
  }
  
  public final TrustedBiddingData getTrustedBiddingSignals() {
    return this.trustedBiddingSignals;
  }
  
  public final AdSelectionSignals getUserBiddingSignals() {
    return this.userBiddingSignals;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    int j = this.buyer.hashCode();
    int k = this.name.hashCode();
    Instant instant = this.activationTime;
    int i = 0;
    if (instant != null) {
      b1 = instant.hashCode();
    } else {
      b1 = 0;
    } 
    instant = this.expirationTime;
    if (instant != null) {
      b2 = instant.hashCode();
    } else {
      b2 = 0;
    } 
    int m = this.dailyUpdateUri.hashCode();
    AdSelectionSignals adSelectionSignals = this.userBiddingSignals;
    if (adSelectionSignals != null) {
      b3 = adSelectionSignals.hashCode();
    } else {
      b3 = 0;
    } 
    TrustedBiddingData trustedBiddingData = this.trustedBiddingSignals;
    if (trustedBiddingData != null)
      i = trustedBiddingData.hashCode(); 
    return (((((((j * 31 + k) * 31 + b1) * 31 + b2) * 31 + m) * 31 + b3) * 31 + i) * 31 + this.biddingLogicUri.hashCode()) * 31 + this.ads.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("CustomAudience: buyer=");
    stringBuilder.append(this.biddingLogicUri);
    stringBuilder.append(", activationTime=");
    stringBuilder.append(this.activationTime);
    stringBuilder.append(", expirationTime=");
    stringBuilder.append(this.expirationTime);
    stringBuilder.append(", dailyUpdateUri=");
    stringBuilder.append(this.dailyUpdateUri);
    stringBuilder.append(", userBiddingSignals=");
    stringBuilder.append(this.userBiddingSignals);
    stringBuilder.append(", trustedBiddingSignals=");
    stringBuilder.append(this.trustedBiddingSignals);
    stringBuilder.append(", biddingLogicUri=");
    stringBuilder.append(this.biddingLogicUri);
    stringBuilder.append(", ads=");
    stringBuilder.append(this.ads);
    return stringBuilder.toString();
  }
  
  @Metadata(d1 = {"\000F\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\013\030\0002\0020\001B3\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\007\022\006\020\b\032\0020\007\022\f\020\t\032\b\022\004\022\0020\0130\n¢\006\002\020\fJ\006\020\024\032\0020\025J\016\020\026\032\0020\0002\006\020\r\032\0020\016J\024\020\027\032\0020\0002\f\020\t\032\b\022\004\022\0020\0130\nJ\016\020\030\032\0020\0002\006\020\b\032\0020\007J\016\020\031\032\0020\0002\006\020\002\032\0020\003J\016\020\032\032\0020\0002\006\020\006\032\0020\007J\016\020\033\032\0020\0002\006\020\017\032\0020\016J\016\020\034\032\0020\0002\006\020\004\032\0020\005J\016\020\035\032\0020\0002\006\020\036\032\0020\021J\016\020\037\032\0020\0002\006\020\022\032\0020\023R\020\020\r\032\004\030\0010\016X\016¢\006\002\n\000R\024\020\t\032\b\022\004\022\0020\0130\nX\016¢\006\002\n\000R\016\020\b\032\0020\007X\016¢\006\002\n\000R\016\020\002\032\0020\003X\016¢\006\002\n\000R\016\020\006\032\0020\007X\016¢\006\002\n\000R\020\020\017\032\004\030\0010\016X\016¢\006\002\n\000R\016\020\004\032\0020\005X\016¢\006\002\n\000R\020\020\020\032\004\030\0010\021X\016¢\006\002\n\000R\020\020\022\032\004\030\0010\023X\016¢\006\002\n\000¨\006 "}, d2 = {"Landroidx/privacysandbox/ads/adservices/customaudience/CustomAudience$Builder;", "", "buyer", "Landroidx/privacysandbox/ads/adservices/common/AdTechIdentifier;", "name", "", "dailyUpdateUri", "Landroid/net/Uri;", "biddingLogicUri", "ads", "", "Landroidx/privacysandbox/ads/adservices/common/AdData;", "(Landroidx/privacysandbox/ads/adservices/common/AdTechIdentifier;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;Ljava/util/List;)V", "activationTime", "Ljava/time/Instant;", "expirationTime", "trustedBiddingData", "Landroidx/privacysandbox/ads/adservices/customaudience/TrustedBiddingData;", "userBiddingSignals", "Landroidx/privacysandbox/ads/adservices/common/AdSelectionSignals;", "build", "Landroidx/privacysandbox/ads/adservices/customaudience/CustomAudience;", "setActivationTime", "setAds", "setBiddingLogicUri", "setBuyer", "setDailyUpdateUri", "setExpirationTime", "setName", "setTrustedBiddingData", "trustedBiddingSignals", "setUserBiddingSignals", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Builder {
    private Instant activationTime;
    
    private List<AdData> ads;
    
    private Uri biddingLogicUri;
    
    private AdTechIdentifier buyer;
    
    private Uri dailyUpdateUri;
    
    private Instant expirationTime;
    
    private String name;
    
    private TrustedBiddingData trustedBiddingData;
    
    private AdSelectionSignals userBiddingSignals;
    
    public Builder(AdTechIdentifier param1AdTechIdentifier, String param1String, Uri param1Uri1, Uri param1Uri2, List<AdData> param1List) {
      this.buyer = param1AdTechIdentifier;
      this.name = param1String;
      this.dailyUpdateUri = param1Uri1;
      this.biddingLogicUri = param1Uri2;
      this.ads = param1List;
    }
    
    public final CustomAudience build() {
      return new CustomAudience(this.buyer, this.name, this.dailyUpdateUri, this.biddingLogicUri, this.ads, this.activationTime, this.expirationTime, this.userBiddingSignals, this.trustedBiddingData);
    }
    
    public final Builder setActivationTime(Instant param1Instant) {
      Intrinsics.checkNotNullParameter(param1Instant, "activationTime");
      Builder builder = this;
      this.activationTime = param1Instant;
      return this;
    }
    
    public final Builder setAds(List<AdData> param1List) {
      Intrinsics.checkNotNullParameter(param1List, "ads");
      Builder builder = this;
      this.ads = param1List;
      return this;
    }
    
    public final Builder setBiddingLogicUri(Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Uri, "biddingLogicUri");
      Builder builder = this;
      this.biddingLogicUri = param1Uri;
      return this;
    }
    
    public final Builder setBuyer(AdTechIdentifier param1AdTechIdentifier) {
      Intrinsics.checkNotNullParameter(param1AdTechIdentifier, "buyer");
      Builder builder = this;
      this.buyer = param1AdTechIdentifier;
      return this;
    }
    
    public final Builder setDailyUpdateUri(Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Uri, "dailyUpdateUri");
      Builder builder = this;
      this.dailyUpdateUri = param1Uri;
      return this;
    }
    
    public final Builder setExpirationTime(Instant param1Instant) {
      Intrinsics.checkNotNullParameter(param1Instant, "expirationTime");
      Builder builder = this;
      this.expirationTime = param1Instant;
      return this;
    }
    
    public final Builder setName(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "name");
      Builder builder = this;
      this.name = param1String;
      return this;
    }
    
    public final Builder setTrustedBiddingData(TrustedBiddingData param1TrustedBiddingData) {
      Intrinsics.checkNotNullParameter(param1TrustedBiddingData, "trustedBiddingSignals");
      Builder builder = this;
      this.trustedBiddingData = param1TrustedBiddingData;
      return this;
    }
    
    public final Builder setUserBiddingSignals(AdSelectionSignals param1AdSelectionSignals) {
      Intrinsics.checkNotNullParameter(param1AdSelectionSignals, "userBiddingSignals");
      Builder builder = this;
      this.userBiddingSignals = param1AdSelectionSignals;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\customaudience\CustomAudience.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */