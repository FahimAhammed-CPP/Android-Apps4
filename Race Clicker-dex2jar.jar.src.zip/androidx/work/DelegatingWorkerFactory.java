package androidx.work;

import android.content.Context;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DelegatingWorkerFactory extends WorkerFactory {
  private static final String TAG = Logger.tagWithPrefix("DelegatingWkrFctry");
  
  private final List<WorkerFactory> mFactories = new CopyOnWriteArrayList<WorkerFactory>();
  
  public final void addFactory(WorkerFactory paramWorkerFactory) {
    this.mFactories.add(paramWorkerFactory);
  }
  
  public final ListenableWorker createWorker(Context paramContext, String paramString, WorkerParameters paramWorkerParameters) {
    for (WorkerFactory workerFactory : this.mFactories) {
      try {
      
      } finally {
        paramString = String.format("Unable to instantiate a ListenableWorker (%s)", new Object[] { paramString });
        Logger.get().error(TAG, paramString, new Throwable[] { (Throwable)paramContext });
      } 
    } 
    return null;
  }
  
  List<WorkerFactory> getFactories() {
    return this.mFactories;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\DelegatingWorkerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */