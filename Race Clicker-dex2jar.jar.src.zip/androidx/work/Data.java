package androidx.work;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class Data {
  public static final Data EMPTY;
  
  public static final int MAX_DATA_BYTES = 10240;
  
  private static final String TAG = Logger.tagWithPrefix("Data");
  
  Map<String, Object> mValues;
  
  static {
    EMPTY = (new Builder()).build();
  }
  
  Data() {}
  
  public Data(Data paramData) {
    this.mValues = new HashMap<String, Object>(paramData.mValues);
  }
  
  public Data(Map<String, ?> paramMap) {
    this.mValues = new HashMap<String, Object>(paramMap);
  }
  
  public static Boolean[] convertPrimitiveBooleanArray(boolean[] paramArrayOfboolean) {
    Boolean[] arrayOfBoolean = new Boolean[paramArrayOfboolean.length];
    for (int i = 0; i < paramArrayOfboolean.length; i++)
      arrayOfBoolean[i] = Boolean.valueOf(paramArrayOfboolean[i]); 
    return arrayOfBoolean;
  }
  
  public static Byte[] convertPrimitiveByteArray(byte[] paramArrayOfbyte) {
    Byte[] arrayOfByte = new Byte[paramArrayOfbyte.length];
    for (int i = 0; i < paramArrayOfbyte.length; i++)
      arrayOfByte[i] = Byte.valueOf(paramArrayOfbyte[i]); 
    return arrayOfByte;
  }
  
  public static Double[] convertPrimitiveDoubleArray(double[] paramArrayOfdouble) {
    Double[] arrayOfDouble = new Double[paramArrayOfdouble.length];
    for (int i = 0; i < paramArrayOfdouble.length; i++)
      arrayOfDouble[i] = Double.valueOf(paramArrayOfdouble[i]); 
    return arrayOfDouble;
  }
  
  public static Float[] convertPrimitiveFloatArray(float[] paramArrayOffloat) {
    Float[] arrayOfFloat = new Float[paramArrayOffloat.length];
    for (int i = 0; i < paramArrayOffloat.length; i++)
      arrayOfFloat[i] = Float.valueOf(paramArrayOffloat[i]); 
    return arrayOfFloat;
  }
  
  public static Integer[] convertPrimitiveIntArray(int[] paramArrayOfint) {
    Integer[] arrayOfInteger = new Integer[paramArrayOfint.length];
    for (int i = 0; i < paramArrayOfint.length; i++)
      arrayOfInteger[i] = Integer.valueOf(paramArrayOfint[i]); 
    return arrayOfInteger;
  }
  
  public static Long[] convertPrimitiveLongArray(long[] paramArrayOflong) {
    Long[] arrayOfLong = new Long[paramArrayOflong.length];
    for (int i = 0; i < paramArrayOflong.length; i++)
      arrayOfLong[i] = Long.valueOf(paramArrayOflong[i]); 
    return arrayOfLong;
  }
  
  public static byte[] convertToPrimitiveArray(Byte[] paramArrayOfByte) {
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    for (int i = 0; i < paramArrayOfByte.length; i++)
      arrayOfByte[i] = paramArrayOfByte[i].byteValue(); 
    return arrayOfByte;
  }
  
  public static double[] convertToPrimitiveArray(Double[] paramArrayOfDouble) {
    double[] arrayOfDouble = new double[paramArrayOfDouble.length];
    for (int i = 0; i < paramArrayOfDouble.length; i++)
      arrayOfDouble[i] = paramArrayOfDouble[i].doubleValue(); 
    return arrayOfDouble;
  }
  
  public static float[] convertToPrimitiveArray(Float[] paramArrayOfFloat) {
    float[] arrayOfFloat = new float[paramArrayOfFloat.length];
    for (int i = 0; i < paramArrayOfFloat.length; i++)
      arrayOfFloat[i] = paramArrayOfFloat[i].floatValue(); 
    return arrayOfFloat;
  }
  
  public static int[] convertToPrimitiveArray(Integer[] paramArrayOfInteger) {
    int[] arrayOfInt = new int[paramArrayOfInteger.length];
    for (int i = 0; i < paramArrayOfInteger.length; i++)
      arrayOfInt[i] = paramArrayOfInteger[i].intValue(); 
    return arrayOfInt;
  }
  
  public static long[] convertToPrimitiveArray(Long[] paramArrayOfLong) {
    long[] arrayOfLong = new long[paramArrayOfLong.length];
    for (int i = 0; i < paramArrayOfLong.length; i++)
      arrayOfLong[i] = paramArrayOfLong[i].longValue(); 
    return arrayOfLong;
  }
  
  public static boolean[] convertToPrimitiveArray(Boolean[] paramArrayOfBoolean) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfBoolean.length];
    for (int i = 0; i < paramArrayOfBoolean.length; i++)
      arrayOfBoolean[i] = paramArrayOfBoolean[i].booleanValue(); 
    return arrayOfBoolean;
  }
  
  public static Data fromByteArray(byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: sipush #10240
    //   5: if_icmpgt -> 229
    //   8: new java/util/HashMap
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore #5
    //   17: new java/io/ByteArrayInputStream
    //   20: dup
    //   21: aload_0
    //   22: invokespecial <init> : ([B)V
    //   25: astore #4
    //   27: new java/io/ObjectInputStream
    //   30: dup
    //   31: aload #4
    //   33: invokespecial <init> : (Ljava/io/InputStream;)V
    //   36: astore_2
    //   37: aload_2
    //   38: astore_0
    //   39: aload_2
    //   40: invokevirtual readInt : ()I
    //   43: istore_1
    //   44: iload_1
    //   45: ifle -> 73
    //   48: aload_2
    //   49: astore_0
    //   50: aload #5
    //   52: aload_2
    //   53: invokevirtual readUTF : ()Ljava/lang/String;
    //   56: aload_2
    //   57: invokevirtual readObject : ()Ljava/lang/Object;
    //   60: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   65: pop
    //   66: iload_1
    //   67: iconst_1
    //   68: isub
    //   69: istore_1
    //   70: goto -> 44
    //   73: aload_2
    //   74: invokevirtual close : ()V
    //   77: goto -> 91
    //   80: astore_0
    //   81: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   84: ldc 'Error in Data#fromByteArray: '
    //   86: aload_0
    //   87: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   90: pop
    //   91: aload #4
    //   93: invokevirtual close : ()V
    //   96: goto -> 175
    //   99: astore_3
    //   100: goto -> 122
    //   103: astore_3
    //   104: goto -> 122
    //   107: astore_2
    //   108: aconst_null
    //   109: astore_0
    //   110: goto -> 186
    //   113: astore_0
    //   114: goto -> 118
    //   117: astore_0
    //   118: aconst_null
    //   119: astore_2
    //   120: aload_0
    //   121: astore_3
    //   122: aload_2
    //   123: astore_0
    //   124: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   127: ldc 'Error in Data#fromByteArray: '
    //   129: aload_3
    //   130: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   133: pop
    //   134: aload_2
    //   135: ifnull -> 156
    //   138: aload_2
    //   139: invokevirtual close : ()V
    //   142: goto -> 156
    //   145: astore_0
    //   146: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   149: ldc 'Error in Data#fromByteArray: '
    //   151: aload_0
    //   152: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   155: pop
    //   156: aload #4
    //   158: invokevirtual close : ()V
    //   161: goto -> 175
    //   164: astore_0
    //   165: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   168: ldc 'Error in Data#fromByteArray: '
    //   170: aload_0
    //   171: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   174: pop
    //   175: new androidx/work/Data
    //   178: dup
    //   179: aload #5
    //   181: invokespecial <init> : (Ljava/util/Map;)V
    //   184: areturn
    //   185: astore_2
    //   186: aload_0
    //   187: ifnull -> 208
    //   190: aload_0
    //   191: invokevirtual close : ()V
    //   194: goto -> 208
    //   197: astore_0
    //   198: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   201: ldc 'Error in Data#fromByteArray: '
    //   203: aload_0
    //   204: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   207: pop
    //   208: aload #4
    //   210: invokevirtual close : ()V
    //   213: goto -> 227
    //   216: astore_0
    //   217: getstatic androidx/work/Data.TAG : Ljava/lang/String;
    //   220: ldc 'Error in Data#fromByteArray: '
    //   222: aload_0
    //   223: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   226: pop
    //   227: aload_2
    //   228: athrow
    //   229: new java/lang/IllegalStateException
    //   232: dup
    //   233: ldc 'Data cannot occupy more than 10240 bytes when serialized'
    //   235: invokespecial <init> : (Ljava/lang/String;)V
    //   238: athrow
    // Exception table:
    //   from	to	target	type
    //   27	37	117	java/io/IOException
    //   27	37	113	java/lang/ClassNotFoundException
    //   27	37	107	finally
    //   39	44	103	java/io/IOException
    //   39	44	99	java/lang/ClassNotFoundException
    //   39	44	185	finally
    //   50	66	103	java/io/IOException
    //   50	66	99	java/lang/ClassNotFoundException
    //   50	66	185	finally
    //   73	77	80	java/io/IOException
    //   91	96	164	java/io/IOException
    //   124	134	185	finally
    //   138	142	145	java/io/IOException
    //   156	161	164	java/io/IOException
    //   190	194	197	java/io/IOException
    //   208	213	216	java/io/IOException
  }
  
  public static byte[] toByteArrayInternal(Data paramData) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    Data data2 = null;
    entry = null;
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      try {
        objectOutputStream.writeInt(paramData.size());
        for (Map.Entry<String, Object> entry : paramData.mValues.entrySet()) {
          objectOutputStream.writeUTF((String)entry.getKey());
          objectOutputStream.writeObject(entry.getValue());
        } 
        try {
          objectOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(TAG, "Error in Data#toByteArray: ", iOException1);
        } 
        try {
          byteArrayOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(TAG, "Error in Data#toByteArray: ", iOException1);
        } 
        if (byteArrayOutputStream.size() <= 10240)
          return byteArrayOutputStream.toByteArray(); 
        throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
      } catch (IOException iOException1) {
        ObjectOutputStream objectOutputStream1 = objectOutputStream;
      } finally {
        IOException iOException1;
        paramData = null;
      } 
    } catch (IOException iOException) {
      paramData = data2;
    } finally {}
    Data data1 = paramData;
    Log.e(TAG, "Error in Data#toByteArray: ", iOException);
    data1 = paramData;
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    if (paramData != null)
      try {
        paramData.close();
      } catch (IOException iOException1) {
        Log.e(TAG, "Error in Data#toByteArray: ", iOException1);
      }  
    try {
      byteArrayOutputStream.close();
      return arrayOfByte;
    } catch (IOException iOException1) {
      Log.e(TAG, "Error in Data#toByteArray: ", iOException1);
      return arrayOfByte;
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      Set<String> set = this.mValues.keySet();
      if (!set.equals(((Data)paramObject).mValues.keySet()))
        return false; 
      for (String str : set) {
        boolean bool;
        Object object = this.mValues.get(str);
        str = (String)((Data)paramObject).mValues.get(str);
        if (object == null || str == null) {
          if (object == str) {
            bool = true;
          } else {
            bool = false;
          } 
        } else if (object instanceof Object[] && str instanceof Object[]) {
          bool = Arrays.deepEquals((Object[])object, (Object[])str);
        } else {
          bool = object.equals(str);
        } 
        if (!bool)
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Boolean) ? ((Boolean)paramString).booleanValue() : paramBoolean;
  }
  
  public boolean[] getBooleanArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Boolean[]) ? convertToPrimitiveArray((Boolean[])paramString) : null;
  }
  
  public byte getByte(String paramString, byte paramByte) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Byte) ? ((Byte)paramString).byteValue() : paramByte;
  }
  
  public byte[] getByteArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Byte[]) ? convertToPrimitiveArray((Byte[])paramString) : null;
  }
  
  public double getDouble(String paramString, double paramDouble) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Double) ? ((Double)paramString).doubleValue() : paramDouble;
  }
  
  public double[] getDoubleArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Double[]) ? convertToPrimitiveArray((Double[])paramString) : null;
  }
  
  public float getFloat(String paramString, float paramFloat) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Float) ? ((Float)paramString).floatValue() : paramFloat;
  }
  
  public float[] getFloatArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Float[]) ? convertToPrimitiveArray((Float[])paramString) : null;
  }
  
  public int getInt(String paramString, int paramInt) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Integer) ? ((Integer)paramString).intValue() : paramInt;
  }
  
  public int[] getIntArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Integer[]) ? convertToPrimitiveArray((Integer[])paramString) : null;
  }
  
  public Map<String, Object> getKeyValueMap() {
    return Collections.unmodifiableMap(this.mValues);
  }
  
  public long getLong(String paramString, long paramLong) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Long) ? ((Long)paramString).longValue() : paramLong;
  }
  
  public long[] getLongArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof Long[]) ? convertToPrimitiveArray((Long[])paramString) : null;
  }
  
  public String getString(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof String) ? paramString : null;
  }
  
  public String[] getStringArray(String paramString) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString instanceof String[]) ? (String[])paramString : null;
  }
  
  public <T> boolean hasKeyWithValueOfType(String paramString, Class<T> paramClass) {
    paramString = (String)this.mValues.get(paramString);
    return (paramString != null && paramClass.isAssignableFrom(paramString.getClass()));
  }
  
  public int hashCode() {
    return this.mValues.hashCode() * 31;
  }
  
  public int size() {
    return this.mValues.size();
  }
  
  public byte[] toByteArray() {
    return toByteArrayInternal(this);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Data {");
    if (!this.mValues.isEmpty())
      for (String str : this.mValues.keySet()) {
        stringBuilder.append(str);
        stringBuilder.append(" : ");
        str = (String)this.mValues.get(str);
        if (str instanceof Object[]) {
          stringBuilder.append(Arrays.toString((Object[])str));
        } else {
          stringBuilder.append(str);
        } 
        stringBuilder.append(", ");
      }  
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static final class Builder {
    private Map<String, Object> mValues = new HashMap<String, Object>();
    
    public Data build() {
      Data data = new Data(this.mValues);
      Data.toByteArrayInternal(data);
      return data;
    }
    
    public Builder put(String param1String, Object param1Object) {
      if (param1Object == null) {
        this.mValues.put(param1String, null);
        return this;
      } 
      Class<?> clazz = param1Object.getClass();
      if (clazz == Boolean.class || clazz == Byte.class || clazz == Integer.class || clazz == Long.class || clazz == Float.class || clazz == Double.class || clazz == String.class || clazz == Boolean[].class || clazz == Byte[].class || clazz == Integer[].class || clazz == Long[].class || clazz == Float[].class || clazz == Double[].class || clazz == String[].class) {
        this.mValues.put(param1String, param1Object);
        return this;
      } 
      if (clazz == boolean[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveBooleanArray((boolean[])param1Object));
        return this;
      } 
      if (clazz == byte[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveByteArray((byte[])param1Object));
        return this;
      } 
      if (clazz == int[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveIntArray((int[])param1Object));
        return this;
      } 
      if (clazz == long[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveLongArray((long[])param1Object));
        return this;
      } 
      if (clazz == float[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveFloatArray((float[])param1Object));
        return this;
      } 
      if (clazz == double[].class) {
        this.mValues.put(param1String, Data.convertPrimitiveDoubleArray((double[])param1Object));
        return this;
      } 
      throw new IllegalArgumentException(String.format("Key %s has invalid type %s", new Object[] { param1String, clazz }));
    }
    
    public Builder putAll(Data param1Data) {
      putAll(param1Data.mValues);
      return this;
    }
    
    public Builder putAll(Map<String, Object> param1Map) {
      for (Map.Entry<String, Object> entry : param1Map.entrySet())
        put((String)entry.getKey(), entry.getValue()); 
      return this;
    }
    
    public Builder putBoolean(String param1String, boolean param1Boolean) {
      this.mValues.put(param1String, Boolean.valueOf(param1Boolean));
      return this;
    }
    
    public Builder putBooleanArray(String param1String, boolean[] param1ArrayOfboolean) {
      this.mValues.put(param1String, Data.convertPrimitiveBooleanArray(param1ArrayOfboolean));
      return this;
    }
    
    public Builder putByte(String param1String, byte param1Byte) {
      this.mValues.put(param1String, Byte.valueOf(param1Byte));
      return this;
    }
    
    public Builder putByteArray(String param1String, byte[] param1ArrayOfbyte) {
      this.mValues.put(param1String, Data.convertPrimitiveByteArray(param1ArrayOfbyte));
      return this;
    }
    
    public Builder putDouble(String param1String, double param1Double) {
      this.mValues.put(param1String, Double.valueOf(param1Double));
      return this;
    }
    
    public Builder putDoubleArray(String param1String, double[] param1ArrayOfdouble) {
      this.mValues.put(param1String, Data.convertPrimitiveDoubleArray(param1ArrayOfdouble));
      return this;
    }
    
    public Builder putFloat(String param1String, float param1Float) {
      this.mValues.put(param1String, Float.valueOf(param1Float));
      return this;
    }
    
    public Builder putFloatArray(String param1String, float[] param1ArrayOffloat) {
      this.mValues.put(param1String, Data.convertPrimitiveFloatArray(param1ArrayOffloat));
      return this;
    }
    
    public Builder putInt(String param1String, int param1Int) {
      this.mValues.put(param1String, Integer.valueOf(param1Int));
      return this;
    }
    
    public Builder putIntArray(String param1String, int[] param1ArrayOfint) {
      this.mValues.put(param1String, Data.convertPrimitiveIntArray(param1ArrayOfint));
      return this;
    }
    
    public Builder putLong(String param1String, long param1Long) {
      this.mValues.put(param1String, Long.valueOf(param1Long));
      return this;
    }
    
    public Builder putLongArray(String param1String, long[] param1ArrayOflong) {
      this.mValues.put(param1String, Data.convertPrimitiveLongArray(param1ArrayOflong));
      return this;
    }
    
    public Builder putString(String param1String1, String param1String2) {
      this.mValues.put(param1String1, param1String2);
      return this;
    }
    
    public Builder putStringArray(String param1String, String[] param1ArrayOfString) {
      this.mValues.put(param1String, param1ArrayOfString);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\Data.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */