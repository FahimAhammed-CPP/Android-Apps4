package androidx.work;

import androidx.lifecycle.LiveData;
import com.google.common.util.concurrent.ListenableFuture;

public interface Operation {
  public static final State.IN_PROGRESS IN_PROGRESS;
  
  public static final State.SUCCESS SUCCESS = new State.SUCCESS();
  
  static {
    IN_PROGRESS = new State.IN_PROGRESS();
  }
  
  ListenableFuture<State.SUCCESS> getResult();
  
  LiveData<State> getState();
  
  public static abstract class State {
    public static final class FAILURE extends State {
      private final Throwable mThrowable;
      
      public FAILURE(Throwable param2Throwable) {
        this.mThrowable = param2Throwable;
      }
      
      public Throwable getThrowable() {
        return this.mThrowable;
      }
      
      public String toString() {
        return String.format("FAILURE (%s)", new Object[] { this.mThrowable.getMessage() });
      }
    }
    
    public static final class IN_PROGRESS extends State {
      private IN_PROGRESS() {}
      
      public String toString() {
        return "IN_PROGRESS";
      }
    }
    
    public static final class SUCCESS extends State {
      private SUCCESS() {}
      
      public String toString() {
        return "SUCCESS";
      }
    }
  }
  
  public static final class FAILURE extends State {
    private final Throwable mThrowable;
    
    public FAILURE(Throwable param1Throwable) {
      this.mThrowable = param1Throwable;
    }
    
    public Throwable getThrowable() {
      return this.mThrowable;
    }
    
    public String toString() {
      return String.format("FAILURE (%s)", new Object[] { this.mThrowable.getMessage() });
    }
  }
  
  public static final class IN_PROGRESS extends State {
    private IN_PROGRESS() {}
    
    public String toString() {
      return "IN_PROGRESS";
    }
  }
  
  public static final class SUCCESS extends State {
    private SUCCESS() {}
    
    public String toString() {
      return "SUCCESS";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\Operation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */