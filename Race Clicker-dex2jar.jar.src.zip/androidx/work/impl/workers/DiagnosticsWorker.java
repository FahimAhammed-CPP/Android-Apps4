package androidx.work.impl.workers;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Logger;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.model.SystemIdInfo;
import androidx.work.impl.model.SystemIdInfoDao;
import androidx.work.impl.model.WorkNameDao;
import androidx.work.impl.model.WorkSpec;
import androidx.work.impl.model.WorkSpecDao;
import androidx.work.impl.model.WorkTagDao;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DiagnosticsWorker extends Worker {
  private static final String TAG = Logger.tagWithPrefix("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  private static String workSpecRow(WorkSpec paramWorkSpec, String paramString1, Integer paramInteger, String paramString2) {
    return String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", new Object[] { paramWorkSpec.id, paramWorkSpec.workerClassName, paramInteger, paramWorkSpec.state.name(), paramString1, paramString2 });
  }
  
  private static String workSpecRows(WorkNameDao paramWorkNameDao, WorkTagDao paramWorkTagDao, SystemIdInfoDao paramSystemIdInfoDao, List<WorkSpec> paramList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (WorkSpec workSpec : paramList) {
      SystemIdInfo systemIdInfo = paramSystemIdInfoDao.getSystemIdInfo(workSpec.id);
      if (systemIdInfo != null) {
        Integer integer = Integer.valueOf(systemIdInfo.systemId);
      } else {
        systemIdInfo = null;
      } 
      List list1 = paramWorkNameDao.getNamesForWorkSpecId(workSpec.id);
      List list2 = paramWorkTagDao.getTagsForWorkSpecId(workSpec.id);
      stringBuilder.append(workSpecRow(workSpec, TextUtils.join(",", list1), (Integer)systemIdInfo, TextUtils.join(",", list2)));
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.Result doWork() {
    WorkDatabase workDatabase = WorkManagerImpl.getInstance(getApplicationContext()).getWorkDatabase();
    WorkSpecDao workSpecDao = workDatabase.workSpecDao();
    WorkNameDao workNameDao = workDatabase.workNameDao();
    WorkTagDao workTagDao = workDatabase.workTagDao();
    SystemIdInfoDao systemIdInfoDao = workDatabase.systemIdInfoDao();
    List<WorkSpec> list3 = workSpecDao.getRecentlyCompletedWork(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L));
    List<WorkSpec> list2 = workSpecDao.getRunningWork();
    List<WorkSpec> list1 = workSpecDao.getAllEligibleWorkSpecsForScheduling(200);
    if (list3 != null && !list3.isEmpty()) {
      Logger logger = Logger.get();
      String str = TAG;
      logger.info(str, "Recently completed work:\n\n", new Throwable[0]);
      Logger.get().info(str, workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list3), new Throwable[0]);
    } 
    if (list2 != null && !list2.isEmpty()) {
      Logger logger = Logger.get();
      String str = TAG;
      logger.info(str, "Running work:\n\n", new Throwable[0]);
      Logger.get().info(str, workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list2), new Throwable[0]);
    } 
    if (list1 != null && !list1.isEmpty()) {
      Logger logger = Logger.get();
      String str = TAG;
      logger.info(str, "Enqueued work:\n\n", new Throwable[0]);
      Logger.get().info(str, workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list1), new Throwable[0]);
    } 
    return ListenableWorker.Result.success();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */