package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130903152;
    
    public static final int cardCornerRadius = 2130903153;
    
    public static final int cardElevation = 2130903154;
    
    public static final int cardMaxElevation = 2130903155;
    
    public static final int cardPreventCornerOverlap = 2130903156;
    
    public static final int cardUseCompatPadding = 2130903157;
    
    public static final int cardViewStyle = 2130903158;
    
    public static final int contentPadding = 2130903198;
    
    public static final int contentPaddingBottom = 2130903199;
    
    public static final int contentPaddingLeft = 2130903200;
    
    public static final int contentPaddingRight = 2130903201;
    
    public static final int contentPaddingTop = 2130903202;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131034196;
    
    public static final int cardview_light_background = 2131034197;
    
    public static final int cardview_shadow_end_color = 2131034198;
    
    public static final int cardview_shadow_start_color = 2131034199;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131099774;
    
    public static final int cardview_default_elevation = 2131099775;
    
    public static final int cardview_default_radius = 2131099776;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131886124;
    
    public static final int CardView = 2131886277;
    
    public static final int CardView_Dark = 2131886278;
    
    public static final int CardView_Light = 2131886279;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130903152, 2130903153, 2130903154, 2130903155, 2130903156, 2130903157, 2130903198, 2130903199, 
        2130903200, 2130903201, 2130903202 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */