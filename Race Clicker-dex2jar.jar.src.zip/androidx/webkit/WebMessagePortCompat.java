package androidx.webkit;

import android.os.Handler;
import android.webkit.WebMessagePort;
import java.lang.reflect.InvocationHandler;

public abstract class WebMessagePortCompat {
  public abstract void close();
  
  public abstract WebMessagePort getFrameworkPort();
  
  public abstract InvocationHandler getInvocationHandler();
  
  public abstract void postMessage(WebMessageCompat paramWebMessageCompat);
  
  public abstract void setWebMessageCallback(Handler paramHandler, WebMessageCallbackCompat paramWebMessageCallbackCompat);
  
  public abstract void setWebMessageCallback(WebMessageCallbackCompat paramWebMessageCallbackCompat);
  
  public static abstract class WebMessageCallbackCompat {
    public void onMessage(WebMessagePortCompat param1WebMessagePortCompat, WebMessageCompat param1WebMessageCompat) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\webkit\WebMessagePortCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */