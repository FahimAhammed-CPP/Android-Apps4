package androidx.webkit.internal;

import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.ServiceWorkerClientCompat;
import org.chromium.support_lib_boundary.ServiceWorkerClientBoundaryInterface;

public class ServiceWorkerClientAdapter implements ServiceWorkerClientBoundaryInterface {
  private final ServiceWorkerClientCompat mClient;
  
  public ServiceWorkerClientAdapter(ServiceWorkerClientCompat paramServiceWorkerClientCompat) {
    this.mClient = paramServiceWorkerClientCompat;
  }
  
  public String[] getSupportedFeatures() {
    return new String[] { "SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST" };
  }
  
  public WebResourceResponse shouldInterceptRequest(WebResourceRequest paramWebResourceRequest) {
    return this.mClient.shouldInterceptRequest(paramWebResourceRequest);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\webkit\internal\ServiceWorkerClientAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */