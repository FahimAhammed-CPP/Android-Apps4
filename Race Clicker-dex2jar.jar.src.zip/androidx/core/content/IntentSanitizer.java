package androidx.core.content;

import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.util.Consumer;
import androidx.core.util.Preconditions;
import androidx.core.util.Predicate;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class IntentSanitizer {
  private static final String TAG = "IntentSanitizer";
  
  private boolean mAllowAnyComponent;
  
  private boolean mAllowClipDataText;
  
  private boolean mAllowIdentifier;
  
  private boolean mAllowSelector;
  
  private boolean mAllowSourceBounds;
  
  private Predicate<String> mAllowedActions;
  
  private Predicate<String> mAllowedCategories;
  
  private Predicate<ClipData> mAllowedClipData;
  
  private Predicate<Uri> mAllowedClipDataUri;
  
  private Predicate<ComponentName> mAllowedComponents;
  
  private Predicate<Uri> mAllowedData;
  
  private Map<String, Predicate<Object>> mAllowedExtras;
  
  private int mAllowedFlags;
  
  private Predicate<String> mAllowedPackages;
  
  private Predicate<String> mAllowedTypes;
  
  private IntentSanitizer() {}
  
  private void putExtra(Intent paramIntent, String paramString, Object paramObject) {
    if (paramObject == null) {
      paramIntent.getExtras().putString(paramString, null);
      return;
    } 
    if (paramObject instanceof Parcelable) {
      paramIntent.putExtra(paramString, (Parcelable)paramObject);
      return;
    } 
    if (paramObject instanceof Parcelable[]) {
      paramIntent.putExtra(paramString, (Parcelable[])paramObject);
      return;
    } 
    if (paramObject instanceof Serializable) {
      paramIntent.putExtra(paramString, (Serializable)paramObject);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Unsupported type ");
    stringBuilder.append(paramObject.getClass());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public Intent sanitize(Intent paramIntent, Consumer<String> paramConsumer) {
    Intent intent = new Intent();
    ComponentName componentName = paramIntent.getComponent();
    if ((this.mAllowAnyComponent && componentName == null) || this.mAllowedComponents.test(componentName)) {
      intent.setComponent(componentName);
    } else {
      StringBuilder stringBuilder = new StringBuilder("Component is not allowed: ");
      stringBuilder.append(componentName);
      paramConsumer.accept(stringBuilder.toString());
      intent.setComponent(new ComponentName("android", "java.lang.Void"));
    } 
    String str2 = paramIntent.getPackage();
    if (str2 == null || this.mAllowedPackages.test(str2)) {
      intent.setPackage(str2);
    } else {
      StringBuilder stringBuilder = new StringBuilder("Package is not allowed: ");
      stringBuilder.append(str2);
      paramConsumer.accept(stringBuilder.toString());
    } 
    int i = this.mAllowedFlags;
    int j = paramIntent.getFlags();
    int k = this.mAllowedFlags;
    if ((i | j) == k) {
      intent.setFlags(paramIntent.getFlags());
    } else {
      intent.setFlags(paramIntent.getFlags() & k);
      StringBuilder stringBuilder = new StringBuilder("The intent contains flags that are not allowed: 0x");
      stringBuilder.append(Integer.toHexString(paramIntent.getFlags() & this.mAllowedFlags));
      paramConsumer.accept(stringBuilder.toString());
    } 
    str2 = paramIntent.getAction();
    if (str2 == null || this.mAllowedActions.test(str2)) {
      intent.setAction(str2);
    } else {
      StringBuilder stringBuilder = new StringBuilder("Action is not allowed: ");
      stringBuilder.append(str2);
      paramConsumer.accept(stringBuilder.toString());
    } 
    Uri uri = paramIntent.getData();
    if (uri == null || this.mAllowedData.test(uri)) {
      intent.setData(uri);
    } else {
      StringBuilder stringBuilder = new StringBuilder("Data is not allowed: ");
      stringBuilder.append(uri);
      paramConsumer.accept(stringBuilder.toString());
    } 
    String str1 = paramIntent.getType();
    if (str1 == null || this.mAllowedTypes.test(str1)) {
      intent.setDataAndType(intent.getData(), str1);
    } else {
      StringBuilder stringBuilder = new StringBuilder("Type is not allowed: ");
      stringBuilder.append(str1);
      paramConsumer.accept(stringBuilder.toString());
    } 
    Set set = paramIntent.getCategories();
    if (set != null)
      for (String str : set) {
        if (this.mAllowedCategories.test(str)) {
          intent.addCategory(str);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder("Category is not allowed: ");
        stringBuilder.append(str);
        paramConsumer.accept(stringBuilder.toString());
      }  
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null)
      for (String str : bundle.keySet()) {
        if (str.equals("android.intent.extra.STREAM") && (this.mAllowedFlags & 0x1) == 0) {
          paramConsumer.accept("Allowing Extra Stream requires also allowing at least  FLAG_GRANT_READ_URI_PERMISSION Flag.");
          continue;
        } 
        if (str.equals("output") && (this.mAllowedFlags & 0x3) != 0) {
          paramConsumer.accept("Allowing Extra Output requires also allowing FLAG_GRANT_READ_URI_PERMISSION and FLAG_GRANT_WRITE_URI_PERMISSION Flags.");
          continue;
        } 
        Object object = bundle.get(str);
        Predicate predicate = this.mAllowedExtras.get(str);
        if (predicate != null && predicate.test(object)) {
          putExtra(intent, str, object);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder("Extra is not allowed. Key: ");
        stringBuilder.append(str);
        stringBuilder.append(". Value: ");
        stringBuilder.append(object);
        paramConsumer.accept(stringBuilder.toString());
      }  
    Api16Impl.sanitizeClipData(paramIntent, intent, this.mAllowedClipData, this.mAllowClipDataText, this.mAllowedClipDataUri, paramConsumer);
    if (Build.VERSION.SDK_INT >= 29)
      if (this.mAllowIdentifier) {
        Api29Impl.setIdentifier(intent, Api29Impl.getIdentifier(paramIntent));
      } else if (Api29Impl.getIdentifier(paramIntent) != null) {
        StringBuilder stringBuilder = new StringBuilder("Identifier is not allowed: ");
        stringBuilder.append(Api29Impl.getIdentifier(paramIntent));
        paramConsumer.accept(stringBuilder.toString());
      }  
    if (this.mAllowSelector) {
      Api15Impl.setSelector(intent, Api15Impl.getSelector(paramIntent));
    } else if (Api15Impl.getSelector(paramIntent) != null) {
      StringBuilder stringBuilder = new StringBuilder("Selector is not allowed: ");
      stringBuilder.append(Api15Impl.getSelector(paramIntent));
      paramConsumer.accept(stringBuilder.toString());
    } 
    if (this.mAllowSourceBounds) {
      intent.setSourceBounds(paramIntent.getSourceBounds());
      return intent;
    } 
    if (paramIntent.getSourceBounds() != null) {
      StringBuilder stringBuilder = new StringBuilder("SourceBounds is not allowed: ");
      stringBuilder.append(paramIntent.getSourceBounds());
      paramConsumer.accept(stringBuilder.toString());
    } 
    return intent;
  }
  
  public Intent sanitizeByFiltering(Intent paramIntent) {
    return sanitize(paramIntent, (Consumer<String>)new IntentSanitizer$.ExternalSyntheticLambda0());
  }
  
  public Intent sanitizeByThrowing(Intent paramIntent) {
    return sanitize(paramIntent, (Consumer<String>)new IntentSanitizer$.ExternalSyntheticLambda1());
  }
  
  private static class Api15Impl {
    static Intent getSelector(Intent param1Intent) {
      return param1Intent.getSelector();
    }
    
    static void setSelector(Intent param1Intent1, Intent param1Intent2) {
      param1Intent1.setSelector(param1Intent2);
    }
  }
  
  private static class Api16Impl {
    private static void checkOtherMembers(int param1Int, ClipData.Item param1Item, Consumer<String> param1Consumer) {
      if (param1Item.getHtmlText() != null || param1Item.getIntent() != null) {
        StringBuilder stringBuilder = new StringBuilder("ClipData item at position ");
        stringBuilder.append(param1Int);
        stringBuilder.append(" contains htmlText, textLinks or intent: ");
        stringBuilder.append(param1Item);
        param1Consumer.accept(stringBuilder.toString());
      } 
    }
    
    static void sanitizeClipData(Intent param1Intent1, Intent param1Intent2, Predicate<ClipData> param1Predicate, boolean param1Boolean, Predicate<Uri> param1Predicate1, Consumer<String> param1Consumer) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual getClipData : ()Landroid/content/ClipData;
      //   4: astore #9
      //   6: aload #9
      //   8: ifnonnull -> 12
      //   11: return
      //   12: aload_2
      //   13: ifnull -> 34
      //   16: aload_2
      //   17: aload #9
      //   19: invokeinterface test : (Ljava/lang/Object;)Z
      //   24: ifeq -> 34
      //   27: aload_1
      //   28: aload #9
      //   30: invokevirtual setClipData : (Landroid/content/ClipData;)V
      //   33: return
      //   34: iconst_0
      //   35: istore #6
      //   37: aconst_null
      //   38: astore_0
      //   39: iload #6
      //   41: aload #9
      //   43: invokevirtual getItemCount : ()I
      //   46: if_icmpge -> 384
      //   49: aload #9
      //   51: iload #6
      //   53: invokevirtual getItemAt : (I)Landroid/content/ClipData$Item;
      //   56: astore #7
      //   58: getstatic android/os/Build$VERSION.SDK_INT : I
      //   61: bipush #31
      //   63: if_icmplt -> 78
      //   66: iload #6
      //   68: aload #7
      //   70: aload #5
      //   72: invokestatic checkOtherMembers : (ILandroid/content/ClipData$Item;Landroidx/core/util/Consumer;)V
      //   75: goto -> 87
      //   78: iload #6
      //   80: aload #7
      //   82: aload #5
      //   84: invokestatic checkOtherMembers : (ILandroid/content/ClipData$Item;Landroidx/core/util/Consumer;)V
      //   87: iload_3
      //   88: ifeq -> 100
      //   91: aload #7
      //   93: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   96: astore_2
      //   97: goto -> 155
      //   100: aload #7
      //   102: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   105: ifnull -> 153
      //   108: new java/lang/StringBuilder
      //   111: dup
      //   112: ldc 'Item text cannot contain value. Item position: '
      //   114: invokespecial <init> : (Ljava/lang/String;)V
      //   117: astore_2
      //   118: aload_2
      //   119: iload #6
      //   121: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   124: pop
      //   125: aload_2
      //   126: ldc '. Text: '
      //   128: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   131: pop
      //   132: aload_2
      //   133: aload #7
      //   135: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   138: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   141: pop
      //   142: aload #5
      //   144: aload_2
      //   145: invokevirtual toString : ()Ljava/lang/String;
      //   148: invokeinterface accept : (Ljava/lang/Object;)V
      //   153: aconst_null
      //   154: astore_2
      //   155: aload #4
      //   157: ifnonnull -> 221
      //   160: aload #7
      //   162: invokevirtual getUri : ()Landroid/net/Uri;
      //   165: ifnull -> 297
      //   168: new java/lang/StringBuilder
      //   171: dup
      //   172: ldc 'Item URI is not allowed. Item position: '
      //   174: invokespecial <init> : (Ljava/lang/String;)V
      //   177: astore #8
      //   179: aload #8
      //   181: iload #6
      //   183: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   186: pop
      //   187: aload #8
      //   189: ldc '. URI: '
      //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   194: pop
      //   195: aload #8
      //   197: aload #7
      //   199: invokevirtual getUri : ()Landroid/net/Uri;
      //   202: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   205: pop
      //   206: aload #5
      //   208: aload #8
      //   210: invokevirtual toString : ()Ljava/lang/String;
      //   213: invokeinterface accept : (Ljava/lang/Object;)V
      //   218: goto -> 297
      //   221: aload #7
      //   223: invokevirtual getUri : ()Landroid/net/Uri;
      //   226: ifnull -> 303
      //   229: aload #4
      //   231: aload #7
      //   233: invokevirtual getUri : ()Landroid/net/Uri;
      //   236: invokeinterface test : (Ljava/lang/Object;)Z
      //   241: ifeq -> 247
      //   244: goto -> 303
      //   247: new java/lang/StringBuilder
      //   250: dup
      //   251: ldc 'Item URI is not allowed. Item position: '
      //   253: invokespecial <init> : (Ljava/lang/String;)V
      //   256: astore #8
      //   258: aload #8
      //   260: iload #6
      //   262: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   265: pop
      //   266: aload #8
      //   268: ldc '. URI: '
      //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   273: pop
      //   274: aload #8
      //   276: aload #7
      //   278: invokevirtual getUri : ()Landroid/net/Uri;
      //   281: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   284: pop
      //   285: aload #5
      //   287: aload #8
      //   289: invokevirtual toString : ()Ljava/lang/String;
      //   292: invokeinterface accept : (Ljava/lang/Object;)V
      //   297: aconst_null
      //   298: astore #7
      //   300: goto -> 310
      //   303: aload #7
      //   305: invokevirtual getUri : ()Landroid/net/Uri;
      //   308: astore #7
      //   310: aload_2
      //   311: ifnonnull -> 322
      //   314: aload_0
      //   315: astore #8
      //   317: aload #7
      //   319: ifnull -> 372
      //   322: aload_0
      //   323: ifnonnull -> 354
      //   326: new android/content/ClipData
      //   329: dup
      //   330: aload #9
      //   332: invokevirtual getDescription : ()Landroid/content/ClipDescription;
      //   335: new android/content/ClipData$Item
      //   338: dup
      //   339: aload_2
      //   340: aconst_null
      //   341: aload #7
      //   343: invokespecial <init> : (Ljava/lang/CharSequence;Landroid/content/Intent;Landroid/net/Uri;)V
      //   346: invokespecial <init> : (Landroid/content/ClipDescription;Landroid/content/ClipData$Item;)V
      //   349: astore #8
      //   351: goto -> 372
      //   354: aload_0
      //   355: new android/content/ClipData$Item
      //   358: dup
      //   359: aload_2
      //   360: aconst_null
      //   361: aload #7
      //   363: invokespecial <init> : (Ljava/lang/CharSequence;Landroid/content/Intent;Landroid/net/Uri;)V
      //   366: invokevirtual addItem : (Landroid/content/ClipData$Item;)V
      //   369: aload_0
      //   370: astore #8
      //   372: iload #6
      //   374: iconst_1
      //   375: iadd
      //   376: istore #6
      //   378: aload #8
      //   380: astore_0
      //   381: goto -> 39
      //   384: aload_0
      //   385: ifnull -> 393
      //   388: aload_1
      //   389: aload_0
      //   390: invokevirtual setClipData : (Landroid/content/ClipData;)V
      //   393: return
    }
    
    private static class Api31Impl {
      static void checkOtherMembers(int param2Int, ClipData.Item param2Item, Consumer<String> param2Consumer) {
        if (param2Item.getHtmlText() != null || param2Item.getIntent() != null || param2Item.getTextLinks() != null) {
          StringBuilder stringBuilder = new StringBuilder("ClipData item at position ");
          stringBuilder.append(param2Int);
          stringBuilder.append(" contains htmlText, textLinks or intent: ");
          stringBuilder.append(param2Item);
          param2Consumer.accept(stringBuilder.toString());
        } 
      }
    }
  }
  
  private static class Api31Impl {
    static void checkOtherMembers(int param1Int, ClipData.Item param1Item, Consumer<String> param1Consumer) {
      if (param1Item.getHtmlText() != null || param1Item.getIntent() != null || param1Item.getTextLinks() != null) {
        StringBuilder stringBuilder = new StringBuilder("ClipData item at position ");
        stringBuilder.append(param1Int);
        stringBuilder.append(" contains htmlText, textLinks or intent: ");
        stringBuilder.append(param1Item);
        param1Consumer.accept(stringBuilder.toString());
      } 
    }
  }
  
  private static class Api29Impl {
    static String getIdentifier(Intent param1Intent) {
      return param1Intent.getIdentifier();
    }
    
    static Intent setIdentifier(Intent param1Intent, String param1String) {
      return param1Intent.setIdentifier(param1String);
    }
  }
  
  public static final class Builder {
    private static final int HISTORY_STACK_FLAGS = 2112614400;
    
    private static final int RECEIVER_FLAGS = 2015363072;
    
    private boolean mAllowAnyComponent;
    
    private boolean mAllowClipDataText = false;
    
    private boolean mAllowIdentifier;
    
    private boolean mAllowSelector;
    
    private boolean mAllowSomeComponents;
    
    private boolean mAllowSourceBounds;
    
    private Predicate<String> mAllowedActions = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda11();
    
    private Predicate<String> mAllowedCategories = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda14();
    
    private Predicate<ClipData> mAllowedClipData = (Predicate<ClipData>)new IntentSanitizer$Builder$.ExternalSyntheticLambda18();
    
    private Predicate<Uri> mAllowedClipDataUri = (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda17();
    
    private Predicate<ComponentName> mAllowedComponents = (Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda16();
    
    private Predicate<Uri> mAllowedData = (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda12();
    
    private Map<String, Predicate<Object>> mAllowedExtras = new HashMap<String, Predicate<Object>>();
    
    private int mAllowedFlags;
    
    private Predicate<String> mAllowedPackages = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda15();
    
    private Predicate<String> mAllowedTypes = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda13();
    
    public Builder allowAction(Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedActions = this.mAllowedActions.or(param1Predicate);
      return this;
    }
    
    public Builder allowAction(String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      allowAction((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda2(param1String));
      return this;
    }
    
    public Builder allowAnyComponent() {
      this.mAllowAnyComponent = true;
      this.mAllowedComponents = (Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda4();
      return this;
    }
    
    public Builder allowCategory(Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedCategories = this.mAllowedCategories.or(param1Predicate);
      return this;
    }
    
    public Builder allowCategory(String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowCategory((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda2(param1String));
    }
    
    public Builder allowClipData(Predicate<ClipData> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedClipData = this.mAllowedClipData.or(param1Predicate);
      return this;
    }
    
    public Builder allowClipDataText() {
      this.mAllowClipDataText = true;
      return this;
    }
    
    public Builder allowClipDataUri(Predicate<Uri> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedClipDataUri = this.mAllowedClipDataUri.or(param1Predicate);
      return this;
    }
    
    public Builder allowClipDataUriWithAuthority(String param1String) {
      Preconditions.checkNotNull(param1String);
      return allowClipDataUri((Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda1(param1String));
    }
    
    public Builder allowComponent(ComponentName param1ComponentName) {
      Preconditions.checkNotNull(param1ComponentName);
      Objects.requireNonNull(param1ComponentName);
      return allowComponent((Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda9(param1ComponentName));
    }
    
    public Builder allowComponent(Predicate<ComponentName> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowSomeComponents = true;
      this.mAllowedComponents = this.mAllowedComponents.or(param1Predicate);
      return this;
    }
    
    public Builder allowComponentWithPackage(String param1String) {
      Preconditions.checkNotNull(param1String);
      return allowComponent((Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda6(param1String));
    }
    
    public Builder allowData(Predicate<Uri> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedData = this.mAllowedData.or(param1Predicate);
      return this;
    }
    
    public Builder allowDataWithAuthority(String param1String) {
      Preconditions.checkNotNull(param1String);
      allowData((Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda7(param1String));
      return this;
    }
    
    public Builder allowExtra(String param1String, Predicate<Object> param1Predicate) {
      IntentSanitizer$Builder$.ExternalSyntheticLambda0 externalSyntheticLambda0;
      Preconditions.checkNotNull(param1String);
      Preconditions.checkNotNull(param1Predicate);
      Predicate predicate2 = this.mAllowedExtras.get(param1String);
      Predicate predicate1 = predicate2;
      if (predicate2 == null)
        externalSyntheticLambda0 = new IntentSanitizer$Builder$.ExternalSyntheticLambda0(); 
      param1Predicate = externalSyntheticLambda0.or(param1Predicate);
      this.mAllowedExtras.put(param1String, param1Predicate);
      return this;
    }
    
    public Builder allowExtra(String param1String, Class<?> param1Class) {
      return allowExtra(param1String, param1Class, (Predicate<?>)new IntentSanitizer$Builder$.ExternalSyntheticLambda10());
    }
    
    public <T> Builder allowExtra(String param1String, Class<T> param1Class, Predicate<T> param1Predicate) {
      Preconditions.checkNotNull(param1String);
      Preconditions.checkNotNull(param1Class);
      Preconditions.checkNotNull(param1Predicate);
      return allowExtra(param1String, (Predicate<Object>)new IntentSanitizer$Builder$.ExternalSyntheticLambda5(param1Class, param1Predicate));
    }
    
    public Builder allowExtraOutput(Predicate<Uri> param1Predicate) {
      allowExtra("output", Uri.class, param1Predicate);
      return this;
    }
    
    public Builder allowExtraOutput(String param1String) {
      allowExtra("output", Uri.class, (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda8(param1String));
      return this;
    }
    
    public Builder allowExtraStream(Predicate<Uri> param1Predicate) {
      allowExtra("android.intent.extra.STREAM", Uri.class, param1Predicate);
      return this;
    }
    
    public Builder allowExtraStreamUriWithAuthority(String param1String) {
      Preconditions.checkNotNull(param1String);
      allowExtra("android.intent.extra.STREAM", Uri.class, (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda3(param1String));
      return this;
    }
    
    public Builder allowFlags(int param1Int) {
      this.mAllowedFlags = param1Int | this.mAllowedFlags;
      return this;
    }
    
    public Builder allowHistoryStackFlags() {
      this.mAllowedFlags |= 0x7DEBF000;
      return this;
    }
    
    public Builder allowIdentifier() {
      this.mAllowIdentifier = true;
      return this;
    }
    
    public Builder allowPackage(Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedPackages = this.mAllowedPackages.or(param1Predicate);
      return this;
    }
    
    public Builder allowPackage(String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowPackage((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda2(param1String));
    }
    
    public Builder allowReceiverFlags() {
      this.mAllowedFlags |= 0x78200000;
      return this;
    }
    
    public Builder allowSelector() {
      this.mAllowSelector = true;
      return this;
    }
    
    public Builder allowSourceBounds() {
      this.mAllowSourceBounds = true;
      return this;
    }
    
    public Builder allowType(Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedTypes = this.mAllowedTypes.or(param1Predicate);
      return this;
    }
    
    public Builder allowType(String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowType((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda2(param1String));
    }
    
    public IntentSanitizer build() {
      boolean bool = this.mAllowAnyComponent;
      if ((!bool || !this.mAllowSomeComponents) && (bool || this.mAllowSomeComponents)) {
        IntentSanitizer intentSanitizer = new IntentSanitizer();
        IntentSanitizer.access$102(intentSanitizer, this.mAllowedFlags);
        IntentSanitizer.access$202(intentSanitizer, this.mAllowedActions);
        IntentSanitizer.access$302(intentSanitizer, this.mAllowedData);
        IntentSanitizer.access$402(intentSanitizer, this.mAllowedTypes);
        IntentSanitizer.access$502(intentSanitizer, this.mAllowedCategories);
        IntentSanitizer.access$602(intentSanitizer, this.mAllowedPackages);
        IntentSanitizer.access$702(intentSanitizer, this.mAllowAnyComponent);
        IntentSanitizer.access$802(intentSanitizer, this.mAllowedComponents);
        IntentSanitizer.access$902(intentSanitizer, this.mAllowedExtras);
        IntentSanitizer.access$1002(intentSanitizer, this.mAllowClipDataText);
        IntentSanitizer.access$1102(intentSanitizer, this.mAllowedClipDataUri);
        IntentSanitizer.access$1202(intentSanitizer, this.mAllowedClipData);
        IntentSanitizer.access$1302(intentSanitizer, this.mAllowIdentifier);
        IntentSanitizer.access$1402(intentSanitizer, this.mAllowSelector);
        IntentSanitizer.access$1502(intentSanitizer, this.mAllowSourceBounds);
        return intentSanitizer;
      } 
      throw new SecurityException("You must call either allowAnyComponent or one or more of the allowComponent methods; but not both.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\core\content\IntentSanitizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */