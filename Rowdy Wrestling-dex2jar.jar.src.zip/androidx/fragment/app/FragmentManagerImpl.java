package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.collection.ArraySet;
import androidx.core.util.DebugUtils;
import androidx.core.util.LogWriter;
import androidx.core.view.OneShotPreDrawListener;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  final HashMap<String, Fragment> mActive = new HashMap<String, Fragment>();
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder> mLifecycleCallbacks = new CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  private FragmentManagerViewModel mNonConfig;
  
  private final OnBackPressedCallback mOnBackPressedCallback = new OnBackPressedCallback(false) {
      public void handleOnBackPressed() {
        FragmentManagerImpl.this.handleOnBackPressed();
      }
    };
  
  private OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  boolean mStopped;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    int i = this.mCurState;
    if (i < 1)
      return; 
    int j = Math.min(i, 3);
    int k = this.mAdded.size();
    for (i = 0; i < k; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mState < j) {
        moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void animateRemoveFragment(final Fragment fragment, AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    EndViewTransitionAnimation endViewTransitionAnimation;
    final View viewToAnimate = fragment.mView;
    final ViewGroup container = fragment.mContainer;
    viewGroup.startViewTransition(view);
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      endViewTransitionAnimation = new EndViewTransitionAnimation(paramAnimationOrAnimator.animation, viewGroup, view);
      fragment.setAnimatingAway(fragment.mView);
      endViewTransitionAnimation.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd(Animation param1Animation) {
              container.post(new Runnable() {
                    public void run() {
                      if (fragment.getAnimatingAway() != null) {
                        fragment.setAnimatingAway(null);
                        FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
            
            public void onAnimationRepeat(Animation param1Animation) {}
            
            public void onAnimationStart(Animation param1Animation) {}
          });
      fragment.mView.startAnimation((Animation)endViewTransitionAnimation);
      return;
    } 
    Animator animator = ((AnimationOrAnimator)endViewTransitionAnimation).animator;
    fragment.setAnimator(((AnimationOrAnimator)endViewTransitionAnimation).animator);
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            container.endViewTransition(viewToAnimate);
            param1Animator = fragment.getAnimator();
            fragment.setAnimator(null);
            if (param1Animator != null && container.indexOfChild(viewToAnimate) < 0) {
              FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
              Fragment fragment = fragment;
              fragmentManagerImpl.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
            } 
          }
        });
    animator.setTarget(fragment.mView);
    animator.start();
  }
  
  private void burpActive() {
    this.mActive.values().removeAll(Collections.singleton(null));
  }
  
  private void checkStateLoss() {
    if (!isStateSaved())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void dispatchParentPrimaryNavigationFragmentChanged(Fragment paramFragment) {
    if (paramFragment != null && this.mActive.get(paramFragment.mWho) == paramFragment)
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        if (fragment.getAnimatingAway() != null) {
          int i = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          moveToState(fragment, i, 0, 0, false);
          continue;
        } 
        if (fragment.getAnimator() != null)
          fragment.getAnimator().end(); 
      } 
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost != null) {
        if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
          if (!paramBoolean)
            checkStateLoss(); 
          if (this.mTmpRecords == null) {
            this.mTmpRecords = new ArrayList<BackStackRecord>();
            this.mTmpIsPop = new ArrayList<Boolean>();
          } 
          this.mExecutingActions = true;
          try {
            executePostponedTransaction((ArrayList<BackStackRecord>)null, (ArrayList<Boolean>)null);
            return;
          } finally {
            this.mExecutingActions = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int i = paramInt1;
    boolean bool1 = ((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    int j = i;
    boolean bool = false;
    while (j < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (!((Boolean)paramArrayList1.get(j)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
      j++;
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool1) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      j = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } else {
      j = paramInt2;
    } 
    int k = i;
    if (j != i) {
      k = i;
      if (bool1) {
        FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, j, true);
        moveToState(this.mCurState, true);
        k = i;
      } 
    } 
    while (k < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(k);
      if (((Boolean)paramArrayList1.get(k)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      k++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_3
    //   13: goto -> 22
    //   16: aload #7
    //   18: invokevirtual size : ()I
    //   21: istore_3
    //   22: iconst_0
    //   23: istore #4
    //   25: iload_3
    //   26: istore #6
    //   28: iload #4
    //   30: iload #6
    //   32: if_icmpge -> 252
    //   35: aload_0
    //   36: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   39: iload #4
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/FragmentManagerImpl$StartEnterTransitionListener
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 119
    //   53: aload #7
    //   55: getfield mIsBack : Z
    //   58: ifne -> 119
    //   61: aload_1
    //   62: aload #7
    //   64: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore_3
    //   71: iload_3
    //   72: iconst_m1
    //   73: if_icmpeq -> 119
    //   76: aload_2
    //   77: iload_3
    //   78: invokevirtual get : (I)Ljava/lang/Object;
    //   81: checkcast java/lang/Boolean
    //   84: invokevirtual booleanValue : ()Z
    //   87: ifeq -> 119
    //   90: aload_0
    //   91: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   94: iload #4
    //   96: invokevirtual remove : (I)Ljava/lang/Object;
    //   99: pop
    //   100: iload #4
    //   102: iconst_1
    //   103: isub
    //   104: istore #5
    //   106: iload #6
    //   108: iconst_1
    //   109: isub
    //   110: istore_3
    //   111: aload #7
    //   113: invokevirtual cancelTransaction : ()V
    //   116: goto -> 240
    //   119: aload #7
    //   121: invokevirtual isReady : ()Z
    //   124: ifne -> 162
    //   127: iload #6
    //   129: istore_3
    //   130: iload #4
    //   132: istore #5
    //   134: aload_1
    //   135: ifnull -> 240
    //   138: iload #6
    //   140: istore_3
    //   141: iload #4
    //   143: istore #5
    //   145: aload #7
    //   147: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   150: aload_1
    //   151: iconst_0
    //   152: aload_1
    //   153: invokevirtual size : ()I
    //   156: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   159: ifeq -> 240
    //   162: aload_0
    //   163: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   166: iload #4
    //   168: invokevirtual remove : (I)Ljava/lang/Object;
    //   171: pop
    //   172: iload #4
    //   174: iconst_1
    //   175: isub
    //   176: istore #5
    //   178: iload #6
    //   180: iconst_1
    //   181: isub
    //   182: istore_3
    //   183: aload_1
    //   184: ifnull -> 235
    //   187: aload #7
    //   189: getfield mIsBack : Z
    //   192: ifne -> 235
    //   195: aload_1
    //   196: aload #7
    //   198: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   201: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   204: istore #4
    //   206: iload #4
    //   208: iconst_m1
    //   209: if_icmpeq -> 235
    //   212: aload_2
    //   213: iload #4
    //   215: invokevirtual get : (I)Ljava/lang/Object;
    //   218: checkcast java/lang/Boolean
    //   221: invokevirtual booleanValue : ()Z
    //   224: ifeq -> 235
    //   227: aload #7
    //   229: invokevirtual cancelTransaction : ()V
    //   232: goto -> 240
    //   235: aload #7
    //   237: invokevirtual completeTransaction : ()V
    //   240: iload #5
    //   242: iconst_1
    //   243: iadd
    //   244: istore #4
    //   246: iload_3
    //   247: istore #6
    //   249: goto -> 28
    //   252: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
        paramFragment = this.mAdded.get(i);
        if (paramFragment.mContainer == viewGroup && paramFragment.mView != null)
          return paramFragment; 
      } 
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPendingActions : Ljava/util/ArrayList;
    //   6: astore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #6
    //   12: ifnull -> 100
    //   15: aload #6
    //   17: invokevirtual size : ()I
    //   20: ifne -> 26
    //   23: goto -> 100
    //   26: aload_0
    //   27: getfield mPendingActions : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: istore #4
    //   35: iconst_0
    //   36: istore #5
    //   38: iload_3
    //   39: iload #4
    //   41: if_icmpge -> 74
    //   44: iload #5
    //   46: aload_0
    //   47: getfield mPendingActions : Ljava/util/ArrayList;
    //   50: iload_3
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   57: aload_1
    //   58: aload_2
    //   59: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   64: ior
    //   65: istore #5
    //   67: iload_3
    //   68: iconst_1
    //   69: iadd
    //   70: istore_3
    //   71: goto -> 38
    //   74: aload_0
    //   75: getfield mPendingActions : Ljava/util/ArrayList;
    //   78: invokevirtual clear : ()V
    //   81: aload_0
    //   82: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   85: invokevirtual getHandler : ()Landroid/os/Handler;
    //   88: aload_0
    //   89: getfield mExecCommit : Ljava/lang/Runnable;
    //   92: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   95: aload_0
    //   96: monitorexit
    //   97: iload #5
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: goto -> 112
    //   110: aload_1
    //   111: athrow
    //   112: goto -> 110
    // Exception table:
    //   from	to	target	type
    //   2	8	104	finally
    //   15	23	104	finally
    //   26	35	104	finally
    //   44	67	104	finally
    //   74	97	104	finally
    //   100	102	104	finally
    //   105	107	104	finally
  }
  
  private boolean isMenuAvailable(Fragment paramFragment) {
    return ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.checkForMenus());
  }
  
  static AnimationOrAnimator makeFadeAnimation(float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.requireView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().popBackStackImmediate())
      return true; 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        executePostponedTransaction(paramArrayList, paramArrayList1);
        int k = paramArrayList.size();
        int i = 0;
        int j;
        for (j = 0; i < k; j = m) {
          int n = i;
          int m = j;
          if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
            if (j != i)
              executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
            j = i + 1;
            m = j;
            if (((Boolean)paramArrayList1.get(i)).booleanValue())
              while (true) {
                m = j;
                if (j < k) {
                  m = j;
                  if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                    m = j;
                    if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                      j++;
                      continue;
                    } 
                  } 
                } 
                break;
              }  
            executeOpsTogether(paramArrayList, paramArrayList1, i, m);
            n = m - 1;
          } 
          i = n + 1;
        } 
        if (j != k)
          executeOpsTogether(paramArrayList, paramArrayList1, j, k); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", (FileDescriptor)null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", (FileDescriptor)null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  private void updateOnBackPressedCallbackEnabled() {
    ArrayList<OpGenerator> arrayList = this.mPendingActions;
    boolean bool = true;
    if (arrayList != null && !arrayList.isEmpty()) {
      this.mOnBackPressedCallback.setEnabled(true);
      return;
    } 
    OnBackPressedCallback onBackPressedCallback = this.mOnBackPressedCallback;
    if (getBackStackEntryCount() <= 0 || !isPrimaryNavigation(this.mParent))
      bool = false; 
    onBackPressedCallback.setEnabled(bool);
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    makeActive(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.mAdded.contains(paramFragment)) {
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          if (paramBoolean) {
            moveToState(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  void addRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.addRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 109
    //   11: aload_3
    //   12: invokevirtual size : ()I
    //   15: ifgt -> 21
    //   18: goto -> 109
    //   21: aload_0
    //   22: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   25: astore_3
    //   26: aload_3
    //   27: aload_3
    //   28: invokevirtual size : ()I
    //   31: iconst_1
    //   32: isub
    //   33: invokevirtual remove : (I)Ljava/lang/Object;
    //   36: checkcast java/lang/Integer
    //   39: invokevirtual intValue : ()I
    //   42: istore_2
    //   43: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   46: ifeq -> 95
    //   49: new java/lang/StringBuilder
    //   52: dup
    //   53: invokespecial <init> : ()V
    //   56: astore_3
    //   57: aload_3
    //   58: ldc_w 'Adding back stack index '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_3
    //   66: iload_2
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_3
    //   72: ldc_w ' with '
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: aload_3
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc 'FragmentManager'
    //   87: aload_3
    //   88: invokevirtual toString : ()Ljava/lang/String;
    //   91: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   94: pop
    //   95: aload_0
    //   96: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   99: iload_2
    //   100: aload_1
    //   101: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   104: pop
    //   105: aload_0
    //   106: monitorexit
    //   107: iload_2
    //   108: ireturn
    //   109: aload_0
    //   110: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   113: ifnonnull -> 127
    //   116: aload_0
    //   117: new java/util/ArrayList
    //   120: dup
    //   121: invokespecial <init> : ()V
    //   124: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   127: aload_0
    //   128: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   131: invokevirtual size : ()I
    //   134: istore_2
    //   135: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   138: ifeq -> 187
    //   141: new java/lang/StringBuilder
    //   144: dup
    //   145: invokespecial <init> : ()V
    //   148: astore_3
    //   149: aload_3
    //   150: ldc_w 'Setting back stack index '
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: aload_3
    //   158: iload_2
    //   159: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   162: pop
    //   163: aload_3
    //   164: ldc_w ' to '
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: aload_3
    //   172: aload_1
    //   173: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   176: pop
    //   177: ldc 'FragmentManager'
    //   179: aload_3
    //   180: invokevirtual toString : ()Ljava/lang/String;
    //   183: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   186: pop
    //   187: aload_0
    //   188: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   191: aload_1
    //   192: invokevirtual add : (Ljava/lang/Object;)Z
    //   195: pop
    //   196: aload_0
    //   197: monitorexit
    //   198: iload_2
    //   199: ireturn
    //   200: astore_1
    //   201: aload_0
    //   202: monitorexit
    //   203: aload_1
    //   204: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	200	finally
    //   11	18	200	finally
    //   21	95	200	finally
    //   95	107	200	finally
    //   109	127	200	finally
    //   127	187	200	finally
    //   187	198	200	finally
    //   201	203	200	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = paramFragment;
      if (paramFragment != null)
        updateOnBackPressedCallbackEnabled(); 
      if (paramFragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
        Fragment fragment;
        OnBackPressedDispatcherOwner onBackPressedDispatcherOwner = (OnBackPressedDispatcherOwner)paramFragmentHostCallback;
        OnBackPressedDispatcher onBackPressedDispatcher = onBackPressedDispatcherOwner.getOnBackPressedDispatcher();
        this.mOnBackPressedDispatcher = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.addCallback(fragment, this.mOnBackPressedCallback);
      } 
      if (paramFragment != null) {
        this.mNonConfig = paramFragment.mFragmentManager.getChildNonConfig(paramFragment);
        return;
      } 
      if (paramFragmentHostCallback instanceof ViewModelStoreOwner) {
        this.mNonConfig = FragmentManagerViewModel.getInstance(((ViewModelStoreOwner)paramFragmentHostCallback).getViewModelStore());
        return;
      } 
      this.mNonConfig = new FragmentManagerViewModel(false);
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.mAdded.contains(paramFragment)) {
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.mAdded) {
            this.mAdded.add(paramFragment);
            paramFragment.mAdded = true;
            if (isMenuAvailable(paramFragment)) {
              this.mNeedMenuInvalidate = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  boolean checkForMenus() {
    Iterator<Fragment> iterator = this.mActive.values().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = isMenuAvailable(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
        if (fragment.mPostponedAlpha > 0.0F)
          fragment.mView.setAlpha(fragment.mPostponedAlpha); 
        if (paramBoolean3) {
          fragment.mPostponedAlpha = 0.0F;
          continue;
        } 
        fragment.mPostponedAlpha = -1.0F;
        fragment.mIsNewlyAdded = false;
      } 
    } 
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, fragment.getNextTransition(), fragment.mHidden ^ true, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null && fragment.mHidden)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        fragment.mView.setVisibility(bool);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && isMenuAvailable(fragment))
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.mCurState;
    boolean bool1 = false;
    if (i < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    i = 0;
    boolean bool2;
    for (bool2 = false; i < this.mAdded.size(); bool2 = bool) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    if (this.mCreatedMenus != null)
      for (i = bool1; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool2;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
    if (this.mOnBackPressedDispatcher != null) {
      this.mOnBackPressedCallback.remove();
      this.mOnBackPressedDispatcher = null;
    } 
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(3);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int j = this.mCurState;
    int i = 0;
    if (j < 1)
      return false; 
    boolean bool;
    for (bool = false; i < this.mAdded.size(); bool = bool1) {
      Fragment fragment = this.mAdded.get(i);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      i++;
    } 
    return bool;
  }
  
  void dispatchPrimaryNavigationFragmentChanged() {
    updateOnBackPressedCallbackEnabled();
    dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(3);
  }
  
  public void dispatchStop() {
    this.mStopped = true;
    dispatchStateChange(2);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield mActive : Ljava/util/HashMap;
    //   36: invokevirtual isEmpty : ()Z
    //   39: ifne -> 138
    //   42: aload_3
    //   43: aload_1
    //   44: invokevirtual print : (Ljava/lang/String;)V
    //   47: aload_3
    //   48: ldc_w 'Active Fragments in '
    //   51: invokevirtual print : (Ljava/lang/String;)V
    //   54: aload_3
    //   55: aload_0
    //   56: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   59: invokestatic toHexString : (I)Ljava/lang/String;
    //   62: invokevirtual print : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: ldc_w ':'
    //   69: invokevirtual println : (Ljava/lang/String;)V
    //   72: aload_0
    //   73: getfield mActive : Ljava/util/HashMap;
    //   76: invokevirtual values : ()Ljava/util/Collection;
    //   79: invokeinterface iterator : ()Ljava/util/Iterator;
    //   84: astore #9
    //   86: aload #9
    //   88: invokeinterface hasNext : ()Z
    //   93: ifeq -> 138
    //   96: aload #9
    //   98: invokeinterface next : ()Ljava/lang/Object;
    //   103: checkcast androidx/fragment/app/Fragment
    //   106: astore #10
    //   108: aload_3
    //   109: aload_1
    //   110: invokevirtual print : (Ljava/lang/String;)V
    //   113: aload_3
    //   114: aload #10
    //   116: invokevirtual println : (Ljava/lang/Object;)V
    //   119: aload #10
    //   121: ifnull -> 86
    //   124: aload #10
    //   126: aload #8
    //   128: aload_2
    //   129: aload_3
    //   130: aload #4
    //   132: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   135: goto -> 86
    //   138: aload_0
    //   139: getfield mAdded : Ljava/util/ArrayList;
    //   142: invokevirtual size : ()I
    //   145: istore #7
    //   147: iconst_0
    //   148: istore #6
    //   150: iload #7
    //   152: ifle -> 232
    //   155: aload_3
    //   156: aload_1
    //   157: invokevirtual print : (Ljava/lang/String;)V
    //   160: aload_3
    //   161: ldc_w 'Added Fragments:'
    //   164: invokevirtual println : (Ljava/lang/String;)V
    //   167: iconst_0
    //   168: istore #5
    //   170: iload #5
    //   172: iload #7
    //   174: if_icmpge -> 232
    //   177: aload_0
    //   178: getfield mAdded : Ljava/util/ArrayList;
    //   181: iload #5
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast androidx/fragment/app/Fragment
    //   189: astore_2
    //   190: aload_3
    //   191: aload_1
    //   192: invokevirtual print : (Ljava/lang/String;)V
    //   195: aload_3
    //   196: ldc_w '  #'
    //   199: invokevirtual print : (Ljava/lang/String;)V
    //   202: aload_3
    //   203: iload #5
    //   205: invokevirtual print : (I)V
    //   208: aload_3
    //   209: ldc_w ': '
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: aload_2
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual println : (Ljava/lang/String;)V
    //   223: iload #5
    //   225: iconst_1
    //   226: iadd
    //   227: istore #5
    //   229: goto -> 170
    //   232: aload_0
    //   233: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   236: astore_2
    //   237: aload_2
    //   238: ifnull -> 329
    //   241: aload_2
    //   242: invokevirtual size : ()I
    //   245: istore #7
    //   247: iload #7
    //   249: ifle -> 329
    //   252: aload_3
    //   253: aload_1
    //   254: invokevirtual print : (Ljava/lang/String;)V
    //   257: aload_3
    //   258: ldc_w 'Fragments Created Menus:'
    //   261: invokevirtual println : (Ljava/lang/String;)V
    //   264: iconst_0
    //   265: istore #5
    //   267: iload #5
    //   269: iload #7
    //   271: if_icmpge -> 329
    //   274: aload_0
    //   275: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   278: iload #5
    //   280: invokevirtual get : (I)Ljava/lang/Object;
    //   283: checkcast androidx/fragment/app/Fragment
    //   286: astore_2
    //   287: aload_3
    //   288: aload_1
    //   289: invokevirtual print : (Ljava/lang/String;)V
    //   292: aload_3
    //   293: ldc_w '  #'
    //   296: invokevirtual print : (Ljava/lang/String;)V
    //   299: aload_3
    //   300: iload #5
    //   302: invokevirtual print : (I)V
    //   305: aload_3
    //   306: ldc_w ': '
    //   309: invokevirtual print : (Ljava/lang/String;)V
    //   312: aload_3
    //   313: aload_2
    //   314: invokevirtual toString : ()Ljava/lang/String;
    //   317: invokevirtual println : (Ljava/lang/String;)V
    //   320: iload #5
    //   322: iconst_1
    //   323: iadd
    //   324: istore #5
    //   326: goto -> 267
    //   329: aload_0
    //   330: getfield mBackStack : Ljava/util/ArrayList;
    //   333: astore_2
    //   334: aload_2
    //   335: ifnull -> 433
    //   338: aload_2
    //   339: invokevirtual size : ()I
    //   342: istore #7
    //   344: iload #7
    //   346: ifle -> 433
    //   349: aload_3
    //   350: aload_1
    //   351: invokevirtual print : (Ljava/lang/String;)V
    //   354: aload_3
    //   355: ldc_w 'Back Stack:'
    //   358: invokevirtual println : (Ljava/lang/String;)V
    //   361: iconst_0
    //   362: istore #5
    //   364: iload #5
    //   366: iload #7
    //   368: if_icmpge -> 433
    //   371: aload_0
    //   372: getfield mBackStack : Ljava/util/ArrayList;
    //   375: iload #5
    //   377: invokevirtual get : (I)Ljava/lang/Object;
    //   380: checkcast androidx/fragment/app/BackStackRecord
    //   383: astore_2
    //   384: aload_3
    //   385: aload_1
    //   386: invokevirtual print : (Ljava/lang/String;)V
    //   389: aload_3
    //   390: ldc_w '  #'
    //   393: invokevirtual print : (Ljava/lang/String;)V
    //   396: aload_3
    //   397: iload #5
    //   399: invokevirtual print : (I)V
    //   402: aload_3
    //   403: ldc_w ': '
    //   406: invokevirtual print : (Ljava/lang/String;)V
    //   409: aload_3
    //   410: aload_2
    //   411: invokevirtual toString : ()Ljava/lang/String;
    //   414: invokevirtual println : (Ljava/lang/String;)V
    //   417: aload_2
    //   418: aload #8
    //   420: aload_3
    //   421: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;)V
    //   424: iload #5
    //   426: iconst_1
    //   427: iadd
    //   428: istore #5
    //   430: goto -> 364
    //   433: aload_0
    //   434: monitorenter
    //   435: aload_0
    //   436: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   439: astore_2
    //   440: aload_2
    //   441: ifnull -> 529
    //   444: aload_2
    //   445: invokevirtual size : ()I
    //   448: istore #7
    //   450: iload #7
    //   452: ifle -> 529
    //   455: aload_3
    //   456: aload_1
    //   457: invokevirtual print : (Ljava/lang/String;)V
    //   460: aload_3
    //   461: ldc_w 'Back Stack Indices:'
    //   464: invokevirtual println : (Ljava/lang/String;)V
    //   467: iconst_0
    //   468: istore #5
    //   470: iload #5
    //   472: iload #7
    //   474: if_icmpge -> 529
    //   477: aload_0
    //   478: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   481: iload #5
    //   483: invokevirtual get : (I)Ljava/lang/Object;
    //   486: checkcast androidx/fragment/app/BackStackRecord
    //   489: astore_2
    //   490: aload_3
    //   491: aload_1
    //   492: invokevirtual print : (Ljava/lang/String;)V
    //   495: aload_3
    //   496: ldc_w '  #'
    //   499: invokevirtual print : (Ljava/lang/String;)V
    //   502: aload_3
    //   503: iload #5
    //   505: invokevirtual print : (I)V
    //   508: aload_3
    //   509: ldc_w ': '
    //   512: invokevirtual print : (Ljava/lang/String;)V
    //   515: aload_3
    //   516: aload_2
    //   517: invokevirtual println : (Ljava/lang/Object;)V
    //   520: iload #5
    //   522: iconst_1
    //   523: iadd
    //   524: istore #5
    //   526: goto -> 470
    //   529: aload_0
    //   530: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   533: astore_2
    //   534: aload_2
    //   535: ifnull -> 571
    //   538: aload_2
    //   539: invokevirtual size : ()I
    //   542: ifle -> 571
    //   545: aload_3
    //   546: aload_1
    //   547: invokevirtual print : (Ljava/lang/String;)V
    //   550: aload_3
    //   551: ldc_w 'mAvailBackStackIndices: '
    //   554: invokevirtual print : (Ljava/lang/String;)V
    //   557: aload_3
    //   558: aload_0
    //   559: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   562: invokevirtual toArray : ()[Ljava/lang/Object;
    //   565: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   568: invokevirtual println : (Ljava/lang/String;)V
    //   571: aload_0
    //   572: monitorexit
    //   573: aload_0
    //   574: getfield mPendingActions : Ljava/util/ArrayList;
    //   577: astore_2
    //   578: aload_2
    //   579: ifnull -> 668
    //   582: aload_2
    //   583: invokevirtual size : ()I
    //   586: istore #7
    //   588: iload #7
    //   590: ifle -> 668
    //   593: aload_3
    //   594: aload_1
    //   595: invokevirtual print : (Ljava/lang/String;)V
    //   598: aload_3
    //   599: ldc_w 'Pending Actions:'
    //   602: invokevirtual println : (Ljava/lang/String;)V
    //   605: iload #6
    //   607: istore #5
    //   609: iload #5
    //   611: iload #7
    //   613: if_icmpge -> 668
    //   616: aload_0
    //   617: getfield mPendingActions : Ljava/util/ArrayList;
    //   620: iload #5
    //   622: invokevirtual get : (I)Ljava/lang/Object;
    //   625: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   628: astore_2
    //   629: aload_3
    //   630: aload_1
    //   631: invokevirtual print : (Ljava/lang/String;)V
    //   634: aload_3
    //   635: ldc_w '  #'
    //   638: invokevirtual print : (Ljava/lang/String;)V
    //   641: aload_3
    //   642: iload #5
    //   644: invokevirtual print : (I)V
    //   647: aload_3
    //   648: ldc_w ': '
    //   651: invokevirtual print : (Ljava/lang/String;)V
    //   654: aload_3
    //   655: aload_2
    //   656: invokevirtual println : (Ljava/lang/Object;)V
    //   659: iload #5
    //   661: iconst_1
    //   662: iadd
    //   663: istore #5
    //   665: goto -> 609
    //   668: aload_3
    //   669: aload_1
    //   670: invokevirtual print : (Ljava/lang/String;)V
    //   673: aload_3
    //   674: ldc_w 'FragmentManager misc state:'
    //   677: invokevirtual println : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_1
    //   682: invokevirtual print : (Ljava/lang/String;)V
    //   685: aload_3
    //   686: ldc_w '  mHost='
    //   689: invokevirtual print : (Ljava/lang/String;)V
    //   692: aload_3
    //   693: aload_0
    //   694: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   697: invokevirtual println : (Ljava/lang/Object;)V
    //   700: aload_3
    //   701: aload_1
    //   702: invokevirtual print : (Ljava/lang/String;)V
    //   705: aload_3
    //   706: ldc_w '  mContainer='
    //   709: invokevirtual print : (Ljava/lang/String;)V
    //   712: aload_3
    //   713: aload_0
    //   714: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   717: invokevirtual println : (Ljava/lang/Object;)V
    //   720: aload_0
    //   721: getfield mParent : Landroidx/fragment/app/Fragment;
    //   724: ifnull -> 747
    //   727: aload_3
    //   728: aload_1
    //   729: invokevirtual print : (Ljava/lang/String;)V
    //   732: aload_3
    //   733: ldc_w '  mParent='
    //   736: invokevirtual print : (Ljava/lang/String;)V
    //   739: aload_3
    //   740: aload_0
    //   741: getfield mParent : Landroidx/fragment/app/Fragment;
    //   744: invokevirtual println : (Ljava/lang/Object;)V
    //   747: aload_3
    //   748: aload_1
    //   749: invokevirtual print : (Ljava/lang/String;)V
    //   752: aload_3
    //   753: ldc_w '  mCurState='
    //   756: invokevirtual print : (Ljava/lang/String;)V
    //   759: aload_3
    //   760: aload_0
    //   761: getfield mCurState : I
    //   764: invokevirtual print : (I)V
    //   767: aload_3
    //   768: ldc_w ' mStateSaved='
    //   771: invokevirtual print : (Ljava/lang/String;)V
    //   774: aload_3
    //   775: aload_0
    //   776: getfield mStateSaved : Z
    //   779: invokevirtual print : (Z)V
    //   782: aload_3
    //   783: ldc_w ' mStopped='
    //   786: invokevirtual print : (Ljava/lang/String;)V
    //   789: aload_3
    //   790: aload_0
    //   791: getfield mStopped : Z
    //   794: invokevirtual print : (Z)V
    //   797: aload_3
    //   798: ldc_w ' mDestroyed='
    //   801: invokevirtual print : (Ljava/lang/String;)V
    //   804: aload_3
    //   805: aload_0
    //   806: getfield mDestroyed : Z
    //   809: invokevirtual println : (Z)V
    //   812: aload_0
    //   813: getfield mNeedMenuInvalidate : Z
    //   816: ifeq -> 839
    //   819: aload_3
    //   820: aload_1
    //   821: invokevirtual print : (Ljava/lang/String;)V
    //   824: aload_3
    //   825: ldc_w '  mNeedMenuInvalidate='
    //   828: invokevirtual print : (Ljava/lang/String;)V
    //   831: aload_3
    //   832: aload_0
    //   833: getfield mNeedMenuInvalidate : Z
    //   836: invokevirtual println : (Z)V
    //   839: return
    //   840: astore_1
    //   841: aload_0
    //   842: monitorexit
    //   843: goto -> 848
    //   846: aload_1
    //   847: athrow
    //   848: goto -> 846
    // Exception table:
    //   from	to	target	type
    //   435	440	840	finally
    //   444	450	840	finally
    //   455	467	840	finally
    //   477	520	840	finally
    //   529	534	840	finally
    //   538	571	840	finally
    //   571	573	840	finally
    //   841	843	840	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield mPendingActions : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield mPendingActions : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield mPendingActions : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokevirtual scheduleCommit : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
      paramFragment.mInnerView = null;
    } 
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null)
      for (int i = this.mAdded.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    if (paramString != null)
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        fragment = fragment.findFragmentByWho(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 68
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore_2
    //   44: aload_2
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload_2
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: ldc 'FragmentManager'
    //   60: aload_2
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   67: pop
    //   68: aload_0
    //   69: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   72: iload_1
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: invokevirtual add : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: astore_2
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_2
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	83	finally
    //   30	68	83	finally
    //   68	82	83	finally
    //   84	86	83	finally
  }
  
  int getActiveFragmentCount() {
    return this.mActive.size();
  }
  
  List<Fragment> getActiveFragments() {
    return new ArrayList<Fragment>(this.mActive.values());
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  FragmentManagerViewModel getChildNonConfig(Fragment paramFragment) {
    return this.mNonConfig.getChildNonConfig(paramFragment);
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = this.mActive.get(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public FragmentFactory getFragmentFactory() {
    if (super.getFragmentFactory() == DEFAULT_FACTORY) {
      Fragment fragment = this.mParent;
      if (fragment != null)
        return fragment.mFragmentManager.getFragmentFactory(); 
      setFragmentFactory(new FragmentFactory() {
            public Fragment instantiate(ClassLoader param1ClassLoader, String param1String) {
              return FragmentManagerImpl.this.mHost.instantiate(FragmentManagerImpl.this.mHost.getContext(), param1String, null);
            }
          });
    } 
    return super.getFragmentFactory();
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  ViewModelStore getViewModelStore(Fragment paramFragment) {
    return this.mNonConfig.getViewModelStore(paramFragment);
  }
  
  void handleOnBackPressed() {
    execPendingActions();
    if (this.mOnBackPressedCallback.isEnabled()) {
      popBackStackImmediate();
      return;
    } 
    this.mOnBackPressedDispatcher.onBackPressed();
  }
  
  public void hideFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isPrimaryNavigation(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManagerImpl fragmentManagerImpl = paramFragment.mFragmentManager;
    return (paramFragment == fragmentManagerImpl.getPrimaryNavigationFragment() && isPrimaryNavigation(fragmentManagerImpl.mParent));
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    boolean bool = false;
    paramFragment.setNextAnim(0);
    if (paramFragment.mContainer != null && paramFragment.mContainer.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool2 = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool1 = bool;
      if (bool2)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool2) {
            animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
            if (animation1 != null)
              return new AnimationOrAnimator(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        if (paramInt2 == 0 && this.mHost.onHasWindowAnimations()) {
          this.mHost.onGetWindowAnimations();
          return null;
        } 
        return null;
      case 6:
        return makeFadeAnimation(1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        break;
    } 
    return makeOpenCloseAnimation(1.125F, 1.0F, 0.0F, 1.0F);
  }
  
  void makeActive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) != null)
      return; 
    this.mActive.put(paramFragment.mWho, paramFragment);
    if (paramFragment.mRetainInstanceChangedWhileDetached) {
      if (paramFragment.mRetainInstance) {
        addRetainedFragment(paramFragment);
      } else {
        removeRetainedFragment(paramFragment);
      } 
      paramFragment.mRetainInstanceChangedWhileDetached = false;
    } 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) == null)
      return; 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && paramFragment.mWho.equals(fragment.mTargetWho)) {
        fragment.mTarget = paramFragment;
        fragment.mTargetWho = null;
      } 
    } 
    this.mActive.put(paramFragment.mWho, null);
    removeRetainedFragment(paramFragment);
    if (paramFragment.mTargetWho != null)
      paramFragment.mTarget = this.mActive.get(paramFragment.mTargetWho); 
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    if (!this.mActive.containsKey(paramFragment.mWho)) {
      if (DEBUG) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.mCurState);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    int j = this.mCurState;
    int i = j;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        i = Math.min(j, 1);
      } else {
        i = Math.min(j, 0);
      }  
    moveToState(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = findFragmentUnder(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        i = viewGroup.indexOfChild(view);
        j = viewGroup.indexOfChild(paramFragment.mView);
        if (j < i) {
          viewGroup.removeViewAt(j);
          viewGroup.addView(paramFragment.mView, i);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        if (paramFragment.mPostponedAlpha > 0.0F)
          paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (animationOrAnimator != null)
          if (animationOrAnimator.animation != null) {
            paramFragment.mView.startAnimation(animationOrAnimator.animation);
          } else {
            animationOrAnimator.animator.setTarget(paramFragment.mView);
            animationOrAnimator.animator.start();
          }  
      } 
    } 
    if (paramFragment.mHiddenChanged)
      completeShowHideFragment(paramFragment); 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      int i = this.mAdded.size();
      for (paramInt = 0; paramInt < i; paramInt++)
        moveFragmentToExpectedState(this.mAdded.get(paramInt)); 
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
          moveFragmentToExpectedState(fragment); 
      } 
      startPendingDeferredFragments();
      if (this.mNeedMenuInvalidate) {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null && this.mCurState == 4) {
          fragmentHostCallback.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #10
    //   6: iconst_1
    //   7: istore #9
    //   9: iconst_1
    //   10: istore #7
    //   12: iconst_1
    //   13: istore #8
    //   15: iload #10
    //   17: ifeq -> 33
    //   20: aload_1
    //   21: getfield mDetached : Z
    //   24: ifeq -> 30
    //   27: goto -> 33
    //   30: goto -> 47
    //   33: iload_2
    //   34: istore #6
    //   36: iload #6
    //   38: istore_2
    //   39: iload #6
    //   41: iconst_1
    //   42: if_icmple -> 47
    //   45: iconst_1
    //   46: istore_2
    //   47: iload_2
    //   48: istore #6
    //   50: aload_1
    //   51: getfield mRemoving : Z
    //   54: ifeq -> 94
    //   57: iload_2
    //   58: istore #6
    //   60: iload_2
    //   61: aload_1
    //   62: getfield mState : I
    //   65: if_icmple -> 94
    //   68: aload_1
    //   69: getfield mState : I
    //   72: ifne -> 88
    //   75: aload_1
    //   76: invokevirtual isInBackStack : ()Z
    //   79: ifeq -> 88
    //   82: iconst_1
    //   83: istore #6
    //   85: goto -> 94
    //   88: aload_1
    //   89: getfield mState : I
    //   92: istore #6
    //   94: iload #6
    //   96: istore_2
    //   97: aload_1
    //   98: getfield mDeferStart : Z
    //   101: ifeq -> 126
    //   104: iload #6
    //   106: istore_2
    //   107: aload_1
    //   108: getfield mState : I
    //   111: iconst_3
    //   112: if_icmpge -> 126
    //   115: iload #6
    //   117: istore_2
    //   118: iload #6
    //   120: iconst_2
    //   121: if_icmple -> 126
    //   124: iconst_2
    //   125: istore_2
    //   126: aload_1
    //   127: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   130: getstatic androidx/lifecycle/Lifecycle$State.CREATED : Landroidx/lifecycle/Lifecycle$State;
    //   133: if_acmpne -> 145
    //   136: iload_2
    //   137: iconst_1
    //   138: invokestatic min : (II)I
    //   141: istore_2
    //   142: goto -> 157
    //   145: iload_2
    //   146: aload_1
    //   147: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   150: invokevirtual ordinal : ()I
    //   153: invokestatic min : (II)I
    //   156: istore_2
    //   157: aload_1
    //   158: getfield mState : I
    //   161: iload_2
    //   162: if_icmpgt -> 1494
    //   165: aload_1
    //   166: getfield mFromLayout : Z
    //   169: ifeq -> 180
    //   172: aload_1
    //   173: getfield mInLayout : Z
    //   176: ifne -> 180
    //   179: return
    //   180: aload_1
    //   181: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   184: ifnonnull -> 194
    //   187: aload_1
    //   188: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   191: ifnull -> 216
    //   194: aload_1
    //   195: aconst_null
    //   196: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   199: aload_1
    //   200: aconst_null
    //   201: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   204: aload_0
    //   205: aload_1
    //   206: aload_1
    //   207: invokevirtual getStateAfterAnimating : ()I
    //   210: iconst_0
    //   211: iconst_0
    //   212: iconst_1
    //   213: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   216: aload_1
    //   217: getfield mState : I
    //   220: istore #6
    //   222: iload #6
    //   224: ifeq -> 264
    //   227: iload_2
    //   228: istore_3
    //   229: iload #6
    //   231: iconst_1
    //   232: if_icmpeq -> 885
    //   235: iload_2
    //   236: istore #4
    //   238: iload #6
    //   240: iconst_2
    //   241: if_icmpeq -> 261
    //   244: iload_2
    //   245: istore_3
    //   246: iload #6
    //   248: iconst_3
    //   249: if_icmpeq -> 258
    //   252: iload_2
    //   253: istore #6
    //   255: goto -> 2289
    //   258: goto -> 1418
    //   261: goto -> 1351
    //   264: iload_2
    //   265: istore_3
    //   266: iload_2
    //   267: ifle -> 885
    //   270: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   273: ifeq -> 312
    //   276: new java/lang/StringBuilder
    //   279: dup
    //   280: invokespecial <init> : ()V
    //   283: astore #11
    //   285: aload #11
    //   287: ldc_w 'moveto CREATED: '
    //   290: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: pop
    //   294: aload #11
    //   296: aload_1
    //   297: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   300: pop
    //   301: ldc 'FragmentManager'
    //   303: aload #11
    //   305: invokevirtual toString : ()Ljava/lang/String;
    //   308: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   311: pop
    //   312: iload_2
    //   313: istore_3
    //   314: aload_1
    //   315: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   318: ifnull -> 471
    //   321: aload_1
    //   322: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   325: aload_0
    //   326: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   329: invokevirtual getContext : ()Landroid/content/Context;
    //   332: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   335: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   338: aload_1
    //   339: aload_1
    //   340: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   343: ldc 'android:view_state'
    //   345: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   348: putfield mSavedViewState : Landroid/util/SparseArray;
    //   351: aload_0
    //   352: aload_1
    //   353: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   356: ldc 'android:target_state'
    //   358: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   361: astore #11
    //   363: aload #11
    //   365: ifnull -> 378
    //   368: aload #11
    //   370: getfield mWho : Ljava/lang/String;
    //   373: astore #11
    //   375: goto -> 381
    //   378: aconst_null
    //   379: astore #11
    //   381: aload_1
    //   382: aload #11
    //   384: putfield mTargetWho : Ljava/lang/String;
    //   387: aload_1
    //   388: getfield mTargetWho : Ljava/lang/String;
    //   391: ifnull -> 408
    //   394: aload_1
    //   395: aload_1
    //   396: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   399: ldc 'android:target_req_state'
    //   401: iconst_0
    //   402: invokevirtual getInt : (Ljava/lang/String;I)I
    //   405: putfield mTargetRequestCode : I
    //   408: aload_1
    //   409: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   412: ifnull -> 434
    //   415: aload_1
    //   416: aload_1
    //   417: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   420: invokevirtual booleanValue : ()Z
    //   423: putfield mUserVisibleHint : Z
    //   426: aload_1
    //   427: aconst_null
    //   428: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   431: goto -> 448
    //   434: aload_1
    //   435: aload_1
    //   436: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   439: ldc 'android:user_visible_hint'
    //   441: iconst_1
    //   442: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   445: putfield mUserVisibleHint : Z
    //   448: iload_2
    //   449: istore_3
    //   450: aload_1
    //   451: getfield mUserVisibleHint : Z
    //   454: ifne -> 471
    //   457: aload_1
    //   458: iconst_1
    //   459: putfield mDeferStart : Z
    //   462: iload_2
    //   463: istore_3
    //   464: iload_2
    //   465: iconst_2
    //   466: if_icmple -> 471
    //   469: iconst_2
    //   470: istore_3
    //   471: aload_1
    //   472: aload_0
    //   473: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   476: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   479: aload_1
    //   480: aload_0
    //   481: getfield mParent : Landroidx/fragment/app/Fragment;
    //   484: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   487: aload_0
    //   488: getfield mParent : Landroidx/fragment/app/Fragment;
    //   491: astore #11
    //   493: aload #11
    //   495: ifnull -> 508
    //   498: aload #11
    //   500: getfield mChildFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   503: astore #11
    //   505: goto -> 517
    //   508: aload_0
    //   509: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   512: getfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   515: astore #11
    //   517: aload_1
    //   518: aload #11
    //   520: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   523: aload_1
    //   524: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   527: ifnull -> 662
    //   530: aload_0
    //   531: getfield mActive : Ljava/util/HashMap;
    //   534: aload_1
    //   535: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   538: getfield mWho : Ljava/lang/String;
    //   541: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   544: aload_1
    //   545: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   548: if_acmpne -> 596
    //   551: aload_1
    //   552: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   555: getfield mState : I
    //   558: iconst_1
    //   559: if_icmpge -> 577
    //   562: aload_0
    //   563: aload_1
    //   564: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   567: iconst_1
    //   568: iconst_0
    //   569: iconst_0
    //   570: iconst_1
    //   571: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   574: goto -> 577
    //   577: aload_1
    //   578: aload_1
    //   579: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   582: getfield mWho : Ljava/lang/String;
    //   585: putfield mTargetWho : Ljava/lang/String;
    //   588: aload_1
    //   589: aconst_null
    //   590: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   593: goto -> 662
    //   596: new java/lang/StringBuilder
    //   599: dup
    //   600: invokespecial <init> : ()V
    //   603: astore #11
    //   605: aload #11
    //   607: ldc_w 'Fragment '
    //   610: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   613: pop
    //   614: aload #11
    //   616: aload_1
    //   617: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   620: pop
    //   621: aload #11
    //   623: ldc_w ' declared target fragment '
    //   626: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: aload #11
    //   632: aload_1
    //   633: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   636: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   639: pop
    //   640: aload #11
    //   642: ldc_w ' that does not belong to this FragmentManager!'
    //   645: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   648: pop
    //   649: new java/lang/IllegalStateException
    //   652: dup
    //   653: aload #11
    //   655: invokevirtual toString : ()Ljava/lang/String;
    //   658: invokespecial <init> : (Ljava/lang/String;)V
    //   661: athrow
    //   662: aload_1
    //   663: getfield mTargetWho : Ljava/lang/String;
    //   666: ifnull -> 778
    //   669: aload_0
    //   670: getfield mActive : Ljava/util/HashMap;
    //   673: aload_1
    //   674: getfield mTargetWho : Ljava/lang/String;
    //   677: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   680: checkcast androidx/fragment/app/Fragment
    //   683: astore #11
    //   685: aload #11
    //   687: ifnull -> 712
    //   690: aload #11
    //   692: getfield mState : I
    //   695: iconst_1
    //   696: if_icmpge -> 778
    //   699: aload_0
    //   700: aload #11
    //   702: iconst_1
    //   703: iconst_0
    //   704: iconst_0
    //   705: iconst_1
    //   706: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   709: goto -> 778
    //   712: new java/lang/StringBuilder
    //   715: dup
    //   716: invokespecial <init> : ()V
    //   719: astore #11
    //   721: aload #11
    //   723: ldc_w 'Fragment '
    //   726: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   729: pop
    //   730: aload #11
    //   732: aload_1
    //   733: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   736: pop
    //   737: aload #11
    //   739: ldc_w ' declared target fragment '
    //   742: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   745: pop
    //   746: aload #11
    //   748: aload_1
    //   749: getfield mTargetWho : Ljava/lang/String;
    //   752: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   755: pop
    //   756: aload #11
    //   758: ldc_w ' that does not belong to this FragmentManager!'
    //   761: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   764: pop
    //   765: new java/lang/IllegalStateException
    //   768: dup
    //   769: aload #11
    //   771: invokevirtual toString : ()Ljava/lang/String;
    //   774: invokespecial <init> : (Ljava/lang/String;)V
    //   777: athrow
    //   778: aload_0
    //   779: aload_1
    //   780: aload_0
    //   781: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   784: invokevirtual getContext : ()Landroid/content/Context;
    //   787: iconst_0
    //   788: invokevirtual dispatchOnFragmentPreAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   791: aload_1
    //   792: invokevirtual performAttach : ()V
    //   795: aload_1
    //   796: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   799: ifnonnull -> 813
    //   802: aload_0
    //   803: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   806: aload_1
    //   807: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   810: goto -> 821
    //   813: aload_1
    //   814: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   817: aload_1
    //   818: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   821: aload_0
    //   822: aload_1
    //   823: aload_0
    //   824: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   827: invokevirtual getContext : ()Landroid/content/Context;
    //   830: iconst_0
    //   831: invokevirtual dispatchOnFragmentAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   834: aload_1
    //   835: getfield mIsCreated : Z
    //   838: ifne -> 872
    //   841: aload_0
    //   842: aload_1
    //   843: aload_1
    //   844: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   847: iconst_0
    //   848: invokevirtual dispatchOnFragmentPreCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   851: aload_1
    //   852: aload_1
    //   853: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   856: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   859: aload_0
    //   860: aload_1
    //   861: aload_1
    //   862: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   865: iconst_0
    //   866: invokevirtual dispatchOnFragmentCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   869: goto -> 885
    //   872: aload_1
    //   873: aload_1
    //   874: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   877: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   880: aload_1
    //   881: iconst_1
    //   882: putfield mState : I
    //   885: iload_3
    //   886: ifle -> 894
    //   889: aload_0
    //   890: aload_1
    //   891: invokevirtual ensureInflatedFragmentView : (Landroidx/fragment/app/Fragment;)V
    //   894: iload_3
    //   895: istore #4
    //   897: iload_3
    //   898: iconst_1
    //   899: if_icmple -> 261
    //   902: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   905: ifeq -> 944
    //   908: new java/lang/StringBuilder
    //   911: dup
    //   912: invokespecial <init> : ()V
    //   915: astore #11
    //   917: aload #11
    //   919: ldc_w 'moveto ACTIVITY_CREATED: '
    //   922: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   925: pop
    //   926: aload #11
    //   928: aload_1
    //   929: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   932: pop
    //   933: ldc 'FragmentManager'
    //   935: aload #11
    //   937: invokevirtual toString : ()Ljava/lang/String;
    //   940: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   943: pop
    //   944: aload_1
    //   945: getfield mFromLayout : Z
    //   948: ifne -> 1307
    //   951: aload_1
    //   952: getfield mContainerId : I
    //   955: ifeq -> 1160
    //   958: aload_1
    //   959: getfield mContainerId : I
    //   962: iconst_m1
    //   963: if_icmpne -> 1016
    //   966: new java/lang/StringBuilder
    //   969: dup
    //   970: invokespecial <init> : ()V
    //   973: astore #11
    //   975: aload #11
    //   977: ldc_w 'Cannot create fragment '
    //   980: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   983: pop
    //   984: aload #11
    //   986: aload_1
    //   987: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   990: pop
    //   991: aload #11
    //   993: ldc_w ' for a container view with no id'
    //   996: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   999: pop
    //   1000: aload_0
    //   1001: new java/lang/IllegalArgumentException
    //   1004: dup
    //   1005: aload #11
    //   1007: invokevirtual toString : ()Ljava/lang/String;
    //   1010: invokespecial <init> : (Ljava/lang/String;)V
    //   1013: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1016: aload_0
    //   1017: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   1020: aload_1
    //   1021: getfield mContainerId : I
    //   1024: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   1027: checkcast android/view/ViewGroup
    //   1030: astore #12
    //   1032: aload #12
    //   1034: astore #11
    //   1036: aload #12
    //   1038: ifnonnull -> 1163
    //   1041: aload #12
    //   1043: astore #11
    //   1045: aload_1
    //   1046: getfield mRestored : Z
    //   1049: ifne -> 1163
    //   1052: aload_1
    //   1053: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1056: aload_1
    //   1057: getfield mContainerId : I
    //   1060: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1063: astore #11
    //   1065: goto -> 1073
    //   1068: ldc_w 'unknown'
    //   1071: astore #11
    //   1073: new java/lang/StringBuilder
    //   1076: dup
    //   1077: invokespecial <init> : ()V
    //   1080: astore #13
    //   1082: aload #13
    //   1084: ldc_w 'No view found for id 0x'
    //   1087: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1090: pop
    //   1091: aload #13
    //   1093: aload_1
    //   1094: getfield mContainerId : I
    //   1097: invokestatic toHexString : (I)Ljava/lang/String;
    //   1100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1103: pop
    //   1104: aload #13
    //   1106: ldc_w ' ('
    //   1109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1112: pop
    //   1113: aload #13
    //   1115: aload #11
    //   1117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1120: pop
    //   1121: aload #13
    //   1123: ldc_w ') for fragment '
    //   1126: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1129: pop
    //   1130: aload #13
    //   1132: aload_1
    //   1133: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1136: pop
    //   1137: aload_0
    //   1138: new java/lang/IllegalArgumentException
    //   1141: dup
    //   1142: aload #13
    //   1144: invokevirtual toString : ()Ljava/lang/String;
    //   1147: invokespecial <init> : (Ljava/lang/String;)V
    //   1150: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1153: aload #12
    //   1155: astore #11
    //   1157: goto -> 1163
    //   1160: aconst_null
    //   1161: astore #11
    //   1163: aload_1
    //   1164: aload #11
    //   1166: putfield mContainer : Landroid/view/ViewGroup;
    //   1169: aload_1
    //   1170: aload_1
    //   1171: aload_1
    //   1172: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1175: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1178: aload #11
    //   1180: aload_1
    //   1181: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1184: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1187: aload_1
    //   1188: getfield mView : Landroid/view/View;
    //   1191: ifnull -> 1302
    //   1194: aload_1
    //   1195: aload_1
    //   1196: getfield mView : Landroid/view/View;
    //   1199: putfield mInnerView : Landroid/view/View;
    //   1202: aload_1
    //   1203: getfield mView : Landroid/view/View;
    //   1206: iconst_0
    //   1207: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1210: aload #11
    //   1212: ifnull -> 1224
    //   1215: aload #11
    //   1217: aload_1
    //   1218: getfield mView : Landroid/view/View;
    //   1221: invokevirtual addView : (Landroid/view/View;)V
    //   1224: aload_1
    //   1225: getfield mHidden : Z
    //   1228: ifeq -> 1240
    //   1231: aload_1
    //   1232: getfield mView : Landroid/view/View;
    //   1235: bipush #8
    //   1237: invokevirtual setVisibility : (I)V
    //   1240: aload_1
    //   1241: aload_1
    //   1242: getfield mView : Landroid/view/View;
    //   1245: aload_1
    //   1246: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1249: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1252: aload_0
    //   1253: aload_1
    //   1254: aload_1
    //   1255: getfield mView : Landroid/view/View;
    //   1258: aload_1
    //   1259: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1262: iconst_0
    //   1263: invokevirtual dispatchOnFragmentViewCreated : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1266: aload_1
    //   1267: getfield mView : Landroid/view/View;
    //   1270: invokevirtual getVisibility : ()I
    //   1273: ifne -> 1290
    //   1276: aload_1
    //   1277: getfield mContainer : Landroid/view/ViewGroup;
    //   1280: ifnull -> 1290
    //   1283: iload #8
    //   1285: istore #5
    //   1287: goto -> 1293
    //   1290: iconst_0
    //   1291: istore #5
    //   1293: aload_1
    //   1294: iload #5
    //   1296: putfield mIsNewlyAdded : Z
    //   1299: goto -> 1307
    //   1302: aload_1
    //   1303: aconst_null
    //   1304: putfield mInnerView : Landroid/view/View;
    //   1307: aload_1
    //   1308: aload_1
    //   1309: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1312: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1315: aload_0
    //   1316: aload_1
    //   1317: aload_1
    //   1318: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1321: iconst_0
    //   1322: invokevirtual dispatchOnFragmentActivityCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1325: aload_1
    //   1326: getfield mView : Landroid/view/View;
    //   1329: ifnull -> 1340
    //   1332: aload_1
    //   1333: aload_1
    //   1334: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1337: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1340: aload_1
    //   1341: aconst_null
    //   1342: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1345: iload_3
    //   1346: istore #4
    //   1348: goto -> 261
    //   1351: iload #4
    //   1353: istore_3
    //   1354: iload #4
    //   1356: iconst_2
    //   1357: if_icmple -> 258
    //   1360: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1363: ifeq -> 1402
    //   1366: new java/lang/StringBuilder
    //   1369: dup
    //   1370: invokespecial <init> : ()V
    //   1373: astore #11
    //   1375: aload #11
    //   1377: ldc_w 'moveto STARTED: '
    //   1380: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1383: pop
    //   1384: aload #11
    //   1386: aload_1
    //   1387: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1390: pop
    //   1391: ldc 'FragmentManager'
    //   1393: aload #11
    //   1395: invokevirtual toString : ()Ljava/lang/String;
    //   1398: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1401: pop
    //   1402: aload_1
    //   1403: invokevirtual performStart : ()V
    //   1406: aload_0
    //   1407: aload_1
    //   1408: iconst_0
    //   1409: invokevirtual dispatchOnFragmentStarted : (Landroidx/fragment/app/Fragment;Z)V
    //   1412: iload #4
    //   1414: istore_3
    //   1415: goto -> 258
    //   1418: iload_3
    //   1419: istore #6
    //   1421: iload_3
    //   1422: iconst_3
    //   1423: if_icmple -> 2289
    //   1426: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1429: ifeq -> 1468
    //   1432: new java/lang/StringBuilder
    //   1435: dup
    //   1436: invokespecial <init> : ()V
    //   1439: astore #11
    //   1441: aload #11
    //   1443: ldc_w 'moveto RESUMED: '
    //   1446: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1449: pop
    //   1450: aload #11
    //   1452: aload_1
    //   1453: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1456: pop
    //   1457: ldc 'FragmentManager'
    //   1459: aload #11
    //   1461: invokevirtual toString : ()Ljava/lang/String;
    //   1464: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1467: pop
    //   1468: aload_1
    //   1469: invokevirtual performResume : ()V
    //   1472: aload_0
    //   1473: aload_1
    //   1474: iconst_0
    //   1475: invokevirtual dispatchOnFragmentResumed : (Landroidx/fragment/app/Fragment;Z)V
    //   1478: aload_1
    //   1479: aconst_null
    //   1480: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1483: aload_1
    //   1484: aconst_null
    //   1485: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1488: iload_3
    //   1489: istore #6
    //   1491: goto -> 2289
    //   1494: iload_2
    //   1495: istore #6
    //   1497: aload_1
    //   1498: getfield mState : I
    //   1501: iload_2
    //   1502: if_icmple -> 2289
    //   1505: aload_1
    //   1506: getfield mState : I
    //   1509: istore #6
    //   1511: iload #6
    //   1513: iconst_1
    //   1514: if_icmpeq -> 1903
    //   1517: iload #6
    //   1519: iconst_2
    //   1520: if_icmpeq -> 1655
    //   1523: iload #6
    //   1525: iconst_3
    //   1526: if_icmpeq -> 1598
    //   1529: iload #6
    //   1531: iconst_4
    //   1532: if_icmpeq -> 1541
    //   1535: iload_2
    //   1536: istore #6
    //   1538: goto -> 2289
    //   1541: iload_2
    //   1542: iconst_4
    //   1543: if_icmpge -> 1598
    //   1546: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1549: ifeq -> 1588
    //   1552: new java/lang/StringBuilder
    //   1555: dup
    //   1556: invokespecial <init> : ()V
    //   1559: astore #11
    //   1561: aload #11
    //   1563: ldc_w 'movefrom RESUMED: '
    //   1566: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1569: pop
    //   1570: aload #11
    //   1572: aload_1
    //   1573: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1576: pop
    //   1577: ldc 'FragmentManager'
    //   1579: aload #11
    //   1581: invokevirtual toString : ()Ljava/lang/String;
    //   1584: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1587: pop
    //   1588: aload_1
    //   1589: invokevirtual performPause : ()V
    //   1592: aload_0
    //   1593: aload_1
    //   1594: iconst_0
    //   1595: invokevirtual dispatchOnFragmentPaused : (Landroidx/fragment/app/Fragment;Z)V
    //   1598: iload_2
    //   1599: iconst_3
    //   1600: if_icmpge -> 1655
    //   1603: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1606: ifeq -> 1645
    //   1609: new java/lang/StringBuilder
    //   1612: dup
    //   1613: invokespecial <init> : ()V
    //   1616: astore #11
    //   1618: aload #11
    //   1620: ldc_w 'movefrom STARTED: '
    //   1623: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1626: pop
    //   1627: aload #11
    //   1629: aload_1
    //   1630: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1633: pop
    //   1634: ldc 'FragmentManager'
    //   1636: aload #11
    //   1638: invokevirtual toString : ()Ljava/lang/String;
    //   1641: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1644: pop
    //   1645: aload_1
    //   1646: invokevirtual performStop : ()V
    //   1649: aload_0
    //   1650: aload_1
    //   1651: iconst_0
    //   1652: invokevirtual dispatchOnFragmentStopped : (Landroidx/fragment/app/Fragment;Z)V
    //   1655: iload_2
    //   1656: iconst_2
    //   1657: if_icmpge -> 1903
    //   1660: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1663: ifeq -> 1702
    //   1666: new java/lang/StringBuilder
    //   1669: dup
    //   1670: invokespecial <init> : ()V
    //   1673: astore #11
    //   1675: aload #11
    //   1677: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1680: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1683: pop
    //   1684: aload #11
    //   1686: aload_1
    //   1687: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1690: pop
    //   1691: ldc 'FragmentManager'
    //   1693: aload #11
    //   1695: invokevirtual toString : ()Ljava/lang/String;
    //   1698: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1701: pop
    //   1702: aload_1
    //   1703: getfield mView : Landroid/view/View;
    //   1706: ifnull -> 1732
    //   1709: aload_0
    //   1710: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   1713: aload_1
    //   1714: invokevirtual onShouldSaveFragmentState : (Landroidx/fragment/app/Fragment;)Z
    //   1717: ifeq -> 1732
    //   1720: aload_1
    //   1721: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1724: ifnonnull -> 1732
    //   1727: aload_0
    //   1728: aload_1
    //   1729: invokevirtual saveFragmentViewState : (Landroidx/fragment/app/Fragment;)V
    //   1732: aload_1
    //   1733: invokevirtual performDestroyView : ()V
    //   1736: aload_0
    //   1737: aload_1
    //   1738: iconst_0
    //   1739: invokevirtual dispatchOnFragmentViewDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   1742: aload_1
    //   1743: getfield mView : Landroid/view/View;
    //   1746: ifnull -> 1870
    //   1749: aload_1
    //   1750: getfield mContainer : Landroid/view/ViewGroup;
    //   1753: ifnull -> 1870
    //   1756: aload_1
    //   1757: getfield mContainer : Landroid/view/ViewGroup;
    //   1760: aload_1
    //   1761: getfield mView : Landroid/view/View;
    //   1764: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1767: aload_1
    //   1768: getfield mView : Landroid/view/View;
    //   1771: invokevirtual clearAnimation : ()V
    //   1774: aload_1
    //   1775: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1778: ifnull -> 1791
    //   1781: aload_1
    //   1782: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1785: getfield mRemoving : Z
    //   1788: ifne -> 1870
    //   1791: aload_0
    //   1792: getfield mCurState : I
    //   1795: ifle -> 1838
    //   1798: aload_0
    //   1799: getfield mDestroyed : Z
    //   1802: ifne -> 1838
    //   1805: aload_1
    //   1806: getfield mView : Landroid/view/View;
    //   1809: invokevirtual getVisibility : ()I
    //   1812: ifne -> 1838
    //   1815: aload_1
    //   1816: getfield mPostponedAlpha : F
    //   1819: fconst_0
    //   1820: fcmpl
    //   1821: iflt -> 1838
    //   1824: aload_0
    //   1825: aload_1
    //   1826: iload_3
    //   1827: iconst_0
    //   1828: iload #4
    //   1830: invokevirtual loadAnimation : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1833: astore #11
    //   1835: goto -> 1841
    //   1838: aconst_null
    //   1839: astore #11
    //   1841: aload_1
    //   1842: fconst_0
    //   1843: putfield mPostponedAlpha : F
    //   1846: aload #11
    //   1848: ifnull -> 1859
    //   1851: aload_0
    //   1852: aload_1
    //   1853: aload #11
    //   1855: iload_2
    //   1856: invokespecial animateRemoveFragment : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1859: aload_1
    //   1860: getfield mContainer : Landroid/view/ViewGroup;
    //   1863: aload_1
    //   1864: getfield mView : Landroid/view/View;
    //   1867: invokevirtual removeView : (Landroid/view/View;)V
    //   1870: aload_1
    //   1871: aconst_null
    //   1872: putfield mContainer : Landroid/view/ViewGroup;
    //   1875: aload_1
    //   1876: aconst_null
    //   1877: putfield mView : Landroid/view/View;
    //   1880: aload_1
    //   1881: aconst_null
    //   1882: putfield mViewLifecycleOwner : Landroidx/fragment/app/FragmentViewLifecycleOwner;
    //   1885: aload_1
    //   1886: getfield mViewLifecycleOwnerLiveData : Landroidx/lifecycle/MutableLiveData;
    //   1889: aconst_null
    //   1890: invokevirtual setValue : (Ljava/lang/Object;)V
    //   1893: aload_1
    //   1894: aconst_null
    //   1895: putfield mInnerView : Landroid/view/View;
    //   1898: aload_1
    //   1899: iconst_0
    //   1900: putfield mInLayout : Z
    //   1903: iload_2
    //   1904: istore #6
    //   1906: iload_2
    //   1907: iconst_1
    //   1908: if_icmpge -> 2289
    //   1911: aload_0
    //   1912: getfield mDestroyed : Z
    //   1915: ifeq -> 1967
    //   1918: aload_1
    //   1919: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1922: ifnull -> 1944
    //   1925: aload_1
    //   1926: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1929: astore #11
    //   1931: aload_1
    //   1932: aconst_null
    //   1933: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1936: aload #11
    //   1938: invokevirtual clearAnimation : ()V
    //   1941: goto -> 1967
    //   1944: aload_1
    //   1945: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1948: ifnull -> 1967
    //   1951: aload_1
    //   1952: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1955: astore #11
    //   1957: aload_1
    //   1958: aconst_null
    //   1959: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1962: aload #11
    //   1964: invokevirtual cancel : ()V
    //   1967: aload_1
    //   1968: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1971: ifnonnull -> 2277
    //   1974: aload_1
    //   1975: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1978: ifnull -> 1984
    //   1981: goto -> 2277
    //   1984: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1987: ifeq -> 2026
    //   1990: new java/lang/StringBuilder
    //   1993: dup
    //   1994: invokespecial <init> : ()V
    //   1997: astore #11
    //   1999: aload #11
    //   2001: ldc_w 'movefrom CREATED: '
    //   2004: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2007: pop
    //   2008: aload #11
    //   2010: aload_1
    //   2011: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2014: pop
    //   2015: ldc 'FragmentManager'
    //   2017: aload #11
    //   2019: invokevirtual toString : ()Ljava/lang/String;
    //   2022: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2025: pop
    //   2026: aload_1
    //   2027: getfield mRemoving : Z
    //   2030: ifeq -> 2045
    //   2033: aload_1
    //   2034: invokevirtual isInBackStack : ()Z
    //   2037: ifne -> 2045
    //   2040: iconst_1
    //   2041: istore_3
    //   2042: goto -> 2047
    //   2045: iconst_0
    //   2046: istore_3
    //   2047: iload_3
    //   2048: ifne -> 2073
    //   2051: aload_0
    //   2052: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2055: aload_1
    //   2056: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   2059: ifeq -> 2065
    //   2062: goto -> 2073
    //   2065: aload_1
    //   2066: iconst_0
    //   2067: putfield mState : I
    //   2070: goto -> 2158
    //   2073: aload_0
    //   2074: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2077: astore #11
    //   2079: aload #11
    //   2081: instanceof androidx/lifecycle/ViewModelStoreOwner
    //   2084: ifeq -> 2099
    //   2087: aload_0
    //   2088: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2091: invokevirtual isCleared : ()Z
    //   2094: istore #8
    //   2096: goto -> 2131
    //   2099: iload #9
    //   2101: istore #8
    //   2103: aload #11
    //   2105: invokevirtual getContext : ()Landroid/content/Context;
    //   2108: instanceof android/app/Activity
    //   2111: ifeq -> 2131
    //   2114: iconst_1
    //   2115: aload_0
    //   2116: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2119: invokevirtual getContext : ()Landroid/content/Context;
    //   2122: checkcast android/app/Activity
    //   2125: invokevirtual isChangingConfigurations : ()Z
    //   2128: ixor
    //   2129: istore #8
    //   2131: iload_3
    //   2132: ifne -> 2140
    //   2135: iload #8
    //   2137: ifeq -> 2148
    //   2140: aload_0
    //   2141: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2144: aload_1
    //   2145: invokevirtual clearNonConfigState : (Landroidx/fragment/app/Fragment;)V
    //   2148: aload_1
    //   2149: invokevirtual performDestroy : ()V
    //   2152: aload_0
    //   2153: aload_1
    //   2154: iconst_0
    //   2155: invokevirtual dispatchOnFragmentDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   2158: aload_1
    //   2159: invokevirtual performDetach : ()V
    //   2162: aload_0
    //   2163: aload_1
    //   2164: iconst_0
    //   2165: invokevirtual dispatchOnFragmentDetached : (Landroidx/fragment/app/Fragment;Z)V
    //   2168: iload_2
    //   2169: istore #6
    //   2171: iload #5
    //   2173: ifne -> 2289
    //   2176: iload_3
    //   2177: ifne -> 2266
    //   2180: aload_0
    //   2181: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2184: aload_1
    //   2185: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   2188: ifeq -> 2194
    //   2191: goto -> 2266
    //   2194: aload_1
    //   2195: aconst_null
    //   2196: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2199: aload_1
    //   2200: aconst_null
    //   2201: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   2204: aload_1
    //   2205: aconst_null
    //   2206: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   2209: iload_2
    //   2210: istore #6
    //   2212: aload_1
    //   2213: getfield mTargetWho : Ljava/lang/String;
    //   2216: ifnull -> 2289
    //   2219: aload_0
    //   2220: getfield mActive : Ljava/util/HashMap;
    //   2223: aload_1
    //   2224: getfield mTargetWho : Ljava/lang/String;
    //   2227: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2230: checkcast androidx/fragment/app/Fragment
    //   2233: astore #11
    //   2235: iload_2
    //   2236: istore #6
    //   2238: aload #11
    //   2240: ifnull -> 2289
    //   2243: iload_2
    //   2244: istore #6
    //   2246: aload #11
    //   2248: invokevirtual getRetainInstance : ()Z
    //   2251: ifeq -> 2289
    //   2254: aload_1
    //   2255: aload #11
    //   2257: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   2260: iload_2
    //   2261: istore #6
    //   2263: goto -> 2289
    //   2266: aload_0
    //   2267: aload_1
    //   2268: invokevirtual makeInactive : (Landroidx/fragment/app/Fragment;)V
    //   2271: iload_2
    //   2272: istore #6
    //   2274: goto -> 2289
    //   2277: aload_1
    //   2278: iload_2
    //   2279: invokevirtual setStateAfterAnimating : (I)V
    //   2282: iload #7
    //   2284: istore #6
    //   2286: goto -> 2289
    //   2289: aload_1
    //   2290: getfield mState : I
    //   2293: iload #6
    //   2295: if_icmpeq -> 2376
    //   2298: new java/lang/StringBuilder
    //   2301: dup
    //   2302: invokespecial <init> : ()V
    //   2305: astore #11
    //   2307: aload #11
    //   2309: ldc_w 'moveToState: Fragment state for '
    //   2312: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2315: pop
    //   2316: aload #11
    //   2318: aload_1
    //   2319: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2322: pop
    //   2323: aload #11
    //   2325: ldc_w ' not updated inline; expected state '
    //   2328: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2331: pop
    //   2332: aload #11
    //   2334: iload #6
    //   2336: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2339: pop
    //   2340: aload #11
    //   2342: ldc_w ' found '
    //   2345: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2348: pop
    //   2349: aload #11
    //   2351: aload_1
    //   2352: getfield mState : I
    //   2355: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2358: pop
    //   2359: ldc 'FragmentManager'
    //   2361: aload #11
    //   2363: invokevirtual toString : ()Ljava/lang/String;
    //   2366: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2369: pop
    //   2370: aload_1
    //   2371: iload #6
    //   2373: putfield mState : I
    //   2376: return
    //   2377: astore #11
    //   2379: goto -> 1068
    // Exception table:
    //   from	to	target	type
    //   1052	1065	2377	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    int i = 0;
    this.mStateSaved = false;
    this.mStopped = false;
    int j = this.mAdded.size();
    while (i < j) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      i++;
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str2 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    int i = 0;
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    str2 = typedArray.getString(2);
    typedArray.recycle();
    if (str1 != null) {
      if (!FragmentFactory.isFragmentClass(paramContext.getClassLoader(), str1))
        return null; 
      if (paramView != null)
        i = paramView.getId(); 
      if (i != -1 || j != -1 || str2 != null) {
        if (j != -1)
          fragment2 = findFragmentById(j); 
        Fragment fragment1 = fragment2;
        if (fragment2 == null) {
          fragment1 = fragment2;
          if (str2 != null)
            fragment1 = findFragmentByTag(str2); 
        } 
        Fragment fragment2 = fragment1;
        if (fragment1 == null) {
          fragment2 = fragment1;
          if (i != -1)
            fragment2 = findFragmentById(i); 
        } 
        if (DEBUG) {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("onCreateView: id=0x");
          stringBuilder2.append(Integer.toHexString(j));
          stringBuilder2.append(" fname=");
          stringBuilder2.append(str1);
          stringBuilder2.append(" existing=");
          stringBuilder2.append(fragment2);
          Log.v("FragmentManager", stringBuilder2.toString());
        } 
        if (fragment2 == null) {
          int k;
          fragment2 = getFragmentFactory().instantiate(paramContext.getClassLoader(), str1);
          fragment2.mFromLayout = true;
          if (j != 0) {
            k = j;
          } else {
            k = i;
          } 
          fragment2.mFragmentId = k;
          fragment2.mContainerId = i;
          fragment2.mTag = str2;
          fragment2.mInLayout = true;
          fragment2.mFragmentManager = this;
          fragment2.mHost = this.mHost;
          fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
          addFragment(fragment2, true);
        } else if (!fragment2.mInLayout) {
          fragment2.mInLayout = true;
          fragment2.mHost = this.mHost;
          fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
        } else {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(paramAttributeSet.getPositionDescription());
          stringBuilder2.append(": Duplicate id 0x");
          stringBuilder2.append(Integer.toHexString(j));
          stringBuilder2.append(", tag ");
          stringBuilder2.append(str2);
          stringBuilder2.append(", or parent id 0x");
          stringBuilder2.append(Integer.toHexString(i));
          stringBuilder2.append(" with another fragment for ");
          stringBuilder2.append(str1);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        if (this.mCurState < 1 && fragment2.mFromLayout) {
          moveToState(fragment2, 1, 0, 0, false);
        } else {
          moveToState(fragment2);
        } 
        if (fragment2.mView != null) {
          if (j != 0)
            fragment2.mView.setId(j); 
          if (fragment2.mView.getTag() == null)
            fragment2.mView.setTag(str2); 
          return fragment2.mView;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Fragment ");
        stringBuilder1.append(str1);
        stringBuilder1.append(" did not create a view.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramAttributeSet.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str1);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView((View)null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      moveToState(paramFragment, this.mCurState, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate((String)null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 >= 0)
      return popBackStackImmediate((String)null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 70
    //   17: iload #4
    //   19: ifge -> 70
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 70
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield mBackStack : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: iconst_1
    //   61: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   64: invokevirtual add : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: iconst_1
    //   69: ireturn
    //   70: aload_3
    //   71: ifnonnull -> 88
    //   74: iload #4
    //   76: iflt -> 82
    //   79: goto -> 88
    //   82: iconst_m1
    //   83: istore #4
    //   85: goto -> 263
    //   88: aload #8
    //   90: invokevirtual size : ()I
    //   93: iconst_1
    //   94: isub
    //   95: istore #6
    //   97: iload #6
    //   99: iflt -> 162
    //   102: aload_0
    //   103: getfield mBackStack : Ljava/util/ArrayList;
    //   106: iload #6
    //   108: invokevirtual get : (I)Ljava/lang/Object;
    //   111: checkcast androidx/fragment/app/BackStackRecord
    //   114: astore #8
    //   116: aload_3
    //   117: ifnull -> 135
    //   120: aload_3
    //   121: aload #8
    //   123: invokevirtual getName : ()Ljava/lang/String;
    //   126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   129: ifeq -> 135
    //   132: goto -> 162
    //   135: iload #4
    //   137: iflt -> 153
    //   140: iload #4
    //   142: aload #8
    //   144: getfield mIndex : I
    //   147: if_icmpne -> 153
    //   150: goto -> 162
    //   153: iload #6
    //   155: iconst_1
    //   156: isub
    //   157: istore #6
    //   159: goto -> 97
    //   162: iload #6
    //   164: ifge -> 169
    //   167: iconst_0
    //   168: ireturn
    //   169: iload #6
    //   171: istore #7
    //   173: iload #5
    //   175: iconst_1
    //   176: iand
    //   177: ifeq -> 259
    //   180: iload #6
    //   182: iconst_1
    //   183: isub
    //   184: istore #5
    //   186: iload #5
    //   188: istore #7
    //   190: iload #5
    //   192: iflt -> 259
    //   195: aload_0
    //   196: getfield mBackStack : Ljava/util/ArrayList;
    //   199: iload #5
    //   201: invokevirtual get : (I)Ljava/lang/Object;
    //   204: checkcast androidx/fragment/app/BackStackRecord
    //   207: astore #8
    //   209: aload_3
    //   210: ifnull -> 229
    //   213: iload #5
    //   215: istore #6
    //   217: aload_3
    //   218: aload #8
    //   220: invokevirtual getName : ()Ljava/lang/String;
    //   223: invokevirtual equals : (Ljava/lang/Object;)Z
    //   226: ifne -> 180
    //   229: iload #5
    //   231: istore #7
    //   233: iload #4
    //   235: iflt -> 259
    //   238: iload #5
    //   240: istore #7
    //   242: iload #4
    //   244: aload #8
    //   246: getfield mIndex : I
    //   249: if_icmpne -> 259
    //   252: iload #5
    //   254: istore #6
    //   256: goto -> 180
    //   259: iload #7
    //   261: istore #4
    //   263: iload #4
    //   265: aload_0
    //   266: getfield mBackStack : Ljava/util/ArrayList;
    //   269: invokevirtual size : ()I
    //   272: iconst_1
    //   273: isub
    //   274: if_icmpne -> 279
    //   277: iconst_0
    //   278: ireturn
    //   279: aload_0
    //   280: getfield mBackStack : Ljava/util/ArrayList;
    //   283: invokevirtual size : ()I
    //   286: iconst_1
    //   287: isub
    //   288: istore #5
    //   290: iload #5
    //   292: iload #4
    //   294: if_icmple -> 329
    //   297: aload_1
    //   298: aload_0
    //   299: getfield mBackStack : Ljava/util/ArrayList;
    //   302: iload #5
    //   304: invokevirtual remove : (I)Ljava/lang/Object;
    //   307: invokevirtual add : (Ljava/lang/Object;)Z
    //   310: pop
    //   311: aload_2
    //   312: iconst_1
    //   313: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   316: invokevirtual add : (Ljava/lang/Object;)Z
    //   319: pop
    //   320: iload #5
    //   322: iconst_1
    //   323: isub
    //   324: istore #5
    //   326: goto -> 290
    //   329: iconst_1
    //   330: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new FragmentLifecycleCallbacksHolder(paramFragmentLifecycleCallbacks, paramBoolean));
  }
  
  public void removeFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<FragmentManager.OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void removeRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.removeRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You must use restoreSaveState when your FragmentHostCallback implements ViewModelStoreOwner")); 
    this.mNonConfig.restoreFromSnapshot(paramFragmentManagerNonConfig);
    restoreSaveState(paramParcelable);
  }
  
  void restoreSaveState(Parcelable paramParcelable) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/FragmentManagerState
    //   9: astore #4
    //   11: aload #4
    //   13: getfield mActive : Ljava/util/ArrayList;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_0
    //   21: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   24: invokevirtual getRetainedFragments : ()Ljava/util/Collection;
    //   27: invokeinterface iterator : ()Ljava/util/Iterator;
    //   32: astore #5
    //   34: aload #5
    //   36: invokeinterface hasNext : ()Z
    //   41: ifeq -> 347
    //   44: aload #5
    //   46: invokeinterface next : ()Ljava/lang/Object;
    //   51: checkcast androidx/fragment/app/Fragment
    //   54: astore #6
    //   56: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   59: ifeq -> 95
    //   62: new java/lang/StringBuilder
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: astore_1
    //   70: aload_1
    //   71: ldc_w 'restoreSaveState: re-attaching retained '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload_1
    //   79: aload #6
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc 'FragmentManager'
    //   87: aload_1
    //   88: invokevirtual toString : ()Ljava/lang/String;
    //   91: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   94: pop
    //   95: aload #4
    //   97: getfield mActive : Ljava/util/ArrayList;
    //   100: invokevirtual iterator : ()Ljava/util/Iterator;
    //   103: astore_3
    //   104: aload_3
    //   105: invokeinterface hasNext : ()Z
    //   110: ifeq -> 141
    //   113: aload_3
    //   114: invokeinterface next : ()Ljava/lang/Object;
    //   119: checkcast androidx/fragment/app/FragmentState
    //   122: astore_1
    //   123: aload_1
    //   124: getfield mWho : Ljava/lang/String;
    //   127: aload #6
    //   129: getfield mWho : Ljava/lang/String;
    //   132: invokevirtual equals : (Ljava/lang/Object;)Z
    //   135: ifeq -> 104
    //   138: goto -> 143
    //   141: aconst_null
    //   142: astore_1
    //   143: aload_1
    //   144: ifnonnull -> 233
    //   147: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   150: ifeq -> 204
    //   153: new java/lang/StringBuilder
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore_1
    //   161: aload_1
    //   162: ldc_w 'Discarding retained Fragment '
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: pop
    //   169: aload_1
    //   170: aload #6
    //   172: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   175: pop
    //   176: aload_1
    //   177: ldc_w ' that was not found in the set of active Fragments '
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: aload_1
    //   185: aload #4
    //   187: getfield mActive : Ljava/util/ArrayList;
    //   190: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   193: pop
    //   194: ldc 'FragmentManager'
    //   196: aload_1
    //   197: invokevirtual toString : ()Ljava/lang/String;
    //   200: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   203: pop
    //   204: aload_0
    //   205: aload #6
    //   207: iconst_1
    //   208: iconst_0
    //   209: iconst_0
    //   210: iconst_0
    //   211: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   214: aload #6
    //   216: iconst_1
    //   217: putfield mRemoving : Z
    //   220: aload_0
    //   221: aload #6
    //   223: iconst_0
    //   224: iconst_0
    //   225: iconst_0
    //   226: iconst_0
    //   227: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   230: goto -> 34
    //   233: aload_1
    //   234: aload #6
    //   236: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   239: aload #6
    //   241: aconst_null
    //   242: putfield mSavedViewState : Landroid/util/SparseArray;
    //   245: aload #6
    //   247: iconst_0
    //   248: putfield mBackStackNesting : I
    //   251: aload #6
    //   253: iconst_0
    //   254: putfield mInLayout : Z
    //   257: aload #6
    //   259: iconst_0
    //   260: putfield mAdded : Z
    //   263: aload #6
    //   265: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   268: ifnull -> 283
    //   271: aload #6
    //   273: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   276: getfield mWho : Ljava/lang/String;
    //   279: astore_3
    //   280: goto -> 285
    //   283: aconst_null
    //   284: astore_3
    //   285: aload #6
    //   287: aload_3
    //   288: putfield mTargetWho : Ljava/lang/String;
    //   291: aload #6
    //   293: aconst_null
    //   294: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   297: aload_1
    //   298: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   301: ifnull -> 34
    //   304: aload_1
    //   305: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   308: aload_0
    //   309: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   312: invokevirtual getContext : ()Landroid/content/Context;
    //   315: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   318: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   321: aload #6
    //   323: aload_1
    //   324: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   327: ldc 'android:view_state'
    //   329: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   332: putfield mSavedViewState : Landroid/util/SparseArray;
    //   335: aload #6
    //   337: aload_1
    //   338: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   341: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   344: goto -> 34
    //   347: aload_0
    //   348: getfield mActive : Ljava/util/HashMap;
    //   351: invokevirtual clear : ()V
    //   354: aload #4
    //   356: getfield mActive : Ljava/util/ArrayList;
    //   359: invokevirtual iterator : ()Ljava/util/Iterator;
    //   362: astore_1
    //   363: aload_1
    //   364: invokeinterface hasNext : ()Z
    //   369: ifeq -> 498
    //   372: aload_1
    //   373: invokeinterface next : ()Ljava/lang/Object;
    //   378: checkcast androidx/fragment/app/FragmentState
    //   381: astore_3
    //   382: aload_3
    //   383: ifnull -> 363
    //   386: aload_3
    //   387: aload_0
    //   388: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   391: invokevirtual getContext : ()Landroid/content/Context;
    //   394: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   397: aload_0
    //   398: invokevirtual getFragmentFactory : ()Landroidx/fragment/app/FragmentFactory;
    //   401: invokevirtual instantiate : (Ljava/lang/ClassLoader;Landroidx/fragment/app/FragmentFactory;)Landroidx/fragment/app/Fragment;
    //   404: astore #5
    //   406: aload #5
    //   408: aload_0
    //   409: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   412: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   415: ifeq -> 475
    //   418: new java/lang/StringBuilder
    //   421: dup
    //   422: invokespecial <init> : ()V
    //   425: astore #6
    //   427: aload #6
    //   429: ldc_w 'restoreSaveState: active ('
    //   432: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   435: pop
    //   436: aload #6
    //   438: aload #5
    //   440: getfield mWho : Ljava/lang/String;
    //   443: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   446: pop
    //   447: aload #6
    //   449: ldc_w '): '
    //   452: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   455: pop
    //   456: aload #6
    //   458: aload #5
    //   460: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   463: pop
    //   464: ldc 'FragmentManager'
    //   466: aload #6
    //   468: invokevirtual toString : ()Ljava/lang/String;
    //   471: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   474: pop
    //   475: aload_0
    //   476: getfield mActive : Ljava/util/HashMap;
    //   479: aload #5
    //   481: getfield mWho : Ljava/lang/String;
    //   484: aload #5
    //   486: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   489: pop
    //   490: aload_3
    //   491: aconst_null
    //   492: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   495: goto -> 363
    //   498: aload_0
    //   499: getfield mAdded : Ljava/util/ArrayList;
    //   502: invokevirtual clear : ()V
    //   505: aload #4
    //   507: getfield mAdded : Ljava/util/ArrayList;
    //   510: ifnull -> 749
    //   513: aload #4
    //   515: getfield mAdded : Ljava/util/ArrayList;
    //   518: invokevirtual iterator : ()Ljava/util/Iterator;
    //   521: astore_3
    //   522: aload_3
    //   523: invokeinterface hasNext : ()Z
    //   528: ifeq -> 749
    //   531: aload_3
    //   532: invokeinterface next : ()Ljava/lang/Object;
    //   537: checkcast java/lang/String
    //   540: astore #5
    //   542: aload_0
    //   543: getfield mActive : Ljava/util/HashMap;
    //   546: aload #5
    //   548: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   551: checkcast androidx/fragment/app/Fragment
    //   554: astore_1
    //   555: aload_1
    //   556: ifnonnull -> 610
    //   559: new java/lang/StringBuilder
    //   562: dup
    //   563: invokespecial <init> : ()V
    //   566: astore #6
    //   568: aload #6
    //   570: ldc_w 'No instantiated fragment for ('
    //   573: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   576: pop
    //   577: aload #6
    //   579: aload #5
    //   581: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   584: pop
    //   585: aload #6
    //   587: ldc_w ')'
    //   590: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   593: pop
    //   594: aload_0
    //   595: new java/lang/IllegalStateException
    //   598: dup
    //   599: aload #6
    //   601: invokevirtual toString : ()Ljava/lang/String;
    //   604: invokespecial <init> : (Ljava/lang/String;)V
    //   607: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   610: aload_1
    //   611: iconst_1
    //   612: putfield mAdded : Z
    //   615: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   618: ifeq -> 674
    //   621: new java/lang/StringBuilder
    //   624: dup
    //   625: invokespecial <init> : ()V
    //   628: astore #6
    //   630: aload #6
    //   632: ldc_w 'restoreSaveState: added ('
    //   635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   638: pop
    //   639: aload #6
    //   641: aload #5
    //   643: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   646: pop
    //   647: aload #6
    //   649: ldc_w '): '
    //   652: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   655: pop
    //   656: aload #6
    //   658: aload_1
    //   659: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   662: pop
    //   663: ldc 'FragmentManager'
    //   665: aload #6
    //   667: invokevirtual toString : ()Ljava/lang/String;
    //   670: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   673: pop
    //   674: aload_0
    //   675: getfield mAdded : Ljava/util/ArrayList;
    //   678: aload_1
    //   679: invokevirtual contains : (Ljava/lang/Object;)Z
    //   682: ifne -> 715
    //   685: aload_0
    //   686: getfield mAdded : Ljava/util/ArrayList;
    //   689: astore #5
    //   691: aload #5
    //   693: monitorenter
    //   694: aload_0
    //   695: getfield mAdded : Ljava/util/ArrayList;
    //   698: aload_1
    //   699: invokevirtual add : (Ljava/lang/Object;)Z
    //   702: pop
    //   703: aload #5
    //   705: monitorexit
    //   706: goto -> 522
    //   709: astore_1
    //   710: aload #5
    //   712: monitorexit
    //   713: aload_1
    //   714: athrow
    //   715: new java/lang/StringBuilder
    //   718: dup
    //   719: invokespecial <init> : ()V
    //   722: astore_3
    //   723: aload_3
    //   724: ldc_w 'Already added '
    //   727: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   730: pop
    //   731: aload_3
    //   732: aload_1
    //   733: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   736: pop
    //   737: new java/lang/IllegalStateException
    //   740: dup
    //   741: aload_3
    //   742: invokevirtual toString : ()Ljava/lang/String;
    //   745: invokespecial <init> : (Ljava/lang/String;)V
    //   748: athrow
    //   749: aload #4
    //   751: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   754: ifnull -> 929
    //   757: aload_0
    //   758: new java/util/ArrayList
    //   761: dup
    //   762: aload #4
    //   764: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   767: arraylength
    //   768: invokespecial <init> : (I)V
    //   771: putfield mBackStack : Ljava/util/ArrayList;
    //   774: iconst_0
    //   775: istore_2
    //   776: iload_2
    //   777: aload #4
    //   779: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   782: arraylength
    //   783: if_icmpge -> 934
    //   786: aload #4
    //   788: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   791: iload_2
    //   792: aaload
    //   793: aload_0
    //   794: invokevirtual instantiate : (Landroidx/fragment/app/FragmentManagerImpl;)Landroidx/fragment/app/BackStackRecord;
    //   797: astore_1
    //   798: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   801: ifeq -> 897
    //   804: new java/lang/StringBuilder
    //   807: dup
    //   808: invokespecial <init> : ()V
    //   811: astore_3
    //   812: aload_3
    //   813: ldc_w 'restoreAllState: back stack #'
    //   816: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   819: pop
    //   820: aload_3
    //   821: iload_2
    //   822: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   825: pop
    //   826: aload_3
    //   827: ldc_w ' (index '
    //   830: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   833: pop
    //   834: aload_3
    //   835: aload_1
    //   836: getfield mIndex : I
    //   839: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   842: pop
    //   843: aload_3
    //   844: ldc_w '): '
    //   847: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   850: pop
    //   851: aload_3
    //   852: aload_1
    //   853: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   856: pop
    //   857: ldc 'FragmentManager'
    //   859: aload_3
    //   860: invokevirtual toString : ()Ljava/lang/String;
    //   863: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   866: pop
    //   867: new java/io/PrintWriter
    //   870: dup
    //   871: new androidx/core/util/LogWriter
    //   874: dup
    //   875: ldc 'FragmentManager'
    //   877: invokespecial <init> : (Ljava/lang/String;)V
    //   880: invokespecial <init> : (Ljava/io/Writer;)V
    //   883: astore_3
    //   884: aload_1
    //   885: ldc_w '  '
    //   888: aload_3
    //   889: iconst_0
    //   890: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   893: aload_3
    //   894: invokevirtual close : ()V
    //   897: aload_0
    //   898: getfield mBackStack : Ljava/util/ArrayList;
    //   901: aload_1
    //   902: invokevirtual add : (Ljava/lang/Object;)Z
    //   905: pop
    //   906: aload_1
    //   907: getfield mIndex : I
    //   910: iflt -> 922
    //   913: aload_0
    //   914: aload_1
    //   915: getfield mIndex : I
    //   918: aload_1
    //   919: invokevirtual setBackStackIndex : (ILandroidx/fragment/app/BackStackRecord;)V
    //   922: iload_2
    //   923: iconst_1
    //   924: iadd
    //   925: istore_2
    //   926: goto -> 776
    //   929: aload_0
    //   930: aconst_null
    //   931: putfield mBackStack : Ljava/util/ArrayList;
    //   934: aload #4
    //   936: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   939: ifnull -> 968
    //   942: aload_0
    //   943: getfield mActive : Ljava/util/HashMap;
    //   946: aload #4
    //   948: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   951: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   954: checkcast androidx/fragment/app/Fragment
    //   957: astore_1
    //   958: aload_0
    //   959: aload_1
    //   960: putfield mPrimaryNav : Landroidx/fragment/app/Fragment;
    //   963: aload_0
    //   964: aload_1
    //   965: invokespecial dispatchParentPrimaryNavigationFragmentChanged : (Landroidx/fragment/app/Fragment;)V
    //   968: aload_0
    //   969: aload #4
    //   971: getfield mNextFragmentIndex : I
    //   974: putfield mNextFragmentIndex : I
    //   977: return
    // Exception table:
    //   from	to	target	type
    //   694	706	709	finally
    //   710	713	709	finally
  }
  
  @Deprecated
  FragmentManagerNonConfig retainNonConfig() {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You cannot use retainNonConfig when your FragmentHostCallback implements ViewModelStoreOwner.")); 
    return this.mNonConfig.getSnapshot();
  }
  
  Parcelable saveAllState() {
    StringBuilder stringBuilder;
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    boolean bool1 = this.mActive.isEmpty();
    BackStackState[] arrayOfBackStackState2 = null;
    if (bool1)
      return null; 
    ArrayList<FragmentState> arrayList = new ArrayList(this.mActive.size());
    Iterator<Fragment> iterator = this.mActive.values().iterator();
    boolean bool = false;
    int i = 0;
    while (iterator.hasNext()) {
      Fragment fragment1 = iterator.next();
      if (fragment1 != null) {
        if (fragment1.mFragmentManager != this) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failure saving state: active ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(" was removed from the FragmentManager");
          throwException(new IllegalStateException(stringBuilder1.toString()));
        } 
        FragmentState fragmentState = new FragmentState(fragment1);
        arrayList.add(fragmentState);
        if (fragment1.mState > 0 && fragmentState.mSavedFragmentState == null) {
          fragmentState.mSavedFragmentState = saveFragmentBasicState(fragment1);
          if (fragment1.mTargetWho != null) {
            Fragment fragment2 = this.mActive.get(fragment1.mTargetWho);
            if (fragment2 == null) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: ");
              stringBuilder1.append(fragment1);
              stringBuilder1.append(" has target not in fragment manager: ");
              stringBuilder1.append(fragment1.mTargetWho);
              throwException(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (fragmentState.mSavedFragmentState == null)
              fragmentState.mSavedFragmentState = new Bundle(); 
            putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment2);
            if (fragment1.mTargetRequestCode != 0)
              fragmentState.mSavedFragmentState.putInt("android:target_req_state", fragment1.mTargetRequestCode); 
          } 
        } else {
          fragmentState.mSavedFragmentState = fragment1.mSavedFragmentState;
        } 
        if (DEBUG) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Saved state of ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(": ");
          stringBuilder1.append(fragmentState.mSavedFragmentState);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        i = 1;
      } 
    } 
    if (!i) {
      if (DEBUG)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    i = this.mAdded.size();
    if (i > 0) {
      ArrayList<String> arrayList2 = new ArrayList(i);
      Iterator<Fragment> iterator1 = this.mAdded.iterator();
      while (true) {
        ArrayList<String> arrayList3 = arrayList2;
        if (iterator1.hasNext()) {
          Fragment fragment1 = iterator1.next();
          arrayList2.add(fragment1.mWho);
          if (fragment1.mFragmentManager != this) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Failure saving state: active ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(" was removed from the FragmentManager");
            throwException(new IllegalStateException(stringBuilder1.toString()));
          } 
          if (DEBUG) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("saveAllState: adding fragment (");
            stringBuilder1.append(fragment1.mWho);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment1);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          continue;
        } 
        break;
      } 
    } else {
      iterator = null;
    } 
    ArrayList<BackStackRecord> arrayList1 = this.mBackStack;
    BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
    if (arrayList1 != null) {
      int j = arrayList1.size();
      arrayOfBackStackState1 = arrayOfBackStackState2;
      if (j > 0) {
        arrayOfBackStackState2 = new BackStackState[j];
        i = bool;
        while (true) {
          arrayOfBackStackState1 = arrayOfBackStackState2;
          if (i < j) {
            arrayOfBackStackState2[i] = new BackStackState(this.mBackStack.get(i));
            if (DEBUG) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(i);
              stringBuilder.append(": ");
              stringBuilder.append(this.mBackStack.get(i));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            i++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.mActive = arrayList;
    fragmentManagerState.mAdded = (ArrayList)iterator;
    fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null)
      fragmentManagerState.mPrimaryNavActiveWho = fragment.mWho; 
    fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
    return fragmentManagerState;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    boolean bool = this.mStateBundle.isEmpty();
    Bundle bundle2 = null;
    if (!bool) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    int i = paramFragment.mState;
    Fragment.SavedState savedState2 = null;
    Fragment.SavedState savedState1 = savedState2;
    if (i > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.mStateArray;
    if (sparseArray == null) {
      this.mStateArray = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
    if (this.mStateArray.size() > 0) {
      paramFragment.mSavedViewState = this.mStateArray;
      this.mStateArray = null;
    } 
  }
  
  void scheduleCommit() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 100
    //   15: aload #4
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 100
    //   23: iconst_1
    //   24: istore_1
    //   25: goto -> 28
    //   28: aload_0
    //   29: getfield mPendingActions : Ljava/util/ArrayList;
    //   32: astore #4
    //   34: iload_3
    //   35: istore_2
    //   36: aload #4
    //   38: ifnull -> 105
    //   41: iload_3
    //   42: istore_2
    //   43: aload #4
    //   45: invokevirtual size : ()I
    //   48: iconst_1
    //   49: if_icmpne -> 105
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 105
    //   57: aload_0
    //   58: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   61: invokevirtual getHandler : ()Landroid/os/Handler;
    //   64: aload_0
    //   65: getfield mExecCommit : Ljava/lang/Runnable;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   75: invokevirtual getHandler : ()Landroid/os/Handler;
    //   78: aload_0
    //   79: getfield mExecCommit : Ljava/lang/Runnable;
    //   82: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   85: pop
    //   86: aload_0
    //   87: invokespecial updateOnBackPressedCallbackEnabled : ()V
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: astore #4
    //   95: aload_0
    //   96: monitorexit
    //   97: aload #4
    //   99: athrow
    //   100: iconst_0
    //   101: istore_1
    //   102: goto -> 28
    //   105: iload_1
    //   106: ifne -> 57
    //   109: iload_2
    //   110: ifeq -> 90
    //   113: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	8	93	finally
    //   15	23	93	finally
    //   28	34	93	finally
    //   43	52	93	finally
    //   57	90	93	finally
    //   90	92	93	finally
    //   95	97	93	finally
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 109
    //   38: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 96
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #5
    //   53: aload #5
    //   55: ldc_w 'Setting back stack index '
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #5
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: ldc_w ' to '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc 'FragmentManager'
    //   87: aload #5
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   100: iload_1
    //   101: aload_2
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: goto -> 269
    //   109: iload_3
    //   110: iload_1
    //   111: if_icmpge -> 202
    //   114: aload_0
    //   115: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   118: aconst_null
    //   119: invokevirtual add : (Ljava/lang/Object;)Z
    //   122: pop
    //   123: aload_0
    //   124: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   127: ifnonnull -> 141
    //   130: aload_0
    //   131: new java/util/ArrayList
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   141: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   144: ifeq -> 183
    //   147: new java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: astore #5
    //   156: aload #5
    //   158: ldc_w 'Adding available back stack index '
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload #5
    //   167: iload_3
    //   168: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: ldc 'FragmentManager'
    //   174: aload #5
    //   176: invokevirtual toString : ()Ljava/lang/String;
    //   179: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   182: pop
    //   183: aload_0
    //   184: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   187: iload_3
    //   188: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   191: invokevirtual add : (Ljava/lang/Object;)Z
    //   194: pop
    //   195: iload_3
    //   196: iconst_1
    //   197: iadd
    //   198: istore_3
    //   199: goto -> 109
    //   202: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   205: ifeq -> 260
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore #5
    //   217: aload #5
    //   219: ldc_w 'Adding back stack index '
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload #5
    //   228: iload_1
    //   229: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #5
    //   235: ldc_w ' with '
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload #5
    //   244: aload_2
    //   245: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   248: pop
    //   249: ldc 'FragmentManager'
    //   251: aload #5
    //   253: invokevirtual toString : ()Ljava/lang/String;
    //   256: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   259: pop
    //   260: aload_0
    //   261: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   264: aload_2
    //   265: invokevirtual add : (Ljava/lang/Object;)Z
    //   268: pop
    //   269: aload_0
    //   270: monitorexit
    //   271: return
    //   272: astore_2
    //   273: aload_0
    //   274: monitorexit
    //   275: goto -> 280
    //   278: aload_2
    //   279: athrow
    //   280: goto -> 278
    // Exception table:
    //   from	to	target	type
    //   2	20	272	finally
    //   20	29	272	finally
    //   38	96	272	finally
    //   96	106	272	finally
    //   114	141	272	finally
    //   141	183	272	finally
    //   183	195	272	finally
    //   202	260	272	finally
    //   260	269	272	finally
    //   269	271	272	finally
    //   273	275	272	finally
  }
  
  public void setMaxLifecycle(Fragment paramFragment, Lifecycle.State paramState) {
    if (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      Fragment fragment = this.mPrimaryNav;
      this.mPrimaryNav = paramFragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
      dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void showFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  void startPendingDeferredFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      DebugUtils.buildShortClassTag(fragment, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore #4
    //   6: aload #4
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore_2
    //   11: aload_0
    //   12: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   15: invokevirtual size : ()I
    //   18: istore_3
    //   19: iload_2
    //   20: iload_3
    //   21: if_icmpge -> 54
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_2
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast androidx/fragment/app/FragmentManagerImpl$FragmentLifecycleCallbacksHolder
    //   35: getfield mCallback : Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;
    //   38: aload_1
    //   39: if_acmpne -> 70
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_2
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: goto -> 54
    //   54: aload #4
    //   56: monitorexit
    //   57: return
    //   58: astore_1
    //   59: aload #4
    //   61: monitorexit
    //   62: goto -> 67
    //   65: aload_1
    //   66: athrow
    //   67: goto -> 65
    //   70: iload_2
    //   71: iconst_1
    //   72: iadd
    //   73: istore_2
    //   74: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   11	19	58	finally
    //   24	51	58	finally
    //   54	57	58	finally
    //   59	62	58	finally
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class EndViewTransitionAnimation extends AnimationSet implements Runnable {
    private boolean mAnimating = true;
    
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimation(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.mEnded && this.mAnimating) {
        this.mAnimating = false;
        this.mParent.post(this);
        return;
      } 
      this.mParent.endViewTransition(this.mChild);
      this.mTransitionEnded = true;
    }
  }
  
  private static final class FragmentLifecycleCallbacksHolder {
    final FragmentManager.FragmentLifecycleCallbacks mCallback;
    
    final boolean mRecursive;
    
    FragmentLifecycleCallbacksHolder(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.mCallback = param1FragmentLifecycleCallbacks;
      this.mRecursive = param1Boolean;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      return (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null && FragmentManagerImpl.this.mPrimaryNav.getChildFragmentManager().popBackStackImmediate()) ? false : FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    final boolean mIsBack;
    
    private int mNumPostponed;
    
    final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      int i = this.mNumPostponed;
      int j = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int k = fragmentManagerImpl.mAdded.size();
      while (j < k) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(j);
        fragment.setOnStartEnterTransitionListener(null);
        if (i != 0 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        j++;
      } 
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, i ^ 0x1, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      int i = this.mNumPostponed - 1;
      this.mNumPostponed = i;
      if (i != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Rowdy Wrestling-dex2jar.jar!\androidx\fragment\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */