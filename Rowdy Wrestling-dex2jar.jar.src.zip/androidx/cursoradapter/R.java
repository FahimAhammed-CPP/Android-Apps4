package androidx.cursoradapter;

public final class R {}


/* Location:              C:\soft\dex2jar-2.0\Rowdy Wrestling-dex2jar.jar!\androidx\cursoradapter\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */