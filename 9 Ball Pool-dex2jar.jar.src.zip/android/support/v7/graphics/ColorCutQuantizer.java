package android.support.v7.graphics;

import android.graphics.Color;
import android.support.v4.graphics.ColorUtils;
import android.util.TimingLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;

final class ColorCutQuantizer {
  static final int COMPONENT_BLUE = -1;
  
  static final int COMPONENT_GREEN = -2;
  
  static final int COMPONENT_RED = -3;
  
  private static final String LOG_TAG = "ColorCutQuantizer";
  
  private static final boolean LOG_TIMINGS = false;
  
  private static final int QUANTIZE_WORD_MASK = 31;
  
  private static final int QUANTIZE_WORD_WIDTH = 5;
  
  private static final Comparator<Vbox> VBOX_COMPARATOR_VOLUME = new Comparator<Vbox>() {
      public int compare(ColorCutQuantizer.Vbox param1Vbox1, ColorCutQuantizer.Vbox param1Vbox2) {
        return param1Vbox2.getVolume() - param1Vbox1.getVolume();
      }
    };
  
  final int[] mColors;
  
  final Palette.Filter[] mFilters;
  
  final int[] mHistogram;
  
  final List<Palette.Swatch> mQuantizedColors;
  
  private final float[] mTempHsl = new float[3];
  
  final TimingLogger mTimingLogger = null;
  
  ColorCutQuantizer(int[] paramArrayOfint, int paramInt, Palette.Filter[] paramArrayOfFilter) {
    this.mFilters = paramArrayOfFilter;
    int[] arrayOfInt = new int[32768];
    this.mHistogram = arrayOfInt;
    boolean bool = false;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      int m = quantizeFromRgb888(paramArrayOfint[i]);
      paramArrayOfint[i] = m;
      arrayOfInt[m] = arrayOfInt[m] + 1;
    } 
    int j = 0;
    for (i = 0; j < arrayOfInt.length; i = m) {
      if (arrayOfInt[j] > 0 && shouldIgnoreColor(j))
        arrayOfInt[j] = 0; 
      int m = i;
      if (arrayOfInt[j] > 0)
        m = i + 1; 
      j++;
    } 
    paramArrayOfint = new int[i];
    this.mColors = paramArrayOfint;
    j = 0;
    int k;
    for (k = 0; j < arrayOfInt.length; k = m) {
      int m = k;
      if (arrayOfInt[j] > 0) {
        paramArrayOfint[k] = j;
        m = k + 1;
      } 
      j++;
    } 
    if (i <= paramInt) {
      this.mQuantizedColors = new ArrayList<Palette.Swatch>();
      i = paramArrayOfint.length;
      for (paramInt = bool; paramInt < i; paramInt++) {
        j = paramArrayOfint[paramInt];
        this.mQuantizedColors.add(new Palette.Swatch(approximateToRgb888(j), arrayOfInt[j]));
      } 
    } else {
      this.mQuantizedColors = quantizePixels(paramInt);
    } 
  }
  
  private static int approximateToRgb888(int paramInt) {
    return approximateToRgb888(quantizedRed(paramInt), quantizedGreen(paramInt), quantizedBlue(paramInt));
  }
  
  static int approximateToRgb888(int paramInt1, int paramInt2, int paramInt3) {
    return Color.rgb(modifyWordWidth(paramInt1, 5, 8), modifyWordWidth(paramInt2, 5, 8), modifyWordWidth(paramInt3, 5, 8));
  }
  
  private List<Palette.Swatch> generateAverageColors(Collection<Vbox> paramCollection) {
    ArrayList<Palette.Swatch> arrayList = new ArrayList(paramCollection.size());
    Iterator<Vbox> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      Palette.Swatch swatch = ((Vbox)iterator.next()).getAverageColor();
      if (!shouldIgnoreColor(swatch))
        arrayList.add(swatch); 
    } 
    return arrayList;
  }
  
  static void modifySignificantOctet(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2;
    switch (paramInt1) {
      default:
        return;
      case -1:
        while (i <= paramInt3) {
          paramInt1 = paramArrayOfint[i];
          paramInt2 = quantizedBlue(paramInt1);
          int j = quantizedGreen(paramInt1);
          paramArrayOfint[i] = quantizedRed(paramInt1) | paramInt2 << 10 | j << 5;
          i++;
        } 
        break;
      case -2:
        while (paramInt2 <= paramInt3) {
          paramInt1 = paramArrayOfint[paramInt2];
          i = quantizedGreen(paramInt1);
          int j = quantizedRed(paramInt1);
          paramArrayOfint[paramInt2] = quantizedBlue(paramInt1) | i << 10 | j << 5;
          paramInt2++;
        } 
        break;
      case -3:
        break;
    } 
  }
  
  private static int modifyWordWidth(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 > paramInt2) {
      paramInt1 <<= paramInt3 - paramInt2;
    } else {
      paramInt1 >>= paramInt2 - paramInt3;
    } 
    return paramInt1 & (1 << paramInt3) - 1;
  }
  
  private static int quantizeFromRgb888(int paramInt) {
    int i = modifyWordWidth(Color.red(paramInt), 8, 5);
    int j = modifyWordWidth(Color.green(paramInt), 8, 5);
    return modifyWordWidth(Color.blue(paramInt), 8, 5) | i << 10 | j << 5;
  }
  
  private List<Palette.Swatch> quantizePixels(int paramInt) {
    PriorityQueue<Vbox> priorityQueue = new PriorityQueue<Vbox>(paramInt, VBOX_COMPARATOR_VOLUME);
    priorityQueue.offer(new Vbox(0, this.mColors.length - 1));
    splitBoxes(priorityQueue, paramInt);
    return generateAverageColors(priorityQueue);
  }
  
  static int quantizedBlue(int paramInt) {
    return paramInt & 0x1F;
  }
  
  static int quantizedGreen(int paramInt) {
    return paramInt >> 5 & 0x1F;
  }
  
  static int quantizedRed(int paramInt) {
    return paramInt >> 10 & 0x1F;
  }
  
  private boolean shouldIgnoreColor(int paramInt) {
    paramInt = approximateToRgb888(paramInt);
    ColorUtils.colorToHSL(paramInt, this.mTempHsl);
    return shouldIgnoreColor(paramInt, this.mTempHsl);
  }
  
  private boolean shouldIgnoreColor(int paramInt, float[] paramArrayOffloat) {
    if (this.mFilters != null && this.mFilters.length > 0) {
      int j = this.mFilters.length;
      for (int i = 0; i < j; i++) {
        if (!this.mFilters[i].isAllowed(paramInt, paramArrayOffloat))
          return true; 
      } 
    } 
    return false;
  }
  
  private boolean shouldIgnoreColor(Palette.Swatch paramSwatch) {
    return shouldIgnoreColor(paramSwatch.getRgb(), paramSwatch.getHsl());
  }
  
  private void splitBoxes(PriorityQueue<Vbox> paramPriorityQueue, int paramInt) {
    while (paramPriorityQueue.size() < paramInt) {
      Vbox vbox = paramPriorityQueue.poll();
      if (vbox != null && vbox.canSplit()) {
        paramPriorityQueue.offer(vbox.splitBox());
        paramPriorityQueue.offer(vbox);
        continue;
      } 
      return;
    } 
  }
  
  List<Palette.Swatch> getQuantizedColors() {
    return this.mQuantizedColors;
  }
  
  private class Vbox {
    private int mLowerIndex;
    
    private int mMaxBlue;
    
    private int mMaxGreen;
    
    private int mMaxRed;
    
    private int mMinBlue;
    
    private int mMinGreen;
    
    private int mMinRed;
    
    private int mPopulation;
    
    private int mUpperIndex;
    
    Vbox(int param1Int1, int param1Int2) {
      this.mLowerIndex = param1Int1;
      this.mUpperIndex = param1Int2;
      fitBox();
    }
    
    final boolean canSplit() {
      return (getColorCount() > 1);
    }
    
    final int findSplitPoint() {
      int i = getLongestColorDimension();
      int[] arrayOfInt1 = ColorCutQuantizer.this.mColors;
      int[] arrayOfInt2 = ColorCutQuantizer.this.mHistogram;
      ColorCutQuantizer.modifySignificantOctet(arrayOfInt1, i, this.mLowerIndex, this.mUpperIndex);
      Arrays.sort(arrayOfInt1, this.mLowerIndex, this.mUpperIndex + 1);
      ColorCutQuantizer.modifySignificantOctet(arrayOfInt1, i, this.mLowerIndex, this.mUpperIndex);
      int k = this.mPopulation / 2;
      i = this.mLowerIndex;
      int j = 0;
      while (i <= this.mUpperIndex) {
        j += arrayOfInt2[arrayOfInt1[i]];
        if (j >= k)
          return Math.min(this.mUpperIndex - 1, i); 
        i++;
      } 
      return this.mLowerIndex;
    }
    
    final void fitBox() {
      int[] arrayOfInt1 = ColorCutQuantizer.this.mColors;
      int[] arrayOfInt2 = ColorCutQuantizer.this.mHistogram;
      int m = this.mLowerIndex;
      int i2 = Integer.MAX_VALUE;
      int i3 = Integer.MIN_VALUE;
      int i1 = 0;
      int k = Integer.MAX_VALUE;
      int n = Integer.MIN_VALUE;
      int i = Integer.MAX_VALUE;
      int j;
      for (j = Integer.MIN_VALUE; m <= this.mUpperIndex; j = i6) {
        int i4 = arrayOfInt1[m];
        int i7 = i1 + arrayOfInt2[i4];
        int i5 = ColorCutQuantizer.quantizedRed(i4);
        int i6 = ColorCutQuantizer.quantizedGreen(i4);
        i4 = ColorCutQuantizer.quantizedBlue(i4);
        i1 = i3;
        if (i5 > i3)
          i1 = i5; 
        i3 = i2;
        if (i5 < i2)
          i3 = i5; 
        i5 = n;
        if (i6 > n)
          i5 = i6; 
        n = k;
        if (i6 < k)
          n = i6; 
        i6 = j;
        if (i4 > j)
          i6 = i4; 
        j = i;
        if (i4 < i)
          j = i4; 
        m++;
        i2 = i3;
        i3 = i1;
        i1 = i7;
        k = n;
        n = i5;
        i = j;
      } 
      this.mMinRed = i2;
      this.mMaxRed = i3;
      this.mMinGreen = k;
      this.mMaxGreen = n;
      this.mMinBlue = i;
      this.mMaxBlue = j;
      this.mPopulation = i1;
    }
    
    final Palette.Swatch getAverageColor() {
      int[] arrayOfInt1 = ColorCutQuantizer.this.mColors;
      int[] arrayOfInt2 = ColorCutQuantizer.this.mHistogram;
      int m = this.mLowerIndex;
      int n = 0;
      int k = 0;
      int j = 0;
      int i = 0;
      while (m <= this.mUpperIndex) {
        int i1 = arrayOfInt1[m];
        int i2 = arrayOfInt2[i1];
        n += i2;
        k += ColorCutQuantizer.quantizedRed(i1) * i2;
        j += ColorCutQuantizer.quantizedGreen(i1) * i2;
        i += i2 * ColorCutQuantizer.quantizedBlue(i1);
        m++;
      } 
      float f1 = k;
      float f2 = n;
      return new Palette.Swatch(ColorCutQuantizer.approximateToRgb888(Math.round(f1 / f2), Math.round(j / f2), Math.round(i / f2)), n);
    }
    
    final int getColorCount() {
      return this.mUpperIndex + 1 - this.mLowerIndex;
    }
    
    final int getLongestColorDimension() {
      int i = this.mMaxRed - this.mMinRed;
      int j = this.mMaxGreen - this.mMinGreen;
      int k = this.mMaxBlue - this.mMinBlue;
      return (i >= j && i >= k) ? -3 : ((j >= i && j >= k) ? -2 : -1);
    }
    
    final int getVolume() {
      return (this.mMaxRed - this.mMinRed + 1) * (this.mMaxGreen - this.mMinGreen + 1) * (this.mMaxBlue - this.mMinBlue + 1);
    }
    
    final Vbox splitBox() {
      if (canSplit()) {
        int i = findSplitPoint();
        Vbox vbox = new Vbox(i + 1, this.mUpperIndex);
        this.mUpperIndex = i;
        fitBox();
        return vbox;
      } 
      throw new IllegalStateException("Can not split a box with only 1 color");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v7\graphics\ColorCutQuantizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */