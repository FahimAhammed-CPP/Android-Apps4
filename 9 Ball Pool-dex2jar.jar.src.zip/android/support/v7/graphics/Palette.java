package android.support.v7.graphics;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.graphics.ColorUtils;
import android.support.v4.util.ArrayMap;
import android.util.Log;
import android.util.SparseBooleanArray;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class Palette {
  static final int DEFAULT_CALCULATE_NUMBER_COLORS = 16;
  
  static final Filter DEFAULT_FILTER = new Filter() {
      private static final float BLACK_MAX_LIGHTNESS = 0.05F;
      
      private static final float WHITE_MIN_LIGHTNESS = 0.95F;
      
      private boolean isBlack(float[] param1ArrayOffloat) {
        return (param1ArrayOffloat[2] <= 0.05F);
      }
      
      private boolean isNearRedILine(float[] param1ArrayOffloat) {
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (param1ArrayOffloat[0] >= 10.0F) {
          bool1 = bool2;
          if (param1ArrayOffloat[0] <= 37.0F) {
            bool1 = bool2;
            if (param1ArrayOffloat[1] <= 0.82F)
              bool1 = true; 
          } 
        } 
        return bool1;
      }
      
      private boolean isWhite(float[] param1ArrayOffloat) {
        return (param1ArrayOffloat[2] >= 0.95F);
      }
      
      public boolean isAllowed(int param1Int, float[] param1ArrayOffloat) {
        return (!isWhite(param1ArrayOffloat) && !isBlack(param1ArrayOffloat) && !isNearRedILine(param1ArrayOffloat));
      }
    };
  
  static final int DEFAULT_RESIZE_BITMAP_AREA = 12544;
  
  static final String LOG_TAG = "Palette";
  
  static final boolean LOG_TIMINGS = false;
  
  static final float MIN_CONTRAST_BODY_TEXT = 4.5F;
  
  static final float MIN_CONTRAST_TITLE_TEXT = 3.0F;
  
  private final Swatch mDominantSwatch;
  
  private final Map<Target, Swatch> mSelectedSwatches;
  
  private final List<Swatch> mSwatches;
  
  private final List<Target> mTargets;
  
  private final SparseBooleanArray mUsedColors;
  
  Palette(List<Swatch> paramList, List<Target> paramList1) {
    this.mSwatches = paramList;
    this.mTargets = paramList1;
    this.mUsedColors = new SparseBooleanArray();
    this.mSelectedSwatches = (Map<Target, Swatch>)new ArrayMap();
    this.mDominantSwatch = findDominantSwatch();
  }
  
  private static float[] copyHslValues(Swatch paramSwatch) {
    float[] arrayOfFloat = new float[3];
    System.arraycopy(paramSwatch.getHsl(), 0, arrayOfFloat, 0, 3);
    return arrayOfFloat;
  }
  
  private Swatch findDominantSwatch() {
    int k = this.mSwatches.size();
    int j = Integer.MIN_VALUE;
    Swatch swatch = null;
    int i = 0;
    while (i < k) {
      Swatch swatch1 = this.mSwatches.get(i);
      int m = j;
      if (swatch1.getPopulation() > j) {
        m = swatch1.getPopulation();
        swatch = swatch1;
      } 
      i++;
      j = m;
    } 
    return swatch;
  }
  
  @NonNull
  public static Builder from(@NonNull Bitmap paramBitmap) {
    return new Builder(paramBitmap);
  }
  
  @NonNull
  public static Palette from(@NonNull List<Swatch> paramList) {
    return (new Builder(paramList)).generate();
  }
  
  @Deprecated
  public static Palette generate(Bitmap paramBitmap) {
    return from(paramBitmap).generate();
  }
  
  @Deprecated
  public static Palette generate(Bitmap paramBitmap, int paramInt) {
    return from(paramBitmap).maximumColorCount(paramInt).generate();
  }
  
  @Deprecated
  public static AsyncTask<Bitmap, Void, Palette> generateAsync(Bitmap paramBitmap, int paramInt, PaletteAsyncListener paramPaletteAsyncListener) {
    return from(paramBitmap).maximumColorCount(paramInt).generate(paramPaletteAsyncListener);
  }
  
  @Deprecated
  public static AsyncTask<Bitmap, Void, Palette> generateAsync(Bitmap paramBitmap, PaletteAsyncListener paramPaletteAsyncListener) {
    return from(paramBitmap).generate(paramPaletteAsyncListener);
  }
  
  private float generateScore(Swatch paramSwatch, Target paramTarget) {
    float f2;
    boolean bool;
    float[] arrayOfFloat = paramSwatch.getHsl();
    if (this.mDominantSwatch != null) {
      bool = this.mDominantSwatch.getPopulation();
    } else {
      bool = true;
    } 
    float f1 = paramTarget.getSaturationWeight();
    float f3 = 0.0F;
    if (f1 > 0.0F) {
      f1 = paramTarget.getSaturationWeight();
      f1 = (1.0F - Math.abs(arrayOfFloat[1] - paramTarget.getTargetSaturation())) * f1;
    } else {
      f1 = 0.0F;
    } 
    if (paramTarget.getLightnessWeight() > 0.0F) {
      f2 = paramTarget.getLightnessWeight() * (1.0F - Math.abs(arrayOfFloat[2] - paramTarget.getTargetLightness()));
    } else {
      f2 = 0.0F;
    } 
    if (paramTarget.getPopulationWeight() > 0.0F)
      f3 = paramTarget.getPopulationWeight() * paramSwatch.getPopulation() / bool; 
    return f1 + f2 + f3;
  }
  
  private Swatch generateScoredTarget(Target paramTarget) {
    Swatch swatch = getMaxScoredSwatchForTarget(paramTarget);
    if (swatch != null && paramTarget.isExclusive())
      this.mUsedColors.append(swatch.getRgb(), true); 
    return swatch;
  }
  
  private Swatch getMaxScoredSwatchForTarget(Target paramTarget) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mSwatches : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore #6
    //   11: fconst_0
    //   12: fstore_2
    //   13: aconst_null
    //   14: astore #7
    //   16: iconst_0
    //   17: istore #5
    //   19: iload #5
    //   21: iload #6
    //   23: if_icmpge -> 107
    //   26: aload_0
    //   27: getfield mSwatches : Ljava/util/List;
    //   30: iload #5
    //   32: invokeinterface get : (I)Ljava/lang/Object;
    //   37: checkcast android/support/v7/graphics/Palette$Swatch
    //   40: astore #9
    //   42: fload_2
    //   43: fstore_3
    //   44: aload #7
    //   46: astore #8
    //   48: aload_0
    //   49: aload #9
    //   51: aload_1
    //   52: invokespecial shouldBeScoredForTarget : (Landroid/support/v7/graphics/Palette$Swatch;Landroid/support/v7/graphics/Target;)Z
    //   55: ifeq -> 92
    //   58: aload_0
    //   59: aload #9
    //   61: aload_1
    //   62: invokespecial generateScore : (Landroid/support/v7/graphics/Palette$Swatch;Landroid/support/v7/graphics/Target;)F
    //   65: fstore #4
    //   67: aload #7
    //   69: ifnull -> 85
    //   72: fload_2
    //   73: fstore_3
    //   74: aload #7
    //   76: astore #8
    //   78: fload #4
    //   80: fload_2
    //   81: fcmpl
    //   82: ifle -> 92
    //   85: aload #9
    //   87: astore #8
    //   89: fload #4
    //   91: fstore_3
    //   92: iload #5
    //   94: iconst_1
    //   95: iadd
    //   96: istore #5
    //   98: fload_3
    //   99: fstore_2
    //   100: aload #8
    //   102: astore #7
    //   104: goto -> 19
    //   107: aload #7
    //   109: areturn
  }
  
  private boolean shouldBeScoredForTarget(Swatch paramSwatch, Target paramTarget) {
    float[] arrayOfFloat = paramSwatch.getHsl();
    return (arrayOfFloat[1] >= paramTarget.getMinimumSaturation() && arrayOfFloat[1] <= paramTarget.getMaximumSaturation() && arrayOfFloat[2] >= paramTarget.getMinimumLightness() && arrayOfFloat[2] <= paramTarget.getMaximumLightness() && !this.mUsedColors.get(paramSwatch.getRgb()));
  }
  
  void generate() {
    int j = this.mTargets.size();
    for (int i = 0; i < j; i++) {
      Target target = this.mTargets.get(i);
      target.normalizeWeights();
      this.mSelectedSwatches.put(target, generateScoredTarget(target));
    } 
    this.mUsedColors.clear();
  }
  
  @ColorInt
  public int getColorForTarget(@NonNull Target paramTarget, @ColorInt int paramInt) {
    Swatch swatch = getSwatchForTarget(paramTarget);
    if (swatch != null)
      paramInt = swatch.getRgb(); 
    return paramInt;
  }
  
  @ColorInt
  public int getDarkMutedColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.DARK_MUTED, paramInt);
  }
  
  @Nullable
  public Swatch getDarkMutedSwatch() {
    return getSwatchForTarget(Target.DARK_MUTED);
  }
  
  @ColorInt
  public int getDarkVibrantColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.DARK_VIBRANT, paramInt);
  }
  
  @Nullable
  public Swatch getDarkVibrantSwatch() {
    return getSwatchForTarget(Target.DARK_VIBRANT);
  }
  
  @ColorInt
  public int getDominantColor(@ColorInt int paramInt) {
    if (this.mDominantSwatch != null)
      paramInt = this.mDominantSwatch.getRgb(); 
    return paramInt;
  }
  
  @Nullable
  public Swatch getDominantSwatch() {
    return this.mDominantSwatch;
  }
  
  @ColorInt
  public int getLightMutedColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.LIGHT_MUTED, paramInt);
  }
  
  @Nullable
  public Swatch getLightMutedSwatch() {
    return getSwatchForTarget(Target.LIGHT_MUTED);
  }
  
  @ColorInt
  public int getLightVibrantColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.LIGHT_VIBRANT, paramInt);
  }
  
  @Nullable
  public Swatch getLightVibrantSwatch() {
    return getSwatchForTarget(Target.LIGHT_VIBRANT);
  }
  
  @ColorInt
  public int getMutedColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.MUTED, paramInt);
  }
  
  @Nullable
  public Swatch getMutedSwatch() {
    return getSwatchForTarget(Target.MUTED);
  }
  
  @Nullable
  public Swatch getSwatchForTarget(@NonNull Target paramTarget) {
    return this.mSelectedSwatches.get(paramTarget);
  }
  
  @NonNull
  public List<Swatch> getSwatches() {
    return Collections.unmodifiableList(this.mSwatches);
  }
  
  @NonNull
  public List<Target> getTargets() {
    return Collections.unmodifiableList(this.mTargets);
  }
  
  @ColorInt
  public int getVibrantColor(@ColorInt int paramInt) {
    return getColorForTarget(Target.VIBRANT, paramInt);
  }
  
  @Nullable
  public Swatch getVibrantSwatch() {
    return getSwatchForTarget(Target.VIBRANT);
  }
  
  public static final class Builder {
    private final Bitmap mBitmap;
    
    private final List<Palette.Filter> mFilters = new ArrayList<Palette.Filter>();
    
    private int mMaxColors = 16;
    
    private Rect mRegion;
    
    private int mResizeArea = 12544;
    
    private int mResizeMaxDimension = -1;
    
    private final List<Palette.Swatch> mSwatches;
    
    private final List<Target> mTargets = new ArrayList<Target>();
    
    public Builder(@NonNull Bitmap param1Bitmap) {
      if (param1Bitmap != null && !param1Bitmap.isRecycled()) {
        this.mFilters.add(Palette.DEFAULT_FILTER);
        this.mBitmap = param1Bitmap;
        this.mSwatches = null;
        this.mTargets.add(Target.LIGHT_VIBRANT);
        this.mTargets.add(Target.VIBRANT);
        this.mTargets.add(Target.DARK_VIBRANT);
        this.mTargets.add(Target.LIGHT_MUTED);
        this.mTargets.add(Target.MUTED);
        this.mTargets.add(Target.DARK_MUTED);
        return;
      } 
      throw new IllegalArgumentException("Bitmap is not valid");
    }
    
    public Builder(@NonNull List<Palette.Swatch> param1List) {
      if (param1List != null && !param1List.isEmpty()) {
        this.mFilters.add(Palette.DEFAULT_FILTER);
        this.mSwatches = param1List;
        this.mBitmap = null;
        return;
      } 
      throw new IllegalArgumentException("List of Swatches is not valid");
    }
    
    private int[] getPixelsFromBitmap(Bitmap param1Bitmap) {
      int j = param1Bitmap.getWidth();
      int i = param1Bitmap.getHeight();
      int[] arrayOfInt2 = new int[j * i];
      param1Bitmap.getPixels(arrayOfInt2, 0, j, 0, 0, j, i);
      if (this.mRegion == null)
        return arrayOfInt2; 
      int k = this.mRegion.width();
      int m = this.mRegion.height();
      int[] arrayOfInt1 = new int[k * m];
      for (i = 0; i < m; i++)
        System.arraycopy(arrayOfInt2, (this.mRegion.top + i) * j + this.mRegion.left, arrayOfInt1, i * k, k); 
      return arrayOfInt1;
    }
    
    private Bitmap scaleBitmapDown(Bitmap param1Bitmap) {
      double d1;
      int i = this.mResizeArea;
      double d2 = -1.0D;
      if (i > 0) {
        i = param1Bitmap.getWidth() * param1Bitmap.getHeight();
        d1 = d2;
        if (i > this.mResizeArea) {
          d1 = this.mResizeArea;
          d2 = i;
          Double.isNaN(d1);
          Double.isNaN(d2);
          d1 = Math.sqrt(d1 / d2);
        } 
      } else {
        d1 = d2;
        if (this.mResizeMaxDimension > 0) {
          i = Math.max(param1Bitmap.getWidth(), param1Bitmap.getHeight());
          d1 = d2;
          if (i > this.mResizeMaxDimension) {
            d1 = this.mResizeMaxDimension;
            d2 = i;
            Double.isNaN(d1);
            Double.isNaN(d2);
            d1 /= d2;
          } 
        } 
      } 
      if (d1 <= 0.0D)
        return param1Bitmap; 
      d2 = param1Bitmap.getWidth();
      Double.isNaN(d2);
      i = (int)Math.ceil(d2 * d1);
      d2 = param1Bitmap.getHeight();
      Double.isNaN(d2);
      return Bitmap.createScaledBitmap(param1Bitmap, i, (int)Math.ceil(d2 * d1), false);
    }
    
    @NonNull
    public Builder addFilter(Palette.Filter param1Filter) {
      if (param1Filter != null)
        this.mFilters.add(param1Filter); 
      return this;
    }
    
    @NonNull
    public Builder addTarget(@NonNull Target param1Target) {
      if (!this.mTargets.contains(param1Target))
        this.mTargets.add(param1Target); 
      return this;
    }
    
    @NonNull
    public Builder clearFilters() {
      this.mFilters.clear();
      return this;
    }
    
    @NonNull
    public Builder clearRegion() {
      this.mRegion = null;
      return this;
    }
    
    @NonNull
    public Builder clearTargets() {
      if (this.mTargets != null)
        this.mTargets.clear(); 
      return this;
    }
    
    @NonNull
    public AsyncTask<Bitmap, Void, Palette> generate(@NonNull final Palette.PaletteAsyncListener listener) {
      if (listener != null)
        return (new AsyncTask<Bitmap, Void, Palette>() {
            protected Palette doInBackground(Bitmap... param2VarArgs) {
              try {
                return Palette.Builder.this.generate();
              } catch (Exception exception) {
                Log.e("Palette", "Exception thrown during async generate", exception);
                return null;
              } 
            }
            
            protected void onPostExecute(Palette param2Palette) {
              listener.onGenerated(param2Palette);
            }
          }).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Bitmap[] { this.mBitmap }); 
      throw new IllegalArgumentException("listener can not be null");
    }
    
    @NonNull
    public Palette generate() {
      List<Palette.Swatch> list;
      if (this.mBitmap != null) {
        Palette.Filter[] arrayOfFilter;
        Bitmap bitmap = scaleBitmapDown(this.mBitmap);
        Rect rect = this.mRegion;
        if (bitmap != this.mBitmap && rect != null) {
          double d1 = bitmap.getWidth();
          double d2 = this.mBitmap.getWidth();
          Double.isNaN(d1);
          Double.isNaN(d2);
          d1 /= d2;
          d2 = rect.left;
          Double.isNaN(d2);
          rect.left = (int)Math.floor(d2 * d1);
          d2 = rect.top;
          Double.isNaN(d2);
          rect.top = (int)Math.floor(d2 * d1);
          d2 = rect.right;
          Double.isNaN(d2);
          rect.right = Math.min((int)Math.ceil(d2 * d1), bitmap.getWidth());
          d2 = rect.bottom;
          Double.isNaN(d2);
          rect.bottom = Math.min((int)Math.ceil(d2 * d1), bitmap.getHeight());
        } 
        int[] arrayOfInt = getPixelsFromBitmap(bitmap);
        int i = this.mMaxColors;
        if (this.mFilters.isEmpty()) {
          rect = null;
        } else {
          arrayOfFilter = this.mFilters.<Palette.Filter>toArray(new Palette.Filter[this.mFilters.size()]);
        } 
        ColorCutQuantizer colorCutQuantizer = new ColorCutQuantizer(arrayOfInt, i, arrayOfFilter);
        if (bitmap != this.mBitmap)
          bitmap.recycle(); 
        list = colorCutQuantizer.getQuantizedColors();
      } else {
        list = this.mSwatches;
      } 
      Palette palette = new Palette(list, this.mTargets);
      palette.generate();
      return palette;
    }
    
    @NonNull
    public Builder maximumColorCount(int param1Int) {
      this.mMaxColors = param1Int;
      return this;
    }
    
    @NonNull
    public Builder resizeBitmapArea(int param1Int) {
      this.mResizeArea = param1Int;
      this.mResizeMaxDimension = -1;
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder resizeBitmapSize(int param1Int) {
      this.mResizeMaxDimension = param1Int;
      this.mResizeArea = -1;
      return this;
    }
    
    @NonNull
    public Builder setRegion(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.mBitmap != null) {
        if (this.mRegion == null)
          this.mRegion = new Rect(); 
        this.mRegion.set(0, 0, this.mBitmap.getWidth(), this.mBitmap.getHeight());
        if (this.mRegion.intersect(param1Int1, param1Int2, param1Int3, param1Int4))
          return this; 
        throw new IllegalArgumentException("The given region must intersect with the Bitmap's dimensions.");
      } 
      return this;
    }
  }
  
  class null extends AsyncTask<Bitmap, Void, Palette> {
    protected Palette doInBackground(Bitmap... param1VarArgs) {
      try {
        return this.this$0.generate();
      } catch (Exception exception) {
        Log.e("Palette", "Exception thrown during async generate", exception);
        return null;
      } 
    }
    
    protected void onPostExecute(Palette param1Palette) {
      listener.onGenerated(param1Palette);
    }
  }
  
  public static interface Filter {
    boolean isAllowed(@ColorInt int param1Int, @NonNull float[] param1ArrayOffloat);
  }
  
  public static interface PaletteAsyncListener {
    void onGenerated(@NonNull Palette param1Palette);
  }
  
  public static final class Swatch {
    private final int mBlue;
    
    private int mBodyTextColor;
    
    private boolean mGeneratedTextColors;
    
    private final int mGreen;
    
    private float[] mHsl;
    
    private final int mPopulation;
    
    private final int mRed;
    
    private final int mRgb;
    
    private int mTitleTextColor;
    
    public Swatch(@ColorInt int param1Int1, int param1Int2) {
      this.mRed = Color.red(param1Int1);
      this.mGreen = Color.green(param1Int1);
      this.mBlue = Color.blue(param1Int1);
      this.mRgb = param1Int1;
      this.mPopulation = param1Int2;
    }
    
    Swatch(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.mRed = param1Int1;
      this.mGreen = param1Int2;
      this.mBlue = param1Int3;
      this.mRgb = Color.rgb(param1Int1, param1Int2, param1Int3);
      this.mPopulation = param1Int4;
    }
    
    Swatch(float[] param1ArrayOffloat, int param1Int) {
      this(ColorUtils.HSLToColor(param1ArrayOffloat), param1Int);
      this.mHsl = param1ArrayOffloat;
    }
    
    private void ensureTextColorsGenerated() {
      if (!this.mGeneratedTextColors) {
        int i = ColorUtils.calculateMinimumAlpha(-1, this.mRgb, 4.5F);
        int j = ColorUtils.calculateMinimumAlpha(-1, this.mRgb, 3.0F);
        if (i != -1 && j != -1) {
          this.mBodyTextColor = ColorUtils.setAlphaComponent(-1, i);
          this.mTitleTextColor = ColorUtils.setAlphaComponent(-1, j);
          this.mGeneratedTextColors = true;
          return;
        } 
        int m = ColorUtils.calculateMinimumAlpha(-16777216, this.mRgb, 4.5F);
        int k = ColorUtils.calculateMinimumAlpha(-16777216, this.mRgb, 3.0F);
        if (m != -1 && k != -1) {
          this.mBodyTextColor = ColorUtils.setAlphaComponent(-16777216, m);
          this.mTitleTextColor = ColorUtils.setAlphaComponent(-16777216, k);
          this.mGeneratedTextColors = true;
          return;
        } 
        if (i != -1) {
          i = ColorUtils.setAlphaComponent(-1, i);
        } else {
          i = ColorUtils.setAlphaComponent(-16777216, m);
        } 
        this.mBodyTextColor = i;
        if (j != -1) {
          i = ColorUtils.setAlphaComponent(-1, j);
        } else {
          i = ColorUtils.setAlphaComponent(-16777216, k);
        } 
        this.mTitleTextColor = i;
        this.mGeneratedTextColors = true;
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.mPopulation == ((Swatch)param1Object).mPopulation && this.mRgb == ((Swatch)param1Object).mRgb);
      } 
      return false;
    }
    
    @ColorInt
    public int getBodyTextColor() {
      ensureTextColorsGenerated();
      return this.mBodyTextColor;
    }
    
    @NonNull
    public float[] getHsl() {
      if (this.mHsl == null)
        this.mHsl = new float[3]; 
      ColorUtils.RGBToHSL(this.mRed, this.mGreen, this.mBlue, this.mHsl);
      return this.mHsl;
    }
    
    public int getPopulation() {
      return this.mPopulation;
    }
    
    @ColorInt
    public int getRgb() {
      return this.mRgb;
    }
    
    @ColorInt
    public int getTitleTextColor() {
      ensureTextColorsGenerated();
      return this.mTitleTextColor;
    }
    
    public int hashCode() {
      return this.mRgb * 31 + this.mPopulation;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(getClass().getSimpleName());
      stringBuilder.append(" [RGB: #");
      stringBuilder.append(Integer.toHexString(getRgb()));
      stringBuilder.append(']');
      stringBuilder.append(" [HSL: ");
      stringBuilder.append(Arrays.toString(getHsl()));
      stringBuilder.append(']');
      stringBuilder.append(" [Population: ");
      stringBuilder.append(this.mPopulation);
      stringBuilder.append(']');
      stringBuilder.append(" [Title Text: #");
      stringBuilder.append(Integer.toHexString(getTitleTextColor()));
      stringBuilder.append(']');
      stringBuilder.append(" [Body Text: #");
      stringBuilder.append(Integer.toHexString(getBodyTextColor()));
      stringBuilder.append(']');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v7\graphics\Palette.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */