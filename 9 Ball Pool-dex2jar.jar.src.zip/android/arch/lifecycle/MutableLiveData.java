package android.arch.lifecycle;

public class MutableLiveData<T> extends LiveData<T> {
  public void postValue(T paramT) {
    super.postValue(paramT);
  }
  
  public void setValue(T paramT) {
    super.setValue(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\arch\lifecycle\MutableLiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */