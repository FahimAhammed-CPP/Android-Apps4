package android.arch.lifecycle;

import android.support.annotation.NonNull;

public interface LifecycleOwner {
  @NonNull
  Lifecycle getLifecycle();
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\arch\lifecycle\LifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */