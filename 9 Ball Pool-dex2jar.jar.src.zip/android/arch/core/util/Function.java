package android.arch.core.util;

public interface Function<I, O> {
  O apply(I paramI);
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\arch\cor\\util\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */