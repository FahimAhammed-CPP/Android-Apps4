package a;

import android.content.Context;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

public final class a {
  @NotNull
  private final Set<b> a = new CopyOnWriteArraySet<b>();
  
  private volatile Context b;
  
  public final void a(@NotNull b paramb) {
    Intrinsics.checkNotNullParameter(paramb, "listener");
    Context context = this.b;
    if (context != null)
      paramb.a(context); 
    this.a.add(paramb);
  }
  
  public final void b() {
    this.b = null;
  }
  
  public final void c(@NotNull Context paramContext) {
    Intrinsics.checkNotNullParameter(paramContext, "context");
    this.b = paramContext;
    Iterator<b> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((b)iterator.next()).a(paramContext); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */