package a;

import android.content.Context;
import org.jetbrains.annotations.NotNull;

public interface b {
  void a(@NotNull Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */