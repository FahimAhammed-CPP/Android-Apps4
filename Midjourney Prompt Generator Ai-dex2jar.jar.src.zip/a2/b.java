package a2;

import java.util.NoSuchElementException;

public abstract class b implements o {
  private final long b;
  
  private final long c;
  
  private long d;
  
  public b(long paramLong1, long paramLong2) {
    this.b = paramLong1;
    this.c = paramLong2;
    f();
  }
  
  protected final void c() {
    long l = this.d;
    if (l >= this.b && l <= this.c)
      return; 
    throw new NoSuchElementException();
  }
  
  protected final long d() {
    return this.d;
  }
  
  public boolean e() {
    return (this.d > this.c);
  }
  
  public void f() {
    this.d = this.b - 1L;
  }
  
  public boolean next() {
    this.d++;
    return e() ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */