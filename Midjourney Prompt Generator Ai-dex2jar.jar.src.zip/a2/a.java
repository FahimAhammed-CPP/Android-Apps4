package a2;

import s2.l;
import s2.p;
import w0.p1;

public abstract class a extends n {
  public final long k;
  
  public final long l;
  
  private c m;
  
  private int[] n;
  
  public a(l paraml, p paramp, p1 paramp1, int paramInt, Object paramObject, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5) {
    super(paraml, paramp, paramp1, paramInt, paramObject, paramLong1, paramLong2, paramLong5);
    this.k = paramLong3;
    this.l = paramLong4;
  }
  
  public final int i(int paramInt) {
    return ((int[])t2.a.h(this.n))[paramInt];
  }
  
  protected final c j() {
    return (c)t2.a.h(this.m);
  }
  
  public void k(c paramc) {
    this.m = paramc;
    this.n = paramc.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */