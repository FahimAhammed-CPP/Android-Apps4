package a2;

import b1.e0;
import b1.k;
import t2.r;
import y1.m0;

public final class c implements g.b {
  private final int[] a;
  
  private final m0[] b;
  
  public c(int[] paramArrayOfint, m0[] paramArrayOfm0) {
    this.a = paramArrayOfint;
    this.b = paramArrayOfm0;
  }
  
  public int[] a() {
    int[] arrayOfInt = new int[this.b.length];
    int i = 0;
    while (true) {
      m0[] arrayOfM0 = this.b;
      if (i < arrayOfM0.length) {
        arrayOfInt[i] = arrayOfM0[i].G();
        i++;
        continue;
      } 
      return arrayOfInt;
    } 
  }
  
  public void b(long paramLong) {
    m0[] arrayOfM0 = this.b;
    int j = arrayOfM0.length;
    for (int i = 0; i < j; i++)
      arrayOfM0[i].a0(paramLong); 
  }
  
  public e0 f(int paramInt1, int paramInt2) {
    paramInt1 = 0;
    while (true) {
      int[] arrayOfInt = this.a;
      if (paramInt1 < arrayOfInt.length) {
        if (paramInt2 == arrayOfInt[paramInt1])
          return (e0)this.b[paramInt1]; 
        paramInt1++;
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unmatched track of type: ");
      stringBuilder.append(paramInt2);
      r.c("BaseMediaChunkOutput", stringBuilder.toString());
      return (e0)new k();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */