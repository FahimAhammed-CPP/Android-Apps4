package a2;

import b1.f;
import s2.i;
import s2.l;
import s2.o;
import s2.o0;
import s2.p;
import w0.p1;

public final class m extends f {
  private final g j;
  
  private g.b k;
  
  private long l;
  
  private volatile boolean m;
  
  public m(l paraml, p paramp, p1 paramp1, int paramInt, Object paramObject, g paramg) {
    super(paraml, paramp, 2, paramp1, paramInt, paramObject, -9223372036854775807L, -9223372036854775807L);
    this.j = paramg;
  }
  
  public void a() {
    if (this.l == 0L)
      this.j.e(this.k, -9223372036854775807L, -9223372036854775807L); 
    try {
      p p = this.b.e(this.l);
      null = this.i;
      f f1 = new f((i)null, p.g, null.b(p));
    } finally {
      o.a((l)this.i);
    } 
  }
  
  public void b() {
    this.m = true;
  }
  
  public void g(g.b paramb) {
    this.k = paramb;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */