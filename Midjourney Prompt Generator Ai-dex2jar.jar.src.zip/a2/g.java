package a2;

import b1.d;
import b1.e0;
import b1.m;
import java.util.List;
import w0.p1;
import x0.t1;

public interface g {
  void a();
  
  boolean b(m paramm);
  
  p1[] c();
  
  d d();
  
  void e(b paramb, long paramLong1, long paramLong2);
  
  public static interface a {
    g a(int param1Int, p1 param1p1, boolean param1Boolean, List<p1> param1List, e0 param1e0, t1 param1t1);
  }
  
  public static interface b {
    e0 f(int param1Int1, int param1Int2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */