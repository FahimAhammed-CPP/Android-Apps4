package a2;

import b1.e0;
import b1.f;
import s2.i;
import s2.l;
import s2.o;
import w0.p1;

public final class p extends a {
  private final int o;
  
  private final p1 p;
  
  private long q;
  
  private boolean r;
  
  public p(l paraml, s2.p paramp, p1 paramp11, int paramInt1, Object paramObject, long paramLong1, long paramLong2, long paramLong3, int paramInt2, p1 paramp12) {
    super(paraml, paramp, paramp11, paramInt1, paramObject, paramLong1, paramLong2, -9223372036854775807L, -9223372036854775807L, paramLong3);
    this.o = paramInt2;
    this.p = paramp12;
  }
  
  public void a() {
    c c = j();
    c.b(0L);
    int j = this.o;
    int i = 0;
    null = c.f(0, j);
    null.e(this.p);
    try {
      s2.p p2 = this.b.e(this.q);
      long l2 = this.i.b(p2);
      long l1 = l2;
      if (l2 != -1L)
        l1 = l2 + this.q; 
      f f = new f((i)this.i, this.q, l1);
      while (i != -1) {
        this.q += i;
        i = null.d((i)f, 2147483647, true);
      } 
      i = (int)this.q;
      null.a(this.g, 1, i, 0, null);
      o.a((l)this.i);
      return;
    } finally {
      o.a((l)this.i);
    } 
  }
  
  public void b() {}
  
  public boolean h() {
    return this.r;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */