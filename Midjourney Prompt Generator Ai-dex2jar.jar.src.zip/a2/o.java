package a2;

import java.util.NoSuchElementException;

public interface o {
  public static final o a = new a();
  
  long a();
  
  long b();
  
  boolean next();
  
  class a implements o {
    public long a() {
      throw new NoSuchElementException();
    }
    
    public long b() {
      throw new NoSuchElementException();
    }
    
    public boolean next() {
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */