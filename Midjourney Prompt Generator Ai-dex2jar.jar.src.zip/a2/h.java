package a2;

public final class h {
  public f a;
  
  public boolean b;
  
  public void a() {
    this.a = null;
    this.b = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */