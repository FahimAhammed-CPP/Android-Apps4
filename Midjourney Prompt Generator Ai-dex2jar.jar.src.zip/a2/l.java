package a2;

import java.util.Arrays;
import s2.o;
import s2.p;
import t2.q0;
import w0.p1;

public abstract class l extends f {
  private byte[] j;
  
  private volatile boolean k;
  
  public l(s2.l paraml, p paramp, int paramInt1, p1 paramp1, int paramInt2, Object paramObject, byte[] paramArrayOfbyte) {
    super(paraml, paramp, paramInt1, paramp1, paramInt2, paramObject, -9223372036854775807L, -9223372036854775807L);
    if (paramArrayOfbyte == null)
      paramArrayOfbyte = q0.f; 
    this.j = paramArrayOfbyte;
  }
  
  private void i(int paramInt) {
    byte[] arrayOfByte = this.j;
    if (arrayOfByte.length < paramInt + 16384)
      this.j = Arrays.copyOf(arrayOfByte, arrayOfByte.length + 16384); 
  }
  
  public final void a() {
    try {
      this.i.b(this.b);
      int i = 0;
      int j = 0;
      while (i != -1 && !this.k) {
        i(j);
        int k = this.i.read(this.j, j, 16384);
        i = k;
        if (k != -1) {
          j += k;
          i = k;
        } 
      } 
      if (!this.k)
        g(this.j, j); 
      return;
    } finally {
      o.a((s2.l)this.i);
    } 
  }
  
  public final void b() {
    this.k = true;
  }
  
  protected abstract void g(byte[] paramArrayOfbyte, int paramInt);
  
  public byte[] h() {
    return this.j;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */