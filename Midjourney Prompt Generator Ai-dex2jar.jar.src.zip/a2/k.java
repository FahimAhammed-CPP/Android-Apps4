package a2;

import b1.f;
import s2.i;
import s2.l;
import s2.o;
import s2.o0;
import s2.p;
import w0.p1;

public class k extends a {
  private final int o;
  
  private final long p;
  
  private final g q;
  
  private long r;
  
  private volatile boolean s;
  
  private boolean t;
  
  public k(l paraml, p paramp, p1 paramp1, int paramInt1, Object paramObject, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, g paramg) {
    super(paraml, paramp, paramp1, paramInt1, paramObject, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5);
    this.o = paramInt2;
    this.p = paramLong6;
    this.q = paramg;
  }
  
  public final void a() {
    if (this.r == 0L) {
      c c = j();
      c.b(this.p);
      g g1 = this.q;
      g.b b = l(c);
      long l1 = this.k;
      if (l1 == -9223372036854775807L) {
        l1 = -9223372036854775807L;
      } else {
        l1 -= this.p;
      } 
      long l2 = this.l;
      if (l2 == -9223372036854775807L) {
        l2 = -9223372036854775807L;
      } else {
        l2 -= this.p;
      } 
      g1.e(b, l1, l2);
    } 
    try {
      p p = this.b.e(this.r);
      null = this.i;
      f f = new f((i)null, p.g, null.b(p));
    } finally {
      o.a((l)this.i);
    } 
  }
  
  public final void b() {
    this.s = true;
  }
  
  public long g() {
    return this.j + this.o;
  }
  
  public boolean h() {
    return this.t;
  }
  
  protected g.b l(c paramc) {
    return paramc;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */