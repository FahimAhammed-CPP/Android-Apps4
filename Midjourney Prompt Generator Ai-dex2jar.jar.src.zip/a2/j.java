package a2;

import java.util.List;
import s2.g0;
import w0.s3;

public interface j {
  void a();
  
  void b();
  
  long c(long paramLong, s3 params3);
  
  boolean e(long paramLong, f paramf, List<? extends n> paramList);
  
  void g(f paramf);
  
  boolean h(f paramf, boolean paramBoolean, g0.c paramc, g0 paramg0);
  
  int j(long paramLong, List<? extends n> paramList);
  
  void k(long paramLong1, long paramLong2, List<? extends n> paramList, h paramh);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */