package a2;

import a1.w;
import a1.y;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import s2.g0;
import s2.h0;
import t2.q0;
import t2.r;
import w0.p1;
import w0.q1;
import w0.s3;
import y1.b0;
import y1.m0;
import y1.n;
import y1.n0;
import y1.o0;
import y1.q;
import z0.h;

public class i<T extends j> implements n0, o0, h0.b<f>, h0.f {
  public final int a;
  
  private final int[] b;
  
  private final p1[] c;
  
  private final boolean[] d;
  
  private final T e;
  
  private final o0.a<i<T>> f;
  
  private final b0.a g;
  
  private final g0 h;
  
  private final h0 i;
  
  private final h j;
  
  private final ArrayList<a> k;
  
  private final List<a> l;
  
  private final m0 m;
  
  private final m0[] n;
  
  private final c o;
  
  private f p;
  
  private p1 q;
  
  private b<T> r;
  
  private long s;
  
  private long t;
  
  private int u;
  
  private a v;
  
  boolean w;
  
  public i(int paramInt, int[] paramArrayOfint, p1[] paramArrayOfp1, T paramT, o0.a<i<T>> parama, s2.b paramb, long paramLong, y paramy, w.a parama1, g0 paramg0, b0.a parama2) {
    this.a = paramInt;
    int k = 0;
    int[] arrayOfInt2 = paramArrayOfint;
    if (paramArrayOfint == null)
      arrayOfInt2 = new int[0]; 
    this.b = arrayOfInt2;
    p1[] arrayOfP1 = paramArrayOfp1;
    if (paramArrayOfp1 == null)
      arrayOfP1 = new p1[0]; 
    this.c = arrayOfP1;
    this.e = paramT;
    this.f = parama;
    this.g = parama2;
    this.h = paramg0;
    this.i = new h0("ChunkSampleStream");
    this.j = new h();
    ArrayList<a> arrayList = new ArrayList();
    this.k = arrayList;
    this.l = Collections.unmodifiableList(arrayList);
    int m = arrayOfInt2.length;
    this.n = new m0[m];
    this.d = new boolean[m];
    int n = m + 1;
    int[] arrayOfInt1 = new int[n];
    m0[] arrayOfM0 = new m0[n];
    m0 m01 = m0.k(paramb, paramy, parama1);
    this.m = m01;
    arrayOfInt1[0] = paramInt;
    arrayOfM0[0] = m01;
    for (paramInt = k; paramInt < m; paramInt = k) {
      m01 = m0.l(paramb);
      this.n[paramInt] = m01;
      k = paramInt + 1;
      arrayOfM0[k] = m01;
      arrayOfInt1[k] = this.b[paramInt];
    } 
    this.o = new c(arrayOfInt1, arrayOfM0);
    this.s = paramLong;
    this.t = paramLong;
  }
  
  private void A(int paramInt) {
    paramInt = Math.min(N(paramInt, 0), this.u);
    if (paramInt > 0) {
      q0.M0(this.k, 0, paramInt);
      this.u -= paramInt;
    } 
  }
  
  private void B(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Ls2/h0;
    //   4: invokevirtual j : ()Z
    //   7: iconst_1
    //   8: ixor
    //   9: invokestatic f : (Z)V
    //   12: aload_0
    //   13: getfield k : Ljava/util/ArrayList;
    //   16: invokevirtual size : ()I
    //   19: istore_2
    //   20: iload_1
    //   21: iload_2
    //   22: if_icmpge -> 43
    //   25: aload_0
    //   26: iload_1
    //   27: invokespecial F : (I)Z
    //   30: ifne -> 36
    //   33: goto -> 45
    //   36: iload_1
    //   37: iconst_1
    //   38: iadd
    //   39: istore_1
    //   40: goto -> 20
    //   43: iconst_m1
    //   44: istore_1
    //   45: iload_1
    //   46: iconst_m1
    //   47: if_icmpne -> 51
    //   50: return
    //   51: aload_0
    //   52: invokespecial E : ()La2/a;
    //   55: getfield h : J
    //   58: lstore_3
    //   59: aload_0
    //   60: iload_1
    //   61: invokespecial C : (I)La2/a;
    //   64: astore #5
    //   66: aload_0
    //   67: getfield k : Ljava/util/ArrayList;
    //   70: invokevirtual isEmpty : ()Z
    //   73: ifeq -> 84
    //   76: aload_0
    //   77: aload_0
    //   78: getfield t : J
    //   81: putfield s : J
    //   84: aload_0
    //   85: iconst_0
    //   86: putfield w : Z
    //   89: aload_0
    //   90: getfield g : Ly1/b0$a;
    //   93: aload_0
    //   94: getfield a : I
    //   97: aload #5
    //   99: getfield g : J
    //   102: lload_3
    //   103: invokevirtual D : (IJJ)V
    //   106: return
  }
  
  private a C(int paramInt) {
    a a1 = this.k.get(paramInt);
    ArrayList<a> arrayList = this.k;
    q0.M0(arrayList, paramInt, arrayList.size());
    this.u = Math.max(this.u, this.k.size());
    m0 m01 = this.m;
    paramInt = 0;
    m01.u(a1.i(0));
    while (true) {
      m0[] arrayOfM0 = this.n;
      if (paramInt < arrayOfM0.length) {
        m0 m02 = arrayOfM0[paramInt];
        m02.u(a1.i(++paramInt));
        continue;
      } 
      return a1;
    } 
  }
  
  private a E() {
    ArrayList<a> arrayList = this.k;
    return arrayList.get(arrayList.size() - 1);
  }
  
  private boolean F(int paramInt) {
    a a1 = this.k.get(paramInt);
    if (this.m.C() > a1.i(0))
      return true; 
    paramInt = 0;
    while (true) {
      m0[] arrayOfM0 = this.n;
      if (paramInt < arrayOfM0.length) {
        int m = arrayOfM0[paramInt].C();
        int k = paramInt + 1;
        paramInt = k;
        if (m > a1.i(k))
          return true; 
        continue;
      } 
      return false;
    } 
  }
  
  private boolean G(f paramf) {
    return paramf instanceof a;
  }
  
  private void I() {
    int k = N(this.m.C(), this.u - 1);
    while (true) {
      int m = this.u;
      if (m <= k) {
        this.u = m + 1;
        J(m);
        continue;
      } 
      break;
    } 
  }
  
  private void J(int paramInt) {
    a a1 = this.k.get(paramInt);
    p1 p11 = a1.d;
    if (!p11.equals(this.q))
      this.g.i(this.a, p11, a1.e, a1.f, a1.g); 
    this.q = p11;
  }
  
  private int N(int paramInt1, int paramInt2) {
    while (true) {
      int k = paramInt2 + 1;
      if (k < this.k.size()) {
        paramInt2 = k;
        if (((a)this.k.get(k)).i(0) > paramInt1)
          return k - 1; 
        continue;
      } 
      return this.k.size() - 1;
    } 
  }
  
  private void Q() {
    this.m.V();
    m0[] arrayOfM0 = this.n;
    int m = arrayOfM0.length;
    for (int k = 0; k < m; k++)
      arrayOfM0[k].V(); 
  }
  
  public T D() {
    return this.e;
  }
  
  boolean H() {
    return (this.s != -9223372036854775807L);
  }
  
  public void K(f paramf, long paramLong1, long paramLong2, boolean paramBoolean) {
    this.p = null;
    this.v = null;
    n n = new n(paramf.a, paramf.b, paramf.f(), paramf.e(), paramLong1, paramLong2, paramf.c());
    this.h.a(paramf.a);
    this.g.r(n, paramf.c, this.a, paramf.d, paramf.e, paramf.f, paramf.g, paramf.h);
    if (!paramBoolean) {
      if (H()) {
        Q();
      } else if (G(paramf)) {
        C(this.k.size() - 1);
        if (this.k.isEmpty())
          this.s = this.t; 
      } 
      this.f.k(this);
    } 
  }
  
  public void L(f paramf, long paramLong1, long paramLong2) {
    this.p = null;
    this.e.g(paramf);
    n n = new n(paramf.a, paramf.b, paramf.f(), paramf.e(), paramLong1, paramLong2, paramf.c());
    this.h.a(paramf.a);
    this.g.u(n, paramf.c, this.a, paramf.d, paramf.e, paramf.f, paramf.g, paramf.h);
    this.f.k(this);
  }
  
  public h0.c M(f paramf, long paramLong1, long paramLong2, IOException paramIOException, int paramInt) {
    int m;
    long l = paramf.c();
    boolean bool = G(paramf);
    int k = this.k.size() - 1;
    if (l == 0L || !bool || !F(k)) {
      m = 1;
    } else {
      m = 0;
    } 
    n n = new n(paramf.a, paramf.b, paramf.f(), paramf.e(), paramLong1, paramLong2, l);
    g0.c c1 = new g0.c(n, new q(paramf.c, this.a, paramf.d, paramf.e, paramf.f, q0.Y0(paramf.g), q0.Y0(paramf.h)), paramIOException, paramInt);
    if (this.e.h(paramf, m, c1, this.h)) {
      h0.c c2;
      if (m) {
        h0.c c4 = h0.f;
        c2 = c4;
        if (bool) {
          if (C(k) == paramf) {
            m = 1;
          } else {
            m = 0;
          } 
          t2.a.f(m);
          c2 = c4;
          if (this.k.isEmpty()) {
            this.s = this.t;
            c2 = c4;
          } 
        } 
      } else {
        r.i("ChunkSampleStream", "Ignoring attempt to cancel non-cancelable load.");
        c2 = null;
      } 
      h0.c c3 = c2;
      if (c2 == null) {
        paramLong1 = this.h.b(c1);
        if (paramLong1 != -9223372036854775807L) {
          c3 = h0.h(false, paramLong1);
        } else {
          c3 = h0.g;
        } 
      } 
      m = c3.c() ^ true;
      this.g.w(n, paramf.c, this.a, paramf.d, paramf.e, paramf.f, paramf.g, paramf.h, paramIOException, m);
      if (m != 0) {
        this.p = null;
        this.h.a(paramf.a);
        this.f.k(this);
      } 
      return c3;
    } 
    Object object = null;
  }
  
  public void O() {
    P(null);
  }
  
  public void P(b<T> paramb) {
    this.r = paramb;
    this.m.R();
    m0[] arrayOfM0 = this.n;
    int m = arrayOfM0.length;
    for (int k = 0; k < m; k++)
      arrayOfM0[k].R(); 
    this.i.m(this);
  }
  
  public void R(long paramLong) {
    boolean bool;
    a a1;
    this.t = paramLong;
    if (H()) {
      this.s = paramLong;
      return;
    } 
    a a2 = null;
    int n = 0;
    int m = 0;
    int k = 0;
    while (true) {
      a1 = a2;
      if (k < this.k.size()) {
        a1 = this.k.get(k);
        int i1 = a1.g cmp paramLong;
        if (i1 == 0 && a1.k == -9223372036854775807L)
          break; 
        if (i1 > 0) {
          a1 = a2;
          break;
        } 
        k++;
        continue;
      } 
      break;
    } 
    if (a1 != null) {
      bool = this.m.Y(a1.i(0));
    } else {
      m0 m01 = this.m;
      if (paramLong < a()) {
        bool = true;
      } else {
        bool = false;
      } 
      bool = m01.Z(paramLong, bool);
    } 
    if (bool) {
      this.u = N(this.m.C(), 0);
      m0[] arrayOfM0 = this.n;
      n = arrayOfM0.length;
      for (k = m; k < n; k++)
        arrayOfM0[k].Z(paramLong, true); 
    } else {
      this.s = paramLong;
      this.w = false;
      this.k.clear();
      this.u = 0;
      if (this.i.j()) {
        this.m.r();
        m0[] arrayOfM0 = this.n;
        m = arrayOfM0.length;
        for (k = n; k < m; k++)
          arrayOfM0[k].r(); 
        this.i.f();
        return;
      } 
      this.i.g();
      Q();
    } 
  }
  
  public a S(long paramLong, int paramInt) {
    int k;
    for (k = 0; k < this.n.length; k++) {
      if (this.b[k] == paramInt) {
        t2.a.f(this.d[k] ^ true);
        this.d[k] = true;
        this.n[k].Z(paramLong, true);
        return new a(this, this, this.n[k], k);
      } 
    } 
    throw new IllegalStateException();
  }
  
  public long a() {
    return H() ? this.s : (this.w ? Long.MIN_VALUE : (E()).h);
  }
  
  public void b() {
    this.i.b();
    this.m.N();
    if (!this.i.j())
      this.e.b(); 
  }
  
  public long c(long paramLong, s3 params3) {
    return this.e.c(paramLong, params3);
  }
  
  public boolean d(long paramLong) {
    boolean bool = this.w;
    int k = 0;
    if (!bool && !this.i.j()) {
      long l;
      List<a> list;
      if (this.i.i())
        return false; 
      bool = H();
      if (bool) {
        list = Collections.emptyList();
        l = this.s;
      } else {
        list = this.l;
        l = (E()).h;
      } 
      this.e.k(paramLong, l, (List)list, this.j);
      h h1 = this.j;
      boolean bool1 = h1.b;
      f f1 = h1.a;
      h1.a();
      if (bool1) {
        this.s = -9223372036854775807L;
        this.w = true;
        return true;
      } 
      if (f1 == null)
        return false; 
      this.p = f1;
      if (G(f1)) {
        a a1 = (a)f1;
        if (bool) {
          paramLong = a1.g;
          l = this.s;
          if (paramLong != l) {
            this.m.b0(l);
            m0[] arrayOfM0 = this.n;
            int m = arrayOfM0.length;
            while (k < m) {
              arrayOfM0[k].b0(this.s);
              k++;
            } 
          } 
          this.s = -9223372036854775807L;
        } 
        a1.k(this.o);
        this.k.add(a1);
      } else if (f1 instanceof m) {
        ((m)f1).g(this.o);
      } 
      paramLong = this.i.n(f1, this, this.h.d(f1.c));
      this.g.A(new n(f1.a, f1.b, paramLong), f1.c, this.a, f1.d, f1.e, f1.f, f1.g, f1.h);
      return true;
    } 
    return false;
  }
  
  public boolean e() {
    return this.i.j();
  }
  
  public int f(q1 paramq1, h paramh, int paramInt) {
    if (H())
      return -3; 
    a a1 = this.v;
    if (a1 != null && a1.i(0) <= this.m.C())
      return -3; 
    I();
    return this.m.S(paramq1, paramh, paramInt, this.w);
  }
  
  public long g() {
    if (this.w)
      return Long.MIN_VALUE; 
    if (H())
      return this.s; 
    long l2 = this.t;
    a a1 = E();
    if (!a1.h())
      if (this.k.size() > 1) {
        ArrayList<a> arrayList = this.k;
        a a2 = arrayList.get(arrayList.size() - 2);
      } else {
        a1 = null;
      }  
    long l1 = l2;
    if (a1 != null)
      l1 = Math.max(l2, a1.h); 
    return Math.max(l1, this.m.z());
  }
  
  public void h(long paramLong) {
    if (!this.i.i()) {
      if (H())
        return; 
      if (this.i.j()) {
        f f1 = (f)t2.a.e(this.p);
        if (G(f1) && F(this.k.size() - 1))
          return; 
        if (this.e.e(paramLong, f1, (List)this.l)) {
          this.i.f();
          if (G(f1))
            this.v = (a)f1; 
        } 
        return;
      } 
      int k = this.e.j(paramLong, (List)this.l);
      if (k < this.k.size())
        B(k); 
    } 
  }
  
  public boolean isReady() {
    return (!H() && this.m.K(this.w));
  }
  
  public void j() {
    this.m.T();
    m0[] arrayOfM0 = this.n;
    int m = arrayOfM0.length;
    for (int k = 0; k < m; k++)
      arrayOfM0[k].T(); 
    this.e.a();
    b<T> b1 = this.r;
    if (b1 != null)
      b1.f(this); 
  }
  
  public int o(long paramLong) {
    if (H())
      return 0; 
    int m = this.m.E(paramLong, this.w);
    a a1 = this.v;
    int k = m;
    if (a1 != null)
      k = Math.min(m, a1.i(0) - this.m.C()); 
    this.m.e0(k);
    I();
    return k;
  }
  
  public void t(long paramLong, boolean paramBoolean) {
    if (H())
      return; 
    int k = this.m.x();
    this.m.q(paramLong, paramBoolean, true);
    int m = this.m.x();
    if (m > k) {
      paramLong = this.m.y();
      k = 0;
      while (true) {
        m0[] arrayOfM0 = this.n;
        if (k < arrayOfM0.length) {
          arrayOfM0[k].q(paramLong, paramBoolean, this.d[k]);
          k++;
          continue;
        } 
        break;
      } 
    } 
    A(m);
  }
  
  public final class a implements n0 {
    public final i<T> a;
    
    private final m0 b;
    
    private final int c;
    
    private boolean d;
    
    public a(i this$0, i<T> param1i, m0 param1m0, int param1Int) {
      this.a = param1i;
      this.b = param1m0;
      this.c = param1Int;
    }
    
    private void a() {
      if (!this.d) {
        i.z(this.e).i(i.w(this.e)[this.c], i.x(this.e)[this.c], 0, null, i.y(this.e));
        this.d = true;
      } 
    }
    
    public void b() {}
    
    public void c() {
      t2.a.f(i.v(this.e)[this.c]);
      i.v(this.e)[this.c] = false;
    }
    
    public int f(q1 param1q1, h param1h, int param1Int) {
      if (this.e.H())
        return -3; 
      if (i.u(this.e) != null && i.u(this.e).i(this.c + 1) <= this.b.C())
        return -3; 
      a();
      return this.b.S(param1q1, param1h, param1Int, this.e.w);
    }
    
    public boolean isReady() {
      return (!this.e.H() && this.b.K(this.e.w));
    }
    
    public int o(long param1Long) {
      if (this.e.H())
        return 0; 
      int k = this.b.E(param1Long, this.e.w);
      int j = k;
      if (i.u(this.e) != null)
        j = Math.min(k, i.u(this.e).i(this.c + 1) - this.b.C()); 
      this.b.e0(j);
      if (j > 0)
        a(); 
      return j;
    }
  }
  
  public static interface b<T extends j> {
    void f(i<T> param1i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */