package a2;

import android.util.SparseArray;
import b1.a0;
import b1.b0;
import b1.d;
import b1.d0;
import b1.e0;
import b1.k;
import b1.l;
import b1.m;
import b1.n;
import j1.g;
import java.util.List;
import s2.i;
import t2.c0;
import t2.q0;
import t2.v;
import w0.p1;
import x0.t1;

public final class e implements n, g {
  public static final g.a j = new d();
  
  private static final a0 k = new a0();
  
  private final l a;
  
  private final int b;
  
  private final p1 c;
  
  private final SparseArray<a> d;
  
  private boolean e;
  
  private g.b f;
  
  private long g;
  
  private b0 h;
  
  private p1[] i;
  
  public e(l paraml, int paramInt, p1 paramp1) {
    this.a = paraml;
    this.b = paramInt;
    this.c = paramp1;
    this.d = new SparseArray();
  }
  
  public void a() {
    this.a.a();
  }
  
  public boolean b(m paramm) {
    int i = this.a.f(paramm, k);
    boolean bool2 = false;
    if (i != 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    t2.a.f(bool1);
    boolean bool1 = bool2;
    if (i == 0)
      bool1 = true; 
    return bool1;
  }
  
  public p1[] c() {
    return this.i;
  }
  
  public d d() {
    b0 b01 = this.h;
    return (b01 instanceof d) ? (d)b01 : null;
  }
  
  public void e(g.b paramb, long paramLong1, long paramLong2) {
    this.f = paramb;
    this.g = paramLong2;
    if (!this.e) {
      this.a.d(this);
      if (paramLong1 != -9223372036854775807L)
        this.a.c(0L, paramLong1); 
      this.e = true;
      return;
    } 
    l l2 = this.a;
    long l1 = paramLong1;
    if (paramLong1 == -9223372036854775807L)
      l1 = 0L; 
    l2.c(0L, l1);
    int i;
    for (i = 0; i < this.d.size(); i++)
      ((a)this.d.valueAt(i)).g(paramb, paramLong2); 
  }
  
  public e0 f(int paramInt1, int paramInt2) {
    a a2 = (a)this.d.get(paramInt1);
    a a1 = a2;
    if (a2 == null) {
      boolean bool;
      if (this.i == null) {
        bool = true;
      } else {
        bool = false;
      } 
      t2.a.f(bool);
      if (paramInt2 == this.b) {
        p1 p11 = this.c;
      } else {
        a1 = null;
      } 
      a1 = new a(paramInt1, paramInt2, (p1)a1);
      a1.g(this.f, this.g);
      this.d.put(paramInt1, a1);
    } 
    return a1;
  }
  
  public void o() {
    p1[] arrayOfP1 = new p1[this.d.size()];
    for (int i = 0; i < this.d.size(); i++)
      arrayOfP1[i] = (p1)t2.a.h(((a)this.d.valueAt(i)).e); 
    this.i = arrayOfP1;
  }
  
  public void u(b0 paramb0) {
    this.h = paramb0;
  }
  
  private static final class a implements e0 {
    private final int a;
    
    private final int b;
    
    private final p1 c;
    
    private final k d;
    
    public p1 e;
    
    private e0 f;
    
    private long g;
    
    public a(int param1Int1, int param1Int2, p1 param1p1) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1p1;
      this.d = new k();
    }
    
    public void a(long param1Long, int param1Int1, int param1Int2, int param1Int3, e0.a param1a) {
      long l = this.g;
      if (l != -9223372036854775807L && param1Long >= l)
        this.f = (e0)this.d; 
      ((e0)q0.j(this.f)).a(param1Long, param1Int1, param1Int2, param1Int3, param1a);
    }
    
    public int b(i param1i, int param1Int1, boolean param1Boolean, int param1Int2) {
      return ((e0)q0.j(this.f)).d(param1i, param1Int1, param1Boolean);
    }
    
    public void e(p1 param1p1) {
      p1 p12 = this.c;
      p1 p11 = param1p1;
      if (p12 != null)
        p11 = param1p1.j(p12); 
      this.e = p11;
      ((e0)q0.j(this.f)).e(this.e);
    }
    
    public void f(c0 param1c0, int param1Int1, int param1Int2) {
      ((e0)q0.j(this.f)).c(param1c0, param1Int1);
    }
    
    public void g(g.b param1b, long param1Long) {
      if (param1b == null) {
        this.f = (e0)this.d;
        return;
      } 
      this.g = param1Long;
      e0 e01 = param1b.f(this.a, this.b);
      this.f = e01;
      p1 p11 = this.e;
      if (p11 != null)
        e01.e(p11); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */