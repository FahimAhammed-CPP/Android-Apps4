package a2;

import s2.l;
import s2.p;
import t2.a;
import w0.p1;

public abstract class n extends f {
  public final long j;
  
  public n(l paraml, p paramp, p1 paramp1, int paramInt, Object paramObject, long paramLong1, long paramLong2, long paramLong3) {
    super(paraml, paramp, 1, paramp1, paramInt, paramObject, paramLong1, paramLong2);
    a.e(paramp1);
    this.j = paramLong3;
  }
  
  public long g() {
    long l2 = this.j;
    long l1 = -1L;
    if (l2 != -1L)
      l1 = 1L + l2; 
    return l1;
  }
  
  public abstract boolean h();
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */