package a2;

import android.net.Uri;
import java.util.List;
import java.util.Map;
import s2.h0;
import s2.l;
import s2.o0;
import s2.p;
import t2.a;
import w0.p1;
import y1.n;

public abstract class f implements h0.e {
  public final long a;
  
  public final p b;
  
  public final int c;
  
  public final p1 d;
  
  public final int e;
  
  public final Object f;
  
  public final long g;
  
  public final long h;
  
  protected final o0 i;
  
  public f(l paraml, p paramp, int paramInt1, p1 paramp1, int paramInt2, Object paramObject, long paramLong1, long paramLong2) {
    this.i = new o0(paraml);
    this.b = (p)a.e(paramp);
    this.c = paramInt1;
    this.d = paramp1;
    this.e = paramInt2;
    this.f = paramObject;
    this.g = paramLong1;
    this.h = paramLong2;
    this.a = n.a();
  }
  
  public final long c() {
    return this.i.o();
  }
  
  public final long d() {
    return this.h - this.g;
  }
  
  public final Map<String, List<String>> e() {
    return this.i.q();
  }
  
  public final Uri f() {
    return this.i.p();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */