package a3;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import k3.a;
import k3.c;

public class a extends a {
  @NonNull
  public static final Parcelable.Creator<a> CREATOR = new j();
  
  final int a;
  
  private boolean b;
  
  private long c;
  
  private final boolean d;
  
  a(int paramInt, boolean paramBoolean1, long paramLong, boolean paramBoolean2) {
    this.a = paramInt;
    this.b = paramBoolean1;
    this.c = paramLong;
    this.d = paramBoolean2;
  }
  
  public long U() {
    return this.c;
  }
  
  public boolean V() {
    return this.d;
  }
  
  public boolean W() {
    return this.b;
  }
  
  public final void writeToParcel(@NonNull Parcel paramParcel, int paramInt) {
    paramInt = c.a(paramParcel);
    c.j(paramParcel, 1, this.a);
    c.c(paramParcel, 2, W());
    c.l(paramParcel, 3, U());
    c.c(paramParcel, 4, V());
    c.b(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */