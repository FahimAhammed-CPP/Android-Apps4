package a3;

import android.os.Parcel;
import android.os.Parcelable;
import k3.b;

public final class j implements Parcelable.Creator {}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */