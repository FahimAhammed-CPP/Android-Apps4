package a3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.auth.k;
import java.util.List;
import java.util.Map;
import k3.c;
import m.a;
import o3.a;

public final class d extends k {
  public static final Parcelable.Creator<d> CREATOR = new e();
  
  private static final a g;
  
  final int a = 1;
  
  private List b;
  
  private List c;
  
  private List d;
  
  private List e;
  
  private List f;
  
  static {
    a a1 = new a();
    g = a1;
    a1.put("registered", a.a.Z("registered", 2));
    a1.put("in_progress", a.a.Z("in_progress", 3));
    a1.put("success", a.a.Z("success", 4));
    a1.put("failed", a.a.Z("failed", 5));
    a1.put("escrowed", a.a.Z("escrowed", 6));
  }
  
  public d() {}
  
  d(int paramInt, List paramList1, List paramList2, List paramList3, List paramList4, List paramList5) {
    this.b = paramList1;
    this.c = paramList2;
    this.d = paramList3;
    this.e = paramList4;
    this.f = paramList5;
  }
  
  public final Map a() {
    return (Map)g;
  }
  
  protected final Object b(a.a parama) {
    StringBuilder stringBuilder;
    int i;
    switch (parama.a0()) {
      default:
        i = parama.a0();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unknown SafeParcelable id=");
        stringBuilder.append(i);
        throw new IllegalStateException(stringBuilder.toString());
      case 6:
        return this.f;
      case 5:
        return this.e;
      case 4:
        return this.d;
      case 3:
        return this.c;
      case 2:
        return this.b;
      case 1:
        break;
    } 
    return Integer.valueOf(this.a);
  }
  
  protected final boolean d(a.a parama) {
    return true;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = c.a(paramParcel);
    c.j(paramParcel, 1, this.a);
    c.q(paramParcel, 2, this.b, false);
    c.q(paramParcel, 3, this.c, false);
    c.q(paramParcel, 4, this.d, false);
    c.q(paramParcel, 5, this.e, false);
    c.q(paramParcel, 6, this.f, false);
    c.b(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */