package a3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.auth.k;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import k3.c;
import o3.a;

public final class b extends k {
  public static final Parcelable.Creator<b> CREATOR = new c();
  
  private static final HashMap f;
  
  final Set a = new HashSet(1);
  
  final int b = 1;
  
  private ArrayList c;
  
  private int d;
  
  private d e;
  
  static {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    f = hashMap;
    hashMap.put("authenticatorData", a.a.W("authenticatorData", 2, f.class));
    hashMap.put("progress", a.a.V("progress", 4, d.class));
  }
  
  public b() {}
  
  b(Set paramSet, int paramInt1, ArrayList paramArrayList, int paramInt2, d paramd) {
    this.c = paramArrayList;
    this.d = paramInt2;
    this.e = paramd;
  }
  
  protected final Object b(a.a parama) {
    int i = parama.a0();
    if (i != 1) {
      if (i != 2) {
        if (i == 4)
          return this.e; 
        i = parama.a0();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unknown SafeParcelable id=");
        stringBuilder.append(i);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      return this.c;
    } 
    return Integer.valueOf(this.b);
  }
  
  protected final boolean d(a.a parama) {
    return this.a.contains(Integer.valueOf(parama.a0()));
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = c.a(paramParcel);
    Set set = this.a;
    if (set.contains(Integer.valueOf(1)))
      c.j(paramParcel, 1, this.b); 
    if (set.contains(Integer.valueOf(2)))
      c.s(paramParcel, 2, this.c, true); 
    if (set.contains(Integer.valueOf(3)))
      c.j(paramParcel, 3, this.d); 
    if (set.contains(Integer.valueOf(4)))
      c.o(paramParcel, 4, (Parcelable)this.e, paramInt, true); 
    c.b(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */