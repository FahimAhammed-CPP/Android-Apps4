package a3;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.auth.k;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import k3.c;
import m.b;
import o3.a;

public final class h extends k {
  public static final Parcelable.Creator<h> CREATOR = new i();
  
  private static final HashMap h;
  
  final Set a = (Set)new b(3);
  
  final int b = 1;
  
  private String c;
  
  private int d;
  
  private byte[] e;
  
  private PendingIntent f;
  
  private a g;
  
  static {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    h = hashMap;
    hashMap.put("accountType", a.a.Y("accountType", 2));
    hashMap.put("status", a.a.X("status", 3));
    hashMap.put("transferBytes", a.a.U("transferBytes", 4));
  }
  
  public h() {}
  
  h(Set paramSet, int paramInt1, String paramString, int paramInt2, byte[] paramArrayOfbyte, PendingIntent paramPendingIntent, a parama) {
    this.c = paramString;
    this.d = paramInt2;
    this.e = paramArrayOfbyte;
    this.f = paramPendingIntent;
    this.g = parama;
  }
  
  protected final Object b(a.a parama) {
    int i = parama.a0();
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            return this.e; 
          i = parama.a0();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown SafeParcelable id=");
          stringBuilder.append(i);
          throw new IllegalStateException(stringBuilder.toString());
        } 
        return Integer.valueOf(this.d);
      } 
      return this.c;
    } 
    return Integer.valueOf(this.b);
  }
  
  protected final boolean d(a.a parama) {
    return this.a.contains(Integer.valueOf(parama.a0()));
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = c.a(paramParcel);
    Set set = this.a;
    if (set.contains(Integer.valueOf(1)))
      c.j(paramParcel, 1, this.b); 
    if (set.contains(Integer.valueOf(2)))
      c.p(paramParcel, 2, this.c, true); 
    if (set.contains(Integer.valueOf(3)))
      c.j(paramParcel, 3, this.d); 
    if (set.contains(Integer.valueOf(4)))
      c.f(paramParcel, 4, this.e, true); 
    if (set.contains(Integer.valueOf(5)))
      c.o(paramParcel, 5, (Parcelable)this.f, paramInt, true); 
    if (set.contains(Integer.valueOf(6)))
      c.o(paramParcel, 6, (Parcelable)this.g, paramInt, true); 
    c.b(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */