package a3;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.auth.k;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import k3.c;
import o3.a;

public final class f extends k {
  public static final Parcelable.Creator<f> CREATOR = new g();
  
  private static final HashMap g;
  
  final Set a = new HashSet(3);
  
  final int b = 1;
  
  private h c;
  
  private String d;
  
  private String e;
  
  private String f;
  
  static {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    g = hashMap;
    hashMap.put("authenticatorInfo", a.a.V("authenticatorInfo", 2, h.class));
    hashMap.put("signature", a.a.Y("signature", 3));
    hashMap.put("package", a.a.Y("package", 4));
  }
  
  public f() {}
  
  f(Set paramSet, int paramInt, h paramh, String paramString1, String paramString2, String paramString3) {
    this.c = paramh;
    this.d = paramString1;
    this.e = paramString2;
    this.f = paramString3;
  }
  
  protected final Object b(a.a parama) {
    int i = parama.a0();
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            return this.e; 
          i = parama.a0();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown SafeParcelable id=");
          stringBuilder.append(i);
          throw new IllegalStateException(stringBuilder.toString());
        } 
        return this.d;
      } 
      return this.c;
    } 
    return Integer.valueOf(this.b);
  }
  
  protected final boolean d(a.a parama) {
    return this.a.contains(Integer.valueOf(parama.a0()));
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = c.a(paramParcel);
    Set set = this.a;
    if (set.contains(Integer.valueOf(1)))
      c.j(paramParcel, 1, this.b); 
    if (set.contains(Integer.valueOf(2)))
      c.o(paramParcel, 2, (Parcelable)this.c, paramInt, true); 
    if (set.contains(Integer.valueOf(3)))
      c.p(paramParcel, 3, this.d, true); 
    if (set.contains(Integer.valueOf(4)))
      c.p(paramParcel, 4, this.e, true); 
    if (set.contains(Integer.valueOf(5)))
      c.p(paramParcel, 5, this.f, true); 
    c.b(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a3\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */