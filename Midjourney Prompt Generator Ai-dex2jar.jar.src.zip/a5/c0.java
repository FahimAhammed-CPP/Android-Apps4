package a5;

import com.google.crypto.tink.shaded.protobuf.a0;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public final class c0 extends y<c0, c0.b> implements s0 {
  private static final c0 DEFAULT_INSTANCE;
  
  public static final int KEY_FIELD_NUMBER = 2;
  
  private static volatile z0<c0> PARSER;
  
  public static final int PRIMARY_KEY_ID_FIELD_NUMBER = 1;
  
  private a0.i<c> key_ = y.z();
  
  private int primaryKeyId_;
  
  static {
    c0 c01 = new c0();
    DEFAULT_INSTANCE = c01;
    y.U(c0.class, c01);
  }
  
  private void a0(c paramc) {
    paramc.getClass();
    b0();
    this.key_.add(paramc);
  }
  
  private void b0() {
    a0.i<c> i1 = this.key_;
    if (!i1.k())
      this.key_ = y.K(i1); 
  }
  
  public static b g0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static c0 h0(InputStream paramInputStream, p paramp) {
    return (c0)y.P(DEFAULT_INSTANCE, paramInputStream, paramp);
  }
  
  public static c0 i0(byte[] paramArrayOfbyte, p paramp) {
    return (c0)y.Q(DEFAULT_INSTANCE, paramArrayOfbyte, paramp);
  }
  
  private void j0(int paramInt) {
    this.primaryKeyId_ = paramInt;
  }
  
  public c c0(int paramInt) {
    return this.key_.get(paramInt);
  }
  
  public int d0() {
    return this.key_.size();
  }
  
  public List<c> e0() {
    return (List<c>)this.key_;
  }
  
  public int f0() {
    return this.primaryKeyId_;
  }
  
  protected final Object y(y.f paramf, Object<c0> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/c0$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 157, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/c0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/c0
    //   77: monitorenter
    //   78: getstatic a5/c0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/c0.DEFAULT_INSTANCE : La5/c0;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/c0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/c0
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/c0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/c0.DEFAULT_INSTANCE : La5/c0;
    //   119: areturn
    //   120: getstatic a5/c0.DEFAULT_INSTANCE : La5/c0;
    //   123: ldc '     '
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'primaryKeyId_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'key_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc a5/c0$c
    //   143: aastore
    //   144: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new a5/c0$b
    //   151: dup
    //   152: aconst_null
    //   153: invokespecial <init> : (La5/c0$a;)V
    //   156: areturn
    //   157: new a5/c0
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<c0, b> implements s0 {
    private b() {
      super(c0.X());
    }
    
    public b B(c0.c param1c) {
      r();
      c0.Z((c0)this.b, param1c);
      return this;
    }
    
    public c0.c C(int param1Int) {
      return ((c0)this.b).c0(param1Int);
    }
    
    public int D() {
      return ((c0)this.b).d0();
    }
    
    public List<c0.c> E() {
      return Collections.unmodifiableList(((c0)this.b).e0());
    }
    
    public b F(int param1Int) {
      r();
      c0.Y((c0)this.b, param1Int);
      return this;
    }
  }
  
  public static final class c extends y<c, c.a> implements s0 {
    private static final c DEFAULT_INSTANCE;
    
    public static final int KEY_DATA_FIELD_NUMBER = 1;
    
    public static final int KEY_ID_FIELD_NUMBER = 3;
    
    public static final int OUTPUT_PREFIX_TYPE_FIELD_NUMBER = 4;
    
    private static volatile z0<c> PARSER;
    
    public static final int STATUS_FIELD_NUMBER = 2;
    
    private y keyData_;
    
    private int keyId_;
    
    private int outputPrefixType_;
    
    private int status_;
    
    static {
      c c1 = new c();
      DEFAULT_INSTANCE = c1;
      y.U(c.class, c1);
    }
    
    public static a h0() {
      return (a)DEFAULT_INSTANCE.u();
    }
    
    private void i0(y param1y) {
      param1y.getClass();
      this.keyData_ = param1y;
    }
    
    private void j0(int param1Int) {
      this.keyId_ = param1Int;
    }
    
    private void k0(i0 param1i0) {
      this.outputPrefixType_ = param1i0.b();
    }
    
    private void l0(z param1z) {
      this.status_ = param1z.b();
    }
    
    public y c0() {
      y y2 = this.keyData_;
      y y1 = y2;
      if (y2 == null)
        y1 = y.b0(); 
      return y1;
    }
    
    public int d0() {
      return this.keyId_;
    }
    
    public i0 e0() {
      i0 i02 = i0.a(this.outputPrefixType_);
      i0 i01 = i02;
      if (i02 == null)
        i01 = i0.g; 
      return i01;
    }
    
    public z f0() {
      z z2 = z.a(this.status_);
      z z1 = z2;
      if (z2 == null)
        z1 = z.f; 
      return z1;
    }
    
    public boolean g0() {
      return (this.keyData_ != null);
    }
    
    protected final Object y(y.f param1f, Object<c> param1Object1, Object param1Object2) {
      // Byte code:
      //   0: getstatic a5/c0$a.a : [I
      //   3: aload_1
      //   4: invokevirtual ordinal : ()I
      //   7: iaload
      //   8: tableswitch default -> 52, 1 -> 162, 2 -> 153, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
      //   52: new java/lang/UnsupportedOperationException
      //   55: dup
      //   56: invokespecial <init> : ()V
      //   59: athrow
      //   60: aconst_null
      //   61: areturn
      //   62: iconst_1
      //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
      //   66: areturn
      //   67: getstatic a5/c0$c.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
      //   70: astore_1
      //   71: aload_1
      //   72: ifnonnull -> 114
      //   75: ldc a5/c0$c
      //   77: monitorenter
      //   78: getstatic a5/c0$c.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
      //   81: astore_2
      //   82: aload_2
      //   83: astore_1
      //   84: aload_2
      //   85: ifnonnull -> 103
      //   88: new com/google/crypto/tink/shaded/protobuf/y$b
      //   91: dup
      //   92: getstatic a5/c0$c.DEFAULT_INSTANCE : La5/c0$c;
      //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
      //   98: astore_1
      //   99: aload_1
      //   100: putstatic a5/c0$c.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
      //   103: ldc a5/c0$c
      //   105: monitorexit
      //   106: aload_1
      //   107: areturn
      //   108: astore_1
      //   109: ldc a5/c0$c
      //   111: monitorexit
      //   112: aload_1
      //   113: athrow
      //   114: aload_1
      //   115: areturn
      //   116: getstatic a5/c0$c.DEFAULT_INSTANCE : La5/c0$c;
      //   119: areturn
      //   120: getstatic a5/c0$c.DEFAULT_INSTANCE : La5/c0$c;
      //   123: ldc '      \\t\\f\\f'
      //   125: iconst_4
      //   126: anewarray java/lang/Object
      //   129: dup
      //   130: iconst_0
      //   131: ldc 'keyData_'
      //   133: aastore
      //   134: dup
      //   135: iconst_1
      //   136: ldc 'status_'
      //   138: aastore
      //   139: dup
      //   140: iconst_2
      //   141: ldc 'keyId_'
      //   143: aastore
      //   144: dup
      //   145: iconst_3
      //   146: ldc 'outputPrefixType_'
      //   148: aastore
      //   149: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
      //   152: areturn
      //   153: new a5/c0$c$a
      //   156: dup
      //   157: aconst_null
      //   158: invokespecial <init> : (La5/c0$a;)V
      //   161: areturn
      //   162: new a5/c0$c
      //   165: dup
      //   166: invokespecial <init> : ()V
      //   169: areturn
      // Exception table:
      //   from	to	target	type
      //   78	82	108	finally
      //   88	103	108	finally
      //   103	106	108	finally
      //   109	112	108	finally
    }
    
    public static final class a extends y.a<c, a> implements s0 {
      private a() {
        super(c0.c.X());
      }
      
      public a B(y param2y) {
        r();
        c0.c.Y((c0.c)this.b, param2y);
        return this;
      }
      
      public a C(int param2Int) {
        r();
        c0.c.b0((c0.c)this.b, param2Int);
        return this;
      }
      
      public a D(i0 param2i0) {
        r();
        c0.c.Z((c0.c)this.b, param2i0);
        return this;
      }
      
      public a E(z param2z) {
        r();
        c0.c.a0((c0.c)this.b, param2z);
        return this;
      }
    }
  }
  
  public static final class a extends y.a<c, c.a> implements s0 {
    private a() {
      super(c0.c.X());
    }
    
    public a B(y param1y) {
      r();
      c0.c.Y((c0.c)this.b, param1y);
      return this;
    }
    
    public a C(int param1Int) {
      r();
      c0.c.b0((c0.c)this.b, param1Int);
      return this;
    }
    
    public a D(i0 param1i0) {
      r();
      c0.c.Z((c0.c)this.b, param1i0);
      return this;
    }
    
    public a E(z param1z) {
      r();
      c0.c.a0((c0.c)this.b, param1z);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */