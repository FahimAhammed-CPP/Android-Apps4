package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class d extends y<d, d.b> implements s0 {
  public static final int AES_CTR_KEY_FIELD_NUMBER = 2;
  
  private static final d DEFAULT_INSTANCE;
  
  public static final int HMAC_KEY_FIELD_NUMBER = 3;
  
  private static volatile z0<d> PARSER;
  
  public static final int VERSION_FIELD_NUMBER = 1;
  
  private f aesCtrKey_;
  
  private v hmacKey_;
  
  private int version_;
  
  static {
    d d1 = new d();
    DEFAULT_INSTANCE = d1;
    y.U(d.class, d1);
  }
  
  public static b e0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static d f0(h paramh, p paramp) {
    return (d)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void g0(f paramf) {
    paramf.getClass();
    this.aesCtrKey_ = paramf;
  }
  
  private void h0(v paramv) {
    paramv.getClass();
    this.hmacKey_ = paramv;
  }
  
  private void i0(int paramInt) {
    this.version_ = paramInt;
  }
  
  public f b0() {
    f f2 = this.aesCtrKey_;
    f f1 = f2;
    if (f2 == null)
      f1 = f.b0(); 
    return f1;
  }
  
  public v c0() {
    v v2 = this.hmacKey_;
    v v1 = v2;
    if (v2 == null)
      v1 = v.b0(); 
    return v1;
  }
  
  public int d0() {
    return this.version_;
  }
  
  protected final Object y(y.f paramf, Object<d> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/d$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 157, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/d.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/d
    //   77: monitorenter
    //   78: getstatic a5/d.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/d.DEFAULT_INSTANCE : La5/d;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/d.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/d
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/d
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/d.DEFAULT_INSTANCE : La5/d;
    //   119: areturn
    //   120: getstatic a5/d.DEFAULT_INSTANCE : La5/d;
    //   123: ldc '      \\t\\t'
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'version_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'aesCtrKey_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'hmacKey_'
    //   143: aastore
    //   144: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new a5/d$b
    //   151: dup
    //   152: aconst_null
    //   153: invokespecial <init> : (La5/d$a;)V
    //   156: areturn
    //   157: new a5/d
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<d, b> implements s0 {
    private b() {
      super(d.X());
    }
    
    public b B(f param1f) {
      r();
      d.Z((d)this.b, param1f);
      return this;
    }
    
    public b C(v param1v) {
      r();
      d.a0((d)this.b, param1v);
      return this;
    }
    
    public b D(int param1Int) {
      r();
      d.Y((d)this.b, param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */