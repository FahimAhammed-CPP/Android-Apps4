package a5;

import com.google.crypto.tink.shaded.protobuf.a0;

public enum u implements a0.c {
  b, c, d, e, f, g, h;
  
  private static final a0.d<u> i;
  
  private final int a;
  
  static {
    u u1 = new u("UNKNOWN_HASH", 0, 0);
    b = u1;
    u u2 = new u("SHA1", 1, 1);
    c = u2;
    u u3 = new u("SHA384", 2, 2);
    d = u3;
    u u4 = new u("SHA256", 3, 3);
    e = u4;
    u u5 = new u("SHA512", 4, 4);
    f = u5;
    u u6 = new u("SHA224", 5, 5);
    g = u6;
    u u7 = new u("UNRECOGNIZED", 6, -1);
    h = u7;
    j = new u[] { u1, u2, u3, u4, u5, u6, u7 };
    i = new a();
  }
  
  u(int paramInt1) {
    this.a = paramInt1;
  }
  
  public static u a(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? null : g) : f) : e) : d) : c) : b;
  }
  
  public final int b() {
    if (this != h)
      return this.a; 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  class a implements a0.d<u> {
    public u b(int param1Int) {
      return u.a(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */