package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class j extends y<j, j.b> implements s0 {
  private static final j DEFAULT_INSTANCE;
  
  public static final int KEY_SIZE_FIELD_NUMBER = 2;
  
  public static final int PARAMS_FIELD_NUMBER = 1;
  
  private static volatile z0<j> PARSER;
  
  private int keySize_;
  
  private k params_;
  
  static {
    j j1 = new j();
    DEFAULT_INSTANCE = j1;
    y.U(j.class, j1);
  }
  
  public static b c0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static j d0(h paramh, p paramp) {
    return (j)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void e0(int paramInt) {
    this.keySize_ = paramInt;
  }
  
  private void f0(k paramk) {
    paramk.getClass();
    this.params_ = paramk;
  }
  
  public int a0() {
    return this.keySize_;
  }
  
  public k b0() {
    k k2 = this.params_;
    k k1 = k2;
    if (k2 == null)
      k1 = k.Z(); 
    return k1;
  }
  
  protected final Object y(y.f paramf, Object<j> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/j$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 152, 2 -> 143, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/j.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/j
    //   77: monitorenter
    //   78: getstatic a5/j.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/j.DEFAULT_INSTANCE : La5/j;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/j.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/j
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/j
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/j.DEFAULT_INSTANCE : La5/j;
    //   119: areturn
    //   120: getstatic a5/j.DEFAULT_INSTANCE : La5/j;
    //   123: ldc '      \\t'
    //   125: iconst_2
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'params_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'keySize_'
    //   138: aastore
    //   139: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   142: areturn
    //   143: new a5/j$b
    //   146: dup
    //   147: aconst_null
    //   148: invokespecial <init> : (La5/j$a;)V
    //   151: areturn
    //   152: new a5/j
    //   155: dup
    //   156: invokespecial <init> : ()V
    //   159: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<j, b> implements s0 {
    private b() {
      super(j.X());
    }
    
    public b B(int param1Int) {
      r();
      j.Z((j)this.b, param1Int);
      return this;
    }
    
    public b C(k param1k) {
      r();
      j.Y((j)this.b, param1k);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */