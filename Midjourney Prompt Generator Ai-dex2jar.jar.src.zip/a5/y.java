package a5;

import com.google.crypto.tink.shaded.protobuf.a0;
import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class y extends y<y, y.b> implements s0 {
  private static final y DEFAULT_INSTANCE;
  
  public static final int KEY_MATERIAL_TYPE_FIELD_NUMBER = 3;
  
  private static volatile z0<y> PARSER;
  
  public static final int TYPE_URL_FIELD_NUMBER = 1;
  
  public static final int VALUE_FIELD_NUMBER = 2;
  
  private int keyMaterialType_;
  
  private String typeUrl_ = "";
  
  private h value_ = h.b;
  
  static {
    y y1 = new y();
    DEFAULT_INSTANCE = y1;
    y.U(y.class, y1);
  }
  
  public static y b0() {
    return DEFAULT_INSTANCE;
  }
  
  public static b f0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  private void g0(c paramc) {
    this.keyMaterialType_ = paramc.b();
  }
  
  private void h0(String paramString) {
    paramString.getClass();
    this.typeUrl_ = paramString;
  }
  
  private void i0(h paramh) {
    paramh.getClass();
    this.value_ = paramh;
  }
  
  public c c0() {
    c c2 = c.a(this.keyMaterialType_);
    c c1 = c2;
    if (c2 == null)
      c1 = c.g; 
    return c1;
  }
  
  public String d0() {
    return this.typeUrl_;
  }
  
  public h e0() {
    return this.value_;
  }
  
  protected final Object y(y.f paramf, Object<y> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/y$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 157, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/y.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/y
    //   77: monitorenter
    //   78: getstatic a5/y.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/y.DEFAULT_INSTANCE : La5/y;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/y.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/y
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/y
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/y.DEFAULT_INSTANCE : La5/y;
    //   119: areturn
    //   120: getstatic a5/y.DEFAULT_INSTANCE : La5/y;
    //   123: ldc '      Ȉ\\n\\f'
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'typeUrl_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'value_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'keyMaterialType_'
    //   143: aastore
    //   144: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new a5/y$b
    //   151: dup
    //   152: aconst_null
    //   153: invokespecial <init> : (La5/y$a;)V
    //   156: areturn
    //   157: new a5/y
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<y, b> implements s0 {
    private b() {
      super(y.X());
    }
    
    public b B(y.c param1c) {
      r();
      y.a0((y)this.b, param1c);
      return this;
    }
    
    public b C(String param1String) {
      r();
      y.Y((y)this.b, param1String);
      return this;
    }
    
    public b D(h param1h) {
      r();
      y.Z((y)this.b, param1h);
      return this;
    }
  }
  
  public enum c implements a0.c {
    b, c, d, e, f, g;
    
    private static final a0.d<c> h;
    
    private final int a;
    
    static {
      c c1 = new c("UNKNOWN_KEYMATERIAL", 0, 0);
      b = c1;
      c c2 = new c("SYMMETRIC", 1, 1);
      c = c2;
      c c3 = new c("ASYMMETRIC_PRIVATE", 2, 2);
      d = c3;
      c c4 = new c("ASYMMETRIC_PUBLIC", 3, 3);
      e = c4;
      c c5 = new c("REMOTE", 4, 4);
      f = c5;
      c c6 = new c("UNRECOGNIZED", 5, -1);
      g = c6;
      i = new c[] { c1, c2, c3, c4, c5, c6 };
      h = new a();
    }
    
    c(int param1Int1) {
      this.a = param1Int1;
    }
    
    public static c a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? ((param1Int != 3) ? ((param1Int != 4) ? null : f) : e) : d) : c) : b;
    }
    
    public final int b() {
      if (this != g)
        return this.a; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    class a implements a0.d<c> {
      public y.c b(int param2Int) {
        return y.c.a(param2Int);
      }
    }
  }
  
  class a implements a0.d<c> {
    public y.c b(int param1Int) {
      return y.c.a(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */