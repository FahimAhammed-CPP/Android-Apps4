package a5;

import com.google.crypto.tink.shaded.protobuf.a0;

public enum i0 implements a0.c {
  b, c, d, e, f, g;
  
  private static final a0.d<i0> h;
  
  private final int a;
  
  static {
    i0 i01 = new i0("UNKNOWN_PREFIX", 0, 0);
    b = i01;
    i0 i02 = new i0("TINK", 1, 1);
    c = i02;
    i0 i03 = new i0("LEGACY", 2, 2);
    d = i03;
    i0 i04 = new i0("RAW", 3, 3);
    e = i04;
    i0 i05 = new i0("CRUNCHY", 4, 4);
    f = i05;
    i0 i06 = new i0("UNRECOGNIZED", 5, -1);
    g = i06;
    i = new i0[] { i01, i02, i03, i04, i05, i06 };
    h = new a();
  }
  
  i0(int paramInt1) {
    this.a = paramInt1;
  }
  
  public static i0 a(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? null : f) : e) : d) : c) : b;
  }
  
  public final int b() {
    if (this != g)
      return this.a; 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  class a implements a0.d<i0> {
    public i0 b(int param1Int) {
      return i0.a(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */