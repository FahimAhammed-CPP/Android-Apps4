package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class m extends y<m, m.b> implements s0 {
  private static final m DEFAULT_INSTANCE;
  
  public static final int KEY_SIZE_FIELD_NUMBER = 2;
  
  private static volatile z0<m> PARSER;
  
  public static final int VERSION_FIELD_NUMBER = 3;
  
  private int keySize_;
  
  private int version_;
  
  static {
    m m1 = new m();
    DEFAULT_INSTANCE = m1;
    y.U(m.class, m1);
  }
  
  public static b a0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static m b0(h paramh, p paramp) {
    return (m)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void c0(int paramInt) {
    this.keySize_ = paramInt;
  }
  
  public int Z() {
    return this.keySize_;
  }
  
  protected final Object y(y.f paramf, Object<m> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/m$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 152, 2 -> 143, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/m.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/m
    //   77: monitorenter
    //   78: getstatic a5/m.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/m.DEFAULT_INSTANCE : La5/m;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/m.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/m
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/m
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/m.DEFAULT_INSTANCE : La5/m;
    //   119: areturn
    //   120: getstatic a5/m.DEFAULT_INSTANCE : La5/m;
    //   123: ldc '      '
    //   125: iconst_2
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'keySize_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'version_'
    //   138: aastore
    //   139: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   142: areturn
    //   143: new a5/m$b
    //   146: dup
    //   147: aconst_null
    //   148: invokespecial <init> : (La5/m$a;)V
    //   151: areturn
    //   152: new a5/m
    //   155: dup
    //   156: invokespecial <init> : ()V
    //   159: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<m, b> implements s0 {
    private b() {
      super(m.X());
    }
    
    public b B(int param1Int) {
      r();
      m.Y((m)this.b, param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */