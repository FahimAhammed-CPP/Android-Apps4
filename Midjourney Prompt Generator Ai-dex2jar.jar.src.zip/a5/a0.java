package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class a0 extends y<a0, a0.b> implements s0 {
  private static final a0 DEFAULT_INSTANCE;
  
  public static final int OUTPUT_PREFIX_TYPE_FIELD_NUMBER = 3;
  
  private static volatile z0<a0> PARSER;
  
  public static final int TYPE_URL_FIELD_NUMBER = 1;
  
  public static final int VALUE_FIELD_NUMBER = 2;
  
  private int outputPrefixType_;
  
  private String typeUrl_ = "";
  
  private h value_ = h.b;
  
  static {
    a0 a01 = new a0();
    DEFAULT_INSTANCE = a01;
    y.U(a0.class, a01);
  }
  
  public static a0 b0() {
    return DEFAULT_INSTANCE;
  }
  
  public static b f0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  private void g0(i0 parami0) {
    this.outputPrefixType_ = parami0.b();
  }
  
  private void h0(String paramString) {
    paramString.getClass();
    this.typeUrl_ = paramString;
  }
  
  private void i0(h paramh) {
    paramh.getClass();
    this.value_ = paramh;
  }
  
  public i0 c0() {
    i0 i02 = i0.a(this.outputPrefixType_);
    i0 i01 = i02;
    if (i02 == null)
      i01 = i0.g; 
    return i01;
  }
  
  public String d0() {
    return this.typeUrl_;
  }
  
  public h e0() {
    return this.value_;
  }
  
  protected final Object y(y.f paramf, Object<a0> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/a0$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 157, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/a0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/a0
    //   77: monitorenter
    //   78: getstatic a5/a0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/a0.DEFAULT_INSTANCE : La5/a0;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/a0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/a0
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/a0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/a0.DEFAULT_INSTANCE : La5/a0;
    //   119: areturn
    //   120: getstatic a5/a0.DEFAULT_INSTANCE : La5/a0;
    //   123: ldc '      Ȉ\\n\\f'
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'typeUrl_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'value_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'outputPrefixType_'
    //   143: aastore
    //   144: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new a5/a0$b
    //   151: dup
    //   152: aconst_null
    //   153: invokespecial <init> : (La5/a0$a;)V
    //   156: areturn
    //   157: new a5/a0
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<a0, b> implements s0 {
    private b() {
      super(a0.X());
    }
    
    public b B(i0 param1i0) {
      r();
      a0.a0((a0)this.b, param1i0);
      return this;
    }
    
    public b C(String param1String) {
      r();
      a0.Y((a0)this.b, param1String);
      return this;
    }
    
    public b D(h param1h) {
      r();
      a0.Z((a0)this.b, param1h);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */