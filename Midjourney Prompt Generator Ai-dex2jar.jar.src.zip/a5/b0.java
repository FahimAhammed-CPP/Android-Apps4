package a5;

import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

@Deprecated
public final class b0 extends y<b0, b0.b> implements s0 {
  public static final int CATALOGUE_NAME_FIELD_NUMBER = 5;
  
  private static final b0 DEFAULT_INSTANCE;
  
  public static final int KEY_MANAGER_VERSION_FIELD_NUMBER = 3;
  
  public static final int NEW_KEY_ALLOWED_FIELD_NUMBER = 4;
  
  private static volatile z0<b0> PARSER;
  
  public static final int PRIMITIVE_NAME_FIELD_NUMBER = 1;
  
  public static final int TYPE_URL_FIELD_NUMBER = 2;
  
  private String catalogueName_ = "";
  
  private int keyManagerVersion_;
  
  private boolean newKeyAllowed_;
  
  private String primitiveName_ = "";
  
  private String typeUrl_ = "";
  
  static {
    b0 b01 = new b0();
    DEFAULT_INSTANCE = b01;
    y.U(b0.class, b01);
  }
  
  protected final Object y(y.f paramf, Object<b0> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/b0$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 167, 2 -> 158, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/b0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/b0
    //   77: monitorenter
    //   78: getstatic a5/b0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/b0.DEFAULT_INSTANCE : La5/b0;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/b0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/b0
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/b0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/b0.DEFAULT_INSTANCE : La5/b0;
    //   119: areturn
    //   120: getstatic a5/b0.DEFAULT_INSTANCE : La5/b0;
    //   123: ldc '      ȈȈȈ'
    //   125: iconst_5
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'primitiveName_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'typeUrl_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'keyManagerVersion_'
    //   143: aastore
    //   144: dup
    //   145: iconst_3
    //   146: ldc 'newKeyAllowed_'
    //   148: aastore
    //   149: dup
    //   150: iconst_4
    //   151: ldc 'catalogueName_'
    //   153: aastore
    //   154: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   157: areturn
    //   158: new a5/b0$b
    //   161: dup
    //   162: aconst_null
    //   163: invokespecial <init> : (La5/b0$a;)V
    //   166: areturn
    //   167: new a5/b0
    //   170: dup
    //   171: invokespecial <init> : ()V
    //   174: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<b0, b> implements s0 {
    private b() {
      super(b0.X());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */