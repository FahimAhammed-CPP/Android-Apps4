package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class g0 extends y<g0, g0.b> implements s0 {
  private static final g0 DEFAULT_INSTANCE;
  
  public static final int PARAMS_FIELD_NUMBER = 2;
  
  private static volatile z0<g0> PARSER;
  
  public static final int VERSION_FIELD_NUMBER = 1;
  
  private h0 params_;
  
  private int version_;
  
  static {
    g0 g01 = new g0();
    DEFAULT_INSTANCE = g01;
    y.U(g0.class, g01);
  }
  
  public static b c0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static g0 d0(h paramh, p paramp) {
    return (g0)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void e0(h0 paramh0) {
    paramh0.getClass();
    this.params_ = paramh0;
  }
  
  private void f0(int paramInt) {
    this.version_ = paramInt;
  }
  
  public h0 a0() {
    h0 h02 = this.params_;
    h0 h01 = h02;
    if (h02 == null)
      h01 = h0.Y(); 
    return h01;
  }
  
  public int b0() {
    return this.version_;
  }
  
  protected final Object y(y.f paramf, Object<g0> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/g0$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 152, 2 -> 143, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/g0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/g0
    //   77: monitorenter
    //   78: getstatic a5/g0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/g0.DEFAULT_INSTANCE : La5/g0;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/g0.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/g0
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/g0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/g0.DEFAULT_INSTANCE : La5/g0;
    //   119: areturn
    //   120: getstatic a5/g0.DEFAULT_INSTANCE : La5/g0;
    //   123: ldc '      \\t'
    //   125: iconst_2
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'version_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'params_'
    //   138: aastore
    //   139: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   142: areturn
    //   143: new a5/g0$b
    //   146: dup
    //   147: aconst_null
    //   148: invokespecial <init> : (La5/g0$a;)V
    //   151: areturn
    //   152: new a5/g0
    //   155: dup
    //   156: invokespecial <init> : ()V
    //   159: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<g0, b> implements s0 {
    private b() {
      super(g0.X());
    }
    
    public b B(h0 param1h0) {
      r();
      g0.Z((g0)this.b, param1h0);
      return this;
    }
    
    public b C(int param1Int) {
      r();
      g0.Y((g0)this.b, param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */