package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class n extends y<n, n.b> implements s0 {
  private static final n DEFAULT_INSTANCE;
  
  public static final int KEY_VALUE_FIELD_NUMBER = 3;
  
  private static volatile z0<n> PARSER;
  
  public static final int VERSION_FIELD_NUMBER = 1;
  
  private h keyValue_ = h.b;
  
  private int version_;
  
  static {
    n n1 = new n();
    DEFAULT_INSTANCE = n1;
    y.U(n.class, n1);
  }
  
  public static b c0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static n d0(h paramh, p paramp) {
    return (n)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void e0(h paramh) {
    paramh.getClass();
    this.keyValue_ = paramh;
  }
  
  private void f0(int paramInt) {
    this.version_ = paramInt;
  }
  
  public h a0() {
    return this.keyValue_;
  }
  
  public int b0() {
    return this.version_;
  }
  
  protected final Object y(y.f paramf, Object<n> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/n$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 152, 2 -> 143, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/n.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/n
    //   77: monitorenter
    //   78: getstatic a5/n.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/n.DEFAULT_INSTANCE : La5/n;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/n.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/n
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/n
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/n.DEFAULT_INSTANCE : La5/n;
    //   119: areturn
    //   120: getstatic a5/n.DEFAULT_INSTANCE : La5/n;
    //   123: ldc '      \\n'
    //   125: iconst_2
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'version_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'keyValue_'
    //   138: aastore
    //   139: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   142: areturn
    //   143: new a5/n$b
    //   146: dup
    //   147: aconst_null
    //   148: invokespecial <init> : (La5/n$a;)V
    //   151: areturn
    //   152: new a5/n
    //   155: dup
    //   156: invokespecial <init> : ()V
    //   159: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<n, b> implements s0 {
    private b() {
      super(n.X());
    }
    
    public b B(h param1h) {
      r();
      n.Z((n)this.b, param1h);
      return this;
    }
    
    public b C(int param1Int) {
      r();
      n.Y((n)this.b, param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */