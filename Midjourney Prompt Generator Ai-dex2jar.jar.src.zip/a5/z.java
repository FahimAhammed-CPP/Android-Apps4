package a5;

import com.google.crypto.tink.shaded.protobuf.a0;

public enum z implements a0.c {
  b, c, d, e, f;
  
  private static final a0.d<z> g;
  
  private final int a;
  
  static {
    z z1 = new z("UNKNOWN_STATUS", 0, 0);
    b = z1;
    z z2 = new z("ENABLED", 1, 1);
    c = z2;
    z z3 = new z("DISABLED", 2, 2);
    d = z3;
    z z4 = new z("DESTROYED", 3, 3);
    e = z4;
    z z5 = new z("UNRECOGNIZED", 4, -1);
    f = z5;
    h = new z[] { z1, z2, z3, z4, z5 };
    g = new a();
  }
  
  z(int paramInt1) {
    this.a = paramInt1;
  }
  
  public static z a(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? null : e) : d) : c) : b;
  }
  
  public final int b() {
    if (this != f)
      return this.a; 
    throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
  }
  
  class a implements a0.d<z> {
    public z b(int param1Int) {
      return z.a(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */