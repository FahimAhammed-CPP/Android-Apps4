package a5;

import com.google.crypto.tink.shaded.protobuf.h;
import com.google.crypto.tink.shaded.protobuf.i;
import com.google.crypto.tink.shaded.protobuf.p;
import com.google.crypto.tink.shaded.protobuf.r0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;
import com.google.crypto.tink.shaded.protobuf.z0;

public final class w extends y<w, w.b> implements s0 {
  private static final w DEFAULT_INSTANCE;
  
  public static final int KEY_SIZE_FIELD_NUMBER = 2;
  
  public static final int PARAMS_FIELD_NUMBER = 1;
  
  private static volatile z0<w> PARSER;
  
  public static final int VERSION_FIELD_NUMBER = 3;
  
  private int keySize_;
  
  private x params_;
  
  private int version_;
  
  static {
    w w1 = new w();
    DEFAULT_INSTANCE = w1;
    y.U(w.class, w1);
  }
  
  public static w a0() {
    return DEFAULT_INSTANCE;
  }
  
  public static b d0() {
    return (b)DEFAULT_INSTANCE.u();
  }
  
  public static w e0(h paramh, p paramp) {
    return (w)y.O(DEFAULT_INSTANCE, paramh, paramp);
  }
  
  private void f0(int paramInt) {
    this.keySize_ = paramInt;
  }
  
  private void g0(x paramx) {
    paramx.getClass();
    this.params_ = paramx;
  }
  
  public int b0() {
    return this.keySize_;
  }
  
  public x c0() {
    x x2 = this.params_;
    x x1 = x2;
    if (x2 == null)
      x1 = x.a0(); 
    return x1;
  }
  
  protected final Object y(y.f paramf, Object<w> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic a5/w$a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 157, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic a5/w.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc a5/w
    //   77: monitorenter
    //   78: getstatic a5/w.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/google/crypto/tink/shaded/protobuf/y$b
    //   91: dup
    //   92: getstatic a5/w.DEFAULT_INSTANCE : La5/w;
    //   95: invokespecial <init> : (Lcom/google/crypto/tink/shaded/protobuf/y;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic a5/w.PARSER : Lcom/google/crypto/tink/shaded/protobuf/z0;
    //   103: ldc a5/w
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc a5/w
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic a5/w.DEFAULT_INSTANCE : La5/w;
    //   119: areturn
    //   120: getstatic a5/w.DEFAULT_INSTANCE : La5/w;
    //   123: ldc '      \\t'
    //   125: iconst_3
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'params_'
    //   133: aastore
    //   134: dup
    //   135: iconst_1
    //   136: ldc 'keySize_'
    //   138: aastore
    //   139: dup
    //   140: iconst_2
    //   141: ldc 'version_'
    //   143: aastore
    //   144: invokestatic M : (Lcom/google/crypto/tink/shaded/protobuf/r0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   147: areturn
    //   148: new a5/w$b
    //   151: dup
    //   152: aconst_null
    //   153: invokespecial <init> : (La5/w$a;)V
    //   156: areturn
    //   157: new a5/w
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public static final class b extends y.a<w, b> implements s0 {
    private b() {
      super(w.X());
    }
    
    public b B(int param1Int) {
      r();
      w.Z((w)this.b, param1Int);
      return this;
    }
    
    public b C(x param1x) {
      r();
      w.Y((w)this.b, param1x);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a5\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */