package a4;

import android.os.Bundle;
import androidx.annotation.NonNull;
import b4.t;
import com.google.android.gms.internal.measurement.x2;
import java.util.List;
import java.util.Map;

public class a {
  private final x2 a;
  
  public a(x2 paramx2) {
    this.a = paramx2;
  }
  
  public void a(@NonNull String paramString1, String paramString2, Bundle paramBundle) {
    this.a.L(paramString1, paramString2, paramBundle);
  }
  
  @NonNull
  public List<Bundle> b(String paramString1, String paramString2) {
    return this.a.F(paramString1, paramString2);
  }
  
  public int c(@NonNull String paramString) {
    return this.a.t(paramString);
  }
  
  @NonNull
  public Map<String, Object> d(String paramString1, String paramString2, boolean paramBoolean) {
    return this.a.G(paramString1, paramString2, paramBoolean);
  }
  
  public void e(@NonNull String paramString1, @NonNull String paramString2, @NonNull Bundle paramBundle) {
    this.a.O(paramString1, paramString2, paramBundle);
  }
  
  public void f(@NonNull a parama) {
    this.a.b(parama);
  }
  
  public void g(@NonNull Bundle paramBundle) {
    this.a.d(paramBundle);
  }
  
  public final void h(boolean paramBoolean) {
    this.a.g(paramBoolean);
  }
  
  public static interface a extends t {}
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */