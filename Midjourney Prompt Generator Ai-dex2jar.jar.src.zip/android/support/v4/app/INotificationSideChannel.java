package android.support.v4.app;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public interface INotificationSideChannel extends IInterface {
  public static final String k = "android$support$v4$app$INotificationSideChannel".replace('$', '.');
  
  void K0(String paramString1, int paramInt, String paramString2);
  
  void d0(String paramString);
  
  void v1(String paramString1, int paramInt, String paramString2, Notification paramNotification);
  
  public static abstract class Stub extends Binder implements INotificationSideChannel {
    public Stub() {
      attachInterface(this, INotificationSideChannel.k);
    }
    
    public static INotificationSideChannel asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(INotificationSideChannel.k);
      return (iInterface != null && iInterface instanceof INotificationSideChannel) ? (INotificationSideChannel)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      String str = INotificationSideChannel.k;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1) {
          if (param1Int1 != 2) {
            if (param1Int1 != 3)
              return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
            d0(param1Parcel1.readString());
            return true;
          } 
          K0(param1Parcel1.readString(), param1Parcel1.readInt(), param1Parcel1.readString());
          return true;
        } 
        v1(param1Parcel1.readString(), param1Parcel1.readInt(), param1Parcel1.readString(), (Notification)INotificationSideChannel.a.a(param1Parcel1, Notification.CREATOR));
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class a implements INotificationSideChannel {
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements INotificationSideChannel {
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
  
  public static class a {
    private static <T> T b(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\support\v4\app\INotificationSideChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */