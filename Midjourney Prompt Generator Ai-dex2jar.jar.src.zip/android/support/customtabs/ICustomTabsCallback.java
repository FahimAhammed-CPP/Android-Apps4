package android.support.customtabs;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface ICustomTabsCallback extends IInterface {
  void S0(String paramString, Bundle paramBundle);
  
  void d1(int paramInt, Bundle paramBundle);
  
  Bundle h0(String paramString, Bundle paramBundle);
  
  void q1(String paramString, Bundle paramBundle);
  
  void t1(Bundle paramBundle);
  
  void x1(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle);
  
  public static abstract class Stub extends Binder implements ICustomTabsCallback {
    public Stub() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public static ICustomTabsCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
      return (iInterface != null && iInterface instanceof ICustomTabsCallback) ? (ICustomTabsCallback)iInterface : new a(param1IBinder);
    }
    
    public static ICustomTabsCallback getDefaultImpl() {
      return a.b;
    }
    
    public static boolean setDefaultImpl(ICustomTabsCallback param1ICustomTabsCallback) {
      if (a.b == null) {
        if (param1ICustomTabsCallback != null) {
          a.b = param1ICustomTabsCallback;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      if (param1Int1 != 1598968902) {
        Bundle bundle1;
        Bundle bundle3;
        String str1;
        boolean bool = false;
        String str2 = null;
        Bundle bundle4 = null;
        Bundle bundle6 = null;
        Bundle bundle5 = null;
        Bundle bundle7 = null;
        Bundle bundle2 = null;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 7:
            param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str2 = param1Parcel1.readString();
            if (param1Parcel1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            bundle1 = h0(str2, bundle2);
            param1Parcel2.writeNoException();
            if (bundle1 != null) {
              param1Parcel2.writeInt(1);
              bundle1.writeToParcel(param1Parcel2, 1);
              return true;
            } 
            param1Parcel2.writeInt(0);
            return true;
          case 6:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            param1Int1 = bundle1.readInt();
            if (bundle1.readInt() != 0) {
              Uri uri = (Uri)Uri.CREATOR.createFromParcel((Parcel)bundle1);
            } else {
              bundle2 = null;
            } 
            if (bundle1.readInt() != 0)
              bool = true; 
            if (bundle1.readInt() != 0)
              bundle3 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            x1(param1Int1, (Uri)bundle2, bool, bundle3);
            param1Parcel2.writeNoException();
            return true;
          case 5:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle4;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            q1(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 4:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            bundle2 = bundle6;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            t1(bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 3:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle5;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            S0(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 2:
            break;
        } 
        bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        param1Int1 = bundle1.readInt();
        bundle2 = bundle7;
        if (bundle1.readInt() != 0)
          bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
        d1(param1Int1, bundle2);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel2.writeString("android.support.customtabs.ICustomTabsCallback");
      return true;
    }
    
    private static class a implements ICustomTabsCallback {
      public static ICustomTabsCallback b;
      
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements ICustomTabsCallback {
    public static ICustomTabsCallback b;
    
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\support\customtabs\ICustomTabsCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */