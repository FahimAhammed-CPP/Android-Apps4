package android.support.customtabs;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface IPostMessageService extends IInterface {
  void C0(ICustomTabsCallback paramICustomTabsCallback, String paramString, Bundle paramBundle);
  
  void p0(ICustomTabsCallback paramICustomTabsCallback, Bundle paramBundle);
  
  public static abstract class Stub extends Binder implements IPostMessageService {
    public Stub() {
      attachInterface(this, "android.support.customtabs.IPostMessageService");
    }
    
    public static IPostMessageService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.IPostMessageService");
      return (iInterface != null && iInterface instanceof IPostMessageService) ? (IPostMessageService)iInterface : new a(param1IBinder);
    }
    
    public static IPostMessageService getDefaultImpl() {
      return a.b;
    }
    
    public static boolean setDefaultImpl(IPostMessageService param1IPostMessageService) {
      if (a.b == null) {
        if (param1IPostMessageService != null) {
          a.b = param1IPostMessageService;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      Bundle bundle1;
      ICustomTabsCallback iCustomTabsCallback2 = null;
      Bundle bundle2 = null;
      if (param1Int1 != 2) {
        if (param1Int1 != 3) {
          if (param1Int1 != 1598968902)
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
          param1Parcel2.writeString("android.support.customtabs.IPostMessageService");
          return true;
        } 
        param1Parcel1.enforceInterface("android.support.customtabs.IPostMessageService");
        iCustomTabsCallback2 = ICustomTabsCallback.Stub.asInterface(param1Parcel1.readStrongBinder());
        String str = param1Parcel1.readString();
        if (param1Parcel1.readInt() != 0)
          bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
        C0(iCustomTabsCallback2, str, bundle2);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("android.support.customtabs.IPostMessageService");
      ICustomTabsCallback iCustomTabsCallback3 = ICustomTabsCallback.Stub.asInterface(param1Parcel1.readStrongBinder());
      ICustomTabsCallback iCustomTabsCallback1 = iCustomTabsCallback2;
      if (param1Parcel1.readInt() != 0)
        bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
      p0(iCustomTabsCallback3, bundle1);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements IPostMessageService {
      public static IPostMessageService b;
      
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements IPostMessageService {
    public static IPostMessageService b;
    
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\support\customtabs\IPostMessageService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */