package android.support.customtabs.trusted;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface ITrustedWebActivityCallback extends IInterface {
  void s1(String paramString, Bundle paramBundle);
  
  public static abstract class Stub extends Binder implements ITrustedWebActivityCallback {
    public Stub() {
      attachInterface(this, "android.support.customtabs.trusted.ITrustedWebActivityCallback");
    }
    
    public static ITrustedWebActivityCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.trusted.ITrustedWebActivityCallback");
      return (iInterface != null && iInterface instanceof ITrustedWebActivityCallback) ? (ITrustedWebActivityCallback)iInterface : new a(param1IBinder);
    }
    
    public static ITrustedWebActivityCallback getDefaultImpl() {
      return a.b;
    }
    
    public static boolean setDefaultImpl(ITrustedWebActivityCallback param1ITrustedWebActivityCallback) {
      if (a.b == null) {
        if (param1ITrustedWebActivityCallback != null) {
          a.b = param1ITrustedWebActivityCallback;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      if (param1Int1 != 2) {
        if (param1Int1 != 1598968902)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Parcel2.writeString("android.support.customtabs.trusted.ITrustedWebActivityCallback");
        return true;
      } 
      param1Parcel1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityCallback");
      String str = param1Parcel1.readString();
      if (param1Parcel1.readInt() != 0) {
        Bundle bundle = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1);
      } else {
        param1Parcel1 = null;
      } 
      s1(str, (Bundle)param1Parcel1);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements ITrustedWebActivityCallback {
      public static ITrustedWebActivityCallback b;
      
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements ITrustedWebActivityCallback {
    public static ITrustedWebActivityCallback b;
    
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\support\customtabs\trusted\ITrustedWebActivityCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */