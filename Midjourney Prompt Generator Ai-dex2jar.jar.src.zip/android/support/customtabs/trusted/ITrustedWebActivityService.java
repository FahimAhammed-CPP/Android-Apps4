package android.support.customtabs.trusted;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface ITrustedWebActivityService extends IInterface {
  int G0();
  
  Bundle J0();
  
  Bundle L0(Bundle paramBundle);
  
  Bundle S();
  
  void W0(Bundle paramBundle);
  
  Bundle X0(Bundle paramBundle);
  
  Bundle n0(String paramString, Bundle paramBundle, IBinder paramIBinder);
  
  public static abstract class Stub extends Binder implements ITrustedWebActivityService {
    public Stub() {
      attachInterface(this, "android.support.customtabs.trusted.ITrustedWebActivityService");
    }
    
    public static ITrustedWebActivityService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
      return (iInterface != null && iInterface instanceof ITrustedWebActivityService) ? (ITrustedWebActivityService)iInterface : new a(param1IBinder);
    }
    
    public static ITrustedWebActivityService getDefaultImpl() {
      return a.b;
    }
    
    public static boolean setDefaultImpl(ITrustedWebActivityService param1ITrustedWebActivityService) {
      if (a.b == null) {
        if (param1ITrustedWebActivityService != null) {
          a.b = param1ITrustedWebActivityService;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      Bundle bundle4 = null;
      Bundle bundle5 = null;
      Bundle bundle2 = null;
      Bundle bundle3 = null;
      if (param1Int1 != 9) {
        if (param1Int1 != 1598968902) {
          switch (param1Int1) {
            default:
              return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
            case 7:
              param1Parcel1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
              bundle1 = J0();
              param1Parcel2.writeNoException();
              if (bundle1 != null) {
                param1Parcel2.writeInt(1);
                bundle1.writeToParcel(param1Parcel2, 1);
                return true;
              } 
              param1Parcel2.writeInt(0);
              return true;
            case 6:
              bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
              bundle2 = bundle3;
              if (bundle1.readInt() != 0)
                bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
              bundle1 = L0(bundle2);
              param1Parcel2.writeNoException();
              if (bundle1 != null) {
                param1Parcel2.writeInt(1);
                bundle1.writeToParcel(param1Parcel2, 1);
                return true;
              } 
              param1Parcel2.writeInt(0);
              return true;
            case 5:
              bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
              bundle1 = S();
              param1Parcel2.writeNoException();
              if (bundle1 != null) {
                param1Parcel2.writeInt(1);
                bundle1.writeToParcel(param1Parcel2, 1);
                return true;
              } 
              param1Parcel2.writeInt(0);
              return true;
            case 4:
              bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
              param1Int1 = G0();
              param1Parcel2.writeNoException();
              param1Parcel2.writeInt(param1Int1);
              return true;
            case 3:
              bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
              bundle2 = bundle4;
              if (bundle1.readInt() != 0)
                bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
              W0(bundle2);
              param1Parcel2.writeNoException();
              return true;
            case 2:
              break;
          } 
          bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
          bundle2 = bundle5;
          if (bundle1.readInt() != 0)
            bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
          bundle1 = X0(bundle2);
          param1Parcel2.writeNoException();
          if (bundle1 != null) {
            param1Parcel2.writeInt(1);
            bundle1.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        } 
        param1Parcel2.writeString("android.support.customtabs.trusted.ITrustedWebActivityService");
        return true;
      } 
      bundle1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityService");
      String str = bundle1.readString();
      if (bundle1.readInt() != 0)
        bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
      Bundle bundle1 = n0(str, bundle2, bundle1.readStrongBinder());
      param1Parcel2.writeNoException();
      if (bundle1 != null) {
        param1Parcel2.writeInt(1);
        bundle1.writeToParcel(param1Parcel2, 1);
        return true;
      } 
      param1Parcel2.writeInt(0);
      return true;
    }
    
    private static class a implements ITrustedWebActivityService {
      public static ITrustedWebActivityService b;
      
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements ITrustedWebActivityService {
    public static ITrustedWebActivityService b;
    
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\support\customtabs\trusted\ITrustedWebActivityService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */