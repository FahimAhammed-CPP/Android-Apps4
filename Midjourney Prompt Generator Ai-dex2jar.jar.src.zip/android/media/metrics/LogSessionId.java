package android.media.metrics;

import android.annotation.NonNull;
import android.annotation.Nullable;



/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\android\media\metrics\LogSessionId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */