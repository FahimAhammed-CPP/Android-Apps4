package a0;

import android.content.Context;
import androidx.annotation.NonNull;
import java.util.List;

public interface a<T> {
  @NonNull
  T create(@NonNull Context paramContext);
  
  @NonNull
  List<Class<? extends a<?>>> dependencies();
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */