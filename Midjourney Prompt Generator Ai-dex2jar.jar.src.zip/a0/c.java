package a0;

import androidx.annotation.NonNull;

public final class c extends RuntimeException {
  public c(@NonNull String paramString) {
    super(paramString);
  }
  
  public c(@NonNull Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */