package a1;

import android.net.Uri;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import s2.p;

public final class r0 extends IOException {
  public final p a;
  
  public final Uri b;
  
  public final Map<String, List<String>> c;
  
  public final long d;
  
  public r0(p paramp, Uri paramUri, Map<String, List<String>> paramMap, long paramLong, Throwable paramThrowable) {
    super(paramThrowable);
    this.a = paramp;
    this.b = paramUri;
    this.c = paramMap;
    this.d = paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */