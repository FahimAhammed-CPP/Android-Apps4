package a1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import t2.q0;
import t2.r;

final class a {
  public static byte[] a(byte[] paramArrayOfbyte) {
    return (q0.a >= 27) ? paramArrayOfbyte : q0.l0(c(q0.D(paramArrayOfbyte)));
  }
  
  public static byte[] b(byte[] paramArrayOfbyte) {
    if (q0.a >= 27)
      return paramArrayOfbyte; 
    try {
      JSONObject jSONObject = new JSONObject(q0.D(paramArrayOfbyte));
      StringBuilder stringBuilder = new StringBuilder("{\"keys\":[");
      JSONArray jSONArray = jSONObject.getJSONArray("keys");
      for (int i = 0; i < jSONArray.length(); i++) {
        if (i != 0)
          stringBuilder.append(","); 
        JSONObject jSONObject1 = jSONArray.getJSONObject(i);
        stringBuilder.append("{\"k\":\"");
        stringBuilder.append(d(jSONObject1.getString("k")));
        stringBuilder.append("\",\"kid\":\"");
        stringBuilder.append(d(jSONObject1.getString("kid")));
        stringBuilder.append("\",\"kty\":\"");
        stringBuilder.append(jSONObject1.getString("kty"));
        stringBuilder.append("\"}");
      } 
      stringBuilder.append("]}");
      return q0.l0(stringBuilder.toString());
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to adjust response data: ");
      stringBuilder.append(q0.D(paramArrayOfbyte));
      r.d("ClearKeyUtil", stringBuilder.toString(), (Throwable)jSONException);
      return paramArrayOfbyte;
    } 
  }
  
  private static String c(String paramString) {
    return paramString.replace('+', '-').replace('/', '_');
  }
  
  private static String d(String paramString) {
    return paramString.replace('-', '+').replace('_', '/');
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */