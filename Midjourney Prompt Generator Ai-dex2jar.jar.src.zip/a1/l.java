package a1;

import android.net.Uri;
import i4.s0;
import java.util.Collection;
import java.util.Map;
import l4.e;
import s2.u;
import t2.a;
import t2.q0;
import w0.x1;

public final class l implements b0 {
  private final Object a = new Object();
  
  private x1.f b;
  
  private y c;
  
  private s2.l.a d;
  
  private String e;
  
  private y b(x1.f paramf) {
    u.b b;
    String str;
    s2.l.a a1 = this.d;
    if (a1 == null)
      b = (new u.b()).e(this.e); 
    Uri uri = paramf.c;
    if (uri == null) {
      uri = null;
    } else {
      str = uri.toString();
    } 
    o0 o0 = new o0(str, paramf.h, (s2.l.a)b);
    s0<Map.Entry> s0 = paramf.e.g().q();
    while (s0.hasNext()) {
      Map.Entry entry = s0.next();
      o0.e((String)entry.getKey(), (String)entry.getValue());
    } 
    h h = (new h.b()).e(paramf.a, n0.d).b(paramf.f).c(paramf.g).d(e.k((Collection)paramf.j)).a(o0);
    h.G(0, paramf.c());
    return h;
  }
  
  public y a(x1 paramx1) {
    a.e(paramx1.b);
    null = paramx1.b.c;
    if (null == null || q0.a < 18)
      return y.a; 
    synchronized (this.a) {
      if (!q0.c(null, this.b)) {
        this.b = null;
        this.c = b(null);
      } 
      return (y)a.e(this.c);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */