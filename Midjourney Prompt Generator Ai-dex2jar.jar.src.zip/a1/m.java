package a1;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import t2.q0;
import w0.k;

public final class m implements Comparator<m.b>, Parcelable {
  public static final Parcelable.Creator<m> CREATOR = new a();
  
  private final b[] a;
  
  private int b;
  
  public final String c;
  
  public final int d;
  
  m(Parcel paramParcel) {
    this.c = paramParcel.readString();
    b[] arrayOfB = (b[])q0.j(paramParcel.createTypedArray(b.CREATOR));
    this.a = arrayOfB;
    this.d = arrayOfB.length;
  }
  
  public m(String paramString, List<b> paramList) {
    this(paramString, false, paramList.<b>toArray(new b[0]));
  }
  
  private m(String paramString, boolean paramBoolean, b... paramVarArgs) {
    this.c = paramString;
    b[] arrayOfB = paramVarArgs;
    if (paramBoolean)
      arrayOfB = (b[])paramVarArgs.clone(); 
    this.a = arrayOfB;
    this.d = arrayOfB.length;
    Arrays.sort(arrayOfB, this);
  }
  
  public m(String paramString, b... paramVarArgs) {
    this(paramString, true, paramVarArgs);
  }
  
  public m(List<b> paramList) {
    this(null, false, paramList.<b>toArray(new b[0]));
  }
  
  public m(b... paramVarArgs) {
    this((String)null, paramVarArgs);
  }
  
  private static boolean b(ArrayList<b> paramArrayList, int paramInt, UUID paramUUID) {
    for (int i = 0; i < paramInt; i++) {
      if (((b)paramArrayList.get(i)).b.equals(paramUUID))
        return true; 
    } 
    return false;
  }
  
  public static m d(m paramm1, m paramm2) {
    String str;
    ArrayList<b> arrayList = new ArrayList();
    byte b1 = 0;
    if (paramm1 != null) {
      String str1 = paramm1.c;
      b[] arrayOfB = paramm1.a;
      int j = arrayOfB.length;
      int i = 0;
      while (true) {
        String str2 = str1;
        if (i < j) {
          b b2 = arrayOfB[i];
          if (b2.c())
            arrayList.add(b2); 
          i++;
          continue;
        } 
        break;
      } 
    } else {
      paramm1 = null;
    } 
    m m1 = paramm1;
    if (paramm2 != null) {
      String str1;
      m m2 = paramm1;
      if (paramm1 == null)
        str1 = paramm2.c; 
      int j = arrayList.size();
      b[] arrayOfB = paramm2.a;
      int k = arrayOfB.length;
      int i = b1;
      while (true) {
        str = str1;
        if (i < k) {
          b b2 = arrayOfB[i];
          if (b2.c() && !b(arrayList, j, b2.b))
            arrayList.add(b2); 
          i++;
          continue;
        } 
        break;
      } 
    } 
    return arrayList.isEmpty() ? null : new m(str, arrayList);
  }
  
  public int a(b paramb1, b paramb2) {
    UUID uUID = k.a;
    return uUID.equals(paramb1.b) ? (uUID.equals(paramb2.b) ? 0 : 1) : paramb1.b.compareTo(paramb2.b);
  }
  
  public m c(String paramString) {
    return q0.c(this.c, paramString) ? this : new m(paramString, false, this.a);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public b e(int paramInt) {
    return this.a[paramInt];
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (m.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (q0.c(this.c, ((m)paramObject).c) && Arrays.equals((Object[])this.a, (Object[])((m)paramObject).a));
    } 
    return false;
  }
  
  public m f(m paramm) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ljava/lang/String;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnull -> 37
    //   9: aload_1
    //   10: getfield c : Ljava/lang/String;
    //   13: astore #4
    //   15: aload #4
    //   17: ifnull -> 37
    //   20: aload_3
    //   21: aload #4
    //   23: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   26: ifeq -> 32
    //   29: goto -> 37
    //   32: iconst_0
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_1
    //   38: istore_2
    //   39: iload_2
    //   40: invokestatic f : (Z)V
    //   43: aload_0
    //   44: getfield c : Ljava/lang/String;
    //   47: astore_3
    //   48: aload_3
    //   49: ifnull -> 55
    //   52: goto -> 60
    //   55: aload_1
    //   56: getfield c : Ljava/lang/String;
    //   59: astore_3
    //   60: new a1/m
    //   63: dup
    //   64: aload_3
    //   65: aload_0
    //   66: getfield a : [La1/m$b;
    //   69: aload_1
    //   70: getfield a : [La1/m$b;
    //   73: invokestatic F0 : ([Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object;
    //   76: checkcast [La1/m$b;
    //   79: invokespecial <init> : (Ljava/lang/String;[La1/m$b;)V
    //   82: areturn
  }
  
  public int hashCode() {
    if (this.b == 0) {
      int i;
      String str = this.c;
      if (str == null) {
        i = 0;
      } else {
        i = str.hashCode();
      } 
      this.b = i * 31 + Arrays.hashCode((Object[])this.a);
    } 
    return this.b;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.c);
    paramParcel.writeTypedArray((Parcelable[])this.a, 0);
  }
  
  class a implements Parcelable.Creator<m> {
    public m a(Parcel param1Parcel) {
      return new m(param1Parcel);
    }
    
    public m[] b(int param1Int) {
      return new m[param1Int];
    }
  }
  
  public static final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();
    
    private int a;
    
    public final UUID b;
    
    public final String c;
    
    public final String d;
    
    public final byte[] e;
    
    b(Parcel param1Parcel) {
      this.b = new UUID(param1Parcel.readLong(), param1Parcel.readLong());
      this.c = param1Parcel.readString();
      this.d = (String)q0.j(param1Parcel.readString());
      this.e = param1Parcel.createByteArray();
    }
    
    public b(UUID param1UUID, String param1String1, String param1String2, byte[] param1ArrayOfbyte) {
      this.b = (UUID)t2.a.e(param1UUID);
      this.c = param1String1;
      this.d = (String)t2.a.e(param1String2);
      this.e = param1ArrayOfbyte;
    }
    
    public b(UUID param1UUID, String param1String, byte[] param1ArrayOfbyte) {
      this(param1UUID, null, param1String, param1ArrayOfbyte);
    }
    
    public boolean a(b param1b) {
      return (c() && !param1b.c() && d(param1b.b));
    }
    
    public b b(byte[] param1ArrayOfbyte) {
      return new b(this.b, this.c, this.d, param1ArrayOfbyte);
    }
    
    public boolean c() {
      return (this.e != null);
    }
    
    public boolean d(UUID param1UUID) {
      return (k.a.equals(this.b) || param1UUID.equals(this.b));
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = param1Object instanceof b;
      boolean bool1 = false;
      if (!bool)
        return false; 
      if (param1Object == this)
        return true; 
      param1Object = param1Object;
      bool = bool1;
      if (q0.c(this.c, ((b)param1Object).c)) {
        bool = bool1;
        if (q0.c(this.d, ((b)param1Object).d)) {
          bool = bool1;
          if (q0.c(this.b, ((b)param1Object).b)) {
            bool = bool1;
            if (Arrays.equals(this.e, ((b)param1Object).e))
              bool = true; 
          } 
        } 
      } 
      return bool;
    }
    
    public int hashCode() {
      if (this.a == 0) {
        int i;
        int j = this.b.hashCode();
        String str = this.c;
        if (str == null) {
          i = 0;
        } else {
          i = str.hashCode();
        } 
        this.a = ((j * 31 + i) * 31 + this.d.hashCode()) * 31 + Arrays.hashCode(this.e);
      } 
      return this.a;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeLong(this.b.getMostSignificantBits());
      param1Parcel.writeLong(this.b.getLeastSignificantBits());
      param1Parcel.writeString(this.c);
      param1Parcel.writeString(this.d);
      param1Parcel.writeByteArray(this.e);
    }
    
    class a implements Parcelable.Creator<b> {
      public m.b a(Parcel param2Parcel) {
        return new m.b(param2Parcel);
      }
      
      public m.b[] b(int param2Int) {
        return new m.b[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<b> {
    public m.b a(Parcel param1Parcel) {
      return new m.b(param1Parcel);
    }
    
    public m.b[] b(int param1Int) {
      return new m.b[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */