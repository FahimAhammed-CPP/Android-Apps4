package a1;

import android.media.NotProvisionedException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Pair;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import s2.g0;
import t2.h;
import t2.i;
import t2.q0;
import t2.r;
import w0.k;
import x0.t1;
import y1.n;

class g implements o {
  public final List<m.b> a;
  
  private final g0 b;
  
  private final a c;
  
  private final b d;
  
  private final int e;
  
  private final boolean f;
  
  private final boolean g;
  
  private final HashMap<String, String> h;
  
  private final i<w.a> i;
  
  private final g0 j;
  
  private final t1 k;
  
  final q0 l;
  
  final UUID m;
  
  final e n;
  
  private int o;
  
  private int p;
  
  private HandlerThread q;
  
  private c r;
  
  private z0.b s;
  
  private o.a t;
  
  private byte[] u;
  
  private byte[] v;
  
  private g0.a w;
  
  private g0.d x;
  
  public g(UUID paramUUID, g0 paramg0, a parama, b paramb, List<m.b> paramList, int paramInt, boolean paramBoolean1, boolean paramBoolean2, byte[] paramArrayOfbyte, HashMap<String, String> paramHashMap, q0 paramq0, Looper paramLooper, g0 paramg01, t1 paramt1) {
    if (paramInt == 1 || paramInt == 3)
      t2.a.e(paramArrayOfbyte); 
    this.m = paramUUID;
    this.c = parama;
    this.d = paramb;
    this.b = paramg0;
    this.e = paramInt;
    this.f = paramBoolean1;
    this.g = paramBoolean2;
    if (paramArrayOfbyte != null) {
      this.v = paramArrayOfbyte;
      this.a = null;
    } else {
      this.a = Collections.unmodifiableList((List<? extends m.b>)t2.a.e(paramList));
    } 
    this.h = paramHashMap;
    this.l = paramq0;
    this.i = new i();
    this.j = paramg01;
    this.k = paramt1;
    this.o = 2;
    this.n = new e(this, paramLooper);
  }
  
  private void B(Object paramObject1, Object paramObject2) {
    if (paramObject1 == this.x) {
      if (this.o != 2 && !r())
        return; 
      this.x = null;
      if (paramObject2 instanceof Exception) {
        this.c.b((Exception)paramObject2, false);
        return;
      } 
      try {
        this.b.l((byte[])paramObject2);
        this.c.c();
        return;
      } catch (Exception exception) {
        this.c.b(exception, true);
      } 
    } 
  }
  
  private boolean C() {
    if (r())
      return true; 
    try {
      byte[] arrayOfByte = this.b.g();
      this.u = arrayOfByte;
      this.b.e(arrayOfByte, this.k);
      this.s = this.b.f(this.u);
      this.o = 3;
      n(new d(3));
      t2.a.e(this.u);
      return true;
    } catch (NotProvisionedException notProvisionedException) {
      this.c.a(this);
    } catch (Exception exception) {
      u(exception, 1);
    } 
    return false;
  }
  
  private void D(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) {
    try {
      this.w = this.b.m(paramArrayOfbyte, this.a, paramInt, this.h);
      ((c)q0.j(this.r)).b(1, t2.a.e(this.w), paramBoolean);
      return;
    } catch (Exception exception) {
      w(exception, true);
      return;
    } 
  }
  
  private boolean F() {
    try {
      this.b.i(this.u, this.v);
      return true;
    } catch (Exception exception) {
      u(exception, 1);
      return false;
    } 
  }
  
  private void n(h<w.a> paramh) {
    Iterator<w.a> iterator = this.i.l().iterator();
    while (iterator.hasNext())
      paramh.accept(iterator.next()); 
  }
  
  private void o(boolean paramBoolean) {
    if (this.g)
      return; 
    byte[] arrayOfByte = (byte[])q0.j(this.u);
    int j = this.e;
    if (j != 0 && j != 1) {
      if (j != 2) {
        if (j != 3)
          return; 
        t2.a.e(this.v);
        t2.a.e(this.u);
        D(this.v, 3, paramBoolean);
        return;
      } 
      if (this.v == null || F()) {
        D(arrayOfByte, 2, paramBoolean);
        return;
      } 
    } else {
      if (this.v == null) {
        D(arrayOfByte, 1, paramBoolean);
        return;
      } 
      if (this.o == 4 || F()) {
        long l = p();
        if (this.e == 0 && l <= 60L) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Offline license has expired or will expire soon. Remaining seconds: ");
          stringBuilder.append(l);
          r.b("DefaultDrmSession", stringBuilder.toString());
          D(arrayOfByte, 2, paramBoolean);
          return;
        } 
        if (l <= 0L) {
          u(new p0(), 2);
          return;
        } 
        this.o = 4;
        n(new f());
      } 
    } 
  }
  
  private long p() {
    if (!k.d.equals(this.m))
      return Long.MAX_VALUE; 
    Pair pair = (Pair)t2.a.e(t0.b(this));
    return Math.min(((Long)pair.first).longValue(), ((Long)pair.second).longValue());
  }
  
  private boolean r() {
    int j = this.o;
    return (j == 3 || j == 4);
  }
  
  private void u(Exception paramException, int paramInt) {
    this.t = new o.a(paramException, c0.a(paramException, paramInt));
    r.d("DefaultDrmSession", "DRM session error", paramException);
    n(new e(paramException));
    if (this.o != 4)
      this.o = 1; 
  }
  
  private void v(Object paramObject1, Object paramObject2) {
    if (paramObject1 == this.w) {
      if (!r())
        return; 
      this.w = null;
      if (paramObject2 instanceof Exception) {
        w((Exception)paramObject2, false);
        return;
      } 
      try {
        paramObject1 = paramObject2;
        if (this.e == 3) {
          this.b.k((byte[])q0.j(this.v), (byte[])paramObject1);
          n(new b());
          return;
        } 
        paramObject1 = this.b.k(this.u, (byte[])paramObject1);
        int j = this.e;
        if ((j == 2 || (j == 0 && this.v != null)) && paramObject1 != null && paramObject1.length != 0)
          this.v = (byte[])paramObject1; 
        this.o = 4;
        n(new c());
        return;
      } catch (Exception exception) {
        w(exception, true);
      } 
    } 
  }
  
  private void w(Exception paramException, boolean paramBoolean) {
    byte b1;
    if (paramException instanceof NotProvisionedException) {
      this.c.a(this);
      return;
    } 
    if (paramBoolean) {
      b1 = 1;
    } else {
      b1 = 2;
    } 
    u(paramException, b1);
  }
  
  private void x() {
    if (this.e == 0 && this.o == 4) {
      q0.j(this.u);
      o(false);
    } 
  }
  
  public void A(Exception paramException, boolean paramBoolean) {
    byte b1;
    if (paramBoolean) {
      b1 = 1;
    } else {
      b1 = 3;
    } 
    u(paramException, b1);
  }
  
  public void E() {
    this.x = this.b.d();
    ((c)q0.j(this.r)).b(0, t2.a.e(this.x), true);
  }
  
  public final o.a a() {
    return (this.o == 1) ? this.t : null;
  }
  
  public void b(w.a parama) {
    int j = this.p;
    if (j <= 0) {
      r.c("DefaultDrmSession", "release() called on a session that's already fully released.");
      return;
    } 
    this.p = --j;
    if (j == 0) {
      this.o = 0;
      ((e)q0.j(this.n)).removeCallbacksAndMessages(null);
      ((c)q0.j(this.r)).c();
      this.r = null;
      ((HandlerThread)q0.j(this.q)).quit();
      this.q = null;
      this.s = null;
      this.t = null;
      this.w = null;
      this.x = null;
      byte[] arrayOfByte = this.u;
      if (arrayOfByte != null) {
        this.b.j(arrayOfByte);
        this.u = null;
      } 
    } 
    if (parama != null) {
      this.i.g(parama);
      if (this.i.c(parama) == 0)
        parama.m(); 
    } 
    this.d.b(this, this.p);
  }
  
  public final UUID c() {
    return this.m;
  }
  
  public void d(w.a parama) {
    HandlerThread handlerThread;
    int j = this.p;
    boolean bool = false;
    if (j < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Session reference count less than zero: ");
      stringBuilder.append(this.p);
      r.c("DefaultDrmSession", stringBuilder.toString());
      this.p = 0;
    } 
    if (parama != null)
      this.i.a(parama); 
    j = this.p + 1;
    this.p = j;
    if (j == 1) {
      if (this.o == 2)
        bool = true; 
      t2.a.f(bool);
      handlerThread = new HandlerThread("ExoPlayer:DrmRequestHandler");
      this.q = handlerThread;
      handlerThread.start();
      this.r = new c(this, this.q.getLooper());
      if (C())
        o(true); 
    } else if (handlerThread != null && r() && this.i.c(handlerThread) == 1) {
      handlerThread.k(this.o);
    } 
    this.d.a(this, this.p);
  }
  
  public boolean e() {
    return this.f;
  }
  
  public Map<String, String> f() {
    byte[] arrayOfByte = this.u;
    return (arrayOfByte == null) ? null : this.b.c(arrayOfByte);
  }
  
  public boolean g(String paramString) {
    return this.b.h((byte[])t2.a.h(this.u), paramString);
  }
  
  public final int getState() {
    return this.o;
  }
  
  public final z0.b h() {
    return this.s;
  }
  
  public boolean q(byte[] paramArrayOfbyte) {
    return Arrays.equals(this.u, paramArrayOfbyte);
  }
  
  public void y(int paramInt) {
    if (paramInt != 2)
      return; 
    x();
  }
  
  public void z() {
    if (C())
      o(true); 
  }
  
  public static interface a {
    void a(g param1g);
    
    void b(Exception param1Exception, boolean param1Boolean);
    
    void c();
  }
  
  public static interface b {
    void a(g param1g, int param1Int);
    
    void b(g param1g, int param1Int);
  }
  
  private class c extends Handler {
    private boolean a;
    
    public c(g this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    private boolean a(Message param1Message, r0 param1r0) {
      // Byte code:
      //   0: aload_1
      //   1: getfield obj : Ljava/lang/Object;
      //   4: checkcast a1/g$d
      //   7: astore #6
      //   9: aload #6
      //   11: getfield b : Z
      //   14: ifne -> 19
      //   17: iconst_0
      //   18: ireturn
      //   19: aload #6
      //   21: getfield e : I
      //   24: iconst_1
      //   25: iadd
      //   26: istore_3
      //   27: aload #6
      //   29: iload_3
      //   30: putfield e : I
      //   33: iload_3
      //   34: aload_0
      //   35: getfield b : La1/g;
      //   38: invokestatic m : (La1/g;)Ls2/g0;
      //   41: iconst_3
      //   42: invokeinterface d : (I)I
      //   47: if_icmple -> 52
      //   50: iconst_0
      //   51: ireturn
      //   52: new y1/n
      //   55: dup
      //   56: aload #6
      //   58: getfield a : J
      //   61: aload_2
      //   62: getfield a : Ls2/p;
      //   65: aload_2
      //   66: getfield b : Landroid/net/Uri;
      //   69: aload_2
      //   70: getfield c : Ljava/util/Map;
      //   73: invokestatic elapsedRealtime : ()J
      //   76: invokestatic elapsedRealtime : ()J
      //   79: aload #6
      //   81: getfield c : J
      //   84: lsub
      //   85: aload_2
      //   86: getfield d : J
      //   89: invokespecial <init> : (JLs2/p;Landroid/net/Uri;Ljava/util/Map;JJJ)V
      //   92: astore #7
      //   94: new y1/q
      //   97: dup
      //   98: iconst_3
      //   99: invokespecial <init> : (I)V
      //   102: astore #8
      //   104: aload_2
      //   105: invokevirtual getCause : ()Ljava/lang/Throwable;
      //   108: instanceof java/io/IOException
      //   111: ifeq -> 125
      //   114: aload_2
      //   115: invokevirtual getCause : ()Ljava/lang/Throwable;
      //   118: checkcast java/io/IOException
      //   121: astore_2
      //   122: goto -> 137
      //   125: new a1/g$f
      //   128: dup
      //   129: aload_2
      //   130: invokevirtual getCause : ()Ljava/lang/Throwable;
      //   133: invokespecial <init> : (Ljava/lang/Throwable;)V
      //   136: astore_2
      //   137: aload_0
      //   138: getfield b : La1/g;
      //   141: invokestatic m : (La1/g;)Ls2/g0;
      //   144: new s2/g0$c
      //   147: dup
      //   148: aload #7
      //   150: aload #8
      //   152: aload_2
      //   153: aload #6
      //   155: getfield e : I
      //   158: invokespecial <init> : (Ly1/n;Ly1/q;Ljava/io/IOException;I)V
      //   161: invokeinterface b : (Ls2/g0$c;)J
      //   166: lstore #4
      //   168: lload #4
      //   170: ldc2_w -9223372036854775807
      //   173: lcmp
      //   174: ifne -> 179
      //   177: iconst_0
      //   178: ireturn
      //   179: aload_0
      //   180: monitorenter
      //   181: aload_0
      //   182: getfield a : Z
      //   185: ifne -> 203
      //   188: aload_0
      //   189: aload_1
      //   190: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   193: lload #4
      //   195: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
      //   198: pop
      //   199: aload_0
      //   200: monitorexit
      //   201: iconst_1
      //   202: ireturn
      //   203: aload_0
      //   204: monitorexit
      //   205: iconst_0
      //   206: ireturn
      //   207: astore_1
      //   208: aload_0
      //   209: monitorexit
      //   210: aload_1
      //   211: athrow
      // Exception table:
      //   from	to	target	type
      //   181	201	207	finally
      //   203	205	207	finally
      //   208	210	207	finally
    }
    
    void b(int param1Int, Object param1Object, boolean param1Boolean) {
      obtainMessage(param1Int, new g.d(n.a(), param1Boolean, SystemClock.elapsedRealtime(), param1Object)).sendToTarget();
    }
    
    public void c() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aconst_null
      //   4: invokevirtual removeCallbacksAndMessages : (Ljava/lang/Object;)V
      //   7: aload_0
      //   8: iconst_1
      //   9: putfield a : Z
      //   12: aload_0
      //   13: monitorexit
      //   14: return
      //   15: astore_1
      //   16: aload_0
      //   17: monitorexit
      //   18: aload_1
      //   19: athrow
      // Exception table:
      //   from	to	target	type
      //   2	12	15	finally
    }
    
    public void handleMessage(Message param1Message) {
      // Byte code:
      //   0: aload_1
      //   1: getfield obj : Ljava/lang/Object;
      //   4: checkcast a1/g$d
      //   7: astore #5
      //   9: aload_1
      //   10: getfield what : I
      //   13: istore_2
      //   14: iload_2
      //   15: ifeq -> 61
      //   18: iload_2
      //   19: iconst_1
      //   20: if_icmpne -> 53
      //   23: aload_0
      //   24: getfield b : La1/g;
      //   27: astore_3
      //   28: aload_3
      //   29: getfield l : La1/q0;
      //   32: aload_3
      //   33: getfield m : Ljava/util/UUID;
      //   36: aload #5
      //   38: getfield d : Ljava/lang/Object;
      //   41: checkcast a1/g0$a
      //   44: invokeinterface b : (Ljava/util/UUID;La1/g0$a;)[B
      //   49: astore_3
      //   50: goto -> 119
      //   53: new java/lang/RuntimeException
      //   56: dup
      //   57: invokespecial <init> : ()V
      //   60: athrow
      //   61: aload_0
      //   62: getfield b : La1/g;
      //   65: astore_3
      //   66: aload_3
      //   67: getfield l : La1/q0;
      //   70: aload_3
      //   71: getfield m : Ljava/util/UUID;
      //   74: aload #5
      //   76: getfield d : Ljava/lang/Object;
      //   79: checkcast a1/g0$d
      //   82: invokeinterface a : (Ljava/util/UUID;La1/g0$d;)[B
      //   87: astore_3
      //   88: goto -> 119
      //   91: astore_3
      //   92: ldc 'DefaultDrmSession'
      //   94: ldc 'Key/provisioning request produced an unexpected exception. Not retrying.'
      //   96: aload_3
      //   97: invokestatic j : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   100: goto -> 119
      //   103: astore #4
      //   105: aload #4
      //   107: astore_3
      //   108: aload_0
      //   109: aload_1
      //   110: aload #4
      //   112: invokespecial a : (Landroid/os/Message;La1/r0;)Z
      //   115: ifeq -> 119
      //   118: return
      //   119: aload_0
      //   120: getfield b : La1/g;
      //   123: invokestatic m : (La1/g;)Ls2/g0;
      //   126: aload #5
      //   128: getfield a : J
      //   131: invokeinterface a : (J)V
      //   136: aload_0
      //   137: monitorenter
      //   138: aload_0
      //   139: getfield a : Z
      //   142: ifne -> 171
      //   145: aload_0
      //   146: getfield b : La1/g;
      //   149: getfield n : La1/g$e;
      //   152: aload_1
      //   153: getfield what : I
      //   156: aload #5
      //   158: getfield d : Ljava/lang/Object;
      //   161: aload_3
      //   162: invokestatic create : (Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;
      //   165: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
      //   168: invokevirtual sendToTarget : ()V
      //   171: aload_0
      //   172: monitorexit
      //   173: return
      //   174: astore_1
      //   175: aload_0
      //   176: monitorexit
      //   177: aload_1
      //   178: athrow
      // Exception table:
      //   from	to	target	type
      //   9	14	103	a1/r0
      //   9	14	91	java/lang/Exception
      //   23	50	103	a1/r0
      //   23	50	91	java/lang/Exception
      //   53	61	103	a1/r0
      //   53	61	91	java/lang/Exception
      //   61	88	103	a1/r0
      //   61	88	91	java/lang/Exception
      //   138	171	174	finally
      //   171	173	174	finally
      //   175	177	174	finally
    }
  }
  
  private static final class d {
    public final long a;
    
    public final boolean b;
    
    public final long c;
    
    public final Object d;
    
    public int e;
    
    public d(long param1Long1, boolean param1Boolean, long param1Long2, Object param1Object) {
      this.a = param1Long1;
      this.b = param1Boolean;
      this.c = param1Long2;
      this.d = param1Object;
    }
  }
  
  private class e extends Handler {
    public e(g this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      Pair pair = (Pair)param1Message.obj;
      Object object1 = pair.first;
      Object object2 = pair.second;
      int i = param1Message.what;
      if (i != 0) {
        if (i != 1)
          return; 
        g.l(this.a, object1, object2);
        return;
      } 
      g.k(this.a, object1, object2);
    }
  }
  
  public static final class f extends IOException {
    public f(Throwable param1Throwable) {
      super(param1Throwable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */