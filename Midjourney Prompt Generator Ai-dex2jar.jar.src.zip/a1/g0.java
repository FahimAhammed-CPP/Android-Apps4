package a1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import x0.t1;

public interface g0 {
  void a();
  
  void b(b paramb);
  
  Map<String, String> c(byte[] paramArrayOfbyte);
  
  d d();
  
  void e(byte[] paramArrayOfbyte, t1 paramt1);
  
  z0.b f(byte[] paramArrayOfbyte);
  
  byte[] g();
  
  boolean h(byte[] paramArrayOfbyte, String paramString);
  
  void i(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  void j(byte[] paramArrayOfbyte);
  
  byte[] k(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  void l(byte[] paramArrayOfbyte);
  
  a m(byte[] paramArrayOfbyte, List<m.b> paramList, int paramInt, HashMap<String, String> paramHashMap);
  
  int n();
  
  public static final class a {
    private final byte[] a;
    
    private final String b;
    
    private final int c;
    
    public a(byte[] param1ArrayOfbyte, String param1String, int param1Int) {
      this.a = param1ArrayOfbyte;
      this.b = param1String;
      this.c = param1Int;
    }
    
    public byte[] a() {
      return this.a;
    }
    
    public String b() {
      return this.b;
    }
  }
  
  public static interface b {
    void a(g0 param1g0, byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2);
  }
  
  public static interface c {
    g0 a(UUID param1UUID);
  }
  
  public static final class d {
    private final byte[] a;
    
    private final String b;
    
    public d(byte[] param1ArrayOfbyte, String param1String) {
      this.a = param1ArrayOfbyte;
      this.b = param1String;
    }
    
    public byte[] a() {
      return this.a;
    }
    
    public String b() {
      return this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */