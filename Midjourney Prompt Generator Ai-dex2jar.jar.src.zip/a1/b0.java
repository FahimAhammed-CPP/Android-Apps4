package a1;

import w0.x1;

public interface b0 {
  y a(x1 paramx1);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */