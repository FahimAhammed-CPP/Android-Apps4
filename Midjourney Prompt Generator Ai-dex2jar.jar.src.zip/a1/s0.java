package a1;

public final class s0 extends Exception {
  public final int a;
  
  public s0(int paramInt) {
    this.a = paramInt;
  }
  
  public s0(int paramInt, Exception paramException) {
    super(paramException);
    this.a = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */