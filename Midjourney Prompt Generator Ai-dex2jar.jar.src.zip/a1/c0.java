package a1;

import android.media.MediaDrm;
import t2.q0;

public final class c0 {
  public static int a(Exception paramException, int paramInt) {
    int i = q0.a;
    if (i >= 21 && b.a(paramException))
      return b.b(paramException); 
    if (i >= 23 && c.a(paramException))
      return 6006; 
    if (i >= 18 && a.b(paramException))
      return 6002; 
    if (i >= 18 && a.a(paramException))
      return 6007; 
    if (paramException instanceof s0)
      return 6001; 
    if (paramException instanceof h.e)
      return 6003; 
    if (paramException instanceof p0)
      return 6008; 
    if (paramInt == 1)
      return 6006; 
    if (paramInt == 2)
      return 6004; 
    if (paramInt == 3)
      return 6002; 
    throw new IllegalArgumentException();
  }
  
  private static final class a {
    public static boolean a(Throwable param1Throwable) {
      return param1Throwable instanceof android.media.DeniedByServerException;
    }
    
    public static boolean b(Throwable param1Throwable) {
      return param1Throwable instanceof android.media.NotProvisionedException;
    }
  }
  
  private static final class b {
    public static boolean a(Throwable param1Throwable) {
      return param1Throwable instanceof MediaDrm.MediaDrmStateException;
    }
    
    public static int b(Throwable param1Throwable) {
      return q0.U(q0.V(((MediaDrm.MediaDrmStateException)param1Throwable).getDiagnosticInfo()));
    }
  }
  
  private static final class c {
    public static boolean a(Throwable param1Throwable) {
      return param1Throwable instanceof android.media.MediaDrmResetException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */