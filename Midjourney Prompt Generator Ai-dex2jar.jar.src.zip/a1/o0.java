package a1;

import android.net.Uri;
import android.text.TextUtils;
import java.io.Closeable;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import s2.c0;
import s2.l;
import s2.n;
import s2.p;
import t2.a;
import t2.q0;

public final class o0 implements q0 {
  private final l.a a;
  
  private final String b;
  
  private final boolean c;
  
  private final Map<String, String> d;
  
  public o0(String paramString, boolean paramBoolean, l.a parama) {
    boolean bool;
    if (!paramBoolean || !TextUtils.isEmpty(paramString)) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    this.a = parama;
    this.b = paramString;
    this.c = paramBoolean;
    this.d = new HashMap<String, String>();
  }
  
  private static byte[] c(l.a parama, String paramString, byte[] paramArrayOfbyte, Map<String, String> paramMap) {
    s2.o0 o01 = new s2.o0(parama.a());
    p p2 = (new p.b()).j(paramString).e(paramMap).d(2).c(paramArrayOfbyte).b(1).a();
    int i = 0;
    p p1 = p2;
    try {
      while (true) {
        n n = new n((l)o01, p1);
        try {
          byte[] arrayOfByte = q0.U0((InputStream)n);
          q0.n((Closeable)n);
          return arrayOfByte;
        } catch (c0 c0) {
          String str = d(c0, i);
          if (str != null) {
            i++;
            p1 = p1.a().j(str).a();
            q0.n((Closeable)n);
            continue;
          } 
          throw c0;
        } finally {}
        q0.n((Closeable)n);
        throw p1;
      } 
    } catch (Exception exception) {
      throw new r0(p2, (Uri)a.e(o01.p()), o01.h(), o01.o(), exception);
    } 
  }
  
  private static String d(c0 paramc0, int paramInt) {
    int i = paramc0.d;
    if ((i == 307 || i == 308) && paramInt < 5) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt == 0)
      return null; 
    Map map = paramc0.f;
    if (map != null) {
      List<String> list = (List)map.get("Location");
      if (list != null && !list.isEmpty())
        return list.get(0); 
    } 
    return null;
  }
  
  public byte[] a(UUID paramUUID, g0.d paramd) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramd.b());
    stringBuilder.append("&signedRequest=");
    stringBuilder.append(q0.D(paramd.a()));
    String str = stringBuilder.toString();
    return c(this.a, str, null, Collections.emptyMap());
  }
  
  public byte[] b(UUID paramUUID, g0.a parama) {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual b : ()Ljava/lang/String;
    //   4: astore_3
    //   5: aload_0
    //   6: getfield c : Z
    //   9: ifne -> 22
    //   12: aload_3
    //   13: astore #4
    //   15: aload_3
    //   16: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   19: ifeq -> 28
    //   22: aload_0
    //   23: getfield b : Ljava/lang/String;
    //   26: astore #4
    //   28: aload #4
    //   30: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   33: ifne -> 157
    //   36: new java/util/HashMap
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #5
    //   45: getstatic w0/k.e : Ljava/util/UUID;
    //   48: astore #6
    //   50: aload #6
    //   52: aload_1
    //   53: invokevirtual equals : (Ljava/lang/Object;)Z
    //   56: ifeq -> 65
    //   59: ldc 'text/xml'
    //   61: astore_3
    //   62: goto -> 84
    //   65: getstatic w0/k.c : Ljava/util/UUID;
    //   68: aload_1
    //   69: invokevirtual equals : (Ljava/lang/Object;)Z
    //   72: ifeq -> 81
    //   75: ldc 'application/json'
    //   77: astore_3
    //   78: goto -> 84
    //   81: ldc 'application/octet-stream'
    //   83: astore_3
    //   84: aload #5
    //   86: ldc 'Content-Type'
    //   88: aload_3
    //   89: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   94: pop
    //   95: aload #6
    //   97: aload_1
    //   98: invokevirtual equals : (Ljava/lang/Object;)Z
    //   101: ifeq -> 116
    //   104: aload #5
    //   106: ldc 'SOAPAction'
    //   108: ldc 'http://schemas.microsoft.com/DRM/2007/03/protocols/AcquireLicense'
    //   110: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield d : Ljava/util/Map;
    //   120: astore_1
    //   121: aload_1
    //   122: monitorenter
    //   123: aload #5
    //   125: aload_0
    //   126: getfield d : Ljava/util/Map;
    //   129: invokeinterface putAll : (Ljava/util/Map;)V
    //   134: aload_1
    //   135: monitorexit
    //   136: aload_0
    //   137: getfield a : Ls2/l$a;
    //   140: aload #4
    //   142: aload_2
    //   143: invokevirtual a : ()[B
    //   146: aload #5
    //   148: invokestatic c : (Ls2/l$a;Ljava/lang/String;[BLjava/util/Map;)[B
    //   151: areturn
    //   152: astore_2
    //   153: aload_1
    //   154: monitorexit
    //   155: aload_2
    //   156: athrow
    //   157: new a1/r0
    //   160: dup
    //   161: new s2/p$b
    //   164: dup
    //   165: invokespecial <init> : ()V
    //   168: getstatic android/net/Uri.EMPTY : Landroid/net/Uri;
    //   171: invokevirtual i : (Landroid/net/Uri;)Ls2/p$b;
    //   174: invokevirtual a : ()Ls2/p;
    //   177: getstatic android/net/Uri.EMPTY : Landroid/net/Uri;
    //   180: invokestatic j : ()Li4/r;
    //   183: lconst_0
    //   184: new java/lang/IllegalStateException
    //   187: dup
    //   188: ldc 'No license URL'
    //   190: invokespecial <init> : (Ljava/lang/String;)V
    //   193: invokespecial <init> : (Ls2/p;Landroid/net/Uri;Ljava/util/Map;JLjava/lang/Throwable;)V
    //   196: athrow
    // Exception table:
    //   from	to	target	type
    //   123	136	152	finally
    //   153	155	152	finally
  }
  
  public void e(String paramString1, String paramString2) {
    a.e(paramString1);
    a.e(paramString2);
    synchronized (this.d) {
      this.d.put(paramString1, paramString2);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */