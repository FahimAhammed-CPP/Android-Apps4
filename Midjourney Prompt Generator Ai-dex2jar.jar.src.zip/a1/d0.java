package a1;

import android.media.MediaDrmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import x0.t1;
import z0.b;

public final class d0 implements g0 {
  public void a() {}
  
  public void b(g0.b paramb) {}
  
  public Map<String, String> c(byte[] paramArrayOfbyte) {
    throw new IllegalStateException();
  }
  
  public g0.d d() {
    throw new IllegalStateException();
  }
  
  public b f(byte[] paramArrayOfbyte) {
    throw new IllegalStateException();
  }
  
  public byte[] g() {
    throw new MediaDrmException("Attempting to open a session using a dummy ExoMediaDrm.");
  }
  
  public boolean h(byte[] paramArrayOfbyte, String paramString) {
    throw new IllegalStateException();
  }
  
  public void i(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    throw new IllegalStateException();
  }
  
  public void j(byte[] paramArrayOfbyte) {}
  
  public byte[] k(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    throw new IllegalStateException();
  }
  
  public void l(byte[] paramArrayOfbyte) {
    throw new IllegalStateException();
  }
  
  public g0.a m(byte[] paramArrayOfbyte, List<m.b> paramList, int paramInt, HashMap<String, String> paramHashMap) {
    throw new IllegalStateException();
  }
  
  public int n() {
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */