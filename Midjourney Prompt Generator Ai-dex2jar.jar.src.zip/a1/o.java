package a1;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import z0.b;

public interface o {
  a a();
  
  void b(w.a parama);
  
  UUID c();
  
  void d(w.a parama);
  
  boolean e();
  
  Map<String, String> f();
  
  boolean g(String paramString);
  
  int getState();
  
  b h();
  
  public static class a extends IOException {
    public final int a;
    
    public a(Throwable param1Throwable, int param1Int) {
      super(param1Throwable);
      this.a = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */