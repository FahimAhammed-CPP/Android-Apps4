package a1;

import java.util.UUID;
import z0.b;

public final class h0 implements b {
  public static final boolean d;
  
  public final UUID a;
  
  public final byte[] b;
  
  public final boolean c;
  
  static {
    // Byte code:
    //   0: ldc 'Amazon'
    //   2: getstatic t2/q0.c : Ljava/lang/String;
    //   5: invokevirtual equals : (Ljava/lang/Object;)Z
    //   8: ifeq -> 38
    //   11: getstatic t2/q0.d : Ljava/lang/String;
    //   14: astore_1
    //   15: ldc 'AFTM'
    //   17: aload_1
    //   18: invokevirtual equals : (Ljava/lang/Object;)Z
    //   21: ifne -> 33
    //   24: ldc 'AFTB'
    //   26: aload_1
    //   27: invokevirtual equals : (Ljava/lang/Object;)Z
    //   30: ifeq -> 38
    //   33: iconst_1
    //   34: istore_0
    //   35: goto -> 40
    //   38: iconst_0
    //   39: istore_0
    //   40: iload_0
    //   41: putstatic a1/h0.d : Z
    //   44: return
  }
  
  public h0(UUID paramUUID, byte[] paramArrayOfbyte, boolean paramBoolean) {
    this.a = paramUUID;
    this.b = paramArrayOfbyte;
    this.c = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */