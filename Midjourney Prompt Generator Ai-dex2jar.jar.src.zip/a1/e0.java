package a1;

import java.util.Map;
import java.util.UUID;
import t2.a;
import w0.k;
import z0.b;

public final class e0 implements o {
  private final o.a a;
  
  public e0(o.a parama) {
    this.a = (o.a)a.e(parama);
  }
  
  public o.a a() {
    return this.a;
  }
  
  public void b(w.a parama) {}
  
  public final UUID c() {
    return k.a;
  }
  
  public void d(w.a parama) {}
  
  public boolean e() {
    return false;
  }
  
  public Map<String, String> f() {
    return null;
  }
  
  public boolean g(String paramString) {
    return false;
  }
  
  public int getState() {
    return 1;
  }
  
  public b h() {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */