package a1;

import android.os.Looper;
import w0.p1;
import x0.t1;

public interface y {
  public static final y a;
  
  @Deprecated
  public static final y b;
  
  static {
    a a = new a();
    a = a;
    b = a;
  }
  
  void a();
  
  void c();
  
  o d(w.a parama, p1 paramp1);
  
  void e(Looper paramLooper, t1 paramt1);
  
  int f(p1 paramp1);
  
  b g(w.a parama, p1 paramp1);
  
  class a implements y {
    public o d(w.a param1a, p1 param1p1) {
      return (param1p1.o == null) ? null : new e0(new o.a(new s0(1), 6001));
    }
    
    public void e(Looper param1Looper, t1 param1t1) {}
    
    public int f(p1 param1p1) {
      return (param1p1.o != null) ? 1 : 0;
    }
  }
  
  public static interface b {
    public static final b a = new z();
    
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */