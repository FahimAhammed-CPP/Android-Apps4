package a1;

import java.util.UUID;

public interface q0 {
  byte[] a(UUID paramUUID, g0.d paramd);
  
  byte[] b(UUID paramUUID, g0.a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */