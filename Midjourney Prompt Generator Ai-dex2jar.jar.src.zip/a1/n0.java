package a1;

import android.media.MediaCrypto;
import android.media.MediaCryptoException;
import android.media.MediaDrm;
import android.media.UnsupportedSchemeException;
import android.media.metrics.LogSessionId;
import android.text.TextUtils;
import h4.d;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import t2.c0;
import t2.q0;
import t2.r;
import w0.k;
import x0.t1;
import z0.b;

public final class n0 implements g0 {
  public static final g0.c d = new j0();
  
  private final UUID a;
  
  private final MediaDrm b;
  
  private int c;
  
  private n0(UUID paramUUID) {
    t2.a.e(paramUUID);
    t2.a.b(k.b.equals(paramUUID) ^ true, "Use C.CLEARKEY_UUID instead");
    this.a = paramUUID;
    MediaDrm mediaDrm = new MediaDrm(v(paramUUID));
    this.b = mediaDrm;
    this.c = 1;
    if (k.d.equals(paramUUID) && C())
      x(mediaDrm); 
  }
  
  private static boolean C() {
    return "ASUS_Z00AD".equals(q0.d);
  }
  
  public static n0 D(UUID paramUUID) {
    try {
      return new n0(paramUUID);
    } catch (UnsupportedSchemeException unsupportedSchemeException) {
      throw new s0(1, unsupportedSchemeException);
    } catch (Exception exception) {
      throw new s0(2, exception);
    } 
  }
  
  private static byte[] q(byte[] paramArrayOfbyte) {
    c0 c0 = new c0(paramArrayOfbyte);
    int i = c0.r();
    short s1 = c0.t();
    short s2 = c0.t();
    if (s1 != 1 || s2 != 1) {
      r.f("FrameworkMediaDrm", "Unexpected record count or type. Skipping LA_URL workaround.");
      return paramArrayOfbyte;
    } 
    short s3 = c0.t();
    Charset charset = d.e;
    String str2 = c0.C(s3, charset);
    if (str2.contains("<LA_URL>"))
      return paramArrayOfbyte; 
    int j = str2.indexOf("</DATA>");
    if (j == -1)
      r.i("FrameworkMediaDrm", "Could not find the </DATA> tag. Skipping LA_URL workaround."); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str2.substring(0, j));
    stringBuilder.append("<LA_URL>https://x</LA_URL>");
    stringBuilder.append(str2.substring(j));
    String str1 = stringBuilder.toString();
    i += 52;
    ByteBuffer byteBuffer = ByteBuffer.allocate(i);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byteBuffer.putInt(i);
    byteBuffer.putShort((short)s1);
    byteBuffer.putShort((short)s2);
    byteBuffer.putShort((short)(str1.length() * 2));
    byteBuffer.put(str1.getBytes(charset));
    return byteBuffer.array();
  }
  
  private static String r(String paramString) {
    return "<LA_URL>https://x</LA_URL>".equals(paramString) ? "" : ((q0.a == 33 && "https://default.url".equals(paramString)) ? "" : paramString);
  }
  
  private static byte[] s(UUID paramUUID, byte[] paramArrayOfbyte) {
    return k.c.equals(paramUUID) ? a.a(paramArrayOfbyte) : paramArrayOfbyte;
  }
  
  private static byte[] t(UUID paramUUID, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: getstatic w0/k.e : Ljava/util/UUID;
    //   3: astore_3
    //   4: aload_1
    //   5: astore_2
    //   6: aload_3
    //   7: aload_0
    //   8: invokevirtual equals : (Ljava/lang/Object;)Z
    //   11: ifeq -> 38
    //   14: aload_1
    //   15: aload_0
    //   16: invokestatic e : ([BLjava/util/UUID;)[B
    //   19: astore_2
    //   20: aload_2
    //   21: ifnonnull -> 27
    //   24: goto -> 29
    //   27: aload_2
    //   28: astore_1
    //   29: aload_3
    //   30: aload_1
    //   31: invokestatic q : ([B)[B
    //   34: invokestatic a : (Ljava/util/UUID;[B)[B
    //   37: astore_2
    //   38: getstatic t2/q0.a : I
    //   41: bipush #23
    //   43: if_icmpge -> 56
    //   46: getstatic w0/k.d : Ljava/util/UUID;
    //   49: aload_0
    //   50: invokevirtual equals : (Ljava/lang/Object;)Z
    //   53: ifne -> 120
    //   56: aload_3
    //   57: aload_0
    //   58: invokevirtual equals : (Ljava/lang/Object;)Z
    //   61: ifeq -> 132
    //   64: ldc_w 'Amazon'
    //   67: getstatic t2/q0.c : Ljava/lang/String;
    //   70: invokevirtual equals : (Ljava/lang/Object;)Z
    //   73: ifeq -> 132
    //   76: getstatic t2/q0.d : Ljava/lang/String;
    //   79: astore_1
    //   80: ldc_w 'AFTB'
    //   83: aload_1
    //   84: invokevirtual equals : (Ljava/lang/Object;)Z
    //   87: ifne -> 120
    //   90: ldc_w 'AFTS'
    //   93: aload_1
    //   94: invokevirtual equals : (Ljava/lang/Object;)Z
    //   97: ifne -> 120
    //   100: ldc_w 'AFTM'
    //   103: aload_1
    //   104: invokevirtual equals : (Ljava/lang/Object;)Z
    //   107: ifne -> 120
    //   110: ldc_w 'AFTT'
    //   113: aload_1
    //   114: invokevirtual equals : (Ljava/lang/Object;)Z
    //   117: ifeq -> 132
    //   120: aload_2
    //   121: aload_0
    //   122: invokestatic e : ([BLjava/util/UUID;)[B
    //   125: astore_0
    //   126: aload_0
    //   127: ifnull -> 132
    //   130: aload_0
    //   131: areturn
    //   132: aload_2
    //   133: areturn
  }
  
  private static String u(UUID paramUUID, String paramString) {
    return (q0.a < 26 && k.c.equals(paramUUID) && ("video/mp4".equals(paramString) || "audio/mp4".equals(paramString))) ? "cenc" : paramString;
  }
  
  private static UUID v(UUID paramUUID) {
    UUID uUID = paramUUID;
    if (q0.a < 27) {
      uUID = paramUUID;
      if (k.c.equals(paramUUID))
        uUID = k.b; 
    } 
    return uUID;
  }
  
  private static void x(MediaDrm paramMediaDrm) {
    paramMediaDrm.setPropertyString("securityLevel", "L3");
  }
  
  private static m.b z(UUID paramUUID, List<m.b> paramList) {
    // Byte code:
    //   0: getstatic w0/k.d : Ljava/util/UUID;
    //   3: aload_0
    //   4: invokevirtual equals : (Ljava/lang/Object;)Z
    //   7: ifne -> 21
    //   10: aload_1
    //   11: iconst_0
    //   12: invokeinterface get : (I)Ljava/lang/Object;
    //   17: checkcast a1/m$b
    //   20: areturn
    //   21: getstatic t2/q0.a : I
    //   24: bipush #28
    //   26: if_icmplt -> 226
    //   29: aload_1
    //   30: invokeinterface size : ()I
    //   35: iconst_1
    //   36: if_icmple -> 226
    //   39: aload_1
    //   40: iconst_0
    //   41: invokeinterface get : (I)Ljava/lang/Object;
    //   46: checkcast a1/m$b
    //   49: astore_0
    //   50: iconst_0
    //   51: istore_3
    //   52: iconst_0
    //   53: istore_2
    //   54: iload_3
    //   55: aload_1
    //   56: invokeinterface size : ()I
    //   61: if_icmpge -> 145
    //   64: aload_1
    //   65: iload_3
    //   66: invokeinterface get : (I)Ljava/lang/Object;
    //   71: checkcast a1/m$b
    //   74: astore #5
    //   76: aload #5
    //   78: getfield e : [B
    //   81: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   84: checkcast [B
    //   87: astore #6
    //   89: aload #5
    //   91: getfield d : Ljava/lang/String;
    //   94: aload_0
    //   95: getfield d : Ljava/lang/String;
    //   98: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   101: ifeq -> 140
    //   104: aload #5
    //   106: getfield c : Ljava/lang/String;
    //   109: aload_0
    //   110: getfield c : Ljava/lang/String;
    //   113: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   116: ifeq -> 140
    //   119: aload #6
    //   121: invokestatic c : ([B)Z
    //   124: ifeq -> 140
    //   127: iload_2
    //   128: aload #6
    //   130: arraylength
    //   131: iadd
    //   132: istore_2
    //   133: iload_3
    //   134: iconst_1
    //   135: iadd
    //   136: istore_3
    //   137: goto -> 54
    //   140: iconst_0
    //   141: istore_3
    //   142: goto -> 147
    //   145: iconst_1
    //   146: istore_3
    //   147: iload_3
    //   148: ifeq -> 226
    //   151: iload_2
    //   152: newarray byte
    //   154: astore #5
    //   156: iconst_0
    //   157: istore_2
    //   158: iconst_0
    //   159: istore_3
    //   160: iload_2
    //   161: aload_1
    //   162: invokeinterface size : ()I
    //   167: if_icmpge -> 219
    //   170: aload_1
    //   171: iload_2
    //   172: invokeinterface get : (I)Ljava/lang/Object;
    //   177: checkcast a1/m$b
    //   180: getfield e : [B
    //   183: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   186: checkcast [B
    //   189: astore #6
    //   191: aload #6
    //   193: arraylength
    //   194: istore #4
    //   196: aload #6
    //   198: iconst_0
    //   199: aload #5
    //   201: iload_3
    //   202: iload #4
    //   204: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   207: iload_3
    //   208: iload #4
    //   210: iadd
    //   211: istore_3
    //   212: iload_2
    //   213: iconst_1
    //   214: iadd
    //   215: istore_2
    //   216: goto -> 160
    //   219: aload_0
    //   220: aload #5
    //   222: invokevirtual b : ([B)La1/m$b;
    //   225: areturn
    //   226: iconst_0
    //   227: istore_2
    //   228: iload_2
    //   229: aload_1
    //   230: invokeinterface size : ()I
    //   235: if_icmpge -> 302
    //   238: aload_1
    //   239: iload_2
    //   240: invokeinterface get : (I)Ljava/lang/Object;
    //   245: checkcast a1/m$b
    //   248: astore_0
    //   249: aload_0
    //   250: getfield e : [B
    //   253: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   256: checkcast [B
    //   259: invokestatic g : ([B)I
    //   262: istore_3
    //   263: getstatic t2/q0.a : I
    //   266: istore #4
    //   268: iload #4
    //   270: bipush #23
    //   272: if_icmpge -> 281
    //   275: iload_3
    //   276: ifne -> 281
    //   279: aload_0
    //   280: areturn
    //   281: iload #4
    //   283: bipush #23
    //   285: if_icmplt -> 295
    //   288: iload_3
    //   289: iconst_1
    //   290: if_icmpne -> 295
    //   293: aload_0
    //   294: areturn
    //   295: iload_2
    //   296: iconst_1
    //   297: iadd
    //   298: istore_2
    //   299: goto -> 228
    //   302: aload_1
    //   303: iconst_0
    //   304: invokeinterface get : (I)Ljava/lang/Object;
    //   309: checkcast a1/m$b
    //   312: areturn
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : I
    //   6: iconst_1
    //   7: isub
    //   8: istore_1
    //   9: aload_0
    //   10: iload_1
    //   11: putfield c : I
    //   14: iload_1
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield b : Landroid/media/MediaDrm;
    //   22: invokevirtual release : ()V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_2
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_2
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	28	finally
    //   18	25	28	finally
  }
  
  public void b(g0.b paramb) {
    k0 k0;
    MediaDrm mediaDrm = this.b;
    if (paramb == null) {
      paramb = null;
    } else {
      k0 = new k0(this, paramb);
    } 
    mediaDrm.setOnEventListener(k0);
  }
  
  public Map<String, String> c(byte[] paramArrayOfbyte) {
    return this.b.queryKeyStatus(paramArrayOfbyte);
  }
  
  public g0.d d() {
    MediaDrm.ProvisionRequest provisionRequest = this.b.getProvisionRequest();
    return new g0.d(provisionRequest.getData(), provisionRequest.getDefaultUrl());
  }
  
  public void e(byte[] paramArrayOfbyte, t1 paramt1) {
    if (q0.a >= 31)
      try {
        a.b(this.b, paramArrayOfbyte, paramt1);
        return;
      } catch (UnsupportedOperationException unsupportedOperationException) {
        r.i("FrameworkMediaDrm", "setLogSessionId failed.");
      }  
  }
  
  public byte[] g() {
    return this.b.openSession();
  }
  
  public boolean h(byte[] paramArrayOfbyte, String paramString) {
    if (q0.a >= 31)
      return a.a(this.b, paramString); 
    try {
      MediaCrypto mediaCrypto = new MediaCrypto(this.a, paramArrayOfbyte);
      try {
        return mediaCrypto.requiresSecureDecoderComponent(paramString);
      } finally {
        mediaCrypto.release();
      } 
    } catch (MediaCryptoException mediaCryptoException) {
      return true;
    } 
  }
  
  public void i(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.b.restoreKeys(paramArrayOfbyte1, paramArrayOfbyte2);
  }
  
  public void j(byte[] paramArrayOfbyte) {
    this.b.closeSession(paramArrayOfbyte);
  }
  
  public byte[] k(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    byte[] arrayOfByte = paramArrayOfbyte2;
    if (k.c.equals(this.a))
      arrayOfByte = a.b(paramArrayOfbyte2); 
    return this.b.provideKeyResponse(paramArrayOfbyte1, arrayOfByte);
  }
  
  public void l(byte[] paramArrayOfbyte) {
    this.b.provideProvisionResponse(paramArrayOfbyte);
  }
  
  public g0.a m(byte[] paramArrayOfbyte, List<m.b> paramList, int paramInt, HashMap<String, String> paramHashMap) {
    MediaDrm.KeyRequest keyRequest2;
    List list = null;
    if (paramList != null) {
      m.b b = z(this.a, paramList);
      keyRequest1 = (MediaDrm.KeyRequest)t(this.a, (byte[])t2.a.e(b.e));
      keyRequest2 = (MediaDrm.KeyRequest)u(this.a, b.d);
    } else {
      keyRequest1 = null;
      keyRequest2 = keyRequest1;
      paramList = list;
    } 
    MediaDrm.KeyRequest keyRequest1 = this.b.getKeyRequest(paramArrayOfbyte, (byte[])keyRequest1, (String)keyRequest2, paramInt, paramHashMap);
    byte[] arrayOfByte = s(this.a, keyRequest1.getData());
    String str2 = r(keyRequest1.getDefaultUrl());
    String str1 = str2;
    if (TextUtils.isEmpty(str2)) {
      str1 = str2;
      if (paramList != null) {
        str1 = str2;
        if (!TextUtils.isEmpty(((m.b)paramList).c))
          str1 = ((m.b)paramList).c; 
      } 
    } 
    if (q0.a >= 23) {
      paramInt = i0.a(keyRequest1);
    } else {
      paramInt = Integer.MIN_VALUE;
    } 
    return new g0.a(arrayOfByte, str1, paramInt);
  }
  
  public int n() {
    return 2;
  }
  
  public h0 w(byte[] paramArrayOfbyte) {
    boolean bool;
    if (q0.a < 21 && k.d.equals(this.a) && "L3".equals(y("securityLevel"))) {
      bool = true;
    } else {
      bool = false;
    } 
    return new h0(v(this.a), paramArrayOfbyte, bool);
  }
  
  public String y(String paramString) {
    return this.b.getPropertyString(paramString);
  }
  
  private static class a {
    public static boolean a(MediaDrm param1MediaDrm, String param1String) {
      return m0.a(param1MediaDrm, param1String);
    }
    
    public static void b(MediaDrm param1MediaDrm, byte[] param1ArrayOfbyte, t1 param1t1) {
      LogSessionId logSessionId = param1t1.a();
      if (!logSessionId.equals(LogSessionId.LOG_SESSION_ID_NONE))
        ((MediaDrm.PlaybackComponent)t2.a.e(l0.a(param1MediaDrm, param1ArrayOfbyte))).setLogSessionId(logSessionId); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */