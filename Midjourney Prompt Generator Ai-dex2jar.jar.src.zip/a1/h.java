package a1;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import i4.p0;
import i4.q;
import i4.s;
import i4.s0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import s2.g0;
import s2.x;
import t2.q0;
import t2.r;
import t2.v;
import w0.k;
import w0.p1;
import x0.t1;

public class h implements y {
  private final UUID c;
  
  private final g0.c d;
  
  private final q0 e;
  
  private final HashMap<String, String> f;
  
  private final boolean g;
  
  private final int[] h;
  
  private final boolean i;
  
  private final g j;
  
  private final g0 k;
  
  private final h l;
  
  private final long m;
  
  private final List<g> n;
  
  private final Set<f> o;
  
  private final Set<g> p;
  
  private int q;
  
  private g0 r;
  
  private g s;
  
  private g t;
  
  private Looper u;
  
  private Handler v;
  
  private int w;
  
  private byte[] x;
  
  private t1 y;
  
  volatile d z;
  
  private h(UUID paramUUID, g0.c paramc, q0 paramq0, HashMap<String, String> paramHashMap, boolean paramBoolean1, int[] paramArrayOfint, boolean paramBoolean2, g0 paramg0, long paramLong) {
    t2.a.e(paramUUID);
    t2.a.b(k.b.equals(paramUUID) ^ true, "Use C.CLEARKEY_UUID instead");
    this.c = paramUUID;
    this.d = paramc;
    this.e = paramq0;
    this.f = paramHashMap;
    this.g = paramBoolean1;
    this.h = paramArrayOfint;
    this.i = paramBoolean2;
    this.k = paramg0;
    this.j = new g(this);
    this.l = new h(null);
    this.w = 0;
    this.n = new ArrayList<g>();
    this.o = p0.h();
    this.p = p0.h();
    this.m = paramLong;
  }
  
  private void A(Looper paramLooper) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield u : Landroid/os/Looper;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnonnull -> 51
    //   11: aload_0
    //   12: aload_1
    //   13: putfield u : Landroid/os/Looper;
    //   16: aload_0
    //   17: new android/os/Handler
    //   20: dup
    //   21: aload_1
    //   22: invokespecial <init> : (Landroid/os/Looper;)V
    //   25: putfield v : Landroid/os/Handler;
    //   28: goto -> 43
    //   31: iload_2
    //   32: invokestatic f : (Z)V
    //   35: aload_0
    //   36: getfield v : Landroid/os/Handler;
    //   39: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   42: pop
    //   43: aload_0
    //   44: monitorexit
    //   45: return
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    //   51: aload_3
    //   52: aload_1
    //   53: if_acmpne -> 61
    //   56: iconst_1
    //   57: istore_2
    //   58: goto -> 31
    //   61: iconst_0
    //   62: istore_2
    //   63: goto -> 31
    // Exception table:
    //   from	to	target	type
    //   2	7	46	finally
    //   11	28	46	finally
    //   31	43	46	finally
  }
  
  private o B(int paramInt, boolean paramBoolean) {
    boolean bool;
    g0 g01 = (g0)t2.a.e(this.r);
    if (g01.n() == 2 && h0.d) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && q0.y0(this.h, paramInt) != -1) {
      if (g01.n() == 1)
        return null; 
      g g1 = this.s;
      if (g1 == null) {
        g1 = y((List<m.b>)q.z(), true, null, paramBoolean);
        this.n.add(g1);
        this.s = g1;
      } else {
        g1.d(null);
      } 
      return this.s;
    } 
    return null;
  }
  
  private void C(Looper paramLooper) {
    if (this.z == null)
      this.z = new d(this, paramLooper); 
  }
  
  private void D() {
    if (this.r != null && this.q == 0 && this.n.isEmpty() && this.o.isEmpty()) {
      ((g0)t2.a.e(this.r)).a();
      this.r = null;
    } 
  }
  
  private void E() {
    s0<o> s0 = s.t(this.p).q();
    while (s0.hasNext())
      ((o)s0.next()).b(null); 
  }
  
  private void F() {
    s0<f> s0 = s.t(this.o).q();
    while (s0.hasNext())
      ((f)s0.next()).a(); 
  }
  
  private void H(o paramo, w.a parama) {
    paramo.b(parama);
    if (this.m != -9223372036854775807L)
      paramo.b(null); 
  }
  
  private o u(Looper paramLooper, w.a parama, p1 paramp1, boolean paramBoolean) {
    g g1;
    C(paramLooper);
    m m1 = paramp1.o;
    if (m1 == null)
      return B(v.k(paramp1.l), paramBoolean); 
    byte[] arrayOfByte = this.x;
    m m2 = null;
    if (arrayOfByte == null) {
      List<m.b> list1 = z((m)t2.a.e(m1), this.c, false);
      List<m.b> list2 = list1;
      if (list1.isEmpty()) {
        e e = new e(this.c, null);
        r.d("DefaultDrmSessionMgr", "DRM error", e);
        if (parama != null)
          parama.l(e); 
        return new e0(new o.a(e, 6003));
      } 
    } else {
      arrayOfByte = null;
    } 
    if (!this.g) {
      g1 = this.t;
    } else {
      Iterator<g> iterator = this.n.iterator();
      while (true) {
        m1 = m2;
        if (iterator.hasNext()) {
          g1 = iterator.next();
          if (q0.c(g1.a, arrayOfByte))
            break; 
          continue;
        } 
        break;
      } 
    } 
    if (g1 == null) {
      g1 = y((List<m.b>)arrayOfByte, false, parama, paramBoolean);
      if (!this.g)
        this.t = g1; 
      this.n.add(g1);
      return g1;
    } 
    g1.d(parama);
    return g1;
  }
  
  private static boolean v(o paramo) {
    int i = paramo.getState();
    null = true;
    if (i == 1)
      if (q0.a >= 19) {
        if (((o.a)t2.a.e(paramo.a())).getCause() instanceof android.media.ResourceBusyException)
          return true; 
      } else {
        return null;
      }  
    return false;
  }
  
  private boolean w(m paramm) {
    if (this.x != null)
      return true; 
    if (z(paramm, this.c, true).isEmpty())
      if (paramm.d == 1 && paramm.e(0).d(k.b)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DrmInitData only contains common PSSH SchemeData. Assuming support for: ");
        stringBuilder.append(this.c);
        r.i("DefaultDrmSessionMgr", stringBuilder.toString());
      } else {
        return false;
      }  
    String str = paramm.c;
    return (str != null) ? ("cenc".equals(str) ? true : ("cbcs".equals(str) ? ((q0.a >= 25)) : (!"cbc1".equals(str) ? (!"cens".equals(str)) : false))) : true;
  }
  
  private g x(List<m.b> paramList, boolean paramBoolean, w.a parama) {
    t2.a.e(this.r);
    boolean bool = this.i;
    g g1 = new g(this.c, this.r, this.j, this.l, paramList, this.w, bool | paramBoolean, paramBoolean, this.x, this.f, this.e, (Looper)t2.a.e(this.u), this.k, (t1)t2.a.e(this.y));
    g1.d(parama);
    if (this.m != -9223372036854775807L)
      g1.d(null); 
    return g1;
  }
  
  private g y(List<m.b> paramList, boolean paramBoolean1, w.a parama, boolean paramBoolean2) {
    g g2 = x(paramList, paramBoolean1, parama);
    g g1 = g2;
    if (v(g2)) {
      g1 = g2;
      if (!this.p.isEmpty()) {
        E();
        H(g2, parama);
        g1 = x(paramList, paramBoolean1, parama);
      } 
    } 
    g2 = g1;
    if (v(g1)) {
      g2 = g1;
      if (paramBoolean2) {
        g2 = g1;
        if (!this.o.isEmpty()) {
          F();
          if (!this.p.isEmpty())
            E(); 
          H(g1, parama);
          g2 = x(paramList, paramBoolean1, parama);
        } 
      } 
    } 
    return g2;
  }
  
  private static List<m.b> z(m paramm, UUID paramUUID, boolean paramBoolean) {
    ArrayList<m.b> arrayList = new ArrayList(paramm.d);
    for (int i = 0; i < paramm.d; i++) {
      boolean bool;
      m.b b = paramm.e(i);
      if (b.d(paramUUID) || (k.c.equals(paramUUID) && b.d(k.b))) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && (b.e != null || paramBoolean))
        arrayList.add(b); 
    } 
    return arrayList;
  }
  
  public void G(int paramInt, byte[] paramArrayOfbyte) {
    t2.a.f(this.n.isEmpty());
    if (paramInt == 1 || paramInt == 3)
      t2.a.e(paramArrayOfbyte); 
    this.w = paramInt;
    this.x = paramArrayOfbyte;
  }
  
  public final void a() {
    int i = this.q - 1;
    this.q = i;
    if (i != 0)
      return; 
    if (this.m != -9223372036854775807L) {
      ArrayList<g> arrayList = new ArrayList<g>(this.n);
      for (i = 0; i < arrayList.size(); i++)
        ((g)arrayList.get(i)).b(null); 
    } 
    F();
    D();
  }
  
  public final void c() {
    int i = this.q;
    this.q = i + 1;
    if (i != 0)
      return; 
    if (this.r == null) {
      g0 g01 = this.d.a(this.c);
      this.r = g01;
      g01.b(new c(null));
      return;
    } 
    if (this.m != -9223372036854775807L)
      for (i = 0; i < this.n.size(); i++)
        ((g)this.n.get(i)).d(null);  
  }
  
  public o d(w.a parama, p1 paramp1) {
    boolean bool;
    if (this.q > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    t2.a.f(bool);
    t2.a.h(this.u);
    return u(this.u, parama, paramp1, true);
  }
  
  public void e(Looper paramLooper, t1 paramt1) {
    A(paramLooper);
    this.y = paramt1;
  }
  
  public int f(p1 paramp1) {
    int i = ((g0)t2.a.e(this.r)).n();
    m m = paramp1.o;
    if (m == null) {
      int j = v.k(paramp1.l);
      return (q0.y0(this.h, j) != -1) ? i : 0;
    } 
    return w(m) ? i : 1;
  }
  
  public y.b g(w.a parama, p1 paramp1) {
    boolean bool;
    if (this.q > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    t2.a.f(bool);
    t2.a.h(this.u);
    f f = new f(this, parama);
    f.d(paramp1);
    return f;
  }
  
  public static final class b {
    private final HashMap<String, String> a = new HashMap<String, String>();
    
    private UUID b = k.d;
    
    private g0.c c = n0.d;
    
    private boolean d;
    
    private int[] e = new int[0];
    
    private boolean f;
    
    private g0 g = (g0)new x();
    
    private long h = 300000L;
    
    public h a(q0 param1q0) {
      return new h(this.b, this.c, param1q0, this.a, this.d, this.e, this.f, this.g, this.h, null);
    }
    
    public b b(boolean param1Boolean) {
      this.d = param1Boolean;
      return this;
    }
    
    public b c(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    public b d(int... param1VarArgs) {
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++) {
        int k = param1VarArgs[i];
        boolean bool2 = true;
        boolean bool1 = bool2;
        if (k != 2)
          if (k == 1) {
            bool1 = bool2;
          } else {
            bool1 = false;
          }  
        t2.a.a(bool1);
      } 
      this.e = (int[])param1VarArgs.clone();
      return this;
    }
    
    public b e(UUID param1UUID, g0.c param1c) {
      this.b = (UUID)t2.a.e(param1UUID);
      this.c = (g0.c)t2.a.e(param1c);
      return this;
    }
  }
  
  private class c implements g0.b {
    private c(h this$0) {}
    
    public void a(g0 param1g0, byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2) {
      ((h.d)t2.a.e(this.a.z)).obtainMessage(param1Int1, param1ArrayOfbyte1).sendToTarget();
    }
  }
  
  private class d extends Handler {
    public d(h this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      byte[] arrayOfByte = (byte[])param1Message.obj;
      if (arrayOfByte == null)
        return; 
      for (g g : h.n(this.a)) {
        if (g.q(arrayOfByte)) {
          g.y(param1Message.what);
          break;
        } 
      } 
    }
  }
  
  public static final class e extends Exception {
    private e(UUID param1UUID) {
      super(stringBuilder.toString());
    }
  }
  
  private class f implements y.b {
    private final w.a b;
    
    private o c;
    
    private boolean d;
    
    public f(h this$0, w.a param1a) {
      this.b = param1a;
    }
    
    public void a() {
      q0.K0((Handler)t2.a.e(h.q(this.e)), new i(this));
    }
    
    public void d(p1 param1p1) {
      ((Handler)t2.a.e(h.q(this.e))).post(new j(this, param1p1));
    }
  }
  
  private class g implements g.a {
    private final Set<g> a = new HashSet<g>();
    
    private g b;
    
    public g(h this$0) {}
    
    public void a(g param1g) {
      this.a.add(param1g);
      if (this.b != null)
        return; 
      this.b = param1g;
      param1g.E();
    }
    
    public void b(Exception param1Exception, boolean param1Boolean) {
      this.b = null;
      q q = q.v(this.a);
      this.a.clear();
      s0<g> s0 = q.q();
      while (s0.hasNext())
        ((g)s0.next()).A(param1Exception, param1Boolean); 
    }
    
    public void c() {
      this.b = null;
      q q = q.v(this.a);
      this.a.clear();
      s0<g> s0 = q.q();
      while (s0.hasNext())
        ((g)s0.next()).z(); 
    }
    
    public void d(g param1g) {
      this.a.remove(param1g);
      if (this.b == param1g) {
        this.b = null;
        if (!this.a.isEmpty()) {
          param1g = this.a.iterator().next();
          this.b = param1g;
          param1g.E();
        } 
      } 
    }
  }
  
  private class h implements g.b {
    private h(h this$0) {}
    
    public void a(g param1g, int param1Int) {
      if (h.o(this.a) != -9223372036854775807L) {
        h.p(this.a).remove(param1g);
        ((Handler)t2.a.e(h.q(this.a))).removeCallbacksAndMessages(param1g);
      } 
    }
    
    public void b(g param1g, int param1Int) {
      if (param1Int == 1 && h.r(this.a) > 0 && h.o(this.a) != -9223372036854775807L) {
        h.p(this.a).add(param1g);
        ((Handler)t2.a.e(h.q(this.a))).postAtTime(new k(param1g), param1g, SystemClock.uptimeMillis() + h.o(this.a));
      } else if (param1Int == 0) {
        h.n(this.a).remove(param1g);
        if (h.s(this.a) == param1g)
          h.t(this.a, null); 
        if (h.b(this.a) == param1g)
          h.h(this.a, null); 
        h.i(this.a).d(param1g);
        if (h.o(this.a) != -9223372036854775807L) {
          ((Handler)t2.a.e(h.q(this.a))).removeCallbacksAndMessages(param1g);
          h.p(this.a).remove(param1g);
        } 
      } 
      h.j(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */