package a1;

import android.os.Handler;
import java.util.concurrent.CopyOnWriteArrayList;
import t2.q0;
import y1.u;

public interface w {
  void D(int paramInt, u.b paramb);
  
  void F(int paramInt, u.b paramb);
  
  @Deprecated
  void G(int paramInt, u.b paramb);
  
  void H(int paramInt, u.b paramb, Exception paramException);
  
  void J(int paramInt, u.b paramb);
  
  void V(int paramInt1, u.b paramb, int paramInt2);
  
  void l0(int paramInt, u.b paramb);
  
  public static class a {
    public final int a;
    
    public final u.b b;
    
    private final CopyOnWriteArrayList<a> c;
    
    public a() {
      this(new CopyOnWriteArrayList<a>(), 0, null);
    }
    
    private a(CopyOnWriteArrayList<a> param1CopyOnWriteArrayList, int param1Int, u.b param1b) {
      this.c = param1CopyOnWriteArrayList;
      this.a = param1Int;
      this.b = param1b;
    }
    
    public void g(Handler param1Handler, w param1w) {
      t2.a.e(param1Handler);
      t2.a.e(param1w);
      this.c.add(new a(param1Handler, param1w));
    }
    
    public void h() {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new u(this, w));
      } 
    }
    
    public void i() {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new t(this, w));
      } 
    }
    
    public void j() {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new v(this, w));
      } 
    }
    
    public void k(int param1Int) {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new s(this, w, param1Int));
      } 
    }
    
    public void l(Exception param1Exception) {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new r(this, w, param1Exception));
      } 
    }
    
    public void m() {
      for (a a1 : this.c) {
        w w = a1.b;
        q0.K0(a1.a, new q(this, w));
      } 
    }
    
    public void t(w param1w) {
      for (a a1 : this.c) {
        if (a1.b == param1w)
          this.c.remove(a1); 
      } 
    }
    
    public a u(int param1Int, u.b param1b) {
      return new a(this.c, param1Int, param1b);
    }
    
    private static final class a {
      public Handler a;
      
      public w b;
      
      public a(Handler param2Handler, w param2w) {
        this.a = param2Handler;
        this.b = param2w;
      }
    }
  }
  
  private static final class a {
    public Handler a;
    
    public w b;
    
    public a(Handler param1Handler, w param1w) {
      this.a = param1Handler;
      this.b = param1w;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a1\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */