package a8;

import android.os.Bundle;

public class a {
  public static String b = "query_info_type";
  
  public static String c = "requester_type_5";
  
  public static String d = "UnityScar";
  
  private String a;
  
  public a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder(d);
    stringBuilder.append(paramString);
    this.a = stringBuilder.toString();
  }
  
  public Bundle a() {
    Bundle bundle = new Bundle();
    bundle.putString(b, c);
    return bundle;
  }
  
  public String b() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */