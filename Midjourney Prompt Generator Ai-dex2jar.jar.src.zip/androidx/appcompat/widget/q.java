package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.res.h;
import androidx.core.widget.b;
import c.j;
import java.lang.ref.WeakReference;

class q {
  private final TextView a;
  
  private n0 b;
  
  private n0 c;
  
  private n0 d;
  
  private n0 e;
  
  private n0 f;
  
  private n0 g;
  
  @NonNull
  private final u h;
  
  private int i = 0;
  
  private Typeface j;
  
  private boolean k;
  
  q(TextView paramTextView) {
    this.a = paramTextView;
    this.h = new u(paramTextView);
  }
  
  private void a(Drawable paramDrawable, n0 paramn0) {
    if (paramDrawable != null && paramn0 != null)
      f.B(paramDrawable, paramn0, this.a.getDrawableState()); 
  }
  
  private static n0 d(Context paramContext, f paramf, int paramInt) {
    ColorStateList colorStateList = paramf.s(paramContext, paramInt);
    if (colorStateList != null) {
      n0 n01 = new n0();
      n01.d = true;
      n01.a = colorStateList;
      return n01;
    } 
    return null;
  }
  
  private void t(int paramInt, float paramFloat) {
    this.h.t(paramInt, paramFloat);
  }
  
  private void u(Context paramContext, p0 paramp0) {
    this.i = paramp0.i(j.m2, this.i);
    int i = j.q2;
    boolean bool1 = paramp0.p(i);
    boolean bool = false;
    if (bool1 || paramp0.p(j.r2)) {
      this.j = null;
      int j = j.r2;
      if (paramp0.p(j))
        i = j; 
      if (!paramContext.isRestricted()) {
        a a = new a(this, new WeakReference<TextView>(this.a));
        try {
          Typeface typeface = paramp0.h(i, this.i, a);
          this.j = typeface;
          if (typeface == null)
            bool = true; 
          this.k = bool;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.j == null) {
        String str = paramp0.m(i);
        if (str != null)
          this.j = Typeface.create(str, this.i); 
      } 
      return;
    } 
    i = j.l2;
    if (paramp0.p(i)) {
      this.k = false;
      i = paramp0.i(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.j = Typeface.MONOSPACE;
          return;
        } 
        this.j = Typeface.SERIF;
        return;
      } 
      this.j = Typeface.SANS_SERIF;
    } 
  }
  
  void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  void c() {
    this.h.a();
  }
  
  int e() {
    return this.h.g();
  }
  
  int f() {
    return this.h.h();
  }
  
  int g() {
    return this.h.i();
  }
  
  int[] h() {
    return this.h.j();
  }
  
  int i() {
    return this.h.k();
  }
  
  boolean j() {
    return this.h.n();
  }
  
  void k(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #16
    //   9: invokestatic n : ()Landroidx/appcompat/widget/f;
    //   12: astore #10
    //   14: aload #16
    //   16: aload_1
    //   17: getstatic c/j.Y : [I
    //   20: iload_2
    //   21: iconst_0
    //   22: invokestatic s : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   25: astore #11
    //   27: aload #11
    //   29: getstatic c/j.Z : I
    //   32: iconst_m1
    //   33: invokevirtual l : (II)I
    //   36: istore_3
    //   37: getstatic c/j.c0 : I
    //   40: istore #4
    //   42: aload #11
    //   44: iload #4
    //   46: invokevirtual p : (I)Z
    //   49: ifeq -> 71
    //   52: aload_0
    //   53: aload #16
    //   55: aload #10
    //   57: aload #11
    //   59: iload #4
    //   61: iconst_0
    //   62: invokevirtual l : (II)I
    //   65: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   68: putfield b : Landroidx/appcompat/widget/n0;
    //   71: getstatic c/j.a0 : I
    //   74: istore #4
    //   76: aload #11
    //   78: iload #4
    //   80: invokevirtual p : (I)Z
    //   83: ifeq -> 105
    //   86: aload_0
    //   87: aload #16
    //   89: aload #10
    //   91: aload #11
    //   93: iload #4
    //   95: iconst_0
    //   96: invokevirtual l : (II)I
    //   99: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   102: putfield c : Landroidx/appcompat/widget/n0;
    //   105: getstatic c/j.d0 : I
    //   108: istore #4
    //   110: aload #11
    //   112: iload #4
    //   114: invokevirtual p : (I)Z
    //   117: ifeq -> 139
    //   120: aload_0
    //   121: aload #16
    //   123: aload #10
    //   125: aload #11
    //   127: iload #4
    //   129: iconst_0
    //   130: invokevirtual l : (II)I
    //   133: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   136: putfield d : Landroidx/appcompat/widget/n0;
    //   139: getstatic c/j.b0 : I
    //   142: istore #4
    //   144: aload #11
    //   146: iload #4
    //   148: invokevirtual p : (I)Z
    //   151: ifeq -> 173
    //   154: aload_0
    //   155: aload #16
    //   157: aload #10
    //   159: aload #11
    //   161: iload #4
    //   163: iconst_0
    //   164: invokevirtual l : (II)I
    //   167: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   170: putfield e : Landroidx/appcompat/widget/n0;
    //   173: getstatic android/os/Build$VERSION.SDK_INT : I
    //   176: istore #5
    //   178: getstatic c/j.e0 : I
    //   181: istore #4
    //   183: aload #11
    //   185: iload #4
    //   187: invokevirtual p : (I)Z
    //   190: ifeq -> 212
    //   193: aload_0
    //   194: aload #16
    //   196: aload #10
    //   198: aload #11
    //   200: iload #4
    //   202: iconst_0
    //   203: invokevirtual l : (II)I
    //   206: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   209: putfield f : Landroidx/appcompat/widget/n0;
    //   212: getstatic c/j.f0 : I
    //   215: istore #4
    //   217: aload #11
    //   219: iload #4
    //   221: invokevirtual p : (I)Z
    //   224: ifeq -> 246
    //   227: aload_0
    //   228: aload #16
    //   230: aload #10
    //   232: aload #11
    //   234: iload #4
    //   236: iconst_0
    //   237: invokevirtual l : (II)I
    //   240: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/f;I)Landroidx/appcompat/widget/n0;
    //   243: putfield g : Landroidx/appcompat/widget/n0;
    //   246: aload #11
    //   248: invokevirtual t : ()V
    //   251: aload_0
    //   252: getfield a : Landroid/widget/TextView;
    //   255: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   258: instanceof android/text/method/PasswordTransformationMethod
    //   261: istore #9
    //   263: aconst_null
    //   264: astore #13
    //   266: aconst_null
    //   267: astore #11
    //   269: iload_3
    //   270: iconst_m1
    //   271: if_icmpeq -> 445
    //   274: aload #16
    //   276: iload_3
    //   277: getstatic c/j.j2 : [I
    //   280: invokestatic q : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/p0;
    //   283: astore #13
    //   285: iload #9
    //   287: ifne -> 317
    //   290: getstatic c/j.s2 : I
    //   293: istore_3
    //   294: aload #13
    //   296: iload_3
    //   297: invokevirtual p : (I)Z
    //   300: ifeq -> 317
    //   303: aload #13
    //   305: iload_3
    //   306: iconst_0
    //   307: invokevirtual a : (IZ)Z
    //   310: istore #7
    //   312: iconst_1
    //   313: istore_3
    //   314: goto -> 322
    //   317: iconst_0
    //   318: istore #7
    //   320: iconst_0
    //   321: istore_3
    //   322: aload_0
    //   323: aload #16
    //   325: aload #13
    //   327: invokespecial u : (Landroid/content/Context;Landroidx/appcompat/widget/p0;)V
    //   330: iload #5
    //   332: bipush #23
    //   334: if_icmpge -> 430
    //   337: getstatic c/j.n2 : I
    //   340: istore #4
    //   342: aload #13
    //   344: iload #4
    //   346: invokevirtual p : (I)Z
    //   349: ifeq -> 364
    //   352: aload #13
    //   354: iload #4
    //   356: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   359: astore #11
    //   361: goto -> 367
    //   364: aconst_null
    //   365: astore #11
    //   367: getstatic c/j.o2 : I
    //   370: istore #4
    //   372: aload #13
    //   374: iload #4
    //   376: invokevirtual p : (I)Z
    //   379: ifeq -> 394
    //   382: aload #13
    //   384: iload #4
    //   386: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   389: astore #10
    //   391: goto -> 397
    //   394: aconst_null
    //   395: astore #10
    //   397: getstatic c/j.p2 : I
    //   400: istore #4
    //   402: aload #13
    //   404: iload #4
    //   406: invokevirtual p : (I)Z
    //   409: ifeq -> 424
    //   412: aload #13
    //   414: iload #4
    //   416: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   419: astore #12
    //   421: goto -> 427
    //   424: aconst_null
    //   425: astore #12
    //   427: goto -> 437
    //   430: aconst_null
    //   431: astore #12
    //   433: aload #12
    //   435: astore #10
    //   437: aload #13
    //   439: invokevirtual t : ()V
    //   442: goto -> 461
    //   445: aconst_null
    //   446: astore #12
    //   448: aload #12
    //   450: astore #10
    //   452: iconst_0
    //   453: istore #7
    //   455: iconst_0
    //   456: istore_3
    //   457: aload #13
    //   459: astore #11
    //   461: aload #16
    //   463: aload_1
    //   464: getstatic c/j.j2 : [I
    //   467: iload_2
    //   468: iconst_0
    //   469: invokestatic s : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   472: astore #17
    //   474: iload #7
    //   476: istore #8
    //   478: iload_3
    //   479: istore #4
    //   481: iload #9
    //   483: ifne -> 521
    //   486: getstatic c/j.s2 : I
    //   489: istore #6
    //   491: iload #7
    //   493: istore #8
    //   495: iload_3
    //   496: istore #4
    //   498: aload #17
    //   500: iload #6
    //   502: invokevirtual p : (I)Z
    //   505: ifeq -> 521
    //   508: aload #17
    //   510: iload #6
    //   512: iconst_0
    //   513: invokevirtual a : (IZ)Z
    //   516: istore #8
    //   518: iconst_1
    //   519: istore #4
    //   521: aload #12
    //   523: astore #15
    //   525: aload #11
    //   527: astore #13
    //   529: aload #10
    //   531: astore #14
    //   533: iload #5
    //   535: bipush #23
    //   537: if_icmpge -> 623
    //   540: getstatic c/j.n2 : I
    //   543: istore_3
    //   544: aload #17
    //   546: iload_3
    //   547: invokevirtual p : (I)Z
    //   550: ifeq -> 561
    //   553: aload #17
    //   555: iload_3
    //   556: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   559: astore #11
    //   561: getstatic c/j.o2 : I
    //   564: istore_3
    //   565: aload #17
    //   567: iload_3
    //   568: invokevirtual p : (I)Z
    //   571: ifeq -> 582
    //   574: aload #17
    //   576: iload_3
    //   577: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   580: astore #10
    //   582: getstatic c/j.p2 : I
    //   585: istore_3
    //   586: aload #12
    //   588: astore #15
    //   590: aload #11
    //   592: astore #13
    //   594: aload #10
    //   596: astore #14
    //   598: aload #17
    //   600: iload_3
    //   601: invokevirtual p : (I)Z
    //   604: ifeq -> 623
    //   607: aload #17
    //   609: iload_3
    //   610: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   613: astore #15
    //   615: aload #10
    //   617: astore #14
    //   619: aload #11
    //   621: astore #13
    //   623: iload #5
    //   625: bipush #28
    //   627: if_icmplt -> 662
    //   630: getstatic c/j.k2 : I
    //   633: istore_3
    //   634: aload #17
    //   636: iload_3
    //   637: invokevirtual p : (I)Z
    //   640: ifeq -> 662
    //   643: aload #17
    //   645: iload_3
    //   646: iconst_m1
    //   647: invokevirtual e : (II)I
    //   650: ifne -> 662
    //   653: aload_0
    //   654: getfield a : Landroid/widget/TextView;
    //   657: iconst_0
    //   658: fconst_0
    //   659: invokevirtual setTextSize : (IF)V
    //   662: aload_0
    //   663: aload #16
    //   665: aload #17
    //   667: invokespecial u : (Landroid/content/Context;Landroidx/appcompat/widget/p0;)V
    //   670: aload #17
    //   672: invokevirtual t : ()V
    //   675: aload #13
    //   677: ifnull -> 689
    //   680: aload_0
    //   681: getfield a : Landroid/widget/TextView;
    //   684: aload #13
    //   686: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   689: aload #14
    //   691: ifnull -> 703
    //   694: aload_0
    //   695: getfield a : Landroid/widget/TextView;
    //   698: aload #14
    //   700: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   703: aload #15
    //   705: ifnull -> 717
    //   708: aload_0
    //   709: getfield a : Landroid/widget/TextView;
    //   712: aload #15
    //   714: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   717: iload #9
    //   719: ifne -> 733
    //   722: iload #4
    //   724: ifeq -> 733
    //   727: aload_0
    //   728: iload #8
    //   730: invokevirtual o : (Z)V
    //   733: aload_0
    //   734: getfield j : Landroid/graphics/Typeface;
    //   737: astore #10
    //   739: aload #10
    //   741: ifnull -> 757
    //   744: aload_0
    //   745: getfield a : Landroid/widget/TextView;
    //   748: aload #10
    //   750: aload_0
    //   751: getfield i : I
    //   754: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   757: aload_0
    //   758: getfield h : Landroidx/appcompat/widget/u;
    //   761: aload_1
    //   762: iload_2
    //   763: invokevirtual o : (Landroid/util/AttributeSet;I)V
    //   766: getstatic androidx/core/widget/b.J : Z
    //   769: ifeq -> 854
    //   772: aload_0
    //   773: getfield h : Landroidx/appcompat/widget/u;
    //   776: invokevirtual k : ()I
    //   779: ifeq -> 854
    //   782: aload_0
    //   783: getfield h : Landroidx/appcompat/widget/u;
    //   786: invokevirtual j : ()[I
    //   789: astore #10
    //   791: aload #10
    //   793: arraylength
    //   794: ifle -> 854
    //   797: aload_0
    //   798: getfield a : Landroid/widget/TextView;
    //   801: invokestatic a : (Landroid/widget/TextView;)I
    //   804: i2f
    //   805: ldc_w -1.0
    //   808: fcmpl
    //   809: ifeq -> 844
    //   812: aload_0
    //   813: getfield a : Landroid/widget/TextView;
    //   816: aload_0
    //   817: getfield h : Landroidx/appcompat/widget/u;
    //   820: invokevirtual h : ()I
    //   823: aload_0
    //   824: getfield h : Landroidx/appcompat/widget/u;
    //   827: invokevirtual g : ()I
    //   830: aload_0
    //   831: getfield h : Landroidx/appcompat/widget/u;
    //   834: invokevirtual i : ()I
    //   837: iconst_0
    //   838: invokestatic a : (Landroid/widget/TextView;IIII)V
    //   841: goto -> 854
    //   844: aload_0
    //   845: getfield a : Landroid/widget/TextView;
    //   848: aload #10
    //   850: iconst_0
    //   851: invokestatic a : (Landroid/widget/TextView;[II)V
    //   854: aload #16
    //   856: aload_1
    //   857: getstatic c/j.g0 : [I
    //   860: invokestatic r : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/p0;
    //   863: astore_1
    //   864: aload_1
    //   865: getstatic c/j.m0 : I
    //   868: iconst_m1
    //   869: invokevirtual e : (II)I
    //   872: istore_2
    //   873: aload_1
    //   874: getstatic c/j.n0 : I
    //   877: iconst_m1
    //   878: invokevirtual e : (II)I
    //   881: istore_3
    //   882: aload_1
    //   883: getstatic c/j.o0 : I
    //   886: iconst_m1
    //   887: invokevirtual e : (II)I
    //   890: istore #4
    //   892: aload_1
    //   893: invokevirtual t : ()V
    //   896: iload_2
    //   897: iconst_m1
    //   898: if_icmpeq -> 909
    //   901: aload_0
    //   902: getfield a : Landroid/widget/TextView;
    //   905: iload_2
    //   906: invokestatic f : (Landroid/widget/TextView;I)V
    //   909: iload_3
    //   910: iconst_m1
    //   911: if_icmpeq -> 922
    //   914: aload_0
    //   915: getfield a : Landroid/widget/TextView;
    //   918: iload_3
    //   919: invokestatic g : (Landroid/widget/TextView;I)V
    //   922: iload #4
    //   924: iconst_m1
    //   925: if_icmpeq -> 937
    //   928: aload_0
    //   929: getfield a : Landroid/widget/TextView;
    //   932: iload #4
    //   934: invokestatic h : (Landroid/widget/TextView;I)V
    //   937: return
  }
  
  void l(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.k) {
      this.j = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null)
        textView.setTypeface(paramTypeface, this.i); 
    } 
  }
  
  void m(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!b.J)
      c(); 
  }
  
  void n(Context paramContext, int paramInt) {
    p0 p0 = p0.q(paramContext, paramInt, j.j2);
    paramInt = j.s2;
    if (p0.p(paramInt))
      o(p0.a(paramInt, false)); 
    if (Build.VERSION.SDK_INT < 23) {
      paramInt = j.n2;
      if (p0.p(paramInt)) {
        ColorStateList colorStateList = p0.c(paramInt);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
    } 
    paramInt = j.k2;
    if (p0.p(paramInt) && p0.e(paramInt, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    u(paramContext, p0);
    p0.t();
    Typeface typeface = this.j;
    if (typeface != null)
      this.a.setTypeface(typeface, this.i); 
  }
  
  void o(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void p(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.h.p(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void q(@NonNull int[] paramArrayOfint, int paramInt) {
    this.h.q(paramArrayOfint, paramInt);
  }
  
  void r(int paramInt) {
    this.h.r(paramInt);
  }
  
  void s(int paramInt, float paramFloat) {
    if (!b.J && !j())
      t(paramInt, paramFloat); 
  }
  
  class a extends h.e {
    a(q this$0, WeakReference param1WeakReference) {}
    
    public void h(int param1Int) {}
    
    public void i(@NonNull Typeface param1Typeface) {
      this.b.l(this.a, param1Typeface);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */