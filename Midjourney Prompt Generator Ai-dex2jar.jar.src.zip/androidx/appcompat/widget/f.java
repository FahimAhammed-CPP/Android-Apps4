package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import androidx.annotation.NonNull;
import androidx.vectordrawable.graphics.drawable.g;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import m.h;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class f {
  private static final PorterDuff.Mode g = PorterDuff.Mode.SRC_IN;
  
  private static f h;
  
  private static final c i = new c(6);
  
  private static final int[] j = new int[] { c.e.Q, c.e.O, c.e.a };
  
  private static final int[] k = new int[] { c.e.m, c.e.z, c.e.r, c.e.n, c.e.o, c.e.q, c.e.p };
  
  private static final int[] l = new int[] { c.e.N, c.e.P, c.e.i, c.e.G, c.e.H, c.e.J, c.e.L, c.e.I, c.e.K, c.e.M };
  
  private static final int[] m = new int[] { c.e.u, c.e.g, c.e.t };
  
  private static final int[] n = new int[] { c.e.F, c.e.R };
  
  private static final int[] o = new int[] { c.e.c, c.e.f };
  
  private WeakHashMap<Context, h<ColorStateList>> a;
  
  private m.a<String, d> b;
  
  private h<String> c;
  
  private final WeakHashMap<Context, m.d<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<Context, m.d<WeakReference<Drawable.ConstantState>>>(0);
  
  private TypedValue e;
  
  private boolean f;
  
  private Drawable A(@NonNull Context paramContext, int paramInt, boolean paramBoolean, @NonNull Drawable paramDrawable) {
    Drawable drawable;
    PorterDuff.Mode mode1;
    PorterDuff.Mode mode2;
    ColorStateList colorStateList = s(paramContext, paramInt);
    if (colorStateList != null) {
      drawable = paramDrawable;
      if (w.a(paramDrawable))
        drawable = paramDrawable.mutate(); 
      drawable = androidx.core.graphics.drawable.a.p(drawable);
      androidx.core.graphics.drawable.a.n(drawable, colorStateList);
      mode1 = u(paramInt);
      Drawable drawable1 = drawable;
      if (mode1 != null) {
        androidx.core.graphics.drawable.a.o(drawable, mode1);
        return drawable;
      } 
    } else {
      if (paramInt == c.e.A) {
        LayerDrawable layerDrawable = (LayerDrawable)mode1;
        Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
        paramInt = c.a.o;
        int i = k0.b((Context)drawable, paramInt);
        PorterDuff.Mode mode = g;
        z(drawable1, i, mode);
        z(layerDrawable.findDrawableByLayerId(16908303), k0.b((Context)drawable, paramInt), mode);
        z(layerDrawable.findDrawableByLayerId(16908301), k0.b((Context)drawable, c.a.m), mode);
        return (Drawable)mode1;
      } 
      if (paramInt == c.e.w || paramInt == c.e.v || paramInt == c.e.x) {
        LayerDrawable layerDrawable = (LayerDrawable)mode1;
        Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
        paramInt = k0.a((Context)drawable, c.a.o);
        PorterDuff.Mode mode = g;
        z(drawable1, paramInt, mode);
        drawable1 = layerDrawable.findDrawableByLayerId(16908303);
        paramInt = c.a.m;
        z(drawable1, k0.b((Context)drawable, paramInt), mode);
        z(layerDrawable.findDrawableByLayerId(16908301), k0.b((Context)drawable, paramInt), mode);
        return (Drawable)mode1;
      } 
      mode2 = mode1;
      if (!C((Context)drawable, paramInt, (Drawable)mode1)) {
        mode2 = mode1;
        if (paramBoolean)
          return null; 
      } 
    } 
    return (Drawable)mode2;
  }
  
  static void B(Drawable paramDrawable, n0 paramn0, int[] paramArrayOfint) {
    if (w.a(paramDrawable) && paramDrawable.mutate() != paramDrawable) {
      Log.d("AppCompatDrawableManag", "Mutated drawable is not the same instance as the input.");
      return;
    } 
    boolean bool = paramn0.d;
    if (bool || paramn0.c) {
      PorterDuff.Mode mode;
      ColorStateList colorStateList;
      if (bool) {
        colorStateList = paramn0.a;
      } else {
        colorStateList = null;
      } 
      if (paramn0.c) {
        mode = paramn0.b;
      } else {
        mode = g;
      } 
      paramDrawable.setColorFilter((ColorFilter)m(colorStateList, mode, paramArrayOfint));
    } else {
      paramDrawable.clearColorFilter();
    } 
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf(); 
  }
  
  static boolean C(@NonNull Context paramContext, int paramInt, @NonNull Drawable paramDrawable) {
    // Byte code:
    //   0: getstatic androidx/appcompat/widget/f.g : Landroid/graphics/PorterDuff$Mode;
    //   3: astore #6
    //   5: getstatic androidx/appcompat/widget/f.j : [I
    //   8: iload_1
    //   9: invokestatic d : ([II)Z
    //   12: istore #5
    //   14: ldc_w 16842801
    //   17: istore_3
    //   18: iload #5
    //   20: ifeq -> 35
    //   23: getstatic c/a.o : I
    //   26: istore_1
    //   27: iconst_m1
    //   28: istore_3
    //   29: iconst_1
    //   30: istore #4
    //   32: goto -> 112
    //   35: getstatic androidx/appcompat/widget/f.l : [I
    //   38: iload_1
    //   39: invokestatic d : ([II)Z
    //   42: ifeq -> 52
    //   45: getstatic c/a.m : I
    //   48: istore_1
    //   49: goto -> 27
    //   52: getstatic androidx/appcompat/widget/f.m : [I
    //   55: iload_1
    //   56: invokestatic d : ([II)Z
    //   59: ifeq -> 72
    //   62: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
    //   65: astore #6
    //   67: iload_3
    //   68: istore_1
    //   69: goto -> 27
    //   72: iload_1
    //   73: getstatic c/e.s : I
    //   76: if_icmpne -> 93
    //   79: ldc_w 16842800
    //   82: istore_1
    //   83: ldc_w 40.8
    //   86: invokestatic round : (F)I
    //   89: istore_3
    //   90: goto -> 29
    //   93: iload_1
    //   94: getstatic c/e.j : I
    //   97: if_icmpne -> 105
    //   100: iload_3
    //   101: istore_1
    //   102: goto -> 27
    //   105: iconst_m1
    //   106: istore_3
    //   107: iconst_0
    //   108: istore #4
    //   110: iconst_0
    //   111: istore_1
    //   112: iload #4
    //   114: ifeq -> 161
    //   117: aload_2
    //   118: astore #7
    //   120: aload_2
    //   121: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
    //   124: ifeq -> 133
    //   127: aload_2
    //   128: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   131: astore #7
    //   133: aload #7
    //   135: aload_0
    //   136: iload_1
    //   137: invokestatic b : (Landroid/content/Context;I)I
    //   140: aload #6
    //   142: invokestatic r : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   145: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   148: iload_3
    //   149: iconst_m1
    //   150: if_icmpeq -> 159
    //   153: aload #7
    //   155: iload_3
    //   156: invokevirtual setAlpha : (I)V
    //   159: iconst_1
    //   160: ireturn
    //   161: iconst_0
    //   162: ireturn
  }
  
  private void a(@NonNull String paramString, @NonNull d paramd) {
    if (this.b == null)
      this.b = new m.a(); 
    this.b.put(paramString, paramd);
  }
  
  private boolean b(@NonNull Context paramContext, long paramLong, @NonNull Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #4
    //   4: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 75
    //   14: aload_0
    //   15: getfield d : Ljava/util/WeakHashMap;
    //   18: aload_1
    //   19: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: checkcast m/d
    //   25: astore #5
    //   27: aload #5
    //   29: astore #4
    //   31: aload #5
    //   33: ifnonnull -> 56
    //   36: new m/d
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield d : Ljava/util/WeakHashMap;
    //   49: aload_1
    //   50: aload #4
    //   52: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: pop
    //   56: aload #4
    //   58: lload_2
    //   59: new java/lang/ref/WeakReference
    //   62: dup
    //   63: aload #6
    //   65: invokespecial <init> : (Ljava/lang/Object;)V
    //   68: invokevirtual i : (JLjava/lang/Object;)V
    //   71: aload_0
    //   72: monitorexit
    //   73: iconst_1
    //   74: ireturn
    //   75: aload_0
    //   76: monitorexit
    //   77: iconst_0
    //   78: ireturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	79	finally
    //   14	27	79	finally
    //   36	56	79	finally
    //   56	71	79	finally
  }
  
  private void c(@NonNull Context paramContext, int paramInt, @NonNull ColorStateList paramColorStateList) {
    if (this.a == null)
      this.a = new WeakHashMap<Context, h<ColorStateList>>(); 
    h<ColorStateList> h2 = this.a.get(paramContext);
    h<ColorStateList> h1 = h2;
    if (h2 == null) {
      h1 = new h();
      this.a.put(paramContext, h1);
    } 
    h1.a(paramInt, paramColorStateList);
  }
  
  private static boolean d(int[] paramArrayOfint, int paramInt) {
    int j = paramArrayOfint.length;
    for (int i = 0; i < j; i++) {
      if (paramArrayOfint[i] == paramInt)
        return true; 
    } 
    return false;
  }
  
  private void e(@NonNull Context paramContext) {
    if (this.f)
      return; 
    this.f = true;
    Drawable drawable = p(paramContext, c.e.S);
    if (drawable != null && w(drawable))
      return; 
    this.f = false;
    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
  }
  
  private ColorStateList f(@NonNull Context paramContext) {
    return g(paramContext, 0);
  }
  
  private ColorStateList g(@NonNull Context paramContext, int paramInt) {
    int k = k0.b(paramContext, c.a.n);
    int i = k0.a(paramContext, c.a.l);
    int[] arrayOfInt1 = k0.b;
    int[] arrayOfInt2 = k0.e;
    int j = androidx.core.graphics.a.c(k, paramInt);
    int[] arrayOfInt3 = k0.c;
    k = androidx.core.graphics.a.c(k, paramInt);
    return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, k0.i }, new int[] { i, j, k, paramInt });
  }
  
  private static long h(TypedValue paramTypedValue) {
    return paramTypedValue.assetCookie << 32L | paramTypedValue.data;
  }
  
  private ColorStateList i(@NonNull Context paramContext) {
    return g(paramContext, k0.b(paramContext, c.a.k));
  }
  
  private ColorStateList j(@NonNull Context paramContext) {
    return g(paramContext, k0.b(paramContext, c.a.l));
  }
  
  private Drawable k(@NonNull Context paramContext, int paramInt) {
    LayerDrawable layerDrawable;
    if (this.e == null)
      this.e = new TypedValue(); 
    TypedValue typedValue = this.e;
    paramContext.getResources().getValue(paramInt, typedValue, true);
    long l = h(typedValue);
    Drawable drawable = o(paramContext, l);
    if (drawable != null)
      return drawable; 
    if (paramInt == c.e.h)
      layerDrawable = new LayerDrawable(new Drawable[] { p(paramContext, c.e.g), p(paramContext, c.e.i) }); 
    if (layerDrawable != null) {
      layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
      b(paramContext, l, (Drawable)layerDrawable);
    } 
    return (Drawable)layerDrawable;
  }
  
  private ColorStateList l(Context paramContext) {
    int[][] arrayOfInt = new int[3][];
    int[] arrayOfInt1 = new int[3];
    int i = c.a.p;
    ColorStateList colorStateList = k0.d(paramContext, i);
    if (colorStateList != null && colorStateList.isStateful()) {
      int[] arrayOfInt2 = k0.b;
      arrayOfInt[0] = arrayOfInt2;
      arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt2, 0);
      arrayOfInt[1] = k0.f;
      arrayOfInt1[1] = k0.b(paramContext, c.a.m);
      arrayOfInt[2] = k0.i;
      arrayOfInt1[2] = colorStateList.getDefaultColor();
    } else {
      arrayOfInt[0] = k0.b;
      arrayOfInt1[0] = k0.a(paramContext, i);
      arrayOfInt[1] = k0.f;
      arrayOfInt1[1] = k0.b(paramContext, c.a.m);
      arrayOfInt[2] = k0.i;
      arrayOfInt1[2] = k0.b(paramContext, i);
    } 
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  private static PorterDuffColorFilter m(ColorStateList paramColorStateList, PorterDuff.Mode paramMode, int[] paramArrayOfint) {
    return (paramColorStateList == null || paramMode == null) ? null : r(paramColorStateList.getColorForState(paramArrayOfint, 0), paramMode);
  }
  
  public static f n() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/f
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/f.h : Landroidx/appcompat/widget/f;
    //   6: ifnonnull -> 25
    //   9: new androidx/appcompat/widget/f
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/f.h : Landroidx/appcompat/widget/f;
    //   21: aload_0
    //   22: invokestatic v : (Landroidx/appcompat/widget/f;)V
    //   25: getstatic androidx/appcompat/widget/f.h : Landroidx/appcompat/widget/f;
    //   28: astore_0
    //   29: ldc androidx/appcompat/widget/f
    //   31: monitorexit
    //   32: aload_0
    //   33: areturn
    //   34: astore_0
    //   35: ldc androidx/appcompat/widget/f
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   3	25	34	finally
    //   25	29	34	finally
  }
  
  private Drawable o(@NonNull Context paramContext, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast m/d
    //   13: astore #4
    //   15: aload #4
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload #4
    //   26: lload_2
    //   27: invokevirtual e : (J)Ljava/lang/Object;
    //   30: checkcast java/lang/ref/WeakReference
    //   33: astore #5
    //   35: aload #5
    //   37: ifnull -> 75
    //   40: aload #5
    //   42: invokevirtual get : ()Ljava/lang/Object;
    //   45: checkcast android/graphics/drawable/Drawable$ConstantState
    //   48: astore #5
    //   50: aload #5
    //   52: ifnull -> 69
    //   55: aload #5
    //   57: aload_1
    //   58: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   61: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   64: astore_1
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_1
    //   68: areturn
    //   69: aload #4
    //   71: lload_2
    //   72: invokevirtual c : (J)V
    //   75: aload_0
    //   76: monitorexit
    //   77: aconst_null
    //   78: areturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	79	finally
    //   24	35	79	finally
    //   40	50	79	finally
    //   55	65	79	finally
    //   69	75	79	finally
  }
  
  public static PorterDuffColorFilter r(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/f
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/f.i : Landroidx/appcompat/widget/f$c;
    //   6: astore #4
    //   8: aload #4
    //   10: iload_0
    //   11: aload_1
    //   12: invokevirtual k : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   15: astore_3
    //   16: aload_3
    //   17: astore_2
    //   18: aload_3
    //   19: ifnonnull -> 41
    //   22: new android/graphics/PorterDuffColorFilter
    //   25: dup
    //   26: iload_0
    //   27: aload_1
    //   28: invokespecial <init> : (ILandroid/graphics/PorterDuff$Mode;)V
    //   31: astore_2
    //   32: aload #4
    //   34: iload_0
    //   35: aload_1
    //   36: aload_2
    //   37: invokevirtual l : (ILandroid/graphics/PorterDuff$Mode;Landroid/graphics/PorterDuffColorFilter;)Landroid/graphics/PorterDuffColorFilter;
    //   40: pop
    //   41: ldc androidx/appcompat/widget/f
    //   43: monitorexit
    //   44: aload_2
    //   45: areturn
    //   46: astore_1
    //   47: ldc androidx/appcompat/widget/f
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   3	16	46	finally
    //   22	41	46	finally
  }
  
  private ColorStateList t(@NonNull Context paramContext, int paramInt) {
    WeakHashMap<Context, h<ColorStateList>> weakHashMap = this.a;
    ColorStateList colorStateList2 = null;
    ColorStateList colorStateList1 = colorStateList2;
    if (weakHashMap != null) {
      h h1 = weakHashMap.get(paramContext);
      colorStateList1 = colorStateList2;
      if (h1 != null)
        colorStateList1 = (ColorStateList)h1.e(paramInt); 
    } 
    return colorStateList1;
  }
  
  static PorterDuff.Mode u(int paramInt) {
    return (paramInt == c.e.D) ? PorterDuff.Mode.MULTIPLY : null;
  }
  
  private static void v(@NonNull f paramf) {
    if (Build.VERSION.SDK_INT < 24) {
      paramf.a("vector", new e());
      paramf.a("animated-vector", new b());
      paramf.a("animated-selector", new a());
    } 
  }
  
  private static boolean w(@NonNull Drawable paramDrawable) {
    return (paramDrawable instanceof g || "android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName()));
  }
  
  private Drawable x(@NonNull Context paramContext, int paramInt) {
    m.a<String, d> a1 = this.b;
    if (a1 != null && !a1.isEmpty()) {
      h<String> h1 = this.c;
      if (h1 != null) {
        String str = (String)h1.e(paramInt);
        if ("appcompat_skip_skip".equals(str) || (str != null && this.b.get(str) == null))
          return null; 
      } else {
        this.c = new h();
      } 
      if (this.e == null)
        this.e = new TypedValue(); 
      TypedValue typedValue = this.e;
      Resources resources = paramContext.getResources();
      resources.getValue(paramInt, typedValue, true);
      long l = h(typedValue);
      Drawable drawable1 = o(paramContext, l);
      if (drawable1 != null)
        return drawable1; 
      CharSequence charSequence = typedValue.string;
      Drawable drawable2 = drawable1;
      if (charSequence != null) {
        drawable2 = drawable1;
        if (charSequence.toString().endsWith(".xml")) {
          drawable2 = drawable1;
          try {
            int i;
            XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
            drawable2 = drawable1;
            AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
            while (true) {
              drawable2 = drawable1;
              i = xmlResourceParser.next();
              if (i != 2 && i != 1)
                continue; 
              break;
            } 
            if (i == 2) {
              drawable2 = drawable1;
              String str = xmlResourceParser.getName();
              drawable2 = drawable1;
              this.c.a(paramInt, str);
              drawable2 = drawable1;
              d d = (d)this.b.get(str);
              Drawable drawable = drawable1;
              if (d != null) {
                drawable2 = drawable1;
                drawable = d.a(paramContext, (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme());
              } 
              drawable2 = drawable;
              if (drawable != null) {
                drawable2 = drawable;
                drawable.setChangingConfigurations(typedValue.changingConfigurations);
                drawable2 = drawable;
                b(paramContext, l, drawable);
                drawable2 = drawable;
              } 
            } else {
              drawable2 = drawable1;
              throw new XmlPullParserException("No start tag found");
            } 
          } catch (Exception exception) {
            Log.e("AppCompatDrawableManag", "Exception while inflating drawable", exception);
          } 
        } 
      } 
      if (drawable2 == null)
        this.c.a(paramInt, "appcompat_skip_skip"); 
      return drawable2;
    } 
    return null;
  }
  
  private static void z(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode) {
    Drawable drawable = paramDrawable;
    if (w.a(paramDrawable))
      drawable = paramDrawable.mutate(); 
    PorterDuff.Mode mode = paramMode;
    if (paramMode == null)
      mode = g; 
    drawable.setColorFilter((ColorFilter)r(paramInt, mode));
  }
  
  public Drawable p(@NonNull Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: iconst_0
    //   6: invokevirtual q : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  Drawable q(@NonNull Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial e : (Landroid/content/Context;)V
    //   7: aload_0
    //   8: aload_1
    //   9: iload_2
    //   10: invokespecial x : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   13: astore #5
    //   15: aload #5
    //   17: astore #4
    //   19: aload #5
    //   21: ifnonnull -> 32
    //   24: aload_0
    //   25: aload_1
    //   26: iload_2
    //   27: invokespecial k : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   30: astore #4
    //   32: aload #4
    //   34: astore #5
    //   36: aload #4
    //   38: ifnonnull -> 48
    //   41: aload_1
    //   42: iload_2
    //   43: invokestatic d : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   46: astore #5
    //   48: aload #5
    //   50: astore #4
    //   52: aload #5
    //   54: ifnull -> 68
    //   57: aload_0
    //   58: aload_1
    //   59: iload_2
    //   60: iload_3
    //   61: aload #5
    //   63: invokespecial A : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   66: astore #4
    //   68: aload #4
    //   70: ifnull -> 78
    //   73: aload #4
    //   75: invokestatic b : (Landroid/graphics/drawable/Drawable;)V
    //   78: aload_0
    //   79: monitorexit
    //   80: aload #4
    //   82: areturn
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	83	finally
    //   24	32	83	finally
    //   41	48	83	finally
    //   57	68	83	finally
    //   73	78	83	finally
  }
  
  ColorStateList s(@NonNull Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: invokespecial t : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   8: astore_3
    //   9: aload_3
    //   10: astore #4
    //   12: aload_3
    //   13: ifnonnull -> 239
    //   16: iload_2
    //   17: getstatic c/e.k : I
    //   20: if_icmpne -> 34
    //   23: aload_1
    //   24: getstatic c/c.c : I
    //   27: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   30: astore_3
    //   31: goto -> 222
    //   34: iload_2
    //   35: getstatic c/e.E : I
    //   38: if_icmpne -> 52
    //   41: aload_1
    //   42: getstatic c/c.f : I
    //   45: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   48: astore_3
    //   49: goto -> 222
    //   52: iload_2
    //   53: getstatic c/e.D : I
    //   56: if_icmpne -> 68
    //   59: aload_0
    //   60: aload_1
    //   61: invokespecial l : (Landroid/content/Context;)Landroid/content/res/ColorStateList;
    //   64: astore_3
    //   65: goto -> 222
    //   68: iload_2
    //   69: getstatic c/e.e : I
    //   72: if_icmpne -> 84
    //   75: aload_0
    //   76: aload_1
    //   77: invokespecial j : (Landroid/content/Context;)Landroid/content/res/ColorStateList;
    //   80: astore_3
    //   81: goto -> 222
    //   84: iload_2
    //   85: getstatic c/e.b : I
    //   88: if_icmpne -> 100
    //   91: aload_0
    //   92: aload_1
    //   93: invokespecial f : (Landroid/content/Context;)Landroid/content/res/ColorStateList;
    //   96: astore_3
    //   97: goto -> 222
    //   100: iload_2
    //   101: getstatic c/e.d : I
    //   104: if_icmpne -> 116
    //   107: aload_0
    //   108: aload_1
    //   109: invokespecial i : (Landroid/content/Context;)Landroid/content/res/ColorStateList;
    //   112: astore_3
    //   113: goto -> 222
    //   116: iload_2
    //   117: getstatic c/e.B : I
    //   120: if_icmpeq -> 214
    //   123: iload_2
    //   124: getstatic c/e.C : I
    //   127: if_icmpne -> 133
    //   130: goto -> 214
    //   133: getstatic androidx/appcompat/widget/f.k : [I
    //   136: iload_2
    //   137: invokestatic d : ([II)Z
    //   140: ifeq -> 154
    //   143: aload_1
    //   144: getstatic c/a.o : I
    //   147: invokestatic d : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   150: astore_3
    //   151: goto -> 222
    //   154: getstatic androidx/appcompat/widget/f.n : [I
    //   157: iload_2
    //   158: invokestatic d : ([II)Z
    //   161: ifeq -> 175
    //   164: aload_1
    //   165: getstatic c/c.b : I
    //   168: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   171: astore_3
    //   172: goto -> 222
    //   175: getstatic androidx/appcompat/widget/f.o : [I
    //   178: iload_2
    //   179: invokestatic d : ([II)Z
    //   182: ifeq -> 196
    //   185: aload_1
    //   186: getstatic c/c.a : I
    //   189: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   192: astore_3
    //   193: goto -> 222
    //   196: iload_2
    //   197: getstatic c/e.y : I
    //   200: if_icmpne -> 222
    //   203: aload_1
    //   204: getstatic c/c.d : I
    //   207: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   210: astore_3
    //   211: goto -> 222
    //   214: aload_1
    //   215: getstatic c/c.e : I
    //   218: invokestatic c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   221: astore_3
    //   222: aload_3
    //   223: astore #4
    //   225: aload_3
    //   226: ifnull -> 239
    //   229: aload_0
    //   230: aload_1
    //   231: iload_2
    //   232: aload_3
    //   233: invokespecial c : (Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    //   236: aload_3
    //   237: astore #4
    //   239: aload_0
    //   240: monitorexit
    //   241: aload #4
    //   243: areturn
    //   244: astore_1
    //   245: aload_0
    //   246: monitorexit
    //   247: aload_1
    //   248: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	244	finally
    //   16	31	244	finally
    //   34	49	244	finally
    //   52	65	244	finally
    //   68	81	244	finally
    //   84	97	244	finally
    //   100	113	244	finally
    //   116	130	244	finally
    //   133	151	244	finally
    //   154	172	244	finally
    //   175	193	244	finally
    //   196	211	244	finally
    //   214	222	244	finally
    //   229	236	244	finally
  }
  
  Drawable y(@NonNull Context paramContext, @NonNull v0 paramv0, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_3
    //   5: invokespecial x : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   8: astore #5
    //   10: aload #5
    //   12: astore #4
    //   14: aload #5
    //   16: ifnonnull -> 26
    //   19: aload_2
    //   20: iload_3
    //   21: invokevirtual c : (I)Landroid/graphics/drawable/Drawable;
    //   24: astore #4
    //   26: aload #4
    //   28: ifnull -> 45
    //   31: aload_0
    //   32: aload_1
    //   33: iload_3
    //   34: iconst_0
    //   35: aload #4
    //   37: invokespecial A : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: areturn
    //   45: aload_0
    //   46: monitorexit
    //   47: aconst_null
    //   48: areturn
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	49	finally
    //   19	26	49	finally
    //   31	41	49	finally
  }
  
  static class a implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)f.a.m(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", exception);
        return null;
      } 
    }
  }
  
  private static class b implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)androidx.vectordrawable.graphics.drawable.b.a(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", exception);
        return null;
      } 
    }
  }
  
  private static class c extends m.e<Integer, PorterDuffColorFilter> {
    public c(int param1Int) {
      super(param1Int);
    }
    
    private static int j(int param1Int, PorterDuff.Mode param1Mode) {
      return (param1Int + 31) * 31 + param1Mode.hashCode();
    }
    
    PorterDuffColorFilter k(int param1Int, PorterDuff.Mode param1Mode) {
      return (PorterDuffColorFilter)c(Integer.valueOf(j(param1Int, param1Mode)));
    }
    
    PorterDuffColorFilter l(int param1Int, PorterDuff.Mode param1Mode, PorterDuffColorFilter param1PorterDuffColorFilter) {
      return (PorterDuffColorFilter)d(Integer.valueOf(j(param1Int, param1Mode)), param1PorterDuffColorFilter);
    }
  }
  
  private static interface d {
    Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, Resources.Theme param1Theme);
  }
  
  private static class e implements d {
    public Drawable a(@NonNull Context param1Context, @NonNull XmlPullParser param1XmlPullParser, @NonNull AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)g.c(param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("VdcInflateDelegate", "Exception while inflating <vector>", exception);
        return null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */