package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.k;
import androidx.core.view.b;
import c.g;
import h.h;
import java.util.ArrayList;

class c extends a implements b.a {
  c A;
  
  private b B;
  
  final f C = new f(this);
  
  int D;
  
  d j;
  
  private Drawable k;
  
  private boolean l;
  
  private boolean m;
  
  private boolean n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private boolean r;
  
  private boolean s;
  
  private boolean t;
  
  private boolean u;
  
  private int v;
  
  private final SparseBooleanArray w = new SparseBooleanArray();
  
  private View x;
  
  e y;
  
  a z;
  
  public c(Context paramContext) {
    super(paramContext, g.c, g.b);
  }
  
  private View w(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.i;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof i.a && ((i.a)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public boolean A() {
    e e1 = this.y;
    return (e1 != null && e1.d());
  }
  
  public void B(Configuration paramConfiguration) {
    if (!this.r)
      this.q = g.a.a(this.b).c(); 
    androidx.appcompat.view.menu.d d1 = this.c;
    if (d1 != null)
      d1.G(true); 
  }
  
  public void C(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void D(ActionMenuView paramActionMenuView) {
    this.i = paramActionMenuView;
    paramActionMenuView.C(this.c);
  }
  
  public void E(Drawable paramDrawable) {
    d d1 = this.j;
    if (d1 != null) {
      d1.setImageDrawable(paramDrawable);
      return;
    } 
    this.l = true;
    this.k = paramDrawable;
  }
  
  public void F(boolean paramBoolean) {
    this.m = paramBoolean;
    this.n = true;
  }
  
  public boolean G() {
    if (this.m && !A()) {
      androidx.appcompat.view.menu.d d1 = this.c;
      if (d1 != null && this.i != null && this.A == null && !d1.v().isEmpty()) {
        c c1 = new c(this, new e(this, this.b, this.c, (View)this.j, true));
        this.A = c1;
        ((View)this.i).post(c1);
        super.k(null);
        return true;
      } 
    } 
    return false;
  }
  
  public void b(androidx.appcompat.view.menu.d paramd, boolean paramBoolean) {
    v();
    super.b(paramd, paramBoolean);
  }
  
  public void c(boolean paramBoolean) {
    super.c(paramBoolean);
    ((View)this.i).requestLayout();
    androidx.appcompat.view.menu.d<androidx.appcompat.view.menu.e> d1 = this.c;
    byte b1 = 0;
    if (d1 != null) {
      ArrayList<androidx.appcompat.view.menu.e> arrayList = d1.r();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        b b2 = ((androidx.appcompat.view.menu.e)arrayList.get(j)).b();
        if (b2 != null)
          b2.i(this); 
      } 
    } 
    d1 = this.c;
    if (d1 != null) {
      ArrayList arrayList = d1.v();
    } else {
      d1 = null;
    } 
    int i = b1;
    if (this.m) {
      i = b1;
      if (d1 != null) {
        int j = d1.size();
        if (j == 1) {
          i = ((androidx.appcompat.view.menu.e)d1.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b1;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.j == null)
        this.j = new d(this, this.a); 
      ViewGroup viewGroup = (ViewGroup)this.j.getParent();
      if (viewGroup != this.i) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.j); 
        viewGroup = (ActionMenuView)this.i;
        viewGroup.addView((View)this.j, (ViewGroup.LayoutParams)viewGroup.A());
      } 
    } else {
      d d2 = this.j;
      if (d2 != null) {
        ViewParent viewParent = d2.getParent();
        i i1 = this.i;
        if (viewParent == i1)
          ((ViewGroup)i1).removeView((View)this.j); 
      } 
    } 
    ((ActionMenuView)this.i).setOverflowReserved(this.m);
  }
  
  public boolean d() {
    // Byte code:
    //   0: aload_0
    //   1: astore #16
    //   3: aload #16
    //   5: getfield c : Landroidx/appcompat/view/menu/d;
    //   8: astore #15
    //   10: aload #15
    //   12: ifnull -> 32
    //   15: aload #15
    //   17: invokevirtual A : ()Ljava/util/ArrayList;
    //   20: astore #15
    //   22: aload #15
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: goto -> 38
    //   32: aconst_null
    //   33: astore #15
    //   35: iconst_0
    //   36: istore #4
    //   38: aload #16
    //   40: getfield q : I
    //   43: istore_1
    //   44: aload #16
    //   46: getfield p : I
    //   49: istore #8
    //   51: iconst_0
    //   52: iconst_0
    //   53: invokestatic makeMeasureSpec : (II)I
    //   56: istore #10
    //   58: aload #16
    //   60: getfield i : Landroidx/appcompat/view/menu/i;
    //   63: checkcast android/view/ViewGroup
    //   66: astore #17
    //   68: iconst_0
    //   69: istore_2
    //   70: iconst_0
    //   71: istore #6
    //   73: iconst_0
    //   74: istore_3
    //   75: iconst_0
    //   76: istore #5
    //   78: iload_2
    //   79: iload #4
    //   81: if_icmpge -> 165
    //   84: aload #15
    //   86: iload_2
    //   87: invokevirtual get : (I)Ljava/lang/Object;
    //   90: checkcast androidx/appcompat/view/menu/e
    //   93: astore #18
    //   95: aload #18
    //   97: invokevirtual o : ()Z
    //   100: ifeq -> 110
    //   103: iload_3
    //   104: iconst_1
    //   105: iadd
    //   106: istore_3
    //   107: goto -> 130
    //   110: aload #18
    //   112: invokevirtual n : ()Z
    //   115: ifeq -> 127
    //   118: iload #5
    //   120: iconst_1
    //   121: iadd
    //   122: istore #5
    //   124: goto -> 130
    //   127: iconst_1
    //   128: istore #6
    //   130: iload_1
    //   131: istore #7
    //   133: aload #16
    //   135: getfield u : Z
    //   138: ifeq -> 155
    //   141: iload_1
    //   142: istore #7
    //   144: aload #18
    //   146: invokevirtual isActionViewExpanded : ()Z
    //   149: ifeq -> 155
    //   152: iconst_0
    //   153: istore #7
    //   155: iload_2
    //   156: iconst_1
    //   157: iadd
    //   158: istore_2
    //   159: iload #7
    //   161: istore_1
    //   162: goto -> 78
    //   165: iload_1
    //   166: istore_2
    //   167: aload #16
    //   169: getfield m : Z
    //   172: ifeq -> 194
    //   175: iload #6
    //   177: ifne -> 190
    //   180: iload_1
    //   181: istore_2
    //   182: iload #5
    //   184: iload_3
    //   185: iadd
    //   186: iload_1
    //   187: if_icmple -> 194
    //   190: iload_1
    //   191: iconst_1
    //   192: isub
    //   193: istore_2
    //   194: iload_2
    //   195: iload_3
    //   196: isub
    //   197: istore_1
    //   198: aload #16
    //   200: getfield w : Landroid/util/SparseBooleanArray;
    //   203: astore #18
    //   205: aload #18
    //   207: invokevirtual clear : ()V
    //   210: aload #16
    //   212: getfield s : Z
    //   215: ifeq -> 242
    //   218: aload #16
    //   220: getfield v : I
    //   223: istore_2
    //   224: iload #8
    //   226: iload_2
    //   227: idiv
    //   228: istore_3
    //   229: iload_2
    //   230: iload #8
    //   232: iload_2
    //   233: irem
    //   234: iload_3
    //   235: idiv
    //   236: iadd
    //   237: istore #6
    //   239: goto -> 247
    //   242: iconst_0
    //   243: istore #6
    //   245: iconst_0
    //   246: istore_3
    //   247: iconst_0
    //   248: istore #7
    //   250: iconst_0
    //   251: istore_2
    //   252: iload #8
    //   254: istore #5
    //   256: iload #4
    //   258: istore #8
    //   260: aload_0
    //   261: astore #16
    //   263: iload #7
    //   265: iload #8
    //   267: if_icmpge -> 779
    //   270: aload #15
    //   272: iload #7
    //   274: invokevirtual get : (I)Ljava/lang/Object;
    //   277: checkcast androidx/appcompat/view/menu/e
    //   280: astore #19
    //   282: aload #19
    //   284: invokevirtual o : ()Z
    //   287: ifeq -> 409
    //   290: aload #16
    //   292: aload #19
    //   294: aload #16
    //   296: getfield x : Landroid/view/View;
    //   299: aload #17
    //   301: invokevirtual n : (Landroidx/appcompat/view/menu/e;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   304: astore #20
    //   306: aload #16
    //   308: getfield x : Landroid/view/View;
    //   311: ifnonnull -> 321
    //   314: aload #16
    //   316: aload #20
    //   318: putfield x : Landroid/view/View;
    //   321: aload #16
    //   323: getfield s : Z
    //   326: ifeq -> 346
    //   329: iload_3
    //   330: aload #20
    //   332: iload #6
    //   334: iload_3
    //   335: iload #10
    //   337: iconst_0
    //   338: invokestatic E : (Landroid/view/View;IIII)I
    //   341: isub
    //   342: istore_3
    //   343: goto -> 355
    //   346: aload #20
    //   348: iload #10
    //   350: iload #10
    //   352: invokevirtual measure : (II)V
    //   355: aload #20
    //   357: invokevirtual getMeasuredWidth : ()I
    //   360: istore #9
    //   362: iload #5
    //   364: iload #9
    //   366: isub
    //   367: istore #5
    //   369: iload_2
    //   370: istore #4
    //   372: iload_2
    //   373: ifne -> 380
    //   376: iload #9
    //   378: istore #4
    //   380: aload #19
    //   382: invokevirtual getGroupId : ()I
    //   385: istore_2
    //   386: iload_2
    //   387: ifeq -> 397
    //   390: aload #18
    //   392: iload_2
    //   393: iconst_1
    //   394: invokevirtual put : (IZ)V
    //   397: aload #19
    //   399: iconst_1
    //   400: invokevirtual u : (Z)V
    //   403: iload #4
    //   405: istore_2
    //   406: goto -> 770
    //   409: aload #19
    //   411: invokevirtual n : ()Z
    //   414: ifeq -> 764
    //   417: aload #19
    //   419: invokevirtual getGroupId : ()I
    //   422: istore #11
    //   424: aload #18
    //   426: iload #11
    //   428: invokevirtual get : (I)Z
    //   431: istore #14
    //   433: iload_1
    //   434: ifgt -> 442
    //   437: iload #14
    //   439: ifeq -> 465
    //   442: iload #5
    //   444: ifle -> 465
    //   447: aload #16
    //   449: getfield s : Z
    //   452: ifeq -> 459
    //   455: iload_3
    //   456: ifle -> 465
    //   459: iconst_1
    //   460: istore #12
    //   462: goto -> 468
    //   465: iconst_0
    //   466: istore #12
    //   468: iload #12
    //   470: istore #13
    //   472: iload #12
    //   474: ifeq -> 629
    //   477: aload #16
    //   479: aload #19
    //   481: aload #16
    //   483: getfield x : Landroid/view/View;
    //   486: aload #17
    //   488: invokevirtual n : (Landroidx/appcompat/view/menu/e;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   491: astore #20
    //   493: aload #16
    //   495: getfield x : Landroid/view/View;
    //   498: ifnonnull -> 508
    //   501: aload #16
    //   503: aload #20
    //   505: putfield x : Landroid/view/View;
    //   508: aload #16
    //   510: getfield s : Z
    //   513: ifeq -> 552
    //   516: aload #20
    //   518: iload #6
    //   520: iload_3
    //   521: iload #10
    //   523: iconst_0
    //   524: invokestatic E : (Landroid/view/View;IIII)I
    //   527: istore #9
    //   529: iload_3
    //   530: iload #9
    //   532: isub
    //   533: istore #4
    //   535: iload #4
    //   537: istore_3
    //   538: iload #9
    //   540: ifne -> 561
    //   543: iconst_0
    //   544: istore #13
    //   546: iload #4
    //   548: istore_3
    //   549: goto -> 561
    //   552: aload #20
    //   554: iload #10
    //   556: iload #10
    //   558: invokevirtual measure : (II)V
    //   561: aload #20
    //   563: invokevirtual getMeasuredWidth : ()I
    //   566: istore #9
    //   568: iload #5
    //   570: iload #9
    //   572: isub
    //   573: istore #5
    //   575: iload_2
    //   576: istore #4
    //   578: iload_2
    //   579: ifne -> 586
    //   582: iload #9
    //   584: istore #4
    //   586: aload #16
    //   588: getfield s : Z
    //   591: ifeq -> 602
    //   594: iload #5
    //   596: iflt -> 615
    //   599: goto -> 610
    //   602: iload #5
    //   604: iload #4
    //   606: iadd
    //   607: ifle -> 615
    //   610: iconst_1
    //   611: istore_2
    //   612: goto -> 617
    //   615: iconst_0
    //   616: istore_2
    //   617: iload #13
    //   619: iload_2
    //   620: iand
    //   621: istore #12
    //   623: iload #4
    //   625: istore_2
    //   626: goto -> 629
    //   629: iload #12
    //   631: ifeq -> 653
    //   634: iload #11
    //   636: ifeq -> 653
    //   639: aload #18
    //   641: iload #11
    //   643: iconst_1
    //   644: invokevirtual put : (IZ)V
    //   647: iload_1
    //   648: istore #4
    //   650: goto -> 741
    //   653: iload_1
    //   654: istore #4
    //   656: iload #14
    //   658: ifeq -> 741
    //   661: aload #18
    //   663: iload #11
    //   665: iconst_0
    //   666: invokevirtual put : (IZ)V
    //   669: iconst_0
    //   670: istore #9
    //   672: iload_1
    //   673: istore #4
    //   675: iload #9
    //   677: iload #7
    //   679: if_icmpge -> 741
    //   682: aload #15
    //   684: iload #9
    //   686: invokevirtual get : (I)Ljava/lang/Object;
    //   689: checkcast androidx/appcompat/view/menu/e
    //   692: astore #16
    //   694: iload_1
    //   695: istore #4
    //   697: aload #16
    //   699: invokevirtual getGroupId : ()I
    //   702: iload #11
    //   704: if_icmpne -> 729
    //   707: iload_1
    //   708: istore #4
    //   710: aload #16
    //   712: invokevirtual l : ()Z
    //   715: ifeq -> 723
    //   718: iload_1
    //   719: iconst_1
    //   720: iadd
    //   721: istore #4
    //   723: aload #16
    //   725: iconst_0
    //   726: invokevirtual u : (Z)V
    //   729: iload #9
    //   731: iconst_1
    //   732: iadd
    //   733: istore #9
    //   735: iload #4
    //   737: istore_1
    //   738: goto -> 672
    //   741: iload #4
    //   743: istore_1
    //   744: iload #12
    //   746: ifeq -> 754
    //   749: iload #4
    //   751: iconst_1
    //   752: isub
    //   753: istore_1
    //   754: aload #19
    //   756: iload #12
    //   758: invokevirtual u : (Z)V
    //   761: goto -> 406
    //   764: aload #19
    //   766: iconst_0
    //   767: invokevirtual u : (Z)V
    //   770: iload #7
    //   772: iconst_1
    //   773: iadd
    //   774: istore #7
    //   776: goto -> 260
    //   779: iconst_1
    //   780: ireturn
  }
  
  public void f(androidx.appcompat.view.menu.e parame, i.a parama) {
    parama.d(parame, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.i;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)parama;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.B == null)
      this.B = new b(this); 
    actionMenuItemView.setPopupCallback(this.B);
  }
  
  public void i(@NonNull Context paramContext, androidx.appcompat.view.menu.d paramd) {
    super.i(paramContext, paramd);
    Resources resources = paramContext.getResources();
    g.a a1 = g.a.a(paramContext);
    if (!this.n)
      this.m = a1.g(); 
    if (!this.t)
      this.o = a1.b(); 
    if (!this.r)
      this.q = a1.c(); 
    int i = this.o;
    if (this.m) {
      if (this.j == null) {
        d d1 = new d(this, this.a);
        this.j = d1;
        if (this.l) {
          d1.setImageDrawable(this.k);
          this.k = null;
          this.l = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.j.measure(j, j);
      } 
      i -= this.j.getMeasuredWidth();
    } else {
      this.j = null;
    } 
    this.p = i;
    this.v = (int)((resources.getDisplayMetrics()).density * 56.0F);
    this.x = null;
  }
  
  public boolean k(k paramk) {
    boolean bool = paramk.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    k k1;
    for (k1 = paramk; k1.W() != this.c; k1 = (k)k1.W());
    View view = w(k1.getItem());
    if (view == null)
      return false; 
    this.D = paramk.getItem().getItemId();
    int j = paramk.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramk.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    a a1 = new a(this, this.b, paramk, view);
    this.z = a1;
    a1.g(bool);
    this.z.k();
    super.k(paramk);
    return true;
  }
  
  public boolean l(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.j) ? false : super.l(paramViewGroup, paramInt);
  }
  
  public View n(androidx.appcompat.view.menu.e parame, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = parame.getActionView();
    if (view == null || parame.j())
      view = super.n(parame, paramView, paramViewGroup); 
    if (parame.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.z(layoutParams)); 
    return view;
  }
  
  public boolean o(int paramInt, androidx.appcompat.view.menu.e parame) {
    return parame.l();
  }
  
  public boolean v() {
    return y() | z();
  }
  
  public Drawable x() {
    d d1 = this.j;
    return (d1 != null) ? d1.getDrawable() : (this.l ? this.k : null);
  }
  
  public boolean y() {
    c c1 = this.A;
    if (c1 != null) {
      i i = this.i;
      if (i != null) {
        ((View)i).removeCallbacks(c1);
        this.A = null;
        return true;
      } 
    } 
    e e1 = this.y;
    if (e1 != null) {
      e1.b();
      return true;
    } 
    return false;
  }
  
  public boolean z() {
    a a1 = this.z;
    if (a1 != null) {
      a1.b();
      return true;
    } 
    return false;
  }
  
  private class a extends g {
    public a(c this$0, Context param1Context, k param1k, View param1View) {
      super(param1Context, (androidx.appcompat.view.menu.d)param1k, param1View, false, c.a.i);
      if (!((androidx.appcompat.view.menu.e)param1k.getItem()).l()) {
        View view;
        c.d d2 = this$0.j;
        c.d d1 = d2;
        if (d2 == null)
          view = (View)c.r(this$0); 
        f(view);
      } 
      j(this$0.C);
    }
    
    protected void e() {
      c c1 = this.m;
      c1.z = null;
      c1.D = 0;
      super.e();
    }
  }
  
  private class b extends ActionMenuItemView.b {
    b(c this$0) {}
    
    public h a() {
      c.a a = this.a.z;
      return (h)((a != null) ? a.c() : null);
    }
  }
  
  private class c implements Runnable {
    private c.e a;
    
    public c(c this$0, c.e param1e) {
      this.a = param1e;
    }
    
    public void run() {
      if (c.s(this.b) != null)
        c.t(this.b).c(); 
      View view = (View)c.u(this.b);
      if (view != null && view.getWindowToken() != null && this.a.m())
        this.b.y = this.a; 
      this.b.A = null;
    }
  }
  
  private class d extends k implements ActionMenuView.a {
    private final float[] c = new float[2];
    
    public d(c this$0, Context param1Context) {
      super(param1Context, null, c.a.h);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      s0.a((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean a() {
      return false;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.d.G();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int m = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - m) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        androidx.core.graphics.drawable.a.k(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    class a extends z {
      a(c.d this$0, View param2View, c param2c) {
        super(param2View);
      }
      
      public h b() {
        c.e e = this.k.d.y;
        return (h)((e == null) ? null : e.c());
      }
      
      public boolean c() {
        this.k.d.G();
        return true;
      }
      
      public boolean d() {
        c c1 = this.k.d;
        if (c1.A != null)
          return false; 
        c1.y();
        return true;
      }
    }
  }
  
  class a extends z {
    a(c this$0, View param1View, c param1c) {
      super(param1View);
    }
    
    public h b() {
      c.e e = this.k.d.y;
      return (h)((e == null) ? null : e.c());
    }
    
    public boolean c() {
      this.k.d.G();
      return true;
    }
    
    public boolean d() {
      c c1 = this.k.d;
      if (c1.A != null)
        return false; 
      c1.y();
      return true;
    }
  }
  
  private class e extends g {
    public e(c this$0, Context param1Context, androidx.appcompat.view.menu.d param1d, View param1View, boolean param1Boolean) {
      super(param1Context, param1d, param1View, param1Boolean, c.a.i);
      h(8388613);
      j(this$0.C);
    }
    
    protected void e() {
      if (c.p(this.m) != null)
        c.q(this.m).close(); 
      this.m.y = null;
      super.e();
    }
  }
  
  private class f implements h.a {
    f(c this$0) {}
    
    public void b(androidx.appcompat.view.menu.d param1d, boolean param1Boolean) {
      if (param1d instanceof k)
        param1d.z().d(false); 
      h.a a1 = this.a.m();
      if (a1 != null)
        a1.b(param1d, param1Boolean); 
    }
    
    public boolean c(androidx.appcompat.view.menu.d param1d) {
      boolean bool = false;
      if (param1d == null)
        return false; 
      this.a.D = ((k)param1d).getItem().getItemId();
      h.a a1 = this.a.m();
      if (a1 != null)
        bool = a1.c(param1d); 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */