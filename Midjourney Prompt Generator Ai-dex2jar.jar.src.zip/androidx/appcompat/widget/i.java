package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class i extends ImageButton {
  private final e a;
  
  private final j b;
  
  public i(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.a = e1;
    e1.e(paramAttributeSet, paramInt);
    j j1 = new j((ImageView)this);
    this.b = j1;
    j1.f(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.a;
    if (e1 != null)
      e1.b(); 
    j j1 = this.b;
    if (j1 != null)
      j1.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    j j1 = this.b;
    return (j1 != null) ? j1.c() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    j j1 = this.b;
    return (j1 != null) ? j1.d() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.b.e() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    j j1 = this.b;
    if (j1 != null)
      j1.b(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    j j1 = this.b;
    if (j1 != null)
      j1.b(); 
  }
  
  public void setImageResource(int paramInt) {
    this.b.g(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    j j1 = this.b;
    if (j1 != null)
      j1.b(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    j j1 = this.b;
    if (j1 != null)
      j1.h(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    j j1 = this.b;
    if (j1 != null)
      j1.i(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */