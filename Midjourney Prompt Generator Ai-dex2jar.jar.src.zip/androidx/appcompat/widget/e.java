package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.core.view.g0;
import c.j;

class e {
  private final View a;
  
  private final f b;
  
  private int c = -1;
  
  private n0 d;
  
  private n0 e;
  
  private n0 f;
  
  e(View paramView) {
    this.a = paramView;
    this.b = f.n();
  }
  
  private boolean a(@NonNull Drawable paramDrawable) {
    if (this.f == null)
      this.f = new n0(); 
    n0 n01 = this.f;
    n01.a();
    ColorStateList colorStateList = g0.h(this.a);
    if (colorStateList != null) {
      n01.d = true;
      n01.a = colorStateList;
    } 
    PorterDuff.Mode mode = g0.i(this.a);
    if (mode != null) {
      n01.c = true;
      n01.b = mode;
    } 
    if (n01.d || n01.c) {
      f.B(paramDrawable, n01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      n0 n01 = this.e;
      if (n01 != null) {
        f.B(drawable, n01, this.a.getDrawableState());
        return;
      } 
      n01 = this.d;
      if (n01 != null)
        f.B(drawable, n01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    n0 n01 = this.e;
    return (n01 != null) ? n01.a : null;
  }
  
  PorterDuff.Mode d() {
    n0 n01 = this.e;
    return (n01 != null) ? n01.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    p0 p0 = p0.s(this.a.getContext(), paramAttributeSet, j.X2, paramInt, 0);
    try {
      paramInt = j.Y2;
      if (p0.p(paramInt)) {
        this.c = p0.l(paramInt, -1);
        ColorStateList colorStateList = this.b.s(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.Z2;
      if (p0.p(paramInt))
        g0.C(this.a, p0.c(paramInt)); 
      paramInt = j.a3;
      if (p0.p(paramInt))
        g0.D(this.a, w.d(p0.i(paramInt, -1), null)); 
      return;
    } finally {
      p0.t();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    f f1 = this.b;
    if (f1 != null) {
      ColorStateList colorStateList = f1.s(this.a.getContext(), paramInt);
    } else {
      f1 = null;
    } 
    h((ColorStateList)f1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new n0(); 
      n0 n01 = this.d;
      n01.a = paramColorStateList;
      n01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new n0(); 
    n0 n01 = this.e;
    n01.a = paramColorStateList;
    n01.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new n0(); 
    n0 n01 = this.e;
    n01.b = paramMode;
    n01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */