package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.TypedValue;
import androidx.core.graphics.a;

class k0 {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  static final int[] b = new int[] { -16842910 };
  
  static final int[] c = new int[] { 16842908 };
  
  static final int[] d = new int[] { 16843518 };
  
  static final int[] e = new int[] { 16842919 };
  
  static final int[] f = new int[] { 16842912 };
  
  static final int[] g = new int[] { 16842913 };
  
  static final int[] h = new int[] { -16842919, -16842908 };
  
  static final int[] i = new int[0];
  
  private static final int[] j = new int[1];
  
  public static int a(Context paramContext, int paramInt) {
    ColorStateList colorStateList = d(paramContext, paramInt);
    if (colorStateList != null && colorStateList.isStateful())
      return colorStateList.getColorForState(b, colorStateList.getDefaultColor()); 
    TypedValue typedValue = e();
    paramContext.getTheme().resolveAttribute(16842803, typedValue, true);
    return c(paramContext, paramInt, typedValue.getFloat());
  }
  
  public static int b(Context paramContext, int paramInt) {
    null = j;
    null[0] = paramInt;
    p0 p0 = p0.r(paramContext, null, null);
    try {
      paramInt = p0.b(0, 0);
      return paramInt;
    } finally {
      p0.t();
    } 
  }
  
  static int c(Context paramContext, int paramInt, float paramFloat) {
    paramInt = b(paramContext, paramInt);
    return a.f(paramInt, Math.round(Color.alpha(paramInt) * paramFloat));
  }
  
  public static ColorStateList d(Context paramContext, int paramInt) {
    null = j;
    null[0] = paramInt;
    p0 p0 = p0.r(paramContext, null, null);
    try {
      return p0.c(0);
    } finally {
      p0.t();
    } 
  }
  
  private static TypedValue e() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */