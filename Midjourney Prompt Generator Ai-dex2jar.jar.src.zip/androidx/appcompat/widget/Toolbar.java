package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.k;
import androidx.core.view.g0;
import c.j;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  private int A;
  
  private boolean B;
  
  private boolean C;
  
  private final ArrayList<View> D = new ArrayList<View>();
  
  private final ArrayList<View> E = new ArrayList<View>();
  
  private final int[] F = new int[2];
  
  f G;
  
  private final ActionMenuView.e H = new a(this);
  
  private q0 I;
  
  private ActionMenuView a;
  
  private TextView b;
  
  private c b0;
  
  private TextView c;
  
  private d c0;
  
  private ImageButton d;
  
  private h.a d0;
  
  private ImageView e;
  
  private androidx.appcompat.view.menu.d.a e0;
  
  private Drawable f;
  
  private boolean f0;
  
  private CharSequence g;
  
  private final Runnable g0 = new b(this);
  
  ImageButton h;
  
  View i;
  
  private Context j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private h0 t;
  
  private int u;
  
  private int v;
  
  private int w = 8388627;
  
  private CharSequence x;
  
  private CharSequence y;
  
  private int z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, c.a.v);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    p0 p0 = p0.s(getContext(), paramAttributeSet, j.t2, paramInt, 0);
    this.l = p0.l(j.U2, 0);
    this.m = p0.l(j.L2, 0);
    this.w = p0.j(j.u2, this.w);
    this.n = p0.j(j.v2, 48);
    int i = p0.d(j.O2, 0);
    int j = j.T2;
    paramInt = i;
    if (p0.p(j))
      paramInt = p0.d(j, i); 
    this.s = paramInt;
    this.r = paramInt;
    this.q = paramInt;
    this.p = paramInt;
    paramInt = p0.d(j.R2, -1);
    if (paramInt >= 0)
      this.p = paramInt; 
    paramInt = p0.d(j.Q2, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = p0.d(j.S2, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = p0.d(j.P2, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    this.o = p0.e(j.G2, -1);
    paramInt = p0.d(j.C2, -2147483648);
    i = p0.d(j.y2, -2147483648);
    j = p0.e(j.A2, 0);
    int k = p0.e(j.B2, 0);
    f();
    this.t.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.t.g(paramInt, i); 
    this.u = p0.d(j.D2, -2147483648);
    this.v = p0.d(j.z2, -2147483648);
    this.f = p0.f(j.x2);
    this.g = p0.n(j.w2);
    CharSequence charSequence3 = p0.n(j.N2);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = p0.n(j.K2);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.j = getContext();
    setPopupTheme(p0.l(j.J2, 0));
    Drawable drawable2 = p0.f(j.I2);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = p0.n(j.H2);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = p0.f(j.E2);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = p0.n(j.F2);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.V2;
    if (p0.p(paramInt))
      setTitleTextColor(p0.b(paramInt, -1)); 
    paramInt = j.M2;
    if (p0.p(paramInt))
      setSubtitleTextColor(p0.b(paramInt, -1)); 
    p0.t();
  }
  
  private boolean E() {
    if (!this.f0)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (F(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean F(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = g0.k((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = androidx.core.view.d.a(paramInt, g0.k((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && F(view) && n(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && F(view) && n(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = k();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = m((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.i != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.E.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private void f() {
    if (this.t == null)
      this.t = new h0(); 
  }
  
  private void g() {
    if (this.e == null)
      this.e = new k(getContext()); 
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new g.d(getContext());
  }
  
  private void h() {
    i();
    if (this.a.G() == null) {
      androidx.appcompat.view.menu.d d1 = (androidx.appcompat.view.menu.d)this.a.getMenu();
      if (this.c0 == null)
        this.c0 = new d(this); 
      this.a.setExpandedActionViewsExclusive(true);
      d1.b(this.c0, this.j);
    } 
  }
  
  private void i() {
    if (this.a == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.a = actionMenuView;
      actionMenuView.setPopupTheme(this.k);
      this.a.setOnMenuItemClickListener(this.H);
      this.a.H(this.d0, this.e0);
      e e1 = k();
      e1.a = 0x800005 | this.n & 0x70;
      this.a.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.a, false);
    } 
  }
  
  private void j() {
    if (this.d == null) {
      this.d = new i(getContext(), null, c.a.u);
      e e1 = k();
      e1.a = 0x800003 | this.n & 0x70;
      this.d.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int n(int paramInt) {
    int i = g0.k((View)this);
    int j = androidx.core.view.d.a(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int o(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = p(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int p(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.w & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int q(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return androidx.core.view.g.b(marginLayoutParams) + androidx.core.view.g.a(marginLayoutParams);
  }
  
  private int r(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int s(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)e1).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)e1).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean t(View paramView) {
    return (paramView.getParent() == this || this.E.contains(paramView));
  }
  
  private int v(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = o(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  private int w(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = o(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int x(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void y(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void z() {
    removeCallbacks(this.g0);
    post(this.g0);
  }
  
  void A() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.a) {
        removeViewAt(i);
        this.E.add(view);
      } 
    } 
  }
  
  public void B(int paramInt1, int paramInt2) {
    f();
    this.t.g(paramInt1, paramInt2);
  }
  
  public void C(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void D(Context paramContext, int paramInt) {
    this.l = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean G() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.I());
  }
  
  void a() {
    for (int i = this.E.size() - 1; i >= 0; i--)
      addView(this.E.get(i)); 
    this.E.clear();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public void d() {
    androidx.appcompat.view.menu.e e1;
    d d1 = this.c0;
    if (d1 == null) {
      d1 = null;
    } else {
      e1 = d1.b;
    } 
    if (e1 != null)
      e1.collapseActionView(); 
  }
  
  void e() {
    if (this.h == null) {
      i i = new i(getContext(), null, c.a.u);
      this.h = i;
      i.setImageDrawable(this.f);
      this.h.setContentDescription(this.g);
      e e1 = k();
      e1.a = 0x800003 | this.n & 0x70;
      e1.b = 2;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.h.setOnClickListener(new c(this));
    } 
  }
  
  public int getContentInsetEnd() {
    h0 h01 = this.t;
    return (h01 != null) ? h01.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.v;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    h0 h01 = this.t;
    return (h01 != null) ? h01.b() : 0;
  }
  
  public int getContentInsetRight() {
    h0 h01 = this.t;
    return (h01 != null) ? h01.c() : 0;
  }
  
  public int getContentInsetStart() {
    h0 h01 = this.t;
    return (h01 != null) ? h01.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.u;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual G : ()Landroidx/appcompat/view/menu/d;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield v : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (g0.k((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (g0.k((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.u, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    h();
    return this.a.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.b0;
  }
  
  public Drawable getOverflowIcon() {
    h();
    return this.a.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.j;
  }
  
  public int getPopupTheme() {
    return this.k;
  }
  
  public CharSequence getSubtitle() {
    return this.y;
  }
  
  public CharSequence getTitle() {
    return this.x;
  }
  
  public int getTitleMarginBottom() {
    return this.s;
  }
  
  public int getTitleMarginEnd() {
    return this.q;
  }
  
  public int getTitleMarginStart() {
    return this.p;
  }
  
  public int getTitleMarginTop() {
    return this.r;
  }
  
  public v getWrapper() {
    if (this.I == null)
      this.I = new q0(this, true); 
    return this.I;
  }
  
  protected e k() {
    return new e(-2, -2);
  }
  
  public e l(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e m(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof d.a) ? new e((d.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.g0);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.C = false; 
    if (!this.C) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.C = true; 
    } 
    if (i == 10 || i == 3)
      this.C = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (g0.k((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.F;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = g0.l((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (F((View)this.d)) {
      if (k) {
        j = w((View)this.d, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = v((View)this.d, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (F((View)this.h))
      if (k) {
        paramInt2 = w((View)this.h, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = v((View)this.h, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (F((View)this.a))
      if (k) {
        j = v((View)this.a, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = w((View)this.a, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (F(this.i))
      if (k) {
        j = w(this.i, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = v(this.i, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (F((View)this.e))
      if (k) {
        paramInt2 = w((View)this.e, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = v((View)this.e, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = F((View)this.b);
    boolean bool = F((View)this.c);
    if (paramBoolean) {
      e e1 = (e)this.b.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.c.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.b;
      } else {
        textView1 = this.c;
      } 
      if (bool) {
        textView2 = this.c;
      } else {
        textView2 = this.b;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.b.getMeasuredWidth() > 0) || (bool && this.c.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.w & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.r;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.s;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.s - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.r;
      } 
      if (k) {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          m = paramInt2 - this.b.getMeasuredWidth();
          k = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.q;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth();
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.q;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          k = this.b.getMeasuredWidth() + paramInt3;
          m = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(paramInt3, paramInt1, k, m);
          k += this.q;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth() + paramInt3;
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.q;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.D, 3);
        k = this.D.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.D, 3);
    int k = this.D.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.d d1 = actionMenuView.G();
    } else {
      actionMenuView = null;
    } 
    int i = g.c;
    if (i != 0 && this.c0 != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.d)
      z(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    f();
    h0 h01 = this.t;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    h01.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.c0;
    if (d1 != null) {
      androidx.appcompat.view.menu.e e1 = d1.b;
      if (e1 != null)
        g.c = e1.getItemId(); 
    } 
    g.d = u();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.B = false; 
    if (!this.B) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.B = true; 
    } 
    if (i == 1 || i == 3)
      this.B = false; 
    return true;
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.f0 = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.v) {
      this.v = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.u) {
      this.u = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(e.b.d(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      if (!t((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageView imageView1 = this.e;
      if (imageView1 != null && t((View)imageView1)) {
        removeView((View)this.e);
        this.E.remove(this.e);
      } 
    } 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      j(); 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(e.b.d(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      j();
      if (!t((View)this.d))
        c((View)this.d, true); 
    } else {
      ImageButton imageButton1 = this.d;
      if (imageButton1 != null && t((View)imageButton1)) {
        removeView((View)this.d);
        this.E.remove(this.d);
      } 
    } 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    j();
    this.d.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.G = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    h();
    this.a.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      if (paramInt == 0) {
        this.j = getContext();
        return;
      } 
      this.j = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        r r = new r(context);
        this.c = r;
        r.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        i = this.A;
        if (i != 0)
          this.c.setTextColor(i); 
      } 
      if (!t((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && t((View)textView1)) {
        removeView((View)this.c);
        this.E.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.y = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    this.A = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramInt); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.b == null) {
        Context context = getContext();
        r r = new r(context);
        this.b = r;
        r.setSingleLine();
        this.b.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.l;
        if (i != 0)
          this.b.setTextAppearance(context, i); 
        i = this.z;
        if (i != 0)
          this.b.setTextColor(i); 
      } 
      if (!t((View)this.b))
        c((View)this.b, true); 
    } else {
      TextView textView1 = this.b;
      if (textView1 != null && t((View)textView1)) {
        removeView((View)this.b);
        this.E.remove(this.b);
      } 
    } 
    TextView textView = this.b;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.x = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    this.z = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextColor(paramInt); 
  }
  
  public boolean u() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.D());
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Toolbar.f f = this.a.G;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.a.G();
    }
  }
  
  class c implements View.OnClickListener {
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.a.d();
    }
  }
  
  private class d implements h {
    androidx.appcompat.view.menu.d a;
    
    androidx.appcompat.view.menu.e b;
    
    d(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.d param1d, boolean param1Boolean) {}
    
    public void c(boolean param1Boolean) {
      if (this.b != null) {
        androidx.appcompat.view.menu.d d1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (d1 != null) {
          int j = d1.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < j) {
              if (this.a.getItem(i) == this.b) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          e(this.a, this.b); 
      } 
    }
    
    public boolean d() {
      return false;
    }
    
    public boolean e(androidx.appcompat.view.menu.d param1d, androidx.appcompat.view.menu.e param1e) {
      View view = this.c.i;
      if (view instanceof g.b)
        ((g.b)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.c;
      toolbar.removeView(toolbar.i);
      toolbar = this.c;
      toolbar.removeView((View)toolbar.h);
      toolbar = this.c;
      toolbar.i = null;
      toolbar.a();
      this.b = null;
      this.c.requestLayout();
      param1e.r(false);
      return true;
    }
    
    public boolean g(androidx.appcompat.view.menu.d param1d, androidx.appcompat.view.menu.e param1e) {
      this.c.e();
      ViewParent viewParent = this.c.h.getParent();
      Toolbar toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.h); 
        Toolbar toolbar1 = this.c;
        toolbar1.addView((View)toolbar1.h);
      } 
      this.c.i = param1e.getActionView();
      this.b = param1e;
      viewParent = this.c.i.getParent();
      toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.i); 
        Toolbar.e e1 = this.c.k();
        toolbar = this.c;
        e1.a = 0x800003 | toolbar.n & 0x70;
        e1.b = 2;
        toolbar.i.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar1 = this.c;
        toolbar1.addView(toolbar1.i);
      } 
      this.c.A();
      this.c.requestLayout();
      param1e.r(true);
      View view = this.c.i;
      if (view instanceof g.b)
        ((g.b)view).onActionViewExpanded(); 
      return true;
    }
    
    public void i(Context param1Context, androidx.appcompat.view.menu.d param1d) {
      androidx.appcompat.view.menu.d d1 = this.a;
      if (d1 != null) {
        androidx.appcompat.view.menu.e e1 = this.b;
        if (e1 != null)
          d1.e(e1); 
      } 
      this.a = param1d;
    }
    
    public boolean k(k param1k) {
      return false;
    }
  }
  
  public static class e extends d.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(@NonNull Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(d.a param1a) {
      super(param1a);
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends t.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int c;
    
    boolean d;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.c = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.d = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g a(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] c(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g a(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] c(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */