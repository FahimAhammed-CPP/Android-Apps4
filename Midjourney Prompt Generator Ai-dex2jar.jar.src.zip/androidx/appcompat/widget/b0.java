package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.core.view.g0;
import androidx.core.widget.i;
import c.j;
import h.h;
import java.lang.reflect.Method;

public class b0 implements h {
  private static Method H;
  
  private static Method I;
  
  private static Method X;
  
  private final c A = new c(this);
  
  private Runnable B;
  
  final Handler C;
  
  private final Rect D = new Rect();
  
  private Rect E;
  
  private boolean F;
  
  PopupWindow G;
  
  private Context a;
  
  private ListAdapter b;
  
  x c;
  
  private int d = -2;
  
  private int e = -2;
  
  private int f;
  
  private int g;
  
  private int h = 1002;
  
  private boolean i;
  
  private boolean j = true;
  
  private boolean k;
  
  private boolean l;
  
  private int m = 0;
  
  private boolean n = false;
  
  private boolean o = false;
  
  int p = Integer.MAX_VALUE;
  
  private View q;
  
  private int r = 0;
  
  private DataSetObserver s;
  
  private View t;
  
  private Drawable u;
  
  private AdapterView.OnItemClickListener v;
  
  private AdapterView.OnItemSelectedListener w;
  
  final g x = new g(this);
  
  private final f y = new f(this);
  
  private final e z = new e(this);
  
  static {
    try {
      H = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
    } 
    try {
      I = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
    } 
    try {
      X = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
    } 
  }
  
  public b0(@NonNull Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public b0(@NonNull Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.C = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.O0, paramInt1, paramInt2);
    this.f = typedArray.getDimensionPixelOffset(j.P0, 0);
    int i = typedArray.getDimensionPixelOffset(j.Q0, 0);
    this.g = i;
    if (i != 0)
      this.i = true; 
    typedArray.recycle();
    l l = new l(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.G = l;
    l.setInputMethodMode(1);
  }
  
  private void E(boolean paramBoolean) {
    Method method = H;
    if (method != null)
      try {
        method.invoke(this.G, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      } catch (Exception exception) {
        Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
      }  
  }
  
  private int d() {
    byte b1;
    byte b2;
    x x1 = this.c;
    boolean bool = true;
    if (x1 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.a;
      this.B = new a(this);
      x x3 = g(context, this.F ^ true);
      this.c = x3;
      Drawable drawable1 = this.u;
      if (drawable1 != null)
        x3.setSelector(drawable1); 
      this.c.setAdapter(this.b);
      this.c.setOnItemClickListener(this.v);
      this.c.setFocusable(true);
      this.c.setFocusableInTouchMode(true);
      this.c.setOnItemSelectedListener(new b(this));
      this.c.setOnScrollListener(this.z);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.w;
      if (onItemSelectedListener != null)
        this.c.setOnItemSelectedListener(onItemSelectedListener); 
      x x2 = this.c;
      View view = this.q;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.r;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.r);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.e;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.G.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.G.getContentView();
      View view = this.q;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.G.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.D);
      Rect rect = this.D;
      int m = rect.top;
      int k = rect.bottom + m;
      b2 = k;
      if (!this.i) {
        this.g = -m;
        b2 = k;
      } 
    } else {
      this.D.setEmpty();
      b2 = 0;
    } 
    if (this.G.getInputMethodMode() != 2)
      bool = false; 
    int j = l(h(), this.g, bool);
    if (this.n || this.d == -1)
      return j + b2; 
    int i = this.e;
    if (i != -2) {
      if (i != -1) {
        i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
      } else {
        i = (this.a.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.D;
        i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, 1073741824);
      } 
    } else {
      i = (this.a.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.D;
      i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, -2147483648);
    } 
    j = this.c.d(i, 0, -1, j - b1, -1);
    i = b1;
    if (j > 0)
      i = b1 + b2 + this.c.getPaddingTop() + this.c.getPaddingBottom(); 
    return j + i;
  }
  
  private int l(View paramView, int paramInt, boolean paramBoolean) {
    Method method = I;
    if (method != null)
      try {
        return ((Integer)method.invoke(this.G, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
      } catch (Exception exception) {
        Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
      }  
    return this.G.getMaxAvailableHeight(paramView, paramInt);
  }
  
  private void q() {
    View view = this.q;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.q); 
    } 
  }
  
  public void A(boolean paramBoolean) {
    this.F = paramBoolean;
    this.G.setFocusable(paramBoolean);
  }
  
  public void B(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.G.setOnDismissListener(paramOnDismissListener);
  }
  
  public void C(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.v = paramOnItemClickListener;
  }
  
  public void D(boolean paramBoolean) {
    this.l = true;
    this.k = paramBoolean;
  }
  
  public void F(int paramInt) {
    this.r = paramInt;
  }
  
  public void G(int paramInt) {
    x x1 = this.c;
    if (f() && x1 != null) {
      x1.setListSelectionHidden(false);
      x1.setSelection(paramInt);
      if (x1.getChoiceMode() != 0)
        x1.setItemChecked(paramInt, true); 
    } 
  }
  
  public void H(int paramInt) {
    this.g = paramInt;
    this.i = true;
  }
  
  public void I(int paramInt) {
    this.e = paramInt;
  }
  
  public void a() {
    int i;
    int j = d();
    boolean bool1 = o();
    i.b(this.G, this.h);
    boolean bool2 = this.G.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!g0.r(h()))
        return; 
      int m = this.e;
      if (m == -1) {
        i = -1;
      } else {
        i = m;
        if (m == -2)
          i = h().getWidth(); 
      } 
      m = this.d;
      if (m == -1) {
        if (!bool1)
          j = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.G;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.G.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.G;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.G.setHeight(-1);
        } 
      } else if (m != -2) {
        j = m;
      } 
      PopupWindow popupWindow1 = this.G;
      if (this.o || this.n)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.G;
      View view = h();
      m = this.f;
      int n = this.g;
      if (i < 0)
        i = -1; 
      if (j < 0)
        j = -1; 
      popupWindow1.update(view, m, n, i, j);
      return;
    } 
    int k = this.e;
    if (k == -1) {
      i = -1;
    } else {
      i = k;
      if (k == -2)
        i = h().getWidth(); 
    } 
    k = this.d;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = k;
    } 
    this.G.setWidth(i);
    this.G.setHeight(j);
    E(true);
    PopupWindow popupWindow = this.G;
    if (!this.o && !this.n) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.G.setTouchInterceptor(this.y);
    if (this.l)
      i.a(this.G, this.k); 
    Method method = X;
    if (method != null)
      try {
        method.invoke(this.G, new Object[] { this.E });
      } catch (Exception exception) {
        Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
      }  
    i.c(this.G, h(), this.f, this.g, this.m);
    this.c.setSelection(-1);
    if (!this.F || this.c.isInTouchMode())
      e(); 
    if (!this.F)
      this.C.post(this.A); 
  }
  
  public void dismiss() {
    this.G.dismiss();
    q();
    this.G.setContentView(null);
    this.c = null;
    this.C.removeCallbacks(this.x);
  }
  
  public void e() {
    x x1 = this.c;
    if (x1 != null) {
      x1.setListSelectionHidden(true);
      x1.requestLayout();
    } 
  }
  
  public boolean f() {
    return this.G.isShowing();
  }
  
  @NonNull
  x g(Context paramContext, boolean paramBoolean) {
    return new x(paramContext, paramBoolean);
  }
  
  public View h() {
    return this.t;
  }
  
  public Drawable i() {
    return this.G.getBackground();
  }
  
  public ListView j() {
    return this.c;
  }
  
  public int k() {
    return this.f;
  }
  
  public int m() {
    return !this.i ? 0 : this.g;
  }
  
  public int n() {
    return this.e;
  }
  
  public boolean o() {
    return (this.G.getInputMethodMode() == 2);
  }
  
  public boolean p() {
    return this.F;
  }
  
  public void r(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.s;
    if (dataSetObserver == null) {
      this.s = new d(this);
    } else {
      ListAdapter listAdapter = this.b;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.b = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.s); 
    x x1 = this.c;
    if (x1 != null)
      x1.setAdapter(this.b); 
  }
  
  public void s(View paramView) {
    this.t = paramView;
  }
  
  public void t(int paramInt) {
    this.G.setAnimationStyle(paramInt);
  }
  
  public void u(Drawable paramDrawable) {
    this.G.setBackgroundDrawable(paramDrawable);
  }
  
  public void v(int paramInt) {
    Drawable drawable = this.G.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.D);
      Rect rect = this.D;
      this.e = rect.left + rect.right + paramInt;
      return;
    } 
    I(paramInt);
  }
  
  public void w(int paramInt) {
    this.m = paramInt;
  }
  
  public void x(Rect paramRect) {
    this.E = paramRect;
  }
  
  public void y(int paramInt) {
    this.f = paramInt;
  }
  
  public void z(int paramInt) {
    this.G.setInputMethodMode(paramInt);
  }
  
  class a implements Runnable {
    a(b0 this$0) {}
    
    public void run() {
      View view = this.a.h();
      if (view != null && view.getWindowToken() != null)
        this.a.a(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(b0 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        x x = this.a.c;
        if (x != null)
          x.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  private class c implements Runnable {
    c(b0 this$0) {}
    
    public void run() {
      this.a.e();
    }
  }
  
  private class d extends DataSetObserver {
    d(b0 this$0) {}
    
    public void onChanged() {
      if (this.a.f())
        this.a.a(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class e implements AbsListView.OnScrollListener {
    e(b0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.o() && this.a.G.getContentView() != null) {
        b0 b01 = this.a;
        b01.C.removeCallbacks(b01.x);
        this.a.x.run();
      } 
    }
  }
  
  private class f implements View.OnTouchListener {
    f(b0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.a.G;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.a.G.getWidth() && k >= 0 && k < this.a.G.getHeight()) {
          b0 b01 = this.a;
          b01.C.postDelayed(b01.x, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        b0 b01 = this.a;
        b01.C.removeCallbacks(b01.x);
      } 
      return false;
    }
  }
  
  private class g implements Runnable {
    g(b0 this$0) {}
    
    public void run() {
      x x = this.a.c;
      if (x != null && g0.r((View)x) && this.a.c.getCount() > this.a.c.getChildCount()) {
        int i = this.a.c.getChildCount();
        b0 b01 = this.a;
        if (i <= b01.p) {
          b01.G.setInputMethodMode(2);
          this.a.a();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */