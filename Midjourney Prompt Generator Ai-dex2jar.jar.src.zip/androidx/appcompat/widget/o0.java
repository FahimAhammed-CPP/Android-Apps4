package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;

class o0 extends g0 {
  private final WeakReference<Context> b;
  
  public o0(@NonNull Context paramContext, @NonNull Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public Drawable getDrawable(int paramInt) {
    Drawable drawable = super.getDrawable(paramInt);
    Context context = this.b.get();
    if (drawable != null && context != null) {
      f.n();
      f.C(context, paramInt, drawable);
    } 
    return drawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */