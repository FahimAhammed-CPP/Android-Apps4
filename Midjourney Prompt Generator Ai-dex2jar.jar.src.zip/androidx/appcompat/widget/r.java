package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.widget.b;
import androidx.core.widget.n;
import java.util.concurrent.Future;
import q.c;

public class r extends TextView implements b {
  private final e a;
  
  private final q b;
  
  private Future<c> c;
  
  public r(Context paramContext) {
    this(paramContext, null);
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.a = e1;
    e1.e(paramAttributeSet, paramInt);
    q q1 = new q(this);
    this.b = q1;
    q1.k(paramAttributeSet, paramInt);
    q1.b();
  }
  
  private void e() {
    Future<c> future = this.c;
    if (future != null)
      try {
        this.c = null;
        n.i(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.a;
    if (e1 != null)
      e1.b(); 
    q q1 = this.b;
    if (q1 != null)
      q1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.J)
      return super.getAutoSizeMaxTextSize(); 
    q q1 = this.b;
    return (q1 != null) ? q1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.J)
      return super.getAutoSizeMinTextSize(); 
    q q1 = this.b;
    return (q1 != null) ? q1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.J)
      return super.getAutoSizeStepGranularity(); 
    q q1 = this.b;
    return (q1 != null) ? q1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.J)
      return super.getAutoSizeTextAvailableSizes(); 
    q q1 = this.b;
    return (q1 != null) ? q1.h() : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = b.J;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    q q1 = this.b;
    return (q1 != null) ? q1.i() : 0;
  }
  
  public int getFirstBaselineToTopHeight() {
    return n.a(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return n.b(this);
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  public CharSequence getText() {
    e();
    return super.getText();
  }
  
  @NonNull
  public c.a getTextMetricsParamsCompat() {
    return n.e(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return h.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    q q1 = this.b;
    if (q1 != null)
      q1.m(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    e();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    q q1 = this.b;
    if (q1 != null && !b.J && q1.j())
      this.b.c(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.J) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    q q1 = this.b;
    if (q1 != null)
      q1.p(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] paramArrayOfint, int paramInt) {
    if (b.J) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    q q1 = this.b;
    if (q1 != null)
      q1.q(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.J) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    q q1 = this.b;
    if (q1 != null)
      q1.r(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(n.k(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    n.f(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    n.g(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    n.h(this, paramInt);
  }
  
  public void setPrecomputedText(@NonNull c paramc) {
    n.i(this, paramc);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    q q1 = this.b;
    if (q1 != null)
      q1.n(paramContext, paramInt); 
  }
  
  public void setTextFuture(@NonNull Future<c> paramFuture) {
    this.c = paramFuture;
    requestLayout();
  }
  
  public void setTextMetricsParamsCompat(@NonNull c.a parama) {
    n.j(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.J) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    q q1 = this.b;
    if (q1 != null)
      q1.s(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */