package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.core.widget.i;
import c.j;

class l extends PopupWindow {
  private static final boolean b = false;
  
  private boolean a;
  
  public l(@NonNull Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    a(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  private void a(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    p0 p0 = p0.s(paramContext, paramAttributeSet, j.B1, paramInt1, paramInt2);
    paramInt1 = j.D1;
    if (p0.p(paramInt1))
      b(p0.a(paramInt1, false)); 
    setBackgroundDrawable(p0.f(j.C1));
    p0.t();
  }
  
  private void b(boolean paramBoolean) {
    if (b) {
      this.a = paramBoolean;
      return;
    } 
    i.a(this, paramBoolean);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i, paramInt3);
  }
  
  public void update(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.update(paramView, paramInt1, i, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */