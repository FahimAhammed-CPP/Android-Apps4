package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.c;
import androidx.appcompat.view.menu.d;
import androidx.appcompat.view.menu.e;
import java.lang.reflect.Method;

public class f0 extends b0 implements c0 {
  private static Method Z;
  
  private c0 Y;
  
  static {
    try {
      Z = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
      return;
    } 
  }
  
  public f0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void J(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      e0.a(this.G, (Transition)paramObject); 
  }
  
  public void K(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      d0.a(this.G, (Transition)paramObject); 
  }
  
  public void L(c0 paramc0) {
    this.Y = paramc0;
  }
  
  public void M(boolean paramBoolean) {
    Method method = Z;
    if (method != null)
      try {
        method.invoke(this.G, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      } catch (Exception exception) {
        Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
      }  
  }
  
  public void b(@NonNull d paramd, @NonNull MenuItem paramMenuItem) {
    c0 c01 = this.Y;
    if (c01 != null)
      c01.b(paramd, paramMenuItem); 
  }
  
  public void c(@NonNull d paramd, @NonNull MenuItem paramMenuItem) {
    c0 c01 = this.Y;
    if (c01 != null)
      c01.c(paramd, paramMenuItem); 
  }
  
  x g(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends x {
    final int n;
    
    final int o;
    
    private c0 p;
    
    private MenuItem q;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == param1Context.getResources().getConfiguration().getLayoutDirection()) {
        this.n = 21;
        this.o = 22;
        return;
      } 
      this.n = 22;
      this.o = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.p != null) {
        int i;
        c c;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          c = (c)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          c = c;
        } 
        e e2 = null;
        e e1 = e2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          e1 = e2;
          if (j != -1) {
            i = j - i;
            e1 = e2;
            if (i >= 0) {
              e1 = e2;
              if (i < c.getCount())
                e1 = c.c(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.q;
        if (menuItem != e1) {
          d d = c.b();
          if (menuItem != null)
            this.p.c(d, menuItem); 
          this.q = (MenuItem)e1;
          if (e1 != null)
            this.p.b(d, (MenuItem)e1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.n) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.o) {
        setSelection(-1);
        ((c)getAdapter()).b().d(false);
        return true;
      } 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
    
    public void setHoverListener(c0 param1c0) {
      this.p = param1c0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */