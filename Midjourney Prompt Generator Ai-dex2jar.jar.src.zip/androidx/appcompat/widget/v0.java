package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;

public class v0 extends Resources {
  private static boolean b = false;
  
  private final WeakReference<Context> a;
  
  public v0(@NonNull Context paramContext, @NonNull Resources paramResources) {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.a = new WeakReference<Context>(paramContext);
  }
  
  public static boolean a() {
    return b;
  }
  
  public static boolean b() {
    a();
    return false;
  }
  
  final Drawable c(int paramInt) {
    return super.getDrawable(paramInt);
  }
  
  public Drawable getDrawable(int paramInt) {
    Context context = this.a.get();
    return (context != null) ? f.n().y(context, this, paramInt) : super.getDrawable(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */