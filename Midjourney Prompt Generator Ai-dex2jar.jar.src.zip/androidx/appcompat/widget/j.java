package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.core.widget.f;
import e.b;

public class j {
  private final ImageView a;
  
  private n0 b;
  
  private n0 c;
  
  private n0 d;
  
  public j(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(@NonNull Drawable paramDrawable) {
    if (this.d == null)
      this.d = new n0(); 
    n0 n01 = this.d;
    n01.a();
    ColorStateList colorStateList = f.a(this.a);
    if (colorStateList != null) {
      n01.d = true;
      n01.a = colorStateList;
    } 
    PorterDuff.Mode mode = f.b(this.a);
    if (mode != null) {
      n01.c = true;
      n01.b = mode;
    } 
    if (n01.d || n01.c) {
      f.B(paramDrawable, n01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean j() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      w.b(drawable); 
    if (drawable != null) {
      if (j() && a(drawable))
        return; 
      n0 n01 = this.c;
      if (n01 != null) {
        f.B(drawable, n01, this.a.getDrawableState());
        return;
      } 
      n01 = this.b;
      if (n01 != null)
        f.B(drawable, n01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    n0 n01 = this.c;
    return (n01 != null) ? n01.a : null;
  }
  
  PorterDuff.Mode d() {
    n0 n01 = this.c;
    return (n01 != null) ? n01.b : null;
  }
  
  boolean e() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void f(AttributeSet paramAttributeSet, int paramInt) {
    p0 p0 = p0.s(this.a.getContext(), paramAttributeSet, c.j.T, paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = p0.l(c.j.U, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = b.d(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        w.b(drawable1); 
      paramInt = c.j.V;
      if (p0.p(paramInt))
        f.c(this.a, p0.c(paramInt)); 
      paramInt = c.j.W;
      if (p0.p(paramInt))
        f.d(this.a, w.d(p0.i(paramInt, -1), null)); 
      return;
    } finally {
      p0.t();
    } 
  }
  
  public void g(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = b.d(this.a.getContext(), paramInt);
      if (drawable != null)
        w.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new n0(); 
    n0 n01 = this.c;
    n01.a = paramColorStateList;
    n01.d = true;
    b();
  }
  
  void i(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new n0(); 
    n0 n01 = this.c;
    n01.b = paramMode;
    n01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */