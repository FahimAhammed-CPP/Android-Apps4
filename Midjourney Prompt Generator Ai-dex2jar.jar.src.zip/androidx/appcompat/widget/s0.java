package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;
import androidx.annotation.NonNull;

public class s0 {
  public static void a(@NonNull View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      r0.a(paramView, paramCharSequence);
      return;
    } 
    t0.f(paramView, paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\widget\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */