package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import c.j;

public class AlertController$RecycleListView extends ListView {
  private final int a;
  
  private final int b;
  
  public AlertController$RecycleListView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.F1);
    this.b = typedArray.getDimensionPixelOffset(j.G1, -1);
    this.a = typedArray.getDimensionPixelOffset(j.H1, -1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\app\AlertController$RecycleListView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */