package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.f0;
import androidx.core.view.g0;
import c.d;
import c.g;

final class j extends f implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int v = g.j;
  
  private final Context b;
  
  private final d c;
  
  private final c d;
  
  private final boolean e;
  
  private final int f;
  
  private final int g;
  
  private final int h;
  
  final f0 i;
  
  final ViewTreeObserver.OnGlobalLayoutListener j = new a(this);
  
  private final View.OnAttachStateChangeListener k = new b(this);
  
  private PopupWindow.OnDismissListener l;
  
  private View m;
  
  View n;
  
  private h.a o;
  
  ViewTreeObserver p;
  
  private boolean q;
  
  private boolean r;
  
  private int s;
  
  private int t = 0;
  
  private boolean u;
  
  public j(Context paramContext, d paramd, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.b = paramContext;
    this.c = paramd;
    this.e = paramBoolean;
    this.d = new c(paramd, LayoutInflater.from(paramContext), paramBoolean, v);
    this.g = paramInt1;
    this.h = paramInt2;
    Resources resources = paramContext.getResources();
    this.f = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.m = paramView;
    this.i = new f0(paramContext, null, paramInt1, paramInt2);
    paramd.b(this, paramContext);
  }
  
  private boolean z() {
    if (f())
      return true; 
    if (!this.q) {
      boolean bool;
      View view = this.m;
      if (view == null)
        return false; 
      this.n = view;
      this.i.B(this);
      this.i.C(this);
      this.i.A(true);
      view = this.n;
      if (this.p == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.p = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.j); 
      view.addOnAttachStateChangeListener(this.k);
      this.i.s(view);
      this.i.w(this.t);
      if (!this.r) {
        this.s = f.o((ListAdapter)this.d, null, this.b, this.f);
        this.r = true;
      } 
      this.i.v(this.s);
      this.i.z(2);
      this.i.x(n());
      this.i.a();
      ListView listView = this.i.j();
      listView.setOnKeyListener(this);
      if (this.u && this.c.u() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.b).inflate(g.i, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.c.u()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.i.r((ListAdapter)this.d);
      this.i.a();
      return true;
    } 
    return false;
  }
  
  public void a() {
    if (z())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void b(d paramd, boolean paramBoolean) {
    if (paramd != this.c)
      return; 
    dismiss();
    h.a a1 = this.o;
    if (a1 != null)
      a1.b(paramd, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    this.r = false;
    c c1 = this.d;
    if (c1 != null)
      c1.notifyDataSetChanged(); 
  }
  
  public boolean d() {
    return false;
  }
  
  public void dismiss() {
    if (f())
      this.i.dismiss(); 
  }
  
  public boolean f() {
    return (!this.q && this.i.f());
  }
  
  public void h(h.a parama) {
    this.o = parama;
  }
  
  public ListView j() {
    return this.i.j();
  }
  
  public boolean k(k paramk) {
    if (paramk.hasVisibleItems()) {
      g g = new g(this.b, paramk, this.n, this.e, this.g, this.h);
      g.j(this.o);
      g.g(f.x(paramk));
      g.i(this.l);
      this.l = null;
      this.c.d(false);
      int m = this.i.k();
      int n = this.i.m();
      int i = m;
      if ((Gravity.getAbsoluteGravity(this.t, g0.k(this.m)) & 0x7) == 5)
        i = m + this.m.getWidth(); 
      if (g.n(i, n)) {
        h.a a1 = this.o;
        if (a1 != null)
          a1.c(paramk); 
        return true;
      } 
    } 
    return false;
  }
  
  public void l(d paramd) {}
  
  public void onDismiss() {
    this.q = true;
    this.c.close();
    ViewTreeObserver viewTreeObserver = this.p;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.p = this.n.getViewTreeObserver(); 
      this.p.removeGlobalOnLayoutListener(this.j);
      this.p = null;
    } 
    this.n.removeOnAttachStateChangeListener(this.k);
    PopupWindow.OnDismissListener onDismissListener = this.l;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(View paramView) {
    this.m = paramView;
  }
  
  public void r(boolean paramBoolean) {
    this.d.d(paramBoolean);
  }
  
  public void s(int paramInt) {
    this.t = paramInt;
  }
  
  public void t(int paramInt) {
    this.i.y(paramInt);
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.l = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void w(int paramInt) {
    this.i.H(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(j this$0) {}
    
    public void onGlobalLayout() {
      if (this.a.f() && !this.a.i.p()) {
        View view = this.a.n;
        if (view == null || !view.isShown()) {
          this.a.dismiss();
          return;
        } 
        this.a.i.a();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(j this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.a.p;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.a.p = param1View.getViewTreeObserver(); 
        j j1 = this.a;
        j1.p.removeGlobalOnLayoutListener(j1.j);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */