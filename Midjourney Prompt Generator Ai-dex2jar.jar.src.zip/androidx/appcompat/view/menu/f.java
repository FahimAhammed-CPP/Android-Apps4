package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import h.h;

abstract class f implements h, h, AdapterView.OnItemClickListener {
  private Rect a;
  
  protected static int o(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int m = View.MeasureSpec.makeMeasureSpec(0, 0);
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i1 = paramListAdapter.getCount();
    ViewGroup viewGroup2 = null;
    int j = 0;
    int k = 0;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (i < i1) {
      FrameLayout frameLayout2;
      int i3 = paramListAdapter.getItemViewType(i);
      int i2 = k;
      if (i3 != k) {
        paramViewGroup = null;
        i2 = i3;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(i, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(m, n);
      i3 = view.getMeasuredWidth();
      if (i3 >= paramInt)
        return paramInt; 
      k = j;
      if (i3 > j)
        k = i3; 
      i++;
      j = k;
      k = i2;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return j;
  }
  
  protected static boolean x(d paramd) {
    int j = paramd.size();
    for (int i = 0; i < j; i++) {
      MenuItem menuItem = paramd.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  protected static c y(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (c)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (c)paramListAdapter;
  }
  
  public boolean e(d paramd, e parame) {
    return false;
  }
  
  public boolean g(d paramd, e parame) {
    return false;
  }
  
  public void i(@NonNull Context paramContext, d paramd) {}
  
  public abstract void l(d paramd);
  
  protected boolean m() {
    return true;
  }
  
  public Rect n() {
    return this.a;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    d d = (y(listAdapter)).a;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (m()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    d.I(menuItem, this, paramInt);
  }
  
  public abstract void p(View paramView);
  
  public void q(Rect paramRect) {
    this.a = paramRect;
  }
  
  public abstract void r(boolean paramBoolean);
  
  public abstract void s(int paramInt);
  
  public abstract void t(int paramInt);
  
  public abstract void u(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void v(boolean paramBoolean);
  
  public abstract void w(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */