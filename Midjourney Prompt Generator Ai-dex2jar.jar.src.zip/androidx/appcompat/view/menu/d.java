package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import androidx.core.view.d1;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import o.a;

public class d implements a {
  private static final int[] A = new int[] { 1, 4, 5, 3, 2, 0 };
  
  private final Context a;
  
  private final Resources b;
  
  private boolean c;
  
  private boolean d;
  
  private a e;
  
  private ArrayList<e> f;
  
  private ArrayList<e> g;
  
  private boolean h;
  
  private ArrayList<e> i;
  
  private ArrayList<e> j;
  
  private boolean k;
  
  private int l = 0;
  
  private ContextMenu.ContextMenuInfo m;
  
  CharSequence n;
  
  Drawable o;
  
  View p;
  
  private boolean q = false;
  
  private boolean r = false;
  
  private boolean s = false;
  
  private boolean t = false;
  
  private boolean u = false;
  
  private ArrayList<e> v = new ArrayList<e>();
  
  private CopyOnWriteArrayList<WeakReference<h>> w = new CopyOnWriteArrayList<WeakReference<h>>();
  
  private e x;
  
  private boolean y = false;
  
  private boolean z;
  
  public d(Context paramContext) {
    this.a = paramContext;
    this.b = paramContext.getResources();
    this.f = new ArrayList<e>();
    this.g = new ArrayList<e>();
    this.h = true;
    this.i = new ArrayList<e>();
    this.j = new ArrayList<e>();
    this.k = true;
    T(true);
  }
  
  private void J(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        G(true); 
    } 
  }
  
  private void P(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = y();
    if (paramView != null) {
      this.p = paramView;
      this.n = null;
      this.o = null;
    } else {
      if (paramInt1 > 0) {
        this.n = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.n = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        this.o = androidx.core.content.a.d(s(), paramInt2);
      } else if (paramDrawable != null) {
        this.o = paramDrawable;
      } 
      this.p = null;
    } 
    G(false);
  }
  
  private void T(boolean paramBoolean) {
    boolean bool = true;
    if (paramBoolean && (this.b.getConfiguration()).keyboard != 1 && d1.b(ViewConfiguration.get(this.a), this.a)) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    this.d = paramBoolean;
  }
  
  private e f(int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    return new e(this, paramInt1, paramInt2, paramInt3, paramInt4, paramCharSequence, paramInt5);
  }
  
  private void h(boolean paramBoolean) {
    if (this.w.isEmpty())
      return; 
    V();
    for (WeakReference<h> weakReference : this.w) {
      h h = weakReference.get();
      if (h == null) {
        this.w.remove(weakReference);
        continue;
      } 
      h.c(paramBoolean);
    } 
    U();
  }
  
  private boolean i(k paramk, h paramh) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    if (paramh != null)
      bool1 = paramh.k(paramk); 
    for (WeakReference<h> weakReference : this.w) {
      h h1 = weakReference.get();
      if (h1 == null) {
        this.w.remove(weakReference);
        continue;
      } 
      if (!bool1)
        bool1 = h1.k(paramk); 
    } 
    return bool1;
  }
  
  private static int m(ArrayList<e> paramArrayList, int paramInt) {
    for (int i = paramArrayList.size() - 1; i >= 0; i--) {
      if (((e)paramArrayList.get(i)).f() <= paramInt)
        return i + 1; 
    } 
    return 0;
  }
  
  private static int x(int paramInt) {
    int i = (0xFFFF0000 & paramInt) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = A;
      if (i < arrayOfInt.length)
        return paramInt & 0xFFFF | arrayOfInt[i] << 16; 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  @NonNull
  public ArrayList<e> A() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      e e1 = this.f.get(i);
      if (e1.isVisible())
        this.g.add(e1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean B() {
    return this.y;
  }
  
  boolean C() {
    return this.c;
  }
  
  public boolean D() {
    return this.d;
  }
  
  void E(e parame) {
    this.k = true;
    G(true);
  }
  
  void F(e parame) {
    this.h = true;
    G(true);
  }
  
  public void G(boolean paramBoolean) {
    if (!this.q) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      h(paramBoolean);
      return;
    } 
    this.r = true;
    if (paramBoolean)
      this.s = true; 
  }
  
  public boolean H(MenuItem paramMenuItem, int paramInt) {
    return I(paramMenuItem, null, paramInt);
  }
  
  public boolean I(MenuItem paramMenuItem, h paramh, int paramInt) {
    e e1 = (e)paramMenuItem;
    if (e1 != null) {
      boolean bool;
      boolean bool1;
      if (!e1.isEnabled())
        return false; 
      boolean bool2 = e1.k();
      androidx.core.view.b b = e1.b();
      if (b != null && b.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (e1.j()) {
        bool2 |= e1.expandActionView();
        bool1 = bool2;
        if (bool2) {
          d(true);
          return bool2;
        } 
      } else {
        if (e1.hasSubMenu() || bool) {
          if ((paramInt & 0x4) == 0)
            d(false); 
          if (!e1.hasSubMenu())
            e1.x(new k(s(), this, e1)); 
          k k = (k)e1.getSubMenu();
          if (bool)
            b.f(k); 
          bool2 |= i(k, paramh);
          boolean bool3 = bool2;
          if (!bool2) {
            d(true);
            bool3 = bool2;
          } 
          return bool3;
        } 
        bool1 = bool2;
        if ((paramInt & 0x1) == 0) {
          d(true);
          return bool2;
        } 
      } 
      return bool1;
    } 
    return false;
  }
  
  public void K(h paramh) {
    for (WeakReference<h> weakReference : this.w) {
      h h1 = weakReference.get();
      if (h1 == null || h1 == paramh)
        this.w.remove(weakReference); 
    } 
  }
  
  public void L(a parama) {
    this.e = parama;
  }
  
  void M(MenuItem paramMenuItem) {
    int j = paramMenuItem.getGroupId();
    int k = this.f.size();
    V();
    for (int i = 0; i < k; i++) {
      e e1 = this.f.get(i);
      if (e1.getGroupId() == j && e1.m() && e1.isCheckable()) {
        boolean bool;
        if (e1 == paramMenuItem) {
          bool = true;
        } else {
          bool = false;
        } 
        e1.s(bool);
      } 
    } 
    U();
  }
  
  protected d N(int paramInt) {
    P(0, null, paramInt, null, null);
    return this;
  }
  
  protected d O(Drawable paramDrawable) {
    P(0, null, 0, paramDrawable, null);
    return this;
  }
  
  protected d Q(int paramInt) {
    P(paramInt, null, 0, null, null);
    return this;
  }
  
  protected d R(CharSequence paramCharSequence) {
    P(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  protected d S(View paramView) {
    P(0, null, 0, null, paramView);
    return this;
  }
  
  public void U() {
    this.q = false;
    if (this.r) {
      this.r = false;
      G(this.s);
    } 
  }
  
  public void V() {
    if (!this.q) {
      this.q = true;
      this.r = false;
      this.s = false;
    } 
  }
  
  protected MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = x(paramInt3);
    e e1 = f(paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
    ContextMenu.ContextMenuInfo contextMenuInfo = this.m;
    if (contextMenuInfo != null)
      e1.v(contextMenuInfo); 
    ArrayList<e> arrayList = this.f;
    arrayList.add(m(arrayList, i), e1);
    G(true);
    return (MenuItem)e1;
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int i = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      i = b2;
    } 
    while (i < b1) {
      ResolveInfo resolveInfo = list.get(i);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = add(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = menuItem; 
      } 
      i++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    e e1 = (e)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    k k = new k(this.a, this, e1);
    e1.x(k);
    return k;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(h paramh, Context paramContext) {
    this.w.add(new WeakReference<h>(paramh));
    paramh.i(paramContext, this);
    this.k = true;
  }
  
  public void c() {
    a a1 = this.e;
    if (a1 != null)
      a1.b(this); 
  }
  
  public void clear() {
    e e1 = this.x;
    if (e1 != null)
      e(e1); 
    this.f.clear();
    G(true);
  }
  
  public void clearHeader() {
    this.o = null;
    this.n = null;
    this.p = null;
    G(false);
  }
  
  public void close() {
    d(true);
  }
  
  public final void d(boolean paramBoolean) {
    if (this.u)
      return; 
    this.u = true;
    for (WeakReference<h> weakReference : this.w) {
      h h = weakReference.get();
      if (h == null) {
        this.w.remove(weakReference);
        continue;
      } 
      h.b(this, paramBoolean);
    } 
    this.u = false;
  }
  
  public boolean e(e parame) {
    boolean bool3 = this.w.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.x != parame)
        return false; 
      V();
      Iterator<WeakReference<h>> iterator = this.w.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<h> weakReference = iterator.next();
          h h = weakReference.get();
          if (h == null) {
            this.w.remove(weakReference);
            continue;
          } 
          bool2 = h.e(this, parame);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      U();
      bool1 = bool2;
      if (bool2) {
        this.x = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public MenuItem findItem(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      e e1 = this.f.get(i);
      if (e1.getItemId() == paramInt)
        return (MenuItem)e1; 
      if (e1.hasSubMenu()) {
        MenuItem menuItem = e1.getSubMenu().findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  boolean g(d paramd, MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(paramd, paramMenuItem));
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  public boolean hasVisibleItems() {
    if (this.z)
      return true; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((e)this.f.get(i)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (o(paramInt, paramKeyEvent) != null);
  }
  
  public boolean j(e parame) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    V();
    Iterator<WeakReference<h>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<h> weakReference = iterator.next();
        h h = weakReference.get();
        if (h == null) {
          this.w.remove(weakReference);
          continue;
        } 
        bool2 = h.g(this, parame);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    U();
    if (bool2)
      this.x = parame; 
    return bool2;
  }
  
  public int k(int paramInt) {
    return l(paramInt, 0);
  }
  
  public int l(int paramInt1, int paramInt2) {
    int j = size();
    int i = paramInt2;
    if (paramInt2 < 0)
      i = 0; 
    while (i < j) {
      if (((e)this.f.get(i)).getGroupId() == paramInt1)
        return i; 
      i++;
    } 
    return -1;
  }
  
  public int n(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((e)this.f.get(i)).getItemId() == paramInt)
        return i; 
    } 
    return -1;
  }
  
  e o(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<e> arrayList = this.v;
    arrayList.clear();
    p(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int k = arrayList.size();
    if (k == 1)
      return arrayList.get(0); 
    boolean bool = C();
    for (int i = 0; i < k; i++) {
      char c;
      e e1 = arrayList.get(i);
      if (bool) {
        c = e1.getAlphabeticShortcut();
      } else {
        c = e1.getNumericShortcut();
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (j & 0x2) == 0) || (c == arrayOfChar[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return e1; 
    } 
    return null;
  }
  
  void p(List<e> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = C();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int k = this.f.size();
    int i;
    for (i = 0; i < k; i++) {
      char c;
      int m;
      e e1 = this.f.get(i);
      if (e1.hasSubMenu())
        ((d)e1.getSubMenu()).p(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = e1.getAlphabeticShortcut();
      } else {
        c = e1.getNumericShortcut();
      } 
      if (bool) {
        m = e1.getAlphabeticModifiers();
      } else {
        m = e1.getNumericModifiers();
      } 
      if ((j & 0x1100F) == (m & 0x1100F)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && e1.isEnabled())
          paramList.add(e1); 
      } 
    } 
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return H(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    e e1 = o(paramInt1, paramKeyEvent);
    if (e1 != null) {
      bool = H((MenuItem)e1, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      d(true); 
    return bool;
  }
  
  public void q() {
    ArrayList<e> arrayList = A();
    if (!this.k)
      return; 
    Iterator<WeakReference<h>> iterator = this.w.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= h.d()) {
      WeakReference<h> weakReference = iterator.next();
      h h = weakReference.get();
      if (h == null) {
        this.w.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      bool = false;
      while (bool < i) {
        e e1 = arrayList.get(bool);
        if (e1.l()) {
          this.i.add(e1);
        } else {
          this.j.add(e1);
        } 
        int j = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(A());
    } 
    this.k = false;
  }
  
  public ArrayList<e> r() {
    q();
    return this.i;
  }
  
  public void removeGroup(int paramInt) {
    int i = k(paramInt);
    if (i >= 0) {
      int k = this.f.size();
      for (int j = 0; j < k - i && ((e)this.f.get(i)).getGroupId() == paramInt; j++)
        J(i, false); 
      G(true);
    } 
  }
  
  public void removeItem(int paramInt) {
    J(n(paramInt), true);
  }
  
  public Context s() {
    return this.a;
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = this.f.size();
    int i;
    for (i = 0; i < j; i++) {
      e e1 = this.f.get(i);
      if (e1.getGroupId() == paramInt) {
        e1.t(paramBoolean2);
        e1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      e e1 = this.f.get(i);
      if (e1.getGroupId() == paramInt)
        e1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      e e1 = this.f.get(i);
      boolean bool1 = bool;
      if (e1.getGroupId() == paramInt) {
        bool1 = bool;
        if (e1.y(paramBoolean))
          bool1 = true; 
      } 
      i++;
    } 
    if (bool)
      G(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    G(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  public e t() {
    return this.x;
  }
  
  public CharSequence u() {
    return this.n;
  }
  
  public ArrayList<e> v() {
    q();
    return this.j;
  }
  
  boolean w() {
    return this.t;
  }
  
  Resources y() {
    return this.b;
  }
  
  public d z() {
    return this;
  }
  
  public static interface a {
    boolean a(d param1d, MenuItem param1MenuItem);
    
    void b(d param1d);
  }
  
  public static interface b {
    boolean a(e param1e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */