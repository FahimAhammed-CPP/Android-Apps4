package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class c extends BaseAdapter {
  d a;
  
  private int b = -1;
  
  private boolean c;
  
  private final boolean d;
  
  private final LayoutInflater e;
  
  private final int f;
  
  public c(d paramd, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.d = paramBoolean;
    this.e = paramLayoutInflater;
    this.a = paramd;
    this.f = paramInt;
    a();
  }
  
  void a() {
    e e = this.a.t();
    if (e != null) {
      ArrayList<e> arrayList = this.a.v();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((e)arrayList.get(i) == e) {
          this.b = i;
          return;
        } 
      } 
    } 
    this.b = -1;
  }
  
  public d b() {
    return this.a;
  }
  
  public e c(int paramInt) {
    ArrayList<e> arrayList;
    if (this.d) {
      arrayList = this.a.v();
    } else {
      arrayList = this.a.A();
    } 
    int j = this.b;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<e> arrayList;
    if (this.d) {
      arrayList = this.a.v();
    } else {
      arrayList = this.a.A();
    } 
    return (this.b < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.e.inflate(this.f, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.a.B() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    i.a a = (i.a)view;
    if (this.c)
      listMenuItemView.setForceShowIcon(true); 
    a.d(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */