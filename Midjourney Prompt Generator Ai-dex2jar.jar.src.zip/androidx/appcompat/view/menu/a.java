package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class a implements h {
  protected Context a;
  
  protected Context b;
  
  protected d c;
  
  protected LayoutInflater d;
  
  protected LayoutInflater e;
  
  private h.a f;
  
  private int g;
  
  private int h;
  
  protected i i;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.d = LayoutInflater.from(paramContext);
    this.g = paramInt1;
    this.h = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.i).addView(paramView, paramInt);
  }
  
  public void b(d paramd, boolean paramBoolean) {
    h.a a1 = this.f;
    if (a1 != null)
      a1.b(paramd, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.i;
    if (viewGroup == null)
      return; 
    d d1 = this.c;
    int j = 0;
    if (d1 != null) {
      d1.q();
      ArrayList<e> arrayList = this.c.A();
      int m = arrayList.size();
      int k = 0;
      for (j = 0; k < m; j = n) {
        e e = arrayList.get(k);
        int n = j;
        if (o(j, e)) {
          View view1 = viewGroup.getChildAt(j);
          if (view1 instanceof i.a) {
            e e1 = ((i.a)view1).getItemData();
          } else {
            d1 = null;
          } 
          View view2 = n(e, view1, viewGroup);
          if (e != d1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, j); 
          n = j + 1;
        } 
        k++;
      } 
    } 
    while (j < viewGroup.getChildCount()) {
      if (!l(viewGroup, j))
        j++; 
    } 
  }
  
  public boolean e(d paramd, e parame) {
    return false;
  }
  
  public abstract void f(e parame, i.a parama);
  
  public boolean g(d paramd, e parame) {
    return false;
  }
  
  public void h(h.a parama) {
    this.f = parama;
  }
  
  public void i(Context paramContext, d paramd) {
    this.b = paramContext;
    this.e = LayoutInflater.from(paramContext);
    this.c = paramd;
  }
  
  public i.a j(ViewGroup paramViewGroup) {
    return (i.a)this.d.inflate(this.h, paramViewGroup, false);
  }
  
  public boolean k(k paramk) {
    h.a a1 = this.f;
    return (a1 != null) ? a1.c(paramk) : false;
  }
  
  protected boolean l(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public h.a m() {
    return this.f;
  }
  
  public View n(e parame, View paramView, ViewGroup paramViewGroup) {
    i.a a1;
    if (paramView instanceof i.a) {
      a1 = (i.a)paramView;
    } else {
      a1 = j(paramViewGroup);
    } 
    f(parame, a1);
    return (View)a1;
  }
  
  public abstract boolean o(int paramInt, e parame);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */