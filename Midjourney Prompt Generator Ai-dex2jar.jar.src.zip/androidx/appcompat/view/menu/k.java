package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class k extends d implements SubMenu {
  private d B;
  
  private e C;
  
  public k(Context paramContext, d paramd, e parame) {
    super(paramContext);
    this.B = paramd;
    this.C = parame;
  }
  
  public boolean B() {
    return this.B.B();
  }
  
  public boolean C() {
    return this.B.C();
  }
  
  public boolean D() {
    return this.B.D();
  }
  
  public void L(d.a parama) {
    this.B.L(parama);
  }
  
  public Menu W() {
    return (Menu)this.B;
  }
  
  public boolean e(e parame) {
    return this.B.e(parame);
  }
  
  boolean g(d paramd, MenuItem paramMenuItem) {
    return (super.g(paramd, paramMenuItem) || this.B.g(paramd, paramMenuItem));
  }
  
  public MenuItem getItem() {
    return (MenuItem)this.C;
  }
  
  public boolean j(e parame) {
    return this.B.j(parame);
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.B.setGroupDividerEnabled(paramBoolean);
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    return (SubMenu)N(paramInt);
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    return (SubMenu)O(paramDrawable);
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    return (SubMenu)Q(paramInt);
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    return (SubMenu)R(paramCharSequence);
  }
  
  public SubMenu setHeaderView(View paramView) {
    return (SubMenu)S(paramView);
  }
  
  public SubMenu setIcon(int paramInt) {
    this.C.setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    this.C.setIcon(paramDrawable);
    return this;
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.B.setQwertyMode(paramBoolean);
  }
  
  public d z() {
    return this.B.z();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */