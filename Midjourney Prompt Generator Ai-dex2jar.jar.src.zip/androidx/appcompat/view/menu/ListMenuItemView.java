package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.p0;
import androidx.core.view.g0;
import c.a;
import c.f;
import c.g;
import c.j;

public class ListMenuItemView extends LinearLayout implements i.a, AbsListView.SelectionBoundsAdjuster {
  private e a;
  
  private ImageView b;
  
  private RadioButton c;
  
  private TextView d;
  
  private CheckBox e;
  
  private TextView f;
  
  private ImageView g;
  
  private ImageView h;
  
  private LinearLayout i;
  
  private Drawable j;
  
  private int k;
  
  private Context l;
  
  private boolean m;
  
  private Drawable n;
  
  private boolean o;
  
  private int p;
  
  private LayoutInflater q;
  
  private boolean r;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.r);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    p0 p0 = p0.s(getContext(), paramAttributeSet, j.w1, paramInt, 0);
    this.j = p0.f(j.y1);
    this.k = p0.l(j.x1, -1);
    this.m = p0.a(j.z1, false);
    this.l = paramContext;
    this.n = p0.f(j.A1);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.q;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.o = typedArray.hasValue(0);
    p0.t();
    typedArray.recycle();
  }
  
  private void a(View paramView) {
    b(paramView, -1);
  }
  
  private void b(View paramView, int paramInt) {
    LinearLayout linearLayout = this.i;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void e() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.f, (ViewGroup)this, false);
    this.e = checkBox;
    a((View)checkBox);
  }
  
  private void f() {
    ImageView imageView = (ImageView)getInflater().inflate(g.g, (ViewGroup)this, false);
    this.b = imageView;
    b((View)imageView, 0);
  }
  
  private void g() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.h, (ViewGroup)this, false);
    this.c = radioButton;
    a((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.q == null)
      this.q = LayoutInflater.from(getContext()); 
    return this.q;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.g;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.h;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.h.getLayoutParams();
      paramRect.top += this.h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public boolean c() {
    return false;
  }
  
  public void d(e parame, int paramInt) {
    this.a = parame;
    this.p = paramInt;
    if (parame.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(parame.i(this));
    setCheckable(parame.isCheckable());
    h(parame.A(), parame.g());
    setIcon(parame.getIcon());
    setEnabled(parame.isEnabled());
    setSubMenuArrowVisible(parame.hasSubMenu());
    setContentDescription(parame.getContentDescription());
  }
  
  public e getItemData() {
    return this.a;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.a.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.f.setText(this.a.h()); 
    if (this.f.getVisibility() != paramChar)
      this.f.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    g0.B((View)this, this.j);
    TextView textView = (TextView)findViewById(f.A);
    this.d = textView;
    int i = this.k;
    if (i != -1)
      textView.setTextAppearance(this.l, i); 
    this.f = (TextView)findViewById(f.v);
    ImageView imageView = (ImageView)findViewById(f.y);
    this.g = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.n); 
    this.h = (ImageView)findViewById(f.l);
    this.i = (LinearLayout)findViewById(f.h);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.b != null && this.m) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.b.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.c == null && this.e == null)
      return; 
    if (this.a.m()) {
      if (this.c == null)
        g(); 
      RadioButton radioButton1 = this.c;
      CheckBox checkBox1 = this.e;
    } else {
      if (this.e == null)
        e(); 
      checkBox = this.e;
      radioButton = this.c;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.a.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.e;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.c;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.a.m()) {
      if (this.c == null)
        g(); 
      RadioButton radioButton = this.c;
    } else {
      if (this.e == null)
        e(); 
      checkBox = this.e;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.r = paramBoolean;
    this.m = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.h;
    if (imageView != null) {
      byte b;
      if (!this.o && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.a.z() || this.r) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.m)
      return; 
    ImageView imageView = this.b;
    if (imageView == null && paramDrawable == null && !this.m)
      return; 
    if (imageView == null)
      f(); 
    if (paramDrawable != null || this.m) {
      imageView = this.b;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.b.getVisibility() != 0)
        this.b.setVisibility(0); 
      return;
    } 
    this.b.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.d.setText(paramCharSequence);
      if (this.d.getVisibility() != 0) {
        this.d.setVisibility(0);
        return;
      } 
    } else if (this.d.getVisibility() != 8) {
      this.d.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */