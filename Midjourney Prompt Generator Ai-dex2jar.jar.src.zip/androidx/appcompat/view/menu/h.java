package androidx.appcompat.view.menu;

import android.content.Context;

public interface h {
  void b(d paramd, boolean paramBoolean);
  
  void c(boolean paramBoolean);
  
  boolean d();
  
  boolean e(d paramd, e parame);
  
  boolean g(d paramd, e parame);
  
  void h(a parama);
  
  void i(Context paramContext, d paramd);
  
  boolean k(k paramk);
  
  public static interface a {
    void b(d param1d, boolean param1Boolean);
    
    boolean c(d param1d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */