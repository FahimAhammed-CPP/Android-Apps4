package androidx.activity.result;

import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

public final class d {
  @NotNull
  private b.d.f a = (b.d.f)b.d.b.a;
  
  @NotNull
  public final b.d.f a() {
    return this.a;
  }
  
  public final void b(@NotNull b.d.f paramf) {
    Intrinsics.checkNotNullParameter(paramf, "<set-?>");
    this.a = paramf;
  }
  
  public static final class a {
    @NotNull
    private b.d.f a = (b.d.f)b.d.b.a;
    
    @NotNull
    public final d a() {
      d d = new d();
      d.b(this.a);
      return d;
    }
    
    @NotNull
    public final a b(@NotNull b.d.f param1f) {
      Intrinsics.checkNotNullParameter(param1f, "mediaType");
      this.a = param1f;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\result\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */