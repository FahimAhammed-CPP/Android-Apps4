package androidx.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.c;
import androidx.annotation.NonNull;
import androidx.core.app.k;
import androidx.core.app.l;
import androidx.core.app.o0;
import androidx.core.view.h;
import androidx.lifecycle.b0;
import androidx.lifecycle.d;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.h;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.u;
import androidx.lifecycle.x;
import ca.w;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import z.d;

public class ComponentActivity extends k implements f0, d, d, l, i {
  final a.a c = new a.a();
  
  private final h d = new h(new b(this));
  
  private final k e = new k(this);
  
  final z.c f;
  
  private e0 g;
  
  private final OnBackPressedDispatcher h;
  
  final f i;
  
  @NonNull
  final h j;
  
  private int k;
  
  private final AtomicInteger l;
  
  private final c m;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> n;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> o;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> p;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<l>> q;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<o0>> r;
  
  private boolean s;
  
  private boolean t;
  
  public ComponentActivity() {
    z.c c1 = z.c.a(this);
    this.f = c1;
    this.h = new OnBackPressedDispatcher(new a(this));
    f f1 = q();
    this.i = f1;
    this.j = new h(f1, new c(this));
    this.l = new AtomicInteger();
    this.m = new b(this);
    this.n = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.o = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.p = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.q = new CopyOnWriteArrayList<androidx.core.util.a<l>>();
    this.r = new CopyOnWriteArrayList<androidx.core.util.a<o0>>();
    this.s = false;
    this.t = false;
    if (a() != null) {
      int j = Build.VERSION.SDK_INT;
      a().a((i)new h(this) {
            public void onStateChanged(@NonNull j param1j, @NonNull androidx.lifecycle.e.a param1a) {
              if (param1a == androidx.lifecycle.e.a.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      a().a((i)new h(this) {
            public void onStateChanged(@NonNull j param1j, @NonNull androidx.lifecycle.e.a param1a) {
              if (param1a == androidx.lifecycle.e.a.ON_DESTROY) {
                this.a.c.b();
                if (!this.a.isChangingConfigurations())
                  this.a.h().a(); 
                this.a.i.g();
              } 
            }
          });
      a().a((i)new h(this) {
            public void onStateChanged(@NonNull j param1j, @NonNull androidx.lifecycle.e.a param1a) {
              this.a.s();
              this.a.a().c((i)this);
            }
          });
      c1.c();
      x.a(this);
      if (j <= 23)
        a().a((i)new ImmLeaksCleaner((Activity)this)); 
      r().h("android:support:activity-result", new d(this));
      p(new e(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private f q() {
    return new g(this);
  }
  
  private void t() {
    g0.a(getWindow().getDecorView(), this);
    h0.a(getWindow().getDecorView(), this);
    z.e.a(getWindow().getDecorView(), this);
    o.a(getWindow().getDecorView(), this);
    n.a(getWindow().getDecorView(), this);
  }
  
  @NonNull
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.e;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    t();
    this.i.S(getWindow().getDecorView());
    super.addContentView(paramView, paramLayoutParams);
  }
  
  @NonNull
  public final OnBackPressedDispatcher f() {
    return this.h;
  }
  
  @NonNull
  public w.a g() {
    w.d d1 = new w.d();
    if (getApplication() != null)
      d1.b(b0.a.d, getApplication()); 
    d1.b(x.a, this);
    d1.b(x.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.b(x.c, getIntent().getExtras()); 
    return (w.a)d1;
  }
  
  @NonNull
  public e0 h() {
    if (getApplication() != null) {
      s();
      return this.g;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.m.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.h.e();
  }
  
  public void onConfigurationChanged(@NonNull Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.n.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.f.d(paramBundle);
    this.c.c((Context)this);
    super.onCreate(paramBundle);
    u.e((Activity)this);
    if (androidx.core.os.a.c())
      this.h.f(d.a((Activity)this)); 
    int j = this.k;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, @NonNull Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.d.a(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, @NonNull MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.d.c(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.s)
      return; 
    Iterator<androidx.core.util.a<l>> iterator = this.q.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new l(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, @NonNull Configuration paramConfiguration) {
    this.s = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.s = false;
      Iterator<androidx.core.util.a<l>> iterator = this.q.iterator();
      return;
    } finally {
      this.s = false;
    } 
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.p.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, @NonNull Menu paramMenu) {
    this.d.b(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.t)
      return; 
    Iterator<androidx.core.util.a<o0>> iterator = this.r.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new o0(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, @NonNull Configuration paramConfiguration) {
    this.t = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.t = false;
      Iterator<androidx.core.util.a<o0>> iterator = this.r.iterator();
      return;
    } finally {
      this.t = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, @NonNull Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.d.d(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, @NonNull String[] paramArrayOfString, @NonNull int[] paramArrayOfint) {
    if (!this.m.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = y();
    e0 e02 = this.g;
    e0 e01 = e02;
    if (e02 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      e01 = e02;
      if (e1 != null)
        e01 = e1.b; 
    } 
    if (e01 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = e01;
    return e;
  }
  
  protected void onSaveInstanceState(@NonNull Bundle paramBundle) {
    androidx.lifecycle.e e = a();
    if (e instanceof k)
      ((k)e).n(androidx.lifecycle.e.b.c); 
    super.onSaveInstanceState(paramBundle);
    this.f.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.o.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public final void p(@NonNull a.b paramb) {
    this.c.a(paramb);
  }
  
  @NonNull
  public final androidx.savedstate.a r() {
    return this.f.b();
  }
  
  public void reportFullyDrawn() {
    try {
      if (b0.b.h())
        b0.b.c("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      this.j.b();
      return;
    } finally {
      b0.b.f();
    } 
  }
  
  void s() {
    if (this.g == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.g = e.b; 
      if (this.g == null)
        this.g = new e0(); 
    } 
  }
  
  public void setContentView(int paramInt) {
    t();
    this.i.S(getWindow().getDecorView());
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    t();
    this.i.S(getWindow().getDecorView());
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    t();
    this.i.S(getWindow().getDecorView());
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@NonNull Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@NonNull Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@NonNull IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@NonNull IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public void u() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  public Object y() {
    return null;
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.o(this.a);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends c {
    b(ComponentActivity this$0) {}
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    e0 b;
  }
  
  private static interface f extends Executor {
    void S(@NonNull View param1View);
    
    void g();
  }
  
  class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
    final long a = SystemClock.uptimeMillis() + 10000L;
    
    Runnable b;
    
    boolean c = false;
    
    g(ComponentActivity this$0) {}
    
    public void S(@NonNull View param1View) {
      if (!this.c) {
        this.c = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
    
    public void execute(Runnable param1Runnable) {
      this.b = param1Runnable;
      View view = this.d.getWindow().getDecorView();
      if (this.c) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
          view.invalidate();
          return;
        } 
        view.postInvalidate();
        return;
      } 
      view.postOnAnimation(new f(this));
    }
    
    public void g() {
      this.d.getWindow().getDecorView().removeCallbacks(this);
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void onDraw() {
      Runnable runnable = this.b;
      if (runnable != null) {
        runnable.run();
        this.b = null;
        if (this.d.j.c()) {
          this.c = false;
          this.d.getWindow().getDecorView().post(this);
          return;
        } 
      } else if (SystemClock.uptimeMillis() > this.a) {
        this.c = false;
        this.d.getWindow().getDecorView().post(this);
      } 
    }
    
    public void run() {
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */