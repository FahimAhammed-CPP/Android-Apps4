package androidx.activity;

import androidx.lifecycle.j;
import org.jetbrains.annotations.NotNull;

public interface l extends j {
  @NotNull
  OnBackPressedDispatcher f();
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */