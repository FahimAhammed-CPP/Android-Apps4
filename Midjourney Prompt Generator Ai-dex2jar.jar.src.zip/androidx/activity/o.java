package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

public final class o {
  public static final void a(@NotNull View paramView, @NotNull l paraml) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paraml, "onBackPressedDispatcherOwner");
    paramView.setTag(m.b, paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */