package androidx.activity;

import ca.w;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.Intrinsics;
import na.a;
import org.jetbrains.annotations.NotNull;

public final class h {
  @NotNull
  private final Executor a;
  
  @NotNull
  private final a<w> b;
  
  @NotNull
  private final Object c;
  
  private int d;
  
  private boolean e;
  
  private boolean f;
  
  @NotNull
  private final List<a<w>> g;
  
  @NotNull
  private final Runnable h;
  
  public h(@NotNull Executor paramExecutor, @NotNull a<w> parama) {
    this.a = paramExecutor;
    this.b = parama;
    this.c = new Object();
    this.g = new ArrayList<a<w>>();
    this.h = new g(this);
  }
  
  private static final void d(h paramh) {
    Intrinsics.checkNotNullParameter(paramh, "this$0");
    synchronized (paramh.c) {
      paramh.e = false;
      if (paramh.d == 0 && !paramh.f) {
        paramh.b.invoke();
        paramh.b();
      } 
      w w = w.a;
      return;
    } 
  }
  
  public final void b() {
    synchronized (this.c) {
      this.f = true;
      Iterator<a<w>> iterator = this.g.iterator();
      while (iterator.hasNext())
        ((a)iterator.next()).invoke(); 
      this.g.clear();
      w w = w.a;
      return;
    } 
  }
  
  public final boolean c() {
    synchronized (this.c) {
      return this.f;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */