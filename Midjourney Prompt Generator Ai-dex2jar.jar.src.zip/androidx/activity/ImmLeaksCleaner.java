package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.NonNull;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import java.lang.reflect.Field;

final class ImmLeaksCleaner implements h {
  private static int b;
  
  private static Field c;
  
  private static Field d;
  
  private static Field e;
  
  private Activity a;
  
  ImmLeaksCleaner(Activity paramActivity) {
    this.a = paramActivity;
  }
  
  private static void a() {
    try {
      b = 2;
      Field field = InputMethodManager.class.getDeclaredField("mServedView");
      d = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mNextServedView");
      e = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mH");
      c = field;
      field.setAccessible(true);
      b = 1;
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      return;
    } 
  }
  
  public void onStateChanged(@NonNull j paramj, @NonNull e.a parama) {
    if (parama != e.a.ON_DESTROY)
      return; 
    if (b == 0)
      a(); 
    if (b == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.a.getSystemService("input_method");
      try {
        Object object = c.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)d.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            e.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */