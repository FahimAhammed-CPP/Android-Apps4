package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

public final class n {
  public static final void a(@NotNull View paramView, @NotNull i parami) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(parami, "fullyDrawnReporterOwner");
    paramView.setTag(m.a, parami);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\activity\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */