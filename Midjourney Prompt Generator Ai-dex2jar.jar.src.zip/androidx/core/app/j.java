package androidx.core.app;

import android.os.Bundle;
import android.os.IBinder;
import androidx.annotation.NonNull;

public final class j {
  public static void a(@NonNull Bundle paramBundle, String paramString, IBinder paramIBinder) {
    a.b(paramBundle, paramString, paramIBinder);
  }
  
  static class a {
    static IBinder a(Bundle param1Bundle, String param1String) {
      return param1Bundle.getBinder(param1String);
    }
    
    static void b(Bundle param1Bundle, String param1String, IBinder param1IBinder) {
      param1Bundle.putBinder(param1String, param1IBinder);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */