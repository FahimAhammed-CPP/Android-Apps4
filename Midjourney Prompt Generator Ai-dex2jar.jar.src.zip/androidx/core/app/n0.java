package androidx.core.app;

import android.app.Person;
import android.graphics.drawable.Icon;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;

public class n0 {
  CharSequence a;
  
  IconCompat b;
  
  String c;
  
  String d;
  
  boolean e;
  
  boolean f;
  
  n0(b paramb) {
    this.a = paramb.a;
    this.b = paramb.b;
    this.c = paramb.c;
    this.d = paramb.d;
    this.e = paramb.e;
    this.f = paramb.f;
  }
  
  public IconCompat a() {
    return this.b;
  }
  
  public String b() {
    return this.d;
  }
  
  public CharSequence c() {
    return this.a;
  }
  
  public String d() {
    return this.c;
  }
  
  public boolean e() {
    return this.e;
  }
  
  public boolean f() {
    return this.f;
  }
  
  @NonNull
  public String g() {
    String str = this.c;
    if (str != null)
      return str; 
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("name:");
      stringBuilder.append(this.a);
      return stringBuilder.toString();
    } 
    return "";
  }
  
  @NonNull
  public Person h() {
    return a.b(this);
  }
  
  static class a {
    static n0 a(Person param1Person) {
      IconCompat iconCompat;
      n0.b b = (new n0.b()).f(param1Person.getName());
      if (param1Person.getIcon() != null) {
        iconCompat = IconCompat.a(param1Person.getIcon());
      } else {
        iconCompat = null;
      } 
      return b.c(iconCompat).g(param1Person.getUri()).e(param1Person.getKey()).b(param1Person.isBot()).d(param1Person.isImportant()).a();
    }
    
    static Person b(n0 param1n0) {
      Icon icon;
      Person.Builder builder = (new Person.Builder()).setName(param1n0.c());
      if (param1n0.a() != null) {
        icon = param1n0.a().o();
      } else {
        icon = null;
      } 
      return builder.setIcon(icon).setUri(param1n0.d()).setKey(param1n0.b()).setBot(param1n0.e()).setImportant(param1n0.f()).build();
    }
  }
  
  public static class b {
    CharSequence a;
    
    IconCompat b;
    
    String c;
    
    String d;
    
    boolean e;
    
    boolean f;
    
    @NonNull
    public n0 a() {
      return new n0(this);
    }
    
    @NonNull
    public b b(boolean param1Boolean) {
      this.e = param1Boolean;
      return this;
    }
    
    @NonNull
    public b c(IconCompat param1IconCompat) {
      this.b = param1IconCompat;
      return this;
    }
    
    @NonNull
    public b d(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    @NonNull
    public b e(String param1String) {
      this.d = param1String;
      return this;
    }
    
    @NonNull
    public b f(CharSequence param1CharSequence) {
      this.a = param1CharSequence;
      return this;
    }
    
    @NonNull
    public b g(String param1String) {
      this.c = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */