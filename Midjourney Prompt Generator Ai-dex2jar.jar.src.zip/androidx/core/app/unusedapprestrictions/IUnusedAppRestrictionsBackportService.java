package androidx.core.app.unusedapprestrictions;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface IUnusedAppRestrictionsBackportService extends IInterface {
  public static final String o = "androidx$core$app$unusedapprestrictions$IUnusedAppRestrictionsBackportService".replace('$', '.');
  
  void e0(IUnusedAppRestrictionsBackportCallback paramIUnusedAppRestrictionsBackportCallback);
  
  public static abstract class Stub extends Binder implements IUnusedAppRestrictionsBackportService {
    public Stub() {
      attachInterface(this, IUnusedAppRestrictionsBackportService.o);
    }
    
    public static IUnusedAppRestrictionsBackportService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(IUnusedAppRestrictionsBackportService.o);
      return (iInterface != null && iInterface instanceof IUnusedAppRestrictionsBackportService) ? (IUnusedAppRestrictionsBackportService)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      String str = IUnusedAppRestrictionsBackportService.o;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        e0(IUnusedAppRestrictionsBackportCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class a implements IUnusedAppRestrictionsBackportService {
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements IUnusedAppRestrictionsBackportService {
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\ap\\unusedapprestrictions\IUnusedAppRestrictionsBackportService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */