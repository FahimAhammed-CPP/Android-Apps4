package androidx.core.app.unusedapprestrictions;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface IUnusedAppRestrictionsBackportCallback extends IInterface {
  public static final String n = "androidx$core$app$unusedapprestrictions$IUnusedAppRestrictionsBackportCallback".replace('$', '.');
  
  void j1(boolean paramBoolean1, boolean paramBoolean2);
  
  public static abstract class Stub extends Binder implements IUnusedAppRestrictionsBackportCallback {
    public Stub() {
      attachInterface(this, IUnusedAppRestrictionsBackportCallback.n);
    }
    
    public static IUnusedAppRestrictionsBackportCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(IUnusedAppRestrictionsBackportCallback.n);
      return (iInterface != null && iInterface instanceof IUnusedAppRestrictionsBackportCallback) ? (IUnusedAppRestrictionsBackportCallback)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      String str = IUnusedAppRestrictionsBackportCallback.n;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        boolean bool1;
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Int1 = param1Parcel1.readInt();
        boolean bool2 = false;
        if (param1Int1 != 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Parcel1.readInt() != 0)
          bool2 = true; 
        j1(bool1, bool2);
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class a implements IUnusedAppRestrictionsBackportCallback {
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  private static class a implements IUnusedAppRestrictionsBackportCallback {
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\ap\\unusedapprestrictions\IUnusedAppRestrictionsBackportCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */