package androidx.core.app;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;
import androidx.annotation.NonNull;

public class CoreComponentFactory extends AppComponentFactory {
  static <T> T a(T paramT) {
    if (paramT instanceof a) {
      Object object = ((a)paramT).a();
      if (object != null)
        return (T)object; 
    } 
    return paramT;
  }
  
  @NonNull
  public Activity instantiateActivity(@NonNull ClassLoader paramClassLoader, @NonNull String paramString, Intent paramIntent) {
    return a(super.instantiateActivity(paramClassLoader, paramString, paramIntent));
  }
  
  @NonNull
  public Application instantiateApplication(@NonNull ClassLoader paramClassLoader, @NonNull String paramString) {
    return a(super.instantiateApplication(paramClassLoader, paramString));
  }
  
  @NonNull
  public ContentProvider instantiateProvider(@NonNull ClassLoader paramClassLoader, @NonNull String paramString) {
    return a(super.instantiateProvider(paramClassLoader, paramString));
  }
  
  @NonNull
  public BroadcastReceiver instantiateReceiver(@NonNull ClassLoader paramClassLoader, @NonNull String paramString, Intent paramIntent) {
    return a(super.instantiateReceiver(paramClassLoader, paramString, paramIntent));
  }
  
  @NonNull
  public Service instantiateService(@NonNull ClassLoader paramClassLoader, @NonNull String paramString, Intent paramIntent) {
    return a(super.instantiateService(paramClassLoader, paramString, paramIntent));
  }
  
  public static interface a {
    Object a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\CoreComponentFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */