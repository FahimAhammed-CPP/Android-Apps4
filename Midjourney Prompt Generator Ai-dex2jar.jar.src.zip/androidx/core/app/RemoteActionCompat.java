package androidx.core.app;

import android.app.PendingIntent;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;
import c0.a;

public final class RemoteActionCompat implements a {
  @NonNull
  public IconCompat a;
  
  @NonNull
  public CharSequence b;
  
  @NonNull
  public CharSequence c;
  
  @NonNull
  public PendingIntent d;
  
  public boolean e;
  
  public boolean f;
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */