package androidx.core.app;

import android.app.Notification;



/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */