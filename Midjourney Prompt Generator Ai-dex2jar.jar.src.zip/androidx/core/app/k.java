package androidx.core.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.core.view.e;
import androidx.lifecycle.e;
import androidx.lifecycle.j;
import androidx.lifecycle.u;
import m.g;

public class k extends Activity implements j, e.a {
  private g<Class<Object>, Object> a = new g();
  
  private androidx.lifecycle.k b = new androidx.lifecycle.k(this);
  
  @NonNull
  public e a() {
    return (e)this.b;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.d(view, paramKeyEvent)) ? true : e.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean j(@NonNull KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    u.e(this);
  }
  
  protected void onSaveInstanceState(@NonNull Bundle paramBundle) {
    this.b.j(e.b.c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */