package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

public final class p0 {
  static RemoteInput a(p0 paramp0) {
    return a.b(paramp0);
  }
  
  static RemoteInput[] b(p0[] paramArrayOfp0) {
    if (paramArrayOfp0 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfp0.length];
    for (int i = 0; i < paramArrayOfp0.length; i++) {
      p0 p01 = paramArrayOfp0[i];
      arrayOfRemoteInput[i] = a(null);
    } 
    return arrayOfRemoteInput;
  }
  
  static class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(p0 param1p0) {
      throw null;
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */