package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

public class n {
  public static Bundle a(@NonNull Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final p0[] c;
    
    private final p0[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, p0[] param1ArrayOfp01, p0[] param1ArrayOfp02, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.j() == 2)
        this.i = param1IconCompat.h(); 
      this.j = n.d.d(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfp01;
      this.d = param1ArrayOfp02;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    @NonNull
    public Bundle c() {
      return this.a;
    }
    
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.g(null, "", i); 
      } 
      return this.b;
    }
    
    public p0[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
  }
  
  public static class b extends e {
    private CharSequence e;
    
    public void a(@NonNull Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(m param1m) {
      Notification.BigTextStyle bigTextStyle = a.a(a.c(a.b(param1m.a()), this.b), this.e);
      if (this.d)
        a.d(bigTextStyle, this.c); 
    }
    
    @NonNull
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    @NonNull
    public b h(CharSequence param1CharSequence) {
      this.e = n.d.d(param1CharSequence);
      return this;
    }
    
    static class a {
      static Notification.BigTextStyle a(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.bigText(param2CharSequence);
      }
      
      static Notification.BigTextStyle b(Notification.Builder param2Builder) {
        return new Notification.BigTextStyle(param2Builder);
      }
      
      static Notification.BigTextStyle c(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.setBigContentTitle(param2CharSequence);
      }
      
      static Notification.BigTextStyle d(Notification.BigTextStyle param2BigTextStyle, CharSequence param2CharSequence) {
        return param2BigTextStyle.setSummaryText(param2CharSequence);
      }
    }
  }
  
  static class a {
    static Notification.BigTextStyle a(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.bigText(param1CharSequence);
    }
    
    static Notification.BigTextStyle b(Notification.Builder param1Builder) {
      return new Notification.BigTextStyle(param1Builder);
    }
    
    static Notification.BigTextStyle c(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.setBigContentTitle(param1CharSequence);
    }
    
    static Notification.BigTextStyle d(Notification.BigTextStyle param1BigTextStyle, CharSequence param1CharSequence) {
      return param1BigTextStyle.setSummaryText(param1CharSequence);
    }
  }
  
  public static final class c {
    public static Notification.BubbleMetadata a(c param1c) {
      return null;
    }
  }
  
  public static class d {
    boolean A;
    
    boolean B;
    
    String C;
    
    Bundle D;
    
    int E = 0;
    
    int F = 0;
    
    Notification G;
    
    RemoteViews H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    String K;
    
    int L = 0;
    
    String M;
    
    long N;
    
    int O = 0;
    
    int P = 0;
    
    boolean Q;
    
    Notification R;
    
    boolean S;
    
    Object T;
    
    @Deprecated
    public ArrayList<String> U;
    
    public Context a;
    
    public ArrayList<n.a> b = new ArrayList<n.a>();
    
    @NonNull
    public ArrayList<n0> c = new ArrayList<n0>();
    
    ArrayList<n.a> d = new ArrayList<n.a>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    n.e p;
    
    CharSequence q;
    
    CharSequence r;
    
    CharSequence[] s;
    
    int t;
    
    int u;
    
    boolean v;
    
    String w;
    
    boolean x;
    
    String y;
    
    boolean z = false;
    
    @Deprecated
    public d(@NonNull Context param1Context) {
      this(param1Context, null);
    }
    
    public d(@NonNull Context param1Context, @NonNull String param1String) {
      Notification notification = new Notification();
      this.R = notification;
      this.a = param1Context;
      this.K = param1String;
      notification.when = System.currentTimeMillis();
      this.R.audioStreamType = -1;
      this.m = 0;
      this.U = new ArrayList<String>();
      this.Q = true;
    }
    
    protected static CharSequence d(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private void j(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.R;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.R;
      notification.flags = param1Int & notification.flags;
    }
    
    @NonNull
    public d a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new n.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    @NonNull
    public Notification b() {
      return (new o(this)).c();
    }
    
    @NonNull
    public Bundle c() {
      if (this.D == null)
        this.D = new Bundle(); 
      return this.D;
    }
    
    @NonNull
    public d e(boolean param1Boolean) {
      j(16, param1Boolean);
      return this;
    }
    
    @NonNull
    public d f(@NonNull String param1String) {
      this.K = param1String;
      return this;
    }
    
    @NonNull
    public d g(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    @NonNull
    public d h(CharSequence param1CharSequence) {
      this.f = d(param1CharSequence);
      return this;
    }
    
    @NonNull
    public d i(CharSequence param1CharSequence) {
      this.e = d(param1CharSequence);
      return this;
    }
    
    @NonNull
    public d k(boolean param1Boolean) {
      this.z = param1Boolean;
      return this;
    }
    
    @NonNull
    public d l(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    @NonNull
    public d m(int param1Int) {
      this.R.icon = param1Int;
      return this;
    }
    
    @NonNull
    public d n(n.e param1e) {
      if (this.p != param1e) {
        this.p = param1e;
        if (param1e != null)
          param1e.g(this); 
      } 
      return this;
    }
    
    @NonNull
    public d o(CharSequence param1CharSequence) {
      this.R.tickerText = d(param1CharSequence);
      return this;
    }
    
    @NonNull
    public d p(long param1Long) {
      this.R.when = param1Long;
      return this;
    }
  }
  
  public static abstract class e {
    protected n.d a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    public void a(@NonNull Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = c();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(m param1m);
    
    protected abstract String c();
    
    public RemoteViews d(m param1m) {
      return null;
    }
    
    public RemoteViews e(m param1m) {
      return null;
    }
    
    public RemoteViews f(m param1m) {
      return null;
    }
    
    public void g(n.d param1d) {
      if (this.a != param1d) {
        this.a = param1d;
        if (param1d != null)
          param1d.n(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */