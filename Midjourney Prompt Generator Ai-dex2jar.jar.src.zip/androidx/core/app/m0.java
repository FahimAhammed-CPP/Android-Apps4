package androidx.core.app;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import androidx.annotation.NonNull;
import java.util.HashSet;
import java.util.Set;

public final class m0 {
  private static final Object c = new Object();
  
  private static Set<String> d = new HashSet<String>();
  
  private static final Object e = new Object();
  
  private final Context a;
  
  private final NotificationManager b;
  
  private m0(Context paramContext) {
    this.a = paramContext;
    this.b = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  @NonNull
  public static m0 b(@NonNull Context paramContext) {
    return new m0(paramContext);
  }
  
  public boolean a() {
    if (Build.VERSION.SDK_INT >= 24)
      return a.a(this.b); 
    AppOpsManager appOpsManager = (AppOpsManager)this.a.getSystemService("appops");
    ApplicationInfo applicationInfo = this.a.getApplicationInfo();
    String str = this.a.getApplicationContext().getPackageName();
    int i = applicationInfo.uid;
    try {
      Class<?> clazz = Class.forName(AppOpsManager.class.getName());
      Class<int> clazz1 = int.class;
      i = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), str })).intValue();
      return (i == 0);
    } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
      return true;
    } 
  }
  
  static class a {
    static boolean a(NotificationManager param1NotificationManager) {
      return l0.a(param1NotificationManager);
    }
    
    static int b(NotificationManager param1NotificationManager) {
      return k0.a(param1NotificationManager);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */