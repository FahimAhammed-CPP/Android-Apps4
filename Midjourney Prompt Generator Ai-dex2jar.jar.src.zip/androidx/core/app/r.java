package androidx.core.app;

import android.app.Notification;
import android.widget.RemoteViews;



/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */