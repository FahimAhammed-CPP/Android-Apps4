package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;
import androidx.annotation.NonNull;

public final class e0 implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View a;
  
  private ViewTreeObserver b;
  
  private final Runnable c;
  
  private e0(View paramView, Runnable paramRunnable) {
    this.a = paramView;
    this.b = paramView.getViewTreeObserver();
    this.c = paramRunnable;
  }
  
  @NonNull
  public static e0 a(@NonNull View paramView, @NonNull Runnable paramRunnable) {
    if (paramView != null) {
      if (paramRunnable != null) {
        e0 e01 = new e0(paramView, paramRunnable);
        paramView.getViewTreeObserver().addOnPreDrawListener(e01);
        paramView.addOnAttachStateChangeListener(e01);
        return e01;
      } 
      throw new NullPointerException("runnable == null");
    } 
    throw new NullPointerException("view == null");
  }
  
  public void b() {
    if (this.b.isAlive()) {
      this.b.removeOnPreDrawListener(this);
    } else {
      this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.a.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.c.run();
    return true;
  }
  
  public void onViewAttachedToWindow(@NonNull View paramView) {
    this.b = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(@NonNull View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */