package androidx.core.view;

import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import androidx.annotation.NonNull;

public final class f1 {
  public static boolean a(@NonNull ViewParent paramViewParent, @NonNull View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    try {
      return a.a(paramViewParent, paramView, paramFloat1, paramFloat2, paramBoolean);
    } catch (AbstractMethodError abstractMethodError) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ViewParent ");
      stringBuilder.append(paramViewParent);
      stringBuilder.append(" does not implement interface method onNestedFling");
      Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      return false;
    } 
  }
  
  public static boolean b(@NonNull ViewParent paramViewParent, @NonNull View paramView, float paramFloat1, float paramFloat2) {
    try {
      return a.b(paramViewParent, paramView, paramFloat1, paramFloat2);
    } catch (AbstractMethodError abstractMethodError) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ViewParent ");
      stringBuilder.append(paramViewParent);
      stringBuilder.append(" does not implement interface method onNestedPreFling");
      Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      return false;
    } 
  }
  
  public static void c(@NonNull ViewParent paramViewParent, @NonNull View paramView, int paramInt1, int paramInt2, @NonNull int[] paramArrayOfint, int paramInt3) {
    if (paramViewParent instanceof z) {
      ((z)paramViewParent).f(paramView, paramInt1, paramInt2, paramArrayOfint, paramInt3);
      return;
    } 
    if (paramInt3 == 0)
      try {
        a.c(paramViewParent, paramView, paramInt1, paramInt2, paramArrayOfint);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedPreScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static void d(@NonNull ViewParent paramViewParent, @NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, @NonNull int[] paramArrayOfint) {
    if (paramViewParent instanceof a0) {
      ((a0)paramViewParent).a(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfint);
      return;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
    paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    if (paramViewParent instanceof z) {
      ((z)paramViewParent).b(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return;
    } 
    if (paramInt5 == 0)
      try {
        a.d(paramViewParent, paramView, paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static void e(@NonNull ViewParent paramViewParent, @NonNull View paramView1, @NonNull View paramView2, int paramInt1, int paramInt2) {
    if (paramViewParent instanceof z) {
      ((z)paramViewParent).d(paramView1, paramView2, paramInt1, paramInt2);
      return;
    } 
    if (paramInt2 == 0)
      try {
        a.e(paramViewParent, paramView1, paramView2, paramInt1);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedScrollAccepted");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static boolean f(@NonNull ViewParent paramViewParent, @NonNull View paramView1, @NonNull View paramView2, int paramInt1, int paramInt2) {
    if (paramViewParent instanceof z)
      return ((z)paramViewParent).c(paramView1, paramView2, paramInt1, paramInt2); 
    if (paramInt2 == 0)
      try {
        return a.f(paramViewParent, paramView1, paramView2, paramInt1);
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onStartNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
    return false;
  }
  
  public static void g(@NonNull ViewParent paramViewParent, @NonNull View paramView, int paramInt) {
    if (paramViewParent instanceof z) {
      ((z)paramViewParent).e(paramView, paramInt);
      return;
    } 
    if (paramInt == 0)
      try {
        a.g(paramViewParent, paramView);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onStopNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  static class a {
    static boolean a(ViewParent param1ViewParent, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1ViewParent.onNestedFling(param1View, param1Float1, param1Float2, param1Boolean);
    }
    
    static boolean b(ViewParent param1ViewParent, View param1View, float param1Float1, float param1Float2) {
      return param1ViewParent.onNestedPreFling(param1View, param1Float1, param1Float2);
    }
    
    static void c(ViewParent param1ViewParent, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint) {
      param1ViewParent.onNestedPreScroll(param1View, param1Int1, param1Int2, param1ArrayOfint);
    }
    
    static void d(ViewParent param1ViewParent, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1ViewParent.onNestedScroll(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void e(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.onNestedScrollAccepted(param1View1, param1View2, param1Int);
    }
    
    static boolean f(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      return param1ViewParent.onStartNestedScroll(param1View1, param1View2, param1Int);
    }
    
    static void g(ViewParent param1ViewParent, View param1View) {
      param1ViewParent.onStopNestedScroll(param1View);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */