package androidx.core.view;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.Log;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import java.lang.reflect.Method;

public final class d1 {
  private static Method a;
  
  static {
    if (Build.VERSION.SDK_INT == 25)
      try {
        a = ViewConfiguration.class.getDeclaredMethod("getScaledScrollFactor", new Class[0]);
        return;
      } catch (Exception exception) {
        Log.i("ViewConfigCompat", "Could not find method getScaledScrollFactor() on ViewConfiguration");
      }  
  }
  
  public static int a(@NonNull ViewConfiguration paramViewConfiguration) {
    return (Build.VERSION.SDK_INT >= 28) ? a.a(paramViewConfiguration) : (paramViewConfiguration.getScaledTouchSlop() / 2);
  }
  
  public static boolean b(@NonNull ViewConfiguration paramViewConfiguration, @NonNull Context paramContext) {
    if (Build.VERSION.SDK_INT >= 28)
      return a.b(paramViewConfiguration); 
    Resources resources = paramContext.getResources();
    int i = resources.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
    return (i != 0 && resources.getBoolean(i));
  }
  
  static class a {
    static int a(ViewConfiguration param1ViewConfiguration) {
      return c1.a(param1ViewConfiguration);
    }
    
    static boolean b(ViewConfiguration param1ViewConfiguration) {
      return b1.a(param1ViewConfiguration);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */