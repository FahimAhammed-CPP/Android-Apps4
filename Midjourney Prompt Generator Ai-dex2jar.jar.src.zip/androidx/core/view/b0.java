package androidx.core.view;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;

public class b0 {
  private int a;
  
  private int b;
  
  public b0(@NonNull ViewGroup paramViewGroup) {}
  
  public int a() {
    return this.a | this.b;
  }
  
  public void b(@NonNull View paramView1, @NonNull View paramView2, int paramInt) {
    c(paramView1, paramView2, paramInt, 0);
  }
  
  public void c(@NonNull View paramView1, @NonNull View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 1) {
      this.b = paramInt1;
      return;
    } 
    this.a = paramInt1;
  }
  
  public void d(@NonNull View paramView, int paramInt) {
    if (paramInt == 1) {
      this.b = 0;
      return;
    } 
    this.a = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */