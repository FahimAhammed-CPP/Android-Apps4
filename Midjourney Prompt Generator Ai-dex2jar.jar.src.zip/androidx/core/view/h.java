package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class h {
  private final Runnable a;
  
  private final CopyOnWriteArrayList<w> b = new CopyOnWriteArrayList<w>();
  
  private final Map<w, Object> c = new HashMap<w, Object>();
  
  public h(@NonNull Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a(@NonNull Menu paramMenu, @NonNull MenuInflater paramMenuInflater) {
    Iterator<w> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((w)iterator.next()).c(paramMenu, paramMenuInflater); 
  }
  
  public void b(@NonNull Menu paramMenu) {
    Iterator<w> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((w)iterator.next()).b(paramMenu); 
  }
  
  public boolean c(@NonNull MenuItem paramMenuItem) {
    Iterator<w> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      if (((w)iterator.next()).a(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void d(@NonNull Menu paramMenu) {
    Iterator<w> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((w)iterator.next()).d(paramMenu); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */