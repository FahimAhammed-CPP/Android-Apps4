package androidx.core.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class g0 {
  private static final AtomicInteger a = new AtomicInteger(1);
  
  private static WeakHashMap<View, Object> b = null;
  
  private static Field c;
  
  private static boolean d = false;
  
  private static final int[] e = new int[] { 
      n.b.b, n.b.c, n.b.n, n.b.y, n.b.B, n.b.C, n.b.D, n.b.E, n.b.F, n.b.G, 
      n.b.d, n.b.e, n.b.f, n.b.g, n.b.h, n.b.i, n.b.j, n.b.k, n.b.l, n.b.m, 
      n.b.o, n.b.p, n.b.q, n.b.r, n.b.s, n.b.t, n.b.u, n.b.v, n.b.w, n.b.x, 
      n.b.z, n.b.A };
  
  private static final d0 f = new f0();
  
  private static final e g = new e();
  
  public static void A(@NonNull View paramView, a parama) {
    View.AccessibilityDelegate accessibilityDelegate;
    a a1 = parama;
    if (parama == null) {
      a1 = parama;
      if (d(paramView) instanceof a.a)
        a1 = new a(); 
    } 
    if (a1 == null) {
      parama = null;
    } else {
      accessibilityDelegate = a1.d();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static void B(@NonNull View paramView, Drawable paramDrawable) {
    g.q(paramView, paramDrawable);
  }
  
  public static void C(@NonNull View paramView, ColorStateList paramColorStateList) {
    int i = Build.VERSION.SDK_INT;
    k.q(paramView, paramColorStateList);
    if (i == 21) {
      Drawable drawable = paramView.getBackground();
      if (k.g(paramView) != null || k.h(paramView) != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (drawable != null && i != 0) {
        if (drawable.isStateful())
          drawable.setState(paramView.getDrawableState()); 
        g.q(paramView, drawable);
      } 
    } 
  }
  
  public static void D(@NonNull View paramView, PorterDuff.Mode paramMode) {
    int i = Build.VERSION.SDK_INT;
    k.r(paramView, paramMode);
    if (i == 21) {
      Drawable drawable = paramView.getBackground();
      if (k.g(paramView) != null || k.h(paramView) != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (drawable != null && i != 0) {
        if (drawable.isStateful())
          drawable.setState(paramView.getDrawableState()); 
        g.q(paramView, drawable);
      } 
    } 
  }
  
  public static void E(@NonNull View paramView, int paramInt) {
    g.s(paramView, paramInt);
  }
  
  public static void F(@NonNull View paramView, String paramString) {
    k.v(paramView, paramString);
  }
  
  private static void G(View paramView) {
    if (j(paramView) == 0)
      E(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (j((View)viewParent) == 4) {
        E(paramView, 2);
        return;
      } 
    } 
  }
  
  private static f<CharSequence> H() {
    return new c(n.b.N, CharSequence.class, 64, 30);
  }
  
  public static void I(@NonNull View paramView) {
    k.z(paramView);
  }
  
  private static f<Boolean> a() {
    return new d(n.b.J, Boolean.class, 28);
  }
  
  static boolean b(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : q.a(paramView).b(paramView, paramKeyEvent);
  }
  
  static boolean c(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : q.a(paramView).f(paramKeyEvent);
  }
  
  private static View.AccessibilityDelegate d(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? n.a(paramView) : e(paramView);
  }
  
  private static View.AccessibilityDelegate e(@NonNull View paramView) {
    // Byte code:
    //   0: getstatic androidx/core/view/g0.d : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic androidx/core/view/g0.c : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 41
    //   14: ldc android/view/View
    //   16: ldc_w 'mAccessibilityDelegate'
    //   19: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic androidx/core/view/g0.c : Ljava/lang/reflect/Field;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setAccessible : (Z)V
    //   32: goto -> 41
    //   35: iconst_1
    //   36: putstatic androidx/core/view/g0.d : Z
    //   39: aconst_null
    //   40: areturn
    //   41: getstatic androidx/core/view/g0.c : Ljava/lang/reflect/Field;
    //   44: aload_0
    //   45: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_0
    //   49: aload_0
    //   50: instanceof android/view/View$AccessibilityDelegate
    //   53: ifeq -> 63
    //   56: aload_0
    //   57: checkcast android/view/View$AccessibilityDelegate
    //   60: astore_0
    //   61: aload_0
    //   62: areturn
    //   63: aconst_null
    //   64: areturn
    //   65: iconst_1
    //   66: putstatic androidx/core/view/g0.d : Z
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: goto -> 35
    //   75: astore_0
    //   76: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   14	32	71	finally
    //   41	61	75	finally
  }
  
  public static int f(@NonNull View paramView) {
    return i.a(paramView);
  }
  
  public static CharSequence g(@NonNull View paramView) {
    return u().d(paramView);
  }
  
  public static ColorStateList h(@NonNull View paramView) {
    return k.g(paramView);
  }
  
  public static PorterDuff.Mode i(@NonNull View paramView) {
    return k.h(paramView);
  }
  
  public static int j(@NonNull View paramView) {
    return g.c(paramView);
  }
  
  public static int k(@NonNull View paramView) {
    return h.d(paramView);
  }
  
  public static int l(@NonNull View paramView) {
    return g.d(paramView);
  }
  
  public static g1 m(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 23) ? l.a(paramView) : k.j(paramView);
  }
  
  public static CharSequence n(@NonNull View paramView) {
    return H().d(paramView);
  }
  
  public static String o(@NonNull View paramView) {
    return k.k(paramView);
  }
  
  @Deprecated
  public static int p(@NonNull View paramView) {
    return g.g(paramView);
  }
  
  public static boolean q(@NonNull View paramView) {
    Boolean bool = a().d(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  public static boolean r(@NonNull View paramView) {
    return i.b(paramView);
  }
  
  public static boolean s(@NonNull View paramView) {
    Boolean bool = z().d(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  static void t(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (g(paramView) != null && paramView.isShown() && paramView.getWindowVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = f(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      i.g(accessibilityEvent, paramInt);
      if (bool) {
        accessibilityEvent.getText().add(g(paramView));
        G(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      i.g(accessibilityEvent1, paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(g(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null) {
      ViewParent viewParent = paramView.getParent();
      try {
        i.e(viewParent, paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      } 
    } 
  }
  
  private static f<CharSequence> u() {
    return new b(n.b.K, CharSequence.class, 8, 28);
  }
  
  public static void v(@NonNull View paramView) {
    g.k(paramView);
  }
  
  public static void w(@NonNull View paramView, @NonNull Runnable paramRunnable) {
    g.m(paramView, paramRunnable);
  }
  
  public static void x(@NonNull View paramView, @NonNull Runnable paramRunnable, long paramLong) {
    g.n(paramView, paramRunnable, paramLong);
  }
  
  public static void y(@NonNull View paramView) {
    j.c(paramView);
  }
  
  private static f<Boolean> z() {
    return new a(n.b.M, Boolean.class, 28);
  }
  
  class a extends f<Boolean> {
    a(g0 this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean e(@NonNull View param1View) {
      return Boolean.valueOf(g0.m.d(param1View));
    }
  }
  
  class b extends f<CharSequence> {
    b(g0 this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence e(View param1View) {
      return g0.m.b(param1View);
    }
  }
  
  class c extends f<CharSequence> {
    c(g0 this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence e(View param1View) {
      return g0.o.a(param1View);
    }
  }
  
  class d extends f<Boolean> {
    d(g0 this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean e(View param1View) {
      return Boolean.valueOf(g0.m.c(param1View));
    }
  }
  
  static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private final WeakHashMap<View, Boolean> a = new WeakHashMap<View, Boolean>();
    
    private void a(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        g0.t(param1View, b);
        this.a.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    private void b(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.a.entrySet())
          a((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      b(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  static abstract class f<T> {
    private final int a;
    
    private final Class<T> b;
    
    private final int c;
    
    private final int d;
    
    f(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    f(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.d = param1Int2;
      this.c = param1Int3;
    }
    
    private boolean a() {
      return true;
    }
    
    private boolean b() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    abstract T c(View param1View);
    
    T d(View param1View) {
      if (b())
        return c(param1View); 
      if (a()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
  }
  
  static class g {
    static AccessibilityNodeProvider a(View param1View) {
      return param1View.getAccessibilityNodeProvider();
    }
    
    static boolean b(View param1View) {
      return param1View.getFitsSystemWindows();
    }
    
    static int c(View param1View) {
      return param1View.getImportantForAccessibility();
    }
    
    static int d(View param1View) {
      return param1View.getMinimumHeight();
    }
    
    static int e(View param1View) {
      return param1View.getMinimumWidth();
    }
    
    static ViewParent f(View param1View) {
      return param1View.getParentForAccessibility();
    }
    
    static int g(View param1View) {
      return param1View.getWindowSystemUiVisibility();
    }
    
    static boolean h(View param1View) {
      return param1View.hasOverlappingRendering();
    }
    
    static boolean i(View param1View) {
      return param1View.hasTransientState();
    }
    
    static boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      return param1View.performAccessibilityAction(param1Int, param1Bundle);
    }
    
    static void k(View param1View) {
      param1View.postInvalidateOnAnimation();
    }
    
    static void l(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateOnAnimation(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void m(View param1View, Runnable param1Runnable) {
      param1View.postOnAnimation(param1Runnable);
    }
    
    static void n(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postOnAnimationDelayed(param1Runnable, param1Long);
    }
    
    static void o(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
    
    static void p(View param1View) {
      param1View.requestFitSystemWindows();
    }
    
    static void q(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    static void r(View param1View, boolean param1Boolean) {
      param1View.setHasTransientState(param1Boolean);
    }
    
    static void s(View param1View, int param1Int) {
      param1View.setImportantForAccessibility(param1Int);
    }
  }
  
  static class h {
    static int a() {
      return View.generateViewId();
    }
    
    static Display b(@NonNull View param1View) {
      return param1View.getDisplay();
    }
    
    static int c(View param1View) {
      return param1View.getLabelFor();
    }
    
    static int d(View param1View) {
      return param1View.getLayoutDirection();
    }
    
    static int e(View param1View) {
      return param1View.getPaddingEnd();
    }
    
    static int f(View param1View) {
      return param1View.getPaddingStart();
    }
    
    static boolean g(View param1View) {
      return param1View.isPaddingRelative();
    }
    
    static void h(View param1View, int param1Int) {
      param1View.setLabelFor(param1Int);
    }
    
    static void i(View param1View, Paint param1Paint) {
      param1View.setLayerPaint(param1Paint);
    }
    
    static void j(View param1View, int param1Int) {
      param1View.setLayoutDirection(param1Int);
    }
    
    static void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.setPaddingRelative(param1Int1, param1Int2, param1Int3, param1Int4);
    }
  }
  
  static class i {
    static int a(View param1View) {
      return param1View.getAccessibilityLiveRegion();
    }
    
    static boolean b(@NonNull View param1View) {
      return param1View.isAttachedToWindow();
    }
    
    static boolean c(@NonNull View param1View) {
      return param1View.isLaidOut();
    }
    
    static boolean d(@NonNull View param1View) {
      return param1View.isLayoutDirectionResolved();
    }
    
    static void e(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.notifySubtreeAccessibilityStateChanged(param1View1, param1View2, param1Int);
    }
    
    static void f(View param1View, int param1Int) {
      param1View.setAccessibilityLiveRegion(param1Int);
    }
    
    static void g(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
  
  static class j {
    static WindowInsets a(View param1View, WindowInsets param1WindowInsets) {
      return param1View.dispatchApplyWindowInsets(param1WindowInsets);
    }
    
    static WindowInsets b(View param1View, WindowInsets param1WindowInsets) {
      return param1View.onApplyWindowInsets(param1WindowInsets);
    }
    
    static void c(View param1View) {
      param1View.requestApplyInsets();
    }
  }
  
  private static class k {
    static void a(@NonNull WindowInsets param1WindowInsets, @NonNull View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(n.b.Q);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    static g1 b(@NonNull View param1View, @NonNull g1 param1g1, @NonNull Rect param1Rect) {
      WindowInsets windowInsets = param1g1.l();
      if (windowInsets != null)
        return g1.n(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1g1;
    }
    
    static boolean c(@NonNull View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1View.dispatchNestedFling(param1Float1, param1Float2, param1Boolean);
    }
    
    static boolean d(@NonNull View param1View, float param1Float1, float param1Float2) {
      return param1View.dispatchNestedPreFling(param1Float1, param1Float2);
    }
    
    static boolean e(View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      return param1View.dispatchNestedPreScroll(param1Int1, param1Int2, param1ArrayOfint1, param1ArrayOfint2);
    }
    
    static boolean f(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int[] param1ArrayOfint) {
      return param1View.dispatchNestedScroll(param1Int1, param1Int2, param1Int3, param1Int4, param1ArrayOfint);
    }
    
    static ColorStateList g(View param1View) {
      return param1View.getBackgroundTintList();
    }
    
    static PorterDuff.Mode h(View param1View) {
      return param1View.getBackgroundTintMode();
    }
    
    static float i(View param1View) {
      return param1View.getElevation();
    }
    
    public static g1 j(@NonNull View param1View) {
      return g1.a.a(param1View);
    }
    
    static String k(View param1View) {
      return param1View.getTransitionName();
    }
    
    static float l(View param1View) {
      return param1View.getTranslationZ();
    }
    
    static float m(@NonNull View param1View) {
      return param1View.getZ();
    }
    
    static boolean n(View param1View) {
      return param1View.hasNestedScrollingParent();
    }
    
    static boolean o(View param1View) {
      return param1View.isImportantForAccessibility();
    }
    
    static boolean p(View param1View) {
      return param1View.isNestedScrollingEnabled();
    }
    
    static void q(View param1View, ColorStateList param1ColorStateList) {
      param1View.setBackgroundTintList(param1ColorStateList);
    }
    
    static void r(View param1View, PorterDuff.Mode param1Mode) {
      param1View.setBackgroundTintMode(param1Mode);
    }
    
    static void s(View param1View, float param1Float) {
      param1View.setElevation(param1Float);
    }
    
    static void t(View param1View, boolean param1Boolean) {
      param1View.setNestedScrollingEnabled(param1Boolean);
    }
    
    static void u(@NonNull View param1View, c0 param1c0) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(n.b.L, param1c0); 
      if (param1c0 == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(n.b.Q));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1c0));
    }
    
    static void v(View param1View, String param1String) {
      param1View.setTransitionName(param1String);
    }
    
    static void w(View param1View, float param1Float) {
      param1View.setTranslationZ(param1Float);
    }
    
    static void x(@NonNull View param1View, float param1Float) {
      param1View.setZ(param1Float);
    }
    
    static boolean y(View param1View, int param1Int) {
      return param1View.startNestedScroll(param1Int);
    }
    
    static void z(View param1View) {
      param1View.stopNestedScroll();
    }
    
    class a implements View.OnApplyWindowInsetsListener {
      g1 a = null;
      
      a(g0.k this$0, c0 param2c0) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        g1 g12 = g1.n(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          g0.k.a(param2WindowInsets, this.b);
          if (g12.equals(this.a))
            return this.c.a(param2View, g12).l(); 
        } 
        this.a = g12;
        g1 g11 = this.c.a(param2View, g12);
        if (i >= 30)
          return g11.l(); 
        g0.y(param2View);
        return g11.l();
      }
    }
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    g1 a = null;
    
    a(g0 this$0, c0 param1c0) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      g1 g12 = g1.n(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        g0.k.a(param1WindowInsets, this.b);
        if (g12.equals(this.a))
          return this.c.a(param1View, g12).l(); 
      } 
      this.a = g12;
      g1 g11 = this.c.a(param1View, g12);
      if (i >= 30)
        return g11.l(); 
      g0.y(param1View);
      return g11.l();
    }
  }
  
  private static class l {
    public static g1 a(@NonNull View param1View) {
      WindowInsets windowInsets = i0.a(param1View);
      if (windowInsets == null)
        return null; 
      g1 g1 = g1.m(windowInsets);
      g1.j(g1);
      g1.d(param1View.getRootView());
      return g1;
    }
    
    static int b(@NonNull View param1View) {
      return k0.a(param1View);
    }
    
    static void c(@NonNull View param1View, int param1Int) {
      h0.a(param1View, param1Int);
    }
    
    static void d(@NonNull View param1View, int param1Int1, int param1Int2) {
      j0.a(param1View, param1Int1, param1Int2);
    }
  }
  
  static class m {
    static void a(@NonNull View param1View, @NonNull g0.p param1p) {
      int i = n.b.P;
      m.g g2 = (m.g)param1View.getTag(i);
      m.g g1 = g2;
      if (g2 == null) {
        g1 = new m.g();
        param1View.setTag(i, g1);
      } 
      Objects.requireNonNull(param1p);
      u0 u0 = new u0(param1p);
      g1.put(param1p, u0);
      n0.a(param1View, u0);
    }
    
    static CharSequence b(View param1View) {
      return t0.a(param1View);
    }
    
    static boolean c(View param1View) {
      return o0.a(param1View);
    }
    
    static boolean d(View param1View) {
      return l0.a(param1View);
    }
    
    static void e(@NonNull View param1View, @NonNull g0.p param1p) {
      m.g g = (m.g)param1View.getTag(n.b.P);
      if (g == null)
        return; 
      View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)g.get(param1p);
      if (onUnhandledKeyEventListener != null)
        r0.a(param1View, onUnhandledKeyEventListener); 
    }
    
    static <T> T f(View param1View, int param1Int) {
      return (T)s0.a(param1View, param1Int);
    }
    
    static void g(View param1View, boolean param1Boolean) {
      p0.a(param1View, param1Boolean);
    }
    
    static void h(View param1View, CharSequence param1CharSequence) {
      q0.a(param1View, param1CharSequence);
    }
    
    static void i(View param1View, boolean param1Boolean) {
      m0.a(param1View, param1Boolean);
    }
  }
  
  private static class n {
    static View.AccessibilityDelegate a(View param1View) {
      return x0.a(param1View);
    }
    
    static List<Rect> b(View param1View) {
      return v0.a(param1View);
    }
    
    static void c(@NonNull View param1View, @NonNull Context param1Context, @NonNull int[] param1ArrayOfint, AttributeSet param1AttributeSet, @NonNull TypedArray param1TypedArray, int param1Int1, int param1Int2) {
      y0.a(param1View, param1Context, param1ArrayOfint, param1AttributeSet, param1TypedArray, param1Int1, param1Int2);
    }
    
    static void d(View param1View, List<Rect> param1List) {
      w0.a(param1View, param1List);
    }
  }
  
  private static class o {
    static CharSequence a(View param1View) {
      return a1.a(param1View);
    }
    
    static void b(View param1View, CharSequence param1CharSequence) {
      z0.a(param1View, param1CharSequence);
    }
  }
  
  public static interface p {
    boolean onUnhandledKeyEvent(@NonNull View param1View, @NonNull KeyEvent param1KeyEvent);
  }
  
  static class q {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static q a(View param1View) {
      int i = n.b.O;
      q q2 = (q)param1View.getTag(i);
      q q1 = q2;
      if (q2 == null) {
        q1 = new q();
        param1View.setTag(i, q1);
      } 
      return q1;
    }
    
    private View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private boolean e(@NonNull View param1View, @NonNull KeyEvent param1KeyEvent) {
      ArrayList<g0.p> arrayList = (ArrayList)param1View.getTag(n.b.P);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((g0.p)arrayList.get(i)).onUnhandledKeyEvent(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic androidx/core/view/g0$q.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic androidx/core/view/g0$q.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 149
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 149
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: aload_2
      //   148: athrow
      //   149: iload_1
      //   150: iconst_1
      //   151: isub
      //   152: istore_1
      //   153: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
    
    boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && g0.r(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */