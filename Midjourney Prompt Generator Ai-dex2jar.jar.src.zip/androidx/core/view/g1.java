package androidx.core.view;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import androidx.annotation.NonNull;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class g1 {
  @NonNull
  public static final g1 b = l.b;
  
  private final l a;
  
  private g1(@NonNull WindowInsets paramWindowInsets) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new k(this, paramWindowInsets);
      return;
    } 
    if (i >= 29) {
      this.a = new j(this, paramWindowInsets);
      return;
    } 
    if (i >= 28) {
      this.a = new i(this, paramWindowInsets);
      return;
    } 
    this.a = new h(this, paramWindowInsets);
  }
  
  public g1(g1 paramg1) {
    if (paramg1 != null) {
      l l1 = paramg1.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l1 instanceof k) {
        this.a = new k(this, (k)l1);
      } else if (i >= 29 && l1 instanceof j) {
        this.a = new j(this, (j)l1);
      } else if (i >= 28 && l1 instanceof i) {
        this.a = new i(this, (i)l1);
      } else if (l1 instanceof h) {
        this.a = new h(this, (h)l1);
      } else if (l1 instanceof g) {
        this.a = new g(this, (g)l1);
      } else {
        this.a = new l(this);
      } 
      l1.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  @NonNull
  public static g1 m(@NonNull WindowInsets paramWindowInsets) {
    return n(paramWindowInsets, null);
  }
  
  @NonNull
  public static g1 n(@NonNull WindowInsets paramWindowInsets, View paramView) {
    g1 g11 = new g1((WindowInsets)androidx.core.util.e.c(paramWindowInsets));
    if (paramView != null && g0.r(paramView)) {
      g11.j(g0.m(paramView));
      g11.d(paramView.getRootView());
    } 
    return g11;
  }
  
  @Deprecated
  @NonNull
  public g1 a() {
    return this.a.a();
  }
  
  @Deprecated
  @NonNull
  public g1 b() {
    return this.a.b();
  }
  
  @Deprecated
  @NonNull
  public g1 c() {
    return this.a.c();
  }
  
  void d(@NonNull View paramView) {
    this.a.d(paramView);
  }
  
  public c e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof g1))
      return false; 
    paramObject = paramObject;
    return androidx.core.util.d.a(this.a, ((g1)paramObject).a);
  }
  
  @NonNull
  public androidx.core.graphics.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  @NonNull
  public androidx.core.graphics.b g() {
    return this.a.i();
  }
  
  void h(androidx.core.graphics.b[] paramArrayOfb) {
    this.a.o(paramArrayOfb);
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  void i(@NonNull androidx.core.graphics.b paramb) {
    this.a.p(paramb);
  }
  
  void j(g1 paramg1) {
    this.a.q(paramg1);
  }
  
  void k(androidx.core.graphics.b paramb) {
    this.a.r(paramb);
  }
  
  public WindowInsets l() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 30) {
      b = k.q;
      return;
    } 
  }
  
  static class a {
    private static Field a;
    
    private static Field b;
    
    private static Field c;
    
    private static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static g1 a(@NonNull View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              g1 g1 = (new g1.b()).b(androidx.core.graphics.b.c(rect)).c(androidx.core.graphics.b.c((Rect)object)).a();
              g1.j(g1);
              g1.d(param1View.getRootView());
              return g1;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    private final g1.f a;
    
    public b() {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new g1.e();
        return;
      } 
      if (i >= 29) {
        this.a = new g1.d();
        return;
      } 
      this.a = new g1.c();
    }
    
    @NonNull
    public g1 a() {
      return this.a.b();
    }
    
    @Deprecated
    @NonNull
    public b b(@NonNull androidx.core.graphics.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    @NonNull
    public b c(@NonNull androidx.core.graphics.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  private static class c extends f {
    private static Field e;
    
    private static boolean f = false;
    
    private static Constructor<WindowInsets> g;
    
    private static boolean h = false;
    
    private WindowInsets c = h();
    
    private androidx.core.graphics.b d;
    
    private static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    @NonNull
    g1 b() {
      a();
      g1 g1 = g1.m(this.c);
      g1.h(this.b);
      g1.k(this.d);
      return g1;
    }
    
    void d(androidx.core.graphics.b param1b) {
      this.d = param1b;
    }
    
    void f(@NonNull androidx.core.graphics.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  private static class d extends f {
    final WindowInsets.Builder c = new WindowInsets.Builder();
    
    @NonNull
    g1 b() {
      a();
      g1 g1 = g1.m(this.c.build());
      g1.h(this.b);
      return g1;
    }
    
    void c(@NonNull androidx.core.graphics.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    void d(@NonNull androidx.core.graphics.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    void e(@NonNull androidx.core.graphics.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    void f(@NonNull androidx.core.graphics.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    void g(@NonNull androidx.core.graphics.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  private static class e extends d {}
  
  private static class f {
    private final g1 a;
    
    androidx.core.graphics.b[] b;
    
    f() {
      this(new g1(null));
    }
    
    f(@NonNull g1 param1g1) {
      this.a = param1g1;
    }
    
    protected final void a() {
      androidx.core.graphics.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        androidx.core.graphics.b b3 = arrayOfB[g1.m.a(1)];
        androidx.core.graphics.b b2 = this.b[g1.m.a(2)];
        androidx.core.graphics.b b1 = b2;
        if (b2 == null)
          b1 = this.a.f(2); 
        b2 = b3;
        if (b3 == null)
          b2 = this.a.f(1); 
        f(androidx.core.graphics.b.a(b2, b1));
        b1 = this.b[g1.m.a(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[g1.m.a(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[g1.m.a(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    @NonNull
    g1 b() {
      throw null;
    }
    
    void c(@NonNull androidx.core.graphics.b param1b) {}
    
    void d(@NonNull androidx.core.graphics.b param1b) {
      throw null;
    }
    
    void e(@NonNull androidx.core.graphics.b param1b) {}
    
    void f(@NonNull androidx.core.graphics.b param1b) {
      throw null;
    }
    
    void g(@NonNull androidx.core.graphics.b param1b) {}
  }
  
  private static class g extends l {
    private static boolean h = false;
    
    private static Method i;
    
    private static Class<?> j;
    
    private static Field k;
    
    private static Field l;
    
    @NonNull
    final WindowInsets c;
    
    private androidx.core.graphics.b[] d;
    
    private androidx.core.graphics.b e = null;
    
    private g1 f;
    
    androidx.core.graphics.b g;
    
    g(@NonNull g1 param1g1, @NonNull WindowInsets param1WindowInsets) {
      super(param1g1);
      this.c = param1WindowInsets;
    }
    
    g(@NonNull g1 param1g1, @NonNull g param1g) {
      this(param1g1, new WindowInsets(param1g.c));
    }
    
    @NonNull
    private androidx.core.graphics.b s(int param1Int, boolean param1Boolean) {
      androidx.core.graphics.b b1 = androidx.core.graphics.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = androidx.core.graphics.b.a(b1, t(i, param1Boolean)); 
      } 
      return b1;
    }
    
    private androidx.core.graphics.b u() {
      g1 g11 = this.f;
      return (g11 != null) ? g11.g() : androidx.core.graphics.b.e;
    }
    
    private androidx.core.graphics.b v(@NonNull View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          w(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && j != null) {
          if (k == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = l.get(object);
            Rect rect = (Rect)k.get(object);
            object = stringBuilder;
            if (rect != null)
              object = androidx.core.graphics.b.c(rect); 
            return (androidx.core.graphics.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
    
    private static void w() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        j = clazz;
        k = clazz.getDeclaredField("mVisibleInsets");
        l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
        k.setAccessible(true);
        l.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    void d(@NonNull View param1View) {
      androidx.core.graphics.b b2 = v(param1View);
      androidx.core.graphics.b b1 = b2;
      if (b2 == null)
        b1 = androidx.core.graphics.b.e; 
      p(b1);
    }
    
    void e(@NonNull g1 param1g1) {
      param1g1.j(this.f);
      param1g1.i(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    @NonNull
    public androidx.core.graphics.b g(int param1Int) {
      return s(param1Int, false);
    }
    
    @NonNull
    final androidx.core.graphics.b k() {
      if (this.e == null)
        this.e = androidx.core.graphics.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    boolean n() {
      return this.c.isRound();
    }
    
    public void o(androidx.core.graphics.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    void p(@NonNull androidx.core.graphics.b param1b) {
      this.g = param1b;
    }
    
    void q(g1 param1g1) {
      this.f = param1g1;
    }
    
    @NonNull
    protected androidx.core.graphics.b t(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        androidx.core.graphics.b b1;
        g1 g11 = null;
        g1 g12 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  c c;
                  if (param1Int != 128)
                    return androidx.core.graphics.b.e; 
                  g11 = this.f;
                  if (g11 != null) {
                    c = g11.e();
                  } else {
                    c = f();
                  } 
                  return (c != null) ? androidx.core.graphics.b.b(c.b(), c.d(), c.c(), c.a()) : androidx.core.graphics.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          androidx.core.graphics.b[] arrayOfB = this.d;
          g11 = g12;
          if (arrayOfB != null)
            b1 = arrayOfB[g1.m.a(8)]; 
          if (b1 != null)
            return b1; 
          androidx.core.graphics.b b3 = k();
          b1 = u();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(androidx.core.graphics.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          } 
          return androidx.core.graphics.b.e;
        } 
        if (param1Boolean) {
          b1 = u();
          androidx.core.graphics.b b3 = i();
          return androidx.core.graphics.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        androidx.core.graphics.b b2 = k();
        g1 g13 = this.f;
        if (g13 != null)
          b1 = g13.g(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return androidx.core.graphics.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? androidx.core.graphics.b.b(0, Math.max((u()).b, (k()).b), 0, 0) : androidx.core.graphics.b.b(0, (k()).b, 0, 0);
    }
  }
  
  private static class h extends g {
    private androidx.core.graphics.b m = null;
    
    h(@NonNull g1 param1g1, @NonNull WindowInsets param1WindowInsets) {
      super(param1g1, param1WindowInsets);
    }
    
    h(@NonNull g1 param1g1, @NonNull h param1h) {
      super(param1g1, param1h);
      this.m = param1h.m;
    }
    
    @NonNull
    g1 b() {
      return g1.m(this.c.consumeStableInsets());
    }
    
    @NonNull
    g1 c() {
      return g1.m(this.c.consumeSystemWindowInsets());
    }
    
    @NonNull
    final androidx.core.graphics.b i() {
      if (this.m == null)
        this.m = androidx.core.graphics.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.m;
    }
    
    boolean m() {
      return this.c.isConsumed();
    }
    
    public void r(androidx.core.graphics.b param1b) {
      this.m = param1b;
    }
  }
  
  private static class i extends h {
    i(@NonNull g1 param1g1, @NonNull WindowInsets param1WindowInsets) {
      super(param1g1, param1WindowInsets);
    }
    
    i(@NonNull g1 param1g1, @NonNull i param1i) {
      super(param1g1, param1i);
    }
    
    @NonNull
    g1 a() {
      return g1.m(i1.a(this.c));
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((g1.g)param1Object).c) && Objects.equals(this.g, ((g1.g)param1Object).g));
    }
    
    c f() {
      return c.e(h1.a(this.c));
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  private static class j extends i {
    private androidx.core.graphics.b n = null;
    
    private androidx.core.graphics.b o = null;
    
    private androidx.core.graphics.b p = null;
    
    j(@NonNull g1 param1g1, @NonNull WindowInsets param1WindowInsets) {
      super(param1g1, param1WindowInsets);
    }
    
    j(@NonNull g1 param1g1, @NonNull j param1j) {
      super(param1g1, param1j);
    }
    
    @NonNull
    androidx.core.graphics.b h() {
      if (this.o == null)
        this.o = androidx.core.graphics.b.d(l1.a(this.c)); 
      return this.o;
    }
    
    @NonNull
    androidx.core.graphics.b j() {
      if (this.n == null)
        this.n = androidx.core.graphics.b.d(j1.a(this.c)); 
      return this.n;
    }
    
    @NonNull
    androidx.core.graphics.b l() {
      if (this.p == null)
        this.p = androidx.core.graphics.b.d(k1.a(this.c)); 
      return this.p;
    }
    
    public void r(androidx.core.graphics.b param1b) {}
  }
  
  private static class k extends j {
    @NonNull
    static final g1 q = g1.m(WindowInsets.CONSUMED);
    
    k(@NonNull g1 param1g1, @NonNull WindowInsets param1WindowInsets) {
      super(param1g1, param1WindowInsets);
    }
    
    k(@NonNull g1 param1g1, @NonNull k param1k) {
      super(param1g1, param1k);
    }
    
    final void d(@NonNull View param1View) {}
    
    @NonNull
    public androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.d(m1.a(this.c, g1.n.a(param1Int)));
    }
  }
  
  private static class l {
    @NonNull
    static final g1 b = (new g1.b()).a().a().b().c();
    
    final g1 a;
    
    l(@NonNull g1 param1g1) {
      this.a = param1g1;
    }
    
    @NonNull
    g1 a() {
      return this.a;
    }
    
    @NonNull
    g1 b() {
      return this.a;
    }
    
    @NonNull
    g1 c() {
      return this.a;
    }
    
    void d(@NonNull View param1View) {}
    
    void e(@NonNull g1 param1g1) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (n() == param1Object.n() && m() == param1Object.m() && androidx.core.util.d.a(k(), param1Object.k()) && androidx.core.util.d.a(i(), param1Object.i()) && androidx.core.util.d.a(f(), param1Object.f()));
    }
    
    c f() {
      return null;
    }
    
    @NonNull
    androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.e;
    }
    
    @NonNull
    androidx.core.graphics.b h() {
      return k();
    }
    
    public int hashCode() {
      return androidx.core.util.d.b(new Object[] { Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), f() });
    }
    
    @NonNull
    androidx.core.graphics.b i() {
      return androidx.core.graphics.b.e;
    }
    
    @NonNull
    androidx.core.graphics.b j() {
      return k();
    }
    
    @NonNull
    androidx.core.graphics.b k() {
      return androidx.core.graphics.b.e;
    }
    
    @NonNull
    androidx.core.graphics.b l() {
      return k();
    }
    
    boolean m() {
      return false;
    }
    
    boolean n() {
      return false;
    }
    
    public void o(androidx.core.graphics.b[] param1ArrayOfb) {}
    
    void p(@NonNull androidx.core.graphics.b param1b) {}
    
    void q(g1 param1g1) {}
    
    public void r(androidx.core.graphics.b param1b) {}
  }
  
  public static final class m {
    static int a(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
  }
  
  private static final class n {
    static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */