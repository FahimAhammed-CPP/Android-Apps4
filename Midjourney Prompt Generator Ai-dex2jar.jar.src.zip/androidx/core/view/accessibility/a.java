package androidx.core.view.accessibility;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;
import androidx.annotation.NonNull;

public final class a extends ClickableSpan {
  private final int a;
  
  private final f b;
  
  private final int c;
  
  public a(int paramInt1, @NonNull f paramf, int paramInt2) {
    this.a = paramInt1;
    this.b = paramf;
    this.c = paramInt2;
  }
  
  public void onClick(@NonNull View paramView) {
    Bundle bundle = new Bundle();
    bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.a);
    this.b.F(this.c, bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\accessibility\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */