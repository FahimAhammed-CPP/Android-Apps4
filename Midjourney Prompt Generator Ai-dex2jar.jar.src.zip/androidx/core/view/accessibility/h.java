package androidx.core.view.accessibility;

import android.view.accessibility.AccessibilityRecord;
import androidx.annotation.NonNull;

public class h {
  public static void a(@NonNull AccessibilityRecord paramAccessibilityRecord, int paramInt) {
    a.c(paramAccessibilityRecord, paramInt);
  }
  
  public static void b(@NonNull AccessibilityRecord paramAccessibilityRecord, int paramInt) {
    a.d(paramAccessibilityRecord, paramInt);
  }
  
  static class a {
    static int a(AccessibilityRecord param1AccessibilityRecord) {
      return param1AccessibilityRecord.getMaxScrollX();
    }
    
    static int b(AccessibilityRecord param1AccessibilityRecord) {
      return param1AccessibilityRecord.getMaxScrollY();
    }
    
    static void c(AccessibilityRecord param1AccessibilityRecord, int param1Int) {
      param1AccessibilityRecord.setMaxScrollX(param1Int);
    }
    
    static void d(AccessibilityRecord param1AccessibilityRecord, int param1Int) {
      param1AccessibilityRecord.setMaxScrollY(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\accessibility\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */