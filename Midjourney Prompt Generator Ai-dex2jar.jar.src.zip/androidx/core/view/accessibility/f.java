package androidx.core.view.accessibility;

import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class f {
  private static int d;
  
  private final AccessibilityNodeInfo a;
  
  public int b = -1;
  
  private int c = -1;
  
  private f(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    this.a = paramAccessibilityNodeInfo;
  }
  
  private void G(View paramView) {
    SparseArray<WeakReference<ClickableSpan>> sparseArray = p(paramView);
    if (sparseArray != null) {
      int j;
      ArrayList<Integer> arrayList = new ArrayList();
      byte b = 0;
      int i = 0;
      while (true) {
        j = b;
        if (i < sparseArray.size()) {
          if (((WeakReference)sparseArray.valueAt(i)).get() == null)
            arrayList.add(Integer.valueOf(i)); 
          i++;
          continue;
        } 
        break;
      } 
      while (j < arrayList.size()) {
        sparseArray.remove(((Integer)arrayList.get(j)).intValue());
        j++;
      } 
    } 
  }
  
  private void H(int paramInt, boolean paramBoolean) {
    Bundle bundle = m();
    if (bundle != null) {
      boolean bool;
      int i = bundle.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0);
      if (paramBoolean) {
        bool = paramInt;
      } else {
        bool = false;
      } 
      bundle.putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", bool | i & paramInt);
    } 
  }
  
  public static f P(@NonNull AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    return new f(paramAccessibilityNodeInfo);
  }
  
  private void b(ClickableSpan paramClickableSpan, Spanned paramSpanned, int paramInt) {
    e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").add(Integer.valueOf(paramSpanned.getSpanStart(paramClickableSpan)));
    e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY").add(Integer.valueOf(paramSpanned.getSpanEnd(paramClickableSpan)));
    e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY").add(Integer.valueOf(paramSpanned.getSpanFlags(paramClickableSpan)));
    e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY").add(Integer.valueOf(paramInt));
  }
  
  private void d() {
    b.a(this.a).remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
    b.a(this.a).remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
    b.a(this.a).remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
    b.a(this.a).remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
  }
  
  private List<Integer> e(String paramString) {
    ArrayList<Integer> arrayList2 = b.a(this.a).getIntegerArrayList(paramString);
    ArrayList<Integer> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      b.a(this.a).putIntegerArrayList(paramString, arrayList1);
    } 
    return arrayList1;
  }
  
  static String g(int paramInt) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        switch (paramInt) {
          default:
            switch (paramInt) {
              default:
                switch (paramInt) {
                  default:
                    switch (paramInt) {
                      default:
                        return "ACTION_UNKNOWN";
                      case 16908375:
                        return "ACTION_DRAG_CANCEL";
                      case 16908374:
                        return "ACTION_DRAG_DROP";
                      case 16908373:
                        return "ACTION_DRAG_START";
                      case 16908372:
                        break;
                    } 
                    return "ACTION_IME_ENTER";
                  case 16908362:
                    return "ACTION_PRESS_AND_HOLD";
                  case 16908361:
                    return "ACTION_PAGE_RIGHT";
                  case 16908360:
                    return "ACTION_PAGE_LEFT";
                  case 16908359:
                    return "ACTION_PAGE_DOWN";
                  case 16908358:
                    return "ACTION_PAGE_UP";
                  case 16908357:
                    return "ACTION_HIDE_TOOLTIP";
                  case 16908356:
                    break;
                } 
                return "ACTION_SHOW_TOOLTIP";
              case 16908349:
                return "ACTION_SET_PROGRESS";
              case 16908348:
                return "ACTION_CONTEXT_CLICK";
              case 16908347:
                return "ACTION_SCROLL_RIGHT";
              case 16908346:
                return "ACTION_SCROLL_DOWN";
              case 16908345:
                return "ACTION_SCROLL_LEFT";
              case 16908344:
                return "ACTION_SCROLL_UP";
              case 16908343:
                return "ACTION_SCROLL_TO_POSITION";
              case 16908342:
                break;
            } 
            return "ACTION_SHOW_ON_SCREEN";
          case 16908354:
            return "ACTION_MOVE_WINDOW";
          case 2097152:
            return "ACTION_SET_TEXT";
          case 524288:
            return "ACTION_COLLAPSE";
          case 262144:
            return "ACTION_EXPAND";
          case 131072:
            return "ACTION_SET_SELECTION";
          case 65536:
            return "ACTION_CUT";
          case 32768:
            return "ACTION_PASTE";
          case 16384:
            return "ACTION_COPY";
          case 8192:
            return "ACTION_SCROLL_BACKWARD";
          case 4096:
            return "ACTION_SCROLL_FORWARD";
          case 2048:
            return "ACTION_PREVIOUS_HTML_ELEMENT";
          case 1024:
            return "ACTION_NEXT_HTML_ELEMENT";
          case 512:
            return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
          case 256:
            return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
          case 128:
            return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
          case 64:
            return "ACTION_ACCESSIBILITY_FOCUS";
          case 32:
            return "ACTION_LONG_CLICK";
          case 16:
            return "ACTION_CLICK";
          case 8:
            return "ACTION_CLEAR_SELECTION";
          case 4:
            break;
        } 
        return "ACTION_SELECT";
      } 
      return "ACTION_CLEAR_FOCUS";
    } 
    return "ACTION_FOCUS";
  }
  
  public static ClickableSpan[] k(CharSequence paramCharSequence) {
    return (paramCharSequence instanceof Spanned) ? (ClickableSpan[])((Spanned)paramCharSequence).getSpans(0, paramCharSequence.length(), ClickableSpan.class) : null;
  }
  
  private SparseArray<WeakReference<ClickableSpan>> n(View paramView) {
    SparseArray<WeakReference<ClickableSpan>> sparseArray2 = p(paramView);
    SparseArray<WeakReference<ClickableSpan>> sparseArray1 = sparseArray2;
    if (sparseArray2 == null) {
      sparseArray1 = new SparseArray();
      paramView.setTag(n.b.I, sparseArray1);
    } 
    return sparseArray1;
  }
  
  private SparseArray<WeakReference<ClickableSpan>> p(View paramView) {
    return (SparseArray<WeakReference<ClickableSpan>>)paramView.getTag(n.b.I);
  }
  
  private boolean t() {
    return e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").isEmpty() ^ true;
  }
  
  private int u(ClickableSpan paramClickableSpan, SparseArray<WeakReference<ClickableSpan>> paramSparseArray) {
    if (paramSparseArray != null)
      for (int j = 0; j < paramSparseArray.size(); j++) {
        if (paramClickableSpan.equals(((WeakReference<ClickableSpan>)paramSparseArray.valueAt(j)).get()))
          return paramSparseArray.keyAt(j); 
      }  
    int i = d;
    d = i + 1;
    return i;
  }
  
  public boolean A() {
    return this.a.isFocused();
  }
  
  public boolean B() {
    return this.a.isLongClickable();
  }
  
  public boolean C() {
    return this.a.isPassword();
  }
  
  public boolean D() {
    return this.a.isScrollable();
  }
  
  public boolean E() {
    return this.a.isSelected();
  }
  
  public boolean F(int paramInt, Bundle paramBundle) {
    return this.a.performAction(paramInt, paramBundle);
  }
  
  public void I(CharSequence paramCharSequence) {
    this.a.setClassName(paramCharSequence);
  }
  
  public void J(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 28) {
      e.a(this.a, paramBoolean);
      return;
    } 
    H(2, paramBoolean);
  }
  
  public void K(CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 28) {
      c.a(this.a, paramCharSequence);
      return;
    } 
    b.a(this.a).putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY", paramCharSequence);
  }
  
  public void L(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 28) {
      b.a(this.a, paramBoolean);
      return;
    } 
    H(1, paramBoolean);
  }
  
  public void M(boolean paramBoolean) {
    this.a.setScrollable(paramBoolean);
  }
  
  public void N(CharSequence paramCharSequence) {
    if (androidx.core.os.a.b()) {
      d.a(this.a, paramCharSequence);
      return;
    } 
    b.a(this.a).putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY", paramCharSequence);
  }
  
  public AccessibilityNodeInfo O() {
    return this.a;
  }
  
  public void a(a parama) {
    this.a.addAction((AccessibilityNodeInfo.AccessibilityAction)parama.a);
  }
  
  public void c(CharSequence paramCharSequence, View paramView) {
    if (Build.VERSION.SDK_INT < 26) {
      d();
      G(paramView);
      ClickableSpan[] arrayOfClickableSpan = k(paramCharSequence);
      if (arrayOfClickableSpan != null && arrayOfClickableSpan.length > 0) {
        m().putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY", n.b.a);
        SparseArray<WeakReference<ClickableSpan>> sparseArray = n(paramView);
        for (int i = 0; i < arrayOfClickableSpan.length; i++) {
          int j = u(arrayOfClickableSpan[i], sparseArray);
          sparseArray.put(j, new WeakReference<ClickableSpan>(arrayOfClickableSpan[i]));
          b(arrayOfClickableSpan[i], (Spanned)paramCharSequence, j);
        } 
      } 
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof f))
      return false; 
    paramObject = paramObject;
    AccessibilityNodeInfo accessibilityNodeInfo = this.a;
    if (accessibilityNodeInfo == null) {
      if (((f)paramObject).a != null)
        return false; 
    } else if (!accessibilityNodeInfo.equals(((f)paramObject).a)) {
      return false;
    } 
    return (this.c != ((f)paramObject).c) ? false : (!(this.b != ((f)paramObject).b));
  }
  
  public List<a> f() {
    List list = this.a.getActionList();
    if (list != null) {
      ArrayList<a> arrayList = new ArrayList();
      int j = list.size();
      for (int i = 0; i < j; i++)
        arrayList.add(new a(list.get(i))); 
      return arrayList;
    } 
    return Collections.emptyList();
  }
  
  @Deprecated
  public void h(Rect paramRect) {
    this.a.getBoundsInParent(paramRect);
  }
  
  public int hashCode() {
    AccessibilityNodeInfo accessibilityNodeInfo = this.a;
    return (accessibilityNodeInfo == null) ? 0 : accessibilityNodeInfo.hashCode();
  }
  
  public void i(Rect paramRect) {
    this.a.getBoundsInScreen(paramRect);
  }
  
  public CharSequence j() {
    return this.a.getClassName();
  }
  
  public CharSequence l() {
    return this.a.getContentDescription();
  }
  
  public Bundle m() {
    return b.a(this.a);
  }
  
  public CharSequence o() {
    return this.a.getPackageName();
  }
  
  public CharSequence q() {
    if (t()) {
      List<Integer> list1 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
      List<Integer> list2 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
      List<Integer> list3 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
      List<Integer> list4 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
      CharSequence charSequence = this.a.getText();
      int j = this.a.getText().length();
      int i = 0;
      SpannableString spannableString = new SpannableString(TextUtils.substring(charSequence, 0, j));
      while (i < list1.size()) {
        spannableString.setSpan(new a(((Integer)list4.get(i)).intValue(), this, m().getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY")), ((Integer)list1.get(i)).intValue(), ((Integer)list2.get(i)).intValue(), ((Integer)list3.get(i)).intValue());
        i++;
      } 
      return (CharSequence)spannableString;
    } 
    return this.a.getText();
  }
  
  public String r() {
    return androidx.core.os.a.c() ? this.a.getUniqueId() : b.a(this.a).getString("androidx.view.accessibility.AccessibilityNodeInfoCompat.UNIQUE_ID_KEY");
  }
  
  public String s() {
    return this.a.getViewIdResourceName();
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(super.toString());
    Rect rect = new Rect();
    h(rect);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("; boundsInParent: ");
    stringBuilder2.append(rect);
    stringBuilder3.append(stringBuilder2.toString());
    i(rect);
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("; boundsInScreen: ");
    stringBuilder2.append(rect);
    stringBuilder3.append(stringBuilder2.toString());
    stringBuilder3.append("; packageName: ");
    stringBuilder3.append(o());
    stringBuilder3.append("; className: ");
    stringBuilder3.append(j());
    stringBuilder3.append("; text: ");
    stringBuilder3.append(q());
    stringBuilder3.append("; contentDescription: ");
    stringBuilder3.append(l());
    stringBuilder3.append("; viewId: ");
    stringBuilder3.append(s());
    stringBuilder3.append("; uniqueId: ");
    stringBuilder3.append(r());
    stringBuilder3.append("; checkable: ");
    stringBuilder3.append(v());
    stringBuilder3.append("; checked: ");
    stringBuilder3.append(w());
    stringBuilder3.append("; focusable: ");
    stringBuilder3.append(z());
    stringBuilder3.append("; focused: ");
    stringBuilder3.append(A());
    stringBuilder3.append("; selected: ");
    stringBuilder3.append(E());
    stringBuilder3.append("; clickable: ");
    stringBuilder3.append(x());
    stringBuilder3.append("; longClickable: ");
    stringBuilder3.append(B());
    stringBuilder3.append("; enabled: ");
    stringBuilder3.append(y());
    stringBuilder3.append("; password: ");
    stringBuilder3.append(C());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("; scrollable: ");
    stringBuilder1.append(D());
    stringBuilder3.append(stringBuilder1.toString());
    stringBuilder3.append("; [");
    List<a> list = f();
    for (int i = 0; i < list.size(); i++) {
      a a = list.get(i);
      String str2 = g(a.a());
      String str1 = str2;
      if (str2.equals("ACTION_UNKNOWN")) {
        str1 = str2;
        if (a.b() != null)
          str1 = a.b().toString(); 
      } 
      stringBuilder3.append(str1);
      if (i != list.size() - 1)
        stringBuilder3.append(", "); 
    } 
    stringBuilder3.append("]");
    return stringBuilder3.toString();
  }
  
  public boolean v() {
    return this.a.isCheckable();
  }
  
  public boolean w() {
    return this.a.isChecked();
  }
  
  public boolean x() {
    return this.a.isClickable();
  }
  
  public boolean y() {
    return this.a.isEnabled();
  }
  
  public boolean z() {
    return this.a.isFocusable();
  }
  
  public static class a {
    public static final a A;
    
    public static final a B;
    
    public static final a C;
    
    public static final a D;
    
    public static final a E;
    
    public static final a F;
    
    @NonNull
    public static final a G;
    
    @NonNull
    public static final a H;
    
    @NonNull
    public static final a I;
    
    @NonNull
    public static final a J;
    
    public static final a K;
    
    public static final a L;
    
    public static final a M;
    
    public static final a N;
    
    public static final a O;
    
    @NonNull
    public static final a P;
    
    @NonNull
    public static final a Q;
    
    @NonNull
    public static final a R;
    
    @NonNull
    public static final a S;
    
    @NonNull
    public static final a T;
    
    @NonNull
    public static final a U;
    
    public static final a e = new a(1, null);
    
    public static final a f = new a(2, null);
    
    public static final a g = new a(4, null);
    
    public static final a h = new a(8, null);
    
    public static final a i = new a(16, null);
    
    public static final a j = new a(32, null);
    
    public static final a k = new a(64, null);
    
    public static final a l = new a(128, null);
    
    public static final a m = new a(256, null, (Class)i.b.class);
    
    public static final a n = new a(512, null, (Class)i.b.class);
    
    public static final a o = new a(1024, null, (Class)i.c.class);
    
    public static final a p = new a(2048, null, (Class)i.c.class);
    
    public static final a q = new a(4096, null);
    
    public static final a r = new a(8192, null);
    
    public static final a s = new a(16384, null);
    
    public static final a t = new a(32768, null);
    
    public static final a u = new a(65536, null);
    
    public static final a v = new a(131072, null, (Class)i.g.class);
    
    public static final a w = new a(262144, null);
    
    public static final a x = new a(524288, null);
    
    public static final a y = new a(1048576, null);
    
    public static final a z = new a(2097152, null, (Class)i.h.class);
    
    final Object a;
    
    private final int b;
    
    private final Class<? extends i.a> c;
    
    protected final i d;
    
    static {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN;
      } else {
        accessibilityAction1 = null;
      } 
      A = new a(accessibilityAction1, 16908342, null, null, null);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION;
      } else {
        accessibilityAction1 = null;
      } 
      B = new a(accessibilityAction1, 16908343, null, null, (Class)i.e.class);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
      } else {
        accessibilityAction1 = null;
      } 
      C = new a(accessibilityAction1, 16908344, null, null, null);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
      } else {
        accessibilityAction1 = null;
      } 
      D = new a(accessibilityAction1, 16908345, null, null, null);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN;
      } else {
        accessibilityAction1 = null;
      } 
      E = new a(accessibilityAction1, 16908346, null, null, null);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT;
      } else {
        accessibilityAction1 = null;
      } 
      F = new a(accessibilityAction1, 16908347, null, null, null);
      if (j >= 29) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_UP;
      } else {
        accessibilityAction1 = null;
      } 
      G = new a(accessibilityAction1, 16908358, null, null, null);
      if (j >= 29) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_DOWN;
      } else {
        accessibilityAction1 = null;
      } 
      H = new a(accessibilityAction1, 16908359, null, null, null);
      if (j >= 29) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_LEFT;
      } else {
        accessibilityAction1 = null;
      } 
      I = new a(accessibilityAction1, 16908360, null, null, null);
      if (j >= 29) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_RIGHT;
      } else {
        accessibilityAction1 = null;
      } 
      J = new a(accessibilityAction1, 16908361, null, null, null);
      if (j >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK;
      } else {
        accessibilityAction1 = null;
      } 
      K = new a(accessibilityAction1, 16908348, null, null, null);
      if (j >= 24) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS;
      } else {
        accessibilityAction1 = null;
      } 
      L = new a(accessibilityAction1, 16908349, null, null, (Class)i.f.class);
      if (j >= 26) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW;
      } else {
        accessibilityAction1 = null;
      } 
      M = new a(accessibilityAction1, 16908354, null, null, (Class)i.d.class);
      if (j >= 28) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP;
      } else {
        accessibilityAction1 = null;
      } 
      N = new a(accessibilityAction1, 16908356, null, null, null);
      if (j >= 28) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP;
      } else {
        accessibilityAction1 = null;
      } 
      O = new a(accessibilityAction1, 16908357, null, null, null);
      if (j >= 30) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_PRESS_AND_HOLD;
      } else {
        accessibilityAction1 = null;
      } 
      P = new a(accessibilityAction1, 16908362, null, null, null);
      if (j >= 30) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER;
      } else {
        accessibilityAction1 = null;
      } 
      Q = new a(accessibilityAction1, 16908372, null, null, null);
      if (j >= 32) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_START;
      } else {
        accessibilityAction1 = null;
      } 
      R = new a(accessibilityAction1, 16908373, null, null, null);
      if (j >= 32) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_DROP;
      } else {
        accessibilityAction1 = null;
      } 
      S = new a(accessibilityAction1, 16908374, null, null, null);
      if (j >= 32) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_CANCEL;
      } else {
        accessibilityAction1 = null;
      } 
      T = new a(accessibilityAction1, 16908375, null, null, null);
      AccessibilityNodeInfo.AccessibilityAction accessibilityAction1 = accessibilityAction2;
      if (j >= 33)
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TEXT_SUGGESTIONS; 
      U = new a(accessibilityAction1, 16908376, null, null, null);
    }
    
    public a(int param1Int, CharSequence param1CharSequence) {
      this(null, param1Int, param1CharSequence, null, null);
    }
    
    private a(int param1Int, CharSequence param1CharSequence, Class<? extends i.a> param1Class) {
      this(null, param1Int, param1CharSequence, null, param1Class);
    }
    
    a(Object param1Object) {
      this(param1Object, 0, null, null, null);
    }
    
    a(Object param1Object, int param1Int, CharSequence param1CharSequence, i param1i, Class<? extends i.a> param1Class) {
      this.b = param1Int;
      this.d = param1i;
      if (param1Object == null) {
        this.a = new AccessibilityNodeInfo.AccessibilityAction(param1Int, param1CharSequence);
      } else {
        this.a = param1Object;
      } 
      this.c = param1Class;
    }
    
    public int a() {
      return ((AccessibilityNodeInfo.AccessibilityAction)this.a).getId();
    }
    
    public CharSequence b() {
      return ((AccessibilityNodeInfo.AccessibilityAction)this.a).getLabel();
    }
    
    public boolean c(View param1View, Bundle param1Bundle) {
      if (this.d != null) {
        i.a a1 = null;
        Object object = null;
        Class<? extends i.a> clazz = this.c;
        if (clazz != null) {
          Exception exception1;
          String str;
          try {
            a1 = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
            try {
              a1.a(param1Bundle);
            } catch (Exception exception2) {
              i.a a2 = a1;
              exception = exception2;
            } 
          } catch (Exception exception) {
            exception1 = exception2;
          } 
          Class<? extends i.a> clazz1 = this.c;
          if (clazz1 == null) {
            str = "null";
          } else {
            str = str.getName();
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to execute command with argument class ViewCommandArgument: ");
          stringBuilder.append(str);
          Log.e("A11yActionCompat", stringBuilder.toString(), exception);
          exception = exception1;
        } 
        return this.d.a(param1View, (i.a)exception);
      } 
      return false;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == null)
        return false; 
      if (!(param1Object instanceof a))
        return false; 
      param1Object = param1Object;
      Object object = this.a;
      if (object == null) {
        if (((a)param1Object).a != null)
          return false; 
      } else if (!object.equals(((a)param1Object).a)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      Object object = this.a;
      return (object != null) ? object.hashCode() : 0;
    }
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AccessibilityActionCompat: ");
      String str2 = f.g(this.b);
      String str1 = str2;
      if (str2.equals("ACTION_UNKNOWN")) {
        str1 = str2;
        if (b() != null)
          str1 = b().toString(); 
      } 
      stringBuilder.append(str1);
      return stringBuilder.toString();
    }
    
    static {
      AccessibilityNodeInfo.AccessibilityAction accessibilityAction2 = null;
    }
  }
  
  private static class b {
    public static Bundle a(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      return param1AccessibilityNodeInfo.getExtras();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\accessibility\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */