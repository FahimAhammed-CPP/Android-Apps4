package androidx.core.view;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.annotation.NonNull;
import androidx.core.view.accessibility.f;
import androidx.core.view.accessibility.g;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

public class a {
  private static final View.AccessibilityDelegate c = new View.AccessibilityDelegate();
  
  private final View.AccessibilityDelegate a;
  
  private final View.AccessibilityDelegate b;
  
  public a() {
    this(c);
  }
  
  public a(@NonNull View.AccessibilityDelegate paramAccessibilityDelegate) {
    this.a = paramAccessibilityDelegate;
    this.b = new a(this);
  }
  
  static List<f.a> c(View paramView) {
    List<?> list2 = (List)paramView.getTag(n.b.H);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return (List)list1;
  }
  
  private boolean e(ClickableSpan paramClickableSpan, View paramView) {
    if (paramClickableSpan != null) {
      ClickableSpan[] arrayOfClickableSpan = f.k(paramView.createAccessibilityNodeInfo().getText());
      for (int i = 0; arrayOfClickableSpan != null && i < arrayOfClickableSpan.length; i++) {
        if (paramClickableSpan.equals(arrayOfClickableSpan[i]))
          return true; 
      } 
    } 
    return false;
  }
  
  private boolean k(int paramInt, View paramView) {
    SparseArray sparseArray = (SparseArray)paramView.getTag(n.b.I);
    if (sparseArray != null) {
      WeakReference<ClickableSpan> weakReference = (WeakReference)sparseArray.get(paramInt);
      if (weakReference != null) {
        ClickableSpan clickableSpan = weakReference.get();
        if (e(clickableSpan, paramView)) {
          clickableSpan.onClick(paramView);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public boolean a(@NonNull View paramView, @NonNull AccessibilityEvent paramAccessibilityEvent) {
    return this.a.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public g b(@NonNull View paramView) {
    AccessibilityNodeProvider accessibilityNodeProvider = b.a(this.a, paramView);
    return (accessibilityNodeProvider != null) ? new g(accessibilityNodeProvider) : null;
  }
  
  View.AccessibilityDelegate d() {
    return this.b;
  }
  
  public void f(@NonNull View paramView, @NonNull AccessibilityEvent paramAccessibilityEvent) {
    this.a.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void g(@NonNull View paramView, @NonNull f paramf) {
    this.a.onInitializeAccessibilityNodeInfo(paramView, paramf.O());
  }
  
  public void h(@NonNull View paramView, @NonNull AccessibilityEvent paramAccessibilityEvent) {
    this.a.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public boolean i(@NonNull ViewGroup paramViewGroup, @NonNull View paramView, @NonNull AccessibilityEvent paramAccessibilityEvent) {
    return this.a.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public boolean j(@NonNull View paramView, int paramInt, Bundle paramBundle) {
    List<f.a> list = c(paramView);
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < list.size()) {
        f.a a1 = list.get(i);
        if (a1.a() == paramInt) {
          bool1 = a1.c(paramView, paramBundle);
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    bool2 = bool1;
    if (!bool1)
      bool2 = b.b(this.a, paramView, paramInt, paramBundle); 
    boolean bool1 = bool2;
    if (!bool2) {
      bool1 = bool2;
      if (paramInt == n.b.a) {
        bool1 = bool2;
        if (paramBundle != null)
          bool1 = k(paramBundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), paramView); 
      } 
    } 
    return bool1;
  }
  
  public void l(@NonNull View paramView, int paramInt) {
    this.a.sendAccessibilityEvent(paramView, paramInt);
  }
  
  public void m(@NonNull View paramView, @NonNull AccessibilityEvent paramAccessibilityEvent) {
    this.a.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
  }
  
  static final class a extends View.AccessibilityDelegate {
    final a a;
    
    a(a param1a) {
      this.a = param1a;
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.a(param1View, param1AccessibilityEvent);
    }
    
    public AccessibilityNodeProvider getAccessibilityNodeProvider(View param1View) {
      g g = this.a.b(param1View);
      return (g != null) ? (AccessibilityNodeProvider)g.a() : null;
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.f(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      f f = f.P(param1AccessibilityNodeInfo);
      f.L(g0.s(param1View));
      f.J(g0.q(param1View));
      f.K(g0.g(param1View));
      f.N(g0.n(param1View));
      this.a.g(param1View, f);
      f.c(param1AccessibilityNodeInfo.getText(), param1View);
      List<f.a> list = a.c(param1View);
      for (int i = 0; i < list.size(); i++)
        f.a(list.get(i)); 
    }
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.h(param1View, param1AccessibilityEvent);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.i(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return this.a.j(param1View, param1Int, param1Bundle);
    }
    
    public void sendAccessibilityEvent(View param1View, int param1Int) {
      this.a.l(param1View, param1Int);
    }
    
    public void sendAccessibilityEventUnchecked(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.m(param1View, param1AccessibilityEvent);
    }
  }
  
  static class b {
    static AccessibilityNodeProvider a(View.AccessibilityDelegate param1AccessibilityDelegate, View param1View) {
      return param1AccessibilityDelegate.getAccessibilityNodeProvider(param1View);
    }
    
    static boolean b(View.AccessibilityDelegate param1AccessibilityDelegate, View param1View, int param1Int, Bundle param1Bundle) {
      return param1AccessibilityDelegate.performAccessibilityAction(param1View, param1Int, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */