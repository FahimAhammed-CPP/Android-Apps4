package androidx.core.view;

import android.view.LayoutInflater;
import androidx.annotation.NonNull;

public final class f {
  public static void a(@NonNull LayoutInflater paramLayoutInflater, @NonNull LayoutInflater.Factory2 paramFactory2) {
    paramLayoutInflater.setFactory2(paramFactory2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */