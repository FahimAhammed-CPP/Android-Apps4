package androidx.core.view;

import android.view.Gravity;

public final class d {
  public static int a(int paramInt1, int paramInt2) {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */