package androidx.core.view;

import android.graphics.Rect;
import android.os.Build;
import android.view.DisplayCutout;
import androidx.annotation.NonNull;
import androidx.core.util.d;
import java.util.List;

public final class c {
  private final DisplayCutout a;
  
  private c(DisplayCutout paramDisplayCutout) {
    this.a = paramDisplayCutout;
  }
  
  static c e(DisplayCutout paramDisplayCutout) {
    return (paramDisplayCutout == null) ? null : new c(paramDisplayCutout);
  }
  
  public int a() {
    return (Build.VERSION.SDK_INT >= 28) ? a.c(this.a) : 0;
  }
  
  public int b() {
    return (Build.VERSION.SDK_INT >= 28) ? a.d(this.a) : 0;
  }
  
  public int c() {
    return (Build.VERSION.SDK_INT >= 28) ? a.e(this.a) : 0;
  }
  
  public int d() {
    return (Build.VERSION.SDK_INT >= 28) ? a.f(this.a) : 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || c.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return d.a(this.a, ((c)paramObject).a);
  }
  
  public int hashCode() {
    DisplayCutout displayCutout = this.a;
    return (displayCutout == null) ? 0 : displayCutout.hashCode();
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DisplayCutoutCompat{");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static class a {
    static DisplayCutout a(Rect param1Rect, List<Rect> param1List) {
      return new DisplayCutout(param1Rect, param1List);
    }
    
    static List<Rect> b(DisplayCutout param1DisplayCutout) {
      return param1DisplayCutout.getBoundingRects();
    }
    
    static int c(DisplayCutout param1DisplayCutout) {
      return param1DisplayCutout.getSafeInsetBottom();
    }
    
    static int d(DisplayCutout param1DisplayCutout) {
      return param1DisplayCutout.getSafeInsetLeft();
    }
    
    static int e(DisplayCutout param1DisplayCutout) {
      return param1DisplayCutout.getSafeInsetRight();
    }
    
    static int f(DisplayCutout param1DisplayCutout) {
      return param1DisplayCutout.getSafeInsetTop();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */