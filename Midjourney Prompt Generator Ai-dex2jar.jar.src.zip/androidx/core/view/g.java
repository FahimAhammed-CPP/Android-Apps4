package androidx.core.view;

import android.view.ViewGroup;
import androidx.annotation.NonNull;

public final class g {
  public static int a(@NonNull ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return a.b(paramMarginLayoutParams);
  }
  
  public static int b(@NonNull ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return a.c(paramMarginLayoutParams);
  }
  
  static class a {
    static int a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getLayoutDirection();
    }
    
    static int b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getMarginEnd();
    }
    
    static int c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getMarginStart();
    }
    
    static boolean d(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.isMarginRelative();
    }
    
    static void e(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.resolveLayoutDirection(param1Int);
    }
    
    static void f(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setLayoutDirection(param1Int);
    }
    
    static void g(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setMarginEnd(param1Int);
    }
    
    static void h(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setMarginStart(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */