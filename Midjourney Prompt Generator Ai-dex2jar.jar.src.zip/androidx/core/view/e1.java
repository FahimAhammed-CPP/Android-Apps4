package androidx.core.view;

import android.view.ViewGroup;
import androidx.annotation.NonNull;

public final class e1 {
  public static boolean a(@NonNull ViewGroup paramViewGroup) {
    return a.b(paramViewGroup);
  }
  
  static class a {
    static int a(ViewGroup param1ViewGroup) {
      return param1ViewGroup.getNestedScrollAxes();
    }
    
    static boolean b(ViewGroup param1ViewGroup) {
      return param1ViewGroup.isTransitionGroup();
    }
    
    static void c(ViewGroup param1ViewGroup, boolean param1Boolean) {
      param1ViewGroup.setTransitionGroup(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\view\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */