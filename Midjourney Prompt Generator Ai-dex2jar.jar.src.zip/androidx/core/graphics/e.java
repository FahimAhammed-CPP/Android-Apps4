package androidx.core.graphics;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.provider.g;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class e extends j {
  private static Class<?> b;
  
  private static Constructor<?> c;
  
  private static Method d;
  
  private static Method e;
  
  private static boolean f = false;
  
  private static boolean h(Object paramObject, String paramString, int paramInt, boolean paramBoolean) {
    k();
    try {
      return ((Boolean)d.invoke(paramObject, new Object[] { paramString, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).booleanValue();
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private static Typeface i(Object paramObject) {
    k();
    try {
      Object object = Array.newInstance(b, 1);
      Array.set(object, 0, paramObject);
      return (Typeface)e.invoke(null, new Object[] { object });
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private File j(@NonNull ParcelFileDescriptor paramParcelFileDescriptor) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("/proc/self/fd/");
      stringBuilder.append(paramParcelFileDescriptor.getFd());
      String str = Os.readlink(stringBuilder.toString());
      return OsConstants.S_ISREG((Os.stat(str)).st_mode) ? new File(str) : null;
    } catch (ErrnoException errnoException) {
      return null;
    } 
  }
  
  private static void k() {
    ClassNotFoundException classNotFoundException1;
    ClassNotFoundException classNotFoundException2;
    ClassNotFoundException classNotFoundException3;
    if (f)
      return; 
    f = true;
    ClassNotFoundException classNotFoundException4 = null;
    try {
      Class<?> clazz = Class.forName("android.graphics.FontFamily");
      Constructor<?> constructor = clazz.getConstructor(new Class[0]);
      Method method2 = clazz.getMethod("addFontWeightStyle", new Class[] { String.class, int.class, boolean.class });
      Method method1 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[] { Array.newInstance(clazz, 1).getClass() });
    } catch (ClassNotFoundException classNotFoundException) {
      Log.e("TypefaceCompatApi21Impl", classNotFoundException.getClass().getName(), classNotFoundException);
      classNotFoundException1 = null;
      classNotFoundException = classNotFoundException1;
      classNotFoundException3 = classNotFoundException;
      classNotFoundException2 = classNotFoundException;
      classNotFoundException = classNotFoundException4;
    } catch (NoSuchMethodException noSuchMethodException) {}
    c = (Constructor<?>)noSuchMethodException;
    b = (Class<?>)classNotFoundException2;
    d = (Method)classNotFoundException3;
    e = (Method)classNotFoundException1;
  }
  
  private static Object l() {
    k();
    try {
      return c.newInstance(new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  public Typeface a(Context paramContext, androidx.core.content.res.e.c paramc, Resources paramResources, int paramInt) {
    Object object = l();
    androidx.core.content.res.e.d[] arrayOfD = paramc.a();
    int i = arrayOfD.length;
    paramInt = 0;
    while (true) {
      if (paramInt < i) {
        androidx.core.content.res.e.d d = arrayOfD[paramInt];
        File file = k.e(paramContext);
        if (file == null)
          return null; 
        try {
          boolean bool = k.c(file, paramResources, d.b());
          if (!bool)
            return null; 
          bool = h(object, file.getPath(), d.e(), d.f());
          if (!bool)
            return null; 
          file.delete();
        } catch (RuntimeException runtimeException) {
          return null;
        } finally {
          file.delete();
        } 
        continue;
      } 
      return i(object);
    } 
  }
  
  public Typeface b(Context paramContext, CancellationSignal paramCancellationSignal, @NonNull g.b[] paramArrayOfb, int paramInt) {
    if (paramArrayOfb.length < 1)
      return null; 
    g.b b1 = g(paramArrayOfb, paramInt);
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(b1.d(), "r", paramCancellationSignal);
      if (parcelFileDescriptor == null) {
        if (parcelFileDescriptor != null)
          parcelFileDescriptor.close(); 
        return null;
      } 
      try {
        FileInputStream fileInputStream;
        File file = j(parcelFileDescriptor);
        if (file == null || !file.canRead()) {
          fileInputStream = new FileInputStream(parcelFileDescriptor.getFileDescriptor());
          try {
            return c(paramContext, fileInputStream);
          } finally {
            try {
              fileInputStream.close();
            } finally {
              fileInputStream = null;
            } 
          } 
        } 
        return Typeface.createFromFile((File)fileInputStream);
      } finally {
        try {
          parcelFileDescriptor.close();
        } finally {
          parcelFileDescriptor = null;
        } 
      } 
    } catch (IOException iOException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\graphics\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */