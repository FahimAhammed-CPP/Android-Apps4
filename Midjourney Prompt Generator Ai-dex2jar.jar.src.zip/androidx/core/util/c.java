package androidx.core.util;

import android.util.Log;
import java.io.Writer;

@Deprecated
public class c extends Writer {
  private final String a;
  
  private StringBuilder b = new StringBuilder(128);
  
  public c(String paramString) {
    this.a = paramString;
  }
  
  private void b() {
    if (this.b.length() > 0) {
      Log.d(this.a, this.b.toString());
      StringBuilder stringBuilder = this.b;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    b();
  }
  
  public void flush() {
    b();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c1 = paramArrayOfchar[paramInt1 + i];
      if (c1 == '\n') {
        b();
      } else {
        this.b.append(c1);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\cor\\util\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */