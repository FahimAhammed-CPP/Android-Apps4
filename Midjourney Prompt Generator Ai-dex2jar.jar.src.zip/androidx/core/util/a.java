package androidx.core.util;

public interface a<T> {
  void accept(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\cor\\util\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */