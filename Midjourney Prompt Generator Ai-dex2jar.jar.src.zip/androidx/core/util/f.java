package androidx.core.util;

import androidx.annotation.NonNull;

public final class f {
  private final float a;
  
  private final float b;
  
  public f(float paramFloat1, float paramFloat2) {
    this.a = e.a(paramFloat1, "width");
    this.b = e.a(paramFloat2, "height");
  }
  
  public float a() {
    return this.b;
  }
  
  public float b() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof f))
      return false; 
    paramObject = paramObject;
    return (((f)paramObject).a == this.a && ((f)paramObject).b == this.b);
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.a) ^ Float.floatToIntBits(this.b);
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.a);
    stringBuilder.append("x");
    stringBuilder.append(this.b);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\cor\\util\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */