package androidx.core.util;

import androidx.annotation.NonNull;

public final class e {
  public static float a(float paramFloat, @NonNull String paramString) {
    if (!Float.isNaN(paramFloat)) {
      if (!Float.isInfinite(paramFloat))
        return paramFloat; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append(" must not be infinite");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(" must not be NaN");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static int b(int paramInt) {
    if (paramInt >= 0)
      return paramInt; 
    throw new IllegalArgumentException();
  }
  
  @NonNull
  public static <T> T c(T paramT) {
    paramT.getClass();
    return paramT;
  }
  
  @NonNull
  public static <T> T d(T paramT, @NonNull Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\cor\\util\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */