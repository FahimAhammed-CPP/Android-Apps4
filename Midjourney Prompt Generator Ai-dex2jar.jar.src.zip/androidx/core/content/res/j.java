package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;



/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\content\res\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */