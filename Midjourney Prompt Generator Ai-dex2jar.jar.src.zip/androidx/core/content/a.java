package androidx.core.content;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.core.app.m0;
import androidx.core.content.res.h;
import androidx.core.os.g;
import java.io.File;
import java.util.concurrent.Executor;

public class a {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  public static int a(@NonNull Context paramContext, @NonNull String paramString) {
    androidx.core.util.d.d(paramString, "permission must be non-null");
    return (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? (m0.b(paramContext).a() ? 0 : -1) : paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static Context b(@NonNull Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? d.a(paramContext) : null;
  }
  
  public static ColorStateList c(@NonNull Context paramContext, int paramInt) {
    return h.c(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static Drawable d(@NonNull Context paramContext, int paramInt) {
    return c.b(paramContext, paramInt);
  }
  
  @NonNull
  public static File[] e(@NonNull Context paramContext) {
    return b.a(paramContext);
  }
  
  @NonNull
  public static File[] f(@NonNull Context paramContext, String paramString) {
    return b.b(paramContext, paramString);
  }
  
  @NonNull
  public static Executor g(@NonNull Context paramContext) {
    return (Build.VERSION.SDK_INT >= 28) ? e.a(paramContext) : g.a(new Handler(paramContext.getMainLooper()));
  }
  
  public static void h(@NonNull Context paramContext, @NonNull Intent paramIntent, Bundle paramBundle) {
    a.b(paramContext, paramIntent, paramBundle);
  }
  
  static class a {
    static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  static class b {
    static File[] a(Context param1Context) {
      return param1Context.getExternalCacheDirs();
    }
    
    static File[] b(Context param1Context, String param1String) {
      return param1Context.getExternalFilesDirs(param1String);
    }
    
    static File[] c(Context param1Context) {
      return param1Context.getObbDirs();
    }
  }
  
  static class c {
    static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  static class d {
    static Context a(Context param1Context) {
      return c.a(param1Context);
    }
    
    static File b(Context param1Context) {
      return d.a(param1Context);
    }
    
    static boolean c(Context param1Context) {
      return b.a(param1Context);
    }
  }
  
  static class e {
    static Executor a(Context param1Context) {
      return e.a(param1Context);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\content\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */