package androidx.core.os;

import android.os.Bundle;
import android.os.IBinder;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

final class b {
  @NotNull
  public static final b a = new b();
  
  public static final void a(@NotNull Bundle paramBundle, @NotNull String paramString, IBinder paramIBinder) {
    Intrinsics.checkNotNullParameter(paramBundle, "bundle");
    Intrinsics.checkNotNullParameter(paramString, "key");
    paramBundle.putBinder(paramString, paramIBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */