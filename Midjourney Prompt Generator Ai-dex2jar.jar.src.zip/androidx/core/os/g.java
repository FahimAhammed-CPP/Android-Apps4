package androidx.core.os;

import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.core.util.e;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class g {
  @NonNull
  public static Executor a(@NonNull Handler paramHandler) {
    return new a(paramHandler);
  }
  
  private static class a implements Executor {
    private final Handler a;
    
    a(@NonNull Handler param1Handler) {
      this.a = (Handler)e.c(param1Handler);
    }
    
    public void execute(@NonNull Runnable param1Runnable) {
      if (this.a.post((Runnable)e.c(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */