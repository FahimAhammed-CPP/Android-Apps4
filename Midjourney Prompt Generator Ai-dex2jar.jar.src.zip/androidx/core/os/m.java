package androidx.core.os;

import android.content.Context;
import android.os.Build;
import android.os.UserManager;
import androidx.annotation.NonNull;
import androidx.core.app.d;

public class m {
  public static boolean a(@NonNull Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? a.a(paramContext) : true;
  }
  
  static class a {
    static boolean a(Context param1Context) {
      return l.a((UserManager)d.a(param1Context, UserManager.class));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */