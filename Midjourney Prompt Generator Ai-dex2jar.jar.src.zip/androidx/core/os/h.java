package androidx.core.os;

import android.os.Build;
import android.os.LocaleList;
import androidx.annotation.NonNull;
import java.util.Locale;

public final class h {
  private static final h b = a(new Locale[0]);
  
  private final j a;
  
  private h(j paramj) {
    this.a = paramj;
  }
  
  @NonNull
  public static h a(@NonNull Locale... paramVarArgs) {
    return (Build.VERSION.SDK_INT >= 24) ? d(a.a(paramVarArgs)) : new h(new i(paramVarArgs));
  }
  
  static Locale b(String paramString) {
    if (paramString.contains("-")) {
      String[] arrayOfString = paramString.split("-", -1);
      if (arrayOfString.length > 2)
        return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
      if (arrayOfString.length > 1)
        return new Locale(arrayOfString[0], arrayOfString[1]); 
      if (arrayOfString.length == 1)
        return new Locale(arrayOfString[0]); 
    } else {
      if (paramString.contains("_")) {
        String[] arrayOfString = paramString.split("_", -1);
        if (arrayOfString.length > 2)
          return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
        if (arrayOfString.length > 1)
          return new Locale(arrayOfString[0], arrayOfString[1]); 
        if (arrayOfString.length == 1)
          return new Locale(arrayOfString[0]); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Can not parse language tag: [");
        stringBuilder1.append(paramString);
        stringBuilder1.append("]");
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      return new Locale(paramString);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can not parse language tag: [");
    stringBuilder.append(paramString);
    stringBuilder.append("]");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @NonNull
  public static h d(@NonNull LocaleList paramLocaleList) {
    return new h(new k(paramLocaleList));
  }
  
  public Locale c(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof h && this.a.equals(((h)paramObject).a));
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  @NonNull
  public String toString() {
    return this.a.toString();
  }
  
  static class a {
    static LocaleList a(Locale... param1VarArgs) {
      return new LocaleList(param1VarArgs);
    }
    
    static LocaleList b() {
      return LocaleList.getAdjustedDefault();
    }
    
    static LocaleList c() {
      return LocaleList.getDefault();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */