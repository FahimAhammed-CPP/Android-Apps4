package androidx.core.os;

import android.os.Build;
import android.os.ext.SdkExtensions;
import androidx.annotation.NonNull;
import java.util.Locale;

public class a {
  public static final int a;
  
  public static final int b;
  
  public static final int c;
  
  public static final int d;
  
  static {
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 30) {
      i = a.a;
    } else {
      i = 0;
    } 
    a = i;
    if (j >= 30) {
      i = a.b;
    } else {
      i = 0;
    } 
    b = i;
    if (j >= 30) {
      i = a.c;
    } else {
      i = 0;
    } 
    c = i;
    int i = bool;
    if (j >= 30)
      i = a.d; 
    d = i;
  }
  
  protected static boolean a(@NonNull String paramString1, @NonNull String paramString2) {
    boolean bool1 = "REL".equals(paramString2);
    boolean bool = false;
    if (bool1)
      return false; 
    Locale locale = Locale.ROOT;
    if (paramString2.toUpperCase(locale).compareTo(paramString1.toUpperCase(locale)) >= 0)
      bool = true; 
    return bool;
  }
  
  @Deprecated
  public static boolean b() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  public static boolean c() {
    int i = Build.VERSION.SDK_INT;
    return (i >= 33 || (i >= 32 && a("Tiramisu", Build.VERSION.CODENAME)));
  }
  
  private static final class a {
    static final int a = SdkExtensions.getExtensionVersion(30);
    
    static final int b = SdkExtensions.getExtensionVersion(31);
    
    static final int c = SdkExtensions.getExtensionVersion(33);
    
    static final int d = SdkExtensions.getExtensionVersion(1000000);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */