package androidx.core.os;

import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import androidx.annotation.NonNull;
import java.util.Locale;

public final class f {
  @NonNull
  public static h a(@NonNull Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? h.d(a.a(paramConfiguration)) : h.a(new Locale[] { paramConfiguration.locale });
  }
  
  static class a {
    static LocaleList a(Configuration param1Configuration) {
      return e.a(param1Configuration);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */