package androidx.core.os;

import android.os.Bundle;
import android.util.Size;
import android.util.SizeF;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

final class c {
  @NotNull
  public static final c a = new c();
  
  public static final void a(@NotNull Bundle paramBundle, @NotNull String paramString, Size paramSize) {
    Intrinsics.checkNotNullParameter(paramBundle, "bundle");
    Intrinsics.checkNotNullParameter(paramString, "key");
    paramBundle.putSize(paramString, paramSize);
  }
  
  public static final void b(@NotNull Bundle paramBundle, @NotNull String paramString, SizeF paramSizeF) {
    Intrinsics.checkNotNullParameter(paramBundle, "bundle");
    Intrinsics.checkNotNullParameter(paramString, "key");
    paramBundle.putSizeF(paramString, paramSizeF);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\os\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */