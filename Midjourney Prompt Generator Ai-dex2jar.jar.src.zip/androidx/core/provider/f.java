package androidx.core.provider;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import m.g;

class f {
  static final m.e<String, Typeface> a = new m.e(16);
  
  private static final ExecutorService b = h.a("fonts-androidx", 10, 10000);
  
  static final Object c = new Object();
  
  static final g<String, ArrayList<androidx.core.util.a<e>>> d = new g();
  
  private static String a(@NonNull e parame, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(parame.d());
    stringBuilder.append("-");
    stringBuilder.append(paramInt);
    return stringBuilder.toString();
  }
  
  private static int b(@NonNull g.a parama) {
    int i = parama.c();
    int j = 1;
    if (i != 0)
      return (parama.c() != 1) ? -3 : -2; 
    g.b[] arrayOfB = parama.b();
    if (arrayOfB != null) {
      if (arrayOfB.length == 0)
        return 1; 
      int k = arrayOfB.length;
      byte b = 0;
      i = 0;
      while (true) {
        j = b;
        if (i < k) {
          j = arrayOfB[i].b();
          if (j != 0)
            return (j < 0) ? -3 : j; 
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  @NonNull
  static e c(@NonNull String paramString, @NonNull Context paramContext, @NonNull e parame, int paramInt) {
    m.e<String, Typeface> e1 = a;
    Typeface typeface = (Typeface)e1.c(paramString);
    if (typeface != null)
      return new e(typeface); 
    try {
      g.a a = d.e(paramContext, parame, null);
      int i = b(a);
      if (i != 0)
        return new e(i); 
      Typeface typeface1 = androidx.core.graphics.d.a(paramContext, null, a.b(), paramInt);
      if (typeface1 != null) {
        e1.d(paramString, typeface1);
        return new e(typeface1);
      } 
      return new e(-3);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return new e(-1);
    } 
  }
  
  static Typeface d(@NonNull Context paramContext, @NonNull e parame, int paramInt, Executor paramExecutor, @NonNull a parama) {
    String str = a(parame, paramInt);
    Typeface typeface = (Typeface)a.c(str);
    if (typeface != null) {
      parama.b(new e(typeface));
      return typeface;
    } 
    b b = new b(parama);
    synchronized (c) {
      g<String, ArrayList<androidx.core.util.a<e>>> g1 = d;
      ArrayList<b> arrayList = (ArrayList)g1.get(str);
      if (arrayList != null) {
        arrayList.add(b);
        return null;
      } 
      arrayList = new ArrayList<b>();
      arrayList.add(b);
      g1.put(str, arrayList);
      c c = new c(str, paramContext, parame, paramInt);
      Executor executor = paramExecutor;
      if (paramExecutor == null)
        executor = b; 
      h.b(executor, c, new d(str));
      return null;
    } 
  }
  
  static Typeface e(@NonNull Context paramContext, @NonNull e parame, @NonNull a parama, int paramInt1, int paramInt2) {
    e e1;
    String str = a(parame, paramInt1);
    Typeface typeface = (Typeface)a.c(str);
    if (typeface != null) {
      parama.b(new e(typeface));
      return typeface;
    } 
    if (paramInt2 == -1) {
      e1 = c(str, paramContext, parame, paramInt1);
      parama.b(e1);
      return e1.a;
    } 
    a a1 = new a(str, (Context)e1, parame, paramInt1);
    try {
      e e2 = h.<e>c(b, a1, paramInt2);
      parama.b(e2);
      return e2.a;
    } catch (InterruptedException interruptedException) {
      parama.b(new e(-3));
      return null;
    } 
  }
  
  class a implements Callable<e> {
    a(f this$0, Context param1Context, e param1e, int param1Int) {}
    
    public f.e a() {
      return f.c(this.a, this.b, this.c, this.d);
    }
  }
  
  class b implements androidx.core.util.a<e> {
    b(f this$0) {}
    
    public void a(f.e param1e) {
      f.e e1 = param1e;
      if (param1e == null)
        e1 = new f.e(-3); 
      this.a.b(e1);
    }
  }
  
  class c implements Callable<e> {
    c(f this$0, Context param1Context, e param1e, int param1Int) {}
    
    public f.e a() {
      try {
        return f.c(this.a, this.b, this.c, this.d);
      } finally {
        Exception exception = null;
      } 
    }
  }
  
  class d implements androidx.core.util.a<e> {
    d(f this$0) {}
    
    public void a(f.e param1e) {
      synchronized (f.c) {
        g<String, ArrayList<androidx.core.util.a<f.e>>> g = f.d;
        ArrayList<androidx.core.util.a> arrayList = (ArrayList)g.get(this.a);
        if (arrayList == null)
          return; 
        g.remove(this.a);
        for (int i = 0; i < arrayList.size(); i++)
          ((androidx.core.util.a)arrayList.get(i)).accept(param1e); 
        return;
      } 
    }
  }
  
  static final class e {
    final Typeface a = null;
    
    final int b;
    
    e(int param1Int) {
      this.b = param1Int;
    }
    
    e(@NonNull Typeface param1Typeface) {
      this.b = 0;
    }
    
    boolean a() {
      return (this.b == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\androidx\core\provider\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */