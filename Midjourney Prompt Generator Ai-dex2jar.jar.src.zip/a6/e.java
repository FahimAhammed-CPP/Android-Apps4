package a6;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class e<T> implements Iterable<T> {
  private final c<T, Void> a;
  
  private e(c<T, Void> paramc) {
    this.a = paramc;
  }
  
  public e(List<T> paramList, Comparator<T> paramComparator) {
    this.a = c.a.b(paramList, Collections.emptyMap(), c.a.d(), paramComparator);
  }
  
  public T a() {
    return this.a.h();
  }
  
  public T c() {
    return this.a.m();
  }
  
  public boolean contains(T paramT) {
    return this.a.a(paramT);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof e))
      return false; 
    paramObject = paramObject;
    return this.a.equals(((e)paramObject).a);
  }
  
  public e<T> g(T paramT) {
    return new e(this.a.o(paramT, null));
  }
  
  public Iterator<T> h(T paramT) {
    return new a<T>(this.a.q(paramT));
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public int indexOf(T paramT) {
    return this.a.indexOf(paramT);
  }
  
  public boolean isEmpty() {
    return this.a.isEmpty();
  }
  
  public Iterator<T> iterator() {
    return new a<T>(this.a.iterator());
  }
  
  public e<T> m(T paramT) {
    c<T, Void> c1 = this.a.r(paramT);
    return (c1 == this.a) ? this : new e(c1);
  }
  
  public e<T> o(e<T> parame) {
    e<T> e1;
    if (size() < parame.size()) {
      e e2 = this;
      e1 = e2;
    } else {
      e<T> e2 = this;
      e1 = parame;
      parame = e2;
    } 
    Iterator<T> iterator = e1.iterator();
    while (iterator.hasNext())
      parame = parame.g(iterator.next()); 
    return parame;
  }
  
  public int size() {
    return this.a.size();
  }
  
  private static class a<T> implements Iterator<T> {
    final Iterator<Map.Entry<T, Void>> a;
    
    public a(Iterator<Map.Entry<T, Void>> param1Iterator) {
      this.a = param1Iterator;
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public T next() {
      return (T)((Map.Entry)this.a.next()).getKey();
    }
    
    public void remove() {
      this.a.remove();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */