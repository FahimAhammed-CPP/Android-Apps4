package a6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class k<K, V> extends c<K, V> {
  private h<K, V> a;
  
  private Comparator<K> b;
  
  private k(h<K, V> paramh, Comparator<K> paramComparator) {
    this.a = paramh;
    this.b = paramComparator;
  }
  
  public static <A, B, C> k<A, C> s(List<A> paramList, Map<B, C> paramMap, c.a.a<A, B> parama, Comparator<A> paramComparator) {
    return b.b(paramList, paramMap, parama, paramComparator);
  }
  
  public static <A, B> k<A, B> t(Map<A, B> paramMap, Comparator<A> paramComparator) {
    return b.b(new ArrayList<A>(paramMap.keySet()), paramMap, c.a.d(), paramComparator);
  }
  
  private h<K, V> u(K paramK) {
    for (h<K, V> h1 = this.a; !h1.isEmpty(); h1 = h1.f()) {
      int i = this.b.compare(paramK, h1.getKey());
      if (i < 0) {
        h1 = h1.a();
        continue;
      } 
      if (i == 0)
        return h1; 
    } 
    return null;
  }
  
  public boolean a(K paramK) {
    return (u(paramK) != null);
  }
  
  public V c(K paramK) {
    h<K, V> h1 = u(paramK);
    return (h1 != null) ? h1.getValue() : null;
  }
  
  public Comparator<K> g() {
    return this.b;
  }
  
  public K h() {
    return (K)this.a.h().getKey();
  }
  
  public int indexOf(K paramK) {
    h<K, V> h1 = this.a;
    int i = 0;
    while (!h1.isEmpty()) {
      int j = this.b.compare(paramK, h1.getKey());
      if (j == 0)
        return i + h1.a().size(); 
      if (j < 0) {
        h1 = h1.a();
        continue;
      } 
      i += h1.a().size() + 1;
      h1 = h1.f();
    } 
    return -1;
  }
  
  public boolean isEmpty() {
    return this.a.isEmpty();
  }
  
  public Iterator<Map.Entry<K, V>> iterator() {
    return new d<K, V>(this.a, null, this.b, false);
  }
  
  public K m() {
    return (K)this.a.g().getKey();
  }
  
  public c<K, V> o(K paramK, V paramV) {
    return new k(this.a.b(paramK, paramV, this.b).c(null, null, h.a.b, null, null), this.b);
  }
  
  public Iterator<Map.Entry<K, V>> q(K paramK) {
    return new d<K, V>(this.a, paramK, this.b, false);
  }
  
  public c<K, V> r(K paramK) {
    return !a(paramK) ? this : new k(this.a.d(paramK, this.b).c(null, null, h.a.b, null, null), this.b);
  }
  
  public int size() {
    return this.a.size();
  }
  
  private static class b<A, B, C> {
    private final List<A> a;
    
    private final Map<B, C> b;
    
    private final c.a.a<A, B> c;
    
    private j<A, C> d;
    
    private j<A, C> e;
    
    private b(List<A> param1List, Map<B, C> param1Map, c.a.a<A, B> param1a) {
      this.a = param1List;
      this.b = param1Map;
      this.c = param1a;
    }
    
    private h<A, C> a(int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        return g.i(); 
      if (param1Int2 == 1) {
        A a2 = this.a.get(param1Int1);
        return new f<A, C>(a2, d(a2), null, null);
      } 
      param1Int2 /= 2;
      int i = param1Int1 + param1Int2;
      h<A, C> h1 = a(param1Int1, param1Int2);
      h<A, C> h2 = a(i + 1, param1Int2);
      A a1 = this.a.get(i);
      return new f<A, C>(a1, d(a1), h1, h2);
    }
    
    public static <A, B, C> k<A, C> b(List<A> param1List, Map<B, C> param1Map, c.a.a<A, B> param1a, Comparator<A> param1Comparator) {
      g<?, ?> g;
      b<A, B, C> b1 = new b<A, B, C>(param1List, param1Map, param1a);
      Collections.sort(param1List, param1Comparator);
      Iterator<b> iterator = (new a(param1List.size())).iterator();
      int i = param1List.size();
      while (iterator.hasNext()) {
        b b2 = iterator.next();
        int k = b2.b;
        i -= k;
        if (b2.a) {
          b1.c(h.a.b, k, i);
          continue;
        } 
        b1.c(h.a.b, k, i);
        k = b2.b;
        i -= k;
        b1.c(h.a.a, k, i);
      } 
      j<A, C> j2 = b1.d;
      j<A, C> j1 = j2;
      if (j2 == null)
        g = g.i(); 
      return new k<A, C>(g, param1Comparator, null);
    }
    
    private void c(h.a param1a, int param1Int1, int param1Int2) {
      f<A, C> f;
      h<A, C> h = a(param1Int2 + 1, param1Int1 - 1);
      A a1 = this.a.get(param1Int2);
      if (param1a == h.a.a) {
        i<A, C> i = new i<A, C>(a1, d(a1), null, h);
      } else {
        f = new f<A, C>(a1, d(a1), null, h);
      } 
      if (this.d == null) {
        this.d = f;
        this.e = f;
        return;
      } 
      this.e.t(f);
      this.e = f;
    }
    
    private C d(A param1A) {
      return this.b.get(this.c.a(param1A));
    }
    
    static class a implements Iterable<b> {
      private long a;
      
      private final int b;
      
      public a(int param2Int) {
        int i = (int)Math.floor(Math.log(++param2Int) / Math.log(2.0D));
        this.b = i;
        this.a = (long)Math.pow(2.0D, i) - 1L & param2Int;
      }
      
      public Iterator<k.b.b> iterator() {
        return new a(this);
      }
      
      class a implements Iterator<k.b.b> {
        private int a;
        
        a(k.b.a this$0) {
          this.a = k.b.a.a(this$0) - 1;
        }
        
        public k.b.b b() {
          boolean bool;
          long l1 = k.b.a.c(this.b);
          long l2 = (1 << this.a);
          k.b.b b = new k.b.b();
          if ((l1 & l2) == 0L) {
            bool = true;
          } else {
            bool = false;
          } 
          b.a = bool;
          b.b = (int)Math.pow(2.0D, this.a);
          this.a--;
          return b;
        }
        
        public boolean hasNext() {
          return (this.a >= 0);
        }
        
        public void remove() {}
      }
    }
    
    class a implements Iterator<b> {
      private int a;
      
      a(k.b this$0) {
        this.a = k.b.a.a((k.b.a)this$0) - 1;
      }
      
      public k.b.b b() {
        boolean bool;
        long l1 = k.b.a.c(this.b);
        long l2 = (1 << this.a);
        k.b.b b = new k.b.b();
        if ((l1 & l2) == 0L) {
          bool = true;
        } else {
          bool = false;
        } 
        b.a = bool;
        b.b = (int)Math.pow(2.0D, this.a);
        this.a--;
        return b;
      }
      
      public boolean hasNext() {
        return (this.a >= 0);
      }
      
      public void remove() {}
    }
    
    static class b {
      public boolean a;
      
      public int b;
    }
  }
  
  static class a implements Iterable<b.b> {
    private long a;
    
    private final int b;
    
    public a(int param1Int) {
      int i = (int)Math.floor(Math.log(++param1Int) / Math.log(2.0D));
      this.b = i;
      this.a = (long)Math.pow(2.0D, i) - 1L & param1Int;
    }
    
    public Iterator<k.b.b> iterator() {
      return new a(this);
    }
    
    class a implements Iterator<k.b.b> {
      private int a;
      
      a(k.b.a this$0) {
        this.a = k.b.a.a(this$0) - 1;
      }
      
      public k.b.b b() {
        boolean bool;
        long l1 = k.b.a.c(this.b);
        long l2 = (1 << this.a);
        k.b.b b = new k.b.b();
        if ((l1 & l2) == 0L) {
          bool = true;
        } else {
          bool = false;
        } 
        b.a = bool;
        b.b = (int)Math.pow(2.0D, this.a);
        this.a--;
        return b;
      }
      
      public boolean hasNext() {
        return (this.a >= 0);
      }
      
      public void remove() {}
    }
  }
  
  class a implements Iterator<b.b> {
    private int a;
    
    a(k this$0) {
      this.a = k.b.a.a((k.b.a)this$0) - 1;
    }
    
    public k.b.b b() {
      boolean bool;
      long l1 = k.b.a.c(this.b);
      long l2 = (1 << this.a);
      k.b.b b = new k.b.b();
      if ((l1 & l2) == 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      b.a = bool;
      b.b = (int)Math.pow(2.0D, this.a);
      this.a--;
      return b;
    }
    
    public boolean hasNext() {
      return (this.a >= 0);
    }
    
    public void remove() {}
  }
  
  static class b {
    public boolean a;
    
    public int b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */