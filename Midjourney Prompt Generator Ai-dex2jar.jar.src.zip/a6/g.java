package a6;

import java.util.Comparator;

public class g<K, V> implements h<K, V> {
  private static final g a = new g();
  
  public static <K, V> g<K, V> i() {
    return a;
  }
  
  public h<K, V> a() {
    return this;
  }
  
  public h<K, V> b(K paramK, V paramV, Comparator<K> paramComparator) {
    return new i<K, V>(paramK, paramV);
  }
  
  public h<K, V> c(K paramK, V paramV, h.a parama, h<K, V> paramh1, h<K, V> paramh2) {
    return this;
  }
  
  public h<K, V> d(K paramK, Comparator<K> paramComparator) {
    return this;
  }
  
  public boolean e() {
    return false;
  }
  
  public h<K, V> f() {
    return this;
  }
  
  public h<K, V> g() {
    return this;
  }
  
  public K getKey() {
    return null;
  }
  
  public V getValue() {
    return null;
  }
  
  public h<K, V> h() {
    return this;
  }
  
  public boolean isEmpty() {
    return true;
  }
  
  public int size() {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */