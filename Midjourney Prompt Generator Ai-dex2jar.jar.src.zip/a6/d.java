package a6;

import java.util.AbstractMap;
import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

public class d<K, V> implements Iterator<Map.Entry<K, V>> {
  private final ArrayDeque<j<K, V>> a = new ArrayDeque<j<K, V>>();
  
  private final boolean b;
  
  d(h<K, V> paramh, K paramK, Comparator<K> paramComparator, boolean paramBoolean) {
    this.b = paramBoolean;
    while (!paramh.isEmpty()) {
      boolean bool;
      if (paramK != null) {
        if (paramBoolean) {
          bool = paramComparator.compare(paramK, paramh.getKey());
        } else {
          bool = paramComparator.compare(paramh.getKey(), paramK);
        } 
      } else {
        bool = true;
      } 
      if (bool) {
        if (paramBoolean) {
          paramh = paramh.a();
          continue;
        } 
        paramh = paramh.f();
        continue;
      } 
      if (!bool) {
        this.a.push((j<K, V>)paramh);
        return;
      } 
      this.a.push((j<K, V>)paramh);
      if (paramBoolean) {
        paramh = paramh.f();
        continue;
      } 
      paramh = paramh.a();
    } 
  }
  
  public Map.Entry<K, V> b() {
    try {
      h h = this.a.pop();
      AbstractMap.SimpleEntry<Object, Object> simpleEntry = new AbstractMap.SimpleEntry<Object, Object>(h.getKey(), h.getValue());
      if (this.b) {
        for (h = h.a(); !h.isEmpty(); h = h.f())
          this.a.push((j<K, V>)h); 
      } else {
        for (h = h.f(); !h.isEmpty(); h = h.a())
          this.a.push((j<K, V>)h); 
      } 
      return (Map.Entry)simpleEntry;
    } catch (EmptyStackException emptyStackException) {
      throw new NoSuchElementException();
    } 
  }
  
  public boolean hasNext() {
    return (this.a.size() > 0);
  }
  
  public void remove() {
    throw new UnsupportedOperationException("remove called on immutable collection");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */