package a6;

import java.util.Comparator;

public interface h<K, V> {
  h<K, V> a();
  
  h<K, V> b(K paramK, V paramV, Comparator<K> paramComparator);
  
  h<K, V> c(K paramK, V paramV, a parama, h<K, V> paramh1, h<K, V> paramh2);
  
  h<K, V> d(K paramK, Comparator<K> paramComparator);
  
  boolean e();
  
  h<K, V> f();
  
  h<K, V> g();
  
  K getKey();
  
  V getValue();
  
  h<K, V> h();
  
  boolean isEmpty();
  
  int size();
  
  public enum a {
    a, b;
    
    static {
      a a1 = new a("RED", 0);
      a = a1;
      a a2 = new a("BLACK", 1);
      b = a2;
      c = new a[] { a1, a2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */