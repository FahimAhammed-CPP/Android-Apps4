package a6;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class c<K, V> implements Iterable<Map.Entry<K, V>> {
  public abstract boolean a(K paramK);
  
  public abstract V c(K paramK);
  
  public boolean equals(Object<Map.Entry<K, V>> paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof c))
      return false; 
    c c1 = (c)paramObject;
    if (!g().equals(c1.g()))
      return false; 
    if (size() != c1.size())
      return false; 
    paramObject = (Object<Map.Entry<K, V>>)iterator();
    Iterator iterator = c1.iterator();
    while (paramObject.hasNext()) {
      if (!((Map.Entry)paramObject.next()).equals(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public abstract Comparator<K> g();
  
  public abstract K h();
  
  public int hashCode() {
    int i = g().hashCode();
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (iterator.hasNext())
      i = i * 31 + ((Map.Entry)iterator.next()).hashCode(); 
    return i;
  }
  
  public abstract int indexOf(K paramK);
  
  public abstract boolean isEmpty();
  
  public abstract Iterator<Map.Entry<K, V>> iterator();
  
  public abstract K m();
  
  public abstract c<K, V> o(K paramK, V paramV);
  
  public abstract Iterator<Map.Entry<K, V>> q(K paramK);
  
  public abstract c<K, V> r(K paramK);
  
  public abstract int size();
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    boolean bool = true;
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      if (bool) {
        bool = false;
      } else {
        stringBuilder.append(", ");
      } 
      stringBuilder.append("(");
      stringBuilder.append(entry.getKey());
      stringBuilder.append("=>");
      stringBuilder.append(entry.getValue());
      stringBuilder.append(")");
    } 
    stringBuilder.append("};");
    return stringBuilder.toString();
  }
  
  public static class a {
    private static final a a = new b();
    
    public static <A, B, C> c<A, C> b(List<A> param1List, Map<B, C> param1Map, a<A, B> param1a, Comparator<A> param1Comparator) {
      return (c<A, C>)((param1List.size() < 25) ? a.v(param1List, param1Map, param1a, param1Comparator) : k.s(param1List, param1Map, param1a, param1Comparator));
    }
    
    public static <K, V> c<K, V> c(Comparator<K> param1Comparator) {
      return new a<K, V>(param1Comparator);
    }
    
    public static <A> a<A, A> d() {
      return a;
    }
    
    public static interface a<C, D> {
      D a(C param2C);
    }
  }
  
  public static interface a<C, D> {
    D a(C param1C);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */