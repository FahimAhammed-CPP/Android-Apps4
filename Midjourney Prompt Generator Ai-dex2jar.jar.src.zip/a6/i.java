package a6;

public class i<K, V> extends j<K, V> {
  i(K paramK, V paramV) {
    super(paramK, paramV, g.i(), g.i());
  }
  
  i(K paramK, V paramV, h<K, V> paramh1, h<K, V> paramh2) {
    super(paramK, paramV, paramh1, paramh2);
  }
  
  public boolean e() {
    return true;
  }
  
  protected j<K, V> k(K paramK, V paramV, h<K, V> paramh1, h<K, V> paramh2) {
    K k = paramK;
    if (paramK == null)
      k = getKey(); 
    V v = paramV;
    if (paramV == null)
      v = getValue(); 
    h<K, V> h1 = paramh1;
    if (paramh1 == null)
      h1 = a(); 
    paramh1 = paramh2;
    if (paramh2 == null)
      paramh1 = f(); 
    return new i(k, v, h1, paramh1);
  }
  
  protected h.a m() {
    return h.a.a;
  }
  
  public int size() {
    return a().size() + 1 + f().size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */