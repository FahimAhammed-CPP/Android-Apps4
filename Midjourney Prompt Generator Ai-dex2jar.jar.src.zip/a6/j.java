package a6;

import java.util.Comparator;

public abstract class j<K, V> implements h<K, V> {
  private final K a;
  
  private final V b;
  
  private h<K, V> c;
  
  private final h<K, V> d;
  
  j(K paramK, V paramV, h<K, V> paramh1, h<K, V> paramh2) {
    this.a = paramK;
    this.b = paramV;
    h<K, V> h1 = paramh1;
    if (paramh1 == null)
      h1 = g.i(); 
    this.c = h1;
    h1 = paramh2;
    if (paramh2 == null)
      h1 = g.i(); 
    this.d = h1;
  }
  
  private j<K, V> i() {
    h<K, V> h1 = this.c;
    h1 = h1.c(null, null, p(h1), null, null);
    h<K, V> h2 = this.d;
    h2 = h2.c(null, null, p(h2), null, null);
    return j(null, null, p(this), h1, h2);
  }
  
  private j<K, V> l() {
    if (this.d.e() && !this.c.e()) {
      j2 = r();
    } else {
      j2 = this;
    } 
    j<K, V> j1 = j2;
    if (j2.c.e()) {
      j1 = j2;
      if (((j)j2.c).c.e())
        j1 = j2.s(); 
    } 
    j<K, V> j2 = j1;
    if (j1.c.e()) {
      j2 = j1;
      if (j1.d.e())
        j2 = j1.i(); 
    } 
    return j2;
  }
  
  private j<K, V> n() {
    j<K, V> j2 = i();
    j<K, V> j1 = j2;
    if (j2.f().a().e())
      j1 = j2.k(null, null, null, ((j<K, V>)j2.f()).s()).r().i(); 
    return j1;
  }
  
  private j<K, V> o() {
    j<K, V> j2 = i();
    j<K, V> j1 = j2;
    if (j2.a().a().e())
      j1 = j2.s().i(); 
    return j1;
  }
  
  private static h.a p(h paramh) {
    return paramh.e() ? h.a.b : h.a.a;
  }
  
  private h<K, V> q() {
    j<K, V> j1;
    if (this.c.isEmpty())
      return g.i(); 
    if (!a().e() && !a().a().e()) {
      j1 = n();
    } else {
      j1 = this;
    } 
    return j1.k(null, null, ((j<K, V>)j1.c).q(), null).l();
  }
  
  private j<K, V> r() {
    j<K, V> j1 = j(null, null, h.a.a, null, ((j)this.d).c);
    return (j<K, V>)this.d.c(null, null, m(), j1, null);
  }
  
  private j<K, V> s() {
    j<K, V> j1 = j(null, null, h.a.a, ((j)this.c).d, null);
    return (j<K, V>)this.c.c(null, null, m(), null, j1);
  }
  
  public h<K, V> a() {
    return this.c;
  }
  
  public h<K, V> b(K paramK, V paramV, Comparator<K> paramComparator) {
    j<K, V> j1;
    int i = paramComparator.compare(paramK, this.a);
    if (i < 0) {
      j1 = k(null, null, this.c.b(paramK, paramV, paramComparator), null);
    } else if (i == 0) {
      j1 = k((K)j1, paramV, null, null);
    } else {
      j1 = k(null, null, null, this.d.b((K)j1, paramV, paramComparator));
    } 
    return j1.l();
  }
  
  public h<K, V> d(K paramK, Comparator<K> paramComparator) {
    j<K, V> j1;
    if (paramComparator.compare(paramK, this.a) < 0) {
      j j2;
      if (!this.c.isEmpty() && !this.c.e() && !((j)this.c).c.e()) {
        j2 = n();
      } else {
        j2 = this;
      } 
      j1 = j2.k(null, null, j2.c.d(paramK, paramComparator), null);
    } else {
      if (this.c.e()) {
        h1 = s();
      } else {
        h1 = this;
      } 
      j<K, V> j2 = (j<K, V>)h1;
      if (!((j)h1).d.isEmpty()) {
        j2 = (j<K, V>)h1;
        if (!((j)h1).d.e()) {
          j2 = (j<K, V>)h1;
          if (!((j)((j)h1).d).c.e())
            j2 = h1.o(); 
        } 
      } 
      h<K, V> h1 = j2;
      if (paramComparator.compare((K)j1, j2.a) == 0) {
        if (j2.d.isEmpty())
          return g.i(); 
        h1 = j2.d.g();
        h1 = j2.k(h1.getKey(), h1.getValue(), null, ((j<K, V>)j2.d).q());
      } 
      j1 = h1.k(null, null, null, ((j)h1).d.d((K)j1, paramComparator));
    } 
    return j1.l();
  }
  
  public h<K, V> f() {
    return this.d;
  }
  
  public h<K, V> g() {
    return this.c.isEmpty() ? this : this.c.g();
  }
  
  public K getKey() {
    return this.a;
  }
  
  public V getValue() {
    return this.b;
  }
  
  public h<K, V> h() {
    return this.d.isEmpty() ? this : this.d.h();
  }
  
  public boolean isEmpty() {
    return false;
  }
  
  public j<K, V> j(K paramK, V paramV, h.a parama, h<K, V> paramh1, h<K, V> paramh2) {
    K k = paramK;
    if (paramK == null)
      k = this.a; 
    V v = paramV;
    if (paramV == null)
      v = this.b; 
    h<K, V> h1 = paramh1;
    if (paramh1 == null)
      h1 = this.c; 
    paramh1 = paramh2;
    if (paramh2 == null)
      paramh1 = this.d; 
    return (j<K, V>)((parama == h.a.a) ? new i<K, V>(k, v, h1, paramh1) : new f<K, V>(k, v, h1, paramh1));
  }
  
  protected abstract j<K, V> k(K paramK, V paramV, h<K, V> paramh1, h<K, V> paramh2);
  
  protected abstract h.a m();
  
  void t(h<K, V> paramh) {
    this.c = paramh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a6\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */