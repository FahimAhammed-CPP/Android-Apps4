package a7;

import androidx.annotation.NonNull;
import d5.l;

public class a extends l {
  public a(@NonNull String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Midjourney Prompt Generator Ai-dex2jar.jar!\a7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */