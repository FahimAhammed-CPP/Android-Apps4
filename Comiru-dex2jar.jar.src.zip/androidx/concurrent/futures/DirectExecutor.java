package androidx.concurrent.futures;

import androidx.annotation.RestrictTo;
import java.util.concurrent.Executor;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public enum DirectExecutor implements Executor {
  INSTANCE;
  
  static {
    $VALUES = new DirectExecutor[] { INSTANCE };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\concurrent\futures\DirectExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */