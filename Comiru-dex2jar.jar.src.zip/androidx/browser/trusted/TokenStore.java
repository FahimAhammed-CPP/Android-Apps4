package androidx.browser.trusted;

import androidx.annotation.BinderThread;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;

public interface TokenStore {
  @BinderThread
  @Nullable
  Token load();
  
  @WorkerThread
  void store(@Nullable Token paramToken);
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\browser\trusted\TokenStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */