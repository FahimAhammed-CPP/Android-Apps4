package androidx.browser.trusted;

import android.app.NotificationManager;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public class NotificationApiHelperForM {
  @NonNull
  @RequiresApi(23)
  static Parcelable[] getActiveNotifications(NotificationManager paramNotificationManager) {
    return (Parcelable[])paramNotificationManager.getActiveNotifications();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\browser\trusted\NotificationApiHelperForM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */