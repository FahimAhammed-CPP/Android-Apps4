package androidx.browser.trusted;

import androidx.concurrent.futures.CallbackToFutureAdapter;



/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\browser\trusted\-$$Lambda$ConnectionHolder$AU_vyFTWietXr1KAI5OuiE799PQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */