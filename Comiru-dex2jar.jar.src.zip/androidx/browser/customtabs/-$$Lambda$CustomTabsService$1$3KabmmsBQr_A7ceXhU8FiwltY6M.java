package androidx.browser.customtabs;

import android.os.IBinder;



/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\browser\customtabs\-$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */