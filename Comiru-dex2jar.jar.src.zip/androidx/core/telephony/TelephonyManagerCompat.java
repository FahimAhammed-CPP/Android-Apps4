package androidx.core.telephony;

import android.annotation.SuppressLint;
import android.os.Build;
import android.telephony.TelephonyManager;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TelephonyManagerCompat {
  private static Method sGetDeviceIdMethod;
  
  private static Method sGetSubIdMethod;
  
  @SuppressLint({"MissingPermission"})
  @Nullable
  @RequiresPermission("android.permission.READ_PHONE_STATE")
  public static String getImei(@NonNull TelephonyManager paramTelephonyManager) {
    if (Build.VERSION.SDK_INT >= 26)
      return Api26Impl.getImei(paramTelephonyManager); 
    if (Build.VERSION.SDK_INT >= 22) {
      int i = getSubscriptionId(paramTelephonyManager);
      if (i != Integer.MAX_VALUE && i != -1) {
        i = SubscriptionManagerCompat.getSlotIndex(i);
        if (Build.VERSION.SDK_INT >= 23)
          return Api23Impl.getDeviceId(paramTelephonyManager, i); 
        try {
          if (sGetDeviceIdMethod == null) {
            sGetDeviceIdMethod = TelephonyManager.class.getDeclaredMethod("getDeviceId", new Class[] { int.class });
            sGetDeviceIdMethod.setAccessible(true);
          } 
          return (String)sGetDeviceIdMethod.invoke(paramTelephonyManager, new Object[] { Integer.valueOf(i) });
        } catch (NoSuchMethodException|IllegalAccessException|InvocationTargetException noSuchMethodException) {
          return null;
        } 
      } 
    } 
    return noSuchMethodException.getDeviceId();
  }
  
  @SuppressLint({"SoonBlockedPrivateApi"})
  public static int getSubscriptionId(@NonNull TelephonyManager paramTelephonyManager) {
    if (Build.VERSION.SDK_INT >= 30)
      return Api30Impl.getSubscriptionId(paramTelephonyManager); 
    if (Build.VERSION.SDK_INT >= 22)
      try {
        if (sGetSubIdMethod == null) {
          sGetSubIdMethod = TelephonyManager.class.getDeclaredMethod("getSubId", new Class[0]);
          sGetSubIdMethod.setAccessible(true);
        } 
        Integer integer = (Integer)sGetSubIdMethod.invoke(paramTelephonyManager, new Object[0]);
        if (integer != null && integer.intValue() != -1)
          return integer.intValue(); 
      } catch (InvocationTargetException|IllegalAccessException|NoSuchMethodException invocationTargetException) {} 
    return Integer.MAX_VALUE;
  }
  
  @RequiresApi(23)
  private static class Api23Impl {
    @SuppressLint({"MissingPermission"})
    @DoNotInline
    @Nullable
    @RequiresPermission("android.permission.READ_PHONE_STATE")
    static String getDeviceId(TelephonyManager param1TelephonyManager, int param1Int) {
      return param1TelephonyManager.getDeviceId(param1Int);
    }
  }
  
  @RequiresApi(26)
  private static class Api26Impl {
    @SuppressLint({"MissingPermission"})
    @DoNotInline
    @Nullable
    @RequiresPermission("android.permission.READ_PHONE_STATE")
    static String getImei(TelephonyManager param1TelephonyManager) {
      return param1TelephonyManager.getImei();
    }
  }
  
  @RequiresApi(30)
  private static class Api30Impl {
    @DoNotInline
    static int getSubscriptionId(TelephonyManager param1TelephonyManager) {
      return param1TelephonyManager.getSubscriptionId();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\telephony\TelephonyManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */