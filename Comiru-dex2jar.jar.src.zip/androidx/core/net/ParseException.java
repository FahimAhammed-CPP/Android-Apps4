package androidx.core.net;

import androidx.annotation.NonNull;

public class ParseException extends RuntimeException {
  @NonNull
  public final String response;
  
  ParseException(@NonNull String paramString) {
    super(paramString);
    this.response = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\net\ParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */