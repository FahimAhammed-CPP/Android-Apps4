package androidx.core.location;

import android.content.Context;
import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.annotation.DoNotInline;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import androidx.collection.SimpleArrayMap;
import androidx.core.os.CancellationSignal;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.Consumer;
import androidx.core.util.Preconditions;
import java.lang.reflect.Field;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;

public final class LocationManagerCompat {
  private static final long GET_CURRENT_LOCATION_TIMEOUT_MS = 30000L;
  
  private static final long MAX_CURRENT_LOCATION_AGE_MS = 10000L;
  
  private static final long PRE_N_LOOPER_TIMEOUT_S = 5L;
  
  private static Field sContextField;
  
  @GuardedBy("sGnssStatusListeners")
  private static final SimpleArrayMap<Object, Object> sGnssStatusListeners = new SimpleArrayMap();
  
  @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
  public static void getCurrentLocation(@NonNull LocationManager paramLocationManager, @NonNull String paramString, @Nullable CancellationSignal paramCancellationSignal, @NonNull Executor paramExecutor, @NonNull final Consumer<Location> consumer) {
    if (Build.VERSION.SDK_INT >= 30) {
      Api30Impl.getCurrentLocation(paramLocationManager, paramString, paramCancellationSignal, paramExecutor, consumer);
      return;
    } 
    if (paramCancellationSignal != null)
      paramCancellationSignal.throwIfCanceled(); 
    final Location location = paramLocationManager.getLastKnownLocation(paramString);
    if (location != null && SystemClock.elapsedRealtime() - LocationCompat.getElapsedRealtimeMillis(location) < 10000L) {
      paramExecutor.execute(new Runnable() {
            public void run() {
              consumer.accept(location);
            }
          });
      return;
    } 
    final CancellableLocationListener listener = new CancellableLocationListener(paramLocationManager, paramExecutor, consumer);
    paramLocationManager.requestLocationUpdates(paramString, 0L, 0.0F, cancellableLocationListener, Looper.getMainLooper());
    if (paramCancellationSignal != null)
      paramCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() {
            @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
            public void onCancel() {
              listener.cancel();
            }
          }); 
    cancellableLocationListener.startTimeout(30000L);
  }
  
  @Nullable
  public static String getGnssHardwareModelName(@NonNull LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssHardwareModelName(paramLocationManager) : null;
  }
  
  public static int getGnssYearOfHardware(@NonNull LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssYearOfHardware(paramLocationManager) : 0;
  }
  
  public static boolean isLocationEnabled(@NonNull LocationManager paramLocationManager) {
    if (Build.VERSION.SDK_INT >= 28)
      return Api28Impl.isLocationEnabled(paramLocationManager); 
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i <= 19)
      try {
        if (sContextField == null) {
          sContextField = LocationManager.class.getDeclaredField("mContext");
          sContextField.setAccessible(true);
        } 
        Context context = (Context)sContextField.get(paramLocationManager);
        if (context != null) {
          if (Build.VERSION.SDK_INT == 19) {
            if (Settings.Secure.getInt(context.getContentResolver(), "location_mode", 0) != 0)
              return true; 
          } else {
            boolean bool1 = TextUtils.isEmpty(Settings.Secure.getString(context.getContentResolver(), "location_providers_allowed"));
            return bool1 ^ true;
          } 
          return false;
        } 
      } catch (ClassCastException|SecurityException|NoSuchFieldException|IllegalAccessException classCastException) {} 
    if (paramLocationManager.isProviderEnabled("network") || paramLocationManager.isProviderEnabled("gps"))
      bool = true; 
    return bool;
  }
  
  @RequiresPermission("android.permission.ACCESS_FINE_LOCATION")
  private static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Handler paramHandler, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore #4
    //   5: iconst_1
    //   6: istore #6
    //   8: iconst_1
    //   9: istore #7
    //   11: iconst_1
    //   12: istore #5
    //   14: iload #4
    //   16: bipush #30
    //   18: if_icmplt -> 92
    //   21: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   24: astore #16
    //   26: aload #16
    //   28: monitorenter
    //   29: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   32: aload_3
    //   33: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   39: astore #15
    //   41: aload #15
    //   43: astore_1
    //   44: aload #15
    //   46: ifnonnull -> 58
    //   49: new androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   52: dup
    //   53: aload_3
    //   54: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   57: astore_1
    //   58: aload_0
    //   59: aload_2
    //   60: aload_1
    //   61: invokevirtual registerGnssStatusCallback : (Ljava/util/concurrent/Executor;Landroid/location/GnssStatus$Callback;)Z
    //   64: ifeq -> 81
    //   67: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   70: aload_3
    //   71: aload_1
    //   72: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   75: pop
    //   76: aload #16
    //   78: monitorexit
    //   79: iconst_1
    //   80: ireturn
    //   81: aload #16
    //   83: monitorexit
    //   84: iconst_0
    //   85: ireturn
    //   86: astore_0
    //   87: aload #16
    //   89: monitorexit
    //   90: aload_0
    //   91: athrow
    //   92: getstatic android/os/Build$VERSION.SDK_INT : I
    //   95: bipush #24
    //   97: if_icmplt -> 203
    //   100: aload_1
    //   101: ifnull -> 110
    //   104: iconst_1
    //   105: istore #8
    //   107: goto -> 113
    //   110: iconst_0
    //   111: istore #8
    //   113: iload #8
    //   115: invokestatic checkArgument : (Z)V
    //   118: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   121: astore #16
    //   123: aload #16
    //   125: monitorenter
    //   126: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   129: aload_3
    //   130: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   133: checkcast androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   136: astore #15
    //   138: aload #15
    //   140: ifnonnull -> 156
    //   143: new androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   146: dup
    //   147: aload_3
    //   148: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   151: astore #15
    //   153: goto -> 161
    //   156: aload #15
    //   158: invokevirtual unregister : ()V
    //   161: aload #15
    //   163: aload_2
    //   164: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   167: aload_0
    //   168: aload #15
    //   170: aload_1
    //   171: invokevirtual registerGnssStatusCallback : (Landroid/location/GnssStatus$Callback;Landroid/os/Handler;)Z
    //   174: ifeq -> 192
    //   177: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   180: aload_3
    //   181: aload #15
    //   183: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   186: pop
    //   187: aload #16
    //   189: monitorexit
    //   190: iconst_1
    //   191: ireturn
    //   192: aload #16
    //   194: monitorexit
    //   195: iconst_0
    //   196: ireturn
    //   197: astore_0
    //   198: aload #16
    //   200: monitorexit
    //   201: aload_0
    //   202: athrow
    //   203: aload_1
    //   204: ifnull -> 213
    //   207: iconst_1
    //   208: istore #8
    //   210: goto -> 216
    //   213: iconst_0
    //   214: istore #8
    //   216: iload #8
    //   218: invokestatic checkArgument : (Z)V
    //   221: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   224: astore #16
    //   226: aload #16
    //   228: monitorenter
    //   229: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   232: aload_3
    //   233: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   236: checkcast androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   239: astore #15
    //   241: aload #15
    //   243: ifnonnull -> 260
    //   246: new androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   249: dup
    //   250: aload_0
    //   251: aload_3
    //   252: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   255: astore #15
    //   257: goto -> 265
    //   260: aload #15
    //   262: invokevirtual unregister : ()V
    //   265: aload #15
    //   267: aload_2
    //   268: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   271: new java/util/concurrent/FutureTask
    //   274: dup
    //   275: new androidx/core/location/LocationManagerCompat$3
    //   278: dup
    //   279: aload_0
    //   280: aload #15
    //   282: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/LocationManagerCompat$GpsStatusTransport;)V
    //   285: invokespecial <init> : (Ljava/util/concurrent/Callable;)V
    //   288: astore_0
    //   289: invokestatic myLooper : ()Landroid/os/Looper;
    //   292: aload_1
    //   293: invokevirtual getLooper : ()Landroid/os/Looper;
    //   296: if_acmpne -> 306
    //   299: aload_0
    //   300: invokevirtual run : ()V
    //   303: goto -> 318
    //   306: aload_1
    //   307: aload_0
    //   308: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   311: istore #8
    //   313: iload #8
    //   315: ifeq -> 599
    //   318: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   321: ldc2_w 5
    //   324: invokevirtual toNanos : (J)J
    //   327: lstore #11
    //   329: invokestatic nanoTime : ()J
    //   332: lstore #13
    //   334: iconst_0
    //   335: istore #4
    //   337: lload #11
    //   339: lstore #9
    //   341: aload_0
    //   342: lload #9
    //   344: getstatic java/util/concurrent/TimeUnit.NANOSECONDS : Ljava/util/concurrent/TimeUnit;
    //   347: invokevirtual get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   350: checkcast java/lang/Boolean
    //   353: invokevirtual booleanValue : ()Z
    //   356: ifeq -> 385
    //   359: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   362: aload_3
    //   363: aload #15
    //   365: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   368: pop
    //   369: iload #4
    //   371: ifeq -> 380
    //   374: invokestatic currentThread : ()Ljava/lang/Thread;
    //   377: invokevirtual interrupt : ()V
    //   380: aload #16
    //   382: monitorexit
    //   383: iconst_1
    //   384: ireturn
    //   385: iload #4
    //   387: ifeq -> 396
    //   390: invokestatic currentThread : ()Ljava/lang/Thread;
    //   393: invokevirtual interrupt : ()V
    //   396: aload #16
    //   398: monitorexit
    //   399: iconst_0
    //   400: ireturn
    //   401: astore_0
    //   402: goto -> 586
    //   405: astore_0
    //   406: iload #4
    //   408: istore #5
    //   410: goto -> 469
    //   413: astore_0
    //   414: iload #4
    //   416: istore #5
    //   418: goto -> 520
    //   421: iload #7
    //   423: istore #4
    //   425: invokestatic nanoTime : ()J
    //   428: lstore #9
    //   430: lload #13
    //   432: lload #11
    //   434: ladd
    //   435: lload #9
    //   437: lsub
    //   438: lstore #9
    //   440: iconst_1
    //   441: istore #4
    //   443: goto -> 341
    //   446: astore_0
    //   447: goto -> 469
    //   450: astore_0
    //   451: iload #6
    //   453: istore #5
    //   455: goto -> 520
    //   458: astore_0
    //   459: iconst_0
    //   460: istore #4
    //   462: goto -> 586
    //   465: astore_0
    //   466: iconst_0
    //   467: istore #5
    //   469: iload #5
    //   471: istore #4
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: astore_2
    //   481: iload #5
    //   483: istore #4
    //   485: aload_2
    //   486: aload_1
    //   487: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   490: pop
    //   491: iload #5
    //   493: istore #4
    //   495: aload_2
    //   496: ldc_w ' appears to be blocked, please run registerGnssStatusCallback() directly on a Looper thread or ensure the main Looper is not blocked by this thread'
    //   499: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   502: pop
    //   503: iload #5
    //   505: istore #4
    //   507: new java/lang/IllegalStateException
    //   510: dup
    //   511: aload_2
    //   512: invokevirtual toString : ()Ljava/lang/String;
    //   515: aload_0
    //   516: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   519: athrow
    //   520: iload #5
    //   522: istore #4
    //   524: aload_0
    //   525: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   528: instanceof java/lang/RuntimeException
    //   531: ifne -> 573
    //   534: iload #5
    //   536: istore #4
    //   538: aload_0
    //   539: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   542: instanceof java/lang/Error
    //   545: ifeq -> 560
    //   548: iload #5
    //   550: istore #4
    //   552: aload_0
    //   553: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   556: checkcast java/lang/Error
    //   559: athrow
    //   560: iload #5
    //   562: istore #4
    //   564: new java/lang/IllegalStateException
    //   567: dup
    //   568: aload_0
    //   569: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   572: athrow
    //   573: iload #5
    //   575: istore #4
    //   577: aload_0
    //   578: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   581: checkcast java/lang/RuntimeException
    //   584: athrow
    //   585: astore_0
    //   586: iload #4
    //   588: ifeq -> 597
    //   591: invokestatic currentThread : ()Ljava/lang/Thread;
    //   594: invokevirtual interrupt : ()V
    //   597: aload_0
    //   598: athrow
    //   599: new java/lang/StringBuilder
    //   602: dup
    //   603: invokespecial <init> : ()V
    //   606: astore_0
    //   607: aload_0
    //   608: aload_1
    //   609: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   612: pop
    //   613: aload_0
    //   614: ldc_w ' is shutting down'
    //   617: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   620: pop
    //   621: new java/lang/IllegalStateException
    //   624: dup
    //   625: aload_0
    //   626: invokevirtual toString : ()Ljava/lang/String;
    //   629: invokespecial <init> : (Ljava/lang/String;)V
    //   632: athrow
    //   633: astore_0
    //   634: aload #16
    //   636: monitorexit
    //   637: aload_0
    //   638: athrow
    //   639: astore_2
    //   640: goto -> 421
    //   643: astore_0
    //   644: iconst_0
    //   645: istore #5
    //   647: goto -> 520
    // Exception table:
    //   from	to	target	type
    //   29	41	86	finally
    //   49	58	86	finally
    //   58	79	86	finally
    //   81	84	86	finally
    //   87	90	86	finally
    //   126	138	197	finally
    //   143	153	197	finally
    //   156	161	197	finally
    //   161	190	197	finally
    //   192	195	197	finally
    //   198	201	197	finally
    //   229	241	633	finally
    //   246	257	633	finally
    //   260	265	633	finally
    //   265	303	633	finally
    //   306	313	633	finally
    //   318	334	643	java/util/concurrent/ExecutionException
    //   318	334	465	java/util/concurrent/TimeoutException
    //   318	334	458	finally
    //   341	369	639	java/lang/InterruptedException
    //   341	369	413	java/util/concurrent/ExecutionException
    //   341	369	405	java/util/concurrent/TimeoutException
    //   341	369	401	finally
    //   374	380	633	finally
    //   380	383	633	finally
    //   390	396	633	finally
    //   396	399	633	finally
    //   425	430	450	java/util/concurrent/ExecutionException
    //   425	430	446	java/util/concurrent/TimeoutException
    //   425	430	585	finally
    //   473	481	585	finally
    //   485	491	585	finally
    //   495	503	585	finally
    //   507	520	585	finally
    //   524	534	585	finally
    //   538	548	585	finally
    //   552	560	585	finally
    //   564	573	585	finally
    //   577	585	585	finally
    //   591	597	633	finally
    //   597	599	633	finally
    //   599	633	633	finally
    //   634	637	633	finally
  }
  
  @RequiresPermission("android.permission.ACCESS_FINE_LOCATION")
  public static boolean registerGnssStatusCallback(@NonNull LocationManager paramLocationManager, @NonNull GnssStatusCompat.Callback paramCallback, @NonNull Handler paramHandler) {
    return (Build.VERSION.SDK_INT >= 30) ? registerGnssStatusCallback(paramLocationManager, ExecutorCompat.create(paramHandler), paramCallback) : registerGnssStatusCallback(paramLocationManager, new InlineHandlerExecutor(paramHandler), paramCallback);
  }
  
  @RequiresPermission("android.permission.ACCESS_FINE_LOCATION")
  public static boolean registerGnssStatusCallback(@NonNull LocationManager paramLocationManager, @NonNull Executor paramExecutor, @NonNull GnssStatusCompat.Callback paramCallback) {
    if (Build.VERSION.SDK_INT >= 30)
      return registerGnssStatusCallback(paramLocationManager, null, paramExecutor, paramCallback); 
    Looper looper2 = Looper.myLooper();
    Looper looper1 = looper2;
    if (looper2 == null)
      looper1 = Looper.getMainLooper(); 
    return registerGnssStatusCallback(paramLocationManager, new Handler(looper1), paramExecutor, paramCallback);
  }
  
  public static void unregisterGnssStatusCallback(@NonNull LocationManager paramLocationManager, @NonNull GnssStatusCompat.Callback paramCallback) {
    GnssStatusTransport gnssStatusTransport;
    PreRGnssStatusTransport preRGnssStatusTransport;
    if (Build.VERSION.SDK_INT >= 30)
      synchronized (sGnssStatusListeners) {
        gnssStatusTransport = (GnssStatusTransport)sGnssStatusListeners.remove(paramCallback);
        if (gnssStatusTransport != null)
          paramLocationManager.unregisterGnssStatusCallback(gnssStatusTransport); 
        return;
      }  
    if (Build.VERSION.SDK_INT >= 24)
      synchronized (sGnssStatusListeners) {
        preRGnssStatusTransport = (PreRGnssStatusTransport)sGnssStatusListeners.remove(gnssStatusTransport);
        if (preRGnssStatusTransport != null) {
          preRGnssStatusTransport.unregister();
          paramLocationManager.unregisterGnssStatusCallback(preRGnssStatusTransport);
        } 
        return;
      }  
    synchronized (sGnssStatusListeners) {
      GpsStatusTransport gpsStatusTransport = (GpsStatusTransport)sGnssStatusListeners.remove(preRGnssStatusTransport);
      if (gpsStatusTransport != null) {
        gpsStatusTransport.unregister();
        paramLocationManager.removeGpsStatusListener(gpsStatusTransport);
      } 
      return;
    } 
  }
  
  @RequiresApi(28)
  private static class Api28Impl {
    @DoNotInline
    static String getGnssHardwareModelName(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssHardwareModelName();
    }
    
    @DoNotInline
    static int getGnssYearOfHardware(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssYearOfHardware();
    }
    
    @DoNotInline
    static boolean isLocationEnabled(LocationManager param1LocationManager) {
      return param1LocationManager.isLocationEnabled();
    }
  }
  
  @RequiresApi(30)
  private static class Api30Impl {
    @DoNotInline
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    static void getCurrentLocation(LocationManager param1LocationManager, @NonNull String param1String, @Nullable CancellationSignal param1CancellationSignal, @NonNull Executor param1Executor, @NonNull final Consumer<Location> consumer) {
      if (param1CancellationSignal != null) {
        CancellationSignal cancellationSignal = (CancellationSignal)param1CancellationSignal.getCancellationSignalObject();
      } else {
        param1CancellationSignal = null;
      } 
      param1LocationManager.getCurrentLocation(param1String, (CancellationSignal)param1CancellationSignal, param1Executor, new Consumer<Location>() {
            public void accept(Location param2Location) {
              consumer.accept(param2Location);
            }
          });
    }
  }
  
  class null implements Consumer<Location> {
    public void accept(Location param1Location) {
      consumer.accept(param1Location);
    }
  }
  
  private static final class CancellableLocationListener implements LocationListener {
    private Consumer<Location> mConsumer;
    
    private final Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    private final Handler mTimeoutHandler;
    
    @Nullable
    Runnable mTimeoutRunnable;
    
    @GuardedBy("this")
    private boolean mTriggered;
    
    CancellableLocationListener(LocationManager param1LocationManager, Executor param1Executor, Consumer<Location> param1Consumer) {
      this.mLocationManager = param1LocationManager;
      this.mExecutor = param1Executor;
      this.mTimeoutHandler = new Handler(Looper.getMainLooper());
      this.mConsumer = param1Consumer;
    }
    
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    private void cleanup() {
      this.mConsumer = null;
      this.mLocationManager.removeUpdates(this);
      Runnable runnable = this.mTimeoutRunnable;
      if (runnable != null) {
        this.mTimeoutHandler.removeCallbacks(runnable);
        this.mTimeoutRunnable = null;
      } 
    }
    
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    public void cancel() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: invokespecial cleanup : ()V
      //   23: return
      //   24: astore_1
      //   25: aload_0
      //   26: monitorexit
      //   27: aload_1
      //   28: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	24	finally
      //   12	19	24	finally
      //   25	27	24	finally
    }
    
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    public void onLocationChanged(@Nullable Location param1Location) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: getfield mConsumer : Landroidx/core/util/Consumer;
      //   23: astore_2
      //   24: aload_0
      //   25: getfield mExecutor : Ljava/util/concurrent/Executor;
      //   28: new androidx/core/location/LocationManagerCompat$CancellableLocationListener$2
      //   31: dup
      //   32: aload_0
      //   33: aload_2
      //   34: aload_1
      //   35: invokespecial <init> : (Landroidx/core/location/LocationManagerCompat$CancellableLocationListener;Landroidx/core/util/Consumer;Landroid/location/Location;)V
      //   38: invokeinterface execute : (Ljava/lang/Runnable;)V
      //   43: aload_0
      //   44: invokespecial cleanup : ()V
      //   47: return
      //   48: astore_1
      //   49: aload_0
      //   50: monitorexit
      //   51: aload_1
      //   52: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	48	finally
      //   12	19	48	finally
      //   49	51	48	finally
    }
    
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    public void onProviderDisabled(@NonNull String param1String) {
      onLocationChanged((Location)null);
    }
    
    public void onProviderEnabled(@NonNull String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
    
    public void startTimeout(long param1Long) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: new androidx/core/location/LocationManagerCompat$CancellableLocationListener$1
      //   16: dup
      //   17: aload_0
      //   18: invokespecial <init> : (Landroidx/core/location/LocationManagerCompat$CancellableLocationListener;)V
      //   21: putfield mTimeoutRunnable : Ljava/lang/Runnable;
      //   24: aload_0
      //   25: getfield mTimeoutHandler : Landroid/os/Handler;
      //   28: aload_0
      //   29: getfield mTimeoutRunnable : Ljava/lang/Runnable;
      //   32: lload_1
      //   33: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
      //   36: pop
      //   37: aload_0
      //   38: monitorexit
      //   39: return
      //   40: astore_3
      //   41: aload_0
      //   42: monitorexit
      //   43: aload_3
      //   44: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	40	finally
      //   12	39	40	finally
      //   41	43	40	finally
    }
  }
  
  class null implements Runnable {
    @RequiresPermission(anyOf = {"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"})
    public void run() {
      LocationManagerCompat.CancellableLocationListener cancellableLocationListener = this.this$0;
      cancellableLocationListener.mTimeoutRunnable = null;
      cancellableLocationListener.onLocationChanged((Location)null);
    }
  }
  
  class null implements Runnable {
    public void run() {
      consumer.accept(location);
    }
  }
  
  @RequiresApi(30)
  private static class GnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    GnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(int param1Int) {
      this.mCallback.onFirstFix(param1Int);
    }
    
    public void onSatelliteStatusChanged(GnssStatus param1GnssStatus) {
      this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(param1GnssStatus));
    }
    
    public void onStarted() {
      this.mCallback.onStarted();
    }
    
    public void onStopped() {
      this.mCallback.onStopped();
    }
  }
  
  private static class GpsStatusTransport implements GpsStatus.Listener {
    final GnssStatusCompat.Callback mCallback;
    
    @Nullable
    volatile Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    GpsStatusTransport(LocationManager param1LocationManager, GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mLocationManager = param1LocationManager;
      this.mCallback = param1Callback;
    }
    
    @RequiresPermission("android.permission.ACCESS_FINE_LOCATION")
    public void onGpsStatusChanged(int param1Int) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4)
              return; 
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onSatelliteStatusChanged(gnssStatus);
                    }
                  });
              return;
            } 
          } else {
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onFirstFix(ttff);
                    }
                  });
              return;
            } 
          } 
        } else {
          executor.execute(new Runnable() {
                public void run() {
                  if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                    return; 
                  LocationManagerCompat.GpsStatusTransport.this.mCallback.onStopped();
                }
              });
          return;
        } 
      } else {
        executor.execute(new Runnable() {
              public void run() {
                if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                  return; 
                LocationManagerCompat.GpsStatusTransport.this.mCallback.onStarted();
              }
            });
      } 
    }
    
    public void register(Executor param1Executor) {
      boolean bool;
      if (this.mExecutor == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttff);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(gnssStatus);
    }
  }
  
  private static final class InlineHandlerExecutor implements Executor {
    private final Handler mHandler;
    
    InlineHandlerExecutor(@NonNull Handler param1Handler) {
      this.mHandler = (Handler)Preconditions.checkNotNull(param1Handler);
    }
    
    public void execute(@NonNull Runnable param1Runnable) {
      if (Looper.myLooper() == this.mHandler.getLooper()) {
        param1Runnable.run();
        return;
      } 
      if (this.mHandler.post((Runnable)Preconditions.checkNotNull(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mHandler);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
  
  @RequiresApi(24)
  private static class PreRGnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    @Nullable
    volatile Executor mExecutor;
    
    PreRGnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(final int ttffMillis) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onFirstFix(ttffMillis);
            }
          });
    }
    
    public void onSatelliteStatusChanged(final GnssStatus status) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
            }
          });
    }
    
    public void onStarted() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStarted();
            }
          });
    }
    
    public void onStopped() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStopped();
            }
          });
    }
    
    public void register(Executor param1Executor) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Executor != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Preconditions.checkArgument(bool1, "invalid null executor");
      if (this.mExecutor == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Preconditions.checkState(bool1);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttffMillis);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\location\LocationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */