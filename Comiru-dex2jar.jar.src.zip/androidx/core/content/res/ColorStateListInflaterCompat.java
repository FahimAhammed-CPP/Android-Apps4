package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.StateSet;
import android.util.TypedValue;
import android.util.Xml;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.FloatRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.XmlRes;
import androidx.core.R;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public final class ColorStateListInflaterCompat {
  private static final ThreadLocal<TypedValue> sTempTypedValue = new ThreadLocal<TypedValue>();
  
  @NonNull
  public static ColorStateList createFromXml(@NonNull Resources paramResources, @NonNull XmlPullParser paramXmlPullParser, @Nullable Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return createFromXmlInner(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  @NonNull
  public static ColorStateList createFromXmlInner(@NonNull Resources paramResources, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  @NonNull
  private static TypedValue getTypedValue() {
    TypedValue typedValue2 = sTempTypedValue.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      sTempTypedValue.set(typedValue1);
    } 
    return typedValue1;
  }
  
  @Nullable
  public static ColorStateList inflate(@NonNull Resources paramResources, @XmlRes int paramInt, @Nullable Resources.Theme paramTheme) {
    try {
      return createFromXml(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  private static ColorStateList inflate(@NonNull Resources paramResources, @NonNull XmlPullParser paramXmlPullParser, @NonNull AttributeSet paramAttributeSet, @Nullable Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int j = paramXmlPullParser.getDepth() + 1;
    int[][] arrayOfInt = new int[20][];
    int[] arrayOfInt1 = new int[arrayOfInt.length];
    int i = 0;
    while (true) {
      int k = paramXmlPullParser.next();
      if (k != 1) {
        int m = paramXmlPullParser.getDepth();
        if (m >= j || k != 3) {
          int[][] arrayOfInt5 = arrayOfInt;
          int[] arrayOfInt4 = arrayOfInt1;
          int n = i;
          if (k == 2) {
            arrayOfInt5 = arrayOfInt;
            arrayOfInt4 = arrayOfInt1;
            n = i;
            if (m <= j)
              if (!paramXmlPullParser.getName().equals("item")) {
                arrayOfInt5 = arrayOfInt;
                arrayOfInt4 = arrayOfInt1;
                n = i;
              } else {
                TypedArray typedArray = obtainAttributes(paramResources, paramTheme, paramAttributeSet, R.styleable.ColorStateListItem);
                n = typedArray.getResourceId(R.styleable.ColorStateListItem_android_color, -1);
                if (n != -1 && !isColorInt(paramResources, n)) {
                  try {
                    n = createFromXml(paramResources, (XmlPullParser)paramResources.getXml(n), paramTheme).getDefaultColor();
                  } catch (Exception exception) {
                    n = typedArray.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                  } 
                } else {
                  n = typedArray.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                } 
                float f = 1.0F;
                if (typedArray.hasValue(R.styleable.ColorStateListItem_android_alpha)) {
                  f = typedArray.getFloat(R.styleable.ColorStateListItem_android_alpha, 1.0F);
                } else if (typedArray.hasValue(R.styleable.ColorStateListItem_alpha)) {
                  f = typedArray.getFloat(R.styleable.ColorStateListItem_alpha, 1.0F);
                } 
                typedArray.recycle();
                int i1 = paramAttributeSet.getAttributeCount();
                arrayOfInt4 = new int[i1];
                k = 0;
                for (m = 0; k < i1; m = i2) {
                  int i3 = paramAttributeSet.getAttributeNameResource(k);
                  int i2 = m;
                  if (i3 != 16843173) {
                    i2 = m;
                    if (i3 != 16843551) {
                      i2 = m;
                      if (i3 != R.attr.alpha) {
                        if (paramAttributeSet.getAttributeBooleanValue(k, false)) {
                          i2 = i3;
                        } else {
                          i2 = -i3;
                        } 
                        arrayOfInt4[m] = i2;
                        i2 = m + 1;
                      } 
                    } 
                  } 
                  k++;
                } 
                int[] arrayOfInt6 = StateSet.trimStateSet(arrayOfInt4, m);
                arrayOfInt4 = GrowingArrayUtils.append(arrayOfInt1, i, modulateColorAlpha(n, f));
                arrayOfInt5 = GrowingArrayUtils.<int[]>append(arrayOfInt, i, arrayOfInt6);
                n = i + 1;
              }  
          } 
          arrayOfInt = arrayOfInt5;
          arrayOfInt1 = arrayOfInt4;
          i = n;
          continue;
        } 
      } 
      int[] arrayOfInt2 = new int[i];
      int[][] arrayOfInt3 = new int[i][];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
      System.arraycopy(arrayOfInt, 0, arrayOfInt3, 0, i);
      return new ColorStateList(arrayOfInt3, arrayOfInt2);
    } 
  }
  
  private static boolean isColorInt(@NonNull Resources paramResources, @ColorRes int paramInt) {
    TypedValue typedValue = getTypedValue();
    paramResources.getValue(paramInt, typedValue, true);
    return (typedValue.type >= 28 && typedValue.type <= 31);
  }
  
  @ColorInt
  private static int modulateColorAlpha(@ColorInt int paramInt, @FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    return paramInt & 0xFFFFFF | Math.round(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  private static TypedArray obtainAttributes(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\content\res\ColorStateListInflaterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */