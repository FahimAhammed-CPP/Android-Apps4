package androidx.core.content.pm;

import androidx.annotation.AnyThread;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import java.util.List;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public abstract class ShortcutInfoChangeListener {
  @AnyThread
  public void onAllShortcutsRemoved() {}
  
  @AnyThread
  public void onShortcutAdded(@NonNull List<ShortcutInfoCompat> paramList) {}
  
  @AnyThread
  public void onShortcutRemoved(@NonNull List<String> paramList) {}
  
  @AnyThread
  public void onShortcutUpdated(@NonNull List<ShortcutInfoCompat> paramList) {}
  
  @AnyThread
  public void onShortcutUsageReported(@NonNull List<String> paramList) {}
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\content\pm\ShortcutInfoChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */