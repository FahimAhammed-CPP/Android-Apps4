package androidx.core.provider;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;

class CalleeHandler {
  @NonNull
  static Handler create() {
    return (Looper.myLooper() == null) ? new Handler(Looper.getMainLooper()) : new Handler();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\provider\CalleeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */