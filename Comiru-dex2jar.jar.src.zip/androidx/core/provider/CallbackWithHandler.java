package androidx.core.provider;

import android.graphics.Typeface;
import android.os.Handler;
import androidx.annotation.NonNull;

class CallbackWithHandler {
  @NonNull
  private final FontsContractCompat.FontRequestCallback mCallback;
  
  @NonNull
  private final Handler mCallbackHandler;
  
  CallbackWithHandler(@NonNull FontsContractCompat.FontRequestCallback paramFontRequestCallback) {
    this.mCallback = paramFontRequestCallback;
    this.mCallbackHandler = CalleeHandler.create();
  }
  
  CallbackWithHandler(@NonNull FontsContractCompat.FontRequestCallback paramFontRequestCallback, @NonNull Handler paramHandler) {
    this.mCallback = paramFontRequestCallback;
    this.mCallbackHandler = paramHandler;
  }
  
  private void onTypefaceRequestFailed(final int reason) {
    final FontsContractCompat.FontRequestCallback callback = this.mCallback;
    this.mCallbackHandler.post(new Runnable() {
          public void run() {
            callback.onTypefaceRequestFailed(reason);
          }
        });
  }
  
  private void onTypefaceRetrieved(@NonNull final Typeface typeface) {
    final FontsContractCompat.FontRequestCallback callback = this.mCallback;
    this.mCallbackHandler.post(new Runnable() {
          public void run() {
            callback.onTypefaceRetrieved(typeface);
          }
        });
  }
  
  void onTypefaceResult(@NonNull FontRequestWorker.TypefaceResult paramTypefaceResult) {
    if (paramTypefaceResult.isSuccess()) {
      onTypefaceRetrieved(paramTypefaceResult.mTypeface);
      return;
    } 
    onTypefaceRequestFailed(paramTypefaceResult.mResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\provider\CallbackWithHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */