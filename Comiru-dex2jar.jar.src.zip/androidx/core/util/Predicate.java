package androidx.core.util;

import android.annotation.SuppressLint;

public interface Predicate<T> {
  @SuppressLint({"UnknownNullness"})
  boolean test(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\cor\\util\Predicate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */