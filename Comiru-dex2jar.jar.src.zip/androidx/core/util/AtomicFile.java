package androidx.core.util;

import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class AtomicFile {
  private static final String LOG_TAG = "AtomicFile";
  
  private final File mBaseName;
  
  private final File mLegacyBackupName;
  
  private final File mNewName;
  
  public AtomicFile(@NonNull File paramFile) {
    this.mBaseName = paramFile;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramFile.getPath());
    stringBuilder.append(".new");
    this.mNewName = new File(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append(paramFile.getPath());
    stringBuilder.append(".bak");
    this.mLegacyBackupName = new File(stringBuilder.toString());
  }
  
  private static void rename(@NonNull File paramFile1, @NonNull File paramFile2) {
    if (paramFile2.isDirectory() && !paramFile2.delete()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to delete file which is a directory ");
      stringBuilder.append(paramFile2);
      Log.e("AtomicFile", stringBuilder.toString());
    } 
    if (!paramFile1.renameTo(paramFile2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to rename ");
      stringBuilder.append(paramFile1);
      stringBuilder.append(" to ");
      stringBuilder.append(paramFile2);
      Log.e("AtomicFile", stringBuilder.toString());
    } 
  }
  
  private static boolean sync(@NonNull FileOutputStream paramFileOutputStream) {
    try {
      paramFileOutputStream.getFD().sync();
      return true;
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public void delete() {
    this.mBaseName.delete();
    this.mNewName.delete();
    this.mLegacyBackupName.delete();
  }
  
  public void failWrite(@Nullable FileOutputStream paramFileOutputStream) {
    if (paramFileOutputStream == null)
      return; 
    if (!sync(paramFileOutputStream))
      Log.e("AtomicFile", "Failed to sync file output stream"); 
    try {
      paramFileOutputStream.close();
    } catch (IOException iOException) {
      Log.e("AtomicFile", "Failed to close file output stream", iOException);
    } 
    if (!this.mNewName.delete()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to delete new file ");
      stringBuilder.append(this.mNewName);
      Log.e("AtomicFile", stringBuilder.toString());
    } 
  }
  
  public void finishWrite(@Nullable FileOutputStream paramFileOutputStream) {
    if (paramFileOutputStream == null)
      return; 
    if (!sync(paramFileOutputStream))
      Log.e("AtomicFile", "Failed to sync file output stream"); 
    try {
      paramFileOutputStream.close();
    } catch (IOException iOException) {
      Log.e("AtomicFile", "Failed to close file output stream", iOException);
    } 
    rename(this.mNewName, this.mBaseName);
  }
  
  @NonNull
  public File getBaseFile() {
    return this.mBaseName;
  }
  
  @NonNull
  public FileInputStream openRead() throws FileNotFoundException {
    if (this.mLegacyBackupName.exists())
      rename(this.mLegacyBackupName, this.mBaseName); 
    if (this.mNewName.exists() && this.mBaseName.exists() && !this.mNewName.delete()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to delete outdated new file ");
      stringBuilder.append(this.mNewName);
      Log.e("AtomicFile", stringBuilder.toString());
    } 
    return new FileInputStream(this.mBaseName);
  }
  
  @NonNull
  public byte[] readFully() throws IOException {
    FileInputStream fileInputStream = openRead();
    try {
      byte[] arrayOfByte = new byte[fileInputStream.available()];
      int i = 0;
      while (true) {
        int j = fileInputStream.read(arrayOfByte, i, arrayOfByte.length - i);
        if (j <= 0)
          return arrayOfByte; 
        j = i + j;
        int k = fileInputStream.available();
        i = j;
        if (k > arrayOfByte.length - j) {
          byte[] arrayOfByte1 = new byte[k + j];
          System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, j);
          arrayOfByte = arrayOfByte1;
          i = j;
        } 
      } 
    } finally {
      fileInputStream.close();
    } 
  }
  
  @NonNull
  public FileOutputStream startWrite() throws IOException {
    if (this.mLegacyBackupName.exists())
      rename(this.mLegacyBackupName, this.mBaseName); 
    try {
      return new FileOutputStream(this.mNewName);
    } catch (FileNotFoundException fileNotFoundException) {
      if (this.mNewName.getParentFile().mkdirs())
        try {
          return new FileOutputStream(this.mNewName);
        } catch (FileNotFoundException fileNotFoundException1) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failed to create new file ");
          stringBuilder1.append(this.mNewName);
          throw new IOException(stringBuilder1.toString(), fileNotFoundException1);
        }  
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to create directory for ");
      stringBuilder.append(this.mNewName);
      throw new IOException(stringBuilder.toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\cor\\util\AtomicFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */