package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.provider.FontsContractCompat;
import java.io.IOException;
import java.io.InputStream;

@RequiresApi(29)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatApi29Impl extends TypefaceCompatBaseImpl {
  @Nullable
  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt) {
    int i;
    boolean bool2;
    try {
      FontResourcesParserCompat.FontFileResourceEntry[] arrayOfFontFileResourceEntry = paramFontFamilyFilesResourceEntry.getEntries();
      int j = arrayOfFontFileResourceEntry.length;
      bool2 = false;
      paramContext = null;
      i = 0;
      while (true) {
        FontFamily.Builder builder;
        boolean bool = true;
        if (i < j) {
          FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = arrayOfFontFileResourceEntry[i];
          try {
            FontFamily.Builder builder1;
            Font.Builder builder2 = (new Font.Builder(paramResources, fontFileResourceEntry.getResourceId())).setWeight(fontFileResourceEntry.getWeight());
            if (!fontFileResourceEntry.isItalic())
              bool = false; 
            Font font = builder2.setSlant(bool).setTtcIndex(fontFileResourceEntry.getTtcIndex()).setFontVariationSettings(fontFileResourceEntry.getVariationSettings()).build();
            if (paramContext == null) {
              builder1 = new FontFamily.Builder(font);
              builder = builder1;
            } else {
              builder.addFont((Font)builder1);
            } 
          } catch (IOException iOException) {}
          i++;
          continue;
        } 
        if (builder == null)
          return null; 
        if ((paramInt & 0x1) != 0) {
          i = 700;
          break;
        } 
        i = 400;
        break;
      } 
    } catch (Exception exception) {
      return null;
    } 
    boolean bool1 = bool2;
    if ((paramInt & 0x2) != 0)
      bool1 = true; 
    FontStyle fontStyle = new FontStyle(i, bool1);
    return (new Typeface.CustomFallbackBuilder(exception.build())).setStyle(fontStyle).build();
  }
  
  @Nullable
  public Typeface createFromFontInfo(Context paramContext, @Nullable CancellationSignal paramCancellationSignal, @NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: astore #11
    //   6: aload_3
    //   7: arraylength
    //   8: istore #8
    //   10: iconst_0
    //   11: istore #7
    //   13: aconst_null
    //   14: astore_1
    //   15: iconst_0
    //   16: istore #5
    //   18: iconst_1
    //   19: istore #6
    //   21: iload #5
    //   23: iload #8
    //   25: if_icmpge -> 231
    //   28: aload_3
    //   29: iload #5
    //   31: aaload
    //   32: astore #10
    //   34: aload_1
    //   35: astore #9
    //   37: aload #11
    //   39: aload #10
    //   41: invokevirtual getUri : ()Landroid/net/Uri;
    //   44: ldc 'r'
    //   46: aload_2
    //   47: invokevirtual openFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   50: astore #12
    //   52: aload #12
    //   54: ifnonnull -> 79
    //   57: aload_1
    //   58: astore #9
    //   60: aload #12
    //   62: ifnull -> 219
    //   65: aload_1
    //   66: astore #9
    //   68: aload #12
    //   70: invokevirtual close : ()V
    //   73: aload_1
    //   74: astore #9
    //   76: goto -> 219
    //   79: aload_1
    //   80: astore #9
    //   82: new android/graphics/fonts/Font$Builder
    //   85: dup
    //   86: aload #12
    //   88: invokespecial <init> : (Landroid/os/ParcelFileDescriptor;)V
    //   91: aload #10
    //   93: invokevirtual getWeight : ()I
    //   96: invokevirtual setWeight : (I)Landroid/graphics/fonts/Font$Builder;
    //   99: astore #13
    //   101: aload_1
    //   102: astore #9
    //   104: aload #10
    //   106: invokevirtual isItalic : ()Z
    //   109: ifeq -> 292
    //   112: goto -> 115
    //   115: aload_1
    //   116: astore #9
    //   118: aload #13
    //   120: iload #6
    //   122: invokevirtual setSlant : (I)Landroid/graphics/fonts/Font$Builder;
    //   125: aload #10
    //   127: invokevirtual getTtcIndex : ()I
    //   130: invokevirtual setTtcIndex : (I)Landroid/graphics/fonts/Font$Builder;
    //   133: invokevirtual build : ()Landroid/graphics/fonts/Font;
    //   136: astore #10
    //   138: aload_1
    //   139: ifnonnull -> 162
    //   142: aload_1
    //   143: astore #9
    //   145: new android/graphics/fonts/FontFamily$Builder
    //   148: dup
    //   149: aload #10
    //   151: invokespecial <init> : (Landroid/graphics/fonts/Font;)V
    //   154: astore #10
    //   156: aload #10
    //   158: astore_1
    //   159: goto -> 172
    //   162: aload_1
    //   163: astore #9
    //   165: aload_1
    //   166: aload #10
    //   168: invokevirtual addFont : (Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/FontFamily$Builder;
    //   171: pop
    //   172: aload_1
    //   173: astore #9
    //   175: aload #12
    //   177: ifnull -> 219
    //   180: goto -> 65
    //   183: astore #10
    //   185: aload #12
    //   187: ifnull -> 213
    //   190: aload_1
    //   191: astore #9
    //   193: aload #12
    //   195: invokevirtual close : ()V
    //   198: goto -> 213
    //   201: astore #12
    //   203: aload_1
    //   204: astore #9
    //   206: aload #10
    //   208: aload #12
    //   210: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   213: aload_1
    //   214: astore #9
    //   216: aload #10
    //   218: athrow
    //   219: iload #5
    //   221: iconst_1
    //   222: iadd
    //   223: istore #5
    //   225: aload #9
    //   227: astore_1
    //   228: goto -> 18
    //   231: aload_1
    //   232: ifnonnull -> 237
    //   235: aconst_null
    //   236: areturn
    //   237: iload #4
    //   239: iconst_1
    //   240: iand
    //   241: ifeq -> 298
    //   244: sipush #700
    //   247: istore #5
    //   249: goto -> 303
    //   252: new android/graphics/fonts/FontStyle
    //   255: dup
    //   256: iload #5
    //   258: iload #6
    //   260: invokespecial <init> : (II)V
    //   263: astore_2
    //   264: new android/graphics/Typeface$CustomFallbackBuilder
    //   267: dup
    //   268: aload_1
    //   269: invokevirtual build : ()Landroid/graphics/fonts/FontFamily;
    //   272: invokespecial <init> : (Landroid/graphics/fonts/FontFamily;)V
    //   275: aload_2
    //   276: invokevirtual setStyle : (Landroid/graphics/fonts/FontStyle;)Landroid/graphics/Typeface$CustomFallbackBuilder;
    //   279: invokevirtual build : ()Landroid/graphics/Typeface;
    //   282: astore_1
    //   283: aload_1
    //   284: areturn
    //   285: astore_1
    //   286: aconst_null
    //   287: areturn
    //   288: astore_1
    //   289: goto -> 219
    //   292: iconst_0
    //   293: istore #6
    //   295: goto -> 115
    //   298: sipush #400
    //   301: istore #5
    //   303: iload #7
    //   305: istore #6
    //   307: iload #4
    //   309: iconst_2
    //   310: iand
    //   311: ifeq -> 252
    //   314: iconst_1
    //   315: istore #6
    //   317: goto -> 252
    // Exception table:
    //   from	to	target	type
    //   6	10	285	java/lang/Exception
    //   37	52	288	java/io/IOException
    //   37	52	285	java/lang/Exception
    //   68	73	288	java/io/IOException
    //   68	73	285	java/lang/Exception
    //   82	101	183	java/lang/Throwable
    //   82	101	288	java/io/IOException
    //   82	101	285	java/lang/Exception
    //   104	112	183	java/lang/Throwable
    //   104	112	288	java/io/IOException
    //   104	112	285	java/lang/Exception
    //   118	138	183	java/lang/Throwable
    //   118	138	288	java/io/IOException
    //   118	138	285	java/lang/Exception
    //   145	156	183	java/lang/Throwable
    //   145	156	288	java/io/IOException
    //   145	156	285	java/lang/Exception
    //   165	172	183	java/lang/Throwable
    //   165	172	288	java/io/IOException
    //   165	172	285	java/lang/Exception
    //   193	198	201	java/lang/Throwable
    //   193	198	288	java/io/IOException
    //   193	198	285	java/lang/Exception
    //   206	213	288	java/io/IOException
    //   206	213	285	java/lang/Exception
    //   216	219	288	java/io/IOException
    //   216	219	285	java/lang/Exception
    //   252	283	285	java/lang/Exception
  }
  
  protected Typeface createFromInputStream(Context paramContext, InputStream paramInputStream) {
    throw new RuntimeException("Do not use this function in API 29 or later.");
  }
  
  @Nullable
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    try {
      Font font = (new Font.Builder(paramResources, paramInt1)).build();
      return (new Typeface.CustomFallbackBuilder((new FontFamily.Builder(font)).build())).setStyle(font.getStyle()).build();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    throw new RuntimeException("Do not use this function in API 29 or later.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\graphics\TypefaceCompatApi29Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */