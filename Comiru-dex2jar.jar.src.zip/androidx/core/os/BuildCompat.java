package androidx.core.os;

import android.os.Build;
import androidx.annotation.ChecksSdkIntAtLeast;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresOptIn;
import androidx.annotation.RestrictTo;

public class BuildCompat {
  @Deprecated
  @ChecksSdkIntAtLeast(api = 24)
  public static boolean isAtLeastN() {
    return (Build.VERSION.SDK_INT >= 24);
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 25)
  public static boolean isAtLeastNMR1() {
    return (Build.VERSION.SDK_INT >= 25);
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 26)
  public static boolean isAtLeastO() {
    return (Build.VERSION.SDK_INT >= 26);
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 27)
  public static boolean isAtLeastOMR1() {
    return (Build.VERSION.SDK_INT >= 27);
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 28)
  public static boolean isAtLeastP() {
    return (Build.VERSION.SDK_INT >= 28);
  }
  
  @RestrictTo({RestrictTo.Scope.TESTS})
  protected static boolean isAtLeastPreReleaseCodename(@NonNull String paramString1, @NonNull String paramString2) {
    boolean bool1 = "REL".equals(paramString2);
    boolean bool = false;
    if (bool1)
      return false; 
    if (paramString2.compareTo(paramString1) >= 0)
      bool = true; 
    return bool;
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 29)
  public static boolean isAtLeastQ() {
    return (Build.VERSION.SDK_INT >= 29);
  }
  
  @Deprecated
  @ChecksSdkIntAtLeast(api = 30)
  public static boolean isAtLeastR() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  @ChecksSdkIntAtLeast(api = 31, codename = "S")
  public static boolean isAtLeastS() {
    return (Build.VERSION.SDK_INT >= 31 || isAtLeastPreReleaseCodename("S", Build.VERSION.CODENAME));
  }
  
  @ChecksSdkIntAtLeast(codename = "T")
  @PrereleaseSdkCheck
  public static boolean isAtLeastT() {
    return isAtLeastPreReleaseCodename("T", Build.VERSION.CODENAME);
  }
  
  @RequiresOptIn
  public static @interface PrereleaseSdkCheck {}
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\os\BuildCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */