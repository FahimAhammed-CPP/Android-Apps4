package androidx.core.os;

import android.os.Build;
import android.os.UserHandle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@RequiresApi(17)
public class UserHandleCompat {
  @Nullable
  private static Method sGetUserIdMethod;
  
  @Nullable
  private static Constructor<UserHandle> sUserHandleConstructor;
  
  private static Method getGetUserIdMethod() throws NoSuchMethodException {
    if (sGetUserIdMethod == null) {
      sGetUserIdMethod = UserHandle.class.getDeclaredMethod("getUserId", new Class[] { int.class });
      sGetUserIdMethod.setAccessible(true);
    } 
    return sGetUserIdMethod;
  }
  
  private static Constructor<UserHandle> getUserHandleConstructor() throws NoSuchMethodException {
    if (sUserHandleConstructor == null) {
      sUserHandleConstructor = UserHandle.class.getDeclaredConstructor(new Class[] { int.class });
      sUserHandleConstructor.setAccessible(true);
    } 
    return sUserHandleConstructor;
  }
  
  @NonNull
  public static UserHandle getUserHandleForUid(int paramInt) {
    if (Build.VERSION.SDK_INT >= 24)
      return Api24Impl.getUserHandleForUid(paramInt); 
    try {
      Integer integer = (Integer)getGetUserIdMethod().invoke(null, new Object[] { Integer.valueOf(paramInt) });
      return getUserHandleConstructor().newInstance(new Object[] { integer });
    } catch (NoSuchMethodException noSuchMethodException) {
      NoSuchMethodError noSuchMethodError = new NoSuchMethodError();
      noSuchMethodError.initCause(noSuchMethodException);
      throw noSuchMethodError;
    } catch (IllegalAccessException illegalAccessException) {
      IllegalAccessError illegalAccessError = new IllegalAccessError();
      illegalAccessError.initCause(illegalAccessException);
      throw illegalAccessError;
    } catch (InstantiationException instantiationException) {
      InstantiationError instantiationError = new InstantiationError();
      instantiationError.initCause(instantiationException);
      throw instantiationError;
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  @RequiresApi(24)
  private static class Api24Impl {
    @NonNull
    static UserHandle getUserHandleForUid(int param1Int) {
      return UserHandle.getUserHandleForUid(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\core\os\UserHandleCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */