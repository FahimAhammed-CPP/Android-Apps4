package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = tintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(tintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    this.mShowDividers = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = tintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    tintTypedArray.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int k = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          layoutParams.width = k;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int k = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          layoutParams.height = k;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - layoutParams.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  int getLocationOffset(View paramView) {
    return 0;
  }
  
  int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  protected boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.mShowDividers & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = ViewUtils.isLayoutRtl((View)this);
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2;
    int m = getPaddingBottom();
    int n = getPaddingBottom();
    int i = getVirtualChildCount();
    paramInt4 = this.mGravity;
    paramInt2 = paramInt4 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt4 = GravityCompat.getAbsoluteGravity(0x800007 & paramInt4, ViewCompat.getLayoutDirection((View)this));
    if (paramInt4 != 1) {
      if (paramInt4 != 5) {
        paramInt1 = getPaddingLeft();
      } else {
        paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = i - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    paramInt4 = 0;
    paramInt3 = j;
    while (paramInt4 < i) {
      int i1 = b1 + b2 * paramInt4;
      View view = getVirtualChildAt(i1);
      if (view == null) {
        paramInt1 += measureNullChild(i1);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool2 && layoutParams.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = layoutParams.gravity;
        int i2 = i4;
        if (i4 < 0)
          i2 = paramInt2; 
        i2 &= 0x70;
        if (i2 != 16) {
          if (i2 != 48) {
            if (i2 != 80) {
              i2 = paramInt3;
            } else {
              i4 = k - m - i6 - layoutParams.bottomMargin;
              i2 = i4;
              if (i3 != -1) {
                i2 = view.getMeasuredHeight();
                i2 = i4 - arrayOfInt2[2] - i2 - i3;
              } 
            } 
          } else {
            i2 = layoutParams.topMargin + paramInt3;
            if (i3 != -1)
              i2 += arrayOfInt1[1] - i3; 
          } 
        } else {
          i2 = (k - j - n - i6) / 2 + paramInt3 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        int i3 = paramInt1;
        if (hasDividerBeforeChildAt(i1))
          i3 = paramInt1 + this.mDividerWidth; 
        paramInt1 = layoutParams.leftMargin + i3;
        setChildFrame(view, paramInt1 + getLocationOffset(view), i2, i5, i6);
        i2 = layoutParams.rightMargin;
        i3 = getNextLocationOffset(view);
        paramInt4 += getChildrenSkipCount(view, i1);
        paramInt1 += i5 + i2 + i3;
      } 
      paramInt4++;
    } 
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = layoutParams.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + layoutParams.leftMargin;
            paramInt4 = layoutParams.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i3, i2);
          paramInt3 = layoutParams.bottomMargin;
          i3 = getNextLocationOffset(view);
          paramInt4 = paramInt2 + getChildrenSkipCount(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #21
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #20
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #27
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #25
    //   63: aload #27
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #27
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #27
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #27
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #25
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #25
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #25
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #25
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #23
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #24
    //   115: iload #21
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #13
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #9
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 850
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   173: astore #26
    //   175: aload #26
    //   177: ifnonnull -> 198
    //   180: aload_0
    //   181: aload_0
    //   182: getfield mTotalLength : I
    //   185: aload_0
    //   186: iload #8
    //   188: invokevirtual measureNullChild : (I)I
    //   191: iadd
    //   192: putfield mTotalLength : I
    //   195: goto -> 841
    //   198: aload #26
    //   200: invokevirtual getVisibility : ()I
    //   203: bipush #8
    //   205: if_icmpne -> 224
    //   208: iload #8
    //   210: aload_0
    //   211: aload #26
    //   213: iload #8
    //   215: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   218: iadd
    //   219: istore #8
    //   221: goto -> 195
    //   224: aload_0
    //   225: iload #8
    //   227: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   230: ifeq -> 246
    //   233: aload_0
    //   234: aload_0
    //   235: getfield mTotalLength : I
    //   238: aload_0
    //   239: getfield mDividerWidth : I
    //   242: iadd
    //   243: putfield mTotalLength : I
    //   246: aload #26
    //   248: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   251: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   254: astore #28
    //   256: fload_3
    //   257: aload #28
    //   259: getfield weight : F
    //   262: fadd
    //   263: fstore_3
    //   264: iload #21
    //   266: ldc 1073741824
    //   268: if_icmpne -> 380
    //   271: aload #28
    //   273: getfield width : I
    //   276: ifne -> 380
    //   279: aload #28
    //   281: getfield weight : F
    //   284: fconst_0
    //   285: fcmpl
    //   286: ifle -> 380
    //   289: iload #15
    //   291: ifeq -> 317
    //   294: aload_0
    //   295: aload_0
    //   296: getfield mTotalLength : I
    //   299: aload #28
    //   301: getfield leftMargin : I
    //   304: aload #28
    //   306: getfield rightMargin : I
    //   309: iadd
    //   310: iadd
    //   311: putfield mTotalLength : I
    //   314: goto -> 346
    //   317: aload_0
    //   318: getfield mTotalLength : I
    //   321: istore #14
    //   323: aload_0
    //   324: iload #14
    //   326: aload #28
    //   328: getfield leftMargin : I
    //   331: iload #14
    //   333: iadd
    //   334: aload #28
    //   336: getfield rightMargin : I
    //   339: iadd
    //   340: invokestatic max : (II)I
    //   343: putfield mTotalLength : I
    //   346: iload #23
    //   348: ifeq -> 374
    //   351: iconst_0
    //   352: iconst_0
    //   353: invokestatic makeMeasureSpec : (II)I
    //   356: istore #14
    //   358: aload #26
    //   360: iload #14
    //   362: iload #14
    //   364: invokevirtual measure : (II)V
    //   367: iload #7
    //   369: istore #14
    //   371: goto -> 564
    //   374: iconst_1
    //   375: istore #12
    //   377: goto -> 568
    //   380: aload #28
    //   382: getfield width : I
    //   385: ifne -> 411
    //   388: aload #28
    //   390: getfield weight : F
    //   393: fconst_0
    //   394: fcmpl
    //   395: ifle -> 411
    //   398: aload #28
    //   400: bipush #-2
    //   402: putfield width : I
    //   405: iconst_0
    //   406: istore #14
    //   408: goto -> 416
    //   411: ldc_w -2147483648
    //   414: istore #14
    //   416: fload_3
    //   417: fconst_0
    //   418: fcmpl
    //   419: ifne -> 431
    //   422: aload_0
    //   423: getfield mTotalLength : I
    //   426: istore #17
    //   428: goto -> 434
    //   431: iconst_0
    //   432: istore #17
    //   434: aload_0
    //   435: aload #26
    //   437: iload #8
    //   439: iload_1
    //   440: iload #17
    //   442: iload_2
    //   443: iconst_0
    //   444: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   447: iload #14
    //   449: ldc_w -2147483648
    //   452: if_icmpeq -> 462
    //   455: aload #28
    //   457: iload #14
    //   459: putfield width : I
    //   462: aload #26
    //   464: invokevirtual getMeasuredWidth : ()I
    //   467: istore #17
    //   469: iload #15
    //   471: ifeq -> 507
    //   474: aload_0
    //   475: aload_0
    //   476: getfield mTotalLength : I
    //   479: aload #28
    //   481: getfield leftMargin : I
    //   484: iload #17
    //   486: iadd
    //   487: aload #28
    //   489: getfield rightMargin : I
    //   492: iadd
    //   493: aload_0
    //   494: aload #26
    //   496: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   499: iadd
    //   500: iadd
    //   501: putfield mTotalLength : I
    //   504: goto -> 546
    //   507: aload_0
    //   508: getfield mTotalLength : I
    //   511: istore #14
    //   513: aload_0
    //   514: iload #14
    //   516: iload #14
    //   518: iload #17
    //   520: iadd
    //   521: aload #28
    //   523: getfield leftMargin : I
    //   526: iadd
    //   527: aload #28
    //   529: getfield rightMargin : I
    //   532: iadd
    //   533: aload_0
    //   534: aload #26
    //   536: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   539: iadd
    //   540: invokestatic max : (II)I
    //   543: putfield mTotalLength : I
    //   546: iload #7
    //   548: istore #14
    //   550: iload #24
    //   552: ifeq -> 564
    //   555: iload #17
    //   557: iload #7
    //   559: invokestatic max : (II)I
    //   562: istore #14
    //   564: iload #14
    //   566: istore #7
    //   568: iload #8
    //   570: istore #18
    //   572: iload #20
    //   574: ldc 1073741824
    //   576: if_icmpeq -> 597
    //   579: aload #28
    //   581: getfield height : I
    //   584: iconst_m1
    //   585: if_icmpne -> 597
    //   588: iconst_1
    //   589: istore #8
    //   591: iconst_1
    //   592: istore #10
    //   594: goto -> 600
    //   597: iconst_0
    //   598: istore #8
    //   600: aload #28
    //   602: getfield topMargin : I
    //   605: aload #28
    //   607: getfield bottomMargin : I
    //   610: iadd
    //   611: istore #14
    //   613: aload #26
    //   615: invokevirtual getMeasuredHeight : ()I
    //   618: iload #14
    //   620: iadd
    //   621: istore #17
    //   623: iload #9
    //   625: aload #26
    //   627: invokevirtual getMeasuredState : ()I
    //   630: invokestatic combineMeasuredStates : (II)I
    //   633: istore #19
    //   635: iload #23
    //   637: ifeq -> 724
    //   640: aload #26
    //   642: invokevirtual getBaseline : ()I
    //   645: istore #22
    //   647: iload #22
    //   649: iconst_m1
    //   650: if_icmpeq -> 724
    //   653: aload #28
    //   655: getfield gravity : I
    //   658: ifge -> 670
    //   661: aload_0
    //   662: getfield mGravity : I
    //   665: istore #9
    //   667: goto -> 677
    //   670: aload #28
    //   672: getfield gravity : I
    //   675: istore #9
    //   677: iload #9
    //   679: bipush #112
    //   681: iand
    //   682: iconst_4
    //   683: ishr
    //   684: bipush #-2
    //   686: iand
    //   687: iconst_1
    //   688: ishr
    //   689: istore #9
    //   691: aload #27
    //   693: iload #9
    //   695: aload #27
    //   697: iload #9
    //   699: iaload
    //   700: iload #22
    //   702: invokestatic max : (II)I
    //   705: iastore
    //   706: aload #25
    //   708: iload #9
    //   710: aload #25
    //   712: iload #9
    //   714: iaload
    //   715: iload #17
    //   717: iload #22
    //   719: isub
    //   720: invokestatic max : (II)I
    //   723: iastore
    //   724: iload #13
    //   726: iload #17
    //   728: invokestatic max : (II)I
    //   731: istore #13
    //   733: iload #5
    //   735: ifeq -> 753
    //   738: aload #28
    //   740: getfield height : I
    //   743: iconst_m1
    //   744: if_icmpne -> 753
    //   747: iconst_1
    //   748: istore #5
    //   750: goto -> 756
    //   753: iconst_0
    //   754: istore #5
    //   756: aload #28
    //   758: getfield weight : F
    //   761: fconst_0
    //   762: fcmpl
    //   763: ifle -> 790
    //   766: iload #8
    //   768: ifeq -> 774
    //   771: goto -> 778
    //   774: iload #17
    //   776: istore #14
    //   778: iload #11
    //   780: iload #14
    //   782: invokestatic max : (II)I
    //   785: istore #8
    //   787: goto -> 812
    //   790: iload #8
    //   792: ifeq -> 799
    //   795: iload #14
    //   797: istore #17
    //   799: iload #6
    //   801: iload #17
    //   803: invokestatic max : (II)I
    //   806: istore #6
    //   808: iload #11
    //   810: istore #8
    //   812: aload_0
    //   813: aload #26
    //   815: iload #18
    //   817: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   820: istore #11
    //   822: iload #19
    //   824: istore #9
    //   826: iload #11
    //   828: iload #18
    //   830: iadd
    //   831: istore #14
    //   833: iload #8
    //   835: istore #11
    //   837: iload #14
    //   839: istore #8
    //   841: iload #8
    //   843: iconst_1
    //   844: iadd
    //   845: istore #8
    //   847: goto -> 160
    //   850: iload #13
    //   852: istore #8
    //   854: aload_0
    //   855: getfield mTotalLength : I
    //   858: ifle -> 883
    //   861: aload_0
    //   862: iload #16
    //   864: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   867: ifeq -> 883
    //   870: aload_0
    //   871: aload_0
    //   872: getfield mTotalLength : I
    //   875: aload_0
    //   876: getfield mDividerWidth : I
    //   879: iadd
    //   880: putfield mTotalLength : I
    //   883: aload #27
    //   885: iconst_1
    //   886: iaload
    //   887: iconst_m1
    //   888: if_icmpne -> 921
    //   891: aload #27
    //   893: iconst_0
    //   894: iaload
    //   895: iconst_m1
    //   896: if_icmpne -> 921
    //   899: aload #27
    //   901: iconst_2
    //   902: iaload
    //   903: iconst_m1
    //   904: if_icmpne -> 921
    //   907: aload #27
    //   909: iconst_3
    //   910: iaload
    //   911: iconst_m1
    //   912: if_icmpeq -> 918
    //   915: goto -> 921
    //   918: goto -> 979
    //   921: iload #8
    //   923: aload #27
    //   925: iconst_3
    //   926: iaload
    //   927: aload #27
    //   929: iconst_0
    //   930: iaload
    //   931: aload #27
    //   933: iconst_1
    //   934: iaload
    //   935: aload #27
    //   937: iconst_2
    //   938: iaload
    //   939: invokestatic max : (II)I
    //   942: invokestatic max : (II)I
    //   945: invokestatic max : (II)I
    //   948: aload #25
    //   950: iconst_3
    //   951: iaload
    //   952: aload #25
    //   954: iconst_0
    //   955: iaload
    //   956: aload #25
    //   958: iconst_1
    //   959: iaload
    //   960: aload #25
    //   962: iconst_2
    //   963: iaload
    //   964: invokestatic max : (II)I
    //   967: invokestatic max : (II)I
    //   970: invokestatic max : (II)I
    //   973: iadd
    //   974: invokestatic max : (II)I
    //   977: istore #8
    //   979: iload #9
    //   981: istore #13
    //   983: iload #8
    //   985: istore #14
    //   987: iload #24
    //   989: ifeq -> 1181
    //   992: iload #21
    //   994: ldc_w -2147483648
    //   997: if_icmpeq -> 1009
    //   1000: iload #8
    //   1002: istore #14
    //   1004: iload #21
    //   1006: ifne -> 1181
    //   1009: aload_0
    //   1010: iconst_0
    //   1011: putfield mTotalLength : I
    //   1014: iconst_0
    //   1015: istore #9
    //   1017: iload #8
    //   1019: istore #14
    //   1021: iload #9
    //   1023: iload #16
    //   1025: if_icmpge -> 1181
    //   1028: aload_0
    //   1029: iload #9
    //   1031: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1034: astore #26
    //   1036: aload #26
    //   1038: ifnonnull -> 1059
    //   1041: aload_0
    //   1042: aload_0
    //   1043: getfield mTotalLength : I
    //   1046: aload_0
    //   1047: iload #9
    //   1049: invokevirtual measureNullChild : (I)I
    //   1052: iadd
    //   1053: putfield mTotalLength : I
    //   1056: goto -> 1082
    //   1059: aload #26
    //   1061: invokevirtual getVisibility : ()I
    //   1064: bipush #8
    //   1066: if_icmpne -> 1085
    //   1069: iload #9
    //   1071: aload_0
    //   1072: aload #26
    //   1074: iload #9
    //   1076: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1079: iadd
    //   1080: istore #9
    //   1082: goto -> 1172
    //   1085: aload #26
    //   1087: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1090: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1093: astore #28
    //   1095: iload #15
    //   1097: ifeq -> 1133
    //   1100: aload_0
    //   1101: aload_0
    //   1102: getfield mTotalLength : I
    //   1105: aload #28
    //   1107: getfield leftMargin : I
    //   1110: iload #7
    //   1112: iadd
    //   1113: aload #28
    //   1115: getfield rightMargin : I
    //   1118: iadd
    //   1119: aload_0
    //   1120: aload #26
    //   1122: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1125: iadd
    //   1126: iadd
    //   1127: putfield mTotalLength : I
    //   1130: goto -> 1082
    //   1133: aload_0
    //   1134: getfield mTotalLength : I
    //   1137: istore #14
    //   1139: aload_0
    //   1140: iload #14
    //   1142: iload #14
    //   1144: iload #7
    //   1146: iadd
    //   1147: aload #28
    //   1149: getfield leftMargin : I
    //   1152: iadd
    //   1153: aload #28
    //   1155: getfield rightMargin : I
    //   1158: iadd
    //   1159: aload_0
    //   1160: aload #26
    //   1162: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1165: iadd
    //   1166: invokestatic max : (II)I
    //   1169: putfield mTotalLength : I
    //   1172: iload #9
    //   1174: iconst_1
    //   1175: iadd
    //   1176: istore #9
    //   1178: goto -> 1017
    //   1181: aload_0
    //   1182: aload_0
    //   1183: getfield mTotalLength : I
    //   1186: aload_0
    //   1187: invokevirtual getPaddingLeft : ()I
    //   1190: aload_0
    //   1191: invokevirtual getPaddingRight : ()I
    //   1194: iadd
    //   1195: iadd
    //   1196: putfield mTotalLength : I
    //   1199: aload_0
    //   1200: getfield mTotalLength : I
    //   1203: aload_0
    //   1204: invokevirtual getSuggestedMinimumWidth : ()I
    //   1207: invokestatic max : (II)I
    //   1210: iload_1
    //   1211: iconst_0
    //   1212: invokestatic resolveSizeAndState : (III)I
    //   1215: istore #18
    //   1217: ldc_w 16777215
    //   1220: iload #18
    //   1222: iand
    //   1223: aload_0
    //   1224: getfield mTotalLength : I
    //   1227: isub
    //   1228: istore #17
    //   1230: iload #12
    //   1232: ifne -> 1368
    //   1235: iload #17
    //   1237: ifeq -> 1249
    //   1240: fload_3
    //   1241: fconst_0
    //   1242: fcmpl
    //   1243: ifle -> 1249
    //   1246: goto -> 1368
    //   1249: iload #6
    //   1251: iload #11
    //   1253: invokestatic max : (II)I
    //   1256: istore #9
    //   1258: iload #24
    //   1260: ifeq -> 1353
    //   1263: iload #21
    //   1265: ldc 1073741824
    //   1267: if_icmpeq -> 1353
    //   1270: iconst_0
    //   1271: istore #6
    //   1273: iload #6
    //   1275: iload #16
    //   1277: if_icmpge -> 1353
    //   1280: aload_0
    //   1281: iload #6
    //   1283: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1286: astore #25
    //   1288: aload #25
    //   1290: ifnull -> 1344
    //   1293: aload #25
    //   1295: invokevirtual getVisibility : ()I
    //   1298: bipush #8
    //   1300: if_icmpne -> 1306
    //   1303: goto -> 1344
    //   1306: aload #25
    //   1308: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1311: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1314: getfield weight : F
    //   1317: fconst_0
    //   1318: fcmpl
    //   1319: ifle -> 1344
    //   1322: aload #25
    //   1324: iload #7
    //   1326: ldc 1073741824
    //   1328: invokestatic makeMeasureSpec : (II)I
    //   1331: aload #25
    //   1333: invokevirtual getMeasuredHeight : ()I
    //   1336: ldc 1073741824
    //   1338: invokestatic makeMeasureSpec : (II)I
    //   1341: invokevirtual measure : (II)V
    //   1344: iload #6
    //   1346: iconst_1
    //   1347: iadd
    //   1348: istore #6
    //   1350: goto -> 1273
    //   1353: iload #16
    //   1355: istore #8
    //   1357: iload #14
    //   1359: istore #7
    //   1361: iload #9
    //   1363: istore #6
    //   1365: goto -> 2114
    //   1368: aload_0
    //   1369: getfield mWeightSum : F
    //   1372: fstore #4
    //   1374: fload #4
    //   1376: fconst_0
    //   1377: fcmpl
    //   1378: ifle -> 1384
    //   1381: fload #4
    //   1383: fstore_3
    //   1384: aload #27
    //   1386: iconst_3
    //   1387: iconst_m1
    //   1388: iastore
    //   1389: aload #27
    //   1391: iconst_2
    //   1392: iconst_m1
    //   1393: iastore
    //   1394: aload #27
    //   1396: iconst_1
    //   1397: iconst_m1
    //   1398: iastore
    //   1399: aload #27
    //   1401: iconst_0
    //   1402: iconst_m1
    //   1403: iastore
    //   1404: aload #25
    //   1406: iconst_3
    //   1407: iconst_m1
    //   1408: iastore
    //   1409: aload #25
    //   1411: iconst_2
    //   1412: iconst_m1
    //   1413: iastore
    //   1414: aload #25
    //   1416: iconst_1
    //   1417: iconst_m1
    //   1418: iastore
    //   1419: aload #25
    //   1421: iconst_0
    //   1422: iconst_m1
    //   1423: iastore
    //   1424: aload_0
    //   1425: iconst_0
    //   1426: putfield mTotalLength : I
    //   1429: iconst_m1
    //   1430: istore #11
    //   1432: iconst_0
    //   1433: istore #12
    //   1435: iload #5
    //   1437: istore #8
    //   1439: iload #16
    //   1441: istore #7
    //   1443: iload #6
    //   1445: istore #9
    //   1447: iload #13
    //   1449: istore #5
    //   1451: iload #17
    //   1453: istore #6
    //   1455: iload #12
    //   1457: istore #13
    //   1459: iload #13
    //   1461: iload #7
    //   1463: if_icmpge -> 1976
    //   1466: aload_0
    //   1467: iload #13
    //   1469: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1472: astore #26
    //   1474: aload #26
    //   1476: ifnull -> 1967
    //   1479: aload #26
    //   1481: invokevirtual getVisibility : ()I
    //   1484: bipush #8
    //   1486: if_icmpne -> 1492
    //   1489: goto -> 1967
    //   1492: aload #26
    //   1494: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1497: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1500: astore #28
    //   1502: aload #28
    //   1504: getfield weight : F
    //   1507: fstore #4
    //   1509: fload #4
    //   1511: fconst_0
    //   1512: fcmpl
    //   1513: ifle -> 1676
    //   1516: iload #6
    //   1518: i2f
    //   1519: fload #4
    //   1521: fmul
    //   1522: fload_3
    //   1523: fdiv
    //   1524: f2i
    //   1525: istore #14
    //   1527: iload_2
    //   1528: aload_0
    //   1529: invokevirtual getPaddingTop : ()I
    //   1532: aload_0
    //   1533: invokevirtual getPaddingBottom : ()I
    //   1536: iadd
    //   1537: aload #28
    //   1539: getfield topMargin : I
    //   1542: iadd
    //   1543: aload #28
    //   1545: getfield bottomMargin : I
    //   1548: iadd
    //   1549: aload #28
    //   1551: getfield height : I
    //   1554: invokestatic getChildMeasureSpec : (III)I
    //   1557: istore #17
    //   1559: aload #28
    //   1561: getfield width : I
    //   1564: ifne -> 1609
    //   1567: iload #21
    //   1569: ldc 1073741824
    //   1571: if_icmpeq -> 1577
    //   1574: goto -> 1609
    //   1577: iload #14
    //   1579: ifle -> 1589
    //   1582: iload #14
    //   1584: istore #12
    //   1586: goto -> 1592
    //   1589: iconst_0
    //   1590: istore #12
    //   1592: aload #26
    //   1594: iload #12
    //   1596: ldc 1073741824
    //   1598: invokestatic makeMeasureSpec : (II)I
    //   1601: iload #17
    //   1603: invokevirtual measure : (II)V
    //   1606: goto -> 1645
    //   1609: aload #26
    //   1611: invokevirtual getMeasuredWidth : ()I
    //   1614: iload #14
    //   1616: iadd
    //   1617: istore #16
    //   1619: iload #16
    //   1621: istore #12
    //   1623: iload #16
    //   1625: ifge -> 1631
    //   1628: iconst_0
    //   1629: istore #12
    //   1631: aload #26
    //   1633: iload #12
    //   1635: ldc 1073741824
    //   1637: invokestatic makeMeasureSpec : (II)I
    //   1640: iload #17
    //   1642: invokevirtual measure : (II)V
    //   1645: iload #5
    //   1647: aload #26
    //   1649: invokevirtual getMeasuredState : ()I
    //   1652: ldc_w -16777216
    //   1655: iand
    //   1656: invokestatic combineMeasuredStates : (II)I
    //   1659: istore #5
    //   1661: fload_3
    //   1662: fload #4
    //   1664: fsub
    //   1665: fstore_3
    //   1666: iload #6
    //   1668: iload #14
    //   1670: isub
    //   1671: istore #6
    //   1673: goto -> 1676
    //   1676: iload #15
    //   1678: ifeq -> 1717
    //   1681: aload_0
    //   1682: aload_0
    //   1683: getfield mTotalLength : I
    //   1686: aload #26
    //   1688: invokevirtual getMeasuredWidth : ()I
    //   1691: aload #28
    //   1693: getfield leftMargin : I
    //   1696: iadd
    //   1697: aload #28
    //   1699: getfield rightMargin : I
    //   1702: iadd
    //   1703: aload_0
    //   1704: aload #26
    //   1706: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1709: iadd
    //   1710: iadd
    //   1711: putfield mTotalLength : I
    //   1714: goto -> 1759
    //   1717: aload_0
    //   1718: getfield mTotalLength : I
    //   1721: istore #12
    //   1723: aload_0
    //   1724: iload #12
    //   1726: aload #26
    //   1728: invokevirtual getMeasuredWidth : ()I
    //   1731: iload #12
    //   1733: iadd
    //   1734: aload #28
    //   1736: getfield leftMargin : I
    //   1739: iadd
    //   1740: aload #28
    //   1742: getfield rightMargin : I
    //   1745: iadd
    //   1746: aload_0
    //   1747: aload #26
    //   1749: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1752: iadd
    //   1753: invokestatic max : (II)I
    //   1756: putfield mTotalLength : I
    //   1759: iload #20
    //   1761: ldc 1073741824
    //   1763: if_icmpeq -> 1781
    //   1766: aload #28
    //   1768: getfield height : I
    //   1771: iconst_m1
    //   1772: if_icmpne -> 1781
    //   1775: iconst_1
    //   1776: istore #12
    //   1778: goto -> 1784
    //   1781: iconst_0
    //   1782: istore #12
    //   1784: aload #28
    //   1786: getfield topMargin : I
    //   1789: aload #28
    //   1791: getfield bottomMargin : I
    //   1794: iadd
    //   1795: istore #17
    //   1797: aload #26
    //   1799: invokevirtual getMeasuredHeight : ()I
    //   1802: iload #17
    //   1804: iadd
    //   1805: istore #16
    //   1807: iload #11
    //   1809: iload #16
    //   1811: invokestatic max : (II)I
    //   1814: istore #14
    //   1816: iload #12
    //   1818: ifeq -> 1828
    //   1821: iload #17
    //   1823: istore #11
    //   1825: goto -> 1832
    //   1828: iload #16
    //   1830: istore #11
    //   1832: iload #9
    //   1834: iload #11
    //   1836: invokestatic max : (II)I
    //   1839: istore #11
    //   1841: iload #8
    //   1843: ifeq -> 1861
    //   1846: aload #28
    //   1848: getfield height : I
    //   1851: iconst_m1
    //   1852: if_icmpne -> 1861
    //   1855: iconst_1
    //   1856: istore #8
    //   1858: goto -> 1864
    //   1861: iconst_0
    //   1862: istore #8
    //   1864: iload #23
    //   1866: ifeq -> 1956
    //   1869: aload #26
    //   1871: invokevirtual getBaseline : ()I
    //   1874: istore #12
    //   1876: iload #12
    //   1878: iconst_m1
    //   1879: if_icmpeq -> 1956
    //   1882: aload #28
    //   1884: getfield gravity : I
    //   1887: ifge -> 1899
    //   1890: aload_0
    //   1891: getfield mGravity : I
    //   1894: istore #9
    //   1896: goto -> 1906
    //   1899: aload #28
    //   1901: getfield gravity : I
    //   1904: istore #9
    //   1906: iload #9
    //   1908: bipush #112
    //   1910: iand
    //   1911: iconst_4
    //   1912: ishr
    //   1913: bipush #-2
    //   1915: iand
    //   1916: iconst_1
    //   1917: ishr
    //   1918: istore #9
    //   1920: aload #27
    //   1922: iload #9
    //   1924: aload #27
    //   1926: iload #9
    //   1928: iaload
    //   1929: iload #12
    //   1931: invokestatic max : (II)I
    //   1934: iastore
    //   1935: aload #25
    //   1937: iload #9
    //   1939: aload #25
    //   1941: iload #9
    //   1943: iaload
    //   1944: iload #16
    //   1946: iload #12
    //   1948: isub
    //   1949: invokestatic max : (II)I
    //   1952: iastore
    //   1953: goto -> 1956
    //   1956: iload #11
    //   1958: istore #9
    //   1960: iload #14
    //   1962: istore #11
    //   1964: goto -> 1967
    //   1967: iload #13
    //   1969: iconst_1
    //   1970: iadd
    //   1971: istore #13
    //   1973: goto -> 1459
    //   1976: aload_0
    //   1977: aload_0
    //   1978: getfield mTotalLength : I
    //   1981: aload_0
    //   1982: invokevirtual getPaddingLeft : ()I
    //   1985: aload_0
    //   1986: invokevirtual getPaddingRight : ()I
    //   1989: iadd
    //   1990: iadd
    //   1991: putfield mTotalLength : I
    //   1994: aload #27
    //   1996: iconst_1
    //   1997: iaload
    //   1998: iconst_m1
    //   1999: if_icmpne -> 2036
    //   2002: aload #27
    //   2004: iconst_0
    //   2005: iaload
    //   2006: iconst_m1
    //   2007: if_icmpne -> 2036
    //   2010: aload #27
    //   2012: iconst_2
    //   2013: iaload
    //   2014: iconst_m1
    //   2015: if_icmpne -> 2036
    //   2018: aload #27
    //   2020: iconst_3
    //   2021: iaload
    //   2022: iconst_m1
    //   2023: if_icmpeq -> 2029
    //   2026: goto -> 2036
    //   2029: iload #11
    //   2031: istore #6
    //   2033: goto -> 2094
    //   2036: iload #11
    //   2038: aload #27
    //   2040: iconst_3
    //   2041: iaload
    //   2042: aload #27
    //   2044: iconst_0
    //   2045: iaload
    //   2046: aload #27
    //   2048: iconst_1
    //   2049: iaload
    //   2050: aload #27
    //   2052: iconst_2
    //   2053: iaload
    //   2054: invokestatic max : (II)I
    //   2057: invokestatic max : (II)I
    //   2060: invokestatic max : (II)I
    //   2063: aload #25
    //   2065: iconst_3
    //   2066: iaload
    //   2067: aload #25
    //   2069: iconst_0
    //   2070: iaload
    //   2071: aload #25
    //   2073: iconst_1
    //   2074: iaload
    //   2075: aload #25
    //   2077: iconst_2
    //   2078: iaload
    //   2079: invokestatic max : (II)I
    //   2082: invokestatic max : (II)I
    //   2085: invokestatic max : (II)I
    //   2088: iadd
    //   2089: invokestatic max : (II)I
    //   2092: istore #6
    //   2094: iload #5
    //   2096: istore #13
    //   2098: iload #8
    //   2100: istore #5
    //   2102: iload #7
    //   2104: istore #8
    //   2106: iload #6
    //   2108: istore #7
    //   2110: iload #9
    //   2112: istore #6
    //   2114: iload #5
    //   2116: ifne -> 2129
    //   2119: iload #20
    //   2121: ldc 1073741824
    //   2123: if_icmpeq -> 2129
    //   2126: goto -> 2133
    //   2129: iload #7
    //   2131: istore #6
    //   2133: aload_0
    //   2134: iload #18
    //   2136: iload #13
    //   2138: ldc_w -16777216
    //   2141: iand
    //   2142: ior
    //   2143: iload #6
    //   2145: aload_0
    //   2146: invokevirtual getPaddingTop : ()I
    //   2149: aload_0
    //   2150: invokevirtual getPaddingBottom : ()I
    //   2153: iadd
    //   2154: iadd
    //   2155: aload_0
    //   2156: invokevirtual getSuggestedMinimumHeight : ()I
    //   2159: invokestatic max : (II)I
    //   2162: iload_2
    //   2163: iload #13
    //   2165: bipush #16
    //   2167: ishl
    //   2168: invokestatic resolveSizeAndState : (III)I
    //   2171: invokevirtual setMeasuredDimension : (II)V
    //   2174: iload #10
    //   2176: ifeq -> 2186
    //   2179: aload_0
    //   2180: iload #8
    //   2182: iload_1
    //   2183: invokespecial forceUniformHeight : (II)V
    //   2186: return
  }
  
  int measureNullChild(int paramInt) {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i3 = getVirtualChildCount();
    int i8 = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    int i9 = this.mBaselineAlignedChildIndex;
    boolean bool1 = this.mUseLargestChild;
    float f = 0.0F;
    int i = 0;
    int i5 = 0;
    int n = 0;
    int i1 = 0;
    int m = 0;
    int i2 = 0;
    int i4 = 0;
    int k = 1;
    boolean bool = false;
    while (i2 < i3) {
      View view = getVirtualChildAt(i2);
      if (view == null) {
        this.mTotalLength += measureNullChild(i2);
      } else if (view.getVisibility() == 8) {
        i2 += getChildrenSkipCount(view, i2);
      } else {
        if (hasDividerBeforeChildAt(i2))
          this.mTotalLength += this.mDividerHeight; 
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        f += layoutParams.weight;
        if (j == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0F) {
          i4 = this.mTotalLength;
          this.mTotalLength = Math.max(i4, layoutParams.topMargin + i4 + layoutParams.bottomMargin);
          i4 = 1;
        } else {
          if (layoutParams.height == 0 && layoutParams.weight > 0.0F) {
            layoutParams.height = -2;
            i11 = 0;
          } else {
            i11 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i12 = this.mTotalLength;
          } else {
            i12 = 0;
          } 
          measureChildBeforeLayout(view, i2, paramInt1, 0, paramInt2, i12);
          if (i11 != Integer.MIN_VALUE)
            layoutParams.height = i11; 
          int i11 = view.getMeasuredHeight();
          int i12 = this.mTotalLength;
          this.mTotalLength = Math.max(i12, i12 + i11 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          if (bool1)
            n = Math.max(i11, n); 
        } 
        int i10 = i2;
        if (i9 >= 0 && i9 == i10 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i10 >= i9 || layoutParams.weight <= 0.0F) {
          if (i8 != 1073741824 && layoutParams.width == -1) {
            i2 = 1;
            bool = true;
          } else {
            i2 = 0;
          } 
          int i11 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i12 = view.getMeasuredWidth() + i11;
          i5 = Math.max(i5, i12);
          int i13 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && layoutParams.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (layoutParams.weight > 0.0F) {
            if (i2 == 0)
              i11 = i12; 
            i1 = Math.max(i1, i11);
            k = m;
            m = i1;
          } else {
            if (i2 == 0)
              i11 = i12; 
            k = Math.max(m, i11);
            m = i1;
          } 
          i11 = getChildrenSkipCount(view, i10);
          i2 = i;
          i1 = m;
          m = k;
          i = i13;
          i11 += i10;
          k = i2;
          i2 = i11;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i2++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i3))
      this.mTotalLength += this.mDividerHeight; 
    if (bool1) {
      i2 = j;
      if (i2 == Integer.MIN_VALUE || i2 == 0) {
        this.mTotalLength = 0;
        for (i2 = 0; i2 < i3; i2++) {
          View view = getVirtualChildAt(i2);
          if (view == null) {
            this.mTotalLength += measureNullChild(i2);
          } else if (view.getVisibility() == 8) {
            i2 += getChildrenSkipCount(view, i2);
          } else {
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            int i10 = this.mTotalLength;
            this.mTotalLength = Math.max(i10, i10 + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          } 
        } 
      } 
    } 
    i2 = j;
    this.mTotalLength += getPaddingTop() + getPaddingBottom();
    int i7 = View.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumHeight()), paramInt2, 0);
    int i6 = (0xFFFFFF & i7) - this.mTotalLength;
    if (i4 != 0 || (i6 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      i1 = 0;
      j = m;
      n = i6;
      m = i5;
      while (i1 < i3) {
        View view = getVirtualChildAt(i1);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i5 = (int)(n * f1 / f);
            i6 = getPaddingLeft();
            int i10 = getPaddingRight();
            i4 = n - i5;
            n = layoutParams.leftMargin;
            int i11 = layoutParams.rightMargin;
            i9 = layoutParams.width;
            f -= f1;
            i6 = getChildMeasureSpec(paramInt1, i6 + i10 + n + i11, i9);
            if (layoutParams.height != 0 || i2 != 1073741824) {
              i5 = view.getMeasuredHeight() + i5;
              n = i5;
              if (i5 < 0)
                n = 0; 
              view.measure(i6, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
            } else {
              if (i5 > 0) {
                n = i5;
              } else {
                n = 0;
              } 
              view.measure(i6, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            n = i4;
          } 
          i5 = layoutParams.leftMargin + layoutParams.rightMargin;
          i6 = view.getMeasuredWidth() + i5;
          i4 = Math.max(m, i6);
          if (i8 != 1073741824 && layoutParams.width == -1) {
            m = 1;
          } else {
            m = 0;
          } 
          if (m != 0) {
            m = i5;
          } else {
            m = i6;
          } 
          m = Math.max(j, m);
          if (k != 0 && layoutParams.width == -1) {
            j = 1;
          } else {
            j = 0;
          } 
          k = this.mTotalLength;
          this.mTotalLength = Math.max(k, view.getMeasuredHeight() + k + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          k = j;
          j = m;
          m = i4;
        } 
        i1++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      n = j;
      j = i;
      i = n;
    } else {
      m = Math.max(m, i1);
      if (bool1 && i2 != 1073741824)
        for (j = 0; j < i3; j++) {
          View view = getVirtualChildAt(j);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      m = i5;
    } 
    if (k != 0 || i8 == 1073741824)
      i = m; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i7);
    if (bool)
      forceUniformWidth(i3, paramInt2); 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
      return;
    } 
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(LinearLayoutCompat.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(LinearLayoutCompat.class.getName());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
      return;
    } 
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface DividerMode {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int gravity = -1;
    
    public float weight;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.weight = 0.0F;
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2);
      this.weight = param1Float;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.LinearLayoutCompat_Layout);
      this.weight = typedArray.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
      this.gravity = typedArray.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
      typedArray.recycle();
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.weight = param1LayoutParams.weight;
      this.gravity = param1LayoutParams.gravity;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface OrientationMode {}
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */