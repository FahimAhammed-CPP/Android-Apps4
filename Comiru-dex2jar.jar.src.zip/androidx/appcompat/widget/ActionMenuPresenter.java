package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.R;
import androidx.appcompat.view.ActionBarPolicy;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.BaseMenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.view.menu.ShowableListMenu;
import androidx.appcompat.view.menu.SubMenuBuilder;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ActionProvider;
import java.util.ArrayList;

class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  ActionButtonSubmenu mActionButtonPopup;
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  int mOpenSubMenuId;
  
  OverflowMenuButton mOverflowButton;
  
  OverflowPopup mOverflowPopup;
  
  private Drawable mPendingOverflowIcon;
  
  private boolean mPendingOverflowIconSet;
  
  private ActionMenuPopupCallback mPopupCallback;
  
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  
  OpenOverflowRunnable mPostedOpenRunnable;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private View mScrapActionButtonView;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.mMenuView;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof MenuView.ItemView && ((MenuView.ItemView)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)paramItemView;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.mPopupCallback == null)
      this.mPopupCallback = new ActionMenuPopupCallback(); 
    actionMenuItemView.setPopupCallback(this.mPopupCallback);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    // Byte code:
    //   0: aload_0
    //   1: astore #15
    //   3: aload #15
    //   5: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   8: ifnull -> 31
    //   11: aload #15
    //   13: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   16: invokevirtual getVisibleItems : ()Ljava/util/ArrayList;
    //   19: astore #14
    //   21: aload #14
    //   23: invokevirtual size : ()I
    //   26: istore #4
    //   28: goto -> 37
    //   31: aconst_null
    //   32: astore #14
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #15
    //   39: getfield mMaxItems : I
    //   42: istore_1
    //   43: aload #15
    //   45: getfield mActionItemWidthLimit : I
    //   48: istore #8
    //   50: iconst_0
    //   51: iconst_0
    //   52: invokestatic makeMeasureSpec : (II)I
    //   55: istore #10
    //   57: aload #15
    //   59: getfield mMenuView : Landroidx/appcompat/view/menu/MenuView;
    //   62: checkcast android/view/ViewGroup
    //   65: astore #16
    //   67: iconst_0
    //   68: istore #5
    //   70: iconst_0
    //   71: istore #6
    //   73: iconst_0
    //   74: istore_2
    //   75: iconst_0
    //   76: istore_3
    //   77: iload #5
    //   79: iload #4
    //   81: if_icmpge -> 166
    //   84: aload #14
    //   86: iload #5
    //   88: invokevirtual get : (I)Ljava/lang/Object;
    //   91: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   94: astore #17
    //   96: aload #17
    //   98: invokevirtual requiresActionButton : ()Z
    //   101: ifeq -> 111
    //   104: iload_2
    //   105: iconst_1
    //   106: iadd
    //   107: istore_2
    //   108: goto -> 129
    //   111: aload #17
    //   113: invokevirtual requestsActionButton : ()Z
    //   116: ifeq -> 126
    //   119: iload_3
    //   120: iconst_1
    //   121: iadd
    //   122: istore_3
    //   123: goto -> 129
    //   126: iconst_1
    //   127: istore #6
    //   129: iload_1
    //   130: istore #7
    //   132: aload #15
    //   134: getfield mExpandedActionViewsExclusive : Z
    //   137: ifeq -> 154
    //   140: iload_1
    //   141: istore #7
    //   143: aload #17
    //   145: invokevirtual isActionViewExpanded : ()Z
    //   148: ifeq -> 154
    //   151: iconst_0
    //   152: istore #7
    //   154: iload #5
    //   156: iconst_1
    //   157: iadd
    //   158: istore #5
    //   160: iload #7
    //   162: istore_1
    //   163: goto -> 77
    //   166: iload_1
    //   167: istore #5
    //   169: aload #15
    //   171: getfield mReserveOverflow : Z
    //   174: ifeq -> 197
    //   177: iload #6
    //   179: ifne -> 192
    //   182: iload_1
    //   183: istore #5
    //   185: iload_3
    //   186: iload_2
    //   187: iadd
    //   188: iload_1
    //   189: if_icmple -> 197
    //   192: iload_1
    //   193: iconst_1
    //   194: isub
    //   195: istore #5
    //   197: iload #5
    //   199: iload_2
    //   200: isub
    //   201: istore_1
    //   202: aload #15
    //   204: getfield mActionButtonGroups : Landroid/util/SparseBooleanArray;
    //   207: astore #17
    //   209: aload #17
    //   211: invokevirtual clear : ()V
    //   214: aload #15
    //   216: getfield mStrictWidthLimit : Z
    //   219: ifeq -> 246
    //   222: aload #15
    //   224: getfield mMinCellSize : I
    //   227: istore_2
    //   228: iload #8
    //   230: iload_2
    //   231: idiv
    //   232: istore_3
    //   233: iload_2
    //   234: iload #8
    //   236: iload_2
    //   237: irem
    //   238: iload_3
    //   239: idiv
    //   240: iadd
    //   241: istore #6
    //   243: goto -> 251
    //   246: iconst_0
    //   247: istore #6
    //   249: iconst_0
    //   250: istore_3
    //   251: iload #8
    //   253: istore #5
    //   255: iconst_0
    //   256: istore #8
    //   258: iconst_0
    //   259: istore_2
    //   260: iload #4
    //   262: istore #7
    //   264: aload_0
    //   265: astore #15
    //   267: iload #8
    //   269: iload #7
    //   271: if_icmpge -> 781
    //   274: aload #14
    //   276: iload #8
    //   278: invokevirtual get : (I)Ljava/lang/Object;
    //   281: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   284: astore #18
    //   286: aload #18
    //   288: invokevirtual requiresActionButton : ()Z
    //   291: ifeq -> 415
    //   294: aload #15
    //   296: aload #18
    //   298: aload #15
    //   300: getfield mScrapActionButtonView : Landroid/view/View;
    //   303: aload #16
    //   305: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   308: astore #19
    //   310: aload #15
    //   312: getfield mScrapActionButtonView : Landroid/view/View;
    //   315: ifnonnull -> 325
    //   318: aload #15
    //   320: aload #19
    //   322: putfield mScrapActionButtonView : Landroid/view/View;
    //   325: aload #15
    //   327: getfield mStrictWidthLimit : Z
    //   330: ifeq -> 350
    //   333: iload_3
    //   334: aload #19
    //   336: iload #6
    //   338: iload_3
    //   339: iload #10
    //   341: iconst_0
    //   342: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   345: isub
    //   346: istore_3
    //   347: goto -> 359
    //   350: aload #19
    //   352: iload #10
    //   354: iload #10
    //   356: invokevirtual measure : (II)V
    //   359: aload #19
    //   361: invokevirtual getMeasuredWidth : ()I
    //   364: istore #4
    //   366: iload #5
    //   368: iload #4
    //   370: isub
    //   371: istore #5
    //   373: iload_2
    //   374: ifne -> 383
    //   377: iload #4
    //   379: istore_2
    //   380: goto -> 383
    //   383: aload #18
    //   385: invokevirtual getGroupId : ()I
    //   388: istore #4
    //   390: iload #4
    //   392: ifeq -> 406
    //   395: aload #17
    //   397: iload #4
    //   399: iconst_1
    //   400: invokevirtual put : (IZ)V
    //   403: goto -> 406
    //   406: aload #18
    //   408: iconst_1
    //   409: invokevirtual setIsActionButton : (Z)V
    //   412: goto -> 772
    //   415: aload #18
    //   417: invokevirtual requestsActionButton : ()Z
    //   420: ifeq -> 766
    //   423: aload #18
    //   425: invokevirtual getGroupId : ()I
    //   428: istore #11
    //   430: aload #17
    //   432: iload #11
    //   434: invokevirtual get : (I)Z
    //   437: istore #13
    //   439: iload_1
    //   440: ifgt -> 448
    //   443: iload #13
    //   445: ifeq -> 471
    //   448: iload #5
    //   450: ifle -> 471
    //   453: aload #15
    //   455: getfield mStrictWidthLimit : Z
    //   458: ifeq -> 465
    //   461: iload_3
    //   462: ifle -> 471
    //   465: iconst_1
    //   466: istore #12
    //   468: goto -> 474
    //   471: iconst_0
    //   472: istore #12
    //   474: iload #12
    //   476: ifeq -> 631
    //   479: aload #15
    //   481: aload #18
    //   483: aload #15
    //   485: getfield mScrapActionButtonView : Landroid/view/View;
    //   488: aload #16
    //   490: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   493: astore #19
    //   495: aload #15
    //   497: getfield mScrapActionButtonView : Landroid/view/View;
    //   500: ifnonnull -> 510
    //   503: aload #15
    //   505: aload #19
    //   507: putfield mScrapActionButtonView : Landroid/view/View;
    //   510: aload #15
    //   512: getfield mStrictWidthLimit : Z
    //   515: ifeq -> 554
    //   518: aload #19
    //   520: iload #6
    //   522: iload_3
    //   523: iload #10
    //   525: iconst_0
    //   526: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   529: istore #9
    //   531: iload_3
    //   532: iload #9
    //   534: isub
    //   535: istore #4
    //   537: iload #4
    //   539: istore_3
    //   540: iload #9
    //   542: ifne -> 563
    //   545: iconst_0
    //   546: istore #12
    //   548: iload #4
    //   550: istore_3
    //   551: goto -> 563
    //   554: aload #19
    //   556: iload #10
    //   558: iload #10
    //   560: invokevirtual measure : (II)V
    //   563: aload #19
    //   565: invokevirtual getMeasuredWidth : ()I
    //   568: istore #9
    //   570: iload #5
    //   572: iload #9
    //   574: isub
    //   575: istore #5
    //   577: iload_2
    //   578: istore #4
    //   580: iload_2
    //   581: ifne -> 588
    //   584: iload #9
    //   586: istore #4
    //   588: aload #15
    //   590: getfield mStrictWidthLimit : Z
    //   593: ifeq -> 604
    //   596: iload #5
    //   598: iflt -> 617
    //   601: goto -> 612
    //   604: iload #5
    //   606: iload #4
    //   608: iadd
    //   609: ifle -> 617
    //   612: iconst_1
    //   613: istore_2
    //   614: goto -> 619
    //   617: iconst_0
    //   618: istore_2
    //   619: iload #12
    //   621: iload_2
    //   622: iand
    //   623: istore #12
    //   625: iload #4
    //   627: istore_2
    //   628: goto -> 631
    //   631: iload #12
    //   633: ifeq -> 655
    //   636: iload #11
    //   638: ifeq -> 655
    //   641: aload #17
    //   643: iload #11
    //   645: iconst_1
    //   646: invokevirtual put : (IZ)V
    //   649: iload_1
    //   650: istore #4
    //   652: goto -> 743
    //   655: iload_1
    //   656: istore #4
    //   658: iload #13
    //   660: ifeq -> 743
    //   663: aload #17
    //   665: iload #11
    //   667: iconst_0
    //   668: invokevirtual put : (IZ)V
    //   671: iconst_0
    //   672: istore #9
    //   674: iload_1
    //   675: istore #4
    //   677: iload #9
    //   679: iload #8
    //   681: if_icmpge -> 743
    //   684: aload #14
    //   686: iload #9
    //   688: invokevirtual get : (I)Ljava/lang/Object;
    //   691: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   694: astore #15
    //   696: iload_1
    //   697: istore #4
    //   699: aload #15
    //   701: invokevirtual getGroupId : ()I
    //   704: iload #11
    //   706: if_icmpne -> 731
    //   709: iload_1
    //   710: istore #4
    //   712: aload #15
    //   714: invokevirtual isActionButton : ()Z
    //   717: ifeq -> 725
    //   720: iload_1
    //   721: iconst_1
    //   722: iadd
    //   723: istore #4
    //   725: aload #15
    //   727: iconst_0
    //   728: invokevirtual setIsActionButton : (Z)V
    //   731: iload #9
    //   733: iconst_1
    //   734: iadd
    //   735: istore #9
    //   737: iload #4
    //   739: istore_1
    //   740: goto -> 674
    //   743: iload #4
    //   745: istore_1
    //   746: iload #12
    //   748: ifeq -> 756
    //   751: iload #4
    //   753: iconst_1
    //   754: isub
    //   755: istore_1
    //   756: aload #18
    //   758: iload #12
    //   760: invokevirtual setIsActionButton : (Z)V
    //   763: goto -> 412
    //   766: aload #18
    //   768: iconst_0
    //   769: invokevirtual setIsActionButton : (Z)V
    //   772: iload #8
    //   774: iconst_1
    //   775: iadd
    //   776: istore #8
    //   778: goto -> 264
    //   781: iconst_1
    //   782: ireturn
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView())
      view = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup); 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView2 = this.mMenuView;
    MenuView menuView1 = super.getMenuView(paramViewGroup);
    if (menuView2 != menuView1)
      ((ActionMenuView)menuView1).setPresenter(this); 
    return menuView1;
  }
  
  public Drawable getOverflowIcon() {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    return (overflowMenuButton != null) ? overflowMenuButton.getDrawable() : (this.mPendingOverflowIconSet ? this.mPendingOverflowIcon : null);
  }
  
  public boolean hideOverflowMenu() {
    if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    ActionButtonSubmenu actionButtonSubmenu = this.mActionButtonPopup;
    if (actionButtonSubmenu != null) {
      actionButtonSubmenu.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(@NonNull Context paramContext, @Nullable MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.mOverflowButton == null) {
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
        if (this.mPendingOverflowIconSet) {
          this.mOverflowButton.setImageDrawable(this.mPendingOverflowIcon);
          this.mPendingOverflowIcon = null;
          this.mPendingOverflowIconSet = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      } 
      i -= this.mOverflowButton.getMeasuredWidth();
    } else {
      this.mOverflowButton = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)((resources.getDisplayMetrics()).density * 56.0F);
    this.mScrapActionButtonView = null;
  }
  
  public boolean isOverflowMenuShowPending() {
    return (this.mPostedOpenRunnable != null || isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing() {
    OverflowPopup overflowPopup = this.mOverflowPopup;
    return (overflowPopup != null && overflowPopup.isShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = ActionBarPolicy.get(this.mContext).getMaxActionButtons(); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState))
      return; 
    paramParcelable = paramParcelable;
    if (((SavedState)paramParcelable).openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(((SavedState)paramParcelable).openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.mOpenSubMenuId;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool = paramSubMenuBuilder.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    SubMenuBuilder subMenuBuilder;
    for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
    View view = findViewForItem(subMenuBuilder.getItem());
    if (view == null)
      return false; 
    this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
    int j = paramSubMenuBuilder.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramSubMenuBuilder.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    this.mActionButtonPopup = new ActionButtonSubmenu(this.mContext, paramSubMenuBuilder, view);
    this.mActionButtonPopup.setForceShowIcon(bool);
    this.mActionButtonPopup.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
      return;
    } 
    if (this.mMenu != null)
      this.mMenu.close(false); 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView) {
    this.mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(this.mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    if (overflowMenuButton != null) {
      overflowMenuButton.setImageDrawable(paramDrawable);
      return;
    } 
    this.mPendingOverflowIconSet = true;
    this.mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null && !this.mMenu.getNonActionItems().isEmpty()) {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, (View)this.mOverflowButton, true));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return true;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    MenuBuilder<MenuItemImpl> menuBuilder = this.mMenu;
    byte b = 0;
    if (menuBuilder != null) {
      ArrayList<MenuItemImpl> arrayList = this.mMenu.getActionItems();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        ActionProvider actionProvider = ((MenuItemImpl)arrayList.get(j)).getSupportActionProvider();
        if (actionProvider != null)
          actionProvider.setSubUiVisibilityListener(this); 
      } 
    } 
    if (this.mMenu != null) {
      ArrayList arrayList = this.mMenu.getNonActionItems();
    } else {
      menuBuilder = null;
    } 
    int i = b;
    if (this.mReserveOverflow) {
      i = b;
      if (menuBuilder != null) {
        int j = menuBuilder.size();
        if (j == 1) {
          i = ((MenuItemImpl)menuBuilder.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.mOverflowButton == null)
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext); 
      ViewGroup viewGroup = (ViewGroup)this.mOverflowButton.getParent();
      if (viewGroup != this.mMenuView) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.mOverflowButton); 
        viewGroup = (ActionMenuView)this.mMenuView;
        viewGroup.addView((View)this.mOverflowButton, (ViewGroup.LayoutParams)viewGroup.generateOverflowButtonLayoutParams());
      } 
    } else {
      OverflowMenuButton overflowMenuButton = this.mOverflowButton;
      if (overflowMenuButton != null && overflowMenuButton.getParent() == this.mMenuView)
        ((ViewGroup)this.mMenuView).removeView((View)this.mOverflowButton); 
    } 
    ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
  }
  
  private class ActionButtonSubmenu extends MenuPopupHelper {
    public ActionButtonSubmenu(Context param1Context, SubMenuBuilder param1SubMenuBuilder, View param1View) {
      super(param1Context, (MenuBuilder)param1SubMenuBuilder, param1View, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)param1SubMenuBuilder.getItem()).isActionButton()) {
        ActionMenuPresenter.OverflowMenuButton overflowMenuButton;
        if (ActionMenuPresenter.this.mOverflowButton == null) {
          View view = (View)ActionMenuPresenter.this.mMenuView;
        } else {
          overflowMenuButton = ActionMenuPresenter.this.mOverflowButton;
        } 
        setAnchorView((View)overflowMenuButton);
      } 
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      ActionMenuPresenter actionMenuPresenter = ActionMenuPresenter.this;
      actionMenuPresenter.mActionButtonPopup = null;
      actionMenuPresenter.mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  private class ActionMenuPopupCallback extends ActionMenuItemView.PopupCallback {
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mActionButtonPopup != null) ? ActionMenuPresenter.this.mActionButtonPopup.getPopup() : null);
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.changeMenuMode(); 
      View view = (View)ActionMenuPresenter.this.mMenuView;
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        ActionMenuPresenter.this.mOverflowPopup = this.mPopup; 
      ActionMenuPresenter.this.mPostedOpenRunnable = null;
    }
  }
  
  private class OverflowMenuButton extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    private final float[] mTempPts = new float[2];
    
    public OverflowMenuButton(Context param1Context) {
      super(param1Context, (AttributeSet)null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new ForwardingListener((View)this) {
            public ShowableListMenu getPopup() {
              return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
            }
            
            public boolean onForwardingStarted() {
              ActionMenuPresenter.this.showOverflowMenu();
              return true;
            }
            
            public boolean onForwardingStopped() {
              if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
                return false; 
              ActionMenuPresenter.this.hideOverflowMenu();
              return true;
            }
          });
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        DrawableCompat.setHotspotBounds(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
  }
  
  class null extends ForwardingListener {
    null(View param1View) {
      super(param1View);
    }
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
    }
    
    public boolean onForwardingStarted() {
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    public boolean onForwardingStopped() {
      if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
        return false; 
      ActionMenuPresenter.this.hideOverflowMenu();
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    public OverflowPopup(Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean, R.attr.actionOverflowMenuStyle);
      setGravity(8388613);
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.close(); 
      ActionMenuPresenter.this.mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        param1MenuBuilder.getRootMenu().close(false); 
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        callback.onCloseMenu(param1MenuBuilder, param1Boolean); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      boolean bool = false;
      if (param1MenuBuilder == null)
        return false; 
      ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId();
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        bool = callback.onOpenSubMenu(param1MenuBuilder); 
      return bool;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\appcompat\widget\ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */