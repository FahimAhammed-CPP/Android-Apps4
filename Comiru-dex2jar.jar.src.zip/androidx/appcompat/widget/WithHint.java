package androidx.appcompat.widget;

import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface WithHint {
  @Nullable
  CharSequence getHint();
}


/* Location:              C:\soft\dex2jar-2.0\Comiru-dex2jar.jar!\androidx\appcompat\widget\WithHint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */