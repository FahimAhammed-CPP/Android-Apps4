package androidx.core.graphics.drawable;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\"\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\005\032*\020\000\032\0020\001*\0020\0022\b\b\003\020\003\032\0020\0042\b\b\003\020\005\032\0020\0042\n\b\002\020\006\032\004\030\0010\007\0322\020\b\032\0020\t*\0020\0022\b\b\003\020\n\032\0020\0042\b\b\003\020\013\032\0020\0042\b\b\003\020\f\032\0020\0042\b\b\003\020\r\032\0020\004¨\006\016"}, d2 = {"toBitmap", "Landroid/graphics/Bitmap;", "Landroid/graphics/drawable/Drawable;", "width", "", "height", "config", "Landroid/graphics/Bitmap$Config;", "updateBounds", "", "left", "top", "right", "bottom", "core-ktx_release"}, k = 2, mv = {1, 5, 1}, xi = 48)
public final class DrawableKt {
  public static final Bitmap toBitmap(Drawable paramDrawable, int paramInt1, int paramInt2, Bitmap.Config paramConfig) {
    Bitmap bitmap1;
    Intrinsics.checkNotNullParameter(paramDrawable, "<this>");
    if (paramDrawable instanceof BitmapDrawable && (paramConfig == null || ((BitmapDrawable)paramDrawable).getBitmap().getConfig() == paramConfig)) {
      BitmapDrawable bitmapDrawable = (BitmapDrawable)paramDrawable;
      if (paramInt1 == bitmapDrawable.getIntrinsicWidth() && paramInt2 == bitmapDrawable.getIntrinsicHeight()) {
        bitmap1 = bitmapDrawable.getBitmap();
        Intrinsics.checkNotNullExpressionValue(bitmap1, "bitmap");
        return bitmap1;
      } 
      bitmap1 = Bitmap.createScaledBitmap(bitmap1.getBitmap(), paramInt1, paramInt2, true);
      Intrinsics.checkNotNullExpressionValue(bitmap1, "createScaledBitmap(bitmap, width, height, true)");
      return bitmap1;
    } 
    Rect rect = bitmap1.getBounds();
    Intrinsics.checkNotNullExpressionValue(rect, "bounds");
    int i = rect.left;
    int j = rect.top;
    int k = rect.right;
    int m = rect.bottom;
    Bitmap.Config config = paramConfig;
    if (paramConfig == null)
      config = Bitmap.Config.ARGB_8888; 
    Bitmap bitmap2 = Bitmap.createBitmap(paramInt1, paramInt2, config);
    bitmap1.setBounds(0, 0, paramInt1, paramInt2);
    bitmap1.draw(new Canvas(bitmap2));
    bitmap1.setBounds(i, j, k, m);
    Intrinsics.checkNotNullExpressionValue(bitmap2, "bitmap");
    return bitmap2;
  }
  
  public static final void updateBounds(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Intrinsics.checkNotNullParameter(paramDrawable, "<this>");
    paramDrawable.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\core\graphics\drawable\DrawableKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */