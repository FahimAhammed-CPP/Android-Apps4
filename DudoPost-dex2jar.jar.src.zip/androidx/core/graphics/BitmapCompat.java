package androidx.core.graphics;

import android.graphics.Bitmap;

public final class BitmapCompat {
  public static int getAllocationByteCount(Bitmap paramBitmap) {
    return paramBitmap.getAllocationByteCount();
  }
  
  public static boolean hasMipMap(Bitmap paramBitmap) {
    return paramBitmap.hasMipMap();
  }
  
  public static void setHasMipMap(Bitmap paramBitmap, boolean paramBoolean) {
    paramBitmap.setHasMipMap(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\core\graphics\BitmapCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */