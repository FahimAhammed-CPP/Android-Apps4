package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class PathParser {
  private static final String LOGTAG = "PathParser";
  
  private static void addNode(ArrayList<PathDataNode> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new PathDataNode(paramChar, paramArrayOffloat));
  }
  
  public static boolean canMorph(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    if (paramArrayOfPathDataNode1 != null) {
      if (paramArrayOfPathDataNode2 == null)
        return false; 
      if (paramArrayOfPathDataNode1.length != paramArrayOfPathDataNode2.length)
        return false; 
      int i = 0;
      while (i < paramArrayOfPathDataNode1.length) {
        if ((paramArrayOfPathDataNode1[i]).mType == (paramArrayOfPathDataNode2[i]).mType) {
          if ((paramArrayOfPathDataNode1[i]).mParams.length != (paramArrayOfPathDataNode2[i]).mParams.length)
            return false; 
          i++;
          continue;
        } 
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  static float[] copyOfRange(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        paramInt2 -= paramInt1;
        i = Math.min(paramInt2, i - paramInt1);
        float[] arrayOfFloat = new float[paramInt2];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, i);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  public static PathDataNode[] createNodesFromPathData(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<PathDataNode> arrayList = new ArrayList();
    int j = 1;
    int i = 0;
    while (j < paramString.length()) {
      j = nextStart(paramString, j);
      String str = paramString.substring(i, j).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = getFloats(str);
        addNode(arrayList, str.charAt(0), arrayOfFloat);
      } 
      i = j;
      j++;
    } 
    if (j - i == 1 && i < paramString.length())
      addNode(arrayList, paramString.charAt(i), new float[0]); 
    return arrayList.<PathDataNode>toArray(new PathDataNode[arrayList.size()]);
  }
  
  public static Path createPathFromPathData(String paramString) {
    Path path = new Path();
    PathDataNode[] arrayOfPathDataNode = createNodesFromPathData(paramString);
    if (arrayOfPathDataNode != null)
      try {
        PathDataNode.nodesToPath(arrayOfPathDataNode, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static PathDataNode[] deepCopyNodes(PathDataNode[] paramArrayOfPathDataNode) {
    if (paramArrayOfPathDataNode == null)
      return null; 
    PathDataNode[] arrayOfPathDataNode = new PathDataNode[paramArrayOfPathDataNode.length];
    for (int i = 0; i < paramArrayOfPathDataNode.length; i++)
      arrayOfPathDataNode[i] = new PathDataNode(paramArrayOfPathDataNode[i]); 
    return arrayOfPathDataNode;
  }
  
  private static void extract(String paramString, int paramInt, ExtractFloatResult paramExtractFloatResult) {
    paramExtractFloatResult.mEndWithNegOrDot = false;
    int i = paramInt;
    boolean bool1 = false;
    boolean bool3 = false;
    boolean bool2 = false;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != ' ') {
        if (c != 'E' && c != 'e') {
          switch (c) {
            default:
              bool1 = false;
              break;
            case '.':
              if (!bool3) {
                bool1 = false;
                bool3 = true;
                break;
              } 
              paramExtractFloatResult.mEndWithNegOrDot = true;
            case '-':
            
            case ',':
              bool1 = false;
              bool2 = true;
              break;
          } 
        } else {
          bool1 = true;
        } 
        if (bool2)
          break; 
        continue;
      } 
      i++;
    } 
    paramExtractFloatResult.mEndPosition = i;
  }
  
  private static float[] getFloats(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      float[] arrayOfFloat = new float[paramString.length()];
      ExtractFloatResult extractFloatResult = new ExtractFloatResult();
      int k = paramString.length();
      int i = 1;
      for (int j = 0;; j = m) {
        int m;
        int n;
        if (i < k) {
          extract(paramString, i, extractFloatResult);
          n = extractFloatResult.mEndPosition;
          m = j;
          if (i < n) {
            arrayOfFloat[j] = Float.parseFloat(paramString.substring(i, n));
            m = j + 1;
          } 
          if (extractFloatResult.mEndWithNegOrDot) {
            i = n;
            j = m;
            continue;
          } 
        } else {
          return copyOfRange(arrayOfFloat, 0, j);
        } 
        i = n + 1;
      } 
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  public static boolean interpolatePathDataNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2, PathDataNode[] paramArrayOfPathDataNode3, float paramFloat) {
    if (paramArrayOfPathDataNode1 != null && paramArrayOfPathDataNode2 != null && paramArrayOfPathDataNode3 != null) {
      if (paramArrayOfPathDataNode1.length == paramArrayOfPathDataNode2.length && paramArrayOfPathDataNode2.length == paramArrayOfPathDataNode3.length) {
        boolean bool = canMorph(paramArrayOfPathDataNode2, paramArrayOfPathDataNode3);
        int i = 0;
        if (!bool)
          return false; 
        while (i < paramArrayOfPathDataNode1.length) {
          paramArrayOfPathDataNode1[i].interpolatePathDataNode(paramArrayOfPathDataNode2[i], paramArrayOfPathDataNode3[i], paramFloat);
          i++;
        } 
        return true;
      } 
      throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
    } 
    throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
  }
  
  private static int nextStart(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  public static void updateNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    for (int i = 0; i < paramArrayOfPathDataNode2.length; i++) {
      (paramArrayOfPathDataNode1[i]).mType = (paramArrayOfPathDataNode2[i]).mType;
      for (int j = 0; j < (paramArrayOfPathDataNode2[i]).mParams.length; j++)
        (paramArrayOfPathDataNode1[i]).mParams[j] = (paramArrayOfPathDataNode2[i]).mParams[j]; 
    } 
  }
  
  private static class ExtractFloatResult {
    int mEndPosition;
    
    boolean mEndWithNegOrDot;
  }
  
  public static class PathDataNode {
    public float[] mParams;
    
    public char mType;
    
    PathDataNode(char param1Char, float[] param1ArrayOffloat) {
      this.mType = param1Char;
      this.mParams = param1ArrayOffloat;
    }
    
    PathDataNode(PathDataNode param1PathDataNode) {
      this.mType = param1PathDataNode.mType;
      float[] arrayOfFloat = param1PathDataNode.mParams;
      this.mParams = PathParser.copyOfRange(arrayOfFloat, 0, arrayOfFloat.length);
    }
    
    private static void addCommand(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: faload
      //   3: fstore #11
      //   5: aload_1
      //   6: iconst_1
      //   7: faload
      //   8: fstore #12
      //   10: aload_1
      //   11: iconst_2
      //   12: faload
      //   13: fstore #13
      //   15: aload_1
      //   16: iconst_3
      //   17: faload
      //   18: fstore #14
      //   20: aload_1
      //   21: iconst_4
      //   22: faload
      //   23: fstore #10
      //   25: aload_1
      //   26: iconst_5
      //   27: faload
      //   28: fstore #9
      //   30: fload #11
      //   32: fstore #5
      //   34: fload #12
      //   36: fstore #6
      //   38: fload #13
      //   40: fstore #7
      //   42: fload #14
      //   44: fstore #8
      //   46: iload_3
      //   47: lookupswitch default -> 216, 65 -> 336, 67 -> 313, 72 -> 291, 76 -> 232, 77 -> 232, 81 -> 269, 83 -> 269, 84 -> 232, 86 -> 291, 90 -> 238, 97 -> 336, 99 -> 313, 104 -> 291, 108 -> 232, 109 -> 232, 113 -> 269, 115 -> 269, 116 -> 232, 118 -> 291, 122 -> 238
      //   216: fload #14
      //   218: fstore #8
      //   220: fload #13
      //   222: fstore #7
      //   224: fload #12
      //   226: fstore #6
      //   228: fload #11
      //   230: fstore #5
      //   232: iconst_2
      //   233: istore #15
      //   235: goto -> 356
      //   238: aload_0
      //   239: invokevirtual close : ()V
      //   242: aload_0
      //   243: fload #10
      //   245: fload #9
      //   247: invokevirtual moveTo : (FF)V
      //   250: fload #10
      //   252: fstore #5
      //   254: fload #5
      //   256: fstore #7
      //   258: fload #9
      //   260: fstore #6
      //   262: fload #6
      //   264: fstore #8
      //   266: goto -> 232
      //   269: iconst_4
      //   270: istore #15
      //   272: fload #11
      //   274: fstore #5
      //   276: fload #12
      //   278: fstore #6
      //   280: fload #13
      //   282: fstore #7
      //   284: fload #14
      //   286: fstore #8
      //   288: goto -> 356
      //   291: iconst_1
      //   292: istore #15
      //   294: fload #11
      //   296: fstore #5
      //   298: fload #12
      //   300: fstore #6
      //   302: fload #13
      //   304: fstore #7
      //   306: fload #14
      //   308: fstore #8
      //   310: goto -> 356
      //   313: bipush #6
      //   315: istore #15
      //   317: fload #11
      //   319: fstore #5
      //   321: fload #12
      //   323: fstore #6
      //   325: fload #13
      //   327: fstore #7
      //   329: fload #14
      //   331: fstore #8
      //   333: goto -> 356
      //   336: bipush #7
      //   338: istore #15
      //   340: fload #14
      //   342: fstore #8
      //   344: fload #13
      //   346: fstore #7
      //   348: fload #12
      //   350: fstore #6
      //   352: fload #11
      //   354: fstore #5
      //   356: iconst_0
      //   357: istore #17
      //   359: iload_2
      //   360: istore #16
      //   362: fload #9
      //   364: fstore #11
      //   366: fload #10
      //   368: fstore #12
      //   370: iload #17
      //   372: istore_2
      //   373: iload_3
      //   374: istore #17
      //   376: iload_2
      //   377: aload #4
      //   379: arraylength
      //   380: if_icmpge -> 2115
      //   383: iload #17
      //   385: bipush #65
      //   387: if_icmpeq -> 1961
      //   390: iload #17
      //   392: bipush #67
      //   394: if_icmpeq -> 1845
      //   397: iload #17
      //   399: bipush #72
      //   401: if_icmpeq -> 1819
      //   404: iload #17
      //   406: bipush #81
      //   408: if_icmpeq -> 1725
      //   411: iload #17
      //   413: bipush #86
      //   415: if_icmpeq -> 1699
      //   418: iload #17
      //   420: bipush #97
      //   422: if_icmpeq -> 1559
      //   425: iload #17
      //   427: bipush #99
      //   429: if_icmpeq -> 1416
      //   432: iload #17
      //   434: bipush #104
      //   436: if_icmpeq -> 1388
      //   439: iload #17
      //   441: bipush #113
      //   443: if_icmpeq -> 1288
      //   446: iload #17
      //   448: bipush #118
      //   450: if_icmpeq -> 1263
      //   453: iload #17
      //   455: bipush #76
      //   457: if_icmpeq -> 1218
      //   460: iload #17
      //   462: bipush #77
      //   464: if_icmpeq -> 1168
      //   467: iload #17
      //   469: bipush #83
      //   471: if_icmpeq -> 1023
      //   474: iload #17
      //   476: bipush #84
      //   478: if_icmpeq -> 912
      //   481: iload #17
      //   483: bipush #108
      //   485: if_icmpeq -> 857
      //   488: iload #17
      //   490: bipush #109
      //   492: if_icmpeq -> 801
      //   495: iload #17
      //   497: bipush #115
      //   499: if_icmpeq -> 643
      //   502: iload #17
      //   504: bipush #116
      //   506: if_icmpeq -> 512
      //   509: goto -> 2104
      //   512: iload #16
      //   514: bipush #113
      //   516: if_icmpeq -> 552
      //   519: iload #16
      //   521: bipush #116
      //   523: if_icmpeq -> 552
      //   526: iload #16
      //   528: bipush #81
      //   530: if_icmpeq -> 552
      //   533: iload #16
      //   535: bipush #84
      //   537: if_icmpne -> 543
      //   540: goto -> 552
      //   543: fconst_0
      //   544: fstore #8
      //   546: fconst_0
      //   547: fstore #7
      //   549: goto -> 566
      //   552: fload #5
      //   554: fload #7
      //   556: fsub
      //   557: fstore #7
      //   559: fload #6
      //   561: fload #8
      //   563: fsub
      //   564: fstore #8
      //   566: iload_2
      //   567: iconst_0
      //   568: iadd
      //   569: istore #16
      //   571: aload #4
      //   573: iload #16
      //   575: faload
      //   576: fstore #9
      //   578: iload_2
      //   579: iconst_1
      //   580: iadd
      //   581: istore #17
      //   583: aload_0
      //   584: fload #7
      //   586: fload #8
      //   588: fload #9
      //   590: aload #4
      //   592: iload #17
      //   594: faload
      //   595: invokevirtual rQuadTo : (FFFF)V
      //   598: fload #5
      //   600: aload #4
      //   602: iload #16
      //   604: faload
      //   605: fadd
      //   606: fstore #9
      //   608: fload #6
      //   610: aload #4
      //   612: iload #17
      //   614: faload
      //   615: fadd
      //   616: fstore #10
      //   618: fload #8
      //   620: fload #6
      //   622: fadd
      //   623: fstore #8
      //   625: fload #7
      //   627: fload #5
      //   629: fadd
      //   630: fstore #7
      //   632: fload #10
      //   634: fstore #6
      //   636: fload #9
      //   638: fstore #5
      //   640: goto -> 509
      //   643: iload #16
      //   645: bipush #99
      //   647: if_icmpeq -> 683
      //   650: iload #16
      //   652: bipush #115
      //   654: if_icmpeq -> 683
      //   657: iload #16
      //   659: bipush #67
      //   661: if_icmpeq -> 683
      //   664: iload #16
      //   666: bipush #83
      //   668: if_icmpne -> 674
      //   671: goto -> 683
      //   674: fconst_0
      //   675: fstore #7
      //   677: fconst_0
      //   678: fstore #8
      //   680: goto -> 697
      //   683: fload #6
      //   685: fload #8
      //   687: fsub
      //   688: fstore #8
      //   690: fload #5
      //   692: fload #7
      //   694: fsub
      //   695: fstore #7
      //   697: iload_2
      //   698: iconst_0
      //   699: iadd
      //   700: istore #16
      //   702: aload #4
      //   704: iload #16
      //   706: faload
      //   707: fstore #9
      //   709: iload_2
      //   710: iconst_1
      //   711: iadd
      //   712: istore #17
      //   714: aload #4
      //   716: iload #17
      //   718: faload
      //   719: fstore #10
      //   721: iload_2
      //   722: iconst_2
      //   723: iadd
      //   724: istore #18
      //   726: aload #4
      //   728: iload #18
      //   730: faload
      //   731: fstore #13
      //   733: iload_2
      //   734: iconst_3
      //   735: iadd
      //   736: istore #19
      //   738: aload_0
      //   739: fload #7
      //   741: fload #8
      //   743: fload #9
      //   745: fload #10
      //   747: fload #13
      //   749: aload #4
      //   751: iload #19
      //   753: faload
      //   754: invokevirtual rCubicTo : (FFFFFF)V
      //   757: aload #4
      //   759: iload #16
      //   761: faload
      //   762: fload #5
      //   764: fadd
      //   765: fstore #10
      //   767: aload #4
      //   769: iload #17
      //   771: faload
      //   772: fload #6
      //   774: fadd
      //   775: fstore #7
      //   777: fload #5
      //   779: aload #4
      //   781: iload #18
      //   783: faload
      //   784: fadd
      //   785: fstore #8
      //   787: aload #4
      //   789: iload #19
      //   791: faload
      //   792: fstore #9
      //   794: fload #10
      //   796: fstore #5
      //   798: goto -> 1533
      //   801: aload #4
      //   803: iload_2
      //   804: iconst_0
      //   805: iadd
      //   806: faload
      //   807: fstore #9
      //   809: fload #5
      //   811: fload #9
      //   813: fadd
      //   814: fstore #5
      //   816: aload #4
      //   818: iload_2
      //   819: iconst_1
      //   820: iadd
      //   821: faload
      //   822: fstore #10
      //   824: fload #6
      //   826: fload #10
      //   828: fadd
      //   829: fstore #6
      //   831: iload_2
      //   832: ifle -> 846
      //   835: aload_0
      //   836: fload #9
      //   838: fload #10
      //   840: invokevirtual rLineTo : (FF)V
      //   843: goto -> 509
      //   846: aload_0
      //   847: fload #9
      //   849: fload #10
      //   851: invokevirtual rMoveTo : (FF)V
      //   854: goto -> 1207
      //   857: iload_2
      //   858: iconst_0
      //   859: iadd
      //   860: istore #16
      //   862: aload #4
      //   864: iload #16
      //   866: faload
      //   867: fstore #9
      //   869: iload_2
      //   870: iconst_1
      //   871: iadd
      //   872: istore #17
      //   874: aload_0
      //   875: fload #9
      //   877: aload #4
      //   879: iload #17
      //   881: faload
      //   882: invokevirtual rLineTo : (FF)V
      //   885: fload #5
      //   887: aload #4
      //   889: iload #16
      //   891: faload
      //   892: fadd
      //   893: fstore #5
      //   895: aload #4
      //   897: iload #17
      //   899: faload
      //   900: fstore #9
      //   902: fload #6
      //   904: fload #9
      //   906: fadd
      //   907: fstore #6
      //   909: goto -> 509
      //   912: iload #16
      //   914: bipush #113
      //   916: if_icmpeq -> 948
      //   919: iload #16
      //   921: bipush #116
      //   923: if_icmpeq -> 948
      //   926: iload #16
      //   928: bipush #81
      //   930: if_icmpeq -> 948
      //   933: fload #6
      //   935: fstore #10
      //   937: fload #5
      //   939: fstore #9
      //   941: iload #16
      //   943: bipush #84
      //   945: if_icmpne -> 966
      //   948: fload #5
      //   950: fconst_2
      //   951: fmul
      //   952: fload #7
      //   954: fsub
      //   955: fstore #9
      //   957: fload #6
      //   959: fconst_2
      //   960: fmul
      //   961: fload #8
      //   963: fsub
      //   964: fstore #10
      //   966: iload_2
      //   967: iconst_0
      //   968: iadd
      //   969: istore #16
      //   971: aload #4
      //   973: iload #16
      //   975: faload
      //   976: fstore #5
      //   978: iload_2
      //   979: iconst_1
      //   980: iadd
      //   981: istore #17
      //   983: aload_0
      //   984: fload #9
      //   986: fload #10
      //   988: fload #5
      //   990: aload #4
      //   992: iload #17
      //   994: faload
      //   995: invokevirtual quadTo : (FFFF)V
      //   998: aload #4
      //   1000: iload #16
      //   1002: faload
      //   1003: fstore #5
      //   1005: aload #4
      //   1007: iload #17
      //   1009: faload
      //   1010: fstore #6
      //   1012: fload #10
      //   1014: fstore #8
      //   1016: fload #9
      //   1018: fstore #7
      //   1020: goto -> 2104
      //   1023: iload #16
      //   1025: bipush #99
      //   1027: if_icmpeq -> 1059
      //   1030: iload #16
      //   1032: bipush #115
      //   1034: if_icmpeq -> 1059
      //   1037: iload #16
      //   1039: bipush #67
      //   1041: if_icmpeq -> 1059
      //   1044: fload #6
      //   1046: fstore #10
      //   1048: fload #5
      //   1050: fstore #9
      //   1052: iload #16
      //   1054: bipush #83
      //   1056: if_icmpne -> 1077
      //   1059: fload #5
      //   1061: fconst_2
      //   1062: fmul
      //   1063: fload #7
      //   1065: fsub
      //   1066: fstore #9
      //   1068: fload #6
      //   1070: fconst_2
      //   1071: fmul
      //   1072: fload #8
      //   1074: fsub
      //   1075: fstore #10
      //   1077: iload_2
      //   1078: iconst_0
      //   1079: iadd
      //   1080: istore #16
      //   1082: aload #4
      //   1084: iload #16
      //   1086: faload
      //   1087: fstore #5
      //   1089: iload_2
      //   1090: iconst_1
      //   1091: iadd
      //   1092: istore #17
      //   1094: aload #4
      //   1096: iload #17
      //   1098: faload
      //   1099: fstore #6
      //   1101: iload_2
      //   1102: iconst_2
      //   1103: iadd
      //   1104: istore #18
      //   1106: aload #4
      //   1108: iload #18
      //   1110: faload
      //   1111: fstore #7
      //   1113: iload_2
      //   1114: iconst_3
      //   1115: iadd
      //   1116: istore #19
      //   1118: aload_0
      //   1119: fload #9
      //   1121: fload #10
      //   1123: fload #5
      //   1125: fload #6
      //   1127: fload #7
      //   1129: aload #4
      //   1131: iload #19
      //   1133: faload
      //   1134: invokevirtual cubicTo : (FFFFFF)V
      //   1137: aload #4
      //   1139: iload #16
      //   1141: faload
      //   1142: fstore #5
      //   1144: aload #4
      //   1146: iload #17
      //   1148: faload
      //   1149: fstore #7
      //   1151: aload #4
      //   1153: iload #18
      //   1155: faload
      //   1156: fstore #9
      //   1158: aload #4
      //   1160: iload #19
      //   1162: faload
      //   1163: fstore #6
      //   1165: goto -> 1544
      //   1168: aload #4
      //   1170: iload_2
      //   1171: iconst_0
      //   1172: iadd
      //   1173: faload
      //   1174: fstore #5
      //   1176: aload #4
      //   1178: iload_2
      //   1179: iconst_1
      //   1180: iadd
      //   1181: faload
      //   1182: fstore #6
      //   1184: iload_2
      //   1185: ifle -> 1199
      //   1188: aload_0
      //   1189: fload #5
      //   1191: fload #6
      //   1193: invokevirtual lineTo : (FF)V
      //   1196: goto -> 509
      //   1199: aload_0
      //   1200: fload #5
      //   1202: fload #6
      //   1204: invokevirtual moveTo : (FF)V
      //   1207: fload #6
      //   1209: fstore #11
      //   1211: fload #5
      //   1213: fstore #12
      //   1215: goto -> 2104
      //   1218: iload_2
      //   1219: iconst_0
      //   1220: iadd
      //   1221: istore #16
      //   1223: aload #4
      //   1225: iload #16
      //   1227: faload
      //   1228: fstore #5
      //   1230: iload_2
      //   1231: iconst_1
      //   1232: iadd
      //   1233: istore #17
      //   1235: aload_0
      //   1236: fload #5
      //   1238: aload #4
      //   1240: iload #17
      //   1242: faload
      //   1243: invokevirtual lineTo : (FF)V
      //   1246: aload #4
      //   1248: iload #16
      //   1250: faload
      //   1251: fstore #5
      //   1253: aload #4
      //   1255: iload #17
      //   1257: faload
      //   1258: fstore #6
      //   1260: goto -> 509
      //   1263: iload_2
      //   1264: iconst_0
      //   1265: iadd
      //   1266: istore #16
      //   1268: aload_0
      //   1269: fconst_0
      //   1270: aload #4
      //   1272: iload #16
      //   1274: faload
      //   1275: invokevirtual rLineTo : (FF)V
      //   1278: aload #4
      //   1280: iload #16
      //   1282: faload
      //   1283: fstore #9
      //   1285: goto -> 902
      //   1288: iload_2
      //   1289: iconst_0
      //   1290: iadd
      //   1291: istore #16
      //   1293: aload #4
      //   1295: iload #16
      //   1297: faload
      //   1298: fstore #7
      //   1300: iload_2
      //   1301: iconst_1
      //   1302: iadd
      //   1303: istore #17
      //   1305: aload #4
      //   1307: iload #17
      //   1309: faload
      //   1310: fstore #8
      //   1312: iload_2
      //   1313: iconst_2
      //   1314: iadd
      //   1315: istore #18
      //   1317: aload #4
      //   1319: iload #18
      //   1321: faload
      //   1322: fstore #9
      //   1324: iload_2
      //   1325: iconst_3
      //   1326: iadd
      //   1327: istore #19
      //   1329: aload_0
      //   1330: fload #7
      //   1332: fload #8
      //   1334: fload #9
      //   1336: aload #4
      //   1338: iload #19
      //   1340: faload
      //   1341: invokevirtual rQuadTo : (FFFF)V
      //   1344: aload #4
      //   1346: iload #16
      //   1348: faload
      //   1349: fload #5
      //   1351: fadd
      //   1352: fstore #10
      //   1354: aload #4
      //   1356: iload #17
      //   1358: faload
      //   1359: fload #6
      //   1361: fadd
      //   1362: fstore #7
      //   1364: fload #5
      //   1366: aload #4
      //   1368: iload #18
      //   1370: faload
      //   1371: fadd
      //   1372: fstore #8
      //   1374: aload #4
      //   1376: iload #19
      //   1378: faload
      //   1379: fstore #9
      //   1381: fload #10
      //   1383: fstore #5
      //   1385: goto -> 1533
      //   1388: iload_2
      //   1389: iconst_0
      //   1390: iadd
      //   1391: istore #16
      //   1393: aload_0
      //   1394: aload #4
      //   1396: iload #16
      //   1398: faload
      //   1399: fconst_0
      //   1400: invokevirtual rLineTo : (FF)V
      //   1403: fload #5
      //   1405: aload #4
      //   1407: iload #16
      //   1409: faload
      //   1410: fadd
      //   1411: fstore #5
      //   1413: goto -> 509
      //   1416: aload #4
      //   1418: iload_2
      //   1419: iconst_0
      //   1420: iadd
      //   1421: faload
      //   1422: fstore #7
      //   1424: aload #4
      //   1426: iload_2
      //   1427: iconst_1
      //   1428: iadd
      //   1429: faload
      //   1430: fstore #8
      //   1432: iload_2
      //   1433: iconst_2
      //   1434: iadd
      //   1435: istore #16
      //   1437: aload #4
      //   1439: iload #16
      //   1441: faload
      //   1442: fstore #9
      //   1444: iload_2
      //   1445: iconst_3
      //   1446: iadd
      //   1447: istore #17
      //   1449: aload #4
      //   1451: iload #17
      //   1453: faload
      //   1454: fstore #10
      //   1456: iload_2
      //   1457: iconst_4
      //   1458: iadd
      //   1459: istore #18
      //   1461: aload #4
      //   1463: iload #18
      //   1465: faload
      //   1466: fstore #13
      //   1468: iload_2
      //   1469: iconst_5
      //   1470: iadd
      //   1471: istore #19
      //   1473: aload_0
      //   1474: fload #7
      //   1476: fload #8
      //   1478: fload #9
      //   1480: fload #10
      //   1482: fload #13
      //   1484: aload #4
      //   1486: iload #19
      //   1488: faload
      //   1489: invokevirtual rCubicTo : (FFFFFF)V
      //   1492: aload #4
      //   1494: iload #16
      //   1496: faload
      //   1497: fload #5
      //   1499: fadd
      //   1500: fstore #10
      //   1502: aload #4
      //   1504: iload #17
      //   1506: faload
      //   1507: fload #6
      //   1509: fadd
      //   1510: fstore #7
      //   1512: fload #5
      //   1514: aload #4
      //   1516: iload #18
      //   1518: faload
      //   1519: fadd
      //   1520: fstore #8
      //   1522: aload #4
      //   1524: iload #19
      //   1526: faload
      //   1527: fstore #9
      //   1529: fload #10
      //   1531: fstore #5
      //   1533: fload #6
      //   1535: fload #9
      //   1537: fadd
      //   1538: fstore #6
      //   1540: fload #8
      //   1542: fstore #9
      //   1544: fload #7
      //   1546: fstore #8
      //   1548: fload #5
      //   1550: fstore #7
      //   1552: fload #9
      //   1554: fstore #5
      //   1556: goto -> 509
      //   1559: iload_2
      //   1560: iconst_5
      //   1561: iadd
      //   1562: istore #16
      //   1564: aload #4
      //   1566: iload #16
      //   1568: faload
      //   1569: fstore #7
      //   1571: iload_2
      //   1572: bipush #6
      //   1574: iadd
      //   1575: istore #17
      //   1577: aload #4
      //   1579: iload #17
      //   1581: faload
      //   1582: fstore #8
      //   1584: aload #4
      //   1586: iload_2
      //   1587: iconst_0
      //   1588: iadd
      //   1589: faload
      //   1590: fstore #9
      //   1592: aload #4
      //   1594: iload_2
      //   1595: iconst_1
      //   1596: iadd
      //   1597: faload
      //   1598: fstore #10
      //   1600: aload #4
      //   1602: iload_2
      //   1603: iconst_2
      //   1604: iadd
      //   1605: faload
      //   1606: fstore #13
      //   1608: aload #4
      //   1610: iload_2
      //   1611: iconst_3
      //   1612: iadd
      //   1613: faload
      //   1614: fconst_0
      //   1615: fcmpl
      //   1616: ifeq -> 1625
      //   1619: iconst_1
      //   1620: istore #20
      //   1622: goto -> 1628
      //   1625: iconst_0
      //   1626: istore #20
      //   1628: aload #4
      //   1630: iload_2
      //   1631: iconst_4
      //   1632: iadd
      //   1633: faload
      //   1634: fconst_0
      //   1635: fcmpl
      //   1636: ifeq -> 1645
      //   1639: iconst_1
      //   1640: istore #21
      //   1642: goto -> 1648
      //   1645: iconst_0
      //   1646: istore #21
      //   1648: aload_0
      //   1649: fload #5
      //   1651: fload #6
      //   1653: fload #7
      //   1655: fload #5
      //   1657: fadd
      //   1658: fload #8
      //   1660: fload #6
      //   1662: fadd
      //   1663: fload #9
      //   1665: fload #10
      //   1667: fload #13
      //   1669: iload #20
      //   1671: iload #21
      //   1673: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   1676: fload #5
      //   1678: aload #4
      //   1680: iload #16
      //   1682: faload
      //   1683: fadd
      //   1684: fstore #5
      //   1686: fload #6
      //   1688: aload #4
      //   1690: iload #17
      //   1692: faload
      //   1693: fadd
      //   1694: fstore #6
      //   1696: goto -> 2096
      //   1699: iload_2
      //   1700: iconst_0
      //   1701: iadd
      //   1702: istore #16
      //   1704: aload_0
      //   1705: fload #5
      //   1707: aload #4
      //   1709: iload #16
      //   1711: faload
      //   1712: invokevirtual lineTo : (FF)V
      //   1715: aload #4
      //   1717: iload #16
      //   1719: faload
      //   1720: fstore #6
      //   1722: goto -> 2104
      //   1725: iload_2
      //   1726: istore #16
      //   1728: iload #16
      //   1730: iconst_0
      //   1731: iadd
      //   1732: istore #17
      //   1734: aload #4
      //   1736: iload #17
      //   1738: faload
      //   1739: fstore #5
      //   1741: iload #16
      //   1743: iconst_1
      //   1744: iadd
      //   1745: istore #18
      //   1747: aload #4
      //   1749: iload #18
      //   1751: faload
      //   1752: fstore #6
      //   1754: iload #16
      //   1756: iconst_2
      //   1757: iadd
      //   1758: istore #19
      //   1760: aload #4
      //   1762: iload #19
      //   1764: faload
      //   1765: fstore #7
      //   1767: iload #16
      //   1769: iconst_3
      //   1770: iadd
      //   1771: istore #16
      //   1773: aload_0
      //   1774: fload #5
      //   1776: fload #6
      //   1778: fload #7
      //   1780: aload #4
      //   1782: iload #16
      //   1784: faload
      //   1785: invokevirtual quadTo : (FFFF)V
      //   1788: aload #4
      //   1790: iload #17
      //   1792: faload
      //   1793: fstore #7
      //   1795: aload #4
      //   1797: iload #18
      //   1799: faload
      //   1800: fstore #8
      //   1802: aload #4
      //   1804: iload #19
      //   1806: faload
      //   1807: fstore #5
      //   1809: aload #4
      //   1811: iload #16
      //   1813: faload
      //   1814: fstore #6
      //   1816: goto -> 2104
      //   1819: iload_2
      //   1820: iconst_0
      //   1821: iadd
      //   1822: istore #16
      //   1824: aload_0
      //   1825: aload #4
      //   1827: iload #16
      //   1829: faload
      //   1830: fload #6
      //   1832: invokevirtual lineTo : (FF)V
      //   1835: aload #4
      //   1837: iload #16
      //   1839: faload
      //   1840: fstore #5
      //   1842: goto -> 2104
      //   1845: iload_2
      //   1846: istore #16
      //   1848: aload #4
      //   1850: iload #16
      //   1852: iconst_0
      //   1853: iadd
      //   1854: faload
      //   1855: fstore #5
      //   1857: aload #4
      //   1859: iload #16
      //   1861: iconst_1
      //   1862: iadd
      //   1863: faload
      //   1864: fstore #6
      //   1866: iload #16
      //   1868: iconst_2
      //   1869: iadd
      //   1870: istore #17
      //   1872: aload #4
      //   1874: iload #17
      //   1876: faload
      //   1877: fstore #7
      //   1879: iload #16
      //   1881: iconst_3
      //   1882: iadd
      //   1883: istore #18
      //   1885: aload #4
      //   1887: iload #18
      //   1889: faload
      //   1890: fstore #8
      //   1892: iload #16
      //   1894: iconst_4
      //   1895: iadd
      //   1896: istore #19
      //   1898: aload #4
      //   1900: iload #19
      //   1902: faload
      //   1903: fstore #9
      //   1905: iload #16
      //   1907: iconst_5
      //   1908: iadd
      //   1909: istore #16
      //   1911: aload_0
      //   1912: fload #5
      //   1914: fload #6
      //   1916: fload #7
      //   1918: fload #8
      //   1920: fload #9
      //   1922: aload #4
      //   1924: iload #16
      //   1926: faload
      //   1927: invokevirtual cubicTo : (FFFFFF)V
      //   1930: aload #4
      //   1932: iload #19
      //   1934: faload
      //   1935: fstore #5
      //   1937: aload #4
      //   1939: iload #16
      //   1941: faload
      //   1942: fstore #6
      //   1944: aload #4
      //   1946: iload #17
      //   1948: faload
      //   1949: fstore #7
      //   1951: aload #4
      //   1953: iload #18
      //   1955: faload
      //   1956: fstore #8
      //   1958: goto -> 2104
      //   1961: iload_2
      //   1962: istore #16
      //   1964: iload #16
      //   1966: iconst_5
      //   1967: iadd
      //   1968: istore #17
      //   1970: aload #4
      //   1972: iload #17
      //   1974: faload
      //   1975: fstore #7
      //   1977: iload #16
      //   1979: bipush #6
      //   1981: iadd
      //   1982: istore #18
      //   1984: aload #4
      //   1986: iload #18
      //   1988: faload
      //   1989: fstore #8
      //   1991: aload #4
      //   1993: iload #16
      //   1995: iconst_0
      //   1996: iadd
      //   1997: faload
      //   1998: fstore #9
      //   2000: aload #4
      //   2002: iload #16
      //   2004: iconst_1
      //   2005: iadd
      //   2006: faload
      //   2007: fstore #10
      //   2009: aload #4
      //   2011: iload #16
      //   2013: iconst_2
      //   2014: iadd
      //   2015: faload
      //   2016: fstore #13
      //   2018: aload #4
      //   2020: iload #16
      //   2022: iconst_3
      //   2023: iadd
      //   2024: faload
      //   2025: fconst_0
      //   2026: fcmpl
      //   2027: ifeq -> 2036
      //   2030: iconst_1
      //   2031: istore #20
      //   2033: goto -> 2039
      //   2036: iconst_0
      //   2037: istore #20
      //   2039: aload #4
      //   2041: iload #16
      //   2043: iconst_4
      //   2044: iadd
      //   2045: faload
      //   2046: fconst_0
      //   2047: fcmpl
      //   2048: ifeq -> 2057
      //   2051: iconst_1
      //   2052: istore #21
      //   2054: goto -> 2060
      //   2057: iconst_0
      //   2058: istore #21
      //   2060: aload_0
      //   2061: fload #5
      //   2063: fload #6
      //   2065: fload #7
      //   2067: fload #8
      //   2069: fload #9
      //   2071: fload #10
      //   2073: fload #13
      //   2075: iload #20
      //   2077: iload #21
      //   2079: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   2082: aload #4
      //   2084: iload #17
      //   2086: faload
      //   2087: fstore #5
      //   2089: aload #4
      //   2091: iload #18
      //   2093: faload
      //   2094: fstore #6
      //   2096: fload #6
      //   2098: fstore #8
      //   2100: fload #5
      //   2102: fstore #7
      //   2104: iload_2
      //   2105: iload #15
      //   2107: iadd
      //   2108: istore_2
      //   2109: iload_3
      //   2110: istore #16
      //   2112: goto -> 373
      //   2115: aload_1
      //   2116: iconst_0
      //   2117: fload #5
      //   2119: fastore
      //   2120: aload_1
      //   2121: iconst_1
      //   2122: fload #6
      //   2124: fastore
      //   2125: aload_1
      //   2126: iconst_2
      //   2127: fload #7
      //   2129: fastore
      //   2130: aload_1
      //   2131: iconst_3
      //   2132: fload #8
      //   2134: fastore
      //   2135: aload_1
      //   2136: iconst_4
      //   2137: fload #12
      //   2139: fastore
      //   2140: aload_1
      //   2141: iconst_5
      //   2142: fload #11
      //   2144: fastore
      //   2145: return
    }
    
    private static void arcToBezier(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d4 = Math.cos(param1Double7);
      double d5 = Math.sin(param1Double7);
      double d2 = Math.cos(param1Double8);
      double d3 = Math.sin(param1Double8);
      param1Double7 = -param1Double3;
      double d7 = param1Double7 * d4;
      double d8 = param1Double4 * d5;
      param1Double7 *= d5;
      double d9 = param1Double4 * d4;
      double d6 = param1Double9 / i;
      double d1 = d3 * param1Double7 + d2 * d9;
      d2 = d7 * d3 - d8 * d2;
      int j = 0;
      d3 = param1Double8;
      param1Double9 = param1Double6;
      param1Double4 = param1Double7;
      param1Double8 = param1Double5;
      param1Double7 = d6;
      param1Double6 = d5;
      param1Double5 = d4;
      while (true) {
        d4 = param1Double3;
        if (j < i) {
          d6 = d3 + param1Double7;
          double d10 = Math.sin(d6);
          double d12 = Math.cos(d6);
          double d11 = param1Double1 + d4 * param1Double5 * d12 - d8 * d10;
          d4 = param1Double2 + d4 * param1Double6 * d12 + d9 * d10;
          d5 = d7 * d10 - d8 * d12;
          d10 = d10 * param1Double4 + d12 * d9;
          d3 = d6 - d3;
          d12 = Math.tan(d3 / 2.0D);
          d3 = Math.sin(d3) * (Math.sqrt(d12 * 3.0D * d12 + 4.0D) - 1.0D) / 3.0D;
          param1Path.rLineTo(0.0F, 0.0F);
          param1Path.cubicTo((float)(param1Double8 + d2 * d3), (float)(param1Double9 + d1 * d3), (float)(d11 - d3 * d5), (float)(d4 - d3 * d10), (float)d11, (float)d4);
          j++;
          param1Double8 = d11;
          d3 = d6;
          d1 = d10;
          d2 = d5;
          param1Double9 = d4;
          continue;
        } 
        break;
      } 
    }
    
    private static void drawArc(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d5 = Math.toRadians(param1Float7);
      double d6 = Math.cos(d5);
      double d7 = Math.sin(d5);
      double d8 = param1Float1;
      double d9 = param1Float2;
      double d10 = param1Float5;
      double d1 = (d8 * d6 + d9 * d7) / d10;
      double d2 = -param1Float1;
      double d11 = param1Float6;
      double d4 = (d2 * d7 + d9 * d6) / d11;
      double d3 = param1Float3;
      d2 = param1Float4;
      double d12 = (d3 * d6 + d2 * d7) / d10;
      double d13 = (-param1Float3 * d7 + d2 * d6) / d11;
      double d15 = d1 - d12;
      double d14 = d4 - d13;
      d3 = (d1 + d12) / 2.0D;
      d2 = (d4 + d13) / 2.0D;
      double d16 = d15 * d15 + d14 * d14;
      if (d16 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d17 = 1.0D / d16 - 0.25D;
      if (d17 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder("Points are too far apart ");
        stringBuilder.append(d16);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d16) / 1.99999D);
        drawArc(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      d16 = Math.sqrt(d17);
      d15 *= d16;
      d14 = d16 * d14;
      if (param1Boolean1 == param1Boolean2) {
        d3 -= d14;
        d2 += d15;
      } else {
        d3 += d14;
        d2 -= d15;
      } 
      d14 = Math.atan2(d4 - d2, d1 - d3);
      d4 = Math.atan2(d13 - d2, d12 - d3) - d14;
      int i = d4 cmp 0.0D;
      if (i >= 0) {
        param1Boolean1 = true;
      } else {
        param1Boolean1 = false;
      } 
      d1 = d4;
      if (param1Boolean2 != param1Boolean1)
        if (i > 0) {
          d1 = d4 - 6.283185307179586D;
        } else {
          d1 = d4 + 6.283185307179586D;
        }  
      d3 *= d10;
      d2 *= d11;
      arcToBezier(param1Path, d3 * d6 - d2 * d7, d3 * d7 + d2 * d6, d10, d11, d8, d9, d5, d14, d1);
    }
    
    public static void nodesToPath(PathDataNode[] param1ArrayOfPathDataNode, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c = 'm';
      for (int i = 0; i < param1ArrayOfPathDataNode.length; i++) {
        PathDataNode pathDataNode = param1ArrayOfPathDataNode[i];
        addCommand(param1Path, arrayOfFloat, c, pathDataNode.mType, pathDataNode.mParams);
        c = (param1ArrayOfPathDataNode[i]).mType;
      } 
    }
    
    public void interpolatePathDataNode(PathDataNode param1PathDataNode1, PathDataNode param1PathDataNode2, float param1Float) {
      this.mType = param1PathDataNode1.mType;
      int i = 0;
      while (true) {
        float[] arrayOfFloat = param1PathDataNode1.mParams;
        if (i < arrayOfFloat.length) {
          this.mParams[i] = arrayOfFloat[i] * (1.0F - param1Float) + param1PathDataNode2.mParams[i] * param1Float;
          i++;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\core\graphics\PathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */