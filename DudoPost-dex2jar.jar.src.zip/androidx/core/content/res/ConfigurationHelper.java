package androidx.core.content.res;

import android.content.res.Resources;

public final class ConfigurationHelper {
  public static int getDensityDpi(Resources paramResources) {
    return (paramResources.getConfiguration()).densityDpi;
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\core\content\res\ConfigurationHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */