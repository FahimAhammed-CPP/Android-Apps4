package androidx.browser.trusted.splashscreens;

public final class SplashScreenVersion {
  public static final String V1 = "androidx.browser.trusted.category.TrustedWebActivitySplashScreensV1";
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\browser\trusted\splashscreens\SplashScreenVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */