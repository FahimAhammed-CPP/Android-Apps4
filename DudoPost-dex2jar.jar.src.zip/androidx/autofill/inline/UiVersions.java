package androidx.autofill.inline;

import android.app.slice.Slice;
import android.os.Bundle;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class UiVersions {
  public static final String INLINE_UI_VERSION_1 = "androidx.autofill.inline.ui.version:v1";
  
  private static final Set<String> UI_VERSIONS = new HashSet<String>(Arrays.asList(new String[] { "androidx.autofill.inline.ui.version:v1" }));
  
  public static Set<String> getUiVersions() {
    return UI_VERSIONS;
  }
  
  public static List<String> getVersions(Bundle paramBundle) {
    return VersionUtils.getSupportedVersions(paramBundle);
  }
  
  public static StylesBuilder newStylesBuilder() {
    return new StylesBuilder();
  }
  
  public static interface Content {
    Slice getSlice();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface InlineUiVersion {}
  
  public static interface Style {
    Bundle getBundle();
    
    String getVersion();
  }
  
  public static final class StylesBuilder {
    private final List<UiVersions.Style> mStyles = new ArrayList<UiVersions.Style>();
    
    public StylesBuilder addStyle(UiVersions.Style param1Style) {
      if (VersionUtils.isVersionSupported(param1Style.getVersion())) {
        this.mStyles.add(param1Style);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder("Unsupported style version: ");
      stringBuilder.append(param1Style.getVersion());
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Bundle build() {
      if (!this.mStyles.isEmpty()) {
        Bundle bundle = new Bundle();
        VersionUtils.writeStylesToBundle(this.mStyles, bundle);
        return bundle;
      } 
      throw new IllegalStateException("Please put at least one style in the builder");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\UiVersions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */