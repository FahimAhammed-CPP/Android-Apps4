package androidx.autofill.inline.v1;

import android.app.PendingIntent;
import android.app.slice.Slice;
import android.app.slice.SliceItem;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.autofill.R;
import androidx.autofill.inline.UiVersions;
import androidx.autofill.inline.common.BundledStyle;
import androidx.autofill.inline.common.ImageViewStyle;
import androidx.autofill.inline.common.SlicedContent;
import androidx.autofill.inline.common.TextViewStyle;
import androidx.autofill.inline.common.ViewStyle;
import java.util.Collections;
import java.util.List;

public final class InlineSuggestionUi {
  private static final String TAG = "InlineSuggestionUi";
  
  public static Style fromBundle(Bundle paramBundle) {
    Style style = new Style(paramBundle);
    if (!style.isValid()) {
      Log.w("InlineSuggestionUi", "Invalid style for androidx.autofill.inline.ui.version:v1");
      return null;
    } 
    return style;
  }
  
  public static Content fromSlice(Slice paramSlice) {
    Content content = new Content(paramSlice);
    if (!content.isValid()) {
      Log.w("InlineSuggestionUi", "Invalid content for androidx.autofill.inline.ui.version:v1");
      return null;
    } 
    return content;
  }
  
  public static PendingIntent getAttributionIntent(Content paramContent) {
    return paramContent.getAttributionIntent();
  }
  
  private static Context getDefaultContextThemeWrapper(Context paramContext) {
    Resources.Theme theme = paramContext.getResources().newTheme();
    theme.applyStyle(R.style.Theme_AutofillInlineSuggestion, true);
    return (Context)new ContextThemeWrapper(paramContext, theme);
  }
  
  public static Content.Builder newContentBuilder(PendingIntent paramPendingIntent) {
    return new Content.Builder(paramPendingIntent);
  }
  
  public static Style.Builder newStyleBuilder() {
    return new Style.Builder();
  }
  
  public static View render(Context paramContext, Content paramContent, Style paramStyle) {
    ViewGroup viewGroup = (ViewGroup)LayoutInflater.from(getDefaultContextThemeWrapper(paramContext)).inflate(R.layout.autofill_inline_suggestion, null);
    ImageView imageView1 = (ImageView)viewGroup.findViewById(R.id.autofill_inline_suggestion_start_icon);
    TextView textView1 = (TextView)viewGroup.findViewById(R.id.autofill_inline_suggestion_title);
    TextView textView2 = (TextView)viewGroup.findViewById(R.id.autofill_inline_suggestion_subtitle);
    ImageView imageView2 = (ImageView)viewGroup.findViewById(R.id.autofill_inline_suggestion_end_icon);
    CharSequence charSequence2 = paramContent.getTitle();
    if (charSequence2 != null) {
      textView1.setText(charSequence2);
      textView1.setVisibility(0);
    } 
    charSequence2 = paramContent.getSubtitle();
    if (charSequence2 != null) {
      textView2.setText(charSequence2);
      textView2.setVisibility(0);
    } 
    Icon icon = paramContent.getStartIcon();
    if (icon != null) {
      imageView1.setImageIcon(icon);
      imageView1.setVisibility(0);
    } 
    icon = paramContent.getEndIcon();
    if (icon != null) {
      imageView2.setImageIcon(icon);
      imageView2.setVisibility(0);
    } 
    CharSequence charSequence1 = paramContent.getContentDescription();
    if (!TextUtils.isEmpty(charSequence1))
      viewGroup.setContentDescription(charSequence1); 
    if (paramStyle.isValid()) {
      if (paramContent.isSingleIconOnly()) {
        paramStyle.applyStyle((View)viewGroup, imageView1);
        return (View)viewGroup;
      } 
      paramStyle.applyStyle((View)viewGroup, imageView1, textView1, textView2, imageView2);
    } 
    return (View)viewGroup;
  }
  
  public static final class Content extends SlicedContent {
    static final String HINT_INLINE_ATTRIBUTION_INTENT = "inline_attribution";
    
    static final String HINT_INLINE_CONTENT_DESCRIPTION = "inline_content_description";
    
    static final String HINT_INLINE_END_ICON = "inline_end_icon";
    
    static final String HINT_INLINE_START_ICON = "inline_start_icon";
    
    static final String HINT_INLINE_SUBTITLE = "inline_subtitle";
    
    static final String HINT_INLINE_TITLE = "inline_title";
    
    private PendingIntent mAttributionIntent;
    
    private CharSequence mContentDescription;
    
    private Icon mEndIcon;
    
    private Icon mStartIcon;
    
    private CharSequence mSubtitle;
    
    private CharSequence mTitle;
    
    Content(Slice param1Slice) {
      super(param1Slice);
      for (SliceItem sliceItem : param1Slice.getItems()) {
        String str = itemType(sliceItem);
        if (str == null)
          continue; 
        str.hashCode();
        int i = str.hashCode();
        byte b = -1;
        switch (i) {
          case 1994860611:
            if (!str.equals("inline_end_icon"))
              break; 
            b = 5;
            break;
          case 1020097497:
            if (!str.equals("inline_attribution"))
              break; 
            b = 4;
            break;
          case 729157938:
            if (!str.equals("inline_title"))
              break; 
            b = 3;
            break;
          case -145102948:
            if (!str.equals("inline_start_icon"))
              break; 
            b = 2;
            break;
          case -1269099888:
            if (!str.equals("inline_content_description"))
              break; 
            b = 1;
            break;
          case -1790855426:
            if (!str.equals("inline_subtitle"))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            continue;
          case 5:
            this.mEndIcon = sliceItem.getIcon();
            continue;
          case 4:
            this.mAttributionIntent = sliceItem.getAction();
            continue;
          case 3:
            this.mTitle = sliceItem.getText().toString();
            continue;
          case 2:
            this.mStartIcon = sliceItem.getIcon();
            continue;
          case 1:
            this.mContentDescription = sliceItem.getText();
            continue;
          case 0:
            break;
        } 
        this.mSubtitle = sliceItem.getText().toString();
      } 
    }
    
    private static String itemType(SliceItem param1SliceItem) {
      String str = param1SliceItem.getFormat();
      str.hashCode();
      int i = str.hashCode();
      byte b = -1;
      switch (i) {
        case 100313435:
          if (!str.equals("image"))
            break; 
          b = 2;
          break;
        case 3556653:
          if (!str.equals("text"))
            break; 
          b = 1;
          break;
        case -1422950858:
          if (!str.equals("action"))
            break; 
          b = 0;
          break;
      } 
      switch (b) {
        default:
          return null;
        case 2:
          return (param1SliceItem.getIcon() == null) ? null : (param1SliceItem.getHints().contains("inline_start_icon") ? "inline_start_icon" : (param1SliceItem.getHints().contains("inline_end_icon") ? "inline_end_icon" : null));
        case 1:
          return TextUtils.isEmpty(param1SliceItem.getText()) ? null : (param1SliceItem.getHints().contains("inline_title") ? "inline_title" : (param1SliceItem.getHints().contains("inline_subtitle") ? "inline_subtitle" : (param1SliceItem.getHints().contains("inline_content_description") ? "inline_content_description" : null)));
        case 0:
          break;
      } 
      return (param1SliceItem.getAction() != null && param1SliceItem.getHints().contains("inline_attribution")) ? "inline_attribution" : null;
    }
    
    public PendingIntent getAttributionIntent() {
      return this.mAttributionIntent;
    }
    
    public CharSequence getContentDescription() {
      return this.mContentDescription;
    }
    
    public Icon getEndIcon() {
      return this.mEndIcon;
    }
    
    public Icon getStartIcon() {
      return this.mStartIcon;
    }
    
    public CharSequence getSubtitle() {
      return this.mSubtitle;
    }
    
    public CharSequence getTitle() {
      return this.mTitle;
    }
    
    boolean isSingleIconOnly() {
      return (this.mStartIcon != null && this.mTitle == null && this.mSubtitle == null && this.mEndIcon == null);
    }
    
    public boolean isValid() {
      return "androidx.autofill.inline.ui.version:v1".equals(SlicedContent.getVersion(this.mSlice));
    }
    
    public static final class Builder extends SlicedContent.Builder<Content> {
      private final PendingIntent mAttributionIntent;
      
      private CharSequence mContentDescription;
      
      private Icon mEndIcon;
      
      private List<String> mHints;
      
      private Icon mStartIcon;
      
      private CharSequence mSubtitle;
      
      private CharSequence mTitle;
      
      Builder(PendingIntent param2PendingIntent) {
        super("androidx.autofill.inline.ui.version:v1");
        this.mAttributionIntent = param2PendingIntent;
      }
      
      public InlineSuggestionUi.Content build() {
        CharSequence charSequence = this.mTitle;
        if (charSequence != null || this.mStartIcon != null || this.mEndIcon != null || this.mSubtitle != null) {
          if (charSequence != null || this.mSubtitle == null) {
            if (this.mAttributionIntent != null) {
              if (this.mStartIcon != null)
                this.mSliceBuilder.addIcon(this.mStartIcon, null, Collections.singletonList("inline_start_icon")); 
              if (this.mTitle != null)
                this.mSliceBuilder.addText(this.mTitle, null, Collections.singletonList("inline_title")); 
              if (this.mSubtitle != null)
                this.mSliceBuilder.addText(this.mSubtitle, null, Collections.singletonList("inline_subtitle")); 
              if (this.mEndIcon != null)
                this.mSliceBuilder.addIcon(this.mEndIcon, null, Collections.singletonList("inline_end_icon")); 
              if (this.mAttributionIntent != null)
                this.mSliceBuilder.addAction(this.mAttributionIntent, (new Slice.Builder(this.mSliceBuilder)).addHints(Collections.singletonList("inline_attribution")).build(), null); 
              if (this.mContentDescription != null)
                this.mSliceBuilder.addText(this.mContentDescription, null, Collections.singletonList("inline_content_description")); 
              if (this.mHints != null)
                this.mSliceBuilder.addHints(this.mHints); 
              return new InlineSuggestionUi.Content(this.mSliceBuilder.build());
            } 
            throw new IllegalStateException("Attribution intent cannot be null.");
          } 
          throw new IllegalStateException("Cannot set the subtitle without setting the title.");
        } 
        throw new IllegalStateException("Title, subtitle, start icon, end icon are all null. Please set value for at least one of them");
      }
      
      public Builder setContentDescription(CharSequence param2CharSequence) {
        this.mContentDescription = param2CharSequence;
        return this;
      }
      
      public Builder setEndIcon(Icon param2Icon) {
        this.mEndIcon = param2Icon;
        return this;
      }
      
      public Builder setHints(List<String> param2List) {
        this.mHints = param2List;
        return this;
      }
      
      public Builder setStartIcon(Icon param2Icon) {
        this.mStartIcon = param2Icon;
        return this;
      }
      
      public Builder setSubtitle(CharSequence param2CharSequence) {
        this.mSubtitle = param2CharSequence;
        return this;
      }
      
      public Builder setTitle(CharSequence param2CharSequence) {
        this.mTitle = param2CharSequence;
        return this;
      }
    }
  }
  
  public static final class Builder extends SlicedContent.Builder<Content> {
    private final PendingIntent mAttributionIntent;
    
    private CharSequence mContentDescription;
    
    private Icon mEndIcon;
    
    private List<String> mHints;
    
    private Icon mStartIcon;
    
    private CharSequence mSubtitle;
    
    private CharSequence mTitle;
    
    Builder(PendingIntent param1PendingIntent) {
      super("androidx.autofill.inline.ui.version:v1");
      this.mAttributionIntent = param1PendingIntent;
    }
    
    public InlineSuggestionUi.Content build() {
      CharSequence charSequence = this.mTitle;
      if (charSequence != null || this.mStartIcon != null || this.mEndIcon != null || this.mSubtitle != null) {
        if (charSequence != null || this.mSubtitle == null) {
          if (this.mAttributionIntent != null) {
            if (this.mStartIcon != null)
              this.mSliceBuilder.addIcon(this.mStartIcon, null, Collections.singletonList("inline_start_icon")); 
            if (this.mTitle != null)
              this.mSliceBuilder.addText(this.mTitle, null, Collections.singletonList("inline_title")); 
            if (this.mSubtitle != null)
              this.mSliceBuilder.addText(this.mSubtitle, null, Collections.singletonList("inline_subtitle")); 
            if (this.mEndIcon != null)
              this.mSliceBuilder.addIcon(this.mEndIcon, null, Collections.singletonList("inline_end_icon")); 
            if (this.mAttributionIntent != null)
              this.mSliceBuilder.addAction(this.mAttributionIntent, (new Slice.Builder(this.mSliceBuilder)).addHints(Collections.singletonList("inline_attribution")).build(), null); 
            if (this.mContentDescription != null)
              this.mSliceBuilder.addText(this.mContentDescription, null, Collections.singletonList("inline_content_description")); 
            if (this.mHints != null)
              this.mSliceBuilder.addHints(this.mHints); 
            return new InlineSuggestionUi.Content(this.mSliceBuilder.build());
          } 
          throw new IllegalStateException("Attribution intent cannot be null.");
        } 
        throw new IllegalStateException("Cannot set the subtitle without setting the title.");
      } 
      throw new IllegalStateException("Title, subtitle, start icon, end icon are all null. Please set value for at least one of them");
    }
    
    public Builder setContentDescription(CharSequence param1CharSequence) {
      this.mContentDescription = param1CharSequence;
      return this;
    }
    
    public Builder setEndIcon(Icon param1Icon) {
      this.mEndIcon = param1Icon;
      return this;
    }
    
    public Builder setHints(List<String> param1List) {
      this.mHints = param1List;
      return this;
    }
    
    public Builder setStartIcon(Icon param1Icon) {
      this.mStartIcon = param1Icon;
      return this;
    }
    
    public Builder setSubtitle(CharSequence param1CharSequence) {
      this.mSubtitle = param1CharSequence;
      return this;
    }
    
    public Builder setTitle(CharSequence param1CharSequence) {
      this.mTitle = param1CharSequence;
      return this;
    }
  }
  
  public static final class Style extends BundledStyle implements UiVersions.Style {
    private static final String KEY_CHIP_STYLE = "chip_style";
    
    private static final String KEY_END_ICON_STYLE = "end_icon_style";
    
    private static final String KEY_LAYOUT_DIRECTION = "layout_direction";
    
    private static final String KEY_SINGLE_ICON_CHIP_ICON_STYLE = "single_icon_chip_icon_style";
    
    private static final String KEY_SINGLE_ICON_CHIP_STYLE = "single_icon_chip_style";
    
    private static final String KEY_START_ICON_STYLE = "start_icon_style";
    
    private static final String KEY_STYLE_V1 = "style_v1";
    
    private static final String KEY_SUBTITLE_STYLE = "subtitle_style";
    
    private static final String KEY_TITLE_STYLE = "title_style";
    
    Style(Bundle param1Bundle) {
      super(param1Bundle);
    }
    
    public void applyStyle(View param1View, ImageView param1ImageView) {
      if (!isValid())
        return; 
      param1View.setLayoutDirection(getLayoutDirection());
      if (param1ImageView.getVisibility() != 8) {
        ImageViewStyle imageViewStyle2 = getSingleIconChipIconStyle();
        ImageViewStyle imageViewStyle1 = imageViewStyle2;
        if (imageViewStyle2 == null)
          imageViewStyle1 = getStartIconStyle(); 
        if (imageViewStyle1 != null)
          imageViewStyle1.applyStyleOnImageViewIfValid(param1ImageView); 
      } 
      ViewStyle viewStyle2 = getSingleIconChipStyle();
      ViewStyle viewStyle1 = viewStyle2;
      if (viewStyle2 == null)
        viewStyle1 = getChipStyle(); 
      if (viewStyle1 != null)
        viewStyle1.applyStyleOnViewIfValid(param1View); 
    }
    
    public void applyStyle(View param1View, ImageView param1ImageView1, TextView param1TextView1, TextView param1TextView2, ImageView param1ImageView2) {
      if (!isValid())
        return; 
      param1View.setLayoutDirection(getLayoutDirection());
      if (param1ImageView1.getVisibility() != 8) {
        ImageViewStyle imageViewStyle = getStartIconStyle();
        if (imageViewStyle != null)
          imageViewStyle.applyStyleOnImageViewIfValid(param1ImageView1); 
      } 
      if (param1TextView1.getVisibility() != 8) {
        TextViewStyle textViewStyle = getTitleStyle();
        if (textViewStyle != null)
          textViewStyle.applyStyleOnTextViewIfValid(param1TextView1); 
      } 
      if (param1TextView2.getVisibility() != 8) {
        TextViewStyle textViewStyle = getSubtitleStyle();
        if (textViewStyle != null)
          textViewStyle.applyStyleOnTextViewIfValid(param1TextView2); 
      } 
      if (param1ImageView2.getVisibility() != 8) {
        ImageViewStyle imageViewStyle = getEndIconStyle();
        if (imageViewStyle != null)
          imageViewStyle.applyStyleOnImageViewIfValid(param1ImageView2); 
      } 
      ViewStyle viewStyle = getChipStyle();
      if (viewStyle != null)
        viewStyle.applyStyleOnViewIfValid(param1View); 
    }
    
    public ViewStyle getChipStyle() {
      Bundle bundle = this.mBundle.getBundle("chip_style");
      return (bundle == null) ? null : new ViewStyle(bundle);
    }
    
    public ImageViewStyle getEndIconStyle() {
      Bundle bundle = this.mBundle.getBundle("end_icon_style");
      return (bundle == null) ? null : new ImageViewStyle(bundle);
    }
    
    public int getLayoutDirection() {
      int i = this.mBundle.getInt("layout_direction", 0);
      return (i != 0 && i != 1) ? 0 : i;
    }
    
    public ImageViewStyle getSingleIconChipIconStyle() {
      Bundle bundle = this.mBundle.getBundle("single_icon_chip_icon_style");
      return (bundle == null) ? null : new ImageViewStyle(bundle);
    }
    
    public ViewStyle getSingleIconChipStyle() {
      Bundle bundle = this.mBundle.getBundle("single_icon_chip_style");
      return (bundle == null) ? null : new ViewStyle(bundle);
    }
    
    public ImageViewStyle getStartIconStyle() {
      Bundle bundle = this.mBundle.getBundle("start_icon_style");
      return (bundle == null) ? null : new ImageViewStyle(bundle);
    }
    
    protected String getStyleKey() {
      return "style_v1";
    }
    
    public TextViewStyle getSubtitleStyle() {
      Bundle bundle = this.mBundle.getBundle("subtitle_style");
      return (bundle == null) ? null : new TextViewStyle(bundle);
    }
    
    public TextViewStyle getTitleStyle() {
      Bundle bundle = this.mBundle.getBundle("title_style");
      return (bundle == null) ? null : new TextViewStyle(bundle);
    }
    
    public String getVersion() {
      return "androidx.autofill.inline.ui.version:v1";
    }
    
    public static final class Builder extends BundledStyle.Builder<Style> {
      Builder() {
        super("style_v1");
      }
      
      public InlineSuggestionUi.Style build() {
        return new InlineSuggestionUi.Style(this.mBundle);
      }
      
      public Builder setChipStyle(ViewStyle param2ViewStyle) {
        param2ViewStyle.assertIsValid();
        this.mBundle.putBundle("chip_style", param2ViewStyle.getBundle());
        return this;
      }
      
      public Builder setEndIconStyle(ImageViewStyle param2ImageViewStyle) {
        param2ImageViewStyle.assertIsValid();
        this.mBundle.putBundle("end_icon_style", param2ImageViewStyle.getBundle());
        return this;
      }
      
      public Builder setLayoutDirection(int param2Int) {
        this.mBundle.putInt("layout_direction", param2Int);
        return this;
      }
      
      public Builder setSingleIconChipIconStyle(ImageViewStyle param2ImageViewStyle) {
        param2ImageViewStyle.assertIsValid();
        this.mBundle.putBundle("single_icon_chip_icon_style", param2ImageViewStyle.getBundle());
        return this;
      }
      
      public Builder setSingleIconChipStyle(ViewStyle param2ViewStyle) {
        param2ViewStyle.assertIsValid();
        this.mBundle.putBundle("single_icon_chip_style", param2ViewStyle.getBundle());
        return this;
      }
      
      public Builder setStartIconStyle(ImageViewStyle param2ImageViewStyle) {
        param2ImageViewStyle.assertIsValid();
        this.mBundle.putBundle("start_icon_style", param2ImageViewStyle.getBundle());
        return this;
      }
      
      public Builder setSubtitleStyle(TextViewStyle param2TextViewStyle) {
        param2TextViewStyle.assertIsValid();
        this.mBundle.putBundle("subtitle_style", param2TextViewStyle.getBundle());
        return this;
      }
      
      public Builder setTitleStyle(TextViewStyle param2TextViewStyle) {
        param2TextViewStyle.assertIsValid();
        this.mBundle.putBundle("title_style", param2TextViewStyle.getBundle());
        return this;
      }
    }
  }
  
  public static final class Builder extends BundledStyle.Builder<Style> {
    Builder() {
      super("style_v1");
    }
    
    public InlineSuggestionUi.Style build() {
      return new InlineSuggestionUi.Style(this.mBundle);
    }
    
    public Builder setChipStyle(ViewStyle param1ViewStyle) {
      param1ViewStyle.assertIsValid();
      this.mBundle.putBundle("chip_style", param1ViewStyle.getBundle());
      return this;
    }
    
    public Builder setEndIconStyle(ImageViewStyle param1ImageViewStyle) {
      param1ImageViewStyle.assertIsValid();
      this.mBundle.putBundle("end_icon_style", param1ImageViewStyle.getBundle());
      return this;
    }
    
    public Builder setLayoutDirection(int param1Int) {
      this.mBundle.putInt("layout_direction", param1Int);
      return this;
    }
    
    public Builder setSingleIconChipIconStyle(ImageViewStyle param1ImageViewStyle) {
      param1ImageViewStyle.assertIsValid();
      this.mBundle.putBundle("single_icon_chip_icon_style", param1ImageViewStyle.getBundle());
      return this;
    }
    
    public Builder setSingleIconChipStyle(ViewStyle param1ViewStyle) {
      param1ViewStyle.assertIsValid();
      this.mBundle.putBundle("single_icon_chip_style", param1ViewStyle.getBundle());
      return this;
    }
    
    public Builder setStartIconStyle(ImageViewStyle param1ImageViewStyle) {
      param1ImageViewStyle.assertIsValid();
      this.mBundle.putBundle("start_icon_style", param1ImageViewStyle.getBundle());
      return this;
    }
    
    public Builder setSubtitleStyle(TextViewStyle param1TextViewStyle) {
      param1TextViewStyle.assertIsValid();
      this.mBundle.putBundle("subtitle_style", param1TextViewStyle.getBundle());
      return this;
    }
    
    public Builder setTitleStyle(TextViewStyle param1TextViewStyle) {
      param1TextViewStyle.assertIsValid();
      this.mBundle.putBundle("title_style", param1TextViewStyle.getBundle());
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\v1\InlineSuggestionUi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */