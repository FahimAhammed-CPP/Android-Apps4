package androidx.autofill.inline.common;

import android.os.Bundle;

public abstract class BundledStyle {
  protected final Bundle mBundle;
  
  protected BundledStyle(Bundle paramBundle) {
    this.mBundle = paramBundle;
  }
  
  public void assertIsValid() {
    if (isValid())
      return; 
    StringBuilder stringBuilder = new StringBuilder("Invalid style, missing bundle key ");
    stringBuilder.append(getStyleKey());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final Bundle getBundle() {
    return this.mBundle;
  }
  
  protected abstract String getStyleKey();
  
  public boolean isValid() {
    Bundle bundle = this.mBundle;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bundle != null) {
      bool1 = bool2;
      if (bundle.getBoolean(getStyleKey(), false))
        bool1 = true; 
    } 
    return bool1;
  }
  
  public static abstract class Builder<T extends BundledStyle> {
    protected final Bundle mBundle;
    
    protected Builder(String param1String) {
      Bundle bundle = new Bundle();
      this.mBundle = bundle;
      bundle.putBoolean(param1String, true);
    }
    
    public abstract T build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\common\BundledStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */