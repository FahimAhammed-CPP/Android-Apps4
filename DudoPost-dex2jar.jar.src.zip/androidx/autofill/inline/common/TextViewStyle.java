package androidx.autofill.inline.common;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import androidx.core.util.Preconditions;

public final class TextViewStyle extends ViewStyle {
  private static final String KEY_TEXT_COLOR = "text_color";
  
  private static final String KEY_TEXT_FONT_FAMILY = "text_font_family";
  
  private static final String KEY_TEXT_FONT_STYLE = "text_font_style";
  
  private static final String KEY_TEXT_SIZE = "text_size";
  
  private static final String KEY_TEXT_SIZE_UNIT = "text_size_unit";
  
  private static final String KEY_TEXT_VIEW_STYLE = "text_view_style";
  
  public TextViewStyle(Bundle paramBundle) {
    super(paramBundle);
  }
  
  public void applyStyleOnTextViewIfValid(TextView paramTextView) {
    if (!isValid())
      return; 
    applyStyleOnViewIfValid((View)paramTextView);
    if (this.mBundle.containsKey("text_color"))
      paramTextView.setTextColor(this.mBundle.getInt("text_color")); 
    if (this.mBundle.containsKey("text_size")) {
      byte b;
      if (this.mBundle.containsKey("text_size_unit")) {
        b = this.mBundle.getInt("text_size_unit");
      } else {
        b = 2;
      } 
      paramTextView.setTextSize(b, this.mBundle.getFloat("text_size"));
    } 
    if (this.mBundle.containsKey("text_font_family")) {
      String str = this.mBundle.getString("text_font_family");
      if (!TextUtils.isEmpty(str))
        paramTextView.setTypeface(Typeface.create(str, this.mBundle.getInt("text_font_style"))); 
    } 
  }
  
  protected String getStyleKey() {
    return "text_view_style";
  }
  
  public static final class Builder extends ViewStyle.BaseBuilder<TextViewStyle, Builder> {
    public Builder() {
      super("text_view_style");
    }
    
    public TextViewStyle build() {
      return new TextViewStyle(this.mBundle);
    }
    
    protected Builder getThis() {
      return this;
    }
    
    public Builder setTextColor(int param1Int) {
      this.mBundle.putInt("text_color", param1Int);
      return this;
    }
    
    public Builder setTextSize(float param1Float) {
      this.mBundle.putFloat("text_size", param1Float);
      return this;
    }
    
    public Builder setTextSize(int param1Int, float param1Float) {
      this.mBundle.putInt("text_size_unit", param1Int);
      this.mBundle.putFloat("text_size", param1Float);
      return this;
    }
    
    public Builder setTypeface(String param1String, int param1Int) {
      Preconditions.checkNotNull(param1String, "fontFamily should not be null");
      this.mBundle.putString("text_font_family", param1String);
      this.mBundle.putInt("text_font_style", param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\common\TextViewStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */