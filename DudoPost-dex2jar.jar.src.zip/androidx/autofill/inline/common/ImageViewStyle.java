package androidx.autofill.inline.common;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import androidx.core.util.Preconditions;

public final class ImageViewStyle extends ViewStyle {
  private static final String KEY_IMAGE_MAX_HEIGHT = "image_max_height";
  
  private static final String KEY_IMAGE_MAX_WIDTH = "image_max_width";
  
  private static final String KEY_IMAGE_SCALE_TYPE = "image_scale_type";
  
  private static final String KEY_IMAGE_TINT_LIST = "image_tint_list";
  
  private static final String KEY_IMAGE_VIEW_STYLE = "image_view_style";
  
  private static final String TAG = "ImageViewStyle";
  
  public ImageViewStyle(Bundle paramBundle) {
    super(paramBundle);
  }
  
  public void applyStyleOnImageViewIfValid(ImageView paramImageView) {
    if (!isValid())
      return; 
    applyStyleOnViewIfValid((View)paramImageView);
    if (this.mBundle.containsKey("image_max_width")) {
      paramImageView.setMaxWidth(this.mBundle.getInt("image_max_width"));
      paramImageView.setAdjustViewBounds(true);
    } 
    if (this.mBundle.containsKey("image_max_height")) {
      paramImageView.setMaxHeight(this.mBundle.getInt("image_max_height"));
      paramImageView.setAdjustViewBounds(true);
    } 
    if (this.mBundle.containsKey("image_tint_list")) {
      ColorStateList colorStateList = (ColorStateList)this.mBundle.getParcelable("image_tint_list");
      if (colorStateList != null)
        paramImageView.setImageTintList(colorStateList); 
    } 
    if (this.mBundle.containsKey("image_scale_type")) {
      String str = this.mBundle.getString("image_scale_type");
      if (str != null)
        try {
          paramImageView.setScaleType(ImageView.ScaleType.valueOf(str));
          return;
        } catch (IllegalArgumentException illegalArgumentException) {
          StringBuilder stringBuilder = new StringBuilder("Cannot recognize the scale type: ");
          stringBuilder.append(str);
          Log.w("ImageViewStyle", stringBuilder.toString());
        }  
    } 
  }
  
  protected String getStyleKey() {
    return "image_view_style";
  }
  
  public static final class Builder extends ViewStyle.BaseBuilder<ImageViewStyle, Builder> {
    public Builder() {
      super("image_view_style");
    }
    
    public ImageViewStyle build() {
      return new ImageViewStyle(this.mBundle);
    }
    
    protected Builder getThis() {
      return this;
    }
    
    public Builder setMaxHeight(int param1Int) {
      this.mBundle.putInt("image_max_height", param1Int);
      return this;
    }
    
    public Builder setMaxWidth(int param1Int) {
      this.mBundle.putInt("image_max_width", param1Int);
      return this;
    }
    
    public Builder setScaleType(ImageView.ScaleType param1ScaleType) {
      Preconditions.checkNotNull(param1ScaleType, "scaleType should not be null");
      this.mBundle.putString("image_scale_type", param1ScaleType.name());
      return this;
    }
    
    public Builder setTintList(ColorStateList param1ColorStateList) {
      Preconditions.checkNotNull(param1ColorStateList, "imageTintList should not be null");
      this.mBundle.putParcelable("image_tint_list", (Parcelable)param1ColorStateList);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\common\ImageViewStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */