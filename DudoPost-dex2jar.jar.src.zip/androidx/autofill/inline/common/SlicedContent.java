package androidx.autofill.inline.common;

import android.app.PendingIntent;
import android.app.slice.Slice;
import android.app.slice.SliceSpec;
import android.net.Uri;
import androidx.autofill.inline.UiVersions;

public abstract class SlicedContent implements UiVersions.Content {
  static final Uri INLINE_SLICE_URI = Uri.parse("inline.slice");
  
  protected final Slice mSlice;
  
  protected SlicedContent(Slice paramSlice) {
    this.mSlice = paramSlice;
  }
  
  public static String getVersion(Slice paramSlice) {
    return paramSlice.getSpec().getType();
  }
  
  public abstract PendingIntent getAttributionIntent();
  
  public final Slice getSlice() {
    return this.mSlice;
  }
  
  public abstract boolean isValid();
  
  public static abstract class Builder<T extends SlicedContent> {
    protected final Slice.Builder mSliceBuilder;
    
    protected Builder(String param1String) {
      this.mSliceBuilder = new Slice.Builder(SlicedContent.INLINE_SLICE_URI, new SliceSpec(param1String, 1));
    }
    
    public abstract T build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\common\SlicedContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */