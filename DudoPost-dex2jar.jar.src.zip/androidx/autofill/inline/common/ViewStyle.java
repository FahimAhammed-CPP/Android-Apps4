package androidx.autofill.inline.common;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.util.Preconditions;

public class ViewStyle extends BundledStyle {
  private static final String KEY_BACKGROUND = "background";
  
  private static final String KEY_BACKGROUND_COLOR = "background_color";
  
  private static final String KEY_LAYOUT_MARGIN = "layout_margin";
  
  private static final String KEY_PADDING = "padding";
  
  private static final String KEY_VIEW_STYLE = "view_style";
  
  public ViewStyle(Bundle paramBundle) {
    super(paramBundle);
  }
  
  public void applyStyleOnViewIfValid(View paramView) {
    if (!isValid())
      return; 
    if (this.mBundle.containsKey("background")) {
      Icon icon = (Icon)this.mBundle.getParcelable("background");
      if (icon != null) {
        Drawable drawable = icon.loadDrawable(paramView.getContext());
        if (drawable != null)
          paramView.setBackground(drawable); 
      } 
    } 
    if (this.mBundle.containsKey("background_color"))
      paramView.setBackgroundColor(this.mBundle.getInt("background_color")); 
    if (this.mBundle.containsKey("padding")) {
      int[] arrayOfInt = this.mBundle.getIntArray("padding");
      if (arrayOfInt != null && arrayOfInt.length == 4)
        if (paramView.getLayoutDirection() == 0) {
          paramView.setPadding(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]);
        } else {
          paramView.setPadding(arrayOfInt[2], arrayOfInt[1], arrayOfInt[0], arrayOfInt[3]);
        }  
    } 
    if (this.mBundle.containsKey("layout_margin")) {
      int[] arrayOfInt = this.mBundle.getIntArray("layout_margin");
      if (arrayOfInt != null && arrayOfInt.length == 4) {
        ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
        if (layoutParams == null) {
          marginLayoutParams = new ViewGroup.MarginLayoutParams(-1, -1);
        } else {
          ViewGroup.LayoutParams layoutParams1 = layoutParams;
          if (!(layoutParams instanceof ViewGroup.MarginLayoutParams))
            marginLayoutParams = new ViewGroup.MarginLayoutParams(layoutParams); 
        } 
        ViewGroup.MarginLayoutParams marginLayoutParams = marginLayoutParams;
        if (paramView.getLayoutDirection() == 0) {
          marginLayoutParams.setMargins(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]);
        } else {
          marginLayoutParams.setMargins(arrayOfInt[2], arrayOfInt[1], arrayOfInt[0], arrayOfInt[3]);
        } 
        paramView.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
      } 
    } 
  }
  
  protected String getStyleKey() {
    return "view_style";
  }
  
  public static abstract class BaseBuilder<T extends ViewStyle, B extends BaseBuilder<T, B>> extends BundledStyle.Builder<T> {
    protected BaseBuilder(String param1String) {
      super(param1String);
    }
    
    protected abstract B getThis();
    
    public B setBackground(Icon param1Icon) {
      Preconditions.checkNotNull(param1Icon, "background icon should not be null");
      this.mBundle.putParcelable("background", (Parcelable)param1Icon);
      return getThis();
    }
    
    public B setBackgroundColor(int param1Int) {
      this.mBundle.putInt("background_color", param1Int);
      return getThis();
    }
    
    public B setLayoutMargin(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.mBundle.putIntArray("layout_margin", new int[] { param1Int1, param1Int2, param1Int3, param1Int4 });
      return getThis();
    }
    
    public B setPadding(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.mBundle.putIntArray("padding", new int[] { param1Int1, param1Int2, param1Int3, param1Int4 });
      return getThis();
    }
  }
  
  public static final class Builder extends BaseBuilder<ViewStyle, Builder> {
    public Builder() {
      super("view_style");
    }
    
    public ViewStyle build() {
      return new ViewStyle(this.mBundle);
    }
    
    protected Builder getThis() {
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\common\ViewStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */