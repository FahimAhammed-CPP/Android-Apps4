package androidx.autofill.inline;

import android.app.PendingIntent;
import android.app.slice.Slice;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.autofill.inline.common.SlicedContent;
import androidx.autofill.inline.v1.InlineSuggestionUi;

public final class Renderer {
  private static final String TAG = "Renderer";
  
  public static PendingIntent getAttributionIntent(Slice paramSlice) {
    StringBuilder stringBuilder;
    String str = SlicedContent.getVersion(paramSlice);
    if (!VersionUtils.isVersionSupported(str)) {
      Log.w("Renderer", "Content version unsupported.");
      return null;
    } 
    str.hashCode();
    if (!str.equals("androidx.autofill.inline.ui.version:v1")) {
      stringBuilder = new StringBuilder("Renderer does not support the content version: ");
      stringBuilder.append(str);
      Log.w("Renderer", stringBuilder.toString());
      return null;
    } 
    InlineSuggestionUi.Content content = InlineSuggestionUi.fromSlice((Slice)stringBuilder);
    return (content == null) ? null : InlineSuggestionUi.getAttributionIntent(content);
  }
  
  public static Bundle getSupportedInlineUiVersionsAsBundle() {
    Bundle bundle = new Bundle();
    VersionUtils.writeSupportedVersions(bundle);
    return bundle;
  }
  
  public static View render(Context paramContext, Slice paramSlice, Bundle paramBundle) {
    StringBuilder stringBuilder;
    String str = SlicedContent.getVersion(paramSlice);
    if (!VersionUtils.isVersionSupported(str)) {
      Log.w("Renderer", "Content version unsupported.");
      return null;
    } 
    paramBundle = VersionUtils.readStyleByVersion(paramBundle, str);
    if (paramBundle == null) {
      Log.w("Renderer", "Cannot find a style with the same version as the slice.");
      return null;
    } 
    str.hashCode();
    if (!str.equals("androidx.autofill.inline.ui.version:v1")) {
      stringBuilder = new StringBuilder("Renderer does not support the style/content version: ");
      stringBuilder.append(str);
      Log.w("Renderer", stringBuilder.toString());
      return null;
    } 
    InlineSuggestionUi.Style style = InlineSuggestionUi.fromBundle(paramBundle);
    InlineSuggestionUi.Content content = InlineSuggestionUi.fromSlice(paramSlice);
    return (style != null) ? ((paramSlice == null) ? null : InlineSuggestionUi.render((Context)stringBuilder, content, style)) : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\Renderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */