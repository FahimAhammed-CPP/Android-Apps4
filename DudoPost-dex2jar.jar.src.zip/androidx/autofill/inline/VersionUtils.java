package androidx.autofill.inline;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public final class VersionUtils {
  private static final String KEY_INLINE_UI_VERSIONS = "androidx.autofill.inline.ui.version:key";
  
  public static List<String> getSupportedVersions(Bundle paramBundle) {
    ArrayList<String> arrayList1 = new ArrayList();
    ArrayList arrayList = paramBundle.getStringArrayList("androidx.autofill.inline.ui.version:key");
    if (arrayList != null)
      for (String str : arrayList) {
        if (isVersionSupported(str))
          arrayList1.add(str); 
      }  
    return arrayList1;
  }
  
  public static boolean isVersionSupported(String paramString) {
    return UiVersions.getUiVersions().contains(paramString);
  }
  
  public static Bundle readStyleByVersion(Bundle paramBundle, String paramString) {
    return paramBundle.getBundle(paramString);
  }
  
  public static void writeStylesToBundle(List<UiVersions.Style> paramList, Bundle paramBundle) {
    ArrayList<String> arrayList = new ArrayList();
    for (UiVersions.Style style : paramList) {
      String str = style.getVersion();
      arrayList.add(style.getVersion());
      paramBundle.putBundle(str, style.getBundle());
    } 
    paramBundle.putStringArrayList("androidx.autofill.inline.ui.version:key", arrayList);
  }
  
  public static void writeSupportedVersions(Bundle paramBundle) {
    paramBundle.putStringArrayList("androidx.autofill.inline.ui.version:key", new ArrayList<String>(UiVersions.getUiVersions()));
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\VersionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */