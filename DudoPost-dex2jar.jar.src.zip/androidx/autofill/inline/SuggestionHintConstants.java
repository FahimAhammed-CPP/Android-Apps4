package androidx.autofill.inline;

public final class SuggestionHintConstants {
  public static final String SUGGESTION_HINT_CLIPBOARD_CONTENT = "clipboardContent";
  
  public static final String SUGGESTION_HINT_SMART_REPLY = "smartReply";
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\autofill\inline\SuggestionHintConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */