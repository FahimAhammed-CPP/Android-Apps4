package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.appcompat.R;
import java.util.function.IntFunction;

public final class AppCompatTextView$InspectionCompanion implements InspectionCompanion<AppCompatTextView> {
  private int mAutoSizeMaxTextSizeId;
  
  private int mAutoSizeMinTextSizeId;
  
  private int mAutoSizeStepGranularityId;
  
  private int mAutoSizeTextTypeId;
  
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private int mDrawableTintId;
  
  private int mDrawableTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  public void mapProperties(PropertyMapper paramPropertyMapper) {
    this.mAutoSizeMaxTextSizeId = paramPropertyMapper.mapInt("autoSizeMaxTextSize", R.attr.autoSizeMaxTextSize);
    this.mAutoSizeMinTextSizeId = paramPropertyMapper.mapInt("autoSizeMinTextSize", R.attr.autoSizeMinTextSize);
    this.mAutoSizeStepGranularityId = paramPropertyMapper.mapInt("autoSizeStepGranularity", R.attr.autoSizeStepGranularity);
    this.mAutoSizeTextTypeId = paramPropertyMapper.mapIntEnum("autoSizeTextType", R.attr.autoSizeTextType, new IntFunction<String>() {
          public String apply(int param1Int) {
            return (param1Int != 0) ? ((param1Int != 1) ? String.valueOf(param1Int) : "uniform") : "none";
          }
        });
    this.mBackgroundTintId = paramPropertyMapper.mapObject("backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = paramPropertyMapper.mapObject("backgroundTintMode", R.attr.backgroundTintMode);
    this.mDrawableTintId = paramPropertyMapper.mapObject("drawableTint", R.attr.drawableTint);
    this.mDrawableTintModeId = paramPropertyMapper.mapObject("drawableTintMode", R.attr.drawableTintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(AppCompatTextView paramAppCompatTextView, PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      paramPropertyReader.readInt(this.mAutoSizeMaxTextSizeId, paramAppCompatTextView.getAutoSizeMaxTextSize());
      paramPropertyReader.readInt(this.mAutoSizeMinTextSizeId, paramAppCompatTextView.getAutoSizeMinTextSize());
      paramPropertyReader.readInt(this.mAutoSizeStepGranularityId, paramAppCompatTextView.getAutoSizeStepGranularity());
      paramPropertyReader.readIntEnum(this.mAutoSizeTextTypeId, paramAppCompatTextView.getAutoSizeTextType());
      paramPropertyReader.readObject(this.mBackgroundTintId, paramAppCompatTextView.getBackgroundTintList());
      paramPropertyReader.readObject(this.mBackgroundTintModeId, paramAppCompatTextView.getBackgroundTintMode());
      paramPropertyReader.readObject(this.mDrawableTintId, paramAppCompatTextView.getCompoundDrawableTintList());
      paramPropertyReader.readObject(this.mDrawableTintModeId, paramAppCompatTextView.getCompoundDrawableTintMode());
      return;
    } 
    throw new InspectionCompanion.UninitializedPropertyMapException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */