package androidx.collection;

import java.util.Iterator;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.LongIterator;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;

@Metadata(bv = {1, 0, 3}, d1 = {"\000D\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\000\n\002\020\t\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\020(\n\000\032!\020\006\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\tH\n\032Q\020\n\032\0020\013\"\004\b\000\020\002*\b\022\004\022\002H\0020\00326\020\f\0322\022\023\022\0210\t¢\006\f\b\016\022\b\b\017\022\004\b\b(\b\022\023\022\021H\002¢\006\f\b\016\022\b\b\017\022\004\b\b(\020\022\004\022\0020\0130\rH\b\032.\020\021\032\002H\002\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\t2\006\020\022\032\002H\002H\b¢\006\002\020\023\0324\020\024\032\002H\002\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\t2\f\020\022\032\b\022\004\022\002H\0020\025H\b¢\006\002\020\026\032\031\020\027\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\003H\b\032\026\020\030\032\0020\031\"\004\b\000\020\002*\b\022\004\022\002H\0020\003\032-\020\032\032\b\022\004\022\002H\0020\003\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\f\020\033\032\b\022\004\022\002H\0020\003H\002\032-\020\034\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\t2\006\020\020\032\002H\002H\007¢\006\002\020\035\032.\020\036\032\0020\013\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\t2\006\020\020\032\002H\002H\n¢\006\002\020\037\032\034\020 \032\b\022\004\022\002H\0020!\"\004\b\000\020\002*\b\022\004\022\002H\0020\003\"\"\020\000\032\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0038Æ\002¢\006\006\032\004\b\004\020\005¨\006\""}, d2 = {"size", "", "T", "Landroidx/collection/LongSparseArray;", "getSize", "(Landroidx/collection/LongSparseArray;)I", "contains", "", "key", "", "forEach", "", "action", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "getOrDefault", "defaultValue", "(Landroidx/collection/LongSparseArray;JLjava/lang/Object;)Ljava/lang/Object;", "getOrElse", "Lkotlin/Function0;", "(Landroidx/collection/LongSparseArray;JLkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "isNotEmpty", "keyIterator", "Lkotlin/collections/LongIterator;", "plus", "other", "remove", "(Landroidx/collection/LongSparseArray;JLjava/lang/Object;)Z", "set", "(Landroidx/collection/LongSparseArray;JLjava/lang/Object;)V", "valueIterator", "", "collection-ktx"}, k = 2, mv = {1, 1, 13})
public final class LongSparseArrayKt {
  public static final <T> boolean contains(LongSparseArray<T> paramLongSparseArray, long paramLong) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.containsKey(paramLong);
  }
  
  public static final <T> void forEach(LongSparseArray<T> paramLongSparseArray, Function2<? super Long, ? super T, Unit> paramFunction2) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramFunction2, "action");
    int j = paramLongSparseArray.size();
    for (int i = 0; i < j; i++)
      paramFunction2.invoke(Long.valueOf(paramLongSparseArray.keyAt(i)), paramLongSparseArray.valueAt(i)); 
  }
  
  public static final <T> T getOrDefault(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.get(paramLong, paramT);
  }
  
  public static final <T> T getOrElse(LongSparseArray<T> paramLongSparseArray, long paramLong, Function0<? extends T> paramFunction0) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramFunction0, "defaultValue");
    paramLongSparseArray = (LongSparseArray<T>)paramLongSparseArray.get(paramLong);
    return (T)((paramLongSparseArray != null) ? paramLongSparseArray : paramFunction0.invoke());
  }
  
  public static final <T> int getSize(LongSparseArray<T> paramLongSparseArray) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.size();
  }
  
  public static final <T> boolean isNotEmpty(LongSparseArray<T> paramLongSparseArray) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.isEmpty() ^ true;
  }
  
  public static final <T> LongIterator keyIterator(LongSparseArray<T> paramLongSparseArray) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return new LongSparseArrayKt$keyIterator$1(paramLongSparseArray);
  }
  
  public static final <T> LongSparseArray<T> plus(LongSparseArray<T> paramLongSparseArray1, LongSparseArray<T> paramLongSparseArray2) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray1, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray2, "other");
    LongSparseArray<T> longSparseArray = new LongSparseArray(paramLongSparseArray1.size() + paramLongSparseArray2.size());
    longSparseArray.putAll(paramLongSparseArray1);
    longSparseArray.putAll(paramLongSparseArray2);
    return longSparseArray;
  }
  
  @Deprecated(message = "Replaced with member function. Remove extension import!")
  public static final <T> boolean remove(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.remove(paramLong, paramT);
  }
  
  public static final <T> void set(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    paramLongSparseArray.put(paramLong, paramT);
  }
  
  public static final <T> Iterator<T> valueIterator(LongSparseArray<T> paramLongSparseArray) {
    Intrinsics.checkParameterIsNotNull(paramLongSparseArray, "receiver$0");
    return new LongSparseArrayKt$valueIterator$1(paramLongSparseArray);
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\037\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\005\n\002\020\013\n\000\n\002\020\t\n\000*\001\000\b\n\030\0002\0020\001J\t\020\b\032\0020\tH\002J\b\020\n\032\0020\013H\026R\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\f"}, d2 = {"androidx/collection/LongSparseArrayKt$keyIterator$1", "Lkotlin/collections/LongIterator;", "index", "", "getIndex", "()I", "setIndex", "(I)V", "hasNext", "", "nextLong", "", "collection-ktx"}, k = 1, mv = {1, 1, 13})
  public static final class LongSparseArrayKt$keyIterator$1 extends LongIterator {
    private int index;
    
    LongSparseArrayKt$keyIterator$1(LongSparseArray<T> param1LongSparseArray) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_keyIterator.size());
    }
    
    public long nextLong() {
      LongSparseArray longSparseArray = this.$this_keyIterator;
      int i = this.index;
      this.index = i + 1;
      return longSparseArray.keyAt(i);
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\033\n\000\n\002\020(\n\000\n\002\020\b\n\002\b\005\n\002\020\013\n\002\b\004*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\t\020\b\032\0020\tH\002J\026\020\n\032\n \013*\004\030\0018\0008\000H\002¢\006\002\020\fR\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\r"}, d2 = {"androidx/collection/LongSparseArrayKt$valueIterator$1", "", "index", "", "getIndex", "()I", "setIndex", "(I)V", "hasNext", "", "next", "kotlin.jvm.PlatformType", "()Ljava/lang/Object;", "collection-ktx"}, k = 1, mv = {1, 1, 13})
  public static final class LongSparseArrayKt$valueIterator$1 implements Iterator<T>, KMappedMarker {
    private int index;
    
    LongSparseArrayKt$valueIterator$1(LongSparseArray<T> param1LongSparseArray) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_valueIterator.size());
    }
    
    public T next() {
      LongSparseArray<T> longSparseArray = this.$this_valueIterator;
      int i = this.index;
      this.index = i + 1;
      return longSparseArray.valueAt(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\collection\LongSparseArrayKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */