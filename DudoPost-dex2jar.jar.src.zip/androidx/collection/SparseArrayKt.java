package androidx.collection;

import java.util.Iterator;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.IntIterator;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;

@Metadata(bv = {1, 0, 3}, d1 = {"\000@\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\020(\n\000\032!\020\006\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\001H\n\032Q\020\t\032\0020\n\"\004\b\000\020\002*\b\022\004\022\002H\0020\00326\020\013\0322\022\023\022\0210\001¢\006\f\b\r\022\b\b\016\022\004\b\b(\b\022\023\022\021H\002¢\006\f\b\r\022\b\b\016\022\004\b\b(\017\022\004\022\0020\n0\fH\b\032.\020\020\032\002H\002\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\0012\006\020\021\032\002H\002H\b¢\006\002\020\022\0324\020\023\032\002H\002\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\0012\f\020\021\032\b\022\004\022\002H\0020\024H\b¢\006\002\020\025\032\031\020\026\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\003H\b\032\026\020\027\032\0020\030\"\004\b\000\020\002*\b\022\004\022\002H\0020\003\032-\020\031\032\b\022\004\022\002H\0020\003\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\f\020\032\032\b\022\004\022\002H\0020\003H\002\032-\020\033\032\0020\007\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\0012\006\020\017\032\002H\002H\007¢\006\002\020\034\032.\020\035\032\0020\n\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\006\020\b\032\0020\0012\006\020\017\032\002H\002H\n¢\006\002\020\036\032\034\020\037\032\b\022\004\022\002H\0020 \"\004\b\000\020\002*\b\022\004\022\002H\0020\003\"\"\020\000\032\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0038Æ\002¢\006\006\032\004\b\004\020\005¨\006!"}, d2 = {"size", "", "T", "Landroidx/collection/SparseArrayCompat;", "getSize", "(Landroidx/collection/SparseArrayCompat;)I", "contains", "", "key", "forEach", "", "action", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "getOrDefault", "defaultValue", "(Landroidx/collection/SparseArrayCompat;ILjava/lang/Object;)Ljava/lang/Object;", "getOrElse", "Lkotlin/Function0;", "(Landroidx/collection/SparseArrayCompat;ILkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "isNotEmpty", "keyIterator", "Lkotlin/collections/IntIterator;", "plus", "other", "remove", "(Landroidx/collection/SparseArrayCompat;ILjava/lang/Object;)Z", "set", "(Landroidx/collection/SparseArrayCompat;ILjava/lang/Object;)V", "valueIterator", "", "collection-ktx"}, k = 2, mv = {1, 1, 13})
public final class SparseArrayKt {
  public static final <T> boolean contains(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.containsKey(paramInt);
  }
  
  public static final <T> void forEach(SparseArrayCompat<T> paramSparseArrayCompat, Function2<? super Integer, ? super T, Unit> paramFunction2) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramFunction2, "action");
    int j = paramSparseArrayCompat.size();
    for (int i = 0; i < j; i++)
      paramFunction2.invoke(Integer.valueOf(paramSparseArrayCompat.keyAt(i)), paramSparseArrayCompat.valueAt(i)); 
  }
  
  public static final <T> T getOrDefault(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.get(paramInt, paramT);
  }
  
  public static final <T> T getOrElse(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, Function0<? extends T> paramFunction0) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramFunction0, "defaultValue");
    paramSparseArrayCompat = (SparseArrayCompat<T>)paramSparseArrayCompat.get(paramInt);
    return (T)((paramSparseArrayCompat != null) ? paramSparseArrayCompat : paramFunction0.invoke());
  }
  
  public static final <T> int getSize(SparseArrayCompat<T> paramSparseArrayCompat) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.size();
  }
  
  public static final <T> boolean isNotEmpty(SparseArrayCompat<T> paramSparseArrayCompat) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.isEmpty() ^ true;
  }
  
  public static final <T> IntIterator keyIterator(SparseArrayCompat<T> paramSparseArrayCompat) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return new SparseArrayKt$keyIterator$1(paramSparseArrayCompat);
  }
  
  public static final <T> SparseArrayCompat<T> plus(SparseArrayCompat<T> paramSparseArrayCompat1, SparseArrayCompat<T> paramSparseArrayCompat2) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat1, "receiver$0");
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat2, "other");
    SparseArrayCompat<T> sparseArrayCompat = new SparseArrayCompat(paramSparseArrayCompat1.size() + paramSparseArrayCompat2.size());
    sparseArrayCompat.putAll(paramSparseArrayCompat1);
    sparseArrayCompat.putAll(paramSparseArrayCompat2);
    return sparseArrayCompat;
  }
  
  @Deprecated(message = "Replaced with member function. Remove extension import!")
  public static final <T> boolean remove(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.remove(paramInt, paramT);
  }
  
  public static final <T> void set(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    paramSparseArrayCompat.put(paramInt, paramT);
  }
  
  public static final <T> Iterator<T> valueIterator(SparseArrayCompat<T> paramSparseArrayCompat) {
    Intrinsics.checkParameterIsNotNull(paramSparseArrayCompat, "receiver$0");
    return new SparseArrayKt$valueIterator$1(paramSparseArrayCompat);
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\033\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\005\n\002\020\013\n\002\b\002*\001\000\b\n\030\0002\0020\001J\t\020\b\032\0020\tH\002J\b\020\n\032\0020\003H\026R\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\013"}, d2 = {"androidx/collection/SparseArrayKt$keyIterator$1", "Lkotlin/collections/IntIterator;", "index", "", "getIndex", "()I", "setIndex", "(I)V", "hasNext", "", "nextInt", "collection-ktx"}, k = 1, mv = {1, 1, 13})
  public static final class SparseArrayKt$keyIterator$1 extends IntIterator {
    private int index;
    
    SparseArrayKt$keyIterator$1(SparseArrayCompat<T> param1SparseArrayCompat) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_keyIterator.size());
    }
    
    public int nextInt() {
      SparseArrayCompat sparseArrayCompat = this.$this_keyIterator;
      int i = this.index;
      this.index = i + 1;
      return sparseArrayCompat.keyAt(i);
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\033\n\000\n\002\020(\n\000\n\002\020\b\n\002\b\005\n\002\020\013\n\002\b\004*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\t\020\b\032\0020\tH\002J\026\020\n\032\n \013*\004\030\0018\0008\000H\002¢\006\002\020\fR\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\r"}, d2 = {"androidx/collection/SparseArrayKt$valueIterator$1", "", "index", "", "getIndex", "()I", "setIndex", "(I)V", "hasNext", "", "next", "kotlin.jvm.PlatformType", "()Ljava/lang/Object;", "collection-ktx"}, k = 1, mv = {1, 1, 13})
  public static final class SparseArrayKt$valueIterator$1 implements Iterator<T>, KMappedMarker {
    private int index;
    
    SparseArrayKt$valueIterator$1(SparseArrayCompat<T> param1SparseArrayCompat) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_valueIterator.size());
    }
    
    public T next() {
      SparseArrayCompat<T> sparseArrayCompat = this.$this_valueIterator;
      int i = this.index;
      this.index = i + 1;
      return sparseArrayCompat.valueAt(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\collection\SparseArrayKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */