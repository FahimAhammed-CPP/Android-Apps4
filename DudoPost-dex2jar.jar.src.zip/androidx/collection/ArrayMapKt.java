package androidx.collection;

import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\026\n\000\n\002\030\002\n\002\b\003\n\002\020\021\n\002\030\002\n\002\b\002\032!\020\000\032\016\022\004\022\002H\002\022\004\022\002H\0030\001\"\004\b\000\020\002\"\004\b\001\020\003H\b\032O\020\000\032\016\022\004\022\002H\002\022\004\022\002H\0030\001\"\004\b\000\020\002\"\004\b\001\020\0032*\020\004\032\026\022\022\b\001\022\016\022\004\022\002H\002\022\004\022\002H\0030\0060\005\"\016\022\004\022\002H\002\022\004\022\002H\0030\006¢\006\002\020\007¨\006\b"}, d2 = {"arrayMapOf", "Landroidx/collection/ArrayMap;", "K", "V", "pairs", "", "Lkotlin/Pair;", "([Lkotlin/Pair;)Landroidx/collection/ArrayMap;", "collection-ktx"}, k = 2, mv = {1, 1, 13})
public final class ArrayMapKt {
  public static final <K, V> ArrayMap<K, V> arrayMapOf() {
    return new ArrayMap<K, V>();
  }
  
  public static final <K, V> ArrayMap<K, V> arrayMapOf(Pair<? extends K, ? extends V>... paramVarArgs) {
    Intrinsics.checkParameterIsNotNull(paramVarArgs, "pairs");
    ArrayMap<Object, Object> arrayMap = new ArrayMap<Object, Object>(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      Pair<? extends K, ? extends V> pair = paramVarArgs[i];
      arrayMap.put(pair.getFirst(), pair.getSecond());
    } 
    return (ArrayMap)arrayMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\collection\ArrayMapKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */