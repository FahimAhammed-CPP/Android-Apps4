package androidx.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
public @interface RestrictTo {
  Scope[] value();
  
  public enum Scope {
    GROUP_ID, LIBRARY, LIBRARY_GROUP, LIBRARY_GROUP_PREFIX, SUBCLASSES, TESTS;
    
    static {
      Scope scope1 = new Scope("LIBRARY", 0);
      LIBRARY = scope1;
      Scope scope2 = new Scope("LIBRARY_GROUP", 1);
      LIBRARY_GROUP = scope2;
      Scope scope3 = new Scope("LIBRARY_GROUP_PREFIX", 2);
      LIBRARY_GROUP_PREFIX = scope3;
      Scope scope4 = new Scope("GROUP_ID", 3);
      GROUP_ID = scope4;
      Scope scope5 = new Scope("TESTS", 4);
      TESTS = scope5;
      Scope scope6 = new Scope("SUBCLASSES", 5);
      SUBCLASSES = scope6;
      $VALUES = new Scope[] { scope1, scope2, scope3, scope4, scope5, scope6 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\annotation\RestrictTo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */