package androidx.activity.result;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.core.app.ActivityOptionsCompat;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\021\n\002\030\002\n\002\b\003\b\000\030\000*\004\b\000\020\001*\004\b\001\020\0022\b\022\004\022\0020\0040\003B/\022\f\020\005\032\b\022\004\022\0028\0000\003\022\022\020\006\032\016\022\004\022\0028\000\022\004\022\0028\0010\007\022\006\020\b\032\0028\000¢\006\002\020\tJ\024\020\025\032\016\022\004\022\0020\004\022\004\022\0028\0010\007H\026J\037\020\026\032\0020\0042\006\020\027\032\0020\0042\b\020\030\032\004\030\0010\031H\026¢\006\002\020\032J\b\020\033\032\0020\004H\026R\035\020\006\032\016\022\004\022\0028\000\022\004\022\0028\0010\007¢\006\b\n\000\032\004\b\n\020\013R\023\020\b\032\0028\000¢\006\n\n\002\020\016\032\004\b\f\020\rR\027\020\005\032\b\022\004\022\0028\0000\003¢\006\b\n\000\032\004\b\017\020\020R'\020\021\032\016\022\004\022\0020\004\022\004\022\0028\0010\0078FX\002¢\006\f\n\004\b\023\020\024\032\004\b\022\020\013¨\006\034"}, d2 = {"Landroidx/activity/result/ActivityResultCallerLauncher;", "I", "O", "Landroidx/activity/result/ActivityResultLauncher;", "", "launcher", "callerContract", "Landroidx/activity/result/contract/ActivityResultContract;", "callerInput", "(Landroidx/activity/result/ActivityResultLauncher;Landroidx/activity/result/contract/ActivityResultContract;Ljava/lang/Object;)V", "getCallerContract", "()Landroidx/activity/result/contract/ActivityResultContract;", "getCallerInput", "()Ljava/lang/Object;", "Ljava/lang/Object;", "getLauncher", "()Landroidx/activity/result/ActivityResultLauncher;", "resultContract", "getResultContract", "resultContract$delegate", "Lkotlin/Lazy;", "getContract", "launch", "input", "options", "Landroidx/core/app/ActivityOptionsCompat;", "(Lkotlin/Unit;Landroidx/core/app/ActivityOptionsCompat;)V", "unregister", "activity-ktx_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class ActivityResultCallerLauncher<I, O> extends ActivityResultLauncher<Unit> {
  private final ActivityResultContract<I, O> callerContract;
  
  private final I callerInput;
  
  private final ActivityResultLauncher<I> launcher;
  
  private final Lazy resultContract$delegate;
  
  public ActivityResultCallerLauncher(ActivityResultLauncher<I> paramActivityResultLauncher, ActivityResultContract<I, O> paramActivityResultContract, I paramI) {
    this.launcher = paramActivityResultLauncher;
    this.callerContract = paramActivityResultContract;
    this.callerInput = paramI;
    this.resultContract$delegate = LazyKt.lazy(new ActivityResultCallerLauncher$resultContract$2());
  }
  
  public final ActivityResultContract<I, O> getCallerContract() {
    return this.callerContract;
  }
  
  public final I getCallerInput() {
    return this.callerInput;
  }
  
  public ActivityResultContract<Unit, O> getContract() {
    return getResultContract();
  }
  
  public final ActivityResultLauncher<I> getLauncher() {
    return this.launcher;
  }
  
  public final ActivityResultContract<Unit, O> getResultContract() {
    return (ActivityResultContract<Unit, O>)this.resultContract$delegate.getValue();
  }
  
  public void launch(Unit paramUnit, ActivityOptionsCompat paramActivityOptionsCompat) {
    Intrinsics.checkNotNullParameter(paramUnit, "input");
    this.launcher.launch(this.callerInput, paramActivityOptionsCompat);
  }
  
  public void unregister() {
    this.launcher.unregister();
  }
  
  @Metadata(d1 = {"\000\t\n\000\n\002\b\003*\001\001\020\000\032\016\022\004\022\002H\002\022\004\022\002H\0030\001\"\004\b\000\020\002\"\004\b\001\020\003H\n"}, d2 = {"<anonymous>", "androidx/activity/result/ActivityResultCallerLauncher$resultContract$2$1", "I", "O"}, k = 3, mv = {1, 5, 1}, xi = 48)
  static final class ActivityResultCallerLauncher$resultContract$2 extends Lambda implements Function0<ActivityResultCallerLauncher$resultContract$2.null> {
    ActivityResultCallerLauncher$resultContract$2() {
      super(0);
    }
    
    public final null invoke() {
      return (null)new ActivityResultContract<Unit, O>() {
          public Intent createIntent(Context param1Context, Unit param1Unit) {
            Intrinsics.checkNotNullParameter(param1Context, "context");
            Intrinsics.checkNotNullParameter(param1Unit, "input");
            return ActivityResultCallerLauncher.this.getCallerContract().createIntent(param1Context, ActivityResultCallerLauncher.this.getCallerInput());
          }
          
          public O parseResult(int param1Int, Intent param1Intent) {
            return (O)ActivityResultCallerLauncher.this.getCallerContract().parseResult(param1Int, param1Intent);
          }
        };
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\003*\001\000\b\n\030\0002\016\022\004\022\0020\002\022\004\022\0028\0000\001J\035\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\002H\026¢\006\002\020\bJ\037\020\t\032\0028\0002\006\020\n\032\0020\0132\b\020\f\032\004\030\0010\004H\026¢\006\002\020\r¨\006\016"}, d2 = {"androidx/activity/result/ActivityResultCallerLauncher$resultContract$2$1", "Landroidx/activity/result/contract/ActivityResultContract;", "", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "(Landroid/content/Context;Lkotlin/Unit;)Landroid/content/Intent;", "parseResult", "resultCode", "", "intent", "(ILandroid/content/Intent;)Ljava/lang/Object;", "activity-ktx_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class null extends ActivityResultContract<Unit, O> {
    public Intent createIntent(Context param1Context, Unit param1Unit) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Unit, "input");
      return ActivityResultCallerLauncher.this.getCallerContract().createIntent(param1Context, ActivityResultCallerLauncher.this.getCallerInput());
    }
    
    public O parseResult(int param1Int, Intent param1Intent) {
      return (O)ActivityResultCallerLauncher.this.getCallerContract().parseResult(param1Int, param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\activity\result\ActivityResultCallerLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */