package androidx.activity;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;

@Metadata(d1 = {"\000\024\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\032\035\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\004H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006"}, d2 = {"trackPipAnimationHintView", "", "Landroid/app/Activity;", "view", "Landroid/view/View;", "(Landroid/app/Activity;Landroid/view/View;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity-ktx_release"}, k = 2, mv = {1, 5, 1}, xi = 48)
public final class PipHintTrackerKt {
  public static final Object trackPipAnimationHintView(Activity paramActivity, View paramView, Continuation<? super Unit> paramContinuation) {
    Object object = FlowKt.callbackFlow(new PipHintTrackerKt$trackPipAnimationHintView$flow$1(paramView, null)).collect(new PipHintTrackerKt$trackPipAnimationHintView$$inlined$collect$1(paramActivity), paramContinuation);
    return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
  }
  
  private static final Rect trackPipAnimationHintView$positionInWindow(View paramView) {
    Rect rect = new Rect();
    paramView.getGlobalVisibleRect(rect);
    return rect;
  }
  
  @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 5, 1})
  public static final class PipHintTrackerKt$trackPipAnimationHintView$$inlined$collect$1 implements FlowCollector<Rect> {
    public PipHintTrackerKt$trackPipAnimationHintView$$inlined$collect$1(Activity param1Activity) {}
    
    public Object emit(Object param1Object, Continuation param1Continuation) {
      param1Object = param1Object;
      Api26Impl.INSTANCE.setPipParamsSourceRectHint(this.$this_trackPipAnimationHintView$inlined, (Rect)param1Object);
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\002\030\002\n\002\030\002\020\000\032\0020\001*\b\022\004\022\0020\0030\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/channels/ProducerScope;", "Landroid/graphics/Rect;"}, k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1", f = "PipHintTracker.kt", i = {}, l = {88}, m = "invokeSuspend", n = {}, s = {})
  static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1 extends SuspendLambda implements Function2<ProducerScope<? super Rect>, Continuation<? super Unit>, Object> {
    int label;
    
    PipHintTrackerKt$trackPipAnimationHintView$flow$1(View param1View, Continuation<? super PipHintTrackerKt$trackPipAnimationHintView$flow$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1(this.$view, (Continuation)param1Continuation);
      pipHintTrackerKt$trackPipAnimationHintView$flow$1.L$0 = param1Object;
      return (Continuation<Unit>)pipHintTrackerKt$trackPipAnimationHintView$flow$1;
    }
    
    public final Object invoke(ProducerScope<? super Rect> param1ProducerScope, Continuation<? super Unit> param1Continuation) {
      return ((PipHintTrackerKt$trackPipAnimationHintView$flow$1)create(param1ProducerScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = this.L$0;
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1((ProducerScope<? super Rect>)param1Object);
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1((ProducerScope<? super Rect>)param1Object, this.$view);
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1((ProducerScope<? super Rect>)param1Object, this.$view, pipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1, pipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1);
        if (Api19Impl.INSTANCE.isAttachedToWindow(this.$view)) {
          param1Object.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
          this.$view.getViewTreeObserver().addOnScrollChangedListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1);
          this.$view.addOnLayoutChangeListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1);
        } 
        this.$view.addOnAttachStateChangeListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1);
        Function0<Unit> function0 = new Function0<Unit>(this.$view, pipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1, pipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1, pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1) {
            public final void invoke() {
              this.$view.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
              this.$view.removeOnLayoutChangeListener(this.$layoutChangeListener);
              this.$view.removeOnAttachStateChangeListener(this.$attachStateChangeListener);
            }
          };
        Continuation continuation = (Continuation)this;
        this.label = 1;
        if (ProduceKt.awaitClose((ProducerScope)param1Object, function0, continuation) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
    
    @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/activity/PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "v", "Landroid/view/View;", "onViewDetachedFromWindow", "activity-ktx_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 implements View.OnAttachStateChangeListener {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener) {}
      
      public void onViewAttachedToWindow(View param1View) {
        Intrinsics.checkNotNullParameter(param1View, "v");
        this.$$this$callbackFlow.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
        this.$view.getViewTreeObserver().addOnScrollChangedListener(this.$scrollChangeListener);
        this.$view.addOnLayoutChangeListener(this.$layoutChangeListener);
      }
      
      public void onViewDetachedFromWindow(View param1View) {
        Intrinsics.checkNotNullParameter(param1View, "v");
        param1View.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
        param1View.removeOnLayoutChangeListener(this.$layoutChangeListener);
      }
    }
    
    @Metadata(d1 = {"\000\030\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\007\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\006\020\005\032\0020\0062\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\t\032\0020\0062\006\020\n\032\0020\0062\006\020\013\032\0020\0062\006\020\f\032\0020\0062\006\020\r\032\0020\006H\n"}, d2 = {"<anonymous>", "", "v", "Landroid/view/View;", "kotlin.jvm.PlatformType", "l", "", "t", "r", "b", "oldLeft", "oldTop", "oldRight", "oldBottom"}, k = 3, mv = {1, 5, 1}, xi = 48)
    static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1 implements View.OnLayoutChangeListener {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1(ProducerScope<? super Rect> param1ProducerScope) {}
      
      public final void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
        if (param1Int1 != param1Int5 || param1Int3 != param1Int7 || param1Int2 != param1Int6 || param1Int4 != param1Int8) {
          ProducerScope<Rect> producerScope = this.$$this$callbackFlow;
          Intrinsics.checkNotNullExpressionValue(param1View, "v");
          producerScope.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(param1View));
        } 
      }
    }
    
    @Metadata(d1 = {"\000\006\n\000\n\002\020\002\020\000\032\0020\001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {1, 5, 1}, xi = 48)
    static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1 implements ViewTreeObserver.OnScrollChangedListener {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View) {}
      
      public final void onScrollChanged() {
        this.$$this$callbackFlow.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
      }
    }
  }
  
  @Metadata(d1 = {"\000\006\n\000\n\002\020\002\020\000\032\0020\001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {1, 5, 1}, xi = 48)
  static final class null extends Lambda implements Function0<Unit> {
    null(View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener, PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 param1PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1) {
      super(0);
    }
    
    public final void invoke() {
      this.$view.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
      this.$view.removeOnLayoutChangeListener(this.$layoutChangeListener);
      this.$view.removeOnAttachStateChangeListener(this.$attachStateChangeListener);
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/activity/PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "v", "Landroid/view/View;", "onViewDetachedFromWindow", "activity-ktx_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 implements View.OnAttachStateChangeListener {
    PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "v");
      this.$$this$callbackFlow.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
      this.$view.getViewTreeObserver().addOnScrollChangedListener(this.$scrollChangeListener);
      this.$view.addOnLayoutChangeListener(this.$layoutChangeListener);
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "v");
      param1View.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
      param1View.removeOnLayoutChangeListener(this.$layoutChangeListener);
    }
  }
  
  @Metadata(d1 = {"\000\030\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\007\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\006\020\005\032\0020\0062\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\t\032\0020\0062\006\020\n\032\0020\0062\006\020\013\032\0020\0062\006\020\f\032\0020\0062\006\020\r\032\0020\006H\n"}, d2 = {"<anonymous>", "", "v", "Landroid/view/View;", "kotlin.jvm.PlatformType", "l", "", "t", "r", "b", "oldLeft", "oldTop", "oldRight", "oldBottom"}, k = 3, mv = {1, 5, 1}, xi = 48)
  static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1 implements View.OnLayoutChangeListener {
    PipHintTrackerKt$trackPipAnimationHintView$flow$1$layoutChangeListener$1(ProducerScope<? super Rect> param1ProducerScope) {}
    
    public final void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      if (param1Int1 != param1Int5 || param1Int3 != param1Int7 || param1Int2 != param1Int6 || param1Int4 != param1Int8) {
        ProducerScope<Rect> producerScope = this.$$this$callbackFlow;
        Intrinsics.checkNotNullExpressionValue(param1View, "v");
        producerScope.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(param1View));
      } 
    }
  }
  
  @Metadata(d1 = {"\000\006\n\000\n\002\020\002\020\000\032\0020\001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {1, 5, 1}, xi = 48)
  static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1 implements ViewTreeObserver.OnScrollChangedListener {
    PipHintTrackerKt$trackPipAnimationHintView$flow$1$scrollChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View) {}
    
    public final void onScrollChanged() {
      this.$$this$callbackFlow.offer(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\DudoPost-dex2jar.jar!\androidx\activity\PipHintTrackerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */