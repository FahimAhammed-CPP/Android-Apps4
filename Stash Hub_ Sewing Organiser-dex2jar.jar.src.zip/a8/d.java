package a8;

import c8.c;
import c8.f;
import kotlin.jvm.internal.l;

public final class d {
  public static final String a(Object paramObject1, Object paramObject2) {
    l.f(paramObject1, "from");
    l.f(paramObject2, "until");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Random range is empty: [");
    stringBuilder.append(paramObject1);
    stringBuilder.append(", ");
    stringBuilder.append(paramObject2);
    stringBuilder.append(").");
    return stringBuilder.toString();
  }
  
  public static final void b(int paramInt1, int paramInt2) {
    boolean bool;
    if (paramInt2 > paramInt1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalArgumentException(a(Integer.valueOf(paramInt1), Integer.valueOf(paramInt2)).toString());
  }
  
  public static final void c(long paramLong1, long paramLong2) {
    boolean bool;
    if (paramLong2 > paramLong1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalArgumentException(a(Long.valueOf(paramLong1), Long.valueOf(paramLong2)).toString());
  }
  
  public static final int d(int paramInt) {
    return 31 - Integer.numberOfLeadingZeros(paramInt);
  }
  
  public static final int e(c paramc, c paramc1) {
    l.f(paramc, "<this>");
    l.f(paramc1, "range");
    if (!paramc1.isEmpty())
      return (paramc1.c() < Integer.MAX_VALUE) ? paramc.d(paramc1.a(), paramc1.c() + 1) : ((paramc1.a() > Integer.MIN_VALUE) ? (paramc.d(paramc1.a() - 1, paramc1.c()) + 1) : paramc.c()); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot get random in empty range: ");
    stringBuilder.append(paramc1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final long f(c paramc, f paramf) {
    l.f(paramc, "<this>");
    l.f(paramf, "range");
    if (!paramf.isEmpty()) {
      long l1 = paramf.c();
      long l2 = paramf.a();
      return (l1 < Long.MAX_VALUE) ? paramc.f(l2, paramf.c() + 1L) : ((l2 > Long.MIN_VALUE) ? (paramc.f(paramf.a() - 1L, paramf.c()) + 1L) : paramc.e());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot get random in empty range: ");
    stringBuilder.append(paramf);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final int g(int paramInt1, int paramInt2) {
    return paramInt1 >>> 32 - paramInt2 & -paramInt2 >> 31;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a8\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */