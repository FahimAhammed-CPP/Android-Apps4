package a8;

import java.io.Serializable;
import kotlin.jvm.internal.h;
import t7.b;

public abstract class c {
  public static final a a = new a(null);
  
  private static final c b = b.a.b();
  
  public abstract int b(int paramInt);
  
  public abstract int c();
  
  public int d(int paramInt1, int paramInt2) {
    d.b(paramInt1, paramInt2);
    int i = paramInt2 - paramInt1;
    if (i > 0 || i == Integer.MIN_VALUE) {
      if ((-i & i) == i) {
        paramInt2 = b(d.d(i));
      } else {
        int j;
        do {
          j = c() >>> 1;
          paramInt2 = j % i;
        } while (j - paramInt2 + i - 1 < 0);
      } 
      return paramInt1 + paramInt2;
    } 
    while (true) {
      int j = c();
      boolean bool = false;
      i = bool;
      if (paramInt1 <= j) {
        i = bool;
        if (j < paramInt2)
          i = 1; 
      } 
      if (i != 0)
        return j; 
    } 
  }
  
  public abstract long e();
  
  public long f(long paramLong1, long paramLong2) {
    d.c(paramLong1, paramLong2);
    long l = paramLong2 - paramLong1;
    if (l > 0L) {
      if ((-l & l) == l) {
        int i = (int)l;
        int j = (int)(l >>> 32L);
        if (i != 0) {
          i = b(d.d(i));
        } else if (j == 1) {
          i = c();
        } else {
          paramLong2 = (b(d.d(j)) << 32L) + (c() & 0xFFFFFFFFL);
          return paramLong1 + paramLong2;
        } 
        paramLong2 = i & 0xFFFFFFFFL;
      } else {
        long l1;
        do {
          l1 = e() >>> 1L;
          paramLong2 = l1 % l;
        } while (l1 - paramLong2 + l - 1L < 0L);
      } 
      return paramLong1 + paramLong2;
    } 
    while (true) {
      l = e();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (paramLong1 <= l) {
        bool1 = bool2;
        if (l < paramLong2)
          bool1 = true; 
      } 
      if (bool1)
        return l; 
    } 
  }
  
  public static final class a extends c implements Serializable {
    private a() {}
    
    public int b(int param1Int) {
      return c.a().b(param1Int);
    }
    
    public int c() {
      return c.a().c();
    }
    
    public int d(int param1Int1, int param1Int2) {
      return c.a().d(param1Int1, param1Int2);
    }
    
    public long e() {
      return c.a().e();
    }
    
    public long f(long param1Long1, long param1Long2) {
      return c.a().f(param1Long1, param1Long2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a8\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */