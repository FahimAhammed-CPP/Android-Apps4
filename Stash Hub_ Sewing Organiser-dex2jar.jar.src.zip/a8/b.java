package a8;

import java.util.Random;
import kotlin.jvm.internal.l;

public final class b extends a {
  private final a c = new a();
  
  public Random g() {
    Random random = (Random)this.c.get();
    l.e(random, "implStorage.get()");
    return random;
  }
  
  public static final class a extends ThreadLocal<Random> {
    protected Random a() {
      return new Random();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a8\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */