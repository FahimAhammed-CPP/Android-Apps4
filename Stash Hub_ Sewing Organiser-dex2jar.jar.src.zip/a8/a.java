package a8;

import java.util.Random;

public abstract class a extends c {
  public int b(int paramInt) {
    return d.g(g().nextInt(), paramInt);
  }
  
  public int c() {
    return g().nextInt();
  }
  
  public long e() {
    return g().nextLong();
  }
  
  public abstract Random g();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */