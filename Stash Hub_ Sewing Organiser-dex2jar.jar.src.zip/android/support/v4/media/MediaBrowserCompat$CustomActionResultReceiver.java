package android.support.v4.media;

import a.b;
import android.os.Bundle;

class MediaBrowserCompat$CustomActionResultReceiver extends b {
  protected void a(int paramInt, Bundle paramBundle) {}
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$CustomActionResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */