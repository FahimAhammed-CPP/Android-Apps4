package a0;

public final class b {
  public static final int a = 2131427328;
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */