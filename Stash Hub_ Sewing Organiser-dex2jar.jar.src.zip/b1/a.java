package b1;

import a1.c;
import android.graphics.PorterDuff;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;
import n6.j;
import p7.m;
import z0.b;
import z0.c;
import z0.d;
import z0.e;
import z0.i;
import z0.j;
import z0.k;
import z0.l;
import z0.m;

public final class a {
  public static final a a = new a();
  
  private final m d(Map<?, ?> paramMap) {
    Object object1 = paramMap.get("text");
    l.c(object1);
    object1 = a(object1);
    Object object2 = paramMap.get("x");
    l.c(object2);
    int i = ((Number)a(object2)).intValue();
    object2 = paramMap.get("y");
    l.c(object2);
    int j = ((Number)a(object2)).intValue();
    object2 = paramMap.get("size");
    l.c(object2);
    int k = ((Number)a(object2)).intValue();
    object2 = paramMap.get("r");
    l.c(object2);
    int m = ((Number)a(object2)).intValue();
    object2 = paramMap.get("g");
    l.c(object2);
    int n = ((Number)a(object2)).intValue();
    object2 = paramMap.get("b");
    l.c(object2);
    int i1 = ((Number)a(object2)).intValue();
    object2 = paramMap.get("a");
    l.c(object2);
    int i2 = ((Number)a(object2)).intValue();
    paramMap = (Map<?, ?>)paramMap.get("fontName");
    l.c(paramMap);
    return new m((String)object1, i, j, k, m, n, i1, i2, a(paramMap));
  }
  
  private final b e(Object paramObject) {
    if (!(paramObject instanceof Map))
      return new b(0, 0, -1, -1); 
    paramObject = paramObject;
    Object object = paramObject.get("width");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    int i = ((Number)object).intValue();
    object = paramObject.get("height");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    int j = ((Number)object).intValue();
    object = paramObject.get("x");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    int k = ((Number)object).intValue();
    paramObject = paramObject.get("y");
    l.d(paramObject, "null cannot be cast to non-null type kotlin.Number");
    return new b(k, ((Number)paramObject).intValue(), i, j);
  }
  
  private final c f(Object paramObject) {
    if (!(paramObject instanceof Map))
      return c.b.a(); 
    paramObject = ((Map)paramObject).get("matrix");
    l.d(paramObject, "null cannot be cast to non-null type kotlin.collections.List<*>");
    List list = (List)paramObject;
    paramObject = new ArrayList(m.k(list, 10));
    for (Number number : list) {
      float f;
      if (number instanceof Double) {
        f = (float)((Number)number).doubleValue();
      } else {
        f = 0.0F;
      } 
      paramObject.add(Float.valueOf(f));
    } 
    return new c(m.K((Collection)paramObject));
  }
  
  private final d g(Object paramObject) {
    if (!(paramObject instanceof Map))
      return new d(false, false, 3, null); 
    paramObject = paramObject;
    Object object = paramObject.get("h");
    l.d(object, "null cannot be cast to non-null type kotlin.Boolean");
    boolean bool = ((Boolean)object).booleanValue();
    paramObject = paramObject.get("v");
    l.d(paramObject, "null cannot be cast to non-null type kotlin.Boolean");
    return new d(bool, ((Boolean)paramObject).booleanValue());
  }
  
  private final k i(Object paramObject) {
    if (!(paramObject instanceof Map))
      return new k(0); 
    paramObject = ((Map)paramObject).get("degree");
    l.d(paramObject, "null cannot be cast to non-null type kotlin.Int");
    return new k(((Integer)paramObject).intValue());
  }
  
  private final l j(Object paramObject) {
    if (!(paramObject instanceof Map))
      return null; 
    paramObject = paramObject;
    Object object = paramObject.get("width");
    l.d(object, "null cannot be cast to non-null type kotlin.Int");
    int i = ((Integer)object).intValue();
    object = paramObject.get("height");
    l.d(object, "null cannot be cast to non-null type kotlin.Int");
    int j = ((Integer)object).intValue();
    object = paramObject.get("keepRatio");
    l.d(object, "null cannot be cast to non-null type kotlin.Boolean");
    boolean bool = ((Boolean)object).booleanValue();
    paramObject = paramObject.get("keepWidthFirst");
    l.d(paramObject, "null cannot be cast to non-null type kotlin.Boolean");
    return new l(i, j, bool, ((Boolean)paramObject).booleanValue());
  }
  
  private final z0.a k(Object paramObject) {
    if (!(paramObject instanceof Map))
      return null; 
    paramObject = ((Map)paramObject).get("texts");
    l.c(paramObject);
    List list = a(paramObject);
    if (list.isEmpty())
      return null; 
    paramObject = new z0.a();
    for (Map map : list) {
      if (map instanceof Map)
        paramObject.a(d(map)); 
    } 
    return (z0.a)paramObject;
  }
  
  public final <T> T a(Object paramObject) {
    l.f(paramObject, "<this>");
    return (T)paramObject;
  }
  
  public final List<j> b(List<? extends Object> paramList, x0.a parama) {
    l.f(paramList, "optionList");
    l.f(parama, "bitmapWrapper");
    ArrayList<k> arrayList = new ArrayList();
    if (parama.b() != 0)
      arrayList.add(new k(parama.b())); 
    if (!parama.c().a())
      arrayList.add(parama.c()); 
    for (List<? extends Object> paramList : paramList) {
      d d;
      c c;
      if (!(paramList instanceof Map))
        continue; 
      Map map = (Map)paramList;
      paramList = (List<? extends Object>)map.get("value");
      if (!(paramList instanceof Map))
        continue; 
      map = (Map)map.get("type");
      if (l.b(map, "flip")) {
        d = g(paramList);
      } else {
        b b;
        if (l.b(map, "clip")) {
          b = e(d);
        } else {
          k k;
          if (l.b(map, "rotate")) {
            k = i(b);
          } else {
            c c1;
            if (l.b(map, "color")) {
              c1 = f(k);
            } else {
              l l1;
              l l2;
              if (l.b(map, "scale")) {
                l2 = j(c1);
                l1 = l2;
                if (l2 == null)
                  continue; 
              } else {
                z0.a a1;
                z0.a a2;
                if (l.b(l2, "add_text")) {
                  a2 = k(l1);
                  a1 = a2;
                  if (a2 == null)
                    continue; 
                } else {
                  i i;
                  if (l.b(a2, "mix_image")) {
                    i = new i((Map)a1);
                  } else if (l.b(a2, "draw")) {
                    c = new c((Map)i);
                  } else {
                    continue;
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
      arrayList.add(c);
    } 
    return (List)arrayList;
  }
  
  public final PorterDuff.Mode c(String paramString) {
    l.f(paramString, "type");
    switch (paramString.hashCode()) {
      default:
        return PorterDuff.Mode.SRC_OVER;
      case 1958005817:
        if (paramString.equals("dstOver"))
          return PorterDuff.Mode.DST_OVER; 
      case 1957556377:
        if (paramString.equals("dstATop"))
          return PorterDuff.Mode.DST_ATOP; 
      case 653829668:
        if (paramString.equals("multiply"))
          return PorterDuff.Mode.MULTIPLY; 
      case 170546239:
        if (paramString.equals("lighten"))
          return PorterDuff.Mode.LIGHTEN; 
      case 109698601:
        if (paramString.equals("srcIn"))
          return PorterDuff.Mode.SRC_IN; 
      case 95891914:
        if (paramString.equals("dstIn"))
          return PorterDuff.Mode.DST_IN; 
      case 94746189:
        if (paramString.equals("clear"))
          return PorterDuff.Mode.CLEAR; 
      case 118875:
        if (paramString.equals("xor"))
          return PorterDuff.Mode.XOR; 
      case 114148:
        if (paramString.equals("src"))
          return PorterDuff.Mode.SRC; 
      case 99781:
        if (paramString.equals("dst"))
          return PorterDuff.Mode.DST; 
      case -894304566:
        if (paramString.equals("srcOut"))
          return PorterDuff.Mode.SRC_OUT; 
      case -907689876:
        if (paramString.equals("screen"))
          return PorterDuff.Mode.SCREEN; 
      case -1091287984:
        if (paramString.equals("overlay"))
          return PorterDuff.Mode.OVERLAY; 
      case -1322311863:
        if (paramString.equals("dstOut"))
          return PorterDuff.Mode.DST_OUT; 
      case -1338968417:
        if (paramString.equals("darken"))
          return PorterDuff.Mode.DARKEN; 
      case -1953637160:
        paramString.equals("srcOver");
      case -1954086600:
        break;
    } 
    if (!paramString.equals("srcATop"));
    return PorterDuff.Mode.SRC_ATOP;
  }
  
  public final e h(j paramj) {
    l.f(paramj, "call");
    Object object = paramj.a("fmt");
    l.c(object);
    return new e((Map)object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */