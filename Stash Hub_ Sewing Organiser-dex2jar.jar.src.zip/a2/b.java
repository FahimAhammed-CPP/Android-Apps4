package a2;

public final class b {
  public static final int a = 2131427338;
  
  public static final int b = 2131427339;
  
  public static final int c = 2131427340;
  
  public static final int d = 2131427341;
  
  public static final int e = 2131427342;
  
  public static final int f = 2131427343;
  
  public static final int g = 2131427344;
  
  public static final int h = 2131427345;
  
  public static final int i = 2131427347;
  
  public static final int j = 2131427348;
  
  public static final int k = 2131427349;
  
  public static final int l = 2131427350;
  
  public static final int m = 2131427351;
  
  public static final int n = 2131427352;
  
  public static final int o = 2131427353;
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */