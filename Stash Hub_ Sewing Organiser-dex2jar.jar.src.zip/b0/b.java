package b0;

import android.os.Trace;

final class b {
  public static void a(String paramString) {
    Trace.beginSection(paramString);
  }
  
  public static void b() {
    Trace.endSection();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */