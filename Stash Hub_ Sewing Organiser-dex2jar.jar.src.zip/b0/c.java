package b0;

import android.os.Trace;

final class c {
  public static void a(String paramString, int paramInt) {
    Trace.beginAsyncSection(paramString, paramInt);
  }
  
  public static void b(String paramString, int paramInt) {
    Trace.endAsyncSection(paramString, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */