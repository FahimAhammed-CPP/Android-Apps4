package a4;

public final class a {
  private final String a;
  
  private final int b;
  
  public a(String paramString, int paramInt) {
    this.a = paramString;
    this.b = paramInt;
  }
  
  public String a() {
    return this.a;
  }
  
  public int b() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */