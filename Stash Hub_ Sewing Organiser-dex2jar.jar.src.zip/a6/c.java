package a6;

import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import n6.c;

class c implements c, f {
  private final FlutterJNI a;
  
  private final Map<String, f> b = new HashMap<String, f>();
  
  private Map<String, List<b>> c = new HashMap<String, List<b>>();
  
  private final Object d = new Object();
  
  private final AtomicBoolean e = new AtomicBoolean(false);
  
  private final Map<Integer, c.b> f = new HashMap<Integer, c.b>();
  
  private int g = 1;
  
  private final d h = new g();
  
  private WeakHashMap<c.c, d> i = new WeakHashMap<c.c, d>();
  
  private i j;
  
  c(FlutterJNI paramFlutterJNI) {
    this(paramFlutterJNI, new e());
  }
  
  c(FlutterJNI paramFlutterJNI, i parami) {
    this.a = paramFlutterJNI;
    this.j = parami;
  }
  
  private void j(String paramString, f paramf, ByteBuffer paramByteBuffer, int paramInt, long paramLong) {
    d d1;
    String str;
    if (paramf != null) {
      str = (String)paramf.b;
    } else {
      str = null;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PlatformChannel ScheduleHandler on ");
    stringBuilder.append(paramString);
    c7.e.b(stringBuilder.toString(), paramInt);
    b b = new b(this, paramString, paramInt, paramf, paramByteBuffer, paramLong);
    paramString = str;
    if (str == null)
      d1 = this.h; 
    d1.a(b);
  }
  
  private static void k(Error paramError) {
    Thread thread = Thread.currentThread();
    if (thread.getUncaughtExceptionHandler() != null) {
      thread.getUncaughtExceptionHandler().uncaughtException(thread, paramError);
      return;
    } 
    throw paramError;
  }
  
  private void l(f paramf, ByteBuffer paramByteBuffer, int paramInt) {
    if (paramf != null) {
      try {
        z5.b.f("DartMessenger", "Deferring to registered handler to process message.");
        paramf.a.a(paramByteBuffer, new g(this.a, paramInt));
        return;
      } catch (Exception exception) {
        z5.b.c("DartMessenger", "Uncaught exception in binary message listener", exception);
      } catch (Error error) {
        k(error);
        return;
      } 
    } else {
      z5.b.f("DartMessenger", "No registered handler for message. Responding to Dart with empty reply message.");
    } 
    this.a.invokePlatformMessageEmptyResponseCallback(paramInt);
  }
  
  public c.c a(c.d paramd) {
    d d1 = this.j.a(paramd);
    j j = new j(null);
    this.i.put(j, d1);
    return j;
  }
  
  public void b(String paramString, c.a parama) {
    f(paramString, parama, null);
  }
  
  public void d(String paramString, ByteBuffer paramByteBuffer, c.b paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DartMessenger#send on ");
    stringBuilder.append(paramString);
    c7.e.a(stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Sending message with callback over channel '");
      stringBuilder.append(paramString);
      stringBuilder.append("'");
      z5.b.f("DartMessenger", stringBuilder.toString());
      int j = this.g;
      this.g = j + 1;
      if (paramb != null)
        this.f.put(Integer.valueOf(j), paramb); 
      if (paramByteBuffer == null) {
        this.a.dispatchEmptyPlatformMessage(paramString, j);
      } else {
        this.a.dispatchPlatformMessage(paramString, paramByteBuffer, paramByteBuffer.position(), j);
      } 
      return;
    } finally {
      c7.e.d();
    } 
  }
  
  public void e(String paramString, ByteBuffer paramByteBuffer) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Sending message over channel '");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    z5.b.f("DartMessenger", stringBuilder.toString());
    d(paramString, paramByteBuffer, null);
  }
  
  public void f(String paramString, c.a parama, c.c paramc) {
    if (parama == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Removing handler for channel '");
      stringBuilder1.append(paramString);
      stringBuilder1.append("'");
      z5.b.f("DartMessenger", stringBuilder1.toString());
      synchronized (this.d) {
        this.b.remove(paramString);
        return;
      } 
    } 
    d d1 = null;
    if (paramc != null) {
      d1 = this.i.get(paramc);
      if (d1 == null)
        throw new IllegalArgumentException("Unrecognized TaskQueue, use BinaryMessenger to create your TaskQueue (ex makeBackgroundTaskQueue)."); 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Setting handler for channel '");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    z5.b.f("DartMessenger", stringBuilder.toString());
    synchronized (this.d) {
      this.b.put(paramString, new f(parama, d1));
      List list = this.c.remove(paramString);
      if (list == null)
        return; 
      for (Object null : list)
        j(paramString, this.b.get(paramString), ((b)null).a, ((b)null).b, ((b)null).c); 
      return;
    } 
  }
  
  public void g(int paramInt, ByteBuffer paramByteBuffer) {
    z5.b.f("DartMessenger", "Received message reply from Dart.");
    c.b b = this.f.remove(Integer.valueOf(paramInt));
    if (b != null)
      try {
        z5.b.f("DartMessenger", "Invoking registered callback for reply from Dart.");
        b.a(paramByteBuffer);
        if (paramByteBuffer != null && paramByteBuffer.isDirect()) {
          paramByteBuffer.limit(0);
          return;
        } 
      } catch (Exception exception) {
        z5.b.c("DartMessenger", "Uncaught exception in binary message reply handler", exception);
      } catch (Error error) {
        k(error);
        return;
      }  
  }
  
  public void h(String paramString, ByteBuffer paramByteBuffer, int paramInt, long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Received message from Dart over channel '");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    z5.b.f("DartMessenger", stringBuilder.toString());
    synchronized (this.d) {
      boolean bool;
      f f1 = this.b.get(paramString);
      if (this.e.get() && f1 == null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        if (!this.c.containsKey(paramString))
          this.c.put(paramString, new LinkedList<b>()); 
        ((List<b>)this.c.get(paramString)).add(new b(paramByteBuffer, paramInt, paramLong));
      } 
      if (!bool)
        j(paramString, f1, paramByteBuffer, paramInt, paramLong); 
      return;
    } 
  }
  
  private static class b {
    public final ByteBuffer a;
    
    int b;
    
    long c;
    
    b(ByteBuffer param1ByteBuffer, int param1Int, long param1Long) {
      this.a = param1ByteBuffer;
      this.b = param1Int;
      this.c = param1Long;
    }
  }
  
  static class c implements d {
    private final ExecutorService a;
    
    c(ExecutorService param1ExecutorService) {
      this.a = param1ExecutorService;
    }
    
    public void a(Runnable param1Runnable) {
      this.a.execute(param1Runnable);
    }
  }
  
  static interface d {
    void a(Runnable param1Runnable);
  }
  
  private static class e implements i {
    ExecutorService a = z5.a.e().b();
    
    public c.d a(c.d param1d) {
      return (c.d)(param1d.a() ? new c.h(this.a) : new c.c(this.a));
    }
  }
  
  private static class f {
    public final c.a a;
    
    public final c.d b;
    
    f(c.a param1a, c.d param1d) {
      this.a = param1a;
      this.b = param1d;
    }
  }
  
  static class g implements c.b {
    private final FlutterJNI a;
    
    private final int b;
    
    private final AtomicBoolean c = new AtomicBoolean(false);
    
    g(FlutterJNI param1FlutterJNI, int param1Int) {
      this.a = param1FlutterJNI;
      this.b = param1Int;
    }
    
    public void a(ByteBuffer param1ByteBuffer) {
      if (!this.c.getAndSet(true)) {
        if (param1ByteBuffer == null) {
          this.a.invokePlatformMessageEmptyResponseCallback(this.b);
          return;
        } 
        this.a.invokePlatformMessageResponseCallback(this.b, param1ByteBuffer, param1ByteBuffer.position());
        return;
      } 
      throw new IllegalStateException("Reply already submitted");
    }
  }
  
  static class h implements d {
    private final ExecutorService a;
    
    private final ConcurrentLinkedQueue<Runnable> b;
    
    private final AtomicBoolean c;
    
    h(ExecutorService param1ExecutorService) {
      this.a = param1ExecutorService;
      this.b = new ConcurrentLinkedQueue<Runnable>();
      this.c = new AtomicBoolean(false);
    }
    
    private void d() {
      if (this.c.compareAndSet(false, true))
        try {
          Runnable runnable = this.b.poll();
          if (runnable != null)
            runnable.run(); 
        } finally {
          this.c.set(false);
          if (!this.b.isEmpty())
            this.a.execute(new e(this)); 
        }  
    }
    
    public void a(Runnable param1Runnable) {
      this.b.add(param1Runnable);
      this.a.execute(new d(this));
    }
  }
  
  static interface i {
    c.d a(c.d param1d);
  }
  
  private static class j implements c.c {
    private j() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a6\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */