package a6;

import android.os.Handler;
import android.os.Looper;
import c7.a;

public class g implements c.d {
  private final Handler a = a.a(Looper.getMainLooper());
  
  public void a(Runnable paramRunnable) {
    this.a.post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a6\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */