package a6;

import android.content.res.AssetManager;
import c7.e;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.List;
import n6.c;
import n6.u;

public class a implements c {
  private final FlutterJNI a;
  
  private final AssetManager b;
  
  private final c c;
  
  private final c d;
  
  private boolean e = false;
  
  private String f;
  
  private d g;
  
  private final c.a h;
  
  public a(FlutterJNI paramFlutterJNI, AssetManager paramAssetManager) {
    a a1 = new a(this);
    this.h = a1;
    this.a = paramFlutterJNI;
    this.b = paramAssetManager;
    c c1 = new c(paramFlutterJNI);
    this.c = c1;
    c1.b("flutter/isolate", a1);
    this.d = new c(c1, null);
    if (paramFlutterJNI.isAttached())
      this.e = true; 
  }
  
  @Deprecated
  public c.c a(c.d paramd) {
    return this.d.a(paramd);
  }
  
  @Deprecated
  public void b(String paramString, c.a parama) {
    this.d.b(paramString, parama);
  }
  
  @Deprecated
  public void d(String paramString, ByteBuffer paramByteBuffer, c.b paramb) {
    this.d.d(paramString, paramByteBuffer, paramb);
  }
  
  @Deprecated
  public void e(String paramString, ByteBuffer paramByteBuffer) {
    this.d.e(paramString, paramByteBuffer);
  }
  
  @Deprecated
  public void f(String paramString, c.a parama, c.c paramc) {
    this.d.f(paramString, parama, paramc);
  }
  
  public void j(b paramb, List<String> paramList) {
    if (this.e) {
      z5.b.g("DartExecutor", "Attempted to run a DartExecutor that is already running.");
      return;
    } 
    e.a("DartExecutor#executeDartEntrypoint");
    try {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Executing Dart entrypoint: ");
      stringBuilder.append(paramb);
      z5.b.f("DartExecutor", stringBuilder.toString());
      this.a.runBundleAndSnapshotFromLibrary(paramb.a, paramb.c, paramb.b, this.b, paramList);
      this.e = true;
      return;
    } finally {
      e.d();
    } 
  }
  
  public String k() {
    return this.f;
  }
  
  public boolean l() {
    return this.e;
  }
  
  public void m() {
    if (this.a.isAttached())
      this.a.notifyLowMemoryWarning(); 
  }
  
  public void n() {
    z5.b.f("DartExecutor", "Attached to JNI. Registering the platform message handler for this Dart execution context.");
    this.a.setPlatformMessageHandler(this.c);
  }
  
  public void o() {
    z5.b.f("DartExecutor", "Detached from JNI. De-registering the platform message handler for this Dart execution context.");
    this.a.setPlatformMessageHandler(null);
  }
  
  class a implements c.a {
    a(a this$0) {}
    
    public void a(ByteBuffer param1ByteBuffer, c.b param1b) {
      a.h(this.a, u.b.c(param1ByteBuffer));
      if (a.i(this.a) != null)
        a.i(this.a).a(a.g(this.a)); 
    }
  }
  
  public static class b {
    public final String a;
    
    public final String b;
    
    public final String c;
    
    public b(String param1String1, String param1String2) {
      this.a = param1String1;
      this.b = null;
      this.c = param1String2;
    }
    
    public b(String param1String1, String param1String2, String param1String3) {
      this.a = param1String1;
      this.b = param1String2;
      this.c = param1String3;
    }
    
    public static b a() {
      c6.d d = z5.a.e().c();
      if (d.h())
        return new b(d.f(), "main"); 
      throw new AssertionError("DartEntrypoints can only be created once a FlutterEngine is created.");
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return !this.a.equals(((b)param1Object).a) ? false : this.c.equals(((b)param1Object).c);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() * 31 + this.c.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("DartEntrypoint( bundle path: ");
      stringBuilder.append(this.a);
      stringBuilder.append(", function: ");
      stringBuilder.append(this.c);
      stringBuilder.append(" )");
      return stringBuilder.toString();
    }
  }
  
  private static class c implements c {
    private final c a;
    
    private c(c param1c) {
      this.a = param1c;
    }
    
    public c.c a(c.d param1d) {
      return this.a.a(param1d);
    }
    
    public void b(String param1String, c.a param1a) {
      this.a.b(param1String, param1a);
    }
    
    public void d(String param1String, ByteBuffer param1ByteBuffer, c.b param1b) {
      this.a.d(param1String, param1ByteBuffer, param1b);
    }
    
    public void e(String param1String, ByteBuffer param1ByteBuffer) {
      this.a.d(param1String, param1ByteBuffer, null);
    }
    
    public void f(String param1String, c.a param1a, c.c param1c) {
      this.a.f(param1String, param1a, param1c);
    }
  }
  
  public static interface d {
    void a(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a6\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */