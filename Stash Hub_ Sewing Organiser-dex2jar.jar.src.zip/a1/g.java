package a1;

import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import java.util.Map;
import kotlin.jvm.internal.l;

public interface g {
  Map<?, ?> a();
  
  Point b(Map<?, ?> paramMap);
  
  public static final class a {
    public static Point a(g param1g, Map<?, ?> param1Map) {
      l.f(param1Map, "map");
      param1g = (g)param1Map.get("x");
      l.d(param1g, "null cannot be cast to non-null type kotlin.Int");
      int i = ((Integer)param1g).intValue();
      param1g = (g)param1Map.get("y");
      l.d(param1g, "null cannot be cast to non-null type kotlin.Int");
      return new Point(i, ((Integer)param1g).intValue());
    }
    
    public static int b(g param1g, String param1String) {
      l.f(param1String, "key");
      param1g = (g)param1g.a().get("color");
      l.d(param1g, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
      Map map = (Map)param1g;
      param1String = (String)map.get("r");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int i = ((Integer)param1String).intValue();
      param1String = (String)map.get("g");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int j = ((Integer)param1String).intValue();
      param1String = (String)map.get("b");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int k = ((Integer)param1String).intValue();
      map = (Map)map.get("a");
      l.d(map, "null cannot be cast to non-null type kotlin.Int");
      return Color.argb(((Integer)map).intValue(), i, j, k);
    }
    
    public static Point c(g param1g, String param1String) {
      l.f(param1String, "key");
      param1String = (String)param1g.a().get(param1String);
      l.d(param1String, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
      return param1g.b((Map<?, ?>)param1String);
    }
    
    public static Rect d(g param1g, String param1String) {
      l.f(param1String, "key");
      param1g = (g)param1g.a().get(param1String);
      l.d(param1g, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
      Map map = (Map)param1g;
      param1String = (String)map.get("left");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int i = ((Integer)param1String).intValue();
      param1String = (String)map.get("top");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int j = ((Integer)param1String).intValue();
      param1String = (String)map.get("width");
      l.d(param1String, "null cannot be cast to non-null type kotlin.Int");
      int k = ((Integer)param1String).intValue();
      map = (Map)map.get("height");
      l.d(map, "null cannot be cast to non-null type kotlin.Int");
      return new Rect(i, j, k + i, ((Integer)map).intValue() + j);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */