package a1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;
import z0.j;

public final class c extends p implements j {
  private final List<e> b;
  
  public c(Map<?, ?> paramMap) {
    super(paramMap);
    ArrayList<n> arrayList = new ArrayList();
    paramMap = (Map<?, ?>)paramMap.get("parts");
    l.d(paramMap, "null cannot be cast to non-null type kotlin.collections.List<*>");
    for (Map<?, ?> paramMap : paramMap) {
      if (paramMap instanceof Map) {
        o o;
        n n;
        Map<?, ?> map = paramMap;
        paramMap = (Map<?, ?>)map.get("key");
        map = (Map<?, ?>)map.get("value");
        l.d(map, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
        map = map;
        if (l.b(paramMap, "rect")) {
          o = new o(map);
        } else {
          k k;
          if (l.b(o, "oval")) {
            k = new k(map);
          } else {
            h h;
            if (l.b(k, "line")) {
              h = new h(map);
            } else if (l.b(h, "point")) {
              n = new n(map);
            } else if (l.b(n, "path")) {
              l l = new l(map);
            } else {
              n = null;
            } 
          } 
        } 
        if (n != null)
          arrayList.add(n); 
      } 
    } 
    this.b = (List)arrayList;
  }
  
  public final List<e> f() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */