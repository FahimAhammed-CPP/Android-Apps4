package a1;

import android.graphics.Point;
import android.graphics.Rect;
import java.util.Map;

public abstract class p implements g {
  private final Map<?, ?> a;
  
  public p(Map<?, ?> paramMap) {
    this.a = paramMap;
  }
  
  public Map<?, ?> a() {
    return this.a;
  }
  
  public Point b(Map<?, ?> paramMap) {
    return g.a.a(this, paramMap);
  }
  
  public int c(String paramString) {
    return g.a.b(this, paramString);
  }
  
  public Point d(String paramString) {
    return g.a.c(this, paramString);
  }
  
  public Rect e(String paramString) {
    return g.a.d(this, paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */