package a1;

import android.graphics.Paint;
import android.graphics.Rect;
import java.util.Map;

public final class o extends e implements f {
  private final Rect b = e("rect");
  
  public o(Map<?, ?> paramMap) {
    super(paramMap);
  }
  
  public Paint f() {
    return f.a.a(this);
  }
  
  public final Rect g() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */