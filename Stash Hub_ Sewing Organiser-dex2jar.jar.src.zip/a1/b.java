package a1;

import android.graphics.Point;
import java.util.Map;
import kotlin.jvm.internal.l;

public final class b extends m {
  private final int b;
  
  private final Point c;
  
  private final Point d;
  
  private final Point e;
  
  public b(Map<?, ?> paramMap) {
    super(paramMap);
    paramMap = (Map<?, ?>)paramMap.get("kind");
    l.d(paramMap, "null cannot be cast to non-null type kotlin.Int");
    int i = ((Integer)paramMap).intValue();
    this.b = i;
    this.c = d("target");
    this.d = d("c1");
    if (i == 3) {
      Point point = d("c2");
    } else {
      paramMap = null;
    } 
    this.e = (Point)paramMap;
  }
  
  public final Point f() {
    return this.d;
  }
  
  public final Point g() {
    return this.e;
  }
  
  public final int h() {
    return this.b;
  }
  
  public final Point i() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */