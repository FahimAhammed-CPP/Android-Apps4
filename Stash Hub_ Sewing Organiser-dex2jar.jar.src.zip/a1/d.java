package a1;

import android.graphics.Paint;
import java.util.Map;
import kotlin.jvm.internal.l;

public final class d extends p {
  public d(Map<?, ?> paramMap) {
    super(paramMap);
  }
  
  public final Paint f() {
    Paint paint = new Paint();
    paint.setColor(c("color"));
    Object object = a().get("lineWeight");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    paint.setStrokeWidth(((Number)object).floatValue());
    object = a().get("paintStyleFill");
    l.d(object, "null cannot be cast to non-null type kotlin.Boolean");
    if (((Boolean)object).booleanValue()) {
      object = Paint.Style.FILL;
    } else {
      object = Paint.Style.STROKE;
    } 
    paint.setStyle((Paint.Style)object);
    return paint;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */