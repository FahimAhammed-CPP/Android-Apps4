package a1;

import android.graphics.Paint;
import android.graphics.Point;
import java.util.Map;

public final class h extends e implements f {
  private final Point b = d("start");
  
  private final Point c = d("end");
  
  public h(Map<?, ?> paramMap) {
    super(paramMap);
  }
  
  public final Point f() {
    return this.c;
  }
  
  public Paint g() {
    return f.a.a(this);
  }
  
  public final Point h() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */