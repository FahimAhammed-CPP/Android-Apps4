package a1;

import android.graphics.Rect;
import java.util.Map;
import kotlin.jvm.internal.l;

public final class a extends m {
  private final Rect b = e("rect");
  
  private final Number c;
  
  private final Number d;
  
  private final boolean e;
  
  public a(Map<?, ?> paramMap) {
    super(paramMap);
    Object object = paramMap.get("start");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    this.c = (Number)object;
    object = paramMap.get("sweep");
    l.d(object, "null cannot be cast to non-null type kotlin.Number");
    this.d = (Number)object;
    paramMap = (Map<?, ?>)paramMap.get("useCenter");
    l.d(paramMap, "null cannot be cast to non-null type kotlin.Boolean");
    this.e = ((Boolean)paramMap).booleanValue();
  }
  
  public final Rect f() {
    return this.b;
  }
  
  public final Number g() {
    return this.c;
  }
  
  public final Number h() {
    return this.d;
  }
  
  public final boolean i() {
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */