package a1;

import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class l extends e implements f {
  private final List<m> b;
  
  public l(Map<?, ?> paramMap) {
    super(paramMap);
    ArrayList<b> arrayList = new ArrayList();
    paramMap = (Map<?, ?>)paramMap.get("parts");
    kotlin.jvm.internal.l.d(paramMap, "null cannot be cast to non-null type kotlin.collections.List<*>");
    for (Map<?, ?> paramMap : paramMap) {
      if (paramMap instanceof Map) {
        j j;
        b b;
        Map<?, ?> map = paramMap;
        paramMap = (Map<?, ?>)map.get("key");
        map = (Map<?, ?>)map.get("value");
        kotlin.jvm.internal.l.d(map, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
        map = map;
        if (kotlin.jvm.internal.l.b(paramMap, "move")) {
          j = new j(map);
        } else {
          i i;
          if (kotlin.jvm.internal.l.b(j, "lineTo")) {
            i = new i(map);
          } else if (kotlin.jvm.internal.l.b(i, "bezier")) {
            b = new b(map);
          } else if (kotlin.jvm.internal.l.b(b, "arcTo")) {
            a a = new a(map);
          } else {
            b = null;
          } 
        } 
        if (b != null)
          arrayList.add(b); 
      } 
    } 
    this.b = (List)arrayList;
  }
  
  public final boolean f() {
    Object object = a().get("autoClose");
    kotlin.jvm.internal.l.d(object, "null cannot be cast to non-null type kotlin.Boolean");
    return ((Boolean)object).booleanValue();
  }
  
  public Paint g() {
    return f.a.a(this);
  }
  
  public final List<m> h() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */