package a1;

import android.graphics.Paint;
import java.util.Map;
import kotlin.jvm.internal.l;

public interface f extends g {
  public static final class a {
    public static Paint a(f param1f) {
      param1f = (f)param1f.a().get("paint");
      l.d(param1f, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
      return (new d((Map<?, ?>)param1f)).f();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */