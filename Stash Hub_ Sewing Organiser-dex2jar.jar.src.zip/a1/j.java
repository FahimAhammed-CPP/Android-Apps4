package a1;

import android.graphics.Point;
import java.util.Map;

public final class j extends m {
  private final Point b = d("offset");
  
  public j(Map<?, ?> paramMap) {
    super(paramMap);
  }
  
  public final Point f() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */