package a1;

import android.graphics.Paint;
import android.graphics.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;

public final class n extends e implements f {
  public n(Map<?, ?> paramMap) {
    super(paramMap);
  }
  
  public final List<Point> f() {
    ArrayList<Point> arrayList = new ArrayList();
    null = a().get("offset");
    l.d(null, "null cannot be cast to non-null type kotlin.collections.List<*>");
    for (Map map : null) {
      if (map instanceof Map)
        arrayList.add(b(map)); 
    } 
    return arrayList;
  }
  
  public Paint g() {
    return f.a.a(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a1\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */