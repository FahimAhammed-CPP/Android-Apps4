package b2;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;
import androidx.collection.f;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class b {
  private static int h;
  
  private static PendingIntent i;
  
  private static final Executor j = y.a;
  
  private final f<String, TaskCompletionSource<Bundle>> a = new f();
  
  private final Context b;
  
  private final q c;
  
  private final ScheduledExecutorService d;
  
  private Messenger e;
  
  private Messenger f;
  
  private c g;
  
  public b(Context paramContext) {
    this.b = paramContext;
    this.c = new q(paramContext);
    this.e = new Messenger((Handler)new x(this, Looper.getMainLooper()));
    ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1);
    scheduledThreadPoolExecutor.setKeepAliveTime(60L, TimeUnit.SECONDS);
    scheduledThreadPoolExecutor.allowCoreThreadTimeOut(true);
    this.d = scheduledThreadPoolExecutor;
  }
  
  private static String e() {
    // Byte code:
    //   0: ldc b2/b
    //   2: monitorenter
    //   3: getstatic b2/b.h : I
    //   6: istore_0
    //   7: iload_0
    //   8: iconst_1
    //   9: iadd
    //   10: putstatic b2/b.h : I
    //   13: iload_0
    //   14: invokestatic toString : (I)Ljava/lang/String;
    //   17: astore_1
    //   18: ldc b2/b
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: ldc b2/b
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	23	finally
  }
  
  private static void f(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: ldc b2/b
    //   2: monitorenter
    //   3: getstatic b2/b.i : Landroid/app/PendingIntent;
    //   6: ifnonnull -> 34
    //   9: new android/content/Intent
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_2
    //   17: aload_2
    //   18: ldc 'com.google.example.invalidpackage'
    //   20: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   23: pop
    //   24: aload_0
    //   25: iconst_0
    //   26: aload_2
    //   27: iconst_0
    //   28: invokestatic getBroadcast : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   31: putstatic b2/b.i : Landroid/app/PendingIntent;
    //   34: aload_1
    //   35: ldc 'app'
    //   37: getstatic b2/b.i : Landroid/app/PendingIntent;
    //   40: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   43: pop
    //   44: ldc b2/b
    //   46: monitorexit
    //   47: return
    //   48: astore_0
    //   49: ldc b2/b
    //   51: monitorexit
    //   52: aload_0
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   3	34	48	finally
    //   34	44	48	finally
  }
  
  private final void g(Message paramMessage) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 561
    //   4: aload_1
    //   5: getfield obj : Ljava/lang/Object;
    //   8: astore_3
    //   9: aload_3
    //   10: instanceof android/content/Intent
    //   13: ifeq -> 561
    //   16: aload_3
    //   17: checkcast android/content/Intent
    //   20: astore_3
    //   21: aload_3
    //   22: new b2/c$a
    //   25: dup
    //   26: invokespecial <init> : ()V
    //   29: invokevirtual setExtrasClassLoader : (Ljava/lang/ClassLoader;)V
    //   32: aload_3
    //   33: ldc 'google.messenger'
    //   35: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   38: ifeq -> 78
    //   41: aload_3
    //   42: ldc 'google.messenger'
    //   44: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   47: astore_3
    //   48: aload_3
    //   49: instanceof b2/c
    //   52: ifeq -> 63
    //   55: aload_0
    //   56: aload_3
    //   57: checkcast b2/c
    //   60: putfield g : Lb2/c;
    //   63: aload_3
    //   64: instanceof android/os/Messenger
    //   67: ifeq -> 78
    //   70: aload_0
    //   71: aload_3
    //   72: checkcast android/os/Messenger
    //   75: putfield f : Landroid/os/Messenger;
    //   78: aload_1
    //   79: getfield obj : Ljava/lang/Object;
    //   82: checkcast android/content/Intent
    //   85: astore #4
    //   87: aload #4
    //   89: invokevirtual getAction : ()Ljava/lang/String;
    //   92: astore_1
    //   93: ldc 'com.google.android.c2dm.intent.REGISTRATION'
    //   95: aload_1
    //   96: invokevirtual equals : (Ljava/lang/Object;)Z
    //   99: ifne -> 151
    //   102: ldc 'Rpc'
    //   104: iconst_3
    //   105: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   108: ifeq -> 150
    //   111: aload_1
    //   112: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   115: astore_1
    //   116: aload_1
    //   117: invokevirtual length : ()I
    //   120: ifeq -> 133
    //   123: ldc 'Unexpected response action: '
    //   125: aload_1
    //   126: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   129: astore_1
    //   130: goto -> 143
    //   133: new java/lang/String
    //   136: dup
    //   137: ldc 'Unexpected response action: '
    //   139: invokespecial <init> : (Ljava/lang/String;)V
    //   142: astore_1
    //   143: ldc 'Rpc'
    //   145: aload_1
    //   146: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   149: pop
    //   150: return
    //   151: aload #4
    //   153: ldc 'registration_id'
    //   155: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   158: astore_3
    //   159: aload_3
    //   160: astore_1
    //   161: aload_3
    //   162: ifnonnull -> 173
    //   165: aload #4
    //   167: ldc 'unregistered'
    //   169: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   172: astore_1
    //   173: aload_1
    //   174: ifnonnull -> 458
    //   177: aload #4
    //   179: ldc 'error'
    //   181: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   184: astore_3
    //   185: aload_3
    //   186: ifnonnull -> 237
    //   189: aload #4
    //   191: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   194: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   197: astore_1
    //   198: new java/lang/StringBuilder
    //   201: dup
    //   202: aload_1
    //   203: invokevirtual length : ()I
    //   206: bipush #49
    //   208: iadd
    //   209: invokespecial <init> : (I)V
    //   212: astore_3
    //   213: aload_3
    //   214: ldc 'Unexpected response, no error or registration id '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: pop
    //   220: aload_3
    //   221: aload_1
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: ldc 'Rpc'
    //   228: aload_3
    //   229: invokevirtual toString : ()Ljava/lang/String;
    //   232: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   235: pop
    //   236: return
    //   237: ldc 'Rpc'
    //   239: iconst_3
    //   240: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   243: ifeq -> 282
    //   246: aload_3
    //   247: invokevirtual length : ()I
    //   250: ifeq -> 264
    //   253: ldc_w 'Received InstanceID error '
    //   256: aload_3
    //   257: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   260: astore_1
    //   261: goto -> 275
    //   264: new java/lang/String
    //   267: dup
    //   268: ldc_w 'Received InstanceID error '
    //   271: invokespecial <init> : (Ljava/lang/String;)V
    //   274: astore_1
    //   275: ldc 'Rpc'
    //   277: aload_1
    //   278: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   281: pop
    //   282: aload_3
    //   283: ldc_w '|'
    //   286: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   289: ifeq -> 403
    //   292: aload_3
    //   293: ldc_w '\|'
    //   296: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   299: astore_1
    //   300: aload_1
    //   301: arraylength
    //   302: iconst_2
    //   303: if_icmple -> 366
    //   306: ldc_w 'ID'
    //   309: aload_1
    //   310: iconst_1
    //   311: aaload
    //   312: invokevirtual equals : (Ljava/lang/Object;)Z
    //   315: ifne -> 321
    //   318: goto -> 366
    //   321: aload_1
    //   322: iconst_2
    //   323: aaload
    //   324: astore #5
    //   326: aload_1
    //   327: iconst_3
    //   328: aaload
    //   329: astore_3
    //   330: aload_3
    //   331: astore_1
    //   332: aload_3
    //   333: ldc_w ':'
    //   336: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   339: ifeq -> 348
    //   342: aload_3
    //   343: iconst_1
    //   344: invokevirtual substring : (I)Ljava/lang/String;
    //   347: astore_1
    //   348: aload_0
    //   349: aload #5
    //   351: aload #4
    //   353: ldc 'error'
    //   355: aload_1
    //   356: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   359: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   362: invokespecial j : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   365: return
    //   366: aload_3
    //   367: invokevirtual length : ()I
    //   370: ifeq -> 384
    //   373: ldc_w 'Unexpected structured response '
    //   376: aload_3
    //   377: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   380: astore_1
    //   381: goto -> 395
    //   384: new java/lang/String
    //   387: dup
    //   388: ldc_w 'Unexpected structured response '
    //   391: invokespecial <init> : (Ljava/lang/String;)V
    //   394: astore_1
    //   395: ldc 'Rpc'
    //   397: aload_1
    //   398: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   401: pop
    //   402: return
    //   403: aload_0
    //   404: getfield a : Landroidx/collection/f;
    //   407: astore_1
    //   408: aload_1
    //   409: monitorenter
    //   410: iconst_0
    //   411: istore_2
    //   412: iload_2
    //   413: aload_0
    //   414: getfield a : Landroidx/collection/f;
    //   417: invokevirtual size : ()I
    //   420: if_icmpge -> 450
    //   423: aload_0
    //   424: aload_0
    //   425: getfield a : Landroidx/collection/f;
    //   428: iload_2
    //   429: invokevirtual i : (I)Ljava/lang/Object;
    //   432: checkcast java/lang/String
    //   435: aload #4
    //   437: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   440: invokespecial j : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   443: iload_2
    //   444: iconst_1
    //   445: iadd
    //   446: istore_2
    //   447: goto -> 412
    //   450: aload_1
    //   451: monitorexit
    //   452: return
    //   453: astore_3
    //   454: aload_1
    //   455: monitorexit
    //   456: aload_3
    //   457: athrow
    //   458: ldc_w '\|ID\|([^|]+)\|:?+(.*)'
    //   461: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   464: aload_1
    //   465: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   468: astore_3
    //   469: aload_3
    //   470: invokevirtual matches : ()Z
    //   473: ifne -> 522
    //   476: ldc 'Rpc'
    //   478: iconst_3
    //   479: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   482: ifeq -> 521
    //   485: aload_1
    //   486: invokevirtual length : ()I
    //   489: ifeq -> 503
    //   492: ldc_w 'Unexpected response string: '
    //   495: aload_1
    //   496: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   499: astore_1
    //   500: goto -> 514
    //   503: new java/lang/String
    //   506: dup
    //   507: ldc_w 'Unexpected response string: '
    //   510: invokespecial <init> : (Ljava/lang/String;)V
    //   513: astore_1
    //   514: ldc 'Rpc'
    //   516: aload_1
    //   517: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   520: pop
    //   521: return
    //   522: aload_3
    //   523: iconst_1
    //   524: invokevirtual group : (I)Ljava/lang/String;
    //   527: astore_1
    //   528: aload_3
    //   529: iconst_2
    //   530: invokevirtual group : (I)Ljava/lang/String;
    //   533: astore_3
    //   534: aload_1
    //   535: ifnull -> 560
    //   538: aload #4
    //   540: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   543: astore #4
    //   545: aload #4
    //   547: ldc 'registration_id'
    //   549: aload_3
    //   550: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   553: aload_0
    //   554: aload_1
    //   555: aload #4
    //   557: invokespecial j : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   560: return
    //   561: ldc 'Rpc'
    //   563: ldc_w 'Dropping invalid message'
    //   566: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   569: pop
    //   570: return
    // Exception table:
    //   from	to	target	type
    //   412	443	453	finally
    //   450	452	453	finally
    //   454	456	453	finally
  }
  
  private final void j(String paramString, Bundle paramBundle) {
    synchronized (this.a) {
      TaskCompletionSource taskCompletionSource = (TaskCompletionSource)this.a.remove(paramString);
      if (taskCompletionSource == null) {
        paramString = String.valueOf(paramString);
        if (paramString.length() != 0) {
          paramString = "Missing callback for ".concat(paramString);
        } else {
          paramString = new String("Missing callback for ");
        } 
        Log.w("Rpc", paramString);
        return;
      } 
      taskCompletionSource.setResult(paramBundle);
      return;
    } 
  }
  
  private static boolean l(Bundle paramBundle) {
    return (paramBundle != null && paramBundle.containsKey("google.messenger"));
  }
  
  private final Task<Bundle> m(Bundle paramBundle) {
    f<String, TaskCompletionSource<Bundle>> f1;
    Messenger messenger;
    String str = e();
    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
    synchronized (this.a) {
      String str1;
      this.a.put(str, taskCompletionSource);
      Intent intent = new Intent();
      intent.setPackage("com.google.android.gms");
      if (this.c.a() == 2) {
        str1 = "com.google.iid.TOKEN_REQUEST";
      } else {
        str1 = "com.google.android.c2dm.intent.REGISTER";
      } 
      intent.setAction(str1);
      intent.putExtras(paramBundle);
      f(this.b, intent);
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 5);
      stringBuilder.append("|ID|");
      stringBuilder.append(str);
      stringBuilder.append("|");
      intent.putExtra("kid", stringBuilder.toString());
      if (Log.isLoggable("Rpc", 3)) {
        String str2 = String.valueOf(intent.getExtras());
        StringBuilder stringBuilder1 = new StringBuilder(str2.length() + 8);
        stringBuilder1.append("Sending ");
        stringBuilder1.append(str2);
        Log.d("Rpc", stringBuilder1.toString());
      } 
      intent.putExtra("google.messenger", (Parcelable)this.e);
      if (this.f != null || this.g != null) {
        Message message = Message.obtain();
        message.obj = intent;
        try {
          messenger = this.f;
          if (messenger != null) {
            messenger.send(message);
          } else {
            this.g.b(message);
          } 
          ScheduledFuture<?> scheduledFuture1 = this.d.schedule(new t(taskCompletionSource), 30L, TimeUnit.SECONDS);
          taskCompletionSource.getTask().addOnCompleteListener(j, new w(this, str, scheduledFuture1));
          return taskCompletionSource.getTask();
        } catch (RemoteException remoteException) {
          if (Log.isLoggable("Rpc", 3))
            Log.d("Rpc", "Messenger failed, fallback to startService"); 
        } 
      } 
      if (this.c.a() == 2) {
        this.b.sendBroadcast(intent);
      } else {
        this.b.startService(intent);
      } 
      ScheduledFuture<?> scheduledFuture = this.d.schedule(new t(taskCompletionSource), 30L, TimeUnit.SECONDS);
      taskCompletionSource.getTask().addOnCompleteListener(j, new w(this, str, scheduledFuture));
      return taskCompletionSource.getTask();
    } 
  }
  
  public Task<Bundle> a(Bundle paramBundle) {
    int i = this.c.c();
    boolean bool = true;
    if (i >= 12000000)
      return e.c(this.b).e(1, paramBundle).continueWith(j, s.a); 
    if (this.c.a() == 0)
      bool = false; 
    return !bool ? Tasks.forException(new IOException("MISSING_INSTANCEID_SERVICE")) : m(paramBundle).continueWithTask(j, new u(this, paramBundle));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */