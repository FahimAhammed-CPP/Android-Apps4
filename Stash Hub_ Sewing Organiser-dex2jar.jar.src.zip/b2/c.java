package b2;

import android.os.Build;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class c implements Parcelable {
  public static final Parcelable.Creator<c> CREATOR = new d();
  
  private Messenger a;
  
  private a b;
  
  public c(IBinder paramIBinder) {
    if (Build.VERSION.SDK_INT >= 21) {
      this.a = new Messenger(paramIBinder);
      return;
    } 
    this.b = new a.a(paramIBinder);
  }
  
  private final IBinder a() {
    Messenger messenger = this.a;
    return (messenger != null) ? messenger.getBinder() : this.b.asBinder();
  }
  
  public final void b(Message paramMessage) {
    Messenger messenger = this.a;
    if (messenger != null) {
      messenger.send(paramMessage);
      return;
    } 
    this.b.f(paramMessage);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    try {
      return a().equals(((c)paramObject).a());
    } catch (ClassCastException classCastException) {
      return false;
    } 
  }
  
  public int hashCode() {
    return a().hashCode();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    IBinder iBinder;
    Messenger messenger = this.a;
    if (messenger != null) {
      iBinder = messenger.getBinder();
    } else {
      iBinder = this.b.asBinder();
    } 
    paramParcel.writeStrongBinder(iBinder);
  }
  
  public static final class a extends ClassLoader {
    protected final Class<?> loadClass(String param1String, boolean param1Boolean) {
      if ("com.google.android.gms.iid.MessengerCompat".equals(param1String)) {
        boolean bool;
        if (Log.isLoggable("CloudMessengerCompat", 3) || (Build.VERSION.SDK_INT == 23 && Log.isLoggable("CloudMessengerCompat", 3))) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          Log.d("CloudMessengerCompat", "Using renamed FirebaseIidMessengerCompat class"); 
        return c.class;
      } 
      return super.loadClass(param1String, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */