package b2;

public final class o extends Exception {
  private final int a;
  
  public o(int paramInt, String paramString) {
    super(paramString);
    this.a = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */