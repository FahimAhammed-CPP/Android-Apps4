package b2;

import android.os.Bundle;

final class r extends p<Bundle> {
  r(int paramInt1, int paramInt2, Bundle paramBundle) {
    super(paramInt1, 1, paramBundle);
  }
  
  final void a(Bundle paramBundle) {
    Bundle bundle = paramBundle.getBundle("data");
    paramBundle = bundle;
    if (bundle == null)
      paramBundle = Bundle.EMPTY; 
    c((T)paramBundle);
  }
  
  final boolean d() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */