package b2;

import android.os.Bundle;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;



/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */