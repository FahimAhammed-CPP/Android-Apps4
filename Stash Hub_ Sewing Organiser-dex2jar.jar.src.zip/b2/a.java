package b2;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.Parcel;

interface a extends IInterface {
  void f(Message paramMessage);
  
  public static class a implements a {
    private final IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
    
    public void f(Message param1Message) {
      Parcel parcel = Parcel.obtain();
      parcel.writeInterfaceToken("com.google.android.gms.iid.IMessengerCompat");
      parcel.writeInt(1);
      param1Message.writeToParcel(parcel, 0);
      try {
        this.a.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */