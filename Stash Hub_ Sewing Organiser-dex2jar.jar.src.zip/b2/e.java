package b2;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.tasks.Task;
import java.util.concurrent.ScheduledExecutorService;

public final class e {
  private static e e;
  
  private final Context a;
  
  private final ScheduledExecutorService b;
  
  private f c = new f(this, null);
  
  private int d = 1;
  
  private e(Context paramContext, ScheduledExecutorService paramScheduledExecutorService) {
    this.b = paramScheduledExecutorService;
    this.a = paramContext.getApplicationContext();
  }
  
  private final int a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: istore_1
    //   7: aload_0
    //   8: iload_1
    //   9: iconst_1
    //   10: iadd
    //   11: putfield d : I
    //   14: aload_0
    //   15: monitorexit
    //   16: iload_1
    //   17: ireturn
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	18	finally
  }
  
  public static e c(Context paramContext) {
    // Byte code:
    //   0: ldc b2/e
    //   2: monitorenter
    //   3: getstatic b2/e.e : Lb2/e;
    //   6: ifnonnull -> 41
    //   9: new b2/e
    //   12: dup
    //   13: aload_0
    //   14: invokestatic zza : ()Lcom/google/android/gms/internal/cloudmessaging/zzb;
    //   17: iconst_1
    //   18: new j2/b
    //   21: dup
    //   22: ldc 'MessengerIpcClient'
    //   24: invokespecial <init> : (Ljava/lang/String;)V
    //   27: getstatic com/google/android/gms/internal/cloudmessaging/zzf.zzb : I
    //   30: invokeinterface zza : (ILjava/util/concurrent/ThreadFactory;I)Ljava/util/concurrent/ScheduledExecutorService;
    //   35: invokespecial <init> : (Landroid/content/Context;Ljava/util/concurrent/ScheduledExecutorService;)V
    //   38: putstatic b2/e.e : Lb2/e;
    //   41: getstatic b2/e.e : Lb2/e;
    //   44: astore_0
    //   45: ldc b2/e
    //   47: monitorexit
    //   48: aload_0
    //   49: areturn
    //   50: astore_0
    //   51: ldc b2/e
    //   53: monitorexit
    //   54: aload_0
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   3	41	50	finally
    //   41	45	50	finally
  }
  
  private final <T> Task<T> d(p<T> paramp) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'MessengerIpcClient'
    //   4: iconst_3
    //   5: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   8: ifeq -> 54
    //   11: aload_1
    //   12: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   15: astore_2
    //   16: new java/lang/StringBuilder
    //   19: dup
    //   20: aload_2
    //   21: invokevirtual length : ()I
    //   24: bipush #9
    //   26: iadd
    //   27: invokespecial <init> : (I)V
    //   30: astore_3
    //   31: aload_3
    //   32: ldc 'Queueing '
    //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: pop
    //   38: aload_3
    //   39: aload_2
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: pop
    //   44: ldc 'MessengerIpcClient'
    //   46: aload_3
    //   47: invokevirtual toString : ()Ljava/lang/String;
    //   50: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   53: pop
    //   54: aload_0
    //   55: getfield c : Lb2/f;
    //   58: aload_1
    //   59: invokevirtual e : (Lb2/p;)Z
    //   62: ifne -> 86
    //   65: new b2/f
    //   68: dup
    //   69: aload_0
    //   70: aconst_null
    //   71: invokespecial <init> : (Lb2/e;Lb2/g;)V
    //   74: astore_2
    //   75: aload_0
    //   76: aload_2
    //   77: putfield c : Lb2/f;
    //   80: aload_2
    //   81: aload_1
    //   82: invokevirtual e : (Lb2/p;)Z
    //   85: pop
    //   86: aload_1
    //   87: getfield b : Lcom/google/android/gms/tasks/TaskCompletionSource;
    //   90: invokevirtual getTask : ()Lcom/google/android/gms/tasks/Task;
    //   93: astore_1
    //   94: aload_0
    //   95: monitorexit
    //   96: aload_1
    //   97: areturn
    //   98: astore_1
    //   99: aload_0
    //   100: monitorexit
    //   101: aload_1
    //   102: athrow
    // Exception table:
    //   from	to	target	type
    //   2	54	98	finally
    //   54	86	98	finally
    //   86	94	98	finally
  }
  
  public final Task<Bundle> e(int paramInt, Bundle paramBundle) {
    return d(new r(a(), 1, paramBundle));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\b2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */