package a3;

import android.os.SystemClock;
import com.google.auto.value.AutoValue;

@AutoValue
public abstract class p {
  public static p a(long paramLong1, long paramLong2, long paramLong3) {
    return new a(paramLong1, paramLong2, paramLong3);
  }
  
  public static p e() {
    return a(System.currentTimeMillis(), SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
  }
  
  public abstract long b();
  
  public abstract long c();
  
  public abstract long d();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */