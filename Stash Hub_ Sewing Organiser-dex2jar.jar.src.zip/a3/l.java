package a3;

public class l extends Exception {
  @Deprecated
  protected l() {}
  
  public l(String paramString) {
    super(paramString);
  }
  
  public l(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */