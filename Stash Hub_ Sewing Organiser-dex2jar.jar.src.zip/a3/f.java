package a3;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.os.m;
import com.google.android.gms.common.internal.p;
import com.google.android.gms.common.internal.r;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.components.ComponentDiscoveryService;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.provider.FirebaseInitProvider;
import g3.g;
import g3.j;
import g3.o;
import g3.x;
import h3.m;
import i2.l;
import i2.m;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class f {
  private static final Object k = new Object();
  
  static final Map<String, f> l = (Map<String, f>)new androidx.collection.a();
  
  private final Context a;
  
  private final String b;
  
  private final n c;
  
  private final o d;
  
  private final AtomicBoolean e = new AtomicBoolean(false);
  
  private final AtomicBoolean f = new AtomicBoolean();
  
  private final x<a5.a> g;
  
  private final u4.b<s4.f> h;
  
  private final List<a> i = new CopyOnWriteArrayList<a>();
  
  private final List<g> j = new CopyOnWriteArrayList<g>();
  
  protected f(Context paramContext, String paramString, n paramn) {
    this.a = (Context)r.j(paramContext);
    this.b = r.f(paramString);
    this.c = (n)r.j(paramn);
    p p = FirebaseInitProvider.b();
    j5.c.b("Firebase");
    j5.c.b("ComponentDiscovery");
    List list = g.c(paramContext, ComponentDiscoveryService.class).b();
    j5.c.a();
    j5.c.b("Runtime");
    o.b b1 = o.m((Executor)m.a).d(list).c((ComponentRegistrar)new FirebaseCommonRegistrar()).c((ComponentRegistrar)new ExecutorsRegistrar()).b(g3.c.s(paramContext, Context.class, new Class[0])).b(g3.c.s(this, f.class, new Class[0])).b(g3.c.s(paramn, n.class, new Class[0])).g((j)new j5.b());
    if (m.a(paramContext) && FirebaseInitProvider.c())
      b1.b(g3.c.s(p, p.class, new Class[0])); 
    o o1 = b1.e();
    this.d = o1;
    j5.c.a();
    this.g = new x(new e(this, paramContext));
    this.h = o1.d(s4.f.class);
    g(new d(this));
    j5.c.a();
  }
  
  private static String B(String paramString) {
    return paramString.trim();
  }
  
  private void C(boolean paramBoolean) {
    Log.d("FirebaseApp", "Notifying background state change listeners.");
    Iterator<a> iterator = this.i.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).a(paramBoolean); 
  }
  
  private void D() {
    Iterator<g> iterator = this.j.iterator();
    while (iterator.hasNext())
      ((g)iterator.next()).b(this.b, this.c); 
  }
  
  private void i() {
    r.m(this.f.get() ^ true, "FirebaseApp was deleted");
  }
  
  private static List<String> l() {
    null = new ArrayList();
    synchronized (k) {
      Iterator<f> iterator = l.values().iterator();
      while (iterator.hasNext())
        null.add(((f)iterator.next()).q()); 
      Collections.sort(null);
      return null;
    } 
  }
  
  public static List<f> n(Context paramContext) {
    synchronized (k) {
      return new ArrayList(l.values());
    } 
  }
  
  public static f o() {
    synchronized (k) {
      f f1 = l.get("[DEFAULT]");
      if (f1 != null) {
        ((s4.f)f1.h.get()).l();
        return f1;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Default FirebaseApp is not initialized in this process ");
      stringBuilder.append(m.a());
      stringBuilder.append(". Make sure to call FirebaseApp.initializeApp(Context) first.");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public static f p(String paramString) {
    synchronized (k) {
      String str;
      f f1 = l.get(B(paramString));
      if (f1 != null) {
        ((s4.f)f1.h.get()).l();
        return f1;
      } 
      List<String> list = l();
      if (list.isEmpty()) {
        str = "";
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Available app names: ");
        stringBuilder.append(TextUtils.join(", ", (Iterable)str));
        str = stringBuilder.toString();
      } 
      throw new IllegalStateException(String.format("FirebaseApp with name %s doesn't exist. %s", new Object[] { paramString, str }));
    } 
  }
  
  private void t() {
    if ((m.a(this.a) ^ true) != 0) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Device in Direct Boot Mode: postponing initialization of Firebase APIs for app ");
      stringBuilder1.append(q());
      Log.i("FirebaseApp", stringBuilder1.toString());
      c.a(this.a);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Device unlocked: initializing all Firebase APIs for app ");
    stringBuilder.append(q());
    Log.i("FirebaseApp", stringBuilder.toString());
    this.d.p(y());
    ((s4.f)this.h.get()).l();
  }
  
  public static f u(Context paramContext) {
    synchronized (k) {
      if (l.containsKey("[DEFAULT]")) {
        f1 = o();
        return f1;
      } 
      n n1 = n.a((Context)f1);
      if (n1 == null) {
        Log.w("FirebaseApp", "Default FirebaseApp failed to initialize because no default options were found. This usually means that com.google.gms:google-services was not applied to your gradle project.");
        return null;
      } 
      f f1 = v((Context)f1, n1);
      return f1;
    } 
  }
  
  public static f v(Context paramContext, n paramn) {
    return w(paramContext, paramn, "[DEFAULT]");
  }
  
  public static f w(Context paramContext, n paramn, String paramString) {
    Map<String, f> map;
    b.b(paramContext);
    paramString = B(paramString);
    if (paramContext.getApplicationContext() != null)
      paramContext = paramContext.getApplicationContext(); 
    synchronized (k) {
      map = l;
      if (!map.containsKey(paramString)) {
        boolean bool1 = true;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("FirebaseApp name ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" already exists!");
        r.m(bool1, stringBuilder1.toString());
        r.k(paramContext, "Application context cannot be null.");
        f f2 = new f(paramContext, paramString, paramn);
        map.put(paramString, f2);
        f2.t();
        return f2;
      } 
    } 
    boolean bool = false;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FirebaseApp name ");
    stringBuilder.append(paramString);
    stringBuilder.append(" already exists!");
    r.m(bool, stringBuilder.toString());
    r.k(paramContext, "Application context cannot be null.");
    f f1 = new f(paramContext, paramString, paramn);
    map.put(paramString, f1);
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_4} */
    f1.t();
    return f1;
  }
  
  public void E(boolean paramBoolean) {
    i();
    if (this.e.compareAndSet(paramBoolean ^ true, paramBoolean)) {
      boolean bool = com.google.android.gms.common.api.internal.c.b().d();
      if (paramBoolean && bool) {
        paramBoolean = true;
      } else if (!paramBoolean && bool) {
        paramBoolean = false;
      } else {
        return;
      } 
      C(paramBoolean);
      return;
    } 
  }
  
  public void F(Boolean paramBoolean) {
    i();
    ((a5.a)this.g.get()).e(paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    return !(paramObject instanceof f) ? false : this.b.equals(((f)paramObject).q());
  }
  
  public void g(a parama) {
    i();
    if (this.e.get() && com.google.android.gms.common.api.internal.c.b().d())
      parama.a(true); 
    this.i.add(parama);
  }
  
  public void h(g paramg) {
    i();
    r.j(paramg);
    this.j.add(paramg);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public void j() {
    if (!this.f.compareAndSet(false, true))
      return; 
    synchronized (k) {
      l.remove(this.b);
      D();
      return;
    } 
  }
  
  public <T> T k(Class<T> paramClass) {
    i();
    return (T)this.d.a(paramClass);
  }
  
  public Context m() {
    i();
    return this.a;
  }
  
  public String q() {
    i();
    return this.b;
  }
  
  public n r() {
    i();
    return this.c;
  }
  
  public String s() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i2.c.e(q().getBytes(Charset.defaultCharset())));
    stringBuilder.append("+");
    stringBuilder.append(i2.c.e(r().c().getBytes(Charset.defaultCharset())));
    return stringBuilder.toString();
  }
  
  public String toString() {
    return p.d(this).a("name", this.b).a("options", this.c).toString();
  }
  
  public boolean x() {
    i();
    return ((a5.a)this.g.get()).b();
  }
  
  public boolean y() {
    return "[DEFAULT]".equals(q());
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
  
  private static class b implements com.google.android.gms.common.api.internal.c.a {
    private static AtomicReference<b> a = new AtomicReference<b>();
    
    private static void c(Context param1Context) {
      if (l.a()) {
        if (!(param1Context.getApplicationContext() instanceof Application))
          return; 
        Application application = (Application)param1Context.getApplicationContext();
        if (a.get() == null) {
          b b1 = new b();
          if (a.compareAndSet(null, b1)) {
            com.google.android.gms.common.api.internal.c.c(application);
            com.google.android.gms.common.api.internal.c.b().a(b1);
          } 
        } 
      } 
    }
    
    public void a(boolean param1Boolean) {
      synchronized (f.c()) {
        for (f f : new ArrayList(f.l.values())) {
          if (f.e(f).get())
            f.f(f, param1Boolean); 
        } 
        return;
      } 
    }
  }
  
  private static class c extends BroadcastReceiver {
    private static AtomicReference<c> b = new AtomicReference<c>();
    
    private final Context a;
    
    public c(Context param1Context) {
      this.a = param1Context;
    }
    
    private static void b(Context param1Context) {
      if (b.get() == null) {
        c c1 = new c(param1Context);
        if (b.compareAndSet(null, c1))
          param1Context.registerReceiver(c1, new IntentFilter("android.intent.action.USER_UNLOCKED")); 
      } 
    }
    
    public void c() {
      this.a.unregisterReceiver(this);
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      synchronized (f.c()) {
        Iterator<f> iterator = f.l.values().iterator();
        while (iterator.hasNext())
          f.d(iterator.next()); 
        c();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */