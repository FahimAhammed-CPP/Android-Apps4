package a3;

final class a extends p {
  private final long a;
  
  private final long b;
  
  private final long c;
  
  a(long paramLong1, long paramLong2, long paramLong3) {
    this.a = paramLong1;
    this.b = paramLong2;
    this.c = paramLong3;
  }
  
  public long b() {
    return this.b;
  }
  
  public long c() {
    return this.a;
  }
  
  public long d() {
    return this.c;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof p) {
      paramObject = paramObject;
      return (this.a == paramObject.c() && this.b == paramObject.b() && this.c == paramObject.d());
    } 
    return false;
  }
  
  public int hashCode() {
    long l = this.a;
    int i = (int)(l ^ l >>> 32L);
    l = this.b;
    int j = (int)(l ^ l >>> 32L);
    l = this.c;
    return (int)(l >>> 32L ^ l) ^ ((i ^ 0xF4243) * 1000003 ^ j) * 1000003;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("StartupTime{epochMillis=");
    stringBuilder.append(this.a);
    stringBuilder.append(", elapsedRealtime=");
    stringBuilder.append(this.b);
    stringBuilder.append(", uptimeMillis=");
    stringBuilder.append(this.c);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */