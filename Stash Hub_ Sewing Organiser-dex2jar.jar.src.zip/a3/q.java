package a3;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Date;
import p4.x;

public final class q implements Comparable<q>, Parcelable {
  public static final Parcelable.Creator<q> CREATOR = new a();
  
  private final long a;
  
  private final int b;
  
  public q(long paramLong, int paramInt) {
    p(paramLong, paramInt);
    this.a = paramLong;
    this.b = paramInt;
  }
  
  protected q(Parcel paramParcel) {
    this.a = paramParcel.readLong();
    this.b = paramParcel.readInt();
  }
  
  public q(Date paramDate) {
    long l1 = paramDate.getTime();
    long l2 = l1 / 1000L;
    int j = (int)(l1 % 1000L) * 1000000;
    l1 = l2;
    int i = j;
    if (j < 0) {
      l1 = l2 - 1L;
      i = j + 1000000000;
    } 
    p(l1, i);
    this.a = l1;
    this.b = i;
  }
  
  public static q o() {
    return new q(new Date());
  }
  
  private static void p(long paramLong, int paramInt) {
    boolean bool;
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    x.a(bool, "Timestamp nanoseconds out of range: %s", new Object[] { Integer.valueOf(paramInt) });
    if (paramInt < 1.0E9D) {
      bool = true;
    } else {
      bool = false;
    } 
    x.a(bool, "Timestamp nanoseconds out of range: %s", new Object[] { Integer.valueOf(paramInt) });
    if (paramLong >= -62135596800L) {
      bool = true;
    } else {
      bool = false;
    } 
    x.a(bool, "Timestamp seconds out of range: %s", new Object[] { Long.valueOf(paramLong) });
    if (paramLong < 253402300800L) {
      bool = true;
    } else {
      bool = false;
    } 
    x.a(bool, "Timestamp seconds out of range: %s", new Object[] { Long.valueOf(paramLong) });
  }
  
  public int a(q paramq) {
    long l1 = this.a;
    long l2 = paramq.a;
    return (l1 == l2) ? Integer.signum(this.b - paramq.b) : Long.signum(l1 - l2);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject == this) ? true : (!(paramObject instanceof q) ? false : ((a((q)paramObject) == 0)));
  }
  
  public int g() {
    return this.b;
  }
  
  public int hashCode() {
    long l = this.a;
    return ((int)l * 37 * 37 + (int)(l >> 32L)) * 37 + this.b;
  }
  
  public long k() {
    return this.a;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Timestamp(seconds=");
    stringBuilder.append(this.a);
    stringBuilder.append(", nanoseconds=");
    stringBuilder.append(this.b);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeLong(this.a);
    paramParcel.writeInt(this.b);
  }
  
  class a implements Parcelable.Creator<q> {
    public q a(Parcel param1Parcel) {
      return new q(param1Parcel);
    }
    
    public q[] b(int param1Int) {
      return new q[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */