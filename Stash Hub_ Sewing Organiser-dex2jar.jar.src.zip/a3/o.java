package a3;

public class o extends l {
  public o(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */