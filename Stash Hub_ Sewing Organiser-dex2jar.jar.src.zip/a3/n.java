package a3;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.internal.p;
import com.google.android.gms.common.internal.r;
import com.google.android.gms.common.internal.u;

public final class n {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final String d;
  
  private final String e;
  
  private final String f;
  
  private final String g;
  
  private n(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    r.m(i2.n.b(paramString1) ^ true, "ApplicationId must be set.");
    this.b = paramString1;
    this.a = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramString6;
    this.g = paramString7;
  }
  
  public static n a(Context paramContext) {
    u u = new u(paramContext);
    String str = u.a("google_app_id");
    return TextUtils.isEmpty(str) ? null : new n(str, u.a("google_api_key"), u.a("firebase_database_url"), u.a("ga_trackingId"), u.a("gcm_defaultSenderId"), u.a("google_storage_bucket"), u.a("project_id"));
  }
  
  public String b() {
    return this.a;
  }
  
  public String c() {
    return this.b;
  }
  
  public String d() {
    return this.c;
  }
  
  public String e() {
    return this.d;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof n;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (p.b(this.b, ((n)paramObject).b)) {
      bool = bool1;
      if (p.b(this.a, ((n)paramObject).a)) {
        bool = bool1;
        if (p.b(this.c, ((n)paramObject).c)) {
          bool = bool1;
          if (p.b(this.d, ((n)paramObject).d)) {
            bool = bool1;
            if (p.b(this.e, ((n)paramObject).e)) {
              bool = bool1;
              if (p.b(this.f, ((n)paramObject).f)) {
                bool = bool1;
                if (p.b(this.g, ((n)paramObject).g))
                  bool = true; 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool;
  }
  
  public String f() {
    return this.e;
  }
  
  public String g() {
    return this.g;
  }
  
  public String h() {
    return this.f;
  }
  
  public int hashCode() {
    return p.c(new Object[] { this.b, this.a, this.c, this.d, this.e, this.f, this.g });
  }
  
  public String toString() {
    return p.d(this).a("applicationId", this.b).a("apiKey", this.a).a("databaseUrl", this.c).a("gcmSenderId", this.e).a("storageBucket", this.f).a("projectId", this.g).toString();
  }
  
  public static final class b {
    private String a;
    
    private String b;
    
    private String c;
    
    private String d;
    
    private String e;
    
    private String f;
    
    private String g;
    
    public n a() {
      return new n(this.b, this.a, this.c, this.d, this.e, this.f, this.g, null);
    }
    
    public b b(String param1String) {
      this.a = r.g(param1String, "ApiKey must be set.");
      return this;
    }
    
    public b c(String param1String) {
      this.b = r.g(param1String, "ApplicationId must be set.");
      return this;
    }
    
    public b d(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public b e(String param1String) {
      this.d = param1String;
      return this;
    }
    
    public b f(String param1String) {
      this.e = param1String;
      return this;
    }
    
    public b g(String param1String) {
      this.g = param1String;
      return this;
    }
    
    public b h(String param1String) {
      this.f = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a3\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */