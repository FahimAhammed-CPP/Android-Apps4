package androidx.loader.app;

import android.os.Bundle;
import androidx.lifecycle.g0;
import androidx.lifecycle.j;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import s.b;

public abstract class a {
  public static <T extends j & g0> a b(T paramT) {
    return new b((j)paramT, ((g0)paramT).e());
  }
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract <D> b<D> c(int paramInt, Bundle paramBundle, a<D> parama);
  
  public abstract void d();
  
  public static interface a<D> {
    void a(b<D> param1b);
    
    void b(b<D> param1b, D param1D);
    
    b<D> c(int param1Int, Bundle param1Bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\loader\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */