package androidx.exifinterface.media;

import android.media.MediaDataSource;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.system.Os;
import android.util.Log;
import java.io.Closeable;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class b {
  static String a(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder = new StringBuilder(paramArrayOfbyte.length * 2);
    for (int i = 0; i < paramArrayOfbyte.length; i++) {
      stringBuilder.append(String.format("%02x", new Object[] { Byte.valueOf(paramArrayOfbyte[i]) }));
    } 
    return stringBuilder.toString();
  }
  
  static void b(FileDescriptor paramFileDescriptor) {
    String str;
    if (Build.VERSION.SDK_INT >= 21) {
      try {
        a.a(paramFileDescriptor);
        return;
      } catch (Exception exception) {
        str = "Error closing fd.";
      } 
    } else {
      str = "closeFileDescriptor is called in API < 21, which must be wrong.";
    } 
    Log.e("ExifInterfaceUtils", str);
  }
  
  static void c(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (RuntimeException runtimeException) {
        throw runtimeException;
      } catch (Exception exception) {
        return;
      }  
  }
  
  static long[] d(Object paramObject) {
    if (paramObject instanceof int[]) {
      paramObject = paramObject;
      long[] arrayOfLong = new long[paramObject.length];
      for (int i = 0; i < paramObject.length; i++)
        arrayOfLong[i] = paramObject[i]; 
      return arrayOfLong;
    } 
    return (paramObject instanceof long[]) ? (long[])paramObject : null;
  }
  
  static int e(InputStream paramInputStream, OutputStream paramOutputStream) {
    byte[] arrayOfByte = new byte[8192];
    int i = 0;
    while (true) {
      int j = paramInputStream.read(arrayOfByte);
      if (j != -1) {
        i += j;
        paramOutputStream.write(arrayOfByte, 0, j);
        continue;
      } 
      return i;
    } 
  }
  
  static void f(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt) {
    byte[] arrayOfByte = new byte[8192];
    while (paramInt > 0) {
      int j = Math.min(paramInt, 8192);
      int i = paramInputStream.read(arrayOfByte, 0, j);
      if (i == j) {
        paramInt -= i;
        paramOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      throw new IOException("Failed to copy the given amount of bytes from the inputstream to the output stream.");
    } 
  }
  
  static boolean g(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    if (paramArrayOfbyte1 != null) {
      if (paramArrayOfbyte2 == null)
        return false; 
      if (paramArrayOfbyte1.length < paramArrayOfbyte2.length)
        return false; 
      for (int i = 0; i < paramArrayOfbyte2.length; i++) {
        if (paramArrayOfbyte1[i] != paramArrayOfbyte2[i])
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  static class a {
    static void a(FileDescriptor param1FileDescriptor) {
      Os.close(param1FileDescriptor);
    }
    
    static FileDescriptor b(FileDescriptor param1FileDescriptor) {
      return Os.dup(param1FileDescriptor);
    }
    
    static long c(FileDescriptor param1FileDescriptor, long param1Long, int param1Int) {
      return Os.lseek(param1FileDescriptor, param1Long, param1Int);
    }
  }
  
  static class b {
    static void a(MediaMetadataRetriever param1MediaMetadataRetriever, MediaDataSource param1MediaDataSource) {
      param1MediaMetadataRetriever.setDataSource(param1MediaDataSource);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\exifinterface\media\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */