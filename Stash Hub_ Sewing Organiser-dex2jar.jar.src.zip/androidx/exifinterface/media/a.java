package androidx.exifinterface.media;

import android.content.res.AssetManager;
import android.media.MediaDataSource;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.system.OsConstants;
import android.util.Log;
import android.util.Pair;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

public class a {
  public static final int[] A;
  
  static final byte[] B;
  
  private static final byte[] C;
  
  private static final byte[] D;
  
  private static final byte[] E;
  
  private static final byte[] F;
  
  private static final byte[] G;
  
  private static final byte[] H;
  
  private static final byte[] I;
  
  private static final byte[] J;
  
  private static final byte[] K;
  
  private static final byte[] L;
  
  private static final byte[] M;
  
  private static final byte[] N;
  
  private static final byte[] O;
  
  private static final byte[] P;
  
  private static final byte[] Q;
  
  private static final byte[] R;
  
  private static final byte[] S;
  
  private static final byte[] T;
  
  private static SimpleDateFormat U;
  
  private static SimpleDateFormat V;
  
  static final String[] W;
  
  static final int[] X;
  
  static final byte[] Y;
  
  private static final e[] Z;
  
  private static final e[] a0;
  
  private static final e[] b0;
  
  private static final e[] c0;
  
  private static final e[] d0;
  
  private static final e e0;
  
  private static final e[] f0;
  
  private static final e[] g0;
  
  private static final e[] h0;
  
  private static final e[] i0;
  
  static final e[][] j0;
  
  private static final e[] k0;
  
  private static final HashMap<Integer, e>[] l0;
  
  private static final HashMap<String, e>[] m0;
  
  private static final HashSet<String> n0;
  
  private static final HashMap<Integer, Integer> o0;
  
  static final Charset p0;
  
  static final byte[] q0;
  
  private static final byte[] r0;
  
  private static final Pattern s0;
  
  private static final Pattern t0;
  
  private static final Pattern u0;
  
  private static final boolean v = Log.isLoggable("ExifInterface", 3);
  
  private static final Pattern v0;
  
  private static final List<Integer> w;
  
  private static final List<Integer> x;
  
  public static final int[] y = new int[] { 8, 8, 8 };
  
  public static final int[] z = new int[] { 4 };
  
  private String a;
  
  private FileDescriptor b;
  
  private AssetManager.AssetInputStream c;
  
  private int d;
  
  private boolean e;
  
  private final HashMap<String, d>[] f;
  
  private Set<Integer> g;
  
  private ByteOrder h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private int l;
  
  private int m;
  
  private byte[] n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private boolean t;
  
  private boolean u;
  
  static {
    A = new int[] { 8 };
    B = new byte[] { -1, -40, -1 };
    C = new byte[] { 102, 116, 121, 112 };
    D = new byte[] { 109, 105, 102, 49 };
    E = new byte[] { 104, 101, 105, 99 };
    F = new byte[] { 79, 76, 89, 77, 80, 0 };
    G = new byte[] { 79, 76, 89, 77, 80, 85, 83, 0, 73, 73 };
    H = new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 };
    I = new byte[] { 101, 88, 73, 102 };
    J = new byte[] { 73, 72, 68, 82 };
    K = new byte[] { 73, 69, 78, 68 };
    L = new byte[] { 82, 73, 70, 70 };
    M = new byte[] { 87, 69, 66, 80 };
    N = new byte[] { 69, 88, 73, 70 };
    O = new byte[] { -99, 1, 42 };
    P = "VP8X".getBytes(Charset.defaultCharset());
    Q = "VP8L".getBytes(Charset.defaultCharset());
    R = "VP8 ".getBytes(Charset.defaultCharset());
    S = "ANIM".getBytes(Charset.defaultCharset());
    T = "ANMF".getBytes(Charset.defaultCharset());
    W = new String[] { 
        "", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", 
        "SRATIONAL", "SINGLE", "DOUBLE", "IFD" };
    X = new int[] { 
        0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 
        8, 4, 8, 1 };
    Y = new byte[] { 65, 83, 67, 73, 73, 0, 0, 0 };
    e[] arrayOfE1 = new e[42];
    arrayOfE1[0] = new e("NewSubfileType", 254, 4);
    arrayOfE1[1] = new e("SubfileType", 255, 4);
    arrayOfE1[2] = new e("ImageWidth", 256, 3, 4);
    arrayOfE1[3] = new e("ImageLength", 257, 3, 4);
    arrayOfE1[4] = new e("BitsPerSample", 258, 3);
    arrayOfE1[5] = new e("Compression", 259, 3);
    arrayOfE1[6] = new e("PhotometricInterpretation", 262, 3);
    arrayOfE1[7] = new e("ImageDescription", 270, 2);
    arrayOfE1[8] = new e("Make", 271, 2);
    arrayOfE1[9] = new e("Model", 272, 2);
    arrayOfE1[10] = new e("StripOffsets", 273, 3, 4);
    arrayOfE1[11] = new e("Orientation", 274, 3);
    arrayOfE1[12] = new e("SamplesPerPixel", 277, 3);
    arrayOfE1[13] = new e("RowsPerStrip", 278, 3, 4);
    arrayOfE1[14] = new e("StripByteCounts", 279, 3, 4);
    arrayOfE1[15] = new e("XResolution", 282, 5);
    arrayOfE1[16] = new e("YResolution", 283, 5);
    arrayOfE1[17] = new e("PlanarConfiguration", 284, 3);
    arrayOfE1[18] = new e("ResolutionUnit", 296, 3);
    arrayOfE1[19] = new e("TransferFunction", 301, 3);
    arrayOfE1[20] = new e("Software", 305, 2);
    arrayOfE1[21] = new e("DateTime", 306, 2);
    arrayOfE1[22] = new e("Artist", 315, 2);
    arrayOfE1[23] = new e("WhitePoint", 318, 5);
    arrayOfE1[24] = new e("PrimaryChromaticities", 319, 5);
    arrayOfE1[25] = new e("SubIFDPointer", 330, 4);
    arrayOfE1[26] = new e("JPEGInterchangeFormat", 513, 4);
    arrayOfE1[27] = new e("JPEGInterchangeFormatLength", 514, 4);
    arrayOfE1[28] = new e("YCbCrCoefficients", 529, 5);
    arrayOfE1[29] = new e("YCbCrSubSampling", 530, 3);
    arrayOfE1[30] = new e("YCbCrPositioning", 531, 3);
    arrayOfE1[31] = new e("ReferenceBlackWhite", 532, 5);
    arrayOfE1[32] = new e("Copyright", 33432, 2);
    arrayOfE1[33] = new e("ExifIFDPointer", 34665, 4);
    arrayOfE1[34] = new e("GPSInfoIFDPointer", 34853, 4);
    arrayOfE1[35] = new e("SensorTopBorder", 4, 4);
    arrayOfE1[36] = new e("SensorLeftBorder", 5, 4);
    arrayOfE1[37] = new e("SensorBottomBorder", 6, 4);
    arrayOfE1[38] = new e("SensorRightBorder", 7, 4);
    arrayOfE1[39] = new e("ISO", 23, 3);
    arrayOfE1[40] = new e("JpgFromRaw", 46, 7);
    arrayOfE1[41] = new e("Xmp", 700, 1);
    Z = arrayOfE1;
    e[] arrayOfE2 = new e[74];
    arrayOfE2[0] = new e("ExposureTime", 33434, 5);
    arrayOfE2[1] = new e("FNumber", 33437, 5);
    arrayOfE2[2] = new e("ExposureProgram", 34850, 3);
    arrayOfE2[3] = new e("SpectralSensitivity", 34852, 2);
    arrayOfE2[4] = new e("PhotographicSensitivity", 34855, 3);
    arrayOfE2[5] = new e("OECF", 34856, 7);
    arrayOfE2[6] = new e("SensitivityType", 34864, 3);
    arrayOfE2[7] = new e("StandardOutputSensitivity", 34865, 4);
    arrayOfE2[8] = new e("RecommendedExposureIndex", 34866, 4);
    arrayOfE2[9] = new e("ISOSpeed", 34867, 4);
    arrayOfE2[10] = new e("ISOSpeedLatitudeyyy", 34868, 4);
    arrayOfE2[11] = new e("ISOSpeedLatitudezzz", 34869, 4);
    arrayOfE2[12] = new e("ExifVersion", 36864, 2);
    arrayOfE2[13] = new e("DateTimeOriginal", 36867, 2);
    arrayOfE2[14] = new e("DateTimeDigitized", 36868, 2);
    arrayOfE2[15] = new e("OffsetTime", 36880, 2);
    arrayOfE2[16] = new e("OffsetTimeOriginal", 36881, 2);
    arrayOfE2[17] = new e("OffsetTimeDigitized", 36882, 2);
    arrayOfE2[18] = new e("ComponentsConfiguration", 37121, 7);
    arrayOfE2[19] = new e("CompressedBitsPerPixel", 37122, 5);
    arrayOfE2[20] = new e("ShutterSpeedValue", 37377, 10);
    arrayOfE2[21] = new e("ApertureValue", 37378, 5);
    arrayOfE2[22] = new e("BrightnessValue", 37379, 10);
    arrayOfE2[23] = new e("ExposureBiasValue", 37380, 10);
    arrayOfE2[24] = new e("MaxApertureValue", 37381, 5);
    arrayOfE2[25] = new e("SubjectDistance", 37382, 5);
    arrayOfE2[26] = new e("MeteringMode", 37383, 3);
    arrayOfE2[27] = new e("LightSource", 37384, 3);
    arrayOfE2[28] = new e("Flash", 37385, 3);
    arrayOfE2[29] = new e("FocalLength", 37386, 5);
    arrayOfE2[30] = new e("SubjectArea", 37396, 3);
    arrayOfE2[31] = new e("MakerNote", 37500, 7);
    arrayOfE2[32] = new e("UserComment", 37510, 7);
    arrayOfE2[33] = new e("SubSecTime", 37520, 2);
    arrayOfE2[34] = new e("SubSecTimeOriginal", 37521, 2);
    arrayOfE2[35] = new e("SubSecTimeDigitized", 37522, 2);
    arrayOfE2[36] = new e("FlashpixVersion", 40960, 7);
    arrayOfE2[37] = new e("ColorSpace", 40961, 3);
    arrayOfE2[38] = new e("PixelXDimension", 40962, 3, 4);
    arrayOfE2[39] = new e("PixelYDimension", 40963, 3, 4);
    arrayOfE2[40] = new e("RelatedSoundFile", 40964, 2);
    arrayOfE2[41] = new e("InteroperabilityIFDPointer", 40965, 4);
    arrayOfE2[42] = new e("FlashEnergy", 41483, 5);
    arrayOfE2[43] = new e("SpatialFrequencyResponse", 41484, 7);
    arrayOfE2[44] = new e("FocalPlaneXResolution", 41486, 5);
    arrayOfE2[45] = new e("FocalPlaneYResolution", 41487, 5);
    arrayOfE2[46] = new e("FocalPlaneResolutionUnit", 41488, 3);
    arrayOfE2[47] = new e("SubjectLocation", 41492, 3);
    arrayOfE2[48] = new e("ExposureIndex", 41493, 5);
    arrayOfE2[49] = new e("SensingMethod", 41495, 3);
    arrayOfE2[50] = new e("FileSource", 41728, 7);
    arrayOfE2[51] = new e("SceneType", 41729, 7);
    arrayOfE2[52] = new e("CFAPattern", 41730, 7);
    arrayOfE2[53] = new e("CustomRendered", 41985, 3);
    arrayOfE2[54] = new e("ExposureMode", 41986, 3);
    arrayOfE2[55] = new e("WhiteBalance", 41987, 3);
    arrayOfE2[56] = new e("DigitalZoomRatio", 41988, 5);
    arrayOfE2[57] = new e("FocalLengthIn35mmFilm", 41989, 3);
    arrayOfE2[58] = new e("SceneCaptureType", 41990, 3);
    arrayOfE2[59] = new e("GainControl", 41991, 3);
    arrayOfE2[60] = new e("Contrast", 41992, 3);
    arrayOfE2[61] = new e("Saturation", 41993, 3);
    arrayOfE2[62] = new e("Sharpness", 41994, 3);
    arrayOfE2[63] = new e("DeviceSettingDescription", 41995, 7);
    arrayOfE2[64] = new e("SubjectDistanceRange", 41996, 3);
    arrayOfE2[65] = new e("ImageUniqueID", 42016, 2);
    arrayOfE2[66] = new e("CameraOwnerName", 42032, 2);
    arrayOfE2[67] = new e("BodySerialNumber", 42033, 2);
    arrayOfE2[68] = new e("LensSpecification", 42034, 5);
    arrayOfE2[69] = new e("LensMake", 42035, 2);
    arrayOfE2[70] = new e("LensModel", 42036, 2);
    arrayOfE2[71] = new e("Gamma", 42240, 5);
    arrayOfE2[72] = new e("DNGVersion", 50706, 1);
    arrayOfE2[73] = new e("DefaultCropSize", 50720, 3, 4);
    a0 = arrayOfE2;
    e[] arrayOfE3 = new e[32];
    arrayOfE3[0] = new e("GPSVersionID", 0, 1);
    arrayOfE3[1] = new e("GPSLatitudeRef", 1, 2);
    arrayOfE3[2] = new e("GPSLatitude", 2, 5, 10);
    arrayOfE3[3] = new e("GPSLongitudeRef", 3, 2);
    arrayOfE3[4] = new e("GPSLongitude", 4, 5, 10);
    arrayOfE3[5] = new e("GPSAltitudeRef", 5, 1);
    arrayOfE3[6] = new e("GPSAltitude", 6, 5);
    arrayOfE3[7] = new e("GPSTimeStamp", 7, 5);
    arrayOfE3[8] = new e("GPSSatellites", 8, 2);
    arrayOfE3[9] = new e("GPSStatus", 9, 2);
    arrayOfE3[10] = new e("GPSMeasureMode", 10, 2);
    arrayOfE3[11] = new e("GPSDOP", 11, 5);
    arrayOfE3[12] = new e("GPSSpeedRef", 12, 2);
    arrayOfE3[13] = new e("GPSSpeed", 13, 5);
    arrayOfE3[14] = new e("GPSTrackRef", 14, 2);
    arrayOfE3[15] = new e("GPSTrack", 15, 5);
    arrayOfE3[16] = new e("GPSImgDirectionRef", 16, 2);
    arrayOfE3[17] = new e("GPSImgDirection", 17, 5);
    arrayOfE3[18] = new e("GPSMapDatum", 18, 2);
    arrayOfE3[19] = new e("GPSDestLatitudeRef", 19, 2);
    arrayOfE3[20] = new e("GPSDestLatitude", 20, 5);
    arrayOfE3[21] = new e("GPSDestLongitudeRef", 21, 2);
    arrayOfE3[22] = new e("GPSDestLongitude", 22, 5);
    arrayOfE3[23] = new e("GPSDestBearingRef", 23, 2);
    arrayOfE3[24] = new e("GPSDestBearing", 24, 5);
    arrayOfE3[25] = new e("GPSDestDistanceRef", 25, 2);
    arrayOfE3[26] = new e("GPSDestDistance", 26, 5);
    arrayOfE3[27] = new e("GPSProcessingMethod", 27, 7);
    arrayOfE3[28] = new e("GPSAreaInformation", 28, 7);
    arrayOfE3[29] = new e("GPSDateStamp", 29, 2);
    arrayOfE3[30] = new e("GPSDifferential", 30, 3);
    arrayOfE3[31] = new e("GPSHPositioningError", 31, 5);
    b0 = arrayOfE3;
    e[] arrayOfE4 = new e[1];
    arrayOfE4[0] = new e("InteroperabilityIndex", 1, 2);
    c0 = arrayOfE4;
    e[] arrayOfE5 = new e[37];
    arrayOfE5[0] = new e("NewSubfileType", 254, 4);
    arrayOfE5[1] = new e("SubfileType", 255, 4);
    arrayOfE5[2] = new e("ThumbnailImageWidth", 256, 3, 4);
    arrayOfE5[3] = new e("ThumbnailImageLength", 257, 3, 4);
    arrayOfE5[4] = new e("BitsPerSample", 258, 3);
    arrayOfE5[5] = new e("Compression", 259, 3);
    arrayOfE5[6] = new e("PhotometricInterpretation", 262, 3);
    arrayOfE5[7] = new e("ImageDescription", 270, 2);
    arrayOfE5[8] = new e("Make", 271, 2);
    arrayOfE5[9] = new e("Model", 272, 2);
    arrayOfE5[10] = new e("StripOffsets", 273, 3, 4);
    arrayOfE5[11] = new e("ThumbnailOrientation", 274, 3);
    arrayOfE5[12] = new e("SamplesPerPixel", 277, 3);
    arrayOfE5[13] = new e("RowsPerStrip", 278, 3, 4);
    arrayOfE5[14] = new e("StripByteCounts", 279, 3, 4);
    arrayOfE5[15] = new e("XResolution", 282, 5);
    arrayOfE5[16] = new e("YResolution", 283, 5);
    arrayOfE5[17] = new e("PlanarConfiguration", 284, 3);
    arrayOfE5[18] = new e("ResolutionUnit", 296, 3);
    arrayOfE5[19] = new e("TransferFunction", 301, 3);
    arrayOfE5[20] = new e("Software", 305, 2);
    arrayOfE5[21] = new e("DateTime", 306, 2);
    arrayOfE5[22] = new e("Artist", 315, 2);
    arrayOfE5[23] = new e("WhitePoint", 318, 5);
    arrayOfE5[24] = new e("PrimaryChromaticities", 319, 5);
    arrayOfE5[25] = new e("SubIFDPointer", 330, 4);
    arrayOfE5[26] = new e("JPEGInterchangeFormat", 513, 4);
    arrayOfE5[27] = new e("JPEGInterchangeFormatLength", 514, 4);
    arrayOfE5[28] = new e("YCbCrCoefficients", 529, 5);
    arrayOfE5[29] = new e("YCbCrSubSampling", 530, 3);
    arrayOfE5[30] = new e("YCbCrPositioning", 531, 3);
    arrayOfE5[31] = new e("ReferenceBlackWhite", 532, 5);
    arrayOfE5[32] = new e("Copyright", 33432, 2);
    arrayOfE5[33] = new e("ExifIFDPointer", 34665, 4);
    arrayOfE5[34] = new e("GPSInfoIFDPointer", 34853, 4);
    arrayOfE5[35] = new e("DNGVersion", 50706, 1);
    arrayOfE5[36] = new e("DefaultCropSize", 50720, 3, 4);
    d0 = arrayOfE5;
    e0 = new e("StripOffsets", 273, 3);
    e[] arrayOfE6 = new e[3];
    arrayOfE6[0] = new e("ThumbnailImage", 256, 7);
    arrayOfE6[1] = new e("CameraSettingsIFDPointer", 8224, 4);
    arrayOfE6[2] = new e("ImageProcessingIFDPointer", 8256, 4);
    f0 = arrayOfE6;
    e[] arrayOfE7 = new e[2];
    arrayOfE7[0] = new e("PreviewImageStart", 257, 4);
    arrayOfE7[1] = new e("PreviewImageLength", 258, 4);
    g0 = arrayOfE7;
    e[] arrayOfE8 = new e[1];
    arrayOfE8[0] = new e("AspectFrame", 4371, 3);
    h0 = arrayOfE8;
    e[] arrayOfE9 = new e[1];
    arrayOfE9[0] = new e("ColorSpace", 55, 3);
    i0 = arrayOfE9;
    e[][] arrayOfE = new e[10][];
    arrayOfE[0] = arrayOfE1;
    arrayOfE[1] = arrayOfE2;
    arrayOfE[2] = arrayOfE3;
    arrayOfE[3] = arrayOfE4;
    arrayOfE[4] = arrayOfE5;
    arrayOfE[5] = arrayOfE1;
    arrayOfE[6] = arrayOfE6;
    arrayOfE[7] = arrayOfE7;
    arrayOfE[8] = arrayOfE8;
    arrayOfE[9] = arrayOfE9;
    j0 = arrayOfE;
    k0 = new e[] { new e("SubIFDPointer", 330, 4), new e("ExifIFDPointer", 34665, 4), new e("GPSInfoIFDPointer", 34853, 4), new e("InteroperabilityIFDPointer", 40965, 4), new e("CameraSettingsIFDPointer", 8224, 1), new e("ImageProcessingIFDPointer", 8256, 1) };
    l0 = (HashMap<Integer, e>[])new HashMap[arrayOfE.length];
    m0 = (HashMap<String, e>[])new HashMap[arrayOfE.length];
    n0 = new HashSet<String>(Arrays.asList(new String[] { "FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp" }));
    o0 = new HashMap<Integer, Integer>();
    Charset charset = Charset.forName("US-ASCII");
    p0 = charset;
    q0 = "Exif\000\000".getBytes(charset);
    r0 = "http://ns.adobe.com/xap/1.0/\000".getBytes(charset);
    Locale locale = Locale.US;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", locale);
    U = simpleDateFormat;
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale);
    V = simpleDateFormat;
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    int i = 0;
    while (true) {
      e[][] arrayOfE10 = j0;
      if (i < arrayOfE10.length) {
        l0[i] = new HashMap<Integer, e>();
        m0[i] = new HashMap<String, e>();
        for (e e1 : arrayOfE10[i]) {
          l0[i].put(Integer.valueOf(e1.a), e1);
          m0[i].put(e1.b, e1);
        } 
        i++;
        continue;
      } 
      HashMap<Integer, Integer> hashMap = o0;
      e[] arrayOfE11 = k0;
      hashMap.put(Integer.valueOf((arrayOfE11[0]).a), integer6);
      hashMap.put(Integer.valueOf((arrayOfE11[1]).a), integer2);
      hashMap.put(Integer.valueOf((arrayOfE11[2]).a), integer3);
      hashMap.put(Integer.valueOf((arrayOfE11[3]).a), integer1);
      hashMap.put(Integer.valueOf((arrayOfE11[4]).a), integer5);
      hashMap.put(Integer.valueOf((arrayOfE11[5]).a), integer4);
      s0 = Pattern.compile(".*[1-9].*");
      t0 = Pattern.compile("^(\\d{2}):(\\d{2}):(\\d{2})$");
      u0 = Pattern.compile("^(\\d{4}):(\\d{2}):(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");
      v0 = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");
      return;
    } 
  }
  
  public a(InputStream paramInputStream) {
    this(paramInputStream, 0);
  }
  
  public a(InputStream paramInputStream, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: getstatic androidx/exifinterface/media/a.j0 : [[Landroidx/exifinterface/media/a$e;
    //   7: astore_3
    //   8: aload_0
    //   9: aload_3
    //   10: arraylength
    //   11: anewarray java/util/HashMap
    //   14: putfield f : [Ljava/util/HashMap;
    //   17: aload_0
    //   18: new java/util/HashSet
    //   21: dup
    //   22: aload_3
    //   23: arraylength
    //   24: invokespecial <init> : (I)V
    //   27: putfield g : Ljava/util/Set;
    //   30: aload_0
    //   31: getstatic java/nio/ByteOrder.BIG_ENDIAN : Ljava/nio/ByteOrder;
    //   34: putfield h : Ljava/nio/ByteOrder;
    //   37: aload_1
    //   38: ldc_w 'inputStream cannot be null'
    //   41: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   44: pop
    //   45: aload_0
    //   46: aconst_null
    //   47: putfield a : Ljava/lang/String;
    //   50: iload_2
    //   51: iconst_1
    //   52: if_icmpne -> 60
    //   55: iconst_1
    //   56: istore_2
    //   57: goto -> 62
    //   60: iconst_0
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 114
    //   66: new java/io/BufferedInputStream
    //   69: dup
    //   70: aload_1
    //   71: getstatic androidx/exifinterface/media/a.q0 : [B
    //   74: arraylength
    //   75: invokespecial <init> : (Ljava/io/InputStream;I)V
    //   78: astore_1
    //   79: aload_1
    //   80: invokestatic w : (Ljava/io/BufferedInputStream;)Z
    //   83: ifne -> 96
    //   86: ldc 'ExifInterface'
    //   88: ldc_w 'Given data does not follow the structure of an Exif-only data.'
    //   91: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   94: pop
    //   95: return
    //   96: aload_0
    //   97: iconst_1
    //   98: putfield e : Z
    //   101: aload_0
    //   102: aconst_null
    //   103: putfield c : Landroid/content/res/AssetManager$AssetInputStream;
    //   106: aload_0
    //   107: aconst_null
    //   108: putfield b : Ljava/io/FileDescriptor;
    //   111: goto -> 183
    //   114: aload_1
    //   115: instanceof android/content/res/AssetManager$AssetInputStream
    //   118: ifeq -> 137
    //   121: aload_0
    //   122: aload_1
    //   123: checkcast android/content/res/AssetManager$AssetInputStream
    //   126: putfield c : Landroid/content/res/AssetManager$AssetInputStream;
    //   129: aload_0
    //   130: aconst_null
    //   131: putfield b : Ljava/io/FileDescriptor;
    //   134: goto -> 183
    //   137: aload_1
    //   138: instanceof java/io/FileInputStream
    //   141: ifeq -> 175
    //   144: aload_1
    //   145: checkcast java/io/FileInputStream
    //   148: astore_3
    //   149: aload_3
    //   150: invokevirtual getFD : ()Ljava/io/FileDescriptor;
    //   153: invokestatic D : (Ljava/io/FileDescriptor;)Z
    //   156: ifeq -> 175
    //   159: aload_0
    //   160: aconst_null
    //   161: putfield c : Landroid/content/res/AssetManager$AssetInputStream;
    //   164: aload_0
    //   165: aload_3
    //   166: invokevirtual getFD : ()Ljava/io/FileDescriptor;
    //   169: putfield b : Ljava/io/FileDescriptor;
    //   172: goto -> 183
    //   175: aload_0
    //   176: aconst_null
    //   177: putfield c : Landroid/content/res/AssetManager$AssetInputStream;
    //   180: goto -> 129
    //   183: aload_0
    //   184: aload_1
    //   185: invokespecial I : (Ljava/io/InputStream;)V
    //   188: return
  }
  
  public a(String paramString) {
    e[][] arrayOfE = j0;
    this.f = (HashMap<String, d>[])new HashMap[arrayOfE.length];
    this.g = new HashSet<Integer>(arrayOfE.length);
    this.h = ByteOrder.BIG_ENDIAN;
    Objects.requireNonNull(paramString, "filename cannot be null");
    v(paramString);
  }
  
  private boolean A(byte[] paramArrayOfbyte) {
    int i = 0;
    while (true) {
      byte[] arrayOfByte = H;
      if (i < arrayOfByte.length) {
        if (paramArrayOfbyte[i] != arrayOfByte[i])
          return false; 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  private boolean B(byte[] paramArrayOfbyte) {
    byte[] arrayOfByte = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
    for (int i = 0; i < arrayOfByte.length; i++) {
      if (paramArrayOfbyte[i] != arrayOfByte[i])
        return false; 
    } 
    return true;
  }
  
  private boolean C(byte[] paramArrayOfbyte) {
    boolean bool = false;
    null = null;
    byte[] arrayOfByte = null;
    try {
    
    } catch (Exception exception) {
    
    } finally {
      paramArrayOfbyte = arrayOfByte;
      if (paramArrayOfbyte != null)
        paramArrayOfbyte.close(); 
    } 
    if (paramArrayOfbyte != null)
      paramArrayOfbyte.close(); 
    return false;
  }
  
  private static boolean D(FileDescriptor paramFileDescriptor) {
    if (Build.VERSION.SDK_INT >= 21)
      try {
        b.a.c(paramFileDescriptor, 0L, OsConstants.SEEK_CUR);
        return true;
      } catch (Exception exception) {
        if (v)
          Log.d("ExifInterface", "The file descriptor for the given input is not seekable"); 
      }  
    return false;
  }
  
  private boolean E(HashMap paramHashMap) {
    d d = (d)paramHashMap.get("BitsPerSample");
    if (d != null) {
      int[] arrayOfInt1 = (int[])d.o(this.h);
      int[] arrayOfInt2 = y;
      if (Arrays.equals(arrayOfInt2, arrayOfInt1))
        return true; 
      if (this.d == 3) {
        d d1 = (d)paramHashMap.get("PhotometricInterpretation");
        if (d1 != null) {
          int i = d1.m(this.h);
          if ((i == 1 && Arrays.equals(arrayOfInt1, A)) || (i == 6 && Arrays.equals(arrayOfInt1, arrayOfInt2)))
            return true; 
        } 
      } 
    } 
    if (v)
      Log.d("ExifInterface", "Unsupported data type value"); 
    return false;
  }
  
  private static boolean F(int paramInt) {
    return (paramInt == 4 || paramInt == 13 || paramInt == 14);
  }
  
  private boolean G(HashMap paramHashMap) {
    d d2 = (d)paramHashMap.get("ImageLength");
    d d1 = (d)paramHashMap.get("ImageWidth");
    if (d2 != null && d1 != null) {
      int i = d2.m(this.h);
      int j = d1.m(this.h);
      if (i <= 512 && j <= 512)
        return true; 
    } 
    return false;
  }
  
  private boolean H(byte[] paramArrayOfbyte) {
    int i = 0;
    while (true) {
      byte[] arrayOfByte = L;
      if (i < arrayOfByte.length) {
        if (paramArrayOfbyte[i] != arrayOfByte[i])
          return false; 
        i++;
        continue;
      } 
      i = 0;
      while (true) {
        arrayOfByte = M;
        if (i < arrayOfByte.length) {
          if (paramArrayOfbyte[L.length + i + 4] != arrayOfByte[i])
            return false; 
          i++;
          continue;
        } 
        return true;
      } 
      break;
    } 
  }
  
  private void I(InputStream paramInputStream) {
    Objects.requireNonNull(paramInputStream, "inputstream shouldn't be null");
    int i = 0;
    try {
      while (i < j0.length) {
        this.f[i] = new HashMap<String, d>();
        i++;
      } 
      InputStream inputStream = paramInputStream;
      if (!this.e) {
        inputStream = new BufferedInputStream(paramInputStream, 5000);
        this.d = i((BufferedInputStream)inputStream);
      } 
      if (X(this.d)) {
        paramInputStream = new g(inputStream);
        if (this.e) {
          o((g)paramInputStream);
        } else {
          i = this.d;
          if (i == 12) {
            g((g)paramInputStream);
          } else if (i == 7) {
            j((g)paramInputStream);
          } else if (i == 10) {
            n((g)paramInputStream);
          } else {
            m((g)paramInputStream);
          } 
        } 
        paramInputStream.o(this.p);
        W((b)paramInputStream);
      } else {
        paramInputStream = new b(inputStream);
        i = this.d;
        if (i == 4) {
          h((b)paramInputStream, 0, 0);
        } else if (i == 13) {
          k((b)paramInputStream);
        } else if (i == 9) {
          l((b)paramInputStream);
        } else if (i == 14) {
          r((b)paramInputStream);
        } 
      } 
      a();
      if (v) {
        K();
        return;
      } 
    } catch (IOException iOException) {
      boolean bool = v;
      if (bool)
        Log.w("ExifInterface", "Invalid image: ExifInterface got an unsupported image format file(ExifInterface supports JPEG and some RAW image formats only) or a corrupted JPEG file to ExifInterface.", iOException); 
      a();
      if (bool) {
        K();
        return;
      } 
    } catch (UnsupportedOperationException unsupportedOperationException) {
    
    } finally {}
  }
  
  private void J(b paramb) {
    ByteOrder byteOrder = L(paramb);
    this.h = byteOrder;
    paramb.h(byteOrder);
    int i = paramb.readUnsignedShort();
    int j = this.d;
    if (j == 7 || j == 10 || i == 42) {
      i = paramb.readInt();
      if (i >= 8) {
        i -= 8;
        if (i > 0)
          paramb.k(i); 
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid first Ifd offset: ");
      stringBuilder1.append(i);
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid start code: ");
    stringBuilder.append(Integer.toHexString(i));
    throw new IOException(stringBuilder.toString());
  }
  
  private void K() {
    for (int i = 0; i < this.f.length; i++) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The size of tag group[");
      stringBuilder.append(i);
      stringBuilder.append("]: ");
      stringBuilder.append(this.f[i].size());
      Log.d("ExifInterface", stringBuilder.toString());
      for (Map.Entry<String, d> entry : this.f[i].entrySet()) {
        d d = (d)entry.getValue();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("tagName: ");
        stringBuilder1.append((String)entry.getKey());
        stringBuilder1.append(", tagType: ");
        stringBuilder1.append(d.toString());
        stringBuilder1.append(", tagValue: '");
        stringBuilder1.append(d.n(this.h));
        stringBuilder1.append("'");
        Log.d("ExifInterface", stringBuilder1.toString());
      } 
    } 
  }
  
  private ByteOrder L(b paramb) {
    short s = paramb.readShort();
    if (s != 18761) {
      if (s == 19789) {
        if (v)
          Log.d("ExifInterface", "readExifSegment: Byte Align MM"); 
        return ByteOrder.BIG_ENDIAN;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid byte order: ");
      stringBuilder.append(Integer.toHexString(s));
      throw new IOException(stringBuilder.toString());
    } 
    if (v)
      Log.d("ExifInterface", "readExifSegment: Byte Align II"); 
    return ByteOrder.LITTLE_ENDIAN;
  }
  
  private void M(byte[] paramArrayOfbyte, int paramInt) {
    g g = new g(paramArrayOfbyte);
    J(g);
    N(g, paramInt);
  }
  
  private void N(g paramg, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/util/Set;
    //   4: aload_1
    //   5: getfield c : I
    //   8: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   11: invokeinterface add : (Ljava/lang/Object;)Z
    //   16: pop
    //   17: aload_1
    //   18: invokevirtual readShort : ()S
    //   21: istore #5
    //   23: getstatic androidx/exifinterface/media/a.v : Z
    //   26: istore #10
    //   28: ldc 'ExifInterface'
    //   30: astore #17
    //   32: iload #10
    //   34: ifeq -> 74
    //   37: new java/lang/StringBuilder
    //   40: dup
    //   41: invokespecial <init> : ()V
    //   44: astore #18
    //   46: aload #18
    //   48: ldc_w 'numberOfDirectoryEntry: '
    //   51: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: pop
    //   55: aload #18
    //   57: iload #5
    //   59: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: ldc 'ExifInterface'
    //   65: aload #18
    //   67: invokevirtual toString : ()Ljava/lang/String;
    //   70: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   73: pop
    //   74: iload #5
    //   76: ifgt -> 80
    //   79: return
    //   80: iconst_0
    //   81: istore #6
    //   83: iload #6
    //   85: iload #5
    //   87: if_icmpge -> 1319
    //   90: aload_1
    //   91: invokevirtual readUnsignedShort : ()I
    //   94: istore #9
    //   96: aload_1
    //   97: invokevirtual readUnsignedShort : ()I
    //   100: istore #4
    //   102: aload_1
    //   103: invokevirtual readInt : ()I
    //   106: istore #8
    //   108: aload_1
    //   109: invokevirtual a : ()I
    //   112: i2l
    //   113: ldc2_w 4
    //   116: ladd
    //   117: lstore #15
    //   119: getstatic androidx/exifinterface/media/a.l0 : [Ljava/util/HashMap;
    //   122: iload_2
    //   123: aaload
    //   124: iload #9
    //   126: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   129: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   132: checkcast androidx/exifinterface/media/a$e
    //   135: astore #19
    //   137: getstatic androidx/exifinterface/media/a.v : Z
    //   140: istore #10
    //   142: iload #10
    //   144: ifeq -> 217
    //   147: aload #19
    //   149: ifnull -> 162
    //   152: aload #19
    //   154: getfield b : Ljava/lang/String;
    //   157: astore #18
    //   159: goto -> 165
    //   162: aconst_null
    //   163: astore #18
    //   165: aload #17
    //   167: ldc_w 'ifdType: %d, tagNumber: %d, tagName: %s, dataFormat: %d, numberOfComponents: %d'
    //   170: iconst_5
    //   171: anewarray java/lang/Object
    //   174: dup
    //   175: iconst_0
    //   176: iload_2
    //   177: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   180: aastore
    //   181: dup
    //   182: iconst_1
    //   183: iload #9
    //   185: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   188: aastore
    //   189: dup
    //   190: iconst_2
    //   191: aload #18
    //   193: aastore
    //   194: dup
    //   195: iconst_3
    //   196: iload #4
    //   198: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   201: aastore
    //   202: dup
    //   203: iconst_4
    //   204: iload #8
    //   206: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   209: aastore
    //   210: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   213: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   216: pop
    //   217: aload #19
    //   219: ifnonnull -> 267
    //   222: iload #10
    //   224: ifeq -> 264
    //   227: new java/lang/StringBuilder
    //   230: dup
    //   231: invokespecial <init> : ()V
    //   234: astore #18
    //   236: aload #18
    //   238: ldc_w 'Skip the tag entry since tag number is not defined: '
    //   241: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: pop
    //   245: aload #18
    //   247: iload #9
    //   249: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload #17
    //   255: aload #18
    //   257: invokevirtual toString : ()Ljava/lang/String;
    //   260: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   263: pop
    //   264: goto -> 513
    //   267: iload #4
    //   269: ifle -> 471
    //   272: getstatic androidx/exifinterface/media/a.X : [I
    //   275: astore #18
    //   277: iload #4
    //   279: aload #18
    //   281: arraylength
    //   282: if_icmplt -> 288
    //   285: goto -> 471
    //   288: aload #19
    //   290: iload #4
    //   292: invokevirtual a : (I)Z
    //   295: ifne -> 356
    //   298: iload #10
    //   300: ifeq -> 264
    //   303: new java/lang/StringBuilder
    //   306: dup
    //   307: invokespecial <init> : ()V
    //   310: astore #18
    //   312: aload #18
    //   314: ldc_w 'Skip the tag entry since data format ('
    //   317: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   320: pop
    //   321: aload #18
    //   323: getstatic androidx/exifinterface/media/a.W : [Ljava/lang/String;
    //   326: iload #4
    //   328: aaload
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: pop
    //   333: aload #18
    //   335: ldc_w ') is unexpected for tag: '
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload #18
    //   344: aload #19
    //   346: getfield b : Ljava/lang/String;
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: pop
    //   353: goto -> 253
    //   356: iload #4
    //   358: istore_3
    //   359: iload #4
    //   361: bipush #7
    //   363: if_icmpne -> 372
    //   366: aload #19
    //   368: getfield c : I
    //   371: istore_3
    //   372: iload #8
    //   374: i2l
    //   375: aload #18
    //   377: iload_3
    //   378: iaload
    //   379: i2l
    //   380: lmul
    //   381: lstore #13
    //   383: lload #13
    //   385: lconst_0
    //   386: lcmp
    //   387: iflt -> 412
    //   390: lload #13
    //   392: ldc2_w 2147483647
    //   395: lcmp
    //   396: ifle -> 402
    //   399: goto -> 412
    //   402: iconst_1
    //   403: istore #4
    //   405: lload #13
    //   407: lstore #11
    //   409: goto -> 526
    //   412: lload #13
    //   414: lstore #11
    //   416: iload_3
    //   417: istore #4
    //   419: iload #10
    //   421: ifeq -> 516
    //   424: new java/lang/StringBuilder
    //   427: dup
    //   428: invokespecial <init> : ()V
    //   431: astore #18
    //   433: aload #18
    //   435: ldc_w 'Skip the tag entry since the number of components is invalid: '
    //   438: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   441: pop
    //   442: aload #18
    //   444: iload #8
    //   446: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   449: pop
    //   450: aload #17
    //   452: aload #18
    //   454: invokevirtual toString : ()Ljava/lang/String;
    //   457: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   460: pop
    //   461: lload #13
    //   463: lstore #11
    //   465: iload_3
    //   466: istore #4
    //   468: goto -> 516
    //   471: iload #10
    //   473: ifeq -> 513
    //   476: new java/lang/StringBuilder
    //   479: dup
    //   480: invokespecial <init> : ()V
    //   483: astore #18
    //   485: aload #18
    //   487: ldc_w 'Skip the tag entry since data format is invalid: '
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: pop
    //   494: aload #18
    //   496: iload #4
    //   498: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   501: pop
    //   502: aload #17
    //   504: aload #18
    //   506: invokevirtual toString : ()Ljava/lang/String;
    //   509: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   512: pop
    //   513: lconst_0
    //   514: lstore #11
    //   516: iconst_0
    //   517: istore #7
    //   519: iload #4
    //   521: istore_3
    //   522: iload #7
    //   524: istore #4
    //   526: iload #4
    //   528: ifne -> 540
    //   531: aload_1
    //   532: lload #15
    //   534: invokevirtual o : (J)V
    //   537: goto -> 1309
    //   540: lload #11
    //   542: ldc2_w 4
    //   545: lcmp
    //   546: ifle -> 761
    //   549: aload_1
    //   550: invokevirtual readInt : ()I
    //   553: istore #4
    //   555: iload #10
    //   557: ifeq -> 600
    //   560: new java/lang/StringBuilder
    //   563: dup
    //   564: invokespecial <init> : ()V
    //   567: astore #18
    //   569: aload #18
    //   571: ldc_w 'seek to data offset: '
    //   574: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   577: pop
    //   578: aload #18
    //   580: iload #4
    //   582: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   585: pop
    //   586: aload #17
    //   588: aload #18
    //   590: invokevirtual toString : ()Ljava/lang/String;
    //   593: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   596: pop
    //   597: goto -> 600
    //   600: aload_0
    //   601: getfield d : I
    //   604: bipush #7
    //   606: if_icmpne -> 751
    //   609: ldc_w 'MakerNote'
    //   612: aload #19
    //   614: getfield b : Ljava/lang/String;
    //   617: invokevirtual equals : (Ljava/lang/Object;)Z
    //   620: ifeq -> 632
    //   623: aload_0
    //   624: iload #4
    //   626: putfield q : I
    //   629: goto -> 751
    //   632: iload_2
    //   633: bipush #6
    //   635: if_icmpne -> 751
    //   638: ldc_w 'ThumbnailImage'
    //   641: aload #19
    //   643: getfield b : Ljava/lang/String;
    //   646: invokevirtual equals : (Ljava/lang/Object;)Z
    //   649: ifeq -> 751
    //   652: aload_0
    //   653: iload #4
    //   655: putfield r : I
    //   658: aload_0
    //   659: iload #8
    //   661: putfield s : I
    //   664: bipush #6
    //   666: aload_0
    //   667: getfield h : Ljava/nio/ByteOrder;
    //   670: invokestatic j : (ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   673: astore #18
    //   675: aload_0
    //   676: getfield r : I
    //   679: i2l
    //   680: aload_0
    //   681: getfield h : Ljava/nio/ByteOrder;
    //   684: invokestatic f : (JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   687: astore #20
    //   689: aload_0
    //   690: getfield s : I
    //   693: i2l
    //   694: aload_0
    //   695: getfield h : Ljava/nio/ByteOrder;
    //   698: invokestatic f : (JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   701: astore #21
    //   703: aload_0
    //   704: getfield f : [Ljava/util/HashMap;
    //   707: iconst_4
    //   708: aaload
    //   709: ldc_w 'Compression'
    //   712: aload #18
    //   714: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   717: pop
    //   718: aload_0
    //   719: getfield f : [Ljava/util/HashMap;
    //   722: iconst_4
    //   723: aaload
    //   724: ldc_w 'JPEGInterchangeFormat'
    //   727: aload #20
    //   729: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   732: pop
    //   733: aload_0
    //   734: getfield f : [Ljava/util/HashMap;
    //   737: iconst_4
    //   738: aaload
    //   739: ldc_w 'JPEGInterchangeFormatLength'
    //   742: aload #21
    //   744: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   747: pop
    //   748: goto -> 751
    //   751: aload_1
    //   752: iload #4
    //   754: i2l
    //   755: invokevirtual o : (J)V
    //   758: goto -> 761
    //   761: lload #15
    //   763: lstore #13
    //   765: getstatic androidx/exifinterface/media/a.o0 : Ljava/util/HashMap;
    //   768: iload #9
    //   770: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   773: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   776: checkcast java/lang/Integer
    //   779: astore #20
    //   781: iload #10
    //   783: ifeq -> 843
    //   786: new java/lang/StringBuilder
    //   789: dup
    //   790: invokespecial <init> : ()V
    //   793: astore #18
    //   795: aload #18
    //   797: ldc_w 'nextIfdType: '
    //   800: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   803: pop
    //   804: aload #18
    //   806: aload #20
    //   808: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   811: pop
    //   812: aload #18
    //   814: ldc_w ' byteCount: '
    //   817: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   820: pop
    //   821: aload #18
    //   823: lload #11
    //   825: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   828: pop
    //   829: aload #17
    //   831: aload #18
    //   833: invokevirtual toString : ()Ljava/lang/String;
    //   836: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   839: pop
    //   840: goto -> 843
    //   843: aload #17
    //   845: astore #18
    //   847: aload #20
    //   849: ifnull -> 1129
    //   852: ldc2_w -1
    //   855: lstore #11
    //   857: iload_3
    //   858: iconst_3
    //   859: if_icmpeq -> 913
    //   862: iload_3
    //   863: iconst_4
    //   864: if_icmpeq -> 904
    //   867: iload_3
    //   868: bipush #8
    //   870: if_icmpeq -> 896
    //   873: iload_3
    //   874: bipush #9
    //   876: if_icmpeq -> 888
    //   879: iload_3
    //   880: bipush #13
    //   882: if_icmpeq -> 888
    //   885: goto -> 922
    //   888: aload_1
    //   889: invokevirtual readInt : ()I
    //   892: istore_3
    //   893: goto -> 918
    //   896: aload_1
    //   897: invokevirtual readShort : ()S
    //   900: istore_3
    //   901: goto -> 918
    //   904: aload_1
    //   905: invokevirtual g : ()J
    //   908: lstore #11
    //   910: goto -> 922
    //   913: aload_1
    //   914: invokevirtual readUnsignedShort : ()I
    //   917: istore_3
    //   918: iload_3
    //   919: i2l
    //   920: lstore #11
    //   922: iload #10
    //   924: ifeq -> 959
    //   927: aload #18
    //   929: ldc_w 'Offset: %d, tagName: %s'
    //   932: iconst_2
    //   933: anewarray java/lang/Object
    //   936: dup
    //   937: iconst_0
    //   938: lload #11
    //   940: invokestatic valueOf : (J)Ljava/lang/Long;
    //   943: aastore
    //   944: dup
    //   945: iconst_1
    //   946: aload #19
    //   948: getfield b : Ljava/lang/String;
    //   951: aastore
    //   952: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   955: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   958: pop
    //   959: lload #11
    //   961: lconst_0
    //   962: lcmp
    //   963: ifle -> 1070
    //   966: aload_0
    //   967: getfield g : Ljava/util/Set;
    //   970: lload #11
    //   972: l2i
    //   973: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   976: invokeinterface contains : (Ljava/lang/Object;)Z
    //   981: ifne -> 1003
    //   984: aload_1
    //   985: lload #11
    //   987: invokevirtual o : (J)V
    //   990: aload_0
    //   991: aload_1
    //   992: aload #20
    //   994: invokevirtual intValue : ()I
    //   997: invokespecial N : (Landroidx/exifinterface/media/a$g;I)V
    //   1000: goto -> 1116
    //   1003: iload #10
    //   1005: ifeq -> 1116
    //   1008: new java/lang/StringBuilder
    //   1011: dup
    //   1012: invokespecial <init> : ()V
    //   1015: astore #17
    //   1017: aload #17
    //   1019: ldc_w 'Skip jump into the IFD since it has already been read: IfdType '
    //   1022: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1025: pop
    //   1026: aload #17
    //   1028: aload #20
    //   1030: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1033: pop
    //   1034: aload #17
    //   1036: ldc_w ' (at '
    //   1039: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1042: pop
    //   1043: aload #17
    //   1045: lload #11
    //   1047: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1050: pop
    //   1051: aload #17
    //   1053: ldc_w ')'
    //   1056: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1059: pop
    //   1060: aload #17
    //   1062: invokevirtual toString : ()Ljava/lang/String;
    //   1065: astore #17
    //   1067: goto -> 1108
    //   1070: iload #10
    //   1072: ifeq -> 1116
    //   1075: new java/lang/StringBuilder
    //   1078: dup
    //   1079: invokespecial <init> : ()V
    //   1082: astore #17
    //   1084: aload #17
    //   1086: ldc_w 'Skip jump into the IFD since its offset is invalid: '
    //   1089: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1092: pop
    //   1093: aload #17
    //   1095: lload #11
    //   1097: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1100: pop
    //   1101: aload #17
    //   1103: invokevirtual toString : ()Ljava/lang/String;
    //   1106: astore #17
    //   1108: aload #18
    //   1110: aload #17
    //   1112: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   1115: pop
    //   1116: aload_1
    //   1117: lload #13
    //   1119: invokevirtual o : (J)V
    //   1122: aload #18
    //   1124: astore #17
    //   1126: goto -> 1309
    //   1129: aload_1
    //   1130: invokevirtual a : ()I
    //   1133: istore #4
    //   1135: aload_0
    //   1136: getfield p : I
    //   1139: istore #7
    //   1141: lload #11
    //   1143: l2i
    //   1144: newarray byte
    //   1146: astore #17
    //   1148: aload_1
    //   1149: aload #17
    //   1151: invokevirtual readFully : ([B)V
    //   1154: new androidx/exifinterface/media/a$d
    //   1157: dup
    //   1158: iload_3
    //   1159: iload #8
    //   1161: iload #4
    //   1163: iload #7
    //   1165: iadd
    //   1166: i2l
    //   1167: aload #17
    //   1169: invokespecial <init> : (IIJ[B)V
    //   1172: astore #17
    //   1174: aload_0
    //   1175: getfield f : [Ljava/util/HashMap;
    //   1178: iload_2
    //   1179: aaload
    //   1180: aload #19
    //   1182: getfield b : Ljava/lang/String;
    //   1185: aload #17
    //   1187: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1190: pop
    //   1191: ldc_w 'DNGVersion'
    //   1194: aload #19
    //   1196: getfield b : Ljava/lang/String;
    //   1199: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1202: ifeq -> 1210
    //   1205: aload_0
    //   1206: iconst_3
    //   1207: putfield d : I
    //   1210: ldc_w 'Make'
    //   1213: aload #19
    //   1215: getfield b : Ljava/lang/String;
    //   1218: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1221: ifne -> 1238
    //   1224: ldc_w 'Model'
    //   1227: aload #19
    //   1229: getfield b : Ljava/lang/String;
    //   1232: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1235: ifeq -> 1256
    //   1238: aload #17
    //   1240: aload_0
    //   1241: getfield h : Ljava/nio/ByteOrder;
    //   1244: invokevirtual n : (Ljava/nio/ByteOrder;)Ljava/lang/String;
    //   1247: ldc_w 'PENTAX'
    //   1250: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1253: ifne -> 1285
    //   1256: ldc_w 'Compression'
    //   1259: aload #19
    //   1261: getfield b : Ljava/lang/String;
    //   1264: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1267: ifeq -> 1291
    //   1270: aload #17
    //   1272: aload_0
    //   1273: getfield h : Ljava/nio/ByteOrder;
    //   1276: invokevirtual m : (Ljava/nio/ByteOrder;)I
    //   1279: ldc_w 65535
    //   1282: if_icmpne -> 1291
    //   1285: aload_0
    //   1286: bipush #8
    //   1288: putfield d : I
    //   1291: aload #18
    //   1293: astore #17
    //   1295: aload_1
    //   1296: invokevirtual a : ()I
    //   1299: i2l
    //   1300: lload #13
    //   1302: lcmp
    //   1303: ifeq -> 1309
    //   1306: goto -> 1116
    //   1309: iload #6
    //   1311: iconst_1
    //   1312: iadd
    //   1313: i2s
    //   1314: istore #6
    //   1316: goto -> 83
    //   1319: aload_1
    //   1320: invokevirtual readInt : ()I
    //   1323: istore_2
    //   1324: getstatic androidx/exifinterface/media/a.v : Z
    //   1327: istore #10
    //   1329: iload #10
    //   1331: ifeq -> 1357
    //   1334: aload #17
    //   1336: ldc_w 'nextIfdOffset: %d'
    //   1339: iconst_1
    //   1340: anewarray java/lang/Object
    //   1343: dup
    //   1344: iconst_0
    //   1345: iload_2
    //   1346: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1349: aastore
    //   1350: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1353: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   1356: pop
    //   1357: iload_2
    //   1358: i2l
    //   1359: lstore #11
    //   1361: lload #11
    //   1363: lconst_0
    //   1364: lcmp
    //   1365: ifle -> 1449
    //   1368: aload_0
    //   1369: getfield g : Ljava/util/Set;
    //   1372: iload_2
    //   1373: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1376: invokeinterface contains : (Ljava/lang/Object;)Z
    //   1381: ifne -> 1428
    //   1384: aload_1
    //   1385: lload #11
    //   1387: invokevirtual o : (J)V
    //   1390: aload_0
    //   1391: getfield f : [Ljava/util/HashMap;
    //   1394: iconst_4
    //   1395: aaload
    //   1396: invokevirtual isEmpty : ()Z
    //   1399: ifeq -> 1409
    //   1402: aload_0
    //   1403: aload_1
    //   1404: iconst_4
    //   1405: invokespecial N : (Landroidx/exifinterface/media/a$g;I)V
    //   1408: return
    //   1409: aload_0
    //   1410: getfield f : [Ljava/util/HashMap;
    //   1413: iconst_5
    //   1414: aaload
    //   1415: invokevirtual isEmpty : ()Z
    //   1418: ifeq -> 1490
    //   1421: aload_0
    //   1422: aload_1
    //   1423: iconst_5
    //   1424: invokespecial N : (Landroidx/exifinterface/media/a$g;I)V
    //   1427: return
    //   1428: iload #10
    //   1430: ifeq -> 1490
    //   1433: new java/lang/StringBuilder
    //   1436: dup
    //   1437: invokespecial <init> : ()V
    //   1440: astore_1
    //   1441: ldc_w 'Stop reading file since re-reading an IFD may cause an infinite loop: '
    //   1444: astore #18
    //   1446: goto -> 1467
    //   1449: iload #10
    //   1451: ifeq -> 1490
    //   1454: new java/lang/StringBuilder
    //   1457: dup
    //   1458: invokespecial <init> : ()V
    //   1461: astore_1
    //   1462: ldc_w 'Stop reading file since a wrong offset may cause an infinite loop: '
    //   1465: astore #18
    //   1467: aload_1
    //   1468: aload #18
    //   1470: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1473: pop
    //   1474: aload_1
    //   1475: iload_2
    //   1476: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1479: pop
    //   1480: aload #17
    //   1482: aload_1
    //   1483: invokevirtual toString : ()Ljava/lang/String;
    //   1486: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   1489: pop
    //   1490: return
  }
  
  private void O(String paramString) {
    for (int i = 0; i < j0.length; i++)
      this.f[i].remove(paramString); 
  }
  
  private void P(int paramInt, String paramString1, String paramString2) {
    if (!this.f[paramInt].isEmpty() && this.f[paramInt].get(paramString1) != null) {
      HashMap<String, d>[] arrayOfHashMap = this.f;
      arrayOfHashMap[paramInt].put(paramString2, arrayOfHashMap[paramInt].get(paramString1));
      this.f[paramInt].remove(paramString1);
    } 
  }
  
  private void Q(g paramg, int paramInt) {
    d d1 = this.f[paramInt].get("ImageLength");
    d d2 = this.f[paramInt].get("ImageWidth");
    if (d1 == null || d2 == null) {
      d1 = this.f[paramInt].get("JPEGInterchangeFormat");
      d2 = this.f[paramInt].get("JPEGInterchangeFormatLength");
      if (d1 != null && d2 != null) {
        int i = d1.m(this.h);
        int j = d1.m(this.h);
        paramg.o(i);
        byte[] arrayOfByte = new byte[j];
        paramg.read(arrayOfByte);
        h(new b(arrayOfByte), i, paramInt);
      } 
    } 
  }
  
  private void S(InputStream paramInputStream, OutputStream paramOutputStream) {
    if (v) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("saveJpegAttributes starting with (inputStream: ");
      stringBuilder.append(paramInputStream);
      stringBuilder.append(", outputStream: ");
      stringBuilder.append(paramOutputStream);
      stringBuilder.append(")");
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    b b = new b(paramInputStream);
    c c = new c(paramOutputStream, ByteOrder.BIG_ENDIAN);
    if (b.readByte() == -1) {
      c.g(-1);
      if (b.readByte() == -40) {
        d d;
        c.g(-40);
        paramOutputStream = null;
        OutputStream outputStream = paramOutputStream;
        if (d("Xmp") != null) {
          outputStream = paramOutputStream;
          if (this.u)
            d = this.f[0].remove("Xmp"); 
        } 
        c.g(-1);
        c.g(-31);
        b0(c);
        if (d != null)
          this.f[0].put("Xmp", d); 
        byte[] arrayOfByte = new byte[4096];
        while (b.readByte() == -1) {
          int i = b.readByte();
          if (i != -39 && i != -38) {
            if (i != -31) {
              c.g(-1);
              c.g(i);
              i = b.readUnsignedShort();
              c.r(i);
              i -= 2;
              if (i >= 0) {
                while (i > 0) {
                  int k = b.read(arrayOfByte, 0, Math.min(i, 4096));
                  if (k >= 0) {
                    c.write(arrayOfByte, 0, k);
                    i -= k;
                  } 
                } 
                continue;
              } 
              throw new IOException("Invalid length");
            } 
            int j = b.readUnsignedShort() - 2;
            if (j >= 0) {
              byte[] arrayOfByte1 = new byte[6];
              if (j >= 6)
                if (b.read(arrayOfByte1) == 6) {
                  if (Arrays.equals(arrayOfByte1, q0)) {
                    b.k(j - 6);
                    continue;
                  } 
                } else {
                  throw new IOException("Invalid exif");
                }  
              c.g(-1);
              c.g(i);
              c.r(j + 2);
              i = j;
              if (j >= 6) {
                i = j - 6;
                c.write(arrayOfByte1);
              } 
              while (i > 0) {
                j = b.read(arrayOfByte, 0, Math.min(i, 4096));
                if (j >= 0) {
                  c.write(arrayOfByte, 0, j);
                  i -= j;
                } 
              } 
              continue;
            } 
            throw new IOException("Invalid length");
          } 
          c.g(-1);
          c.g(i);
          b.e(b, c);
          return;
        } 
        throw new IOException("Invalid marker");
      } 
      throw new IOException("Invalid marker");
    } 
    throw new IOException("Invalid marker");
  }
  
  private void T(InputStream paramInputStream, OutputStream paramOutputStream) {
    OutputStream outputStream;
    b b1;
    if (v) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("savePngAttributes starting with (inputStream: ");
      stringBuilder.append(paramInputStream);
      stringBuilder.append(", outputStream: ");
      stringBuilder.append(paramOutputStream);
      stringBuilder.append(")");
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    b b2 = new b(paramInputStream);
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
    c c = new c(paramOutputStream, byteOrder);
    byte[] arrayOfByte = H;
    b.f(b2, c, arrayOfByte.length);
    int i = this.p;
    if (i == 0) {
      i = b2.readInt();
      c.h(i);
      b.f(b2, c, i + 4 + 4);
    } else {
      b.f(b2, c, i - arrayOfByte.length - 4 - 4);
      b2.k(b2.readInt() + 4 + 4);
    } 
    paramOutputStream = null;
    try {
    
    } finally {
      b2 = null;
      outputStream = paramOutputStream;
    } 
    b.c(outputStream);
    throw b1;
  }
  
  private void U(InputStream paramInputStream, OutputStream paramOutputStream) {
    // Byte code:
    //   0: getstatic androidx/exifinterface/media/a.v : Z
    //   3: ifeq -> 67
    //   6: new java/lang/StringBuilder
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: astore #10
    //   15: aload #10
    //   17: ldc_w 'saveWebpAttributes starting with (inputStream: '
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: pop
    //   24: aload #10
    //   26: aload_1
    //   27: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   30: pop
    //   31: aload #10
    //   33: ldc_w ', outputStream: '
    //   36: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: pop
    //   40: aload #10
    //   42: aload_2
    //   43: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   46: pop
    //   47: aload #10
    //   49: ldc_w ')'
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: ldc 'ExifInterface'
    //   58: aload #10
    //   60: invokevirtual toString : ()Ljava/lang/String;
    //   63: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   66: pop
    //   67: getstatic java/nio/ByteOrder.LITTLE_ENDIAN : Ljava/nio/ByteOrder;
    //   70: astore #14
    //   72: new androidx/exifinterface/media/a$b
    //   75: dup
    //   76: aload_1
    //   77: aload #14
    //   79: invokespecial <init> : (Ljava/io/InputStream;Ljava/nio/ByteOrder;)V
    //   82: astore #12
    //   84: new androidx/exifinterface/media/a$c
    //   87: dup
    //   88: aload_2
    //   89: aload #14
    //   91: invokespecial <init> : (Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V
    //   94: astore #13
    //   96: getstatic androidx/exifinterface/media/a.L : [B
    //   99: astore #15
    //   101: aload #12
    //   103: aload #13
    //   105: aload #15
    //   107: arraylength
    //   108: invokestatic f : (Ljava/io/InputStream;Ljava/io/OutputStream;I)V
    //   111: getstatic androidx/exifinterface/media/a.M : [B
    //   114: astore #16
    //   116: aload #12
    //   118: aload #16
    //   120: arraylength
    //   121: iconst_4
    //   122: iadd
    //   123: invokevirtual k : (I)V
    //   126: aconst_null
    //   127: astore #11
    //   129: aconst_null
    //   130: astore_2
    //   131: new java/io/ByteArrayOutputStream
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: astore #10
    //   140: new androidx/exifinterface/media/a$c
    //   143: dup
    //   144: aload #10
    //   146: aload #14
    //   148: invokespecial <init> : (Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V
    //   151: astore_2
    //   152: aload_0
    //   153: getfield p : I
    //   156: istore_3
    //   157: iload_3
    //   158: ifeq -> 225
    //   161: aload #12
    //   163: aload_2
    //   164: iload_3
    //   165: aload #15
    //   167: arraylength
    //   168: iconst_4
    //   169: iadd
    //   170: aload #16
    //   172: arraylength
    //   173: iadd
    //   174: isub
    //   175: iconst_4
    //   176: isub
    //   177: iconst_4
    //   178: isub
    //   179: invokestatic f : (Ljava/io/InputStream;Ljava/io/OutputStream;I)V
    //   182: aload #12
    //   184: iconst_4
    //   185: invokevirtual k : (I)V
    //   188: aload #12
    //   190: invokevirtual readInt : ()I
    //   193: istore #4
    //   195: iload #4
    //   197: istore_3
    //   198: iload #4
    //   200: iconst_2
    //   201: irem
    //   202: ifeq -> 210
    //   205: iload #4
    //   207: iconst_1
    //   208: iadd
    //   209: istore_3
    //   210: aload #12
    //   212: iload_3
    //   213: invokevirtual k : (I)V
    //   216: aload_0
    //   217: aload_2
    //   218: invokespecial b0 : (Landroidx/exifinterface/media/a$c;)I
    //   221: pop
    //   222: goto -> 833
    //   225: iconst_4
    //   226: newarray byte
    //   228: astore #11
    //   230: aload #12
    //   232: aload #11
    //   234: invokevirtual read : ([B)I
    //   237: iconst_4
    //   238: if_icmpne -> 878
    //   241: getstatic androidx/exifinterface/media/a.P : [B
    //   244: astore #14
    //   246: aload #11
    //   248: aload #14
    //   250: invokestatic equals : ([B[B)Z
    //   253: istore #9
    //   255: iconst_1
    //   256: istore #5
    //   258: iconst_1
    //   259: istore #6
    //   261: iload #9
    //   263: ifeq -> 419
    //   266: aload #12
    //   268: invokevirtual readInt : ()I
    //   271: istore #4
    //   273: iload #4
    //   275: iconst_2
    //   276: irem
    //   277: iconst_1
    //   278: if_icmpne -> 929
    //   281: iload #4
    //   283: iconst_1
    //   284: iadd
    //   285: istore_3
    //   286: goto -> 289
    //   289: iload_3
    //   290: newarray byte
    //   292: astore #11
    //   294: aload #12
    //   296: aload #11
    //   298: invokevirtual read : ([B)I
    //   301: pop
    //   302: aload #11
    //   304: iconst_0
    //   305: bipush #8
    //   307: aload #11
    //   309: iconst_0
    //   310: baload
    //   311: ior
    //   312: i2b
    //   313: bastore
    //   314: aload #11
    //   316: iconst_0
    //   317: baload
    //   318: iconst_1
    //   319: ishr
    //   320: iconst_1
    //   321: iand
    //   322: iconst_1
    //   323: if_icmpne -> 935
    //   326: iload #6
    //   328: istore_3
    //   329: goto -> 332
    //   332: aload_2
    //   333: aload #14
    //   335: invokevirtual write : ([B)V
    //   338: aload_2
    //   339: iload #4
    //   341: invokevirtual h : (I)V
    //   344: aload_2
    //   345: aload #11
    //   347: invokevirtual write : ([B)V
    //   350: iload_3
    //   351: ifeq -> 403
    //   354: aload_0
    //   355: aload #12
    //   357: aload_2
    //   358: getstatic androidx/exifinterface/media/a.S : [B
    //   361: aconst_null
    //   362: invokespecial b : (Landroidx/exifinterface/media/a$b;Landroidx/exifinterface/media/a$c;[B[B)V
    //   365: iconst_4
    //   366: newarray byte
    //   368: astore #11
    //   370: aload_1
    //   371: aload #11
    //   373: invokevirtual read : ([B)I
    //   376: pop
    //   377: aload #11
    //   379: getstatic androidx/exifinterface/media/a.T : [B
    //   382: invokestatic equals : ([B[B)Z
    //   385: ifne -> 391
    //   388: goto -> 216
    //   391: aload_0
    //   392: aload #12
    //   394: aload_2
    //   395: aload #11
    //   397: invokespecial c : (Landroidx/exifinterface/media/a$b;Landroidx/exifinterface/media/a$c;[B)V
    //   400: goto -> 365
    //   403: aload_0
    //   404: aload #12
    //   406: aload_2
    //   407: getstatic androidx/exifinterface/media/a.R : [B
    //   410: getstatic androidx/exifinterface/media/a.Q : [B
    //   413: invokespecial b : (Landroidx/exifinterface/media/a$b;Landroidx/exifinterface/media/a$c;[B[B)V
    //   416: goto -> 216
    //   419: getstatic androidx/exifinterface/media/a.R : [B
    //   422: astore_1
    //   423: aload #11
    //   425: aload_1
    //   426: invokestatic equals : ([B[B)Z
    //   429: ifne -> 443
    //   432: aload #11
    //   434: getstatic androidx/exifinterface/media/a.Q : [B
    //   437: invokestatic equals : ([B[B)Z
    //   440: ifeq -> 833
    //   443: aload #12
    //   445: invokevirtual readInt : ()I
    //   448: istore #8
    //   450: iload #8
    //   452: iconst_2
    //   453: irem
    //   454: iconst_1
    //   455: if_icmpne -> 940
    //   458: iload #8
    //   460: iconst_1
    //   461: iadd
    //   462: istore_3
    //   463: goto -> 466
    //   466: iconst_3
    //   467: newarray byte
    //   469: astore #15
    //   471: aload #11
    //   473: aload_1
    //   474: invokestatic equals : ([B[B)Z
    //   477: ifeq -> 563
    //   480: aload #12
    //   482: aload #15
    //   484: invokevirtual read : ([B)I
    //   487: pop
    //   488: iconst_3
    //   489: newarray byte
    //   491: astore #16
    //   493: aload #12
    //   495: aload #16
    //   497: invokevirtual read : ([B)I
    //   500: iconst_3
    //   501: if_icmpne -> 552
    //   504: getstatic androidx/exifinterface/media/a.O : [B
    //   507: aload #16
    //   509: invokestatic equals : ([B[B)Z
    //   512: ifeq -> 552
    //   515: aload #12
    //   517: invokevirtual readInt : ()I
    //   520: istore #4
    //   522: iload_3
    //   523: bipush #10
    //   525: isub
    //   526: istore_3
    //   527: iload #4
    //   529: iconst_2
    //   530: ishl
    //   531: bipush #18
    //   533: ishr
    //   534: istore #7
    //   536: iload #4
    //   538: bipush #18
    //   540: ishl
    //   541: bipush #18
    //   543: ishr
    //   544: istore #6
    //   546: iconst_0
    //   547: istore #5
    //   549: goto -> 637
    //   552: new java/io/IOException
    //   555: dup
    //   556: ldc_w 'Encountered error while checking VP8 signature'
    //   559: invokespecial <init> : (Ljava/lang/String;)V
    //   562: athrow
    //   563: aload #11
    //   565: getstatic androidx/exifinterface/media/a.Q : [B
    //   568: invokestatic equals : ([B[B)Z
    //   571: ifeq -> 956
    //   574: aload #12
    //   576: invokevirtual readByte : ()B
    //   579: bipush #47
    //   581: if_icmpne -> 626
    //   584: aload #12
    //   586: invokevirtual readInt : ()I
    //   589: istore #4
    //   591: iload #4
    //   593: sipush #16383
    //   596: iand
    //   597: iconst_1
    //   598: iadd
    //   599: istore #6
    //   601: iload #4
    //   603: ldc_w 268419072
    //   606: iand
    //   607: bipush #14
    //   609: iushr
    //   610: iconst_1
    //   611: iadd
    //   612: istore #7
    //   614: iload #4
    //   616: ldc_w 268435456
    //   619: iand
    //   620: ifeq -> 946
    //   623: goto -> 949
    //   626: new java/io/IOException
    //   629: dup
    //   630: ldc_w 'Encountered error while checking VP8L signature'
    //   633: invokespecial <init> : (Ljava/lang/String;)V
    //   636: athrow
    //   637: aload_2
    //   638: aload #14
    //   640: invokevirtual write : ([B)V
    //   643: aload_2
    //   644: bipush #10
    //   646: invokevirtual h : (I)V
    //   649: bipush #10
    //   651: newarray byte
    //   653: astore #14
    //   655: iload #5
    //   657: ifeq -> 672
    //   660: aload #14
    //   662: iconst_0
    //   663: aload #14
    //   665: iconst_0
    //   666: baload
    //   667: bipush #16
    //   669: ior
    //   670: i2b
    //   671: bastore
    //   672: aload #14
    //   674: iconst_0
    //   675: aload #14
    //   677: iconst_0
    //   678: baload
    //   679: bipush #8
    //   681: ior
    //   682: i2b
    //   683: bastore
    //   684: iload #6
    //   686: iconst_1
    //   687: isub
    //   688: istore #5
    //   690: iload #7
    //   692: iconst_1
    //   693: isub
    //   694: istore #6
    //   696: aload #14
    //   698: iconst_4
    //   699: iload #5
    //   701: i2b
    //   702: bastore
    //   703: aload #14
    //   705: iconst_5
    //   706: iload #5
    //   708: bipush #8
    //   710: ishr
    //   711: i2b
    //   712: bastore
    //   713: aload #14
    //   715: bipush #6
    //   717: iload #5
    //   719: bipush #16
    //   721: ishr
    //   722: i2b
    //   723: bastore
    //   724: aload #14
    //   726: bipush #7
    //   728: iload #6
    //   730: i2b
    //   731: bastore
    //   732: aload #14
    //   734: bipush #8
    //   736: iload #6
    //   738: bipush #8
    //   740: ishr
    //   741: i2b
    //   742: bastore
    //   743: aload #14
    //   745: bipush #9
    //   747: iload #6
    //   749: bipush #16
    //   751: ishr
    //   752: i2b
    //   753: bastore
    //   754: aload_2
    //   755: aload #14
    //   757: invokevirtual write : ([B)V
    //   760: aload_2
    //   761: aload #11
    //   763: invokevirtual write : ([B)V
    //   766: aload_2
    //   767: iload #8
    //   769: invokevirtual h : (I)V
    //   772: aload #11
    //   774: aload_1
    //   775: invokestatic equals : ([B[B)Z
    //   778: ifeq -> 803
    //   781: aload_2
    //   782: aload #15
    //   784: invokevirtual write : ([B)V
    //   787: aload_2
    //   788: getstatic androidx/exifinterface/media/a.O : [B
    //   791: invokevirtual write : ([B)V
    //   794: aload_2
    //   795: iload #4
    //   797: invokevirtual h : (I)V
    //   800: goto -> 823
    //   803: aload #11
    //   805: getstatic androidx/exifinterface/media/a.Q : [B
    //   808: invokestatic equals : ([B[B)Z
    //   811: ifeq -> 823
    //   814: aload_2
    //   815: bipush #47
    //   817: invokevirtual write : (I)V
    //   820: goto -> 794
    //   823: aload #12
    //   825: aload_2
    //   826: iload_3
    //   827: invokestatic f : (Ljava/io/InputStream;Ljava/io/OutputStream;I)V
    //   830: goto -> 216
    //   833: aload #12
    //   835: aload_2
    //   836: invokestatic e : (Ljava/io/InputStream;Ljava/io/OutputStream;)I
    //   839: pop
    //   840: aload #10
    //   842: invokevirtual size : ()I
    //   845: istore_3
    //   846: getstatic androidx/exifinterface/media/a.M : [B
    //   849: astore_1
    //   850: aload #13
    //   852: iload_3
    //   853: aload_1
    //   854: arraylength
    //   855: iadd
    //   856: invokevirtual h : (I)V
    //   859: aload #13
    //   861: aload_1
    //   862: invokevirtual write : ([B)V
    //   865: aload #10
    //   867: aload #13
    //   869: invokevirtual writeTo : (Ljava/io/OutputStream;)V
    //   872: aload #10
    //   874: invokestatic c : (Ljava/io/Closeable;)V
    //   877: return
    //   878: new java/io/IOException
    //   881: dup
    //   882: ldc_w 'Encountered invalid length while parsing WebP chunk type'
    //   885: invokespecial <init> : (Ljava/lang/String;)V
    //   888: athrow
    //   889: astore_1
    //   890: aload #10
    //   892: astore_2
    //   893: goto -> 923
    //   896: astore_1
    //   897: aload #10
    //   899: astore_2
    //   900: goto -> 911
    //   903: astore_1
    //   904: goto -> 923
    //   907: astore_1
    //   908: aload #11
    //   910: astore_2
    //   911: new java/io/IOException
    //   914: dup
    //   915: ldc_w 'Failed to save WebP file'
    //   918: aload_1
    //   919: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   922: athrow
    //   923: aload_2
    //   924: invokestatic c : (Ljava/io/Closeable;)V
    //   927: aload_1
    //   928: athrow
    //   929: iload #4
    //   931: istore_3
    //   932: goto -> 289
    //   935: iconst_0
    //   936: istore_3
    //   937: goto -> 332
    //   940: iload #8
    //   942: istore_3
    //   943: goto -> 466
    //   946: iconst_0
    //   947: istore #5
    //   949: iload_3
    //   950: iconst_5
    //   951: isub
    //   952: istore_3
    //   953: goto -> 637
    //   956: iconst_0
    //   957: istore #4
    //   959: iconst_0
    //   960: istore #5
    //   962: iconst_0
    //   963: istore #6
    //   965: iconst_0
    //   966: istore #7
    //   968: goto -> 637
    // Exception table:
    //   from	to	target	type
    //   131	140	907	java/lang/Exception
    //   131	140	903	finally
    //   140	157	896	java/lang/Exception
    //   140	157	889	finally
    //   161	195	896	java/lang/Exception
    //   161	195	889	finally
    //   210	216	896	java/lang/Exception
    //   210	216	889	finally
    //   216	222	896	java/lang/Exception
    //   216	222	889	finally
    //   225	255	896	java/lang/Exception
    //   225	255	889	finally
    //   266	273	896	java/lang/Exception
    //   266	273	889	finally
    //   289	302	896	java/lang/Exception
    //   289	302	889	finally
    //   332	350	896	java/lang/Exception
    //   332	350	889	finally
    //   354	365	896	java/lang/Exception
    //   354	365	889	finally
    //   365	388	896	java/lang/Exception
    //   365	388	889	finally
    //   391	400	896	java/lang/Exception
    //   391	400	889	finally
    //   403	416	896	java/lang/Exception
    //   403	416	889	finally
    //   419	443	896	java/lang/Exception
    //   419	443	889	finally
    //   443	450	896	java/lang/Exception
    //   443	450	889	finally
    //   466	522	896	java/lang/Exception
    //   466	522	889	finally
    //   552	563	896	java/lang/Exception
    //   552	563	889	finally
    //   563	591	896	java/lang/Exception
    //   563	591	889	finally
    //   626	637	896	java/lang/Exception
    //   626	637	889	finally
    //   637	655	896	java/lang/Exception
    //   637	655	889	finally
    //   754	794	896	java/lang/Exception
    //   754	794	889	finally
    //   794	800	896	java/lang/Exception
    //   794	800	889	finally
    //   803	820	896	java/lang/Exception
    //   803	820	889	finally
    //   823	830	896	java/lang/Exception
    //   823	830	889	finally
    //   833	872	896	java/lang/Exception
    //   833	872	889	finally
    //   878	889	896	java/lang/Exception
    //   878	889	889	finally
    //   911	923	903	finally
  }
  
  private void W(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : [Ljava/util/HashMap;
    //   4: iconst_4
    //   5: aaload
    //   6: astore_3
    //   7: aload_3
    //   8: ldc_w 'Compression'
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: checkcast androidx/exifinterface/media/a$d
    //   17: astore #4
    //   19: aload #4
    //   21: ifnull -> 72
    //   24: aload #4
    //   26: aload_0
    //   27: getfield h : Ljava/nio/ByteOrder;
    //   30: invokevirtual m : (Ljava/nio/ByteOrder;)I
    //   33: istore_2
    //   34: aload_0
    //   35: iload_2
    //   36: putfield o : I
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpeq -> 57
    //   44: iload_2
    //   45: bipush #6
    //   47: if_icmpeq -> 78
    //   50: iload_2
    //   51: bipush #7
    //   53: if_icmpeq -> 57
    //   56: return
    //   57: aload_0
    //   58: aload_3
    //   59: invokespecial E : (Ljava/util/HashMap;)Z
    //   62: ifeq -> 84
    //   65: aload_0
    //   66: aload_1
    //   67: aload_3
    //   68: invokespecial u : (Landroidx/exifinterface/media/a$b;Ljava/util/HashMap;)V
    //   71: return
    //   72: aload_0
    //   73: bipush #6
    //   75: putfield o : I
    //   78: aload_0
    //   79: aload_1
    //   80: aload_3
    //   81: invokespecial t : (Landroidx/exifinterface/media/a$b;Ljava/util/HashMap;)V
    //   84: return
  }
  
  private static boolean X(int paramInt) {
    return !(paramInt == 4 || paramInt == 9 || paramInt == 13 || paramInt == 14);
  }
  
  private void Y(int paramInt1, int paramInt2) {
    HashMap<String, d>[] arrayOfHashMap;
    if (this.f[paramInt1].isEmpty() || this.f[paramInt2].isEmpty()) {
      if (v)
        Log.d("ExifInterface", "Cannot perform swap since only one image data exists"); 
      return;
    } 
    d d1 = this.f[paramInt1].get("ImageLength");
    d d2 = this.f[paramInt1].get("ImageWidth");
    d d3 = this.f[paramInt2].get("ImageLength");
    d d4 = this.f[paramInt2].get("ImageWidth");
    if (d1 == null || d2 == null) {
      if (v) {
        String str = "First image does not contain valid size information";
      } else {
        return;
      } 
    } else {
      String str;
      if (d3 == null || d4 == null) {
        if (v) {
          str = "Second image does not contain valid size information";
        } else {
          return;
        } 
      } else {
        int i = str.m(this.h);
        int j = d2.m(this.h);
        int k = d3.m(this.h);
        int m = d4.m(this.h);
        if (i < k && j < m) {
          arrayOfHashMap = this.f;
          HashMap<String, d> hashMap = arrayOfHashMap[paramInt1];
          arrayOfHashMap[paramInt1] = arrayOfHashMap[paramInt2];
          arrayOfHashMap[paramInt2] = hashMap;
          return;
        } 
        return;
      } 
    } 
    Log.d("ExifInterface", (String)arrayOfHashMap);
  }
  
  private void Z(g paramg, int paramInt) {
    d d1;
    int[] arrayOfInt;
    d d2 = this.f[paramInt].get("DefaultCropSize");
    d d3 = this.f[paramInt].get("SensorTopBorder");
    d d4 = this.f[paramInt].get("SensorLeftBorder");
    d d5 = this.f[paramInt].get("SensorBottomBorder");
    d d6 = this.f[paramInt].get("SensorRightBorder");
    if (d2 != null) {
      if (d2.a == 5) {
        f[] arrayOfF = (f[])d2.o(this.h);
        if (arrayOfF == null || arrayOfF.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          String str = Arrays.toString((Object[])arrayOfF);
        } else {
          d1 = d.h(arrayOfF[0], this.h);
          d2 = d.h(arrayOfF[1], this.h);
          this.f[paramInt].put("ImageWidth", d1);
          this.f[paramInt].put("ImageLength", d2);
        } 
      } else {
        arrayOfInt = (int[])d2.o(this.h);
        if (arrayOfInt == null || arrayOfInt.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          String str = Arrays.toString(arrayOfInt);
        } else {
          d1 = d.j(arrayOfInt[0], this.h);
          d2 = d.j(arrayOfInt[1], this.h);
          this.f[paramInt].put("ImageWidth", d1);
          this.f[paramInt].put("ImageLength", d2);
        } 
      } 
      d2.append((String)d1);
      Log.w("ExifInterface", d2.toString());
      return;
    } 
    if (arrayOfInt != null && d4 != null && d5 != null && d6 != null) {
      int i = arrayOfInt.m(this.h);
      int j = d5.m(this.h);
      int k = d6.m(this.h);
      int m = d4.m(this.h);
      if (j > i && k > m) {
        d1 = d.j(j - i, this.h);
        d2 = d.j(k - m, this.h);
        this.f[paramInt].put("ImageLength", d1);
        this.f[paramInt].put("ImageWidth", d2);
        return;
      } 
    } else {
      Q((g)d1, paramInt);
    } 
  }
  
  private void a() {
    String str = d("DateTimeOriginal");
    if (str != null && d("DateTime") == null)
      this.f[0].put("DateTime", d.e(str)); 
    if (d("ImageWidth") == null)
      this.f[0].put("ImageWidth", d.f(0L, this.h)); 
    if (d("ImageLength") == null)
      this.f[0].put("ImageLength", d.f(0L, this.h)); 
    if (d("Orientation") == null)
      this.f[0].put("Orientation", d.f(0L, this.h)); 
    if (d("LightSource") == null)
      this.f[1].put("LightSource", d.f(0L, this.h)); 
  }
  
  private void a0() {
    Y(0, 5);
    Y(0, 4);
    Y(5, 4);
    d d1 = this.f[1].get("PixelXDimension");
    d d2 = this.f[1].get("PixelYDimension");
    if (d1 != null && d2 != null) {
      this.f[0].put("ImageWidth", d1);
      this.f[0].put("ImageLength", d2);
    } 
    if (this.f[4].isEmpty() && G(this.f[5])) {
      HashMap<String, d>[] arrayOfHashMap = this.f;
      arrayOfHashMap[4] = arrayOfHashMap[5];
      arrayOfHashMap[5] = new HashMap<String, d>();
    } 
    if (!G(this.f[4]))
      Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image."); 
    P(0, "ThumbnailOrientation", "Orientation");
    P(0, "ThumbnailImageLength", "ImageLength");
    P(0, "ThumbnailImageWidth", "ImageWidth");
    P(5, "ThumbnailOrientation", "Orientation");
    P(5, "ThumbnailImageLength", "ImageLength");
    P(5, "ThumbnailImageWidth", "ImageWidth");
    P(4, "Orientation", "ThumbnailOrientation");
    P(4, "ImageLength", "ThumbnailImageLength");
    P(4, "ImageWidth", "ThumbnailImageWidth");
  }
  
  private void b(b paramb, c paramc, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    StringBuilder stringBuilder;
    byte[] arrayOfByte;
    do {
      String str;
      StringBuilder stringBuilder1;
      arrayOfByte = new byte[4];
      if (paramb.read(arrayOfByte) != 4) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Encountered invalid length while copying WebP chunks up tochunk type ");
        Charset charset = p0;
        stringBuilder1.append(new String(paramArrayOfbyte1, charset));
        if (paramArrayOfbyte2 == null) {
          str = "";
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append(" or ");
          stringBuilder.append(new String(paramArrayOfbyte2, (Charset)str));
          str = stringBuilder.toString();
        } 
        stringBuilder1.append(str);
        throw new IOException(stringBuilder1.toString());
      } 
      c((b)str, (c)stringBuilder1, arrayOfByte);
    } while (!Arrays.equals(arrayOfByte, (byte[])stringBuilder) && (paramArrayOfbyte2 == null || !Arrays.equals(arrayOfByte, paramArrayOfbyte2)));
  }
  
  private int b0(c paramc) {
    char c1;
    e[][] arrayOfE = j0;
    int[] arrayOfInt1 = new int[arrayOfE.length];
    int[] arrayOfInt2 = new int[arrayOfE.length];
    e[] arrayOfE1 = k0;
    int j = arrayOfE1.length;
    int i;
    for (i = 0; i < j; i++)
      O((arrayOfE1[i]).b); 
    if (this.i)
      if (this.j) {
        O("StripOffsets");
        O("StripByteCounts");
      } else {
        O("JPEGInterchangeFormat");
        O("JPEGInterchangeFormatLength");
      }  
    for (i = 0; i < j0.length; i++) {
      Object[] arrayOfObject = this.f[i].entrySet().toArray();
      int k = arrayOfObject.length;
      for (j = 0; j < k; j++) {
        Map.Entry entry = (Map.Entry)arrayOfObject[j];
        if (entry.getValue() == null)
          this.f[i].remove(entry.getKey()); 
      } 
    } 
    if (!this.f[1].isEmpty())
      this.f[0].put((k0[1]).b, d.f(0L, this.h)); 
    if (!this.f[2].isEmpty())
      this.f[0].put((k0[2]).b, d.f(0L, this.h)); 
    if (!this.f[3].isEmpty())
      this.f[1].put((k0[3]).b, d.f(0L, this.h)); 
    if (this.i)
      if (this.j) {
        this.f[4].put("StripOffsets", d.j(0, this.h));
        this.f[4].put("StripByteCounts", d.j(this.m, this.h));
      } else {
        this.f[4].put("JPEGInterchangeFormat", d.f(0L, this.h));
        this.f[4].put("JPEGInterchangeFormatLength", d.f(this.m, this.h));
      }  
    for (i = 0; i < j0.length; i++) {
      Iterator<Map.Entry> iterator = this.f[i].entrySet().iterator();
      j = 0;
      while (iterator.hasNext()) {
        int k = ((d)((Map.Entry)iterator.next()).getValue()).p();
        if (k > 4)
          j += k; 
      } 
      arrayOfInt2[i] = arrayOfInt2[i] + j;
    } 
    i = 8;
    j = 0;
    while (j < j0.length) {
      int k = i;
      if (!this.f[j].isEmpty()) {
        arrayOfInt1[j] = i;
        k = i + this.f[j].size() * 12 + 2 + 4 + arrayOfInt2[j];
      } 
      j++;
      i = k;
    } 
    j = i;
    if (this.i) {
      if (this.j) {
        this.f[4].put("StripOffsets", d.j(i, this.h));
      } else {
        this.f[4].put("JPEGInterchangeFormat", d.f(i, this.h));
      } 
      this.l = i;
      j = i + this.m;
    } 
    i = j;
    if (this.d == 4)
      i = j + 8; 
    if (v)
      for (j = 0; j < j0.length; j++) {
        Log.d("ExifInterface", String.format("index: %d, offsets: %d, tag count: %d, data sizes: %d, total size: %d", new Object[] { Integer.valueOf(j), Integer.valueOf(arrayOfInt1[j]), Integer.valueOf(this.f[j].size()), Integer.valueOf(arrayOfInt2[j]), Integer.valueOf(i) }));
      }  
    if (!this.f[1].isEmpty())
      this.f[0].put((k0[1]).b, d.f(arrayOfInt1[1], this.h)); 
    if (!this.f[2].isEmpty())
      this.f[0].put((k0[2]).b, d.f(arrayOfInt1[2], this.h)); 
    if (!this.f[3].isEmpty())
      this.f[1].put((k0[3]).b, d.f(arrayOfInt1[3], this.h)); 
    j = this.d;
    if (j != 4) {
      if (j != 13) {
        if (j == 14) {
          paramc.write(N);
          paramc.h(i);
        } 
      } else {
        paramc.h(i);
        paramc.write(I);
      } 
    } else {
      paramc.r(i);
      paramc.write(q0);
    } 
    if (this.h == ByteOrder.BIG_ENDIAN) {
      c1 = '䵍';
    } else {
      c1 = '䥉';
    } 
    paramc.k(c1);
    paramc.a(this.h);
    paramc.r(42);
    paramc.o(8L);
    for (j = 0; j < j0.length; j++) {
      if (!this.f[j].isEmpty()) {
        paramc.r(this.f[j].size());
        int k = arrayOfInt1[j] + 2 + this.f[j].size() * 12 + 4;
        for (Map.Entry<String, d> entry : this.f[j].entrySet()) {
          int m = ((e)m0[j].get(entry.getKey())).a;
          d d = (d)entry.getValue();
          int n = d.p();
          paramc.r(m);
          paramc.r(d.a);
          paramc.h(d.b);
          if (n > 4) {
            paramc.o(k);
            m = k + n;
          } else {
            paramc.write(d.d);
            m = k;
            if (n < 4)
              while (true) {
                m = k;
                if (n < 4) {
                  paramc.g(0);
                  n++;
                  continue;
                } 
                break;
              }  
          } 
          k = m;
        } 
        if (j == 0 && !this.f[4].isEmpty()) {
          paramc.o(arrayOfInt1[4]);
        } else {
          paramc.o(0L);
        } 
        Iterator iterator = this.f[j].entrySet().iterator();
        while (iterator.hasNext()) {
          byte[] arrayOfByte = ((d)((Map.Entry)iterator.next()).getValue()).d;
          if (arrayOfByte.length > 4)
            paramc.write(arrayOfByte, 0, arrayOfByte.length); 
        } 
      } 
    } 
    if (this.i)
      paramc.write(q()); 
    if (this.d == 14 && i % 2 == 1)
      paramc.g(0); 
    paramc.a(ByteOrder.BIG_ENDIAN);
    return i;
  }
  
  private void c(b paramb, c paramc, byte[] paramArrayOfbyte) {
    int j = paramb.readInt();
    paramc.write(paramArrayOfbyte);
    paramc.h(j);
    int i = j;
    if (j % 2 == 1)
      i = j + 1; 
    b.f(paramb, paramc, i);
  }
  
  private d f(String paramString) {
    Objects.requireNonNull(paramString, "tag shouldn't be null");
    String str = paramString;
    if ("ISOSpeedRatings".equals(paramString)) {
      if (v)
        Log.d("ExifInterface", "getExifAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY."); 
      str = "PhotographicSensitivity";
    } 
    for (int i = 0; i < j0.length; i++) {
      d d = this.f[i].get(str);
      if (d != null)
        return d; 
    } 
    return null;
  }
  
  private void g(g paramg) {
    if (Build.VERSION.SDK_INT >= 28) {
      MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
      try {
        b.b.a(mediaMetadataRetriever, new a(this, paramg));
        String str4 = mediaMetadataRetriever.extractMetadata(33);
        String str5 = mediaMetadataRetriever.extractMetadata(34);
        String str2 = mediaMetadataRetriever.extractMetadata(26);
        String str1 = mediaMetadataRetriever.extractMetadata(17);
        boolean bool = "yes".equals(str2);
        String str3 = null;
        if (bool) {
          str3 = mediaMetadataRetriever.extractMetadata(29);
          str1 = mediaMetadataRetriever.extractMetadata(30);
          str2 = mediaMetadataRetriever.extractMetadata(31);
        } else if ("yes".equals(str1)) {
          str3 = mediaMetadataRetriever.extractMetadata(18);
          str1 = mediaMetadataRetriever.extractMetadata(19);
          str2 = mediaMetadataRetriever.extractMetadata(24);
        } else {
          str1 = null;
          str2 = str1;
        } 
        if (str3 != null)
          this.f[0].put("ImageWidth", d.j(Integer.parseInt(str3), this.h)); 
        if (str1 != null)
          this.f[0].put("ImageLength", d.j(Integer.parseInt(str1), this.h)); 
        if (str2 != null) {
          byte b = 1;
          int i = Integer.parseInt(str2);
          if (i != 90) {
            if (i != 180) {
              if (i == 270)
                b = 8; 
            } else {
              b = 3;
            } 
          } else {
            b = 6;
          } 
          this.f[0].put("Orientation", d.j(b, this.h));
        } 
        if (str4 != null && str5 != null) {
          int i = Integer.parseInt(str4);
          int j = Integer.parseInt(str5);
          if (j > 6) {
            paramg.o(i);
            byte[] arrayOfByte = new byte[6];
            if (paramg.read(arrayOfByte) == 6) {
              j -= 6;
              if (Arrays.equals(arrayOfByte, q0)) {
                arrayOfByte = new byte[j];
                if (paramg.read(arrayOfByte) == j) {
                  this.p = i + 6;
                  M(arrayOfByte, 0);
                } else {
                  throw new IOException("Can't read exif");
                } 
              } else {
                throw new IOException("Invalid identifier");
              } 
            } else {
              throw new IOException("Can't read identifier");
            } 
          } else {
            throw new IOException("Invalid exif length");
          } 
        } 
        if (v) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Heif meta: ");
          stringBuilder.append(str3);
          stringBuilder.append("x");
          stringBuilder.append(str1);
          stringBuilder.append(", rotation ");
          stringBuilder.append(str2);
          Log.d("ExifInterface", stringBuilder.toString());
        } 
        return;
      } catch (RuntimeException runtimeException) {
        throw new UnsupportedOperationException("Failed to read EXIF from HEIF file. Given stream is either malformed or unsupported.");
      } finally {
        mediaMetadataRetriever.release();
      } 
    } 
    throw new UnsupportedOperationException("Reading EXIF from HEIF files is supported from SDK 28 and above");
  }
  
  private void h(b paramb, int paramInt1, int paramInt2) {
    boolean bool = v;
    String str = "ExifInterface";
    if (bool) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("getJpegAttributes starting with: ");
      stringBuilder1.append(paramb);
      Log.d("ExifInterface", stringBuilder1.toString());
    } 
    paramb.h(ByteOrder.BIG_ENDIAN);
    int i = paramb.readByte();
    if (i == -1) {
      if (paramb.readByte() == -40) {
        i = 2;
        while (true) {
          int j = paramb.readByte();
          if (j == -1) {
            byte b1 = paramb.readByte();
            bool = v;
            if (bool) {
              StringBuilder stringBuilder3 = new StringBuilder();
              stringBuilder3.append("Found JPEG segment indicator: ");
              stringBuilder3.append(Integer.toHexString(b1 & 0xFF));
              Log.d(str, stringBuilder3.toString());
            } 
            if (b1 != -39) {
              if (b1 == -38)
                continue; 
              int k = paramb.readUnsignedShort() - 2;
              j = i + 1 + 1 + 2;
              if (bool) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("JPEG segment: ");
                stringBuilder3.append(Integer.toHexString(b1 & 0xFF));
                stringBuilder3.append(" (length: ");
                stringBuilder3.append(k + 2);
                stringBuilder3.append(")");
                Log.d(str, stringBuilder3.toString());
              } 
              if (k >= 0) {
                if (b1 != -31) {
                  if (b1 != -2) {
                    String str1;
                    HashMap<String, d> hashMap;
                    switch (b1) {
                      default:
                        switch (b1) {
                          default:
                            switch (b1) {
                              default:
                                switch (b1) {
                                  default:
                                    i = k;
                                    k = i;
                                    break;
                                  case -51:
                                  case -50:
                                  case -49:
                                    break;
                                } 
                                break;
                              case -55:
                              case -54:
                              case -53:
                                break;
                            } 
                            break;
                          case -59:
                          case -58:
                          case -57:
                            break;
                        } 
                      case -64:
                      case -63:
                      case -62:
                      case -61:
                        paramb.k(1);
                        hashMap = this.f[paramInt2];
                        if (paramInt2 != 4) {
                          str1 = "ImageLength";
                        } else {
                          str1 = "ThumbnailImageLength";
                        } 
                        hashMap.put(str1, d.f(paramb.readUnsignedShort(), this.h));
                        hashMap = this.f[paramInt2];
                        if (paramInt2 != 4) {
                          str1 = "ImageWidth";
                        } else {
                          str1 = "ThumbnailImageWidth";
                        } 
                        hashMap.put(str1, d.f(paramb.readUnsignedShort(), this.h));
                        i = k - 5;
                        k = i;
                        break;
                    } 
                  } else {
                    byte[] arrayOfByte = new byte[k];
                    if (paramb.read(arrayOfByte) == k) {
                      if (d("UserComment") == null)
                        this.f[1].put("UserComment", d.e(new String(arrayOfByte, p0))); 
                      i = j;
                    } else {
                      throw new IOException("Invalid exif");
                    } 
                    k = 0;
                    j = i;
                  } 
                } else {
                  byte[] arrayOfByte1 = new byte[k];
                  paramb.readFully(arrayOfByte1);
                  byte[] arrayOfByte2 = q0;
                  if (b.g(arrayOfByte1, arrayOfByte2)) {
                    arrayOfByte1 = Arrays.copyOfRange(arrayOfByte1, arrayOfByte2.length, k);
                    this.p = paramInt1 + j + arrayOfByte2.length;
                    M(arrayOfByte1, paramInt2);
                    W(new b(arrayOfByte1));
                  } else {
                    arrayOfByte2 = r0;
                    if (b.g(arrayOfByte1, arrayOfByte2)) {
                      int m = arrayOfByte2.length;
                      arrayOfByte1 = Arrays.copyOfRange(arrayOfByte1, arrayOfByte2.length, k);
                      if (d("Xmp") == null) {
                        this.f[0].put("Xmp", new d(1, arrayOfByte1.length, (j + m), arrayOfByte1));
                        this.u = true;
                      } 
                    } 
                  } 
                  i = j + k;
                  k = 0;
                  j = i;
                } 
                if (k >= 0) {
                  paramb.k(k);
                  i = j + k;
                  continue;
                } 
                throw new IOException("Invalid length");
              } 
              throw new IOException("Invalid length");
            } 
            paramb.h(this.h);
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Invalid marker:");
          stringBuilder2.append(Integer.toHexString(j & 0xFF));
          throw new IOException(stringBuilder2.toString());
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid marker: ");
      stringBuilder1.append(Integer.toHexString(i & 0xFF));
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid marker: ");
    stringBuilder.append(Integer.toHexString(i & 0xFF));
    throw new IOException(stringBuilder.toString());
  }
  
  private int i(BufferedInputStream paramBufferedInputStream) {
    paramBufferedInputStream.mark(5000);
    byte[] arrayOfByte = new byte[5000];
    paramBufferedInputStream.read(arrayOfByte);
    paramBufferedInputStream.reset();
    return y(arrayOfByte) ? 4 : (B(arrayOfByte) ? 9 : (x(arrayOfByte) ? 12 : (z(arrayOfByte) ? 7 : (C(arrayOfByte) ? 10 : (A(arrayOfByte) ? 13 : (H(arrayOfByte) ? 14 : 0))))));
  }
  
  private void j(g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial m : (Landroidx/exifinterface/media/a$g;)V
    //   5: aload_0
    //   6: getfield f : [Ljava/util/HashMap;
    //   9: iconst_1
    //   10: aaload
    //   11: ldc_w 'MakerNote'
    //   14: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: checkcast androidx/exifinterface/media/a$d
    //   20: astore_1
    //   21: aload_1
    //   22: ifnull -> 410
    //   25: new androidx/exifinterface/media/a$g
    //   28: dup
    //   29: aload_1
    //   30: getfield d : [B
    //   33: invokespecial <init> : ([B)V
    //   36: astore_1
    //   37: aload_1
    //   38: aload_0
    //   39: getfield h : Ljava/nio/ByteOrder;
    //   42: invokevirtual h : (Ljava/nio/ByteOrder;)V
    //   45: getstatic androidx/exifinterface/media/a.F : [B
    //   48: astore #8
    //   50: aload #8
    //   52: arraylength
    //   53: newarray byte
    //   55: astore #9
    //   57: aload_1
    //   58: aload #9
    //   60: invokevirtual readFully : ([B)V
    //   63: aload_1
    //   64: lconst_0
    //   65: invokevirtual o : (J)V
    //   68: getstatic androidx/exifinterface/media/a.G : [B
    //   71: astore #10
    //   73: aload #10
    //   75: arraylength
    //   76: newarray byte
    //   78: astore #11
    //   80: aload_1
    //   81: aload #11
    //   83: invokevirtual readFully : ([B)V
    //   86: aload #9
    //   88: aload #8
    //   90: invokestatic equals : ([B[B)Z
    //   93: ifeq -> 110
    //   96: ldc2_w 8
    //   99: lstore #6
    //   101: aload_1
    //   102: lload #6
    //   104: invokevirtual o : (J)V
    //   107: goto -> 128
    //   110: aload #11
    //   112: aload #10
    //   114: invokestatic equals : ([B[B)Z
    //   117: ifeq -> 128
    //   120: ldc2_w 12
    //   123: lstore #6
    //   125: goto -> 101
    //   128: aload_0
    //   129: aload_1
    //   130: bipush #6
    //   132: invokespecial N : (Landroidx/exifinterface/media/a$g;I)V
    //   135: aload_0
    //   136: getfield f : [Ljava/util/HashMap;
    //   139: bipush #7
    //   141: aaload
    //   142: ldc_w 'PreviewImageStart'
    //   145: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   148: checkcast androidx/exifinterface/media/a$d
    //   151: astore_1
    //   152: aload_0
    //   153: getfield f : [Ljava/util/HashMap;
    //   156: bipush #7
    //   158: aaload
    //   159: ldc_w 'PreviewImageLength'
    //   162: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   165: checkcast androidx/exifinterface/media/a$d
    //   168: astore #8
    //   170: aload_1
    //   171: ifnull -> 208
    //   174: aload #8
    //   176: ifnull -> 208
    //   179: aload_0
    //   180: getfield f : [Ljava/util/HashMap;
    //   183: iconst_5
    //   184: aaload
    //   185: ldc_w 'JPEGInterchangeFormat'
    //   188: aload_1
    //   189: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   192: pop
    //   193: aload_0
    //   194: getfield f : [Ljava/util/HashMap;
    //   197: iconst_5
    //   198: aaload
    //   199: ldc_w 'JPEGInterchangeFormatLength'
    //   202: aload #8
    //   204: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   207: pop
    //   208: aload_0
    //   209: getfield f : [Ljava/util/HashMap;
    //   212: bipush #8
    //   214: aaload
    //   215: ldc_w 'AspectFrame'
    //   218: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   221: checkcast androidx/exifinterface/media/a$d
    //   224: astore_1
    //   225: aload_1
    //   226: ifnull -> 410
    //   229: aload_1
    //   230: aload_0
    //   231: getfield h : Ljava/nio/ByteOrder;
    //   234: invokevirtual o : (Ljava/nio/ByteOrder;)Ljava/lang/Object;
    //   237: checkcast [I
    //   240: astore_1
    //   241: aload_1
    //   242: ifnull -> 371
    //   245: aload_1
    //   246: arraylength
    //   247: iconst_4
    //   248: if_icmpeq -> 254
    //   251: goto -> 371
    //   254: aload_1
    //   255: iconst_2
    //   256: iaload
    //   257: aload_1
    //   258: iconst_0
    //   259: iaload
    //   260: if_icmple -> 410
    //   263: aload_1
    //   264: iconst_3
    //   265: iaload
    //   266: aload_1
    //   267: iconst_1
    //   268: iaload
    //   269: if_icmple -> 410
    //   272: aload_1
    //   273: iconst_2
    //   274: iaload
    //   275: aload_1
    //   276: iconst_0
    //   277: iaload
    //   278: isub
    //   279: iconst_1
    //   280: iadd
    //   281: istore #5
    //   283: aload_1
    //   284: iconst_3
    //   285: iaload
    //   286: aload_1
    //   287: iconst_1
    //   288: iaload
    //   289: isub
    //   290: iconst_1
    //   291: iadd
    //   292: istore #4
    //   294: iload #5
    //   296: istore_3
    //   297: iload #4
    //   299: istore_2
    //   300: iload #5
    //   302: iload #4
    //   304: if_icmpge -> 322
    //   307: iload #5
    //   309: iload #4
    //   311: iadd
    //   312: istore_3
    //   313: iload_3
    //   314: iload #4
    //   316: isub
    //   317: istore_2
    //   318: iload_3
    //   319: iload_2
    //   320: isub
    //   321: istore_3
    //   322: iload_3
    //   323: aload_0
    //   324: getfield h : Ljava/nio/ByteOrder;
    //   327: invokestatic j : (ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   330: astore_1
    //   331: iload_2
    //   332: aload_0
    //   333: getfield h : Ljava/nio/ByteOrder;
    //   336: invokestatic j : (ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   339: astore #8
    //   341: aload_0
    //   342: getfield f : [Ljava/util/HashMap;
    //   345: iconst_0
    //   346: aaload
    //   347: ldc_w 'ImageWidth'
    //   350: aload_1
    //   351: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   354: pop
    //   355: aload_0
    //   356: getfield f : [Ljava/util/HashMap;
    //   359: iconst_0
    //   360: aaload
    //   361: ldc_w 'ImageLength'
    //   364: aload #8
    //   366: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   369: pop
    //   370: return
    //   371: new java/lang/StringBuilder
    //   374: dup
    //   375: invokespecial <init> : ()V
    //   378: astore #8
    //   380: aload #8
    //   382: ldc_w 'Invalid aspect frame values. frame='
    //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: pop
    //   389: aload #8
    //   391: aload_1
    //   392: invokestatic toString : ([I)Ljava/lang/String;
    //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   398: pop
    //   399: ldc 'ExifInterface'
    //   401: aload #8
    //   403: invokevirtual toString : ()Ljava/lang/String;
    //   406: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   409: pop
    //   410: return
  }
  
  private void k(b paramb) {
    if (v) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getPngAttributes starting with: ");
      stringBuilder.append(paramb);
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    paramb.h(ByteOrder.BIG_ENDIAN);
    byte[] arrayOfByte = H;
    paramb.k(arrayOfByte.length);
    int i = arrayOfByte.length + 0;
    try {
      while (true) {
        int j = paramb.readInt();
        arrayOfByte = new byte[4];
        if (paramb.read(arrayOfByte) == 4) {
          i = i + 4 + 4;
          if (i != 16 || Arrays.equals(arrayOfByte, J)) {
            StringBuilder stringBuilder;
            if (Arrays.equals(arrayOfByte, K))
              return; 
            if (Arrays.equals(arrayOfByte, I)) {
              StringBuilder stringBuilder1;
              byte[] arrayOfByte1 = new byte[j];
              if (paramb.read(arrayOfByte1) == j) {
                j = paramb.readInt();
                CRC32 cRC32 = new CRC32();
                cRC32.update(arrayOfByte);
                cRC32.update(arrayOfByte1);
                if ((int)cRC32.getValue() == j) {
                  this.p = i;
                  M(arrayOfByte1, 0);
                  a0();
                  W(new b(arrayOfByte1));
                  return;
                } 
                stringBuilder1 = new StringBuilder();
                stringBuilder1.append("Encountered invalid CRC value for PNG-EXIF chunk.\n recorded CRC value: ");
                stringBuilder1.append(j);
                stringBuilder1.append(", calculated CRC value: ");
                stringBuilder1.append(cRC32.getValue());
                throw new IOException(stringBuilder1.toString());
              } 
              stringBuilder = new StringBuilder();
              stringBuilder.append("Failed to read given length for given PNG chunk type: ");
              stringBuilder.append(b.a((byte[])stringBuilder1));
              throw new IOException(stringBuilder.toString());
            } 
            j += 4;
            stringBuilder.k(j);
            i += j;
            continue;
          } 
          throw new IOException("Encountered invalid PNG file--IHDR chunk should appearas the first chunk");
        } 
        throw new IOException("Encountered invalid length while parsing PNG chunktype");
      } 
    } catch (EOFException eOFException) {
      throw new IOException("Encountered corrupt PNG file.");
    } 
  }
  
  private void l(b paramb) {
    boolean bool = v;
    if (bool) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getRafAttributes starting with: ");
      stringBuilder.append(paramb);
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    paramb.k(84);
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    byte[] arrayOfByte3 = new byte[4];
    paramb.read(arrayOfByte1);
    paramb.read(arrayOfByte2);
    paramb.read(arrayOfByte3);
    int i = ByteBuffer.wrap(arrayOfByte1).getInt();
    int j = ByteBuffer.wrap(arrayOfByte2).getInt();
    int k = ByteBuffer.wrap(arrayOfByte3).getInt();
    arrayOfByte1 = new byte[j];
    paramb.k(i - paramb.a());
    paramb.read(arrayOfByte1);
    h(new b(arrayOfByte1), i, 5);
    paramb.k(k - paramb.a());
    paramb.h(ByteOrder.BIG_ENDIAN);
    j = paramb.readInt();
    if (bool) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("numberOfDirectoryEntry: ");
      stringBuilder.append(j);
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    for (i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      k = paramb.readUnsignedShort();
      int m = paramb.readUnsignedShort();
      if (k == e0.a) {
        i = paramb.readShort();
        j = paramb.readShort();
        d d1 = d.j(i, this.h);
        d d2 = d.j(j, this.h);
        this.f[0].put("ImageLength", d1);
        this.f[0].put("ImageWidth", d2);
        if (v) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Updated to length: ");
          stringBuilder.append(i);
          stringBuilder.append(", width: ");
          stringBuilder.append(j);
          Log.d("ExifInterface", stringBuilder.toString());
        } 
        return;
      } 
      stringBuilder.k(m);
    } 
  }
  
  private void m(g paramg) {
    J(paramg);
    N(paramg, 0);
    Z(paramg, 0);
    Z(paramg, 5);
    Z(paramg, 4);
    a0();
    if (this.d == 8) {
      d d = this.f[1].get("MakerNote");
      if (d != null) {
        g g1 = new g(d.d);
        g1.h(this.h);
        g1.k(6);
        N(g1, 9);
        d d1 = this.f[9].get("ColorSpace");
        if (d1 != null)
          this.f[1].put("ColorSpace", d1); 
      } 
    } 
  }
  
  private void n(g paramg) {
    if (v) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getRw2Attributes starting with: ");
      stringBuilder.append(paramg);
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    m(paramg);
    d d1 = this.f[0].get("JpgFromRaw");
    if (d1 != null)
      h(new b(d1.d), (int)d1.c, 5); 
    d1 = this.f[0].get("ISO");
    d d2 = this.f[1].get("PhotographicSensitivity");
    if (d1 != null && d2 == null)
      this.f[1].put("PhotographicSensitivity", d1); 
  }
  
  private void o(g paramg) {
    byte[] arrayOfByte1 = q0;
    paramg.k(arrayOfByte1.length);
    byte[] arrayOfByte2 = new byte[paramg.available()];
    paramg.readFully(arrayOfByte2);
    this.p = arrayOfByte1.length;
    M(arrayOfByte2, 0);
  }
  
  private void r(b paramb) {
    if (v) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getWebpAttributes starting with: ");
      stringBuilder.append(paramb);
      Log.d("ExifInterface", stringBuilder.toString());
    } 
    paramb.h(ByteOrder.LITTLE_ENDIAN);
    paramb.k(L.length);
    int j = paramb.readInt() + 8;
    byte[] arrayOfByte = M;
    paramb.k(arrayOfByte.length);
    int i = arrayOfByte.length + 8;
    while (true) {
      int m;
      try {
        arrayOfByte = new byte[4];
        if (paramb.read(arrayOfByte) == 4) {
          k = paramb.readInt();
          m = i + 4 + 4;
          if (Arrays.equals(N, arrayOfByte)) {
            byte[] arrayOfByte1 = new byte[k];
            if (paramb.read(arrayOfByte1) == k) {
              this.p = m;
              M(arrayOfByte1, 0);
              W(new b(arrayOfByte1));
              return;
            } 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to read given length for given PNG chunk type: ");
            stringBuilder.append(b.a(arrayOfByte));
            throw new IOException(stringBuilder.toString());
          } 
        } else {
          throw new IOException("Encountered invalid length while parsing WebP chunktype");
        } 
      } catch (EOFException eOFException) {
        throw new IOException("Encountered corrupt WebP file.");
      } 
      i = k;
      if (k % 2 == 1)
        i = k + 1; 
      int k = m + i;
      if (k == j)
        break; 
      if (k <= j) {
        eOFException.k(i);
        i = k;
        continue;
      } 
      throw new IOException("Encountered WebP file with invalid chunk size");
    } 
  }
  
  private static Pair<Integer, Integer> s(String paramString) {
    Pair<Integer, Integer> pair;
    long l1;
    long l2;
    boolean bool = paramString.contains(",");
    int i = 1;
    Integer integer1 = Integer.valueOf(2);
    Integer integer2 = Integer.valueOf(-1);
    if (bool) {
      String[] arrayOfString = paramString.split(",", -1);
      Pair<Integer, Integer> pair1 = s(arrayOfString[0]);
      pair = pair1;
      if (((Integer)pair1.first).intValue() == 2)
        return pair1; 
      while (i < arrayOfString.length) {
        byte b1;
        byte b2;
        pair1 = s(arrayOfString[i]);
        if (((Integer)pair1.first).equals(pair.first) || ((Integer)pair1.second).equals(pair.first)) {
          b1 = ((Integer)pair.first).intValue();
        } else {
          b1 = -1;
        } 
        if (((Integer)pair.second).intValue() != -1 && (((Integer)pair1.first).equals(pair.second) || ((Integer)pair1.second).equals(pair.second))) {
          b2 = ((Integer)pair.second).intValue();
        } else {
          b2 = -1;
        } 
        if (b1 == -1 && b2 == -1)
          return new Pair(integer1, integer2); 
        if (b1 == -1) {
          pair = new Pair(Integer.valueOf(b2), integer2);
        } else if (b2 == -1) {
          pair = new Pair(Integer.valueOf(b1), integer2);
        } 
        i++;
      } 
      return pair;
    } 
    if (pair.contains("/")) {
      String[] arrayOfString = pair.split("/", -1);
      if (arrayOfString.length == 2) {
        try {
          l1 = (long)Double.parseDouble(arrayOfString[0]);
          l2 = (long)Double.parseDouble(arrayOfString[1]);
          if (l1 < 0L || l2 < 0L)
            return new Pair(Integer.valueOf(10), integer2); 
        } catch (NumberFormatException numberFormatException) {
          return new Pair(integer1, integer2);
        } 
      } else {
        return new Pair(integer1, integer2);
      } 
    } else {
      try {
        Long long_ = Long.valueOf(Long.parseLong((String)numberFormatException));
        return (long_.longValue() >= 0L && long_.longValue() <= 65535L) ? new Pair(Integer.valueOf(3), Integer.valueOf(4)) : ((long_.longValue() < 0L) ? new Pair(Integer.valueOf(9), integer2) : new Pair(Integer.valueOf(4), integer2));
      } catch (NumberFormatException numberFormatException1) {
        try {
          Double.parseDouble((String)numberFormatException);
          return new Pair(Integer.valueOf(12), integer2);
        } catch (NumberFormatException numberFormatException2) {
          return new Pair(integer1, integer2);
        } 
      } 
    } 
    return (l1 > 2147483647L || l2 > 2147483647L) ? new Pair(Integer.valueOf(5), integer2) : new Pair(Integer.valueOf(10), Integer.valueOf(5));
  }
  
  private void t(b paramb, HashMap paramHashMap) {
    d d2 = (d)paramHashMap.get("JPEGInterchangeFormat");
    d d1 = (d)paramHashMap.get("JPEGInterchangeFormatLength");
    if (d2 != null && d1 != null) {
      int j = d2.m(this.h);
      int k = d1.m(this.h);
      int i = j;
      if (this.d == 7)
        i = j + this.q; 
      if (i > 0 && k > 0) {
        this.i = true;
        if (this.a == null && this.c == null && this.b == null) {
          byte[] arrayOfByte = new byte[k];
          paramb.skip(i);
          paramb.read(arrayOfByte);
          this.n = arrayOfByte;
        } 
        this.l = i;
        this.m = k;
      } 
      if (v) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Setting thumbnail attributes with offset: ");
        stringBuilder.append(i);
        stringBuilder.append(", length: ");
        stringBuilder.append(k);
        Log.d("ExifInterface", stringBuilder.toString());
      } 
    } 
  }
  
  private void u(b paramb, HashMap paramHashMap) {
    d d1 = (d)paramHashMap.get("StripOffsets");
    d d2 = (d)paramHashMap.get("StripByteCounts");
    if (d1 != null && d2 != null) {
      long[] arrayOfLong1 = b.d(d1.o(this.h));
      long[] arrayOfLong2 = b.d(d2.o(this.h));
      if (arrayOfLong1 == null || arrayOfLong1.length == 0) {
        Log.w("ExifInterface", "stripOffsets should not be null or have zero length.");
        return;
      } 
      if (arrayOfLong2 == null || arrayOfLong2.length == 0) {
        Log.w("ExifInterface", "stripByteCounts should not be null or have zero length.");
        return;
      } 
      if (arrayOfLong1.length != arrayOfLong2.length) {
        Log.w("ExifInterface", "stripOffsets and stripByteCounts should have same length.");
        return;
      } 
      long l = 0L;
      int j = arrayOfLong2.length;
      int i;
      for (i = 0; i < j; i++)
        l += arrayOfLong2[i]; 
      int m = (int)l;
      byte[] arrayOfByte = new byte[m];
      this.k = true;
      this.j = true;
      this.i = true;
      j = 0;
      int k = 0;
      i = 0;
      while (j < arrayOfLong1.length) {
        StringBuilder stringBuilder;
        int i1 = (int)arrayOfLong1[j];
        int n = (int)arrayOfLong2[j];
        if (j < arrayOfLong1.length - 1 && (i1 + n) != arrayOfLong1[j + 1])
          this.k = false; 
        i1 -= k;
        if (i1 < 0) {
          Log.d("ExifInterface", "Invalid strip offset value");
          return;
        } 
        l = i1;
        if (paramb.skip(l) != l) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to skip ");
          stringBuilder.append(i1);
          stringBuilder.append(" bytes.");
          Log.d("ExifInterface", stringBuilder.toString());
          return;
        } 
        byte[] arrayOfByte1 = new byte[n];
        if (stringBuilder.read(arrayOfByte1) != n) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to read ");
          stringBuilder.append(n);
          stringBuilder.append(" bytes.");
          Log.d("ExifInterface", stringBuilder.toString());
          return;
        } 
        k = k + i1 + n;
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, i, n);
        i += n;
        j++;
      } 
      this.n = arrayOfByte;
      if (this.k) {
        this.l = (int)arrayOfLong1[0];
        this.m = m;
        return;
      } 
    } 
  }
  
  private void v(String paramString) {
    Exception exception;
    Objects.requireNonNull(paramString, "filename cannot be null");
    String str = null;
    this.c = null;
    this.a = paramString;
    try {
      FileInputStream fileInputStream = new FileInputStream(paramString);
    } finally {
      exception = null;
    } 
    b.c((Closeable)paramString);
    throw exception;
  }
  
  private static boolean w(BufferedInputStream paramBufferedInputStream) {
    byte[] arrayOfByte = q0;
    paramBufferedInputStream.mark(arrayOfByte.length);
    arrayOfByte = new byte[arrayOfByte.length];
    paramBufferedInputStream.read(arrayOfByte);
    paramBufferedInputStream.reset();
    int i = 0;
    while (true) {
      byte[] arrayOfByte1 = q0;
      if (i < arrayOfByte1.length) {
        if (arrayOfByte[i] != arrayOfByte1[i])
          return false; 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  private boolean x(byte[] paramArrayOfbyte) {
    byte[] arrayOfByte2 = null;
    byte[] arrayOfByte1 = null;
    try {
      b b = new b(paramArrayOfbyte);
      try {
        long l1 = b.readInt();
        arrayOfByte1 = new byte[4];
        b.read(arrayOfByte1);
        boolean bool1 = Arrays.equals(arrayOfByte1, C);
        if (!bool1)
          return false; 
        long l2 = 16L;
        if (l1 == 1L) {
          long l = b.readLong();
          l1 = l;
          if (l < 16L)
            return false; 
        } else {
          l2 = 8L;
        } 
        long l3 = l1;
        if (l1 > paramArrayOfbyte.length) {
          int j = paramArrayOfbyte.length;
          l3 = j;
        } 
        l2 = l3 - l2;
        if (l2 < 8L)
          return false; 
        paramArrayOfbyte = new byte[4];
        l1 = 0L;
        int i = 0;
        for (boolean bool = false; l1 < l2 / 4L; bool = bool2) {
          boolean bool2;
          int j = b.read(paramArrayOfbyte);
          if (j != 4)
            return false; 
          if (l1 == 1L) {
            bool2 = bool;
          } else {
            if (Arrays.equals(paramArrayOfbyte, D)) {
              j = 1;
            } else {
              bool1 = Arrays.equals(paramArrayOfbyte, E);
              j = i;
              if (bool1) {
                bool = true;
                j = i;
              } 
            } 
            i = j;
            bool2 = bool;
            if (j != 0) {
              i = j;
              bool2 = bool;
              if (bool)
                return true; 
            } 
          } 
          l1++;
        } 
        return false;
      } catch (Exception exception1) {
        b b1 = b;
      } finally {
        Exception exception1;
        paramArrayOfbyte = null;
      } 
    } catch (Exception exception) {
      paramArrayOfbyte = arrayOfByte2;
    } finally {}
    arrayOfByte1 = paramArrayOfbyte;
    if (v) {
      arrayOfByte1 = paramArrayOfbyte;
      Log.d("ExifInterface", "Exception parsing HEIF file type box.", exception);
    } 
    if (paramArrayOfbyte != null)
      paramArrayOfbyte.close(); 
    return false;
  }
  
  private static boolean y(byte[] paramArrayOfbyte) {
    int i = 0;
    while (true) {
      byte[] arrayOfByte = B;
      if (i < arrayOfByte.length) {
        if (paramArrayOfbyte[i] != arrayOfByte[i])
          return false; 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  private boolean z(byte[] paramArrayOfbyte) {
    boolean bool = false;
    null = null;
    byte[] arrayOfByte = null;
    try {
    
    } catch (Exception exception) {
    
    } finally {
      paramArrayOfbyte = arrayOfByte;
      if (paramArrayOfbyte != null)
        paramArrayOfbyte.close(); 
    } 
    if (paramArrayOfbyte != null)
      paramArrayOfbyte.close(); 
    return false;
  }
  
  public void R() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : I
    //   4: invokestatic F : (I)Z
    //   7: ifeq -> 937
    //   10: aload_0
    //   11: getfield b : Ljava/io/FileDescriptor;
    //   14: ifnonnull -> 38
    //   17: aload_0
    //   18: getfield a : Ljava/lang/String;
    //   21: ifnull -> 27
    //   24: goto -> 38
    //   27: new java/io/IOException
    //   30: dup
    //   31: ldc_w 'ExifInterface does not support saving attributes for the current input.'
    //   34: invokespecial <init> : (Ljava/lang/String;)V
    //   37: athrow
    //   38: aload_0
    //   39: getfield i : Z
    //   42: ifeq -> 73
    //   45: aload_0
    //   46: getfield j : Z
    //   49: ifeq -> 73
    //   52: aload_0
    //   53: getfield k : Z
    //   56: ifeq -> 62
    //   59: goto -> 73
    //   62: new java/io/IOException
    //   65: dup
    //   66: ldc_w 'ExifInterface does not support saving attributes when the image file has non-consecutive thumbnail strips'
    //   69: invokespecial <init> : (Ljava/lang/String;)V
    //   72: athrow
    //   73: aload_0
    //   74: iconst_1
    //   75: putfield t : Z
    //   78: aload_0
    //   79: aload_0
    //   80: invokevirtual p : ()[B
    //   83: putfield n : [B
    //   86: aconst_null
    //   87: astore #7
    //   89: aconst_null
    //   90: astore #5
    //   92: aconst_null
    //   93: astore #6
    //   95: aconst_null
    //   96: astore #8
    //   98: ldc_w 'temp'
    //   101: ldc_w 'tmp'
    //   104: invokestatic createTempFile : (Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    //   107: astore #13
    //   109: aload_0
    //   110: getfield a : Ljava/lang/String;
    //   113: ifnull -> 136
    //   116: new java/io/FileInputStream
    //   119: dup
    //   120: aload_0
    //   121: getfield a : Ljava/lang/String;
    //   124: invokespecial <init> : (Ljava/lang/String;)V
    //   127: astore #9
    //   129: aload #9
    //   131: astore #5
    //   133: goto -> 179
    //   136: getstatic android/os/Build$VERSION.SDK_INT : I
    //   139: bipush #21
    //   141: if_icmplt -> 176
    //   144: aload_0
    //   145: getfield b : Ljava/io/FileDescriptor;
    //   148: lconst_0
    //   149: getstatic android/system/OsConstants.SEEK_SET : I
    //   152: invokestatic c : (Ljava/io/FileDescriptor;JI)J
    //   155: pop2
    //   156: new java/io/FileInputStream
    //   159: dup
    //   160: aload_0
    //   161: getfield b : Ljava/io/FileDescriptor;
    //   164: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   167: astore #9
    //   169: aload #9
    //   171: astore #5
    //   173: goto -> 179
    //   176: aconst_null
    //   177: astore #5
    //   179: new java/io/FileOutputStream
    //   182: dup
    //   183: aload #13
    //   185: invokespecial <init> : (Ljava/io/File;)V
    //   188: astore #6
    //   190: aload #5
    //   192: aload #6
    //   194: invokestatic e : (Ljava/io/InputStream;Ljava/io/OutputStream;)I
    //   197: pop
    //   198: aload #5
    //   200: invokestatic c : (Ljava/io/Closeable;)V
    //   203: aload #6
    //   205: invokestatic c : (Ljava/io/Closeable;)V
    //   208: iconst_0
    //   209: istore_3
    //   210: iconst_0
    //   211: istore_1
    //   212: iconst_0
    //   213: istore #4
    //   215: iconst_0
    //   216: istore_2
    //   217: new java/io/FileInputStream
    //   220: dup
    //   221: aload #13
    //   223: invokespecial <init> : (Ljava/io/File;)V
    //   226: astore #6
    //   228: aload_0
    //   229: getfield a : Ljava/lang/String;
    //   232: ifnull -> 251
    //   235: new java/io/FileOutputStream
    //   238: dup
    //   239: aload_0
    //   240: getfield a : Ljava/lang/String;
    //   243: invokespecial <init> : (Ljava/lang/String;)V
    //   246: astore #5
    //   248: goto -> 290
    //   251: getstatic android/os/Build$VERSION.SDK_INT : I
    //   254: bipush #21
    //   256: if_icmplt -> 287
    //   259: aload_0
    //   260: getfield b : Ljava/io/FileDescriptor;
    //   263: lconst_0
    //   264: getstatic android/system/OsConstants.SEEK_SET : I
    //   267: invokestatic c : (Ljava/io/FileDescriptor;JI)J
    //   270: pop2
    //   271: new java/io/FileOutputStream
    //   274: dup
    //   275: aload_0
    //   276: getfield b : Ljava/io/FileDescriptor;
    //   279: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   282: astore #5
    //   284: goto -> 290
    //   287: aconst_null
    //   288: astore #5
    //   290: new java/io/BufferedInputStream
    //   293: dup
    //   294: aload #6
    //   296: invokespecial <init> : (Ljava/io/InputStream;)V
    //   299: astore #8
    //   301: new java/io/BufferedOutputStream
    //   304: dup
    //   305: aload #5
    //   307: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   310: astore #7
    //   312: iload_3
    //   313: istore_1
    //   314: aload #8
    //   316: astore #10
    //   318: aload #7
    //   320: astore #11
    //   322: aload_0
    //   323: getfield d : I
    //   326: istore #4
    //   328: iload #4
    //   330: iconst_4
    //   331: if_icmpne -> 355
    //   334: iload_3
    //   335: istore_1
    //   336: aload #8
    //   338: astore #10
    //   340: aload #7
    //   342: astore #11
    //   344: aload_0
    //   345: aload #8
    //   347: aload #7
    //   349: invokespecial S : (Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   352: goto -> 408
    //   355: iload #4
    //   357: bipush #13
    //   359: if_icmpne -> 383
    //   362: iload_3
    //   363: istore_1
    //   364: aload #8
    //   366: astore #10
    //   368: aload #7
    //   370: astore #11
    //   372: aload_0
    //   373: aload #8
    //   375: aload #7
    //   377: invokespecial T : (Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   380: goto -> 408
    //   383: iload #4
    //   385: bipush #14
    //   387: if_icmpne -> 408
    //   390: iload_3
    //   391: istore_1
    //   392: aload #8
    //   394: astore #10
    //   396: aload #7
    //   398: astore #11
    //   400: aload_0
    //   401: aload #8
    //   403: aload #7
    //   405: invokespecial U : (Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   408: aload #8
    //   410: invokestatic c : (Ljava/io/Closeable;)V
    //   413: aload #7
    //   415: invokestatic c : (Ljava/io/Closeable;)V
    //   418: aload #13
    //   420: invokevirtual delete : ()Z
    //   423: pop
    //   424: aload_0
    //   425: aconst_null
    //   426: putfield n : [B
    //   429: return
    //   430: astore #9
    //   432: goto -> 502
    //   435: astore #5
    //   437: aconst_null
    //   438: astore #11
    //   440: goto -> 815
    //   443: astore #9
    //   445: aconst_null
    //   446: astore #7
    //   448: goto -> 502
    //   451: astore #9
    //   453: aconst_null
    //   454: astore #7
    //   456: aload #7
    //   458: astore #8
    //   460: goto -> 502
    //   463: astore #5
    //   465: goto -> 489
    //   468: astore #5
    //   470: aconst_null
    //   471: astore #11
    //   473: aload #7
    //   475: astore #6
    //   477: iload #4
    //   479: istore_1
    //   480: goto -> 819
    //   483: astore #5
    //   485: aload #8
    //   487: astore #6
    //   489: aconst_null
    //   490: astore #7
    //   492: aconst_null
    //   493: astore #8
    //   495: aload #5
    //   497: astore #9
    //   499: aconst_null
    //   500: astore #5
    //   502: new java/io/FileInputStream
    //   505: dup
    //   506: aload #13
    //   508: invokespecial <init> : (Ljava/io/File;)V
    //   511: astore #12
    //   513: aload #5
    //   515: astore #10
    //   517: aload #5
    //   519: astore #11
    //   521: aload_0
    //   522: getfield a : Ljava/lang/String;
    //   525: ifnonnull -> 592
    //   528: aload #5
    //   530: astore #6
    //   532: aload #5
    //   534: astore #10
    //   536: aload #5
    //   538: astore #11
    //   540: getstatic android/os/Build$VERSION.SDK_INT : I
    //   543: bipush #21
    //   545: if_icmplt -> 616
    //   548: aload #5
    //   550: astore #10
    //   552: aload #5
    //   554: astore #11
    //   556: aload_0
    //   557: getfield b : Ljava/io/FileDescriptor;
    //   560: lconst_0
    //   561: getstatic android/system/OsConstants.SEEK_SET : I
    //   564: invokestatic c : (Ljava/io/FileDescriptor;JI)J
    //   567: pop2
    //   568: aload #5
    //   570: astore #10
    //   572: aload #5
    //   574: astore #11
    //   576: new java/io/FileOutputStream
    //   579: dup
    //   580: aload_0
    //   581: getfield b : Ljava/io/FileDescriptor;
    //   584: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   587: astore #5
    //   589: goto -> 948
    //   592: aload #5
    //   594: astore #10
    //   596: aload #5
    //   598: astore #11
    //   600: new java/io/FileOutputStream
    //   603: dup
    //   604: aload_0
    //   605: getfield a : Ljava/lang/String;
    //   608: invokespecial <init> : (Ljava/lang/String;)V
    //   611: astore #5
    //   613: goto -> 948
    //   616: aload #6
    //   618: astore #10
    //   620: aload #6
    //   622: astore #11
    //   624: aload #12
    //   626: aload #6
    //   628: invokestatic e : (Ljava/io/InputStream;Ljava/io/OutputStream;)I
    //   631: pop
    //   632: iload_3
    //   633: istore_1
    //   634: aload #8
    //   636: astore #10
    //   638: aload #7
    //   640: astore #11
    //   642: aload #12
    //   644: invokestatic c : (Ljava/io/Closeable;)V
    //   647: iload_3
    //   648: istore_1
    //   649: aload #8
    //   651: astore #10
    //   653: aload #7
    //   655: astore #11
    //   657: aload #6
    //   659: invokestatic c : (Ljava/io/Closeable;)V
    //   662: iload_3
    //   663: istore_1
    //   664: aload #8
    //   666: astore #10
    //   668: aload #7
    //   670: astore #11
    //   672: new java/io/IOException
    //   675: dup
    //   676: ldc_w 'Failed to save new file'
    //   679: aload #9
    //   681: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   684: athrow
    //   685: astore #9
    //   687: aload #12
    //   689: astore #6
    //   691: aload #10
    //   693: astore #5
    //   695: goto -> 766
    //   698: astore #9
    //   700: aload #11
    //   702: astore #5
    //   704: aload #12
    //   706: astore #6
    //   708: goto -> 718
    //   711: astore #9
    //   713: goto -> 766
    //   716: astore #9
    //   718: new java/lang/StringBuilder
    //   721: dup
    //   722: invokespecial <init> : ()V
    //   725: astore #10
    //   727: aload #10
    //   729: ldc_w 'Failed to save new file. Original file is stored in '
    //   732: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   735: pop
    //   736: aload #10
    //   738: aload #13
    //   740: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   743: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   746: pop
    //   747: new java/io/IOException
    //   750: dup
    //   751: aload #10
    //   753: invokevirtual toString : ()Ljava/lang/String;
    //   756: aload #9
    //   758: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   761: athrow
    //   762: astore #9
    //   764: iconst_1
    //   765: istore_2
    //   766: iload_2
    //   767: istore_1
    //   768: aload #8
    //   770: astore #10
    //   772: aload #7
    //   774: astore #11
    //   776: aload #6
    //   778: invokestatic c : (Ljava/io/Closeable;)V
    //   781: iload_2
    //   782: istore_1
    //   783: aload #8
    //   785: astore #10
    //   787: aload #7
    //   789: astore #11
    //   791: aload #5
    //   793: invokestatic c : (Ljava/io/Closeable;)V
    //   796: iload_2
    //   797: istore_1
    //   798: aload #8
    //   800: astore #10
    //   802: aload #7
    //   804: astore #11
    //   806: aload #9
    //   808: athrow
    //   809: astore #5
    //   811: aload #10
    //   813: astore #8
    //   815: aload #8
    //   817: astore #6
    //   819: aload #6
    //   821: invokestatic c : (Ljava/io/Closeable;)V
    //   824: aload #11
    //   826: invokestatic c : (Ljava/io/Closeable;)V
    //   829: iload_1
    //   830: ifne -> 839
    //   833: aload #13
    //   835: invokevirtual delete : ()Z
    //   838: pop
    //   839: aload #5
    //   841: athrow
    //   842: astore #7
    //   844: goto -> 857
    //   847: astore #7
    //   849: goto -> 877
    //   852: astore #7
    //   854: aconst_null
    //   855: astore #6
    //   857: aload #5
    //   859: astore #8
    //   861: aload #7
    //   863: astore #5
    //   865: aload #8
    //   867: astore #7
    //   869: goto -> 924
    //   872: astore #7
    //   874: aconst_null
    //   875: astore #6
    //   877: goto -> 901
    //   880: astore #5
    //   882: aconst_null
    //   883: astore #8
    //   885: aload #6
    //   887: astore #7
    //   889: aload #8
    //   891: astore #6
    //   893: goto -> 924
    //   896: astore #7
    //   898: aconst_null
    //   899: astore #6
    //   901: new java/io/IOException
    //   904: dup
    //   905: ldc_w 'Failed to copy original file to temp file'
    //   908: aload #7
    //   910: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   913: athrow
    //   914: astore #8
    //   916: aload #5
    //   918: astore #7
    //   920: aload #8
    //   922: astore #5
    //   924: aload #7
    //   926: invokestatic c : (Ljava/io/Closeable;)V
    //   929: aload #6
    //   931: invokestatic c : (Ljava/io/Closeable;)V
    //   934: aload #5
    //   936: athrow
    //   937: new java/io/IOException
    //   940: dup
    //   941: ldc_w 'ExifInterface only supports saving attributes for JPEG, PNG, and WebP formats.'
    //   944: invokespecial <init> : (Ljava/lang/String;)V
    //   947: athrow
    //   948: aload #5
    //   950: astore #6
    //   952: goto -> 616
    // Exception table:
    //   from	to	target	type
    //   98	129	896	java/lang/Exception
    //   98	129	880	finally
    //   136	169	896	java/lang/Exception
    //   136	169	880	finally
    //   179	190	872	java/lang/Exception
    //   179	190	852	finally
    //   190	198	847	java/lang/Exception
    //   190	198	842	finally
    //   217	228	483	java/lang/Exception
    //   217	228	468	finally
    //   228	248	463	java/lang/Exception
    //   228	248	468	finally
    //   251	284	463	java/lang/Exception
    //   251	284	468	finally
    //   290	301	451	java/lang/Exception
    //   290	301	468	finally
    //   301	312	443	java/lang/Exception
    //   301	312	435	finally
    //   322	328	430	java/lang/Exception
    //   322	328	809	finally
    //   344	352	430	java/lang/Exception
    //   344	352	809	finally
    //   372	380	430	java/lang/Exception
    //   372	380	809	finally
    //   400	408	430	java/lang/Exception
    //   400	408	809	finally
    //   502	513	716	java/lang/Exception
    //   502	513	711	finally
    //   521	528	698	java/lang/Exception
    //   521	528	685	finally
    //   540	548	698	java/lang/Exception
    //   540	548	685	finally
    //   556	568	698	java/lang/Exception
    //   556	568	685	finally
    //   576	589	698	java/lang/Exception
    //   576	589	685	finally
    //   600	613	698	java/lang/Exception
    //   600	613	685	finally
    //   624	632	698	java/lang/Exception
    //   624	632	685	finally
    //   642	647	809	finally
    //   657	662	809	finally
    //   672	685	809	finally
    //   718	762	762	finally
    //   776	781	809	finally
    //   791	796	809	finally
    //   806	809	809	finally
    //   901	914	914	finally
  }
  
  public void V(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_1
    //   1: astore #8
    //   3: aload_2
    //   4: astore #7
    //   6: aload #8
    //   8: ldc_w 'tag shouldn't be null'
    //   11: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   14: pop
    //   15: ldc_w 'DateTime'
    //   18: aload #8
    //   20: invokevirtual equals : (Ljava/lang/Object;)Z
    //   23: ifne -> 51
    //   26: ldc_w 'DateTimeOriginal'
    //   29: aload #8
    //   31: invokevirtual equals : (Ljava/lang/Object;)Z
    //   34: ifne -> 51
    //   37: aload #7
    //   39: astore_1
    //   40: ldc_w 'DateTimeDigitized'
    //   43: aload #8
    //   45: invokevirtual equals : (Ljava/lang/Object;)Z
    //   48: ifeq -> 185
    //   51: aload #7
    //   53: astore_1
    //   54: aload #7
    //   56: ifnull -> 185
    //   59: getstatic androidx/exifinterface/media/a.u0 : Ljava/util/regex/Pattern;
    //   62: aload #7
    //   64: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   67: invokevirtual find : ()Z
    //   70: istore #5
    //   72: getstatic androidx/exifinterface/media/a.v0 : Ljava/util/regex/Pattern;
    //   75: aload #7
    //   77: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   80: invokevirtual find : ()Z
    //   83: istore #6
    //   85: aload_2
    //   86: invokevirtual length : ()I
    //   89: bipush #19
    //   91: if_icmpne -> 130
    //   94: iload #5
    //   96: ifne -> 107
    //   99: iload #6
    //   101: ifne -> 107
    //   104: goto -> 130
    //   107: aload #7
    //   109: astore_1
    //   110: iload #6
    //   112: ifeq -> 185
    //   115: aload #7
    //   117: ldc_w '-'
    //   120: ldc_w ':'
    //   123: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   126: astore_1
    //   127: goto -> 185
    //   130: new java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: astore_1
    //   138: aload #7
    //   140: astore_2
    //   141: aload #8
    //   143: astore #7
    //   145: aload_1
    //   146: ldc_w 'Invalid value for '
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: pop
    //   153: aload_1
    //   154: aload #7
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_1
    //   161: ldc_w ' : '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: aload_1
    //   169: aload_2
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: pop
    //   174: ldc 'ExifInterface'
    //   176: aload_1
    //   177: invokevirtual toString : ()Ljava/lang/String;
    //   180: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   183: pop
    //   184: return
    //   185: aload #8
    //   187: astore #7
    //   189: ldc_w 'ISOSpeedRatings'
    //   192: aload #8
    //   194: invokevirtual equals : (Ljava/lang/Object;)Z
    //   197: ifeq -> 220
    //   200: getstatic androidx/exifinterface/media/a.v : Z
    //   203: ifeq -> 215
    //   206: ldc 'ExifInterface'
    //   208: ldc_w 'setAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.'
    //   211: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   214: pop
    //   215: ldc_w 'PhotographicSensitivity'
    //   218: astore #7
    //   220: aload_1
    //   221: astore #8
    //   223: aload_1
    //   224: ifnull -> 400
    //   227: aload_1
    //   228: astore #8
    //   230: getstatic androidx/exifinterface/media/a.n0 : Ljava/util/HashSet;
    //   233: aload #7
    //   235: invokevirtual contains : (Ljava/lang/Object;)Z
    //   238: ifeq -> 400
    //   241: aload #7
    //   243: ldc_w 'GPSTimeStamp'
    //   246: invokevirtual equals : (Ljava/lang/Object;)Z
    //   249: ifeq -> 364
    //   252: getstatic androidx/exifinterface/media/a.t0 : Ljava/util/regex/Pattern;
    //   255: aload_1
    //   256: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   259: astore_2
    //   260: aload_2
    //   261: invokevirtual find : ()Z
    //   264: ifne -> 284
    //   267: new java/lang/StringBuilder
    //   270: dup
    //   271: invokespecial <init> : ()V
    //   274: astore #8
    //   276: aload_1
    //   277: astore_2
    //   278: aload #8
    //   280: astore_1
    //   281: goto -> 145
    //   284: new java/lang/StringBuilder
    //   287: dup
    //   288: invokespecial <init> : ()V
    //   291: astore_1
    //   292: aload_1
    //   293: aload_2
    //   294: iconst_1
    //   295: invokevirtual group : (I)Ljava/lang/String;
    //   298: invokestatic parseInt : (Ljava/lang/String;)I
    //   301: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   304: pop
    //   305: aload_1
    //   306: ldc_w '/1,'
    //   309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   312: pop
    //   313: aload_1
    //   314: aload_2
    //   315: iconst_2
    //   316: invokevirtual group : (I)Ljava/lang/String;
    //   319: invokestatic parseInt : (Ljava/lang/String;)I
    //   322: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   325: pop
    //   326: aload_1
    //   327: ldc_w '/1,'
    //   330: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: pop
    //   334: aload_1
    //   335: aload_2
    //   336: iconst_3
    //   337: invokevirtual group : (I)Ljava/lang/String;
    //   340: invokestatic parseInt : (Ljava/lang/String;)I
    //   343: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: aload_1
    //   348: ldc_w '/1'
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload_1
    //   356: invokevirtual toString : ()Ljava/lang/String;
    //   359: astore #8
    //   361: goto -> 400
    //   364: new androidx/exifinterface/media/a$f
    //   367: dup
    //   368: aload_1
    //   369: invokestatic parseDouble : (Ljava/lang/String;)D
    //   372: invokespecial <init> : (D)V
    //   375: invokevirtual toString : ()Ljava/lang/String;
    //   378: astore #8
    //   380: goto -> 400
    //   383: new java/lang/StringBuilder
    //   386: dup
    //   387: invokespecial <init> : ()V
    //   390: astore #8
    //   392: aload_1
    //   393: astore_2
    //   394: aload #8
    //   396: astore_1
    //   397: goto -> 145
    //   400: iconst_0
    //   401: istore #4
    //   403: iload #4
    //   405: getstatic androidx/exifinterface/media/a.j0 : [[Landroidx/exifinterface/media/a$e;
    //   408: arraylength
    //   409: if_icmpge -> 1418
    //   412: iload #4
    //   414: iconst_4
    //   415: if_icmpne -> 428
    //   418: aload_0
    //   419: getfield i : Z
    //   422: ifne -> 428
    //   425: goto -> 1409
    //   428: getstatic androidx/exifinterface/media/a.m0 : [Ljava/util/HashMap;
    //   431: iload #4
    //   433: aaload
    //   434: aload #7
    //   436: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   439: checkcast androidx/exifinterface/media/a$e
    //   442: astore_1
    //   443: aload_1
    //   444: ifnull -> 1409
    //   447: aload #8
    //   449: ifnonnull -> 468
    //   452: aload_0
    //   453: getfield f : [Ljava/util/HashMap;
    //   456: iload #4
    //   458: aaload
    //   459: aload #7
    //   461: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   464: pop
    //   465: goto -> 1409
    //   468: aload #8
    //   470: invokestatic s : (Ljava/lang/String;)Landroid/util/Pair;
    //   473: astore #10
    //   475: aload_1
    //   476: getfield c : I
    //   479: aload #10
    //   481: getfield first : Ljava/lang/Object;
    //   484: checkcast java/lang/Integer
    //   487: invokevirtual intValue : ()I
    //   490: if_icmpeq -> 833
    //   493: aload_1
    //   494: getfield c : I
    //   497: aload #10
    //   499: getfield second : Ljava/lang/Object;
    //   502: checkcast java/lang/Integer
    //   505: invokevirtual intValue : ()I
    //   508: if_icmpne -> 514
    //   511: goto -> 833
    //   514: aload_1
    //   515: getfield d : I
    //   518: istore_3
    //   519: iload_3
    //   520: iconst_m1
    //   521: if_icmpeq -> 565
    //   524: iload_3
    //   525: aload #10
    //   527: getfield first : Ljava/lang/Object;
    //   530: checkcast java/lang/Integer
    //   533: invokevirtual intValue : ()I
    //   536: if_icmpeq -> 557
    //   539: aload_1
    //   540: getfield d : I
    //   543: aload #10
    //   545: getfield second : Ljava/lang/Object;
    //   548: checkcast java/lang/Integer
    //   551: invokevirtual intValue : ()I
    //   554: if_icmpne -> 565
    //   557: aload_1
    //   558: getfield d : I
    //   561: istore_3
    //   562: goto -> 838
    //   565: aload_1
    //   566: getfield c : I
    //   569: istore_3
    //   570: iload_3
    //   571: iconst_1
    //   572: if_icmpeq -> 830
    //   575: iload_3
    //   576: bipush #7
    //   578: if_icmpeq -> 830
    //   581: iload_3
    //   582: iconst_2
    //   583: if_icmpne -> 589
    //   586: goto -> 830
    //   589: getstatic androidx/exifinterface/media/a.v : Z
    //   592: ifeq -> 1409
    //   595: new java/lang/StringBuilder
    //   598: dup
    //   599: invokespecial <init> : ()V
    //   602: astore #9
    //   604: aload #9
    //   606: ldc_w 'Given tag ('
    //   609: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   612: pop
    //   613: aload #9
    //   615: aload #7
    //   617: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   620: pop
    //   621: aload #9
    //   623: ldc_w ') value didn't match with one of expected formats: '
    //   626: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: getstatic androidx/exifinterface/media/a.W : [Ljava/lang/String;
    //   633: astore #11
    //   635: aload #9
    //   637: aload #11
    //   639: aload_1
    //   640: getfield c : I
    //   643: aaload
    //   644: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   647: pop
    //   648: aload_1
    //   649: getfield d : I
    //   652: istore_3
    //   653: ldc ''
    //   655: astore_2
    //   656: iload_3
    //   657: iconst_m1
    //   658: if_icmpne -> 667
    //   661: ldc ''
    //   663: astore_1
    //   664: goto -> 704
    //   667: new java/lang/StringBuilder
    //   670: dup
    //   671: invokespecial <init> : ()V
    //   674: astore #12
    //   676: aload #12
    //   678: ldc_w ', '
    //   681: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   684: pop
    //   685: aload #12
    //   687: aload #11
    //   689: aload_1
    //   690: getfield d : I
    //   693: aaload
    //   694: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   697: pop
    //   698: aload #12
    //   700: invokevirtual toString : ()Ljava/lang/String;
    //   703: astore_1
    //   704: aload #9
    //   706: aload_1
    //   707: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   710: pop
    //   711: aload #9
    //   713: ldc_w ' (guess: '
    //   716: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   719: pop
    //   720: aload #9
    //   722: aload #11
    //   724: aload #10
    //   726: getfield first : Ljava/lang/Object;
    //   729: checkcast java/lang/Integer
    //   732: invokevirtual intValue : ()I
    //   735: aaload
    //   736: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   739: pop
    //   740: aload #10
    //   742: getfield second : Ljava/lang/Object;
    //   745: checkcast java/lang/Integer
    //   748: invokevirtual intValue : ()I
    //   751: iconst_m1
    //   752: if_icmpne -> 760
    //   755: aload_2
    //   756: astore_1
    //   757: goto -> 800
    //   760: new java/lang/StringBuilder
    //   763: dup
    //   764: invokespecial <init> : ()V
    //   767: astore_1
    //   768: aload_1
    //   769: ldc_w ', '
    //   772: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   775: pop
    //   776: aload_1
    //   777: aload #11
    //   779: aload #10
    //   781: getfield second : Ljava/lang/Object;
    //   784: checkcast java/lang/Integer
    //   787: invokevirtual intValue : ()I
    //   790: aaload
    //   791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   794: pop
    //   795: aload_1
    //   796: invokevirtual toString : ()Ljava/lang/String;
    //   799: astore_1
    //   800: aload #9
    //   802: aload_1
    //   803: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   806: pop
    //   807: aload #9
    //   809: ldc_w ')'
    //   812: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   815: pop
    //   816: ldc 'ExifInterface'
    //   818: aload #9
    //   820: invokevirtual toString : ()Ljava/lang/String;
    //   823: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   826: pop
    //   827: goto -> 1409
    //   830: goto -> 838
    //   833: aload_1
    //   834: getfield c : I
    //   837: istore_3
    //   838: iload_3
    //   839: tableswitch default -> 900, 1 -> 1384, 2 -> 1367, 3 -> 1308, 4 -> 1249, 5 -> 1160, 6 -> 900, 7 -> 1367, 8 -> 900, 9 -> 1093, 10 -> 1004, 11 -> 900, 12 -> 941
    //   900: getstatic androidx/exifinterface/media/a.v : Z
    //   903: ifeq -> 1409
    //   906: new java/lang/StringBuilder
    //   909: dup
    //   910: invokespecial <init> : ()V
    //   913: astore_1
    //   914: aload_1
    //   915: ldc_w 'Data format isn't one of expected formats: '
    //   918: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   921: pop
    //   922: aload_1
    //   923: iload_3
    //   924: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   927: pop
    //   928: ldc 'ExifInterface'
    //   930: aload_1
    //   931: invokevirtual toString : ()Ljava/lang/String;
    //   934: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   937: pop
    //   938: goto -> 1409
    //   941: aload #8
    //   943: ldc_w ','
    //   946: iconst_m1
    //   947: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   950: astore_1
    //   951: aload_1
    //   952: arraylength
    //   953: newarray double
    //   955: astore_2
    //   956: iconst_0
    //   957: istore_3
    //   958: iload_3
    //   959: aload_1
    //   960: arraylength
    //   961: if_icmpge -> 980
    //   964: aload_2
    //   965: iload_3
    //   966: aload_1
    //   967: iload_3
    //   968: aaload
    //   969: invokestatic parseDouble : (Ljava/lang/String;)D
    //   972: dastore
    //   973: iload_3
    //   974: iconst_1
    //   975: iadd
    //   976: istore_3
    //   977: goto -> 958
    //   980: aload_0
    //   981: getfield f : [Ljava/util/HashMap;
    //   984: iload #4
    //   986: aaload
    //   987: aload #7
    //   989: aload_2
    //   990: aload_0
    //   991: getfield h : Ljava/nio/ByteOrder;
    //   994: invokestatic b : ([DLjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   997: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1000: pop
    //   1001: goto -> 1409
    //   1004: aload #8
    //   1006: ldc_w ','
    //   1009: iconst_m1
    //   1010: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1013: astore_1
    //   1014: aload_1
    //   1015: arraylength
    //   1016: anewarray androidx/exifinterface/media/a$f
    //   1019: astore_2
    //   1020: iconst_0
    //   1021: istore_3
    //   1022: iload_3
    //   1023: aload_1
    //   1024: arraylength
    //   1025: if_icmpge -> 1073
    //   1028: aload_1
    //   1029: iload_3
    //   1030: aaload
    //   1031: ldc_w '/'
    //   1034: iconst_m1
    //   1035: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1038: astore #9
    //   1040: aload_2
    //   1041: iload_3
    //   1042: new androidx/exifinterface/media/a$f
    //   1045: dup
    //   1046: aload #9
    //   1048: iconst_0
    //   1049: aaload
    //   1050: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1053: d2l
    //   1054: aload #9
    //   1056: iconst_1
    //   1057: aaload
    //   1058: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1061: d2l
    //   1062: invokespecial <init> : (JJ)V
    //   1065: aastore
    //   1066: iload_3
    //   1067: iconst_1
    //   1068: iadd
    //   1069: istore_3
    //   1070: goto -> 1022
    //   1073: aload_0
    //   1074: getfield f : [Ljava/util/HashMap;
    //   1077: iload #4
    //   1079: aaload
    //   1080: astore_1
    //   1081: aload_2
    //   1082: aload_0
    //   1083: getfield h : Ljava/nio/ByteOrder;
    //   1086: invokestatic d : ([Landroidx/exifinterface/media/a$f;Ljava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   1089: astore_2
    //   1090: goto -> 1149
    //   1093: aload #8
    //   1095: ldc_w ','
    //   1098: iconst_m1
    //   1099: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1102: astore_1
    //   1103: aload_1
    //   1104: arraylength
    //   1105: newarray int
    //   1107: astore_2
    //   1108: iconst_0
    //   1109: istore_3
    //   1110: iload_3
    //   1111: aload_1
    //   1112: arraylength
    //   1113: if_icmpge -> 1132
    //   1116: aload_2
    //   1117: iload_3
    //   1118: aload_1
    //   1119: iload_3
    //   1120: aaload
    //   1121: invokestatic parseInt : (Ljava/lang/String;)I
    //   1124: iastore
    //   1125: iload_3
    //   1126: iconst_1
    //   1127: iadd
    //   1128: istore_3
    //   1129: goto -> 1110
    //   1132: aload_0
    //   1133: getfield f : [Ljava/util/HashMap;
    //   1136: iload #4
    //   1138: aaload
    //   1139: astore_1
    //   1140: aload_2
    //   1141: aload_0
    //   1142: getfield h : Ljava/nio/ByteOrder;
    //   1145: invokestatic c : ([ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   1148: astore_2
    //   1149: aload_1
    //   1150: aload #7
    //   1152: aload_2
    //   1153: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1156: pop
    //   1157: goto -> 1409
    //   1160: aload #8
    //   1162: ldc_w ','
    //   1165: iconst_m1
    //   1166: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1169: astore_1
    //   1170: aload_1
    //   1171: arraylength
    //   1172: anewarray androidx/exifinterface/media/a$f
    //   1175: astore_2
    //   1176: iconst_0
    //   1177: istore_3
    //   1178: iload_3
    //   1179: aload_1
    //   1180: arraylength
    //   1181: if_icmpge -> 1229
    //   1184: aload_1
    //   1185: iload_3
    //   1186: aaload
    //   1187: ldc_w '/'
    //   1190: iconst_m1
    //   1191: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1194: astore #9
    //   1196: aload_2
    //   1197: iload_3
    //   1198: new androidx/exifinterface/media/a$f
    //   1201: dup
    //   1202: aload #9
    //   1204: iconst_0
    //   1205: aaload
    //   1206: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1209: d2l
    //   1210: aload #9
    //   1212: iconst_1
    //   1213: aaload
    //   1214: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1217: d2l
    //   1218: invokespecial <init> : (JJ)V
    //   1221: aastore
    //   1222: iload_3
    //   1223: iconst_1
    //   1224: iadd
    //   1225: istore_3
    //   1226: goto -> 1178
    //   1229: aload_0
    //   1230: getfield f : [Ljava/util/HashMap;
    //   1233: iload #4
    //   1235: aaload
    //   1236: astore_1
    //   1237: aload_2
    //   1238: aload_0
    //   1239: getfield h : Ljava/nio/ByteOrder;
    //   1242: invokestatic i : ([Landroidx/exifinterface/media/a$f;Ljava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   1245: astore_2
    //   1246: goto -> 1398
    //   1249: aload #8
    //   1251: ldc_w ','
    //   1254: iconst_m1
    //   1255: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1258: astore_1
    //   1259: aload_1
    //   1260: arraylength
    //   1261: newarray long
    //   1263: astore_2
    //   1264: iconst_0
    //   1265: istore_3
    //   1266: iload_3
    //   1267: aload_1
    //   1268: arraylength
    //   1269: if_icmpge -> 1288
    //   1272: aload_2
    //   1273: iload_3
    //   1274: aload_1
    //   1275: iload_3
    //   1276: aaload
    //   1277: invokestatic parseLong : (Ljava/lang/String;)J
    //   1280: lastore
    //   1281: iload_3
    //   1282: iconst_1
    //   1283: iadd
    //   1284: istore_3
    //   1285: goto -> 1266
    //   1288: aload_0
    //   1289: getfield f : [Ljava/util/HashMap;
    //   1292: iload #4
    //   1294: aaload
    //   1295: astore_1
    //   1296: aload_2
    //   1297: aload_0
    //   1298: getfield h : Ljava/nio/ByteOrder;
    //   1301: invokestatic g : ([JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   1304: astore_2
    //   1305: goto -> 1398
    //   1308: aload #8
    //   1310: ldc_w ','
    //   1313: iconst_m1
    //   1314: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1317: astore_1
    //   1318: aload_1
    //   1319: arraylength
    //   1320: newarray int
    //   1322: astore_2
    //   1323: iconst_0
    //   1324: istore_3
    //   1325: iload_3
    //   1326: aload_1
    //   1327: arraylength
    //   1328: if_icmpge -> 1347
    //   1331: aload_2
    //   1332: iload_3
    //   1333: aload_1
    //   1334: iload_3
    //   1335: aaload
    //   1336: invokestatic parseInt : (Ljava/lang/String;)I
    //   1339: iastore
    //   1340: iload_3
    //   1341: iconst_1
    //   1342: iadd
    //   1343: istore_3
    //   1344: goto -> 1325
    //   1347: aload_0
    //   1348: getfield f : [Ljava/util/HashMap;
    //   1351: iload #4
    //   1353: aaload
    //   1354: astore_1
    //   1355: aload_2
    //   1356: aload_0
    //   1357: getfield h : Ljava/nio/ByteOrder;
    //   1360: invokestatic k : ([ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/a$d;
    //   1363: astore_2
    //   1364: goto -> 1398
    //   1367: aload_0
    //   1368: getfield f : [Ljava/util/HashMap;
    //   1371: iload #4
    //   1373: aaload
    //   1374: astore_1
    //   1375: aload #8
    //   1377: invokestatic e : (Ljava/lang/String;)Landroidx/exifinterface/media/a$d;
    //   1380: astore_2
    //   1381: goto -> 1398
    //   1384: aload_0
    //   1385: getfield f : [Ljava/util/HashMap;
    //   1388: iload #4
    //   1390: aaload
    //   1391: astore_1
    //   1392: aload #8
    //   1394: invokestatic a : (Ljava/lang/String;)Landroidx/exifinterface/media/a$d;
    //   1397: astore_2
    //   1398: aload_1
    //   1399: aload #7
    //   1401: aload_2
    //   1402: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1405: pop
    //   1406: goto -> 1409
    //   1409: iload #4
    //   1411: iconst_1
    //   1412: iadd
    //   1413: istore #4
    //   1415: goto -> 403
    //   1418: return
    //   1419: astore_2
    //   1420: goto -> 383
    // Exception table:
    //   from	to	target	type
    //   364	380	1419	java/lang/NumberFormatException
  }
  
  public String d(String paramString) {
    Objects.requireNonNull(paramString, "tag shouldn't be null");
    d d = f(paramString);
    if (d != null) {
      StringBuilder stringBuilder;
      if (!n0.contains(paramString))
        return d.n(this.h); 
      if (paramString.equals("GPSTimeStamp")) {
        String str;
        int i = d.a;
        if (i != 5 && i != 10) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("GPS Timestamp format is not rational. format=");
          stringBuilder1.append(d.a);
          str = stringBuilder1.toString();
          Log.w("ExifInterface", str);
          return null;
        } 
        f[] arrayOfF = (f[])d.o(this.h);
        if (arrayOfF == null || arrayOfF.length != 3) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid GPS Timestamp array. array=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfF));
          str = stringBuilder.toString();
          Log.w("ExifInterface", str);
          return null;
        } 
        return String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf((int)((float)((f)str[0]).a / (float)((f)str[0]).b)), Integer.valueOf((int)((float)((f)str[1]).a / (float)((f)str[1]).b)), Integer.valueOf((int)((float)((f)str[2]).a / (float)((f)str[2]).b)) });
      } 
      try {
        return Double.toString(stringBuilder.l(this.h));
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
    } 
    return null;
  }
  
  public int e(String paramString, int paramInt) {
    Objects.requireNonNull(paramString, "tag shouldn't be null");
    d d = f(paramString);
    if (d == null)
      return paramInt; 
    try {
      return d.m(this.h);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public byte[] p() {
    int i = this.o;
    return (i == 6 || i == 7) ? q() : null;
  }
  
  public byte[] q() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Z
    //   4: istore_3
    //   5: aconst_null
    //   6: astore #8
    //   8: iload_3
    //   9: ifne -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload_0
    //   15: getfield n : [B
    //   18: astore #6
    //   20: aload #6
    //   22: ifnull -> 28
    //   25: aload #6
    //   27: areturn
    //   28: aload_0
    //   29: getfield c : Landroid/content/res/AssetManager$AssetInputStream;
    //   32: astore #6
    //   34: aload #6
    //   36: ifnull -> 87
    //   39: aload #6
    //   41: invokevirtual markSupported : ()Z
    //   44: ifeq -> 55
    //   47: aload #6
    //   49: invokevirtual reset : ()V
    //   52: goto -> 462
    //   55: ldc 'ExifInterface'
    //   57: ldc_w 'Cannot read thumbnail from inputstream without mark/reset support'
    //   60: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   63: pop
    //   64: aload #6
    //   66: invokestatic c : (Ljava/io/Closeable;)V
    //   69: aconst_null
    //   70: areturn
    //   71: astore #7
    //   73: aconst_null
    //   74: astore #10
    //   76: goto -> 444
    //   79: astore #8
    //   81: aconst_null
    //   82: astore #7
    //   84: goto -> 402
    //   87: aload_0
    //   88: getfield a : Ljava/lang/String;
    //   91: ifnull -> 110
    //   94: new java/io/FileInputStream
    //   97: dup
    //   98: aload_0
    //   99: getfield a : Ljava/lang/String;
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: astore #6
    //   107: goto -> 462
    //   110: getstatic android/os/Build$VERSION.SDK_INT : I
    //   113: bipush #21
    //   115: if_icmplt -> 184
    //   118: aload_0
    //   119: getfield b : Ljava/io/FileDescriptor;
    //   122: invokestatic b : (Ljava/io/FileDescriptor;)Ljava/io/FileDescriptor;
    //   125: astore #6
    //   127: aload #6
    //   129: lconst_0
    //   130: getstatic android/system/OsConstants.SEEK_SET : I
    //   133: invokestatic c : (Ljava/io/FileDescriptor;JI)J
    //   136: pop2
    //   137: new java/io/FileInputStream
    //   140: dup
    //   141: aload #6
    //   143: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   146: astore #9
    //   148: aload #6
    //   150: astore #7
    //   152: aload #9
    //   154: astore #6
    //   156: goto -> 191
    //   159: astore #7
    //   161: aload #6
    //   163: astore #10
    //   165: aload #8
    //   167: astore #6
    //   169: goto -> 444
    //   172: astore #8
    //   174: aload #6
    //   176: astore #7
    //   178: aconst_null
    //   179: astore #6
    //   181: goto -> 402
    //   184: aconst_null
    //   185: astore #6
    //   187: aload #6
    //   189: astore #7
    //   191: aload #6
    //   193: ifnull -> 365
    //   196: aload #6
    //   198: astore #9
    //   200: aload #7
    //   202: astore #10
    //   204: aload #6
    //   206: aload_0
    //   207: getfield l : I
    //   210: aload_0
    //   211: getfield p : I
    //   214: iadd
    //   215: i2l
    //   216: invokevirtual skip : (J)J
    //   219: lstore #4
    //   221: aload #6
    //   223: astore #9
    //   225: aload #7
    //   227: astore #10
    //   229: aload_0
    //   230: getfield l : I
    //   233: istore_1
    //   234: aload #6
    //   236: astore #9
    //   238: aload #7
    //   240: astore #10
    //   242: aload_0
    //   243: getfield p : I
    //   246: istore_2
    //   247: lload #4
    //   249: iload_1
    //   250: iload_2
    //   251: iadd
    //   252: i2l
    //   253: lcmp
    //   254: ifne -> 346
    //   257: aload #6
    //   259: astore #9
    //   261: aload #7
    //   263: astore #10
    //   265: aload_0
    //   266: getfield m : I
    //   269: newarray byte
    //   271: astore #8
    //   273: aload #6
    //   275: astore #9
    //   277: aload #7
    //   279: astore #10
    //   281: aload #6
    //   283: aload #8
    //   285: invokevirtual read : ([B)I
    //   288: aload_0
    //   289: getfield m : I
    //   292: if_icmpne -> 327
    //   295: aload #6
    //   297: astore #9
    //   299: aload #7
    //   301: astore #10
    //   303: aload_0
    //   304: aload #8
    //   306: putfield n : [B
    //   309: aload #6
    //   311: invokestatic c : (Ljava/io/Closeable;)V
    //   314: aload #7
    //   316: ifnull -> 324
    //   319: aload #7
    //   321: invokestatic b : (Ljava/io/FileDescriptor;)V
    //   324: aload #8
    //   326: areturn
    //   327: aload #6
    //   329: astore #9
    //   331: aload #7
    //   333: astore #10
    //   335: new java/io/IOException
    //   338: dup
    //   339: ldc_w 'Corrupted image'
    //   342: invokespecial <init> : (Ljava/lang/String;)V
    //   345: athrow
    //   346: aload #6
    //   348: astore #9
    //   350: aload #7
    //   352: astore #10
    //   354: new java/io/IOException
    //   357: dup
    //   358: ldc_w 'Corrupted image'
    //   361: invokespecial <init> : (Ljava/lang/String;)V
    //   364: athrow
    //   365: aload #6
    //   367: astore #9
    //   369: aload #7
    //   371: astore #10
    //   373: new java/io/FileNotFoundException
    //   376: dup
    //   377: invokespecial <init> : ()V
    //   380: athrow
    //   381: astore #7
    //   383: aconst_null
    //   384: astore #10
    //   386: aload #8
    //   388: astore #6
    //   390: goto -> 444
    //   393: astore #8
    //   395: aconst_null
    //   396: astore #6
    //   398: aload #6
    //   400: astore #7
    //   402: aload #6
    //   404: astore #9
    //   406: aload #7
    //   408: astore #10
    //   410: ldc 'ExifInterface'
    //   412: ldc_w 'Encountered exception while getting thumbnail'
    //   415: aload #8
    //   417: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   420: pop
    //   421: aload #6
    //   423: invokestatic c : (Ljava/io/Closeable;)V
    //   426: aload #7
    //   428: ifnull -> 436
    //   431: aload #7
    //   433: invokestatic b : (Ljava/io/FileDescriptor;)V
    //   436: aconst_null
    //   437: areturn
    //   438: astore #7
    //   440: aload #9
    //   442: astore #6
    //   444: aload #6
    //   446: invokestatic c : (Ljava/io/Closeable;)V
    //   449: aload #10
    //   451: ifnull -> 459
    //   454: aload #10
    //   456: invokestatic b : (Ljava/io/FileDescriptor;)V
    //   459: aload #7
    //   461: athrow
    //   462: aconst_null
    //   463: astore #7
    //   465: goto -> 191
    //   468: astore #8
    //   470: goto -> 402
    // Exception table:
    //   from	to	target	type
    //   28	34	393	java/lang/Exception
    //   28	34	381	finally
    //   39	52	79	java/lang/Exception
    //   39	52	71	finally
    //   55	64	79	java/lang/Exception
    //   55	64	71	finally
    //   87	107	393	java/lang/Exception
    //   87	107	381	finally
    //   110	127	393	java/lang/Exception
    //   110	127	381	finally
    //   127	148	172	java/lang/Exception
    //   127	148	159	finally
    //   204	221	468	java/lang/Exception
    //   204	221	438	finally
    //   229	234	468	java/lang/Exception
    //   229	234	438	finally
    //   242	247	468	java/lang/Exception
    //   242	247	438	finally
    //   265	273	468	java/lang/Exception
    //   265	273	438	finally
    //   281	295	468	java/lang/Exception
    //   281	295	438	finally
    //   303	309	468	java/lang/Exception
    //   303	309	438	finally
    //   335	346	468	java/lang/Exception
    //   335	346	438	finally
    //   354	365	468	java/lang/Exception
    //   354	365	438	finally
    //   373	381	468	java/lang/Exception
    //   373	381	438	finally
    //   410	421	438	finally
  }
  
  static {
    Integer integer1 = Integer.valueOf(3);
  }
  
  static {
    Integer integer2 = Integer.valueOf(1);
    Integer integer3 = Integer.valueOf(2);
    Integer integer4 = Integer.valueOf(8);
    w = Arrays.asList(new Integer[] { integer2, Integer.valueOf(6), integer1, integer4 });
    Integer integer5 = Integer.valueOf(7);
    Integer integer6 = Integer.valueOf(5);
    x = Arrays.asList(new Integer[] { integer3, integer5, Integer.valueOf(4), integer6 });
  }
  
  class a extends MediaDataSource {
    long a;
    
    a(a this$0, a.g param1g) {}
    
    public void close() {}
    
    public long getSize() {
      return -1L;
    }
    
    public int readAt(long param1Long, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        return 0; 
      if (param1Long < 0L)
        return -1; 
      try {
        long l = this.a;
        if (l != param1Long) {
          if (l >= 0L && param1Long >= l + this.b.available())
            return -1; 
          this.b.o(param1Long);
          this.a = param1Long;
        } 
        int i = param1Int2;
        if (param1Int2 > this.b.available())
          i = this.b.available(); 
        param1Int1 = this.b.read(param1ArrayOfbyte, param1Int1, i);
        if (param1Int1 >= 0) {
          this.a += param1Int1;
          return param1Int1;
        } 
      } catch (IOException iOException) {}
      this.a = -1L;
      return -1;
    }
  }
  
  private static class b extends InputStream implements DataInput {
    private static final ByteOrder e = ByteOrder.LITTLE_ENDIAN;
    
    private static final ByteOrder f = ByteOrder.BIG_ENDIAN;
    
    final DataInputStream a;
    
    private ByteOrder b = ByteOrder.BIG_ENDIAN;
    
    int c;
    
    private byte[] d;
    
    b(InputStream param1InputStream) {
      this(param1InputStream, ByteOrder.BIG_ENDIAN);
    }
    
    b(InputStream param1InputStream, ByteOrder param1ByteOrder) {
      param1InputStream = new DataInputStream(param1InputStream);
      this.a = (DataInputStream)param1InputStream;
      param1InputStream.mark(0);
      this.c = 0;
      this.b = param1ByteOrder;
    }
    
    b(byte[] param1ArrayOfbyte) {
      this(new ByteArrayInputStream(param1ArrayOfbyte), ByteOrder.BIG_ENDIAN);
    }
    
    public int a() {
      return this.c;
    }
    
    public int available() {
      return this.a.available();
    }
    
    public long g() {
      return readInt() & 0xFFFFFFFFL;
    }
    
    public void h(ByteOrder param1ByteOrder) {
      this.b = param1ByteOrder;
    }
    
    public void k(int param1Int) {
      int i;
      for (i = 0; i < param1Int; i += j) {
        DataInputStream dataInputStream = this.a;
        int m = param1Int - i;
        int k = (int)dataInputStream.skip(m);
        int j = k;
        if (k <= 0) {
          if (this.d == null)
            this.d = new byte[8192]; 
          j = Math.min(8192, m);
          j = this.a.read(this.d, 0, j);
          if (j == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Reached EOF while skipping ");
            stringBuilder.append(param1Int);
            stringBuilder.append(" bytes.");
            throw new EOFException(stringBuilder.toString());
          } 
        } 
      } 
      this.c += i;
    }
    
    public void mark(int param1Int) {
      throw new UnsupportedOperationException("Mark is currently unsupported");
    }
    
    public int read() {
      this.c++;
      return this.a.read();
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      param1Int1 = this.a.read(param1ArrayOfbyte, param1Int1, param1Int2);
      this.c += param1Int1;
      return param1Int1;
    }
    
    public boolean readBoolean() {
      this.c++;
      return this.a.readBoolean();
    }
    
    public byte readByte() {
      this.c++;
      int i = this.a.read();
      if (i >= 0)
        return (byte)i; 
      throw new EOFException();
    }
    
    public char readChar() {
      this.c += 2;
      return this.a.readChar();
    }
    
    public double readDouble() {
      return Double.longBitsToDouble(readLong());
    }
    
    public float readFloat() {
      return Float.intBitsToFloat(readInt());
    }
    
    public void readFully(byte[] param1ArrayOfbyte) {
      this.c += param1ArrayOfbyte.length;
      this.a.readFully(param1ArrayOfbyte);
    }
    
    public void readFully(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      this.c += param1Int2;
      this.a.readFully(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public int readInt() {
      this.c += 4;
      int i = this.a.read();
      int j = this.a.read();
      int k = this.a.read();
      int m = this.a.read();
      if ((i | j | k | m) >= 0) {
        ByteOrder byteOrder = this.b;
        if (byteOrder == e)
          return (m << 24) + (k << 16) + (j << 8) + i; 
        if (byteOrder == f)
          return (i << 24) + (j << 16) + (k << 8) + m; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid byte order: ");
        stringBuilder.append(this.b);
        throw new IOException(stringBuilder.toString());
      } 
      throw new EOFException();
    }
    
    public String readLine() {
      Log.d("ExifInterface", "Currently unsupported");
      return null;
    }
    
    public long readLong() {
      this.c += 8;
      int i = this.a.read();
      int j = this.a.read();
      int k = this.a.read();
      int m = this.a.read();
      int n = this.a.read();
      int i1 = this.a.read();
      int i2 = this.a.read();
      int i3 = this.a.read();
      if ((i | j | k | m | n | i1 | i2 | i3) >= 0) {
        ByteOrder byteOrder = this.b;
        if (byteOrder == e)
          return (i3 << 56L) + (i2 << 48L) + (i1 << 40L) + (n << 32L) + (m << 24L) + (k << 16L) + (j << 8L) + i; 
        if (byteOrder == f)
          return (i << 56L) + (j << 48L) + (k << 40L) + (m << 32L) + (n << 24L) + (i1 << 16L) + (i2 << 8L) + i3; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid byte order: ");
        stringBuilder.append(this.b);
        throw new IOException(stringBuilder.toString());
      } 
      throw new EOFException();
    }
    
    public short readShort() {
      this.c += 2;
      int i = this.a.read();
      int j = this.a.read();
      if ((i | j) >= 0) {
        ByteOrder byteOrder = this.b;
        if (byteOrder == e)
          return (short)((j << 8) + i); 
        if (byteOrder == f)
          return (short)((i << 8) + j); 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid byte order: ");
        stringBuilder.append(this.b);
        throw new IOException(stringBuilder.toString());
      } 
      throw new EOFException();
    }
    
    public String readUTF() {
      this.c += 2;
      return this.a.readUTF();
    }
    
    public int readUnsignedByte() {
      this.c++;
      return this.a.readUnsignedByte();
    }
    
    public int readUnsignedShort() {
      this.c += 2;
      int i = this.a.read();
      int j = this.a.read();
      if ((i | j) >= 0) {
        ByteOrder byteOrder = this.b;
        if (byteOrder == e)
          return (j << 8) + i; 
        if (byteOrder == f)
          return (i << 8) + j; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid byte order: ");
        stringBuilder.append(this.b);
        throw new IOException(stringBuilder.toString());
      } 
      throw new EOFException();
    }
    
    public void reset() {
      throw new UnsupportedOperationException("Reset is currently unsupported");
    }
    
    public int skipBytes(int param1Int) {
      throw new UnsupportedOperationException("skipBytes is currently unsupported");
    }
  }
  
  private static class c extends FilterOutputStream {
    final OutputStream a;
    
    private ByteOrder b;
    
    public c(OutputStream param1OutputStream, ByteOrder param1ByteOrder) {
      super(param1OutputStream);
      this.a = param1OutputStream;
      this.b = param1ByteOrder;
    }
    
    public void a(ByteOrder param1ByteOrder) {
      this.b = param1ByteOrder;
    }
    
    public void g(int param1Int) {
      this.a.write(param1Int);
    }
    
    public void h(int param1Int) {
      OutputStream outputStream;
      ByteOrder byteOrder = this.b;
      if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.a.write(param1Int >>> 0 & 0xFF);
        this.a.write(param1Int >>> 8 & 0xFF);
        this.a.write(param1Int >>> 16 & 0xFF);
        outputStream = this.a;
        param1Int >>>= 24;
      } else if (outputStream == ByteOrder.BIG_ENDIAN) {
        this.a.write(param1Int >>> 24 & 0xFF);
        this.a.write(param1Int >>> 16 & 0xFF);
        this.a.write(param1Int >>> 8 & 0xFF);
        outputStream = this.a;
        param1Int >>>= 0;
      } else {
        return;
      } 
      outputStream.write(param1Int & 0xFF);
    }
    
    public void k(short param1Short) {
      int i;
      OutputStream outputStream;
      ByteOrder byteOrder = this.b;
      if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.a.write(param1Short >>> 0 & 0xFF);
        outputStream = this.a;
        i = param1Short >>> 8;
      } else if (outputStream == ByteOrder.BIG_ENDIAN) {
        this.a.write(i >>> 8 & 0xFF);
        outputStream = this.a;
        i >>>= 0;
      } else {
        return;
      } 
      outputStream.write(i & 0xFF);
    }
    
    public void o(long param1Long) {
      h((int)param1Long);
    }
    
    public void r(int param1Int) {
      k((short)param1Int);
    }
    
    public void write(byte[] param1ArrayOfbyte) {
      this.a.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      this.a.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
  }
  
  private static class d {
    public final int a;
    
    public final int b;
    
    public final long c;
    
    public final byte[] d;
    
    d(int param1Int1, int param1Int2, long param1Long, byte[] param1ArrayOfbyte) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Long;
      this.d = param1ArrayOfbyte;
    }
    
    d(int param1Int1, int param1Int2, byte[] param1ArrayOfbyte) {
      this(param1Int1, param1Int2, -1L, param1ArrayOfbyte);
    }
    
    public static d a(String param1String) {
      if (param1String.length() == 1 && param1String.charAt(0) >= '0' && param1String.charAt(0) <= '1')
        return new d(1, 1, new byte[] { (byte)(param1String.charAt(0) - 48) }); 
      byte[] arrayOfByte = param1String.getBytes(a.p0);
      return new d(1, arrayOfByte.length, arrayOfByte);
    }
    
    public static d b(double[] param1ArrayOfdouble, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[12] * param1ArrayOfdouble.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfdouble.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putDouble(param1ArrayOfdouble[i]); 
      return new d(12, param1ArrayOfdouble.length, byteBuffer.array());
    }
    
    public static d c(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[9] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt(param1ArrayOfint[i]); 
      return new d(9, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public static d d(a.f[] param1ArrayOff, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[10] * param1ArrayOff.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOff.length;
      for (int i = 0; i < j; i++) {
        a.f f1 = param1ArrayOff[i];
        byteBuffer.putInt((int)f1.a);
        byteBuffer.putInt((int)f1.b);
      } 
      return new d(10, param1ArrayOff.length, byteBuffer.array());
    }
    
    public static d e(String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append(false);
      byte[] arrayOfByte = stringBuilder.toString().getBytes(a.p0);
      return new d(2, arrayOfByte.length, arrayOfByte);
    }
    
    public static d f(long param1Long, ByteOrder param1ByteOrder) {
      return g(new long[] { param1Long }, param1ByteOrder);
    }
    
    public static d g(long[] param1ArrayOflong, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[4] * param1ArrayOflong.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOflong.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt((int)param1ArrayOflong[i]); 
      return new d(4, param1ArrayOflong.length, byteBuffer.array());
    }
    
    public static d h(a.f param1f, ByteOrder param1ByteOrder) {
      return i(new a.f[] { param1f }, param1ByteOrder);
    }
    
    public static d i(a.f[] param1ArrayOff, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[5] * param1ArrayOff.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOff.length;
      for (int i = 0; i < j; i++) {
        a.f f1 = param1ArrayOff[i];
        byteBuffer.putInt((int)f1.a);
        byteBuffer.putInt((int)f1.b);
      } 
      return new d(5, param1ArrayOff.length, byteBuffer.array());
    }
    
    public static d j(int param1Int, ByteOrder param1ByteOrder) {
      return k(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static d k(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.X[3] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putShort((short)param1ArrayOfint[i]); 
      return new d(3, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public double l(ByteOrder param1ByteOrder) {
      Object object = o(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Double.parseDouble((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof double[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof a.f[]) {
          object = object;
          if (object.length == 1)
            return object[0].a(); 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a double value");
      } 
      throw new NumberFormatException("NULL can't be converted to a double value");
    }
    
    public int m(ByteOrder param1ByteOrder) {
      Object object = o(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Integer.parseInt((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return (int)object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a integer value");
      } 
      throw new NumberFormatException("NULL can't be converted to a integer value");
    }
    
    public String n(ByteOrder param1ByteOrder) {
      Object object = o(param1ByteOrder);
      if (object == null)
        return null; 
      if (object instanceof String)
        return (String)object; 
      StringBuilder stringBuilder = new StringBuilder();
      boolean bool = object instanceof long[];
      int j = 0;
      boolean bool1 = false;
      boolean bool2 = false;
      int i = 0;
      if (bool) {
        object = object;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof int[]) {
        object = object;
        i = j;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof double[]) {
        object = object;
        i = bool1;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof a.f[]) {
        object = object;
        i = bool2;
        while (i < object.length) {
          stringBuilder.append(((a.f)object[i]).a);
          stringBuilder.append('/');
          stringBuilder.append(((a.f)object[i]).b);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      return null;
    }
    
    Object o(ByteOrder param1ByteOrder) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #13
      //   3: new androidx/exifinterface/media/a$b
      //   6: dup
      //   7: aload_0
      //   8: getfield d : [B
      //   11: invokespecial <init> : ([B)V
      //   14: astore #14
      //   16: aload #14
      //   18: astore #13
      //   20: aload #14
      //   22: aload_1
      //   23: invokevirtual h : (Ljava/nio/ByteOrder;)V
      //   26: aload #14
      //   28: astore #13
      //   30: aload_0
      //   31: getfield a : I
      //   34: istore #12
      //   36: iconst_1
      //   37: istore #5
      //   39: iconst_0
      //   40: istore_3
      //   41: iconst_0
      //   42: istore #6
      //   44: iconst_0
      //   45: istore #7
      //   47: iconst_0
      //   48: istore #8
      //   50: iconst_0
      //   51: istore #9
      //   53: iconst_0
      //   54: istore #10
      //   56: iconst_0
      //   57: istore #11
      //   59: iconst_0
      //   60: istore #4
      //   62: iconst_0
      //   63: istore_2
      //   64: iload #12
      //   66: tableswitch default -> 1080, 1 -> 863, 2 -> 681, 3 -> 615, 4 -> 549, 5 -> 470, 6 -> 863, 7 -> 681, 8 -> 404, 9 -> 338, 10 -> 257, 11 -> 191, 12 -> 128
      //   128: aload #14
      //   130: astore #13
      //   132: aload_0
      //   133: getfield b : I
      //   136: newarray double
      //   138: astore_1
      //   139: aload #14
      //   141: astore #13
      //   143: iload_2
      //   144: aload_0
      //   145: getfield b : I
      //   148: if_icmpge -> 170
      //   151: aload #14
      //   153: astore #13
      //   155: aload_1
      //   156: iload_2
      //   157: aload #14
      //   159: invokevirtual readDouble : ()D
      //   162: dastore
      //   163: iload_2
      //   164: iconst_1
      //   165: iadd
      //   166: istore_2
      //   167: goto -> 139
      //   170: aload #14
      //   172: invokevirtual close : ()V
      //   175: aload_1
      //   176: areturn
      //   177: astore #13
      //   179: ldc 'ExifInterface'
      //   181: ldc 'IOException occurred while closing InputStream'
      //   183: aload #13
      //   185: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   188: pop
      //   189: aload_1
      //   190: areturn
      //   191: aload #14
      //   193: astore #13
      //   195: aload_0
      //   196: getfield b : I
      //   199: newarray double
      //   201: astore_1
      //   202: iload_3
      //   203: istore_2
      //   204: aload #14
      //   206: astore #13
      //   208: iload_2
      //   209: aload_0
      //   210: getfield b : I
      //   213: if_icmpge -> 236
      //   216: aload #14
      //   218: astore #13
      //   220: aload_1
      //   221: iload_2
      //   222: aload #14
      //   224: invokevirtual readFloat : ()F
      //   227: f2d
      //   228: dastore
      //   229: iload_2
      //   230: iconst_1
      //   231: iadd
      //   232: istore_2
      //   233: goto -> 204
      //   236: aload #14
      //   238: invokevirtual close : ()V
      //   241: aload_1
      //   242: areturn
      //   243: astore #13
      //   245: ldc 'ExifInterface'
      //   247: ldc 'IOException occurred while closing InputStream'
      //   249: aload #13
      //   251: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   254: pop
      //   255: aload_1
      //   256: areturn
      //   257: aload #14
      //   259: astore #13
      //   261: aload_0
      //   262: getfield b : I
      //   265: anewarray androidx/exifinterface/media/a$f
      //   268: astore_1
      //   269: iload #6
      //   271: istore_2
      //   272: aload #14
      //   274: astore #13
      //   276: iload_2
      //   277: aload_0
      //   278: getfield b : I
      //   281: if_icmpge -> 317
      //   284: aload #14
      //   286: astore #13
      //   288: aload_1
      //   289: iload_2
      //   290: new androidx/exifinterface/media/a$f
      //   293: dup
      //   294: aload #14
      //   296: invokevirtual readInt : ()I
      //   299: i2l
      //   300: aload #14
      //   302: invokevirtual readInt : ()I
      //   305: i2l
      //   306: invokespecial <init> : (JJ)V
      //   309: aastore
      //   310: iload_2
      //   311: iconst_1
      //   312: iadd
      //   313: istore_2
      //   314: goto -> 272
      //   317: aload #14
      //   319: invokevirtual close : ()V
      //   322: aload_1
      //   323: areturn
      //   324: astore #13
      //   326: ldc 'ExifInterface'
      //   328: ldc 'IOException occurred while closing InputStream'
      //   330: aload #13
      //   332: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   335: pop
      //   336: aload_1
      //   337: areturn
      //   338: aload #14
      //   340: astore #13
      //   342: aload_0
      //   343: getfield b : I
      //   346: newarray int
      //   348: astore_1
      //   349: iload #7
      //   351: istore_2
      //   352: aload #14
      //   354: astore #13
      //   356: iload_2
      //   357: aload_0
      //   358: getfield b : I
      //   361: if_icmpge -> 383
      //   364: aload #14
      //   366: astore #13
      //   368: aload_1
      //   369: iload_2
      //   370: aload #14
      //   372: invokevirtual readInt : ()I
      //   375: iastore
      //   376: iload_2
      //   377: iconst_1
      //   378: iadd
      //   379: istore_2
      //   380: goto -> 352
      //   383: aload #14
      //   385: invokevirtual close : ()V
      //   388: aload_1
      //   389: areturn
      //   390: astore #13
      //   392: ldc 'ExifInterface'
      //   394: ldc 'IOException occurred while closing InputStream'
      //   396: aload #13
      //   398: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   401: pop
      //   402: aload_1
      //   403: areturn
      //   404: aload #14
      //   406: astore #13
      //   408: aload_0
      //   409: getfield b : I
      //   412: newarray int
      //   414: astore_1
      //   415: iload #8
      //   417: istore_2
      //   418: aload #14
      //   420: astore #13
      //   422: iload_2
      //   423: aload_0
      //   424: getfield b : I
      //   427: if_icmpge -> 449
      //   430: aload #14
      //   432: astore #13
      //   434: aload_1
      //   435: iload_2
      //   436: aload #14
      //   438: invokevirtual readShort : ()S
      //   441: iastore
      //   442: iload_2
      //   443: iconst_1
      //   444: iadd
      //   445: istore_2
      //   446: goto -> 418
      //   449: aload #14
      //   451: invokevirtual close : ()V
      //   454: aload_1
      //   455: areturn
      //   456: astore #13
      //   458: ldc 'ExifInterface'
      //   460: ldc 'IOException occurred while closing InputStream'
      //   462: aload #13
      //   464: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   467: pop
      //   468: aload_1
      //   469: areturn
      //   470: aload #14
      //   472: astore #13
      //   474: aload_0
      //   475: getfield b : I
      //   478: anewarray androidx/exifinterface/media/a$f
      //   481: astore_1
      //   482: iload #9
      //   484: istore_2
      //   485: aload #14
      //   487: astore #13
      //   489: iload_2
      //   490: aload_0
      //   491: getfield b : I
      //   494: if_icmpge -> 528
      //   497: aload #14
      //   499: astore #13
      //   501: aload_1
      //   502: iload_2
      //   503: new androidx/exifinterface/media/a$f
      //   506: dup
      //   507: aload #14
      //   509: invokevirtual g : ()J
      //   512: aload #14
      //   514: invokevirtual g : ()J
      //   517: invokespecial <init> : (JJ)V
      //   520: aastore
      //   521: iload_2
      //   522: iconst_1
      //   523: iadd
      //   524: istore_2
      //   525: goto -> 485
      //   528: aload #14
      //   530: invokevirtual close : ()V
      //   533: aload_1
      //   534: areturn
      //   535: astore #13
      //   537: ldc 'ExifInterface'
      //   539: ldc 'IOException occurred while closing InputStream'
      //   541: aload #13
      //   543: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   546: pop
      //   547: aload_1
      //   548: areturn
      //   549: aload #14
      //   551: astore #13
      //   553: aload_0
      //   554: getfield b : I
      //   557: newarray long
      //   559: astore_1
      //   560: iload #10
      //   562: istore_2
      //   563: aload #14
      //   565: astore #13
      //   567: iload_2
      //   568: aload_0
      //   569: getfield b : I
      //   572: if_icmpge -> 594
      //   575: aload #14
      //   577: astore #13
      //   579: aload_1
      //   580: iload_2
      //   581: aload #14
      //   583: invokevirtual g : ()J
      //   586: lastore
      //   587: iload_2
      //   588: iconst_1
      //   589: iadd
      //   590: istore_2
      //   591: goto -> 563
      //   594: aload #14
      //   596: invokevirtual close : ()V
      //   599: aload_1
      //   600: areturn
      //   601: astore #13
      //   603: ldc 'ExifInterface'
      //   605: ldc 'IOException occurred while closing InputStream'
      //   607: aload #13
      //   609: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   612: pop
      //   613: aload_1
      //   614: areturn
      //   615: aload #14
      //   617: astore #13
      //   619: aload_0
      //   620: getfield b : I
      //   623: newarray int
      //   625: astore_1
      //   626: iload #11
      //   628: istore_2
      //   629: aload #14
      //   631: astore #13
      //   633: iload_2
      //   634: aload_0
      //   635: getfield b : I
      //   638: if_icmpge -> 660
      //   641: aload #14
      //   643: astore #13
      //   645: aload_1
      //   646: iload_2
      //   647: aload #14
      //   649: invokevirtual readUnsignedShort : ()I
      //   652: iastore
      //   653: iload_2
      //   654: iconst_1
      //   655: iadd
      //   656: istore_2
      //   657: goto -> 629
      //   660: aload #14
      //   662: invokevirtual close : ()V
      //   665: aload_1
      //   666: areturn
      //   667: astore #13
      //   669: ldc 'ExifInterface'
      //   671: ldc 'IOException occurred while closing InputStream'
      //   673: aload #13
      //   675: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   678: pop
      //   679: aload_1
      //   680: areturn
      //   681: iload #4
      //   683: istore_2
      //   684: aload #14
      //   686: astore #13
      //   688: aload_0
      //   689: getfield b : I
      //   692: getstatic androidx/exifinterface/media/a.Y : [B
      //   695: arraylength
      //   696: if_icmplt -> 757
      //   699: iconst_0
      //   700: istore_2
      //   701: aload #14
      //   703: astore #13
      //   705: getstatic androidx/exifinterface/media/a.Y : [B
      //   708: astore_1
      //   709: iload #5
      //   711: istore_3
      //   712: aload #14
      //   714: astore #13
      //   716: iload_2
      //   717: aload_1
      //   718: arraylength
      //   719: if_icmpge -> 743
      //   722: aload #14
      //   724: astore #13
      //   726: aload_0
      //   727: getfield d : [B
      //   730: iload_2
      //   731: baload
      //   732: aload_1
      //   733: iload_2
      //   734: baload
      //   735: if_icmpeq -> 1083
      //   738: iconst_0
      //   739: istore_3
      //   740: goto -> 743
      //   743: iload #4
      //   745: istore_2
      //   746: iload_3
      //   747: ifeq -> 757
      //   750: aload #14
      //   752: astore #13
      //   754: aload_1
      //   755: arraylength
      //   756: istore_2
      //   757: aload #14
      //   759: astore #13
      //   761: new java/lang/StringBuilder
      //   764: dup
      //   765: invokespecial <init> : ()V
      //   768: astore_1
      //   769: aload #14
      //   771: astore #13
      //   773: iload_2
      //   774: aload_0
      //   775: getfield b : I
      //   778: if_icmpge -> 833
      //   781: aload #14
      //   783: astore #13
      //   785: aload_0
      //   786: getfield d : [B
      //   789: iload_2
      //   790: baload
      //   791: istore_3
      //   792: iload_3
      //   793: ifne -> 799
      //   796: goto -> 833
      //   799: iload_3
      //   800: bipush #32
      //   802: if_icmplt -> 819
      //   805: aload #14
      //   807: astore #13
      //   809: aload_1
      //   810: iload_3
      //   811: i2c
      //   812: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   815: pop
      //   816: goto -> 1090
      //   819: aload #14
      //   821: astore #13
      //   823: aload_1
      //   824: bipush #63
      //   826: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   829: pop
      //   830: goto -> 1090
      //   833: aload #14
      //   835: astore #13
      //   837: aload_1
      //   838: invokevirtual toString : ()Ljava/lang/String;
      //   841: astore_1
      //   842: aload #14
      //   844: invokevirtual close : ()V
      //   847: aload_1
      //   848: areturn
      //   849: astore #13
      //   851: ldc 'ExifInterface'
      //   853: ldc 'IOException occurred while closing InputStream'
      //   855: aload #13
      //   857: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   860: pop
      //   861: aload_1
      //   862: areturn
      //   863: aload #14
      //   865: astore #13
      //   867: aload_0
      //   868: getfield d : [B
      //   871: astore_1
      //   872: aload #14
      //   874: astore #13
      //   876: aload_1
      //   877: arraylength
      //   878: iconst_1
      //   879: if_icmpne -> 941
      //   882: aload_1
      //   883: iconst_0
      //   884: baload
      //   885: iflt -> 941
      //   888: aload_1
      //   889: iconst_0
      //   890: baload
      //   891: iconst_1
      //   892: if_icmpgt -> 941
      //   895: aload #14
      //   897: astore #13
      //   899: new java/lang/String
      //   902: dup
      //   903: iconst_1
      //   904: newarray char
      //   906: dup
      //   907: iconst_0
      //   908: aload_1
      //   909: iconst_0
      //   910: baload
      //   911: bipush #48
      //   913: iadd
      //   914: i2c
      //   915: castore
      //   916: invokespecial <init> : ([C)V
      //   919: astore_1
      //   920: aload #14
      //   922: invokevirtual close : ()V
      //   925: aload_1
      //   926: areturn
      //   927: astore #13
      //   929: ldc 'ExifInterface'
      //   931: ldc 'IOException occurred while closing InputStream'
      //   933: aload #13
      //   935: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   938: pop
      //   939: aload_1
      //   940: areturn
      //   941: aload #14
      //   943: astore #13
      //   945: new java/lang/String
      //   948: dup
      //   949: aload_1
      //   950: getstatic androidx/exifinterface/media/a.p0 : Ljava/nio/charset/Charset;
      //   953: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
      //   956: astore_1
      //   957: aload #14
      //   959: invokevirtual close : ()V
      //   962: aload_1
      //   963: areturn
      //   964: astore #13
      //   966: ldc 'ExifInterface'
      //   968: ldc 'IOException occurred while closing InputStream'
      //   970: aload #13
      //   972: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   975: pop
      //   976: aload_1
      //   977: areturn
      //   978: aload #14
      //   980: invokevirtual close : ()V
      //   983: aconst_null
      //   984: areturn
      //   985: astore_1
      //   986: ldc 'ExifInterface'
      //   988: ldc 'IOException occurred while closing InputStream'
      //   990: aload_1
      //   991: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   994: pop
      //   995: aconst_null
      //   996: areturn
      //   997: astore #13
      //   999: aload #14
      //   1001: astore_1
      //   1002: aload #13
      //   1004: astore #14
      //   1006: goto -> 1017
      //   1009: astore_1
      //   1010: goto -> 1053
      //   1013: astore #14
      //   1015: aconst_null
      //   1016: astore_1
      //   1017: aload_1
      //   1018: astore #13
      //   1020: ldc 'ExifInterface'
      //   1022: ldc 'IOException occurred during reading a value'
      //   1024: aload #14
      //   1026: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1029: pop
      //   1030: aload_1
      //   1031: ifnull -> 1050
      //   1034: aload_1
      //   1035: invokevirtual close : ()V
      //   1038: aconst_null
      //   1039: areturn
      //   1040: astore_1
      //   1041: ldc 'ExifInterface'
      //   1043: ldc 'IOException occurred while closing InputStream'
      //   1045: aload_1
      //   1046: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1049: pop
      //   1050: aconst_null
      //   1051: areturn
      //   1052: astore_1
      //   1053: aload #13
      //   1055: ifnull -> 1078
      //   1058: aload #13
      //   1060: invokevirtual close : ()V
      //   1063: goto -> 1078
      //   1066: astore #13
      //   1068: ldc 'ExifInterface'
      //   1070: ldc 'IOException occurred while closing InputStream'
      //   1072: aload #13
      //   1074: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1077: pop
      //   1078: aload_1
      //   1079: athrow
      //   1080: goto -> 978
      //   1083: iload_2
      //   1084: iconst_1
      //   1085: iadd
      //   1086: istore_2
      //   1087: goto -> 701
      //   1090: iload_2
      //   1091: iconst_1
      //   1092: iadd
      //   1093: istore_2
      //   1094: goto -> 769
      // Exception table:
      //   from	to	target	type
      //   3	16	1013	java/io/IOException
      //   3	16	1009	finally
      //   20	26	997	java/io/IOException
      //   20	26	1052	finally
      //   30	36	997	java/io/IOException
      //   30	36	1052	finally
      //   132	139	997	java/io/IOException
      //   132	139	1052	finally
      //   143	151	997	java/io/IOException
      //   143	151	1052	finally
      //   155	163	997	java/io/IOException
      //   155	163	1052	finally
      //   170	175	177	java/io/IOException
      //   195	202	997	java/io/IOException
      //   195	202	1052	finally
      //   208	216	997	java/io/IOException
      //   208	216	1052	finally
      //   220	229	997	java/io/IOException
      //   220	229	1052	finally
      //   236	241	243	java/io/IOException
      //   261	269	997	java/io/IOException
      //   261	269	1052	finally
      //   276	284	997	java/io/IOException
      //   276	284	1052	finally
      //   288	310	997	java/io/IOException
      //   288	310	1052	finally
      //   317	322	324	java/io/IOException
      //   342	349	997	java/io/IOException
      //   342	349	1052	finally
      //   356	364	997	java/io/IOException
      //   356	364	1052	finally
      //   368	376	997	java/io/IOException
      //   368	376	1052	finally
      //   383	388	390	java/io/IOException
      //   408	415	997	java/io/IOException
      //   408	415	1052	finally
      //   422	430	997	java/io/IOException
      //   422	430	1052	finally
      //   434	442	997	java/io/IOException
      //   434	442	1052	finally
      //   449	454	456	java/io/IOException
      //   474	482	997	java/io/IOException
      //   474	482	1052	finally
      //   489	497	997	java/io/IOException
      //   489	497	1052	finally
      //   501	521	997	java/io/IOException
      //   501	521	1052	finally
      //   528	533	535	java/io/IOException
      //   553	560	997	java/io/IOException
      //   553	560	1052	finally
      //   567	575	997	java/io/IOException
      //   567	575	1052	finally
      //   579	587	997	java/io/IOException
      //   579	587	1052	finally
      //   594	599	601	java/io/IOException
      //   619	626	997	java/io/IOException
      //   619	626	1052	finally
      //   633	641	997	java/io/IOException
      //   633	641	1052	finally
      //   645	653	997	java/io/IOException
      //   645	653	1052	finally
      //   660	665	667	java/io/IOException
      //   688	699	997	java/io/IOException
      //   688	699	1052	finally
      //   705	709	997	java/io/IOException
      //   705	709	1052	finally
      //   716	722	997	java/io/IOException
      //   716	722	1052	finally
      //   726	738	997	java/io/IOException
      //   726	738	1052	finally
      //   754	757	997	java/io/IOException
      //   754	757	1052	finally
      //   761	769	997	java/io/IOException
      //   761	769	1052	finally
      //   773	781	997	java/io/IOException
      //   773	781	1052	finally
      //   785	792	997	java/io/IOException
      //   785	792	1052	finally
      //   809	816	997	java/io/IOException
      //   809	816	1052	finally
      //   823	830	997	java/io/IOException
      //   823	830	1052	finally
      //   837	842	997	java/io/IOException
      //   837	842	1052	finally
      //   842	847	849	java/io/IOException
      //   867	872	997	java/io/IOException
      //   867	872	1052	finally
      //   876	882	997	java/io/IOException
      //   876	882	1052	finally
      //   899	920	997	java/io/IOException
      //   899	920	1052	finally
      //   920	925	927	java/io/IOException
      //   945	957	997	java/io/IOException
      //   945	957	1052	finally
      //   957	962	964	java/io/IOException
      //   978	983	985	java/io/IOException
      //   1020	1030	1052	finally
      //   1034	1038	1040	java/io/IOException
      //   1058	1063	1066	java/io/IOException
    }
    
    public int p() {
      return a.X[this.a] * this.b;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(a.W[this.a]);
      stringBuilder.append(", data length:");
      stringBuilder.append(this.d.length);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static class e {
    public final int a;
    
    public final String b;
    
    public final int c;
    
    public final int d;
    
    e(String param1String, int param1Int1, int param1Int2) {
      this.b = param1String;
      this.a = param1Int1;
      this.c = param1Int2;
      this.d = -1;
    }
    
    e(String param1String, int param1Int1, int param1Int2, int param1Int3) {
      this.b = param1String;
      this.a = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
    }
    
    boolean a(int param1Int) {
      int i = this.c;
      if (i != 7) {
        if (param1Int == 7)
          return true; 
        if (i != param1Int) {
          int j = this.d;
          return (j == param1Int) ? true : (((i == 4 || j == 4) && param1Int == 3) ? true : (((i == 9 || j == 9) && param1Int == 8) ? true : (((i == 12 || j == 12) && param1Int == 11))));
        } 
      } 
      return true;
    }
  }
  
  private static class f {
    public final long a;
    
    public final long b;
    
    f(double param1Double) {
      this((long)(param1Double * 10000.0D), 10000L);
    }
    
    f(long param1Long1, long param1Long2) {
      if (param1Long2 == 0L) {
        this.a = 0L;
        this.b = 1L;
        return;
      } 
      this.a = param1Long1;
      this.b = param1Long2;
    }
    
    public double a() {
      return this.a / this.b;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("/");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
  
  private static class g extends b {
    g(InputStream param1InputStream) {
      super(param1InputStream);
      if (param1InputStream.markSupported()) {
        this.a.mark(2147483647);
        return;
      } 
      throw new IllegalArgumentException("Cannot create SeekableByteOrderedDataInputStream with stream that does not support mark/reset");
    }
    
    g(byte[] param1ArrayOfbyte) {
      super(param1ArrayOfbyte);
      this.a.mark(2147483647);
    }
    
    public void o(long param1Long) {
      int i = this.c;
      if (i > param1Long) {
        this.c = 0;
        this.a.reset();
      } else {
        param1Long -= i;
      } 
      k((int)param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\exifinterface\media\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */