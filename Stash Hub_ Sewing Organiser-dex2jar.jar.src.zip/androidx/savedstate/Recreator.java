package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import x.d;

public final class Recreator implements h {
  public static final a b = new a(null);
  
  private final d a;
  
  public Recreator(d paramd) {
    this.a = paramd;
  }
  
  private final void b(String paramString) {
    try {
      Class<? extends a.a> clazz = Class.forName(paramString, false, Recreator.class.getClassLoader()).asSubclass(a.a.class);
      l.e(clazz, "{\n                Class.…class.java)\n            }");
      try {
        Constructor<? extends a.a> constructor = clazz.getDeclaredConstructor(new Class[0]);
        constructor.setAccessible(true);
        try {
          clazz = (Class<? extends a.a>)constructor.newInstance(new Object[0]);
          l.e(clazz, "{\n                constr…wInstance()\n            }");
          a.a a1 = (a.a)clazz;
          a1.a(this.a);
          return;
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate ");
          stringBuilder.append(paramString);
          throw new RuntimeException(stringBuilder.toString(), exception);
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class ");
        stringBuilder.append(exception.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Class ");
      stringBuilder.append((String)noSuchMethodException);
      stringBuilder.append(" wasn't found");
      throw new RuntimeException(stringBuilder.toString(), classNotFoundException);
    } 
  }
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    if (parama == e.a.ON_CREATE) {
      paramj.a().c((i)this);
      Bundle bundle = this.a.k().b("androidx.savedstate.Restarter");
      if (bundle == null)
        return; 
      ArrayList arrayList = bundle.getStringArrayList("classes_to_restore");
      if (arrayList != null) {
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext())
          b(iterator.next()); 
        return;
      } 
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    } 
    throw new AssertionError("Next event must be ON_CREATE");
  }
  
  public static final class a {
    private a() {}
  }
  
  public static final class b implements a.c {
    private final Set<String> a = new LinkedHashSet<String>();
    
    public b(a param1a) {
      param1a.h("androidx.savedstate.Restarter", this);
    }
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      bundle.putStringArrayList("classes_to_restore", new ArrayList<String>(this.a));
      return bundle;
    }
    
    public final void b(String param1String) {
      l.f(param1String, "className");
      this.a.add(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */