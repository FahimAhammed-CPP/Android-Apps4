package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.e;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import java.util.Map;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import x.d;

public final class a {
  private static final b g = new b(null);
  
  private final e.b<String, c> a = new e.b();
  
  private boolean b;
  
  private Bundle c;
  
  private boolean d;
  
  private Recreator.b e;
  
  private boolean f = true;
  
  private static final void d(a parama, j paramj, e.a parama1) {
    boolean bool;
    l.f(parama, "this$0");
    l.f(paramj, "<anonymous parameter 0>");
    l.f(parama1, "event");
    if (parama1 == e.a.ON_START) {
      bool = true;
    } else if (parama1 == e.a.ON_STOP) {
      bool = false;
    } else {
      return;
    } 
    parama.f = bool;
  }
  
  public final Bundle b(String paramString) {
    l.f(paramString, "key");
    if (this.d) {
      Bundle bundle = this.c;
      if (bundle != null) {
        if (bundle != null) {
          bundle = bundle.getBundle(paramString);
        } else {
          bundle = null;
        } 
        Bundle bundle2 = this.c;
        if (bundle2 != null)
          bundle2.remove(paramString); 
        Bundle bundle1 = this.c;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (bundle1 != null) {
          bool1 = bool2;
          if (!bundle1.isEmpty())
            bool1 = true; 
        } 
        if (!bool1)
          this.c = null; 
        return bundle;
      } 
      return null;
    } 
    throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component".toString());
  }
  
  public final c c(String paramString) {
    l.f(paramString, "key");
    for (Map.Entry entry : this.a) {
      l.e(entry, "components");
      String str = (String)entry.getKey();
      c c = (c)entry.getValue();
      if (l.b(str, paramString))
        return c; 
    } 
    return null;
  }
  
  public final void e(e parame) {
    l.f(parame, "lifecycle");
    if ((this.b ^ true) != 0) {
      parame.a((i)new x.b(this));
      this.b = true;
      return;
    } 
    throw new IllegalStateException("SavedStateRegistry was already attached.".toString());
  }
  
  public final void f(Bundle paramBundle) {
    if (this.b) {
      if ((this.d ^ true) != 0) {
        if (paramBundle != null) {
          paramBundle = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
        } else {
          paramBundle = null;
        } 
        this.c = paramBundle;
        this.d = true;
        return;
      } 
      throw new IllegalStateException("SavedStateRegistry was already restored.".toString());
    } 
    throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).".toString());
  }
  
  public final void g(Bundle paramBundle) {
    l.f(paramBundle, "outBundle");
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.c;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    e.b.d<Map.Entry> d = this.a.g();
    l.e(d, "this.components.iteratorWithAdditions()");
    while (d.hasNext()) {
      Map.Entry entry = d.next();
      bundle1.putBundle((String)entry.getKey(), ((c)entry.getValue()).a());
    } 
    if (!bundle1.isEmpty())
      paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle1); 
  }
  
  public final void h(String paramString, c paramc) {
    boolean bool;
    l.f(paramString, "key");
    l.f(paramc, "provider");
    if ((c)this.a.n(paramString, paramc) == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalArgumentException("SavedStateProvider with the given key is already registered".toString());
  }
  
  public final void i(Class<? extends a> paramClass) {
    l.f(paramClass, "clazz");
    if (this.f) {
      String str;
      Recreator.b b2 = this.e;
      Recreator.b b1 = b2;
      if (b2 == null)
        b1 = new Recreator.b(this); 
      this.e = b1;
      try {
        paramClass.getDeclaredConstructor(new Class[0]);
        b1 = this.e;
        if (b1 != null) {
          str = paramClass.getName();
          l.e(str, "clazz.name");
          b1.b(str);
        } 
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class ");
        stringBuilder.append(str.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalArgumentException(stringBuilder.toString(), noSuchMethodException);
      } 
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState".toString());
  }
  
  public static interface a {
    void a(d param1d);
  }
  
  private static final class b {
    private b() {}
  }
  
  public static interface c {
    Bundle a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\savedstate\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */