package androidx.collection;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class a<K, V> extends f<K, V> implements Map<K, V> {
  e<K, V> l;
  
  public a() {}
  
  public a(int paramInt) {
    super(paramInt);
  }
  
  private e<K, V> m() {
    if (this.l == null)
      this.l = new a(this); 
    return this.l;
  }
  
  public Set<Map.Entry<K, V>> entrySet() {
    return m().l();
  }
  
  public Set<K> keySet() {
    return m().m();
  }
  
  public boolean n(Collection<?> paramCollection) {
    return e.p(this, paramCollection);
  }
  
  public void putAll(Map<? extends K, ? extends V> paramMap) {
    c(this.c + paramMap.size());
    for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet())
      put((K)entry.getKey(), (V)entry.getValue()); 
  }
  
  public Collection<V> values() {
    return m().n();
  }
  
  class a extends e<K, V> {
    a(a this$0) {}
    
    protected void a() {
      this.d.clear();
    }
    
    protected Object b(int param1Int1, int param1Int2) {
      return this.d.b[(param1Int1 << 1) + param1Int2];
    }
    
    protected Map<K, V> c() {
      return this.d;
    }
    
    protected int d() {
      return this.d.c;
    }
    
    protected int e(Object param1Object) {
      return this.d.f(param1Object);
    }
    
    protected int f(Object param1Object) {
      return this.d.h(param1Object);
    }
    
    protected void g(K param1K, V param1V) {
      this.d.put(param1K, param1V);
    }
    
    protected void h(int param1Int) {
      this.d.j(param1Int);
    }
    
    protected V i(int param1Int, V param1V) {
      return (V)this.d.k(param1Int, param1V);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\collection\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */