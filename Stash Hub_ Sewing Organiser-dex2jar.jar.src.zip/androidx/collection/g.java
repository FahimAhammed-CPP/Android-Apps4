package androidx.collection;

public class g<E> implements Cloneable {
  private static final Object e = new Object();
  
  private boolean a = false;
  
  private int[] b;
  
  private Object[] c;
  
  private int d;
  
  public g() {
    this(10);
  }
  
  public g(int paramInt) {
    if (paramInt == 0) {
      this.b = c.a;
      this.c = c.c;
      return;
    } 
    paramInt = c.d(paramInt);
    this.b = new int[paramInt];
    this.c = new Object[paramInt];
  }
  
  private void d() {
    int k = this.d;
    int[] arrayOfInt = this.b;
    Object[] arrayOfObject = this.c;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != e) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.a = false;
    this.d = j;
  }
  
  public void b() {
    int j = this.d;
    Object[] arrayOfObject = this.c;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.d = 0;
    this.a = false;
  }
  
  public g<E> c() {
    try {
      g<E> g1 = (g)super.clone();
      g1.b = (int[])this.b.clone();
      g1.c = (Object[])this.c.clone();
      return g1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public E e(int paramInt) {
    return f(paramInt, null);
  }
  
  public E f(int paramInt, E paramE) {
    paramInt = c.a(this.b, this.d, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.c;
      return (E)((arrayOfObject[paramInt] == e) ? (Object)paramE : arrayOfObject[paramInt]);
    } 
    return paramE;
  }
  
  public int h(int paramInt) {
    if (this.a)
      d(); 
    return c.a(this.b, this.d, paramInt);
  }
  
  public int i(int paramInt) {
    if (this.a)
      d(); 
    return this.b[paramInt];
  }
  
  public void j(int paramInt, E paramE) {
    int i = c.a(this.b, this.d, paramInt);
    if (i >= 0) {
      this.c[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.d;
    if (j < k) {
      Object[] arrayOfObject = this.c;
      if (arrayOfObject[j] == e) {
        this.b[j] = paramInt;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.a) {
      i = j;
      if (k >= this.b.length) {
        d();
        i = c.a(this.b, this.d, paramInt);
      } 
    } 
    j = this.d;
    if (j >= this.b.length) {
      j = c.d(j + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.b;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.b = arrayOfInt1;
      this.c = arrayOfObject1;
    } 
    j = this.d;
    if (j - i != 0) {
      int[] arrayOfInt = this.b;
      k = i + 1;
      System.arraycopy(arrayOfInt, i, arrayOfInt, k, j - i);
      Object[] arrayOfObject = this.c;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.d - i);
    } 
    this.b[i] = paramInt;
    this.c[i] = paramE;
    this.d++;
  }
  
  public void l(int paramInt) {
    paramInt = c.a(this.b, this.d, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.c;
      Object object1 = arrayOfObject[paramInt];
      Object object2 = e;
      if (object1 != object2) {
        arrayOfObject[paramInt] = object2;
        this.a = true;
      } 
    } 
  }
  
  public int m() {
    if (this.a)
      d(); 
    return this.d;
  }
  
  public E n(int paramInt) {
    if (this.a)
      d(); 
    return (E)this.c[paramInt];
  }
  
  public String toString() {
    if (m() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.d * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.d; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(i(i));
      stringBuilder.append('=');
      E e = n(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\collection\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */