package androidx.core.util;

import java.util.Objects;

public final class e {
  public static float a(float paramFloat, String paramString) {
    if (!Float.isNaN(paramFloat)) {
      if (!Float.isInfinite(paramFloat))
        return paramFloat; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append(" must not be infinite");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(" must not be NaN");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static <T> T b(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T c(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\cor\\util\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */