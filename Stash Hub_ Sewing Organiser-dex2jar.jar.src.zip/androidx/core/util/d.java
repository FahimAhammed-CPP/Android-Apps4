package androidx.core.util;

import android.os.Build;
import java.util.Arrays;
import java.util.Objects;

public class d {
  public static boolean a(Object paramObject1, Object paramObject2) {
    return (Build.VERSION.SDK_INT >= 19) ? a.a(paramObject1, paramObject2) : ((paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2))));
  }
  
  public static int b(Object... paramVarArgs) {
    return (Build.VERSION.SDK_INT >= 19) ? a.b(paramVarArgs) : Arrays.hashCode(paramVarArgs);
  }
  
  public static <T> T c(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T d(T paramT, String paramString) {
    Objects.requireNonNull(paramT, paramString);
    return paramT;
  }
  
  static class a {
    static boolean a(Object param1Object1, Object param1Object2) {
      return Objects.equals(param1Object1, param1Object2);
    }
    
    static int b(Object... param1VarArgs) {
      return Objects.hash(param1VarArgs);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\cor\\util\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */