package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class h implements f {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final g.d c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  h(g.d paramd) {
    boolean bool;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = paramd;
    Context context = paramd.a;
    this.a = context;
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      builder = h.a(context, paramd.K);
    } else {
      builder = new Notification.Builder(paramd.a);
    } 
    this.b = builder;
    Notification notification = paramd.S;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramd.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramd.e).setContentText(paramd.f).setContentInfo(paramd.k).setContentIntent(paramd.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramd.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramd.j).setNumber(paramd.l).setProgress(paramd.t, paramd.u, paramd.v);
    if (i < 21)
      this.b.setSound(notification.sound, notification.audioStreamType); 
    if (i >= 16) {
      a.b(a.d(a.c(this.b, paramd.q), paramd.o), paramd.m);
      Iterator<g.a> iterator = paramd.b.iterator();
      while (iterator.hasNext())
        b(iterator.next()); 
      Bundle bundle = paramd.D;
      if (bundle != null)
        this.g.putAll(bundle); 
      if (Build.VERSION.SDK_INT < 20) {
        if (paramd.z)
          this.g.putBoolean("android.support.localOnly", true); 
        String str = paramd.w;
        if (str != null) {
          Bundle bundle1;
          String str1;
          this.g.putString("android.support.groupKey", str);
          if (paramd.x) {
            bundle1 = this.g;
            str1 = "android.support.isGroupSummary";
          } else {
            bundle1 = this.g;
            str1 = "android.support.useSideChannel";
          } 
          bundle1.putBoolean(str1, true);
        } 
        str = paramd.y;
        if (str != null)
          this.g.putString("android.support.sortKey", str); 
      } 
      this.d = paramd.H;
      this.e = paramd.I;
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 17)
      b.a(this.b, paramd.n); 
    if (i >= 19 && i < 21) {
      List<String> list = e(f(paramd.c), paramd.V);
      if (list != null && !list.isEmpty())
        this.g.putStringArray("android.people", list.<String>toArray(new String[list.size()])); 
    } 
    if (i >= 20) {
      d.i(this.b, paramd.z);
      d.g(this.b, paramd.w);
      d.j(this.b, paramd.y);
      d.h(this.b, paramd.x);
      this.h = paramd.O;
    } 
    if (i >= 21) {
      List<String> list;
      e.b(this.b, paramd.C);
      e.c(this.b, paramd.E);
      e.f(this.b, paramd.F);
      e.d(this.b, paramd.G);
      e.e(this.b, notification.sound, notification.audioAttributes);
      if (i < 28) {
        list = e(f(paramd.c), paramd.V);
      } else {
        list = paramd.V;
      } 
      if (list != null && !list.isEmpty())
        for (String str : list)
          e.a(this.b, str);  
      this.i = paramd.J;
      if (paramd.d.size() > 0) {
        Bundle bundle2 = paramd.c().getBundle("android.car.EXTENSIONS");
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle2 = new Bundle(bundle1);
        Bundle bundle3 = new Bundle();
        for (i = 0; i < paramd.d.size(); i++)
          bundle3.putBundle(Integer.toString(i), i.b(paramd.d.get(i))); 
        bundle1.putBundle("invisible_actions", bundle3);
        bundle2.putBundle("invisible_actions", bundle3);
        paramd.c().putBundle("android.car.EXTENSIONS", bundle1);
        this.g.putBundle("android.car.EXTENSIONS", bundle2);
      } 
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Object object = paramd.U;
      if (object != null)
        f.b(this.b, object); 
    } 
    if (i >= 24) {
      c.a(this.b, paramd.D);
      g.e(this.b, paramd.s);
      RemoteViews remoteViews = paramd.H;
      if (remoteViews != null)
        g.c(this.b, remoteViews); 
      remoteViews = paramd.I;
      if (remoteViews != null)
        g.b(this.b, remoteViews); 
      remoteViews = paramd.J;
      if (remoteViews != null)
        g.d(this.b, remoteViews); 
    } 
    if (i >= 26) {
      h.b(this.b, paramd.L);
      h.e(this.b, paramd.r);
      h.f(this.b, paramd.M);
      h.g(this.b, paramd.N);
      h.d(this.b, paramd.O);
      if (paramd.B)
        h.c(this.b, paramd.A); 
      if (!TextUtils.isEmpty(paramd.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (k k : paramd.c)
        i.a(this.b, k.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      j.a(this.b, paramd.Q);
      j.b(this.b, g.c.a(paramd.R));
    } 
    if (i >= 31) {
      int j = paramd.P;
      if (j != 0)
        k.b(this.b, j); 
    } 
    if (paramd.T) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE;
      notification.defaults = j;
      j &= 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          d.g(this.b, "silent"); 
        h.d(this.b, this.h);
      } 
    } 
  }
  
  private void b(g.a parama) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      Notification.Action.Builder builder;
      Bundle bundle;
      IconCompat iconCompat = parama.e();
      boolean bool = false;
      if (i >= 23) {
        if (iconCompat != null) {
          Icon icon = iconCompat.o();
        } else {
          iconCompat = null;
        } 
        builder = f.a((Icon)iconCompat, parama.i(), parama.a());
      } else {
        if (builder != null) {
          i = builder.h();
        } else {
          i = 0;
        } 
        builder = d.e(i, parama.i(), parama.a());
      } 
      if (parama.f() != null) {
        RemoteInput[] arrayOfRemoteInput = m.b(parama.f());
        int j = arrayOfRemoteInput.length;
        for (i = bool; i < j; i++)
          d.c(builder, arrayOfRemoteInput[i]); 
      } 
      if (parama.d() != null) {
        bundle = new Bundle(parama.d());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
      i = Build.VERSION.SDK_INT;
      if (i >= 24)
        g.a(builder, parama.b()); 
      bundle.putInt("android.support.action.semanticAction", parama.g());
      if (i >= 28)
        i.b(builder, parama.g()); 
      if (i >= 29)
        j.c(builder, parama.k()); 
      if (i >= 31)
        k.a(builder, parama.j()); 
      bundle.putBoolean("android.support.action.showsUserInterface", parama.h());
      d.b(builder, bundle);
      d.a(this.b, d.d(builder));
      return;
    } 
    if (i >= 16)
      this.f.add(i.f(this.b, parama)); 
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    androidx.collection.b b = new androidx.collection.b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> f(List<k> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<k> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((k)iterator.next()).g()); 
    return arrayList;
  }
  
  private void g(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    int i = paramNotification.defaults & 0xFFFFFFFE;
    paramNotification.defaults = i;
    paramNotification.defaults = i & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/core/app/g$d;
    //   4: getfield p : Landroidx/core/app/g$e;
    //   7: astore_3
    //   8: aload_3
    //   9: ifnull -> 17
    //   12: aload_3
    //   13: aload_0
    //   14: invokevirtual b : (Landroidx/core/app/f;)V
    //   17: aload_3
    //   18: ifnull -> 30
    //   21: aload_3
    //   22: aload_0
    //   23: invokevirtual e : (Landroidx/core/app/f;)Landroid/widget/RemoteViews;
    //   26: astore_2
    //   27: goto -> 32
    //   30: aconst_null
    //   31: astore_2
    //   32: aload_0
    //   33: invokevirtual d : ()Landroid/app/Notification;
    //   36: astore #4
    //   38: aload_2
    //   39: ifnull -> 51
    //   42: aload #4
    //   44: aload_2
    //   45: putfield contentView : Landroid/widget/RemoteViews;
    //   48: goto -> 66
    //   51: aload_0
    //   52: getfield c : Landroidx/core/app/g$d;
    //   55: getfield H : Landroid/widget/RemoteViews;
    //   58: astore_2
    //   59: aload_2
    //   60: ifnull -> 66
    //   63: goto -> 42
    //   66: getstatic android/os/Build$VERSION.SDK_INT : I
    //   69: istore_1
    //   70: iload_1
    //   71: bipush #16
    //   73: if_icmplt -> 96
    //   76: aload_3
    //   77: ifnull -> 96
    //   80: aload_3
    //   81: aload_0
    //   82: invokevirtual d : (Landroidx/core/app/f;)Landroid/widget/RemoteViews;
    //   85: astore_2
    //   86: aload_2
    //   87: ifnull -> 96
    //   90: aload #4
    //   92: aload_2
    //   93: putfield bigContentView : Landroid/widget/RemoteViews;
    //   96: iload_1
    //   97: bipush #21
    //   99: if_icmplt -> 128
    //   102: aload_3
    //   103: ifnull -> 128
    //   106: aload_0
    //   107: getfield c : Landroidx/core/app/g$d;
    //   110: getfield p : Landroidx/core/app/g$e;
    //   113: aload_0
    //   114: invokevirtual f : (Landroidx/core/app/f;)Landroid/widget/RemoteViews;
    //   117: astore_2
    //   118: aload_2
    //   119: ifnull -> 128
    //   122: aload #4
    //   124: aload_2
    //   125: putfield headsUpContentView : Landroid/widget/RemoteViews;
    //   128: iload_1
    //   129: bipush #16
    //   131: if_icmplt -> 153
    //   134: aload_3
    //   135: ifnull -> 153
    //   138: aload #4
    //   140: invokestatic a : (Landroid/app/Notification;)Landroid/os/Bundle;
    //   143: astore_2
    //   144: aload_2
    //   145: ifnull -> 153
    //   148: aload_3
    //   149: aload_2
    //   150: invokevirtual a : (Landroid/os/Bundle;)V
    //   153: aload #4
    //   155: areturn
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return a.a(this.b); 
    if (i >= 24) {
      Notification notification = a.a(this.b);
      if (this.h != 0) {
        if (d.f(notification) != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (d.f(notification) != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 21) {
      c.a(this.b, this.g);
      Notification notification = a.a(this.b);
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      remoteViews = this.i;
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
      if (this.h != 0) {
        if (d.f(notification) != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (d.f(notification) != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 20) {
      c.a(this.b, this.g);
      Notification notification = a.a(this.b);
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      if (this.h != 0) {
        if (d.f(notification) != null && (notification.flags & 0x200) != 0 && this.h == 2)
          g(notification); 
        if (d.f(notification) != null && (notification.flags & 0x200) == 0 && this.h == 1)
          g(notification); 
      } 
      return notification;
    } 
    if (i >= 19) {
      SparseArray<Bundle> sparseArray = i.a(this.f);
      if (sparseArray != null)
        this.g.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      c.a(this.b, this.g);
      Notification notification = a.a(this.b);
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    if (i >= 16) {
      Notification notification = a.a(this.b);
      Bundle bundle1 = g.a(notification);
      Bundle bundle2 = new Bundle(this.g);
      for (String str : this.g.keySet()) {
        if (bundle1.containsKey(str))
          bundle2.remove(str); 
      } 
      bundle1.putAll(bundle2);
      SparseArray<Bundle> sparseArray = i.a(this.f);
      if (sparseArray != null)
        g.a(notification).putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      RemoteViews remoteViews = this.d;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.e;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    return this.b.getNotification();
  }
  
  static class a {
    static Notification a(Notification.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setPriority(param1Int);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return param1Builder.setSubText(param1CharSequence);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setUsesChronometer(param1Boolean);
    }
  }
  
  static class b {
    static Notification.Builder a(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setShowWhen(param1Boolean);
    }
  }
  
  static class c {
    static Notification.Builder a(Notification.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.setExtras(param1Bundle);
    }
  }
  
  static class d {
    static Notification.Builder a(Notification.Builder param1Builder, Notification.Action param1Action) {
      return param1Builder.addAction(param1Action);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, Bundle param1Bundle) {
      return param1Builder.addExtras(param1Bundle);
    }
    
    static Notification.Action.Builder c(Notification.Action.Builder param1Builder, RemoteInput param1RemoteInput) {
      return param1Builder.addRemoteInput(param1RemoteInput);
    }
    
    static Notification.Action d(Notification.Action.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static Notification.Action.Builder e(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Int, param1CharSequence, param1PendingIntent);
    }
    
    static String f(Notification param1Notification) {
      return param1Notification.getGroup();
    }
    
    static Notification.Builder g(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setGroup(param1String);
    }
    
    static Notification.Builder h(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setGroupSummary(param1Boolean);
    }
    
    static Notification.Builder i(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setLocalOnly(param1Boolean);
    }
    
    static Notification.Builder j(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setSortKey(param1String);
    }
  }
  
  static class e {
    static Notification.Builder a(Notification.Builder param1Builder, String param1String) {
      return param1Builder.addPerson(param1String);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setCategory(param1String);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setColor(param1Int);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, Notification param1Notification) {
      return param1Builder.setPublicVersion(param1Notification);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, Uri param1Uri, Object param1Object) {
      return param1Builder.setSound(param1Uri, (AudioAttributes)param1Object);
    }
    
    static Notification.Builder f(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setVisibility(param1Int);
    }
  }
  
  static class f {
    static Notification.Action.Builder a(Icon param1Icon, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      return new Notification.Action.Builder(param1Icon, param1CharSequence, param1PendingIntent);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, Object param1Object) {
      return param1Builder.setSmallIcon((Icon)param1Object);
    }
  }
  
  static class g {
    static Notification.Action.Builder a(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAllowGeneratedReplies(param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomBigContentView(param1RemoteViews);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomContentView(param1RemoteViews);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, RemoteViews param1RemoteViews) {
      return param1Builder.setCustomHeadsUpContentView(param1RemoteViews);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, CharSequence[] param1ArrayOfCharSequence) {
      return param1Builder.setRemoteInputHistory(param1ArrayOfCharSequence);
    }
  }
  
  static class h {
    static Notification.Builder a(Context param1Context, String param1String) {
      return new Notification.Builder(param1Context, param1String);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setBadgeIconType(param1Int);
    }
    
    static Notification.Builder c(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setColorized(param1Boolean);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setGroupAlertBehavior(param1Int);
    }
    
    static Notification.Builder e(Notification.Builder param1Builder, CharSequence param1CharSequence) {
      return param1Builder.setSettingsText(param1CharSequence);
    }
    
    static Notification.Builder f(Notification.Builder param1Builder, String param1String) {
      return param1Builder.setShortcutId(param1String);
    }
    
    static Notification.Builder g(Notification.Builder param1Builder, long param1Long) {
      return param1Builder.setTimeoutAfter(param1Long);
    }
  }
  
  static class i {
    static Notification.Builder a(Notification.Builder param1Builder, Person param1Person) {
      return param1Builder.addPerson(param1Person);
    }
    
    static Notification.Action.Builder b(Notification.Action.Builder param1Builder, int param1Int) {
      return param1Builder.setSemanticAction(param1Int);
    }
  }
  
  static class j {
    static Notification.Builder a(Notification.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAllowSystemGeneratedContextualActions(param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, Notification.BubbleMetadata param1BubbleMetadata) {
      return param1Builder.setBubbleMetadata(param1BubbleMetadata);
    }
    
    static Notification.Action.Builder c(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setContextual(param1Boolean);
    }
    
    static Notification.Builder d(Notification.Builder param1Builder, Object param1Object) {
      return param1Builder.setLocusId((LocusId)param1Object);
    }
  }
  
  static class k {
    static Notification.Action.Builder a(Notification.Action.Builder param1Builder, boolean param1Boolean) {
      return param1Builder.setAuthenticationRequired(param1Boolean);
    }
    
    static Notification.Builder b(Notification.Builder param1Builder, int param1Int) {
      return param1Builder.setForegroundServiceBehavior(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */