package androidx.core.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.collection.f;
import androidx.core.view.b;
import androidx.lifecycle.e;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.u;

public class d extends Activity implements j, b.a {
  private f<Class<Object>, Object> a = new f();
  
  private k b = new k(this);
  
  public e a() {
    return (e)this.b;
  }
  
  public boolean c(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : b.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    u.e(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.b.j(e.b.c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */