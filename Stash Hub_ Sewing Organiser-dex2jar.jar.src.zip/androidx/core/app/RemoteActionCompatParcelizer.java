package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.a;
import c0.a;

public class RemoteActionCompatParcelizer {
  public static RemoteActionCompat read(a parama) {
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
    remoteActionCompat.a = (IconCompat)parama.v((a)remoteActionCompat.a, 1);
    remoteActionCompat.b = parama.l(remoteActionCompat.b, 2);
    remoteActionCompat.c = parama.l(remoteActionCompat.c, 3);
    remoteActionCompat.d = (PendingIntent)parama.r((Parcelable)remoteActionCompat.d, 4);
    remoteActionCompat.e = parama.h(remoteActionCompat.e, 5);
    remoteActionCompat.f = parama.h(remoteActionCompat.f, 6);
    return remoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, a parama) {
    parama.x(false, false);
    parama.M((a)paramRemoteActionCompat.a, 1);
    parama.D(paramRemoteActionCompat.b, 2);
    parama.D(paramRemoteActionCompat.c, 3);
    parama.H((Parcelable)paramRemoteActionCompat.d, 4);
    parama.z(paramRemoteActionCompat.e, 5);
    parama.z(paramRemoteActionCompat.f, 6);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\RemoteActionCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */