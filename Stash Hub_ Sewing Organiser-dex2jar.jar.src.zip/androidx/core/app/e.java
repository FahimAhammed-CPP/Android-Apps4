package androidx.core.app;

import android.content.res.Configuration;

public final class e {
  private final boolean a;
  
  private final Configuration b;
  
  public e(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  public e(boolean paramBoolean, Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */