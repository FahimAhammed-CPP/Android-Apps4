package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

public final class m {
  static RemoteInput a(m paramm) {
    return a.b(paramm);
  }
  
  static RemoteInput[] b(m[] paramArrayOfm) {
    if (paramArrayOfm == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfm.length];
    for (int i = 0; i < paramArrayOfm.length; i++)
      arrayOfRemoteInput[i] = a(paramArrayOfm[i]); 
    return arrayOfRemoteInput;
  }
  
  static class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(m param1m) {
      throw null;
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */