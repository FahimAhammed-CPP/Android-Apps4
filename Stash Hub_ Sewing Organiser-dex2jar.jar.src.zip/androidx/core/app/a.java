package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.core.content.a;
import java.util.Arrays;
import java.util.HashSet;

public class a extends a {
  private static g a;
  
  public static g a() {
    return a;
  }
  
  public static void b(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    String[] arrayOfString;
    g g1 = a;
    if (g1 != null && g1.b(paramActivity, paramArrayOfString, paramInt))
      return; 
    HashSet<Integer> hashSet = new HashSet();
    int j = 0;
    int i = 0;
    while (i < paramArrayOfString.length) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        if (!androidx.core.os.a.c() && TextUtils.equals(paramArrayOfString[i], "android.permission.POST_NOTIFICATIONS"))
          hashSet.add(Integer.valueOf(i)); 
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    i = hashSet.size();
    if (i > 0) {
      arrayOfString = new String[paramArrayOfString.length - i];
    } else {
      arrayOfString = paramArrayOfString;
    } 
    if (i > 0) {
      if (i == paramArrayOfString.length)
        return; 
      int k = 0;
      i = j;
      while (i < paramArrayOfString.length) {
        j = k;
        if (!hashSet.contains(Integer.valueOf(i))) {
          arrayOfString[k] = paramArrayOfString[i];
          j = k + 1;
        } 
        i++;
        k = j;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof h)
        ((h)stringBuilder).b(paramInt); 
      c.b((Activity)stringBuilder, paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof f)
      (new Handler(Looper.getMainLooper())).post(new a(arrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public static boolean c(Activity paramActivity, String paramString) {
    if (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString))
      return false; 
    int i = Build.VERSION.SDK_INT;
    return (i >= 32) ? e.a(paramActivity, paramString) : ((i == 31) ? d.b(paramActivity, paramString) : ((i >= 23) ? c.c(paramActivity, paramString) : false));
  }
  
  public static void d(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      b.b(paramActivity, paramIntent, paramInt, paramBundle);
      return;
    } 
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }
  
  class a implements Runnable {
    a(a this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.a.length];
      PackageManager packageManager = this.b.getPackageManager();
      String str = this.b.getPackageName();
      int j = this.a.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.a[i], str); 
      ((a.f)this.b).onRequestPermissionsResult(this.c, this.a, arrayOfInt);
    }
  }
  
  static class b {
    static void a(Activity param1Activity) {
      param1Activity.finishAffinity();
    }
    
    static void b(Activity param1Activity, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      param1Activity.startActivityForResult(param1Intent, param1Int, param1Bundle);
    }
    
    static void c(Activity param1Activity, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) {
      param1Activity.startIntentSenderForResult(param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
  }
  
  static class c {
    static void a(Object param1Object) {
      ((SharedElementCallback.OnSharedElementsReadyListener)param1Object).onSharedElementsReady();
    }
    
    static void b(Activity param1Activity, String[] param1ArrayOfString, int param1Int) {
      param1Activity.requestPermissions(param1ArrayOfString, param1Int);
    }
    
    static boolean c(Activity param1Activity, String param1String) {
      return param1Activity.shouldShowRequestPermissionRationale(param1String);
    }
  }
  
  static class d {
    static boolean a(Activity param1Activity) {
      return param1Activity.isLaunchedFromBubble();
    }
    
    static boolean b(Activity param1Activity, String param1String) {
      try {
        PackageManager packageManager = param1Activity.getApplication().getPackageManager();
        return ((Boolean)PackageManager.class.getMethod("shouldShowRequestPermissionRationale", new Class[] { String.class }).invoke(packageManager, new Object[] { param1String })).booleanValue();
      } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException noSuchMethodException) {
        return param1Activity.shouldShowRequestPermissionRationale(param1String);
      } 
    }
  }
  
  static class e {
    static boolean a(Activity param1Activity, String param1String) {
      return param1Activity.shouldShowRequestPermissionRationale(param1String);
    }
  }
  
  public static interface f {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface g {
    boolean a(Activity param1Activity, int param1Int1, int param1Int2, Intent param1Intent);
    
    boolean b(Activity param1Activity, String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface h {
    void b(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */