package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.util.e;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a = -1;
  
  Object b;
  
  public byte[] c = null;
  
  public Parcelable d = null;
  
  public int e = 0;
  
  public int f = 0;
  
  public ColorStateList g = null;
  
  PorterDuff.Mode h = k;
  
  public String i = null;
  
  public String j;
  
  public IconCompat() {}
  
  IconCompat(int paramInt) {
    this.a = paramInt;
  }
  
  public static IconCompat a(Icon paramIcon) {
    return a.a(paramIcon);
  }
  
  static Bitmap b(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate(-(paramBitmap.getWidth() - i) / 2.0F, -(paramBitmap.getHeight() - i) / 2.0F);
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat c(Uri paramUri) {
    androidx.core.util.d.c(paramUri);
    return d(paramUri.toString());
  }
  
  public static IconCompat d(String paramString) {
    androidx.core.util.d.c(paramString);
    IconCompat iconCompat = new IconCompat(6);
    iconCompat.b = paramString;
    return iconCompat;
  }
  
  public static IconCompat e(Uri paramUri) {
    androidx.core.util.d.c(paramUri);
    return f(paramUri.toString());
  }
  
  public static IconCompat f(String paramString) {
    androidx.core.util.d.c(paramString);
    IconCompat iconCompat = new IconCompat(4);
    iconCompat.b = paramString;
    return iconCompat;
  }
  
  public static IconCompat g(Resources paramResources, String paramString, int paramInt) {
    androidx.core.util.d.c(paramString);
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      if (paramResources != null)
        try {
          iconCompat.b = paramResources.getResourceName(paramInt);
          iconCompat.j = paramString;
          return iconCompat;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw new IllegalArgumentException("Icon resource cannot be found");
        }  
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  private static String q(int paramInt) {
    switch (paramInt) {
      default:
        return "UNKNOWN";
      case 6:
        return "URI_MASKABLE";
      case 5:
        return "BITMAP_MASKABLE";
      case 4:
        return "URI";
      case 3:
        return "DATA";
      case 2:
        return "RESOURCE";
      case 1:
        break;
    } 
    return "BITMAP";
  }
  
  public int h() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.b(this.b); 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String i() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.c(this.b); 
    if (i == 2) {
      String str = this.j;
      return (str == null || TextUtils.isEmpty(str)) ? ((String)this.b).split(":", -1)[0] : this.j;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int j() {
    int j = this.a;
    int i = j;
    if (j == -1) {
      i = j;
      if (Build.VERSION.SDK_INT >= 23)
        i = a.d(this.b); 
    } 
    return i;
  }
  
  public Uri k() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.e(this.b); 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public InputStream l(Context paramContext) {
    StringBuilder stringBuilder;
    Uri uri = k();
    String str = uri.getScheme();
    if ("content".equals(str) || "file".equals(str)) {
      try {
        return paramContext.getContentResolver().openInputStream(uri);
      } catch (Exception null) {
        stringBuilder = new StringBuilder();
        str = "Unable to load image from URI: ";
      } 
      stringBuilder.append(str);
      stringBuilder.append(uri);
      Log.w("IconCompat", stringBuilder.toString(), exception);
      return null;
    } 
    try {
      return new FileInputStream(new File((String)this.b));
    } catch (FileNotFoundException exception) {
      stringBuilder = new StringBuilder();
      str = "Unable to load image from path: ";
    } 
    stringBuilder.append(str);
    stringBuilder.append(uri);
    Log.w("IconCompat", stringBuilder.toString(), exception);
    return null;
  }
  
  public void m() {
    String str;
    Parcelable parcelable2;
    byte[] arrayOfByte;
    Parcelable parcelable1;
    this.h = PorterDuff.Mode.valueOf(this.i);
    switch (this.a) {
      default:
        return;
      case 3:
        this.b = this.c;
        return;
      case 2:
      case 4:
      case 6:
        str = new String(this.c, Charset.forName("UTF-16"));
        this.b = str;
        if (this.a == 2 && this.j == null) {
          this.j = str.split(":", -1)[0];
          return;
        } 
        return;
      case 1:
      case 5:
        parcelable2 = this.d;
        if (parcelable2 != null)
          break; 
        arrayOfByte = this.c;
        this.b = arrayOfByte;
        this.a = 3;
        this.e = 0;
        this.f = arrayOfByte.length;
        return;
      case -1:
        parcelable1 = this.d;
        if (parcelable1 != null)
          break; 
        throw new IllegalArgumentException("Invalid icon");
    } 
    this.b = parcelable1;
  }
  
  public void n(boolean paramBoolean) {
    this.i = this.h.name();
    switch (this.a) {
      default:
        return;
      case 4:
      case 6:
        this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
        return;
      case 3:
        this.c = (byte[])this.b;
        return;
      case 2:
        this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
        return;
      case 1:
      case 5:
        if (paramBoolean) {
          Bitmap bitmap = (Bitmap)this.b;
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
          this.c = byteArrayOutputStream.toByteArray();
          return;
        } 
        break;
      case -1:
        if (!paramBoolean)
          break; 
        throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
    } 
    this.d = (Parcelable)this.b;
  }
  
  @Deprecated
  public Icon o() {
    return p(null);
  }
  
  public Icon p(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 23)
      return a.g(this, paramContext); 
    throw new UnsupportedOperationException("This method is only supported on API level 23+");
  }
  
  public String toString() {
    int i;
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    stringBuilder.append(q(this.a));
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          i = this.f;
        } else {
          break;
        } 
        stringBuilder.append(i);
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(h()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        i = ((Bitmap)this.b).getHeight();
        stringBuilder.append(i);
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  static class a {
    static IconCompat a(Object param1Object) {
      e.b(param1Object);
      int i = d(param1Object);
      if (i != 2) {
        if (i != 4) {
          if (i != 6) {
            IconCompat iconCompat = new IconCompat(-1);
            iconCompat.b = param1Object;
            return iconCompat;
          } 
          return IconCompat.c(e(param1Object));
        } 
        return IconCompat.e(e(param1Object));
      } 
      return IconCompat.g(null, c(param1Object), b(param1Object));
    }
    
    static int b(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.a(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getResId", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        return 0;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        return 0;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    }
    
    static String c(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.b(param1Object); 
      try {
        return (String)param1Object.getClass().getMethod("getResPackage", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
        return null;
      } 
    }
    
    static int d(Object param1Object) {
      StringBuilder stringBuilder;
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.c(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getType", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        stringBuilder = new StringBuilder();
      } catch (InvocationTargetException invocationTargetException) {
        stringBuilder = new StringBuilder();
      } catch (NoSuchMethodException noSuchMethodException) {
        stringBuilder = new StringBuilder();
      } 
      stringBuilder.append("Unable to get icon type ");
      stringBuilder.append(param1Object);
      Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
      return -1;
    }
    
    static Uri e(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.d(param1Object); 
      try {
        return (Uri)param1Object.getClass().getMethod("getUri", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    }
    
    static Drawable f(Icon param1Icon, Context param1Context) {
      return param1Icon.loadDrawable(param1Context);
    }
    
    static Icon g(IconCompat param1IconCompat, Context param1Context) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : I
      //   4: tableswitch default -> 52, -1 -> 325, 0 -> 52, 1 -> 277, 2 -> 262, 3 -> 240, 4 -> 226, 5 -> 185, 6 -> 62
      //   52: new java/lang/IllegalArgumentException
      //   55: dup
      //   56: ldc 'Unknown type'
      //   58: invokespecial <init> : (Ljava/lang/String;)V
      //   61: athrow
      //   62: getstatic android/os/Build$VERSION.SDK_INT : I
      //   65: istore_2
      //   66: iload_2
      //   67: bipush #30
      //   69: if_icmplt -> 83
      //   72: aload_0
      //   73: invokevirtual k : ()Landroid/net/Uri;
      //   76: invokestatic a : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
      //   79: astore_1
      //   80: goto -> 290
      //   83: aload_1
      //   84: ifnull -> 149
      //   87: aload_0
      //   88: aload_1
      //   89: invokevirtual l : (Landroid/content/Context;)Ljava/io/InputStream;
      //   92: astore_1
      //   93: aload_1
      //   94: ifnull -> 113
      //   97: aload_1
      //   98: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
      //   101: astore_1
      //   102: aload_1
      //   103: astore_3
      //   104: iload_2
      //   105: bipush #26
      //   107: if_icmplt -> 217
      //   110: goto -> 201
      //   113: new java/lang/StringBuilder
      //   116: dup
      //   117: invokespecial <init> : ()V
      //   120: astore_1
      //   121: aload_1
      //   122: ldc 'Cannot load adaptive icon from uri: '
      //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   127: pop
      //   128: aload_1
      //   129: aload_0
      //   130: invokevirtual k : ()Landroid/net/Uri;
      //   133: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   136: pop
      //   137: new java/lang/IllegalStateException
      //   140: dup
      //   141: aload_1
      //   142: invokevirtual toString : ()Ljava/lang/String;
      //   145: invokespecial <init> : (Ljava/lang/String;)V
      //   148: athrow
      //   149: new java/lang/StringBuilder
      //   152: dup
      //   153: invokespecial <init> : ()V
      //   156: astore_1
      //   157: aload_1
      //   158: ldc 'Context is required to resolve the file uri of the icon: '
      //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   163: pop
      //   164: aload_1
      //   165: aload_0
      //   166: invokevirtual k : ()Landroid/net/Uri;
      //   169: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   172: pop
      //   173: new java/lang/IllegalArgumentException
      //   176: dup
      //   177: aload_1
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: invokespecial <init> : (Ljava/lang/String;)V
      //   184: athrow
      //   185: getstatic android/os/Build$VERSION.SDK_INT : I
      //   188: bipush #26
      //   190: if_icmplt -> 209
      //   193: aload_0
      //   194: getfield b : Ljava/lang/Object;
      //   197: checkcast android/graphics/Bitmap
      //   200: astore_1
      //   201: aload_1
      //   202: invokestatic b : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   205: astore_1
      //   206: goto -> 290
      //   209: aload_0
      //   210: getfield b : Ljava/lang/Object;
      //   213: checkcast android/graphics/Bitmap
      //   216: astore_3
      //   217: aload_3
      //   218: iconst_0
      //   219: invokestatic b : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
      //   222: astore_1
      //   223: goto -> 285
      //   226: aload_0
      //   227: getfield b : Ljava/lang/Object;
      //   230: checkcast java/lang/String
      //   233: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
      //   236: astore_1
      //   237: goto -> 290
      //   240: aload_0
      //   241: getfield b : Ljava/lang/Object;
      //   244: checkcast [B
      //   247: aload_0
      //   248: getfield e : I
      //   251: aload_0
      //   252: getfield f : I
      //   255: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
      //   258: astore_1
      //   259: goto -> 290
      //   262: aload_0
      //   263: invokevirtual i : ()Ljava/lang/String;
      //   266: aload_0
      //   267: getfield e : I
      //   270: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
      //   273: astore_1
      //   274: goto -> 290
      //   277: aload_0
      //   278: getfield b : Ljava/lang/Object;
      //   281: checkcast android/graphics/Bitmap
      //   284: astore_1
      //   285: aload_1
      //   286: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   289: astore_1
      //   290: aload_0
      //   291: getfield g : Landroid/content/res/ColorStateList;
      //   294: astore_3
      //   295: aload_3
      //   296: ifnull -> 305
      //   299: aload_1
      //   300: aload_3
      //   301: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
      //   304: pop
      //   305: aload_0
      //   306: getfield h : Landroid/graphics/PorterDuff$Mode;
      //   309: astore_0
      //   310: aload_0
      //   311: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
      //   314: if_acmpeq -> 323
      //   317: aload_1
      //   318: aload_0
      //   319: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
      //   322: pop
      //   323: aload_1
      //   324: areturn
      //   325: aload_0
      //   326: getfield b : Ljava/lang/Object;
      //   329: checkcast android/graphics/drawable/Icon
      //   332: areturn
    }
  }
  
  static class b {
    static Drawable a(Drawable param1Drawable1, Drawable param1Drawable2) {
      return (Drawable)new AdaptiveIconDrawable(param1Drawable1, param1Drawable2);
    }
    
    static Icon b(Bitmap param1Bitmap) {
      return Icon.createWithAdaptiveBitmap(param1Bitmap);
    }
  }
  
  static class c {
    static int a(Object param1Object) {
      return ((Icon)param1Object).getResId();
    }
    
    static String b(Object param1Object) {
      return ((Icon)param1Object).getResPackage();
    }
    
    static int c(Object param1Object) {
      return ((Icon)param1Object).getType();
    }
    
    static Uri d(Object param1Object) {
      return ((Icon)param1Object).getUri();
    }
  }
  
  static class d {
    static Icon a(Uri param1Uri) {
      return Icon.createWithAdaptiveBitmapContentUri(param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */