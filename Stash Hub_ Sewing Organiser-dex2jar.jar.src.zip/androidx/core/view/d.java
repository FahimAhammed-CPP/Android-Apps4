package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class d {
  private final Runnable a;
  
  private final CopyOnWriteArrayList<e> b = new CopyOnWriteArrayList<e>();
  
  private final Map<e, Object> c = new HashMap<e, Object>();
  
  public d(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a(Menu paramMenu, MenuInflater paramMenuInflater) {
    Iterator<e> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((e)iterator.next()).c(paramMenu, paramMenuInflater); 
  }
  
  public void b(Menu paramMenu) {
    Iterator<e> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((e)iterator.next()).b(paramMenu); 
  }
  
  public boolean c(MenuItem paramMenuItem) {
    Iterator<e> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      if (((e)iterator.next()).a(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void d(Menu paramMenu) {
    Iterator<e> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((e)iterator.next()).d(paramMenu); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\view\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */