package androidx.core.view;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class m {
  public static final m b;
  
  private final l a;
  
  static {
    m m1;
    if (Build.VERSION.SDK_INT >= 30) {
      m1 = k.q;
    } else {
      m1 = l.b;
    } 
    b = m1;
  }
  
  private m(WindowInsets paramWindowInsets) {
    g g;
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      g = new k(this, paramWindowInsets);
    } else {
      j j;
      if (i >= 29) {
        j = new j(this, (WindowInsets)g);
      } else {
        i i1;
        if (i >= 28) {
          i1 = new i(this, (WindowInsets)j);
        } else {
          h h;
          if (i >= 21) {
            h = new h(this, (WindowInsets)i1);
          } else if (i >= 20) {
            g = new g(this, (WindowInsets)h);
          } else {
            this.a = new l(this);
            return;
          } 
        } 
      } 
    } 
    this.a = g;
  }
  
  public m(m paramm) {
    if (paramm != null) {
      l l1;
      l l2 = paramm.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l2 instanceof k) {
        l1 = new k(this, (k)l2);
      } else if (i >= 29 && l2 instanceof j) {
        l1 = new j(this, (j)l2);
      } else if (i >= 28 && l2 instanceof i) {
        l1 = new i(this, (i)l2);
      } else if (i >= 21 && l2 instanceof h) {
        l1 = new h(this, (h)l2);
      } else if (i >= 20 && l2 instanceof g) {
        l1 = new g(this, (g)l2);
      } else {
        l1 = new l(this);
      } 
      this.a = l1;
      l2.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  public static m n(WindowInsets paramWindowInsets) {
    return o(paramWindowInsets, null);
  }
  
  public static m o(WindowInsets paramWindowInsets, View paramView) {
    m m1 = new m((WindowInsets)androidx.core.util.e.b(paramWindowInsets));
    if (paramView != null && j.h(paramView)) {
      m1.k(j.f(paramView));
      m1.d(paramView.getRootView());
    } 
    return m1;
  }
  
  @Deprecated
  public m a() {
    return this.a.a();
  }
  
  @Deprecated
  public m b() {
    return this.a.b();
  }
  
  @Deprecated
  public m c() {
    return this.a.c();
  }
  
  void d(View paramView) {
    this.a.d(paramView);
  }
  
  public a e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof m))
      return false; 
    paramObject = paramObject;
    return androidx.core.util.d.a(this.a, ((m)paramObject).a);
  }
  
  public androidx.core.graphics.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  public androidx.core.graphics.b g() {
    return this.a.i();
  }
  
  public boolean h(int paramInt) {
    return this.a.o(paramInt);
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  void i(androidx.core.graphics.b[] paramArrayOfb) {
    this.a.p(paramArrayOfb);
  }
  
  void j(androidx.core.graphics.b paramb) {
    this.a.q(paramb);
  }
  
  void k(m paramm) {
    this.a.r(paramm);
  }
  
  void l(androidx.core.graphics.b paramb) {
    this.a.s(paramb);
  }
  
  public WindowInsets m() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  static class a {
    private static Field a;
    
    private static Field b;
    
    private static Field c;
    
    private static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static m a(View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              m m = (new m.b()).b(androidx.core.graphics.b.c(rect)).c(androidx.core.graphics.b.c((Rect)object)).a();
              m.k(m);
              m.d(param1View.getRootView());
              return m;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    private final m.f a;
    
    public b() {
      m.f f1;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        f1 = new m.e();
      } else if (i >= 29) {
        f1 = new m.d();
      } else if (i >= 20) {
        f1 = new m.c();
      } else {
        f1 = new m.f();
      } 
      this.a = f1;
    }
    
    public m a() {
      return this.a.b();
    }
    
    @Deprecated
    public b b(androidx.core.graphics.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    public b c(androidx.core.graphics.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  private static class c extends f {
    private static Field e;
    
    private static boolean f = false;
    
    private static Constructor<WindowInsets> g;
    
    private static boolean h = false;
    
    private WindowInsets c = h();
    
    private androidx.core.graphics.b d;
    
    private static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    m b() {
      a();
      m m = m.n(this.c);
      m.i(this.b);
      m.l(this.d);
      return m;
    }
    
    void d(androidx.core.graphics.b param1b) {
      this.d = param1b;
    }
    
    void f(androidx.core.graphics.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  private static class d extends f {
    final WindowInsets.Builder c = new WindowInsets.Builder();
    
    m b() {
      a();
      m m = m.n(this.c.build());
      m.i(this.b);
      return m;
    }
    
    void c(androidx.core.graphics.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    void d(androidx.core.graphics.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    void e(androidx.core.graphics.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    void f(androidx.core.graphics.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    void g(androidx.core.graphics.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  private static class e extends d {}
  
  private static class f {
    private final m a;
    
    androidx.core.graphics.b[] b;
    
    f() {
      this(new m(null));
    }
    
    f(m param1m) {
      this.a = param1m;
    }
    
    protected final void a() {
      androidx.core.graphics.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        androidx.core.graphics.b b3 = arrayOfB[m.m.b(1)];
        androidx.core.graphics.b b2 = this.b[m.m.b(2)];
        androidx.core.graphics.b b1 = b2;
        if (b2 == null)
          b1 = this.a.f(2); 
        b2 = b3;
        if (b3 == null)
          b2 = this.a.f(1); 
        f(androidx.core.graphics.b.a(b2, b1));
        b1 = this.b[m.m.b(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[m.m.b(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[m.m.b(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    m b() {
      a();
      return this.a;
    }
    
    void c(androidx.core.graphics.b param1b) {}
    
    void d(androidx.core.graphics.b param1b) {}
    
    void e(androidx.core.graphics.b param1b) {}
    
    void f(androidx.core.graphics.b param1b) {}
    
    void g(androidx.core.graphics.b param1b) {}
  }
  
  private static class g extends l {
    private static boolean h = false;
    
    private static Method i;
    
    private static Class<?> j;
    
    private static Field k;
    
    private static Field l;
    
    final WindowInsets c;
    
    private androidx.core.graphics.b[] d;
    
    private androidx.core.graphics.b e = null;
    
    private m f;
    
    androidx.core.graphics.b g;
    
    g(m param1m, WindowInsets param1WindowInsets) {
      super(param1m);
      this.c = param1WindowInsets;
    }
    
    g(m param1m, g param1g) {
      this(param1m, new WindowInsets(param1g.c));
    }
    
    private androidx.core.graphics.b t(int param1Int, boolean param1Boolean) {
      androidx.core.graphics.b b1 = androidx.core.graphics.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = androidx.core.graphics.b.a(b1, u(i, param1Boolean)); 
      } 
      return b1;
    }
    
    private androidx.core.graphics.b v() {
      m m1 = this.f;
      return (m1 != null) ? m1.g() : androidx.core.graphics.b.e;
    }
    
    private androidx.core.graphics.b w(View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          y(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && j != null) {
          if (k == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = l.get(object);
            Rect rect = (Rect)k.get(object);
            object = stringBuilder;
            if (rect != null)
              object = androidx.core.graphics.b.c(rect); 
            return (androidx.core.graphics.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
    
    private static void y() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        j = clazz;
        k = clazz.getDeclaredField("mVisibleInsets");
        l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
        k.setAccessible(true);
        l.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    void d(View param1View) {
      androidx.core.graphics.b b2 = w(param1View);
      androidx.core.graphics.b b1 = b2;
      if (b2 == null)
        b1 = androidx.core.graphics.b.e; 
      q(b1);
    }
    
    void e(m param1m) {
      param1m.k(this.f);
      param1m.j(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    public androidx.core.graphics.b g(int param1Int) {
      return t(param1Int, false);
    }
    
    final androidx.core.graphics.b k() {
      if (this.e == null)
        this.e = androidx.core.graphics.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    boolean n() {
      return this.c.isRound();
    }
    
    boolean o(int param1Int) {
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0 && !x(i))
          return false; 
      } 
      return true;
    }
    
    public void p(androidx.core.graphics.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    void q(androidx.core.graphics.b param1b) {
      this.g = param1b;
    }
    
    void r(m param1m) {
      this.f = param1m;
    }
    
    protected androidx.core.graphics.b u(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        androidx.core.graphics.b b1;
        m m1 = null;
        m m2 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  a a;
                  if (param1Int != 128)
                    return androidx.core.graphics.b.e; 
                  m1 = this.f;
                  if (m1 != null) {
                    a = m1.e();
                  } else {
                    a = f();
                  } 
                  return (a != null) ? androidx.core.graphics.b.b(a.b(), a.d(), a.c(), a.a()) : androidx.core.graphics.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          androidx.core.graphics.b[] arrayOfB = this.d;
          m1 = m2;
          if (arrayOfB != null)
            b1 = arrayOfB[m.m.b(8)]; 
          if (b1 != null)
            return b1; 
          androidx.core.graphics.b b3 = k();
          b1 = v();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(androidx.core.graphics.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          } 
          return androidx.core.graphics.b.e;
        } 
        if (param1Boolean) {
          b1 = v();
          androidx.core.graphics.b b3 = i();
          return androidx.core.graphics.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        androidx.core.graphics.b b2 = k();
        m m3 = this.f;
        if (m3 != null)
          b1 = m3.g(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return androidx.core.graphics.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? androidx.core.graphics.b.b(0, Math.max((v()).b, (k()).b), 0, 0) : androidx.core.graphics.b.b(0, (k()).b, 0, 0);
    }
    
    protected boolean x(int param1Int) {
      if (param1Int != 1 && param1Int != 2)
        if (param1Int != 4) {
          if (param1Int != 8 && param1Int != 128)
            return true; 
        } else {
          return false;
        }  
      return u(param1Int, false).equals(androidx.core.graphics.b.e) ^ true;
    }
  }
  
  private static class h extends g {
    private androidx.core.graphics.b m = null;
    
    h(m param1m, WindowInsets param1WindowInsets) {
      super(param1m, param1WindowInsets);
    }
    
    h(m param1m, h param1h) {
      super(param1m, param1h);
      this.m = param1h.m;
    }
    
    m b() {
      return m.n(this.c.consumeStableInsets());
    }
    
    m c() {
      return m.n(this.c.consumeSystemWindowInsets());
    }
    
    final androidx.core.graphics.b i() {
      if (this.m == null)
        this.m = androidx.core.graphics.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.m;
    }
    
    boolean m() {
      return this.c.isConsumed();
    }
    
    public void s(androidx.core.graphics.b param1b) {
      this.m = param1b;
    }
  }
  
  private static class i extends h {
    i(m param1m, WindowInsets param1WindowInsets) {
      super(param1m, param1WindowInsets);
    }
    
    i(m param1m, i param1i) {
      super(param1m, param1i);
    }
    
    m a() {
      return m.n(this.c.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((m.g)param1Object).c) && Objects.equals(this.g, ((m.g)param1Object).g));
    }
    
    a f() {
      return a.e(this.c.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  private static class j extends i {
    private androidx.core.graphics.b n = null;
    
    private androidx.core.graphics.b o = null;
    
    private androidx.core.graphics.b p = null;
    
    j(m param1m, WindowInsets param1WindowInsets) {
      super(param1m, param1WindowInsets);
    }
    
    j(m param1m, j param1j) {
      super(param1m, param1j);
    }
    
    androidx.core.graphics.b h() {
      if (this.o == null)
        this.o = androidx.core.graphics.b.d(this.c.getMandatorySystemGestureInsets()); 
      return this.o;
    }
    
    androidx.core.graphics.b j() {
      if (this.n == null)
        this.n = androidx.core.graphics.b.d(this.c.getSystemGestureInsets()); 
      return this.n;
    }
    
    androidx.core.graphics.b l() {
      if (this.p == null)
        this.p = androidx.core.graphics.b.d(this.c.getTappableElementInsets()); 
      return this.p;
    }
    
    public void s(androidx.core.graphics.b param1b) {}
  }
  
  private static class k extends j {
    static final m q = m.n(WindowInsets.CONSUMED);
    
    k(m param1m, WindowInsets param1WindowInsets) {
      super(param1m, param1WindowInsets);
    }
    
    k(m param1m, k param1k) {
      super(param1m, param1k);
    }
    
    final void d(View param1View) {}
    
    public androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.d(this.c.getInsets(m.n.a(param1Int)));
    }
    
    public boolean o(int param1Int) {
      return this.c.isVisible(m.n.a(param1Int));
    }
  }
  
  private static class l {
    static final m b = (new m.b()).a().a().b().c();
    
    final m a;
    
    l(m param1m) {
      this.a = param1m;
    }
    
    m a() {
      return this.a;
    }
    
    m b() {
      return this.a;
    }
    
    m c() {
      return this.a;
    }
    
    void d(View param1View) {}
    
    void e(m param1m) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (n() == param1Object.n() && m() == param1Object.m() && androidx.core.util.d.a(k(), param1Object.k()) && androidx.core.util.d.a(i(), param1Object.i()) && androidx.core.util.d.a(f(), param1Object.f()));
    }
    
    a f() {
      return null;
    }
    
    androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b h() {
      return k();
    }
    
    public int hashCode() {
      return androidx.core.util.d.b(new Object[] { Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), f() });
    }
    
    androidx.core.graphics.b i() {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b j() {
      return k();
    }
    
    androidx.core.graphics.b k() {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b l() {
      return k();
    }
    
    boolean m() {
      return false;
    }
    
    boolean n() {
      return false;
    }
    
    boolean o(int param1Int) {
      return true;
    }
    
    public void p(androidx.core.graphics.b[] param1ArrayOfb) {}
    
    void q(androidx.core.graphics.b param1b) {}
    
    void r(m param1m) {}
    
    public void s(androidx.core.graphics.b param1b) {}
  }
  
  public static final class m {
    public static int a() {
      return 8;
    }
    
    static int b(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
  }
  
  private static final class n {
    static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\view\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */