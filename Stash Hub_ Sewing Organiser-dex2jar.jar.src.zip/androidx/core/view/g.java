package androidx.core.view;

public interface g {}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\view\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */