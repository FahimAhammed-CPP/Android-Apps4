package androidx.core.os;

import android.os.LocaleList;
import java.util.Locale;

final class k implements j {
  private final LocaleList a;
  
  k(Object paramObject) {
    this.a = (LocaleList)paramObject;
  }
  
  public Object a() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    return this.a.equals(((j)paramObject).a());
  }
  
  public Locale get(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\os\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */