package androidx.core.os;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import java.io.Serializable;
import kotlin.jvm.internal.l;
import o7.m;

public final class d {
  public static final Bundle a(m<String, ? extends Object>... paramVarArgs) {
    StringBuilder stringBuilder;
    l.f(paramVarArgs, "pairs");
    Bundle bundle = new Bundle(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0;; i++) {
      String str;
      Object object;
      if (i < j) {
        m<String, ? extends Object> m1 = paramVarArgs[i];
        str = (String)m1.a();
        object = m1.b();
        if (object == null) {
          bundle.putString(str, null);
          continue;
        } 
        if (object instanceof Boolean) {
          bundle.putBoolean(str, ((Boolean)object).booleanValue());
          continue;
        } 
        if (object instanceof Byte) {
          bundle.putByte(str, ((Number)object).byteValue());
          continue;
        } 
        if (object instanceof Character) {
          bundle.putChar(str, ((Character)object).charValue());
          continue;
        } 
        if (object instanceof Double) {
          bundle.putDouble(str, ((Number)object).doubleValue());
          continue;
        } 
        if (object instanceof Float) {
          bundle.putFloat(str, ((Number)object).floatValue());
          continue;
        } 
        if (object instanceof Integer) {
          bundle.putInt(str, ((Number)object).intValue());
          continue;
        } 
        if (object instanceof Long) {
          bundle.putLong(str, ((Number)object).longValue());
          continue;
        } 
        if (object instanceof Short) {
          bundle.putShort(str, ((Number)object).shortValue());
          continue;
        } 
        if (object instanceof Bundle) {
          bundle.putBundle(str, (Bundle)object);
          continue;
        } 
        if (object instanceof CharSequence) {
          bundle.putCharSequence(str, (CharSequence)object);
          continue;
        } 
        if (object instanceof Parcelable) {
          bundle.putParcelable(str, (Parcelable)object);
          continue;
        } 
        if (object instanceof boolean[]) {
          bundle.putBooleanArray(str, (boolean[])object);
          continue;
        } 
        if (object instanceof byte[]) {
          bundle.putByteArray(str, (byte[])object);
          continue;
        } 
        if (object instanceof char[]) {
          bundle.putCharArray(str, (char[])object);
          continue;
        } 
        if (object instanceof double[]) {
          bundle.putDoubleArray(str, (double[])object);
          continue;
        } 
        if (object instanceof float[]) {
          bundle.putFloatArray(str, (float[])object);
          continue;
        } 
        if (object instanceof int[]) {
          bundle.putIntArray(str, (int[])object);
          continue;
        } 
        if (object instanceof long[]) {
          bundle.putLongArray(str, (long[])object);
          continue;
        } 
        if (object instanceof short[]) {
          bundle.putShortArray(str, (short[])object);
          continue;
        } 
        if (object instanceof Object[]) {
          Class<?> clazz = object.getClass().getComponentType();
          l.c(clazz);
          if (Parcelable.class.isAssignableFrom(clazz)) {
            l.d(object, "null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
            bundle.putParcelableArray(str, (Parcelable[])object);
          } else if (String.class.isAssignableFrom(clazz)) {
            l.d(object, "null cannot be cast to non-null type kotlin.Array<kotlin.String>");
            bundle.putStringArray(str, (String[])object);
          } else if (CharSequence.class.isAssignableFrom(clazz)) {
            l.d(object, "null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
            bundle.putCharSequenceArray(str, (CharSequence[])object);
          } else {
            if (!Serializable.class.isAssignableFrom(clazz)) {
              String str1 = clazz.getCanonicalName();
              stringBuilder = new StringBuilder();
              stringBuilder.append("Illegal value array type ");
              stringBuilder.append(str1);
              stringBuilder.append(" for key \"");
              stringBuilder.append(str);
              stringBuilder.append('"');
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            stringBuilder.putSerializable(str, (Serializable)object);
          } 
          continue;
        } 
        if (!(object instanceof Serializable)) {
          int k = Build.VERSION.SDK_INT;
          if (k >= 18 && object instanceof IBinder) {
            b.a((Bundle)stringBuilder, str, (IBinder)object);
          } else if (k >= 21 && object instanceof Size) {
            c.a((Bundle)stringBuilder, str, (Size)object);
          } else if (k >= 21 && object instanceof SizeF) {
            c.b((Bundle)stringBuilder, str, (SizeF)object);
          } else {
            String str1 = object.getClass().getCanonicalName();
            stringBuilder = new StringBuilder();
            stringBuilder.append("Illegal value type ");
            stringBuilder.append(str1);
            stringBuilder.append(" for key \"");
            stringBuilder.append(str);
            stringBuilder.append('"');
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          continue;
        } 
      } else {
        break;
      } 
      stringBuilder.putSerializable(str, (Serializable)object);
    } 
    return (Bundle)stringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\os\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */