package androidx.core.os;

import android.os.Bundle;
import android.util.Size;
import android.util.SizeF;
import kotlin.jvm.internal.l;

final class c {
  public static final c a = new c();
  
  public static final void a(Bundle paramBundle, String paramString, Size paramSize) {
    l.f(paramBundle, "bundle");
    l.f(paramString, "key");
    paramBundle.putSize(paramString, paramSize);
  }
  
  public static final void b(Bundle paramBundle, String paramString, SizeF paramSizeF) {
    l.f(paramBundle, "bundle");
    l.f(paramString, "key");
    paramBundle.putSizeF(paramString, paramSizeF);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\os\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */