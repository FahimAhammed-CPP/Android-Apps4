package androidx.core.os;

import android.os.Bundle;
import android.os.IBinder;
import kotlin.jvm.internal.l;

final class b {
  public static final b a = new b();
  
  public static final void a(Bundle paramBundle, String paramString, IBinder paramIBinder) {
    l.f(paramBundle, "bundle");
    l.f(paramString, "key");
    paramBundle.putBinder(paramString, paramIBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\os\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */