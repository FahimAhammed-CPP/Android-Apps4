package androidx.core.os;

import android.os.Handler;
import androidx.core.util.e;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class f {
  public static Executor a(Handler paramHandler) {
    return new a(paramHandler);
  }
  
  private static class a implements Executor {
    private final Handler a;
    
    a(Handler param1Handler) {
      this.a = (Handler)e.b(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (this.a.post((Runnable)e.b(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\os\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */