package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import j.a;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class c {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return d(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static TypedValue c() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  private static ColorStateList d(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getDepth : ()I
    //   6: iconst_1
    //   7: iadd
    //   8: istore #12
    //   10: bipush #20
    //   12: anewarray [I
    //   15: astore #14
    //   17: bipush #20
    //   19: newarray int
    //   21: astore #15
    //   23: iconst_0
    //   24: istore #6
    //   26: aload_0
    //   27: astore #18
    //   29: aload_1
    //   30: invokeinterface next : ()I
    //   35: istore #8
    //   37: iload #8
    //   39: iconst_1
    //   40: if_icmpeq -> 509
    //   43: aload_1
    //   44: invokeinterface getDepth : ()I
    //   49: istore #9
    //   51: iload #9
    //   53: iload #12
    //   55: if_icmpge -> 64
    //   58: iload #8
    //   60: iconst_3
    //   61: if_icmpeq -> 509
    //   64: aload #15
    //   66: astore #17
    //   68: aload #14
    //   70: astore #16
    //   72: iload #6
    //   74: istore #7
    //   76: iload #8
    //   78: iconst_2
    //   79: if_icmpne -> 494
    //   82: aload #15
    //   84: astore #17
    //   86: aload #14
    //   88: astore #16
    //   90: iload #6
    //   92: istore #7
    //   94: iload #9
    //   96: iload #12
    //   98: if_icmpgt -> 494
    //   101: aload_1
    //   102: invokeinterface getName : ()Ljava/lang/String;
    //   107: ldc 'item'
    //   109: invokevirtual equals : (Ljava/lang/Object;)Z
    //   112: ifne -> 130
    //   115: aload #15
    //   117: astore #17
    //   119: aload #14
    //   121: astore #16
    //   123: iload #6
    //   125: istore #7
    //   127: goto -> 494
    //   130: aload #18
    //   132: aload_3
    //   133: aload_2
    //   134: getstatic i/c.b : [I
    //   137: invokestatic g : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   140: astore #16
    //   142: getstatic i/c.c : I
    //   145: istore #8
    //   147: aload #16
    //   149: iload #8
    //   151: iconst_m1
    //   152: invokevirtual getResourceId : (II)I
    //   155: istore #9
    //   157: iload #8
    //   159: istore #7
    //   161: iload #9
    //   163: iconst_m1
    //   164: if_icmpeq -> 207
    //   167: iload #8
    //   169: istore #7
    //   171: aload #18
    //   173: iload #9
    //   175: invokestatic e : (Landroid/content/res/Resources;I)Z
    //   178: ifne -> 207
    //   181: aload #18
    //   183: aload #18
    //   185: iload #9
    //   187: invokevirtual getXml : (I)Landroid/content/res/XmlResourceParser;
    //   190: aload_3
    //   191: invokestatic a : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   194: invokevirtual getDefaultColor : ()I
    //   197: istore #7
    //   199: goto -> 218
    //   202: getstatic i/c.c : I
    //   205: istore #7
    //   207: aload #16
    //   209: iload #7
    //   211: ldc -65281
    //   213: invokevirtual getColor : (II)I
    //   216: istore #7
    //   218: fconst_1
    //   219: fstore #4
    //   221: getstatic i/c.d : I
    //   224: istore #8
    //   226: aload #16
    //   228: iload #8
    //   230: invokevirtual hasValue : (I)Z
    //   233: ifeq -> 249
    //   236: aload #16
    //   238: iload #8
    //   240: fconst_1
    //   241: invokevirtual getFloat : (IF)F
    //   244: fstore #4
    //   246: goto -> 267
    //   249: getstatic i/c.f : I
    //   252: istore #8
    //   254: aload #16
    //   256: iload #8
    //   258: invokevirtual hasValue : (I)Z
    //   261: ifeq -> 267
    //   264: goto -> 236
    //   267: getstatic android/os/Build$VERSION.SDK_INT : I
    //   270: bipush #31
    //   272: if_icmplt -> 293
    //   275: getstatic i/c.e : I
    //   278: istore #8
    //   280: aload #16
    //   282: iload #8
    //   284: invokevirtual hasValue : (I)Z
    //   287: ifeq -> 293
    //   290: goto -> 298
    //   293: getstatic i/c.g : I
    //   296: istore #8
    //   298: aload #16
    //   300: iload #8
    //   302: ldc -1.0
    //   304: invokevirtual getFloat : (IF)F
    //   307: fstore #5
    //   309: aload #16
    //   311: invokevirtual recycle : ()V
    //   314: aload_2
    //   315: invokeinterface getAttributeCount : ()I
    //   320: istore #13
    //   322: iload #13
    //   324: newarray int
    //   326: astore #16
    //   328: iconst_0
    //   329: istore #8
    //   331: iconst_0
    //   332: istore #9
    //   334: iload #8
    //   336: iload #13
    //   338: if_icmpge -> 447
    //   341: aload_2
    //   342: iload #8
    //   344: invokeinterface getAttributeNameResource : (I)I
    //   349: istore #11
    //   351: iload #9
    //   353: istore #10
    //   355: iload #11
    //   357: ldc 16843173
    //   359: if_icmpeq -> 434
    //   362: iload #9
    //   364: istore #10
    //   366: iload #11
    //   368: ldc 16843551
    //   370: if_icmpeq -> 434
    //   373: iload #9
    //   375: istore #10
    //   377: iload #11
    //   379: getstatic i/a.a : I
    //   382: if_icmpeq -> 434
    //   385: iload #9
    //   387: istore #10
    //   389: iload #11
    //   391: getstatic i/a.b : I
    //   394: if_icmpeq -> 434
    //   397: aload_2
    //   398: iload #8
    //   400: iconst_0
    //   401: invokeinterface getAttributeBooleanValue : (IZ)Z
    //   406: ifeq -> 416
    //   409: iload #11
    //   411: istore #10
    //   413: goto -> 421
    //   416: iload #11
    //   418: ineg
    //   419: istore #10
    //   421: aload #16
    //   423: iload #9
    //   425: iload #10
    //   427: iastore
    //   428: iload #9
    //   430: iconst_1
    //   431: iadd
    //   432: istore #10
    //   434: iload #8
    //   436: iconst_1
    //   437: iadd
    //   438: istore #8
    //   440: iload #10
    //   442: istore #9
    //   444: goto -> 334
    //   447: aload #16
    //   449: iload #9
    //   451: invokestatic trimStateSet : ([II)[I
    //   454: astore #16
    //   456: aload #15
    //   458: iload #6
    //   460: iload #7
    //   462: fload #4
    //   464: fload #5
    //   466: invokestatic f : (IFF)I
    //   469: invokestatic a : ([III)[I
    //   472: astore #17
    //   474: aload #14
    //   476: iload #6
    //   478: aload #16
    //   480: invokestatic b : ([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
    //   483: checkcast [[I
    //   486: astore #16
    //   488: iload #6
    //   490: iconst_1
    //   491: iadd
    //   492: istore #7
    //   494: aload #17
    //   496: astore #15
    //   498: aload #16
    //   500: astore #14
    //   502: iload #7
    //   504: istore #6
    //   506: goto -> 26
    //   509: iload #6
    //   511: newarray int
    //   513: astore_0
    //   514: iload #6
    //   516: anewarray [I
    //   519: astore_1
    //   520: aload #15
    //   522: iconst_0
    //   523: aload_0
    //   524: iconst_0
    //   525: iload #6
    //   527: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   530: aload #14
    //   532: iconst_0
    //   533: aload_1
    //   534: iconst_0
    //   535: iload #6
    //   537: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   540: new android/content/res/ColorStateList
    //   543: dup
    //   544: aload_1
    //   545: aload_0
    //   546: invokespecial <init> : ([[I[I)V
    //   549: areturn
    //   550: astore #17
    //   552: goto -> 202
    // Exception table:
    //   from	to	target	type
    //   181	199	550	java/lang/Exception
  }
  
  private static boolean e(Resources paramResources, int paramInt) {
    TypedValue typedValue = c();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  private static int f(int paramInt, float paramFloat1, float paramFloat2) {
    boolean bool;
    if (paramFloat2 >= 0.0F && paramFloat2 <= 100.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramFloat1 == 1.0F && !bool)
      return paramInt; 
    int j = a.a((int)(Color.alpha(paramInt) * paramFloat1 + 0.5F), 0, 255);
    int i = paramInt;
    if (bool) {
      a a = a.c(paramInt);
      i = a.m(a.j(), a.i(), paramFloat2);
    } 
    return i & 0xFFFFFF | j << 24;
  }
  
  private static TypedArray g(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\core\content\res\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */