package androidx.concurrent.futures;

public final class c<V> extends a<V> {
  public static <V> c<V> A() {
    return new c<V>();
  }
  
  public boolean w(V paramV) {
    return super.w(paramV);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\concurrent\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */