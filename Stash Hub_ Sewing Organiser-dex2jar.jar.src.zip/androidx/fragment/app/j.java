package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class j extends i implements LayoutInflater.Factory2 {
  static boolean L = false;
  
  static final Interpolator M = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final Interpolator N = (Interpolator)new DecelerateInterpolator(1.5F);
  
  boolean A;
  
  boolean B;
  
  boolean C;
  
  ArrayList<a> D;
  
  ArrayList<Boolean> E;
  
  ArrayList<Fragment> F;
  
  Bundle G = null;
  
  SparseArray<Parcelable> H = null;
  
  ArrayList<m> I;
  
  private l J;
  
  Runnable K = new b(this);
  
  ArrayList<k> c;
  
  boolean d;
  
  int e = 0;
  
  final ArrayList<Fragment> f = new ArrayList<Fragment>();
  
  final HashMap<String, Fragment> g = new HashMap<String, Fragment>();
  
  ArrayList<a> l;
  
  ArrayList<Fragment> m;
  
  private OnBackPressedDispatcher n;
  
  private final androidx.activity.j o = new a(this, false);
  
  ArrayList<a> p;
  
  ArrayList<Integer> q;
  
  ArrayList<i.b> r;
  
  private final CopyOnWriteArrayList<i> s = new CopyOnWriteArrayList<i>();
  
  int t = 0;
  
  h u;
  
  e v;
  
  Fragment w;
  
  Fragment x;
  
  boolean y;
  
  boolean z;
  
  private boolean E0(Fragment paramFragment) {
    return ((paramFragment.G && paramFragment.H) || paramFragment.x.s());
  }
  
  static g K0(float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(N);
    alphaAnimation.setDuration(220L);
    return new g((Animation)alphaAnimation);
  }
  
  static g M0(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(M);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(N);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new g((Animation)animationSet);
  }
  
  private void N0(androidx.collection.b<Fragment> paramb) {
    int m = paramb.size();
    for (int k = 0; k < m; k++) {
      Fragment fragment = (Fragment)paramb.p(k);
      if (!fragment.o) {
        View view = fragment.c1();
        fragment.S = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean U0(String paramString, int paramInt1, int paramInt2) {
    l0();
    j0(true);
    Fragment fragment = this.x;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.q().h())
      return true; 
    boolean bool = V0(this.D, this.E, paramString, paramInt1, paramInt2);
    if (bool) {
      this.d = true;
      try {
        Z0(this.D, this.E);
      } finally {
        u();
      } 
    } 
    p1();
    g0();
    r();
    return bool;
  }
  
  private int W0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, androidx.collection.b<Fragment> paramb) {
    int k = paramInt2 - 1;
    int m;
    for (m = paramInt2; k >= paramInt1; m = n) {
      boolean bool;
      a a = paramArrayList.get(k);
      boolean bool1 = ((Boolean)paramArrayList1.get(k)).booleanValue();
      if (a.s() && !a.q(paramArrayList, k + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int n = m;
      if (bool) {
        if (this.I == null)
          this.I = new ArrayList<m>(); 
        m m1 = new m(a, bool1);
        this.I.add(m1);
        a.u(m1);
        if (bool1) {
          a.l();
        } else {
          a.m(false);
        } 
        n = m - 1;
        if (k != n) {
          paramArrayList.remove(k);
          paramArrayList.add(n, a);
        } 
        j(paramb);
      } 
      k--;
    } 
    return m;
  }
  
  private void X(Fragment paramFragment) {
    if (paramFragment != null && this.g.get(paramFragment.e) == paramFragment)
      paramFragment.U0(); 
  }
  
  private void Z0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        o0(paramArrayList, paramArrayList1);
        int n = paramArrayList.size();
        int k = 0;
        int m;
        for (m = 0; k < n; m = i1) {
          int i2 = k;
          int i1 = m;
          if (!((a)paramArrayList.get(k)).q) {
            if (m != k)
              n0(paramArrayList, paramArrayList1, m, k); 
            m = k + 1;
            i1 = m;
            if (((Boolean)paramArrayList1.get(k)).booleanValue())
              while (true) {
                i1 = m;
                if (m < n) {
                  i1 = m;
                  if (((Boolean)paramArrayList1.get(m)).booleanValue()) {
                    i1 = m;
                    if (!((a)paramArrayList.get(m)).q) {
                      m++;
                      continue;
                    } 
                  } 
                } 
                break;
              }  
            n0(paramArrayList, paramArrayList1, k, i1);
            i2 = i1 - 1;
          } 
          k = i2 + 1;
        } 
        if (m != n)
          n0(paramArrayList, paramArrayList1, m, n); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int d1(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void e0(int paramInt) {
    try {
      this.d = true;
      P0(paramInt, false);
      this.d = false;
      return;
    } finally {
      this.d = false;
    } 
  }
  
  private void h0() {
    for (Fragment fragment : this.g.values()) {
      if (fragment != null) {
        if (fragment.o() != null) {
          int k = fragment.J();
          View view = fragment.o();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.f1(null);
          R0(fragment, k, 0, 0, false);
          continue;
        } 
        if (fragment.p() != null)
          fragment.p().end(); 
      } 
    } 
  }
  
  private void j(androidx.collection.b<Fragment> paramb) {
    int k = this.t;
    if (k < 1)
      return; 
    int m = Math.min(k, 3);
    int n = this.f.size();
    for (k = 0; k < n; k++) {
      Fragment fragment = this.f.get(k);
      if (fragment.a < m) {
        R0(fragment, m, fragment.z(), fragment.A(), false);
        if (fragment.K != null && !fragment.C && fragment.Q)
          paramb.add(fragment); 
      } 
    } 
  }
  
  private void j0(boolean paramBoolean) {
    if (!this.d) {
      if (this.u != null) {
        if (Looper.myLooper() == this.u.h().getLooper()) {
          if (!paramBoolean)
            t(); 
          if (this.D == null) {
            this.D = new ArrayList<a>();
            this.E = new ArrayList<Boolean>();
          } 
          this.d = true;
          try {
            o0(null, null);
            return;
          } finally {
            this.d = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void m0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      a a = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        a.h(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        a.m(bool);
      } else {
        a.h(1);
        a.l();
      } 
      paramInt1++;
    } 
  }
  
  private void n0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int n;
    int k = paramInt1;
    boolean bool1 = ((a)paramArrayList.get(k)).q;
    ArrayList<Fragment> arrayList = this.F;
    if (arrayList == null) {
      this.F = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.F.addAll(this.f);
    Fragment fragment = z0();
    int m = k;
    boolean bool = false;
    while (m < paramInt2) {
      a a = paramArrayList.get(m);
      if (!((Boolean)paramArrayList1.get(m)).booleanValue()) {
        fragment = a.n(this.F, fragment);
      } else {
        fragment = a.v(this.F, fragment);
      } 
      if (bool || a.h) {
        bool = true;
      } else {
        bool = false;
      } 
      m++;
    } 
    this.F.clear();
    if (!bool1)
      o.B(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    m0(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool1) {
      androidx.collection.b<Fragment> b = new androidx.collection.b();
      j(b);
      n = W0(paramArrayList, paramArrayList1, paramInt1, paramInt2, b);
      N0(b);
    } else {
      n = paramInt2;
    } 
    m = k;
    if (n != k) {
      m = k;
      if (bool1) {
        o.B(this, paramArrayList, paramArrayList1, paramInt1, n, true);
        P0(this.t, true);
        m = k;
      } 
    } 
    while (m < paramInt2) {
      a a = paramArrayList.get(m);
      if (((Boolean)paramArrayList1.get(m)).booleanValue()) {
        paramInt1 = a.u;
        if (paramInt1 >= 0) {
          t0(paramInt1);
          a.u = -1;
        } 
      } 
      a.t();
      m++;
    } 
    if (bool)
      b1(); 
  }
  
  private void n1(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new androidx.core.util.c("FragmentManager"));
    h h1 = this.u;
    if (h1 != null) {
      try {
        h1.l("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      b("  ", null, (PrintWriter)exception, new String[0]);
    } 
    throw paramRuntimeException;
  }
  
  private void o(Fragment paramFragment, g paramg, int paramInt) {
    h h1;
    View view = paramFragment.K;
    ViewGroup viewGroup = paramFragment.J;
    viewGroup.startViewTransition(view);
    paramFragment.m1(paramInt);
    if (paramg.a != null) {
      h1 = new h(paramg.a, viewGroup, view);
      paramFragment.f1(paramFragment.K);
      h1.setAnimationListener(new c(this, viewGroup, paramFragment));
      paramFragment.K.startAnimation((Animation)h1);
      return;
    } 
    Animator animator = ((g)h1).b;
    paramFragment.g1(animator);
    animator.addListener((Animator.AnimatorListener)new d(this, viewGroup, view, paramFragment));
    animator.setTarget(paramFragment.K);
    animator.start();
  }
  
  private void o0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload #4
    //   28: istore #6
    //   30: iload_3
    //   31: iload #6
    //   33: if_icmpge -> 245
    //   36: aload_0
    //   37: getfield I : Ljava/util/ArrayList;
    //   40: iload_3
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/j$m
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 121
    //   53: aload #7
    //   55: getfield a : Z
    //   58: ifne -> 121
    //   61: aload_1
    //   62: aload #7
    //   64: getfield b : Landroidx/fragment/app/a;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore #4
    //   72: iload #4
    //   74: iconst_m1
    //   75: if_icmpeq -> 121
    //   78: aload_2
    //   79: iload #4
    //   81: invokevirtual get : (I)Ljava/lang/Object;
    //   84: checkcast java/lang/Boolean
    //   87: invokevirtual booleanValue : ()Z
    //   90: ifeq -> 121
    //   93: aload_0
    //   94: getfield I : Ljava/util/ArrayList;
    //   97: iload_3
    //   98: invokevirtual remove : (I)Ljava/lang/Object;
    //   101: pop
    //   102: iload_3
    //   103: iconst_1
    //   104: isub
    //   105: istore #5
    //   107: iload #6
    //   109: iconst_1
    //   110: isub
    //   111: istore #4
    //   113: aload #7
    //   115: invokevirtual c : ()V
    //   118: goto -> 233
    //   121: aload #7
    //   123: invokevirtual e : ()Z
    //   126: ifne -> 164
    //   129: iload #6
    //   131: istore #4
    //   133: iload_3
    //   134: istore #5
    //   136: aload_1
    //   137: ifnull -> 233
    //   140: iload #6
    //   142: istore #4
    //   144: iload_3
    //   145: istore #5
    //   147: aload #7
    //   149: getfield b : Landroidx/fragment/app/a;
    //   152: aload_1
    //   153: iconst_0
    //   154: aload_1
    //   155: invokevirtual size : ()I
    //   158: invokevirtual q : (Ljava/util/ArrayList;II)Z
    //   161: ifeq -> 233
    //   164: aload_0
    //   165: getfield I : Ljava/util/ArrayList;
    //   168: iload_3
    //   169: invokevirtual remove : (I)Ljava/lang/Object;
    //   172: pop
    //   173: iload_3
    //   174: iconst_1
    //   175: isub
    //   176: istore #5
    //   178: iload #6
    //   180: iconst_1
    //   181: isub
    //   182: istore #4
    //   184: aload_1
    //   185: ifnull -> 228
    //   188: aload #7
    //   190: getfield a : Z
    //   193: ifne -> 228
    //   196: aload_1
    //   197: aload #7
    //   199: getfield b : Landroidx/fragment/app/a;
    //   202: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   205: istore_3
    //   206: iload_3
    //   207: iconst_m1
    //   208: if_icmpeq -> 228
    //   211: aload_2
    //   212: iload_3
    //   213: invokevirtual get : (I)Ljava/lang/Object;
    //   216: checkcast java/lang/Boolean
    //   219: invokevirtual booleanValue : ()Z
    //   222: ifeq -> 228
    //   225: goto -> 113
    //   228: aload #7
    //   230: invokevirtual d : ()V
    //   233: iload #5
    //   235: iconst_1
    //   236: iadd
    //   237: istore_3
    //   238: iload #4
    //   240: istore #6
    //   242: goto -> 30
    //   245: return
  }
  
  public static int o1(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  private void p1() {
    ArrayList<k> arrayList = this.c;
    boolean bool = true;
    if (arrayList != null && !arrayList.isEmpty()) {
      this.o.f(true);
      return;
    } 
    androidx.activity.j j1 = this.o;
    if (v0() <= 0 || !F0(this.w))
      bool = false; 
    j1.f(bool);
  }
  
  private void r() {
    this.g.values().removeAll(Collections.singleton(null));
  }
  
  private Fragment r0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.J;
    View view = paramFragment.K;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int k = this.f.indexOf(paramFragment) - 1; k >= 0; k--) {
        paramFragment = this.f.get(k);
        if (paramFragment.J == viewGroup && paramFragment.K != null)
          return paramFragment; 
      } 
    } 
    return null;
  }
  
  private void s0() {
    if (this.I != null)
      while (!this.I.isEmpty())
        ((m)this.I.remove(0)).d();  
  }
  
  private void t() {
    if (!H0())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void u() {
    this.d = false;
    this.E.clear();
    this.D.clear();
  }
  
  private boolean u0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/ArrayList;
    //   6: astore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #6
    //   12: ifnull -> 100
    //   15: aload #6
    //   17: invokevirtual size : ()I
    //   20: ifne -> 26
    //   23: goto -> 100
    //   26: aload_0
    //   27: getfield c : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: istore #4
    //   35: iconst_0
    //   36: istore #5
    //   38: iload_3
    //   39: iload #4
    //   41: if_icmpge -> 74
    //   44: iload #5
    //   46: aload_0
    //   47: getfield c : Ljava/util/ArrayList;
    //   50: iload_3
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast androidx/fragment/app/j$k
    //   57: aload_1
    //   58: aload_2
    //   59: invokeinterface a : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   64: ior
    //   65: istore #5
    //   67: iload_3
    //   68: iconst_1
    //   69: iadd
    //   70: istore_3
    //   71: goto -> 38
    //   74: aload_0
    //   75: getfield c : Ljava/util/ArrayList;
    //   78: invokevirtual clear : ()V
    //   81: aload_0
    //   82: getfield u : Landroidx/fragment/app/h;
    //   85: invokevirtual h : ()Landroid/os/Handler;
    //   88: aload_0
    //   89: getfield K : Ljava/lang/Runnable;
    //   92: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   95: aload_0
    //   96: monitorexit
    //   97: iload #5
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	104	finally
    //   15	23	104	finally
    //   26	35	104	finally
    //   44	67	104	finally
    //   74	97	104	finally
    //   100	102	104	finally
    //   105	107	104	finally
  }
  
  public boolean A(MenuItem paramMenuItem) {
    if (this.t < 1)
      return false; 
    for (int k = 0; k < this.f.size(); k++) {
      Fragment fragment = this.f.get(k);
      if (fragment != null && fragment.F0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  f0 A0(Fragment paramFragment) {
    return this.J.j(paramFragment);
  }
  
  public void B() {
    this.z = false;
    this.A = false;
    e0(1);
  }
  
  void B0() {
    l0();
    if (this.o.c()) {
      h();
      return;
    } 
    this.n.e();
  }
  
  public boolean C(Menu paramMenu, MenuInflater paramMenuInflater) {
    int k = this.t;
    boolean bool1 = false;
    if (k < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    k = 0;
    boolean bool2;
    for (bool2 = false; k < this.f.size(); bool2 = bool) {
      Fragment fragment = this.f.get(k);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.H0(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      k++;
      arrayList = arrayList1;
    } 
    if (this.m != null)
      for (k = bool1; k < this.m.size(); k++) {
        Fragment fragment = this.m.get(k);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.h0(); 
      }  
    this.m = arrayList;
    return bool2;
  }
  
  public void C0(Fragment paramFragment) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.C) {
      paramFragment.C = true;
      paramFragment.R = true ^ paramFragment.R;
    } 
  }
  
  public void D() {
    this.B = true;
    l0();
    e0(0);
    this.u = null;
    this.v = null;
    this.w = null;
    if (this.n != null) {
      this.o.d();
      this.n = null;
    } 
  }
  
  public boolean D0() {
    return this.B;
  }
  
  public void E() {
    e0(1);
  }
  
  public void F() {
    for (int k = 0; k < this.f.size(); k++) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.N0(); 
    } 
  }
  
  boolean F0(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    j j1 = paramFragment.v;
    return (paramFragment == j1.z0() && F0(j1.w));
  }
  
  public void G(boolean paramBoolean) {
    for (int k = this.f.size() - 1; k >= 0; k--) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.O0(paramBoolean); 
    } 
  }
  
  boolean G0(int paramInt) {
    return (this.t >= paramInt);
  }
  
  void H(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).H(paramFragment, paramBundle, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  public boolean H0() {
    return (this.z || this.A);
  }
  
  void I(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).I(paramFragment, paramContext, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  g I0(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int k = paramFragment.z();
    boolean bool = false;
    paramFragment.j1(0);
    ViewGroup viewGroup = paramFragment.J;
    if (viewGroup != null && viewGroup.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.c0(paramInt1, paramBoolean, k);
    if (animation != null)
      return new g(animation); 
    Animator animator = paramFragment.d0(paramInt1, paramBoolean, k);
    if (animator != null)
      return new g(animator); 
    if (k != 0) {
      boolean bool2 = "anim".equals(this.u.g().getResources().getResourceTypeName(k));
      boolean bool1 = bool;
      if (bool2)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.u.g(), k);
          if (animation1 != null)
            return new g(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.u.g(), k);
          if (animator != null)
            return new g(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool2) {
            animation1 = AnimationUtils.loadAnimation(this.u.g(), k);
            if (animation1 != null)
              return new g(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = o1(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        if (paramInt2 == 0 && this.u.p()) {
          this.u.o();
          return null;
        } 
        return null;
      case 6:
        return K0(1.0F, 0.0F);
      case 5:
        return K0(0.0F, 1.0F);
      case 4:
        return M0(1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return M0(0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return M0(1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        break;
    } 
    return M0(1.125F, 1.0F, 0.0F, 1.0F);
  }
  
  void J(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).J(paramFragment, paramBundle, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void J0(Fragment paramFragment) {
    if (this.g.get(paramFragment.e) != null)
      return; 
    this.g.put(paramFragment.e, paramFragment);
    if (paramFragment.F) {
      if (paramFragment.E) {
        m(paramFragment);
      } else {
        a1(paramFragment);
      } 
      paramFragment.F = false;
    } 
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void K(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).K(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void L(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).L(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void L0(Fragment paramFragment) {
    if (this.g.get(paramFragment.e) == null)
      return; 
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    for (Fragment fragment : this.g.values()) {
      if (fragment != null && paramFragment.e.equals(fragment.l)) {
        fragment.g = paramFragment;
        fragment.l = null;
      } 
    } 
    this.g.put(paramFragment.e, null);
    a1(paramFragment);
    String str = paramFragment.l;
    if (str != null)
      paramFragment.g = this.g.get(str); 
    paramFragment.N();
  }
  
  void M(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).M(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void N(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).N(paramFragment, paramContext, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void O(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).O(paramFragment, paramBundle, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void O0(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    if (!this.g.containsKey(paramFragment.e)) {
      if (L) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.t);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    int m = this.t;
    int k = m;
    if (paramFragment.p)
      if (paramFragment.Q()) {
        k = Math.min(m, 1);
      } else {
        k = Math.min(m, 0);
      }  
    R0(paramFragment, k, paramFragment.A(), paramFragment.B(), false);
    if (paramFragment.K != null) {
      Fragment fragment = r0(paramFragment);
      if (fragment != null) {
        View view = fragment.K;
        ViewGroup viewGroup = paramFragment.J;
        k = viewGroup.indexOfChild(view);
        m = viewGroup.indexOfChild(paramFragment.K);
        if (m < k) {
          viewGroup.removeViewAt(m);
          viewGroup.addView(paramFragment.K, k);
        } 
      } 
      if (paramFragment.Q && paramFragment.J != null) {
        float f = paramFragment.S;
        if (f > 0.0F)
          paramFragment.K.setAlpha(f); 
        paramFragment.S = 0.0F;
        paramFragment.Q = false;
        g g = I0(paramFragment, paramFragment.A(), true, paramFragment.B());
        if (g != null) {
          Animation animation = g.a;
          if (animation != null) {
            paramFragment.K.startAnimation(animation);
          } else {
            g.b.setTarget(paramFragment.K);
            g.b.start();
          } 
        } 
      } 
    } 
    if (paramFragment.R)
      w(paramFragment); 
  }
  
  void P(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).P(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void P0(int paramInt, boolean paramBoolean) {
    if (this.u != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.t)
        return; 
      this.t = paramInt;
      int k = this.f.size();
      for (paramInt = 0; paramInt < k; paramInt++)
        O0(this.f.get(paramInt)); 
      for (Fragment fragment : this.g.values()) {
        if (fragment != null && (fragment.p || fragment.D) && !fragment.Q)
          O0(fragment); 
      } 
      m1();
      if (this.y) {
        h h1 = this.u;
        if (h1 != null && this.t == 4) {
          h1.s();
          this.y = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void Q(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).Q(paramFragment, paramBundle, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void Q0(Fragment paramFragment) {
    R0(paramFragment, this.t, 0, 0, false);
  }
  
  void R(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).R(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  void R0(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: istore #11
    //   6: iconst_1
    //   7: istore #10
    //   9: iconst_1
    //   10: istore #7
    //   12: iconst_1
    //   13: istore #9
    //   15: iload #11
    //   17: ifeq -> 33
    //   20: aload_1
    //   21: getfield D : Z
    //   24: ifeq -> 30
    //   27: goto -> 33
    //   30: goto -> 47
    //   33: iload_2
    //   34: istore #6
    //   36: iload #6
    //   38: istore_2
    //   39: iload #6
    //   41: iconst_1
    //   42: if_icmple -> 47
    //   45: iconst_1
    //   46: istore_2
    //   47: iload_2
    //   48: istore #6
    //   50: aload_1
    //   51: getfield p : Z
    //   54: ifeq -> 96
    //   57: aload_1
    //   58: getfield a : I
    //   61: istore #8
    //   63: iload_2
    //   64: istore #6
    //   66: iload_2
    //   67: iload #8
    //   69: if_icmple -> 96
    //   72: iload #8
    //   74: ifne -> 90
    //   77: aload_1
    //   78: invokevirtual Q : ()Z
    //   81: ifeq -> 90
    //   84: iconst_1
    //   85: istore #6
    //   87: goto -> 96
    //   90: aload_1
    //   91: getfield a : I
    //   94: istore #6
    //   96: iload #6
    //   98: istore_2
    //   99: aload_1
    //   100: getfield M : Z
    //   103: ifeq -> 128
    //   106: iload #6
    //   108: istore_2
    //   109: aload_1
    //   110: getfield a : I
    //   113: iconst_3
    //   114: if_icmpge -> 128
    //   117: iload #6
    //   119: istore_2
    //   120: iload #6
    //   122: iconst_2
    //   123: if_icmple -> 128
    //   126: iconst_2
    //   127: istore_2
    //   128: aload_1
    //   129: getfield V : Landroidx/lifecycle/e$b;
    //   132: astore #12
    //   134: aload #12
    //   136: getstatic androidx/lifecycle/e$b.c : Landroidx/lifecycle/e$b;
    //   139: if_acmpne -> 151
    //   142: iload_2
    //   143: iconst_1
    //   144: invokestatic min : (II)I
    //   147: istore_2
    //   148: goto -> 161
    //   151: iload_2
    //   152: aload #12
    //   154: invokevirtual ordinal : ()I
    //   157: invokestatic min : (II)I
    //   160: istore_2
    //   161: aload_1
    //   162: getfield a : I
    //   165: istore #8
    //   167: iload #8
    //   169: iload_2
    //   170: if_icmpgt -> 1521
    //   173: aload_1
    //   174: getfield q : Z
    //   177: ifeq -> 188
    //   180: aload_1
    //   181: getfield r : Z
    //   184: ifne -> 188
    //   187: return
    //   188: aload_1
    //   189: invokevirtual o : ()Landroid/view/View;
    //   192: ifnonnull -> 202
    //   195: aload_1
    //   196: invokevirtual p : ()Landroid/animation/Animator;
    //   199: ifnull -> 224
    //   202: aload_1
    //   203: aconst_null
    //   204: invokevirtual f1 : (Landroid/view/View;)V
    //   207: aload_1
    //   208: aconst_null
    //   209: invokevirtual g1 : (Landroid/animation/Animator;)V
    //   212: aload_0
    //   213: aload_1
    //   214: aload_1
    //   215: invokevirtual J : ()I
    //   218: iconst_0
    //   219: iconst_0
    //   220: iconst_1
    //   221: invokevirtual R0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   224: aload_1
    //   225: getfield a : I
    //   228: istore #6
    //   230: iload #6
    //   232: ifeq -> 272
    //   235: iload_2
    //   236: istore_3
    //   237: iload #6
    //   239: iconst_1
    //   240: if_icmpeq -> 910
    //   243: iload_2
    //   244: istore #4
    //   246: iload #6
    //   248: iconst_2
    //   249: if_icmpeq -> 269
    //   252: iload_2
    //   253: istore_3
    //   254: iload #6
    //   256: iconst_3
    //   257: if_icmpeq -> 266
    //   260: iload_2
    //   261: istore #6
    //   263: goto -> 2318
    //   266: goto -> 1444
    //   269: goto -> 1376
    //   272: iload_2
    //   273: istore_3
    //   274: iload_2
    //   275: ifle -> 910
    //   278: getstatic androidx/fragment/app/j.L : Z
    //   281: ifeq -> 321
    //   284: new java/lang/StringBuilder
    //   287: dup
    //   288: invokespecial <init> : ()V
    //   291: astore #12
    //   293: aload #12
    //   295: ldc_w 'moveto CREATED: '
    //   298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: pop
    //   302: aload #12
    //   304: aload_1
    //   305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   308: pop
    //   309: ldc_w 'FragmentManager'
    //   312: aload #12
    //   314: invokevirtual toString : ()Ljava/lang/String;
    //   317: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   320: pop
    //   321: aload_1
    //   322: getfield b : Landroid/os/Bundle;
    //   325: astore #12
    //   327: iload_2
    //   328: istore_3
    //   329: aload #12
    //   331: ifnull -> 486
    //   334: aload #12
    //   336: aload_0
    //   337: getfield u : Landroidx/fragment/app/h;
    //   340: invokevirtual g : ()Landroid/content/Context;
    //   343: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   346: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   349: aload_1
    //   350: aload_1
    //   351: getfield b : Landroid/os/Bundle;
    //   354: ldc_w 'android:view_state'
    //   357: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   360: putfield c : Landroid/util/SparseArray;
    //   363: aload_0
    //   364: aload_1
    //   365: getfield b : Landroid/os/Bundle;
    //   368: ldc_w 'android:target_state'
    //   371: invokevirtual x0 : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   374: astore #12
    //   376: aload #12
    //   378: ifnull -> 391
    //   381: aload #12
    //   383: getfield e : Ljava/lang/String;
    //   386: astore #12
    //   388: goto -> 394
    //   391: aconst_null
    //   392: astore #12
    //   394: aload_1
    //   395: aload #12
    //   397: putfield l : Ljava/lang/String;
    //   400: aload #12
    //   402: ifnull -> 420
    //   405: aload_1
    //   406: aload_1
    //   407: getfield b : Landroid/os/Bundle;
    //   410: ldc_w 'android:target_req_state'
    //   413: iconst_0
    //   414: invokevirtual getInt : (Ljava/lang/String;I)I
    //   417: putfield m : I
    //   420: aload_1
    //   421: getfield d : Ljava/lang/Boolean;
    //   424: astore #12
    //   426: aload #12
    //   428: ifnull -> 448
    //   431: aload_1
    //   432: aload #12
    //   434: invokevirtual booleanValue : ()Z
    //   437: putfield N : Z
    //   440: aload_1
    //   441: aconst_null
    //   442: putfield d : Ljava/lang/Boolean;
    //   445: goto -> 463
    //   448: aload_1
    //   449: aload_1
    //   450: getfield b : Landroid/os/Bundle;
    //   453: ldc_w 'android:user_visible_hint'
    //   456: iconst_1
    //   457: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   460: putfield N : Z
    //   463: iload_2
    //   464: istore_3
    //   465: aload_1
    //   466: getfield N : Z
    //   469: ifne -> 486
    //   472: aload_1
    //   473: iconst_1
    //   474: putfield M : Z
    //   477: iload_2
    //   478: istore_3
    //   479: iload_2
    //   480: iconst_2
    //   481: if_icmple -> 486
    //   484: iconst_2
    //   485: istore_3
    //   486: aload_0
    //   487: getfield u : Landroidx/fragment/app/h;
    //   490: astore #12
    //   492: aload_1
    //   493: aload #12
    //   495: putfield w : Landroidx/fragment/app/h;
    //   498: aload_0
    //   499: getfield w : Landroidx/fragment/app/Fragment;
    //   502: astore #13
    //   504: aload_1
    //   505: aload #13
    //   507: putfield y : Landroidx/fragment/app/Fragment;
    //   510: aload #13
    //   512: ifnull -> 525
    //   515: aload #13
    //   517: getfield x : Landroidx/fragment/app/j;
    //   520: astore #12
    //   522: goto -> 532
    //   525: aload #12
    //   527: getfield e : Landroidx/fragment/app/j;
    //   530: astore #12
    //   532: aload_1
    //   533: aload #12
    //   535: putfield v : Landroidx/fragment/app/j;
    //   538: aload_1
    //   539: getfield g : Landroidx/fragment/app/Fragment;
    //   542: astore #12
    //   544: aload #12
    //   546: ifnull -> 683
    //   549: aload_0
    //   550: getfield g : Ljava/util/HashMap;
    //   553: aload #12
    //   555: getfield e : Ljava/lang/String;
    //   558: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   561: astore #12
    //   563: aload_1
    //   564: getfield g : Landroidx/fragment/app/Fragment;
    //   567: astore #13
    //   569: aload #12
    //   571: aload #13
    //   573: if_acmpne -> 617
    //   576: aload #13
    //   578: getfield a : I
    //   581: iconst_1
    //   582: if_icmpge -> 598
    //   585: aload_0
    //   586: aload #13
    //   588: iconst_1
    //   589: iconst_0
    //   590: iconst_0
    //   591: iconst_1
    //   592: invokevirtual R0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   595: goto -> 598
    //   598: aload_1
    //   599: aload_1
    //   600: getfield g : Landroidx/fragment/app/Fragment;
    //   603: getfield e : Ljava/lang/String;
    //   606: putfield l : Ljava/lang/String;
    //   609: aload_1
    //   610: aconst_null
    //   611: putfield g : Landroidx/fragment/app/Fragment;
    //   614: goto -> 683
    //   617: new java/lang/StringBuilder
    //   620: dup
    //   621: invokespecial <init> : ()V
    //   624: astore #12
    //   626: aload #12
    //   628: ldc_w 'Fragment '
    //   631: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   634: pop
    //   635: aload #12
    //   637: aload_1
    //   638: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   641: pop
    //   642: aload #12
    //   644: ldc_w ' declared target fragment '
    //   647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   650: pop
    //   651: aload #12
    //   653: aload_1
    //   654: getfield g : Landroidx/fragment/app/Fragment;
    //   657: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   660: pop
    //   661: aload #12
    //   663: ldc_w ' that does not belong to this FragmentManager!'
    //   666: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   669: pop
    //   670: new java/lang/IllegalStateException
    //   673: dup
    //   674: aload #12
    //   676: invokevirtual toString : ()Ljava/lang/String;
    //   679: invokespecial <init> : (Ljava/lang/String;)V
    //   682: athrow
    //   683: aload_1
    //   684: getfield l : Ljava/lang/String;
    //   687: astore #12
    //   689: aload #12
    //   691: ifnull -> 801
    //   694: aload_0
    //   695: getfield g : Ljava/util/HashMap;
    //   698: aload #12
    //   700: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   703: checkcast androidx/fragment/app/Fragment
    //   706: astore #12
    //   708: aload #12
    //   710: ifnull -> 735
    //   713: aload #12
    //   715: getfield a : I
    //   718: iconst_1
    //   719: if_icmpge -> 801
    //   722: aload_0
    //   723: aload #12
    //   725: iconst_1
    //   726: iconst_0
    //   727: iconst_0
    //   728: iconst_1
    //   729: invokevirtual R0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   732: goto -> 801
    //   735: new java/lang/StringBuilder
    //   738: dup
    //   739: invokespecial <init> : ()V
    //   742: astore #12
    //   744: aload #12
    //   746: ldc_w 'Fragment '
    //   749: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   752: pop
    //   753: aload #12
    //   755: aload_1
    //   756: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   759: pop
    //   760: aload #12
    //   762: ldc_w ' declared target fragment '
    //   765: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   768: pop
    //   769: aload #12
    //   771: aload_1
    //   772: getfield l : Ljava/lang/String;
    //   775: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   778: pop
    //   779: aload #12
    //   781: ldc_w ' that does not belong to this FragmentManager!'
    //   784: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   787: pop
    //   788: new java/lang/IllegalStateException
    //   791: dup
    //   792: aload #12
    //   794: invokevirtual toString : ()Ljava/lang/String;
    //   797: invokespecial <init> : (Ljava/lang/String;)V
    //   800: athrow
    //   801: aload_0
    //   802: aload_1
    //   803: aload_0
    //   804: getfield u : Landroidx/fragment/app/h;
    //   807: invokevirtual g : ()Landroid/content/Context;
    //   810: iconst_0
    //   811: invokevirtual N : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   814: aload_1
    //   815: invokevirtual D0 : ()V
    //   818: aload_1
    //   819: getfield y : Landroidx/fragment/app/Fragment;
    //   822: astore #12
    //   824: aload #12
    //   826: ifnonnull -> 840
    //   829: aload_0
    //   830: getfield u : Landroidx/fragment/app/h;
    //   833: aload_1
    //   834: invokevirtual i : (Landroidx/fragment/app/Fragment;)V
    //   837: goto -> 846
    //   840: aload #12
    //   842: aload_1
    //   843: invokevirtual Z : (Landroidx/fragment/app/Fragment;)V
    //   846: aload_0
    //   847: aload_1
    //   848: aload_0
    //   849: getfield u : Landroidx/fragment/app/h;
    //   852: invokevirtual g : ()Landroid/content/Context;
    //   855: iconst_0
    //   856: invokevirtual I : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   859: aload_1
    //   860: getfield U : Z
    //   863: ifne -> 897
    //   866: aload_0
    //   867: aload_1
    //   868: aload_1
    //   869: getfield b : Landroid/os/Bundle;
    //   872: iconst_0
    //   873: invokevirtual O : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   876: aload_1
    //   877: aload_1
    //   878: getfield b : Landroid/os/Bundle;
    //   881: invokevirtual G0 : (Landroid/os/Bundle;)V
    //   884: aload_0
    //   885: aload_1
    //   886: aload_1
    //   887: getfield b : Landroid/os/Bundle;
    //   890: iconst_0
    //   891: invokevirtual J : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   894: goto -> 910
    //   897: aload_1
    //   898: aload_1
    //   899: getfield b : Landroid/os/Bundle;
    //   902: invokevirtual d1 : (Landroid/os/Bundle;)V
    //   905: aload_1
    //   906: iconst_1
    //   907: putfield a : I
    //   910: iload_3
    //   911: ifle -> 919
    //   914: aload_0
    //   915: aload_1
    //   916: invokevirtual k0 : (Landroidx/fragment/app/Fragment;)V
    //   919: iload_3
    //   920: istore #4
    //   922: iload_3
    //   923: iconst_1
    //   924: if_icmple -> 269
    //   927: getstatic androidx/fragment/app/j.L : Z
    //   930: ifeq -> 970
    //   933: new java/lang/StringBuilder
    //   936: dup
    //   937: invokespecial <init> : ()V
    //   940: astore #12
    //   942: aload #12
    //   944: ldc_w 'moveto ACTIVITY_CREATED: '
    //   947: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   950: pop
    //   951: aload #12
    //   953: aload_1
    //   954: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   957: pop
    //   958: ldc_w 'FragmentManager'
    //   961: aload #12
    //   963: invokevirtual toString : ()Ljava/lang/String;
    //   966: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   969: pop
    //   970: aload_1
    //   971: getfield q : Z
    //   974: ifne -> 1332
    //   977: aload_1
    //   978: getfield A : I
    //   981: istore_2
    //   982: iload_2
    //   983: ifeq -> 1185
    //   986: iload_2
    //   987: iconst_m1
    //   988: if_icmpne -> 1041
    //   991: new java/lang/StringBuilder
    //   994: dup
    //   995: invokespecial <init> : ()V
    //   998: astore #12
    //   1000: aload #12
    //   1002: ldc_w 'Cannot create fragment '
    //   1005: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1008: pop
    //   1009: aload #12
    //   1011: aload_1
    //   1012: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1015: pop
    //   1016: aload #12
    //   1018: ldc_w ' for a container view with no id'
    //   1021: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1024: pop
    //   1025: aload_0
    //   1026: new java/lang/IllegalArgumentException
    //   1029: dup
    //   1030: aload #12
    //   1032: invokevirtual toString : ()Ljava/lang/String;
    //   1035: invokespecial <init> : (Ljava/lang/String;)V
    //   1038: invokespecial n1 : (Ljava/lang/RuntimeException;)V
    //   1041: aload_0
    //   1042: getfield v : Landroidx/fragment/app/e;
    //   1045: aload_1
    //   1046: getfield A : I
    //   1049: invokevirtual c : (I)Landroid/view/View;
    //   1052: checkcast android/view/ViewGroup
    //   1055: astore #13
    //   1057: aload #13
    //   1059: astore #12
    //   1061: aload #13
    //   1063: ifnonnull -> 1188
    //   1066: aload #13
    //   1068: astore #12
    //   1070: aload_1
    //   1071: getfield s : Z
    //   1074: ifne -> 1188
    //   1077: aload_1
    //   1078: invokevirtual E : ()Landroid/content/res/Resources;
    //   1081: aload_1
    //   1082: getfield A : I
    //   1085: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1088: astore #12
    //   1090: goto -> 1098
    //   1093: ldc_w 'unknown'
    //   1096: astore #12
    //   1098: new java/lang/StringBuilder
    //   1101: dup
    //   1102: invokespecial <init> : ()V
    //   1105: astore #14
    //   1107: aload #14
    //   1109: ldc_w 'No view found for id 0x'
    //   1112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1115: pop
    //   1116: aload #14
    //   1118: aload_1
    //   1119: getfield A : I
    //   1122: invokestatic toHexString : (I)Ljava/lang/String;
    //   1125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1128: pop
    //   1129: aload #14
    //   1131: ldc_w ' ('
    //   1134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1137: pop
    //   1138: aload #14
    //   1140: aload #12
    //   1142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1145: pop
    //   1146: aload #14
    //   1148: ldc_w ') for fragment '
    //   1151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1154: pop
    //   1155: aload #14
    //   1157: aload_1
    //   1158: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1161: pop
    //   1162: aload_0
    //   1163: new java/lang/IllegalArgumentException
    //   1166: dup
    //   1167: aload #14
    //   1169: invokevirtual toString : ()Ljava/lang/String;
    //   1172: invokespecial <init> : (Ljava/lang/String;)V
    //   1175: invokespecial n1 : (Ljava/lang/RuntimeException;)V
    //   1178: aload #13
    //   1180: astore #12
    //   1182: goto -> 1188
    //   1185: aconst_null
    //   1186: astore #12
    //   1188: aload_1
    //   1189: aload #12
    //   1191: putfield J : Landroid/view/ViewGroup;
    //   1194: aload_1
    //   1195: aload_1
    //   1196: aload_1
    //   1197: getfield b : Landroid/os/Bundle;
    //   1200: invokevirtual M0 : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1203: aload #12
    //   1205: aload_1
    //   1206: getfield b : Landroid/os/Bundle;
    //   1209: invokevirtual I0 : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1212: aload_1
    //   1213: getfield K : Landroid/view/View;
    //   1216: astore #13
    //   1218: aload #13
    //   1220: ifnull -> 1327
    //   1223: aload_1
    //   1224: aload #13
    //   1226: putfield L : Landroid/view/View;
    //   1229: aload #13
    //   1231: iconst_0
    //   1232: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1235: aload #12
    //   1237: ifnull -> 1249
    //   1240: aload #12
    //   1242: aload_1
    //   1243: getfield K : Landroid/view/View;
    //   1246: invokevirtual addView : (Landroid/view/View;)V
    //   1249: aload_1
    //   1250: getfield C : Z
    //   1253: ifeq -> 1265
    //   1256: aload_1
    //   1257: getfield K : Landroid/view/View;
    //   1260: bipush #8
    //   1262: invokevirtual setVisibility : (I)V
    //   1265: aload_1
    //   1266: aload_1
    //   1267: getfield K : Landroid/view/View;
    //   1270: aload_1
    //   1271: getfield b : Landroid/os/Bundle;
    //   1274: invokevirtual A0 : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1277: aload_0
    //   1278: aload_1
    //   1279: aload_1
    //   1280: getfield K : Landroid/view/View;
    //   1283: aload_1
    //   1284: getfield b : Landroid/os/Bundle;
    //   1287: iconst_0
    //   1288: invokevirtual T : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1291: aload_1
    //   1292: getfield K : Landroid/view/View;
    //   1295: invokevirtual getVisibility : ()I
    //   1298: ifne -> 1315
    //   1301: aload_1
    //   1302: getfield J : Landroid/view/ViewGroup;
    //   1305: ifnull -> 1315
    //   1308: iload #9
    //   1310: istore #5
    //   1312: goto -> 1318
    //   1315: iconst_0
    //   1316: istore #5
    //   1318: aload_1
    //   1319: iload #5
    //   1321: putfield Q : Z
    //   1324: goto -> 1332
    //   1327: aload_1
    //   1328: aconst_null
    //   1329: putfield L : Landroid/view/View;
    //   1332: aload_1
    //   1333: aload_1
    //   1334: getfield b : Landroid/os/Bundle;
    //   1337: invokevirtual C0 : (Landroid/os/Bundle;)V
    //   1340: aload_0
    //   1341: aload_1
    //   1342: aload_1
    //   1343: getfield b : Landroid/os/Bundle;
    //   1346: iconst_0
    //   1347: invokevirtual H : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1350: aload_1
    //   1351: getfield K : Landroid/view/View;
    //   1354: ifnull -> 1365
    //   1357: aload_1
    //   1358: aload_1
    //   1359: getfield b : Landroid/os/Bundle;
    //   1362: invokevirtual e1 : (Landroid/os/Bundle;)V
    //   1365: aload_1
    //   1366: aconst_null
    //   1367: putfield b : Landroid/os/Bundle;
    //   1370: iload_3
    //   1371: istore #4
    //   1373: goto -> 269
    //   1376: iload #4
    //   1378: istore_3
    //   1379: iload #4
    //   1381: iconst_2
    //   1382: if_icmple -> 266
    //   1385: getstatic androidx/fragment/app/j.L : Z
    //   1388: ifeq -> 1428
    //   1391: new java/lang/StringBuilder
    //   1394: dup
    //   1395: invokespecial <init> : ()V
    //   1398: astore #12
    //   1400: aload #12
    //   1402: ldc_w 'moveto STARTED: '
    //   1405: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1408: pop
    //   1409: aload #12
    //   1411: aload_1
    //   1412: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1415: pop
    //   1416: ldc_w 'FragmentManager'
    //   1419: aload #12
    //   1421: invokevirtual toString : ()Ljava/lang/String;
    //   1424: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1427: pop
    //   1428: aload_1
    //   1429: invokevirtual X0 : ()V
    //   1432: aload_0
    //   1433: aload_1
    //   1434: iconst_0
    //   1435: invokevirtual R : (Landroidx/fragment/app/Fragment;Z)V
    //   1438: iload #4
    //   1440: istore_3
    //   1441: goto -> 266
    //   1444: iload_3
    //   1445: istore #6
    //   1447: iload_3
    //   1448: iconst_3
    //   1449: if_icmple -> 2318
    //   1452: getstatic androidx/fragment/app/j.L : Z
    //   1455: ifeq -> 1495
    //   1458: new java/lang/StringBuilder
    //   1461: dup
    //   1462: invokespecial <init> : ()V
    //   1465: astore #12
    //   1467: aload #12
    //   1469: ldc_w 'moveto RESUMED: '
    //   1472: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1475: pop
    //   1476: aload #12
    //   1478: aload_1
    //   1479: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1482: pop
    //   1483: ldc_w 'FragmentManager'
    //   1486: aload #12
    //   1488: invokevirtual toString : ()Ljava/lang/String;
    //   1491: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1494: pop
    //   1495: aload_1
    //   1496: invokevirtual V0 : ()V
    //   1499: aload_0
    //   1500: aload_1
    //   1501: iconst_0
    //   1502: invokevirtual P : (Landroidx/fragment/app/Fragment;Z)V
    //   1505: aload_1
    //   1506: aconst_null
    //   1507: putfield b : Landroid/os/Bundle;
    //   1510: aload_1
    //   1511: aconst_null
    //   1512: putfield c : Landroid/util/SparseArray;
    //   1515: iload_3
    //   1516: istore #6
    //   1518: goto -> 2318
    //   1521: iload_2
    //   1522: istore #6
    //   1524: iload #8
    //   1526: iload_2
    //   1527: if_icmple -> 2318
    //   1530: iload #8
    //   1532: iconst_1
    //   1533: if_icmpeq -> 1929
    //   1536: iload #8
    //   1538: iconst_2
    //   1539: if_icmpeq -> 1676
    //   1542: iload #8
    //   1544: iconst_3
    //   1545: if_icmpeq -> 1618
    //   1548: iload #8
    //   1550: iconst_4
    //   1551: if_icmpeq -> 1560
    //   1554: iload_2
    //   1555: istore #6
    //   1557: goto -> 2318
    //   1560: iload_2
    //   1561: iconst_4
    //   1562: if_icmpge -> 1618
    //   1565: getstatic androidx/fragment/app/j.L : Z
    //   1568: ifeq -> 1608
    //   1571: new java/lang/StringBuilder
    //   1574: dup
    //   1575: invokespecial <init> : ()V
    //   1578: astore #12
    //   1580: aload #12
    //   1582: ldc_w 'movefrom RESUMED: '
    //   1585: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1588: pop
    //   1589: aload #12
    //   1591: aload_1
    //   1592: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1595: pop
    //   1596: ldc_w 'FragmentManager'
    //   1599: aload #12
    //   1601: invokevirtual toString : ()Ljava/lang/String;
    //   1604: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1607: pop
    //   1608: aload_1
    //   1609: invokevirtual R0 : ()V
    //   1612: aload_0
    //   1613: aload_1
    //   1614: iconst_0
    //   1615: invokevirtual M : (Landroidx/fragment/app/Fragment;Z)V
    //   1618: iload_2
    //   1619: iconst_3
    //   1620: if_icmpge -> 1676
    //   1623: getstatic androidx/fragment/app/j.L : Z
    //   1626: ifeq -> 1666
    //   1629: new java/lang/StringBuilder
    //   1632: dup
    //   1633: invokespecial <init> : ()V
    //   1636: astore #12
    //   1638: aload #12
    //   1640: ldc_w 'movefrom STARTED: '
    //   1643: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1646: pop
    //   1647: aload #12
    //   1649: aload_1
    //   1650: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1653: pop
    //   1654: ldc_w 'FragmentManager'
    //   1657: aload #12
    //   1659: invokevirtual toString : ()Ljava/lang/String;
    //   1662: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1665: pop
    //   1666: aload_1
    //   1667: invokevirtual Y0 : ()V
    //   1670: aload_0
    //   1671: aload_1
    //   1672: iconst_0
    //   1673: invokevirtual S : (Landroidx/fragment/app/Fragment;Z)V
    //   1676: iload_2
    //   1677: iconst_2
    //   1678: if_icmpge -> 1929
    //   1681: getstatic androidx/fragment/app/j.L : Z
    //   1684: ifeq -> 1724
    //   1687: new java/lang/StringBuilder
    //   1690: dup
    //   1691: invokespecial <init> : ()V
    //   1694: astore #12
    //   1696: aload #12
    //   1698: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1701: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1704: pop
    //   1705: aload #12
    //   1707: aload_1
    //   1708: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1711: pop
    //   1712: ldc_w 'FragmentManager'
    //   1715: aload #12
    //   1717: invokevirtual toString : ()Ljava/lang/String;
    //   1720: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1723: pop
    //   1724: aload_1
    //   1725: getfield K : Landroid/view/View;
    //   1728: ifnull -> 1754
    //   1731: aload_0
    //   1732: getfield u : Landroidx/fragment/app/h;
    //   1735: aload_1
    //   1736: invokevirtual q : (Landroidx/fragment/app/Fragment;)Z
    //   1739: ifeq -> 1754
    //   1742: aload_1
    //   1743: getfield c : Landroid/util/SparseArray;
    //   1746: ifnonnull -> 1754
    //   1749: aload_0
    //   1750: aload_1
    //   1751: invokevirtual g1 : (Landroidx/fragment/app/Fragment;)V
    //   1754: aload_1
    //   1755: invokevirtual K0 : ()V
    //   1758: aload_0
    //   1759: aload_1
    //   1760: iconst_0
    //   1761: invokevirtual U : (Landroidx/fragment/app/Fragment;Z)V
    //   1764: aload_1
    //   1765: getfield K : Landroid/view/View;
    //   1768: astore #12
    //   1770: aload #12
    //   1772: ifnull -> 1896
    //   1775: aload_1
    //   1776: getfield J : Landroid/view/ViewGroup;
    //   1779: astore #13
    //   1781: aload #13
    //   1783: ifnull -> 1896
    //   1786: aload #13
    //   1788: aload #12
    //   1790: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1793: aload_1
    //   1794: getfield K : Landroid/view/View;
    //   1797: invokevirtual clearAnimation : ()V
    //   1800: aload_1
    //   1801: invokevirtual C : ()Landroidx/fragment/app/Fragment;
    //   1804: ifnull -> 1817
    //   1807: aload_1
    //   1808: invokevirtual C : ()Landroidx/fragment/app/Fragment;
    //   1811: getfield p : Z
    //   1814: ifne -> 1896
    //   1817: aload_0
    //   1818: getfield t : I
    //   1821: ifle -> 1864
    //   1824: aload_0
    //   1825: getfield B : Z
    //   1828: ifne -> 1864
    //   1831: aload_1
    //   1832: getfield K : Landroid/view/View;
    //   1835: invokevirtual getVisibility : ()I
    //   1838: ifne -> 1864
    //   1841: aload_1
    //   1842: getfield S : F
    //   1845: fconst_0
    //   1846: fcmpl
    //   1847: iflt -> 1864
    //   1850: aload_0
    //   1851: aload_1
    //   1852: iload_3
    //   1853: iconst_0
    //   1854: iload #4
    //   1856: invokevirtual I0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/j$g;
    //   1859: astore #12
    //   1861: goto -> 1867
    //   1864: aconst_null
    //   1865: astore #12
    //   1867: aload_1
    //   1868: fconst_0
    //   1869: putfield S : F
    //   1872: aload #12
    //   1874: ifnull -> 1885
    //   1877: aload_0
    //   1878: aload_1
    //   1879: aload #12
    //   1881: iload_2
    //   1882: invokespecial o : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/j$g;I)V
    //   1885: aload_1
    //   1886: getfield J : Landroid/view/ViewGroup;
    //   1889: aload_1
    //   1890: getfield K : Landroid/view/View;
    //   1893: invokevirtual removeView : (Landroid/view/View;)V
    //   1896: aload_1
    //   1897: aconst_null
    //   1898: putfield J : Landroid/view/ViewGroup;
    //   1901: aload_1
    //   1902: aconst_null
    //   1903: putfield K : Landroid/view/View;
    //   1906: aload_1
    //   1907: aconst_null
    //   1908: putfield X : Landroidx/fragment/app/r;
    //   1911: aload_1
    //   1912: getfield Y : Landroidx/lifecycle/p;
    //   1915: aconst_null
    //   1916: invokevirtual m : (Ljava/lang/Object;)V
    //   1919: aload_1
    //   1920: aconst_null
    //   1921: putfield L : Landroid/view/View;
    //   1924: aload_1
    //   1925: iconst_0
    //   1926: putfield r : Z
    //   1929: iload_2
    //   1930: istore #6
    //   1932: iload_2
    //   1933: iconst_1
    //   1934: if_icmpge -> 2318
    //   1937: aload_0
    //   1938: getfield B : Z
    //   1941: ifeq -> 1993
    //   1944: aload_1
    //   1945: invokevirtual o : ()Landroid/view/View;
    //   1948: ifnull -> 1970
    //   1951: aload_1
    //   1952: invokevirtual o : ()Landroid/view/View;
    //   1955: astore #12
    //   1957: aload_1
    //   1958: aconst_null
    //   1959: invokevirtual f1 : (Landroid/view/View;)V
    //   1962: aload #12
    //   1964: invokevirtual clearAnimation : ()V
    //   1967: goto -> 1993
    //   1970: aload_1
    //   1971: invokevirtual p : ()Landroid/animation/Animator;
    //   1974: ifnull -> 1993
    //   1977: aload_1
    //   1978: invokevirtual p : ()Landroid/animation/Animator;
    //   1981: astore #12
    //   1983: aload_1
    //   1984: aconst_null
    //   1985: invokevirtual g1 : (Landroid/animation/Animator;)V
    //   1988: aload #12
    //   1990: invokevirtual cancel : ()V
    //   1993: aload_1
    //   1994: invokevirtual o : ()Landroid/view/View;
    //   1997: ifnonnull -> 2306
    //   2000: aload_1
    //   2001: invokevirtual p : ()Landroid/animation/Animator;
    //   2004: ifnull -> 2010
    //   2007: goto -> 2306
    //   2010: getstatic androidx/fragment/app/j.L : Z
    //   2013: ifeq -> 2053
    //   2016: new java/lang/StringBuilder
    //   2019: dup
    //   2020: invokespecial <init> : ()V
    //   2023: astore #12
    //   2025: aload #12
    //   2027: ldc_w 'movefrom CREATED: '
    //   2030: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2033: pop
    //   2034: aload #12
    //   2036: aload_1
    //   2037: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2040: pop
    //   2041: ldc_w 'FragmentManager'
    //   2044: aload #12
    //   2046: invokevirtual toString : ()Ljava/lang/String;
    //   2049: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2052: pop
    //   2053: aload_1
    //   2054: getfield p : Z
    //   2057: ifeq -> 2072
    //   2060: aload_1
    //   2061: invokevirtual Q : ()Z
    //   2064: ifne -> 2072
    //   2067: iconst_1
    //   2068: istore_3
    //   2069: goto -> 2074
    //   2072: iconst_0
    //   2073: istore_3
    //   2074: iload_3
    //   2075: ifne -> 2100
    //   2078: aload_0
    //   2079: getfield J : Landroidx/fragment/app/l;
    //   2082: aload_1
    //   2083: invokevirtual m : (Landroidx/fragment/app/Fragment;)Z
    //   2086: ifeq -> 2092
    //   2089: goto -> 2100
    //   2092: aload_1
    //   2093: iconst_0
    //   2094: putfield a : I
    //   2097: goto -> 2185
    //   2100: aload_0
    //   2101: getfield u : Landroidx/fragment/app/h;
    //   2104: astore #12
    //   2106: aload #12
    //   2108: instanceof androidx/lifecycle/g0
    //   2111: ifeq -> 2126
    //   2114: aload_0
    //   2115: getfield J : Landroidx/fragment/app/l;
    //   2118: invokevirtual k : ()Z
    //   2121: istore #9
    //   2123: goto -> 2158
    //   2126: iload #10
    //   2128: istore #9
    //   2130: aload #12
    //   2132: invokevirtual g : ()Landroid/content/Context;
    //   2135: instanceof android/app/Activity
    //   2138: ifeq -> 2158
    //   2141: iconst_1
    //   2142: aload_0
    //   2143: getfield u : Landroidx/fragment/app/h;
    //   2146: invokevirtual g : ()Landroid/content/Context;
    //   2149: checkcast android/app/Activity
    //   2152: invokevirtual isChangingConfigurations : ()Z
    //   2155: ixor
    //   2156: istore #9
    //   2158: iload_3
    //   2159: ifne -> 2167
    //   2162: iload #9
    //   2164: ifeq -> 2175
    //   2167: aload_0
    //   2168: getfield J : Landroidx/fragment/app/l;
    //   2171: aload_1
    //   2172: invokevirtual f : (Landroidx/fragment/app/Fragment;)V
    //   2175: aload_1
    //   2176: invokevirtual J0 : ()V
    //   2179: aload_0
    //   2180: aload_1
    //   2181: iconst_0
    //   2182: invokevirtual K : (Landroidx/fragment/app/Fragment;Z)V
    //   2185: aload_1
    //   2186: invokevirtual L0 : ()V
    //   2189: aload_0
    //   2190: aload_1
    //   2191: iconst_0
    //   2192: invokevirtual L : (Landroidx/fragment/app/Fragment;Z)V
    //   2195: iload_2
    //   2196: istore #6
    //   2198: iload #5
    //   2200: ifne -> 2318
    //   2203: iload_3
    //   2204: ifne -> 2295
    //   2207: aload_0
    //   2208: getfield J : Landroidx/fragment/app/l;
    //   2211: aload_1
    //   2212: invokevirtual m : (Landroidx/fragment/app/Fragment;)Z
    //   2215: ifeq -> 2221
    //   2218: goto -> 2295
    //   2221: aload_1
    //   2222: aconst_null
    //   2223: putfield w : Landroidx/fragment/app/h;
    //   2226: aload_1
    //   2227: aconst_null
    //   2228: putfield y : Landroidx/fragment/app/Fragment;
    //   2231: aload_1
    //   2232: aconst_null
    //   2233: putfield v : Landroidx/fragment/app/j;
    //   2236: aload_1
    //   2237: getfield l : Ljava/lang/String;
    //   2240: astore #12
    //   2242: iload_2
    //   2243: istore #6
    //   2245: aload #12
    //   2247: ifnull -> 2318
    //   2250: aload_0
    //   2251: getfield g : Ljava/util/HashMap;
    //   2254: aload #12
    //   2256: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2259: checkcast androidx/fragment/app/Fragment
    //   2262: astore #12
    //   2264: iload_2
    //   2265: istore #6
    //   2267: aload #12
    //   2269: ifnull -> 2318
    //   2272: iload_2
    //   2273: istore #6
    //   2275: aload #12
    //   2277: invokevirtual F : ()Z
    //   2280: ifeq -> 2318
    //   2283: aload_1
    //   2284: aload #12
    //   2286: putfield g : Landroidx/fragment/app/Fragment;
    //   2289: iload_2
    //   2290: istore #6
    //   2292: goto -> 2318
    //   2295: aload_0
    //   2296: aload_1
    //   2297: invokevirtual L0 : (Landroidx/fragment/app/Fragment;)V
    //   2300: iload_2
    //   2301: istore #6
    //   2303: goto -> 2318
    //   2306: aload_1
    //   2307: iload_2
    //   2308: invokevirtual m1 : (I)V
    //   2311: iload #7
    //   2313: istore #6
    //   2315: goto -> 2318
    //   2318: aload_1
    //   2319: getfield a : I
    //   2322: iload #6
    //   2324: if_icmpeq -> 2406
    //   2327: new java/lang/StringBuilder
    //   2330: dup
    //   2331: invokespecial <init> : ()V
    //   2334: astore #12
    //   2336: aload #12
    //   2338: ldc_w 'moveToState: Fragment state for '
    //   2341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2344: pop
    //   2345: aload #12
    //   2347: aload_1
    //   2348: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2351: pop
    //   2352: aload #12
    //   2354: ldc_w ' not updated inline; expected state '
    //   2357: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2360: pop
    //   2361: aload #12
    //   2363: iload #6
    //   2365: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2368: pop
    //   2369: aload #12
    //   2371: ldc_w ' found '
    //   2374: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2377: pop
    //   2378: aload #12
    //   2380: aload_1
    //   2381: getfield a : I
    //   2384: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2387: pop
    //   2388: ldc_w 'FragmentManager'
    //   2391: aload #12
    //   2393: invokevirtual toString : ()Ljava/lang/String;
    //   2396: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2399: pop
    //   2400: aload_1
    //   2401: iload #6
    //   2403: putfield a : I
    //   2406: return
    //   2407: astore #12
    //   2409: goto -> 1093
    // Exception table:
    //   from	to	target	type
    //   1077	1090	2407	android/content/res/Resources$NotFoundException
  }
  
  void S(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).S(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  public void S0() {
    int k = 0;
    this.z = false;
    this.A = false;
    int m = this.f.size();
    while (k < m) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.U(); 
      k++;
    } 
  }
  
  void T(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).T(paramFragment, paramView, paramBundle, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  public void T0(Fragment paramFragment) {
    if (paramFragment.M) {
      if (this.d) {
        this.C = true;
        return;
      } 
      paramFragment.M = false;
      R0(paramFragment, this.t, 0, 0, false);
    } 
  }
  
  void U(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.w;
    if (fragment != null) {
      i i1 = fragment.w();
      if (i1 instanceof j)
        ((j)i1).U(paramFragment, true); 
    } 
    Iterator<i> iterator = this.s.iterator();
    while (iterator.hasNext()) {
      i i1 = iterator.next();
      if (paramBoolean && !i1.b)
        continue; 
      i.a a = i1.a;
      throw null;
    } 
  }
  
  public boolean V(MenuItem paramMenuItem) {
    if (this.t < 1)
      return false; 
    for (int k = 0; k < this.f.size(); k++) {
      Fragment fragment = this.f.get(k);
      if (fragment != null && fragment.P0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  boolean V0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield l : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield l : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: aload_3
    //   70: ifnonnull -> 87
    //   73: iload #4
    //   75: iflt -> 81
    //   78: goto -> 87
    //   81: iconst_m1
    //   82: istore #4
    //   84: goto -> 262
    //   87: aload #8
    //   89: invokevirtual size : ()I
    //   92: iconst_1
    //   93: isub
    //   94: istore #6
    //   96: iload #6
    //   98: iflt -> 161
    //   101: aload_0
    //   102: getfield l : Ljava/util/ArrayList;
    //   105: iload #6
    //   107: invokevirtual get : (I)Ljava/lang/Object;
    //   110: checkcast androidx/fragment/app/a
    //   113: astore #8
    //   115: aload_3
    //   116: ifnull -> 134
    //   119: aload_3
    //   120: aload #8
    //   122: invokevirtual o : ()Ljava/lang/String;
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 134
    //   131: goto -> 161
    //   134: iload #4
    //   136: iflt -> 152
    //   139: iload #4
    //   141: aload #8
    //   143: getfield u : I
    //   146: if_icmpne -> 152
    //   149: goto -> 161
    //   152: iload #6
    //   154: iconst_1
    //   155: isub
    //   156: istore #6
    //   158: goto -> 96
    //   161: iload #6
    //   163: ifge -> 168
    //   166: iconst_0
    //   167: ireturn
    //   168: iload #6
    //   170: istore #7
    //   172: iload #5
    //   174: iconst_1
    //   175: iand
    //   176: ifeq -> 258
    //   179: iload #6
    //   181: iconst_1
    //   182: isub
    //   183: istore #5
    //   185: iload #5
    //   187: istore #7
    //   189: iload #5
    //   191: iflt -> 258
    //   194: aload_0
    //   195: getfield l : Ljava/util/ArrayList;
    //   198: iload #5
    //   200: invokevirtual get : (I)Ljava/lang/Object;
    //   203: checkcast androidx/fragment/app/a
    //   206: astore #8
    //   208: aload_3
    //   209: ifnull -> 228
    //   212: iload #5
    //   214: istore #6
    //   216: aload_3
    //   217: aload #8
    //   219: invokevirtual o : ()Ljava/lang/String;
    //   222: invokevirtual equals : (Ljava/lang/Object;)Z
    //   225: ifne -> 179
    //   228: iload #5
    //   230: istore #7
    //   232: iload #4
    //   234: iflt -> 258
    //   237: iload #5
    //   239: istore #7
    //   241: iload #4
    //   243: aload #8
    //   245: getfield u : I
    //   248: if_icmpne -> 258
    //   251: iload #5
    //   253: istore #6
    //   255: goto -> 179
    //   258: iload #7
    //   260: istore #4
    //   262: iload #4
    //   264: aload_0
    //   265: getfield l : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: iconst_1
    //   272: isub
    //   273: if_icmpne -> 278
    //   276: iconst_0
    //   277: ireturn
    //   278: aload_0
    //   279: getfield l : Ljava/util/ArrayList;
    //   282: invokevirtual size : ()I
    //   285: iconst_1
    //   286: isub
    //   287: istore #5
    //   289: iload #5
    //   291: iload #4
    //   293: if_icmple -> 327
    //   296: aload_1
    //   297: aload_0
    //   298: getfield l : Ljava/util/ArrayList;
    //   301: iload #5
    //   303: invokevirtual remove : (I)Ljava/lang/Object;
    //   306: invokevirtual add : (Ljava/lang/Object;)Z
    //   309: pop
    //   310: aload_2
    //   311: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   314: invokevirtual add : (Ljava/lang/Object;)Z
    //   317: pop
    //   318: iload #5
    //   320: iconst_1
    //   321: isub
    //   322: istore #5
    //   324: goto -> 289
    //   327: iconst_1
    //   328: ireturn
  }
  
  public void W(Menu paramMenu) {
    if (this.t < 1)
      return; 
    for (int k = 0; k < this.f.size(); k++) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.Q0(paramMenu); 
    } 
  }
  
  public void X0(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.v != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      n1(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.e);
  }
  
  public void Y() {
    e0(3);
  }
  
  public void Y0(Fragment paramFragment) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.u);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.Q();
    if (!paramFragment.D || (bool ^ true) != 0)
      synchronized (this.f) {
        this.f.remove(paramFragment);
        if (E0(paramFragment))
          this.y = true; 
        paramFragment.o = false;
        paramFragment.p = true;
        return;
      }  
  }
  
  public void Z(boolean paramBoolean) {
    for (int k = this.f.size() - 1; k >= 0; k--) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.S0(paramBoolean); 
    } 
  }
  
  public n a() {
    return new a(this);
  }
  
  public boolean a0(Menu paramMenu) {
    int m = this.t;
    int k = 0;
    if (m < 1)
      return false; 
    boolean bool;
    for (bool = false; k < this.f.size(); bool = bool1) {
      Fragment fragment = this.f.get(k);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.T0(paramMenu))
          bool1 = true; 
      } 
      k++;
    } 
    return bool;
  }
  
  void a1(Fragment paramFragment) {
    if (H0()) {
      if (L)
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.J.l(paramFragment) && L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield g : Ljava/util/HashMap;
    //   36: invokevirtual isEmpty : ()Z
    //   39: ifne -> 138
    //   42: aload_3
    //   43: aload_1
    //   44: invokevirtual print : (Ljava/lang/String;)V
    //   47: aload_3
    //   48: ldc_w 'Active Fragments in '
    //   51: invokevirtual print : (Ljava/lang/String;)V
    //   54: aload_3
    //   55: aload_0
    //   56: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   59: invokestatic toHexString : (I)Ljava/lang/String;
    //   62: invokevirtual print : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: ldc_w ':'
    //   69: invokevirtual println : (Ljava/lang/String;)V
    //   72: aload_0
    //   73: getfield g : Ljava/util/HashMap;
    //   76: invokevirtual values : ()Ljava/util/Collection;
    //   79: invokeinterface iterator : ()Ljava/util/Iterator;
    //   84: astore #9
    //   86: aload #9
    //   88: invokeinterface hasNext : ()Z
    //   93: ifeq -> 138
    //   96: aload #9
    //   98: invokeinterface next : ()Ljava/lang/Object;
    //   103: checkcast androidx/fragment/app/Fragment
    //   106: astore #10
    //   108: aload_3
    //   109: aload_1
    //   110: invokevirtual print : (Ljava/lang/String;)V
    //   113: aload_3
    //   114: aload #10
    //   116: invokevirtual println : (Ljava/lang/Object;)V
    //   119: aload #10
    //   121: ifnull -> 86
    //   124: aload #10
    //   126: aload #8
    //   128: aload_2
    //   129: aload_3
    //   130: aload #4
    //   132: invokevirtual g : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   135: goto -> 86
    //   138: aload_0
    //   139: getfield f : Ljava/util/ArrayList;
    //   142: invokevirtual size : ()I
    //   145: istore #7
    //   147: iconst_0
    //   148: istore #6
    //   150: iload #7
    //   152: ifle -> 232
    //   155: aload_3
    //   156: aload_1
    //   157: invokevirtual print : (Ljava/lang/String;)V
    //   160: aload_3
    //   161: ldc_w 'Added Fragments:'
    //   164: invokevirtual println : (Ljava/lang/String;)V
    //   167: iconst_0
    //   168: istore #5
    //   170: iload #5
    //   172: iload #7
    //   174: if_icmpge -> 232
    //   177: aload_0
    //   178: getfield f : Ljava/util/ArrayList;
    //   181: iload #5
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast androidx/fragment/app/Fragment
    //   189: astore_2
    //   190: aload_3
    //   191: aload_1
    //   192: invokevirtual print : (Ljava/lang/String;)V
    //   195: aload_3
    //   196: ldc_w '  #'
    //   199: invokevirtual print : (Ljava/lang/String;)V
    //   202: aload_3
    //   203: iload #5
    //   205: invokevirtual print : (I)V
    //   208: aload_3
    //   209: ldc_w ': '
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: aload_2
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual println : (Ljava/lang/String;)V
    //   223: iload #5
    //   225: iconst_1
    //   226: iadd
    //   227: istore #5
    //   229: goto -> 170
    //   232: aload_0
    //   233: getfield m : Ljava/util/ArrayList;
    //   236: astore_2
    //   237: aload_2
    //   238: ifnull -> 329
    //   241: aload_2
    //   242: invokevirtual size : ()I
    //   245: istore #7
    //   247: iload #7
    //   249: ifle -> 329
    //   252: aload_3
    //   253: aload_1
    //   254: invokevirtual print : (Ljava/lang/String;)V
    //   257: aload_3
    //   258: ldc_w 'Fragments Created Menus:'
    //   261: invokevirtual println : (Ljava/lang/String;)V
    //   264: iconst_0
    //   265: istore #5
    //   267: iload #5
    //   269: iload #7
    //   271: if_icmpge -> 329
    //   274: aload_0
    //   275: getfield m : Ljava/util/ArrayList;
    //   278: iload #5
    //   280: invokevirtual get : (I)Ljava/lang/Object;
    //   283: checkcast androidx/fragment/app/Fragment
    //   286: astore_2
    //   287: aload_3
    //   288: aload_1
    //   289: invokevirtual print : (Ljava/lang/String;)V
    //   292: aload_3
    //   293: ldc_w '  #'
    //   296: invokevirtual print : (Ljava/lang/String;)V
    //   299: aload_3
    //   300: iload #5
    //   302: invokevirtual print : (I)V
    //   305: aload_3
    //   306: ldc_w ': '
    //   309: invokevirtual print : (Ljava/lang/String;)V
    //   312: aload_3
    //   313: aload_2
    //   314: invokevirtual toString : ()Ljava/lang/String;
    //   317: invokevirtual println : (Ljava/lang/String;)V
    //   320: iload #5
    //   322: iconst_1
    //   323: iadd
    //   324: istore #5
    //   326: goto -> 267
    //   329: aload_0
    //   330: getfield l : Ljava/util/ArrayList;
    //   333: astore_2
    //   334: aload_2
    //   335: ifnull -> 433
    //   338: aload_2
    //   339: invokevirtual size : ()I
    //   342: istore #7
    //   344: iload #7
    //   346: ifle -> 433
    //   349: aload_3
    //   350: aload_1
    //   351: invokevirtual print : (Ljava/lang/String;)V
    //   354: aload_3
    //   355: ldc_w 'Back Stack:'
    //   358: invokevirtual println : (Ljava/lang/String;)V
    //   361: iconst_0
    //   362: istore #5
    //   364: iload #5
    //   366: iload #7
    //   368: if_icmpge -> 433
    //   371: aload_0
    //   372: getfield l : Ljava/util/ArrayList;
    //   375: iload #5
    //   377: invokevirtual get : (I)Ljava/lang/Object;
    //   380: checkcast androidx/fragment/app/a
    //   383: astore_2
    //   384: aload_3
    //   385: aload_1
    //   386: invokevirtual print : (Ljava/lang/String;)V
    //   389: aload_3
    //   390: ldc_w '  #'
    //   393: invokevirtual print : (Ljava/lang/String;)V
    //   396: aload_3
    //   397: iload #5
    //   399: invokevirtual print : (I)V
    //   402: aload_3
    //   403: ldc_w ': '
    //   406: invokevirtual print : (Ljava/lang/String;)V
    //   409: aload_3
    //   410: aload_2
    //   411: invokevirtual toString : ()Ljava/lang/String;
    //   414: invokevirtual println : (Ljava/lang/String;)V
    //   417: aload_2
    //   418: aload #8
    //   420: aload_3
    //   421: invokevirtual j : (Ljava/lang/String;Ljava/io/PrintWriter;)V
    //   424: iload #5
    //   426: iconst_1
    //   427: iadd
    //   428: istore #5
    //   430: goto -> 364
    //   433: aload_0
    //   434: monitorenter
    //   435: aload_0
    //   436: getfield p : Ljava/util/ArrayList;
    //   439: astore_2
    //   440: aload_2
    //   441: ifnull -> 529
    //   444: aload_2
    //   445: invokevirtual size : ()I
    //   448: istore #7
    //   450: iload #7
    //   452: ifle -> 529
    //   455: aload_3
    //   456: aload_1
    //   457: invokevirtual print : (Ljava/lang/String;)V
    //   460: aload_3
    //   461: ldc_w 'Back Stack Indices:'
    //   464: invokevirtual println : (Ljava/lang/String;)V
    //   467: iconst_0
    //   468: istore #5
    //   470: iload #5
    //   472: iload #7
    //   474: if_icmpge -> 529
    //   477: aload_0
    //   478: getfield p : Ljava/util/ArrayList;
    //   481: iload #5
    //   483: invokevirtual get : (I)Ljava/lang/Object;
    //   486: checkcast androidx/fragment/app/a
    //   489: astore_2
    //   490: aload_3
    //   491: aload_1
    //   492: invokevirtual print : (Ljava/lang/String;)V
    //   495: aload_3
    //   496: ldc_w '  #'
    //   499: invokevirtual print : (Ljava/lang/String;)V
    //   502: aload_3
    //   503: iload #5
    //   505: invokevirtual print : (I)V
    //   508: aload_3
    //   509: ldc_w ': '
    //   512: invokevirtual print : (Ljava/lang/String;)V
    //   515: aload_3
    //   516: aload_2
    //   517: invokevirtual println : (Ljava/lang/Object;)V
    //   520: iload #5
    //   522: iconst_1
    //   523: iadd
    //   524: istore #5
    //   526: goto -> 470
    //   529: aload_0
    //   530: getfield q : Ljava/util/ArrayList;
    //   533: astore_2
    //   534: aload_2
    //   535: ifnull -> 571
    //   538: aload_2
    //   539: invokevirtual size : ()I
    //   542: ifle -> 571
    //   545: aload_3
    //   546: aload_1
    //   547: invokevirtual print : (Ljava/lang/String;)V
    //   550: aload_3
    //   551: ldc_w 'mAvailBackStackIndices: '
    //   554: invokevirtual print : (Ljava/lang/String;)V
    //   557: aload_3
    //   558: aload_0
    //   559: getfield q : Ljava/util/ArrayList;
    //   562: invokevirtual toArray : ()[Ljava/lang/Object;
    //   565: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   568: invokevirtual println : (Ljava/lang/String;)V
    //   571: aload_0
    //   572: monitorexit
    //   573: aload_0
    //   574: getfield c : Ljava/util/ArrayList;
    //   577: astore_2
    //   578: aload_2
    //   579: ifnull -> 668
    //   582: aload_2
    //   583: invokevirtual size : ()I
    //   586: istore #7
    //   588: iload #7
    //   590: ifle -> 668
    //   593: aload_3
    //   594: aload_1
    //   595: invokevirtual print : (Ljava/lang/String;)V
    //   598: aload_3
    //   599: ldc_w 'Pending Actions:'
    //   602: invokevirtual println : (Ljava/lang/String;)V
    //   605: iload #6
    //   607: istore #5
    //   609: iload #5
    //   611: iload #7
    //   613: if_icmpge -> 668
    //   616: aload_0
    //   617: getfield c : Ljava/util/ArrayList;
    //   620: iload #5
    //   622: invokevirtual get : (I)Ljava/lang/Object;
    //   625: checkcast androidx/fragment/app/j$k
    //   628: astore_2
    //   629: aload_3
    //   630: aload_1
    //   631: invokevirtual print : (Ljava/lang/String;)V
    //   634: aload_3
    //   635: ldc_w '  #'
    //   638: invokevirtual print : (Ljava/lang/String;)V
    //   641: aload_3
    //   642: iload #5
    //   644: invokevirtual print : (I)V
    //   647: aload_3
    //   648: ldc_w ': '
    //   651: invokevirtual print : (Ljava/lang/String;)V
    //   654: aload_3
    //   655: aload_2
    //   656: invokevirtual println : (Ljava/lang/Object;)V
    //   659: iload #5
    //   661: iconst_1
    //   662: iadd
    //   663: istore #5
    //   665: goto -> 609
    //   668: aload_3
    //   669: aload_1
    //   670: invokevirtual print : (Ljava/lang/String;)V
    //   673: aload_3
    //   674: ldc_w 'FragmentManager misc state:'
    //   677: invokevirtual println : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_1
    //   682: invokevirtual print : (Ljava/lang/String;)V
    //   685: aload_3
    //   686: ldc_w '  mHost='
    //   689: invokevirtual print : (Ljava/lang/String;)V
    //   692: aload_3
    //   693: aload_0
    //   694: getfield u : Landroidx/fragment/app/h;
    //   697: invokevirtual println : (Ljava/lang/Object;)V
    //   700: aload_3
    //   701: aload_1
    //   702: invokevirtual print : (Ljava/lang/String;)V
    //   705: aload_3
    //   706: ldc_w '  mContainer='
    //   709: invokevirtual print : (Ljava/lang/String;)V
    //   712: aload_3
    //   713: aload_0
    //   714: getfield v : Landroidx/fragment/app/e;
    //   717: invokevirtual println : (Ljava/lang/Object;)V
    //   720: aload_0
    //   721: getfield w : Landroidx/fragment/app/Fragment;
    //   724: ifnull -> 747
    //   727: aload_3
    //   728: aload_1
    //   729: invokevirtual print : (Ljava/lang/String;)V
    //   732: aload_3
    //   733: ldc_w '  mParent='
    //   736: invokevirtual print : (Ljava/lang/String;)V
    //   739: aload_3
    //   740: aload_0
    //   741: getfield w : Landroidx/fragment/app/Fragment;
    //   744: invokevirtual println : (Ljava/lang/Object;)V
    //   747: aload_3
    //   748: aload_1
    //   749: invokevirtual print : (Ljava/lang/String;)V
    //   752: aload_3
    //   753: ldc_w '  mCurState='
    //   756: invokevirtual print : (Ljava/lang/String;)V
    //   759: aload_3
    //   760: aload_0
    //   761: getfield t : I
    //   764: invokevirtual print : (I)V
    //   767: aload_3
    //   768: ldc_w ' mStateSaved='
    //   771: invokevirtual print : (Ljava/lang/String;)V
    //   774: aload_3
    //   775: aload_0
    //   776: getfield z : Z
    //   779: invokevirtual print : (Z)V
    //   782: aload_3
    //   783: ldc_w ' mStopped='
    //   786: invokevirtual print : (Ljava/lang/String;)V
    //   789: aload_3
    //   790: aload_0
    //   791: getfield A : Z
    //   794: invokevirtual print : (Z)V
    //   797: aload_3
    //   798: ldc_w ' mDestroyed='
    //   801: invokevirtual print : (Ljava/lang/String;)V
    //   804: aload_3
    //   805: aload_0
    //   806: getfield B : Z
    //   809: invokevirtual println : (Z)V
    //   812: aload_0
    //   813: getfield y : Z
    //   816: ifeq -> 839
    //   819: aload_3
    //   820: aload_1
    //   821: invokevirtual print : (Ljava/lang/String;)V
    //   824: aload_3
    //   825: ldc_w '  mNeedMenuInvalidate='
    //   828: invokevirtual print : (Ljava/lang/String;)V
    //   831: aload_3
    //   832: aload_0
    //   833: getfield y : Z
    //   836: invokevirtual println : (Z)V
    //   839: return
    //   840: astore_1
    //   841: aload_0
    //   842: monitorexit
    //   843: aload_1
    //   844: athrow
    // Exception table:
    //   from	to	target	type
    //   435	440	840	finally
    //   444	450	840	finally
    //   455	467	840	finally
    //   477	520	840	finally
    //   529	534	840	finally
    //   538	571	840	finally
    //   571	573	840	finally
    //   841	843	840	finally
  }
  
  void b0() {
    p1();
    X(this.x);
  }
  
  void b1() {
    if (this.r != null)
      for (int k = 0; k < this.r.size(); k++)
        ((i.b)this.r.get(k)).a();  
  }
  
  public boolean c() {
    boolean bool = l0();
    s0();
    return bool;
  }
  
  public void c0() {
    this.z = false;
    this.A = false;
    e0(4);
  }
  
  void c1(Parcelable paramParcelable) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/k
    //   9: astore #5
    //   11: aload #5
    //   13: getfield a : Ljava/util/ArrayList;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_0
    //   21: getfield J : Landroidx/fragment/app/l;
    //   24: invokevirtual i : ()Ljava/util/Collection;
    //   27: invokeinterface iterator : ()Ljava/util/Iterator;
    //   32: astore #6
    //   34: aload #6
    //   36: invokeinterface hasNext : ()Z
    //   41: ifeq -> 359
    //   44: aload #6
    //   46: invokeinterface next : ()Ljava/lang/Object;
    //   51: checkcast androidx/fragment/app/Fragment
    //   54: astore #7
    //   56: getstatic androidx/fragment/app/j.L : Z
    //   59: ifeq -> 96
    //   62: new java/lang/StringBuilder
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: astore_1
    //   70: aload_1
    //   71: ldc_w 'restoreSaveState: re-attaching retained '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload_1
    //   79: aload #7
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload_1
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload #5
    //   98: getfield a : Ljava/util/ArrayList;
    //   101: invokevirtual iterator : ()Ljava/util/Iterator;
    //   104: astore #4
    //   106: aload #4
    //   108: invokeinterface hasNext : ()Z
    //   113: ifeq -> 145
    //   116: aload #4
    //   118: invokeinterface next : ()Ljava/lang/Object;
    //   123: checkcast androidx/fragment/app/m
    //   126: astore_1
    //   127: aload_1
    //   128: getfield b : Ljava/lang/String;
    //   131: aload #7
    //   133: getfield e : Ljava/lang/String;
    //   136: invokevirtual equals : (Ljava/lang/Object;)Z
    //   139: ifeq -> 106
    //   142: goto -> 147
    //   145: aconst_null
    //   146: astore_1
    //   147: aload_1
    //   148: ifnonnull -> 238
    //   151: getstatic androidx/fragment/app/j.L : Z
    //   154: ifeq -> 209
    //   157: new java/lang/StringBuilder
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: astore_1
    //   165: aload_1
    //   166: ldc_w 'Discarding retained Fragment '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_1
    //   174: aload #7
    //   176: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload_1
    //   181: ldc_w ' that was not found in the set of active Fragments '
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload_1
    //   189: aload #5
    //   191: getfield a : Ljava/util/ArrayList;
    //   194: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: ldc_w 'FragmentManager'
    //   201: aload_1
    //   202: invokevirtual toString : ()Ljava/lang/String;
    //   205: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   208: pop
    //   209: aload_0
    //   210: aload #7
    //   212: iconst_1
    //   213: iconst_0
    //   214: iconst_0
    //   215: iconst_0
    //   216: invokevirtual R0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   219: aload #7
    //   221: iconst_1
    //   222: putfield p : Z
    //   225: aload_0
    //   226: aload #7
    //   228: iconst_0
    //   229: iconst_0
    //   230: iconst_0
    //   231: iconst_0
    //   232: invokevirtual R0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   235: goto -> 34
    //   238: aload_1
    //   239: aload #7
    //   241: putfield r : Landroidx/fragment/app/Fragment;
    //   244: aload #7
    //   246: aconst_null
    //   247: putfield c : Landroid/util/SparseArray;
    //   250: aload #7
    //   252: iconst_0
    //   253: putfield u : I
    //   256: aload #7
    //   258: iconst_0
    //   259: putfield r : Z
    //   262: aload #7
    //   264: iconst_0
    //   265: putfield o : Z
    //   268: aload #7
    //   270: getfield g : Landroidx/fragment/app/Fragment;
    //   273: astore #4
    //   275: aload #4
    //   277: ifnull -> 290
    //   280: aload #4
    //   282: getfield e : Ljava/lang/String;
    //   285: astore #4
    //   287: goto -> 293
    //   290: aconst_null
    //   291: astore #4
    //   293: aload #7
    //   295: aload #4
    //   297: putfield l : Ljava/lang/String;
    //   300: aload #7
    //   302: aconst_null
    //   303: putfield g : Landroidx/fragment/app/Fragment;
    //   306: aload_1
    //   307: getfield q : Landroid/os/Bundle;
    //   310: astore #4
    //   312: aload #4
    //   314: ifnull -> 34
    //   317: aload #4
    //   319: aload_0
    //   320: getfield u : Landroidx/fragment/app/h;
    //   323: invokevirtual g : ()Landroid/content/Context;
    //   326: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   329: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   332: aload #7
    //   334: aload_1
    //   335: getfield q : Landroid/os/Bundle;
    //   338: ldc_w 'android:view_state'
    //   341: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   344: putfield c : Landroid/util/SparseArray;
    //   347: aload #7
    //   349: aload_1
    //   350: getfield q : Landroid/os/Bundle;
    //   353: putfield b : Landroid/os/Bundle;
    //   356: goto -> 34
    //   359: aload_0
    //   360: getfield g : Ljava/util/HashMap;
    //   363: invokevirtual clear : ()V
    //   366: aload #5
    //   368: getfield a : Ljava/util/ArrayList;
    //   371: invokevirtual iterator : ()Ljava/util/Iterator;
    //   374: astore_1
    //   375: aload_1
    //   376: invokeinterface hasNext : ()Z
    //   381: ifeq -> 515
    //   384: aload_1
    //   385: invokeinterface next : ()Ljava/lang/Object;
    //   390: checkcast androidx/fragment/app/m
    //   393: astore #4
    //   395: aload #4
    //   397: ifnull -> 375
    //   400: aload #4
    //   402: aload_0
    //   403: getfield u : Landroidx/fragment/app/h;
    //   406: invokevirtual g : ()Landroid/content/Context;
    //   409: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   412: aload_0
    //   413: invokevirtual e : ()Landroidx/fragment/app/g;
    //   416: invokevirtual a : (Ljava/lang/ClassLoader;Landroidx/fragment/app/g;)Landroidx/fragment/app/Fragment;
    //   419: astore #6
    //   421: aload #6
    //   423: aload_0
    //   424: putfield v : Landroidx/fragment/app/j;
    //   427: getstatic androidx/fragment/app/j.L : Z
    //   430: ifeq -> 491
    //   433: new java/lang/StringBuilder
    //   436: dup
    //   437: invokespecial <init> : ()V
    //   440: astore #7
    //   442: aload #7
    //   444: ldc_w 'restoreSaveState: active ('
    //   447: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload #7
    //   453: aload #6
    //   455: getfield e : Ljava/lang/String;
    //   458: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   461: pop
    //   462: aload #7
    //   464: ldc_w '): '
    //   467: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   470: pop
    //   471: aload #7
    //   473: aload #6
    //   475: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   478: pop
    //   479: ldc_w 'FragmentManager'
    //   482: aload #7
    //   484: invokevirtual toString : ()Ljava/lang/String;
    //   487: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   490: pop
    //   491: aload_0
    //   492: getfield g : Ljava/util/HashMap;
    //   495: aload #6
    //   497: getfield e : Ljava/lang/String;
    //   500: aload #6
    //   502: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   505: pop
    //   506: aload #4
    //   508: aconst_null
    //   509: putfield r : Landroidx/fragment/app/Fragment;
    //   512: goto -> 375
    //   515: aload_0
    //   516: getfield f : Ljava/util/ArrayList;
    //   519: invokevirtual clear : ()V
    //   522: aload #5
    //   524: getfield b : Ljava/util/ArrayList;
    //   527: astore_1
    //   528: aload_1
    //   529: ifnull -> 772
    //   532: aload_1
    //   533: invokevirtual iterator : ()Ljava/util/Iterator;
    //   536: astore #4
    //   538: aload #4
    //   540: invokeinterface hasNext : ()Z
    //   545: ifeq -> 772
    //   548: aload #4
    //   550: invokeinterface next : ()Ljava/lang/Object;
    //   555: checkcast java/lang/String
    //   558: astore #6
    //   560: aload_0
    //   561: getfield g : Ljava/util/HashMap;
    //   564: aload #6
    //   566: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   569: checkcast androidx/fragment/app/Fragment
    //   572: astore_1
    //   573: aload_1
    //   574: ifnonnull -> 628
    //   577: new java/lang/StringBuilder
    //   580: dup
    //   581: invokespecial <init> : ()V
    //   584: astore #7
    //   586: aload #7
    //   588: ldc_w 'No instantiated fragment for ('
    //   591: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   594: pop
    //   595: aload #7
    //   597: aload #6
    //   599: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: pop
    //   603: aload #7
    //   605: ldc_w ')'
    //   608: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: pop
    //   612: aload_0
    //   613: new java/lang/IllegalStateException
    //   616: dup
    //   617: aload #7
    //   619: invokevirtual toString : ()Ljava/lang/String;
    //   622: invokespecial <init> : (Ljava/lang/String;)V
    //   625: invokespecial n1 : (Ljava/lang/RuntimeException;)V
    //   628: aload_1
    //   629: iconst_1
    //   630: putfield o : Z
    //   633: getstatic androidx/fragment/app/j.L : Z
    //   636: ifeq -> 693
    //   639: new java/lang/StringBuilder
    //   642: dup
    //   643: invokespecial <init> : ()V
    //   646: astore #7
    //   648: aload #7
    //   650: ldc_w 'restoreSaveState: added ('
    //   653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   656: pop
    //   657: aload #7
    //   659: aload #6
    //   661: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   664: pop
    //   665: aload #7
    //   667: ldc_w '): '
    //   670: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   673: pop
    //   674: aload #7
    //   676: aload_1
    //   677: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   680: pop
    //   681: ldc_w 'FragmentManager'
    //   684: aload #7
    //   686: invokevirtual toString : ()Ljava/lang/String;
    //   689: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   692: pop
    //   693: aload_0
    //   694: getfield f : Ljava/util/ArrayList;
    //   697: aload_1
    //   698: invokevirtual contains : (Ljava/lang/Object;)Z
    //   701: ifne -> 734
    //   704: aload_0
    //   705: getfield f : Ljava/util/ArrayList;
    //   708: astore #6
    //   710: aload #6
    //   712: monitorenter
    //   713: aload_0
    //   714: getfield f : Ljava/util/ArrayList;
    //   717: aload_1
    //   718: invokevirtual add : (Ljava/lang/Object;)Z
    //   721: pop
    //   722: aload #6
    //   724: monitorexit
    //   725: goto -> 538
    //   728: astore_1
    //   729: aload #6
    //   731: monitorexit
    //   732: aload_1
    //   733: athrow
    //   734: new java/lang/StringBuilder
    //   737: dup
    //   738: invokespecial <init> : ()V
    //   741: astore #4
    //   743: aload #4
    //   745: ldc_w 'Already added '
    //   748: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   751: pop
    //   752: aload #4
    //   754: aload_1
    //   755: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   758: pop
    //   759: new java/lang/IllegalStateException
    //   762: dup
    //   763: aload #4
    //   765: invokevirtual toString : ()Ljava/lang/String;
    //   768: invokespecial <init> : (Ljava/lang/String;)V
    //   771: athrow
    //   772: aload #5
    //   774: getfield c : [Landroidx/fragment/app/b;
    //   777: ifnull -> 962
    //   780: aload_0
    //   781: new java/util/ArrayList
    //   784: dup
    //   785: aload #5
    //   787: getfield c : [Landroidx/fragment/app/b;
    //   790: arraylength
    //   791: invokespecial <init> : (I)V
    //   794: putfield l : Ljava/util/ArrayList;
    //   797: iconst_0
    //   798: istore_2
    //   799: aload #5
    //   801: getfield c : [Landroidx/fragment/app/b;
    //   804: astore_1
    //   805: iload_2
    //   806: aload_1
    //   807: arraylength
    //   808: if_icmpge -> 967
    //   811: aload_1
    //   812: iload_2
    //   813: aaload
    //   814: aload_0
    //   815: invokevirtual a : (Landroidx/fragment/app/j;)Landroidx/fragment/app/a;
    //   818: astore_1
    //   819: getstatic androidx/fragment/app/j.L : Z
    //   822: ifeq -> 931
    //   825: new java/lang/StringBuilder
    //   828: dup
    //   829: invokespecial <init> : ()V
    //   832: astore #4
    //   834: aload #4
    //   836: ldc_w 'restoreAllState: back stack #'
    //   839: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   842: pop
    //   843: aload #4
    //   845: iload_2
    //   846: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   849: pop
    //   850: aload #4
    //   852: ldc_w ' (index '
    //   855: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   858: pop
    //   859: aload #4
    //   861: aload_1
    //   862: getfield u : I
    //   865: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   868: pop
    //   869: aload #4
    //   871: ldc_w '): '
    //   874: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   877: pop
    //   878: aload #4
    //   880: aload_1
    //   881: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   884: pop
    //   885: ldc_w 'FragmentManager'
    //   888: aload #4
    //   890: invokevirtual toString : ()Ljava/lang/String;
    //   893: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   896: pop
    //   897: new java/io/PrintWriter
    //   900: dup
    //   901: new androidx/core/util/c
    //   904: dup
    //   905: ldc_w 'FragmentManager'
    //   908: invokespecial <init> : (Ljava/lang/String;)V
    //   911: invokespecial <init> : (Ljava/io/Writer;)V
    //   914: astore #4
    //   916: aload_1
    //   917: ldc_w '  '
    //   920: aload #4
    //   922: iconst_0
    //   923: invokevirtual k : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   926: aload #4
    //   928: invokevirtual close : ()V
    //   931: aload_0
    //   932: getfield l : Ljava/util/ArrayList;
    //   935: aload_1
    //   936: invokevirtual add : (Ljava/lang/Object;)Z
    //   939: pop
    //   940: aload_1
    //   941: getfield u : I
    //   944: istore_3
    //   945: iload_3
    //   946: iflt -> 955
    //   949: aload_0
    //   950: iload_3
    //   951: aload_1
    //   952: invokevirtual i1 : (ILandroidx/fragment/app/a;)V
    //   955: iload_2
    //   956: iconst_1
    //   957: iadd
    //   958: istore_2
    //   959: goto -> 799
    //   962: aload_0
    //   963: aconst_null
    //   964: putfield l : Ljava/util/ArrayList;
    //   967: aload #5
    //   969: getfield d : Ljava/lang/String;
    //   972: astore_1
    //   973: aload_1
    //   974: ifnull -> 999
    //   977: aload_0
    //   978: getfield g : Ljava/util/HashMap;
    //   981: aload_1
    //   982: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   985: checkcast androidx/fragment/app/Fragment
    //   988: astore_1
    //   989: aload_0
    //   990: aload_1
    //   991: putfield x : Landroidx/fragment/app/Fragment;
    //   994: aload_0
    //   995: aload_1
    //   996: invokespecial X : (Landroidx/fragment/app/Fragment;)V
    //   999: aload_0
    //   1000: aload #5
    //   1002: getfield e : I
    //   1005: putfield e : I
    //   1008: return
    // Exception table:
    //   from	to	target	type
    //   713	725	728	finally
    //   729	732	728	finally
  }
  
  public Fragment d(String paramString) {
    if (paramString != null)
      for (int k = this.f.size() - 1; k >= 0; k--) {
        Fragment fragment = this.f.get(k);
        if (fragment != null && paramString.equals(fragment.B))
          return fragment; 
      }  
    if (paramString != null)
      for (Fragment fragment : this.g.values()) {
        if (fragment != null && paramString.equals(fragment.B))
          return fragment; 
      }  
    return null;
  }
  
  public void d0() {
    this.z = false;
    this.A = false;
    e0(3);
  }
  
  public g e() {
    if (super.e() == i.b) {
      Fragment fragment = this.w;
      if (fragment != null)
        return fragment.v.e(); 
      i(new f(this));
    } 
    return super.e();
  }
  
  Parcelable e1() {
    StringBuilder stringBuilder;
    s0();
    h0();
    l0();
    this.z = true;
    boolean bool1 = this.g.isEmpty();
    b[] arrayOfB2 = null;
    if (bool1)
      return null; 
    ArrayList<m> arrayList = new ArrayList(this.g.size());
    Iterator<Fragment> iterator = this.g.values().iterator();
    boolean bool = false;
    int k = 0;
    while (iterator.hasNext()) {
      Fragment fragment1 = iterator.next();
      if (fragment1 != null) {
        if (fragment1.v != this) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failure saving state: active ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(" was removed from the FragmentManager");
          n1(new IllegalStateException(stringBuilder1.toString()));
        } 
        m m = new m(fragment1);
        arrayList.add(m);
        if (fragment1.a > 0 && m.q == null) {
          m.q = f1(fragment1);
          String str = fragment1.l;
          if (str != null) {
            Fragment fragment2 = this.g.get(str);
            if (fragment2 == null) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: ");
              stringBuilder1.append(fragment1);
              stringBuilder1.append(" has target not in fragment manager: ");
              stringBuilder1.append(fragment1.l);
              n1(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (m.q == null)
              m.q = new Bundle(); 
            X0(m.q, "android:target_state", fragment2);
            k = fragment1.m;
            if (k != 0)
              m.q.putInt("android:target_req_state", k); 
          } 
        } else {
          m.q = fragment1.b;
        } 
        if (L) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Saved state of ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(": ");
          stringBuilder1.append(m.q);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        k = 1;
      } 
    } 
    if (k == 0) {
      if (L)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    k = this.f.size();
    if (k > 0) {
      ArrayList<String> arrayList2 = new ArrayList(k);
      Iterator<Fragment> iterator1 = this.f.iterator();
      while (true) {
        ArrayList<String> arrayList3 = arrayList2;
        if (iterator1.hasNext()) {
          Fragment fragment1 = iterator1.next();
          arrayList2.add(fragment1.e);
          if (fragment1.v != this) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Failure saving state: active ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(" was removed from the FragmentManager");
            n1(new IllegalStateException(stringBuilder1.toString()));
          } 
          if (L) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("saveAllState: adding fragment (");
            stringBuilder1.append(fragment1.e);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment1);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          continue;
        } 
        break;
      } 
    } else {
      iterator = null;
    } 
    ArrayList<a> arrayList1 = this.l;
    b[] arrayOfB1 = arrayOfB2;
    if (arrayList1 != null) {
      int m = arrayList1.size();
      arrayOfB1 = arrayOfB2;
      if (m > 0) {
        arrayOfB2 = new b[m];
        k = bool;
        while (true) {
          arrayOfB1 = arrayOfB2;
          if (k < m) {
            arrayOfB2[k] = new b(this.l.get(k));
            if (L) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(k);
              stringBuilder.append(": ");
              stringBuilder.append(this.l.get(k));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            k++;
            continue;
          } 
          break;
        } 
      } 
    } 
    k k1 = new k();
    k1.a = arrayList;
    k1.b = (ArrayList)iterator;
    k1.c = (b[])stringBuilder;
    Fragment fragment = this.x;
    if (fragment != null)
      k1.d = fragment.e; 
    k1.e = this.e;
    return k1;
  }
  
  public List<Fragment> f() {
    if (this.f.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.f) {
      return (List)this.f.clone();
    } 
  }
  
  public void f0() {
    this.A = true;
    e0(2);
  }
  
  Bundle f1(Fragment paramFragment) {
    if (this.G == null)
      this.G = new Bundle(); 
    paramFragment.W0(this.G);
    Q(paramFragment, this.G, false);
    boolean bool = this.G.isEmpty();
    Bundle bundle2 = null;
    if (!bool) {
      bundle2 = this.G;
      this.G = null;
    } 
    if (paramFragment.K != null)
      g1(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.c != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.c);
    } 
    bundle2 = bundle1;
    if (!paramFragment.N) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.N);
    } 
    return bundle2;
  }
  
  public void g(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      i0(new l(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void g0() {
    if (this.C) {
      this.C = false;
      m1();
    } 
  }
  
  void g1(Fragment paramFragment) {
    if (paramFragment.L == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.H;
    if (sparseArray == null) {
      this.H = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.L.saveHierarchyState(this.H);
    if (this.H.size() > 0) {
      paramFragment.c = this.H;
      this.H = null;
    } 
  }
  
  public boolean h() {
    t();
    return U0(null, -1, 0);
  }
  
  void h1() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield I : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 100
    //   15: aload #4
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 100
    //   23: iconst_1
    //   24: istore_1
    //   25: goto -> 28
    //   28: aload_0
    //   29: getfield c : Ljava/util/ArrayList;
    //   32: astore #4
    //   34: iload_3
    //   35: istore_2
    //   36: aload #4
    //   38: ifnull -> 105
    //   41: iload_3
    //   42: istore_2
    //   43: aload #4
    //   45: invokevirtual size : ()I
    //   48: iconst_1
    //   49: if_icmpne -> 105
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 105
    //   57: aload_0
    //   58: getfield u : Landroidx/fragment/app/h;
    //   61: invokevirtual h : ()Landroid/os/Handler;
    //   64: aload_0
    //   65: getfield K : Ljava/lang/Runnable;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: getfield u : Landroidx/fragment/app/h;
    //   75: invokevirtual h : ()Landroid/os/Handler;
    //   78: aload_0
    //   79: getfield K : Ljava/lang/Runnable;
    //   82: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   85: pop
    //   86: aload_0
    //   87: invokespecial p1 : ()V
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: astore #4
    //   95: aload_0
    //   96: monitorexit
    //   97: aload #4
    //   99: athrow
    //   100: iconst_0
    //   101: istore_1
    //   102: goto -> 28
    //   105: iload_1
    //   106: ifne -> 57
    //   109: iload_2
    //   110: ifeq -> 90
    //   113: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	8	93	finally
    //   15	23	93	finally
    //   28	34	93	finally
    //   43	52	93	finally
    //   57	90	93	finally
    //   90	92	93	finally
    //   95	97	93	finally
  }
  
  public void i0(k paramk, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial t : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield B : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield u : Landroidx/fragment/app/h;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield c : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield c : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield c : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokevirtual h1 : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  public void i1(int paramInt, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield p : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield p : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield p : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 110
    //   38: getstatic androidx/fragment/app/j.L : Z
    //   41: ifeq -> 97
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #5
    //   53: aload #5
    //   55: ldc_w 'Setting back stack index '
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #5
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: ldc_w ' to '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload #5
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   96: pop
    //   97: aload_0
    //   98: getfield p : Ljava/util/ArrayList;
    //   101: iload_1
    //   102: aload_2
    //   103: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: goto -> 272
    //   110: iload_3
    //   111: iload_1
    //   112: if_icmpge -> 204
    //   115: aload_0
    //   116: getfield p : Ljava/util/ArrayList;
    //   119: aconst_null
    //   120: invokevirtual add : (Ljava/lang/Object;)Z
    //   123: pop
    //   124: aload_0
    //   125: getfield q : Ljava/util/ArrayList;
    //   128: ifnonnull -> 142
    //   131: aload_0
    //   132: new java/util/ArrayList
    //   135: dup
    //   136: invokespecial <init> : ()V
    //   139: putfield q : Ljava/util/ArrayList;
    //   142: getstatic androidx/fragment/app/j.L : Z
    //   145: ifeq -> 185
    //   148: new java/lang/StringBuilder
    //   151: dup
    //   152: invokespecial <init> : ()V
    //   155: astore #5
    //   157: aload #5
    //   159: ldc_w 'Adding available back stack index '
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload #5
    //   168: iload_3
    //   169: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: ldc_w 'FragmentManager'
    //   176: aload #5
    //   178: invokevirtual toString : ()Ljava/lang/String;
    //   181: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   184: pop
    //   185: aload_0
    //   186: getfield q : Ljava/util/ArrayList;
    //   189: iload_3
    //   190: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   193: invokevirtual add : (Ljava/lang/Object;)Z
    //   196: pop
    //   197: iload_3
    //   198: iconst_1
    //   199: iadd
    //   200: istore_3
    //   201: goto -> 110
    //   204: getstatic androidx/fragment/app/j.L : Z
    //   207: ifeq -> 263
    //   210: new java/lang/StringBuilder
    //   213: dup
    //   214: invokespecial <init> : ()V
    //   217: astore #5
    //   219: aload #5
    //   221: ldc_w 'Adding back stack index '
    //   224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: pop
    //   228: aload #5
    //   230: iload_1
    //   231: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload #5
    //   237: ldc_w ' with '
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload #5
    //   246: aload_2
    //   247: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   250: pop
    //   251: ldc_w 'FragmentManager'
    //   254: aload #5
    //   256: invokevirtual toString : ()Ljava/lang/String;
    //   259: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   262: pop
    //   263: aload_0
    //   264: getfield p : Ljava/util/ArrayList;
    //   267: aload_2
    //   268: invokevirtual add : (Ljava/lang/Object;)Z
    //   271: pop
    //   272: aload_0
    //   273: monitorexit
    //   274: return
    //   275: astore_2
    //   276: aload_0
    //   277: monitorexit
    //   278: aload_2
    //   279: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	275	finally
    //   20	29	275	finally
    //   38	97	275	finally
    //   97	107	275	finally
    //   115	142	275	finally
    //   142	185	275	finally
    //   185	197	275	finally
    //   204	263	275	finally
    //   263	272	275	finally
    //   272	274	275	finally
    //   276	278	275	finally
  }
  
  public void j1(Fragment paramFragment, androidx.lifecycle.e.b paramb) {
    if (this.g.get(paramFragment.e) == paramFragment && (paramFragment.w == null || paramFragment.w() == this)) {
      paramFragment.V = paramb;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void k(a parama) {
    if (this.l == null)
      this.l = new ArrayList<a>(); 
    this.l.add(parama);
  }
  
  void k0(Fragment paramFragment) {
    if (paramFragment.q && !paramFragment.t) {
      paramFragment.I0(paramFragment.M0(paramFragment.b), null, paramFragment.b);
      View view = paramFragment.K;
      if (view != null) {
        paramFragment.L = view;
        view.setSaveFromParentEnabled(false);
        if (paramFragment.C)
          paramFragment.K.setVisibility(8); 
        paramFragment.A0(paramFragment.K, paramFragment.b);
        T(paramFragment, paramFragment.K, paramFragment.b, false);
        return;
      } 
      paramFragment.L = null;
    } 
  }
  
  public void k1(Fragment paramFragment) {
    if (paramFragment == null || (this.g.get(paramFragment.e) == paramFragment && (paramFragment.w == null || paramFragment.w() == this))) {
      Fragment fragment = this.x;
      this.x = paramFragment;
      X(fragment);
      X(this.x);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void l(Fragment paramFragment, boolean paramBoolean) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    J0(paramFragment);
    if (!paramFragment.D)
      if (!this.f.contains(paramFragment)) {
        synchronized (this.f) {
          this.f.add(paramFragment);
          paramFragment.o = true;
          paramFragment.p = false;
          if (paramFragment.K == null)
            paramFragment.R = false; 
          if (E0(paramFragment))
            this.y = true; 
          if (paramBoolean) {
            Q0(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public boolean l0() {
    j0(true);
    boolean bool = false;
    while (u0(this.D, this.E)) {
      this.d = true;
      try {
        Z0(this.D, this.E);
        u();
      } finally {
        u();
      } 
    } 
    p1();
    g0();
    r();
    return bool;
  }
  
  public void l1(Fragment paramFragment) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.C) {
      paramFragment.C = false;
      paramFragment.R ^= 0x1;
    } 
  }
  
  void m(Fragment paramFragment) {
    if (H0()) {
      if (L)
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.J.e(paramFragment) && L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void m1() {
    for (Fragment fragment : this.g.values()) {
      if (fragment != null)
        T0(fragment); 
    } 
  }
  
  public int n(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 110
    //   11: aload_3
    //   12: invokevirtual size : ()I
    //   15: ifgt -> 21
    //   18: goto -> 110
    //   21: aload_0
    //   22: getfield q : Ljava/util/ArrayList;
    //   25: astore_3
    //   26: aload_3
    //   27: aload_3
    //   28: invokevirtual size : ()I
    //   31: iconst_1
    //   32: isub
    //   33: invokevirtual remove : (I)Ljava/lang/Object;
    //   36: checkcast java/lang/Integer
    //   39: invokevirtual intValue : ()I
    //   42: istore_2
    //   43: getstatic androidx/fragment/app/j.L : Z
    //   46: ifeq -> 96
    //   49: new java/lang/StringBuilder
    //   52: dup
    //   53: invokespecial <init> : ()V
    //   56: astore_3
    //   57: aload_3
    //   58: ldc_w 'Adding back stack index '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_3
    //   66: iload_2
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_3
    //   72: ldc_w ' with '
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: aload_3
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload_3
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield p : Ljava/util/ArrayList;
    //   100: iload_2
    //   101: aload_1
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: aload_0
    //   107: monitorexit
    //   108: iload_2
    //   109: ireturn
    //   110: aload_0
    //   111: getfield p : Ljava/util/ArrayList;
    //   114: ifnonnull -> 128
    //   117: aload_0
    //   118: new java/util/ArrayList
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: putfield p : Ljava/util/ArrayList;
    //   128: aload_0
    //   129: getfield p : Ljava/util/ArrayList;
    //   132: invokevirtual size : ()I
    //   135: istore_2
    //   136: getstatic androidx/fragment/app/j.L : Z
    //   139: ifeq -> 189
    //   142: new java/lang/StringBuilder
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: astore_3
    //   150: aload_3
    //   151: ldc_w 'Setting back stack index '
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: pop
    //   158: aload_3
    //   159: iload_2
    //   160: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: aload_3
    //   165: ldc_w ' to '
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: aload_3
    //   173: aload_1
    //   174: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: ldc_w 'FragmentManager'
    //   181: aload_3
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   188: pop
    //   189: aload_0
    //   190: getfield p : Ljava/util/ArrayList;
    //   193: aload_1
    //   194: invokevirtual add : (Ljava/lang/Object;)Z
    //   197: pop
    //   198: aload_0
    //   199: monitorexit
    //   200: iload_2
    //   201: ireturn
    //   202: astore_1
    //   203: aload_0
    //   204: monitorexit
    //   205: aload_1
    //   206: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	202	finally
    //   11	18	202	finally
    //   21	96	202	finally
    //   96	108	202	finally
    //   110	128	202	finally
    //   128	189	202	finally
    //   189	200	202	finally
    //   203	205	202	finally
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str2 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.a);
    int k = 0;
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    int m = typedArray.getResourceId(1, -1);
    str2 = typedArray.getString(2);
    typedArray.recycle();
    if (str1 != null) {
      if (!g.b(paramContext.getClassLoader(), str1))
        return null; 
      if (paramView != null)
        k = paramView.getId(); 
      if (k != -1 || m != -1 || str2 != null) {
        String str = paramString;
        if (m != -1)
          fragment1 = p0(m); 
        Fragment fragment2 = fragment1;
        if (fragment1 == null) {
          fragment2 = fragment1;
          if (str2 != null)
            fragment2 = d(str2); 
        } 
        Fragment fragment1 = fragment2;
        if (fragment2 == null) {
          fragment1 = fragment2;
          if (k != -1)
            fragment1 = p0(k); 
        } 
        if (L) {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("onCreateView: id=0x");
          stringBuilder2.append(Integer.toHexString(m));
          stringBuilder2.append(" fname=");
          stringBuilder2.append(str1);
          stringBuilder2.append(" existing=");
          stringBuilder2.append(fragment1);
          Log.v("FragmentManager", stringBuilder2.toString());
        } 
        if (fragment1 == null) {
          int n;
          fragment1 = e().a(paramContext.getClassLoader(), str1);
          fragment1.q = true;
          if (m != 0) {
            n = m;
          } else {
            n = k;
          } 
          fragment1.z = n;
          fragment1.A = k;
          fragment1.B = str2;
          fragment1.r = true;
          fragment1.v = this;
          h h1 = this.u;
          fragment1.w = h1;
          fragment1.n0(h1.g(), paramAttributeSet, fragment1.b);
          l(fragment1, true);
        } else if (!fragment1.r) {
          fragment1.r = true;
          h h1 = this.u;
          fragment1.w = h1;
          fragment1.n0(h1.g(), paramAttributeSet, fragment1.b);
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramAttributeSet.getPositionDescription());
          stringBuilder1.append(": Duplicate id 0x");
          stringBuilder1.append(Integer.toHexString(m));
          stringBuilder1.append(", tag ");
          stringBuilder1.append(str2);
          stringBuilder1.append(", or parent id 0x");
          stringBuilder1.append(Integer.toHexString(k));
          stringBuilder1.append(" with another fragment for ");
          stringBuilder1.append(str1);
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        if (this.t < 1 && ((Fragment)stringBuilder1).q) {
          R0((Fragment)stringBuilder1, 1, 0, 0, false);
        } else {
          Q0((Fragment)stringBuilder1);
        } 
        View view = ((Fragment)stringBuilder1).K;
        if (view != null) {
          if (m != 0)
            view.setId(m); 
          if (((Fragment)stringBuilder1).K.getTag() == null)
            ((Fragment)stringBuilder1).K.setTag(str2); 
          return ((Fragment)stringBuilder1).K;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Fragment ");
        stringBuilder1.append(str1);
        stringBuilder1.append(" did not create a view.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramAttributeSet.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str1);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p(h paramh, e parame, Fragment paramFragment) {
    if (this.u == null) {
      l l1;
      this.u = paramh;
      this.v = parame;
      this.w = paramFragment;
      if (paramFragment != null)
        p1(); 
      if (paramh instanceof androidx.activity.l) {
        Fragment fragment;
        androidx.activity.l l2 = (androidx.activity.l)paramh;
        OnBackPressedDispatcher onBackPressedDispatcher = l2.j();
        this.n = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.b(fragment, this.o);
      } 
      if (paramFragment != null) {
        l1 = paramFragment.v.w0(paramFragment);
      } else if (l1 instanceof g0) {
        l1 = l.h(((g0)l1).e());
      } else {
        l1 = new l(false);
      } 
      this.J = l1;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public Fragment p0(int paramInt) {
    for (int k = this.f.size() - 1; k >= 0; k--) {
      Fragment fragment = this.f.get(k);
      if (fragment != null && fragment.z == paramInt)
        return fragment; 
    } 
    for (Fragment fragment : this.g.values()) {
      if (fragment != null && fragment.z == paramInt)
        return fragment; 
    } 
    return null;
  }
  
  public void q(Fragment paramFragment) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.D) {
      paramFragment.D = false;
      if (!paramFragment.o)
        if (!this.f.contains(paramFragment)) {
          if (L) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.f) {
            this.f.add(paramFragment);
            paramFragment.o = true;
            if (E0(paramFragment)) {
              this.y = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public Fragment q0(String paramString) {
    for (Fragment fragment : this.g.values()) {
      if (fragment != null) {
        fragment = fragment.i(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  boolean s() {
    Iterator<Fragment> iterator = this.g.values().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = E0(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  public void t0(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield p : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield q : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield q : Ljava/util/ArrayList;
    //   30: getstatic androidx/fragment/app/j.L : Z
    //   33: ifeq -> 69
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore_2
    //   44: aload_2
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload_2
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: ldc_w 'FragmentManager'
    //   61: aload_2
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   68: pop
    //   69: aload_0
    //   70: getfield q : Ljava/util/ArrayList;
    //   73: iload_1
    //   74: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   77: invokevirtual add : (Ljava/lang/Object;)Z
    //   80: pop
    //   81: aload_0
    //   82: monitorexit
    //   83: return
    //   84: astore_2
    //   85: aload_0
    //   86: monitorexit
    //   87: aload_2
    //   88: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	84	finally
    //   30	69	84	finally
    //   69	83	84	finally
    //   85	87	84	finally
  }
  
  public String toString() {
    h h1;
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.w;
    if (fragment == null)
      h1 = this.u; 
    androidx.core.util.b.a(h1, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  void v(a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.m(paramBoolean3);
    } else {
      parama.l();
    } 
    ArrayList<a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      o.B(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      P0(this.t, true); 
    for (Fragment fragment : this.g.values()) {
      if (fragment != null && fragment.K != null && fragment.Q && parama.p(fragment.A)) {
        float f = fragment.S;
        if (f > 0.0F)
          fragment.K.setAlpha(f); 
        if (paramBoolean3) {
          fragment.S = 0.0F;
          continue;
        } 
        fragment.S = -1.0F;
        fragment.Q = false;
      } 
    } 
  }
  
  public int v0() {
    ArrayList<a> arrayList = this.l;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  void w(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield K : Landroid/view/View;
    //   4: ifnull -> 197
    //   7: aload_0
    //   8: aload_1
    //   9: aload_1
    //   10: invokevirtual A : ()I
    //   13: aload_1
    //   14: getfield C : Z
    //   17: iconst_1
    //   18: ixor
    //   19: aload_1
    //   20: invokevirtual B : ()I
    //   23: invokevirtual I0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/j$g;
    //   26: astore_3
    //   27: aload_3
    //   28: ifnull -> 133
    //   31: aload_3
    //   32: getfield b : Landroid/animation/Animator;
    //   35: astore #4
    //   37: aload #4
    //   39: ifnull -> 133
    //   42: aload #4
    //   44: aload_1
    //   45: getfield K : Landroid/view/View;
    //   48: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   51: aload_1
    //   52: getfield C : Z
    //   55: ifeq -> 115
    //   58: aload_1
    //   59: invokevirtual P : ()Z
    //   62: ifeq -> 73
    //   65: aload_1
    //   66: iconst_0
    //   67: invokevirtual i1 : (Z)V
    //   70: goto -> 123
    //   73: aload_1
    //   74: getfield J : Landroid/view/ViewGroup;
    //   77: astore #4
    //   79: aload_1
    //   80: getfield K : Landroid/view/View;
    //   83: astore #5
    //   85: aload #4
    //   87: aload #5
    //   89: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   92: aload_3
    //   93: getfield b : Landroid/animation/Animator;
    //   96: new androidx/fragment/app/j$e
    //   99: dup
    //   100: aload_0
    //   101: aload #4
    //   103: aload #5
    //   105: aload_1
    //   106: invokespecial <init> : (Landroidx/fragment/app/j;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;)V
    //   109: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   112: goto -> 123
    //   115: aload_1
    //   116: getfield K : Landroid/view/View;
    //   119: iconst_0
    //   120: invokevirtual setVisibility : (I)V
    //   123: aload_3
    //   124: getfield b : Landroid/animation/Animator;
    //   127: invokevirtual start : ()V
    //   130: goto -> 197
    //   133: aload_3
    //   134: ifnull -> 155
    //   137: aload_1
    //   138: getfield K : Landroid/view/View;
    //   141: aload_3
    //   142: getfield a : Landroid/view/animation/Animation;
    //   145: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   148: aload_3
    //   149: getfield a : Landroid/view/animation/Animation;
    //   152: invokevirtual start : ()V
    //   155: aload_1
    //   156: getfield C : Z
    //   159: ifeq -> 175
    //   162: aload_1
    //   163: invokevirtual P : ()Z
    //   166: ifne -> 175
    //   169: bipush #8
    //   171: istore_2
    //   172: goto -> 177
    //   175: iconst_0
    //   176: istore_2
    //   177: aload_1
    //   178: getfield K : Landroid/view/View;
    //   181: iload_2
    //   182: invokevirtual setVisibility : (I)V
    //   185: aload_1
    //   186: invokevirtual P : ()Z
    //   189: ifeq -> 197
    //   192: aload_1
    //   193: iconst_0
    //   194: invokevirtual i1 : (Z)V
    //   197: aload_1
    //   198: getfield o : Z
    //   201: ifeq -> 217
    //   204: aload_0
    //   205: aload_1
    //   206: invokespecial E0 : (Landroidx/fragment/app/Fragment;)Z
    //   209: ifeq -> 217
    //   212: aload_0
    //   213: iconst_1
    //   214: putfield y : Z
    //   217: aload_1
    //   218: iconst_0
    //   219: putfield R : Z
    //   222: aload_1
    //   223: aload_1
    //   224: getfield C : Z
    //   227: invokevirtual l0 : (Z)V
    //   230: return
  }
  
  l w0(Fragment paramFragment) {
    return this.J.g(paramFragment);
  }
  
  public void x(Fragment paramFragment) {
    if (L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.D) {
      paramFragment.D = true;
      if (paramFragment.o) {
        if (L) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.f) {
          this.f.remove(paramFragment);
          if (E0(paramFragment))
            this.y = true; 
          paramFragment.o = false;
          return;
        } 
      } 
    } 
  }
  
  public Fragment x0(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = this.g.get(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      n1(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public void y() {
    this.z = false;
    this.A = false;
    e0(2);
  }
  
  LayoutInflater.Factory2 y0() {
    return this;
  }
  
  public void z(Configuration paramConfiguration) {
    for (int k = 0; k < this.f.size(); k++) {
      Fragment fragment = this.f.get(k);
      if (fragment != null)
        fragment.E0(paramConfiguration); 
    } 
  }
  
  public Fragment z0() {
    return this.x;
  }
  
  class a extends androidx.activity.j {
    a(j this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void b() {
      this.d.B0();
    }
  }
  
  class b implements Runnable {
    b(j this$0) {}
    
    public void run() {
      this.a.l0();
    }
  }
  
  class c implements Animation.AnimationListener {
    c(j this$0, ViewGroup param1ViewGroup, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    class a implements Runnable {
      a(j.c this$0) {}
      
      public void run() {
        if (this.a.b.o() != null) {
          this.a.b.f1(null);
          j.c c1 = this.a;
          j j = c1.c;
          Fragment fragment = c1.b;
          j.R0(fragment, fragment.J(), 0, 0, false);
        } 
      }
    }
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      if (this.a.b.o() != null) {
        this.a.b.f1(null);
        j.c c1 = this.a;
        j j = c1.c;
        Fragment fragment = c1.b;
        j.R0(fragment, fragment.J(), 0, 0, false);
      } 
    }
  }
  
  class d extends AnimatorListenerAdapter {
    d(j this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.p();
      this.c.g1(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0) {
        j j1 = this.d;
        Fragment fragment = this.c;
        j1.R0(fragment, fragment.J(), 0, 0, false);
      } 
    }
  }
  
  class e extends AnimatorListenerAdapter {
    e(j this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      Fragment fragment = this.c;
      View view = fragment.K;
      if (view != null && fragment.C)
        view.setVisibility(8); 
    }
  }
  
  class f extends g {
    f(j this$0) {}
    
    public Fragment a(ClassLoader param1ClassLoader, String param1String) {
      h h = this.b.u;
      return h.b(h.g(), param1String, null);
    }
  }
  
  private static class g {
    public final Animation a = null;
    
    public final Animator b;
    
    g(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    g(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class h extends AnimationSet implements Runnable {
    private final ViewGroup a;
    
    private final View b;
    
    private boolean c;
    
    private boolean d;
    
    private boolean e = true;
    
    h(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.a = param1ViewGroup;
      this.b = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.c = true;
        androidx.core.view.h.a((View)this.a, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.c = true;
        androidx.core.view.h.a((View)this.a, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.c && this.e) {
        this.e = false;
        this.a.post(this);
        return;
      } 
      this.a.endViewTransition(this.b);
      this.d = true;
    }
  }
  
  private static final class i {
    final i.a a;
    
    final boolean b;
  }
  
  static class j {
    public static final int[] a = new int[] { 16842755, 16842960, 16842961 };
  }
  
  static interface k {
    boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class l implements k {
    final String a;
    
    final int b;
    
    final int c;
    
    l(j this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = this.d.x;
      return (fragment != null && this.b < 0 && this.a == null && fragment.q().h()) ? false : this.d.V0(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  static class m implements Fragment.f {
    final boolean a;
    
    final a b;
    
    private int c;
    
    m(a param1a, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1a;
    }
    
    public void a() {
      int i = this.c - 1;
      this.c = i;
      if (i != 0)
        return; 
      this.b.s.h1();
    }
    
    public void b() {
      this.c++;
    }
    
    public void c() {
      a a1 = this.b;
      a1.s.v(a1, this.a, false, false);
    }
    
    public void d() {
      int i = this.c;
      int j = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      j j1 = this.b.s;
      int k = j1.f.size();
      while (j < k) {
        Fragment fragment = j1.f.get(j);
        fragment.l1(null);
        if (i != 0 && fragment.R())
          fragment.o1(); 
        j++;
      } 
      a a1 = this.b;
      a1.s.v(a1, this.a, i ^ 0x1, true);
    }
    
    public boolean e() {
      return (this.c == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */