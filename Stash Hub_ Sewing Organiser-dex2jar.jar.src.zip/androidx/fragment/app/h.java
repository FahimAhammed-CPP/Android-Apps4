package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import androidx.core.util.e;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class h<E> extends e {
  private final Activity a;
  
  private final Context b;
  
  private final Handler c;
  
  private final int d;
  
  final j e = new j();
  
  h(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.a = paramActivity;
    this.b = (Context)e.c(paramContext, "context == null");
    this.c = (Handler)e.c(paramHandler, "handler == null");
    this.d = paramInt;
  }
  
  h(d paramd) {
    this((Activity)paramd, (Context)paramd, new Handler(), 0);
  }
  
  public View c(int paramInt) {
    return null;
  }
  
  public boolean d() {
    return true;
  }
  
  Activity f() {
    return this.a;
  }
  
  Context g() {
    return this.b;
  }
  
  Handler h() {
    return this.c;
  }
  
  void i(Fragment paramFragment) {}
  
  public void l(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public abstract E m();
  
  public LayoutInflater n() {
    return LayoutInflater.from(this.b);
  }
  
  public int o() {
    return this.d;
  }
  
  public boolean p() {
    return true;
  }
  
  public boolean q(Fragment paramFragment) {
    return true;
  }
  
  public void r(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (paramInt == -1) {
      this.b.startActivity(paramIntent);
      return;
    } 
    throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
  }
  
  public void s() {}
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */