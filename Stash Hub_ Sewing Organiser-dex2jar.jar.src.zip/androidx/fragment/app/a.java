package androidx.fragment.app;

import android.util.Log;
import androidx.core.util.c;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

final class a extends n implements j.k {
  final j s;
  
  boolean t;
  
  int u = -1;
  
  public a(j paramj) {
    this.s = paramj;
  }
  
  private static boolean r(n.a parama) {
    Fragment fragment = parama.b;
    return (fragment != null && fragment.o && fragment.K != null && !fragment.D && !fragment.C && fragment.R());
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (j.L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.h)
      this.s.k(this); 
    return true;
  }
  
  public int d() {
    return i(false);
  }
  
  public int e() {
    return i(true);
  }
  
  void f(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    super.f(paramInt1, paramFragment, paramString, paramInt2);
    paramFragment.v = this.s;
  }
  
  public n g(Fragment paramFragment) {
    j j1 = paramFragment.v;
    if (j1 == null || j1 == this.s)
      return super.g(paramFragment); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void h(int paramInt) {
    if (!this.h)
      return; 
    if (j.L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int m = this.a.size();
    for (int i = 0; i < m; i++) {
      n.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.u += paramInt;
        if (j.L) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.u);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  int i(boolean paramBoolean) {
    if (!this.t) {
      byte b;
      if (j.L) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter((Writer)new c("FragmentManager"));
        j("  ", printWriter);
        printWriter.close();
      } 
      this.t = true;
      if (this.h) {
        b = this.s.n(this);
      } else {
        b = -1;
      } 
      this.u = b;
      this.s.i0(this, paramBoolean);
      return this.u;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void j(String paramString, PrintWriter paramPrintWriter) {
    k(paramString, paramPrintWriter, true);
  }
  
  public void k(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.j);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.u);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.t);
      if (this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.g));
      } 
      if (this.b != 0 || this.c != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.b));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.c));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.k != 0 || this.l != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.k));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.l);
      } 
      if (this.m != 0 || this.n != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.m));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.n);
      } 
    } 
    if (!this.a.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int m = this.a.size();
      int i;
      for (i = 0; i < m; i++) {
        StringBuilder stringBuilder;
        String str;
        n.a a1 = this.a.get(i);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  void l() {
    int m = this.a.size();
    for (int i = 0; i < m; i++) {
      StringBuilder stringBuilder;
      n.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null)
        fragment.k1(this.f, this.g); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.s.j1((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.s.k1(null);
          break;
        case 8:
          this.s.k1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.j1(a1.c);
          this.s.q((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.j1(a1.d);
          this.s.x((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.j1(a1.c);
          this.s.l1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.j1(a1.d);
          this.s.C0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.j1(a1.d);
          this.s.Y0((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.j1(a1.c);
          this.s.l((Fragment)stringBuilder, false);
          break;
      } 
      if (!this.q && a1.a != 1 && stringBuilder != null)
        this.s.O0((Fragment)stringBuilder); 
    } 
    if (!this.q) {
      j j1 = this.s;
      j1.P0(j1.t, true);
    } 
  }
  
  void m(boolean paramBoolean) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      n.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null)
        fragment.k1(j.d1(this.f), this.g); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.s.j1((Fragment)stringBuilder, a1.g);
          break;
        case 9:
          this.s.k1((Fragment)stringBuilder);
          break;
        case 8:
          this.s.k1(null);
          break;
        case 7:
          stringBuilder.j1(a1.f);
          this.s.x((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.j1(a1.e);
          this.s.q((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.j1(a1.f);
          this.s.C0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.j1(a1.e);
          this.s.l1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.j1(a1.e);
          this.s.l((Fragment)stringBuilder, false);
          break;
        case 1:
          stringBuilder.j1(a1.f);
          this.s.Y0((Fragment)stringBuilder);
          break;
      } 
      if (!this.q && a1.a != 3 && stringBuilder != null)
        this.s.O0((Fragment)stringBuilder); 
    } 
    if (!this.q && paramBoolean) {
      j j1 = this.s;
      j1.P0(j1.t, true);
    } 
  }
  
  Fragment n(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.a.size(); fragment = paramFragment) {
      Fragment fragment1;
      n.a a1 = this.a.get(i);
      int m = a1.a;
      if (m != 1)
        if (m != 2) {
          if (m != 3 && m != 6) {
            if (m != 7) {
              if (m != 8) {
                paramFragment = fragment;
                m = i;
              } else {
                this.a.add(i, new n.a(9, fragment));
                m = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            fragment1 = a1.b;
            paramFragment = fragment;
            m = i;
            if (fragment1 == fragment) {
              this.a.add(i, new n.a(9, fragment1));
              m = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment2 = ((n.a)fragment1).b;
          int i2 = fragment2.A;
          int i1 = paramArrayList.size() - 1;
          boolean bool = false;
          m = i;
          paramFragment = fragment;
          while (i1 >= 0) {
            Fragment fragment3 = paramArrayList.get(i1);
            fragment = paramFragment;
            i = m;
            boolean bool1 = bool;
            if (fragment3.A == i2)
              if (fragment3 == fragment2) {
                bool1 = true;
                fragment = paramFragment;
                i = m;
              } else {
                fragment = paramFragment;
                i = m;
                if (fragment3 == paramFragment) {
                  this.a.add(m, new n.a(9, fragment3));
                  i = m + 1;
                  fragment = null;
                } 
                n.a a2 = new n.a(3, fragment3);
                a2.c = ((n.a)fragment1).c;
                a2.e = ((n.a)fragment1).e;
                a2.d = ((n.a)fragment1).d;
                a2.f = ((n.a)fragment1).f;
                this.a.add(i, a2);
                paramArrayList.remove(fragment3);
                i++;
                bool1 = bool;
              }  
            i1--;
            paramFragment = fragment;
            m = i;
            bool = bool1;
          } 
          if (bool) {
            this.a.remove(m);
            m--;
          } else {
            ((n.a)fragment1).a = 1;
            paramArrayList.add(fragment2);
          } 
          continue;
        }  
      paramArrayList.add(((n.a)fragment1).b);
      m = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  public String o() {
    return this.j;
  }
  
  boolean p(int paramInt) {
    int m = this.a.size();
    for (int i = 0; i < m; i++) {
      int i1;
      Fragment fragment = ((n.a)this.a.get(i)).b;
      if (fragment != null) {
        i1 = fragment.A;
      } else {
        i1 = 0;
      } 
      if (i1 && i1 == paramInt)
        return true; 
    } 
    return false;
  }
  
  boolean q(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int i1 = this.a.size();
    int m = -1;
    int i = 0;
    while (i < i1) {
      int i2;
      Fragment fragment = ((n.a)this.a.get(i)).b;
      if (fragment != null) {
        i2 = fragment.A;
      } else {
        i2 = 0;
      } 
      int i3 = m;
      if (i2) {
        i3 = m;
        if (i2 != m) {
          for (m = paramInt1; m < paramInt2; m++) {
            a a1 = paramArrayList.get(m);
            int i4 = a1.a.size();
            for (i3 = 0; i3 < i4; i3++) {
              int i5;
              Fragment fragment1 = ((n.a)a1.a.get(i3)).b;
              if (fragment1 != null) {
                i5 = fragment1.A;
              } else {
                i5 = 0;
              } 
              if (i5 == i2)
                return true; 
            } 
          } 
          i3 = i2;
        } 
      } 
      i++;
      m = i3;
    } 
    return false;
  }
  
  boolean s() {
    for (int i = 0; i < this.a.size(); i++) {
      if (r(this.a.get(i)))
        return true; 
    } 
    return false;
  }
  
  public void t() {
    if (this.r != null) {
      for (int i = 0; i < this.r.size(); i++)
        ((Runnable)this.r.get(i)).run(); 
      this.r = null;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.u >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.u);
    } 
    if (this.j != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.j);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  void u(Fragment.f paramf) {
    for (int i = 0; i < this.a.size(); i++) {
      n.a a1 = this.a.get(i);
      if (r(a1))
        a1.b.l1(paramf); 
    } 
  }
  
  Fragment v(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = this.a.size() - 1;
    while (i >= 0) {
      n.a a1 = this.a.get(i);
      int m = a1.a;
      if (m != 1)
        if (m != 3) {
          switch (m) {
            case 10:
              a1.h = a1.g;
              break;
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i--;
        }  
    } 
    return paramFragment;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */