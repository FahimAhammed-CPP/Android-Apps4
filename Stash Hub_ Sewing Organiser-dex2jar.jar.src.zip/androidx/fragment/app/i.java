package androidx.fragment.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class i {
  static final g b = new g();
  
  private g a = null;
  
  public abstract n a();
  
  public abstract void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract boolean c();
  
  public abstract Fragment d(String paramString);
  
  public g e() {
    if (this.a == null)
      this.a = b; 
    return this.a;
  }
  
  public abstract List<Fragment> f();
  
  public abstract void g(int paramInt1, int paramInt2);
  
  public abstract boolean h();
  
  public void i(g paramg) {
    this.a = paramg;
  }
  
  public static abstract class a {}
  
  public static interface b {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */