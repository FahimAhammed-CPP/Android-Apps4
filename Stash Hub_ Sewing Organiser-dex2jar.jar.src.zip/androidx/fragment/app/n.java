package androidx.fragment.app;

import androidx.lifecycle.e;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class n {
  ArrayList<a> a = new ArrayList<a>();
  
  int b;
  
  int c;
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  boolean h;
  
  boolean i = true;
  
  String j;
  
  int k;
  
  CharSequence l;
  
  int m;
  
  CharSequence n;
  
  ArrayList<String> o;
  
  ArrayList<String> p;
  
  boolean q = false;
  
  ArrayList<Runnable> r;
  
  public n b(Fragment paramFragment, String paramString) {
    f(0, paramFragment, paramString, 1);
    return this;
  }
  
  void c(a parama) {
    this.a.add(parama);
    parama.c = this.b;
    parama.d = this.c;
    parama.e = this.d;
    parama.f = this.e;
  }
  
  public abstract int d();
  
  public abstract int e();
  
  void f(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      if (paramString != null) {
        String str = paramFragment.B;
        if (str == null || paramString.equals(str)) {
          paramFragment.B = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.B);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramFragment.z;
          if (i == 0 || i == paramInt1) {
            paramFragment.z = paramInt1;
            paramFragment.A = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.z);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      c(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public n g(Fragment paramFragment) {
    c(new a(3, paramFragment));
    return this;
  }
  
  static final class a {
    int a;
    
    Fragment b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    e.b g;
    
    e.b h;
    
    a() {}
    
    a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      e.b b1 = e.b.e;
      this.g = b1;
      this.h = b1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */