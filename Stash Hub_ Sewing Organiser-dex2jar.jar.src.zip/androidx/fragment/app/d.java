package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.l;
import androidx.collection.g;
import androidx.core.app.a;
import androidx.lifecycle.e;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class d extends ComponentActivity implements a.f, a.h {
  boolean A;
  
  boolean B;
  
  boolean C = true;
  
  boolean D;
  
  boolean E;
  
  boolean F;
  
  int G;
  
  g<String> H;
  
  final f y = f.b(new a(this));
  
  final k z = new k((j)this);
  
  private static boolean A(i parami, e.b paramb) {
    Iterator<Fragment> iterator = parami.f().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.a().b().g(e.b.d)) {
        fragment.W.n(paramb);
        bool1 = true;
      } 
      bool = bool1;
      if (fragment.x() != null)
        bool = bool1 | A(fragment.q(), paramb); 
    } 
    return bool;
  }
  
  private int u(Fragment paramFragment) {
    if (this.H.m() < 65534) {
      while (this.H.h(this.G) >= 0)
        this.G = (this.G + 1) % 65534; 
      int i = this.G;
      this.H.j(i, paramFragment.e);
      this.G = (this.G + 1) % 65534;
      return i;
    } 
    throw new IllegalStateException("Too many pending Fragment activity results.");
  }
  
  static void v(int paramInt) {
    if ((paramInt & 0xFFFF0000) == 0)
      return; 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  private void z() {
    do {
    
    } while (A(x(), e.b.c));
  }
  
  public void B(Fragment paramFragment) {}
  
  @Deprecated
  protected boolean C(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  protected void D() {
    this.z.h(e.a.ON_RESUME);
    this.y.p();
  }
  
  public void E(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    this.F = true;
    if (paramInt == -1)
      try {
        a.d((Activity)this, paramIntent, -1, paramBundle);
        return;
      } finally {
        this.F = false;
      }  
    v(paramInt);
    a.d((Activity)this, paramIntent, (u(paramFragment) + 1 << 16) + (paramInt & 0xFFFF), paramBundle);
    this.F = false;
  }
  
  @Deprecated
  public void F() {
    invalidateOptionsMenu();
  }
  
  public final void b(int paramInt) {
    if (!this.D && paramInt != -1)
      v(paramInt); 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.A);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.B);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.C);
    if (getApplication() != null)
      androidx.loader.app.a.b((j)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.y.u().b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    this.y.v();
    int i = paramInt1 >> 16;
    if (i != 0) {
      String str = (String)this.H.e(--i);
      this.H.l(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.y.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      fragment.W(paramInt1 & 0xFFFF, paramInt2, (Intent)stringBuilder);
      return;
    } 
    a.g g1 = a.a();
    if (g1 != null && g1.a((Activity)this, paramInt1, paramInt2, (Intent)stringBuilder))
      return; 
    super.onActivityResult(paramInt1, paramInt2, (Intent)stringBuilder);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.y.v();
    this.y.d(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.y.a(null);
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      this.y.x(parcelable);
      if (paramBundle.containsKey("android:support:next_request_index")) {
        this.G = paramBundle.getInt("android:support:next_request_index");
        int[] arrayOfInt = paramBundle.getIntArray("android:support:request_indicies");
        String[] arrayOfString = paramBundle.getStringArray("android:support:request_fragment_who");
        if (arrayOfInt == null || arrayOfString == null || arrayOfInt.length != arrayOfString.length) {
          Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
        } else {
          this.H = new g(arrayOfInt.length);
          for (int i = 0; i < arrayOfInt.length; i++)
            this.H.j(arrayOfInt[i], arrayOfString[i]); 
        } 
      } 
    } 
    if (this.H == null) {
      this.H = new g();
      this.G = 0;
    } 
    super.onCreate(paramBundle);
    this.z.h(e.a.ON_CREATE);
    this.y.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.y.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = w(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = w(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.y.h();
    this.z.h(e.a.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.y.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.y.e(paramMenuItem)) : this.y.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.y.j(paramBoolean);
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.y.v();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.y.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.B = false;
    this.y.m();
    this.z.h(e.a.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.y.n(paramBoolean);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    D();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (C(paramView, paramMenu) | this.y.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.y.v();
    int i = paramInt >> 16 & 0xFFFF;
    if (i != 0) {
      StringBuilder stringBuilder;
      String str = (String)this.H.e(--i);
      this.H.l(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.y.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      fragment.v0(paramInt & 0xFFFF, (String[])stringBuilder, paramArrayOfint);
    } 
  }
  
  protected void onResume() {
    super.onResume();
    this.B = true;
    this.y.v();
    this.y.s();
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    z();
    this.z.h(e.a.ON_STOP);
    Parcelable parcelable = this.y.y();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
    if (this.H.m() > 0) {
      paramBundle.putInt("android:support:next_request_index", this.G);
      int[] arrayOfInt = new int[this.H.m()];
      String[] arrayOfString = new String[this.H.m()];
      for (int i = 0; i < this.H.m(); i++) {
        arrayOfInt[i] = this.H.i(i);
        arrayOfString[i] = (String)this.H.n(i);
      } 
      paramBundle.putIntArray("android:support:request_indicies", arrayOfInt);
      paramBundle.putStringArray("android:support:request_fragment_who", arrayOfString);
    } 
  }
  
  protected void onStart() {
    super.onStart();
    this.C = false;
    if (!this.A) {
      this.A = true;
      this.y.c();
    } 
    this.y.v();
    this.y.s();
    this.z.h(e.a.ON_START);
    this.y.q();
  }
  
  public void onStateNotSaved() {
    this.y.v();
  }
  
  protected void onStop() {
    super.onStop();
    this.C = true;
    z();
    this.y.r();
    this.z.h(e.a.ON_STOP);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (!this.F && paramInt != -1)
      v(paramInt); 
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (!this.F && paramInt != -1)
      v(paramInt); 
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.E && paramInt1 != -1)
      v(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    if (!this.E && paramInt1 != -1)
      v(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  final View w(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.y.w(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public i x() {
    return this.y.u();
  }
  
  @Deprecated
  public androidx.loader.app.a y() {
    return androidx.loader.app.a.b((j)this);
  }
  
  class a extends h<d> implements g0, l {
    public a(d this$0) {
      super(this$0);
    }
    
    public e a() {
      return (e)this.f.z;
    }
    
    public View c(int param1Int) {
      return this.f.findViewById(param1Int);
    }
    
    public boolean d() {
      Window window = this.f.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public f0 e() {
      return this.f.e();
    }
    
    public void i(Fragment param1Fragment) {
      this.f.B(param1Fragment);
    }
    
    public OnBackPressedDispatcher j() {
      return this.f.j();
    }
    
    public void l(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      this.f.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
    }
    
    public LayoutInflater n() {
      return this.f.getLayoutInflater().cloneInContext((Context)this.f);
    }
    
    public int o() {
      Window window = this.f.getWindow();
      return (window == null) ? 0 : (window.getAttributes()).windowAnimations;
    }
    
    public boolean p() {
      return (this.f.getWindow() != null);
    }
    
    public boolean q(Fragment param1Fragment) {
      return this.f.isFinishing() ^ true;
    }
    
    public void r(Fragment param1Fragment, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      this.f.E(param1Fragment, param1Intent, param1Int, param1Bundle);
    }
    
    public void s() {
      this.f.F();
    }
    
    public d t() {
      return this.f;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */