package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class e {
  @Deprecated
  public Fragment b(Context paramContext, String paramString, Bundle paramBundle) {
    return Fragment.O(paramContext, paramString, paramBundle);
  }
  
  public abstract View c(int paramInt);
  
  public abstract boolean d();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */