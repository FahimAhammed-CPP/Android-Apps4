package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import androidx.lifecycle.e;

final class m implements Parcelable {
  public static final Parcelable.Creator<m> CREATOR = new a();
  
  final String a;
  
  final String b;
  
  final boolean c;
  
  final int d;
  
  final int e;
  
  final String f;
  
  final boolean g;
  
  final boolean l;
  
  final boolean m;
  
  final Bundle n;
  
  final boolean o;
  
  final int p;
  
  Bundle q;
  
  Fragment r;
  
  m(Parcel paramParcel) {
    boolean bool1;
    this.a = paramParcel.readString();
    this.b = paramParcel.readString();
    int i = paramParcel.readInt();
    boolean bool2 = true;
    if (i != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.c = bool1;
    this.d = paramParcel.readInt();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readString();
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.g = bool1;
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.l = bool1;
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.m = bool1;
    this.n = paramParcel.readBundle();
    if (paramParcel.readInt() != 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    this.o = bool1;
    this.q = paramParcel.readBundle();
    this.p = paramParcel.readInt();
  }
  
  m(Fragment paramFragment) {
    this.a = paramFragment.getClass().getName();
    this.b = paramFragment.e;
    this.c = paramFragment.q;
    this.d = paramFragment.z;
    this.e = paramFragment.A;
    this.f = paramFragment.B;
    this.g = paramFragment.E;
    this.l = paramFragment.p;
    this.m = paramFragment.D;
    this.n = paramFragment.f;
    this.o = paramFragment.C;
    this.p = paramFragment.V.ordinal();
  }
  
  public Fragment a(ClassLoader paramClassLoader, g paramg) {
    if (this.r == null) {
      Bundle bundle2 = this.n;
      if (bundle2 != null)
        bundle2.setClassLoader(paramClassLoader); 
      Fragment fragment2 = paramg.a(paramClassLoader, this.a);
      this.r = fragment2;
      fragment2.h1(this.n);
      Bundle bundle1 = this.q;
      if (bundle1 != null) {
        bundle1.setClassLoader(paramClassLoader);
        fragment1 = this.r;
        bundle1 = this.q;
      } else {
        fragment1 = this.r;
        bundle1 = new Bundle();
      } 
      fragment1.b = bundle1;
      Fragment fragment1 = this.r;
      fragment1.e = this.b;
      fragment1.q = this.c;
      fragment1.s = true;
      fragment1.z = this.d;
      fragment1.A = this.e;
      fragment1.B = this.f;
      fragment1.E = this.g;
      fragment1.p = this.l;
      fragment1.D = this.m;
      fragment1.C = this.o;
      fragment1.V = e.b.values()[this.p];
      if (j.L) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiated fragment ");
        stringBuilder.append(this.r);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    return this.r;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentState{");
    stringBuilder.append(this.a);
    stringBuilder.append(" (");
    stringBuilder.append(this.b);
    stringBuilder.append(")}:");
    if (this.c)
      stringBuilder.append(" fromLayout"); 
    if (this.e != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.e));
    } 
    String str = this.f;
    if (str != null && !str.isEmpty()) {
      stringBuilder.append(" tag=");
      stringBuilder.append(this.f);
    } 
    if (this.g)
      stringBuilder.append(" retainInstance"); 
    if (this.l)
      stringBuilder.append(" removing"); 
    if (this.m)
      stringBuilder.append(" detached"); 
    if (this.o)
      stringBuilder.append(" hidden"); 
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  static final class a implements Parcelable.Creator<m> {
    public m a(Parcel param1Parcel) {
      return new m(param1Parcel);
    }
    
    public m[] b(int param1Int) {
      return new m[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */