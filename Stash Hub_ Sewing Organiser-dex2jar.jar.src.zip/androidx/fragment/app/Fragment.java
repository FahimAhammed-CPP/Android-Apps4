package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.app.n;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.p;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;
import x.d;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, j, g0, d {
  static final Object b0 = new Object();
  
  int A;
  
  String B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  boolean F;
  
  boolean G;
  
  boolean H = true;
  
  private boolean I;
  
  ViewGroup J;
  
  View K;
  
  View L;
  
  boolean M;
  
  boolean N = true;
  
  d O;
  
  Runnable P = new a(this);
  
  boolean Q;
  
  boolean R;
  
  float S;
  
  LayoutInflater T;
  
  boolean U;
  
  androidx.lifecycle.e.b V = androidx.lifecycle.e.b.e;
  
  k W;
  
  r X;
  
  p<j> Y = new p();
  
  x.c Z;
  
  int a = 0;
  
  private int a0;
  
  Bundle b;
  
  SparseArray<Parcelable> c;
  
  Boolean d;
  
  String e = UUID.randomUUID().toString();
  
  Bundle f;
  
  Fragment g;
  
  String l = null;
  
  int m;
  
  private Boolean n = null;
  
  boolean o;
  
  boolean p;
  
  boolean q;
  
  boolean r;
  
  boolean s;
  
  boolean t;
  
  int u;
  
  j v;
  
  h w;
  
  j x = new j();
  
  Fragment y;
  
  int z;
  
  public Fragment() {
    M();
  }
  
  private void M() {
    this.W = new k(this);
    this.Z = x.c.a(this);
    if (Build.VERSION.SDK_INT >= 19)
      this.W.a((i)new h(this) {
            public void a(j param1j, androidx.lifecycle.e.a param1a) {
              if (param1a == androidx.lifecycle.e.a.ON_STOP) {
                View view = this.a.K;
                if (view != null)
                  view.cancelPendingInputEvents(); 
              } 
            }
          }); 
  }
  
  @Deprecated
  public static Fragment O(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Fragment fragment = g.d(paramContext.getClassLoader(), paramString).getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.h1(paramBundle);
      } 
      return fragment;
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new e(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new e(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new e(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new e(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  private d h() {
    if (this.O == null)
      this.O = new d(); 
    return this.O;
  }
  
  int A() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.e;
  }
  
  public void A0(View paramView, Bundle paramBundle) {}
  
  int B() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.f;
  }
  
  public void B0(Bundle paramBundle) {
    this.I = true;
  }
  
  public final Fragment C() {
    return this.y;
  }
  
  void C0(Bundle paramBundle) {
    this.x.S0();
    this.a = 2;
    this.I = false;
    V(paramBundle);
    if (this.I) {
      this.x.y();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new s(stringBuilder.toString());
  }
  
  public Object D() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object2 = d1.j;
    Object object1 = object2;
    if (object2 == b0)
      object1 = u(); 
    return object1;
  }
  
  void D0() {
    this.x.p(this.w, new c(this), this);
    this.I = false;
    Y(this.w.g());
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onAttach()");
    throw new s(stringBuilder.toString());
  }
  
  public final Resources E() {
    return a1().getResources();
  }
  
  void E0(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    this.x.z(paramConfiguration);
  }
  
  public final boolean F() {
    return this.E;
  }
  
  boolean F0(MenuItem paramMenuItem) {
    if (!this.C) {
      if (a0(paramMenuItem))
        return true; 
      if (this.x.A(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public Object G() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object2 = d1.h;
    Object object1 = object2;
    if (object2 == b0)
      object1 = s(); 
    return object1;
  }
  
  void G0(Bundle paramBundle) {
    this.x.S0();
    this.a = 1;
    this.I = false;
    this.Z.d(paramBundle);
    b0(paramBundle);
    this.U = true;
    if (this.I) {
      this.W.h(androidx.lifecycle.e.a.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new s(stringBuilder.toString());
  }
  
  public Object H() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.k;
  }
  
  boolean H0(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool3 = this.C;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.G) {
        bool = bool1;
        if (this.H) {
          bool = true;
          e0(paramMenu, paramMenuInflater);
        } 
      } 
      bool2 = bool | this.x.C(paramMenu, paramMenuInflater);
    } 
    return bool2;
  }
  
  public Object I() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object2 = d1.l;
    Object object1 = object2;
    if (object2 == b0)
      object1 = H(); 
    return object1;
  }
  
  void I0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.x.S0();
    this.t = true;
    this.X = new r();
    View view = f0(paramLayoutInflater, paramViewGroup, paramBundle);
    this.K = view;
    if (view != null) {
      this.X.c();
      this.Y.m(this.X);
      return;
    } 
    if (!this.X.d()) {
      this.X = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  int J() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.c;
  }
  
  void J0() {
    this.x.D();
    this.W.h(androidx.lifecycle.e.a.ON_DESTROY);
    this.a = 0;
    this.I = false;
    this.U = false;
    g0();
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new s(stringBuilder.toString());
  }
  
  public final Fragment K() {
    Fragment fragment = this.g;
    if (fragment != null)
      return fragment; 
    j j1 = this.v;
    if (j1 != null) {
      String str = this.l;
      if (str != null)
        return j1.g.get(str); 
    } 
    return null;
  }
  
  void K0() {
    this.x.E();
    if (this.K != null)
      this.X.b(androidx.lifecycle.e.a.ON_DESTROY); 
    this.a = 1;
    this.I = false;
    i0();
    if (this.I) {
      androidx.loader.app.a.b(this).d();
      this.t = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new s(stringBuilder.toString());
  }
  
  public View L() {
    return this.K;
  }
  
  void L0() {
    this.I = false;
    j0();
    this.T = null;
    if (this.I) {
      if (!this.x.D0()) {
        this.x.D();
        this.x = new j();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new s(stringBuilder.toString());
  }
  
  LayoutInflater M0(Bundle paramBundle) {
    LayoutInflater layoutInflater = k0(paramBundle);
    this.T = layoutInflater;
    return layoutInflater;
  }
  
  void N() {
    M();
    this.e = UUID.randomUUID().toString();
    this.o = false;
    this.p = false;
    this.q = false;
    this.r = false;
    this.s = false;
    this.u = 0;
    this.v = null;
    this.x = new j();
    this.w = null;
    this.z = 0;
    this.A = 0;
    this.B = null;
    this.C = false;
    this.D = false;
  }
  
  void N0() {
    onLowMemory();
    this.x.F();
  }
  
  void O0(boolean paramBoolean) {
    o0(paramBoolean);
    this.x.G(paramBoolean);
  }
  
  boolean P() {
    d d1 = this.O;
    return (d1 == null) ? false : d1.s;
  }
  
  boolean P0(MenuItem paramMenuItem) {
    if (!this.C) {
      if (this.G && this.H && p0(paramMenuItem))
        return true; 
      if (this.x.V(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  final boolean Q() {
    return (this.u > 0);
  }
  
  void Q0(Menu paramMenu) {
    if (!this.C) {
      if (this.G && this.H)
        q0(paramMenu); 
      this.x.W(paramMenu);
    } 
  }
  
  boolean R() {
    d d1 = this.O;
    return (d1 == null) ? false : d1.q;
  }
  
  void R0() {
    this.x.Y();
    if (this.K != null)
      this.X.b(androidx.lifecycle.e.a.ON_PAUSE); 
    this.W.h(androidx.lifecycle.e.a.ON_PAUSE);
    this.a = 3;
    this.I = false;
    r0();
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new s(stringBuilder.toString());
  }
  
  public final boolean S() {
    return this.p;
  }
  
  void S0(boolean paramBoolean) {
    s0(paramBoolean);
    this.x.Z(paramBoolean);
  }
  
  public final boolean T() {
    j j1 = this.v;
    return (j1 == null) ? false : j1.H0();
  }
  
  boolean T0(Menu paramMenu) {
    boolean bool3 = this.C;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.G) {
        bool = bool1;
        if (this.H) {
          bool = true;
          t0(paramMenu);
        } 
      } 
      bool2 = bool | this.x.a0(paramMenu);
    } 
    return bool2;
  }
  
  void U() {
    this.x.S0();
  }
  
  void U0() {
    boolean bool = this.v.F0(this);
    Boolean bool1 = this.n;
    if (bool1 == null || bool1.booleanValue() != bool) {
      this.n = Boolean.valueOf(bool);
      u0(bool);
      this.x.b0();
    } 
  }
  
  public void V(Bundle paramBundle) {
    this.I = true;
  }
  
  void V0() {
    this.x.S0();
    this.x.l0();
    this.a = 4;
    this.I = false;
    w0();
    if (this.I) {
      k k1 = this.W;
      androidx.lifecycle.e.a a = androidx.lifecycle.e.a.ON_RESUME;
      k1.h(a);
      if (this.K != null)
        this.X.b(a); 
      this.x.c0();
      this.x.l0();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new s(stringBuilder.toString());
  }
  
  public void W(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  void W0(Bundle paramBundle) {
    x0(paramBundle);
    this.Z.e(paramBundle);
    Parcelable parcelable = this.x.e1();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  @Deprecated
  public void X(Activity paramActivity) {
    this.I = true;
  }
  
  void X0() {
    this.x.S0();
    this.x.l0();
    this.a = 3;
    this.I = false;
    y0();
    if (this.I) {
      k k1 = this.W;
      androidx.lifecycle.e.a a = androidx.lifecycle.e.a.ON_START;
      k1.h(a);
      if (this.K != null)
        this.X.b(a); 
      this.x.d0();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new s(stringBuilder.toString());
  }
  
  public void Y(Context paramContext) {
    Activity activity;
    this.I = true;
    h h1 = this.w;
    if (h1 == null) {
      h1 = null;
    } else {
      activity = h1.f();
    } 
    if (activity != null) {
      this.I = false;
      X(activity);
    } 
  }
  
  void Y0() {
    this.x.f0();
    if (this.K != null)
      this.X.b(androidx.lifecycle.e.a.ON_STOP); 
    this.W.h(androidx.lifecycle.e.a.ON_STOP);
    this.a = 2;
    this.I = false;
    z0();
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new s(stringBuilder.toString());
  }
  
  public void Z(Fragment paramFragment) {}
  
  public final d Z0() {
    d d1 = l();
    if (d1 != null)
      return d1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to an activity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.W;
  }
  
  public boolean a0(MenuItem paramMenuItem) {
    return false;
  }
  
  public final Context a1() {
    Context context = r();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b0(Bundle paramBundle) {
    this.I = true;
    d1(paramBundle);
    if (!this.x.G0(1))
      this.x.B(); 
  }
  
  public final i b1() {
    i i = w();
    if (i != null)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not associated with a fragment manager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public Animation c0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public final View c1() {
    View view = L();
    if (view != null)
      return view; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not return a View from onCreateView() or this was called before onCreateView().");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public Animator d0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  void d1(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.x.c1(parcelable);
        this.x.B();
      } 
    } 
  }
  
  public f0 e() {
    j j1 = this.v;
    if (j1 != null)
      return j1.A0(this); 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public void e0(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  final void e1(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.c;
    if (sparseArray != null) {
      this.L.restoreHierarchyState(sparseArray);
      this.c = null;
    } 
    this.I = false;
    B0(paramBundle);
    if (this.I) {
      if (this.K != null)
        this.X.b(androidx.lifecycle.e.a.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new s(stringBuilder.toString());
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  void f() {
    d d1 = this.O;
    f f = null;
    if (d1 != null) {
      d1.q = false;
      f = d1.r;
      d1.r = null;
    } 
    if (f != null)
      f.a(); 
  }
  
  public View f0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    int i = this.a0;
    return (i != 0) ? paramLayoutInflater.inflate(i, paramViewGroup, false) : null;
  }
  
  void f1(View paramView) {
    (h()).a = paramView;
  }
  
  public void g(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.z));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.A));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.B);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.a);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.e);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.u);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.o);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.p);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.q);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.r);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.C);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.D);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.H);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.G);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.E);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.N);
    if (this.v != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.v);
    } 
    if (this.w != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.w);
    } 
    if (this.y != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.y);
    } 
    if (this.f != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.f);
    } 
    if (this.b != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.b);
    } 
    if (this.c != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.c);
    } 
    Fragment fragment = K();
    if (fragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(fragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.m);
    } 
    if (z() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(z());
    } 
    if (this.J != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.J);
    } 
    if (this.K != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.K);
    } 
    if (this.L != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.K);
    } 
    if (o() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(o());
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(J());
    } 
    if (r() != null)
      androidx.loader.app.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Child ");
    stringBuilder1.append(this.x);
    stringBuilder1.append(":");
    paramPrintWriter.println(stringBuilder1.toString());
    j j1 = this.x;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("  ");
    j1.b(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void g0() {
    this.I = true;
  }
  
  void g1(Animator paramAnimator) {
    (h()).b = paramAnimator;
  }
  
  public void h0() {}
  
  public void h1(Bundle paramBundle) {
    if (this.v == null || !T()) {
      this.f = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already added and state has been saved");
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  Fragment i(String paramString) {
    return paramString.equals(this.e) ? this : this.x.q0(paramString);
  }
  
  public void i0() {
    this.I = true;
  }
  
  void i1(boolean paramBoolean) {
    (h()).s = paramBoolean;
  }
  
  public void j0() {
    this.I = true;
  }
  
  void j1(int paramInt) {
    if (this.O == null && paramInt == 0)
      return; 
    (h()).d = paramInt;
  }
  
  public final androidx.savedstate.a k() {
    return this.Z.b();
  }
  
  public LayoutInflater k0(Bundle paramBundle) {
    return y(paramBundle);
  }
  
  void k1(int paramInt1, int paramInt2) {
    if (this.O == null && paramInt1 == 0 && paramInt2 == 0)
      return; 
    h();
    d d1 = this.O;
    d1.e = paramInt1;
    d1.f = paramInt2;
  }
  
  public final d l() {
    h h1 = this.w;
    return (h1 == null) ? null : (d)h1.f();
  }
  
  public void l0(boolean paramBoolean) {}
  
  void l1(f paramf) {
    h();
    d d1 = this.O;
    f f1 = d1.r;
    if (paramf == f1)
      return; 
    if (paramf == null || f1 == null) {
      if (d1.q)
        d1.r = paramf; 
      if (paramf != null)
        paramf.b(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean m() {
    d d1 = this.O;
    if (d1 != null) {
      Boolean bool = d1.n;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  @Deprecated
  public void m0(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.I = true;
  }
  
  void m1(int paramInt) {
    (h()).c = paramInt;
  }
  
  public boolean n() {
    d d1 = this.O;
    if (d1 != null) {
      Boolean bool = d1.m;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public void n0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.I = true;
    h h1 = this.w;
    if (h1 == null) {
      h1 = null;
    } else {
      activity = h1.f();
    } 
    if (activity != null) {
      this.I = false;
      m0(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public void n1(Intent paramIntent, int paramInt, Bundle paramBundle) {
    h h1 = this.w;
    if (h1 != null) {
      h1.r(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  View o() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.a;
  }
  
  public void o0(boolean paramBoolean) {}
  
  public void o1() {
    j j1 = this.v;
    if (j1 == null || j1.u == null) {
      (h()).q = false;
      return;
    } 
    if (Looper.myLooper() != this.v.u.h().getLooper()) {
      this.v.u.h().postAtFrontOfQueue(new b(this));
      return;
    } 
    f();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.I = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    Z0().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.I = true;
  }
  
  Animator p() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.b;
  }
  
  public boolean p0(MenuItem paramMenuItem) {
    return false;
  }
  
  public final i q() {
    if (this.w != null)
      return this.x; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" has not been attached yet.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void q0(Menu paramMenu) {}
  
  public Context r() {
    h h1 = this.w;
    return (h1 == null) ? null : h1.g();
  }
  
  public void r0() {
    this.I = true;
  }
  
  public Object s() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.g;
  }
  
  public void s0(boolean paramBoolean) {}
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    n1(paramIntent, paramInt, null);
  }
  
  n t() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.o;
  }
  
  public void t0(Menu paramMenu) {}
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    androidx.core.util.b.a(this, stringBuilder);
    stringBuilder.append(" (");
    stringBuilder.append(this.e);
    stringBuilder.append(")");
    if (this.z != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.z));
    } 
    if (this.B != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.B);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public Object u() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.i;
  }
  
  public void u0(boolean paramBoolean) {}
  
  n v() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.p;
  }
  
  public void v0(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public final i w() {
    return this.v;
  }
  
  public void w0() {
    this.I = true;
  }
  
  public final Object x() {
    h h1 = this.w;
    return (h1 == null) ? null : h1.m();
  }
  
  public void x0(Bundle paramBundle) {}
  
  @Deprecated
  public LayoutInflater y(Bundle paramBundle) {
    h h1 = this.w;
    if (h1 != null) {
      LayoutInflater layoutInflater = h1.n();
      androidx.core.view.c.b(layoutInflater, this.x.y0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void y0() {
    this.I = true;
  }
  
  int z() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.d;
  }
  
  public void z0() {
    this.I = true;
  }
  
  class a implements Runnable {
    a(Fragment this$0) {}
    
    public void run() {
      this.a.o1();
    }
  }
  
  class b implements Runnable {
    b(Fragment this$0) {}
    
    public void run() {
      this.a.f();
    }
  }
  
  class c extends e {
    c(Fragment this$0) {}
    
    public View c(int param1Int) {
      View view = this.a.K;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean d() {
      return (this.a.K != null);
    }
  }
  
  static class d {
    View a;
    
    Animator b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    Object g = null;
    
    Object h;
    
    Object i;
    
    Object j;
    
    Object k;
    
    Object l;
    
    Boolean m;
    
    Boolean n;
    
    n o;
    
    n p;
    
    boolean q;
    
    Fragment.f r;
    
    boolean s;
    
    d() {
      Object object = Fragment.b0;
      this.h = object;
      this.i = null;
      this.j = object;
      this.k = null;
      this.l = object;
    }
  }
  
  public static class e extends RuntimeException {
    public e(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  static interface f {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */