package androidx.fragment.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;

public class c extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  private Handler c0;
  
  private Runnable d0 = new a(this);
  
  int e0 = 0;
  
  int f0 = 0;
  
  boolean g0 = true;
  
  boolean h0 = true;
  
  int i0 = -1;
  
  Dialog j0;
  
  boolean k0;
  
  boolean l0;
  
  boolean m0;
  
  public void V(Bundle paramBundle) {
    super.V(paramBundle);
    if (!this.h0)
      return; 
    View view = L();
    if (view != null)
      if (view.getParent() == null) {
        this.j0.setContentView(view);
      } else {
        throw new IllegalStateException("DialogFragment can not be attached to a container view");
      }  
    d d = l();
    if (d != null)
      this.j0.setOwnerActivity((Activity)d); 
    this.j0.setCancelable(this.g0);
    this.j0.setOnCancelListener(this);
    this.j0.setOnDismissListener(this);
    if (paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.j0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public void Y(Context paramContext) {
    super.Y(paramContext);
    if (!this.m0)
      this.l0 = false; 
  }
  
  public void b0(Bundle paramBundle) {
    boolean bool;
    super.b0(paramBundle);
    this.c0 = new Handler();
    if (this.A == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h0 = bool;
    if (paramBundle != null) {
      this.e0 = paramBundle.getInt("android:style", 0);
      this.f0 = paramBundle.getInt("android:theme", 0);
      this.g0 = paramBundle.getBoolean("android:cancelable", true);
      this.h0 = paramBundle.getBoolean("android:showsDialog", this.h0);
      this.i0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public void i0() {
    super.i0();
    Dialog dialog = this.j0;
    if (dialog != null) {
      this.k0 = true;
      dialog.setOnDismissListener(null);
      this.j0.dismiss();
      if (!this.l0)
        onDismiss((DialogInterface)this.j0); 
      this.j0 = null;
    } 
  }
  
  public void j0() {
    super.j0();
    if (!this.m0 && !this.l0)
      this.l0 = true; 
  }
  
  public LayoutInflater k0(Bundle paramBundle) {
    if (!this.h0)
      return super.k0(paramBundle); 
    Dialog dialog = q1(paramBundle);
    this.j0 = dialog;
    if (dialog != null) {
      s1(dialog, this.e0);
      Context context1 = this.j0.getContext();
      return (LayoutInflater)context1.getSystemService("layout_inflater");
    } 
    Context context = this.w.g();
    return (LayoutInflater)context.getSystemService("layout_inflater");
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.k0)
      p1(true, true); 
  }
  
  void p1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.l0)
      return; 
    this.l0 = true;
    this.m0 = false;
    Dialog dialog = this.j0;
    if (dialog != null) {
      dialog.setOnDismissListener(null);
      this.j0.dismiss();
      if (!paramBoolean2)
        if (Looper.myLooper() == this.c0.getLooper()) {
          onDismiss((DialogInterface)this.j0);
        } else {
          this.c0.post(this.d0);
        }  
    } 
    this.k0 = true;
    if (this.i0 >= 0) {
      b1().g(this.i0, 1);
      this.i0 = -1;
      return;
    } 
    n n = b1().a();
    n.g(this);
    if (paramBoolean1) {
      n.e();
      return;
    } 
    n.d();
  }
  
  public Dialog q1(Bundle paramBundle) {
    throw null;
  }
  
  public void r1(boolean paramBoolean) {
    this.h0 = paramBoolean;
  }
  
  public void s1(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      paramDialog.getWindow().addFlags(24);
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public void t1(i parami, String paramString) {
    this.l0 = false;
    this.m0 = true;
    n n = parami.a();
    n.b(this, paramString);
    n.d();
  }
  
  public void x0(Bundle paramBundle) {
    super.x0(paramBundle);
    Dialog dialog = this.j0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      if (bundle != null)
        paramBundle.putBundle("android:savedDialogState", bundle); 
    } 
    int i = this.e0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.f0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.g0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.h0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.i0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void y0() {
    super.y0();
    Dialog dialog = this.j0;
    if (dialog != null) {
      this.k0 = false;
      dialog.show();
    } 
  }
  
  public void z0() {
    super.z0();
    Dialog dialog = this.j0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  class a implements Runnable {
    a(c this$0) {}
    
    public void run() {
      c c1 = this.a;
      Dialog dialog = c1.j0;
      if (dialog != null)
        c1.onDismiss((DialogInterface)dialog); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */