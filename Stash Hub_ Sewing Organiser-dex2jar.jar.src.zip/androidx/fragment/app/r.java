package androidx.fragment.app;

import androidx.lifecycle.e;
import androidx.lifecycle.j;
import androidx.lifecycle.k;

class r implements j {
  private k a = null;
  
  public e a() {
    c();
    return (e)this.a;
  }
  
  void b(e.a parama) {
    this.a.h(parama);
  }
  
  void c() {
    if (this.a == null)
      this.a = new k(this); 
  }
  
  boolean d() {
    return (this.a != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */