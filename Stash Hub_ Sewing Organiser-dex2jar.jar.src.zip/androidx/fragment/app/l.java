package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.b0;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.f0;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

class l extends b0 {
  private static final c0.b j = new a();
  
  private final HashSet<Fragment> d = new HashSet<Fragment>();
  
  private final HashMap<String, l> e = new HashMap<String, l>();
  
  private final HashMap<String, f0> f = new HashMap<String, f0>();
  
  private final boolean g;
  
  private boolean h = false;
  
  private boolean i = false;
  
  l(boolean paramBoolean) {
    this.g = paramBoolean;
  }
  
  static l h(f0 paramf0) {
    return (l)(new c0(paramf0, j)).a(l.class);
  }
  
  protected void d() {
    if (j.L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.h = true;
  }
  
  boolean e(Fragment paramFragment) {
    return this.d.add(paramFragment);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.d.equals(((l)paramObject).d) && this.e.equals(((l)paramObject).e) && this.f.equals(((l)paramObject).f));
    } 
    return false;
  }
  
  void f(Fragment paramFragment) {
    if (j.L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for ");
      stringBuilder.append(paramFragment);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    l l1 = this.e.get(paramFragment.e);
    if (l1 != null) {
      l1.d();
      this.e.remove(paramFragment.e);
    } 
    f0 f0 = this.f.get(paramFragment.e);
    if (f0 != null) {
      f0.a();
      this.f.remove(paramFragment.e);
    } 
  }
  
  l g(Fragment paramFragment) {
    l l2 = this.e.get(paramFragment.e);
    l l1 = l2;
    if (l2 == null) {
      l1 = new l(this.g);
      this.e.put(paramFragment.e, l1);
    } 
    return l1;
  }
  
  public int hashCode() {
    return (this.d.hashCode() * 31 + this.e.hashCode()) * 31 + this.f.hashCode();
  }
  
  Collection<Fragment> i() {
    return this.d;
  }
  
  f0 j(Fragment paramFragment) {
    f0 f02 = this.f.get(paramFragment.e);
    f0 f01 = f02;
    if (f02 == null) {
      f01 = new f0();
      this.f.put(paramFragment.e, f01);
    } 
    return f01;
  }
  
  boolean k() {
    return this.h;
  }
  
  boolean l(Fragment paramFragment) {
    return this.d.remove(paramFragment);
  }
  
  boolean m(Fragment paramFragment) {
    return !this.d.contains(paramFragment) ? true : (this.g ? this.h : (this.i ^ true));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<Fragment> iterator = this.d.iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.e.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append((String)iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.f.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append((String)iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  static final class a implements c0.b {
    public <T extends b0> T a(Class<T> param1Class) {
      return (T)new l(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */