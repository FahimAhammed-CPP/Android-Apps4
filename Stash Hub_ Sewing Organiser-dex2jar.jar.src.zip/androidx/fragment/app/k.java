package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

final class k implements Parcelable {
  public static final Parcelable.Creator<k> CREATOR = new a();
  
  ArrayList<m> a;
  
  ArrayList<String> b;
  
  b[] c;
  
  String d = null;
  
  int e;
  
  public k() {}
  
  public k(Parcel paramParcel) {
    this.a = paramParcel.createTypedArrayList(m.CREATOR);
    this.b = paramParcel.createStringArrayList();
    this.c = (b[])paramParcel.createTypedArray(b.CREATOR);
    this.d = paramParcel.readString();
    this.e = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.a);
    paramParcel.writeStringList(this.b);
    paramParcel.writeTypedArray((Parcelable[])this.c, paramInt);
    paramParcel.writeString(this.d);
    paramParcel.writeInt(this.e);
  }
  
  static final class a implements Parcelable.Creator<k> {
    public k a(Parcel param1Parcel) {
      return new k(param1Parcel);
    }
    
    public k[] b(int param1Int) {
      return new k[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */