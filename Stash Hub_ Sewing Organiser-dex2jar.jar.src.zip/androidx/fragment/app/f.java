package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.core.util.e;

public class f {
  private final h<?> a;
  
  private f(h<?> paramh) {
    this.a = paramh;
  }
  
  public static f b(h<?> paramh) {
    return new f((h)e.c(paramh, "callbacks == null"));
  }
  
  public void a(Fragment paramFragment) {
    h<?> h1 = this.a;
    h1.e.p(h1, h1, paramFragment);
  }
  
  public void c() {
    this.a.e.y();
  }
  
  public void d(Configuration paramConfiguration) {
    this.a.e.z(paramConfiguration);
  }
  
  public boolean e(MenuItem paramMenuItem) {
    return this.a.e.A(paramMenuItem);
  }
  
  public void f() {
    this.a.e.B();
  }
  
  public boolean g(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.e.C(paramMenu, paramMenuInflater);
  }
  
  public void h() {
    this.a.e.D();
  }
  
  public void i() {
    this.a.e.F();
  }
  
  public void j(boolean paramBoolean) {
    this.a.e.G(paramBoolean);
  }
  
  public boolean k(MenuItem paramMenuItem) {
    return this.a.e.V(paramMenuItem);
  }
  
  public void l(Menu paramMenu) {
    this.a.e.W(paramMenu);
  }
  
  public void m() {
    this.a.e.Y();
  }
  
  public void n(boolean paramBoolean) {
    this.a.e.Z(paramBoolean);
  }
  
  public boolean o(Menu paramMenu) {
    return this.a.e.a0(paramMenu);
  }
  
  public void p() {
    this.a.e.c0();
  }
  
  public void q() {
    this.a.e.d0();
  }
  
  public void r() {
    this.a.e.f0();
  }
  
  public boolean s() {
    return this.a.e.l0();
  }
  
  public Fragment t(String paramString) {
    return this.a.e.q0(paramString);
  }
  
  public i u() {
    return this.a.e;
  }
  
  public void v() {
    this.a.e.S0();
  }
  
  public View w(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.e.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void x(Parcelable paramParcelable) {
    h<?> h1 = this.a;
    if (h1 instanceof androidx.lifecycle.g0) {
      h1.e.c1(paramParcelable);
      return;
    } 
    throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
  }
  
  public Parcelable y() {
    return this.a.e.e1();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */