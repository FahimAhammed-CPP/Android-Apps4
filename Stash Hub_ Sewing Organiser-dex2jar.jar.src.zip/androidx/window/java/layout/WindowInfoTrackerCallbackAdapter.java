package androidx.window.java.layout;

import android.app.Activity;
import androidx.core.util.a;
import androidx.window.layout.WindowInfoTracker;
import androidx.window.layout.WindowLayoutInfo;
import h8.c2;
import h8.i;
import h8.p0;
import h8.q0;
import h8.u1;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.l;
import kotlinx.coroutines.flow.b;
import kotlinx.coroutines.flow.c;
import o7.o;
import o7.u;
import r7.d;
import r7.g;
import s7.b;
import y7.p;

public final class WindowInfoTrackerCallbackAdapter implements WindowInfoTracker {
  private final Map<a<?>, c2> consumerToJobMap;
  
  private final ReentrantLock lock;
  
  private final WindowInfoTracker tracker;
  
  public WindowInfoTrackerCallbackAdapter(WindowInfoTracker paramWindowInfoTracker) {
    this.tracker = paramWindowInfoTracker;
    this.lock = new ReentrantLock();
    this.consumerToJobMap = new LinkedHashMap<a<?>, c2>();
  }
  
  private final <T> void addListener(Executor paramExecutor, a<T> parama, b<? extends T> paramb) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (this.consumerToJobMap.get(parama) == null) {
        p0 p0 = q0.a((g)u1.a(paramExecutor));
        this.consumerToJobMap.put(parama, i.d(p0, null, null, new WindowInfoTrackerCallbackAdapter$addListener$1$1(paramb, parama, null), 3, null));
      } 
      u u = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  private final void removeListener(a<?> parama) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      c2 c22 = this.consumerToJobMap.get(parama);
      if (c22 != null)
        c2.a.a(c22, null, 1, null); 
      c2 c21 = this.consumerToJobMap.remove(parama);
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void addWindowLayoutInfoListener(Activity paramActivity, Executor paramExecutor, a<WindowLayoutInfo> parama) {
    l.f(paramActivity, "activity");
    l.f(paramExecutor, "executor");
    l.f(parama, "consumer");
    addListener(paramExecutor, parama, this.tracker.windowLayoutInfo(paramActivity));
  }
  
  public final void removeWindowLayoutInfoListener(a<WindowLayoutInfo> parama) {
    l.f(parama, "consumer");
    removeListener(parama);
  }
  
  public b<WindowLayoutInfo> windowLayoutInfo(Activity paramActivity) {
    l.f(paramActivity, "activity");
    return this.tracker.windowLayoutInfo(paramActivity);
  }
  
  @f(c = "androidx.window.java.layout.WindowInfoTrackerCallbackAdapter$addListener$1$1", f = "WindowInfoTrackerCallbackAdapter.kt", l = {96}, m = "invokeSuspend")
  static final class WindowInfoTrackerCallbackAdapter$addListener$1$1 extends l implements p<p0, d<? super u>, Object> {
    int label;
    
    WindowInfoTrackerCallbackAdapter$addListener$1$1(b<? extends T> param1b, a<T> param1a, d<? super WindowInfoTrackerCallbackAdapter$addListener$1$1> param1d) {
      super(2, param1d);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      return (d<u>)new WindowInfoTrackerCallbackAdapter$addListener$1$1(this.$flow, this.$consumer, (d)param1d);
    }
    
    public final Object invoke(p0 param1p0, d<? super u> param1d) {
      return ((WindowInfoTrackerCallbackAdapter$addListener$1$1)create(param1p0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object<T> param1Object) {
      Object object = b.c();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          o.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        o.b(param1Object);
        param1Object = (Object<T>)this.$flow;
        WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 = new WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(this.$consumer);
        this.label = 1;
        if (param1Object.a(windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1, (d)this) == object)
          return object; 
      } 
      return u.a;
    }
    
    public static final class WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 implements c<T> {
      public WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(a param1a) {}
      
      public Object emit(T param1T, d<? super u> param1d) {
        this.$consumer$inlined.accept(param1T);
        return u.a;
      }
    }
  }
  
  public static final class WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 implements c<T> {
    public WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(a param1a) {}
    
    public Object emit(T param1T, d<? super u> param1d) {
      this.$consumer$inlined.accept(param1T);
      return u.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\java\layout\WindowInfoTrackerCallbackAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */