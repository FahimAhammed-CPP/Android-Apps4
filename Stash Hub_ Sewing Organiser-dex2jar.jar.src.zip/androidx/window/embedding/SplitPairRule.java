package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import p7.m;

@ExperimentalWindowApi
public final class SplitPairRule extends SplitRule {
  private final boolean clearTop;
  
  private final Set<SplitPairFilter> filters;
  
  private final boolean finishPrimaryWithSecondary;
  
  private final boolean finishSecondaryWithPrimary;
  
  public SplitPairRule(Set<SplitPairFilter> paramSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    super(paramInt1, paramInt2, paramFloat, paramInt3);
    this.finishPrimaryWithSecondary = paramBoolean1;
    this.finishSecondaryWithPrimary = paramBoolean2;
    this.clearTop = paramBoolean3;
    this.filters = m.Q(paramSet);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SplitPairRule))
      return false; 
    if (!super.equals(paramObject))
      return false; 
    Set<SplitPairFilter> set = this.filters;
    paramObject = paramObject;
    return !l.b(set, ((SplitPairRule)paramObject).filters) ? false : ((this.finishPrimaryWithSecondary != ((SplitPairRule)paramObject).finishPrimaryWithSecondary) ? false : ((this.finishSecondaryWithPrimary != ((SplitPairRule)paramObject).finishSecondaryWithPrimary) ? false : (!(this.clearTop != ((SplitPairRule)paramObject).clearTop))));
  }
  
  public final boolean getClearTop() {
    return this.clearTop;
  }
  
  public final Set<SplitPairFilter> getFilters() {
    return this.filters;
  }
  
  public final boolean getFinishPrimaryWithSecondary() {
    return this.finishPrimaryWithSecondary;
  }
  
  public final boolean getFinishSecondaryWithPrimary() {
    return this.finishSecondaryWithPrimary;
  }
  
  public int hashCode() {
    return (((super.hashCode() * 31 + this.filters.hashCode()) * 31 + a.a(this.finishPrimaryWithSecondary)) * 31 + a.a(this.finishSecondaryWithPrimary)) * 31 + a.a(this.clearTop);
  }
  
  public final SplitPairRule plus$window_release(SplitPairFilter paramSplitPairFilter) {
    l.f(paramSplitPairFilter, "filter");
    LinkedHashSet<SplitPairFilter> linkedHashSet = new LinkedHashSet();
    linkedHashSet.addAll(this.filters);
    linkedHashSet.add(paramSplitPairFilter);
    return new SplitPairRule(m.Q(linkedHashSet), this.finishPrimaryWithSecondary, this.finishSecondaryWithPrimary, this.clearTop, getMinWidth(), getMinSmallestWidth(), getSplitRatio(), getLayoutDirection());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitPairRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */