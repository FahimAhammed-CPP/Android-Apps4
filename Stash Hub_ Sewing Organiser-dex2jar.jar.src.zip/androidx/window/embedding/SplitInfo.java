package androidx.window.embedding;

import android.app.Activity;
import androidx.window.core.ExperimentalWindowApi;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class SplitInfo {
  private final ActivityStack primaryActivityStack;
  
  private final ActivityStack secondaryActivityStack;
  
  private final float splitRatio;
  
  public SplitInfo(ActivityStack paramActivityStack1, ActivityStack paramActivityStack2, float paramFloat) {
    this.primaryActivityStack = paramActivityStack1;
    this.secondaryActivityStack = paramActivityStack2;
    this.splitRatio = paramFloat;
  }
  
  public final boolean contains(Activity paramActivity) {
    l.f(paramActivity, "activity");
    return (this.primaryActivityStack.contains(paramActivity) || this.secondaryActivityStack.contains(paramActivity));
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SplitInfo))
      return false; 
    ActivityStack activityStack = this.primaryActivityStack;
    paramObject = paramObject;
    if (!l.b(activityStack, ((SplitInfo)paramObject).primaryActivityStack))
      return false; 
    if (!l.b(this.secondaryActivityStack, ((SplitInfo)paramObject).secondaryActivityStack))
      return false; 
    if (this.splitRatio == ((SplitInfo)paramObject).splitRatio) {
      bool = true;
    } else {
      bool = false;
    } 
    return !!bool;
  }
  
  public final ActivityStack getPrimaryActivityStack() {
    return this.primaryActivityStack;
  }
  
  public final ActivityStack getSecondaryActivityStack() {
    return this.secondaryActivityStack;
  }
  
  public final float getSplitRatio() {
    return this.splitRatio;
  }
  
  public int hashCode() {
    return (this.primaryActivityStack.hashCode() * 31 + this.secondaryActivityStack.hashCode()) * 31 + Float.floatToIntBits(this.splitRatio);
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("SplitInfo:{");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("primaryActivityStack=");
    stringBuilder2.append(getPrimaryActivityStack());
    stringBuilder2.append(',');
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("secondaryActivityStack=");
    stringBuilder2.append(getSecondaryActivityStack());
    stringBuilder2.append(',');
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("splitRatio=");
    stringBuilder2.append(getSplitRatio());
    stringBuilder2.append('}');
    stringBuilder1.append(stringBuilder2.toString());
    String str = stringBuilder1.toString();
    l.e(str, "StringBuilder().apply(builderAction).toString()");
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */