package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import p7.m;

@ExperimentalWindowApi
public final class ActivityRule extends EmbeddingRule {
  private final boolean alwaysExpand;
  
  private final Set<ActivityFilter> filters;
  
  public ActivityRule(Set<ActivityFilter> paramSet, boolean paramBoolean) {
    this.alwaysExpand = paramBoolean;
    this.filters = m.Q(paramSet);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ActivityRule))
      return false; 
    Set<ActivityFilter> set = this.filters;
    paramObject = paramObject;
    return !l.b(set, ((ActivityRule)paramObject).filters) ? false : (!(this.alwaysExpand != ((ActivityRule)paramObject).alwaysExpand));
  }
  
  public final boolean getAlwaysExpand() {
    return this.alwaysExpand;
  }
  
  public final Set<ActivityFilter> getFilters() {
    return this.filters;
  }
  
  public int hashCode() {
    return this.filters.hashCode() * 31 + a.a(this.alwaysExpand);
  }
  
  public final ActivityRule plus$window_release(ActivityFilter paramActivityFilter) {
    l.f(paramActivityFilter, "filter");
    LinkedHashSet<ActivityFilter> linkedHashSet = new LinkedHashSet();
    linkedHashSet.addAll(this.filters);
    linkedHashSet.add(paramActivityFilter);
    return new ActivityRule(m.Q(linkedHashSet), this.alwaysExpand);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\ActivityRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */