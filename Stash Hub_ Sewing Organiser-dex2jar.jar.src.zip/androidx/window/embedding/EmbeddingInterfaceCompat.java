package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;
import java.util.List;
import java.util.Set;

@ExperimentalWindowApi
public interface EmbeddingInterfaceCompat {
  void setEmbeddingCallback(EmbeddingCallbackInterface paramEmbeddingCallbackInterface);
  
  void setSplitRules(Set<? extends EmbeddingRule> paramSet);
  
  public static interface EmbeddingCallbackInterface {
    void onSplitInfoChanged(List<SplitInfo> param1List);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingInterfaceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */