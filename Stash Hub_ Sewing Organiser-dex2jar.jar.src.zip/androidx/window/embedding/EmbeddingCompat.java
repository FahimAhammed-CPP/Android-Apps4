package androidx.window.embedding;

import android.util.Log;
import androidx.window.core.ExperimentalWindowApi;
import androidx.window.extensions.WindowExtensionsProvider;
import androidx.window.extensions.embedding.ActivityEmbeddingComponent;
import java.util.Set;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class EmbeddingCompat implements EmbeddingInterfaceCompat {
  public static final Companion Companion = new Companion(null);
  
  public static final boolean DEBUG = true;
  
  private static final String TAG = "EmbeddingCompat";
  
  private final EmbeddingAdapter adapter;
  
  private final ActivityEmbeddingComponent embeddingExtension;
  
  public EmbeddingCompat() {
    this(Companion.embeddingComponent(), new EmbeddingAdapter());
  }
  
  public EmbeddingCompat(ActivityEmbeddingComponent paramActivityEmbeddingComponent, EmbeddingAdapter paramEmbeddingAdapter) {
    this.embeddingExtension = paramActivityEmbeddingComponent;
    this.adapter = paramEmbeddingAdapter;
  }
  
  public void setEmbeddingCallback(EmbeddingInterfaceCompat.EmbeddingCallbackInterface paramEmbeddingCallbackInterface) {
    l.f(paramEmbeddingCallbackInterface, "embeddingCallback");
    EmbeddingTranslatingCallback embeddingTranslatingCallback = new EmbeddingTranslatingCallback(paramEmbeddingCallbackInterface, this.adapter);
    this.embeddingExtension.setSplitInfoCallback(embeddingTranslatingCallback);
  }
  
  public void setSplitRules(Set<? extends EmbeddingRule> paramSet) {
    l.f(paramSet, "rules");
    this.embeddingExtension.setEmbeddingRules(this.adapter.translate(paramSet));
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final ActivityEmbeddingComponent embeddingComponent() {
      if (isEmbeddingAvailable()) {
        ActivityEmbeddingComponent activityEmbeddingComponent = WindowExtensionsProvider.getWindowExtensions().getActivityEmbeddingComponent();
        null = activityEmbeddingComponent;
        if (activityEmbeddingComponent == null) {
          null = new EmptyEmbeddingComponent();
        } else {
          return null;
        } 
      } else {
        null = new EmptyEmbeddingComponent();
      } 
      return null;
    }
    
    public final Integer getExtensionApiLevel() {
      String str;
      try {
        int i = WindowExtensionsProvider.getWindowExtensions().getVendorApiLevel();
        return Integer.valueOf(i);
      } catch (NoClassDefFoundError noClassDefFoundError) {
        str = "Embedding extension version not found";
      } catch (UnsupportedOperationException unsupportedOperationException) {
        str = "Stub Extension";
      } 
      Log.d("EmbeddingCompat", str);
      return null;
    }
    
    public final boolean isEmbeddingAvailable() {
      String str;
      try {
        ActivityEmbeddingComponent activityEmbeddingComponent = WindowExtensionsProvider.getWindowExtensions().getActivityEmbeddingComponent();
        return (activityEmbeddingComponent != null);
      } catch (NoClassDefFoundError noClassDefFoundError) {
        str = "Embedding extension version not found";
      } catch (UnsupportedOperationException unsupportedOperationException) {
        str = "Stub Extension";
      } 
      Log.d("EmbeddingCompat", str);
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */