package androidx.window.embedding;

import android.app.Activity;
import android.content.Context;
import androidx.core.util.a;
import androidx.window.core.ExperimentalWindowApi;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import o7.u;
import p7.k0;
import p7.m;

@ExperimentalWindowApi
public final class SplitController {
  public static final Companion Companion = new Companion(null);
  
  private static volatile SplitController globalInstance;
  
  private static final ReentrantLock globalLock = new ReentrantLock();
  
  public static final boolean sDebug = false;
  
  private final EmbeddingBackend embeddingBackend = ExtensionEmbeddingBackend.Companion.getInstance();
  
  private Set<? extends EmbeddingRule> staticSplitRules = k0.b();
  
  private SplitController() {}
  
  public static final SplitController getInstance() {
    return Companion.getInstance();
  }
  
  public static final void initialize(Context paramContext, int paramInt) {
    Companion.initialize(paramContext, paramInt);
  }
  
  private final void setStaticSplitRules(Set<? extends EmbeddingRule> paramSet) {
    this.staticSplitRules = paramSet;
    this.embeddingBackend.setSplitRules(paramSet);
  }
  
  public final void addSplitListener(Activity paramActivity, Executor paramExecutor, a<List<SplitInfo>> parama) {
    l.f(paramActivity, "activity");
    l.f(paramExecutor, "executor");
    l.f(parama, "consumer");
    this.embeddingBackend.registerSplitListenerForActivity(paramActivity, paramExecutor, parama);
  }
  
  public final void clearRegisteredRules() {
    this.embeddingBackend.setSplitRules(this.staticSplitRules);
  }
  
  public final Set<EmbeddingRule> getSplitRules() {
    return m.Q(this.embeddingBackend.getSplitRules());
  }
  
  public final boolean isSplitSupported() {
    return this.embeddingBackend.isSplitSupported();
  }
  
  public final void registerRule(EmbeddingRule paramEmbeddingRule) {
    l.f(paramEmbeddingRule, "rule");
    this.embeddingBackend.registerRule(paramEmbeddingRule);
  }
  
  public final void removeSplitListener(a<List<SplitInfo>> parama) {
    l.f(parama, "consumer");
    this.embeddingBackend.unregisterSplitListenerForActivity(parama);
  }
  
  public final void unregisterRule(EmbeddingRule paramEmbeddingRule) {
    l.f(paramEmbeddingRule, "rule");
    this.embeddingBackend.unregisterRule(paramEmbeddingRule);
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final SplitController getInstance() {
      if (SplitController.globalInstance == null) {
        ReentrantLock reentrantLock = SplitController.globalLock;
        reentrantLock.lock();
        try {
          if (SplitController.globalInstance == null) {
            Companion companion = SplitController.Companion;
            SplitController.globalInstance = new SplitController(null);
          } 
          u u = u.a;
        } finally {
          reentrantLock.unlock();
        } 
      } 
      SplitController splitController = SplitController.globalInstance;
      l.c(splitController);
      return splitController;
    }
    
    public final void initialize(Context param1Context, int param1Int) {
      l.f(param1Context, "context");
      Set<EmbeddingRule> set2 = (new SplitRuleParser()).parseSplitRules$window_release(param1Context, param1Int);
      SplitController splitController = getInstance();
      Set<EmbeddingRule> set1 = set2;
      if (set2 == null)
        set1 = k0.b(); 
      splitController.setStaticSplitRules(set1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */