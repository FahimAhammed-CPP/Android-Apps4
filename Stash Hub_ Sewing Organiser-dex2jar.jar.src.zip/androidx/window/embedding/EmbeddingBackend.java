package androidx.window.embedding;

import android.app.Activity;
import androidx.core.util.a;
import androidx.window.core.ExperimentalWindowApi;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

@ExperimentalWindowApi
public interface EmbeddingBackend {
  Set<EmbeddingRule> getSplitRules();
  
  boolean isSplitSupported();
  
  void registerRule(EmbeddingRule paramEmbeddingRule);
  
  void registerSplitListenerForActivity(Activity paramActivity, Executor paramExecutor, a<List<SplitInfo>> parama);
  
  void setSplitRules(Set<? extends EmbeddingRule> paramSet);
  
  void unregisterRule(EmbeddingRule paramEmbeddingRule);
  
  void unregisterSplitListenerForActivity(a<List<SplitInfo>> parama);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */