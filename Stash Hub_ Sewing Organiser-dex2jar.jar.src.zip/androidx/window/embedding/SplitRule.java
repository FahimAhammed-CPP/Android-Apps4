package androidx.window.embedding;

import android.graphics.Rect;
import android.os.Build;
import android.view.WindowMetrics;
import androidx.window.core.ExperimentalWindowApi;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public class SplitRule extends EmbeddingRule {
  private final int layoutDirection;
  
  private final int minSmallestWidth;
  
  private final int minWidth;
  
  private final float splitRatio;
  
  public SplitRule() {
    this(0, 0, 0.0F, 0, 15, null);
  }
  
  public SplitRule(int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    this.minWidth = paramInt1;
    this.minSmallestWidth = paramInt2;
    this.splitRatio = paramFloat;
    this.layoutDirection = paramInt3;
  }
  
  public final boolean checkParentMetrics(WindowMetrics paramWindowMetrics) {
    boolean bool1;
    l.f(paramWindowMetrics, "parentMetrics");
    int i = Build.VERSION.SDK_INT;
    boolean bool3 = false;
    if (i <= 30)
      return false; 
    Rect rect = Api30Impl.INSTANCE.getBounds(paramWindowMetrics);
    if (this.minWidth == 0 || rect.width() >= this.minWidth) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.minSmallestWidth == 0 || Math.min(rect.width(), rect.height()) >= this.minSmallestWidth) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    boolean bool2 = bool3;
    if (i != 0) {
      bool2 = bool3;
      if (bool1)
        bool2 = true; 
    } 
    return bool2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SplitRule))
      return false; 
    int i = this.minWidth;
    paramObject = paramObject;
    if (i != ((SplitRule)paramObject).minWidth)
      return false; 
    if (this.minSmallestWidth != ((SplitRule)paramObject).minSmallestWidth)
      return false; 
    if (this.splitRatio == ((SplitRule)paramObject).splitRatio) {
      i = 1;
    } else {
      i = 0;
    } 
    return (i == 0) ? false : (!(this.layoutDirection != ((SplitRule)paramObject).layoutDirection));
  }
  
  public final int getLayoutDirection() {
    return this.layoutDirection;
  }
  
  public final int getMinSmallestWidth() {
    return this.minSmallestWidth;
  }
  
  public final int getMinWidth() {
    return this.minWidth;
  }
  
  public final float getSplitRatio() {
    return this.splitRatio;
  }
  
  public int hashCode() {
    return ((this.minWidth * 31 + this.minSmallestWidth) * 31 + Float.floatToIntBits(this.splitRatio)) * 31 + this.layoutDirection;
  }
  
  public static final class Api30Impl {
    public static final Api30Impl INSTANCE = new Api30Impl();
    
    public final Rect getBounds(WindowMetrics param1WindowMetrics) {
      l.f(param1WindowMetrics, "windowMetrics");
      Rect rect = param1WindowMetrics.getBounds();
      l.e(rect, "windowMetrics.bounds");
      return rect;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface LayoutDir {}
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */