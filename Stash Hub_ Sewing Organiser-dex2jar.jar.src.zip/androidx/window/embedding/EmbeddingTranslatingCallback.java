package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;
import androidx.window.extensions.embedding.SplitInfo;
import java.util.List;
import java.util.function.Consumer;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class EmbeddingTranslatingCallback implements Consumer<List<? extends SplitInfo>> {
  private final EmbeddingAdapter adapter;
  
  private final EmbeddingInterfaceCompat.EmbeddingCallbackInterface callback;
  
  public EmbeddingTranslatingCallback(EmbeddingInterfaceCompat.EmbeddingCallbackInterface paramEmbeddingCallbackInterface, EmbeddingAdapter paramEmbeddingAdapter) {
    this.callback = paramEmbeddingCallbackInterface;
    this.adapter = paramEmbeddingAdapter;
  }
  
  public void accept(List<? extends SplitInfo> paramList) {
    l.f(paramList, "splitInfoList");
    this.callback.onSplitInfoChanged(this.adapter.translate(paramList));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingTranslatingCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */