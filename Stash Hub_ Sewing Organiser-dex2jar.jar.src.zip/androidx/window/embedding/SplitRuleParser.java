package androidx.window.embedding;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import androidx.window.R;
import androidx.window.core.ExperimentalWindowApi;
import f8.f;
import java.util.HashSet;
import java.util.Set;
import kotlin.jvm.internal.l;
import p7.k0;

@ExperimentalWindowApi
public final class SplitRuleParser {
  private final ComponentName buildClassName(String paramString, CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      int i;
      if (paramCharSequence.length() == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (!i) {
        String str = paramCharSequence.toString();
        if (str.charAt(0) == '.')
          return new ComponentName(paramString, l.m(paramString, str)); 
        i = f.C(str, '/', 0, false, 6, null);
        paramCharSequence = paramString;
        paramString = str;
        if (i > 0) {
          paramCharSequence = str.substring(0, i);
          l.e(paramCharSequence, "(this as java.lang.Strin…ing(startIndex, endIndex)");
          paramString = str.substring(i + 1);
          l.e(paramString, "(this as java.lang.String).substring(startIndex)");
        } 
        if (!l.b(paramString, "*") && f.C(paramString, '.', 0, false, 6, null) < 0) {
          StringBuilder stringBuilder = new StringBuilder((String)paramCharSequence);
          stringBuilder.append('.');
          stringBuilder.append(paramString);
          return new ComponentName((String)paramCharSequence, stringBuilder.toString());
        } 
        return new ComponentName((String)paramCharSequence, paramString);
      } 
    } 
    throw new IllegalArgumentException("Activity name must not be null");
  }
  
  private final ActivityFilter parseActivityFilter(Context paramContext, XmlResourceParser paramXmlResourceParser) {
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes((AttributeSet)paramXmlResourceParser, R.styleable.ActivityFilter, 0, 0);
    String str2 = typedArray.getString(R.styleable.ActivityFilter_activityName);
    String str3 = typedArray.getString(R.styleable.ActivityFilter_activityAction);
    String str1 = paramContext.getApplicationContext().getPackageName();
    l.e(str1, "packageName");
    return new ActivityFilter(buildClassName(str1, str2), str3);
  }
  
  private final ActivityRule parseSplitActivityRule(Context paramContext, XmlResourceParser paramXmlResourceParser) {
    boolean bool = paramContext.getTheme().obtainStyledAttributes((AttributeSet)paramXmlResourceParser, R.styleable.ActivityRule, 0, 0).getBoolean(R.styleable.ActivityRule_alwaysExpand, false);
    return new ActivityRule(k0.b(), bool);
  }
  
  private final SplitPairFilter parseSplitPairFilter(Context paramContext, XmlResourceParser paramXmlResourceParser) {
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes((AttributeSet)paramXmlResourceParser, R.styleable.SplitPairFilter, 0, 0);
    String str2 = typedArray.getString(R.styleable.SplitPairFilter_primaryActivityName);
    String str3 = typedArray.getString(R.styleable.SplitPairFilter_secondaryActivityName);
    String str4 = typedArray.getString(R.styleable.SplitPairFilter_secondaryActivityAction);
    String str1 = paramContext.getApplicationContext().getPackageName();
    l.e(str1, "packageName");
    return new SplitPairFilter(buildClassName(str1, str2), buildClassName(str1, str3), str4);
  }
  
  private final SplitPairRule parseSplitPairRule(Context paramContext, XmlResourceParser paramXmlResourceParser) {
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes((AttributeSet)paramXmlResourceParser, R.styleable.SplitPairRule, 0, 0);
    float f = typedArray.getFloat(R.styleable.SplitPairRule_splitRatio, 0.0F);
    int i = (int)typedArray.getDimension(R.styleable.SplitPairRule_splitMinWidth, 0.0F);
    int j = (int)typedArray.getDimension(R.styleable.SplitPairRule_splitMinSmallestWidth, 0.0F);
    int k = typedArray.getInt(R.styleable.SplitPairRule_splitLayoutDirection, 3);
    boolean bool1 = typedArray.getBoolean(R.styleable.SplitPairRule_finishPrimaryWithSecondary, false);
    boolean bool2 = typedArray.getBoolean(R.styleable.SplitPairRule_finishSecondaryWithPrimary, true);
    boolean bool3 = typedArray.getBoolean(R.styleable.SplitPairRule_clearTop, false);
    return new SplitPairRule(k0.b(), bool1, bool2, bool3, i, j, f, k);
  }
  
  private final SplitPlaceholderRule parseSplitPlaceholderRule(Context paramContext, XmlResourceParser paramXmlResourceParser) {
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes((AttributeSet)paramXmlResourceParser, R.styleable.SplitPlaceholderRule, 0, 0);
    String str2 = typedArray.getString(R.styleable.SplitPlaceholderRule_placeholderActivityName);
    float f = typedArray.getFloat(R.styleable.SplitPlaceholderRule_splitRatio, 0.0F);
    int i = (int)typedArray.getDimension(R.styleable.SplitPlaceholderRule_splitMinWidth, 0.0F);
    int j = (int)typedArray.getDimension(R.styleable.SplitPlaceholderRule_splitMinSmallestWidth, 0.0F);
    int k = typedArray.getInt(R.styleable.SplitPlaceholderRule_splitLayoutDirection, 3);
    String str1 = paramContext.getApplicationContext().getPackageName();
    l.e(str1, "packageName");
    ComponentName componentName = buildClassName(str1, str2);
    Set<ActivityFilter> set = k0.b();
    Intent intent = (new Intent()).setComponent(componentName);
    l.e(intent, "Intent().setComponent(pl…eholderActivityClassName)");
    return new SplitPlaceholderRule(set, intent, i, j, f, k);
  }
  
  private final Set<EmbeddingRule> parseSplitXml(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    try {
      XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
      l.e(xmlResourceParser, "resources.getXml(splitResourceId)");
      HashSet<SplitPlaceholderRule> hashSet = new HashSet();
      int i = xmlResourceParser.getDepth();
      paramInt = xmlResourceParser.next();
      Resources resources2 = null;
      Resources resources1 = resources2;
      resources = resources1;
      while (paramInt != 1 && (paramInt != 3 || xmlResourceParser.getDepth() > i)) {
        SplitPairRule splitPairRule2;
        SplitPlaceholderRule splitPlaceholderRule2;
        Resources resources3 = resources2;
        Resources resources4 = resources1;
        Resources resources5 = resources;
        if (xmlResourceParser.getEventType() == 2)
          if (l.b("split-config", xmlResourceParser.getName())) {
            resources3 = resources2;
            resources4 = resources1;
            resources5 = resources;
          } else {
            String str = xmlResourceParser.getName();
            resources3 = resources2;
            resources4 = resources1;
            resources5 = resources;
            if (str != null) {
              SplitPlaceholderRule splitPlaceholderRule4;
              Resources resources6;
              ActivityRule activityRule1;
              SplitPlaceholderRule splitPlaceholderRule3;
              SplitPairRule splitPairRule;
              ActivityRule activityRule2;
              SplitPlaceholderRule splitPlaceholderRule5;
              Resources resources7;
              ActivityRule activityRule3;
              switch (str.hashCode()) {
                default:
                  resources3 = resources2;
                  resources4 = resources1;
                  resources5 = resources;
                  break;
                case 2050988213:
                  if (!str.equals("SplitPlaceholderRule")) {
                    resources3 = resources2;
                    resources4 = resources1;
                    resources5 = resources;
                    break;
                  } 
                  splitPlaceholderRule4 = parseSplitPlaceholderRule(paramContext, xmlResourceParser);
                  hashSet.add(splitPlaceholderRule4);
                  resources3 = null;
                  resources1 = resources3;
                  resources4 = resources1;
                  splitPlaceholderRule5 = splitPlaceholderRule4;
                case 1793077963:
                  if (!str.equals("ActivityRule")) {
                    resources3 = resources2;
                    resources4 = resources1;
                    splitPlaceholderRule5 = splitPlaceholderRule4;
                    break;
                  } 
                  activityRule2 = parseSplitActivityRule(paramContext, xmlResourceParser);
                  hashSet.add(activityRule2);
                  resources1 = null;
                  resources6 = resources1;
                  resources4 = resources1;
                  resources7 = resources6;
                  break;
                case 1579230604:
                  if (!str.equals("SplitPairFilter")) {
                    Resources resources8 = resources2;
                    resources4 = resources1;
                    resources7 = resources6;
                    break;
                  } 
                  if (resources1 != null) {
                    SplitPairFilter splitPairFilter = parseSplitPairFilter(paramContext, xmlResourceParser);
                    hashSet.remove(resources1);
                    splitPairRule = resources1.plus$window_release(splitPairFilter);
                    hashSet.add(splitPairRule);
                    Resources resources8 = resources2;
                  } else {
                    throw new IllegalArgumentException("Found orphaned SplitPairFilter outside of SplitPairRule");
                  } 
                  splitPairRule2 = splitPairRule;
                  resources7 = resources6;
                  break;
                case 520447504:
                  if (!str.equals("SplitPairRule")) {
                    Resources resources8 = resources2;
                    splitPairRule2 = splitPairRule;
                    resources7 = resources6;
                    break;
                  } 
                  splitPairRule = parseSplitPairRule(paramContext, xmlResourceParser);
                  hashSet.add(splitPairRule);
                  activityRule2 = null;
                  activityRule1 = activityRule2;
                  splitPairRule2 = splitPairRule;
                  activityRule3 = activityRule1;
                  break;
                case 511422343:
                  if (!str.equals("ActivityFilter")) {
                    Resources resources8 = resources2;
                    splitPairRule2 = splitPairRule;
                    activityRule3 = activityRule1;
                    break;
                  } 
                  if (resources2 != null || activityRule1 != null) {
                    ActivityFilter activityFilter = parseActivityFilter(paramContext, xmlResourceParser);
                    if (resources2 != null) {
                      hashSet.remove(resources2);
                      activityRule2 = resources2.plus$window_release(activityFilter);
                      hashSet.add(activityRule2);
                    } else {
                      resources3 = resources2;
                      splitPairRule2 = splitPairRule;
                      activityRule3 = activityRule1;
                      if (activityRule1 != null) {
                        hashSet.remove(activityRule1);
                        splitPlaceholderRule3 = activityRule1.plus$window_release(activityFilter);
                        hashSet.add(splitPlaceholderRule3);
                        resources3 = resources2;
                      } else {
                        break;
                      } 
                      splitPairRule2 = splitPairRule;
                      SplitPlaceholderRule splitPlaceholderRule = splitPlaceholderRule3;
                    } 
                  } else {
                    throw new IllegalArgumentException("Found orphaned ActivityFilter");
                  } 
                  splitPairRule2 = splitPairRule;
                  splitPlaceholderRule2 = splitPlaceholderRule3;
                  break;
              } 
            } 
          }  
        paramInt = xmlResourceParser.next();
        resources2 = resources3;
        SplitPairRule splitPairRule1 = splitPairRule2;
        SplitPlaceholderRule splitPlaceholderRule1 = splitPlaceholderRule2;
      } 
      return (Set)hashSet;
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      return null;
    } 
  }
  
  public final Set<EmbeddingRule> parseSplitRules$window_release(Context paramContext, int paramInt) {
    l.f(paramContext, "context");
    return parseSplitXml(paramContext, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitRuleParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */