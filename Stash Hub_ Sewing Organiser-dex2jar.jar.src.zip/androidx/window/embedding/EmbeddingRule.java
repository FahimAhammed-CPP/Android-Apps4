package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;

@ExperimentalWindowApi
public abstract class EmbeddingRule {}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */