package androidx.window.embedding;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import androidx.window.core.ExperimentalWindowApi;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class SplitPairFilter {
  private final ComponentName primaryActivityName;
  
  private final String secondaryActivityIntentAction;
  
  private final ComponentName secondaryActivityName;
  
  public SplitPairFilter(ComponentName paramComponentName1, ComponentName paramComponentName2, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'primaryActivityName'
    //   3: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc 'secondaryActivityName'
    //   9: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_0
    //   13: invokespecial <init> : ()V
    //   16: aload_0
    //   17: aload_1
    //   18: putfield primaryActivityName : Landroid/content/ComponentName;
    //   21: aload_0
    //   22: aload_2
    //   23: putfield secondaryActivityName : Landroid/content/ComponentName;
    //   26: aload_0
    //   27: aload_3
    //   28: putfield secondaryActivityIntentAction : Ljava/lang/String;
    //   31: aload_1
    //   32: invokevirtual getPackageName : ()Ljava/lang/String;
    //   35: astore_3
    //   36: aload_3
    //   37: ldc 'primaryActivityName.packageName'
    //   39: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   42: aload_1
    //   43: invokevirtual getClassName : ()Ljava/lang/String;
    //   46: astore #7
    //   48: aload #7
    //   50: ldc 'primaryActivityName.className'
    //   52: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   55: aload_2
    //   56: invokevirtual getPackageName : ()Ljava/lang/String;
    //   59: astore #6
    //   61: aload #6
    //   63: ldc 'secondaryActivityName.packageName'
    //   65: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   68: aload_2
    //   69: invokevirtual getClassName : ()Ljava/lang/String;
    //   72: astore_1
    //   73: aload_1
    //   74: ldc 'secondaryActivityName.className'
    //   76: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   79: aload_3
    //   80: invokeinterface length : ()I
    //   85: istore #4
    //   87: iconst_1
    //   88: istore #5
    //   90: iload #4
    //   92: ifne -> 101
    //   95: iconst_1
    //   96: istore #4
    //   98: goto -> 104
    //   101: iconst_0
    //   102: istore #4
    //   104: iload #4
    //   106: ifne -> 139
    //   109: aload #6
    //   111: invokeinterface length : ()I
    //   116: ifne -> 125
    //   119: iconst_1
    //   120: istore #4
    //   122: goto -> 128
    //   125: iconst_0
    //   126: istore #4
    //   128: iload #4
    //   130: ifne -> 139
    //   133: iconst_1
    //   134: istore #4
    //   136: goto -> 142
    //   139: iconst_0
    //   140: istore #4
    //   142: iload #4
    //   144: ifeq -> 478
    //   147: aload #7
    //   149: invokeinterface length : ()I
    //   154: ifne -> 163
    //   157: iconst_1
    //   158: istore #4
    //   160: goto -> 166
    //   163: iconst_0
    //   164: istore #4
    //   166: iload #4
    //   168: ifne -> 200
    //   171: aload_1
    //   172: invokeinterface length : ()I
    //   177: ifne -> 186
    //   180: iconst_1
    //   181: istore #4
    //   183: goto -> 189
    //   186: iconst_0
    //   187: istore #4
    //   189: iload #4
    //   191: ifne -> 200
    //   194: iconst_1
    //   195: istore #4
    //   197: goto -> 203
    //   200: iconst_0
    //   201: istore #4
    //   203: iload #4
    //   205: ifeq -> 465
    //   208: aload_3
    //   209: ldc '*'
    //   211: iconst_0
    //   212: iconst_2
    //   213: aconst_null
    //   214: invokestatic u : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   217: ifeq -> 249
    //   220: aload_3
    //   221: ldc '*'
    //   223: iconst_0
    //   224: iconst_0
    //   225: bipush #6
    //   227: aconst_null
    //   228: invokestatic D : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   231: aload_3
    //   232: invokevirtual length : ()I
    //   235: iconst_1
    //   236: isub
    //   237: if_icmpne -> 243
    //   240: goto -> 249
    //   243: iconst_0
    //   244: istore #4
    //   246: goto -> 252
    //   249: iconst_1
    //   250: istore #4
    //   252: iload #4
    //   254: ifeq -> 452
    //   257: aload #7
    //   259: ldc '*'
    //   261: iconst_0
    //   262: iconst_2
    //   263: aconst_null
    //   264: invokestatic u : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   267: ifeq -> 301
    //   270: aload #7
    //   272: ldc '*'
    //   274: iconst_0
    //   275: iconst_0
    //   276: bipush #6
    //   278: aconst_null
    //   279: invokestatic D : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   282: aload #7
    //   284: invokevirtual length : ()I
    //   287: iconst_1
    //   288: isub
    //   289: if_icmpne -> 295
    //   292: goto -> 301
    //   295: iconst_0
    //   296: istore #4
    //   298: goto -> 304
    //   301: iconst_1
    //   302: istore #4
    //   304: iload #4
    //   306: ifeq -> 439
    //   309: aload #6
    //   311: ldc '*'
    //   313: iconst_0
    //   314: iconst_2
    //   315: aconst_null
    //   316: invokestatic u : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   319: ifeq -> 353
    //   322: aload #6
    //   324: ldc '*'
    //   326: iconst_0
    //   327: iconst_0
    //   328: bipush #6
    //   330: aconst_null
    //   331: invokestatic D : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   334: aload #6
    //   336: invokevirtual length : ()I
    //   339: iconst_1
    //   340: isub
    //   341: if_icmpne -> 347
    //   344: goto -> 353
    //   347: iconst_0
    //   348: istore #4
    //   350: goto -> 356
    //   353: iconst_1
    //   354: istore #4
    //   356: iload #4
    //   358: ifeq -> 426
    //   361: iload #5
    //   363: istore #4
    //   365: aload_1
    //   366: ldc '*'
    //   368: iconst_0
    //   369: iconst_2
    //   370: aconst_null
    //   371: invokestatic u : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   374: ifeq -> 407
    //   377: aload_1
    //   378: ldc '*'
    //   380: iconst_0
    //   381: iconst_0
    //   382: bipush #6
    //   384: aconst_null
    //   385: invokestatic D : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   388: aload_1
    //   389: invokevirtual length : ()I
    //   392: iconst_1
    //   393: isub
    //   394: if_icmpne -> 404
    //   397: iload #5
    //   399: istore #4
    //   401: goto -> 407
    //   404: iconst_0
    //   405: istore #4
    //   407: iload #4
    //   409: ifeq -> 413
    //   412: return
    //   413: new java/lang/IllegalArgumentException
    //   416: dup
    //   417: ldc 'Wildcard in class name is only allowed at the end.'
    //   419: invokevirtual toString : ()Ljava/lang/String;
    //   422: invokespecial <init> : (Ljava/lang/String;)V
    //   425: athrow
    //   426: new java/lang/IllegalArgumentException
    //   429: dup
    //   430: ldc 'Wildcard in package name is only allowed at the end.'
    //   432: invokevirtual toString : ()Ljava/lang/String;
    //   435: invokespecial <init> : (Ljava/lang/String;)V
    //   438: athrow
    //   439: new java/lang/IllegalArgumentException
    //   442: dup
    //   443: ldc 'Wildcard in class name is only allowed at the end.'
    //   445: invokevirtual toString : ()Ljava/lang/String;
    //   448: invokespecial <init> : (Ljava/lang/String;)V
    //   451: athrow
    //   452: new java/lang/IllegalArgumentException
    //   455: dup
    //   456: ldc 'Wildcard in package name is only allowed at the end.'
    //   458: invokevirtual toString : ()Ljava/lang/String;
    //   461: invokespecial <init> : (Ljava/lang/String;)V
    //   464: athrow
    //   465: new java/lang/IllegalArgumentException
    //   468: dup
    //   469: ldc 'Activity class name must not be empty.'
    //   471: invokevirtual toString : ()Ljava/lang/String;
    //   474: invokespecial <init> : (Ljava/lang/String;)V
    //   477: athrow
    //   478: new java/lang/IllegalArgumentException
    //   481: dup
    //   482: ldc 'Package name must not be empty'
    //   484: invokevirtual toString : ()Ljava/lang/String;
    //   487: invokespecial <init> : (Ljava/lang/String;)V
    //   490: athrow
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SplitPairFilter))
      return false; 
    ComponentName componentName = this.primaryActivityName;
    paramObject = paramObject;
    return !l.b(componentName, ((SplitPairFilter)paramObject).primaryActivityName) ? false : (!l.b(this.secondaryActivityName, ((SplitPairFilter)paramObject).secondaryActivityName) ? false : (!!l.b(this.secondaryActivityIntentAction, ((SplitPairFilter)paramObject).secondaryActivityIntentAction)));
  }
  
  public final ComponentName getPrimaryActivityName() {
    return this.primaryActivityName;
  }
  
  public final String getSecondaryActivityIntentAction() {
    return this.secondaryActivityIntentAction;
  }
  
  public final ComponentName getSecondaryActivityName() {
    return this.secondaryActivityName;
  }
  
  public int hashCode() {
    int i;
    int j = this.primaryActivityName.hashCode();
    int k = this.secondaryActivityName.hashCode();
    String str = this.secondaryActivityIntentAction;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return (j * 31 + k) * 31 + i;
  }
  
  public final boolean matchesActivityIntentPair(Activity paramActivity, Intent paramIntent) {
    l.f(paramActivity, "primaryActivity");
    l.f(paramIntent, "secondaryActivityIntent");
    ComponentName componentName = paramActivity.getComponentName();
    MatcherUtils matcherUtils = MatcherUtils.INSTANCE;
    boolean bool1 = matcherUtils.areComponentsMatching$window_release(componentName, this.primaryActivityName);
    boolean bool = false;
    if (!bool1)
      return false; 
    if (!matcherUtils.areComponentsMatching$window_release(paramIntent.getComponent(), this.secondaryActivityName))
      return false; 
    String str = this.secondaryActivityIntentAction;
    if (str == null || l.b(str, paramIntent.getAction()))
      bool = true; 
    return bool;
  }
  
  public final boolean matchesActivityPair(Activity paramActivity1, Activity paramActivity2) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'primaryActivity'
    //   3: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc 'secondaryActivity'
    //   9: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: getstatic androidx/window/embedding/MatcherUtils.INSTANCE : Landroidx/window/embedding/MatcherUtils;
    //   15: astore #6
    //   17: aload #6
    //   19: aload_1
    //   20: invokevirtual getComponentName : ()Landroid/content/ComponentName;
    //   23: aload_0
    //   24: getfield primaryActivityName : Landroid/content/ComponentName;
    //   27: invokevirtual areComponentsMatching$window_release : (Landroid/content/ComponentName;Landroid/content/ComponentName;)Z
    //   30: istore_3
    //   31: iconst_1
    //   32: istore #5
    //   34: iload_3
    //   35: ifeq -> 59
    //   38: aload #6
    //   40: aload_2
    //   41: invokevirtual getComponentName : ()Landroid/content/ComponentName;
    //   44: aload_0
    //   45: getfield secondaryActivityName : Landroid/content/ComponentName;
    //   48: invokevirtual areComponentsMatching$window_release : (Landroid/content/ComponentName;Landroid/content/ComponentName;)Z
    //   51: ifeq -> 59
    //   54: iconst_1
    //   55: istore_3
    //   56: goto -> 61
    //   59: iconst_0
    //   60: istore_3
    //   61: iload_3
    //   62: istore #4
    //   64: aload_2
    //   65: invokevirtual getIntent : ()Landroid/content/Intent;
    //   68: ifnull -> 106
    //   71: iload_3
    //   72: ifeq -> 101
    //   75: aload_2
    //   76: invokevirtual getIntent : ()Landroid/content/Intent;
    //   79: astore_2
    //   80: aload_2
    //   81: ldc 'secondaryActivity.intent'
    //   83: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   86: aload_0
    //   87: aload_1
    //   88: aload_2
    //   89: invokevirtual matchesActivityIntentPair : (Landroid/app/Activity;Landroid/content/Intent;)Z
    //   92: ifeq -> 101
    //   95: iload #5
    //   97: istore_3
    //   98: goto -> 103
    //   101: iconst_0
    //   102: istore_3
    //   103: iload_3
    //   104: istore #4
    //   106: iload #4
    //   108: ireturn
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SplitPairFilter{primaryActivityName=");
    stringBuilder.append(this.primaryActivityName);
    stringBuilder.append(", secondaryActivityName=");
    stringBuilder.append(this.secondaryActivityName);
    stringBuilder.append(", secondaryActivityAction=");
    stringBuilder.append(this.secondaryActivityIntentAction);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitPairFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */