package androidx.window.embedding;

import android.view.WindowMetrics;
import java.util.function.Predicate;



/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */