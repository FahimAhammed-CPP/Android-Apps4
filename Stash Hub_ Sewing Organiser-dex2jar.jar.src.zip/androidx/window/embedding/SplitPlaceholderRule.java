package androidx.window.embedding;

import android.content.Intent;
import androidx.window.core.ExperimentalWindowApi;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import p7.m;

@ExperimentalWindowApi
public final class SplitPlaceholderRule extends SplitRule {
  private final Set<ActivityFilter> filters;
  
  private final Intent placeholderIntent;
  
  public SplitPlaceholderRule(Set<ActivityFilter> paramSet, Intent paramIntent, int paramInt1, int paramInt2, float paramFloat, int paramInt3) {
    super(paramInt1, paramInt2, paramFloat, paramInt3);
    this.placeholderIntent = paramIntent;
    this.filters = m.Q(paramSet);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SplitPlaceholderRule))
      return false; 
    if (!super.equals(paramObject))
      return false; 
    if (!super.equals(paramObject))
      return false; 
    Set<ActivityFilter> set = this.filters;
    paramObject = paramObject;
    return !l.b(set, ((SplitPlaceholderRule)paramObject).filters) ? false : (!!l.b(this.placeholderIntent, ((SplitPlaceholderRule)paramObject).placeholderIntent));
  }
  
  public final Set<ActivityFilter> getFilters() {
    return this.filters;
  }
  
  public final Intent getPlaceholderIntent() {
    return this.placeholderIntent;
  }
  
  public int hashCode() {
    return (super.hashCode() * 31 + this.filters.hashCode()) * 31 + this.placeholderIntent.hashCode();
  }
  
  public final SplitPlaceholderRule plus$window_release(ActivityFilter paramActivityFilter) {
    l.f(paramActivityFilter, "filter");
    LinkedHashSet<ActivityFilter> linkedHashSet = new LinkedHashSet();
    linkedHashSet.addAll(this.filters);
    linkedHashSet.add(paramActivityFilter);
    return new SplitPlaceholderRule(m.Q(linkedHashSet), this.placeholderIntent, getMinWidth(), getMinSmallestWidth(), getSplitRatio(), getLayoutDirection());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\SplitPlaceholderRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */