package androidx.window.embedding;

import androidx.window.extensions.embedding.ActivityEmbeddingComponent;
import androidx.window.extensions.embedding.EmbeddingRule;
import androidx.window.extensions.embedding.SplitInfo;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import kotlin.jvm.internal.l;

final class EmptyEmbeddingComponent implements ActivityEmbeddingComponent {
  public void setEmbeddingRules(Set<EmbeddingRule> paramSet) {
    l.f(paramSet, "splitRules");
  }
  
  public void setSplitInfoCallback(Consumer<List<SplitInfo>> paramConsumer) {
    l.f(paramConsumer, "consumer");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmptyEmbeddingComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */