package androidx.window.embedding;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import androidx.window.core.ExperimentalWindowApi;
import f8.f;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class ActivityFilter {
  private final ComponentName componentName;
  
  private final String intentAction;
  
  public ActivityFilter(ComponentName paramComponentName, String paramString) {
    this.componentName = paramComponentName;
    this.intentAction = paramString;
    paramString = paramComponentName.getPackageName();
    l.e(paramString, "componentName.packageName");
    String str = paramComponentName.getClassName();
    l.e(str, "componentName.className");
    int i = paramString.length();
    boolean bool = true;
    if (i > 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      if (str.length() > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        if (!f.u(paramString, "*", false, 2, null) || f.D(paramString, "*", 0, false, 6, null) == paramString.length() - 1) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          i = bool;
          if (f.u(str, "*", false, 2, null))
            if (f.D(str, "*", 0, false, 6, null) == str.length() - 1) {
              i = bool;
            } else {
              i = 0;
            }  
          if (i != 0)
            return; 
          throw new IllegalArgumentException("Wildcard in class name is only allowed at the end.".toString());
        } 
        throw new IllegalArgumentException("Wildcard in package name is only allowed at the end.".toString());
      } 
      throw new IllegalArgumentException("Activity class name must not be empty.".toString());
    } 
    throw new IllegalArgumentException("Package name must not be empty".toString());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ActivityFilter))
      return false; 
    ComponentName componentName = this.componentName;
    paramObject = paramObject;
    return !l.b(componentName, ((ActivityFilter)paramObject).componentName) ? false : (!!l.b(this.intentAction, ((ActivityFilter)paramObject).intentAction));
  }
  
  public final ComponentName getComponentName() {
    return this.componentName;
  }
  
  public final String getIntentAction() {
    return this.intentAction;
  }
  
  public int hashCode() {
    int i;
    int j = this.componentName.hashCode();
    String str = this.intentAction;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return j * 31 + i;
  }
  
  public final boolean matchesActivity(Activity paramActivity) {
    l.f(paramActivity, "activity");
    if (MatcherUtils.INSTANCE.areActivityOrIntentComponentsMatching$window_release(paramActivity, this.componentName)) {
      String str = this.intentAction;
      if (str != null) {
        String str1;
        Intent intent = paramActivity.getIntent();
        if (intent == null) {
          intent = null;
        } else {
          str1 = intent.getAction();
        } 
        if (l.b(str, str1))
          return true; 
      } else {
        return true;
      } 
    } 
    return false;
  }
  
  public final boolean matchesIntent(Intent paramIntent) {
    l.f(paramIntent, "intent");
    boolean bool1 = MatcherUtils.INSTANCE.areComponentsMatching$window_release(paramIntent.getComponent(), this.componentName);
    boolean bool = false;
    if (!bool1)
      return false; 
    String str = this.intentAction;
    if (str == null || l.b(str, paramIntent.getAction()))
      bool = true; 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ActivityFilter(componentName=");
    stringBuilder.append(this.componentName);
    stringBuilder.append(", intentAction=");
    stringBuilder.append(this.intentAction);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\ActivityFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */