package androidx.window.embedding;

import android.app.Activity;
import android.content.Intent;
import android.util.Pair;
import android.view.WindowMetrics;
import androidx.window.core.ExperimentalWindowApi;
import androidx.window.extensions.embedding.ActivityRule;
import androidx.window.extensions.embedding.ActivityStack;
import androidx.window.extensions.embedding.EmbeddingRule;
import androidx.window.extensions.embedding.SplitInfo;
import androidx.window.extensions.embedding.SplitPairRule;
import androidx.window.extensions.embedding.SplitPlaceholderRule;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import kotlin.jvm.internal.l;
import p7.m;

@ExperimentalWindowApi
public final class EmbeddingAdapter {
  private final <F, S> F component1(Pair<F, S> paramPair) {
    l.f(paramPair, "<this>");
    return (F)paramPair.first;
  }
  
  private final <F, S> S component2(Pair<F, S> paramPair) {
    l.f(paramPair, "<this>");
    return (S)paramPair.second;
  }
  
  private final SplitInfo translate(SplitInfo paramSplitInfo) {
    boolean bool;
    ActivityStack activityStack1 = paramSplitInfo.getPrimaryActivityStack();
    l.e(activityStack1, "splitInfo.primaryActivityStack");
    boolean bool1 = false;
    try {
      bool = activityStack1.isEmpty();
    } catch (NoSuchMethodError noSuchMethodError) {
      bool = false;
    } 
    List<? extends Activity> list = activityStack1.getActivities();
    l.e(list, "primaryActivityStack.activities");
    ActivityStack activityStack = new ActivityStack(list, bool);
    ActivityStack activityStack2 = paramSplitInfo.getSecondaryActivityStack();
    l.e(activityStack2, "splitInfo.secondaryActivityStack");
    try {
      bool = activityStack2.isEmpty();
    } catch (NoSuchMethodError noSuchMethodError) {
      bool = bool1;
    } 
  }
  
  private static final boolean translateActivityIntentPredicates$lambda-3(EmbeddingAdapter paramEmbeddingAdapter, Set paramSet, Pair<Activity, ?> paramPair) {
    l.f(paramEmbeddingAdapter, "this$0");
    l.f(paramSet, "$splitPairFilters");
    l.e(paramPair, "(first, second)");
    Activity activity = paramEmbeddingAdapter.component1(paramPair);
    Intent intent = (Intent)paramEmbeddingAdapter.component2(paramPair);
    boolean bool = paramSet instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && paramSet.isEmpty())
      return false; 
    Iterator<SplitPairFilter> iterator = paramSet.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((SplitPairFilter)iterator.next()).matchesActivityIntentPair(activity, intent)) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  private static final boolean translateActivityPairPredicates$lambda-1(EmbeddingAdapter paramEmbeddingAdapter, Set paramSet, Pair<Activity, ?> paramPair) {
    l.f(paramEmbeddingAdapter, "this$0");
    l.f(paramSet, "$splitPairFilters");
    l.e(paramPair, "(first, second)");
    Activity activity2 = paramEmbeddingAdapter.component1(paramPair);
    Activity activity1 = (Activity)paramEmbeddingAdapter.component2(paramPair);
    boolean bool = paramSet instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && paramSet.isEmpty())
      return false; 
    Iterator<SplitPairFilter> iterator = paramSet.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((SplitPairFilter)iterator.next()).matchesActivityPair(activity2, activity1)) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  private static final boolean translateActivityPredicates$lambda-6(Set paramSet, Activity paramActivity) {
    l.f(paramSet, "$activityFilters");
    boolean bool = paramSet instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && paramSet.isEmpty())
      return false; 
    Iterator<ActivityFilter> iterator = paramSet.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        ActivityFilter activityFilter = iterator.next();
        l.e(paramActivity, "activity");
        if (activityFilter.matchesActivity(paramActivity)) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  private static final boolean translateIntentPredicates$lambda-8(Set paramSet, Intent paramIntent) {
    l.f(paramSet, "$activityFilters");
    boolean bool = paramSet instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && paramSet.isEmpty())
      return false; 
    Iterator<ActivityFilter> iterator = paramSet.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        ActivityFilter activityFilter = iterator.next();
        l.e(paramIntent, "intent");
        if (activityFilter.matchesIntent(paramIntent)) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  private static final boolean translateParentMetricsPredicate$lambda-4(SplitRule paramSplitRule, WindowMetrics paramWindowMetrics) {
    l.f(paramSplitRule, "$splitRule");
    l.e(paramWindowMetrics, "windowMetrics");
    return paramSplitRule.checkParentMetrics(paramWindowMetrics);
  }
  
  public final List<SplitInfo> translate(List<? extends SplitInfo> paramList) {
    l.f(paramList, "splitInfoList");
    ArrayList<SplitInfo> arrayList = new ArrayList(m.k(paramList, 10));
    Iterator<? extends SplitInfo> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(translate(iterator.next())); 
    return arrayList;
  }
  
  public final Set<EmbeddingRule> translate(Set<? extends EmbeddingRule> paramSet) {
    l.f(paramSet, "rules");
    ArrayList<EmbeddingRule> arrayList = new ArrayList(m.k(paramSet, 10));
    for (EmbeddingRule embeddingRule1 : paramSet) {
      SplitPairRule splitPairRule;
      ActivityRule activityRule;
      String str;
      if (embeddingRule1 instanceof SplitPairRule) {
        SplitPairRule splitPairRule1 = (SplitPairRule)embeddingRule1;
        splitPairRule = (new SplitPairRule.Builder(translateActivityPairPredicates(splitPairRule1.getFilters()), translateActivityIntentPredicates(splitPairRule1.getFilters()), translateParentMetricsPredicate((SplitRule)embeddingRule1))).setSplitRatio(splitPairRule1.getSplitRatio()).setLayoutDirection(splitPairRule1.getLayoutDirection()).setShouldFinishPrimaryWithSecondary(splitPairRule1.getFinishPrimaryWithSecondary()).setShouldFinishSecondaryWithPrimary(splitPairRule1.getFinishSecondaryWithPrimary()).setShouldClearTop(splitPairRule1.getClearTop()).build();
        str = "SplitPairRuleBuilder(\n  …                 .build()";
      } else {
        SplitPlaceholderRule splitPlaceholderRule;
        if (splitPairRule instanceof SplitPlaceholderRule) {
          SplitPlaceholderRule splitPlaceholderRule1 = (SplitPlaceholderRule)splitPairRule;
          splitPlaceholderRule = (new SplitPlaceholderRule.Builder(splitPlaceholderRule1.getPlaceholderIntent(), translateActivityPredicates(splitPlaceholderRule1.getFilters()), translateIntentPredicates(splitPlaceholderRule1.getFilters()), translateParentMetricsPredicate((SplitRule)splitPairRule))).setSplitRatio(splitPlaceholderRule1.getSplitRatio()).setLayoutDirection(splitPlaceholderRule1.getLayoutDirection()).build();
          str = "SplitPlaceholderRuleBuil…                 .build()";
        } else if (splitPlaceholderRule instanceof ActivityRule) {
          ActivityRule activityRule1 = (ActivityRule)splitPlaceholderRule;
          activityRule = (new ActivityRule.Builder(translateActivityPredicates(activityRule1.getFilters()), translateIntentPredicates(activityRule1.getFilters()))).setShouldAlwaysExpand(activityRule1.getAlwaysExpand()).build();
          str = "ActivityRuleBuilder(\n   …                 .build()";
        } else {
          throw new IllegalArgumentException("Unsupported rule type");
        } 
      } 
      l.e(activityRule, str);
      EmbeddingRule embeddingRule = (EmbeddingRule)activityRule;
      arrayList.add(embeddingRule);
    } 
    return m.Q(arrayList);
  }
  
  public final Predicate<Pair<Activity, Intent>> translateActivityIntentPredicates(Set<SplitPairFilter> paramSet) {
    l.f(paramSet, "splitPairFilters");
    return new b(this, paramSet);
  }
  
  public final Predicate<Pair<Activity, Activity>> translateActivityPairPredicates(Set<SplitPairFilter> paramSet) {
    l.f(paramSet, "splitPairFilters");
    return new c(this, paramSet);
  }
  
  public final Predicate<Activity> translateActivityPredicates(Set<ActivityFilter> paramSet) {
    l.f(paramSet, "activityFilters");
    return new e(paramSet);
  }
  
  public final Predicate<Intent> translateIntentPredicates(Set<ActivityFilter> paramSet) {
    l.f(paramSet, "activityFilters");
    return new f(paramSet);
  }
  
  public final Predicate<WindowMetrics> translateParentMetricsPredicate(SplitRule paramSplitRule) {
    l.f(paramSplitRule, "splitRule");
    return new d(paramSplitRule);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\EmbeddingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */