package androidx.window.embedding;

import android.app.Activity;
import android.util.Log;
import androidx.core.util.a;
import androidx.window.core.ExperimentalWindowApi;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import o7.u;
import p7.m;

@ExperimentalWindowApi
public final class ExtensionEmbeddingBackend implements EmbeddingBackend {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG = "EmbeddingBackend";
  
  private static volatile ExtensionEmbeddingBackend globalInstance;
  
  private static final ReentrantLock globalLock = new ReentrantLock();
  
  private EmbeddingInterfaceCompat embeddingExtension;
  
  private final CopyOnWriteArrayList<SplitListenerWrapper> splitChangeCallbacks;
  
  private final EmbeddingCallbackImpl splitInfoEmbeddingCallback;
  
  private final CopyOnWriteArraySet<EmbeddingRule> splitRules;
  
  public ExtensionEmbeddingBackend(EmbeddingInterfaceCompat paramEmbeddingInterfaceCompat) {
    this.embeddingExtension = paramEmbeddingInterfaceCompat;
    EmbeddingCallbackImpl embeddingCallbackImpl = new EmbeddingCallbackImpl();
    this.splitInfoEmbeddingCallback = embeddingCallbackImpl;
    this.splitChangeCallbacks = new CopyOnWriteArrayList<SplitListenerWrapper>();
    EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
    if (embeddingInterfaceCompat != null)
      embeddingInterfaceCompat.setEmbeddingCallback(embeddingCallbackImpl); 
    this.splitRules = new CopyOnWriteArraySet<EmbeddingRule>();
  }
  
  public final EmbeddingInterfaceCompat getEmbeddingExtension() {
    return this.embeddingExtension;
  }
  
  public final CopyOnWriteArrayList<SplitListenerWrapper> getSplitChangeCallbacks() {
    return this.splitChangeCallbacks;
  }
  
  public Set<EmbeddingRule> getSplitRules() {
    return this.splitRules;
  }
  
  public boolean isSplitSupported() {
    return (this.embeddingExtension != null);
  }
  
  public void registerRule(EmbeddingRule paramEmbeddingRule) {
    l.f(paramEmbeddingRule, "rule");
    if (!this.splitRules.contains(paramEmbeddingRule)) {
      this.splitRules.add(paramEmbeddingRule);
      EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
      if (embeddingInterfaceCompat == null)
        return; 
      embeddingInterfaceCompat.setSplitRules(this.splitRules);
    } 
  }
  
  public void registerSplitListenerForActivity(Activity paramActivity, Executor paramExecutor, a<List<SplitInfo>> parama) {
    l.f(paramActivity, "activity");
    l.f(paramExecutor, "executor");
    l.f(parama, "callback");
    ReentrantLock reentrantLock = globalLock;
    reentrantLock.lock();
    try {
      List<SplitInfo> list;
      if (getEmbeddingExtension() == null) {
        Log.v("EmbeddingBackend", "Extension not loaded, skipping callback registration.");
        parama.accept(m.d());
        return;
      } 
      SplitListenerWrapper splitListenerWrapper = new SplitListenerWrapper(paramActivity, paramExecutor, parama);
      getSplitChangeCallbacks().add(splitListenerWrapper);
      if (this.splitInfoEmbeddingCallback.getLastInfo() != null) {
        list = this.splitInfoEmbeddingCallback.getLastInfo();
        l.c(list);
      } else {
        list = m.d();
      } 
      splitListenerWrapper.accept(list);
      u u = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void setEmbeddingExtension(EmbeddingInterfaceCompat paramEmbeddingInterfaceCompat) {
    this.embeddingExtension = paramEmbeddingInterfaceCompat;
  }
  
  public void setSplitRules(Set<? extends EmbeddingRule> paramSet) {
    l.f(paramSet, "rules");
    this.splitRules.clear();
    this.splitRules.addAll(paramSet);
    EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
    if (embeddingInterfaceCompat == null)
      return; 
    embeddingInterfaceCompat.setSplitRules(this.splitRules);
  }
  
  public void unregisterRule(EmbeddingRule paramEmbeddingRule) {
    l.f(paramEmbeddingRule, "rule");
    if (this.splitRules.contains(paramEmbeddingRule)) {
      this.splitRules.remove(paramEmbeddingRule);
      EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
      if (embeddingInterfaceCompat == null)
        return; 
      embeddingInterfaceCompat.setSplitRules(this.splitRules);
    } 
  }
  
  public void unregisterSplitListenerForActivity(a<List<SplitInfo>> parama) {
    l.f(parama, "consumer");
    ReentrantLock reentrantLock = globalLock;
    reentrantLock.lock();
    try {
      for (SplitListenerWrapper splitListenerWrapper : getSplitChangeCallbacks()) {
        if (l.b(splitListenerWrapper.getCallback(), parama)) {
          getSplitChangeCallbacks().remove(splitListenerWrapper);
          break;
        } 
      } 
      u u = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public static final class Companion {
    private Companion() {}
    
    private final EmbeddingInterfaceCompat initAndVerifyEmbeddingExtension() {
      EmbeddingCompat embeddingCompat1;
      EmbeddingCompat embeddingCompat2 = null;
      try {
        EmbeddingCompat.Companion companion = EmbeddingCompat.Companion;
      } finally {
        Exception exception = null;
        Log.d("EmbeddingBackend", l.m("Failed to load embedding extension: ", exception));
      } 
      if (embeddingCompat1 == null)
        Log.d("EmbeddingBackend", "No supported embedding extension found"); 
      return embeddingCompat1;
    }
    
    public final ExtensionEmbeddingBackend getInstance() {
      if (ExtensionEmbeddingBackend.globalInstance == null) {
        ReentrantLock reentrantLock = ExtensionEmbeddingBackend.globalLock;
        reentrantLock.lock();
        try {
          if (ExtensionEmbeddingBackend.globalInstance == null)
            ExtensionEmbeddingBackend.globalInstance = new ExtensionEmbeddingBackend(ExtensionEmbeddingBackend.Companion.initAndVerifyEmbeddingExtension()); 
          u u = u.a;
        } finally {
          reentrantLock.unlock();
        } 
      } 
      ExtensionEmbeddingBackend extensionEmbeddingBackend = ExtensionEmbeddingBackend.globalInstance;
      l.c(extensionEmbeddingBackend);
      return extensionEmbeddingBackend;
    }
    
    public final boolean isExtensionVersionSupported(Integer param1Integer) {
      boolean bool = false;
      if (param1Integer == null)
        return false; 
      if (param1Integer.intValue() >= 1)
        bool = true; 
      return bool;
    }
  }
  
  public final class EmbeddingCallbackImpl implements EmbeddingInterfaceCompat.EmbeddingCallbackInterface {
    private List<SplitInfo> lastInfo;
    
    public final List<SplitInfo> getLastInfo() {
      return this.lastInfo;
    }
    
    public void onSplitInfoChanged(List<SplitInfo> param1List) {
      l.f(param1List, "splitInfo");
      this.lastInfo = param1List;
      Iterator<ExtensionEmbeddingBackend.SplitListenerWrapper> iterator = ExtensionEmbeddingBackend.this.getSplitChangeCallbacks().iterator();
      while (iterator.hasNext())
        ((ExtensionEmbeddingBackend.SplitListenerWrapper)iterator.next()).accept(param1List); 
    }
    
    public final void setLastInfo(List<SplitInfo> param1List) {
      this.lastInfo = param1List;
    }
  }
  
  public static final class SplitListenerWrapper {
    private final Activity activity;
    
    private final a<List<SplitInfo>> callback;
    
    private final Executor executor;
    
    private List<SplitInfo> lastValue;
    
    public SplitListenerWrapper(Activity param1Activity, Executor param1Executor, a<List<SplitInfo>> param1a) {
      this.activity = param1Activity;
      this.executor = param1Executor;
      this.callback = param1a;
    }
    
    private static final void accept$lambda-1(SplitListenerWrapper param1SplitListenerWrapper, List param1List) {
      l.f(param1SplitListenerWrapper, "this$0");
      l.f(param1List, "$splitsWithActivity");
      param1SplitListenerWrapper.getCallback().accept(param1List);
    }
    
    public final void accept(List<SplitInfo> param1List) {
      l.f(param1List, "splitInfoList");
      ArrayList<SplitInfo> arrayList = new ArrayList();
      for (SplitInfo splitInfo : param1List) {
        if (((SplitInfo)splitInfo).contains(this.activity))
          arrayList.add(splitInfo); 
      } 
      if (l.b(arrayList, this.lastValue))
        return; 
      this.lastValue = arrayList;
      this.executor.execute(new g(this, arrayList));
    }
    
    public final a<List<SplitInfo>> getCallback() {
      return this.callback;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\ExtensionEmbeddingBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */