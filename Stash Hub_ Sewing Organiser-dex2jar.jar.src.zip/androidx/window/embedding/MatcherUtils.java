package androidx.window.embedding;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import androidx.window.core.ExperimentalWindowApi;
import f8.f;
import kotlin.jvm.internal.l;

@ExperimentalWindowApi
public final class MatcherUtils {
  public static final MatcherUtils INSTANCE = new MatcherUtils();
  
  public static final boolean sDebugMatchers = false;
  
  public static final String sMatchersTag = "SplitRuleResolution";
  
  private final boolean wildcardMatch(String paramString1, String paramString2) {
    boolean bool;
    if (!f.u(paramString2, "*", false, 2, null))
      return false; 
    if (l.b(paramString2, "*"))
      return true; 
    if (f.D(paramString2, "*", 0, false, 6, null) == f.I(paramString2, "*", 0, false, 6, null) && f.i(paramString2, "*", false, 2, null)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramString2 = paramString2.substring(0, paramString2.length() - 1);
      l.e(paramString2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
      return f.p(paramString1, paramString2, false, 2, null);
    } 
    throw new IllegalArgumentException("Name pattern with a wildcard must only contain a single wildcard in the end".toString());
  }
  
  public final boolean areActivityOrIntentComponentsMatching$window_release(Activity paramActivity, ComponentName paramComponentName) {
    l.f(paramActivity, "activity");
    l.f(paramComponentName, "ruleComponent");
    if (areComponentsMatching$window_release(paramActivity.getComponentName(), paramComponentName))
      return true; 
    Intent intent = paramActivity.getIntent();
    if (intent == null)
      return false; 
    ComponentName componentName = intent.getComponent();
    return (componentName == null) ? false : INSTANCE.areComponentsMatching$window_release(componentName, paramComponentName);
  }
  
  public final boolean areComponentsMatching$window_release(ComponentName paramComponentName1, ComponentName paramComponentName2) {
    // Byte code:
    //   0: aload_2
    //   1: ldc 'ruleComponent'
    //   3: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: ifnonnull -> 38
    //   10: aload_2
    //   11: invokevirtual getPackageName : ()Ljava/lang/String;
    //   14: ldc '*'
    //   16: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   19: ifeq -> 36
    //   22: aload_2
    //   23: invokevirtual getClassName : ()Ljava/lang/String;
    //   26: ldc '*'
    //   28: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   31: ifeq -> 36
    //   34: iconst_1
    //   35: ireturn
    //   36: iconst_0
    //   37: ireturn
    //   38: aload_1
    //   39: invokevirtual toString : ()Ljava/lang/String;
    //   42: astore #5
    //   44: aload #5
    //   46: ldc 'activityComponent.toString()'
    //   48: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   51: aload #5
    //   53: ldc '*'
    //   55: iconst_0
    //   56: iconst_2
    //   57: aconst_null
    //   58: invokestatic u : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   61: iconst_1
    //   62: ixor
    //   63: ifeq -> 197
    //   66: aload_1
    //   67: invokevirtual getPackageName : ()Ljava/lang/String;
    //   70: aload_2
    //   71: invokevirtual getPackageName : ()Ljava/lang/String;
    //   74: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   77: ifne -> 125
    //   80: aload_1
    //   81: invokevirtual getPackageName : ()Ljava/lang/String;
    //   84: astore #5
    //   86: aload #5
    //   88: ldc 'activityComponent.packageName'
    //   90: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   93: aload_2
    //   94: invokevirtual getPackageName : ()Ljava/lang/String;
    //   97: astore #6
    //   99: aload #6
    //   101: ldc 'ruleComponent.packageName'
    //   103: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   106: aload_0
    //   107: aload #5
    //   109: aload #6
    //   111: invokespecial wildcardMatch : (Ljava/lang/String;Ljava/lang/String;)Z
    //   114: ifeq -> 120
    //   117: goto -> 125
    //   120: iconst_0
    //   121: istore_3
    //   122: goto -> 127
    //   125: iconst_1
    //   126: istore_3
    //   127: aload_1
    //   128: invokevirtual getClassName : ()Ljava/lang/String;
    //   131: aload_2
    //   132: invokevirtual getClassName : ()Ljava/lang/String;
    //   135: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   138: ifne -> 181
    //   141: aload_1
    //   142: invokevirtual getClassName : ()Ljava/lang/String;
    //   145: astore_1
    //   146: aload_1
    //   147: ldc 'activityComponent.className'
    //   149: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   152: aload_2
    //   153: invokevirtual getClassName : ()Ljava/lang/String;
    //   156: astore_2
    //   157: aload_2
    //   158: ldc 'ruleComponent.className'
    //   160: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   163: aload_0
    //   164: aload_1
    //   165: aload_2
    //   166: invokespecial wildcardMatch : (Ljava/lang/String;Ljava/lang/String;)Z
    //   169: ifeq -> 175
    //   172: goto -> 181
    //   175: iconst_0
    //   176: istore #4
    //   178: goto -> 184
    //   181: iconst_1
    //   182: istore #4
    //   184: iload_3
    //   185: ifeq -> 195
    //   188: iload #4
    //   190: ifeq -> 195
    //   193: iconst_1
    //   194: ireturn
    //   195: iconst_0
    //   196: ireturn
    //   197: new java/lang/IllegalArgumentException
    //   200: dup
    //   201: ldc 'Wildcard can only be part of the rule.'
    //   203: invokevirtual toString : ()Ljava/lang/String;
    //   206: invokespecial <init> : (Ljava/lang/String;)V
    //   209: athrow
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\embedding\MatcherUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */