package androidx.window.core;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(RetentionPolicy.CLASS)
public @interface ExperimentalWindowApi {}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\core\ExperimentalWindowApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */