package androidx.window.core;

import f8.f;
import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import o7.g;
import o7.h;
import y7.a;

public final class Version implements Comparable<Version> {
  private static final Version CURRENT;
  
  public static final Companion Companion = new Companion(null);
  
  private static final Version UNKNOWN = new Version(0, 0, 0, "");
  
  private static final Version VERSION_0_1 = new Version(0, 1, 0, "");
  
  private static final Version VERSION_1_0;
  
  private static final String VERSION_PATTERN_STRING = "(\\d+)(?:\\.(\\d+))(?:\\.(\\d+))(?:-(.+))?";
  
  private final g bigInteger$delegate;
  
  private final String description;
  
  private final int major;
  
  private final int minor;
  
  private final int patch;
  
  static {
    Version version = new Version(1, 0, 0, "");
    VERSION_1_0 = version;
    CURRENT = version;
  }
  
  private Version(int paramInt1, int paramInt2, int paramInt3, String paramString) {
    this.major = paramInt1;
    this.minor = paramInt2;
    this.patch = paramInt3;
    this.description = paramString;
    this.bigInteger$delegate = h.a(new Version$bigInteger$2());
  }
  
  private final BigInteger getBigInteger() {
    Object object = this.bigInteger$delegate.getValue();
    l.e(object, "<get-bigInteger>(...)");
    return (BigInteger)object;
  }
  
  public static final Version parse(String paramString) {
    return Companion.parse(paramString);
  }
  
  public int compareTo(Version paramVersion) {
    l.f(paramVersion, "other");
    return getBigInteger().compareTo(paramVersion.getBigInteger());
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof Version;
    boolean bool1 = false;
    if (!bool)
      return false; 
    int i = this.major;
    paramObject = paramObject;
    bool = bool1;
    if (i == ((Version)paramObject).major) {
      bool = bool1;
      if (this.minor == ((Version)paramObject).minor) {
        bool = bool1;
        if (this.patch == ((Version)paramObject).patch)
          bool = true; 
      } 
    } 
    return bool;
  }
  
  public final String getDescription() {
    return this.description;
  }
  
  public final int getMajor() {
    return this.major;
  }
  
  public final int getMinor() {
    return this.minor;
  }
  
  public final int getPatch() {
    return this.patch;
  }
  
  public int hashCode() {
    return ((527 + this.major) * 31 + this.minor) * 31 + this.patch;
  }
  
  public String toString() {
    String str;
    if ((f.k(this.description) ^ true) != 0) {
      str = l.m("-", this.description);
    } else {
      str = "";
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.major);
    stringBuilder.append('.');
    stringBuilder.append(this.minor);
    stringBuilder.append('.');
    stringBuilder.append(this.patch);
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final Version getCURRENT() {
      return Version.CURRENT;
    }
    
    public final Version getUNKNOWN() {
      return Version.UNKNOWN;
    }
    
    public final Version getVERSION_0_1() {
      return Version.VERSION_0_1;
    }
    
    public final Version getVERSION_1_0() {
      return Version.VERSION_1_0;
    }
    
    public final Version parse(String param1String) {
      if (param1String != null) {
        Integer integer3;
        Integer integer2;
        Integer integer1;
        String str1;
        if (f.k(param1String))
          return null; 
        Matcher matcher = Pattern.compile("(\\d+)(?:\\.(\\d+))(?:\\.(\\d+))(?:-(.+))?").matcher(param1String);
        if (!matcher.matches())
          return null; 
        param1String = matcher.group(1);
        if (param1String == null) {
          param1String = null;
        } else {
          integer3 = Integer.valueOf(Integer.parseInt(param1String));
        } 
        if (integer3 == null)
          return null; 
        int i = integer3.intValue();
        String str3 = matcher.group(2);
        if (str3 == null) {
          str3 = null;
        } else {
          integer2 = Integer.valueOf(Integer.parseInt(str3));
        } 
        if (integer2 == null)
          return null; 
        int j = integer2.intValue();
        String str2 = matcher.group(3);
        if (str2 == null) {
          str2 = null;
        } else {
          integer1 = Integer.valueOf(Integer.parseInt(str2));
        } 
        if (integer1 == null)
          return null; 
        int k = integer1.intValue();
        if (matcher.group(4) != null) {
          str1 = matcher.group(4);
        } else {
          str1 = "";
        } 
        l.e(str1, "description");
        return new Version(i, j, k, str1, null);
      } 
      return null;
    }
  }
  
  static final class Version$bigInteger$2 extends m implements a<BigInteger> {
    Version$bigInteger$2() {
      super(0);
    }
    
    public final BigInteger invoke() {
      return BigInteger.valueOf(Version.this.getMajor()).shiftLeft(32).or(BigInteger.valueOf(Version.this.getMinor())).shiftLeft(32).or(BigInteger.valueOf(Version.this.getPatch()));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\core\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */