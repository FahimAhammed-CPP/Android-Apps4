package androidx.window.core;

import android.graphics.Rect;
import java.util.Objects;
import kotlin.jvm.internal.l;

public final class Bounds {
  private final int bottom;
  
  private final int left;
  
  private final int right;
  
  private final int top;
  
  public Bounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.left = paramInt1;
    this.top = paramInt2;
    this.right = paramInt3;
    this.bottom = paramInt4;
  }
  
  public Bounds(Rect paramRect) {
    this(paramRect.left, paramRect.top, paramRect.right, paramRect.bottom);
  }
  
  public boolean equals(Object paramObject) {
    Class<?> clazz;
    if (this == paramObject)
      return true; 
    if (paramObject == null) {
      clazz = null;
    } else {
      clazz = paramObject.getClass();
    } 
    if (!l.b(Bounds.class, clazz))
      return false; 
    Objects.requireNonNull(paramObject, "null cannot be cast to non-null type androidx.window.core.Bounds");
    paramObject = paramObject;
    return (this.left != ((Bounds)paramObject).left) ? false : ((this.top != ((Bounds)paramObject).top) ? false : ((this.right != ((Bounds)paramObject).right) ? false : (!(this.bottom != ((Bounds)paramObject).bottom))));
  }
  
  public final int getBottom() {
    return this.bottom;
  }
  
  public final int getHeight() {
    return this.bottom - this.top;
  }
  
  public final int getLeft() {
    return this.left;
  }
  
  public final int getRight() {
    return this.right;
  }
  
  public final int getTop() {
    return this.top;
  }
  
  public final int getWidth() {
    return this.right - this.left;
  }
  
  public int hashCode() {
    return ((this.left * 31 + this.top) * 31 + this.right) * 31 + this.bottom;
  }
  
  public final boolean isEmpty() {
    return (getHeight() == 0 || getWidth() == 0);
  }
  
  public final boolean isZero() {
    return (getHeight() == 0 && getWidth() == 0);
  }
  
  public final Rect toRect() {
    return new Rect(this.left, this.top, this.right, this.bottom);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Bounds.class.getSimpleName());
    stringBuilder.append(" { [");
    stringBuilder.append(this.left);
    stringBuilder.append(',');
    stringBuilder.append(this.top);
    stringBuilder.append(',');
    stringBuilder.append(this.right);
    stringBuilder.append(',');
    stringBuilder.append(this.bottom);
    stringBuilder.append("] }");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\core\Bounds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */