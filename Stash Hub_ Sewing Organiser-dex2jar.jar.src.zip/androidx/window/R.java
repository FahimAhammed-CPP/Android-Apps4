package androidx.window;

public final class R {
  public static final class attr {
    public static final int activityAction = 2130771968;
    
    public static final int activityName = 2130771969;
    
    public static final int alwaysExpand = 2130771971;
    
    public static final int clearTop = 2130771974;
    
    public static final int finishPrimaryWithSecondary = 2130771977;
    
    public static final int finishSecondaryWithPrimary = 2130771978;
    
    public static final int placeholderActivityName = 2130772001;
    
    public static final int primaryActivityName = 2130772002;
    
    public static final int secondaryActivityAction = 2130772005;
    
    public static final int secondaryActivityName = 2130772006;
    
    public static final int splitLayoutDirection = 2130772008;
    
    public static final int splitMinSmallestWidth = 2130772009;
    
    public static final int splitMinWidth = 2130772010;
    
    public static final int splitRatio = 2130772011;
  }
  
  public static final class id {
    public static final int androidx_window_activity_scope = 2131099690;
    
    public static final int locale = 2131099724;
    
    public static final int ltr = 2131099725;
    
    public static final int rtl = 2131099736;
  }
  
  public static final class styleable {
    public static final int[] ActivityFilter = new int[] { 2130771968, 2130771969 };
    
    public static final int ActivityFilter_activityAction = 0;
    
    public static final int ActivityFilter_activityName = 1;
    
    public static final int[] ActivityRule = new int[] { 2130771971 };
    
    public static final int ActivityRule_alwaysExpand = 0;
    
    public static final int[] SplitPairFilter = new int[] { 2130772002, 2130772005, 2130772006 };
    
    public static final int SplitPairFilter_primaryActivityName = 0;
    
    public static final int SplitPairFilter_secondaryActivityAction = 1;
    
    public static final int SplitPairFilter_secondaryActivityName = 2;
    
    public static final int[] SplitPairRule = new int[] { 2130771974, 2130771977, 2130771978, 2130772008, 2130772009, 2130772010, 2130772011 };
    
    public static final int SplitPairRule_clearTop = 0;
    
    public static final int SplitPairRule_finishPrimaryWithSecondary = 1;
    
    public static final int SplitPairRule_finishSecondaryWithPrimary = 2;
    
    public static final int SplitPairRule_splitLayoutDirection = 3;
    
    public static final int SplitPairRule_splitMinSmallestWidth = 4;
    
    public static final int SplitPairRule_splitMinWidth = 5;
    
    public static final int SplitPairRule_splitRatio = 6;
    
    public static final int[] SplitPlaceholderRule = new int[] { 2130772001, 2130772008, 2130772009, 2130772010, 2130772011 };
    
    public static final int SplitPlaceholderRule_placeholderActivityName = 0;
    
    public static final int SplitPlaceholderRule_splitLayoutDirection = 1;
    
    public static final int SplitPlaceholderRule_splitMinSmallestWidth = 2;
    
    public static final int SplitPlaceholderRule_splitMinWidth = 3;
    
    public static final int SplitPlaceholderRule_splitRatio = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */