package androidx.window.layout;

import android.graphics.Rect;
import androidx.window.core.Bounds;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarDisplayFeature;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import p7.m;

public final class SidecarAdapter {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG = SidecarAdapter.class.getSimpleName();
  
  private final boolean isEqualSidecarDisplayFeature(SidecarDisplayFeature paramSidecarDisplayFeature1, SidecarDisplayFeature paramSidecarDisplayFeature2) {
    return l.b(paramSidecarDisplayFeature1, paramSidecarDisplayFeature2) ? true : ((paramSidecarDisplayFeature1 == null) ? false : ((paramSidecarDisplayFeature2 == null) ? false : ((paramSidecarDisplayFeature1.getType() != paramSidecarDisplayFeature2.getType()) ? false : l.b(paramSidecarDisplayFeature1.getRect(), paramSidecarDisplayFeature2.getRect()))));
  }
  
  private final boolean isEqualSidecarDisplayFeatures(List<SidecarDisplayFeature> paramList1, List<SidecarDisplayFeature> paramList2) {
    if (paramList1 == paramList2)
      return true; 
    if (paramList1 == null)
      return false; 
    if (paramList2 == null)
      return false; 
    if (paramList1.size() != paramList2.size())
      return false; 
    int i = paramList1.size() - 1;
    if (i >= 0)
      for (int j = 0;; j = k) {
        int k = j + 1;
        if (!isEqualSidecarDisplayFeature(paramList1.get(j), paramList2.get(j)))
          return false; 
        if (k > i)
          return true; 
      }  
    return true;
  }
  
  public final boolean isEqualSidecarDeviceState(SidecarDeviceState paramSidecarDeviceState1, SidecarDeviceState paramSidecarDeviceState2) {
    if (l.b(paramSidecarDeviceState1, paramSidecarDeviceState2))
      return true; 
    if (paramSidecarDeviceState1 == null)
      return false; 
    if (paramSidecarDeviceState2 == null)
      return false; 
    Companion companion = Companion;
    return (companion.getSidecarDevicePosture$window_release(paramSidecarDeviceState1) == companion.getSidecarDevicePosture$window_release(paramSidecarDeviceState2));
  }
  
  public final boolean isEqualSidecarWindowLayoutInfo(SidecarWindowLayoutInfo paramSidecarWindowLayoutInfo1, SidecarWindowLayoutInfo paramSidecarWindowLayoutInfo2) {
    if (l.b(paramSidecarWindowLayoutInfo1, paramSidecarWindowLayoutInfo2))
      return true; 
    if (paramSidecarWindowLayoutInfo1 == null)
      return false; 
    if (paramSidecarWindowLayoutInfo2 == null)
      return false; 
    Companion companion = Companion;
    return isEqualSidecarDisplayFeatures(companion.getSidecarDisplayFeatures(paramSidecarWindowLayoutInfo1), companion.getSidecarDisplayFeatures(paramSidecarWindowLayoutInfo2));
  }
  
  public final WindowLayoutInfo translate(SidecarWindowLayoutInfo paramSidecarWindowLayoutInfo, SidecarDeviceState paramSidecarDeviceState) {
    l.f(paramSidecarDeviceState, "state");
    if (paramSidecarWindowLayoutInfo == null)
      return new WindowLayoutInfo(m.d()); 
    SidecarDeviceState sidecarDeviceState = new SidecarDeviceState();
    Companion companion = Companion;
    companion.setSidecarDevicePosture(sidecarDeviceState, companion.getSidecarDevicePosture$window_release(paramSidecarDeviceState));
    return new WindowLayoutInfo(translate(companion.getSidecarDisplayFeatures(paramSidecarWindowLayoutInfo), sidecarDeviceState));
  }
  
  public final List<DisplayFeature> translate(List<SidecarDisplayFeature> paramList, SidecarDeviceState paramSidecarDeviceState) {
    l.f(paramList, "sidecarDisplayFeatures");
    l.f(paramSidecarDeviceState, "deviceState");
    ArrayList<DisplayFeature> arrayList = new ArrayList();
    for (SidecarDisplayFeature sidecarDisplayFeature : paramList) {
      DisplayFeature displayFeature = Companion.translate$window_release(sidecarDisplayFeature, paramSidecarDeviceState);
      if (displayFeature != null)
        arrayList.add(displayFeature); 
    } 
    return arrayList;
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final int getRawSidecarDevicePosture(SidecarDeviceState param1SidecarDeviceState) {
      l.f(param1SidecarDeviceState, "sidecarDeviceState");
      try {
        return param1SidecarDeviceState.posture;
      } catch (NoSuchFieldError noSuchFieldError) {
        try {
          Object object = SidecarDeviceState.class.getMethod("getPosture", new Class[0]).invoke(param1SidecarDeviceState, new Object[0]);
          if (object != null)
            return ((Integer)object).intValue(); 
          throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
        } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
          return 0;
        } 
      } 
    }
    
    public final int getSidecarDevicePosture$window_release(SidecarDeviceState param1SidecarDeviceState) {
      l.f(param1SidecarDeviceState, "sidecarDeviceState");
      int i = getRawSidecarDevicePosture(param1SidecarDeviceState);
      if (i >= 0) {
        int j = i;
        return (i > 4) ? 0 : j;
      } 
      return 0;
    }
    
    public final List<SidecarDisplayFeature> getSidecarDisplayFeatures(SidecarWindowLayoutInfo param1SidecarWindowLayoutInfo) {
      l.f(param1SidecarWindowLayoutInfo, "info");
      try {
        List<SidecarDisplayFeature> list2 = param1SidecarWindowLayoutInfo.displayFeatures;
        List<SidecarDisplayFeature> list1 = list2;
        if (list2 == null)
          list1 = m.d(); 
        return list1;
      } catch (NoSuchFieldError noSuchFieldError) {
        try {
          Object object = SidecarWindowLayoutInfo.class.getMethod("getDisplayFeatures", new Class[0]).invoke(param1SidecarWindowLayoutInfo, new Object[0]);
          if (object != null)
            return (List<SidecarDisplayFeature>)object; 
          throw new NullPointerException("null cannot be cast to non-null type kotlin.collections.List<androidx.window.sidecar.SidecarDisplayFeature>");
        } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
          return m.d();
        } 
      } 
    }
    
    public final void setSidecarDevicePosture(SidecarDeviceState param1SidecarDeviceState, int param1Int) {
      l.f(param1SidecarDeviceState, "sidecarDeviceState");
      try {
        param1SidecarDeviceState.posture = param1Int;
        return;
      } catch (NoSuchFieldError noSuchFieldError) {
        try {
          SidecarDeviceState.class.getMethod("setPosture", new Class[] { int.class }).invoke(param1SidecarDeviceState, new Object[] { Integer.valueOf(param1Int) });
          return;
        } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
          return;
        } 
      } 
    }
    
    public final void setSidecarDisplayFeatures(SidecarWindowLayoutInfo param1SidecarWindowLayoutInfo, List<SidecarDisplayFeature> param1List) {
      l.f(param1SidecarWindowLayoutInfo, "info");
      l.f(param1List, "displayFeatures");
      try {
        param1SidecarWindowLayoutInfo.displayFeatures = param1List;
        return;
      } catch (NoSuchFieldError noSuchFieldError) {
        try {
          SidecarWindowLayoutInfo.class.getMethod("setDisplayFeatures", new Class[] { List.class }).invoke(param1SidecarWindowLayoutInfo, new Object[] { param1List });
          return;
        } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
          return;
        } 
      } 
    }
    
    public final DisplayFeature translate$window_release(SidecarDisplayFeature param1SidecarDisplayFeature, SidecarDeviceState param1SidecarDeviceState) {
      HardwareFoldingFeature.Type type;
      l.f(param1SidecarDisplayFeature, "feature");
      l.f(param1SidecarDeviceState, "deviceState");
      Rect rect = param1SidecarDisplayFeature.getRect();
      l.e(rect, "feature.rect");
      if (rect.width() == 0 && rect.height() == 0)
        return null; 
      if (param1SidecarDisplayFeature.getType() == 1 && rect.width() != 0 && rect.height() != 0)
        return null; 
      if ((param1SidecarDisplayFeature.getType() == 2 || param1SidecarDisplayFeature.getType() == 1) && rect.left != 0 && rect.top != 0)
        return null; 
      int i = param1SidecarDisplayFeature.getType();
      if (i != 1) {
        if (i != 2)
          return null; 
        type = HardwareFoldingFeature.Type.Companion.getHINGE();
      } else {
        type = HardwareFoldingFeature.Type.Companion.getFOLD();
      } 
      i = getSidecarDevicePosture$window_release(param1SidecarDeviceState);
      if (i != 0 && i != 1) {
        Rect rect1;
        if (i != 2) {
          if (i == 3 || i != 4) {
            FoldingFeature.State state = FoldingFeature.State.FLAT;
            rect1 = param1SidecarDisplayFeature.getRect();
            l.e(rect1, "feature.rect");
            return new HardwareFoldingFeature(new Bounds(rect1), type, state);
          } 
        } else {
          FoldingFeature.State state = FoldingFeature.State.HALF_OPENED;
          rect1 = rect1.getRect();
          l.e(rect1, "feature.rect");
          return new HardwareFoldingFeature(new Bounds(rect1), type, state);
        } 
      } 
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\SidecarAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */