package androidx.window.layout;

import android.app.Activity;
import android.content.Context;
import androidx.window.extensions.layout.WindowLayoutComponent;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.w;
import kotlinx.coroutines.flow.b;

public interface WindowInfoTracker {
  public static final Companion Companion = Companion.$$INSTANCE;
  
  b<WindowLayoutInfo> windowLayoutInfo(Activity paramActivity);
  
  public static final class Companion {
    private static final boolean DEBUG = false;
    
    private static final String TAG = w.b(WindowInfoTracker.class).a();
    
    private static WindowInfoTrackerDecorator decorator = EmptyDecorator.INSTANCE;
    
    public final WindowInfoTracker getOrCreate(Context param1Context) {
      l.f(param1Context, "context");
      WindowInfoTrackerImpl windowInfoTrackerImpl = new WindowInfoTrackerImpl(WindowMetricsCalculatorCompat.INSTANCE, windowBackend$window_release(param1Context));
      return decorator.decorate(windowInfoTrackerImpl);
    }
    
    public final void overrideDecorator(WindowInfoTrackerDecorator param1WindowInfoTrackerDecorator) {
      l.f(param1WindowInfoTrackerDecorator, "overridingDecorator");
      decorator = param1WindowInfoTrackerDecorator;
    }
    
    public final void reset() {
      decorator = EmptyDecorator.INSTANCE;
    }
    
    public final WindowBackend windowBackend$window_release(Context param1Context) {
      WindowLayoutComponent windowLayoutComponent1;
      SidecarWindowBackend sidecarWindowBackend;
      l.f(param1Context, "context");
      WindowLayoutComponent windowLayoutComponent2 = null;
      try {
      
      } finally {
        Exception exception = null;
        windowLayoutComponent1 = windowLayoutComponent2;
      } 
      windowLayoutComponent2 = windowLayoutComponent1;
      if (windowLayoutComponent1 == null)
        sidecarWindowBackend = SidecarWindowBackend.Companion.getInstance(param1Context); 
      return sidecarWindowBackend;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowInfoTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */