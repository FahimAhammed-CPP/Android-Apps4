package androidx.window.layout;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.window.core.Version;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarInterface;
import androidx.window.sidecar.SidecarProvider;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import o7.u;
import p7.m;

public final class SidecarCompat implements ExtensionInterfaceCompat {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG = "SidecarCompat";
  
  private final Map<Activity, ComponentCallbacks> componentCallbackMap;
  
  private ExtensionInterfaceCompat.ExtensionCallbackInterface extensionCallback;
  
  private final SidecarInterface sidecar;
  
  private final SidecarAdapter sidecarAdapter;
  
  private final Map<IBinder, Activity> windowListenerRegisteredContexts;
  
  public SidecarCompat(Context paramContext) {
    this(SidecarProvider.getSidecarImpl(paramContext.getApplicationContext()), new SidecarAdapter());
  }
  
  public SidecarCompat(SidecarInterface paramSidecarInterface, SidecarAdapter paramSidecarAdapter) {
    this.sidecar = paramSidecarInterface;
    this.sidecarAdapter = paramSidecarAdapter;
    this.windowListenerRegisteredContexts = new LinkedHashMap<IBinder, Activity>();
    this.componentCallbackMap = new LinkedHashMap<Activity, ComponentCallbacks>();
  }
  
  private final void registerConfigurationChangeListener(Activity paramActivity) {
    if (this.componentCallbackMap.get(paramActivity) == null) {
      SidecarCompat$registerConfigurationChangeListener$configChangeObserver$1 sidecarCompat$registerConfigurationChangeListener$configChangeObserver$1 = new SidecarCompat$registerConfigurationChangeListener$configChangeObserver$1(paramActivity);
      this.componentCallbackMap.put(paramActivity, sidecarCompat$registerConfigurationChangeListener$configChangeObserver$1);
      paramActivity.registerComponentCallbacks(sidecarCompat$registerConfigurationChangeListener$configChangeObserver$1);
    } 
  }
  
  private final void unregisterComponentCallback(Activity paramActivity) {
    paramActivity.unregisterComponentCallbacks(this.componentCallbackMap.get(paramActivity));
    this.componentCallbackMap.remove(paramActivity);
  }
  
  public final SidecarInterface getSidecar() {
    return this.sidecar;
  }
  
  public final WindowLayoutInfo getWindowLayoutInfo(Activity paramActivity) {
    SidecarDeviceState sidecarDeviceState1;
    SidecarWindowLayoutInfo sidecarWindowLayoutInfo;
    l.f(paramActivity, "activity");
    IBinder iBinder = Companion.getActivityWindowToken$window_release(paramActivity);
    if (iBinder == null)
      return new WindowLayoutInfo(m.d()); 
    SidecarInterface sidecarInterface = this.sidecar;
    paramActivity = null;
    if (sidecarInterface == null) {
      iBinder = null;
    } else {
      sidecarWindowLayoutInfo = sidecarInterface.getWindowLayoutInfo(iBinder);
    } 
    SidecarAdapter sidecarAdapter = this.sidecarAdapter;
    sidecarInterface = this.sidecar;
    if (sidecarInterface != null)
      sidecarDeviceState1 = sidecarInterface.getDeviceState(); 
    SidecarDeviceState sidecarDeviceState2 = sidecarDeviceState1;
    if (sidecarDeviceState1 == null)
      sidecarDeviceState2 = new SidecarDeviceState(); 
    return sidecarAdapter.translate(sidecarWindowLayoutInfo, sidecarDeviceState2);
  }
  
  public void onWindowLayoutChangeListenerAdded(Activity paramActivity) {
    l.f(paramActivity, "activity");
    IBinder iBinder = Companion.getActivityWindowToken$window_release(paramActivity);
    if (iBinder != null) {
      register(iBinder, paramActivity);
      return;
    } 
    FirstAttachAdapter firstAttachAdapter = new FirstAttachAdapter(this, paramActivity);
    paramActivity.getWindow().getDecorView().addOnAttachStateChangeListener(firstAttachAdapter);
  }
  
  public void onWindowLayoutChangeListenerRemoved(Activity paramActivity) {
    boolean bool;
    l.f(paramActivity, "activity");
    IBinder iBinder = Companion.getActivityWindowToken$window_release(paramActivity);
    if (iBinder == null)
      return; 
    SidecarInterface sidecarInterface = this.sidecar;
    if (sidecarInterface != null)
      sidecarInterface.onWindowLayoutChangeListenerRemoved(iBinder); 
    unregisterComponentCallback(paramActivity);
    if (this.windowListenerRegisteredContexts.size() == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    this.windowListenerRegisteredContexts.remove(iBinder);
    if (bool) {
      SidecarInterface sidecarInterface1 = this.sidecar;
      if (sidecarInterface1 == null)
        return; 
      sidecarInterface1.onDeviceStateListenersChanged(true);
    } 
  }
  
  public final void register(IBinder paramIBinder, Activity paramActivity) {
    l.f(paramIBinder, "windowToken");
    l.f(paramActivity, "activity");
    this.windowListenerRegisteredContexts.put(paramIBinder, paramActivity);
    SidecarInterface sidecarInterface = this.sidecar;
    if (sidecarInterface != null)
      sidecarInterface.onWindowLayoutChangeListenerAdded(paramIBinder); 
    if (this.windowListenerRegisteredContexts.size() == 1) {
      SidecarInterface sidecarInterface1 = this.sidecar;
      if (sidecarInterface1 != null)
        sidecarInterface1.onDeviceStateListenersChanged(false); 
    } 
    ExtensionInterfaceCompat.ExtensionCallbackInterface extensionCallbackInterface = this.extensionCallback;
    if (extensionCallbackInterface != null)
      extensionCallbackInterface.onWindowLayoutChanged(paramActivity, getWindowLayoutInfo(paramActivity)); 
    registerConfigurationChangeListener(paramActivity);
  }
  
  public void setExtensionCallback(ExtensionInterfaceCompat.ExtensionCallbackInterface paramExtensionCallbackInterface) {
    l.f(paramExtensionCallbackInterface, "extensionCallback");
    this.extensionCallback = new DistinctElementCallback(paramExtensionCallbackInterface);
    SidecarInterface sidecarInterface = this.sidecar;
    if (sidecarInterface == null)
      return; 
    sidecarInterface.setSidecarCallback(new DistinctSidecarElementCallback(this.sidecarAdapter, new TranslatingCallback()));
  }
  
  public boolean validateExtensionInterface() {
    // Byte code:
    //   0: aload_0
    //   1: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   4: astore_1
    //   5: aconst_null
    //   6: astore_2
    //   7: aload_1
    //   8: ifnonnull -> 14
    //   11: goto -> 619
    //   14: aload_1
    //   15: invokevirtual getClass : ()Ljava/lang/Class;
    //   18: astore_1
    //   19: aload_1
    //   20: ifnonnull -> 26
    //   23: goto -> 619
    //   26: aload_1
    //   27: ldc 'setSidecarCallback'
    //   29: iconst_1
    //   30: anewarray java/lang/Class
    //   33: dup
    //   34: iconst_0
    //   35: ldc androidx/window/sidecar/SidecarInterface$SidecarCallback
    //   37: aastore
    //   38: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   41: astore_1
    //   42: goto -> 621
    //   45: aload_1
    //   46: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   49: astore_1
    //   50: aload_1
    //   51: getstatic java/lang/Void.TYPE : Ljava/lang/Class;
    //   54: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   57: ifeq -> 590
    //   60: aload_0
    //   61: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   64: astore_1
    //   65: aload_1
    //   66: ifnonnull -> 72
    //   69: goto -> 79
    //   72: aload_1
    //   73: invokeinterface getDeviceState : ()Landroidx/window/sidecar/SidecarDeviceState;
    //   78: pop
    //   79: aload_0
    //   80: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   83: astore_1
    //   84: aload_1
    //   85: ifnonnull -> 91
    //   88: goto -> 98
    //   91: aload_1
    //   92: iconst_1
    //   93: invokeinterface onDeviceStateListenersChanged : (Z)V
    //   98: aload_0
    //   99: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   102: astore_1
    //   103: aload_1
    //   104: ifnonnull -> 110
    //   107: goto -> 630
    //   110: aload_1
    //   111: invokevirtual getClass : ()Ljava/lang/Class;
    //   114: astore_1
    //   115: aload_1
    //   116: ifnonnull -> 122
    //   119: goto -> 630
    //   122: aload_1
    //   123: ldc_w 'getWindowLayoutInfo'
    //   126: iconst_1
    //   127: anewarray java/lang/Class
    //   130: dup
    //   131: iconst_0
    //   132: ldc_w android/os/IBinder
    //   135: aastore
    //   136: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   139: astore_1
    //   140: goto -> 632
    //   143: aload_1
    //   144: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   147: astore_1
    //   148: aload_1
    //   149: ldc_w androidx/window/sidecar/SidecarWindowLayoutInfo
    //   152: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   155: ifeq -> 575
    //   158: aload_0
    //   159: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   162: astore_1
    //   163: aload_1
    //   164: ifnonnull -> 170
    //   167: goto -> 641
    //   170: aload_1
    //   171: invokevirtual getClass : ()Ljava/lang/Class;
    //   174: astore_1
    //   175: aload_1
    //   176: ifnonnull -> 182
    //   179: goto -> 641
    //   182: aload_1
    //   183: ldc_w 'onWindowLayoutChangeListenerAdded'
    //   186: iconst_1
    //   187: anewarray java/lang/Class
    //   190: dup
    //   191: iconst_0
    //   192: ldc_w android/os/IBinder
    //   195: aastore
    //   196: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   199: astore_1
    //   200: goto -> 643
    //   203: aload_1
    //   204: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   207: astore_1
    //   208: aload_1
    //   209: getstatic java/lang/Void.TYPE : Ljava/lang/Class;
    //   212: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   215: ifeq -> 560
    //   218: aload_0
    //   219: getfield sidecar : Landroidx/window/sidecar/SidecarInterface;
    //   222: astore_1
    //   223: aload_1
    //   224: ifnonnull -> 230
    //   227: goto -> 652
    //   230: aload_1
    //   231: invokevirtual getClass : ()Ljava/lang/Class;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnonnull -> 242
    //   239: goto -> 652
    //   242: aload_1
    //   243: ldc_w 'onWindowLayoutChangeListenerRemoved'
    //   246: iconst_1
    //   247: anewarray java/lang/Class
    //   250: dup
    //   251: iconst_0
    //   252: ldc_w android/os/IBinder
    //   255: aastore
    //   256: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   259: astore_1
    //   260: goto -> 654
    //   263: aload_1
    //   264: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   267: astore_1
    //   268: aload_1
    //   269: getstatic java/lang/Void.TYPE : Ljava/lang/Class;
    //   272: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   275: ifeq -> 545
    //   278: new androidx/window/sidecar/SidecarDeviceState
    //   281: dup
    //   282: invokespecial <init> : ()V
    //   285: astore_1
    //   286: aload_1
    //   287: iconst_3
    //   288: putfield posture : I
    //   291: goto -> 364
    //   294: ldc androidx/window/sidecar/SidecarDeviceState
    //   296: ldc_w 'setPosture'
    //   299: iconst_1
    //   300: anewarray java/lang/Class
    //   303: dup
    //   304: iconst_0
    //   305: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   308: aastore
    //   309: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   312: aload_1
    //   313: iconst_1
    //   314: anewarray java/lang/Object
    //   317: dup
    //   318: iconst_0
    //   319: iconst_3
    //   320: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   323: aastore
    //   324: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   327: pop
    //   328: ldc androidx/window/sidecar/SidecarDeviceState
    //   330: ldc_w 'getPosture'
    //   333: iconst_0
    //   334: anewarray java/lang/Class
    //   337: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   340: aload_1
    //   341: iconst_0
    //   342: anewarray java/lang/Object
    //   345: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   348: astore_1
    //   349: aload_1
    //   350: ifnull -> 534
    //   353: aload_1
    //   354: checkcast java/lang/Integer
    //   357: invokevirtual intValue : ()I
    //   360: iconst_3
    //   361: if_icmpne -> 523
    //   364: new androidx/window/sidecar/SidecarDisplayFeature
    //   367: dup
    //   368: invokespecial <init> : ()V
    //   371: astore_1
    //   372: aload_1
    //   373: invokevirtual getRect : ()Landroid/graphics/Rect;
    //   376: astore_2
    //   377: aload_2
    //   378: ldc_w 'displayFeature.rect'
    //   381: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   384: aload_1
    //   385: aload_2
    //   386: invokevirtual setRect : (Landroid/graphics/Rect;)V
    //   389: aload_1
    //   390: invokevirtual getType : ()I
    //   393: pop
    //   394: aload_1
    //   395: iconst_1
    //   396: invokevirtual setType : (I)V
    //   399: new androidx/window/sidecar/SidecarWindowLayoutInfo
    //   402: dup
    //   403: invokespecial <init> : ()V
    //   406: astore_2
    //   407: aload_2
    //   408: getfield displayFeatures : Ljava/util/List;
    //   411: astore_3
    //   412: iconst_1
    //   413: ireturn
    //   414: new java/util/ArrayList
    //   417: dup
    //   418: invokespecial <init> : ()V
    //   421: astore_3
    //   422: aload_3
    //   423: aload_1
    //   424: invokeinterface add : (Ljava/lang/Object;)Z
    //   429: pop
    //   430: ldc_w androidx/window/sidecar/SidecarWindowLayoutInfo
    //   433: ldc_w 'setDisplayFeatures'
    //   436: iconst_1
    //   437: anewarray java/lang/Class
    //   440: dup
    //   441: iconst_0
    //   442: ldc_w java/util/List
    //   445: aastore
    //   446: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   449: aload_2
    //   450: iconst_1
    //   451: anewarray java/lang/Object
    //   454: dup
    //   455: iconst_0
    //   456: aload_3
    //   457: aastore
    //   458: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   461: pop
    //   462: ldc_w androidx/window/sidecar/SidecarWindowLayoutInfo
    //   465: ldc_w 'getDisplayFeatures'
    //   468: iconst_0
    //   469: anewarray java/lang/Class
    //   472: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   475: aload_2
    //   476: iconst_0
    //   477: anewarray java/lang/Object
    //   480: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   483: astore_1
    //   484: aload_1
    //   485: ifnull -> 512
    //   488: aload_3
    //   489: aload_1
    //   490: checkcast java/util/List
    //   493: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   496: ifeq -> 501
    //   499: iconst_1
    //   500: ireturn
    //   501: new java/lang/Exception
    //   504: dup
    //   505: ldc_w 'Invalid display feature getter/setter'
    //   508: invokespecial <init> : (Ljava/lang/String;)V
    //   511: athrow
    //   512: new java/lang/NullPointerException
    //   515: dup
    //   516: ldc_w 'null cannot be cast to non-null type kotlin.collections.List<androidx.window.sidecar.SidecarDisplayFeature>'
    //   519: invokespecial <init> : (Ljava/lang/String;)V
    //   522: athrow
    //   523: new java/lang/Exception
    //   526: dup
    //   527: ldc_w 'Invalid device posture getter/setter'
    //   530: invokespecial <init> : (Ljava/lang/String;)V
    //   533: athrow
    //   534: new java/lang/NullPointerException
    //   537: dup
    //   538: ldc_w 'null cannot be cast to non-null type kotlin.Int'
    //   541: invokespecial <init> : (Ljava/lang/String;)V
    //   544: athrow
    //   545: new java/lang/NoSuchMethodException
    //   548: dup
    //   549: ldc_w 'Illegal return type for 'onWindowLayoutChangeListenerRemoved': '
    //   552: aload_1
    //   553: invokestatic m : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   556: invokespecial <init> : (Ljava/lang/String;)V
    //   559: athrow
    //   560: new java/lang/NoSuchMethodException
    //   563: dup
    //   564: ldc_w 'Illegal return type for 'onWindowLayoutChangeListenerAdded': '
    //   567: aload_1
    //   568: invokestatic m : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   571: invokespecial <init> : (Ljava/lang/String;)V
    //   574: athrow
    //   575: new java/lang/NoSuchMethodException
    //   578: dup
    //   579: ldc_w 'Illegal return type for 'getWindowLayoutInfo': '
    //   582: aload_1
    //   583: invokestatic m : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   586: invokespecial <init> : (Ljava/lang/String;)V
    //   589: athrow
    //   590: new java/lang/NoSuchMethodException
    //   593: dup
    //   594: ldc_w 'Illegal return type for 'setSidecarCallback': '
    //   597: aload_1
    //   598: invokestatic m : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   601: invokespecial <init> : (Ljava/lang/String;)V
    //   604: athrow
    //   605: iconst_0
    //   606: ireturn
    //   607: astore_1
    //   608: goto -> 605
    //   611: astore_2
    //   612: goto -> 294
    //   615: astore_3
    //   616: goto -> 414
    //   619: aconst_null
    //   620: astore_1
    //   621: aload_1
    //   622: ifnonnull -> 45
    //   625: aconst_null
    //   626: astore_1
    //   627: goto -> 50
    //   630: aconst_null
    //   631: astore_1
    //   632: aload_1
    //   633: ifnonnull -> 143
    //   636: aconst_null
    //   637: astore_1
    //   638: goto -> 148
    //   641: aconst_null
    //   642: astore_1
    //   643: aload_1
    //   644: ifnonnull -> 203
    //   647: aconst_null
    //   648: astore_1
    //   649: goto -> 208
    //   652: aconst_null
    //   653: astore_1
    //   654: aload_1
    //   655: ifnonnull -> 263
    //   658: aload_2
    //   659: astore_1
    //   660: goto -> 268
    // Exception table:
    //   from	to	target	type
    //   0	5	607	finally
    //   14	19	607	finally
    //   26	42	607	finally
    //   45	50	607	finally
    //   50	65	607	finally
    //   72	79	607	finally
    //   79	84	607	finally
    //   91	98	607	finally
    //   98	103	607	finally
    //   110	115	607	finally
    //   122	140	607	finally
    //   143	148	607	finally
    //   148	163	607	finally
    //   170	175	607	finally
    //   182	200	607	finally
    //   203	208	607	finally
    //   208	223	607	finally
    //   230	235	607	finally
    //   242	260	607	finally
    //   263	268	607	finally
    //   268	286	607	finally
    //   286	291	611	java/lang/NoSuchFieldError
    //   286	291	607	finally
    //   294	349	607	finally
    //   353	364	607	finally
    //   364	407	607	finally
    //   407	412	615	java/lang/NoSuchFieldError
    //   407	412	607	finally
    //   414	484	607	finally
    //   488	499	607	finally
    //   501	512	607	finally
    //   512	523	607	finally
    //   523	534	607	finally
    //   534	545	607	finally
    //   545	560	607	finally
    //   560	575	607	finally
    //   575	590	607	finally
    //   590	605	607	finally
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final IBinder getActivityWindowToken$window_release(Activity param1Activity) {
      if (param1Activity == null)
        return null; 
      Window window = param1Activity.getWindow();
      if (window == null)
        return null; 
      WindowManager.LayoutParams layoutParams = window.getAttributes();
      return (layoutParams == null) ? null : layoutParams.token;
    }
    
    public final Version getSidecarVersion() {
      Version version = null;
      try {
        String str = SidecarProvider.getApiVersion();
        if (!TextUtils.isEmpty(str))
          version = Version.Companion.parse(str); 
        return version;
      } catch (NoClassDefFoundError|UnsupportedOperationException noClassDefFoundError) {
        return null;
      } 
    }
  }
  
  private static final class DistinctElementCallback implements ExtensionInterfaceCompat.ExtensionCallbackInterface {
    private final WeakHashMap<Activity, WindowLayoutInfo> activityWindowLayoutInfo;
    
    private final ExtensionInterfaceCompat.ExtensionCallbackInterface callbackInterface;
    
    private final ReentrantLock lock;
    
    public DistinctElementCallback(ExtensionInterfaceCompat.ExtensionCallbackInterface param1ExtensionCallbackInterface) {
      this.callbackInterface = param1ExtensionCallbackInterface;
      this.lock = new ReentrantLock();
      this.activityWindowLayoutInfo = new WeakHashMap<Activity, WindowLayoutInfo>();
    }
    
    public void onWindowLayoutChanged(Activity param1Activity, WindowLayoutInfo param1WindowLayoutInfo) {
      l.f(param1Activity, "activity");
      l.f(param1WindowLayoutInfo, "newLayout");
      ReentrantLock reentrantLock = this.lock;
      reentrantLock.lock();
      try {
        boolean bool = l.b(param1WindowLayoutInfo, this.activityWindowLayoutInfo.get(param1Activity));
        if (bool)
          return; 
        WindowLayoutInfo windowLayoutInfo = this.activityWindowLayoutInfo.put(param1Activity, param1WindowLayoutInfo);
        reentrantLock.unlock();
        return;
      } finally {
        reentrantLock.unlock();
      } 
    }
  }
  
  private static final class DistinctSidecarElementCallback implements SidecarInterface.SidecarCallback {
    private final SidecarInterface.SidecarCallback callbackInterface;
    
    private SidecarDeviceState lastDeviceState;
    
    private final ReentrantLock lock;
    
    private final WeakHashMap<IBinder, SidecarWindowLayoutInfo> mActivityWindowLayoutInfo;
    
    private final SidecarAdapter sidecarAdapter;
    
    public DistinctSidecarElementCallback(SidecarAdapter param1SidecarAdapter, SidecarInterface.SidecarCallback param1SidecarCallback) {
      this.sidecarAdapter = param1SidecarAdapter;
      this.callbackInterface = param1SidecarCallback;
      this.lock = new ReentrantLock();
      this.mActivityWindowLayoutInfo = new WeakHashMap<IBinder, SidecarWindowLayoutInfo>();
    }
    
    public void onDeviceStateChanged(SidecarDeviceState param1SidecarDeviceState) {
      l.f(param1SidecarDeviceState, "newDeviceState");
      ReentrantLock reentrantLock = this.lock;
      reentrantLock.lock();
      try {
        boolean bool = this.sidecarAdapter.isEqualSidecarDeviceState(this.lastDeviceState, param1SidecarDeviceState);
        if (bool)
          return; 
        this.lastDeviceState = param1SidecarDeviceState;
        this.callbackInterface.onDeviceStateChanged(param1SidecarDeviceState);
        u u = u.a;
        return;
      } finally {
        reentrantLock.unlock();
      } 
    }
    
    public void onWindowLayoutChanged(IBinder param1IBinder, SidecarWindowLayoutInfo param1SidecarWindowLayoutInfo) {
      l.f(param1IBinder, "token");
      l.f(param1SidecarWindowLayoutInfo, "newLayout");
      synchronized (this.lock) {
        SidecarWindowLayoutInfo sidecarWindowLayoutInfo = this.mActivityWindowLayoutInfo.get(param1IBinder);
        boolean bool = this.sidecarAdapter.isEqualSidecarWindowLayoutInfo(sidecarWindowLayoutInfo, param1SidecarWindowLayoutInfo);
        if (bool)
          return; 
        sidecarWindowLayoutInfo = this.mActivityWindowLayoutInfo.put(param1IBinder, param1SidecarWindowLayoutInfo);
        this.callbackInterface.onWindowLayoutChanged(param1IBinder, param1SidecarWindowLayoutInfo);
        return;
      } 
    }
  }
  
  private static final class FirstAttachAdapter implements View.OnAttachStateChangeListener {
    private final WeakReference<Activity> activityWeakReference;
    
    private final SidecarCompat sidecarCompat;
    
    public FirstAttachAdapter(SidecarCompat param1SidecarCompat, Activity param1Activity) {
      this.sidecarCompat = param1SidecarCompat;
      this.activityWeakReference = new WeakReference<Activity>(param1Activity);
    }
    
    public void onViewAttachedToWindow(View param1View) {
      l.f(param1View, "view");
      param1View.removeOnAttachStateChangeListener(this);
      Activity activity = this.activityWeakReference.get();
      IBinder iBinder = SidecarCompat.Companion.getActivityWindowToken$window_release(activity);
      if (activity == null)
        return; 
      if (iBinder == null)
        return; 
      this.sidecarCompat.register(iBinder, activity);
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      l.f(param1View, "view");
    }
  }
  
  public final class TranslatingCallback implements SidecarInterface.SidecarCallback {
    public void onDeviceStateChanged(SidecarDeviceState param1SidecarDeviceState) {
      l.f(param1SidecarDeviceState, "newDeviceState");
      Collection collection = SidecarCompat.this.windowListenerRegisteredContexts.values();
      SidecarCompat sidecarCompat = SidecarCompat.this;
      for (Activity activity : collection) {
        SidecarWindowLayoutInfo sidecarWindowLayoutInfo;
        IBinder iBinder = SidecarCompat.Companion.getActivityWindowToken$window_release(activity);
        collection = null;
        if (iBinder != null) {
          SidecarInterface sidecarInterface = sidecarCompat.getSidecar();
          if (sidecarInterface != null)
            sidecarWindowLayoutInfo = sidecarInterface.getWindowLayoutInfo(iBinder); 
        } 
        ExtensionInterfaceCompat.ExtensionCallbackInterface extensionCallbackInterface = sidecarCompat.extensionCallback;
        if (extensionCallbackInterface == null)
          continue; 
        extensionCallbackInterface.onWindowLayoutChanged(activity, sidecarCompat.sidecarAdapter.translate(sidecarWindowLayoutInfo, param1SidecarDeviceState));
      } 
    }
    
    public void onWindowLayoutChanged(IBinder param1IBinder, SidecarWindowLayoutInfo param1SidecarWindowLayoutInfo) {
      SidecarDeviceState sidecarDeviceState1;
      l.f(param1IBinder, "windowToken");
      l.f(param1SidecarWindowLayoutInfo, "newLayout");
      Activity activity = (Activity)SidecarCompat.this.windowListenerRegisteredContexts.get(param1IBinder);
      if (activity == null) {
        Log.w("SidecarCompat", "Unable to resolve activity from window token. Missing a call to #onWindowLayoutChangeListenerAdded()?");
        return;
      } 
      SidecarAdapter sidecarAdapter = SidecarCompat.this.sidecarAdapter;
      SidecarInterface sidecarInterface = SidecarCompat.this.getSidecar();
      if (sidecarInterface == null) {
        sidecarInterface = null;
      } else {
        sidecarDeviceState1 = sidecarInterface.getDeviceState();
      } 
      SidecarDeviceState sidecarDeviceState2 = sidecarDeviceState1;
      if (sidecarDeviceState1 == null)
        sidecarDeviceState2 = new SidecarDeviceState(); 
      WindowLayoutInfo windowLayoutInfo = sidecarAdapter.translate(param1SidecarWindowLayoutInfo, sidecarDeviceState2);
      ExtensionInterfaceCompat.ExtensionCallbackInterface extensionCallbackInterface = SidecarCompat.this.extensionCallback;
      if (extensionCallbackInterface == null)
        return; 
      extensionCallbackInterface.onWindowLayoutChanged(activity, windowLayoutInfo);
    }
  }
  
  public static final class SidecarCompat$registerConfigurationChangeListener$configChangeObserver$1 implements ComponentCallbacks {
    SidecarCompat$registerConfigurationChangeListener$configChangeObserver$1(Activity param1Activity) {}
    
    public void onConfigurationChanged(Configuration param1Configuration) {
      l.f(param1Configuration, "newConfig");
      ExtensionInterfaceCompat.ExtensionCallbackInterface extensionCallbackInterface = SidecarCompat.this.extensionCallback;
      if (extensionCallbackInterface == null)
        return; 
      Activity activity = this.$activity;
      extensionCallbackInterface.onWindowLayoutChanged(activity, SidecarCompat.this.getWindowLayoutInfo(activity));
    }
    
    public void onLowMemory() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\SidecarCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */