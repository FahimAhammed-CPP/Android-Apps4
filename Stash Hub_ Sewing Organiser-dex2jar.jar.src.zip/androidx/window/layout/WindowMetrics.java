package androidx.window.layout;

import android.graphics.Rect;
import androidx.window.core.Bounds;
import kotlin.jvm.internal.l;

public final class WindowMetrics {
  private final Bounds _bounds;
  
  public WindowMetrics(Rect paramRect) {
    this(new Bounds(paramRect));
  }
  
  public WindowMetrics(Bounds paramBounds) {
    this._bounds = paramBounds;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || !l.b(WindowMetrics.class, paramObject.getClass()))
      return false; 
    paramObject = paramObject;
    return l.b(this._bounds, ((WindowMetrics)paramObject)._bounds);
  }
  
  public final Rect getBounds() {
    return this._bounds.toRect();
  }
  
  public int hashCode() {
    return this._bounds.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("WindowMetrics { bounds: ");
    stringBuilder.append(getBounds());
    stringBuilder.append(" }");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowMetrics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */