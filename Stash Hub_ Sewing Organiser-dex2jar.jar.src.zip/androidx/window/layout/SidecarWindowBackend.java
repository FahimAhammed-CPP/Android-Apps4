package androidx.window.layout;

import android.app.Activity;
import android.content.Context;
import androidx.core.util.a;
import androidx.window.core.Version;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import o7.u;
import p7.m;

public final class SidecarWindowBackend implements WindowBackend {
  public static final Companion Companion = new Companion(null);
  
  public static final boolean DEBUG = false;
  
  private static final String TAG = "WindowServer";
  
  private static volatile SidecarWindowBackend globalInstance;
  
  private static final ReentrantLock globalLock = new ReentrantLock();
  
  private ExtensionInterfaceCompat windowExtension;
  
  private final CopyOnWriteArrayList<WindowLayoutChangeCallbackWrapper> windowLayoutChangeCallbacks;
  
  public SidecarWindowBackend(ExtensionInterfaceCompat paramExtensionInterfaceCompat) {
    this.windowExtension = paramExtensionInterfaceCompat;
    this.windowLayoutChangeCallbacks = new CopyOnWriteArrayList<WindowLayoutChangeCallbackWrapper>();
    paramExtensionInterfaceCompat = this.windowExtension;
    if (paramExtensionInterfaceCompat == null)
      return; 
    paramExtensionInterfaceCompat.setExtensionCallback(new ExtensionListenerImpl());
  }
  
  private final void callbackRemovedForActivity(Activity paramActivity) {
    boolean bool1;
    CopyOnWriteArrayList<WindowLayoutChangeCallbackWrapper> copyOnWriteArrayList = this.windowLayoutChangeCallbacks;
    boolean bool = copyOnWriteArrayList instanceof java.util.Collection;
    boolean bool2 = false;
    if (bool && copyOnWriteArrayList.isEmpty()) {
      bool1 = bool2;
    } else {
      Iterator<WindowLayoutChangeCallbackWrapper> iterator = copyOnWriteArrayList.iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          if (l.b(((WindowLayoutChangeCallbackWrapper)iterator.next()).getActivity(), paramActivity)) {
            bool1 = true;
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    if (bool1)
      return; 
    ExtensionInterfaceCompat extensionInterfaceCompat = this.windowExtension;
    if (extensionInterfaceCompat == null)
      return; 
    extensionInterfaceCompat.onWindowLayoutChangeListenerRemoved(paramActivity);
  }
  
  private final boolean isActivityRegistered(Activity paramActivity) {
    CopyOnWriteArrayList<WindowLayoutChangeCallbackWrapper> copyOnWriteArrayList = this.windowLayoutChangeCallbacks;
    boolean bool = copyOnWriteArrayList instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && copyOnWriteArrayList.isEmpty())
      return false; 
    Iterator<WindowLayoutChangeCallbackWrapper> iterator = copyOnWriteArrayList.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (l.b(((WindowLayoutChangeCallbackWrapper)iterator.next()).getActivity(), paramActivity)) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final ExtensionInterfaceCompat getWindowExtension() {
    return this.windowExtension;
  }
  
  public final CopyOnWriteArrayList<WindowLayoutChangeCallbackWrapper> getWindowLayoutChangeCallbacks() {
    return this.windowLayoutChangeCallbacks;
  }
  
  public void registerLayoutChangeCallback(Activity paramActivity, Executor paramExecutor, a<WindowLayoutInfo> parama) {
    l.f(paramActivity, "activity");
    l.f(paramExecutor, "executor");
    l.f(parama, "callback");
    ReentrantLock reentrantLock = globalLock;
    reentrantLock.lock();
    try {
      ExtensionInterfaceCompat extensionInterfaceCompat = getWindowExtension();
      if (extensionInterfaceCompat == null) {
        parama.accept(new WindowLayoutInfo(m.d()));
        return;
      } 
      boolean bool = isActivityRegistered(paramActivity);
      WindowLayoutChangeCallbackWrapper windowLayoutChangeCallbackWrapper = new WindowLayoutChangeCallbackWrapper(paramActivity, paramExecutor, parama);
      getWindowLayoutChangeCallbacks().add(windowLayoutChangeCallbackWrapper);
      if (!bool) {
        extensionInterfaceCompat.onWindowLayoutChangeListenerAdded(paramActivity);
      } else {
        Iterator<WindowLayoutChangeCallbackWrapper> iterator = getWindowLayoutChangeCallbacks().iterator();
        while (true) {
          Executor executor;
          WindowLayoutInfo windowLayoutInfo;
          bool = iterator.hasNext();
          paramExecutor = null;
          if (bool) {
            parama = (a<WindowLayoutInfo>)iterator.next();
            if (l.b(paramActivity, ((WindowLayoutChangeCallbackWrapper)parama).getActivity())) {
              a<WindowLayoutInfo> a1 = parama;
            } else {
              continue;
            } 
          } else {
            paramActivity = null;
          } 
          WindowLayoutChangeCallbackWrapper windowLayoutChangeCallbackWrapper1 = (WindowLayoutChangeCallbackWrapper)paramActivity;
          if (windowLayoutChangeCallbackWrapper1 == null) {
            executor = paramExecutor;
          } else {
            windowLayoutInfo = executor.getLastInfo();
          } 
          if (windowLayoutInfo != null)
            windowLayoutChangeCallbackWrapper.accept(windowLayoutInfo); 
          u u1 = u.a;
          return;
        } 
      } 
      u u = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void setWindowExtension(ExtensionInterfaceCompat paramExtensionInterfaceCompat) {
    this.windowExtension = paramExtensionInterfaceCompat;
  }
  
  public void unregisterLayoutChangeCallback(a<WindowLayoutInfo> parama) {
    l.f(parama, "callback");
    synchronized (globalLock) {
      ExtensionInterfaceCompat extensionInterfaceCompat = getWindowExtension();
      if (extensionInterfaceCompat == null)
        return; 
      ArrayList<WindowLayoutChangeCallbackWrapper> arrayList = new ArrayList();
      for (WindowLayoutChangeCallbackWrapper windowLayoutChangeCallbackWrapper : getWindowLayoutChangeCallbacks()) {
        if (windowLayoutChangeCallbackWrapper.getCallback() == parama) {
          l.e(windowLayoutChangeCallbackWrapper, "callbackWrapper");
          arrayList.add(windowLayoutChangeCallbackWrapper);
        } 
      } 
      getWindowLayoutChangeCallbacks().removeAll(arrayList);
      Iterator<WindowLayoutChangeCallbackWrapper> iterator = arrayList.iterator();
      while (iterator.hasNext())
        callbackRemovedForActivity(((WindowLayoutChangeCallbackWrapper)iterator.next()).getActivity()); 
      u u = u.a;
      return;
    } 
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final SidecarWindowBackend getInstance(Context param1Context) {
      l.f(param1Context, "context");
      if (SidecarWindowBackend.globalInstance == null) {
        ReentrantLock reentrantLock = SidecarWindowBackend.globalLock;
        reentrantLock.lock();
        try {
          if (SidecarWindowBackend.globalInstance == null)
            SidecarWindowBackend.globalInstance = new SidecarWindowBackend(SidecarWindowBackend.Companion.initAndVerifyExtension(param1Context)); 
          u u = u.a;
        } finally {
          reentrantLock.unlock();
        } 
      } 
      SidecarWindowBackend sidecarWindowBackend = SidecarWindowBackend.globalInstance;
      l.c(sidecarWindowBackend);
      return sidecarWindowBackend;
    }
    
    public final ExtensionInterfaceCompat initAndVerifyExtension(Context param1Context) {
      l.f(param1Context, "context");
      SidecarCompat sidecarCompat = null;
      try {
        return sidecarCompat;
      } finally {
        param1Context = null;
      } 
    }
    
    public final boolean isSidecarVersionSupported(Version param1Version) {
      boolean bool = false;
      if (param1Version == null)
        return false; 
      if (param1Version.compareTo(Version.Companion.getVERSION_0_1()) >= 0)
        bool = true; 
      return bool;
    }
    
    public final void resetInstance() {
      SidecarWindowBackend.globalInstance = null;
    }
  }
  
  public final class ExtensionListenerImpl implements ExtensionInterfaceCompat.ExtensionCallbackInterface {
    public void onWindowLayoutChanged(Activity param1Activity, WindowLayoutInfo param1WindowLayoutInfo) {
      l.f(param1Activity, "activity");
      l.f(param1WindowLayoutInfo, "newLayout");
      for (SidecarWindowBackend.WindowLayoutChangeCallbackWrapper windowLayoutChangeCallbackWrapper : SidecarWindowBackend.this.getWindowLayoutChangeCallbacks()) {
        if (!l.b(windowLayoutChangeCallbackWrapper.getActivity(), param1Activity))
          continue; 
        windowLayoutChangeCallbackWrapper.accept(param1WindowLayoutInfo);
      } 
    }
  }
  
  public static final class WindowLayoutChangeCallbackWrapper {
    private final Activity activity;
    
    private final a<WindowLayoutInfo> callback;
    
    private final Executor executor;
    
    private WindowLayoutInfo lastInfo;
    
    public WindowLayoutChangeCallbackWrapper(Activity param1Activity, Executor param1Executor, a<WindowLayoutInfo> param1a) {
      this.activity = param1Activity;
      this.executor = param1Executor;
      this.callback = param1a;
    }
    
    private static final void accept$lambda-0(WindowLayoutChangeCallbackWrapper param1WindowLayoutChangeCallbackWrapper, WindowLayoutInfo param1WindowLayoutInfo) {
      l.f(param1WindowLayoutChangeCallbackWrapper, "this$0");
      l.f(param1WindowLayoutInfo, "$newLayoutInfo");
      param1WindowLayoutChangeCallbackWrapper.getCallback().accept(param1WindowLayoutInfo);
    }
    
    public final void accept(WindowLayoutInfo param1WindowLayoutInfo) {
      l.f(param1WindowLayoutInfo, "newLayoutInfo");
      this.lastInfo = param1WindowLayoutInfo;
      this.executor.execute(new a(this, param1WindowLayoutInfo));
    }
    
    public final Activity getActivity() {
      return this.activity;
    }
    
    public final a<WindowLayoutInfo> getCallback() {
      return this.callback;
    }
    
    public final WindowLayoutInfo getLastInfo() {
      return this.lastInfo;
    }
    
    public final void setLastInfo(WindowLayoutInfo param1WindowLayoutInfo) {
      this.lastInfo = param1WindowLayoutInfo;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\SidecarWindowBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */