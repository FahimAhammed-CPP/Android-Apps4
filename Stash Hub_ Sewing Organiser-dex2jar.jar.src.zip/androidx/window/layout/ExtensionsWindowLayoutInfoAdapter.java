package androidx.window.layout;

import android.app.Activity;
import android.graphics.Rect;
import androidx.window.core.Bounds;
import androidx.window.extensions.layout.DisplayFeature;
import androidx.window.extensions.layout.FoldingFeature;
import androidx.window.extensions.layout.WindowLayoutInfo;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;

public final class ExtensionsWindowLayoutInfoAdapter {
  public static final ExtensionsWindowLayoutInfoAdapter INSTANCE = new ExtensionsWindowLayoutInfoAdapter();
  
  private final boolean validBounds(Activity paramActivity, Bounds paramBounds) {
    Rect rect = WindowMetricsCalculatorCompat.INSTANCE.computeCurrentWindowMetrics(paramActivity).getBounds();
    return paramBounds.isZero() ? false : ((paramBounds.getWidth() != rect.width() && paramBounds.getHeight() != rect.height()) ? false : ((paramBounds.getWidth() < rect.width() && paramBounds.getHeight() < rect.height()) ? false : (!(paramBounds.getWidth() == rect.width() && paramBounds.getHeight() == rect.height()))));
  }
  
  public final FoldingFeature translate$window_release(Activity paramActivity, FoldingFeature paramFoldingFeature) {
    HardwareFoldingFeature.Type type;
    FoldingFeature.State state;
    l.f(paramActivity, "activity");
    l.f(paramFoldingFeature, "oemFeature");
    int i = paramFoldingFeature.getType();
    HardwareFoldingFeature hardwareFoldingFeature = null;
    if (i != 1) {
      if (i != 2)
        return null; 
      type = HardwareFoldingFeature.Type.Companion.getHINGE();
    } else {
      type = HardwareFoldingFeature.Type.Companion.getFOLD();
    } 
    i = paramFoldingFeature.getState();
    if (i != 1) {
      if (i != 2)
        return null; 
      state = FoldingFeature.State.HALF_OPENED;
    } else {
      state = FoldingFeature.State.FLAT;
    } 
    Rect rect = paramFoldingFeature.getBounds();
    l.e(rect, "oemFeature.bounds");
    if (validBounds(paramActivity, new Bounds(rect))) {
      Rect rect1 = paramFoldingFeature.getBounds();
      l.e(rect1, "oemFeature.bounds");
      hardwareFoldingFeature = new HardwareFoldingFeature(new Bounds(rect1), type, state);
    } 
    return hardwareFoldingFeature;
  }
  
  public final WindowLayoutInfo translate$window_release(Activity paramActivity, WindowLayoutInfo paramWindowLayoutInfo) {
    l.f(paramActivity, "activity");
    l.f(paramWindowLayoutInfo, "info");
    List list = paramWindowLayoutInfo.getDisplayFeatures();
    l.e(list, "info.displayFeatures");
    ArrayList<DisplayFeature> arrayList = new ArrayList();
    for (DisplayFeature displayFeature : list) {
      if (displayFeature instanceof FoldingFeature) {
        ExtensionsWindowLayoutInfoAdapter extensionsWindowLayoutInfoAdapter = INSTANCE;
        l.e(displayFeature, "feature");
        FoldingFeature foldingFeature = extensionsWindowLayoutInfoAdapter.translate$window_release(paramActivity, (FoldingFeature)displayFeature);
      } else {
        displayFeature = null;
      } 
      if (displayFeature != null)
        arrayList.add(displayFeature); 
    } 
    return new WindowLayoutInfo((List)arrayList);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\ExtensionsWindowLayoutInfoAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */