package androidx.window.layout;

import android.view.DisplayCutout;
import kotlin.jvm.internal.l;

public final class DisplayCompatHelperApi28 {
  public static final DisplayCompatHelperApi28 INSTANCE = new DisplayCompatHelperApi28();
  
  public final int safeInsetBottom(DisplayCutout paramDisplayCutout) {
    l.f(paramDisplayCutout, "displayCutout");
    return paramDisplayCutout.getSafeInsetBottom();
  }
  
  public final int safeInsetLeft(DisplayCutout paramDisplayCutout) {
    l.f(paramDisplayCutout, "displayCutout");
    return paramDisplayCutout.getSafeInsetLeft();
  }
  
  public final int safeInsetRight(DisplayCutout paramDisplayCutout) {
    l.f(paramDisplayCutout, "displayCutout");
    return paramDisplayCutout.getSafeInsetRight();
  }
  
  public final int safeInsetTop(DisplayCutout paramDisplayCutout) {
    l.f(paramDisplayCutout, "displayCutout");
    return paramDisplayCutout.getSafeInsetTop();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\DisplayCompatHelperApi28.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */