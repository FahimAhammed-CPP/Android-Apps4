package androidx.window.layout;

import android.graphics.Point;
import android.view.Display;
import kotlin.jvm.internal.l;

public final class DisplayCompatHelperApi17 {
  public static final DisplayCompatHelperApi17 INSTANCE = new DisplayCompatHelperApi17();
  
  public final void getRealSize(Display paramDisplay, Point paramPoint) {
    l.f(paramDisplay, "display");
    l.f(paramPoint, "point");
    paramDisplay.getRealSize(paramPoint);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\DisplayCompatHelperApi17.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */