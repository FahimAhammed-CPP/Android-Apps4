package androidx.window.layout;

import android.app.Activity;
import android.graphics.Rect;
import kotlin.jvm.internal.l;

public final class ActivityCompatHelperApi30 {
  public static final ActivityCompatHelperApi30 INSTANCE = new ActivityCompatHelperApi30();
  
  public final Rect currentWindowBounds(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Rect rect = paramActivity.getWindowManager().getCurrentWindowMetrics().getBounds();
    l.e(rect, "activity.windowManager.currentWindowMetrics.bounds");
    return rect;
  }
  
  public final Rect maximumWindowBounds(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Rect rect = paramActivity.getWindowManager().getMaximumWindowMetrics().getBounds();
    l.e(rect, "activity.windowManager.maximumWindowMetrics.bounds");
    return rect;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\ActivityCompatHelperApi30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */