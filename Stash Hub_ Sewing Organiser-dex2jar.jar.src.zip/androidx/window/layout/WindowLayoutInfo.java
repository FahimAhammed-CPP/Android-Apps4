package androidx.window.layout;

import java.util.List;
import kotlin.jvm.internal.l;
import p7.m;

public final class WindowLayoutInfo {
  private final List<DisplayFeature> displayFeatures;
  
  public WindowLayoutInfo(List<? extends DisplayFeature> paramList) {
    this.displayFeatures = (List)paramList;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || !l.b(WindowLayoutInfo.class, paramObject.getClass()))
      return false; 
    paramObject = paramObject;
    return l.b(this.displayFeatures, ((WindowLayoutInfo)paramObject).displayFeatures);
  }
  
  public final List<DisplayFeature> getDisplayFeatures() {
    return this.displayFeatures;
  }
  
  public int hashCode() {
    return this.displayFeatures.hashCode();
  }
  
  public String toString() {
    return m.z(this.displayFeatures, ", ", "WindowLayoutInfo{ DisplayFeatures[", "] }", 0, null, null, 56, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowLayoutInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */