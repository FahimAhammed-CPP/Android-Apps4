package androidx.window.layout;

import kotlin.jvm.internal.h;

public interface FoldingFeature extends DisplayFeature {
  OcclusionType getOcclusionType();
  
  Orientation getOrientation();
  
  State getState();
  
  boolean isSeparating();
  
  public static final class OcclusionType {
    public static final Companion Companion = new Companion(null);
    
    public static final OcclusionType FULL = new OcclusionType("FULL");
    
    public static final OcclusionType NONE = new OcclusionType("NONE");
    
    private final String description;
    
    static {
    
    }
    
    private OcclusionType(String param1String) {
      this.description = param1String;
    }
    
    public String toString() {
      return this.description;
    }
    
    public static final class Companion {
      private Companion() {}
    }
  }
  
  public static final class Companion {
    private Companion() {}
  }
  
  public static final class Orientation {
    public static final Companion Companion = new Companion(null);
    
    public static final Orientation HORIZONTAL = new Orientation("HORIZONTAL");
    
    public static final Orientation VERTICAL = new Orientation("VERTICAL");
    
    private final String description;
    
    static {
    
    }
    
    private Orientation(String param1String) {
      this.description = param1String;
    }
    
    public String toString() {
      return this.description;
    }
    
    public static final class Companion {
      private Companion() {}
    }
  }
  
  public static final class Companion {
    private Companion() {}
  }
  
  public static final class State {
    public static final Companion Companion = new Companion(null);
    
    public static final State FLAT = new State("FLAT");
    
    public static final State HALF_OPENED = new State("HALF_OPENED");
    
    private final String description;
    
    private State(String param1String) {
      this.description = param1String;
    }
    
    public String toString() {
      return this.description;
    }
    
    public static final class Companion {
      private Companion() {}
    }
  }
  
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\FoldingFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */