package androidx.window.layout;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.Display;
import android.view.DisplayCutout;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import kotlin.jvm.internal.l;

public final class WindowMetricsCalculatorCompat implements WindowMetricsCalculator {
  public static final WindowMetricsCalculatorCompat INSTANCE = new WindowMetricsCalculatorCompat();
  
  private static final String TAG;
  
  static {
    String str = WindowMetricsCalculatorCompat.class.getSimpleName();
    l.e(str, "WindowMetricsCalculatorC…at::class.java.simpleName");
    TAG = str;
  }
  
  private final DisplayCutout getCutoutForDisplay(Display paramDisplay) {
    try {
      Constructor<?> constructor = Class.forName("android.view.DisplayInfo").getConstructor(new Class[0]);
      constructor.setAccessible(true);
      constructor = (Constructor<?>)constructor.newInstance(new Object[0]);
      Method method = paramDisplay.getClass().getDeclaredMethod("getDisplayInfo", new Class[] { constructor.getClass() });
      method.setAccessible(true);
      method.invoke(paramDisplay, new Object[] { constructor });
      Field field = constructor.getClass().getDeclaredField("displayCutout");
      field.setAccessible(true);
      Object object = field.get(constructor);
      if (object instanceof DisplayCutout)
        return (DisplayCutout)object; 
    } catch (ClassNotFoundException classNotFoundException) {
      Log.w(TAG, classNotFoundException);
    } catch (NoSuchMethodException noSuchMethodException) {
    
    } catch (NoSuchFieldException noSuchFieldException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {
    
    } catch (InstantiationException instantiationException) {}
    return null;
  }
  
  private final int getNavigationBarHeight(Context paramContext) {
    Resources resources = paramContext.getResources();
    int i = resources.getIdentifier("navigation_bar_height", "dimen", "android");
    return (i > 0) ? resources.getDimensionPixelSize(i) : 0;
  }
  
  private final void getRectSizeFromDisplay(Activity paramActivity, Rect paramRect) {
    paramActivity.getWindowManager().getDefaultDisplay().getRectSize(paramRect);
  }
  
  public WindowMetrics computeCurrentWindowMetrics(Activity paramActivity) {
    Rect rect;
    l.f(paramActivity, "activity");
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      rect = ActivityCompatHelperApi30.INSTANCE.currentWindowBounds(paramActivity);
    } else if (i >= 29) {
      rect = computeWindowBoundsQ$window_release((Activity)rect);
    } else if (i >= 28) {
      rect = computeWindowBoundsP$window_release((Activity)rect);
    } else if (i >= 24) {
      rect = computeWindowBoundsN$window_release((Activity)rect);
    } else {
      rect = computeWindowBoundsIceCreamSandwich$window_release((Activity)rect);
    } 
    return new WindowMetrics(rect);
  }
  
  public WindowMetrics computeMaximumWindowMetrics(Activity paramActivity) {
    Rect rect;
    l.f(paramActivity, "activity");
    if (Build.VERSION.SDK_INT >= 30) {
      rect = ActivityCompatHelperApi30.INSTANCE.maximumWindowBounds(paramActivity);
    } else {
      Display display = rect.getWindowManager().getDefaultDisplay();
      l.e(display, "display");
      Point point = getRealSizeForDisplay$window_release(display);
      rect = new Rect(0, 0, point.x, point.y);
    } 
    return new WindowMetrics(rect);
  }
  
  public final Rect computeWindowBoundsIceCreamSandwich$window_release(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Display display = paramActivity.getWindowManager().getDefaultDisplay();
    l.e(display, "defaultDisplay");
    Point point = getRealSizeForDisplay$window_release(display);
    Rect rect = new Rect();
    int i = point.x;
    if (i != 0) {
      int j = point.y;
      if (j != 0) {
        rect.right = i;
        rect.bottom = j;
        return rect;
      } 
    } 
    display.getRectSize(rect);
    return rect;
  }
  
  public final Rect computeWindowBoundsN$window_release(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Rect rect = new Rect();
    Display display = paramActivity.getWindowManager().getDefaultDisplay();
    display.getRectSize(rect);
    if (!ActivityCompatHelperApi24.INSTANCE.isInMultiWindowMode(paramActivity)) {
      l.e(display, "defaultDisplay");
      Point point = getRealSizeForDisplay$window_release(display);
      int i = getNavigationBarHeight((Context)paramActivity);
      int j = rect.bottom;
      if (j + i == point.y) {
        rect.bottom = j + i;
        return rect;
      } 
      j = rect.right;
      if (j + i == point.x)
        rect.right = j + i; 
    } 
    return rect;
  }
  
  public final Rect computeWindowBoundsP$window_release(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Rect rect = new Rect();
    Configuration configuration = paramActivity.getResources().getConfiguration();
    try {
      Field field = Configuration.class.getDeclaredField("windowConfiguration");
      field.setAccessible(true);
      Object object = field.get(configuration);
      boolean bool = ActivityCompatHelperApi24.INSTANCE.isInMultiWindowMode(paramActivity);
      if (bool) {
        object = object.getClass().getDeclaredMethod("getBounds", new Class[0]).invoke(object, new Object[0]);
        if (object != null) {
          object = object;
        } else {
          throw new NullPointerException("null cannot be cast to non-null type android.graphics.Rect");
        } 
      } else {
        object = object.getClass().getDeclaredMethod("getAppBounds", new Class[0]).invoke(object, new Object[0]);
        if (object != null) {
          object = object;
        } else {
          throw new NullPointerException("null cannot be cast to non-null type android.graphics.Rect");
        } 
      } 
      rect.set((Rect)object);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.w(TAG, noSuchFieldException);
      getRectSizeFromDisplay(paramActivity, rect);
    } catch (NoSuchMethodException noSuchMethodException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    Display display = paramActivity.getWindowManager().getDefaultDisplay();
    Point point = new Point();
    DisplayCompatHelperApi17 displayCompatHelperApi17 = DisplayCompatHelperApi17.INSTANCE;
    l.e(display, "currentDisplay");
    displayCompatHelperApi17.getRealSize(display, point);
    ActivityCompatHelperApi24 activityCompatHelperApi24 = ActivityCompatHelperApi24.INSTANCE;
    if (!activityCompatHelperApi24.isInMultiWindowMode(paramActivity)) {
      int i = getNavigationBarHeight((Context)paramActivity);
      int j = rect.bottom;
      if (j + i == point.y) {
        rect.bottom = j + i;
      } else {
        j = rect.right;
        if (j + i == point.x) {
          rect.right = j + i;
        } else if (rect.left == i) {
          rect.left = 0;
        } 
      } 
    } 
    if ((rect.width() < point.x || rect.height() < point.y) && !activityCompatHelperApi24.isInMultiWindowMode(paramActivity)) {
      DisplayCutout displayCutout = getCutoutForDisplay(display);
      if (displayCutout != null) {
        int i = rect.left;
        DisplayCompatHelperApi28 displayCompatHelperApi28 = DisplayCompatHelperApi28.INSTANCE;
        if (i == displayCompatHelperApi28.safeInsetLeft(displayCutout))
          rect.left = 0; 
        if (point.x - rect.right == displayCompatHelperApi28.safeInsetRight(displayCutout))
          rect.right += displayCompatHelperApi28.safeInsetRight(displayCutout); 
        if (rect.top == displayCompatHelperApi28.safeInsetTop(displayCutout))
          rect.top = 0; 
        if (point.y - rect.bottom == displayCompatHelperApi28.safeInsetBottom(displayCutout))
          rect.bottom += displayCompatHelperApi28.safeInsetBottom(displayCutout); 
      } 
    } 
    return rect;
  }
  
  public final Rect computeWindowBoundsQ$window_release(Activity paramActivity) {
    l.f(paramActivity, "activity");
    Configuration configuration = paramActivity.getResources().getConfiguration();
    try {
      Field field = Configuration.class.getDeclaredField("windowConfiguration");
      field.setAccessible(true);
      object = field.get(configuration);
      object = object.getClass().getDeclaredMethod("getBounds", new Class[0]).invoke(object, new Object[0]);
      if (object != null)
        return new Rect((Rect)object); 
      throw new NullPointerException("null cannot be cast to non-null type android.graphics.Rect");
    } catch (NoSuchFieldException null) {
    
    } catch (NoSuchMethodException null) {
    
    } catch (IllegalAccessException null) {
    
    } catch (InvocationTargetException object) {}
    Log.w(TAG, (Throwable)object);
    return computeWindowBoundsP$window_release(paramActivity);
  }
  
  public final Point getRealSizeForDisplay$window_release(Display paramDisplay) {
    l.f(paramDisplay, "display");
    Point point = new Point();
    if (Build.VERSION.SDK_INT >= 17) {
      DisplayCompatHelperApi17.INSTANCE.getRealSize(paramDisplay, point);
      return point;
    } 
    try {
      Method method = Display.class.getDeclaredMethod("getRealSize", new Class[] { Point.class });
      method.setAccessible(true);
      method.invoke(paramDisplay, new Object[] { point });
      return point;
    } catch (NoSuchMethodException noSuchMethodException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    Log.w(TAG, invocationTargetException);
    return point;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowMetricsCalculatorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */