package androidx.window.layout;

import android.app.Activity;
import kotlin.jvm.internal.l;

public final class ActivityCompatHelperApi24 {
  public static final ActivityCompatHelperApi24 INSTANCE = new ActivityCompatHelperApi24();
  
  public final boolean isInMultiWindowMode(Activity paramActivity) {
    l.f(paramActivity, "activity");
    return paramActivity.isInMultiWindowMode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\ActivityCompatHelperApi24.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */