package androidx.window.layout;

import android.app.Activity;
import androidx.core.util.a;
import java.util.concurrent.Executor;

public interface WindowBackend {
  void registerLayoutChangeCallback(Activity paramActivity, Executor paramExecutor, a<WindowLayoutInfo> parama);
  
  void unregisterLayoutChangeCallback(a<WindowLayoutInfo> parama);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */