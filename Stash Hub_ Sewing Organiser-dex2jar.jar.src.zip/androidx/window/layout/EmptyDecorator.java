package androidx.window.layout;

import kotlin.jvm.internal.l;

final class EmptyDecorator implements WindowInfoTrackerDecorator {
  public static final EmptyDecorator INSTANCE = new EmptyDecorator();
  
  public WindowInfoTracker decorate(WindowInfoTracker paramWindowInfoTracker) {
    l.f(paramWindowInfoTracker, "tracker");
    return paramWindowInfoTracker;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\EmptyDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */