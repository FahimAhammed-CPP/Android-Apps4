package androidx.window.layout;

import android.app.Activity;
import androidx.window.core.ExperimentalWindowApi;
import kotlin.jvm.internal.d;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import y7.l;

public interface WindowMetricsCalculator {
  public static final Companion Companion = Companion.$$INSTANCE;
  
  WindowMetrics computeCurrentWindowMetrics(Activity paramActivity);
  
  WindowMetrics computeMaximumWindowMetrics(Activity paramActivity);
  
  public static final class Companion {
    private static l<? super WindowMetricsCalculator, ? extends WindowMetricsCalculator> decorator = WindowMetricsCalculator$Companion$decorator$1.INSTANCE;
    
    public final WindowMetricsCalculator getOrCreate() {
      return (WindowMetricsCalculator)decorator.invoke(WindowMetricsCalculatorCompat.INSTANCE);
    }
    
    @ExperimentalWindowApi
    public final void overrideDecorator(WindowMetricsCalculatorDecorator param1WindowMetricsCalculatorDecorator) {
      l.f(param1WindowMetricsCalculatorDecorator, "overridingDecorator");
      decorator = new WindowMetricsCalculator$Companion$overrideDecorator$1(param1WindowMetricsCalculatorDecorator);
    }
    
    @ExperimentalWindowApi
    public final void reset() {
      decorator = WindowMetricsCalculator$Companion$reset$1.INSTANCE;
    }
    
    static final class WindowMetricsCalculator$Companion$decorator$1 extends m implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
      public static final WindowMetricsCalculator$Companion$decorator$1 INSTANCE = new WindowMetricsCalculator$Companion$decorator$1();
      
      WindowMetricsCalculator$Companion$decorator$1() {
        super(1);
      }
      
      public final WindowMetricsCalculator invoke(WindowMetricsCalculator param2WindowMetricsCalculator) {
        l.f(param2WindowMetricsCalculator, "it");
        return param2WindowMetricsCalculator;
      }
    }
    
    static final class WindowMetricsCalculator$Companion$reset$1 extends m implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
      public static final WindowMetricsCalculator$Companion$reset$1 INSTANCE = new WindowMetricsCalculator$Companion$reset$1();
      
      WindowMetricsCalculator$Companion$reset$1() {
        super(1);
      }
      
      public final WindowMetricsCalculator invoke(WindowMetricsCalculator param2WindowMetricsCalculator) {
        l.f(param2WindowMetricsCalculator, "it");
        return param2WindowMetricsCalculator;
      }
    }
  }
  
  static final class WindowMetricsCalculator$Companion$decorator$1 extends m implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$decorator$1 INSTANCE = new WindowMetricsCalculator$Companion$decorator$1();
    
    WindowMetricsCalculator$Companion$decorator$1() {
      super(1);
    }
    
    public final WindowMetricsCalculator invoke(WindowMetricsCalculator param1WindowMetricsCalculator) {
      l.f(param1WindowMetricsCalculator, "it");
      return param1WindowMetricsCalculator;
    }
  }
  
  static final class WindowMetricsCalculator$Companion$reset$1 extends m implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$reset$1 INSTANCE = new WindowMetricsCalculator$Companion$reset$1();
    
    WindowMetricsCalculator$Companion$reset$1() {
      super(1);
    }
    
    public final WindowMetricsCalculator invoke(WindowMetricsCalculator param1WindowMetricsCalculator) {
      l.f(param1WindowMetricsCalculator, "it");
      return param1WindowMetricsCalculator;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowMetricsCalculator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */