package androidx.window.layout;

import android.app.Activity;
import androidx.core.util.a;
import androidx.profileinstaller.g;
import j8.e;
import j8.f;
import j8.g;
import j8.h;
import java.util.concurrent.Executor;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;
import kotlinx.coroutines.flow.b;
import kotlinx.coroutines.flow.c;
import kotlinx.coroutines.flow.d;
import o7.o;
import o7.u;
import r7.d;
import s7.b;
import y7.p;

public final class WindowInfoTrackerImpl implements WindowInfoTracker {
  private static final int BUFFER_CAPACITY = 10;
  
  public static final Companion Companion = new Companion(null);
  
  private final WindowBackend windowBackend;
  
  private final WindowMetricsCalculator windowMetricsCalculator;
  
  public WindowInfoTrackerImpl(WindowMetricsCalculator paramWindowMetricsCalculator, WindowBackend paramWindowBackend) {
    this.windowMetricsCalculator = paramWindowMetricsCalculator;
    this.windowBackend = paramWindowBackend;
  }
  
  public b<WindowLayoutInfo> windowLayoutInfo(Activity paramActivity) {
    l.f(paramActivity, "activity");
    return d.e(new WindowInfoTrackerImpl$windowLayoutInfo$1(paramActivity, null));
  }
  
  public static final class Companion {
    private Companion() {}
  }
  
  @f(c = "androidx.window.layout.WindowInfoTrackerImpl$windowLayoutInfo$1", f = "WindowInfoTrackerImpl.kt", l = {54, 55}, m = "invokeSuspend")
  static final class WindowInfoTrackerImpl$windowLayoutInfo$1 extends l implements p<c<? super WindowLayoutInfo>, d<? super u>, Object> {
    Object L$1;
    
    Object L$2;
    
    int label;
    
    WindowInfoTrackerImpl$windowLayoutInfo$1(Activity param1Activity, d<? super WindowInfoTrackerImpl$windowLayoutInfo$1> param1d) {
      super(2, param1d);
    }
    
    private static final void invokeSuspend$lambda-0(f param1f, WindowLayoutInfo param1WindowLayoutInfo) {
      l.e(param1WindowLayoutInfo, "info");
      param1f.c(param1WindowLayoutInfo);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$1 = new WindowInfoTrackerImpl$windowLayoutInfo$1(this.$activity, (d)param1d);
      windowInfoTrackerImpl$windowLayoutInfo$1.L$0 = param1Object;
      return (d<u>)windowInfoTrackerImpl$windowLayoutInfo$1;
    }
    
    public final Object invoke(c<? super WindowLayoutInfo> param1c, d<? super u> param1d) {
      return ((WindowInfoTrackerImpl$windowLayoutInfo$1)create(param1c, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object1;
      WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$1;
      Object object2 = b.c();
      int i = this.label;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            g g = (g)this.L$2;
            a a = (a)this.L$1;
            c c = (c)this.L$0;
            object1 = a;
            try {
              o.b(param1Object);
              param1Object = g;
              object1 = a;
              windowInfoTrackerImpl$windowLayoutInfo$1 = this;
            } finally {
              a = null;
            } 
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          g g = (g)this.L$2;
          a a1 = (a)this.L$1;
          c c = (c)this.L$0;
          object1 = a1;
          o.b(param1Object);
          WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$11 = this;
          object1 = a1;
          windowInfoTrackerImpl$windowLayoutInfo$1 = windowInfoTrackerImpl$windowLayoutInfo$11;
          Object object = param1Object;
          a a2 = (a)object1;
          param1Object = windowInfoTrackerImpl$windowLayoutInfo$1;
        } 
      } else {
        o.b(param1Object);
        c c = (c)this.L$0;
        f f = h.b(10, e.b, null, 4, null);
        param1Object = new c(f);
        WindowInfoTrackerImpl.this.windowBackend.registerLayoutChangeCallback(this.$activity, (Executor)g.a, (a<WindowLayoutInfo>)param1Object);
        object1 = param1Object;
        g g = f.iterator();
        object1 = param1Object;
        param1Object = g;
        windowInfoTrackerImpl$windowLayoutInfo$1 = this;
        Object object = param1Object;
      } 
      WindowInfoTrackerImpl.this.windowBackend.unregisterLayoutChangeCallback((a<WindowLayoutInfo>)object1);
      throw windowInfoTrackerImpl$windowLayoutInfo$1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\WindowInfoTrackerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */