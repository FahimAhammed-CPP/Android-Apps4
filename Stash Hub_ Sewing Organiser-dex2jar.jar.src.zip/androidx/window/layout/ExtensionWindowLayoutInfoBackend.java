package androidx.window.layout;

import android.app.Activity;
import androidx.core.util.a;
import androidx.window.extensions.layout.WindowLayoutComponent;
import androidx.window.extensions.layout.WindowLayoutInfo;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import kotlin.jvm.internal.l;
import o7.u;

public final class ExtensionWindowLayoutInfoBackend implements WindowBackend {
  private final Map<Activity, MulticastConsumer> activityToListeners;
  
  private final WindowLayoutComponent component;
  
  private final ReentrantLock extensionWindowBackendLock;
  
  private final Map<a<WindowLayoutInfo>, Activity> listenerToActivity;
  
  public ExtensionWindowLayoutInfoBackend(WindowLayoutComponent paramWindowLayoutComponent) {
    this.component = paramWindowLayoutComponent;
    this.extensionWindowBackendLock = new ReentrantLock();
    this.activityToListeners = new LinkedHashMap<Activity, MulticastConsumer>();
    this.listenerToActivity = new LinkedHashMap<a<WindowLayoutInfo>, Activity>();
  }
  
  public void registerLayoutChangeCallback(Activity paramActivity, Executor paramExecutor, a<WindowLayoutInfo> parama) {
    l.f(paramActivity, "activity");
    l.f(paramExecutor, "executor");
    l.f(parama, "callback");
    ReentrantLock reentrantLock = this.extensionWindowBackendLock;
    reentrantLock.lock();
    try {
      u u2;
      MulticastConsumer multicastConsumer = this.activityToListeners.get(paramActivity);
      if (multicastConsumer == null) {
        multicastConsumer = null;
      } else {
        multicastConsumer.addListener(parama);
        this.listenerToActivity.put(parama, paramActivity);
        u2 = u.a;
      } 
      if (u2 == null) {
        MulticastConsumer multicastConsumer1 = new MulticastConsumer(paramActivity);
        this.activityToListeners.put(paramActivity, multicastConsumer1);
        this.listenerToActivity.put(parama, paramActivity);
        multicastConsumer1.addListener(parama);
        this.component.addWindowLayoutInfoListener(paramActivity, multicastConsumer1);
      } 
      u u1 = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public void unregisterLayoutChangeCallback(a<WindowLayoutInfo> parama) {
    l.f(parama, "callback");
    ReentrantLock reentrantLock = this.extensionWindowBackendLock;
    reentrantLock.lock();
    try {
      Activity activity = this.listenerToActivity.get(parama);
      if (activity == null)
        return; 
      MulticastConsumer multicastConsumer = this.activityToListeners.get(activity);
      if (multicastConsumer == null)
        return; 
      multicastConsumer.removeListener(parama);
      if (multicastConsumer.isEmpty())
        this.component.removeWindowLayoutInfoListener(multicastConsumer); 
      u u = u.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  private static final class MulticastConsumer implements Consumer<WindowLayoutInfo> {
    private final Activity activity;
    
    private WindowLayoutInfo lastKnownValue;
    
    private final ReentrantLock multicastConsumerLock;
    
    private final Set<a<WindowLayoutInfo>> registeredListeners;
    
    public MulticastConsumer(Activity param1Activity) {
      this.activity = param1Activity;
      this.multicastConsumerLock = new ReentrantLock();
      this.registeredListeners = new LinkedHashSet<a<WindowLayoutInfo>>();
    }
    
    public void accept(WindowLayoutInfo param1WindowLayoutInfo) {
      l.f(param1WindowLayoutInfo, "value");
      ReentrantLock reentrantLock = this.multicastConsumerLock;
      reentrantLock.lock();
      try {
        this.lastKnownValue = ExtensionsWindowLayoutInfoAdapter.INSTANCE.translate$window_release(this.activity, param1WindowLayoutInfo);
        Iterator<a<WindowLayoutInfo>> iterator = this.registeredListeners.iterator();
        while (iterator.hasNext())
          ((a)iterator.next()).accept(this.lastKnownValue); 
        u u = u.a;
        return;
      } finally {
        reentrantLock.unlock();
      } 
    }
    
    public final void addListener(a<WindowLayoutInfo> param1a) {
      l.f(param1a, "listener");
      ReentrantLock reentrantLock = this.multicastConsumerLock;
      reentrantLock.lock();
      try {
        WindowLayoutInfo windowLayoutInfo = this.lastKnownValue;
        if (windowLayoutInfo != null)
          param1a.accept(windowLayoutInfo); 
        this.registeredListeners.add(param1a);
        return;
      } finally {
        reentrantLock.unlock();
      } 
    }
    
    public final boolean isEmpty() {
      return this.registeredListeners.isEmpty();
    }
    
    public final void removeListener(a<WindowLayoutInfo> param1a) {
      l.f(param1a, "listener");
      ReentrantLock reentrantLock = this.multicastConsumerLock;
      reentrantLock.lock();
      try {
        this.registeredListeners.remove(param1a);
        return;
      } finally {
        reentrantLock.unlock();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\ExtensionWindowLayoutInfoBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */