package androidx.window.layout;

import android.graphics.Rect;
import androidx.window.core.Bounds;
import java.util.Objects;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public final class HardwareFoldingFeature implements FoldingFeature {
  public static final Companion Companion = new Companion(null);
  
  private final Bounds featureBounds;
  
  private final FoldingFeature.State state;
  
  private final Type type;
  
  public HardwareFoldingFeature(Bounds paramBounds, Type paramType, FoldingFeature.State paramState) {
    this.featureBounds = paramBounds;
    this.type = paramType;
    this.state = paramState;
    Companion.validateFeatureBounds$window_release(paramBounds);
  }
  
  public boolean equals(Object paramObject) {
    Class<?> clazz;
    if (this == paramObject)
      return true; 
    if (paramObject == null) {
      clazz = null;
    } else {
      clazz = paramObject.getClass();
    } 
    if (!l.b(HardwareFoldingFeature.class, clazz))
      return false; 
    Objects.requireNonNull(paramObject, "null cannot be cast to non-null type androidx.window.layout.HardwareFoldingFeature");
    paramObject = paramObject;
    return !l.b(this.featureBounds, ((HardwareFoldingFeature)paramObject).featureBounds) ? false : (!l.b(this.type, ((HardwareFoldingFeature)paramObject).type) ? false : (!!l.b(getState(), paramObject.getState())));
  }
  
  public Rect getBounds() {
    return this.featureBounds.toRect();
  }
  
  public FoldingFeature.OcclusionType getOcclusionType() {
    return (this.featureBounds.getWidth() == 0 || this.featureBounds.getHeight() == 0) ? FoldingFeature.OcclusionType.NONE : FoldingFeature.OcclusionType.FULL;
  }
  
  public FoldingFeature.Orientation getOrientation() {
    return (this.featureBounds.getWidth() > this.featureBounds.getHeight()) ? FoldingFeature.Orientation.HORIZONTAL : FoldingFeature.Orientation.VERTICAL;
  }
  
  public FoldingFeature.State getState() {
    return this.state;
  }
  
  public final Type getType$window_release() {
    return this.type;
  }
  
  public int hashCode() {
    return (this.featureBounds.hashCode() * 31 + this.type.hashCode()) * 31 + getState().hashCode();
  }
  
  public boolean isSeparating() {
    Type type = this.type;
    Type.Companion companion = Type.Companion;
    return l.b(type, companion.getHINGE()) ? true : ((l.b(this.type, companion.getFOLD()) && l.b(getState(), FoldingFeature.State.HALF_OPENED)));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HardwareFoldingFeature.class.getSimpleName());
    stringBuilder.append(" { ");
    stringBuilder.append(this.featureBounds);
    stringBuilder.append(", type=");
    stringBuilder.append(this.type);
    stringBuilder.append(", state=");
    stringBuilder.append(getState());
    stringBuilder.append(" }");
    return stringBuilder.toString();
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final void validateFeatureBounds$window_release(Bounds param1Bounds) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'bounds'
      //   3: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_1
      //   7: invokevirtual getWidth : ()I
      //   10: istore_2
      //   11: iconst_0
      //   12: istore_3
      //   13: iload_2
      //   14: ifne -> 32
      //   17: aload_1
      //   18: invokevirtual getHeight : ()I
      //   21: ifeq -> 27
      //   24: goto -> 32
      //   27: iconst_0
      //   28: istore_2
      //   29: goto -> 34
      //   32: iconst_1
      //   33: istore_2
      //   34: iload_2
      //   35: ifeq -> 74
      //   38: aload_1
      //   39: invokevirtual getLeft : ()I
      //   42: ifeq -> 54
      //   45: iload_3
      //   46: istore_2
      //   47: aload_1
      //   48: invokevirtual getTop : ()I
      //   51: ifne -> 56
      //   54: iconst_1
      //   55: istore_2
      //   56: iload_2
      //   57: ifeq -> 61
      //   60: return
      //   61: new java/lang/IllegalArgumentException
      //   64: dup
      //   65: ldc 'Bounding rectangle must start at the top or left window edge for folding features'
      //   67: invokevirtual toString : ()Ljava/lang/String;
      //   70: invokespecial <init> : (Ljava/lang/String;)V
      //   73: athrow
      //   74: new java/lang/IllegalArgumentException
      //   77: dup
      //   78: ldc 'Bounds must be non zero'
      //   80: invokevirtual toString : ()Ljava/lang/String;
      //   83: invokespecial <init> : (Ljava/lang/String;)V
      //   86: athrow
    }
  }
  
  public static final class Type {
    public static final Companion Companion = new Companion(null);
    
    private static final Type FOLD = new Type("FOLD");
    
    private static final Type HINGE = new Type("HINGE");
    
    private final String description;
    
    private Type(String param1String) {
      this.description = param1String;
    }
    
    public String toString() {
      return this.description;
    }
    
    public static final class Companion {
      private Companion() {}
      
      public final HardwareFoldingFeature.Type getFOLD() {
        return HardwareFoldingFeature.Type.FOLD;
      }
      
      public final HardwareFoldingFeature.Type getHINGE() {
        return HardwareFoldingFeature.Type.HINGE;
      }
    }
  }
  
  public static final class Companion {
    private Companion() {}
    
    public final HardwareFoldingFeature.Type getFOLD() {
      return HardwareFoldingFeature.Type.FOLD;
    }
    
    public final HardwareFoldingFeature.Type getHINGE() {
      return HardwareFoldingFeature.Type.HINGE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\window\layout\HardwareFoldingFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */