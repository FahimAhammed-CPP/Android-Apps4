package androidx.work;

import android.os.Build;
import d0.g;
import d0.i;
import d0.r;
import d0.w;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class a {
  final Executor a;
  
  final Executor b;
  
  final w c;
  
  final i d;
  
  final r e;
  
  final g f;
  
  final String g;
  
  final int h;
  
  final int i;
  
  final int j;
  
  final int k;
  
  private final boolean l;
  
  a(b paramb) {
    e0.a a1;
    Executor executor2 = paramb.a;
    Executor executor1 = executor2;
    if (executor2 == null)
      executor1 = a(false); 
    this.a = executor1;
    executor1 = paramb.d;
    if (executor1 == null) {
      this.l = true;
      executor1 = a(true);
    } else {
      this.l = false;
    } 
    this.b = executor1;
    w w2 = paramb.b;
    w w1 = w2;
    if (w2 == null)
      w1 = w.c(); 
    this.c = w1;
    i i2 = paramb.c;
    i i1 = i2;
    if (i2 == null)
      i1 = i.c(); 
    this.d = i1;
    r r2 = paramb.e;
    r r1 = r2;
    if (r2 == null)
      a1 = new e0.a(); 
    this.e = (r)a1;
    this.h = paramb.h;
    this.i = paramb.i;
    this.j = paramb.j;
    this.k = paramb.k;
    this.f = paramb.f;
    this.g = paramb.g;
  }
  
  private Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), b(paramBoolean));
  }
  
  private ThreadFactory b(boolean paramBoolean) {
    return new a(this, paramBoolean);
  }
  
  public String c() {
    return this.g;
  }
  
  public g d() {
    return this.f;
  }
  
  public Executor e() {
    return this.a;
  }
  
  public i f() {
    return this.d;
  }
  
  public int g() {
    return this.j;
  }
  
  public int h() {
    return (Build.VERSION.SDK_INT == 23) ? (this.k / 2) : this.k;
  }
  
  public int i() {
    return this.i;
  }
  
  public int j() {
    return this.h;
  }
  
  public r k() {
    return this.e;
  }
  
  public Executor l() {
    return this.b;
  }
  
  public w m() {
    return this.c;
  }
  
  class a implements ThreadFactory {
    private final AtomicInteger a = new AtomicInteger(0);
    
    a(a this$0, boolean param1Boolean) {}
    
    public Thread newThread(Runnable param1Runnable) {
      String str;
      if (this.b) {
        str = "WM.task-";
      } else {
        str = "androidx.work-";
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(this.a.incrementAndGet());
      return new Thread(param1Runnable, stringBuilder.toString());
    }
  }
  
  public static final class b {
    Executor a;
    
    w b;
    
    i c;
    
    Executor d;
    
    r e;
    
    g f;
    
    String g;
    
    int h = 4;
    
    int i = 0;
    
    int j = Integer.MAX_VALUE;
    
    int k = 20;
    
    public a a() {
      return new a(this);
    }
  }
  
  public static interface c {
    a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */