package androidx.work;

import d0.h;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class OverwritingInputMerger extends h {
  public b b(List<b> paramList) {
    b.a a = new b.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<b> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(((b)iterator.next()).h()); 
    a.d((Map)hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */