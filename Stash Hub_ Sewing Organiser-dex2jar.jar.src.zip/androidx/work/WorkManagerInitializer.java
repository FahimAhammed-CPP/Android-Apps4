package androidx.work;

import a0.a;
import android.content.Context;
import d0.k;
import d0.u;
import java.util.Collections;
import java.util.List;

public final class WorkManagerInitializer implements a<u> {
  private static final String a = k.f("WrkMgrInitializer");
  
  public List<Class<? extends a<?>>> a() {
    return Collections.emptyList();
  }
  
  public u c(Context paramContext) {
    k.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    u.d(paramContext, (new a.b()).a());
    return u.c(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */