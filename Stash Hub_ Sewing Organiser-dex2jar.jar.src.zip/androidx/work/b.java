package androidx.work;

import android.util.Log;
import d0.k;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class b {
  private static final String b = k.f("Data");
  
  public static final b c = (new a()).a();
  
  Map<String, Object> a;
  
  b() {}
  
  public b(b paramb) {
    this.a = new HashMap<String, Object>(paramb.a);
  }
  
  public b(Map<String, ?> paramMap) {
    this.a = new HashMap<String, Object>(paramMap);
  }
  
  public static Boolean[] a(boolean[] paramArrayOfboolean) {
    Boolean[] arrayOfBoolean = new Boolean[paramArrayOfboolean.length];
    for (int i = 0; i < paramArrayOfboolean.length; i++)
      arrayOfBoolean[i] = Boolean.valueOf(paramArrayOfboolean[i]); 
    return arrayOfBoolean;
  }
  
  public static Byte[] b(byte[] paramArrayOfbyte) {
    Byte[] arrayOfByte = new Byte[paramArrayOfbyte.length];
    for (int i = 0; i < paramArrayOfbyte.length; i++)
      arrayOfByte[i] = Byte.valueOf(paramArrayOfbyte[i]); 
    return arrayOfByte;
  }
  
  public static Double[] c(double[] paramArrayOfdouble) {
    Double[] arrayOfDouble = new Double[paramArrayOfdouble.length];
    for (int i = 0; i < paramArrayOfdouble.length; i++)
      arrayOfDouble[i] = Double.valueOf(paramArrayOfdouble[i]); 
    return arrayOfDouble;
  }
  
  public static Float[] d(float[] paramArrayOffloat) {
    Float[] arrayOfFloat = new Float[paramArrayOffloat.length];
    for (int i = 0; i < paramArrayOffloat.length; i++)
      arrayOfFloat[i] = Float.valueOf(paramArrayOffloat[i]); 
    return arrayOfFloat;
  }
  
  public static Integer[] e(int[] paramArrayOfint) {
    Integer[] arrayOfInteger = new Integer[paramArrayOfint.length];
    for (int i = 0; i < paramArrayOfint.length; i++)
      arrayOfInteger[i] = Integer.valueOf(paramArrayOfint[i]); 
    return arrayOfInteger;
  }
  
  public static Long[] f(long[] paramArrayOflong) {
    Long[] arrayOfLong = new Long[paramArrayOflong.length];
    for (int i = 0; i < paramArrayOflong.length; i++)
      arrayOfLong[i] = Long.valueOf(paramArrayOflong[i]); 
    return arrayOfLong;
  }
  
  public static b g(byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: sipush #10240
    //   5: if_icmpgt -> 229
    //   8: new java/util/HashMap
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore #5
    //   17: new java/io/ByteArrayInputStream
    //   20: dup
    //   21: aload_0
    //   22: invokespecial <init> : ([B)V
    //   25: astore #4
    //   27: new java/io/ObjectInputStream
    //   30: dup
    //   31: aload #4
    //   33: invokespecial <init> : (Ljava/io/InputStream;)V
    //   36: astore_2
    //   37: aload_2
    //   38: astore_0
    //   39: aload_2
    //   40: invokevirtual readInt : ()I
    //   43: istore_1
    //   44: iload_1
    //   45: ifle -> 73
    //   48: aload_2
    //   49: astore_0
    //   50: aload #5
    //   52: aload_2
    //   53: invokevirtual readUTF : ()Ljava/lang/String;
    //   56: aload_2
    //   57: invokevirtual readObject : ()Ljava/lang/Object;
    //   60: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   65: pop
    //   66: iload_1
    //   67: iconst_1
    //   68: isub
    //   69: istore_1
    //   70: goto -> 44
    //   73: aload_2
    //   74: invokevirtual close : ()V
    //   77: goto -> 91
    //   80: astore_0
    //   81: getstatic androidx/work/b.b : Ljava/lang/String;
    //   84: ldc 'Error in Data#fromByteArray: '
    //   86: aload_0
    //   87: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   90: pop
    //   91: aload #4
    //   93: invokevirtual close : ()V
    //   96: goto -> 175
    //   99: astore_3
    //   100: goto -> 122
    //   103: astore_3
    //   104: goto -> 122
    //   107: astore_2
    //   108: aconst_null
    //   109: astore_0
    //   110: goto -> 186
    //   113: astore_0
    //   114: goto -> 118
    //   117: astore_0
    //   118: aconst_null
    //   119: astore_2
    //   120: aload_0
    //   121: astore_3
    //   122: aload_2
    //   123: astore_0
    //   124: getstatic androidx/work/b.b : Ljava/lang/String;
    //   127: ldc 'Error in Data#fromByteArray: '
    //   129: aload_3
    //   130: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   133: pop
    //   134: aload_2
    //   135: ifnull -> 156
    //   138: aload_2
    //   139: invokevirtual close : ()V
    //   142: goto -> 156
    //   145: astore_0
    //   146: getstatic androidx/work/b.b : Ljava/lang/String;
    //   149: ldc 'Error in Data#fromByteArray: '
    //   151: aload_0
    //   152: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   155: pop
    //   156: aload #4
    //   158: invokevirtual close : ()V
    //   161: goto -> 175
    //   164: astore_0
    //   165: getstatic androidx/work/b.b : Ljava/lang/String;
    //   168: ldc 'Error in Data#fromByteArray: '
    //   170: aload_0
    //   171: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   174: pop
    //   175: new androidx/work/b
    //   178: dup
    //   179: aload #5
    //   181: invokespecial <init> : (Ljava/util/Map;)V
    //   184: areturn
    //   185: astore_2
    //   186: aload_0
    //   187: ifnull -> 208
    //   190: aload_0
    //   191: invokevirtual close : ()V
    //   194: goto -> 208
    //   197: astore_0
    //   198: getstatic androidx/work/b.b : Ljava/lang/String;
    //   201: ldc 'Error in Data#fromByteArray: '
    //   203: aload_0
    //   204: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   207: pop
    //   208: aload #4
    //   210: invokevirtual close : ()V
    //   213: goto -> 227
    //   216: astore_0
    //   217: getstatic androidx/work/b.b : Ljava/lang/String;
    //   220: ldc 'Error in Data#fromByteArray: '
    //   222: aload_0
    //   223: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   226: pop
    //   227: aload_2
    //   228: athrow
    //   229: new java/lang/IllegalStateException
    //   232: dup
    //   233: ldc 'Data cannot occupy more than 10240 bytes when serialized'
    //   235: invokespecial <init> : (Ljava/lang/String;)V
    //   238: athrow
    // Exception table:
    //   from	to	target	type
    //   27	37	117	java/io/IOException
    //   27	37	113	java/lang/ClassNotFoundException
    //   27	37	107	finally
    //   39	44	103	java/io/IOException
    //   39	44	99	java/lang/ClassNotFoundException
    //   39	44	185	finally
    //   50	66	103	java/io/IOException
    //   50	66	99	java/lang/ClassNotFoundException
    //   50	66	185	finally
    //   73	77	80	java/io/IOException
    //   91	96	164	java/io/IOException
    //   124	134	185	finally
    //   138	142	145	java/io/IOException
    //   156	161	164	java/io/IOException
    //   190	194	197	java/io/IOException
    //   208	213	216	java/io/IOException
  }
  
  public static byte[] k(b paramb) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    b b2 = null;
    entry = null;
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      try {
        objectOutputStream.writeInt(paramb.j());
        for (Map.Entry<String, Object> entry : paramb.a.entrySet()) {
          objectOutputStream.writeUTF((String)entry.getKey());
          objectOutputStream.writeObject(entry.getValue());
        } 
        try {
          objectOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(b, "Error in Data#toByteArray: ", iOException1);
        } 
        try {
          byteArrayOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(b, "Error in Data#toByteArray: ", iOException1);
        } 
        if (byteArrayOutputStream.size() <= 10240)
          return byteArrayOutputStream.toByteArray(); 
        throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
      } catch (IOException iOException1) {
        ObjectOutputStream objectOutputStream1 = objectOutputStream;
      } finally {
        IOException iOException1;
        paramb = null;
      } 
    } catch (IOException iOException) {
      paramb = b2;
    } finally {}
    b b1 = paramb;
    Log.e(b, "Error in Data#toByteArray: ", iOException);
    b1 = paramb;
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    if (paramb != null)
      try {
        paramb.close();
      } catch (IOException iOException1) {
        Log.e(b, "Error in Data#toByteArray: ", iOException1);
      }  
    try {
      byteArrayOutputStream.close();
      return arrayOfByte;
    } catch (IOException iOException1) {
      Log.e(b, "Error in Data#toByteArray: ", iOException1);
      return arrayOfByte;
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (b.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      Set<String> set = this.a.keySet();
      if (!set.equals(((b)paramObject).a.keySet()))
        return false; 
      for (String str : set) {
        boolean bool;
        Object object = this.a.get(str);
        str = (String)((b)paramObject).a.get(str);
        if (object == null || str == null) {
          if (object == str) {
            bool = true;
          } else {
            bool = false;
          } 
        } else if (object instanceof Object[] && str instanceof Object[]) {
          bool = Arrays.deepEquals((Object[])object, (Object[])str);
        } else {
          bool = object.equals(str);
        } 
        if (!bool)
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public Map<String, Object> h() {
    return Collections.unmodifiableMap(this.a);
  }
  
  public int hashCode() {
    return this.a.hashCode() * 31;
  }
  
  public String i(String paramString) {
    paramString = (String)this.a.get(paramString);
    return (paramString instanceof String) ? paramString : null;
  }
  
  public int j() {
    return this.a.size();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Data {");
    if (!this.a.isEmpty())
      for (String str : this.a.keySet()) {
        stringBuilder.append(str);
        stringBuilder.append(" : ");
        str = (String)this.a.get(str);
        if (str instanceof Object[]) {
          stringBuilder.append(Arrays.toString((Object[])str));
        } else {
          stringBuilder.append(str);
        } 
        stringBuilder.append(", ");
      }  
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static final class a {
    private Map<String, Object> a = new HashMap<String, Object>();
    
    public b a() {
      b b = new b(this.a);
      b.k(b);
      return b;
    }
    
    public a b(String param1String, Object param1Object) {
      if (param1Object == null) {
        this.a.put(param1String, null);
        return this;
      } 
      Class<?> clazz = param1Object.getClass();
      if (clazz == Boolean.class || clazz == Byte.class || clazz == Integer.class || clazz == Long.class || clazz == Float.class || clazz == Double.class || clazz == String.class || clazz == Boolean[].class || clazz == Byte[].class || clazz == Integer[].class || clazz == Long[].class || clazz == Float[].class || clazz == Double[].class || clazz == String[].class) {
        this.a.put(param1String, param1Object);
        return this;
      } 
      if (clazz == boolean[].class) {
        this.a.put(param1String, b.a((boolean[])param1Object));
        return this;
      } 
      if (clazz == byte[].class) {
        this.a.put(param1String, b.b((byte[])param1Object));
        return this;
      } 
      if (clazz == int[].class) {
        this.a.put(param1String, b.e((int[])param1Object));
        return this;
      } 
      if (clazz == long[].class) {
        this.a.put(param1String, b.f((long[])param1Object));
        return this;
      } 
      if (clazz == float[].class) {
        this.a.put(param1String, b.d((float[])param1Object));
        return this;
      } 
      if (clazz == double[].class) {
        this.a.put(param1String, b.c((double[])param1Object));
        return this;
      } 
      throw new IllegalArgumentException(String.format("Key %s has invalid type %s", new Object[] { param1String, clazz }));
    }
    
    public a c(b param1b) {
      d(param1b.a);
      return this;
    }
    
    public a d(Map<String, Object> param1Map) {
      for (Map.Entry<String, Object> entry : param1Map.entrySet())
        b((String)entry.getKey(), entry.getValue()); 
      return this;
    }
    
    public a e(String param1String1, String param1String2) {
      this.a.put(param1String1, param1String2);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */