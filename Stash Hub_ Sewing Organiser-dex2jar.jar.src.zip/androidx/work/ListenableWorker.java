package androidx.work;

import android.content.Context;
import androidx.annotation.Keep;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.d;
import d0.e;
import d0.w;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
  private Context a;
  
  private WorkerParameters b;
  
  private volatile boolean c;
  
  private boolean d;
  
  private boolean e;
  
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.a = paramContext;
        this.b = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context a() {
    return this.a;
  }
  
  public Executor b() {
    return this.b.a();
  }
  
  public d<e> d() {
    c c = c.t();
    c.q(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (d<e>)c;
  }
  
  public final UUID f() {
    return this.b.c();
  }
  
  public final b g() {
    return this.b.d();
  }
  
  public n0.a h() {
    return this.b.e();
  }
  
  public w i() {
    return this.b.f();
  }
  
  public boolean j() {
    return this.e;
  }
  
  public final boolean k() {
    return this.c;
  }
  
  public final boolean l() {
    return this.d;
  }
  
  public void m() {}
  
  public void n(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public final void o() {
    this.d = true;
  }
  
  public abstract d<a> p();
  
  public final void q() {
    this.c = true;
    m();
  }
  
  public static abstract class a {
    public static a a() {
      return new a();
    }
    
    public static a b() {
      return new b();
    }
    
    public static a c() {
      return new c();
    }
    
    public static a d(b param1b) {
      return new c(param1b);
    }
    
    public static final class a extends a {
      private final b a;
      
      public a() {
        this(b.c);
      }
      
      public a(b param2b) {
        this.a = param2b;
      }
      
      public b e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || a.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((a)param2Object).a);
      }
      
      public int hashCode() {
        return a.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failure {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    public static final class b extends a {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && b.class == param2Object.getClass()));
      }
      
      public int hashCode() {
        return b.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    public static final class c extends a {
      private final b a;
      
      public c() {
        this(b.c);
      }
      
      public c(b param2b) {
        this.a = param2b;
      }
      
      public b e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || c.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((c)param2Object).a);
      }
      
      public int hashCode() {
        return c.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Success {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  public static final class a extends a {
    private final b a;
    
    public a() {
      this(b.c);
    }
    
    public a(b param1b) {
      this.a = param1b;
    }
    
    public b e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || a.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((a)param1Object).a);
    }
    
    public int hashCode() {
      return a.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failure {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends a {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && b.class == param1Object.getClass()));
    }
    
    public int hashCode() {
      return b.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  public static final class c extends a {
    private final b a;
    
    public c() {
      this(b.c);
    }
    
    public c(b param1b) {
      this.a = param1b;
    }
    
    public b e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || c.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      return c.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Success {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */