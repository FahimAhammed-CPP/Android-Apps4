package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import d0.k;
import d0.m;
import d0.u;
import d0.v;

public class DiagnosticsReceiver extends BroadcastReceiver {
  private static final String a = k.f("DiagnosticsRcvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    k.c().a(a, "Requesting diagnostics", new Throwable[0]);
    try {
      u.c(paramContext).a((v)m.d(DiagnosticsWorker.class));
      return;
    } catch (IllegalStateException illegalStateException) {
      k.c().b(a, "WorkManager is not initialized", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */