package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import d0.k;
import e0.b;
import e0.i;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SystemJobService extends JobService implements b {
  private static final String c = k.f("SystemJobService");
  
  private i a;
  
  private final Map<String, JobParameters> b = new HashMap<String, JobParameters>();
  
  private static String b(JobParameters paramJobParameters) {
    try {
      PersistableBundle persistableBundle = paramJobParameters.getExtras();
      if (persistableBundle != null && persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
        return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
    } catch (NullPointerException nullPointerException) {}
    return null;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    k.c().a(c, String.format("%s executed on JobScheduler", new Object[] { paramString }), new Throwable[0]);
    synchronized (this.b) {
      JobParameters jobParameters = this.b.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    try {
      i i1 = i.j(getApplicationContext());
      this.a = i1;
      i1.l().d(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        k.c().h(c, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public void onDestroy() {
    super.onDestroy();
    i i1 = this.a;
    if (i1 != null)
      i1.l().i(this); 
  }
  
  public boolean onStartJob(JobParameters paramJobParameters) {
    Map<String, JobParameters> map;
    WorkerParameters.a a;
    if (this.a == null) {
      k.c().a(c, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      jobFinished(paramJobParameters, true);
      return false;
    } 
    String str = b(paramJobParameters);
    if (TextUtils.isEmpty(str)) {
      k.c().b(c, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    synchronized (this.b) {
      if (this.b.containsKey(str)) {
        k.c().a(c, String.format("Job is already being executed by SystemJobService: %s", new Object[] { str }), new Throwable[0]);
        return false;
      } 
      k.c().a(c, String.format("onStartJob for %s", new Object[] { str }), new Throwable[0]);
      this.b.put(str, paramJobParameters);
      map = null;
      int j = Build.VERSION.SDK_INT;
      if (j >= 24) {
        WorkerParameters.a a1 = new WorkerParameters.a();
        if (paramJobParameters.getTriggeredContentUris() != null)
          a1.b = Arrays.asList(paramJobParameters.getTriggeredContentUris()); 
        if (paramJobParameters.getTriggeredContentAuthorities() != null)
          a1.a = Arrays.asList(paramJobParameters.getTriggeredContentAuthorities()); 
        a = a1;
        if (j >= 28) {
          a1.c = paramJobParameters.getNetwork();
          a = a1;
        } 
      } 
      this.a.u(str, a);
      return true;
    } 
  }
  
  public boolean onStopJob(JobParameters paramJobParameters) {
    if (this.a == null) {
      k.c().a(c, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      return true;
    } 
    null = b(paramJobParameters);
    if (TextUtils.isEmpty(null)) {
      k.c().b(c, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    k.c().a(c, String.format("onStopJob for %s", new Object[] { null }), new Throwable[0]);
    synchronized (this.b) {
      this.b.remove(null);
      this.a.w(null);
      return this.a.l().f(null) ^ true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */