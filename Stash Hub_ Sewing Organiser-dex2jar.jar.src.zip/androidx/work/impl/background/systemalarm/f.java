package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import d0.k;
import e0.e;
import l0.p;

public class f implements e {
  private static final String b = k.f("SystemAlarmScheduler");
  
  private final Context a;
  
  public f(Context paramContext) {
    this.a = paramContext.getApplicationContext();
  }
  
  private void a(p paramp) {
    k.c().a(b, String.format("Scheduling work with workSpecId %s", new Object[] { paramp.a }), new Throwable[0]);
    Intent intent = b.f(this.a, paramp.a);
    this.a.startService(intent);
  }
  
  public void b(String paramString) {
    Intent intent = b.g(this.a, paramString);
    this.a.startService(intent);
  }
  
  public void d(p... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++)
      a(paramVarArgs[i]); 
  }
  
  public boolean f() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */