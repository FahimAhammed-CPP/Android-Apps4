package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import d0.k;
import e0.i;

public class RescheduleReceiver extends BroadcastReceiver {
  private static final String a = k.f("RescheduleReceiver");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    k.c().a(a, String.format("Received intent %s", new Object[] { paramIntent }), new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 23)
      try {
        i.j(paramContext).s(goAsync());
        return;
      } catch (IllegalStateException illegalStateException) {
        k.c().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", new Throwable[] { illegalStateException });
        return;
      }  
    illegalStateException.startService(b.e((Context)illegalStateException));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\RescheduleReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */