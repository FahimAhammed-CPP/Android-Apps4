package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import d0.k;
import e0.i;
import l0.g;
import l0.h;
import m0.c;

class a {
  private static final String a = k.f("Alarms");
  
  public static void a(Context paramContext, i parami, String paramString) {
    h h = parami.n().y();
    g g = h.b(paramString);
    if (g != null) {
      b(paramContext, paramString, g.b);
      k.c().a(a, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[] { paramString }), new Throwable[0]);
      h.c(paramString);
    } 
  }
  
  private static void b(Context paramContext, String paramString, int paramInt) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent intent = b.c(paramContext, paramString);
    if (Build.VERSION.SDK_INT >= 23) {
      i = 603979776;
    } else {
      i = 536870912;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, intent, i);
    if (pendingIntent != null && alarmManager != null) {
      k.c().a(a, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", new Object[] { paramString, Integer.valueOf(paramInt) }), new Throwable[0]);
      alarmManager.cancel(pendingIntent);
    } 
  }
  
  public static void c(Context paramContext, i parami, String paramString, long paramLong) {
    int j;
    WorkDatabase workDatabase = parami.n();
    h h = workDatabase.y();
    g g = h.b(paramString);
    if (g != null) {
      b(paramContext, paramString, g.b);
      j = g.b;
    } else {
      j = (new c(workDatabase)).b();
      h.d(new g(paramString, j));
    } 
    d(paramContext, paramString, j, paramLong);
  }
  
  private static void d(Context paramContext, String paramString, int paramInt, long paramLong) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    int j = Build.VERSION.SDK_INT;
    if (j >= 23) {
      i = 201326592;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, b.c(paramContext, paramString), i);
    if (alarmManager != null) {
      if (j >= 19) {
        alarmManager.setExact(0, paramLong, pendingIntent);
        return;
      } 
      alarmManager.set(0, paramLong, pendingIntent);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */