package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import d0.k;
import e0.b;
import h0.c;
import java.util.Collections;
import java.util.List;
import l0.p;
import m0.j;
import m0.n;

public class d implements c, b, n.b {
  private static final String n = k.f("DelayMetCommandHandler");
  
  private final Context a;
  
  private final int b;
  
  private final String c;
  
  private final e d;
  
  private final h0.d e;
  
  private final Object f;
  
  private int g;
  
  private PowerManager.WakeLock l;
  
  private boolean m;
  
  d(Context paramContext, int paramInt, String paramString, e parame) {
    this.a = paramContext;
    this.b = paramInt;
    this.d = parame;
    this.c = paramString;
    this.e = new h0.d(paramContext, parame.f(), this);
    this.m = false;
    this.g = 0;
    this.f = new Object();
  }
  
  private void d() {
    synchronized (this.f) {
      this.e.e();
      this.d.h().c(this.c);
      PowerManager.WakeLock wakeLock = this.l;
      if (wakeLock != null && wakeLock.isHeld()) {
        k.c().a(n, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.l, this.c }), new Throwable[0]);
        this.l.release();
      } 
      return;
    } 
  }
  
  private void g() {
    synchronized (this.f) {
      if (this.g < 2) {
        Intent intent1;
        this.g = 2;
        k k = k.c();
        String str = n;
        k.a(str, String.format("Stopping work for WorkSpec %s", new Object[] { this.c }), new Throwable[0]);
        Intent intent2 = b.g(this.a, this.c);
        e e1 = this.d;
        e1.k(new e.b(e1, intent2, this.b));
        if (this.d.e().g(this.c)) {
          k.c().a(str, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.c }), new Throwable[0]);
          intent1 = b.f(this.a, this.c);
          e e2 = this.d;
          e2.k(new e.b(e2, intent1, this.b));
        } else {
          k.c().a((String)intent1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.c }), new Throwable[0]);
        } 
      } else {
        k.c().a(n, String.format("Already stopped work for %s", new Object[] { this.c }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public void a(String paramString, boolean paramBoolean) {
    k.c().a(n, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    d();
    if (paramBoolean) {
      Intent intent = b.f(this.a, this.c);
      e e1 = this.d;
      e1.k(new e.b(e1, intent, this.b));
    } 
    if (this.m) {
      Intent intent = b.b(this.a);
      e e1 = this.d;
      e1.k(new e.b(e1, intent, this.b));
    } 
  }
  
  public void b(String paramString) {
    k.c().a(n, String.format("Exceeded time limits on execution for %s", new Object[] { paramString }), new Throwable[0]);
    g();
  }
  
  public void c(List<String> paramList) {
    g();
  }
  
  public void e(List<String> paramList) {
    if (!paramList.contains(this.c))
      return; 
    synchronized (this.f) {
      if (this.g == 0) {
        this.g = 1;
        k.c().a(n, String.format("onAllConstraintsMet for %s", new Object[] { this.c }), new Throwable[0]);
        if (this.d.e().j(this.c)) {
          this.d.h().b(this.c, 600000L, this);
        } else {
          d();
        } 
      } else {
        k.c().a(n, String.format("Already started work for %s", new Object[] { this.c }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  void f() {
    this.l = j.b(this.a, String.format("%s (%s)", new Object[] { this.c, Integer.valueOf(this.b) }));
    k k = k.c();
    String str = n;
    k.a(str, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.l, this.c }), new Throwable[0]);
    this.l.acquire();
    p p = this.d.g().n().B().l(this.c);
    if (p == null) {
      g();
      return;
    } 
    boolean bool = p.b();
    this.m = bool;
    if (!bool) {
      k.c().a(str, String.format("No constraints for %s", new Object[] { this.c }), new Throwable[0]);
      e(Collections.singletonList(this.c));
      return;
    } 
    this.e.d(Collections.singletonList(p));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */