package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import d0.k;
import e0.b;
import java.util.HashMap;
import java.util.Map;
import l0.p;

public class b implements b {
  private static final String d = k.f("CommandHandler");
  
  private final Context a;
  
  private final Map<String, b> b;
  
  private final Object c;
  
  b(Context paramContext) {
    this.a = paramContext;
    this.b = new HashMap<String, b>();
    this.c = new Object();
  }
  
  static Intent b(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_CONSTRAINTS_CHANGED");
    return intent;
  }
  
  static Intent c(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_DELAY_MET");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  static Intent d(Context paramContext, String paramString, boolean paramBoolean) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_EXECUTION_COMPLETED");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NEEDS_RESCHEDULE", paramBoolean);
    return intent;
  }
  
  static Intent e(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_RESCHEDULE");
    return intent;
  }
  
  static Intent f(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_SCHEDULE_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  static Intent g(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_STOP_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  private void h(Intent paramIntent, int paramInt, e parame) {
    k.c().a(d, String.format("Handling constraints changed %s", new Object[] { paramIntent }), new Throwable[0]);
    (new c(this.a, paramInt, parame)).a();
  }
  
  private void i(Intent paramIntent, int paramInt, e parame) {
    Bundle bundle = paramIntent.getExtras();
    synchronized (this.c) {
      String str1 = bundle.getString("KEY_WORKSPEC_ID");
      k k = k.c();
      String str2 = d;
      k.a(str2, String.format("Handing delay met for %s", new Object[] { str1 }), new Throwable[0]);
      if (!this.b.containsKey(str1)) {
        d d = new d(this.a, paramInt, str1, parame);
        this.b.put(str1, d);
        d.f();
      } else {
        k.c().a(str2, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", new Object[] { str1 }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  private void j(Intent paramIntent, int paramInt) {
    Bundle bundle = paramIntent.getExtras();
    String str = bundle.getString("KEY_WORKSPEC_ID");
    boolean bool = bundle.getBoolean("KEY_NEEDS_RESCHEDULE");
    k.c().a(d, String.format("Handling onExecutionCompleted %s, %s", new Object[] { paramIntent, Integer.valueOf(paramInt) }), new Throwable[0]);
    a(str, bool);
  }
  
  private void k(Intent paramIntent, int paramInt, e parame) {
    k.c().a(d, String.format("Handling reschedule %s, %s", new Object[] { paramIntent, Integer.valueOf(paramInt) }), new Throwable[0]);
    parame.g().r();
  }
  
  private void l(Intent paramIntent, int paramInt, e parame) {
    null = paramIntent.getExtras().getString("KEY_WORKSPEC_ID");
    k k = k.c();
    String str = d;
    k.a(str, String.format("Handling schedule work for %s", new Object[] { null }), new Throwable[0]);
    WorkDatabase workDatabase = parame.g().n();
    workDatabase.c();
    try {
      k k1;
      StringBuilder stringBuilder;
      p p = workDatabase.B().l(null);
      if (p == null) {
        k1 = k.c();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping scheduling ");
        stringBuilder.append(null);
        stringBuilder.append(" because it's no longer in the DB");
        k1.h(str, stringBuilder.toString(), new Throwable[0]);
        return;
      } 
      if (((p)stringBuilder).b.a()) {
        k1 = k.c();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping scheduling ");
        stringBuilder.append(null);
        stringBuilder.append("because it is finished.");
        k1.h(str, stringBuilder.toString(), new Throwable[0]);
        return;
      } 
      long l = stringBuilder.a();
      if (!stringBuilder.b()) {
        k.c().a(str, String.format("Setting up Alarms for %s at %s", new Object[] { null, Long.valueOf(l) }), new Throwable[0]);
        a.c(this.a, k1.g(), null, l);
      } else {
        k.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", new Object[] { null, Long.valueOf(l) }), new Throwable[0]);
        a.c(this.a, k1.g(), null, l);
        k1.k(new e.b((e)k1, b(this.a), paramInt));
      } 
      workDatabase.r();
      return;
    } finally {
      workDatabase.g();
    } 
  }
  
  private void m(Intent paramIntent, e parame) {
    String str = paramIntent.getExtras().getString("KEY_WORKSPEC_ID");
    k.c().a(d, String.format("Handing stopWork work for %s", new Object[] { str }), new Throwable[0]);
    parame.g().w(str);
    a.a(this.a, parame.g(), str);
    parame.a(str, false);
  }
  
  private static boolean n(Bundle paramBundle, String... paramVarArgs) {
    if (paramBundle != null) {
      if (paramBundle.isEmpty())
        return false; 
      int j = paramVarArgs.length;
      for (int i = 0; i < j; i++) {
        if (paramBundle.get(paramVarArgs[i]) == null)
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.c) {
      b b1 = this.b.remove(paramString);
      if (b1 != null)
        b1.a(paramString, paramBoolean); 
      return;
    } 
  }
  
  boolean o() {
    synchronized (this.c) {
      if (!this.b.isEmpty())
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  void p(Intent paramIntent, int paramInt, e parame) {
    String str = paramIntent.getAction();
    if ("ACTION_CONSTRAINTS_CHANGED".equals(str)) {
      h(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_RESCHEDULE".equals(str)) {
      k(paramIntent, paramInt, parame);
      return;
    } 
    if (!n(paramIntent.getExtras(), new String[] { "KEY_WORKSPEC_ID" })) {
      k.c().b(d, String.format("Invalid request for %s, requires %s.", new Object[] { str, "KEY_WORKSPEC_ID" }), new Throwable[0]);
      return;
    } 
    if ("ACTION_SCHEDULE_WORK".equals(str)) {
      l(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_DELAY_MET".equals(str)) {
      i(paramIntent, paramInt, parame);
      return;
    } 
    if ("ACTION_STOP_WORK".equals(str)) {
      m(paramIntent, parame);
      return;
    } 
    if ("ACTION_EXECUTION_COMPLETED".equals(str)) {
      j(paramIntent, paramInt);
      return;
    } 
    k.c().h(d, String.format("Ignoring intent %s", new Object[] { paramIntent }), new Throwable[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */