package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import d0.b;
import d0.k;
import d0.l;
import java.util.Iterator;
import java.util.List;
import l0.p;

abstract class ConstraintProxy extends BroadcastReceiver {
  private static final String a = k.f("ConstraintProxy");
  
  static void a(Context paramContext, List<p> paramList) {
    boolean bool4;
    int j;
    boolean bool5;
    boolean bool6;
    Iterator<p> iterator = paramList.iterator();
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    int i = 0;
    while (true) {
      bool4 = bool3;
      bool5 = bool2;
      bool6 = bool1;
      j = i;
      if (iterator.hasNext()) {
        byte b;
        b b1 = ((p)iterator.next()).j;
        bool4 = bool3 | b1.f();
        bool5 = bool2 | b1.g();
        bool6 = bool1 | b1.i();
        if (b1.b() != l.a) {
          b = 1;
        } else {
          b = 0;
        } 
        j = i | b;
        bool3 = bool4;
        bool2 = bool5;
        bool1 = bool6;
        i = j;
        if (bool4) {
          bool3 = bool4;
          bool2 = bool5;
          bool1 = bool6;
          i = j;
          if (bool5) {
            bool3 = bool4;
            bool2 = bool5;
            bool1 = bool6;
            i = j;
            if (bool6) {
              bool3 = bool4;
              bool2 = bool5;
              bool1 = bool6;
              i = j;
              if (j != 0)
                break; 
            } 
          } 
        } 
        continue;
      } 
      break;
    } 
    paramContext.sendBroadcast(ConstraintProxyUpdateReceiver.a(paramContext, bool4, bool5, bool6, j));
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    k.c().a(a, String.format("onReceive : %s", new Object[] { paramIntent }), new Throwable[0]);
    paramContext.startService(b.b(paramContext));
  }
  
  public static class BatteryChargingProxy extends ConstraintProxy {}
  
  public static class BatteryNotLowProxy extends ConstraintProxy {}
  
  public static class NetworkStateProxy extends ConstraintProxy {}
  
  public static class StorageNotLowProxy extends ConstraintProxy {}
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */