package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import d0.k;
import e0.b;
import e0.i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import m0.g;
import m0.j;
import m0.n;

public class e implements b {
  static final String o = k.f("SystemAlarmDispatcher");
  
  final Context a;
  
  private final n0.a b;
  
  private final n c;
  
  private final e0.d d;
  
  private final i e;
  
  final b f;
  
  private final Handler g;
  
  final List<Intent> l;
  
  Intent m;
  
  private c n;
  
  e(Context paramContext) {
    this(paramContext, null, null);
  }
  
  e(Context paramContext, e0.d paramd, i parami) {
    Context context = paramContext.getApplicationContext();
    this.a = context;
    this.f = new b(context);
    this.c = new n();
    if (parami == null)
      parami = i.j(paramContext); 
    this.e = parami;
    if (paramd == null)
      paramd = parami.l(); 
    this.d = paramd;
    this.b = parami.o();
    paramd.d(this);
    this.l = new ArrayList<Intent>();
    this.m = null;
    this.g = new Handler(Looper.getMainLooper());
  }
  
  private void c() {
    if (this.g.getLooper().getThread() == Thread.currentThread())
      return; 
    throw new IllegalStateException("Needs to be invoked on the main thread.");
  }
  
  private boolean i(String paramString) {
    c();
    synchronized (this.l) {
      Iterator<Intent> iterator = this.l.iterator();
      while (iterator.hasNext()) {
        if (paramString.equals(((Intent)iterator.next()).getAction()))
          return true; 
      } 
      return false;
    } 
  }
  
  private void l() {
    c();
    PowerManager.WakeLock wakeLock = j.b(this.a, "ProcessCommand");
    try {
      wakeLock.acquire();
      this.e.o().b(new a(this));
      return;
    } finally {
      wakeLock.release();
    } 
  }
  
  public void a(String paramString, boolean paramBoolean) {
    k(new b(this, b.d(this.a, paramString, paramBoolean), 0));
  }
  
  public boolean b(Intent paramIntent, int paramInt) {
    // Byte code:
    //   0: invokestatic c : ()Ld0/k;
    //   3: astore #5
    //   5: getstatic androidx/work/impl/background/systemalarm/e.o : Ljava/lang/String;
    //   8: astore #4
    //   10: iconst_0
    //   11: istore_3
    //   12: aload #5
    //   14: aload #4
    //   16: ldc 'Adding command %s (%s)'
    //   18: iconst_2
    //   19: anewarray java/lang/Object
    //   22: dup
    //   23: iconst_0
    //   24: aload_1
    //   25: aastore
    //   26: dup
    //   27: iconst_1
    //   28: iload_2
    //   29: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   32: aastore
    //   33: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   36: iconst_0
    //   37: anewarray java/lang/Throwable
    //   40: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   43: aload_0
    //   44: invokespecial c : ()V
    //   47: aload_1
    //   48: invokevirtual getAction : ()Ljava/lang/String;
    //   51: astore #5
    //   53: aload #5
    //   55: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   58: ifeq -> 77
    //   61: invokestatic c : ()Ld0/k;
    //   64: aload #4
    //   66: ldc 'Unknown command. Ignoring'
    //   68: iconst_0
    //   69: anewarray java/lang/Throwable
    //   72: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   75: iconst_0
    //   76: ireturn
    //   77: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   79: aload #5
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: ifeq -> 98
    //   87: aload_0
    //   88: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   90: invokespecial i : (Ljava/lang/String;)Z
    //   93: ifeq -> 98
    //   96: iconst_0
    //   97: ireturn
    //   98: aload_1
    //   99: ldc 'KEY_START_ID'
    //   101: iload_2
    //   102: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   105: pop
    //   106: aload_0
    //   107: getfield l : Ljava/util/List;
    //   110: astore #4
    //   112: aload #4
    //   114: monitorenter
    //   115: iload_3
    //   116: istore_2
    //   117: aload_0
    //   118: getfield l : Ljava/util/List;
    //   121: invokeinterface isEmpty : ()Z
    //   126: ifne -> 131
    //   129: iconst_1
    //   130: istore_2
    //   131: aload_0
    //   132: getfield l : Ljava/util/List;
    //   135: aload_1
    //   136: invokeinterface add : (Ljava/lang/Object;)Z
    //   141: pop
    //   142: iload_2
    //   143: ifne -> 150
    //   146: aload_0
    //   147: invokespecial l : ()V
    //   150: aload #4
    //   152: monitorexit
    //   153: iconst_1
    //   154: ireturn
    //   155: astore_1
    //   156: aload #4
    //   158: monitorexit
    //   159: aload_1
    //   160: athrow
    // Exception table:
    //   from	to	target	type
    //   117	129	155	finally
    //   131	142	155	finally
    //   146	150	155	finally
    //   150	153	155	finally
    //   156	159	155	finally
  }
  
  void d() {
    k k = k.c();
    null = o;
    k.a(null, "Checking if commands are complete.", new Throwable[0]);
    c();
    synchronized (this.l) {
      if (this.m != null) {
        k.c().a(null, String.format("Removing command %s", new Object[] { this.m }), new Throwable[0]);
        if (((Intent)this.l.remove(0)).equals(this.m)) {
          this.m = null;
        } else {
          throw new IllegalStateException("Dequeue-d command is not the first.");
        } 
      } 
      g g = this.b.c();
      if (!this.f.o() && this.l.isEmpty() && !g.a()) {
        k.c().a(null, "No more commands & intents.", new Throwable[0]);
        c c1 = this.n;
        if (c1 != null)
          c1.c(); 
      } else if (!this.l.isEmpty()) {
        l();
      } 
      return;
    } 
  }
  
  e0.d e() {
    return this.d;
  }
  
  n0.a f() {
    return this.b;
  }
  
  i g() {
    return this.e;
  }
  
  n h() {
    return this.c;
  }
  
  void j() {
    k.c().a(o, "Destroying SystemAlarmDispatcher", new Throwable[0]);
    this.d.i(this);
    this.c.a();
    this.n = null;
  }
  
  void k(Runnable paramRunnable) {
    this.g.post(paramRunnable);
  }
  
  void m(c paramc) {
    if (this.n != null) {
      k.c().b(o, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    this.n = paramc;
  }
  
  class a implements Runnable {
    a(e this$0) {}
    
    public void run() {
      List<Intent> list;
      e e1;
      synchronized (this.a.l) {
        e.d d;
        e e2 = this.a;
        e2.m = e2.l.get(0);
        Intent intent = this.a.m;
        if (intent != null) {
          String str1 = intent.getAction();
          int i = this.a.m.getIntExtra("KEY_START_ID", 0);
          k k = k.c();
          String str2 = e.o;
          k.a(str2, String.format("Processing command %s, %s", new Object[] { this.a.m, Integer.valueOf(i) }), new Throwable[0]);
          PowerManager.WakeLock wakeLock = j.b(this.a.a, String.format("%s (%s)", new Object[] { str1, Integer.valueOf(i) }));
          try {
            k.c().a(str2, String.format("Acquiring operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.acquire();
            e e3 = this.a;
            e3.f.p(e3.m, i, e3);
            k.c().a(str2, String.format("Releasing operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.release();
            e1 = this.a;
          } finally {
            str2 = null;
          } 
        } else {
          return;
        } 
        e1.k(d);
        return;
      } 
    }
  }
  
  static class b implements Runnable {
    private final e a;
    
    private final Intent b;
    
    private final int c;
    
    b(e param1e, Intent param1Intent, int param1Int) {
      this.a = param1e;
      this.b = param1Intent;
      this.c = param1Int;
    }
    
    public void run() {
      this.a.b(this.b, this.c);
    }
  }
  
  static interface c {
    void c();
  }
  
  static class d implements Runnable {
    private final e a;
    
    d(e param1e) {
      this.a = param1e;
    }
    
    public void run() {
      this.a.d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */