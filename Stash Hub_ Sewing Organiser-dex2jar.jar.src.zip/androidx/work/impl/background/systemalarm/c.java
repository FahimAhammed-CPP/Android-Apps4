package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import d0.k;
import h0.d;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import l0.p;

class c {
  private static final String e = k.f("ConstraintsCmdHandler");
  
  private final Context a;
  
  private final int b;
  
  private final e c;
  
  private final d d;
  
  c(Context paramContext, int paramInt, e parame) {
    this.a = paramContext;
    this.b = paramInt;
    this.c = parame;
    this.d = new d(paramContext, parame.f(), null);
  }
  
  void a() {
    List<p> list = this.c.g().n().B().q();
    ConstraintProxy.a(this.a, list);
    this.d.d(list);
    ArrayList<p> arrayList = new ArrayList(list.size());
    long l = System.currentTimeMillis();
    for (p p : list) {
      String str = p.a;
      if (l >= p.a() && (!p.b() || this.d.c(str)))
        arrayList.add(p); 
    } 
    Iterator<p> iterator = arrayList.iterator();
    while (iterator.hasNext()) {
      String str = ((p)iterator.next()).a;
      Intent intent = b.c(this.a, str);
      k.c().a(e, String.format("Creating a delay_met command for workSpec with id (%s)", new Object[] { str }), new Throwable[0]);
      e e1 = this.c;
      e1.k(new e.b(e1, intent, this.b));
    } 
    this.d.e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */