package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import androidx.lifecycle.m;
import d0.k;
import m0.j;

public class SystemAlarmService extends m implements e.c {
  private static final String d = k.f("SystemAlarmService");
  
  private e b;
  
  private boolean c;
  
  private void g() {
    e e1 = new e((Context)this);
    this.b = e1;
    e1.m(this);
  }
  
  public void c() {
    this.c = true;
    k.c().a(d, "All commands completed in dispatcher", new Throwable[0]);
    j.a();
    stopSelf();
  }
  
  public void onCreate() {
    super.onCreate();
    g();
    this.c = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.c = true;
    this.b.j();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.c) {
      k.c().d(d, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.b.j();
      g();
      this.c = false;
    } 
    if (paramIntent != null)
      this.b.b(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */