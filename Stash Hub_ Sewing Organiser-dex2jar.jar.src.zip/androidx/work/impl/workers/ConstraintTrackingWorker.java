package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.d;
import d0.k;
import e0.i;
import h0.c;
import h0.d;
import java.util.Collections;
import java.util.List;
import l0.p;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  private static final String o = k.f("ConstraintTrkngWrkr");
  
  private WorkerParameters f;
  
  final Object g;
  
  volatile boolean l;
  
  c<ListenableWorker.a> m;
  
  private ListenableWorker n;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.f = paramWorkerParameters;
    this.g = new Object();
    this.l = false;
    this.m = c.t();
  }
  
  public void c(List<String> paramList) {
    k.c().a(o, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.g) {
      this.l = true;
      return;
    } 
  }
  
  public void e(List<String> paramList) {}
  
  public n0.a h() {
    return i.j(a()).o();
  }
  
  public boolean j() {
    ListenableWorker listenableWorker = this.n;
    return (listenableWorker != null && listenableWorker.j());
  }
  
  public void m() {
    super.m();
    ListenableWorker listenableWorker = this.n;
    if (listenableWorker != null && !listenableWorker.k())
      this.n.q(); 
  }
  
  public d<ListenableWorker.a> p() {
    b().execute(new a(this));
    return (d<ListenableWorker.a>)this.m;
  }
  
  public WorkDatabase r() {
    return i.j(a()).n();
  }
  
  void s() {
    this.m.p(ListenableWorker.a.a());
  }
  
  void t() {
    this.m.p(ListenableWorker.a.b());
  }
  
  void u() {
    String str = g().i("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
    if (TextUtils.isEmpty(str)) {
      k.c().b(o, "No worker to delegate to.", new Throwable[0]);
    } else {
      ListenableWorker listenableWorker = i().b(a(), str, this.f);
      this.n = listenableWorker;
      if (listenableWorker == null) {
        k.c().a(o, "No worker to delegate to.", new Throwable[0]);
      } else {
        p p = r().B().l(f().toString());
        if (p == null) {
          s();
          return;
        } 
        d d = new d(a(), h(), this);
        d.d(Collections.singletonList(p));
        if (d.c(f().toString())) {
          k.c().a(o, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
          try {
            return;
          } finally {
            d = null;
            k k = k.c();
            null = o;
            k.a(null, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)d });
          } 
        } 
        k.c().a(o, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
        t();
        return;
      } 
    } 
    s();
  }
  
  class a implements Runnable {
    a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      this.a.u();
    }
  }
  
  class b implements Runnable {
    b(ConstraintTrackingWorker this$0, d param1d) {}
    
    public void run() {
      synchronized (this.b.g) {
        if (this.b.l) {
          this.b.t();
        } else {
          this.b.m.r(this.a);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */