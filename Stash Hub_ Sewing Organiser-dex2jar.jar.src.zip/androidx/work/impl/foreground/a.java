package androidx.work.impl.foreground;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import d0.e;
import d0.k;
import e0.b;
import e0.i;
import h0.c;
import h0.d;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import l0.p;

public class a implements c, b {
  static final String o = k.f("SystemFgDispatcher");
  
  private Context a;
  
  private i b;
  
  private final n0.a c;
  
  final Object d;
  
  String e;
  
  final Map<String, e> f;
  
  final Map<String, p> g;
  
  final Set<p> l;
  
  final d m;
  
  private b n;
  
  a(Context paramContext) {
    this.a = paramContext;
    this.d = new Object();
    i i1 = i.j(paramContext);
    this.b = i1;
    n0.a a1 = i1.o();
    this.c = a1;
    this.e = null;
    this.f = new LinkedHashMap<String, e>();
    this.l = new HashSet<p>();
    this.g = new HashMap<String, p>();
    this.m = new d(this.a, a1, this);
    this.b.l().d(this);
  }
  
  public static Intent b(Context paramContext, String paramString, e parame) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_NOTIFY");
    intent.putExtra("KEY_NOTIFICATION_ID", parame.c());
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", parame.a());
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)parame.b());
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent d(Context paramContext, String paramString, e parame) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_START_FOREGROUND");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NOTIFICATION_ID", parame.c());
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", parame.a());
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)parame.b());
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent f(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_STOP_FOREGROUND");
    return intent;
  }
  
  private void g(Intent paramIntent) {
    k.c().d(o, String.format("Stopping foreground work for %s", new Object[] { paramIntent }), new Throwable[0]);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    if (str != null && !TextUtils.isEmpty(str))
      this.b.e(UUID.fromString(str)); 
  }
  
  private void h(Intent paramIntent) {
    int j = 0;
    int k = paramIntent.getIntExtra("KEY_NOTIFICATION_ID", 0);
    int m = paramIntent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    Notification notification = (Notification)paramIntent.getParcelableExtra("KEY_NOTIFICATION");
    k.c().a(o, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", new Object[] { Integer.valueOf(k), str, Integer.valueOf(m) }), new Throwable[0]);
    if (notification != null && this.n != null) {
      e e = new e(k, notification, m);
      this.f.put(str, e);
      if (TextUtils.isEmpty(this.e)) {
        this.e = str;
        this.n.e(k, m, notification);
        return;
      } 
      this.n.f(k, notification);
      if (m != 0 && Build.VERSION.SDK_INT >= 29) {
        Iterator<Map.Entry> iterator = this.f.entrySet().iterator();
        while (iterator.hasNext())
          j |= ((e)((Map.Entry)iterator.next()).getValue()).a(); 
        e e1 = this.f.get(this.e);
        if (e1 != null)
          this.n.e(e1.c(), j, e1.b()); 
      } 
    } 
  }
  
  private void i(Intent paramIntent) {
    k.c().d(o, String.format("Started foreground service %s", new Object[] { paramIntent }), new Throwable[0]);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    WorkDatabase workDatabase = this.b.n();
    this.c.b(new a(this, workDatabase, str));
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.d) {
      p p = this.g.remove(paramString);
      if (p != null) {
        paramBoolean = this.l.remove(p);
      } else {
        paramBoolean = false;
      } 
      if (paramBoolean)
        this.m.d(this.l); 
      null = this.f.remove(paramString);
      if (paramString.equals(this.e) && this.f.size() > 0) {
        Iterator<Map.Entry> iterator = this.f.entrySet().iterator();
        while (true) {
          Map.Entry entry = iterator.next();
          if (iterator.hasNext())
            continue; 
          this.e = (String)entry.getKey();
          if (this.n != null) {
            e e = (e)entry.getValue();
            this.n.e(e.c(), e.a(), e.b());
            this.n.d(e.c());
          } 
          break;
        } 
      } 
      b b1 = this.n;
      if (null != null && b1 != null) {
        k.c().a(o, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", new Object[] { Integer.valueOf(null.c()), paramString, Integer.valueOf(null.a()) }), new Throwable[0]);
        b1.d(null.c());
      } 
      return;
    } 
  }
  
  public void c(List<String> paramList) {
    if (!paramList.isEmpty())
      for (String str : paramList) {
        k.c().a(o, String.format("Constraints unmet for WorkSpec %s", new Object[] { str }), new Throwable[0]);
        this.b.v(str);
      }  
  }
  
  public void e(List<String> paramList) {}
  
  void j(Intent paramIntent) {
    k.c().d(o, "Stopping foreground service", new Throwable[0]);
    b b1 = this.n;
    if (b1 != null)
      b1.b(); 
  }
  
  void k() {
    this.n = null;
    synchronized (this.d) {
      this.m.e();
      this.b.l().i(this);
      return;
    } 
  }
  
  void l(Intent paramIntent) {
    String str = paramIntent.getAction();
    if ("ACTION_START_FOREGROUND".equals(str)) {
      i(paramIntent);
    } else if (!"ACTION_NOTIFY".equals(str)) {
      if ("ACTION_CANCEL_WORK".equals(str)) {
        g(paramIntent);
        return;
      } 
      if ("ACTION_STOP_FOREGROUND".equals(str))
        j(paramIntent); 
      return;
    } 
    h(paramIntent);
  }
  
  void m(b paramb) {
    if (this.n != null) {
      k.c().b(o, "A callback already exists.", new Throwable[0]);
      return;
    } 
    this.n = paramb;
  }
  
  class a implements Runnable {
    a(a this$0, WorkDatabase param1WorkDatabase, String param1String) {}
    
    public void run() {
      p p = this.a.B().l(this.b);
      if (p != null && p.b())
        synchronized (this.c.d) {
          this.c.g.put(this.b, p);
          this.c.l.add(p);
          a a1 = this.c;
          a1.m.d(a1.l);
          return;
        }  
    }
  }
  
  static interface b {
    void b();
    
    void d(int param1Int);
    
    void e(int param1Int1, int param1Int2, Notification param1Notification);
    
    void f(int param1Int, Notification param1Notification);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\impl\foreground\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */