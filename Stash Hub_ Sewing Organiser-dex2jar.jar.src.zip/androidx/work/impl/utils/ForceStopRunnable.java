package androidx.work.impl.utils;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.ApplicationExitInfo;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.os.Build;
import android.text.TextUtils;
import androidx.core.os.a;
import androidx.work.a;
import androidx.work.impl.WorkDatabase;
import d0.g;
import d0.k;
import d0.t;
import e0.f;
import e0.h;
import e0.i;
import g0.b;
import java.util.List;
import java.util.concurrent.TimeUnit;
import l0.n;
import l0.p;
import l0.q;
import m0.f;

public class ForceStopRunnable implements Runnable {
  private static final String d = k.f("ForceStopRunnable");
  
  private static final long e = TimeUnit.DAYS.toMillis(3650L);
  
  private final Context a;
  
  private final i b;
  
  private int c;
  
  public ForceStopRunnable(Context paramContext, i parami) {
    this.a = paramContext.getApplicationContext();
    this.b = parami;
    this.c = 0;
  }
  
  static Intent c(Context paramContext) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return intent;
  }
  
  private static PendingIntent d(Context paramContext, int paramInt) {
    return PendingIntent.getBroadcast(paramContext, -1, c(paramContext), paramInt);
  }
  
  static void g(Context paramContext) {
    int j;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (a.b()) {
      j = 167772160;
    } else {
      j = 134217728;
    } 
    PendingIntent pendingIntent = d(paramContext, j);
    long l = System.currentTimeMillis() + e;
    if (alarmManager != null) {
      if (Build.VERSION.SDK_INT >= 19) {
        alarmManager.setExact(0, l, pendingIntent);
        return;
      } 
      alarmManager.set(0, l, pendingIntent);
    } 
  }
  
  public boolean a() {
    boolean bool1;
    int j = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    if (j >= 23) {
      bool1 = b.i(this.a, this.b);
    } else {
      bool1 = false;
    } 
    WorkDatabase workDatabase = this.b.n();
    null = workDatabase.B();
    n n = workDatabase.A();
    workDatabase.c();
    try {
      List list = null.b();
      if (list != null && !list.isEmpty()) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 0)
        for (p p : list) {
          null.j(t.a, new String[] { p.a });
          null.d(p.a, -1L);
        }  
      n.b();
      workDatabase.r();
      workDatabase.g();
      return bool2;
    } finally {
      workDatabase.g();
    } 
  }
  
  public void b() {
    boolean bool = a();
    if (h()) {
      k.c().a(d, "Rescheduling Workers.", new Throwable[0]);
      this.b.r();
      this.b.k().c(false);
      return;
    } 
    if (e()) {
      k.c().a(d, "Application was force-stopped, rescheduling.", new Throwable[0]);
      this.b.r();
      return;
    } 
    if (bool) {
      k.c().a(d, "Found unfinished work, scheduling it.", new Throwable[0]);
      f.b(this.b.h(), this.b.n(), this.b.m());
    } 
  }
  
  public boolean e() {
    int j = 536870912;
    try {
      List<ApplicationExitInfo> list;
      if (a.b())
        j = 570425344; 
      PendingIntent pendingIntent = d(this.a, j);
      if (Build.VERSION.SDK_INT >= 30) {
        if (pendingIntent != null)
          pendingIntent.cancel(); 
        list = ((ActivityManager)this.a.getSystemService("activity")).getHistoricalProcessExitReasons(null, 0, 0);
        if (list != null && !list.isEmpty())
          for (j = 0;; j++) {
            if (j < list.size()) {
              if (((ApplicationExitInfo)list.get(j)).getReason() == 10)
                return true; 
            } else {
              return false;
            } 
          }  
      } else if (list == null) {
        g(this.a);
        return true;
      } 
      return false;
    } catch (SecurityException securityException) {
    
    } catch (IllegalArgumentException illegalArgumentException) {}
    k.c().h(d, "Ignoring exception", new Throwable[] { illegalArgumentException });
    return true;
  }
  
  public boolean f() {
    a a = this.b.h();
    if (TextUtils.isEmpty(a.c())) {
      k.c().a(d, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = f.b(this.a, a);
    k.c().a(d, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  boolean h() {
    return this.b.k().a();
  }
  
  public void i(long paramLong) {
    try {
      Thread.sleep(paramLong);
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public void run() {
    try {
      boolean bool = f();
      if (!bool)
        return; 
      while (true) {
        h.e(this.a);
        k.c().a(d, "Performing cleanup operations.", new Throwable[0]);
        try {
          b();
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
          IllegalStateException illegalStateException;
          int j = this.c + 1;
          this.c = j;
          if (j >= 3) {
            k k = k.c();
            String str = d;
            k.b(str, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { (Throwable)sQLiteCantOpenDatabaseException });
            illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)sQLiteCantOpenDatabaseException);
            g g = this.b.h().d();
            if (g != null) {
              k.c().a(str, "Routing exception to the specified exception handler", new Throwable[] { illegalStateException });
              g.a(illegalStateException);
            } else {
              throw illegalStateException;
            } 
          } else {
            long l = j;
            k.c().a(d, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { illegalStateException });
            i(this.c * 300L);
            continue;
          } 
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        return;
      } 
    } finally {
      this.b.q();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    private static final String a = k.f("ForceStopRunnable$Rcvr");
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        k.c().g(a, "Rescheduling alarm that keeps track of force-stops.", new Throwable[0]);
        ForceStopRunnable.g(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */