package androidx.work.impl.utils.futures;

import com.google.common.util.concurrent.d;

public final class c<V> extends a<V> {
  public static <V> c<V> t() {
    return new c<V>();
  }
  
  public boolean p(V paramV) {
    return super.p(paramV);
  }
  
  public boolean q(Throwable paramThrowable) {
    return super.q(paramThrowable);
  }
  
  public boolean r(d<? extends V> paramd) {
    return super.r(paramd);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\imp\\utils\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */