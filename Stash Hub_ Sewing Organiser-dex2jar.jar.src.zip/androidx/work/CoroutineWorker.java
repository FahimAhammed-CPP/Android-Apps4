package androidx.work;

import android.content.Context;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.d;
import d0.e;
import d0.j;
import h8.c2;
import h8.g1;
import h8.g2;
import h8.i;
import h8.j0;
import h8.p0;
import h8.q0;
import h8.z;
import java.util.concurrent.Executor;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.l;
import o7.o;
import o7.u;
import r7.d;
import r7.g;
import y7.p;

public abstract class CoroutineWorker extends ListenableWorker {
  private final z f = g2.b(null, 1, null);
  
  private final c<ListenableWorker.a> g;
  
  private final j0 l;
  
  public CoroutineWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    c<ListenableWorker.a> c1 = c.t();
    l.e(c1, "create()");
    this.g = c1;
    c1.a(new a(this), (Executor)h().c());
    this.l = g1.a();
  }
  
  public final d<e> d() {
    z z1 = g2.b(null, 1, null);
    p0 p0 = q0.a(s().k0((g)z1));
    j<e> j = new j((c2)z1, null, 2, null);
    i.d(p0, null, null, new b(j, this, null), 3, null);
    return (d<e>)j;
  }
  
  public final void m() {
    super.m();
    this.g.cancel(false);
  }
  
  public final d<ListenableWorker.a> p() {
    i.d(q0.a(s().k0((g)this.f)), null, null, new c(this, null), 3, null);
    return (d<ListenableWorker.a>)this.g;
  }
  
  public abstract Object r(d<? super ListenableWorker.a> paramd);
  
  public j0 s() {
    return this.l;
  }
  
  public Object t(d<? super e> paramd) {
    return u(this, paramd);
  }
  
  public final c<ListenableWorker.a> v() {
    return this.g;
  }
  
  public final z w() {
    return this.f;
  }
  
  static final class a implements Runnable {
    a(CoroutineWorker param1CoroutineWorker) {}
    
    public final void run() {
      if (this.a.v().isCancelled())
        c2.a.a((c2)this.a.w(), null, 1, null); 
    }
  }
  
  @f(c = "androidx.work.CoroutineWorker$getForegroundInfoAsync$1", f = "CoroutineWorker.kt", l = {134}, m = "invokeSuspend")
  static final class b extends l implements p<p0, d<? super u>, Object> {
    Object a;
    
    int b;
    
    b(j<e> param1j, CoroutineWorker param1CoroutineWorker, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      return (d<u>)new b(this.c, this.d, (d)param1d);
    }
    
    public final Object invoke(p0 param1p0, d<? super u> param1d) {
      return ((b)create(param1p0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object<e> param1Object) {
      Object object1;
      Object<e> object = (Object<e>)s7.b.c();
      int i = this.b;
      if (i != 0) {
        if (i == 1) {
          object = (Object<e>)this.a;
          o.b(param1Object);
          object1 = param1Object;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        o.b(param1Object);
        param1Object = (Object<e>)this.c;
        CoroutineWorker coroutineWorker = this.d;
        this.a = param1Object;
        this.b = 1;
        object1 = coroutineWorker.t((d<? super e>)this);
        if (object1 == object)
          return object; 
        object = param1Object;
      } 
      object.c(object1);
      return u.a;
    }
  }
  
  @f(c = "androidx.work.CoroutineWorker$startWork$1", f = "CoroutineWorker.kt", l = {68}, m = "invokeSuspend")
  static final class c extends l implements p<p0, d<? super u>, Object> {
    int a;
    
    c(CoroutineWorker param1CoroutineWorker, d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      return (d<u>)new c(this.b, (d)param1d);
    }
    
    public final Object invoke(p0 param1p0, d<? super u> param1d) {
      return ((c)create(param1p0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = s7.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1) {
          try {
            o.b(param1Object);
          } finally {}
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        o.b(param1Object);
        param1Object = this.b;
        this.a = 1;
        Object object1 = param1Object.r((d<? super ListenableWorker.a>)this);
        param1Object = object1;
        if (object1 == object)
          return object; 
      } 
      param1Object = param1Object;
      this.b.v().p(param1Object);
      return u.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\CoroutineWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */