package androidx.work;

import android.net.Network;
import android.net.Uri;
import d0.f;
import d0.p;
import d0.w;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters {
  private UUID a;
  
  private b b;
  
  private Set<String> c;
  
  private a d;
  
  private int e;
  
  private Executor f;
  
  private n0.a g;
  
  private w h;
  
  private p i;
  
  private f j;
  
  public WorkerParameters(UUID paramUUID, b paramb, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, n0.a parama1, w paramw, p paramp, f paramf) {
    this.a = paramUUID;
    this.b = paramb;
    this.c = new HashSet<String>(paramCollection);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutor;
    this.g = parama1;
    this.h = paramw;
    this.i = paramp;
    this.j = paramf;
  }
  
  public Executor a() {
    return this.f;
  }
  
  public f b() {
    return this.j;
  }
  
  public UUID c() {
    return this.a;
  }
  
  public b d() {
    return this.b;
  }
  
  public n0.a e() {
    return this.g;
  }
  
  public w f() {
    return this.h;
  }
  
  public static class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */