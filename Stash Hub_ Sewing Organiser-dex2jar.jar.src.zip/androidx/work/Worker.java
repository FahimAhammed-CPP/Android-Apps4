package androidx.work;

import android.content.Context;
import androidx.annotation.Keep;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.d;

public abstract class Worker extends ListenableWorker {
  c<ListenableWorker.a> f;
  
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public final d<ListenableWorker.a> p() {
    this.f = c.t();
    b().execute(new a(this));
    return (d<ListenableWorker.a>)this.f;
  }
  
  public abstract ListenableWorker.a r();
  
  class a implements Runnable {
    a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.a.f.q(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */