package androidx.startup;

import a0.b;
import a0.c;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class a {
  private static volatile a d;
  
  private static final Object e = new Object();
  
  final Map<Class<?>, Object> a;
  
  final Set<Class<? extends a0.a<?>>> b;
  
  final Context c;
  
  a(Context paramContext) {
    this.c = paramContext.getApplicationContext();
    this.b = new HashSet<Class<? extends a0.a<?>>>();
    this.a = new HashMap<Class<?>, Object>();
  }
  
  private <T> T c(Class<? extends a0.a<?>> paramClass, Set<Class<?>> paramSet) {
    // Byte code:
    //   0: invokestatic h : ()Z
    //   3: ifeq -> 13
    //   6: aload_1
    //   7: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   10: invokestatic c : (Ljava/lang/String;)V
    //   13: aload_2
    //   14: aload_1
    //   15: invokeinterface contains : (Ljava/lang/Object;)Z
    //   20: ifne -> 199
    //   23: aload_0
    //   24: getfield a : Ljava/util/Map;
    //   27: aload_1
    //   28: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   33: ifne -> 183
    //   36: aload_2
    //   37: aload_1
    //   38: invokeinterface add : (Ljava/lang/Object;)Z
    //   43: pop
    //   44: aload_1
    //   45: iconst_0
    //   46: anewarray java/lang/Class
    //   49: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   52: iconst_0
    //   53: anewarray java/lang/Object
    //   56: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   59: checkcast a0/a
    //   62: astore_3
    //   63: aload_3
    //   64: invokeinterface a : ()Ljava/util/List;
    //   69: astore #4
    //   71: aload #4
    //   73: invokeinterface isEmpty : ()Z
    //   78: ifne -> 137
    //   81: aload #4
    //   83: invokeinterface iterator : ()Ljava/util/Iterator;
    //   88: astore #4
    //   90: aload #4
    //   92: invokeinterface hasNext : ()Z
    //   97: ifeq -> 137
    //   100: aload #4
    //   102: invokeinterface next : ()Ljava/lang/Object;
    //   107: checkcast java/lang/Class
    //   110: astore #5
    //   112: aload_0
    //   113: getfield a : Ljava/util/Map;
    //   116: aload #5
    //   118: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   123: ifne -> 90
    //   126: aload_0
    //   127: aload #5
    //   129: aload_2
    //   130: invokespecial c : (Ljava/lang/Class;Ljava/util/Set;)Ljava/lang/Object;
    //   133: pop
    //   134: goto -> 90
    //   137: aload_3
    //   138: aload_0
    //   139: getfield c : Landroid/content/Context;
    //   142: invokeinterface b : (Landroid/content/Context;)Ljava/lang/Object;
    //   147: astore_3
    //   148: aload_2
    //   149: aload_1
    //   150: invokeinterface remove : (Ljava/lang/Object;)Z
    //   155: pop
    //   156: aload_0
    //   157: getfield a : Ljava/util/Map;
    //   160: aload_1
    //   161: aload_3
    //   162: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   167: pop
    //   168: aload_3
    //   169: astore_1
    //   170: goto -> 194
    //   173: astore_1
    //   174: new a0/c
    //   177: dup
    //   178: aload_1
    //   179: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   182: athrow
    //   183: aload_0
    //   184: getfield a : Ljava/util/Map;
    //   187: aload_1
    //   188: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   193: astore_1
    //   194: invokestatic f : ()V
    //   197: aload_1
    //   198: areturn
    //   199: new java/lang/IllegalStateException
    //   202: dup
    //   203: ldc 'Cannot initialize %s. Cycle detected.'
    //   205: iconst_1
    //   206: anewarray java/lang/Object
    //   209: dup
    //   210: iconst_0
    //   211: aload_1
    //   212: invokevirtual getName : ()Ljava/lang/String;
    //   215: aastore
    //   216: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   219: invokespecial <init> : (Ljava/lang/String;)V
    //   222: athrow
    //   223: astore_1
    //   224: invokestatic f : ()V
    //   227: aload_1
    //   228: athrow
    // Exception table:
    //   from	to	target	type
    //   6	13	223	finally
    //   13	44	223	finally
    //   44	90	173	finally
    //   90	134	173	finally
    //   137	168	173	finally
    //   174	183	223	finally
    //   183	194	223	finally
    //   199	223	223	finally
  }
  
  public static a d(Context paramContext) {
    if (d == null)
      synchronized (e) {
        if (d == null)
          d = new a(paramContext); 
      }  
    return d;
  }
  
  void a() {
    Exception exception;
    try {
      b0.a.c("Startup");
      ComponentName componentName = new ComponentName(this.c.getPackageName(), InitializationProvider.class.getName());
      b((this.c.getPackageManager().getProviderInfo(componentName, 128)).metaData);
      b0.a.f();
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new c(nameNotFoundException);
    } finally {}
    b0.a.f();
    throw exception;
  }
  
  void b(Bundle paramBundle) {
    String str = this.c.getString(b.a);
    if (paramBundle != null)
      try {
        HashSet<Class<?>> hashSet = new HashSet();
        for (String str1 : paramBundle.keySet()) {
          if (str.equals(paramBundle.getString(str1, null))) {
            Class<?> clazz = Class.forName(str1);
            if (a0.a.class.isAssignableFrom(clazz))
              this.b.add(clazz); 
          } 
        } 
        Iterator<Class<? extends a0.a<?>>> iterator = this.b.iterator();
        while (iterator.hasNext())
          c(iterator.next(), hashSet); 
      } catch (ClassNotFoundException classNotFoundException) {
        throw new c(classNotFoundException);
      }  
  }
  
  public boolean e(Class<? extends a0.a<?>> paramClass) {
    return this.b.contains(paramClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\startup\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */