package androidx.lifecycle;

@Deprecated
class ReflectiveGenericLifecycleObserver implements h {
  private final Object a;
  
  private final a.a b;
  
  ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.a = paramObject;
    this.b = a.c.c(paramObject.getClass());
  }
  
  public void a(j paramj, e.a parama) {
    this.b.a(paramj, parama, this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */