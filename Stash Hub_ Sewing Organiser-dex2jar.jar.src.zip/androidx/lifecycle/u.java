package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public class u extends Fragment {
  public static final b b = new b(null);
  
  private a a;
  
  private final void a(e.a parama) {
    if (Build.VERSION.SDK_INT < 29) {
      b b1 = b;
      Activity activity = getActivity();
      l.e(activity, "activity");
      b1.a(activity, parama);
    } 
  }
  
  private final void b(a parama) {
    if (parama != null)
      parama.a(); 
  }
  
  private final void c(a parama) {
    if (parama != null)
      parama.b(); 
  }
  
  private final void d(a parama) {
    if (parama != null)
      parama.c(); 
  }
  
  public static final void e(Activity paramActivity) {
    b.c(paramActivity);
  }
  
  public final void f(a parama) {
    this.a = parama;
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    b(this.a);
    a(e.a.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    a(e.a.ON_DESTROY);
    this.a = null;
  }
  
  public void onPause() {
    super.onPause();
    a(e.a.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    c(this.a);
    a(e.a.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    d(this.a);
    a(e.a.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    a(e.a.ON_STOP);
  }
  
  public static interface a {
    void a();
    
    void b();
    
    void c();
  }
  
  public static final class b {
    private b() {}
    
    public final void a(Activity param1Activity, e.a param1a) {
      l.f(param1Activity, "activity");
      l.f(param1a, "event");
      if (param1Activity instanceof l) {
        ((l)param1Activity).a().h(param1a);
        return;
      } 
      if (param1Activity instanceof j) {
        e e = ((j)param1Activity).a();
        if (e instanceof k)
          ((k)e).h(param1a); 
      } 
    }
    
    public final u b(Activity param1Activity) {
      l.f(param1Activity, "<this>");
      Fragment fragment = param1Activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
      l.d(fragment, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
      return (u)fragment;
    }
    
    public final void c(Activity param1Activity) {
      l.f(param1Activity, "activity");
      if (Build.VERSION.SDK_INT >= 29)
        u.c.Companion.a(param1Activity); 
      FragmentManager fragmentManager = param1Activity.getFragmentManager();
      if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
        fragmentManager.beginTransaction().add(new u(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
        fragmentManager.executePendingTransactions();
      } 
    }
  }
  
  public static final class c implements Application.ActivityLifecycleCallbacks {
    public static final a Companion = new a(null);
    
    public static final void registerIn(Activity param1Activity) {
      Companion.a(param1Activity);
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
    }
    
    public void onActivityDestroyed(Activity param1Activity) {
      l.f(param1Activity, "activity");
    }
    
    public void onActivityPaused(Activity param1Activity) {
      l.f(param1Activity, "activity");
    }
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      l.f(param1Activity, "activity");
      u.b.a(param1Activity, e.a.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {
      l.f(param1Activity, "activity");
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      l.f(param1Bundle, "bundle");
    }
    
    public void onActivityStarted(Activity param1Activity) {
      l.f(param1Activity, "activity");
    }
    
    public void onActivityStopped(Activity param1Activity) {
      l.f(param1Activity, "activity");
    }
    
    public static final class a {
      private a() {}
      
      public final void a(Activity param2Activity) {
        l.f(param2Activity, "activity");
        param2Activity.registerActivityLifecycleCallbacks(new u.c());
      }
    }
  }
  
  public static final class a {
    private a() {}
    
    public final void a(Activity param1Activity) {
      l.f(param1Activity, "activity");
      param1Activity.registerActivityLifecycleCallbacks(new u.c());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */