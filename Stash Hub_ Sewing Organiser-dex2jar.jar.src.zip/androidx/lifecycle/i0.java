package androidx.lifecycle;

import android.view.View;
import kotlin.jvm.internal.l;
import r.e;

public final class i0 {
  public static final void a(View paramView, g0 paramg0) {
    l.f(paramView, "<this>");
    paramView.setTag(e.a, paramg0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */