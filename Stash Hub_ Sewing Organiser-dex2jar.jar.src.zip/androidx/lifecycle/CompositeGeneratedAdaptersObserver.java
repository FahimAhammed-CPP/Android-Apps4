package androidx.lifecycle;

import kotlin.jvm.internal.l;

public final class CompositeGeneratedAdaptersObserver implements h {
  private final c[] a;
  
  public CompositeGeneratedAdaptersObserver(c[] paramArrayOfc) {
    this.a = paramArrayOfc;
  }
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    o o = new o();
    c[] arrayOfC = this.a;
    int k = arrayOfC.length;
    boolean bool = false;
    int i;
    for (i = 0; i < k; i++)
      arrayOfC[i].a(paramj, parama, false, o); 
    arrayOfC = this.a;
    k = arrayOfC.length;
    for (i = bool; i < k; i++)
      arrayOfC[i].a(paramj, parama, true, o); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */