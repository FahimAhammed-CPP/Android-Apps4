package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.jvm.internal.l;

public final class g {
  public static final g a = new g();
  
  private static final AtomicBoolean b = new AtomicBoolean(false);
  
  public static final void a(Context paramContext) {
    l.f(paramContext, "context");
    if (b.getAndSet(true))
      return; 
    paramContext = paramContext.getApplicationContext();
    l.d(paramContext, "null cannot be cast to non-null type android.app.Application");
    ((Application)paramContext).registerActivityLifecycleCallbacks(new a());
  }
  
  public static final class a extends b {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      u.b.c(param1Activity);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */