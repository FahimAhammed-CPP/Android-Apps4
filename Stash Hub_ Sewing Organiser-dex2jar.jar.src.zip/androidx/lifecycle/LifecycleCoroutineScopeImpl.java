package androidx.lifecycle;

import h8.g2;
import kotlin.jvm.internal.l;
import r7.g;

public final class LifecycleCoroutineScopeImpl extends f implements h {
  private final e a;
  
  private final g b;
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    if (b().b().compareTo(e.b.a) <= 0) {
      b().c(this);
      g2.d(d(), null, 1, null);
    } 
  }
  
  public e b() {
    return this.a;
  }
  
  public g d() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScopeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */