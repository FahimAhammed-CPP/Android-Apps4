package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public final class t implements j {
  public static final b m = new b(null);
  
  private static final t n = new t();
  
  private int a;
  
  private int b;
  
  private boolean c = true;
  
  private boolean d = true;
  
  private Handler e;
  
  private final k f = new k(this);
  
  private final Runnable g = new s(this);
  
  private final u.a l = new d(this);
  
  private static final void l(t paramt) {
    l.f(paramt, "this$0");
    paramt.m();
    paramt.n();
  }
  
  public static final j o() {
    return m.a();
  }
  
  public e a() {
    return this.f;
  }
  
  public final void e() {
    int i = this.b - 1;
    this.b = i;
    if (i == 0) {
      Handler handler = this.e;
      l.c(handler);
      handler.postDelayed(this.g, 700L);
    } 
  }
  
  public final void f() {
    int i = this.b + 1;
    this.b = i;
    if (i == 1) {
      if (this.c) {
        this.f.h(e.a.ON_RESUME);
        this.c = false;
        return;
      } 
      Handler handler = this.e;
      l.c(handler);
      handler.removeCallbacks(this.g);
    } 
  }
  
  public final void g() {
    int i = this.a + 1;
    this.a = i;
    if (i == 1 && this.d) {
      this.f.h(e.a.ON_START);
      this.d = false;
    } 
  }
  
  public final void h() {
    this.a--;
    n();
  }
  
  public final void i(Context paramContext) {
    l.f(paramContext, "context");
    this.e = new Handler();
    this.f.h(e.a.ON_CREATE);
    paramContext = paramContext.getApplicationContext();
    l.d(paramContext, "null cannot be cast to non-null type android.app.Application");
    ((Application)paramContext).registerActivityLifecycleCallbacks(new c());
  }
  
  public final void m() {
    if (this.b == 0) {
      this.c = true;
      this.f.h(e.a.ON_PAUSE);
    } 
  }
  
  public final void n() {
    if (this.a == 0 && this.c) {
      this.f.h(e.a.ON_STOP);
      this.d = true;
    } 
  }
  
  public static final class a {
    public static final a a = new a();
    
    public static final void a(Activity param1Activity, Application.ActivityLifecycleCallbacks param1ActivityLifecycleCallbacks) {
      l.f(param1Activity, "activity");
      l.f(param1ActivityLifecycleCallbacks, "callback");
      param1Activity.registerActivityLifecycleCallbacks(param1ActivityLifecycleCallbacks);
    }
  }
  
  public static final class b {
    private b() {}
    
    public final j a() {
      return t.d();
    }
    
    public final void b(Context param1Context) {
      l.f(param1Context, "context");
      t.d().i(param1Context);
    }
  }
  
  public static final class c extends b {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      if (Build.VERSION.SDK_INT < 29)
        u.b.b(param1Activity).f(t.c(t.this)); 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      l.f(param1Activity, "activity");
      t.this.e();
    }
    
    public void onActivityPreCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      t.a.a(param1Activity, new a());
    }
    
    public void onActivityStopped(Activity param1Activity) {
      l.f(param1Activity, "activity");
      t.this.h();
    }
    
    public static final class a extends b {
      public void onActivityPostResumed(Activity param2Activity) {
        l.f(param2Activity, "activity");
        t.this.f();
      }
      
      public void onActivityPostStarted(Activity param2Activity) {
        l.f(param2Activity, "activity");
        t.this.g();
      }
    }
  }
  
  public static final class a extends b {
    public void onActivityPostResumed(Activity param1Activity) {
      l.f(param1Activity, "activity");
      t.this.f();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      l.f(param1Activity, "activity");
      t.this.g();
    }
  }
  
  public static final class d implements u.a {
    d(t param1t) {}
    
    public void a() {}
    
    public void b() {
      this.a.f();
    }
    
    public void c() {
      this.a.g();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */