package androidx.lifecycle;

import android.app.Application;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public class c0 {
  private final f0 a;
  
  private final b b;
  
  private final r.a c;
  
  public c0(f0 paramf0, b paramb) {
    this(paramf0, paramb, null, 4, null);
  }
  
  public c0(f0 paramf0, b paramb, r.a parama) {
    this.a = paramf0;
    this.b = paramb;
    this.c = parama;
  }
  
  public c0(g0 paramg0, b paramb) {
    this(paramg0.e(), paramb, e0.a(paramg0));
  }
  
  public <T extends b0> T a(Class<T> paramClass) {
    l.f(paramClass, "modelClass");
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends b0> T b(String paramString, Class<T> paramClass) {
    b b1;
    r.d d1;
    l.f(paramString, "key");
    l.f(paramClass, "modelClass");
    b0 b0 = this.a.b(paramString);
    if (paramClass.isInstance(b0)) {
      b1 = this.b;
      if (b1 instanceof d) {
        d d = (d)b1;
      } else {
        b1 = null;
      } 
      if (b1 != null) {
        l.c(b0);
        b1.a(b0);
      } 
      l.d(b0, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
      return (T)b0;
    } 
    r.d d2 = new r.d(this.c);
    d2.b(c.c, b1);
    try {
      d2 = this.b.b((Class)paramClass, (r.a)d2);
      d1 = d2;
    } catch (AbstractMethodError abstractMethodError) {
      d1 = this.b.a((Class<r.d>)d1);
    } 
    this.a.d((String)b1, (b0)d1);
    return (T)d1;
  }
  
  public static class a extends c {
    public static final a d = new a(null);
    
    public static final r.a.b<Application> e = a.a.a;
    
    public static final class a {
      private a() {}
      
      private static final class a implements r.a.b<Application> {
        public static final a a = new a();
      }
    }
    
    private static final class a implements r.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  public static final class a {
    private a() {}
    
    private static final class a implements r.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  private static final class a implements r.a.b<Application> {
    public static final a a = new a();
  }
  
  public static interface b {
    public static final a a = a.a;
    
    <T extends b0> T a(Class<T> param1Class);
    
    <T extends b0> T b(Class<T> param1Class, r.a param1a);
    
    public static final class a {}
  }
  
  public static final class a {}
  
  public static class c implements b {
    public static final a b = new a(null);
    
    public static final r.a.b<String> c = a.a.a;
    
    public static final class a {
      private a() {}
      
      private static final class a implements r.a.b<String> {
        public static final a a = new a();
      }
    }
    
    private static final class a implements r.a.b<String> {
      public static final a a = new a();
    }
  }
  
  public static final class a {
    private a() {}
    
    private static final class a implements r.a.b<String> {
      public static final a a = new a();
    }
  }
  
  private static final class a implements r.a.b<String> {
    public static final a a = new a();
  }
  
  public static class d {
    public void a(b0 param1b0) {
      l.f(param1b0, "viewModel");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */