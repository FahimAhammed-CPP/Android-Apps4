package androidx.lifecycle;

import android.os.Handler;
import kotlin.jvm.internal.l;

public class a0 {
  private final k a;
  
  private final Handler b;
  
  private a c;
  
  public a0(j paramj) {
    this.a = new k(paramj);
    this.b = new Handler();
  }
  
  private final void f(e.a parama) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, parama);
    this.c = a1;
    Handler handler = this.b;
    l.c(a1);
    handler.postAtFrontOfQueue(a1);
  }
  
  public e a() {
    return this.a;
  }
  
  public void b() {
    f(e.a.ON_START);
  }
  
  public void c() {
    f(e.a.ON_CREATE);
  }
  
  public void d() {
    f(e.a.ON_STOP);
    f(e.a.ON_DESTROY);
  }
  
  public void e() {
    f(e.a.ON_START);
  }
  
  public static final class a implements Runnable {
    private final k a;
    
    private final e.a b;
    
    private boolean c;
    
    public a(k param1k, e.a param1a) {
      this.a = param1k;
      this.b = param1a;
    }
    
    public void run() {
      if (!this.c) {
        this.a.h(this.b);
        this.c = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */