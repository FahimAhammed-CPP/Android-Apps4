package androidx.lifecycle;

public class p<T> extends LiveData<T> {
  public void k(T paramT) {
    super.k(paramT);
  }
  
  public void m(T paramT) {
    super.m(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */