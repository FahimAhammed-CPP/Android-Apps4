package androidx.lifecycle;

import android.os.Bundle;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.w;
import y7.l;

public final class x {
  public static final r.a.b<x.d> a = new b();
  
  public static final r.a.b<g0> b = new c();
  
  public static final r.a.b<Bundle> c = new a();
  
  public static final <T extends x.d & g0> void a(T paramT) {
    boolean bool;
    l.f(paramT, "<this>");
    e.b b1 = paramT.a().b();
    if (b1 == e.b.b || b1 == e.b.c) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramT.k().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
        y y = new y(paramT.k(), (g0)paramT);
        paramT.k().h("androidx.lifecycle.internal.SavedStateHandlesProvider", y);
        paramT.a().a(new SavedStateHandleAttacher(y));
      } 
      return;
    } 
    throw new IllegalArgumentException("Failed requirement.".toString());
  }
  
  public static final z b(g0 paramg0) {
    l.f(paramg0, "<this>");
    r.c c = new r.c();
    d d = d.a;
    c.a(w.b(z.class), d);
    return (new c0(paramg0, c.b())).<z>b("androidx.lifecycle.internal.SavedStateHandlesVM", z.class);
  }
  
  public static final class a implements r.a.b<Bundle> {}
  
  public static final class b implements r.a.b<x.d> {}
  
  public static final class c implements r.a.b<g0> {}
  
  static final class d extends m implements l<r.a, z> {
    public static final d a = new d();
    
    d() {
      super(1);
    }
    
    public final z a(r.a param1a) {
      l.f(param1a, "$this$initializer");
      return new z();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */