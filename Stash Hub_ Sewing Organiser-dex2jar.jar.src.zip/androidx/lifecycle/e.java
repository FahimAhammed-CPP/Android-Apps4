package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public abstract class e {
  private AtomicReference<Object> a = new AtomicReference();
  
  public abstract void a(i parami);
  
  public abstract b b();
  
  public abstract void c(i parami);
  
  public enum a {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    public static final a Companion;
    
    static {
      ON_PAUSE = new a("ON_PAUSE", 3);
      ON_STOP = new a("ON_STOP", 4);
      ON_DESTROY = new a("ON_DESTROY", 5);
      ON_ANY = new a("ON_ANY", 6);
      $VALUES = a();
      Companion = new a(null);
    }
    
    public final e.b g() {
      StringBuilder stringBuilder;
      switch (b.a[ordinal()]) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append(this);
          stringBuilder.append(" has no target state");
          throw new IllegalArgumentException(stringBuilder.toString());
        case 6:
          return e.b.a;
        case 5:
          return e.b.e;
        case 3:
        case 4:
          return e.b.d;
        case 1:
        case 2:
          break;
      } 
      return e.b.c;
    }
    
    public static final class a {
      private a() {}
      
      public final e.a a(e.b param2b) {
        l.f(param2b, "state");
        int i = a.a[param2b.ordinal()];
        return (i != 1) ? ((i != 2) ? ((i != 3) ? null : e.a.ON_PAUSE) : e.a.ON_STOP) : e.a.ON_DESTROY;
      }
      
      public final e.a b(e.b param2b) {
        l.f(param2b, "state");
        int i = a.a[param2b.ordinal()];
        return (i != 1) ? ((i != 2) ? ((i != 5) ? null : e.a.ON_CREATE) : e.a.ON_RESUME) : e.a.ON_START;
      }
    }
  }
  
  public static final class a {
    private a() {}
    
    public final e.a a(e.b param1b) {
      l.f(param1b, "state");
      int i = a.a[param1b.ordinal()];
      return (i != 1) ? ((i != 2) ? ((i != 3) ? null : e.a.ON_PAUSE) : e.a.ON_STOP) : e.a.ON_DESTROY;
    }
    
    public final e.a b(e.b param1b) {
      l.f(param1b, "state");
      int i = a.a[param1b.ordinal()];
      return (i != 1) ? ((i != 2) ? ((i != 5) ? null : e.a.ON_CREATE) : e.a.ON_RESUME) : e.a.ON_START;
    }
  }
  
  public enum b {
    a, b, c, d, e;
    
    public final boolean g(b param1b) {
      l.f(param1b, "state");
      return (compareTo((E)param1b) >= 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */