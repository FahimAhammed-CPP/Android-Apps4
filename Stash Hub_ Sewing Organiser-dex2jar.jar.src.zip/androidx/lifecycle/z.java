package androidx.lifecycle;

import java.util.LinkedHashMap;
import java.util.Map;

public final class z extends b0 {
  private final Map<String, w> d = new LinkedHashMap<String, w>();
  
  public final Map<String, w> e() {
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */