package androidx.lifecycle;

import f8.f;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;
import p7.m;

public final class n {
  public static final n a = new n();
  
  private static final Map<Class<?>, Integer> b = new HashMap<Class<?>, Integer>();
  
  private static final Map<Class<?>, List<Constructor<? extends c>>> c = new HashMap<Class<?>, List<Constructor<? extends c>>>();
  
  private final c a(Constructor<? extends c> paramConstructor, Object paramObject) {
    try {
      paramConstructor = (Constructor<? extends c>)paramConstructor.newInstance(new Object[] { paramObject });
      l.e(paramConstructor, "{\n            constructo…tance(`object`)\n        }");
      return (c)paramConstructor;
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  private final Constructor<? extends c> b(Class<?> paramClass) {
    boolean bool;
    String str1;
    try {
      Package package_ = paramClass.getPackage();
      str2 = paramClass.getCanonicalName();
      if (package_ != null) {
        str1 = package_.getName();
      } else {
        str1 = "";
      } 
      l.e(str1, "fullPackage");
      if (str1.length() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
    } catch (ClassNotFoundException null) {
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } 
    if (!bool) {
      l.e(str2, "name");
      str2 = str2.substring(str1.length() + 1);
      l.e(str2, "this as java.lang.String).substring(startIndex)");
    } 
    l.e(str2, "if (fullPackage.isEmpty(…g(fullPackage.length + 1)");
    String str2 = c(str2);
    if (str1.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      str1 = str2;
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append('.');
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    Class<?> clazz = Class.forName(str1);
    l.d(clazz, "null cannot be cast to non-null type java.lang.Class<out androidx.lifecycle.GeneratedAdapter>");
    Constructor<?> constructor2 = clazz.getDeclaredConstructor(new Class[] { (Class)noSuchMethodException });
    Constructor<?> constructor1 = constructor2;
    if (!constructor2.isAccessible()) {
      constructor2.setAccessible(true);
      return (Constructor)constructor2;
    } 
    return (Constructor)constructor1;
  }
  
  public static final String c(String paramString) {
    l.f(paramString, "className");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(f.n(paramString, ".", "_", false, 4, null));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  private final int d(Class<?> paramClass) {
    Map<Class<?>, Integer> map = b;
    Integer integer = map.get(paramClass);
    if (integer != null)
      return integer.intValue(); 
    int i = g(paramClass);
    map.put(paramClass, Integer.valueOf(i));
    return i;
  }
  
  private final boolean e(Class<?> paramClass) {
    return (paramClass != null && i.class.isAssignableFrom(paramClass));
  }
  
  public static final h f(Object paramObject) {
    l.f(paramObject, "object");
    boolean bool1 = paramObject instanceof h;
    boolean bool2 = paramObject instanceof DefaultLifecycleObserver;
    if (bool1 && bool2)
      return new DefaultLifecycleObserverAdapter((DefaultLifecycleObserver)paramObject, (h)paramObject); 
    if (bool2)
      return new DefaultLifecycleObserverAdapter((DefaultLifecycleObserver)paramObject, null); 
    if (bool1)
      return (h)paramObject; 
    Class<?> clazz = paramObject.getClass();
    n n1 = a;
    if (n1.d(clazz) == 2) {
      clazz = (Class<?>)c.get(clazz);
      l.c(clazz);
      List<Constructor<? extends c>> list = (List)clazz;
      int j = list.size();
      int i = 0;
      if (j == 1)
        return new SingleGeneratedAdapterObserver(n1.a(list.get(0), paramObject)); 
      j = list.size();
      c[] arrayOfC = new c[j];
      while (i < j) {
        arrayOfC[i] = a.a(list.get(i), paramObject);
        i++;
      } 
      return new CompositeGeneratedAdaptersObserver(arrayOfC);
    } 
    return new ReflectiveGenericLifecycleObserver(paramObject);
  }
  
  private final int g(Class<?> paramClass) {
    if (paramClass.getCanonicalName() == null)
      return 1; 
    Constructor<? extends c> constructor = b(paramClass);
    if (constructor != null) {
      c.put(paramClass, m.b(constructor));
      return 2;
    } 
    if (a.c.d(paramClass))
      return 1; 
    Class<?> clazz = paramClass.getSuperclass();
    ArrayList<Constructor<? extends c>> arrayList = null;
    if (e(clazz)) {
      l.e(clazz, "superclass");
      if (d(clazz) == 1)
        return 1; 
      clazz = (Class<?>)c.get(clazz);
      l.c(clazz);
      arrayList = new ArrayList((Collection)clazz);
    } 
    Class[] arrayOfClass = paramClass.getInterfaces();
    l.e(arrayOfClass, "klass.interfaces");
    int i = 0;
    int j = arrayOfClass.length;
    while (i < j) {
      ArrayList<Constructor<? extends c>> arrayList1;
      Class<?> clazz1 = arrayOfClass[i];
      if (!e(clazz1)) {
        arrayList1 = arrayList;
      } else {
        l.e(clazz1, "intrface");
        if (d(clazz1) == 1)
          return 1; 
        arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList = (ArrayList<Constructor<? extends c>>)c.get(clazz1);
        l.c(arrayList);
        arrayList1.addAll(arrayList);
      } 
      i++;
      arrayList = arrayList1;
    } 
    if (arrayList != null) {
      c.put(paramClass, arrayList);
      return 2;
    } 
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */