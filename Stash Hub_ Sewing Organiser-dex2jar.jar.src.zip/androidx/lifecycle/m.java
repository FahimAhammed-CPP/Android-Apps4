package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import kotlin.jvm.internal.l;

public class m extends Service implements j {
  private final a0 a = new a0(this);
  
  public e a() {
    return this.a.a();
  }
  
  public IBinder onBind(Intent paramIntent) {
    l.f(paramIntent, "intent");
    this.a.b();
    return null;
  }
  
  public void onCreate() {
    this.a.c();
    super.onCreate();
  }
  
  public void onDestroy() {
    this.a.d();
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.a.e();
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */