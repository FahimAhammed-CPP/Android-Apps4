package androidx.lifecycle;

import kotlin.jvm.internal.l;

public final class DefaultLifecycleObserverAdapter implements h {
  private final DefaultLifecycleObserver a;
  
  private final h b;
  
  public DefaultLifecycleObserverAdapter(DefaultLifecycleObserver paramDefaultLifecycleObserver, h paramh) {
    this.a = paramDefaultLifecycleObserver;
    this.b = paramh;
  }
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    switch (a.a[parama.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.a.onDestroy(paramj);
        break;
      case 5:
        this.a.onStop(paramj);
        break;
      case 4:
        this.a.onPause(paramj);
        break;
      case 3:
        this.a.onResume(paramj);
        break;
      case 2:
        this.a.onStart(paramj);
        break;
      case 1:
        this.a.onCreate(paramj);
        break;
    } 
    h h1 = this.b;
    if (h1 != null)
      h1.a(paramj, parama); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\DefaultLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */