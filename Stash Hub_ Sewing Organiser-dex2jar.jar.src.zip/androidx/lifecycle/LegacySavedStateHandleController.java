package androidx.lifecycle;

import java.util.Iterator;
import kotlin.jvm.internal.l;
import x.d;

public final class LegacySavedStateHandleController {
  public static final LegacySavedStateHandleController a = new LegacySavedStateHandleController();
  
  public static final void a(b0 paramb0, androidx.savedstate.a parama, e parame) {
    l.f(paramb0, "viewModel");
    l.f(parama, "registry");
    l.f(parame, "lifecycle");
    SavedStateHandleController savedStateHandleController = paramb0.<SavedStateHandleController>c("androidx.lifecycle.savedstate.vm.tag");
    if (savedStateHandleController != null && !savedStateHandleController.c()) {
      savedStateHandleController.b(parama, parame);
      a.b(parama, parame);
    } 
  }
  
  private final void b(androidx.savedstate.a parama, e parame) {
    e.b b = parame.b();
    if (b == e.b.b || b.g(e.b.d)) {
      parama.i(a.class);
      return;
    } 
    parame.a(new LegacySavedStateHandleController$tryToAddRecreator$1(parame, parama));
  }
  
  public static final class a implements androidx.savedstate.a.a {
    public void a(d param1d) {
      l.f(param1d, "owner");
      if (param1d instanceof g0) {
        f0 f0 = ((g0)param1d).e();
        androidx.savedstate.a a1 = param1d.k();
        Iterator<String> iterator = f0.c().iterator();
        while (iterator.hasNext()) {
          b0 b0 = f0.b(iterator.next());
          l.c(b0);
          LegacySavedStateHandleController.a(b0, a1, param1d.a());
        } 
        if ((f0.c().isEmpty() ^ true) != 0)
          a1.i(a.class); 
        return;
      } 
      throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner".toString());
    }
  }
  
  public static final class LegacySavedStateHandleController$tryToAddRecreator$1 implements h {
    LegacySavedStateHandleController$tryToAddRecreator$1(e param1e, androidx.savedstate.a param1a) {}
    
    public void a(j param1j, e.a param1a) {
      l.f(param1j, "source");
      l.f(param1a, "event");
      if (param1a == e.a.ON_START) {
        this.a.c(this);
        this.b.i(LegacySavedStateHandleController.a.class);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\LegacySavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */