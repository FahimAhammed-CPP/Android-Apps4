package androidx.lifecycle;

import androidx.savedstate.a;
import kotlin.jvm.internal.l;

public final class SavedStateHandleController implements h {
  private final String a;
  
  private final w b;
  
  private boolean c;
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    if (parama == e.a.ON_DESTROY) {
      this.c = false;
      paramj.a().c(this);
    } 
  }
  
  public final void b(a parama, e parame) {
    l.f(parama, "registry");
    l.f(parame, "lifecycle");
    if ((this.c ^ true) != 0) {
      this.c = true;
      parame.a(this);
      parama.h(this.a, this.b.c());
      return;
    } 
    throw new IllegalStateException("Already attached to lifecycleOwner".toString());
  }
  
  public final boolean c() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */