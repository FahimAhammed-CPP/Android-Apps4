package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import kotlin.jvm.internal.l;

public class b implements Application.ActivityLifecycleCallbacks {
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    l.f(paramActivity, "activity");
  }
  
  public void onActivityDestroyed(Activity paramActivity) {
    l.f(paramActivity, "activity");
  }
  
  public void onActivityPaused(Activity paramActivity) {
    l.f(paramActivity, "activity");
  }
  
  public void onActivityResumed(Activity paramActivity) {
    l.f(paramActivity, "activity");
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {
    l.f(paramActivity, "activity");
    l.f(paramBundle, "outState");
  }
  
  public void onActivityStarted(Activity paramActivity) {
    l.f(paramActivity, "activity");
  }
  
  public void onActivityStopped(Activity paramActivity) {
    l.f(paramActivity, "activity");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */