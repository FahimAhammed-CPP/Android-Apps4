package androidx.lifecycle;

import d.c;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.l;

public class k extends e {
  public static final a j = new a(null);
  
  private final boolean b;
  
  private e.a<i, b> c;
  
  private e.b d;
  
  private final WeakReference<j> e;
  
  private int f;
  
  private boolean g;
  
  private boolean h;
  
  private ArrayList<e.b> i;
  
  public k(j paramj) {
    this(paramj, true);
  }
  
  private k(j paramj, boolean paramBoolean) {
    this.b = paramBoolean;
    this.c = new e.a();
    this.d = e.b.b;
    this.i = new ArrayList<e.b>();
    this.e = new WeakReference<j>(paramj);
  }
  
  private final void d(j paramj) {
    Iterator<Map.Entry> iterator = this.c.descendingIterator();
    l.e(iterator, "observerMap.descendingIterator()");
    while (iterator.hasNext() && !this.h) {
      Map.Entry entry = iterator.next();
      l.e(entry, "next()");
      i i = (i)entry.getKey();
      b b1 = (b)entry.getValue();
      while (b1.b().compareTo(this.d) > 0 && !this.h && this.c.contains(i)) {
        e.a a1 = e.a.Companion.a(b1.b());
        if (a1 != null) {
          m(a1.g());
          b1.a(paramj, a1);
          l();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(b1.b());
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private final e.b e(i parami) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Le/a;
    //   4: aload_1
    //   5: invokevirtual p : (Ljava/lang/Object;)Ljava/util/Map$Entry;
    //   8: astore_1
    //   9: aconst_null
    //   10: astore_2
    //   11: aload_1
    //   12: ifnull -> 37
    //   15: aload_1
    //   16: invokeinterface getValue : ()Ljava/lang/Object;
    //   21: checkcast androidx/lifecycle/k$b
    //   24: astore_1
    //   25: aload_1
    //   26: ifnull -> 37
    //   29: aload_1
    //   30: invokevirtual b : ()Landroidx/lifecycle/e$b;
    //   33: astore_1
    //   34: goto -> 39
    //   37: aconst_null
    //   38: astore_1
    //   39: aload_0
    //   40: getfield i : Ljava/util/ArrayList;
    //   43: invokeinterface isEmpty : ()Z
    //   48: iconst_1
    //   49: ixor
    //   50: ifeq -> 72
    //   53: aload_0
    //   54: getfield i : Ljava/util/ArrayList;
    //   57: astore_2
    //   58: aload_2
    //   59: aload_2
    //   60: invokevirtual size : ()I
    //   63: iconst_1
    //   64: isub
    //   65: invokevirtual get : (I)Ljava/lang/Object;
    //   68: checkcast androidx/lifecycle/e$b
    //   71: astore_2
    //   72: getstatic androidx/lifecycle/k.j : Landroidx/lifecycle/k$a;
    //   75: astore_3
    //   76: aload_3
    //   77: aload_3
    //   78: aload_0
    //   79: getfield d : Landroidx/lifecycle/e$b;
    //   82: aload_1
    //   83: invokevirtual a : (Landroidx/lifecycle/e$b;Landroidx/lifecycle/e$b;)Landroidx/lifecycle/e$b;
    //   86: aload_2
    //   87: invokevirtual a : (Landroidx/lifecycle/e$b;Landroidx/lifecycle/e$b;)Landroidx/lifecycle/e$b;
    //   90: areturn
  }
  
  private final void f(String paramString) {
    if (this.b) {
      if (c.g().b())
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Method ");
      stringBuilder.append(paramString);
      stringBuilder.append(" must be called on the main thread");
      throw new IllegalStateException(stringBuilder.toString().toString());
    } 
  }
  
  private final void g(j paramj) {
    e.b.d<Map.Entry> d = this.c.g();
    l.e(d, "observerMap.iteratorWithAdditions()");
    while (d.hasNext() && !this.h) {
      Map.Entry entry = d.next();
      i i = (i)entry.getKey();
      b b1 = (b)entry.getValue();
      while (b1.b().compareTo(this.d) < 0 && !this.h && this.c.contains(i)) {
        m(b1.b());
        e.a a1 = e.a.Companion.b(b1.b());
        if (a1 != null) {
          b1.a(paramj, a1);
          l();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(b1.b());
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private final boolean i() {
    if (this.c.size() == 0)
      return true; 
    Map.Entry entry1 = this.c.a();
    l.c(entry1);
    e.b b1 = ((b)entry1.getValue()).b();
    Map.Entry entry2 = this.c.k();
    l.c(entry2);
    e.b b2 = ((b)entry2.getValue()).b();
    return (b1 == b2 && this.d == b2);
  }
  
  private final void k(e.b paramb) {
    boolean bool;
    e.b b1 = this.d;
    if (b1 == paramb)
      return; 
    if (b1 != e.b.b || paramb != e.b.a) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      this.d = paramb;
      if (this.g || this.f != 0) {
        this.h = true;
        return;
      } 
      this.g = true;
      o();
      this.g = false;
      if (this.d == e.b.a)
        this.c = new e.a(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("no event down from ");
    stringBuilder.append(this.d);
    stringBuilder.append(" in component ");
    stringBuilder.append(this.e.get());
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  private final void l() {
    ArrayList<e.b> arrayList = this.i;
    arrayList.remove(arrayList.size() - 1);
  }
  
  private final void m(e.b paramb) {
    this.i.add(paramb);
  }
  
  private final void o() {
    j j = this.e.get();
    if (j != null) {
      while (true) {
        boolean bool = i();
        this.h = false;
        if (!bool) {
          e.b b1 = this.d;
          Map.Entry entry2 = this.c.a();
          l.c(entry2);
          if (b1.compareTo(((b)entry2.getValue()).b()) < 0)
            d(j); 
          Map.Entry entry1 = this.c.k();
          if (!this.h && entry1 != null && this.d.compareTo(((b)entry1.getValue()).b()) > 0)
            g(j); 
          continue;
        } 
        break;
      } 
      return;
    } 
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
  }
  
  public void a(i parami) {
    boolean bool;
    l.f(parami, "observer");
    f("addObserver");
    e.b b3 = this.d;
    e.b b1 = e.b.a;
    if (b3 != b1)
      b1 = e.b.b; 
    b b2 = new b(parami, b1);
    if ((b)this.c.n(parami, b2) != null)
      return; 
    j j = this.e.get();
    if (j == null)
      return; 
    if (this.f != 0 || this.g) {
      bool = true;
    } else {
      bool = false;
    } 
    b1 = e(parami);
    this.f++;
    while (b2.b().compareTo(b1) < 0 && this.c.contains(parami)) {
      m(b2.b());
      e.a a1 = e.a.Companion.b(b2.b());
      if (a1 != null) {
        b2.a(j, a1);
        l();
        e.b b4 = e(parami);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(b2.b());
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      o(); 
    this.f--;
  }
  
  public e.b b() {
    return this.d;
  }
  
  public void c(i parami) {
    l.f(parami, "observer");
    f("removeObserver");
    this.c.o(parami);
  }
  
  public void h(e.a parama) {
    l.f(parama, "event");
    f("handleLifecycleEvent");
    k(parama.g());
  }
  
  public void j(e.b paramb) {
    l.f(paramb, "state");
    f("markState");
    n(paramb);
  }
  
  public void n(e.b paramb) {
    l.f(paramb, "state");
    f("setCurrentState");
    k(paramb);
  }
  
  public static final class a {
    private a() {}
    
    public final e.b a(e.b param1b1, e.b param1b2) {
      l.f(param1b1, "state1");
      e.b b1 = param1b1;
      if (param1b2 != null) {
        b1 = param1b1;
        if (param1b2.compareTo(param1b1) < 0)
          b1 = param1b2; 
      } 
      return b1;
    }
  }
  
  public static final class b {
    private e.b a;
    
    private h b;
    
    public b(i param1i, e.b param1b) {
      l.c(param1i);
      this.b = n.f(param1i);
      this.a = param1b;
    }
    
    public final void a(j param1j, e.a param1a) {
      l.f(param1a, "event");
      e.b b1 = param1a.g();
      this.a = k.j.a(this.a, b1);
      h h1 = this.b;
      l.c(param1j);
      h1.a(param1j, param1a);
      this.a = b1;
    }
    
    public final e.b b() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */