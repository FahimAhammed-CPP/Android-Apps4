package androidx.lifecycle;

import android.os.Bundle;
import androidx.savedstate.a;
import java.util.Map;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import o7.g;
import o7.h;

public final class y implements a.c {
  private final a a;
  
  private boolean b;
  
  private Bundle c;
  
  private final g d;
  
  public y(a parama, g0 paramg0) {
    this.a = parama;
    this.d = h.a(new a(paramg0));
  }
  
  private final z b() {
    return (z)this.d.getValue();
  }
  
  public Bundle a() {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.c;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    for (Map.Entry<String, w> entry : b().e().entrySet()) {
      String str = (String)entry.getKey();
      Bundle bundle = ((w)entry.getValue()).c().a();
      if (!l.b(bundle, Bundle.EMPTY))
        bundle1.putBundle(str, bundle); 
    } 
    this.b = false;
    return bundle1;
  }
  
  public final void c() {
    if (!this.b) {
      this.c = this.a.b("androidx.lifecycle.internal.SavedStateHandlesProvider");
      this.b = true;
      b();
    } 
  }
  
  static final class a extends m implements y7.a<z> {
    a(g0 param1g0) {
      super(0);
    }
    
    public final z a() {
      return x.b(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */