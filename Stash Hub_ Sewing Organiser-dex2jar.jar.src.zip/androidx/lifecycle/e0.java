package androidx.lifecycle;

import kotlin.jvm.internal.l;
import r.a;

public final class e0 {
  public static final a a(g0 paramg0) {
    l.f(paramg0, "owner");
    return (a)((paramg0 instanceof d) ? ((d)paramg0).d() : a.a.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */