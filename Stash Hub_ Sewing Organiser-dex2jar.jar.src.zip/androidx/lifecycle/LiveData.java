package androidx.lifecycle;

import d.c;
import java.util.Map;

public abstract class LiveData<T> {
  static final Object k = new Object();
  
  final Object a = new Object();
  
  private e.b<q<? super T>, b> b = new e.b();
  
  int c = 0;
  
  private boolean d;
  
  private volatile Object e;
  
  volatile Object f;
  
  private int g;
  
  private boolean h;
  
  private boolean i;
  
  private final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  static void b(String paramString) {
    if (c.g().b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void d(b paramb) {
    if (!paramb.b)
      return; 
    if (!paramb.e()) {
      paramb.b(false);
      return;
    } 
    int i = paramb.c;
    int j = this.g;
    if (i >= j)
      return; 
    paramb.c = j;
    paramb.a.a((T)this.e);
  }
  
  void c(int paramInt) {
    int i = this.c;
    this.c = paramInt + i;
    if (this.d)
      return; 
    this.d = true;
    while (true) {
      int j;
      try {
        j = this.c;
      } finally {
        this.d = false;
      } 
      if (i > 0 && j == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (paramInt != 0) {
        i();
      } else if (i != 0) {
        j();
      } 
      i = j;
    } 
  }
  
  void e(b paramb) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      b b1;
      this.i = false;
      if (paramb != null) {
        d(paramb);
        b1 = null;
      } else {
        e.b.d<Map.Entry> d = this.b.g();
        while (true) {
          b1 = paramb;
          if (d.hasNext()) {
            d((b)((Map.Entry)d.next()).getValue());
            if (this.i) {
              b1 = paramb;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramb = b1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public T f() {
    Object object = this.e;
    return (T)((object != k) ? object : null);
  }
  
  public boolean g() {
    return (this.c > 0);
  }
  
  public void h(j paramj, q<? super T> paramq) {
    b("observe");
    if (paramj.a().b() == e.b.a)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramj, paramq);
    b b1 = (b)this.b.n(paramq, lifecycleBoundObserver);
    if (b1 == null || b1.d(paramj)) {
      if (b1 != null)
        return; 
      paramj.a().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  protected void i() {}
  
  protected void j() {}
  
  protected void k(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      c.g().c(this.j);
      return;
    } 
  }
  
  public void l(q<? super T> paramq) {
    b("removeObserver");
    b b1 = (b)this.b.o(paramq);
    if (b1 == null)
      return; 
    b1.c();
    b1.b(false);
  }
  
  protected void m(T paramT) {
    b("setValue");
    this.g++;
    this.e = paramT;
    e(null);
  }
  
  class LifecycleBoundObserver extends b implements h {
    final j e;
    
    LifecycleBoundObserver(LiveData this$0, j param1j, q<? super T> param1q) {
      super(this$0, param1q);
      this.e = param1j;
    }
    
    public void a(j param1j, e.a param1a) {
      e.b b1 = this.e.a().b();
      if (b1 == e.b.a) {
        this.f.l(this.a);
        return;
      } 
      param1a = null;
      while (param1a != b1) {
        b(e());
        e.b b3 = this.e.a().b();
        e.b b2 = b1;
        b1 = b3;
      } 
    }
    
    void c() {
      this.e.a().c(this);
    }
    
    boolean d(j param1j) {
      return (this.e == param1j);
    }
    
    boolean e() {
      return this.e.a().b().g(e.b.d);
    }
  }
  
  class a implements Runnable {
    a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.a.a) {
        Object object = this.a.f;
        this.a.f = LiveData.k;
        this.a.m(object);
        return;
      } 
    }
  }
  
  private abstract class b {
    final q<? super T> a;
    
    boolean b;
    
    int c = -1;
    
    b(LiveData this$0, q<? super T> param1q) {
      this.a = param1q;
    }
    
    void b(boolean param1Boolean) {
      byte b1;
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      LiveData liveData = this.d;
      if (param1Boolean) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      liveData.c(b1);
      if (this.b)
        this.d.e(this); 
    }
    
    void c() {}
    
    boolean d(j param1j) {
      return false;
    }
    
    abstract boolean e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */