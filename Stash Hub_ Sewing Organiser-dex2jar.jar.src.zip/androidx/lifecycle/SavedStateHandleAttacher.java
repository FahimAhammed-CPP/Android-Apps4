package androidx.lifecycle;

import kotlin.jvm.internal.l;

public final class SavedStateHandleAttacher implements h {
  private final y a;
  
  public SavedStateHandleAttacher(y paramy) {
    this.a = paramy;
  }
  
  public void a(j paramj, e.a parama) {
    boolean bool;
    l.f(paramj, "source");
    l.f(parama, "event");
    if (parama == e.a.ON_CREATE) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramj.a().c(this);
      this.a.c();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Next event must be ON_CREATE, it was ");
    stringBuilder.append(parama);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\SavedStateHandleAttacher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */