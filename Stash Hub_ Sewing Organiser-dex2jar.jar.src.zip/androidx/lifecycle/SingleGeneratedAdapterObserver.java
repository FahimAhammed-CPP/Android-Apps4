package androidx.lifecycle;

import kotlin.jvm.internal.l;

public final class SingleGeneratedAdapterObserver implements h {
  private final c a;
  
  public SingleGeneratedAdapterObserver(c paramc) {
    this.a = paramc;
  }
  
  public void a(j paramj, e.a parama) {
    l.f(paramj, "source");
    l.f(parama, "event");
    this.a.a(paramj, parama, false, null);
    this.a.a(paramj, parama, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */