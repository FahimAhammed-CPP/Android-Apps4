package androidx.lifecycle;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.l;

public class f0 {
  private final Map<String, b0> a = new LinkedHashMap<String, b0>();
  
  public final void a() {
    Iterator<b0> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((b0)iterator.next()).a(); 
    this.a.clear();
  }
  
  public final b0 b(String paramString) {
    l.f(paramString, "key");
    return this.a.get(paramString);
  }
  
  public final Set<String> c() {
    return new HashSet<String>(this.a.keySet());
  }
  
  public final void d(String paramString, b0 paramb0) {
    l.f(paramString, "key");
    l.f(paramb0, "viewModel");
    b0 b01 = this.a.put(paramString, paramb0);
    if (b01 != null)
      b01.d(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */