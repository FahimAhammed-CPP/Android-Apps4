package androidx.lifecycle;

import a0.a;
import android.content.Context;
import androidx.startup.a;
import java.util.List;
import kotlin.jvm.internal.l;
import p7.m;

public final class ProcessLifecycleInitializer implements a<j> {
  public List<Class<? extends a<?>>> a() {
    return m.d();
  }
  
  public j c(Context paramContext) {
    l.f(paramContext, "context");
    a a1 = a.d(paramContext);
    l.e(a1, "getInstance(context)");
    if (a1.e(ProcessLifecycleInitializer.class)) {
      g.a(paramContext);
      t.b b = t.m;
      b.b(paramContext);
      return b.a();
    } 
    throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml".toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */