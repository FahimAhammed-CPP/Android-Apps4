package androidx.lifecycle;

import r.a;

public interface d {
  a d();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\lifecycle\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */