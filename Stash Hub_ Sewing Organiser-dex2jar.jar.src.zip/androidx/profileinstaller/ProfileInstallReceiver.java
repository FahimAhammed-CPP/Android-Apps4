package androidx.profileinstaller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;

public class ProfileInstallReceiver extends BroadcastReceiver {
  static void a(i.c paramc) {
    byte b;
    if (Build.VERSION.SDK_INT >= 24) {
      Process.sendSignal(Process.myPid(), 10);
      b = 12;
    } else {
      b = 13;
    } 
    paramc.b(b, null);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str1;
    if (paramIntent == null)
      return; 
    String str2 = paramIntent.getAction();
    if ("androidx.profileinstaller.action.INSTALL_PROFILE".equals(str2)) {
      i.k(paramContext, g.a, new a(this), true);
      return;
    } 
    if ("androidx.profileinstaller.action.SKIP_FILE".equals(str2)) {
      Bundle bundle = paramIntent.getExtras();
      if (bundle != null) {
        str1 = bundle.getString("EXTRA_SKIP_FILE_OPERATION");
        if ("WRITE_SKIP_FILE".equals(str1)) {
          i.l(paramContext, g.a, new a(this));
          return;
        } 
        if ("DELETE_SKIP_FILE".equals(str1)) {
          i.c(paramContext, g.a, new a(this));
          return;
        } 
      } 
    } else {
      if ("androidx.profileinstaller.action.SAVE_PROFILE".equals(str2)) {
        a(new a(this));
        return;
      } 
      if ("androidx.profileinstaller.action.BENCHMARK_OPERATION".equals(str2)) {
        Bundle bundle = str1.getExtras();
        if (bundle != null) {
          String str = bundle.getString("EXTRA_BENCHMARK_OPERATION");
          a a = new a(this);
          if ("DROP_SHADER_CACHE".equals(str)) {
            a.b(paramContext, a);
            return;
          } 
          a.b(16, null);
        } 
      } 
    } 
  }
  
  class a implements i.c {
    a(ProfileInstallReceiver this$0) {}
    
    public void a(int param1Int, Object param1Object) {
      i.b.a(param1Int, param1Object);
    }
    
    public void b(int param1Int, Object param1Object) {
      i.b.b(param1Int, param1Object);
      this.a.setResultCode(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\ProfileInstallReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */