package androidx.profileinstaller;

import java.util.TreeMap;

class d {
  final String a;
  
  final String b;
  
  final long c;
  
  long d;
  
  int e;
  
  final int f;
  
  final int g;
  
  int[] h;
  
  final TreeMap<Integer, Integer> i;
  
  d(String paramString1, String paramString2, long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint, TreeMap<Integer, Integer> paramTreeMap) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramLong1;
    this.d = paramLong2;
    this.e = paramInt1;
    this.f = paramInt2;
    this.g = paramInt3;
    this.h = paramArrayOfint;
    this.i = paramTreeMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */