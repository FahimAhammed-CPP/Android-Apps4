package androidx.profileinstaller;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.util.Log;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.Executor;

public class i {
  private static final c a = new a();
  
  static final c b = new b();
  
  static boolean b(File paramFile) {
    return (new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat")).delete();
  }
  
  static void c(Context paramContext, Executor paramExecutor, c paramc) {
    b(paramContext.getFilesDir());
    g(paramExecutor, paramc, 11, null);
  }
  
  static boolean d(PackageInfo paramPackageInfo, File paramFile, c paramc) {
    paramFile = new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
    boolean bool1 = paramFile.exists();
    boolean bool = false;
    if (!bool1)
      return false; 
    try {
      DataInputStream dataInputStream = new DataInputStream(new FileInputStream(paramFile));
      try {
        long l = dataInputStream.readLong();
        dataInputStream.close();
        if (l == paramPackageInfo.lastUpdateTime)
          bool = true; 
        return bool;
      } finally {
        try {
          dataInputStream.close();
        } finally {
          dataInputStream = null;
        } 
      } 
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  static void f(PackageInfo paramPackageInfo, File paramFile) {
    paramFile = new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
    try {
      DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(paramFile));
      try {
        dataOutputStream.writeLong(paramPackageInfo.lastUpdateTime);
        return;
      } finally {
        try {
          dataOutputStream.close();
        } finally {
          dataOutputStream = null;
        } 
      } 
    } catch (IOException iOException) {
      return;
    } 
  }
  
  static void g(Executor paramExecutor, c paramc, int paramInt, Object paramObject) {
    paramExecutor.execute(new h(paramc, paramInt, paramObject));
  }
  
  private static boolean h(AssetManager paramAssetManager, String paramString1, PackageInfo paramPackageInfo, File paramFile, String paramString2, Executor paramExecutor, c paramc) {
    if (Build.VERSION.SDK_INT < 19) {
      g(paramExecutor, paramc, 3, null);
      return false;
    } 
    c c1 = new c(paramAssetManager, paramExecutor, paramc, paramString2, "dexopt/baseline.prof", "dexopt/baseline.profm", new File(new File("/data/misc/profiles/cur/0", paramString1), "primary.prof"));
    if (!c1.e())
      return false; 
    boolean bool = c1.i().m().n();
    if (bool)
      f(paramPackageInfo, paramFile); 
    return bool;
  }
  
  public static void i(Context paramContext) {
    j(paramContext, g.a, a);
  }
  
  public static void j(Context paramContext, Executor paramExecutor, c paramc) {
    k(paramContext, paramExecutor, paramc, false);
  }
  
  static void k(Context paramContext, Executor paramExecutor, c paramc, boolean paramBoolean) {
    Context context = paramContext.getApplicationContext();
    String str1 = context.getPackageName();
    ApplicationInfo applicationInfo = context.getApplicationInfo();
    AssetManager assetManager = context.getAssets();
    String str2 = (new File(applicationInfo.sourceDir)).getName();
    PackageManager packageManager = paramContext.getPackageManager();
    boolean bool = false;
    try {
      boolean bool1;
      PackageInfo packageInfo = packageManager.getPackageInfo(str1, 0);
      File file = paramContext.getFilesDir();
      if (paramBoolean || !d(packageInfo, file, paramc)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Installing profile for ");
        stringBuilder.append(paramContext.getPackageName());
        Log.d("ProfileInstaller", stringBuilder.toString());
        bool1 = bool;
        if (h(assetManager, str1, packageInfo, file, str2, paramExecutor, paramc)) {
          bool1 = bool;
          if (paramBoolean)
            bool1 = true; 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping profile installation for ");
        stringBuilder.append(paramContext.getPackageName());
        Log.d("ProfileInstaller", stringBuilder.toString());
        bool1 = bool;
      } 
      o.c(paramContext, bool1);
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      paramc.b(7, nameNotFoundException);
      o.c(paramContext, false);
      return;
    } 
  }
  
  static void l(Context paramContext, Executor paramExecutor, c paramc) {
    String str = paramContext.getApplicationContext().getPackageName();
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
      f(packageInfo, paramContext.getFilesDir());
      g(paramExecutor, paramc, 10, null);
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      g(paramExecutor, paramc, 7, nameNotFoundException);
      return;
    } 
  }
  
  class a implements c {
    public void a(int param1Int, Object param1Object) {}
    
    public void b(int param1Int, Object param1Object) {}
  }
  
  class b implements c {
    public void a(int param1Int, Object param1Object) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4) {
              if (param1Int != 5) {
                param1Object = "";
              } else {
                param1Object = "DIAGNOSTIC_PROFILE_IS_COMPRESSED";
              } 
            } else {
              param1Object = "DIAGNOSTIC_REF_PROFILE_DOES_NOT_EXIST";
            } 
          } else {
            param1Object = "DIAGNOSTIC_REF_PROFILE_EXISTS";
          } 
        } else {
          param1Object = "DIAGNOSTIC_CURRENT_PROFILE_DOES_NOT_EXIST";
        } 
      } else {
        param1Object = "DIAGNOSTIC_CURRENT_PROFILE_EXISTS";
      } 
      Log.d("ProfileInstaller", (String)param1Object);
    }
    
    public void b(int param1Int, Object param1Object) {
      String str;
      switch (param1Int) {
        default:
          str = "";
          break;
        case 11:
          str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
          break;
        case 10:
          str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
          break;
        case 8:
          str = "RESULT_PARSE_EXCEPTION";
          break;
        case 7:
          str = "RESULT_IO_EXCEPTION";
          break;
        case 6:
          str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
          break;
        case 5:
          str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
          break;
        case 4:
          str = "RESULT_NOT_WRITABLE";
          break;
        case 3:
          str = "RESULT_UNSUPPORTED_ART_VERSION";
          break;
        case 2:
          str = "RESULT_ALREADY_INSTALLED";
          break;
        case 1:
          str = "RESULT_INSTALL_SUCCESS";
          break;
      } 
      if (param1Int != 6 && param1Int != 7 && param1Int != 8) {
        Log.d("ProfileInstaller", str);
        return;
      } 
      Log.e("ProfileInstaller", str, (Throwable)param1Object);
    }
  }
  
  public static interface c {
    void a(int param1Int, Object param1Object);
    
    void b(int param1Int, Object param1Object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */