package androidx.profileinstaller;

import a0.a;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ProfileInstallerInitializer implements a<ProfileInstallerInitializer.c> {
  private static void l(Context paramContext) {
    (new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>())).execute(new k(paramContext));
  }
  
  public List<Class<? extends a<?>>> a() {
    return Collections.emptyList();
  }
  
  public c f(Context paramContext) {
    if (Build.VERSION.SDK_INT < 24)
      return new c(); 
    g(paramContext.getApplicationContext());
    return new c();
  }
  
  void g(Context paramContext) {
    a.c(new l(this, paramContext));
  }
  
  void h(Context paramContext) {
    Handler handler;
    if (Build.VERSION.SDK_INT >= 28) {
      handler = b.a(Looper.getMainLooper());
    } else {
      handler = new Handler(Looper.getMainLooper());
    } 
    int i = (new Random()).nextInt(Math.max(1000, 1));
    handler.postDelayed(new j(paramContext), (i + 5000));
  }
  
  private static class a {
    public static void c(Runnable param1Runnable) {
      Choreographer.getInstance().postFrameCallback(new m(param1Runnable));
    }
  }
  
  private static class b {
    public static Handler a(Looper param1Looper) {
      return Handler.createAsync(param1Looper);
    }
  }
  
  public static class c {}
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\ProfileInstallerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */