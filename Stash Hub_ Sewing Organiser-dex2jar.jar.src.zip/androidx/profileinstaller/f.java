package androidx.profileinstaller;

enum f {
  b(0L),
  c(1L),
  d(2L),
  e(3L),
  f(4L);
  
  private final long a;
  
  f(long paramLong) {
    this.a = paramLong;
  }
  
  public long g() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */