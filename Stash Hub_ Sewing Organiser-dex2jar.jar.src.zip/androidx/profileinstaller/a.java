package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import java.io.File;

class a {
  static boolean a(File paramFile) {
    File[] arrayOfFile;
    if (paramFile.isDirectory()) {
      arrayOfFile = paramFile.listFiles();
      if (arrayOfFile == null)
        return false; 
      int j = arrayOfFile.length;
      int i = 0;
      boolean bool = true;
      while (i < j) {
        if (a(arrayOfFile[i]) && bool) {
          bool = true;
        } else {
          bool = false;
        } 
        i++;
      } 
      return bool;
    } 
    arrayOfFile.delete();
    return true;
  }
  
  static void b(Context paramContext, ProfileInstallReceiver.a parama) {
    File file;
    int i = Build.VERSION.SDK_INT;
    if (i >= 24) {
      file = b.a(paramContext);
    } else if (i >= 23) {
      file = a.a((Context)file);
    } else {
      file = file.getCacheDir();
    } 
    if (a(file)) {
      i = 14;
    } else {
      i = 15;
    } 
    parama.b(i, null);
  }
  
  private static class a {
    static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
  }
  
  private static class b {
    static File a(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext().getCodeCacheDir();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */