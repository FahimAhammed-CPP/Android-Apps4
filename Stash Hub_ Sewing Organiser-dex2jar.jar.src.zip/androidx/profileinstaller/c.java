package androidx.profileinstaller;

import android.content.res.AssetManager;
import android.os.Build;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executor;

public class c {
  private final AssetManager a;
  
  private final Executor b;
  
  private final i.c c;
  
  private final byte[] d;
  
  private final File e;
  
  private final String f;
  
  private final String g;
  
  private final String h;
  
  private boolean i = false;
  
  private d[] j;
  
  private byte[] k;
  
  public c(AssetManager paramAssetManager, Executor paramExecutor, i.c paramc, String paramString1, String paramString2, String paramString3, File paramFile) {
    this.a = paramAssetManager;
    this.b = paramExecutor;
    this.c = paramc;
    this.f = paramString1;
    this.g = paramString2;
    this.h = paramString3;
    this.e = paramFile;
    this.d = d();
  }
  
  private c b(d[] paramArrayOfd, byte[] paramArrayOfbyte) {
    try {
      InputStream inputStream = h(this.a, this.h);
      if (inputStream != null)
        try {
          this.j = n.q(inputStream, n.o(inputStream, n.b), paramArrayOfbyte, paramArrayOfd);
          return this;
        } finally {
          try {
            inputStream.close();
          } finally {
            paramArrayOfbyte = null;
          } 
        }  
      if (inputStream != null) {
        inputStream.close();
        return null;
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      i.c c1 = this.c;
      byte b = 9;
      c1.b(b, fileNotFoundException);
    } catch (IOException iOException) {
      i.c c1 = this.c;
      byte b = 7;
    } catch (IllegalStateException illegalStateException) {
      this.j = null;
      i.c c1 = this.c;
      byte b = 8;
    } 
    return null;
  }
  
  private void c() {
    if (this.i)
      return; 
    throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
  }
  
  private static byte[] d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 24) {
      if (i > 33)
        return null; 
      switch (i) {
        default:
          return null;
        case 31:
        case 32:
        case 33:
          return p.a;
        case 28:
        case 29:
        case 30:
          return p.b;
        case 27:
          return p.c;
        case 26:
          return p.d;
        case 24:
        case 25:
          break;
      } 
      return p.e;
    } 
    return null;
  }
  
  private InputStream f(AssetManager paramAssetManager) {
    i.c c1;
    byte b;
    try {
      return h(paramAssetManager, this.g);
    } catch (FileNotFoundException null) {
      c1 = this.c;
      b = 6;
    } catch (IOException iOException) {
      c1 = this.c;
      b = 7;
    } 
    c1.b(b, iOException);
    return null;
  }
  
  private InputStream h(AssetManager paramAssetManager, String paramString) {
    try {
      return paramAssetManager.openFd(paramString).createInputStream();
    } catch (FileNotFoundException fileNotFoundException) {
      String str = fileNotFoundException.getMessage();
      if (str != null && str.contains("compressed"))
        this.c.a(5, null); 
      return null;
    } 
  }
  
  private d[] j(InputStream paramInputStream) {
    try {
      d[] arrayOfD = n.w(paramInputStream, n.o(paramInputStream, n.a), this.f);
      try {
        paramInputStream.close();
        return arrayOfD;
      } catch (IOException iOException) {
        this.c.b(7, iOException);
        return arrayOfD;
      } 
    } catch (IOException iOException1) {
      this.c.b(7, iOException1);
      iOException.close();
    } catch (IllegalStateException illegalStateException) {
      this.c.b(8, illegalStateException);
      try {
        iOException.close();
      } catch (IOException iOException1) {
        this.c.b(7, iOException1);
      } 
    } finally {
      Exception exception;
    } 
    return null;
  }
  
  private static boolean k() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 24) {
      if (i > 33)
        return false; 
      if (i != 24 && i != 25)
        switch (i) {
          default:
            return false;
          case 31:
          case 32:
          case 33:
            break;
        }  
      return true;
    } 
    return false;
  }
  
  private void l(int paramInt, Object paramObject) {
    this.b.execute(new b(this, paramInt, paramObject));
  }
  
  public boolean e() {
    if (this.d == null) {
      byte b = 3;
      Integer integer = Integer.valueOf(Build.VERSION.SDK_INT);
      l(b, integer);
      return false;
    } 
    if (!this.e.canWrite()) {
      byte b = 4;
      Object object = null;
      l(b, object);
      return false;
    } 
    this.i = true;
    return true;
  }
  
  public c i() {
    c();
    if (this.d == null)
      return this; 
    InputStream inputStream = f(this.a);
    if (inputStream != null)
      this.j = j(inputStream); 
    d[] arrayOfD = this.j;
    if (arrayOfD != null && k()) {
      c c1 = b(arrayOfD, this.d);
      if (c1 != null)
        return c1; 
    } 
    return this;
  }
  
  public c m() {
    d[] arrayOfD = this.j;
    byte[] arrayOfByte = this.d;
    if (arrayOfD != null) {
      if (arrayOfByte == null)
        return this; 
      c();
      try {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
          n.E(byteArrayOutputStream, arrayOfByte);
          if (!n.B(byteArrayOutputStream, arrayOfByte, arrayOfD)) {
            this.c.b(5, null);
            this.j = null;
            return this;
          } 
          this.k = byteArrayOutputStream.toByteArray();
        } finally {
          try {
            byteArrayOutputStream.close();
          } finally {
            byteArrayOutputStream = null;
          } 
        } 
      } catch (IOException iOException) {
        i.c c1 = this.c;
        byte b = 7;
        c1.b(b, iOException);
      } catch (IllegalStateException illegalStateException) {
        i.c c1 = this.c;
        byte b = 8;
      } 
      this.j = null;
    } 
    return this;
  }
  
  public boolean n() {
    byte[] arrayOfByte = this.k;
    if (arrayOfByte == null)
      return false; 
    c();
    try {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
      try {
        FileOutputStream fileOutputStream = new FileOutputStream(this.e);
      } finally {
        try {
          byteArrayInputStream.close();
        } finally {
          byteArrayInputStream = null;
        } 
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      l(6, fileNotFoundException);
    } catch (IOException iOException) {
      l(7, iOException);
    } finally {}
    this.k = null;
    this.j = null;
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */