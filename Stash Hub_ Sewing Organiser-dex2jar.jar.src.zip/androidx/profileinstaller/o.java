package androidx.profileinstaller;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Objects;

public final class o {
  private static final androidx.concurrent.futures.c<c> a = androidx.concurrent.futures.c.A();
  
  private static final Object b = new Object();
  
  private static c c = null;
  
  private static long a(Context paramContext) {
    PackageManager packageManager = paramContext.getApplicationContext().getPackageManager();
    if (Build.VERSION.SDK_INT >= 33) {
      packageInfo = a.a(packageManager, paramContext);
      return packageInfo.lastUpdateTime;
    } 
    PackageInfo packageInfo = packageManager.getPackageInfo(packageInfo.getPackageName(), 0);
    return packageInfo.lastUpdateTime;
  }
  
  private static c b(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    c c1 = new c(paramInt, paramBoolean1, paramBoolean2);
    c = c1;
    a.w(c1);
    return c;
  }
  
  static c c(Context paramContext, boolean paramBoolean) {
    // Byte code:
    //   0: iload_1
    //   1: ifne -> 17
    //   4: getstatic androidx/profileinstaller/o.c : Landroidx/profileinstaller/o$c;
    //   7: astore #13
    //   9: aload #13
    //   11: ifnull -> 17
    //   14: aload #13
    //   16: areturn
    //   17: getstatic androidx/profileinstaller/o.b : Ljava/lang/Object;
    //   20: astore #13
    //   22: aload #13
    //   24: monitorenter
    //   25: iload_1
    //   26: ifne -> 45
    //   29: getstatic androidx/profileinstaller/o.c : Landroidx/profileinstaller/o$c;
    //   32: astore #14
    //   34: aload #14
    //   36: ifnull -> 45
    //   39: aload #13
    //   41: monitorexit
    //   42: aload #14
    //   44: areturn
    //   45: getstatic android/os/Build$VERSION.SDK_INT : I
    //   48: istore_3
    //   49: iconst_0
    //   50: istore_2
    //   51: iload_3
    //   52: bipush #28
    //   54: if_icmplt -> 376
    //   57: iload_3
    //   58: bipush #30
    //   60: if_icmpne -> 66
    //   63: goto -> 376
    //   66: new java/io/File
    //   69: dup
    //   70: new java/io/File
    //   73: dup
    //   74: ldc '/data/misc/profiles/ref/'
    //   76: aload_0
    //   77: invokevirtual getPackageName : ()Ljava/lang/String;
    //   80: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   83: ldc 'primary.prof'
    //   85: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   88: astore #14
    //   90: aload #14
    //   92: invokevirtual length : ()J
    //   95: lstore #7
    //   97: aload #14
    //   99: invokevirtual exists : ()Z
    //   102: ifeq -> 407
    //   105: lload #7
    //   107: lconst_0
    //   108: lcmp
    //   109: ifle -> 407
    //   112: iconst_1
    //   113: istore #4
    //   115: goto -> 118
    //   118: new java/io/File
    //   121: dup
    //   122: new java/io/File
    //   125: dup
    //   126: ldc '/data/misc/profiles/cur/0/'
    //   128: aload_0
    //   129: invokevirtual getPackageName : ()Ljava/lang/String;
    //   132: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   135: ldc 'primary.prof'
    //   137: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   140: astore #14
    //   142: aload #14
    //   144: invokevirtual length : ()J
    //   147: lstore #9
    //   149: aload #14
    //   151: invokevirtual exists : ()Z
    //   154: istore #5
    //   156: iload #5
    //   158: ifeq -> 174
    //   161: lload #9
    //   163: lconst_0
    //   164: lcmp
    //   165: ifle -> 174
    //   168: iconst_1
    //   169: istore #5
    //   171: goto -> 177
    //   174: iconst_0
    //   175: istore #5
    //   177: aload_0
    //   178: invokestatic a : (Landroid/content/Context;)J
    //   181: lstore #11
    //   183: new java/io/File
    //   186: dup
    //   187: aload_0
    //   188: invokevirtual getFilesDir : ()Ljava/io/File;
    //   191: ldc 'profileInstalled'
    //   193: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   196: astore #14
    //   198: aconst_null
    //   199: astore_0
    //   200: aload #14
    //   202: invokevirtual exists : ()Z
    //   205: istore #6
    //   207: iload #6
    //   209: ifeq -> 236
    //   212: aload #14
    //   214: invokestatic a : (Ljava/io/File;)Landroidx/profileinstaller/o$b;
    //   217: astore_0
    //   218: goto -> 236
    //   221: ldc 131072
    //   223: iload #4
    //   225: iload #5
    //   227: invokestatic b : (IZZ)Landroidx/profileinstaller/o$c;
    //   230: astore_0
    //   231: aload #13
    //   233: monitorexit
    //   234: aload_0
    //   235: areturn
    //   236: aload_0
    //   237: ifnull -> 418
    //   240: aload_0
    //   241: getfield c : J
    //   244: lload #11
    //   246: lcmp
    //   247: ifne -> 418
    //   250: aload_0
    //   251: getfield b : I
    //   254: istore_3
    //   255: iload_3
    //   256: iconst_2
    //   257: if_icmpne -> 413
    //   260: goto -> 418
    //   263: iload_3
    //   264: istore_2
    //   265: aload_0
    //   266: ifnull -> 300
    //   269: iload_3
    //   270: istore_2
    //   271: aload_0
    //   272: getfield b : I
    //   275: iconst_2
    //   276: if_icmpne -> 300
    //   279: iload_3
    //   280: istore_2
    //   281: iload_3
    //   282: iconst_1
    //   283: if_icmpne -> 300
    //   286: iload_3
    //   287: istore_2
    //   288: lload #7
    //   290: aload_0
    //   291: getfield d : J
    //   294: lcmp
    //   295: ifge -> 300
    //   298: iconst_3
    //   299: istore_2
    //   300: new androidx/profileinstaller/o$b
    //   303: dup
    //   304: iconst_1
    //   305: iload_2
    //   306: lload #11
    //   308: lload #9
    //   310: invokespecial <init> : (IIJJ)V
    //   313: astore #15
    //   315: aload_0
    //   316: ifnull -> 332
    //   319: aload_0
    //   320: aload #15
    //   322: invokevirtual equals : (Ljava/lang/Object;)Z
    //   325: istore_1
    //   326: iload_2
    //   327: istore_3
    //   328: iload_1
    //   329: ifne -> 347
    //   332: aload #15
    //   334: aload #14
    //   336: invokevirtual b : (Ljava/io/File;)V
    //   339: iload_2
    //   340: istore_3
    //   341: goto -> 347
    //   344: ldc 196608
    //   346: istore_3
    //   347: iload_3
    //   348: iload #4
    //   350: iload #5
    //   352: invokestatic b : (IZZ)Landroidx/profileinstaller/o$c;
    //   355: astore_0
    //   356: aload #13
    //   358: monitorexit
    //   359: aload_0
    //   360: areturn
    //   361: ldc 65536
    //   363: iload #4
    //   365: iload #5
    //   367: invokestatic b : (IZZ)Landroidx/profileinstaller/o$c;
    //   370: astore_0
    //   371: aload #13
    //   373: monitorexit
    //   374: aload_0
    //   375: areturn
    //   376: ldc 262144
    //   378: iconst_0
    //   379: iconst_0
    //   380: invokestatic b : (IZZ)Landroidx/profileinstaller/o$c;
    //   383: astore_0
    //   384: aload #13
    //   386: monitorexit
    //   387: aload_0
    //   388: areturn
    //   389: astore_0
    //   390: aload #13
    //   392: monitorexit
    //   393: aload_0
    //   394: athrow
    //   395: astore_0
    //   396: goto -> 361
    //   399: astore_0
    //   400: goto -> 221
    //   403: astore_0
    //   404: goto -> 344
    //   407: iconst_0
    //   408: istore #4
    //   410: goto -> 118
    //   413: iload_3
    //   414: istore_2
    //   415: goto -> 435
    //   418: iload #4
    //   420: ifeq -> 428
    //   423: iconst_1
    //   424: istore_2
    //   425: goto -> 435
    //   428: iload #5
    //   430: ifeq -> 435
    //   433: iconst_2
    //   434: istore_2
    //   435: iload_2
    //   436: istore_3
    //   437: iload_1
    //   438: ifeq -> 263
    //   441: iload_2
    //   442: istore_3
    //   443: iload #5
    //   445: ifeq -> 263
    //   448: iload_2
    //   449: istore_3
    //   450: iload_2
    //   451: iconst_1
    //   452: if_icmpeq -> 263
    //   455: iconst_2
    //   456: istore_3
    //   457: goto -> 263
    // Exception table:
    //   from	to	target	type
    //   29	34	389	finally
    //   39	42	389	finally
    //   45	49	389	finally
    //   66	105	389	finally
    //   118	156	389	finally
    //   177	183	395	android/content/pm/PackageManager$NameNotFoundException
    //   177	183	389	finally
    //   183	198	389	finally
    //   200	207	389	finally
    //   212	218	399	java/io/IOException
    //   212	218	389	finally
    //   221	234	389	finally
    //   240	255	389	finally
    //   271	279	389	finally
    //   288	298	389	finally
    //   300	315	389	finally
    //   319	326	389	finally
    //   332	339	403	java/io/IOException
    //   332	339	389	finally
    //   347	359	389	finally
    //   361	374	389	finally
    //   376	387	389	finally
    //   390	393	389	finally
  }
  
  private static class a {
    static PackageInfo a(PackageManager param1PackageManager, Context param1Context) {
      return param1PackageManager.getPackageInfo(param1Context.getPackageName(), PackageManager.PackageInfoFlags.of(0L));
    }
  }
  
  static class b {
    final int a;
    
    final int b;
    
    final long c;
    
    final long d;
    
    b(int param1Int1, int param1Int2, long param1Long1, long param1Long2) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Long1;
      this.d = param1Long2;
    }
    
    static b a(File param1File) {
      DataInputStream dataInputStream = new DataInputStream(new FileInputStream(param1File));
      try {
        return new b(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
      } finally {
        try {
          dataInputStream.close();
        } finally {
          dataInputStream = null;
        } 
      } 
    }
    
    void b(File param1File) {
      param1File.delete();
      DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(param1File));
      try {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeLong(this.c);
        dataOutputStream.writeLong(this.d);
        return;
      } finally {
        try {
          dataOutputStream.close();
        } finally {
          dataOutputStream = null;
        } 
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (!(param1Object instanceof b))
          return false; 
        param1Object = param1Object;
        return (this.b == ((b)param1Object).b && this.c == ((b)param1Object).c && this.a == ((b)param1Object).a && this.d == ((b)param1Object).d);
      } 
      return false;
    }
    
    public int hashCode() {
      return Objects.hash(new Object[] { Integer.valueOf(this.b), Long.valueOf(this.c), Integer.valueOf(this.a), Long.valueOf(this.d) });
    }
  }
  
  public static class c {
    final int a;
    
    private final boolean b;
    
    private final boolean c;
    
    c(int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
      this.a = param1Int;
      this.c = param1Boolean2;
      this.b = param1Boolean1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */