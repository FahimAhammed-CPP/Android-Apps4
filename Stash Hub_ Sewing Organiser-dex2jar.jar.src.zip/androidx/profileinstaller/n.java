package androidx.profileinstaller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

class n {
  static final byte[] a = new byte[] { 112, 114, 111, 0 };
  
  static final byte[] b = new byte[] { 112, 114, 109, 0 };
  
  private static void A(InputStream paramInputStream) {
    e.h(paramInputStream);
    int j = e.j(paramInputStream);
    if (j == 6)
      return; 
    int i = j;
    if (j == 7)
      return; 
    while (i > 0) {
      e.j(paramInputStream);
      for (j = e.j(paramInputStream); j > 0; j--)
        e.h(paramInputStream); 
      i--;
    } 
  }
  
  static boolean B(OutputStream paramOutputStream, byte[] paramArrayOfbyte, d[] paramArrayOfd) {
    if (Arrays.equals(paramArrayOfbyte, p.a)) {
      N(paramOutputStream, paramArrayOfd);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, p.b)) {
      M(paramOutputStream, paramArrayOfd);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, p.d)) {
      K(paramOutputStream, paramArrayOfd);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, p.c)) {
      L(paramOutputStream, paramArrayOfd);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, p.e)) {
      J(paramOutputStream, paramArrayOfd);
      return true;
    } 
    return false;
  }
  
  private static void C(OutputStream paramOutputStream, d paramd) {
    int[] arrayOfInt = paramd.h;
    int k = arrayOfInt.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      Integer integer = Integer.valueOf(arrayOfInt[i]);
      e.p(paramOutputStream, integer.intValue() - j);
      j = integer.intValue();
      i++;
    } 
  }
  
  private static q D(d[] paramArrayOfd) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      q q;
      e.p(byteArrayOutputStream, paramArrayOfd.length);
      int i = 0;
      int j = 2;
      while (i < paramArrayOfd.length) {
        d d1 = paramArrayOfd[i];
        e.q(byteArrayOutputStream, d1.c);
        e.q(byteArrayOutputStream, d1.d);
        e.q(byteArrayOutputStream, d1.g);
        String str = j(d1.a, d1.b, p.a);
        int k = e.k(str);
        e.p(byteArrayOutputStream, k);
        j = j + 4 + 4 + 4 + 2 + k * 1;
        e.n(byteArrayOutputStream, str);
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        q = new q(f.b, j, arrayOfByte, false);
        return q;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(q.length);
      throw e.c(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  static void E(OutputStream paramOutputStream, byte[] paramArrayOfbyte) {
    paramOutputStream.write(a);
    paramOutputStream.write(paramArrayOfbyte);
  }
  
  private static void F(OutputStream paramOutputStream, d paramd) {
    I(paramOutputStream, paramd);
    C(paramOutputStream, paramd);
    H(paramOutputStream, paramd);
  }
  
  private static void G(OutputStream paramOutputStream, d paramd, String paramString) {
    e.p(paramOutputStream, e.k(paramString));
    e.p(paramOutputStream, paramd.e);
    e.q(paramOutputStream, paramd.f);
    e.q(paramOutputStream, paramd.c);
    e.q(paramOutputStream, paramd.g);
    e.n(paramOutputStream, paramString);
  }
  
  private static void H(OutputStream paramOutputStream, d paramd) {
    byte[] arrayOfByte = new byte[k(paramd.g)];
    for (Map.Entry<Integer, Integer> entry : paramd.i.entrySet()) {
      int i = ((Integer)entry.getKey()).intValue();
      int j = ((Integer)entry.getValue()).intValue();
      if ((j & 0x2) != 0)
        z(arrayOfByte, 2, i, paramd); 
      if ((j & 0x4) != 0)
        z(arrayOfByte, 4, i, paramd); 
    } 
    paramOutputStream.write(arrayOfByte);
  }
  
  private static void I(OutputStream paramOutputStream, d paramd) {
    Iterator<Map.Entry> iterator = paramd.i.entrySet().iterator();
    for (int i = 0; iterator.hasNext(); i = j) {
      Map.Entry entry = iterator.next();
      int j = ((Integer)entry.getKey()).intValue();
      if ((((Integer)entry.getValue()).intValue() & 0x1) == 0)
        continue; 
      e.p(paramOutputStream, j - i);
      e.p(paramOutputStream, 0);
    } 
  }
  
  private static void J(OutputStream paramOutputStream, d[] paramArrayOfd) {
    e.p(paramOutputStream, paramArrayOfd.length);
    int j = paramArrayOfd.length;
    for (int i = 0; i < j; i++) {
      d d1 = paramArrayOfd[i];
      String str = j(d1.a, d1.b, p.e);
      e.p(paramOutputStream, e.k(str));
      e.p(paramOutputStream, d1.i.size());
      e.p(paramOutputStream, d1.h.length);
      e.q(paramOutputStream, d1.c);
      e.n(paramOutputStream, str);
      Iterator<Integer> iterator = d1.i.keySet().iterator();
      while (iterator.hasNext())
        e.p(paramOutputStream, ((Integer)iterator.next()).intValue()); 
      int[] arrayOfInt = d1.h;
      int m = arrayOfInt.length;
      for (int k = 0; k < m; k++)
        e.p(paramOutputStream, arrayOfInt[k]); 
    } 
  }
  
  private static void K(OutputStream paramOutputStream, d[] paramArrayOfd) {
    e.r(paramOutputStream, paramArrayOfd.length);
    int j = paramArrayOfd.length;
    for (int i = 0; i < j; i++) {
      d d1 = paramArrayOfd[i];
      int k = d1.i.size();
      String str = j(d1.a, d1.b, p.d);
      e.p(paramOutputStream, e.k(str));
      e.p(paramOutputStream, d1.h.length);
      e.q(paramOutputStream, (k * 4));
      e.q(paramOutputStream, d1.c);
      e.n(paramOutputStream, str);
      Iterator<Integer> iterator = d1.i.keySet().iterator();
      while (iterator.hasNext()) {
        e.p(paramOutputStream, ((Integer)iterator.next()).intValue());
        e.p(paramOutputStream, 0);
      } 
      int[] arrayOfInt = d1.h;
      int m = arrayOfInt.length;
      for (k = 0; k < m; k++)
        e.p(paramOutputStream, arrayOfInt[k]); 
    } 
  }
  
  private static void L(OutputStream paramOutputStream, d[] paramArrayOfd) {
    byte[] arrayOfByte = b(paramArrayOfd, p.c);
    e.r(paramOutputStream, paramArrayOfd.length);
    e.m(paramOutputStream, arrayOfByte);
  }
  
  private static void M(OutputStream paramOutputStream, d[] paramArrayOfd) {
    byte[] arrayOfByte = b(paramArrayOfd, p.b);
    e.r(paramOutputStream, paramArrayOfd.length);
    e.m(paramOutputStream, arrayOfByte);
  }
  
  private static void N(OutputStream paramOutputStream, d[] paramArrayOfd) {
    O(paramOutputStream, paramArrayOfd);
  }
  
  private static void O(OutputStream paramOutputStream, d[] paramArrayOfd) {
    int j;
    ArrayList<q> arrayList = new ArrayList(3);
    ArrayList<byte[]> arrayList1 = new ArrayList(3);
    arrayList.add(D(paramArrayOfd));
    arrayList.add(c(paramArrayOfd));
    arrayList.add(d(paramArrayOfd));
    long l = p.a.length + a.length + 4L + (arrayList.size() * 16);
    e.q(paramOutputStream, arrayList.size());
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < arrayList.size()) {
        byte[] arrayOfByte;
        q q = arrayList.get(i);
        e.q(paramOutputStream, q.a.g());
        e.q(paramOutputStream, l);
        if (q.d) {
          arrayOfByte = q.c;
          long l1 = arrayOfByte.length;
          arrayOfByte = e.b(arrayOfByte);
          arrayList1.add(arrayOfByte);
          e.q(paramOutputStream, arrayOfByte.length);
          e.q(paramOutputStream, l1);
          j = arrayOfByte.length;
        } else {
          arrayList1.add(((q)arrayOfByte).c);
          e.q(paramOutputStream, ((q)arrayOfByte).c.length);
          e.q(paramOutputStream, 0L);
          j = ((q)arrayOfByte).c.length;
        } 
        l += j;
        i++;
        continue;
      } 
      break;
    } 
    while (j < arrayList1.size()) {
      paramOutputStream.write(arrayList1.get(j));
      j++;
    } 
  }
  
  private static int a(d paramd) {
    Iterator<Map.Entry> iterator = paramd.i.entrySet().iterator();
    int i;
    for (i = 0; iterator.hasNext(); i |= ((Integer)((Map.Entry)iterator.next()).getValue()).intValue());
    return i;
  }
  
  private static byte[] b(d[] paramArrayOfd, byte[] paramArrayOfbyte) {
    int i1 = paramArrayOfd.length;
    int k = 0;
    int m = 0;
    int j = 0;
    int i = 0;
    while (j < i1) {
      d d1 = paramArrayOfd[j];
      i += e.k(j(d1.a, d1.b, paramArrayOfbyte)) + 16 + d1.e * 2 + d1.f + k(d1.g);
      j++;
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(i);
    if (Arrays.equals(paramArrayOfbyte, p.c)) {
      k = paramArrayOfd.length;
      for (j = m; j < k; j++) {
        d d1 = paramArrayOfd[j];
        G(byteArrayOutputStream, d1, j(d1.a, d1.b, paramArrayOfbyte));
        F(byteArrayOutputStream, d1);
      } 
    } else {
      m = paramArrayOfd.length;
      for (j = 0; j < m; j++) {
        d d1 = paramArrayOfd[j];
        G(byteArrayOutputStream, d1, j(d1.a, d1.b, paramArrayOfbyte));
      } 
      m = paramArrayOfd.length;
      for (j = k; j < m; j++)
        F(byteArrayOutputStream, paramArrayOfd[j]); 
    } 
    if (byteArrayOutputStream.size() == i)
      return byteArrayOutputStream.toByteArray(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The bytes saved do not match expectation. actual=");
    stringBuilder.append(byteArrayOutputStream.size());
    stringBuilder.append(" expected=");
    stringBuilder.append(i);
    throw e.c(stringBuilder.toString());
  }
  
  private static q c(d[] paramArrayOfd) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    int j = 0;
    try {
      q q;
      while (i < paramArrayOfd.length) {
        d d1 = paramArrayOfd[i];
        e.p(byteArrayOutputStream, i);
        e.p(byteArrayOutputStream, d1.e);
        j = j + 2 + 2 + d1.e * 2;
        C(byteArrayOutputStream, d1);
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        q = new q(f.d, j, arrayOfByte, true);
        return q;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(q.length);
      throw e.c(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static q d(d[] paramArrayOfd) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    int j = 0;
    try {
      q q;
      while (i < paramArrayOfd.length) {
        d d1 = paramArrayOfd[i];
        int k = a(d1);
        byte[] arrayOfByte1 = e(d1);
        byte[] arrayOfByte2 = f(d1);
        e.p(byteArrayOutputStream, i);
        int m = arrayOfByte1.length + 2 + arrayOfByte2.length;
        e.q(byteArrayOutputStream, m);
        e.p(byteArrayOutputStream, k);
        byteArrayOutputStream.write(arrayOfByte1);
        byteArrayOutputStream.write(arrayOfByte2);
        j = j + 2 + 4 + m;
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        q = new q(f.e, j, arrayOfByte, true);
        return q;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(q.length);
      throw e.c(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static byte[] e(d paramd) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      H(byteArrayOutputStream, paramd);
      return byteArrayOutputStream.toByteArray();
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static byte[] f(d paramd) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      I(byteArrayOutputStream, paramd);
      return byteArrayOutputStream.toByteArray();
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static String g(String paramString1, String paramString2) {
    if ("!".equals(paramString2))
      return paramString1.replace(":", "!"); 
    String str = paramString1;
    if (":".equals(paramString2))
      str = paramString1.replace("!", ":"); 
    return str;
  }
  
  private static String h(String paramString) {
    int j = paramString.indexOf("!");
    int i = j;
    if (j < 0)
      i = paramString.indexOf(":"); 
    String str = paramString;
    if (i > 0)
      str = paramString.substring(i + 1); 
    return str;
  }
  
  private static d i(d[] paramArrayOfd, String paramString) {
    if (paramArrayOfd.length <= 0)
      return null; 
    paramString = h(paramString);
    for (int i = 0; i < paramArrayOfd.length; i++) {
      if ((paramArrayOfd[i]).b.equals(paramString))
        return paramArrayOfd[i]; 
    } 
    return null;
  }
  
  private static String j(String paramString1, String paramString2, byte[] paramArrayOfbyte) {
    String str = p.a(paramArrayOfbyte);
    if (paramString1.length() <= 0)
      return g(paramString2, str); 
    if (paramString2.equals("classes.dex"))
      return paramString1; 
    if (paramString2.contains("!") || paramString2.contains(":"))
      return g(paramString2, str); 
    if (paramString2.endsWith(".apk"))
      return paramString2; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(p.a(paramArrayOfbyte));
    stringBuilder.append(paramString2);
    return stringBuilder.toString();
  }
  
  private static int k(int paramInt) {
    return y(paramInt * 2) / 8;
  }
  
  private static int l(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 == 4)
          return paramInt2 + paramInt3; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected flag: ");
        stringBuilder.append(paramInt1);
        throw e.c(stringBuilder.toString());
      } 
      return paramInt2;
    } 
    throw e.c("HOT methods are not stored in the bitmap");
  }
  
  private static int[] m(InputStream paramInputStream, int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    int i = 0;
    int j = 0;
    while (i < paramInt) {
      j += e.h(paramInputStream);
      arrayOfInt[i] = j;
      i++;
    } 
    return arrayOfInt;
  }
  
  private static int n(BitSet paramBitSet, int paramInt1, int paramInt2) {
    byte b = 2;
    if (!paramBitSet.get(l(2, paramInt1, paramInt2)))
      b = 0; 
    int i = b;
    if (paramBitSet.get(l(4, paramInt1, paramInt2)))
      i = b | 0x4; 
    return i;
  }
  
  static byte[] o(InputStream paramInputStream, byte[] paramArrayOfbyte) {
    if (Arrays.equals(paramArrayOfbyte, e.d(paramInputStream, paramArrayOfbyte.length)))
      return e.d(paramInputStream, p.b.length); 
    throw e.c("Invalid magic");
  }
  
  private static void p(InputStream paramInputStream, d paramd) {
    int j = paramInputStream.available() - paramd.f;
    int i = 0;
    label13: while (paramInputStream.available() > j) {
      int m = i + e.h(paramInputStream);
      paramd.i.put(Integer.valueOf(m), Integer.valueOf(1));
      int k = e.h(paramInputStream);
      while (true) {
        i = m;
        if (k > 0) {
          A(paramInputStream);
          k--;
          continue;
        } 
        continue label13;
      } 
    } 
    if (paramInputStream.available() == j)
      return; 
    throw e.c("Read too much data during profile line parse");
  }
  
  static d[] q(InputStream paramInputStream, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, d[] paramArrayOfd) {
    if (Arrays.equals(paramArrayOfbyte1, p.f)) {
      if (!Arrays.equals(p.a, paramArrayOfbyte2))
        return r(paramInputStream, paramArrayOfbyte1, paramArrayOfd); 
      throw e.c("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
    } 
    if (Arrays.equals(paramArrayOfbyte1, p.g))
      return t(paramInputStream, paramArrayOfbyte2, paramArrayOfd); 
    throw e.c("Unsupported meta version");
  }
  
  static d[] r(InputStream paramInputStream, byte[] paramArrayOfbyte, d[] paramArrayOfd) {
    if (Arrays.equals(paramArrayOfbyte, p.f)) {
      int i = e.j(paramInputStream);
      long l = e.i(paramInputStream);
      paramArrayOfbyte = e.e(paramInputStream, (int)e.i(paramInputStream), (int)l);
      if (paramInputStream.read() <= 0) {
        paramInputStream = new ByteArrayInputStream(paramArrayOfbyte);
        try {
          return s(paramInputStream, i, paramArrayOfd);
        } finally {
          try {
            paramInputStream.close();
          } finally {
            paramInputStream = null;
          } 
        } 
      } 
      throw e.c("Content found after the end of file");
    } 
    throw e.c("Unsupported meta version");
  }
  
  private static d[] s(InputStream paramInputStream, int paramInt, d[] paramArrayOfd) {
    int i = paramInputStream.available();
    byte b = 0;
    if (i == 0)
      return new d[0]; 
    if (paramInt == paramArrayOfd.length) {
      int j;
      String[] arrayOfString = new String[paramInt];
      int[] arrayOfInt = new int[paramInt];
      i = 0;
      while (true) {
        j = b;
        if (i < paramInt) {
          j = e.h(paramInputStream);
          arrayOfInt[i] = e.h(paramInputStream);
          arrayOfString[i] = e.f(paramInputStream, j);
          i++;
          continue;
        } 
        break;
      } 
      while (j < paramInt) {
        d d1 = paramArrayOfd[j];
        if (d1.b.equals(arrayOfString[j])) {
          i = arrayOfInt[j];
          d1.e = i;
          d1.h = m(paramInputStream, i);
          j++;
          continue;
        } 
        throw e.c("Order of dexfiles in metadata did not match baseline");
      } 
      return paramArrayOfd;
    } 
    throw e.c("Mismatched number of dex files found in metadata");
  }
  
  static d[] t(InputStream paramInputStream, byte[] paramArrayOfbyte, d[] paramArrayOfd) {
    int i = e.h(paramInputStream);
    long l = e.i(paramInputStream);
    byte[] arrayOfByte = e.e(paramInputStream, (int)e.i(paramInputStream), (int)l);
    if (paramInputStream.read() <= 0) {
      paramInputStream = new ByteArrayInputStream(arrayOfByte);
      try {
        return u(paramInputStream, paramArrayOfbyte, i, paramArrayOfd);
      } finally {
        try {
          paramInputStream.close();
        } finally {
          paramInputStream = null;
        } 
      } 
    } 
    throw e.c("Content found after the end of file");
  }
  
  private static d[] u(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt, d[] paramArrayOfd) {
    int j = paramInputStream.available();
    int i = 0;
    if (j == 0)
      return new d[0]; 
    if (paramInt == paramArrayOfd.length) {
      while (i < paramInt) {
        int[] arrayOfInt;
        e.h(paramInputStream);
        String str = e.f(paramInputStream, e.h(paramInputStream));
        long l = e.i(paramInputStream);
        j = e.h(paramInputStream);
        d d1 = i(paramArrayOfd, str);
        if (d1 != null) {
          d1.d = l;
          arrayOfInt = m(paramInputStream, j);
          if (Arrays.equals(paramArrayOfbyte, p.e)) {
            d1.e = j;
            d1.h = arrayOfInt;
          } 
          i++;
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Missing profile key: ");
        stringBuilder.append((String)arrayOfInt);
        throw e.c(stringBuilder.toString());
      } 
      return paramArrayOfd;
    } 
    throw e.c("Mismatched number of dex files found in metadata");
  }
  
  private static void v(InputStream paramInputStream, d paramd) {
    BitSet bitSet = BitSet.valueOf(e.d(paramInputStream, e.a(paramd.g * 2)));
    int i = 0;
    while (true) {
      int j = paramd.g;
      if (i < j) {
        j = n(bitSet, i, j);
        if (j != 0) {
          Integer integer2 = paramd.i.get(Integer.valueOf(i));
          Integer integer1 = integer2;
          if (integer2 == null)
            integer1 = Integer.valueOf(0); 
          paramd.i.put(Integer.valueOf(i), Integer.valueOf(j | integer1.intValue()));
        } 
        i++;
        continue;
      } 
      break;
    } 
  }
  
  static d[] w(InputStream paramInputStream, byte[] paramArrayOfbyte, String paramString) {
    if (Arrays.equals(paramArrayOfbyte, p.b)) {
      int i = e.j(paramInputStream);
      long l = e.i(paramInputStream);
      paramArrayOfbyte = e.e(paramInputStream, (int)e.i(paramInputStream), (int)l);
      if (paramInputStream.read() <= 0) {
        paramInputStream = new ByteArrayInputStream(paramArrayOfbyte);
        try {
          return x(paramInputStream, paramString, i);
        } finally {
          try {
            paramInputStream.close();
          } finally {
            paramInputStream = null;
          } 
        } 
      } 
      throw e.c("Content found after the end of file");
    } 
    throw e.c("Unsupported version");
  }
  
  private static d[] x(InputStream paramInputStream, String paramString, int paramInt) {
    int j;
    int i = paramInputStream.available();
    byte b = 0;
    if (i == 0)
      return new d[0]; 
    d[] arrayOfD = new d[paramInt];
    i = 0;
    while (true) {
      j = b;
      if (i < paramInt) {
        j = e.h(paramInputStream);
        int k = e.h(paramInputStream);
        long l1 = e.i(paramInputStream);
        long l2 = e.i(paramInputStream);
        long l3 = e.i(paramInputStream);
        arrayOfD[i] = new d(paramString, e.f(paramInputStream, j), l2, 0L, k, (int)l1, (int)l3, new int[k], new TreeMap<Integer, Integer>());
        i++;
        continue;
      } 
      break;
    } 
    while (j < paramInt) {
      d d = arrayOfD[j];
      p(paramInputStream, d);
      d.h = m(paramInputStream, d.e);
      v(paramInputStream, d);
      j++;
    } 
    return arrayOfD;
  }
  
  private static int y(int paramInt) {
    return paramInt + 8 - 1 & 0xFFFFFFF8;
  }
  
  private static void z(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, d paramd) {
    paramInt1 = l(paramInt1, paramInt2, paramd.g);
    paramInt2 = paramInt1 / 8;
    paramArrayOfbyte[paramInt2] = (byte)(1 << paramInt1 % 8 | paramArrayOfbyte[paramInt2]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */