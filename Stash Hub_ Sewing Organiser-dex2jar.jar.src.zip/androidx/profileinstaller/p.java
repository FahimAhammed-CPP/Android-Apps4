package androidx.profileinstaller;

import java.util.Arrays;

public class p {
  static final byte[] a = new byte[] { 48, 49, 53, 0 };
  
  static final byte[] b = new byte[] { 48, 49, 48, 0 };
  
  static final byte[] c = new byte[] { 48, 48, 57, 0 };
  
  static final byte[] d = new byte[] { 48, 48, 53, 0 };
  
  static final byte[] e = new byte[] { 48, 48, 49, 0 };
  
  static final byte[] f = new byte[] { 48, 48, 49, 0 };
  
  static final byte[] g = new byte[] { 48, 48, 50, 0 };
  
  static String a(byte[] paramArrayOfbyte) {
    return Arrays.equals(paramArrayOfbyte, e) ? ":" : (Arrays.equals(paramArrayOfbyte, d) ? ":" : "!");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\profileinstaller\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */