package androidx.datastore.preferences.protobuf;

import java.util.List;

public interface g0 extends List {
  g0 f();
  
  Object h(int paramInt);
  
  List<?> i();
  
  void l(h paramh);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */