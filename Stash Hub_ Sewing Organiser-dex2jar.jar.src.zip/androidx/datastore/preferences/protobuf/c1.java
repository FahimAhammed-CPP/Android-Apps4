package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class c1 {
  private static final c1 c = new c1();
  
  private final h1 a = new j0();
  
  private final ConcurrentMap<Class<?>, g1<?>> b = new ConcurrentHashMap<Class<?>, g1<?>>();
  
  public static c1 a() {
    return c;
  }
  
  public <T> void b(T paramT, f1 paramf1, p paramp) {
    e(paramT).h(paramT, paramf1, paramp);
  }
  
  public g1<?> c(Class<?> paramClass, g1<?> paramg1) {
    a0.b(paramClass, "messageType");
    a0.b(paramg1, "schema");
    return this.b.putIfAbsent(paramClass, paramg1);
  }
  
  public <T> g1<T> d(Class<T> paramClass) {
    a0.b(paramClass, "messageType");
    g1<T> g12 = (g1)this.b.get(paramClass);
    g1<T> g11 = g12;
    if (g12 == null) {
      g11 = this.a.a(paramClass);
      g1<?> g1 = c(paramClass, g11);
      if (g1 != null)
        g11 = (g1)g1; 
    } 
    return g11;
  }
  
  public <T> g1<T> e(T paramT) {
    return d((Class)paramT.getClass());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */