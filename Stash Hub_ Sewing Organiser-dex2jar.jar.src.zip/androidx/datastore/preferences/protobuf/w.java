package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class w extends c<Float> implements a0.f, RandomAccess, a1 {
  private static final w d;
  
  private float[] b;
  
  private int c;
  
  static {
    w w1 = new w(new float[0], 0);
    d = w1;
    w1.d();
  }
  
  w() {
    this(new float[10], 0);
  }
  
  private w(float[] paramArrayOffloat, int paramInt) {
    this.b = paramArrayOffloat;
    this.c = paramInt;
  }
  
  private void m(int paramInt, float paramFloat) {
    a();
    if (paramInt >= 0) {
      int i = this.c;
      if (paramInt <= i) {
        float[] arrayOfFloat = this.b;
        if (i < arrayOfFloat.length) {
          System.arraycopy(arrayOfFloat, paramInt, arrayOfFloat, paramInt + 1, i - paramInt);
        } else {
          float[] arrayOfFloat1 = new float[i * 3 / 2 + 1];
          System.arraycopy(arrayOfFloat, 0, arrayOfFloat1, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfFloat1, paramInt + 1, this.c - paramInt);
          this.b = arrayOfFloat1;
        } 
        this.b[paramInt] = paramFloat;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private void n(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private String q(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean addAll(Collection<? extends Float> paramCollection) {
    a();
    a0.a(paramCollection);
    if (!(paramCollection instanceof w))
      return super.addAll(paramCollection); 
    paramCollection = paramCollection;
    int i = ((w)paramCollection).c;
    if (i == 0)
      return false; 
    int j = this.c;
    if (Integer.MAX_VALUE - j >= i) {
      i = j + i;
      float[] arrayOfFloat = this.b;
      if (i > arrayOfFloat.length)
        this.b = Arrays.copyOf(arrayOfFloat, i); 
      System.arraycopy(((w)paramCollection).b, 0, this.b, this.c, ((w)paramCollection).c);
      this.c = i;
      this.modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public void c(int paramInt, Float paramFloat) {
    m(paramInt, paramFloat.floatValue());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof w))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((w)paramObject).c)
      return false; 
    paramObject = ((w)paramObject).b;
    for (int i = 0; i < this.c; i++) {
      if (Float.floatToIntBits(this.b[i]) != Float.floatToIntBits(paramObject[i]))
        return false; 
    } 
    return true;
  }
  
  public boolean g(Float paramFloat) {
    k(paramFloat.floatValue());
    return true;
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.c; i++)
      j = j * 31 + Float.floatToIntBits(this.b[i]); 
    return j;
  }
  
  public void k(float paramFloat) {
    a();
    int i = this.c;
    float[] arrayOfFloat = this.b;
    if (i == arrayOfFloat.length) {
      float[] arrayOfFloat1 = new float[i * 3 / 2 + 1];
      System.arraycopy(arrayOfFloat, 0, arrayOfFloat1, 0, i);
      this.b = arrayOfFloat1;
    } 
    arrayOfFloat = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfFloat[i] = paramFloat;
  }
  
  public Float o(int paramInt) {
    return Float.valueOf(p(paramInt));
  }
  
  public float p(int paramInt) {
    n(paramInt);
    return this.b[paramInt];
  }
  
  public a0.f r(int paramInt) {
    if (paramInt >= this.c)
      return new w(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public boolean remove(Object paramObject) {
    a();
    for (int i = 0; i < this.c; i++) {
      if (paramObject.equals(Float.valueOf(this.b[i]))) {
        paramObject = this.b;
        System.arraycopy(paramObject, i + 1, paramObject, i, this.c - i - 1);
        this.c--;
        this.modCount++;
        return true;
      } 
    } 
    return false;
  }
  
  protected void removeRange(int paramInt1, int paramInt2) {
    a();
    if (paramInt2 >= paramInt1) {
      float[] arrayOfFloat = this.b;
      System.arraycopy(arrayOfFloat, paramInt2, arrayOfFloat, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      this.modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Float s(int paramInt) {
    a();
    n(paramInt);
    float[] arrayOfFloat = this.b;
    float f1 = arrayOfFloat[paramInt];
    int i = this.c;
    if (paramInt < i - 1)
      System.arraycopy(arrayOfFloat, paramInt + 1, arrayOfFloat, paramInt, i - paramInt - 1); 
    this.c--;
    this.modCount++;
    return Float.valueOf(f1);
  }
  
  public int size() {
    return this.c;
  }
  
  public Float t(int paramInt, Float paramFloat) {
    return Float.valueOf(u(paramInt, paramFloat.floatValue()));
  }
  
  public float u(int paramInt, float paramFloat) {
    a();
    n(paramInt);
    float[] arrayOfFloat = this.b;
    float f1 = arrayOfFloat[paramInt];
    arrayOfFloat[paramInt] = paramFloat;
    return f1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */