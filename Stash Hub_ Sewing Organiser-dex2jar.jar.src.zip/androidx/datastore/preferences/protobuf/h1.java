package androidx.datastore.preferences.protobuf;

interface h1 {
  <T> g1<T> a(Class<T> paramClass);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */