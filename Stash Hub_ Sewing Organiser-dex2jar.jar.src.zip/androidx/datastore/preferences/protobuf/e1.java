package androidx.datastore.preferences.protobuf;

final class e1 implements p0 {
  private final r0 a;
  
  private final String b;
  
  private final Object[] c;
  
  private final int d;
  
  e1(r0 paramr0, String paramString, Object[] paramArrayOfObject) {
    this.a = paramr0;
    this.b = paramString;
    this.c = paramArrayOfObject;
    char c = paramString.charAt(0);
    if (c < '?') {
      this.d = c;
      return;
    } 
    int j = c & 0x1FFF;
    int i = 13;
    c = '\001';
    while (true) {
      char c1 = paramString.charAt(c);
      if (c1 >= '?') {
        j |= (c1 & 0x1FFF) << i;
        i += 13;
        int m = c + 1;
        continue;
      } 
      int k = j | c1 << i;
      // Byte code: goto -> 33
    } 
  }
  
  public boolean a() {
    return ((this.d & 0x2) == 2);
  }
  
  public b1 b() {
    return ((this.d & 0x1) == 1) ? b1.a : b1.b;
  }
  
  public r0 c() {
    return this.a;
  }
  
  Object[] d() {
    return this.c;
  }
  
  String e() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */