package androidx.datastore.preferences.protobuf;

import java.util.List;

public class m1 extends RuntimeException {
  private final List<String> a = null;
  
  public m1(r0 paramr0) {
    super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
  }
  
  public b0 a() {
    return new b0(getMessage());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */