package androidx.datastore.preferences.protobuf;

public class k0<K, V> {
  private final a<K, V> a;
  
  private final K b;
  
  private final V c;
  
  private k0(t1.b paramb1, K paramK, t1.b paramb2, V paramV) {
    this.a = new a<K, V>(paramb1, paramK, paramb2, paramV);
    this.b = paramK;
    this.c = paramV;
  }
  
  static <K, V> int b(a<K, V> parama, K paramK, V paramV) {
    return u.d(parama.a, 1, paramK) + u.d(parama.c, 2, paramV);
  }
  
  public static <K, V> k0<K, V> d(t1.b paramb1, K paramK, t1.b paramb2, V paramV) {
    return new k0<K, V>(paramb1, paramK, paramb2, paramV);
  }
  
  static <K, V> void e(k paramk, a<K, V> parama, K paramK, V paramV) {
    u.z(paramk, parama.a, 1, paramK);
    u.z(paramk, parama.c, 2, paramV);
  }
  
  public int a(int paramInt, K paramK, V paramV) {
    return k.V(paramInt) + k.C(b(this.a, paramK, paramV));
  }
  
  a<K, V> c() {
    return this.a;
  }
  
  static class a<K, V> {
    public final t1.b a;
    
    public final K b;
    
    public final t1.b c;
    
    public final V d;
    
    public a(t1.b param1b1, K param1K, t1.b param1b2, V param1V) {
      this.a = param1b1;
      this.b = param1K;
      this.c = param1b2;
      this.d = param1V;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */