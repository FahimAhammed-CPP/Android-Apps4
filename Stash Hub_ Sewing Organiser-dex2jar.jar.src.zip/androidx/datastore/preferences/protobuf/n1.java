package androidx.datastore.preferences.protobuf;

abstract class n1<T, B> {
  abstract void a(B paramB, int paramInt1, int paramInt2);
  
  abstract void b(B paramB, int paramInt, long paramLong);
  
  abstract void c(B paramB, int paramInt, T paramT);
  
  abstract void d(B paramB, int paramInt, h paramh);
  
  abstract void e(B paramB, int paramInt, long paramLong);
  
  abstract B f(Object paramObject);
  
  abstract T g(Object paramObject);
  
  abstract int h(T paramT);
  
  abstract int i(T paramT);
  
  abstract void j(Object paramObject);
  
  abstract T k(T paramT1, T paramT2);
  
  final void l(B paramB, f1 paramf1) {
    do {
    
    } while (paramf1.p() != Integer.MAX_VALUE && m(paramB, paramf1));
  }
  
  final boolean m(B paramB, f1 paramf1) {
    int j = paramf1.c();
    int i = t1.a(j);
    j = t1.b(j);
    if (j != 0) {
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j != 4) {
              if (j == 5) {
                a(paramB, i, paramf1.n());
                return true;
              } 
              throw b0.d();
            } 
            return false;
          } 
          B b = n();
          j = t1.c(i, 4);
          l(b, paramf1);
          if (j == paramf1.c()) {
            c(paramB, i, r(b));
            return true;
          } 
          throw b0.a();
        } 
        d(paramB, i, paramf1.u());
        return true;
      } 
      b(paramB, i, paramf1.f());
      return true;
    } 
    e(paramB, i, paramf1.E());
    return true;
  }
  
  abstract B n();
  
  abstract void o(Object paramObject, B paramB);
  
  abstract void p(Object paramObject, T paramT);
  
  abstract boolean q(f1 paramf1);
  
  abstract T r(B paramB);
  
  abstract void s(T paramT, u1 paramu1);
  
  abstract void t(T paramT, u1 paramu1);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */