package androidx.datastore.preferences.protobuf;

final class s {
  private static final q<?> a = new r();
  
  private static final q<?> b = c();
  
  static q<?> a() {
    q<?> q1 = b;
    if (q1 != null)
      return q1; 
    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
  }
  
  static q<?> b() {
    return a;
  }
  
  private static q<?> c() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */