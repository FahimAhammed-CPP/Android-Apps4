package androidx.datastore.preferences.protobuf;

class x implements q0 {
  private static final x a = new x();
  
  public static x c() {
    return a;
  }
  
  public p0 a(Class<?> paramClass) {
    if (y.class.isAssignableFrom(paramClass))
      try {
        return (p0)y.<y<?, ?>>z((Class)paramClass.asSubclass((Class)y.class)).s();
      } catch (Exception exception) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unable to get message info for ");
        stringBuilder1.append(paramClass.getName());
        throw new RuntimeException(stringBuilder1.toString(), exception);
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported message type: ");
    stringBuilder.append(paramClass.getName());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean b(Class<?> paramClass) {
    return y.class.isAssignableFrom(paramClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */