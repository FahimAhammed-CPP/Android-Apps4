package androidx.datastore.preferences.protobuf;

final class d {
  static {
    if (a("org.robolectric.Robolectric") != null) {
      bool = true;
    } else {
      bool = false;
    } 
    b = bool;
  }
  
  private static <T> Class<T> a(String paramString) {
    try {
      return (Class)Class.forName(paramString);
    } finally {
      paramString = null;
    } 
  }
  
  static Class<?> b() {
    return a;
  }
  
  static boolean c() {
    return (a != null && !b);
  }
  
  static {
    boolean bool;
  }
  
  private static final Class<?> a = a("libcore.io.Memory");
  
  private static final boolean b;
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */