package androidx.datastore.preferences.protobuf;

import java.io.IOException;

public class b0 extends IOException {
  private r0 a = null;
  
  public b0(String paramString) {
    super(paramString);
  }
  
  static b0 a() {
    return new b0("Protocol message end-group tag did not match expected tag.");
  }
  
  static b0 b() {
    return new b0("Protocol message contained an invalid tag (zero).");
  }
  
  static b0 c() {
    return new b0("Protocol message had invalid UTF-8.");
  }
  
  static a d() {
    return new a("Protocol message tag had invalid wire type.");
  }
  
  static b0 e() {
    return new b0("CodedInputStream encountered a malformed varint.");
  }
  
  static b0 f() {
    return new b0("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
  }
  
  static b0 g() {
    return new b0("Failed to parse the message.");
  }
  
  static b0 h() {
    return new b0("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
  }
  
  static b0 j() {
    return new b0("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
  }
  
  static b0 k() {
    return new b0("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
  }
  
  public b0 i(r0 paramr0) {
    this.a = paramr0;
    return this;
  }
  
  public static class a extends b0 {
    public a(String param1String) {
      super(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */