package androidx.datastore.preferences.protobuf;

public abstract class n<ContainingType extends r0, Type> {}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */