package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

abstract class e implements f1 {
  private e() {}
  
  public static e Q(ByteBuffer paramByteBuffer, boolean paramBoolean) {
    if (paramByteBuffer.hasArray())
      return new b(paramByteBuffer, paramBoolean); 
    throw new IllegalArgumentException("Direct buffers not yet supported");
  }
  
  private static final class b extends e {
    private final boolean a;
    
    private final byte[] b;
    
    private int c;
    
    private final int d;
    
    private int e;
    
    private int f;
    
    private int g;
    
    public b(ByteBuffer param1ByteBuffer, boolean param1Boolean) {
      super(null);
      this.a = param1Boolean;
      this.b = param1ByteBuffer.array();
      int i = param1ByteBuffer.arrayOffset() + param1ByteBuffer.position();
      this.c = i;
      this.d = i;
      this.e = param1ByteBuffer.arrayOffset() + param1ByteBuffer.limit();
    }
    
    private boolean R() {
      return (this.c == this.e);
    }
    
    private byte S() {
      int i = this.c;
      if (i != this.e) {
        byte[] arrayOfByte = this.b;
        this.c = i + 1;
        return arrayOfByte[i];
      } 
      throw b0.k();
    }
    
    private Object T(t1.b param1b, Class<?> param1Class, p param1p) {
      switch (e.a.a[param1b.ordinal()]) {
        default:
          throw new RuntimeException("unsupported field type.");
        case 17:
          return Long.valueOf(d());
        case 16:
          return Integer.valueOf(w());
        case 15:
          return F();
        case 14:
          return Long.valueOf(j());
        case 13:
          return Integer.valueOf(h());
        case 12:
          return Long.valueOf(r());
        case 11:
          return Integer.valueOf(z());
        case 10:
          return L(param1Class, param1p);
        case 9:
          return Long.valueOf(E());
        case 8:
          return Integer.valueOf(x());
        case 7:
          return Float.valueOf(readFloat());
        case 6:
          return Long.valueOf(f());
        case 5:
          return Integer.valueOf(n());
        case 4:
          return Integer.valueOf(b());
        case 3:
          return Double.valueOf(readDouble());
        case 2:
          return u();
        case 1:
          break;
      } 
      return Boolean.valueOf(o());
    }
    
    private <T> T U(g1<T> param1g1, p param1p) {
      int i = this.g;
      this.g = t1.c(t1.a(this.f), 4);
      try {
        T t = param1g1.f();
        param1g1.h(t, this, param1p);
        param1g1.b(t);
        int j = this.f;
        int k = this.g;
        if (j == k)
          return t; 
        throw b0.g();
      } finally {
        this.g = i;
      } 
    }
    
    private int V() {
      f0(4);
      return W();
    }
    
    private int W() {
      int i = this.c;
      byte[] arrayOfByte = this.b;
      this.c = i + 4;
      byte b1 = arrayOfByte[i];
      byte b2 = arrayOfByte[i + 1];
      byte b3 = arrayOfByte[i + 2];
      return (arrayOfByte[i + 3] & 0xFF) << 24 | b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
    }
    
    private long X() {
      f0(8);
      return Y();
    }
    
    private long Y() {
      int i = this.c;
      byte[] arrayOfByte = this.b;
      this.c = i + 8;
      long l1 = arrayOfByte[i];
      long l2 = arrayOfByte[i + 1];
      long l3 = arrayOfByte[i + 2];
      long l4 = arrayOfByte[i + 3];
      long l5 = arrayOfByte[i + 4];
      long l6 = arrayOfByte[i + 5];
      long l7 = arrayOfByte[i + 6];
      return (arrayOfByte[i + 7] & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
    }
    
    private <T> T Z(g1<T> param1g1, p param1p) {
      int j = c0();
      f0(j);
      int i = this.e;
      j = this.c + j;
      this.e = j;
      try {
        T t = param1g1.f();
        param1g1.h(t, this, param1p);
        param1g1.b(t);
        int k = this.c;
        if (k == j)
          return t; 
        throw b0.g();
      } finally {
        this.e = i;
      } 
    }
    
    private int c0() {
      int j = this.c;
      int i = this.e;
      if (i != j) {
        byte[] arrayOfByte = this.b;
        int k = j + 1;
        j = arrayOfByte[j];
        if (j >= 0) {
          this.c = k;
          return j;
        } 
        if (i - k < 9)
          return (int)e0(); 
        i = k + 1;
        j ^= arrayOfByte[k] << 7;
        if (j < 0) {
          k = j ^ 0xFFFFFF80;
        } else {
          k = i + 1;
          j ^= arrayOfByte[i] << 14;
          if (j >= 0) {
            j ^= 0x3F80;
            i = k;
            k = j;
          } else {
            i = k + 1;
            k = j ^ arrayOfByte[k] << 21;
            if (k < 0) {
              k ^= 0xFFE03F80;
            } else {
              int m = i + 1;
              byte b1 = arrayOfByte[i];
              j = k ^ b1 << 28 ^ 0xFE03F80;
              k = j;
              i = m;
              if (b1 < 0) {
                int n = m + 1;
                k = j;
                i = n;
                if (arrayOfByte[m] < 0) {
                  m = n + 1;
                  k = j;
                  i = m;
                  if (arrayOfByte[n] < 0) {
                    n = m + 1;
                    k = j;
                    i = n;
                    if (arrayOfByte[m] < 0) {
                      m = n + 1;
                      k = j;
                      i = m;
                      if (arrayOfByte[n] < 0) {
                        i = m + 1;
                        if (arrayOfByte[m] >= 0) {
                          k = j;
                        } else {
                          throw b0.e();
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
        this.c = i;
        return k;
      } 
      throw b0.k();
    }
    
    private long e0() {
      long l = 0L;
      for (int i = 0; i < 64; i += 7) {
        byte b1 = S();
        l |= (b1 & Byte.MAX_VALUE) << i;
        if ((b1 & 0x80) == 0)
          return l; 
      } 
      throw b0.e();
    }
    
    private void f0(int param1Int) {
      if (param1Int >= 0 && param1Int <= this.e - this.c)
        return; 
      throw b0.k();
    }
    
    private void g0(int param1Int) {
      if (this.c == param1Int)
        return; 
      throw b0.k();
    }
    
    private void h0(int param1Int) {
      if (t1.b(this.f) == param1Int)
        return; 
      throw b0.d();
    }
    
    private void i0(int param1Int) {
      f0(param1Int);
      this.c += param1Int;
    }
    
    private void j0() {
      int i = this.g;
      this.g = t1.c(t1.a(this.f), 4);
      do {
      
      } while (p() != Integer.MAX_VALUE && y());
      if (this.f == this.g) {
        this.g = i;
        return;
      } 
      throw b0.g();
    }
    
    private void k0() {
      int j = this.e;
      int i = this.c;
      if (j - i >= 10) {
        byte[] arrayOfByte = this.b;
        j = 0;
        while (j < 10) {
          int k = i + 1;
          if (arrayOfByte[i] >= 0) {
            this.c = k;
            return;
          } 
          j++;
          i = k;
        } 
      } 
      l0();
    }
    
    private void l0() {
      for (int i = 0; i < 10; i++) {
        if (S() >= 0)
          return; 
      } 
      throw b0.e();
    }
    
    private void m0(int param1Int) {
      f0(param1Int);
      if ((param1Int & 0x3) == 0)
        return; 
      throw b0.g();
    }
    
    private void n0(int param1Int) {
      f0(param1Int);
      if ((param1Int & 0x7) == 0)
        return; 
      throw b0.g();
    }
    
    public void A(List<h> param1List) {
      if (t1.b(this.f) == 2)
        while (true) {
          param1List.add(u());
          if (R())
            return; 
          int i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        }  
      throw b0.d();
    }
    
    public void B(List<Double> param1List) {
      if (param1List instanceof m) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.k(Double.longBitsToDouble(Y())); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.k(readDouble());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Double.valueOf(Double.longBitsToDouble(Y()))); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Double.valueOf(readDouble()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public void C(List<Long> param1List) {
      int i;
      if (param1List instanceof i0) {
        param1List = param1List;
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.m(d0());
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(E());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.add(Long.valueOf(d0()));
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.add(Long.valueOf(E()));
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } 
      g0(i);
    }
    
    public void D(List<Long> param1List) {
      if (param1List instanceof i0) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.m(Y()); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(r());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Long.valueOf(Y())); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Long.valueOf(r()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public long E() {
      h0(0);
      return d0();
    }
    
    public String F() {
      return a0(true);
    }
    
    public void G(List<Long> param1List) {
      if (param1List instanceof i0) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.m(Y()); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(f());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 1) {
          if (i == 2) {
            i = c0();
            n0(i);
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Long.valueOf(Y())); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Long.valueOf(f()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public void H(List<Integer> param1List) {
      int i;
      if (param1List instanceof z) {
        param1List = param1List;
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.k(c0());
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.k(x());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.add(Integer.valueOf(c0()));
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.add(Integer.valueOf(x()));
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } 
      g0(i);
    }
    
    public void I(List<Integer> param1List) {
      if (param1List instanceof z) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.k(c0()); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.k(b());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Integer.valueOf(c0())); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Integer.valueOf(b()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public <T> T J(g1<T> param1g1, p param1p) {
      h0(2);
      return Z(param1g1, param1p);
    }
    
    public <K, V> void K(Map<K, V> param1Map, k0.a<K, V> param1a, p param1p) {
      h0(2);
      int j = c0();
      f0(j);
      int i = this.e;
      this.e = this.c + j;
      try {
        K k = param1a.b;
        V v = param1a.d;
        while (true) {
          j = p();
          if (j == Integer.MAX_VALUE) {
            param1Map.put(k, v);
            return;
          } 
          if (j != 1) {
            if (j != 2)
              try {
                if (y())
                  continue; 
                throw new b0("Unable to parse map entry.");
              } catch (a a1) {
                if (y())
                  continue; 
                throw new b0("Unable to parse map entry.");
              }  
            Object object1 = T(param1a.c, param1a.d.getClass(), param1p);
            v = (V)object1;
            continue;
          } 
          Object object = T(param1a.a, null, null);
          k = (K)object;
        } 
      } finally {
        this.e = i;
      } 
    }
    
    public <T> T L(Class<T> param1Class, p param1p) {
      h0(2);
      return Z(c1.a().d(param1Class), param1p);
    }
    
    public <T> T M(Class<T> param1Class, p param1p) {
      h0(3);
      return U(c1.a().d(param1Class), param1p);
    }
    
    public <T> void N(List<T> param1List, g1<T> param1g1, p param1p) {
      if (t1.b(this.f) == 3) {
        int i = this.f;
        while (true) {
          param1List.add(U(param1g1, param1p));
          if (R())
            return; 
          int j = this.c;
          if (c0() != i) {
            this.c = j;
            return;
          } 
        } 
      } 
      throw b0.d();
    }
    
    public <T> void O(List<T> param1List, g1<T> param1g1, p param1p) {
      if (t1.b(this.f) == 2) {
        int i = this.f;
        while (true) {
          param1List.add(Z(param1g1, param1p));
          if (R())
            return; 
          int j = this.c;
          if (c0() != i) {
            this.c = j;
            return;
          } 
        } 
      } 
      throw b0.d();
    }
    
    public <T> T P(g1<T> param1g1, p param1p) {
      h0(3);
      return U(param1g1, param1p);
    }
    
    public void a(List<Integer> param1List) {
      if (param1List instanceof z) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.k(i.b(c0())); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.k(h());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Integer.valueOf(i.b(c0()))); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Integer.valueOf(h()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public String a0(boolean param1Boolean) {
      h0(2);
      int i = c0();
      if (i == 0)
        return ""; 
      f0(i);
      if (param1Boolean) {
        byte[] arrayOfByte = this.b;
        int j = this.c;
        if (!s1.n(arrayOfByte, j, j + i))
          throw b0.c(); 
      } 
      String str = new String(this.b, this.c, i, a0.a);
      this.c += i;
      return str;
    }
    
    public int b() {
      h0(0);
      return c0();
    }
    
    public void b0(List<String> param1List, boolean param1Boolean) {
      if (t1.b(this.f) == 2) {
        if (param1List instanceof g0 && !param1Boolean) {
          param1List = param1List;
          while (true) {
            param1List.l(u());
            if (R())
              return; 
            int i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
        while (true) {
          param1List.add(a0(param1Boolean));
          if (R())
            return; 
          int i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
      throw b0.d();
    }
    
    public int c() {
      return this.f;
    }
    
    public long d() {
      h0(0);
      return d0();
    }
    
    public long d0() {
      int j;
      int k = this.c;
      int i = this.e;
      if (i != k) {
        byte[] arrayOfByte = this.b;
        j = k + 1;
        k = arrayOfByte[k];
        if (k >= 0) {
          this.c = j;
          return k;
        } 
        if (i - j < 9)
          return e0(); 
        i = j + 1;
        k ^= arrayOfByte[j] << 7;
        if (k < 0) {
          j = k ^ 0xFFFFFF80;
        } else {
          long l1;
          j = i + 1;
          k ^= arrayOfByte[i] << 14;
          if (k >= 0) {
            l1 = (k ^ 0x3F80);
            i = j;
          } else {
            i = j + 1;
            j = k ^ arrayOfByte[j] << 21;
            if (j < 0) {
              j ^= 0xFFE03F80;
            } else {
              long l2 = j;
              j = i + 1;
              long l3 = l2 ^ arrayOfByte[i] << 28L;
              if (l3 >= 0L) {
                l2 = 266354560L;
                i = j;
              } else {
                i = j + 1;
                l2 = l3 ^ arrayOfByte[j] << 35L;
                if (l2 < 0L) {
                  l3 = -34093383808L;
                } else {
                  j = i + 1;
                  l3 = l2 ^ arrayOfByte[i] << 42L;
                  if (l3 >= 0L) {
                    l2 = 4363953127296L;
                    i = j;
                  } else {
                    i = j + 1;
                    l2 = l3 ^ arrayOfByte[j] << 49L;
                    if (l2 < 0L) {
                      l3 = -558586000294016L;
                    } else {
                      j = i + 1;
                      l2 = l2 ^ arrayOfByte[i] << 56L ^ 0xFE03F80FE03F80L;
                      if (l2 < 0L) {
                        i = j + 1;
                        if (arrayOfByte[j] < 0L)
                          throw b0.e(); 
                      } else {
                        i = j;
                      } 
                      this.c = i;
                      return l2;
                    } 
                    l2 ^= l3;
                  } 
                  l2 = l3 ^ l2;
                } 
                l2 ^= l3;
              } 
              l2 = l3 ^ l2;
            } 
            l1 = j;
          } 
          this.c = i;
          return l1;
        } 
      } else {
        throw b0.k();
      } 
      long l = j;
    }
    
    public void e(List<Integer> param1List) {
      if (param1List instanceof z) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.k(n());
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.k(W()); 
      } else {
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.add(Integer.valueOf(n()));
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.add(Integer.valueOf(W())); 
      } 
    }
    
    public long f() {
      h0(1);
      return X();
    }
    
    public void g(List<Integer> param1List) {
      if (param1List instanceof z) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.k(z());
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.k(W()); 
      } else {
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.add(Integer.valueOf(z()));
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.add(Integer.valueOf(W())); 
      } 
    }
    
    public int h() {
      h0(0);
      return i.b(c0());
    }
    
    public void i(List<Long> param1List) {
      if (param1List instanceof i0) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.m(i.c(d0())); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(j());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Long.valueOf(i.c(d0()))); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Long.valueOf(j()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public long j() {
      h0(0);
      return i.c(d0());
    }
    
    public void k(List<Integer> param1List) {
      if (param1List instanceof z) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.k(c0()); 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.k(w());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        int i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c;
            while (this.c < j + i)
              param1List.add(Integer.valueOf(c0())); 
            return;
          } 
          throw b0.d();
        } 
        while (true) {
          param1List.add(Integer.valueOf(w()));
          if (R())
            return; 
          i = this.c;
          if (c0() != this.f) {
            this.c = i;
            return;
          } 
        } 
      } 
    }
    
    public void l(List<Boolean> param1List) {
      int i;
      if (param1List instanceof f) {
        param1List = param1List;
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                boolean bool;
                if (c0() != 0) {
                  bool = true;
                } else {
                  bool = false;
                } 
                param1List.m(bool);
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(o());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                boolean bool;
                if (c0() != 0) {
                  bool = true;
                } else {
                  bool = false;
                } 
                param1List.add(Boolean.valueOf(bool));
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.add(Boolean.valueOf(o()));
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } 
      g0(i);
    }
    
    public String m() {
      return a0(false);
    }
    
    public int n() {
      h0(5);
      return V();
    }
    
    public boolean o() {
      boolean bool = false;
      h0(0);
      if (c0() != 0)
        bool = true; 
      return bool;
    }
    
    public int p() {
      if (R())
        return Integer.MAX_VALUE; 
      int i = c0();
      this.f = i;
      return (i == this.g) ? Integer.MAX_VALUE : t1.a(i);
    }
    
    public void q(List<String> param1List) {
      b0(param1List, false);
    }
    
    public long r() {
      h0(1);
      return X();
    }
    
    public double readDouble() {
      h0(1);
      return Double.longBitsToDouble(X());
    }
    
    public float readFloat() {
      h0(5);
      return Float.intBitsToFloat(V());
    }
    
    public void s(List<Long> param1List) {
      int i;
      if (param1List instanceof i0) {
        param1List = param1List;
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.m(d0());
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.m(d());
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } else {
        i = t1.b(this.f);
        if (i != 0) {
          if (i == 2) {
            i = c0();
            int j = this.c + i;
            while (true) {
              i = j;
              if (this.c < j) {
                param1List.add(Long.valueOf(d0()));
                continue;
              } 
              break;
            } 
          } else {
            throw b0.d();
          } 
        } else {
          while (true) {
            param1List.add(Long.valueOf(d()));
            if (R())
              return; 
            i = this.c;
            if (c0() != this.f) {
              this.c = i;
              return;
            } 
          } 
        } 
      } 
      g0(i);
    }
    
    public void t(List<String> param1List) {
      b0(param1List, true);
    }
    
    public h u() {
      h h;
      h0(2);
      int i = c0();
      if (i == 0)
        return h.b; 
      f0(i);
      if (this.a) {
        h = h.E(this.b, this.c, i);
      } else {
        h = h.n(this.b, this.c, i);
      } 
      this.c += i;
      return h;
    }
    
    public void v(List<Float> param1List) {
      if (param1List instanceof w) {
        param1List = param1List;
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.k(readFloat());
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.k(Float.intBitsToFloat(W())); 
      } else {
        int i = t1.b(this.f);
        if (i != 2) {
          if (i == 5)
            while (true) {
              param1List.add(Float.valueOf(readFloat()));
              if (R())
                return; 
              i = this.c;
              if (c0() != this.f) {
                this.c = i;
                return;
              } 
            }  
          throw b0.d();
        } 
        i = c0();
        m0(i);
        int j = this.c;
        while (this.c < j + i)
          param1List.add(Float.valueOf(Float.intBitsToFloat(W()))); 
      } 
    }
    
    public int w() {
      h0(0);
      return c0();
    }
    
    public int x() {
      h0(0);
      return c0();
    }
    
    public boolean y() {
      if (!R()) {
        int i = this.f;
        if (i != this.g) {
          i = t1.b(i);
          if (i != 0) {
            if (i != 1) {
              if (i != 2) {
                if (i != 3) {
                  if (i == 5) {
                    i = 4;
                    i0(i);
                    return true;
                  } 
                  throw b0.d();
                } 
                j0();
                return true;
              } 
              i = c0();
              i0(i);
              return true;
            } 
            i = 8;
            i0(i);
            return true;
          } 
          k0();
          return true;
        } 
      } 
      return false;
    }
    
    public int z() {
      h0(5);
      return V();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */