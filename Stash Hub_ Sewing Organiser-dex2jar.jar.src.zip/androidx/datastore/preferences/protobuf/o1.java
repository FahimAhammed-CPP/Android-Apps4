package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

public final class o1 {
  private static final o1 f = new o1(0, new int[0], new Object[0], false);
  
  private int a;
  
  private int[] b;
  
  private Object[] c;
  
  private int d = -1;
  
  private boolean e;
  
  private o1() {
    this(0, new int[8], new Object[8], true);
  }
  
  private o1(int paramInt, int[] paramArrayOfint, Object[] paramArrayOfObject, boolean paramBoolean) {
    this.a = paramInt;
    this.b = paramArrayOfint;
    this.c = paramArrayOfObject;
    this.e = paramBoolean;
  }
  
  private void b() {
    int i = this.a;
    int[] arrayOfInt = this.b;
    if (i == arrayOfInt.length) {
      if (i < 4) {
        j = 8;
      } else {
        j = i >> 1;
      } 
      int j = i + j;
      this.b = Arrays.copyOf(arrayOfInt, j);
      this.c = Arrays.copyOf(this.c, j);
    } 
  }
  
  private static boolean c(int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      if (paramArrayOfint1[i] != paramArrayOfint2[i])
        return false; 
    } 
    return true;
  }
  
  private static boolean d(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      if (!paramArrayOfObject1[i].equals(paramArrayOfObject2[i]))
        return false; 
    } 
    return true;
  }
  
  public static o1 e() {
    return f;
  }
  
  private static int h(int[] paramArrayOfint, int paramInt) {
    int j = 17;
    for (int i = 0; i < paramInt; i++)
      j = j * 31 + paramArrayOfint[i]; 
    return j;
  }
  
  private static int i(Object[] paramArrayOfObject, int paramInt) {
    int j = 17;
    for (int i = 0; i < paramInt; i++)
      j = j * 31 + paramArrayOfObject[i].hashCode(); 
    return j;
  }
  
  static o1 k(o1 paramo11, o1 paramo12) {
    int i = paramo11.a + paramo12.a;
    int[] arrayOfInt = Arrays.copyOf(paramo11.b, i);
    System.arraycopy(paramo12.b, 0, arrayOfInt, paramo11.a, paramo12.a);
    Object[] arrayOfObject = Arrays.copyOf(paramo11.c, i);
    System.arraycopy(paramo12.c, 0, arrayOfObject, paramo11.a, paramo12.a);
    return new o1(i, arrayOfInt, arrayOfObject, true);
  }
  
  static o1 l() {
    return new o1();
  }
  
  private static void p(int paramInt, Object paramObject, u1 paramu1) {
    int i = t1.a(paramInt);
    paramInt = t1.b(paramInt);
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt == 5) {
              paramu1.l(i, ((Integer)paramObject).intValue());
              return;
            } 
            throw new RuntimeException(b0.d());
          } 
          if (paramu1.v() == u1.a.a) {
            paramu1.h(i);
            ((o1)paramObject).q(paramu1);
            paramu1.z(i);
            return;
          } 
          paramu1.z(i);
          ((o1)paramObject).q(paramu1);
          paramu1.h(i);
          return;
        } 
        paramu1.J(i, (h)paramObject);
        return;
      } 
      paramu1.u(i, ((Long)paramObject).longValue());
      return;
    } 
    paramu1.c(i, ((Long)paramObject).longValue());
  }
  
  void a() {
    if (this.e)
      return; 
    throw new UnsupportedOperationException();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof o1))
      return false; 
    paramObject = paramObject;
    int i = this.a;
    return (i == ((o1)paramObject).a && c(this.b, ((o1)paramObject).b, i)) ? (!!d(this.c, ((o1)paramObject).c, this.a)) : false;
  }
  
  public int f() {
    int i = this.d;
    if (i != -1)
      return i; 
    int j = 0;
    int k = 0;
    while (j < this.a) {
      int m = this.b[j];
      i = t1.a(m);
      m = t1.b(m);
      if (m != 0) {
        if (m != 1) {
          if (m != 2) {
            if (m != 3) {
              if (m == 5) {
                i = k.m(i, ((Integer)this.c[j]).intValue());
              } else {
                throw new IllegalStateException(b0.d());
              } 
            } else {
              i = k.V(i) * 2 + ((o1)this.c[j]).f();
            } 
          } else {
            i = k.g(i, (h)this.c[j]);
          } 
        } else {
          i = k.o(i, ((Long)this.c[j]).longValue());
        } 
      } else {
        i = k.Y(i, ((Long)this.c[j]).longValue());
      } 
      k += i;
      j++;
    } 
    this.d = k;
    return k;
  }
  
  public int g() {
    int i = this.d;
    if (i != -1)
      return i; 
    i = 0;
    int j = 0;
    while (i < this.a) {
      j += k.J(t1.a(this.b[i]), (h)this.c[i]);
      i++;
    } 
    this.d = j;
    return j;
  }
  
  public int hashCode() {
    int i = this.a;
    return ((527 + i) * 31 + h(this.b, i)) * 31 + i(this.c, this.a);
  }
  
  public void j() {
    this.e = false;
  }
  
  final void m(StringBuilder paramStringBuilder, int paramInt) {
    for (int i = 0; i < this.a; i++)
      t0.c(paramStringBuilder, paramInt, String.valueOf(t1.a(this.b[i])), this.c[i]); 
  }
  
  void n(int paramInt, Object paramObject) {
    a();
    b();
    int[] arrayOfInt = this.b;
    int i = this.a;
    arrayOfInt[i] = paramInt;
    this.c[i] = paramObject;
    this.a = i + 1;
  }
  
  void o(u1 paramu1) {
    if (paramu1.v() == u1.a.b) {
      for (int i = this.a - 1; i >= 0; i--)
        paramu1.f(t1.a(this.b[i]), this.c[i]); 
    } else {
      for (int i = 0; i < this.a; i++)
        paramu1.f(t1.a(this.b[i]), this.c[i]); 
    } 
  }
  
  public void q(u1 paramu1) {
    if (this.a == 0)
      return; 
    if (paramu1.v() == u1.a.a) {
      for (int i = 0; i < this.a; i++)
        p(this.b[i], this.c[i], paramu1); 
    } else {
      for (int i = this.a - 1; i >= 0; i--)
        p(this.b[i], this.c[i], paramu1); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\o1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */