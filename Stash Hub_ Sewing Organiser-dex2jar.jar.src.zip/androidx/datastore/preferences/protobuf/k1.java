package androidx.datastore.preferences.protobuf;

final class k1 implements p0 {
  private final b1 a;
  
  private final boolean b;
  
  private final int[] c;
  
  private final t[] d;
  
  private final r0 e;
  
  public boolean a() {
    return this.b;
  }
  
  public b1 b() {
    return this.a;
  }
  
  public r0 c() {
    return this.e;
  }
  
  public int[] d() {
    return this.c;
  }
  
  public t[] e() {
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */