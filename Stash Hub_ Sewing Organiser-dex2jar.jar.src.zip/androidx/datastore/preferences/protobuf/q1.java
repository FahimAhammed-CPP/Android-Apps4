package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public class q1 extends AbstractList<String> implements g0, RandomAccess {
  private final g0 a;
  
  public q1(g0 paramg0) {
    this.a = paramg0;
  }
  
  public String c(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public g0 f() {
    return this;
  }
  
  public Object h(int paramInt) {
    return this.a.h(paramInt);
  }
  
  public List<?> i() {
    return this.a.i();
  }
  
  public Iterator<String> iterator() {
    return new b(this);
  }
  
  public void l(h paramh) {
    throw new UnsupportedOperationException();
  }
  
  public ListIterator<String> listIterator(int paramInt) {
    return new a(this, paramInt);
  }
  
  public int size() {
    return this.a.size();
  }
  
  class a implements ListIterator<String> {
    ListIterator<String> a;
    
    a(q1 this$0, int param1Int) {
      this.a = q1.a(this$0).listIterator(param1Int);
    }
    
    public void b(String param1String) {
      throw new UnsupportedOperationException();
    }
    
    public String c() {
      return this.a.next();
    }
    
    public String d() {
      return this.a.previous();
    }
    
    public void e(String param1String) {
      throw new UnsupportedOperationException();
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public boolean hasPrevious() {
      return this.a.hasPrevious();
    }
    
    public int nextIndex() {
      return this.a.nextIndex();
    }
    
    public int previousIndex() {
      return this.a.previousIndex();
    }
    
    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
  
  class b implements Iterator<String> {
    Iterator<String> a;
    
    b(q1 this$0) {
      this.a = q1.a(this$0).iterator();
    }
    
    public String b() {
      return this.a.next();
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\q1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */