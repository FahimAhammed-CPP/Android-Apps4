package androidx.datastore.preferences.protobuf;

import java.util.Map;

interface m0 {
  Object a(Object paramObject1, Object paramObject2);
  
  Object b(Object paramObject);
  
  int c(int paramInt, Object paramObject1, Object paramObject2);
  
  boolean d(Object paramObject);
  
  Object e(Object paramObject);
  
  k0.a<?, ?> f(Object paramObject);
  
  Map<?, ?> g(Object paramObject);
  
  Map<?, ?> h(Object paramObject);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */