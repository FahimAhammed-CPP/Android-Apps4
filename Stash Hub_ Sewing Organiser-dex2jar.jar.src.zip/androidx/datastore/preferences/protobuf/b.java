package androidx.datastore.preferences.protobuf;

public abstract class b<MessageType extends r0> implements z0<MessageType> {
  private static final p a = p.b();
  
  private MessageType c(MessageType paramMessageType) {
    if (paramMessageType != null) {
      if (paramMessageType.i())
        return paramMessageType; 
      throw d(paramMessageType).a().i(paramMessageType);
    } 
    return paramMessageType;
  }
  
  private m1 d(MessageType paramMessageType) {
    return (paramMessageType instanceof a) ? ((a)paramMessageType).p() : new m1((r0)paramMessageType);
  }
  
  public MessageType e(h paramh, p paramp) {
    return c(f(paramh, paramp));
  }
  
  public MessageType f(h paramh, p paramp) {
    try {
      i i = paramh.u();
      r0 r0 = (r0)b(i, paramp);
      try {
        i.a(0);
        return (MessageType)r0;
      } catch (b0 b0) {
        throw b0.i(r0);
      } 
    } catch (b0 b0) {
      throw b0;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */