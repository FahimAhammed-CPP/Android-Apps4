package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Type;

public enum v {
  A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, a0, b0, c0, d0, e0, f, f0, g, g0, h0, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;
  
  private static final v[] i0;
  
  private static final Type[] j0;
  
  private final c0 a;
  
  private final int b;
  
  private final b c;
  
  private final Class<?> d;
  
  private final boolean e;
  
  static {
    b b1 = b.b;
    c0 c06 = c0.l;
    v v1 = new v("DOUBLE", 0, 0, b1, c06);
    f = v1;
    c0 c07 = c0.g;
    v v2 = new v("FLOAT", 1, 1, b1, c07);
    g = v2;
    c0 c03 = c0.f;
    v v3 = new v("INT64", 2, 2, b1, c03);
    l = v3;
    v v4 = new v("UINT64", 3, 3, b1, c03);
    m = v4;
    c0 c05 = c0.e;
    v v5 = new v("INT32", 4, 4, b1, c05);
    n = v5;
    v v6 = new v("FIXED64", 5, 5, b1, c03);
    o = v6;
    v v7 = new v("FIXED32", 6, 6, b1, c05);
    p = v7;
    c0 c08 = c0.m;
    v v8 = new v("BOOL", 7, 7, b1, c08);
    q = v8;
    c0 c02 = c0.n;
    v v9 = new v("STRING", 8, 8, b1, c02);
    r = v9;
    c0 c01 = c0.q;
    v v10 = new v("MESSAGE", 9, 9, b1, c01);
    s = v10;
    c0 c04 = c0.o;
    v v11 = new v("BYTES", 10, 10, b1, c04);
    t = v11;
    v v12 = new v("UINT32", 11, 11, b1, c05);
    u = v12;
    c0 c09 = c0.p;
    v v13 = new v("ENUM", 12, 12, b1, c09);
    v = v13;
    v v14 = new v("SFIXED32", 13, 13, b1, c05);
    w = v14;
    v v15 = new v("SFIXED64", 14, 14, b1, c03);
    x = v15;
    v v16 = new v("SINT32", 15, 15, b1, c05);
    y = v16;
    v v17 = new v("SINT64", 16, 16, b1, c03);
    z = v17;
    v v18 = new v("GROUP", 17, 17, b1, c01);
    A = v18;
    b b2 = b.c;
    v v19 = new v("DOUBLE_LIST", 18, 18, b2, c06);
    B = v19;
    v v20 = new v("FLOAT_LIST", 19, 19, b2, c07);
    C = v20;
    v v21 = new v("INT64_LIST", 20, 20, b2, c03);
    D = v21;
    v v22 = new v("UINT64_LIST", 21, 21, b2, c03);
    E = v22;
    v v23 = new v("INT32_LIST", 22, 22, b2, c05);
    F = v23;
    v v24 = new v("FIXED64_LIST", 23, 23, b2, c03);
    G = v24;
    v v25 = new v("FIXED32_LIST", 24, 24, b2, c05);
    H = v25;
    v v26 = new v("BOOL_LIST", 25, 25, b2, c08);
    I = v26;
    v v28 = new v("STRING_LIST", 26, 26, b2, c02);
    J = v28;
    v v29 = new v("MESSAGE_LIST", 27, 27, b2, c01);
    K = v29;
    v v32 = new v("BYTES_LIST", 28, 28, b2, c04);
    L = v32;
    v v33 = new v("UINT32_LIST", 29, 29, b2, c05);
    M = v33;
    v v34 = new v("ENUM_LIST", 30, 30, b2, c09);
    N = v34;
    v v35 = new v("SFIXED32_LIST", 31, 31, b2, c05);
    O = v35;
    v v36 = new v("SFIXED64_LIST", 32, 32, b2, c03);
    P = v36;
    v v37 = new v("SINT32_LIST", 33, 33, b2, c05);
    Q = v37;
    v v38 = new v("SINT64_LIST", 34, 34, b2, c03);
    R = v38;
    b b3 = b.d;
    v v40 = new v("DOUBLE_LIST_PACKED", 35, 35, b3, c06);
    S = v40;
    v v41 = new v("FLOAT_LIST_PACKED", 36, 36, b3, c07);
    T = v41;
    v v42 = new v("INT64_LIST_PACKED", 37, 37, b3, c03);
    U = v42;
    v v43 = new v("UINT64_LIST_PACKED", 38, 38, b3, c03);
    V = v43;
    v v44 = new v("INT32_LIST_PACKED", 39, 39, b3, c05);
    W = v44;
    v v45 = new v("FIXED64_LIST_PACKED", 40, 40, b3, c03);
    X = v45;
    v v46 = new v("FIXED32_LIST_PACKED", 41, 41, b3, c05);
    Y = v46;
    v v47 = new v("BOOL_LIST_PACKED", 42, 42, b3, c08);
    Z = v47;
    v v48 = new v("UINT32_LIST_PACKED", 43, 43, b3, c05);
    a0 = v48;
    v v49 = new v("ENUM_LIST_PACKED", 44, 44, b3, c09);
    b0 = v49;
    v v50 = new v("SFIXED32_LIST_PACKED", 45, 45, b3, c05);
    c0 = v50;
    v v51 = new v("SFIXED64_LIST_PACKED", 46, 46, b3, c03);
    d0 = v51;
    v v39 = new v("SINT32_LIST_PACKED", 47, 47, b3, c05);
    e0 = v39;
    v v30 = new v("SINT64_LIST_PACKED", 48, 48, b3, c03);
    f0 = v30;
    v v27 = new v("GROUP_LIST", 49, 49, b2, c01);
    g0 = v27;
    v v31 = new v("MAP", 50, 50, b.e, c0.d);
    h0 = v31;
    int i = 0;
    k0 = new v[] { 
        v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, 
        v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, 
        v21, v22, v23, v24, v25, v26, v28, v29, v32, v33, 
        v34, v35, v36, v37, v38, v40, v41, v42, v43, v44, 
        v45, v46, v47, v48, v49, v50, v51, v39, v30, v27, 
        v31 };
    j0 = new Type[0];
    v[] arrayOfV = values();
    i0 = new v[arrayOfV.length];
    int j = arrayOfV.length;
    while (i < j) {
      v2 = arrayOfV[i];
      i0[v2.b] = v2;
      i++;
    } 
  }
  
  v(int paramInt1, b paramb, c0 paramc0) {
    Class<?> clazz;
    this.b = paramInt1;
    this.c = paramb;
    this.a = paramc0;
    this$enum$index = a.a[paramb.ordinal()];
    boolean bool = true;
    if (this$enum$index != 1 && this$enum$index != 2) {
      this$enum$name = null;
    } else {
      clazz = paramc0.a();
    } 
    this.d = clazz;
    if (paramb == b.b) {
      this$enum$index = a.b[paramc0.ordinal()];
      if (this$enum$index != 1 && this$enum$index != 2 && this$enum$index != 3) {
        this.e = bool;
        return;
      } 
    } 
    bool = false;
    this.e = bool;
  }
  
  public int a() {
    return this.b;
  }
  
  enum b {
    b, c, d, e;
    
    private final boolean a;
    
    static {
      b b1 = new b("SCALAR", 0, false);
      b = b1;
      b b2 = new b("VECTOR", 1, true);
      c = b2;
      b b3 = new b("PACKED_VECTOR", 2, true);
      d = b3;
      b b4 = new b("MAP", 3, false);
      e = b4;
      f = new b[] { b1, b2, b3, b4 };
    }
    
    b(boolean param1Boolean) {
      this.a = param1Boolean;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */