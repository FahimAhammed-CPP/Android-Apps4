package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class k extends g {
  private static final Logger c = Logger.getLogger(k.class.getName());
  
  private static final boolean d = r1.C();
  
  l a;
  
  private boolean b;
  
  private k() {}
  
  public static int A(int paramInt, e0 parame0) {
    return V(paramInt) + B(parame0);
  }
  
  public static int B(e0 parame0) {
    return C(parame0.b());
  }
  
  static int C(int paramInt) {
    return X(paramInt) + paramInt;
  }
  
  public static int D(int paramInt, r0 paramr0) {
    return V(1) * 2 + W(2, paramInt) + E(3, paramr0);
  }
  
  public static int E(int paramInt, r0 paramr0) {
    return V(paramInt) + G(paramr0);
  }
  
  static int F(int paramInt, r0 paramr0, g1 paramg1) {
    return V(paramInt) + H(paramr0, paramg1);
  }
  
  public static int G(r0 paramr0) {
    return C(paramr0.b());
  }
  
  static int H(r0 paramr0, g1 paramg1) {
    return C(((a)paramr0).n(paramg1));
  }
  
  static int I(int paramInt) {
    return (paramInt > 4096) ? 4096 : paramInt;
  }
  
  public static int J(int paramInt, h paramh) {
    return V(1) * 2 + W(2, paramInt) + g(3, paramh);
  }
  
  @Deprecated
  public static int K(int paramInt) {
    return X(paramInt);
  }
  
  public static int L(int paramInt1, int paramInt2) {
    return V(paramInt1) + M(paramInt2);
  }
  
  public static int M(int paramInt) {
    return 4;
  }
  
  public static int N(int paramInt, long paramLong) {
    return V(paramInt) + O(paramLong);
  }
  
  public static int O(long paramLong) {
    return 8;
  }
  
  public static int P(int paramInt1, int paramInt2) {
    return V(paramInt1) + Q(paramInt2);
  }
  
  public static int Q(int paramInt) {
    return X(a0(paramInt));
  }
  
  public static int R(int paramInt, long paramLong) {
    return V(paramInt) + S(paramLong);
  }
  
  public static int S(long paramLong) {
    return Z(b0(paramLong));
  }
  
  public static int T(int paramInt, String paramString) {
    return V(paramInt) + U(paramString);
  }
  
  public static int U(String paramString) {
    int i;
    try {
      i = s1.g(paramString);
    } catch (d d) {
      i = (paramString.getBytes(a0.a)).length;
    } 
    return C(i);
  }
  
  public static int V(int paramInt) {
    return X(t1.c(paramInt, 0));
  }
  
  public static int W(int paramInt1, int paramInt2) {
    return V(paramInt1) + X(paramInt2);
  }
  
  public static int X(int paramInt) {
    return ((paramInt & 0xFFFFFF80) == 0) ? 1 : (((paramInt & 0xFFFFC000) == 0) ? 2 : (((0xFFE00000 & paramInt) == 0) ? 3 : (((paramInt & 0xF0000000) == 0) ? 4 : 5)));
  }
  
  public static int Y(int paramInt, long paramLong) {
    return V(paramInt) + Z(paramLong);
  }
  
  public static int Z(long paramLong) {
    if ((0xFFFFFFFFFFFFFF80L & paramLong) == 0L)
      return 1; 
    if (paramLong < 0L)
      return 10; 
    if ((0xFFFFFFF800000000L & paramLong) != 0L) {
      j = 6;
      paramLong >>>= 28L;
    } else {
      j = 2;
    } 
    int i = j;
    long l1 = paramLong;
    if ((0xFFFFFFFFFFE00000L & paramLong) != 0L) {
      i = j + 2;
      l1 = paramLong >>> 14L;
    } 
    int j = i;
    if ((l1 & 0xFFFFFFFFFFFFC000L) != 0L)
      j = i + 1; 
    return j;
  }
  
  public static int a0(int paramInt) {
    return paramInt >> 31 ^ paramInt << 1;
  }
  
  public static long b0(long paramLong) {
    return paramLong >> 63L ^ paramLong << 1L;
  }
  
  public static int d(int paramInt, boolean paramBoolean) {
    return V(paramInt) + e(paramBoolean);
  }
  
  public static int e(boolean paramBoolean) {
    return 1;
  }
  
  public static int f(byte[] paramArrayOfbyte) {
    return C(paramArrayOfbyte.length);
  }
  
  public static k f0(OutputStream paramOutputStream, int paramInt) {
    return new e(paramOutputStream, paramInt);
  }
  
  public static int g(int paramInt, h paramh) {
    return V(paramInt) + h(paramh);
  }
  
  public static k g0(byte[] paramArrayOfbyte) {
    return h0(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static int h(h paramh) {
    return C(paramh.size());
  }
  
  public static k h0(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return new c(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  public static int i(int paramInt, double paramDouble) {
    return V(paramInt) + j(paramDouble);
  }
  
  public static int j(double paramDouble) {
    return 8;
  }
  
  public static int k(int paramInt1, int paramInt2) {
    return V(paramInt1) + l(paramInt2);
  }
  
  public static int l(int paramInt) {
    return w(paramInt);
  }
  
  public static int m(int paramInt1, int paramInt2) {
    return V(paramInt1) + n(paramInt2);
  }
  
  public static int n(int paramInt) {
    return 4;
  }
  
  public static int o(int paramInt, long paramLong) {
    return V(paramInt) + p(paramLong);
  }
  
  public static int p(long paramLong) {
    return 8;
  }
  
  public static int q(int paramInt, float paramFloat) {
    return V(paramInt) + r(paramFloat);
  }
  
  public static int r(float paramFloat) {
    return 4;
  }
  
  @Deprecated
  static int s(int paramInt, r0 paramr0, g1 paramg1) {
    return V(paramInt) * 2 + u(paramr0, paramg1);
  }
  
  @Deprecated
  public static int t(r0 paramr0) {
    return paramr0.b();
  }
  
  @Deprecated
  static int u(r0 paramr0, g1 paramg1) {
    return ((a)paramr0).n(paramg1);
  }
  
  public static int v(int paramInt1, int paramInt2) {
    return V(paramInt1) + w(paramInt2);
  }
  
  public static int w(int paramInt) {
    return (paramInt >= 0) ? X(paramInt) : 10;
  }
  
  public static int x(int paramInt, long paramLong) {
    return V(paramInt) + y(paramLong);
  }
  
  public static int y(long paramLong) {
    return Z(paramLong);
  }
  
  public static int z(int paramInt, e0 parame0) {
    return V(1) * 2 + W(2, paramInt) + A(3, parame0);
  }
  
  @Deprecated
  public final void A0(int paramInt, r0 paramr0) {
    W0(paramInt, 3);
    C0(paramr0);
    W0(paramInt, 4);
  }
  
  @Deprecated
  final void B0(int paramInt, r0 paramr0, g1 paramg1) {
    W0(paramInt, 3);
    D0(paramr0, paramg1);
    W0(paramInt, 4);
  }
  
  @Deprecated
  public final void C0(r0 paramr0) {
    paramr0.j(this);
  }
  
  @Deprecated
  final void D0(r0 paramr0, g1<r0> paramg1) {
    paramg1.i(paramr0, this.a);
  }
  
  public abstract void E0(int paramInt1, int paramInt2);
  
  public abstract void F0(int paramInt);
  
  public final void G0(int paramInt, long paramLong) {
    Z0(paramInt, paramLong);
  }
  
  public final void H0(long paramLong) {
    a1(paramLong);
  }
  
  abstract void I0(int paramInt, r0 paramr0, g1 paramg1);
  
  public abstract void J0(r0 paramr0);
  
  public abstract void K0(int paramInt, r0 paramr0);
  
  public abstract void L0(int paramInt, h paramh);
  
  public final void M0(int paramInt1, int paramInt2) {
    u0(paramInt1, paramInt2);
  }
  
  public final void N0(int paramInt) {
    v0(paramInt);
  }
  
  public final void O0(int paramInt, long paramLong) {
    w0(paramInt, paramLong);
  }
  
  public final void P0(long paramLong) {
    x0(paramLong);
  }
  
  public final void Q0(int paramInt1, int paramInt2) {
    X0(paramInt1, a0(paramInt2));
  }
  
  public final void R0(int paramInt) {
    Y0(a0(paramInt));
  }
  
  public final void S0(int paramInt, long paramLong) {
    Z0(paramInt, b0(paramLong));
  }
  
  public final void T0(long paramLong) {
    a1(b0(paramLong));
  }
  
  public abstract void U0(int paramInt, String paramString);
  
  public abstract void V0(String paramString);
  
  public abstract void W0(int paramInt1, int paramInt2);
  
  public abstract void X0(int paramInt1, int paramInt2);
  
  public abstract void Y0(int paramInt);
  
  public abstract void Z0(int paramInt, long paramLong);
  
  public abstract void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  public abstract void a1(long paramLong);
  
  public final void c() {
    if (i0() == 0)
      return; 
    throw new IllegalStateException("Did not write as much data as expected.");
  }
  
  public abstract void c0();
  
  final void d0(String paramString, s1.d paramd) {
    c.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", paramd);
    byte[] arrayOfByte = paramString.getBytes(a0.a);
    try {
      Y0(arrayOfByte.length);
      a(arrayOfByte, 0, arrayOfByte.length);
      return;
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      throw new d(indexOutOfBoundsException);
    } catch (d d1) {
      throw d1;
    } 
  }
  
  boolean e0() {
    return this.b;
  }
  
  public abstract int i0();
  
  public abstract void j0(byte paramByte);
  
  public abstract void k0(int paramInt, boolean paramBoolean);
  
  public final void l0(boolean paramBoolean) {
    j0((byte)paramBoolean);
  }
  
  public final void m0(byte[] paramArrayOfbyte) {
    n0(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  abstract void n0(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  public abstract void o0(int paramInt, h paramh);
  
  public abstract void p0(h paramh);
  
  public final void q0(int paramInt, double paramDouble) {
    w0(paramInt, Double.doubleToRawLongBits(paramDouble));
  }
  
  public final void r0(double paramDouble) {
    x0(Double.doubleToRawLongBits(paramDouble));
  }
  
  public final void s0(int paramInt1, int paramInt2) {
    E0(paramInt1, paramInt2);
  }
  
  public final void t0(int paramInt) {
    F0(paramInt);
  }
  
  public abstract void u0(int paramInt1, int paramInt2);
  
  public abstract void v0(int paramInt);
  
  public abstract void w0(int paramInt, long paramLong);
  
  public abstract void x0(long paramLong);
  
  public final void y0(int paramInt, float paramFloat) {
    u0(paramInt, Float.floatToRawIntBits(paramFloat));
  }
  
  public final void z0(float paramFloat) {
    v0(Float.floatToRawIntBits(paramFloat));
  }
  
  private static abstract class b extends k {
    final byte[] e;
    
    final int f;
    
    int g;
    
    int h;
    
    b(int param1Int) {
      super(null);
      if (param1Int >= 0) {
        byte[] arrayOfByte = new byte[Math.max(param1Int, 20)];
        this.e = arrayOfByte;
        this.f = arrayOfByte.length;
        return;
      } 
      throw new IllegalArgumentException("bufferSize must be >= 0");
    }
    
    final void b1(byte param1Byte) {
      byte[] arrayOfByte = this.e;
      int i = this.g;
      this.g = i + 1;
      arrayOfByte[i] = param1Byte;
      this.h++;
    }
    
    final void c1(int param1Int) {
      byte[] arrayOfByte = this.e;
      int j = this.g;
      int i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)(param1Int & 0xFF);
      j = i + 1;
      this.g = j;
      arrayOfByte[i] = (byte)(param1Int >> 8 & 0xFF);
      i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)(param1Int >> 16 & 0xFF);
      this.g = i + 1;
      arrayOfByte[i] = (byte)(param1Int >> 24 & 0xFF);
      this.h += 4;
    }
    
    final void d1(long param1Long) {
      byte[] arrayOfByte = this.e;
      int j = this.g;
      int i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)(int)(param1Long & 0xFFL);
      j = i + 1;
      this.g = j;
      arrayOfByte[i] = (byte)(int)(param1Long >> 8L & 0xFFL);
      i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)(int)(param1Long >> 16L & 0xFFL);
      j = i + 1;
      this.g = j;
      arrayOfByte[i] = (byte)(int)(0xFFL & param1Long >> 24L);
      i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)((int)(param1Long >> 32L) & 0xFF);
      j = i + 1;
      this.g = j;
      arrayOfByte[i] = (byte)((int)(param1Long >> 40L) & 0xFF);
      i = j + 1;
      this.g = i;
      arrayOfByte[j] = (byte)((int)(param1Long >> 48L) & 0xFF);
      this.g = i + 1;
      arrayOfByte[i] = (byte)((int)(param1Long >> 56L) & 0xFF);
      this.h += 8;
    }
    
    final void e1(int param1Int) {
      if (param1Int >= 0) {
        g1(param1Int);
        return;
      } 
      h1(param1Int);
    }
    
    final void f1(int param1Int1, int param1Int2) {
      g1(t1.c(param1Int1, param1Int2));
    }
    
    final void g1(int param1Int) {
      int i = param1Int;
      if (k.b()) {
        long l = this.g;
        while (true) {
          if ((param1Int & 0xFFFFFF80) == 0) {
            byte[] arrayOfByte1 = this.e;
            i = this.g;
            this.g = i + 1;
            r1.H(arrayOfByte1, i, (byte)param1Int);
            param1Int = (int)(this.g - l);
            this.h += param1Int;
            return;
          } 
          byte[] arrayOfByte = this.e;
          i = this.g;
          this.g = i + 1;
          r1.H(arrayOfByte, i, (byte)(param1Int & 0x7F | 0x80));
          param1Int >>>= 7;
        } 
      } 
      while (true) {
        if ((i & 0xFFFFFF80) == 0) {
          byte[] arrayOfByte1 = this.e;
          param1Int = this.g;
          this.g = param1Int + 1;
          arrayOfByte1[param1Int] = (byte)i;
          this.h++;
          return;
        } 
        byte[] arrayOfByte = this.e;
        param1Int = this.g;
        this.g = param1Int + 1;
        arrayOfByte[param1Int] = (byte)(i & 0x7F | 0x80);
        this.h++;
        i >>>= 7;
      } 
    }
    
    final void h1(long param1Long) {
      long l = param1Long;
      if (k.b()) {
        l = this.g;
        while (true) {
          if ((param1Long & 0xFFFFFFFFFFFFFF80L) == 0L) {
            byte[] arrayOfByte1 = this.e;
            int j = this.g;
            this.g = j + 1;
            r1.H(arrayOfByte1, j, (byte)(int)param1Long);
            j = (int)(this.g - l);
            this.h += j;
            return;
          } 
          byte[] arrayOfByte = this.e;
          int i = this.g;
          this.g = i + 1;
          r1.H(arrayOfByte, i, (byte)((int)param1Long & 0x7F | 0x80));
          param1Long >>>= 7L;
        } 
      } 
      while (true) {
        if ((l & 0xFFFFFFFFFFFFFF80L) == 0L) {
          byte[] arrayOfByte1 = this.e;
          int j = this.g;
          this.g = j + 1;
          arrayOfByte1[j] = (byte)(int)l;
          this.h++;
          return;
        } 
        byte[] arrayOfByte = this.e;
        int i = this.g;
        this.g = i + 1;
        arrayOfByte[i] = (byte)((int)l & 0x7F | 0x80);
        this.h++;
        l >>>= 7L;
      } 
    }
    
    public final int i0() {
      throw new UnsupportedOperationException("spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array or ByteBuffer.");
    }
  }
  
  private static class c extends k {
    private final byte[] e;
    
    private final int f;
    
    private final int g;
    
    private int h;
    
    c(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      super(null);
      Objects.requireNonNull(param1ArrayOfbyte, "buffer");
      int i = param1ArrayOfbyte.length;
      int j = param1Int1 + param1Int2;
      if ((param1Int1 | param1Int2 | i - j) >= 0) {
        this.e = param1ArrayOfbyte;
        this.f = param1Int1;
        this.h = param1Int1;
        this.g = j;
        return;
      } 
      throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", new Object[] { Integer.valueOf(param1ArrayOfbyte.length), Integer.valueOf(param1Int1), Integer.valueOf(param1Int2) }));
    }
    
    public final void E0(int param1Int1, int param1Int2) {
      W0(param1Int1, 0);
      F0(param1Int2);
    }
    
    public final void F0(int param1Int) {
      if (param1Int >= 0) {
        Y0(param1Int);
        return;
      } 
      a1(param1Int);
    }
    
    final void I0(int param1Int, r0 param1r0, g1<r0> param1g1) {
      W0(param1Int, 2);
      Y0(((a)param1r0).n(param1g1));
      param1g1.i(param1r0, this.a);
    }
    
    public final void J0(r0 param1r0) {
      Y0(param1r0.b());
      param1r0.j(this);
    }
    
    public final void K0(int param1Int, r0 param1r0) {
      W0(1, 3);
      X0(2, param1Int);
      c1(3, param1r0);
      W0(1, 4);
    }
    
    public final void L0(int param1Int, h param1h) {
      W0(1, 3);
      X0(2, param1Int);
      o0(3, param1h);
      W0(1, 4);
    }
    
    public final void U0(int param1Int, String param1String) {
      W0(param1Int, 2);
      V0(param1String);
    }
    
    public final void V0(String param1String) {
      int i = this.h;
      try {
        int j = k.X(param1String.length() * 3);
        int m = k.X(param1String.length());
        if (m == j) {
          j = i + m;
          this.h = j;
          j = s1.f(param1String, this.e, j, i0());
          this.h = i;
          Y0(j - i - m);
        } else {
          Y0(s1.g(param1String));
          j = s1.f(param1String, this.e, this.h, i0());
        } 
        this.h = j;
        return;
      } catch (d d) {
        this.h = i;
        d0(param1String, d);
        return;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        throw new k.d(indexOutOfBoundsException);
      } 
    }
    
    public final void W0(int param1Int1, int param1Int2) {
      Y0(t1.c(param1Int1, param1Int2));
    }
    
    public final void X0(int param1Int1, int param1Int2) {
      W0(param1Int1, 0);
      Y0(param1Int2);
    }
    
    public final void Y0(int param1Int) {
      int i = param1Int;
      if (k.b()) {
        i = param1Int;
        if (!d.c()) {
          i = param1Int;
          if (i0() >= 5) {
            if ((param1Int & 0xFFFFFF80) == 0) {
              byte[] arrayOfByte1 = this.e;
              i = this.h;
              this.h = i + 1;
              r1.H(arrayOfByte1, i, (byte)param1Int);
              return;
            } 
            byte[] arrayOfByte = this.e;
            i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)(param1Int | 0x80));
            param1Int >>>= 7;
            if ((param1Int & 0xFFFFFF80) == 0) {
              arrayOfByte = this.e;
              i = this.h;
              this.h = i + 1;
              r1.H(arrayOfByte, i, (byte)param1Int);
              return;
            } 
            arrayOfByte = this.e;
            i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)(param1Int | 0x80));
            param1Int >>>= 7;
            if ((param1Int & 0xFFFFFF80) == 0) {
              arrayOfByte = this.e;
              i = this.h;
              this.h = i + 1;
              r1.H(arrayOfByte, i, (byte)param1Int);
              return;
            } 
            arrayOfByte = this.e;
            i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)(param1Int | 0x80));
            param1Int >>>= 7;
            if ((param1Int & 0xFFFFFF80) == 0) {
              arrayOfByte = this.e;
              i = this.h;
              this.h = i + 1;
              r1.H(arrayOfByte, i, (byte)param1Int);
              return;
            } 
            arrayOfByte = this.e;
            i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)(param1Int | 0x80));
            arrayOfByte = this.e;
            i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)(param1Int >>> 7));
            return;
          } 
        } 
      } 
      while (true) {
        if ((i & 0xFFFFFF80) == 0)
          try {
            byte[] arrayOfByte1 = this.e;
            param1Int = this.h;
            this.h = param1Int + 1;
            arrayOfByte1[param1Int] = (byte)i;
            return;
          } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(1) }), indexOutOfBoundsException);
          }  
        byte[] arrayOfByte = this.e;
        param1Int = this.h;
        this.h = param1Int + 1;
        arrayOfByte[param1Int] = (byte)(i & 0x7F | 0x80);
        i >>>= 7;
      } 
    }
    
    public final void Z0(int param1Int, long param1Long) {
      W0(param1Int, 0);
      a1(param1Long);
    }
    
    public final void a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      b1(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public final void a1(long param1Long) {
      long l = param1Long;
      if (k.b()) {
        l = param1Long;
        if (i0() >= 10)
          while (true) {
            if ((param1Long & 0xFFFFFFFFFFFFFF80L) == 0L) {
              byte[] arrayOfByte1 = this.e;
              int j = this.h;
              this.h = j + 1;
              r1.H(arrayOfByte1, j, (byte)(int)param1Long);
              return;
            } 
            byte[] arrayOfByte = this.e;
            int i = this.h;
            this.h = i + 1;
            r1.H(arrayOfByte, i, (byte)((int)param1Long & 0x7F | 0x80));
            param1Long >>>= 7L;
          }  
      } 
      while (true) {
        if ((l & 0xFFFFFFFFFFFFFF80L) == 0L)
          try {
            byte[] arrayOfByte1 = this.e;
            int j = this.h;
            this.h = j + 1;
            arrayOfByte1[j] = (byte)(int)l;
            return;
          } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(1) }), indexOutOfBoundsException);
          }  
        byte[] arrayOfByte = this.e;
        int i = this.h;
        this.h = i + 1;
        arrayOfByte[i] = (byte)((int)l & 0x7F | 0x80);
        l >>>= 7L;
      } 
    }
    
    public final void b1(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      try {
        System.arraycopy(param1ArrayOfbyte, param1Int1, this.e, this.h, param1Int2);
        this.h += param1Int2;
        return;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(param1Int2) }), indexOutOfBoundsException);
      } 
    }
    
    public void c0() {}
    
    public final void c1(int param1Int, r0 param1r0) {
      W0(param1Int, 2);
      J0(param1r0);
    }
    
    public final int i0() {
      return this.g - this.h;
    }
    
    public final void j0(byte param1Byte) {
      try {
        byte[] arrayOfByte = this.e;
        int i = this.h;
        this.h = i + 1;
        arrayOfByte[i] = param1Byte;
        return;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(1) }), indexOutOfBoundsException);
      } 
    }
    
    public final void k0(int param1Int, boolean param1Boolean) {
      W0(param1Int, 0);
      j0((byte)param1Boolean);
    }
    
    public final void n0(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      Y0(param1Int2);
      b1(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public final void o0(int param1Int, h param1h) {
      W0(param1Int, 2);
      p0(param1h);
    }
    
    public final void p0(h param1h) {
      Y0(param1h.size());
      param1h.F(this);
    }
    
    public final void u0(int param1Int1, int param1Int2) {
      W0(param1Int1, 5);
      v0(param1Int2);
    }
    
    public final void v0(int param1Int) {
      try {
        byte[] arrayOfByte = this.e;
        int j = this.h;
        int i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)(param1Int & 0xFF);
        j = i + 1;
        this.h = j;
        arrayOfByte[i] = (byte)(param1Int >> 8 & 0xFF);
        i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)(param1Int >> 16 & 0xFF);
        this.h = i + 1;
        arrayOfByte[i] = (byte)(param1Int >> 24 & 0xFF);
        return;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(1) }), indexOutOfBoundsException);
      } 
    }
    
    public final void w0(int param1Int, long param1Long) {
      W0(param1Int, 1);
      x0(param1Long);
    }
    
    public final void x0(long param1Long) {
      try {
        byte[] arrayOfByte = this.e;
        int j = this.h;
        int i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)((int)param1Long & 0xFF);
        j = i + 1;
        this.h = j;
        arrayOfByte[i] = (byte)((int)(param1Long >> 8L) & 0xFF);
        i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)((int)(param1Long >> 16L) & 0xFF);
        j = i + 1;
        this.h = j;
        arrayOfByte[i] = (byte)((int)(param1Long >> 24L) & 0xFF);
        i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)((int)(param1Long >> 32L) & 0xFF);
        j = i + 1;
        this.h = j;
        arrayOfByte[i] = (byte)((int)(param1Long >> 40L) & 0xFF);
        i = j + 1;
        this.h = i;
        arrayOfByte[j] = (byte)((int)(param1Long >> 48L) & 0xFF);
        this.h = i + 1;
        arrayOfByte[i] = (byte)((int)(param1Long >> 56L) & 0xFF);
        return;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        throw new k.d(String.format("Pos: %d, limit: %d, len: %d", new Object[] { Integer.valueOf(this.h), Integer.valueOf(this.g), Integer.valueOf(1) }), indexOutOfBoundsException);
      } 
    }
  }
  
  public static class d extends IOException {
    d(String param1String, Throwable param1Throwable) {
      super(stringBuilder.toString(), param1Throwable);
    }
    
    d(Throwable param1Throwable) {
      super("CodedOutputStream was writing to a flat byte array and ran out of space.", param1Throwable);
    }
  }
  
  private static final class e extends b {
    private final OutputStream i;
    
    e(OutputStream param1OutputStream, int param1Int) {
      super(param1Int);
      Objects.requireNonNull(param1OutputStream, "out");
      this.i = param1OutputStream;
    }
    
    private void i1() {
      this.i.write(this.e, 0, this.g);
      this.g = 0;
    }
    
    private void j1(int param1Int) {
      if (this.f - this.g < param1Int)
        i1(); 
    }
    
    public void E0(int param1Int1, int param1Int2) {
      j1(20);
      f1(param1Int1, 0);
      e1(param1Int2);
    }
    
    public void F0(int param1Int) {
      if (param1Int >= 0) {
        Y0(param1Int);
        return;
      } 
      a1(param1Int);
    }
    
    void I0(int param1Int, r0 param1r0, g1 param1g1) {
      W0(param1Int, 2);
      m1(param1r0, param1g1);
    }
    
    public void J0(r0 param1r0) {
      Y0(param1r0.b());
      param1r0.j(this);
    }
    
    public void K0(int param1Int, r0 param1r0) {
      W0(1, 3);
      X0(2, param1Int);
      l1(3, param1r0);
      W0(1, 4);
    }
    
    public void L0(int param1Int, h param1h) {
      W0(1, 3);
      X0(2, param1Int);
      o0(3, param1h);
      W0(1, 4);
    }
    
    public void U0(int param1Int, String param1String) {
      W0(param1Int, 2);
      V0(param1String);
    }
    
    public void V0(String param1String) {
      try {
        int j = param1String.length() * 3;
        int i = k.X(j);
        int k = i + j;
        int m = this.f;
        if (k > m) {
          byte[] arrayOfByte = new byte[j];
          i = s1.f(param1String, arrayOfByte, 0, j);
          Y0(i);
          a(arrayOfByte, 0, i);
          return;
        } 
        if (k > m - this.g)
          i1(); 
        k = k.X(param1String.length());
        j = this.g;
        if (k == i) {
          i = j + k;
          try {
            this.g = i;
            m = s1.f(param1String, this.e, i, this.f - i);
            this.g = j;
            i = m - j - k;
            g1(i);
            this.g = m;
            this.h += i;
            return;
          } catch (d d) {
            this.h -= this.g - j;
            this.g = j;
            throw d;
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            throw new k.d(arrayIndexOutOfBoundsException);
          } 
        } 
        i = s1.g(param1String);
        g1(i);
        this.g = s1.f(param1String, this.e, this.g, i);
        this.h += i;
        return;
      } catch (d d) {
        d0(param1String, d);
        return;
      } 
    }
    
    public void W0(int param1Int1, int param1Int2) {
      Y0(t1.c(param1Int1, param1Int2));
    }
    
    public void X0(int param1Int1, int param1Int2) {
      j1(20);
      f1(param1Int1, 0);
      g1(param1Int2);
    }
    
    public void Y0(int param1Int) {
      j1(5);
      g1(param1Int);
    }
    
    public void Z0(int param1Int, long param1Long) {
      j1(20);
      f1(param1Int, 0);
      h1(param1Long);
    }
    
    public void a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      k1(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public void a1(long param1Long) {
      j1(10);
      h1(param1Long);
    }
    
    public void c0() {
      if (this.g > 0)
        i1(); 
    }
    
    public void j0(byte param1Byte) {
      if (this.g == this.f)
        i1(); 
      b1(param1Byte);
    }
    
    public void k0(int param1Int, boolean param1Boolean) {
      j1(11);
      f1(param1Int, 0);
      b1((byte)param1Boolean);
    }
    
    public void k1(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      int i = this.f;
      int j = this.g;
      if (i - j >= param1Int2) {
        System.arraycopy(param1ArrayOfbyte, param1Int1, this.e, j, param1Int2);
        this.g += param1Int2;
      } else {
        i -= j;
        System.arraycopy(param1ArrayOfbyte, param1Int1, this.e, j, i);
        param1Int1 += i;
        param1Int2 -= i;
        this.g = this.f;
        this.h += i;
        i1();
        if (param1Int2 <= this.f) {
          System.arraycopy(param1ArrayOfbyte, param1Int1, this.e, 0, param1Int2);
          this.g = param1Int2;
        } else {
          this.i.write(param1ArrayOfbyte, param1Int1, param1Int2);
        } 
      } 
      this.h += param1Int2;
    }
    
    public void l1(int param1Int, r0 param1r0) {
      W0(param1Int, 2);
      J0(param1r0);
    }
    
    void m1(r0 param1r0, g1<r0> param1g1) {
      Y0(((a)param1r0).n(param1g1));
      param1g1.i(param1r0, this.a);
    }
    
    public void n0(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      Y0(param1Int2);
      k1(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public void o0(int param1Int, h param1h) {
      W0(param1Int, 2);
      p0(param1h);
    }
    
    public void p0(h param1h) {
      Y0(param1h.size());
      param1h.F(this);
    }
    
    public void u0(int param1Int1, int param1Int2) {
      j1(14);
      f1(param1Int1, 5);
      c1(param1Int2);
    }
    
    public void v0(int param1Int) {
      j1(4);
      c1(param1Int);
    }
    
    public void w0(int param1Int, long param1Long) {
      j1(18);
      f1(param1Int, 1);
      d1(param1Long);
    }
    
    public void x0(long param1Long) {
      j1(8);
      d1(param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */