package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.Map;

interface f1 {
  void A(List<h> paramList);
  
  void B(List<Double> paramList);
  
  void C(List<Long> paramList);
  
  void D(List<Long> paramList);
  
  long E();
  
  String F();
  
  void G(List<Long> paramList);
  
  void H(List<Integer> paramList);
  
  void I(List<Integer> paramList);
  
  <T> T J(g1<T> paramg1, p paramp);
  
  <K, V> void K(Map<K, V> paramMap, k0.a<K, V> parama, p paramp);
  
  <T> T L(Class<T> paramClass, p paramp);
  
  @Deprecated
  <T> T M(Class<T> paramClass, p paramp);
  
  @Deprecated
  <T> void N(List<T> paramList, g1<T> paramg1, p paramp);
  
  <T> void O(List<T> paramList, g1<T> paramg1, p paramp);
  
  @Deprecated
  <T> T P(g1<T> paramg1, p paramp);
  
  void a(List<Integer> paramList);
  
  int b();
  
  int c();
  
  long d();
  
  void e(List<Integer> paramList);
  
  long f();
  
  void g(List<Integer> paramList);
  
  int h();
  
  void i(List<Long> paramList);
  
  long j();
  
  void k(List<Integer> paramList);
  
  void l(List<Boolean> paramList);
  
  String m();
  
  int n();
  
  boolean o();
  
  int p();
  
  void q(List<String> paramList);
  
  long r();
  
  double readDouble();
  
  float readFloat();
  
  void s(List<Long> paramList);
  
  void t(List<String> paramList);
  
  h u();
  
  void v(List<Float> paramList);
  
  int w();
  
  int x();
  
  boolean y();
  
  int z();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */