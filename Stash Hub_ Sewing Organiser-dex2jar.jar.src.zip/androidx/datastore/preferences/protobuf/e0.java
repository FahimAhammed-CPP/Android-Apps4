package androidx.datastore.preferences.protobuf;

public class e0 {
  private static final p e = p.b();
  
  private h a;
  
  private p b;
  
  protected volatile r0 c;
  
  private volatile h d;
  
  protected void a(r0 paramr0) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   4: ifnull -> 8
    //   7: return
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   14: ifnull -> 20
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_0
    //   21: getfield a : Landroidx/datastore/preferences/protobuf/h;
    //   24: ifnull -> 66
    //   27: aload_0
    //   28: aload_1
    //   29: invokeinterface h : ()Landroidx/datastore/preferences/protobuf/z0;
    //   34: aload_0
    //   35: getfield a : Landroidx/datastore/preferences/protobuf/h;
    //   38: aload_0
    //   39: getfield b : Landroidx/datastore/preferences/protobuf/p;
    //   42: invokeinterface a : (Landroidx/datastore/preferences/protobuf/h;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   47: checkcast androidx/datastore/preferences/protobuf/r0
    //   50: putfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   53: aload_0
    //   54: getfield a : Landroidx/datastore/preferences/protobuf/h;
    //   57: astore_2
    //   58: aload_0
    //   59: aload_2
    //   60: putfield d : Landroidx/datastore/preferences/protobuf/h;
    //   63: goto -> 90
    //   66: aload_0
    //   67: aload_1
    //   68: putfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   71: getstatic androidx/datastore/preferences/protobuf/h.b : Landroidx/datastore/preferences/protobuf/h;
    //   74: astore_2
    //   75: goto -> 58
    //   78: aload_0
    //   79: aload_1
    //   80: putfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   83: aload_0
    //   84: getstatic androidx/datastore/preferences/protobuf/h.b : Landroidx/datastore/preferences/protobuf/h;
    //   87: putfield d : Landroidx/datastore/preferences/protobuf/h;
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: astore_1
    //   94: aload_0
    //   95: monitorexit
    //   96: aload_1
    //   97: athrow
    //   98: astore_2
    //   99: goto -> 78
    // Exception table:
    //   from	to	target	type
    //   10	19	93	finally
    //   20	58	98	androidx/datastore/preferences/protobuf/b0
    //   20	58	93	finally
    //   58	63	98	androidx/datastore/preferences/protobuf/b0
    //   58	63	93	finally
    //   66	75	98	androidx/datastore/preferences/protobuf/b0
    //   66	75	93	finally
    //   78	90	93	finally
    //   90	92	93	finally
    //   94	96	93	finally
  }
  
  public int b() {
    if (this.d != null)
      return this.d.size(); 
    h h1 = this.a;
    return (h1 != null) ? h1.size() : ((this.c != null) ? this.c.b() : 0);
  }
  
  public r0 c(r0 paramr0) {
    a(paramr0);
    return this.c;
  }
  
  public r0 d(r0 paramr0) {
    r0 r01 = this.c;
    this.a = null;
    this.d = null;
    this.c = paramr0;
    return r01;
  }
  
  public h e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Landroidx/datastore/preferences/protobuf/h;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield d : Landroidx/datastore/preferences/protobuf/h;
    //   11: areturn
    //   12: aload_0
    //   13: getfield a : Landroidx/datastore/preferences/protobuf/h;
    //   16: astore_1
    //   17: aload_1
    //   18: ifnull -> 23
    //   21: aload_1
    //   22: areturn
    //   23: aload_0
    //   24: monitorenter
    //   25: aload_0
    //   26: getfield d : Landroidx/datastore/preferences/protobuf/h;
    //   29: ifnull -> 41
    //   32: aload_0
    //   33: getfield d : Landroidx/datastore/preferences/protobuf/h;
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: areturn
    //   41: aload_0
    //   42: getfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   45: ifnonnull -> 60
    //   48: getstatic androidx/datastore/preferences/protobuf/h.b : Landroidx/datastore/preferences/protobuf/h;
    //   51: astore_1
    //   52: aload_0
    //   53: aload_1
    //   54: putfield d : Landroidx/datastore/preferences/protobuf/h;
    //   57: goto -> 73
    //   60: aload_0
    //   61: getfield c : Landroidx/datastore/preferences/protobuf/r0;
    //   64: invokeinterface f : ()Landroidx/datastore/preferences/protobuf/h;
    //   69: astore_1
    //   70: goto -> 52
    //   73: aload_0
    //   74: getfield d : Landroidx/datastore/preferences/protobuf/h;
    //   77: astore_1
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_1
    //   81: areturn
    //   82: astore_1
    //   83: aload_0
    //   84: monitorexit
    //   85: aload_1
    //   86: athrow
    // Exception table:
    //   from	to	target	type
    //   25	39	82	finally
    //   41	52	82	finally
    //   52	57	82	finally
    //   60	70	82	finally
    //   73	80	82	finally
    //   83	85	82	finally
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof e0))
      return false; 
    paramObject = paramObject;
    r0 r01 = this.c;
    r0 r02 = ((e0)paramObject).c;
    return (r01 == null && r02 == null) ? e().equals(paramObject.e()) : ((r01 != null && r02 != null) ? r01.equals(r02) : ((r01 != null) ? r01.equals(paramObject.c(r01.c())) : c(r02.c()).equals(r02)));
  }
  
  public int hashCode() {
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */