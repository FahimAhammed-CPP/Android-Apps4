package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class f extends c<Boolean> implements a0.a, RandomAccess, a1 {
  private static final f d;
  
  private boolean[] b;
  
  private int c;
  
  static {
    f f1 = new f(new boolean[0], 0);
    d = f1;
    f1.d();
  }
  
  f() {
    this(new boolean[10], 0);
  }
  
  private f(boolean[] paramArrayOfboolean, int paramInt) {
    this.b = paramArrayOfboolean;
    this.c = paramInt;
  }
  
  private void k(int paramInt, boolean paramBoolean) {
    a();
    if (paramInt >= 0) {
      int i = this.c;
      if (paramInt <= i) {
        boolean[] arrayOfBoolean = this.b;
        if (i < arrayOfBoolean.length) {
          System.arraycopy(arrayOfBoolean, paramInt, arrayOfBoolean, paramInt + 1, i - paramInt);
        } else {
          boolean[] arrayOfBoolean1 = new boolean[i * 3 / 2 + 1];
          System.arraycopy(arrayOfBoolean, 0, arrayOfBoolean1, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfBoolean1, paramInt + 1, this.c - paramInt);
          this.b = arrayOfBoolean1;
        } 
        this.b[paramInt] = paramBoolean;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private void n(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private String q(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean addAll(Collection<? extends Boolean> paramCollection) {
    a();
    a0.a(paramCollection);
    if (!(paramCollection instanceof f))
      return super.addAll(paramCollection); 
    paramCollection = paramCollection;
    int i = ((f)paramCollection).c;
    if (i == 0)
      return false; 
    int j = this.c;
    if (Integer.MAX_VALUE - j >= i) {
      i = j + i;
      boolean[] arrayOfBoolean = this.b;
      if (i > arrayOfBoolean.length)
        this.b = Arrays.copyOf(arrayOfBoolean, i); 
      System.arraycopy(((f)paramCollection).b, 0, this.b, this.c, ((f)paramCollection).c);
      this.c = i;
      this.modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public void c(int paramInt, Boolean paramBoolean) {
    k(paramInt, paramBoolean.booleanValue());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof f))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((f)paramObject).c)
      return false; 
    paramObject = ((f)paramObject).b;
    for (int i = 0; i < this.c; i++) {
      if (this.b[i] != paramObject[i])
        return false; 
    } 
    return true;
  }
  
  public boolean g(Boolean paramBoolean) {
    m(paramBoolean.booleanValue());
    return true;
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.c; i++)
      j = j * 31 + a0.c(this.b[i]); 
    return j;
  }
  
  public void m(boolean paramBoolean) {
    a();
    int i = this.c;
    boolean[] arrayOfBoolean = this.b;
    if (i == arrayOfBoolean.length) {
      boolean[] arrayOfBoolean1 = new boolean[i * 3 / 2 + 1];
      System.arraycopy(arrayOfBoolean, 0, arrayOfBoolean1, 0, i);
      this.b = arrayOfBoolean1;
    } 
    arrayOfBoolean = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfBoolean[i] = paramBoolean;
  }
  
  public Boolean o(int paramInt) {
    return Boolean.valueOf(p(paramInt));
  }
  
  public boolean p(int paramInt) {
    n(paramInt);
    return this.b[paramInt];
  }
  
  public a0.a r(int paramInt) {
    if (paramInt >= this.c)
      return new f(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public boolean remove(Object paramObject) {
    a();
    for (int i = 0; i < this.c; i++) {
      if (paramObject.equals(Boolean.valueOf(this.b[i]))) {
        paramObject = this.b;
        System.arraycopy(paramObject, i + 1, paramObject, i, this.c - i - 1);
        this.c--;
        this.modCount++;
        return true;
      } 
    } 
    return false;
  }
  
  protected void removeRange(int paramInt1, int paramInt2) {
    a();
    if (paramInt2 >= paramInt1) {
      boolean[] arrayOfBoolean = this.b;
      System.arraycopy(arrayOfBoolean, paramInt2, arrayOfBoolean, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      this.modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Boolean s(int paramInt) {
    a();
    n(paramInt);
    boolean[] arrayOfBoolean = this.b;
    boolean bool = arrayOfBoolean[paramInt];
    int i = this.c;
    if (paramInt < i - 1)
      System.arraycopy(arrayOfBoolean, paramInt + 1, arrayOfBoolean, paramInt, i - paramInt - 1); 
    this.c--;
    this.modCount++;
    return Boolean.valueOf(bool);
  }
  
  public int size() {
    return this.c;
  }
  
  public Boolean t(int paramInt, Boolean paramBoolean) {
    return Boolean.valueOf(u(paramInt, paramBoolean.booleanValue()));
  }
  
  public boolean u(int paramInt, boolean paramBoolean) {
    a();
    n(paramInt);
    boolean[] arrayOfBoolean = this.b;
    boolean bool = arrayOfBoolean[paramInt];
    arrayOfBoolean[paramInt] = paramBoolean;
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */