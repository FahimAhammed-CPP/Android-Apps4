package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.ByteOrder;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.misc.Unsafe;

final class r1 {
  private static final Logger a = Logger.getLogger(r1.class.getName());
  
  private static final Unsafe b = B();
  
  private static final Class<?> c = d.b();
  
  private static final boolean d = m(long.class);
  
  private static final boolean e = m(int.class);
  
  private static final e f = z();
  
  private static final boolean g = Q();
  
  private static final boolean h = P();
  
  static final long i;
  
  private static final long j = j(boolean[].class);
  
  private static final long k = k(boolean[].class);
  
  private static final long l = j(int[].class);
  
  private static final long m = k(int[].class);
  
  private static final long n = j(long[].class);
  
  private static final long o = k(long[].class);
  
  private static final long p = j(float[].class);
  
  private static final long q = k(float[].class);
  
  private static final long r = j(double[].class);
  
  private static final long s = k(double[].class);
  
  private static final long t = j(Object[].class);
  
  private static final long u = k(Object[].class);
  
  private static final long v = o(l());
  
  private static final int w;
  
  static final boolean x;
  
  static {
    w = (int)(0x7L & l);
    if (ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN) {
      bool = true;
    } else {
      bool = false;
    } 
    x = bool;
  }
  
  static Object A(Object paramObject, long paramLong) {
    return f.i(paramObject, paramLong);
  }
  
  static Unsafe B() {
    try {
      return AccessController.<Unsafe>doPrivileged(new a());
    } finally {
      Exception exception = null;
    } 
  }
  
  static boolean C() {
    return h;
  }
  
  static boolean D() {
    return g;
  }
  
  static void E(Object paramObject, long paramLong, boolean paramBoolean) {
    f.k(paramObject, paramLong, paramBoolean);
  }
  
  private static void F(Object paramObject, long paramLong, boolean paramBoolean) {
    I(paramObject, paramLong, (byte)paramBoolean);
  }
  
  private static void G(Object paramObject, long paramLong, boolean paramBoolean) {
    J(paramObject, paramLong, (byte)paramBoolean);
  }
  
  static void H(byte[] paramArrayOfbyte, long paramLong, byte paramByte) {
    f.l(paramArrayOfbyte, i + paramLong, paramByte);
  }
  
  private static void I(Object paramObject, long paramLong, byte paramByte) {
    long l = 0xFFFFFFFFFFFFFFFCL & paramLong;
    int i = x(paramObject, l);
    int j = ((int)paramLong & 0x3) << 3;
    M(paramObject, l, (0xFF & paramByte) << j | i & 255 << j);
  }
  
  private static void J(Object paramObject, long paramLong, byte paramByte) {
    long l = 0xFFFFFFFFFFFFFFFCL & paramLong;
    int i = x(paramObject, l);
    int j = ((int)paramLong & 0x3) << 3;
    M(paramObject, l, (0xFF & paramByte) << j | i & 255 << j);
  }
  
  static void K(Object paramObject, long paramLong, double paramDouble) {
    f.m(paramObject, paramLong, paramDouble);
  }
  
  static void L(Object paramObject, long paramLong, float paramFloat) {
    f.n(paramObject, paramLong, paramFloat);
  }
  
  static void M(Object paramObject, long paramLong, int paramInt) {
    f.o(paramObject, paramLong, paramInt);
  }
  
  static void N(Object paramObject, long paramLong1, long paramLong2) {
    f.p(paramObject, paramLong1, paramLong2);
  }
  
  static void O(Object paramObject1, long paramLong, Object paramObject2) {
    f.q(paramObject1, paramLong, paramObject2);
  }
  
  private static boolean P() {
    Unsafe unsafe = b;
    if (unsafe == null)
      return false; 
    try {
      Class<?> clazz = unsafe.getClass();
      clazz.getMethod("objectFieldOffset", new Class[] { Field.class });
      clazz.getMethod("arrayBaseOffset", new Class[] { Class.class });
      clazz.getMethod("arrayIndexScale", new Class[] { Class.class });
      Class<long> clazz1 = long.class;
      clazz.getMethod("getInt", new Class[] { Object.class, clazz1 });
      clazz.getMethod("putInt", new Class[] { Object.class, clazz1, int.class });
      clazz.getMethod("getLong", new Class[] { Object.class, clazz1 });
      clazz.getMethod("putLong", new Class[] { Object.class, clazz1, clazz1 });
      clazz.getMethod("getObject", new Class[] { Object.class, clazz1 });
      clazz.getMethod("putObject", new Class[] { Object.class, clazz1, Object.class });
      if (d.c())
        return true; 
      clazz.getMethod("getByte", new Class[] { Object.class, clazz1 });
      return true;
    } finally {
      unsafe = null;
      Logger logger = a;
      Level level = Level.WARNING;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("platform method missing - proto runtime falling back to safer methods: ");
      stringBuilder.append(unsafe);
      logger.log(level, stringBuilder.toString());
    } 
  }
  
  private static boolean Q() {
    Unsafe unsafe = b;
    if (unsafe == null)
      return false; 
    try {
      Class<?> clazz = unsafe.getClass();
      clazz.getMethod("objectFieldOffset", new Class[] { Field.class });
      Class<long> clazz1 = long.class;
      clazz.getMethod("getLong", new Class[] { Object.class, clazz1 });
      if (l() == null)
        return false; 
      if (d.c())
        return true; 
      clazz.getMethod("getByte", new Class[] { clazz1 });
      return true;
    } finally {
      unsafe = null;
      Logger logger = a;
      Level level = Level.WARNING;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("platform method missing - proto runtime falling back to safer methods: ");
      stringBuilder.append(unsafe);
      logger.log(level, stringBuilder.toString());
    } 
  }
  
  static <T> T i(Class<T> paramClass) {
    try {
      return (T)b.allocateInstance(paramClass);
    } catch (InstantiationException instantiationException) {
      throw new IllegalStateException(instantiationException);
    } 
  }
  
  private static int j(Class<?> paramClass) {
    return h ? f.a(paramClass) : -1;
  }
  
  private static int k(Class<?> paramClass) {
    return h ? f.b(paramClass) : -1;
  }
  
  private static Field l() {
    if (d.c()) {
      Field field1 = n(Buffer.class, "effectiveDirectAddress");
      if (field1 != null)
        return field1; 
    } 
    Field field = n(Buffer.class, "address");
    return (field != null && field.getType() == long.class) ? field : null;
  }
  
  private static boolean m(Class<?> paramClass) {
    if (!d.c())
      return false; 
    try {
      Class<?> clazz = c;
      Class<boolean> clazz1 = boolean.class;
      clazz.getMethod("peekLong", new Class[] { paramClass, clazz1 });
      clazz.getMethod("pokeLong", new Class[] { paramClass, long.class, clazz1 });
      Class<int> clazz2 = int.class;
      clazz.getMethod("pokeInt", new Class[] { paramClass, clazz2, clazz1 });
      clazz.getMethod("peekInt", new Class[] { paramClass, clazz1 });
      clazz.getMethod("pokeByte", new Class[] { paramClass, byte.class });
      clazz.getMethod("peekByte", new Class[] { paramClass });
      clazz.getMethod("pokeByteArray", new Class[] { paramClass, byte[].class, clazz2, clazz2 });
      return true;
    } finally {
      paramClass = null;
    } 
  }
  
  private static Field n(Class<?> paramClass, String paramString) {
    try {
      return paramClass.getDeclaredField(paramString);
    } finally {
      paramClass = null;
    } 
  }
  
  private static long o(Field paramField) {
    if (paramField != null) {
      e e1 = f;
      if (e1 != null)
        return e1.j(paramField); 
    } 
    return -1L;
  }
  
  static boolean p(Object paramObject, long paramLong) {
    return f.c(paramObject, paramLong);
  }
  
  private static boolean q(Object paramObject, long paramLong) {
    return (t(paramObject, paramLong) != 0);
  }
  
  private static boolean r(Object paramObject, long paramLong) {
    return (u(paramObject, paramLong) != 0);
  }
  
  static byte s(byte[] paramArrayOfbyte, long paramLong) {
    return f.d(paramArrayOfbyte, i + paramLong);
  }
  
  private static byte t(Object paramObject, long paramLong) {
    return (byte)(x(paramObject, 0xFFFFFFFFFFFFFFFCL & paramLong) >>> (int)((paramLong & 0x3L) << 3L) & 0xFF);
  }
  
  private static byte u(Object paramObject, long paramLong) {
    return (byte)(x(paramObject, 0xFFFFFFFFFFFFFFFCL & paramLong) >>> (int)((paramLong & 0x3L) << 3L) & 0xFF);
  }
  
  static double v(Object paramObject, long paramLong) {
    return f.e(paramObject, paramLong);
  }
  
  static float w(Object paramObject, long paramLong) {
    return f.f(paramObject, paramLong);
  }
  
  static int x(Object paramObject, long paramLong) {
    return f.g(paramObject, paramLong);
  }
  
  static long y(Object paramObject, long paramLong) {
    return f.h(paramObject, paramLong);
  }
  
  private static e z() {
    Unsafe unsafe = b;
    b b = null;
    if (unsafe == null)
      return null; 
    if (d.c()) {
      if (d)
        return new c(unsafe); 
      if (e)
        b = new b(unsafe); 
      return b;
    } 
    return new d(unsafe);
  }
  
  static {
    boolean bool;
  }
  
  static {
    long l = j(byte[].class);
    i = l;
  }
  
  static final class a implements PrivilegedExceptionAction<Unsafe> {
    public Unsafe a() {
      for (Field field : Unsafe.class.getDeclaredFields()) {
        field.setAccessible(true);
        Object object = field.get(null);
        if (Unsafe.class.isInstance(object))
          return Unsafe.class.cast(object); 
      } 
      return null;
    }
  }
  
  private static final class b extends e {
    b(Unsafe param1Unsafe) {
      super(param1Unsafe);
    }
    
    public boolean c(Object param1Object, long param1Long) {
      return r1.x ? r1.e(param1Object, param1Long) : r1.f(param1Object, param1Long);
    }
    
    public byte d(Object param1Object, long param1Long) {
      return r1.x ? r1.a(param1Object, param1Long) : r1.b(param1Object, param1Long);
    }
    
    public double e(Object param1Object, long param1Long) {
      return Double.longBitsToDouble(h(param1Object, param1Long));
    }
    
    public float f(Object param1Object, long param1Long) {
      return Float.intBitsToFloat(g(param1Object, param1Long));
    }
    
    public void k(Object param1Object, long param1Long, boolean param1Boolean) {
      if (r1.x) {
        r1.g(param1Object, param1Long, param1Boolean);
        return;
      } 
      r1.h(param1Object, param1Long, param1Boolean);
    }
    
    public void l(Object param1Object, long param1Long, byte param1Byte) {
      if (r1.x) {
        r1.c(param1Object, param1Long, param1Byte);
        return;
      } 
      r1.d(param1Object, param1Long, param1Byte);
    }
    
    public void m(Object param1Object, long param1Long, double param1Double) {
      p(param1Object, param1Long, Double.doubleToLongBits(param1Double));
    }
    
    public void n(Object param1Object, long param1Long, float param1Float) {
      o(param1Object, param1Long, Float.floatToIntBits(param1Float));
    }
  }
  
  private static final class c extends e {
    c(Unsafe param1Unsafe) {
      super(param1Unsafe);
    }
    
    public boolean c(Object param1Object, long param1Long) {
      return r1.x ? r1.e(param1Object, param1Long) : r1.f(param1Object, param1Long);
    }
    
    public byte d(Object param1Object, long param1Long) {
      return r1.x ? r1.a(param1Object, param1Long) : r1.b(param1Object, param1Long);
    }
    
    public double e(Object param1Object, long param1Long) {
      return Double.longBitsToDouble(h(param1Object, param1Long));
    }
    
    public float f(Object param1Object, long param1Long) {
      return Float.intBitsToFloat(g(param1Object, param1Long));
    }
    
    public void k(Object param1Object, long param1Long, boolean param1Boolean) {
      if (r1.x) {
        r1.g(param1Object, param1Long, param1Boolean);
        return;
      } 
      r1.h(param1Object, param1Long, param1Boolean);
    }
    
    public void l(Object param1Object, long param1Long, byte param1Byte) {
      if (r1.x) {
        r1.c(param1Object, param1Long, param1Byte);
        return;
      } 
      r1.d(param1Object, param1Long, param1Byte);
    }
    
    public void m(Object param1Object, long param1Long, double param1Double) {
      p(param1Object, param1Long, Double.doubleToLongBits(param1Double));
    }
    
    public void n(Object param1Object, long param1Long, float param1Float) {
      o(param1Object, param1Long, Float.floatToIntBits(param1Float));
    }
  }
  
  private static final class d extends e {
    d(Unsafe param1Unsafe) {
      super(param1Unsafe);
    }
    
    public boolean c(Object param1Object, long param1Long) {
      return this.a.getBoolean(param1Object, param1Long);
    }
    
    public byte d(Object param1Object, long param1Long) {
      return this.a.getByte(param1Object, param1Long);
    }
    
    public double e(Object param1Object, long param1Long) {
      return this.a.getDouble(param1Object, param1Long);
    }
    
    public float f(Object param1Object, long param1Long) {
      return this.a.getFloat(param1Object, param1Long);
    }
    
    public void k(Object param1Object, long param1Long, boolean param1Boolean) {
      this.a.putBoolean(param1Object, param1Long, param1Boolean);
    }
    
    public void l(Object param1Object, long param1Long, byte param1Byte) {
      this.a.putByte(param1Object, param1Long, param1Byte);
    }
    
    public void m(Object param1Object, long param1Long, double param1Double) {
      this.a.putDouble(param1Object, param1Long, param1Double);
    }
    
    public void n(Object param1Object, long param1Long, float param1Float) {
      this.a.putFloat(param1Object, param1Long, param1Float);
    }
  }
  
  private static abstract class e {
    Unsafe a;
    
    e(Unsafe param1Unsafe) {
      this.a = param1Unsafe;
    }
    
    public final int a(Class<?> param1Class) {
      return this.a.arrayBaseOffset(param1Class);
    }
    
    public final int b(Class<?> param1Class) {
      return this.a.arrayIndexScale(param1Class);
    }
    
    public abstract boolean c(Object param1Object, long param1Long);
    
    public abstract byte d(Object param1Object, long param1Long);
    
    public abstract double e(Object param1Object, long param1Long);
    
    public abstract float f(Object param1Object, long param1Long);
    
    public final int g(Object param1Object, long param1Long) {
      return this.a.getInt(param1Object, param1Long);
    }
    
    public final long h(Object param1Object, long param1Long) {
      return this.a.getLong(param1Object, param1Long);
    }
    
    public final Object i(Object param1Object, long param1Long) {
      return this.a.getObject(param1Object, param1Long);
    }
    
    public final long j(Field param1Field) {
      return this.a.objectFieldOffset(param1Field);
    }
    
    public abstract void k(Object param1Object, long param1Long, boolean param1Boolean);
    
    public abstract void l(Object param1Object, long param1Long, byte param1Byte);
    
    public abstract void m(Object param1Object, long param1Long, double param1Double);
    
    public abstract void n(Object param1Object, long param1Long, float param1Float);
    
    public final void o(Object param1Object, long param1Long, int param1Int) {
      this.a.putInt(param1Object, param1Long, param1Int);
    }
    
    public final void p(Object param1Object, long param1Long1, long param1Long2) {
      this.a.putLong(param1Object, param1Long1, param1Long2);
    }
    
    public final void q(Object param1Object1, long param1Long, Object param1Object2) {
      this.a.putObject(param1Object1, param1Long, param1Object2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\r1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */