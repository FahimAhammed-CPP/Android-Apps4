package androidx.datastore.preferences.protobuf;

final class o0 {
  private static final m0 a = c();
  
  private static final m0 b = new n0();
  
  static m0 a() {
    return a;
  }
  
  static m0 b() {
    return b;
  }
  
  private static m0 c() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */