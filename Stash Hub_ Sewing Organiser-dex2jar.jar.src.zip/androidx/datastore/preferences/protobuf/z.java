package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class z extends c<Integer> implements a0.g, RandomAccess, a1 {
  private static final z d;
  
  private int[] b;
  
  private int c;
  
  static {
    z z1 = new z(new int[0], 0);
    d = z1;
    z1.d();
  }
  
  z() {
    this(new int[10], 0);
  }
  
  private z(int[] paramArrayOfint, int paramInt) {
    this.b = paramArrayOfint;
    this.c = paramInt;
  }
  
  private void m(int paramInt1, int paramInt2) {
    a();
    if (paramInt1 >= 0) {
      int i = this.c;
      if (paramInt1 <= i) {
        int[] arrayOfInt = this.b;
        if (i < arrayOfInt.length) {
          System.arraycopy(arrayOfInt, paramInt1, arrayOfInt, paramInt1 + 1, i - paramInt1);
        } else {
          int[] arrayOfInt1 = new int[i * 3 / 2 + 1];
          System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, paramInt1);
          System.arraycopy(this.b, paramInt1, arrayOfInt1, paramInt1 + 1, this.c - paramInt1);
          this.b = arrayOfInt1;
        } 
        this.b[paramInt1] = paramInt2;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(q(paramInt1));
  }
  
  private void n(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private String q(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean addAll(Collection<? extends Integer> paramCollection) {
    a();
    a0.a(paramCollection);
    if (!(paramCollection instanceof z))
      return super.addAll(paramCollection); 
    paramCollection = paramCollection;
    int i = ((z)paramCollection).c;
    if (i == 0)
      return false; 
    int j = this.c;
    if (Integer.MAX_VALUE - j >= i) {
      i = j + i;
      int[] arrayOfInt = this.b;
      if (i > arrayOfInt.length)
        this.b = Arrays.copyOf(arrayOfInt, i); 
      System.arraycopy(((z)paramCollection).b, 0, this.b, this.c, ((z)paramCollection).c);
      this.c = i;
      this.modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public void c(int paramInt, Integer paramInteger) {
    m(paramInt, paramInteger.intValue());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof z))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((z)paramObject).c)
      return false; 
    paramObject = ((z)paramObject).b;
    for (int i = 0; i < this.c; i++) {
      if (this.b[i] != paramObject[i])
        return false; 
    } 
    return true;
  }
  
  public boolean g(Integer paramInteger) {
    k(paramInteger.intValue());
    return true;
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.c; i++)
      j = j * 31 + this.b[i]; 
    return j;
  }
  
  public void k(int paramInt) {
    a();
    int i = this.c;
    int[] arrayOfInt = this.b;
    if (i == arrayOfInt.length) {
      int[] arrayOfInt1 = new int[i * 3 / 2 + 1];
      System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, i);
      this.b = arrayOfInt1;
    } 
    arrayOfInt = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfInt[i] = paramInt;
  }
  
  public Integer o(int paramInt) {
    return Integer.valueOf(p(paramInt));
  }
  
  public int p(int paramInt) {
    n(paramInt);
    return this.b[paramInt];
  }
  
  public a0.g r(int paramInt) {
    if (paramInt >= this.c)
      return new z(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public boolean remove(Object paramObject) {
    a();
    for (int i = 0; i < this.c; i++) {
      if (paramObject.equals(Integer.valueOf(this.b[i]))) {
        paramObject = this.b;
        System.arraycopy(paramObject, i + 1, paramObject, i, this.c - i - 1);
        this.c--;
        this.modCount++;
        return true;
      } 
    } 
    return false;
  }
  
  protected void removeRange(int paramInt1, int paramInt2) {
    a();
    if (paramInt2 >= paramInt1) {
      int[] arrayOfInt = this.b;
      System.arraycopy(arrayOfInt, paramInt2, arrayOfInt, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      this.modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Integer s(int paramInt) {
    a();
    n(paramInt);
    int[] arrayOfInt = this.b;
    int i = arrayOfInt[paramInt];
    int j = this.c;
    if (paramInt < j - 1)
      System.arraycopy(arrayOfInt, paramInt + 1, arrayOfInt, paramInt, j - paramInt - 1); 
    this.c--;
    this.modCount++;
    return Integer.valueOf(i);
  }
  
  public int size() {
    return this.c;
  }
  
  public Integer t(int paramInt, Integer paramInteger) {
    return Integer.valueOf(u(paramInt, paramInteger.intValue()));
  }
  
  public int u(int paramInt1, int paramInt2) {
    a();
    n(paramInt1);
    int[] arrayOfInt = this.b;
    int i = arrayOfInt[paramInt1];
    arrayOfInt[paramInt1] = paramInt2;
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */