package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class l0<K, V> extends LinkedHashMap<K, V> {
  private static final l0 b;
  
  private boolean a = true;
  
  static {
    l0 l01 = new l0();
    b = l01;
    l01.l();
  }
  
  private l0() {}
  
  private l0(Map<K, V> paramMap) {
    super(paramMap);
  }
  
  static <K, V> int b(Map<K, V> paramMap) {
    Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += c(entry.getValue()) ^ j) {
      Map.Entry entry = iterator.next();
      int j = c(entry.getKey());
    } 
    return i;
  }
  
  private static int c(Object paramObject) {
    if (paramObject instanceof byte[])
      return a0.d((byte[])paramObject); 
    if (!(paramObject instanceof a0.c))
      return paramObject.hashCode(); 
    throw new UnsupportedOperationException();
  }
  
  private static void d(Map<?, ?> paramMap) {
    for (Object object : paramMap.keySet()) {
      a0.a(object);
      a0.a(paramMap.get(object));
    } 
  }
  
  public static <K, V> l0<K, V> e() {
    return b;
  }
  
  private void f() {
    if (j())
      return; 
    throw new UnsupportedOperationException();
  }
  
  private static boolean h(Object paramObject1, Object paramObject2) {
    return (paramObject1 instanceof byte[] && paramObject2 instanceof byte[]) ? Arrays.equals((byte[])paramObject1, (byte[])paramObject2) : paramObject1.equals(paramObject2);
  }
  
  static <K, V> boolean i(Map<K, V> paramMap1, Map<K, V> paramMap2) {
    if (paramMap1 == paramMap2)
      return true; 
    if (paramMap1.size() != paramMap2.size())
      return false; 
    for (Map.Entry<K, V> entry : paramMap1.entrySet()) {
      if (!paramMap2.containsKey(entry.getKey()))
        return false; 
      if (!h(entry.getValue(), paramMap2.get(entry.getKey())))
        return false; 
    } 
    return true;
  }
  
  public void clear() {
    f();
    super.clear();
  }
  
  public Set<Map.Entry<K, V>> entrySet() {
    return isEmpty() ? Collections.emptySet() : super.entrySet();
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof Map && i(this, (Map<?, ?>)paramObject));
  }
  
  public int hashCode() {
    return b(this);
  }
  
  public boolean j() {
    return this.a;
  }
  
  public void l() {
    this.a = false;
  }
  
  public void m(l0<K, V> paraml0) {
    f();
    if (!paraml0.isEmpty())
      putAll(paraml0); 
  }
  
  public l0<K, V> n() {
    return isEmpty() ? new l0() : new l0(this);
  }
  
  public V put(K paramK, V paramV) {
    f();
    a0.a(paramK);
    a0.a(paramV);
    return super.put(paramK, paramV);
  }
  
  public void putAll(Map<? extends K, ? extends V> paramMap) {
    f();
    d(paramMap);
    super.putAll(paramMap);
  }
  
  public V remove(Object paramObject) {
    f();
    return super.remove(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */