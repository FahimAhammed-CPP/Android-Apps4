package androidx.datastore.preferences.protobuf;

final class x0 implements w0 {
  public Object a(Object paramObject) {
    return ((y)paramObject).v(y.f.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */