package androidx.datastore.preferences.protobuf;

public final class t1 {
  static final int a = c(1, 3);
  
  static final int b = c(1, 4);
  
  static final int c = c(2, 0);
  
  static final int d = c(3, 2);
  
  public static int a(int paramInt) {
    return paramInt >>> 3;
  }
  
  public static int b(int paramInt) {
    return paramInt & 0x7;
  }
  
  static int c(int paramInt1, int paramInt2) {
    return paramInt1 << 3 | paramInt2;
  }
  
  public enum b {
    c, d, e, f, g, l, m, n, o, p, q, r, s, t, u, v, w, x;
    
    private final t1.c a;
    
    private final int b;
    
    static {
      b b1 = new b("DOUBLE", 0, t1.c.e, 1);
      c = b1;
      b b2 = new b("FLOAT", 1, t1.c.d, 5);
      d = b2;
      t1.c c1 = t1.c.c;
      b b3 = new b("INT64", 2, c1, 0);
      e = b3;
      b b4 = new b("UINT64", 3, c1, 0);
      f = b4;
      t1.c c4 = t1.c.b;
      b b5 = new b("INT32", 4, c4, 0);
      g = b5;
      b b6 = new b("FIXED64", 5, c1, 1);
      l = b6;
      b b7 = new b("FIXED32", 6, c4, 5);
      m = b7;
      b b8 = new b("BOOL", 7, t1.c.f, 0);
      n = b8;
      a a = new a("STRING", 8, t1.c.g, 2);
      o = a;
      t1.c c3 = t1.c.n;
      b b9 = new b("GROUP", 9, c3, 3);
      p = b9;
      c c2 = new c("MESSAGE", 10, c3, 2);
      q = c2;
      d d = new d("BYTES", 11, t1.c.l, 2);
      r = d;
      b b11 = new b("UINT32", 12, c4, 0);
      s = b11;
      b b12 = new b("ENUM", 13, t1.c.m, 0);
      t = b12;
      b b13 = new b("SFIXED32", 14, c4, 5);
      u = b13;
      b b14 = new b("SFIXED64", 15, c1, 1);
      v = b14;
      b b15 = new b("SINT32", 16, c4, 0);
      w = b15;
      b b10 = new b("SINT64", 17, c1, 0);
      x = b10;
      y = new b[] { 
          b1, b2, b3, b4, b5, b6, b7, b8, a, b9, 
          c2, d, b11, b12, b13, b14, b15, b10 };
    }
    
    b(t1.c param1c, int param1Int1) {
      this.a = param1c;
      this.b = param1Int1;
    }
    
    public t1.c a() {
      return this.a;
    }
    
    public int g() {
      return this.b;
    }
    
    enum a {
    
    }
    
    enum b {
    
    }
    
    enum c {
    
    }
    
    enum d {
    
    }
  }
  
  enum a {
  
  }
  
  enum b {
  
  }
  
  enum c {
  
  }
  
  enum d {
  
  }
  
  public enum c {
    b, c, d, e, f, g, l, m, n;
    
    private final Object a;
    
    static {
      c c1 = new c("INT", 0, Integer.valueOf(0));
      b = c1;
      c c2 = new c("LONG", 1, Long.valueOf(0L));
      c = c2;
      c c3 = new c("FLOAT", 2, Float.valueOf(0.0F));
      d = c3;
      c c4 = new c("DOUBLE", 3, Double.valueOf(0.0D));
      e = c4;
      c c5 = new c("BOOLEAN", 4, Boolean.FALSE);
      f = c5;
      c c6 = new c("STRING", 5, "");
      g = c6;
      c c7 = new c("BYTE_STRING", 6, h.b);
      l = c7;
      c c8 = new c("ENUM", 7, null);
      m = c8;
      c c9 = new c("MESSAGE", 8, null);
      n = c9;
      o = new c[] { c1, c2, c3, c4, c5, c6, c7, c8, c9 };
    }
    
    c(Object param1Object) {
      this.a = param1Object;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\t1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */