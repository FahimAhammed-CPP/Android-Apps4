package androidx.datastore.preferences.protobuf;

import java.util.HashMap;
import java.util.Map;

public class p {
  private static boolean b = true;
  
  private static final Class<?> c = c();
  
  private static volatile p d;
  
  static final p e = new p(true);
  
  private final Map<a, y.e<?, ?>> a = new HashMap<a, y.e<?, ?>>();
  
  p() {}
  
  p(boolean paramBoolean) {}
  
  public static p b() {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/p.d : Landroidx/datastore/preferences/protobuf/p;
    //   3: astore_0
    //   4: aload_0
    //   5: ifnonnull -> 53
    //   8: ldc androidx/datastore/preferences/protobuf/p
    //   10: monitorenter
    //   11: getstatic androidx/datastore/preferences/protobuf/p.d : Landroidx/datastore/preferences/protobuf/p;
    //   14: astore_1
    //   15: aload_1
    //   16: astore_0
    //   17: aload_1
    //   18: ifnonnull -> 42
    //   21: getstatic androidx/datastore/preferences/protobuf/p.b : Z
    //   24: ifeq -> 34
    //   27: invokestatic a : ()Landroidx/datastore/preferences/protobuf/p;
    //   30: astore_0
    //   31: goto -> 38
    //   34: getstatic androidx/datastore/preferences/protobuf/p.e : Landroidx/datastore/preferences/protobuf/p;
    //   37: astore_0
    //   38: aload_0
    //   39: putstatic androidx/datastore/preferences/protobuf/p.d : Landroidx/datastore/preferences/protobuf/p;
    //   42: ldc androidx/datastore/preferences/protobuf/p
    //   44: monitorexit
    //   45: aload_0
    //   46: areturn
    //   47: astore_0
    //   48: ldc androidx/datastore/preferences/protobuf/p
    //   50: monitorexit
    //   51: aload_0
    //   52: athrow
    //   53: aload_0
    //   54: areturn
    // Exception table:
    //   from	to	target	type
    //   11	15	47	finally
    //   21	31	47	finally
    //   34	38	47	finally
    //   38	42	47	finally
    //   42	45	47	finally
    //   48	51	47	finally
  }
  
  static Class<?> c() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.Extension");
    } catch (ClassNotFoundException classNotFoundException) {
      return null;
    } 
  }
  
  public <ContainingType extends r0> y.e<ContainingType, ?> a(ContainingType paramContainingType, int paramInt) {
    return (y.e<ContainingType, ?>)this.a.get(new a(paramContainingType, paramInt));
  }
  
  private static final class a {
    private final Object a;
    
    private final int b;
    
    a(Object param1Object, int param1Int) {
      this.a = param1Object;
      this.b = param1Int;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = param1Object instanceof a;
      boolean bool1 = false;
      if (!bool)
        return false; 
      param1Object = param1Object;
      bool = bool1;
      if (this.a == ((a)param1Object).a) {
        bool = bool1;
        if (this.b == ((a)param1Object).b)
          bool = true; 
      } 
      return bool;
    }
    
    public int hashCode() {
      return System.identityHashCode(this.a) * 65535 + this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */