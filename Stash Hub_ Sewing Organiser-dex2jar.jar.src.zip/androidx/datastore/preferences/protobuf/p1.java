package androidx.datastore.preferences.protobuf;

class p1 extends n1<o1, o1> {
  o1 A(Object paramObject) {
    return ((y)paramObject).unknownFields;
  }
  
  int B(o1 paramo1) {
    return paramo1.f();
  }
  
  int C(o1 paramo1) {
    return paramo1.g();
  }
  
  o1 D(o1 paramo11, o1 paramo12) {
    return paramo12.equals(o1.e()) ? paramo11 : o1.k(paramo11, paramo12);
  }
  
  o1 E() {
    return o1.l();
  }
  
  void F(Object paramObject, o1 paramo1) {
    G(paramObject, paramo1);
  }
  
  void G(Object paramObject, o1 paramo1) {
    ((y)paramObject).unknownFields = paramo1;
  }
  
  o1 H(o1 paramo1) {
    paramo1.j();
    return paramo1;
  }
  
  void I(o1 paramo1, u1 paramu1) {
    paramo1.o(paramu1);
  }
  
  void J(o1 paramo1, u1 paramu1) {
    paramo1.q(paramu1);
  }
  
  void j(Object paramObject) {
    A(paramObject).j();
  }
  
  boolean q(f1 paramf1) {
    return false;
  }
  
  void u(o1 paramo1, int paramInt1, int paramInt2) {
    paramo1.n(t1.c(paramInt1, 5), Integer.valueOf(paramInt2));
  }
  
  void v(o1 paramo1, int paramInt, long paramLong) {
    paramo1.n(t1.c(paramInt, 1), Long.valueOf(paramLong));
  }
  
  void w(o1 paramo11, int paramInt, o1 paramo12) {
    paramo11.n(t1.c(paramInt, 3), paramo12);
  }
  
  void x(o1 paramo1, int paramInt, h paramh) {
    paramo1.n(t1.c(paramInt, 2), paramh);
  }
  
  void y(o1 paramo1, int paramInt, long paramLong) {
    paramo1.n(t1.c(paramInt, 0), Long.valueOf(paramLong));
  }
  
  o1 z(Object paramObject) {
    o1 o12 = A(paramObject);
    o1 o11 = o12;
    if (o12 == o1.e()) {
      o11 = o1.l();
      G(paramObject, o11);
    } 
    return o11;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\p1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */