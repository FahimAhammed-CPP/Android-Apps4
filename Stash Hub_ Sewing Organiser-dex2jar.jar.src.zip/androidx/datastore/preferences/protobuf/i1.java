package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.List;

final class i1 {
  private static final Class<?> a = B();
  
  private static final n1<?, ?> b = C(false);
  
  private static final n1<?, ?> c = C(true);
  
  private static final n1<?, ?> d = new p1();
  
  static <UT, UB> UB A(int paramInt, List<Integer> paramList, a0.e parame, UB paramUB, n1<UT, UB> paramn1) {
    UB uB;
    if (parame == null)
      return paramUB; 
    if (paramList instanceof java.util.RandomAccess) {
      int k = paramList.size();
      int i = 0;
      int j = 0;
      while (i < k) {
        int m = ((Integer)paramList.get(i)).intValue();
        if (parame.a(m)) {
          if (i != j)
            paramList.set(j, Integer.valueOf(m)); 
          j++;
        } else {
          paramUB = L(paramInt, m, paramUB, paramn1);
        } 
        i++;
      } 
      uB = paramUB;
      if (j != k) {
        paramList.subList(j, k).clear();
        return paramUB;
      } 
    } else {
      Iterator<Integer> iterator = paramList.iterator();
      while (true) {
        uB = paramUB;
        if (iterator.hasNext()) {
          int i = ((Integer)iterator.next()).intValue();
          if (!parame.a(i)) {
            paramUB = L(paramInt, i, paramUB, paramn1);
            iterator.remove();
          } 
          continue;
        } 
        break;
      } 
    } 
    return uB;
  }
  
  private static Class<?> B() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.GeneratedMessageV3");
    } finally {
      Exception exception = null;
    } 
  }
  
  private static n1<?, ?> C(boolean paramBoolean) {
    try {
      return (clazz == null) ? null : clazz.getConstructor(new Class[] { boolean.class }).newInstance(new Object[] { Boolean.valueOf(paramBoolean) });
    } finally {
      Exception exception = null;
    } 
  }
  
  private static Class<?> D() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.UnknownFieldSetSchema");
    } finally {
      Exception exception = null;
    } 
  }
  
  static <T, FT extends u.b<FT>> void E(q<FT> paramq, T paramT1, T paramT2) {
    u<FT> u = paramq.c(paramT2);
    if (!u.n())
      paramq.d(paramT1).u(u); 
  }
  
  static <T> void F(m0 paramm0, T paramT1, T paramT2, long paramLong) {
    r1.O(paramT1, paramLong, paramm0.a(r1.A(paramT1, paramLong), r1.A(paramT2, paramLong)));
  }
  
  static <T, UT, UB> void G(n1<UT, UB> paramn1, T paramT1, T paramT2) {
    paramn1.p(paramT1, paramn1.k(paramn1.g(paramT1), paramn1.g(paramT2)));
  }
  
  public static n1<?, ?> H() {
    return b;
  }
  
  public static n1<?, ?> I() {
    return c;
  }
  
  public static void J(Class<?> paramClass) {
    if (!y.class.isAssignableFrom(paramClass)) {
      Class<?> clazz = a;
      if (clazz != null) {
        if (clazz.isAssignableFrom(paramClass))
          return; 
        throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
      } 
    } 
  }
  
  static boolean K(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2)));
  }
  
  static <UT, UB> UB L(int paramInt1, int paramInt2, UB paramUB, n1<UT, UB> paramn1) {
    UB uB = paramUB;
    if (paramUB == null)
      uB = paramn1.n(); 
    paramn1.e(uB, paramInt1, paramInt2);
    return uB;
  }
  
  public static n1<?, ?> M() {
    return d;
  }
  
  public static void N(int paramInt, List<Boolean> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.r(paramInt, paramList, paramBoolean); 
  }
  
  public static void O(int paramInt, List<h> paramList, u1 paramu1) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.I(paramInt, paramList); 
  }
  
  public static void P(int paramInt, List<Double> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.G(paramInt, paramList, paramBoolean); 
  }
  
  public static void Q(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.F(paramInt, paramList, paramBoolean); 
  }
  
  public static void R(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.p(paramInt, paramList, paramBoolean); 
  }
  
  public static void S(int paramInt, List<Long> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.j(paramInt, paramList, paramBoolean); 
  }
  
  public static void T(int paramInt, List<Float> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.b(paramInt, paramList, paramBoolean); 
  }
  
  public static void U(int paramInt, List<?> paramList, u1 paramu1, g1 paramg1) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.M(paramInt, paramList, paramg1); 
  }
  
  public static void V(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.a(paramInt, paramList, paramBoolean); 
  }
  
  public static void W(int paramInt, List<Long> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.E(paramInt, paramList, paramBoolean); 
  }
  
  public static void X(int paramInt, List<?> paramList, u1 paramu1, g1 paramg1) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.L(paramInt, paramList, paramg1); 
  }
  
  public static void Y(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.k(paramInt, paramList, paramBoolean); 
  }
  
  public static void Z(int paramInt, List<Long> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.o(paramInt, paramList, paramBoolean); 
  }
  
  static int a(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    return (i == 0) ? 0 : (paramBoolean ? (k.V(paramInt) + k.C(i)) : (i * k.d(paramInt, true)));
  }
  
  public static void a0(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.B(paramInt, paramList, paramBoolean); 
  }
  
  static int b(List<?> paramList) {
    return paramList.size();
  }
  
  public static void b0(int paramInt, List<Long> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.t(paramInt, paramList, paramBoolean); 
  }
  
  static int c(int paramInt, List<h> paramList) {
    int j = paramList.size();
    int i = 0;
    if (j == 0)
      return 0; 
    j *= k.V(paramInt);
    paramInt = i;
    i = j;
    while (paramInt < paramList.size()) {
      i += k.h(paramList.get(paramInt));
      paramInt++;
    } 
    return i;
  }
  
  public static void c0(int paramInt, List<String> paramList, u1 paramu1) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.y(paramInt, paramList); 
  }
  
  static int d(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = e(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  public static void d0(int paramInt, List<Integer> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.s(paramInt, paramList, paramBoolean); 
  }
  
  static int e(List<Integer> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof z) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.l(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.l(((Integer)paramList.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void e0(int paramInt, List<Long> paramList, u1 paramu1, boolean paramBoolean) {
    if (paramList != null && !paramList.isEmpty())
      paramu1.q(paramInt, paramList, paramBoolean); 
  }
  
  static int f(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    return (i == 0) ? 0 : (paramBoolean ? (k.V(paramInt) + k.C(i * 4)) : (i * k.m(paramInt, 0)));
  }
  
  static int g(List<?> paramList) {
    return paramList.size() * 4;
  }
  
  static int h(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    return (i == 0) ? 0 : (paramBoolean ? (k.V(paramInt) + k.C(i * 8)) : (i * k.o(paramInt, 0L)));
  }
  
  static int i(List<?> paramList) {
    return paramList.size() * 8;
  }
  
  static int j(int paramInt, List<r0> paramList, g1 paramg1) {
    int k = paramList.size();
    int i = 0;
    if (k == 0)
      return 0; 
    int j = 0;
    while (i < k) {
      j += k.s(paramInt, paramList.get(i), paramg1);
      i++;
    } 
    return j;
  }
  
  static int k(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = l(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  static int l(List<Integer> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof z) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.w(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.w(((Integer)paramList.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static int m(int paramInt, List<Long> paramList, boolean paramBoolean) {
    if (paramList.size() == 0)
      return 0; 
    int i = n(paramList);
    return paramBoolean ? (k.V(paramInt) + k.C(i)) : (i + paramList.size() * k.V(paramInt));
  }
  
  static int n(List<Long> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof i0) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.y(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.y(((Long)paramList.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static int o(int paramInt, Object paramObject, g1 paramg1) {
    return (paramObject instanceof e0) ? k.A(paramInt, (e0)paramObject) : k.F(paramInt, (r0)paramObject, paramg1);
  }
  
  static int p(int paramInt, List<?> paramList, g1 paramg1) {
    int k = paramList.size();
    int j = 0;
    if (k == 0)
      return 0; 
    int i = k.V(paramInt) * k;
    for (paramInt = j; paramInt < k; paramInt++) {
      Object object = paramList.get(paramInt);
      if (object instanceof e0) {
        j = k.B((e0)object);
      } else {
        j = k.H((r0)object, paramg1);
      } 
      i += j;
    } 
    return i;
  }
  
  static int q(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = r(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  static int r(List<Integer> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof z) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.Q(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.Q(((Integer)paramList.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static int s(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = t(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  static int t(List<Long> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof i0) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.S(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.S(((Long)paramList.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static int u(int paramInt, List<?> paramList) {
    int k = paramList.size();
    int i = 0;
    byte b = 0;
    if (k == 0)
      return 0; 
    int j = k.V(paramInt) * k;
    paramInt = j;
    if (paramList instanceof g0) {
      paramList = paramList;
      paramInt = j;
      i = b;
      while (true) {
        j = paramInt;
        if (i < k) {
          Object object = paramList.h(i);
          if (object instanceof h) {
            j = k.h((h)object);
          } else {
            j = k.U((String)object);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } else {
      while (true) {
        j = paramInt;
        if (i < k) {
          Object object = paramList.get(i);
          if (object instanceof h) {
            j = k.h((h)object);
          } else {
            j = k.U((String)object);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  static int v(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = w(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  static int w(List<Integer> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof z) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.X(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.X(((Integer)paramList.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static int x(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = y(paramList);
    paramInt = k.V(paramInt);
    return paramBoolean ? (paramInt + k.C(j)) : (j + i * paramInt);
  }
  
  static int y(List<Long> paramList) {
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof i0) {
      paramList = paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += k.Z(paramList.p(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += k.Z(((Long)paramList.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  static <UT, UB> UB z(int paramInt, List<Integer> paramList, a0.d<?> paramd, UB paramUB, n1<UT, UB> paramn1) {
    UB uB;
    if (paramd == null)
      return paramUB; 
    if (paramList instanceof java.util.RandomAccess) {
      int k = paramList.size();
      int i = 0;
      int j = 0;
      while (i < k) {
        int m = ((Integer)paramList.get(i)).intValue();
        if (paramd.a(m) != null) {
          if (i != j)
            paramList.set(j, Integer.valueOf(m)); 
          j++;
        } else {
          paramUB = L(paramInt, m, paramUB, paramn1);
        } 
        i++;
      } 
      uB = paramUB;
      if (j != k) {
        paramList.subList(j, k).clear();
        return paramUB;
      } 
    } else {
      Iterator<Integer> iterator = paramList.iterator();
      while (true) {
        uB = paramUB;
        if (iterator.hasNext()) {
          int i = ((Integer)iterator.next()).intValue();
          if (paramd.a(i) == null) {
            paramUB = L(paramInt, i, paramUB, paramn1);
            iterator.remove();
          } 
          continue;
        } 
        break;
      } 
    } 
    return uB;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */