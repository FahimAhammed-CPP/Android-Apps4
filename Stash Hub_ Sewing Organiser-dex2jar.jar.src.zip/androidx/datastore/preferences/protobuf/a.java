package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract class a<MessageType extends a<MessageType, BuilderType>, BuilderType extends a.a<MessageType, BuilderType>> implements r0 {
  protected int memoizedHashCode = 0;
  
  protected static <T> void l(Iterable<T> paramIterable, List<? super T> paramList) {
    a.l(paramIterable, paramList);
  }
  
  private String o(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Serializing ");
    stringBuilder.append(getClass().getName());
    stringBuilder.append(" to a ");
    stringBuilder.append(paramString);
    stringBuilder.append(" threw an IOException (should never happen).");
    return stringBuilder.toString();
  }
  
  public h f() {
    try {
      h.h h = h.t(b());
      j(h.b());
      return h.a();
    } catch (IOException iOException) {
      throw new RuntimeException(o("ByteString"), iOException);
    } 
  }
  
  int m() {
    throw new UnsupportedOperationException();
  }
  
  int n(g1<a> paramg1) {
    int j = m();
    int i = j;
    if (j == -1) {
      i = paramg1.e(this);
      q(i);
    } 
    return i;
  }
  
  m1 p() {
    return new m1(this);
  }
  
  void q(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  public void r(OutputStream paramOutputStream) {
    k k = k.f0(paramOutputStream, k.I(b()));
    j(k);
    k.c0();
  }
  
  public static abstract class a<MessageType extends a<MessageType, BuilderType>, BuilderType extends a<MessageType, BuilderType>> implements r0.a {
    protected static <T> void l(Iterable<T> param1Iterable, List<? super T> param1List) {
      String str;
      a0.a(param1Iterable);
      if (param1Iterable instanceof g0) {
        List<?> list = ((g0)param1Iterable).i();
        param1Iterable = (g0)param1List;
        int i = param1List.size();
        Iterator<?> iterator = list.iterator();
        while (iterator.hasNext()) {
          list = (List<?>)iterator.next();
          if (list == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Element at index ");
            stringBuilder.append(param1Iterable.size() - i);
            stringBuilder.append(" is null.");
            str = stringBuilder.toString();
            for (int j = param1Iterable.size() - 1; j >= i; j--)
              param1Iterable.remove(j); 
            throw new NullPointerException(str);
          } 
          if (list instanceof h) {
            param1Iterable.l((h)list);
            continue;
          } 
          param1Iterable.add((T)list);
        } 
      } else {
        if (param1Iterable instanceof a1) {
          str.addAll((Collection)param1Iterable);
          return;
        } 
        m(param1Iterable, (List<? super T>)str);
      } 
    }
    
    private static <T> void m(Iterable<T> param1Iterable, List<? super T> param1List) {
      if (param1List instanceof ArrayList && param1Iterable instanceof Collection)
        ((ArrayList)param1List).ensureCapacity(param1List.size() + ((Collection)param1Iterable).size()); 
      int i = param1List.size();
      Iterator<T> iterator = param1Iterable.iterator();
      while (iterator.hasNext()) {
        T t = iterator.next();
        if (t == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Element at index ");
          stringBuilder.append(param1List.size() - i);
          stringBuilder.append(" is null.");
          String str = stringBuilder.toString();
          for (int j = param1List.size() - 1; j >= i; j--)
            param1List.remove(j); 
          throw new NullPointerException(str);
        } 
        param1List.add(t);
      } 
    }
    
    protected static m1 q(r0 param1r0) {
      return new m1(param1r0);
    }
    
    protected abstract BuilderType n(MessageType param1MessageType);
    
    public BuilderType p(r0 param1r0) {
      if (c().getClass().isInstance(param1r0))
        return n((MessageType)param1r0); 
      throw new IllegalArgumentException("mergeFrom(MessageLite) can only merge messages of the same type.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */