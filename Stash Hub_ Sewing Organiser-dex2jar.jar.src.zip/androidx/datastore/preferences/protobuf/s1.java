package androidx.datastore.preferences.protobuf;

final class s1 {
  private static final b a;
  
  static {
    c c;
    if (e.e() && !d.c()) {
      e e = new e();
    } else {
      c = new c();
    } 
    a = c;
  }
  
  static String e(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return a.a(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  static int f(CharSequence paramCharSequence, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return a.b(paramCharSequence, paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  static int g(CharSequence paramCharSequence) {
    int k;
    int m = paramCharSequence.length();
    int j;
    for (j = 0; j < m && paramCharSequence.charAt(j) < ''; j++);
    int i = m;
    while (true) {
      k = i;
      if (j < m) {
        k = paramCharSequence.charAt(j);
        if (k < 2048) {
          i += 127 - k >>> 31;
          j++;
          continue;
        } 
        k = i + h(paramCharSequence, j);
      } 
      break;
    } 
    if (k >= m)
      return k; 
    paramCharSequence = new StringBuilder();
    paramCharSequence.append("UTF-8 length does not fit in int: ");
    paramCharSequence.append(k + 4294967296L);
    throw new IllegalArgumentException(paramCharSequence.toString());
  }
  
  private static int h(CharSequence paramCharSequence, int paramInt) {
    int j = paramCharSequence.length();
    int i = 0;
    while (paramInt < j) {
      int k;
      char c = paramCharSequence.charAt(paramInt);
      if (c < 'ࠀ') {
        i += 127 - c >>> 31;
        k = paramInt;
      } else {
        int m = i + 2;
        i = m;
        k = paramInt;
        if ('?' <= c) {
          i = m;
          k = paramInt;
          if (c <= '?')
            if (Character.codePointAt(paramCharSequence, paramInt) >= 65536) {
              k = paramInt + 1;
              i = m;
            } else {
              throw new d(paramInt, j);
            }  
        } 
      } 
      paramInt = k + 1;
    } 
    return i;
  }
  
  private static int i(int paramInt) {
    int i = paramInt;
    if (paramInt > -12)
      i = -1; 
    return i;
  }
  
  private static int j(int paramInt1, int paramInt2) {
    return (paramInt1 > -12 || paramInt2 > -65) ? -1 : (paramInt1 ^ paramInt2 << 8);
  }
  
  private static int k(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 > -12 || paramInt2 > -65 || paramInt3 > -65) ? -1 : (paramInt1 ^ paramInt2 << 8 ^ paramInt3 << 16);
  }
  
  private static int l(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    byte b1 = paramArrayOfbyte[paramInt1 - 1];
    paramInt2 -= paramInt1;
    if (paramInt2 != 0) {
      if (paramInt2 != 1) {
        if (paramInt2 == 2)
          return k(b1, paramArrayOfbyte[paramInt1], paramArrayOfbyte[paramInt1 + 1]); 
        throw new AssertionError();
      } 
      return j(b1, paramArrayOfbyte[paramInt1]);
    } 
    return i(b1);
  }
  
  public static boolean m(byte[] paramArrayOfbyte) {
    return a.c(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static boolean n(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return a.c(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  private static class a {
    private static void h(byte param1Byte1, byte param1Byte2, byte param1Byte3, byte param1Byte4, char[] param1ArrayOfchar, int param1Int) {
      if (!m(param1Byte2) && (param1Byte1 << 28) + param1Byte2 + 112 >> 30 == 0 && !m(param1Byte3) && !m(param1Byte4)) {
        int i = (param1Byte1 & 0x7) << 18 | r(param1Byte2) << 12 | r(param1Byte3) << 6 | r(param1Byte4);
        param1ArrayOfchar[param1Int] = l(i);
        param1ArrayOfchar[param1Int + 1] = q(i);
        return;
      } 
      throw b0.c();
    }
    
    private static void i(byte param1Byte, char[] param1ArrayOfchar, int param1Int) {
      param1ArrayOfchar[param1Int] = (char)param1Byte;
    }
    
    private static void j(byte param1Byte1, byte param1Byte2, byte param1Byte3, char[] param1ArrayOfchar, int param1Int) {
      if (!m(param1Byte2) && (param1Byte1 != -32 || param1Byte2 >= -96) && (param1Byte1 != -19 || param1Byte2 < -96) && !m(param1Byte3)) {
        param1ArrayOfchar[param1Int] = (char)((param1Byte1 & 0xF) << 12 | r(param1Byte2) << 6 | r(param1Byte3));
        return;
      } 
      throw b0.c();
    }
    
    private static void k(byte param1Byte1, byte param1Byte2, char[] param1ArrayOfchar, int param1Int) {
      if (param1Byte1 >= -62 && !m(param1Byte2)) {
        param1ArrayOfchar[param1Int] = (char)((param1Byte1 & 0x1F) << 6 | r(param1Byte2));
        return;
      } 
      throw b0.c();
    }
    
    private static char l(int param1Int) {
      return (char)((param1Int >>> 10) + 55232);
    }
    
    private static boolean m(byte param1Byte) {
      return (param1Byte > -65);
    }
    
    private static boolean n(byte param1Byte) {
      return (param1Byte >= 0);
    }
    
    private static boolean o(byte param1Byte) {
      return (param1Byte < -16);
    }
    
    private static boolean p(byte param1Byte) {
      return (param1Byte < -32);
    }
    
    private static char q(int param1Int) {
      return (char)((param1Int & 0x3FF) + 56320);
    }
    
    private static int r(byte param1Byte) {
      return param1Byte & 0x3F;
    }
  }
  
  static abstract class b {
    abstract String a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2);
    
    abstract int b(CharSequence param1CharSequence, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2);
    
    final boolean c(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      boolean bool = false;
      if (d(0, param1ArrayOfbyte, param1Int1, param1Int2) == 0)
        bool = true; 
      return bool;
    }
    
    abstract int d(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2, int param1Int3);
  }
  
  static final class c extends b {
    private static int e(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      while (param1Int1 < param1Int2 && param1ArrayOfbyte[param1Int1] >= 0)
        param1Int1++; 
      return (param1Int1 >= param1Int2) ? 0 : f(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    private static int f(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      while (true) {
        if (param1Int1 >= param1Int2)
          return 0; 
        int i = param1Int1 + 1;
        byte b1 = param1ArrayOfbyte[param1Int1];
        param1Int1 = i;
        if (b1 < 0) {
          if (b1 < -32) {
            if (i >= param1Int2)
              return b1; 
            if (b1 >= -62) {
              param1Int1 = i + 1;
              if (param1ArrayOfbyte[i] > -65)
                return -1; 
              continue;
            } 
            return -1;
          } 
          if (b1 < -16) {
            if (i >= param1Int2 - 1)
              return s1.c(param1ArrayOfbyte, i, param1Int2); 
            int j = i + 1;
            param1Int1 = param1ArrayOfbyte[i];
            if (param1Int1 <= -65 && (b1 != -32 || param1Int1 >= -96) && (b1 != -19 || param1Int1 < -96)) {
              param1Int1 = j + 1;
              if (param1ArrayOfbyte[j] > -65)
                return -1; 
              continue;
            } 
            return -1;
          } 
          if (i >= param1Int2 - 2)
            return s1.c(param1ArrayOfbyte, i, param1Int2); 
          param1Int1 = i + 1;
          i = param1ArrayOfbyte[i];
          if (i <= -65 && (b1 << 28) + i + 112 >> 30 == 0) {
            i = param1Int1 + 1;
            if (param1ArrayOfbyte[param1Int1] <= -65) {
              param1Int1 = i + 1;
              if (param1ArrayOfbyte[i] > -65)
                break; 
              continue;
            } 
          } 
          break;
        } 
      } 
      return -1;
    }
    
    String a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      if ((param1Int1 | param1Int2 | param1ArrayOfbyte.length - param1Int1 - param1Int2) >= 0) {
        int j = param1Int1 + param1Int2;
        char[] arrayOfChar = new char[param1Int2];
        for (param1Int2 = 0; param1Int1 < j; param1Int2++) {
          byte b1 = param1ArrayOfbyte[param1Int1];
          if (!s1.a.b(b1))
            break; 
          param1Int1++;
          s1.a.c(b1, arrayOfChar, param1Int2);
        } 
        int i = param1Int2;
        param1Int2 = param1Int1;
        param1Int1 = i;
        while (param1Int2 < j) {
          i = param1Int2 + 1;
          byte b1 = param1ArrayOfbyte[param1Int2];
          if (s1.a.b(b1)) {
            param1Int2 = param1Int1 + 1;
            s1.a.c(b1, arrayOfChar, param1Int1);
            param1Int1 = param1Int2;
            param1Int2 = i;
            while (param1Int2 < j) {
              b1 = param1ArrayOfbyte[param1Int2];
              if (!s1.a.b(b1))
                break; 
              param1Int2++;
              s1.a.c(b1, arrayOfChar, param1Int1);
              param1Int1++;
            } 
            continue;
          } 
          if (s1.a.d(b1)) {
            if (i < j) {
              s1.a.e(b1, param1ArrayOfbyte[i], arrayOfChar, param1Int1);
              param1Int2 = i + 1;
              param1Int1++;
              continue;
            } 
            throw b0.c();
          } 
          if (s1.a.f(b1)) {
            if (i < j - 1) {
              param1Int2 = i + 1;
              s1.a.g(b1, param1ArrayOfbyte[i], param1ArrayOfbyte[param1Int2], arrayOfChar, param1Int1);
              param1Int2++;
              param1Int1++;
              continue;
            } 
            throw b0.c();
          } 
          if (i < j - 2) {
            param1Int2 = i + 1;
            byte b2 = param1ArrayOfbyte[i];
            i = param1Int2 + 1;
            s1.a.a(b1, b2, param1ArrayOfbyte[param1Int2], param1ArrayOfbyte[i], arrayOfChar, param1Int1);
            param1Int2 = i + 1;
            param1Int1 = param1Int1 + 1 + 1;
            continue;
          } 
          throw b0.c();
        } 
        return new String(arrayOfChar, 0, param1Int1);
      } 
      throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", new Object[] { Integer.valueOf(param1ArrayOfbyte.length), Integer.valueOf(param1Int1), Integer.valueOf(param1Int2) }));
    }
    
    int b(CharSequence param1CharSequence, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      int j = param1CharSequence.length();
      int k = param1Int2 + param1Int1;
      param1Int2 = 0;
      while (param1Int2 < j) {
        int m = param1Int2 + param1Int1;
        if (m < k) {
          char c1 = param1CharSequence.charAt(param1Int2);
          if (c1 < '') {
            param1ArrayOfbyte[m] = (byte)c1;
            param1Int2++;
          } 
        } 
      } 
      if (param1Int2 == j)
        return param1Int1 + j; 
      int i = param1Int1 + param1Int2;
      param1Int1 = param1Int2;
      while (param1Int1 < j) {
        char c1 = param1CharSequence.charAt(param1Int1);
        if (c1 < '' && i < k) {
          param1Int2 = i + 1;
          param1ArrayOfbyte[i] = (byte)c1;
        } else if (c1 < 'ࠀ' && i <= k - 2) {
          int m = i + 1;
          param1ArrayOfbyte[i] = (byte)(c1 >>> 6 | 0x3C0);
          param1Int2 = m + 1;
          param1ArrayOfbyte[m] = (byte)(c1 & 0x3F | 0x80);
        } else if ((c1 < '?' || '?' < c1) && i <= k - 3) {
          param1Int2 = i + 1;
          param1ArrayOfbyte[i] = (byte)(c1 >>> 12 | 0x1E0);
          i = param1Int2 + 1;
          param1ArrayOfbyte[param1Int2] = (byte)(c1 >>> 6 & 0x3F | 0x80);
          param1Int2 = i + 1;
          param1ArrayOfbyte[i] = (byte)(c1 & 0x3F | 0x80);
        } else if (i <= k - 4) {
          param1Int2 = param1Int1 + 1;
          if (param1Int2 != param1CharSequence.length()) {
            char c2 = param1CharSequence.charAt(param1Int2);
            if (Character.isSurrogatePair(c1, c2)) {
              param1Int1 = Character.toCodePoint(c1, c2);
              int m = i + 1;
              param1ArrayOfbyte[i] = (byte)(param1Int1 >>> 18 | 0xF0);
              i = m + 1;
              param1ArrayOfbyte[m] = (byte)(param1Int1 >>> 12 & 0x3F | 0x80);
              m = i + 1;
              param1ArrayOfbyte[i] = (byte)(param1Int1 >>> 6 & 0x3F | 0x80);
              i = m + 1;
              param1ArrayOfbyte[m] = (byte)(param1Int1 & 0x3F | 0x80);
              param1Int1 = param1Int2;
              param1Int2 = i;
            } else {
              param1Int1 = param1Int2;
              throw new s1.d(param1Int1 - 1, j);
            } 
          } else {
            throw new s1.d(param1Int1 - 1, j);
          } 
        } else {
          if ('?' <= c1 && c1 <= '?') {
            param1Int2 = param1Int1 + 1;
            if (param1Int2 == param1CharSequence.length() || !Character.isSurrogatePair(c1, param1CharSequence.charAt(param1Int2)))
              throw new s1.d(param1Int1, j); 
          } 
          param1CharSequence = new StringBuilder();
          param1CharSequence.append("Failed writing ");
          param1CharSequence.append(c1);
          param1CharSequence.append(" at index ");
          param1CharSequence.append(i);
          throw new ArrayIndexOutOfBoundsException(param1CharSequence.toString());
        } 
        param1Int1++;
        i = param1Int2;
      } 
      return i;
    }
    
    int d(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2, int param1Int3) {
      int i = param1Int2;
      if (param1Int1 != 0) {
        if (param1Int2 >= param1Int3)
          return param1Int1; 
        byte b1 = (byte)param1Int1;
        if (b1 < -32) {
          if (b1 >= -62) {
            param1Int1 = param1Int2 + 1;
            if (param1ArrayOfbyte[param1Int2] > -65)
              return -1; 
          } else {
            return -1;
          } 
        } else if (b1 < -16) {
          byte b2 = (byte)(param1Int1 >> 8);
          param1Int1 = b2;
          i = param1Int2;
          if (b2 == 0) {
            i = param1Int2 + 1;
            param1Int1 = param1ArrayOfbyte[param1Int2];
            if (i >= param1Int3)
              return s1.a(b1, param1Int1); 
          } 
          if (param1Int1 <= -65 && (b1 != -32 || param1Int1 >= -96) && (b1 != -19 || param1Int1 < -96)) {
            param1Int1 = i + 1;
            if (param1ArrayOfbyte[i] > -65)
              return -1; 
          } else {
            return -1;
          } 
        } else {
          i = (byte)(param1Int1 >> 8);
          int j = 0;
          if (i == 0) {
            param1Int1 = param1Int2 + 1;
            i = param1ArrayOfbyte[param1Int2];
            if (param1Int1 >= param1Int3)
              return s1.a(b1, i); 
            param1Int2 = param1Int1;
            param1Int1 = j;
          } else {
            param1Int1 = (byte)(param1Int1 >> 16);
          } 
          int k = param1Int1;
          j = param1Int2;
          if (param1Int1 == 0) {
            j = param1Int2 + 1;
            k = param1ArrayOfbyte[param1Int2];
            if (j >= param1Int3)
              return s1.b(b1, i, k); 
          } 
          if (i <= -65 && (b1 << 28) + i + 112 >> 30 == 0 && k <= -65) {
            param1Int1 = j + 1;
            if (param1ArrayOfbyte[j] > -65)
              return -1; 
          } else {
            return -1;
          } 
        } 
        i = param1Int1;
      } 
      return e(param1ArrayOfbyte, i, param1Int3);
    }
  }
  
  static class d extends IllegalArgumentException {
    d(int param1Int1, int param1Int2) {
      super(stringBuilder.toString());
    }
  }
  
  static final class e extends b {
    static boolean e() {
      return (r1.C() && r1.D());
    }
    
    private static int f(byte[] param1ArrayOfbyte, long param1Long, int param1Int) {
      int i = g(param1ArrayOfbyte, param1Long, param1Int);
      param1Int -= i;
      param1Long += i;
      while (true) {
        long l;
        byte b1 = 0;
        i = param1Int;
        param1Int = b1;
        while (true) {
          l = param1Long;
          if (i > 0) {
            l = param1Long + 1L;
            param1Int = r1.s(param1ArrayOfbyte, param1Long);
            if (param1Int >= 0) {
              i--;
              param1Long = l;
              continue;
            } 
          } 
          break;
        } 
        if (i == 0)
          return 0; 
        i--;
        if (param1Int < -32) {
          if (i == 0)
            return param1Int; 
          i--;
          if (param1Int >= -62) {
            param1Long = 1L + l;
            param1Int = i;
            if (r1.s(param1ArrayOfbyte, l) > -65)
              return -1; 
            continue;
          } 
          return -1;
        } 
        if (param1Int < -16) {
          if (i < 2)
            return h(param1ArrayOfbyte, param1Int, l, i); 
          i -= 2;
          long l1 = l + 1L;
          b1 = r1.s(param1ArrayOfbyte, l);
          if (b1 <= -65 && (param1Int != -32 || b1 >= -96) && (param1Int != -19 || b1 < -96)) {
            param1Long = 1L + l1;
            param1Int = i;
            if (r1.s(param1ArrayOfbyte, l1) > -65)
              return -1; 
            continue;
          } 
          return -1;
        } 
        if (i < 3)
          return h(param1ArrayOfbyte, param1Int, l, i); 
        i -= 3;
        param1Long = l + 1L;
        b1 = r1.s(param1ArrayOfbyte, l);
        if (b1 <= -65 && (param1Int << 28) + b1 + 112 >> 30 == 0) {
          l = param1Long + 1L;
          if (r1.s(param1ArrayOfbyte, param1Long) <= -65) {
            param1Long = 1L + l;
            param1Int = i;
            if (r1.s(param1ArrayOfbyte, l) > -65)
              break; 
            continue;
          } 
        } 
        break;
      } 
      return -1;
    }
    
    private static int g(byte[] param1ArrayOfbyte, long param1Long, int param1Int) {
      int i = 0;
      if (param1Int < 16)
        return 0; 
      while (i < param1Int) {
        if (r1.s(param1ArrayOfbyte, param1Long) < 0)
          return i; 
        i++;
        param1Long = 1L + param1Long;
      } 
      return param1Int;
    }
    
    private static int h(byte[] param1ArrayOfbyte, int param1Int1, long param1Long, int param1Int2) {
      if (param1Int2 != 0) {
        if (param1Int2 != 1) {
          if (param1Int2 == 2)
            return s1.b(param1Int1, r1.s(param1ArrayOfbyte, param1Long), r1.s(param1ArrayOfbyte, param1Long + 1L)); 
          throw new AssertionError();
        } 
        return s1.a(param1Int1, r1.s(param1ArrayOfbyte, param1Long));
      } 
      return s1.d(param1Int1);
    }
    
    String a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      if ((param1Int1 | param1Int2 | param1ArrayOfbyte.length - param1Int1 - param1Int2) >= 0) {
        int j = param1Int1 + param1Int2;
        char[] arrayOfChar = new char[param1Int2];
        for (param1Int2 = 0; param1Int1 < j; param1Int2++) {
          byte b1 = r1.s(param1ArrayOfbyte, param1Int1);
          if (!s1.a.b(b1))
            break; 
          param1Int1++;
          s1.a.c(b1, arrayOfChar, param1Int2);
        } 
        int i = param1Int2;
        param1Int2 = param1Int1;
        param1Int1 = i;
        while (param1Int2 < j) {
          i = param1Int2 + 1;
          byte b1 = r1.s(param1ArrayOfbyte, param1Int2);
          if (s1.a.b(b1)) {
            param1Int2 = param1Int1 + 1;
            s1.a.c(b1, arrayOfChar, param1Int1);
            param1Int1 = param1Int2;
            param1Int2 = i;
            while (param1Int2 < j) {
              b1 = r1.s(param1ArrayOfbyte, param1Int2);
              if (!s1.a.b(b1))
                break; 
              param1Int2++;
              s1.a.c(b1, arrayOfChar, param1Int1);
              param1Int1++;
            } 
            continue;
          } 
          if (s1.a.d(b1)) {
            if (i < j) {
              s1.a.e(b1, r1.s(param1ArrayOfbyte, i), arrayOfChar, param1Int1);
              param1Int2 = i + 1;
              param1Int1++;
              continue;
            } 
            throw b0.c();
          } 
          if (s1.a.f(b1)) {
            if (i < j - 1) {
              param1Int2 = i + 1;
              s1.a.g(b1, r1.s(param1ArrayOfbyte, i), r1.s(param1ArrayOfbyte, param1Int2), arrayOfChar, param1Int1);
              param1Int2++;
              param1Int1++;
              continue;
            } 
            throw b0.c();
          } 
          if (i < j - 2) {
            param1Int2 = i + 1;
            byte b2 = r1.s(param1ArrayOfbyte, i);
            i = param1Int2 + 1;
            s1.a.a(b1, b2, r1.s(param1ArrayOfbyte, param1Int2), r1.s(param1ArrayOfbyte, i), arrayOfChar, param1Int1);
            param1Int2 = i + 1;
            param1Int1 = param1Int1 + 1 + 1;
            continue;
          } 
          throw b0.c();
        } 
        return new String(arrayOfChar, 0, param1Int1);
      } 
      throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", new Object[] { Integer.valueOf(param1ArrayOfbyte.length), Integer.valueOf(param1Int1), Integer.valueOf(param1Int2) }));
    }
    
    int b(CharSequence param1CharSequence, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      long l1 = param1Int1;
      long l2 = param1Int2 + l1;
      int i = param1CharSequence.length();
      if (i <= param1Int2 && param1ArrayOfbyte.length - param1Int2 >= param1Int1) {
        long l3;
        param1Int2 = 0;
        while (true) {
          l3 = 1L;
          if (param1Int2 < i) {
            param1Int1 = param1CharSequence.charAt(param1Int2);
            if (param1Int1 < 128) {
              r1.H(param1ArrayOfbyte, l1, (byte)param1Int1);
              param1Int2++;
              l1 = 1L + l1;
              continue;
            } 
          } 
          break;
        } 
        param1Int1 = param1Int2;
        long l4 = l1;
        if (param1Int2 == i)
          return (int)l1; 
        while (param1Int1 < i) {
          char c = param1CharSequence.charAt(param1Int1);
          if (c < '' && l4 < l2) {
            r1.H(param1ArrayOfbyte, l4, (byte)c);
            long l = l3;
            l1 = l4 + l3;
            l3 = l;
          } else if (c < 'ࠀ' && l4 <= l2 - 2L) {
            l1 = l4 + l3;
            r1.H(param1ArrayOfbyte, l4, (byte)(c >>> 6 | 0x3C0));
            r1.H(param1ArrayOfbyte, l1, (byte)(c & 0x3F | 0x80));
            l1 += l3;
          } else if ((c < '?' || '?' < c) && l4 <= l2 - 3L) {
            l1 = l4 + l3;
            r1.H(param1ArrayOfbyte, l4, (byte)(c >>> 12 | 0x1E0));
            l3 = l1 + l3;
            r1.H(param1ArrayOfbyte, l1, (byte)(c >>> 6 & 0x3F | 0x80));
            r1.H(param1ArrayOfbyte, l3, (byte)(c & 0x3F | 0x80));
            l1 = l3 + 1L;
            l3 = 1L;
          } else if (l4 <= l2 - 4L) {
            param1Int2 = param1Int1 + 1;
            if (param1Int2 != i) {
              char c1 = param1CharSequence.charAt(param1Int2);
              if (Character.isSurrogatePair(c, c1)) {
                param1Int1 = Character.toCodePoint(c, c1);
                l3 = l4 + 1L;
                r1.H(param1ArrayOfbyte, l4, (byte)(param1Int1 >>> 18 | 0xF0));
                l1 = l3 + 1L;
                r1.H(param1ArrayOfbyte, l3, (byte)(param1Int1 >>> 12 & 0x3F | 0x80));
                l4 = l1 + 1L;
                r1.H(param1ArrayOfbyte, l1, (byte)(param1Int1 >>> 6 & 0x3F | 0x80));
                l3 = 1L;
                l1 = l4 + 1L;
                r1.H(param1ArrayOfbyte, l4, (byte)(param1Int1 & 0x3F | 0x80));
                param1Int1 = param1Int2;
              } else {
                param1Int1 = param1Int2;
                throw new s1.d(param1Int1 - 1, i);
              } 
            } else {
              throw new s1.d(param1Int1 - 1, i);
            } 
          } else {
            if ('?' <= c && c <= '?') {
              param1Int2 = param1Int1 + 1;
              if (param1Int2 == i || !Character.isSurrogatePair(c, param1CharSequence.charAt(param1Int2)))
                throw new s1.d(param1Int1, i); 
            } 
            param1CharSequence = new StringBuilder();
            param1CharSequence.append("Failed writing ");
            param1CharSequence.append(c);
            param1CharSequence.append(" at index ");
            param1CharSequence.append(l4);
            throw new ArrayIndexOutOfBoundsException(param1CharSequence.toString());
          } 
          param1Int1++;
          l4 = l1;
        } 
        return (int)l4;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed writing ");
      stringBuilder.append(param1CharSequence.charAt(i - 1));
      stringBuilder.append(" at index ");
      stringBuilder.append(param1Int1 + param1Int2);
      throw new ArrayIndexOutOfBoundsException(stringBuilder.toString());
    }
    
    int d(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2, int param1Int3) {
      int i = param1ArrayOfbyte.length;
      boolean bool = false;
      if ((param1Int2 | param1Int3 | i - param1Int3) >= 0) {
        long l1 = param1Int2;
        long l3 = param1Int3;
        long l2 = l1;
        if (param1Int1 != 0) {
          if (l1 >= l3)
            return param1Int1; 
          i = (byte)param1Int1;
          if (i < -32) {
            if (i >= -62) {
              if (r1.s(param1ArrayOfbyte, l1) > -65)
                return -1; 
              l2 = 1L + l1;
            } else {
              return -1;
            } 
          } else {
            if (i < -16) {
              param1Int2 = (byte)(param1Int1 >> 8);
              l2 = l1;
              param1Int1 = param1Int2;
              if (param1Int2 == 0) {
                l2 = l1 + 1L;
                param1Int1 = r1.s(param1ArrayOfbyte, l1);
                if (l2 >= l3)
                  return s1.a(i, param1Int1); 
              } 
              if (param1Int1 <= -65 && (i != -32 || param1Int1 >= -96) && (i != -19 || param1Int1 < -96)) {
                l1 = l2 + 1L;
                if (r1.s(param1ArrayOfbyte, l2) > -65)
                  return -1; 
              } else {
                return -1;
              } 
            } else {
              param1Int2 = (byte)(param1Int1 >> 8);
              if (param1Int2 == 0) {
                l2 = l1 + 1L;
                param1Int2 = r1.s(param1ArrayOfbyte, l1);
                if (l2 >= l3)
                  return s1.a(i, param1Int2); 
                l1 = l2;
                param1Int1 = bool;
              } else {
                param1Int1 = (byte)(param1Int1 >> 16);
              } 
              param1Int3 = param1Int1;
              l2 = l1;
              if (param1Int1 == 0) {
                l2 = l1 + 1L;
                param1Int3 = r1.s(param1ArrayOfbyte, l1);
                if (l2 >= l3)
                  return s1.b(i, param1Int2, param1Int3); 
              } 
              if (param1Int2 <= -65 && (i << 28) + param1Int2 + 112 >> 30 == 0 && param1Int3 <= -65) {
                l1 = l2 + 1L;
                if (r1.s(param1ArrayOfbyte, l2) > -65)
                  return -1; 
              } else {
                return -1;
              } 
            } 
            l2 = l1;
          } 
        } 
        return f(param1ArrayOfbyte, l2, (int)(l3 - l2));
      } 
      throw new ArrayIndexOutOfBoundsException(String.format("Array length=%d, index=%d, limit=%d", new Object[] { Integer.valueOf(param1ArrayOfbyte.length), Integer.valueOf(param1Int2), Integer.valueOf(param1Int3) }));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\s1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */