package androidx.datastore.preferences.protobuf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

final class u<T extends u.b<T>> {
  private static final u d = new u(true);
  
  private final j1<T, Object> a = j1.q(16);
  
  private boolean b;
  
  private boolean c;
  
  private u() {}
  
  private u(j1<T, Object> paramj1) {
    t();
  }
  
  private u(boolean paramBoolean) {
    this(j1.q(0));
    t();
  }
  
  static void A(k paramk, t1.b paramb, Object paramObject) {
    int i;
    switch (a.b[paramb.ordinal()]) {
      default:
        return;
      case 18:
        if (paramObject instanceof a0.c) {
          i = ((a0.c)paramObject).b();
        } else {
          i = ((Integer)paramObject).intValue();
        } 
        paramk.t0(i);
        return;
      case 17:
        paramk.T0(((Long)paramObject).longValue());
        return;
      case 16:
        paramk.R0(((Integer)paramObject).intValue());
        return;
      case 15:
        paramk.P0(((Long)paramObject).longValue());
        return;
      case 14:
        paramk.N0(((Integer)paramObject).intValue());
        return;
      case 13:
        paramk.Y0(((Integer)paramObject).intValue());
        return;
      case 12:
        if (!(paramObject instanceof h)) {
          paramk.m0((byte[])paramObject);
          return;
        } 
        paramk.p0((h)paramObject);
        return;
      case 11:
        if (!(paramObject instanceof h)) {
          paramk.V0((String)paramObject);
          return;
        } 
        paramk.p0((h)paramObject);
        return;
      case 10:
        paramk.J0((r0)paramObject);
        return;
      case 9:
        paramk.C0((r0)paramObject);
        return;
      case 8:
        paramk.l0(((Boolean)paramObject).booleanValue());
        return;
      case 7:
        paramk.v0(((Integer)paramObject).intValue());
        return;
      case 6:
        paramk.x0(((Long)paramObject).longValue());
        return;
      case 5:
        paramk.F0(((Integer)paramObject).intValue());
        return;
      case 4:
        paramk.a1(((Long)paramObject).longValue());
        return;
      case 3:
        paramk.H0(((Long)paramObject).longValue());
        return;
      case 2:
        paramk.z0(((Float)paramObject).floatValue());
        return;
      case 1:
        break;
    } 
    paramk.r0(((Double)paramObject).doubleValue());
  }
  
  private static Object c(Object paramObject) {
    if (paramObject instanceof byte[]) {
      paramObject = paramObject;
      byte[] arrayOfByte = new byte[paramObject.length];
      System.arraycopy(paramObject, 0, arrayOfByte, 0, paramObject.length);
      return arrayOfByte;
    } 
    return paramObject;
  }
  
  static int d(t1.b paramb, int paramInt, Object paramObject) {
    int i = k.V(paramInt);
    paramInt = i;
    if (paramb == t1.b.p)
      paramInt = i * 2; 
    return paramInt + e(paramb, paramObject);
  }
  
  static int e(t1.b paramb, Object paramObject) {
    switch (a.b[paramb.ordinal()]) {
      default:
        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
      case 18:
        return (paramObject instanceof a0.c) ? k.l(((a0.c)paramObject).b()) : k.l(((Integer)paramObject).intValue());
      case 17:
        return k.S(((Long)paramObject).longValue());
      case 16:
        return k.Q(((Integer)paramObject).intValue());
      case 15:
        return k.O(((Long)paramObject).longValue());
      case 14:
        return k.M(((Integer)paramObject).intValue());
      case 13:
        return k.X(((Integer)paramObject).intValue());
      case 12:
        return (paramObject instanceof h) ? k.h((h)paramObject) : k.f((byte[])paramObject);
      case 11:
        return (paramObject instanceof h) ? k.h((h)paramObject) : k.U((String)paramObject);
      case 10:
        return (paramObject instanceof d0) ? k.B((d0)paramObject) : k.G((r0)paramObject);
      case 9:
        return k.t((r0)paramObject);
      case 8:
        return k.e(((Boolean)paramObject).booleanValue());
      case 7:
        return k.n(((Integer)paramObject).intValue());
      case 6:
        return k.p(((Long)paramObject).longValue());
      case 5:
        return k.w(((Integer)paramObject).intValue());
      case 4:
        return k.Z(((Long)paramObject).longValue());
      case 3:
        return k.y(((Long)paramObject).longValue());
      case 2:
        return k.r(((Float)paramObject).floatValue());
      case 1:
        break;
    } 
    return k.j(((Double)paramObject).doubleValue());
  }
  
  public static int f(b<?> paramb, Object paramObject) {
    t1.b b1 = paramb.d();
    int i = paramb.b();
    if (paramb.c()) {
      boolean bool1 = paramb.f();
      boolean bool = false;
      int j = 0;
      List list = (List)paramObject;
      if (bool1) {
        iterator = list.iterator();
        while (iterator.hasNext())
          j += e(b1, iterator.next()); 
        return k.V(i) + j + k.K(j);
      } 
      Iterator iterator = iterator.iterator();
      for (j = bool; iterator.hasNext(); j += d(b1, i, iterator.next()));
      return j;
    } 
    return d(b1, i, paramObject);
  }
  
  public static <T extends b<T>> u<T> h() {
    return d;
  }
  
  private int k(Map.Entry<T, Object> paramEntry) {
    b<?> b = (b)paramEntry.getKey();
    Object object = paramEntry.getValue();
    if (b.e() == t1.c.n && !b.c() && !b.f()) {
      boolean bool = object instanceof d0;
      int i = ((b)paramEntry.getKey()).b();
      return bool ? k.z(i, (d0)object) : k.D(i, (r0)object);
    } 
    return f(b, object);
  }
  
  static int m(t1.b paramb, boolean paramBoolean) {
    return paramBoolean ? 2 : paramb.g();
  }
  
  private static <T extends b<T>> boolean q(Map.Entry<T, Object> paramEntry) {
    b b = (b)paramEntry.getKey();
    if (b.e() == t1.c.n) {
      Iterator<r0> iterator;
      boolean bool = b.c();
      paramEntry = (Map.Entry<T, Object>)paramEntry.getValue();
      if (bool) {
        iterator = ((List)paramEntry).iterator();
        while (iterator.hasNext()) {
          if (!((r0)iterator.next()).i())
            return false; 
        } 
      } else if (iterator instanceof r0) {
        if (!((r0)iterator).i())
          return false; 
      } else {
        if (iterator instanceof d0)
          return true; 
        throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
      } 
    } 
    return true;
  }
  
  private static boolean r(t1.b paramb, Object paramObject) {
    a0.a(paramObject);
    int i = a.a[paramb.a().ordinal()];
    boolean bool2 = true;
    boolean bool3 = true;
    boolean bool1 = true;
    switch (i) {
      default:
        return false;
      case 9:
        if (!(paramObject instanceof r0)) {
          if (paramObject instanceof d0)
            return true; 
          bool1 = false;
        } 
        return bool1;
      case 8:
        bool1 = bool2;
        if (!(paramObject instanceof Integer)) {
          if (paramObject instanceof a0.c)
            return true; 
          bool1 = false;
        } 
        return bool1;
      case 7:
        bool1 = bool3;
        if (!(paramObject instanceof h)) {
          if (paramObject instanceof byte[])
            return true; 
          bool1 = false;
        } 
        return bool1;
      case 6:
        return paramObject instanceof String;
      case 5:
        return paramObject instanceof Boolean;
      case 4:
        return paramObject instanceof Double;
      case 3:
        return paramObject instanceof Float;
      case 2:
        return paramObject instanceof Long;
      case 1:
        break;
    } 
    return paramObject instanceof Integer;
  }
  
  private void v(Map.Entry<T, Object> paramEntry) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getKey : ()Ljava/lang/Object;
    //   6: checkcast androidx/datastore/preferences/protobuf/u$b
    //   9: astore #4
    //   11: aload_1
    //   12: invokeinterface getValue : ()Ljava/lang/Object;
    //   17: astore_2
    //   18: aload_2
    //   19: astore_1
    //   20: aload_2
    //   21: instanceof androidx/datastore/preferences/protobuf/d0
    //   24: ifeq -> 35
    //   27: aload_2
    //   28: checkcast androidx/datastore/preferences/protobuf/d0
    //   31: invokevirtual f : ()Landroidx/datastore/preferences/protobuf/r0;
    //   34: astore_1
    //   35: aload #4
    //   37: invokeinterface c : ()Z
    //   42: ifeq -> 121
    //   45: aload_0
    //   46: aload #4
    //   48: invokevirtual i : (Landroidx/datastore/preferences/protobuf/u$b;)Ljava/lang/Object;
    //   51: astore_3
    //   52: aload_3
    //   53: astore_2
    //   54: aload_3
    //   55: ifnonnull -> 66
    //   58: new java/util/ArrayList
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: astore_2
    //   66: aload_1
    //   67: checkcast java/util/List
    //   70: invokeinterface iterator : ()Ljava/util/Iterator;
    //   75: astore_1
    //   76: aload_1
    //   77: invokeinterface hasNext : ()Z
    //   82: ifeq -> 109
    //   85: aload_1
    //   86: invokeinterface next : ()Ljava/lang/Object;
    //   91: astore_3
    //   92: aload_2
    //   93: checkcast java/util/List
    //   96: aload_3
    //   97: invokestatic c : (Ljava/lang/Object;)Ljava/lang/Object;
    //   100: invokeinterface add : (Ljava/lang/Object;)Z
    //   105: pop
    //   106: goto -> 76
    //   109: aload_0
    //   110: getfield a : Landroidx/datastore/preferences/protobuf/j1;
    //   113: aload #4
    //   115: aload_2
    //   116: invokevirtual r : (Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    //   119: pop
    //   120: return
    //   121: aload #4
    //   123: invokeinterface e : ()Landroidx/datastore/preferences/protobuf/t1$c;
    //   128: getstatic androidx/datastore/preferences/protobuf/t1$c.n : Landroidx/datastore/preferences/protobuf/t1$c;
    //   131: if_acmpne -> 182
    //   134: aload_0
    //   135: aload #4
    //   137: invokevirtual i : (Landroidx/datastore/preferences/protobuf/u$b;)Ljava/lang/Object;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnonnull -> 148
    //   145: goto -> 182
    //   148: aload #4
    //   150: aload_2
    //   151: checkcast androidx/datastore/preferences/protobuf/r0
    //   154: invokeinterface d : ()Landroidx/datastore/preferences/protobuf/r0$a;
    //   159: aload_1
    //   160: checkcast androidx/datastore/preferences/protobuf/r0
    //   163: invokeinterface m : (Landroidx/datastore/preferences/protobuf/r0$a;Landroidx/datastore/preferences/protobuf/r0;)Landroidx/datastore/preferences/protobuf/r0$a;
    //   168: invokeinterface a : ()Landroidx/datastore/preferences/protobuf/r0;
    //   173: astore_2
    //   174: aload_0
    //   175: getfield a : Landroidx/datastore/preferences/protobuf/j1;
    //   178: astore_1
    //   179: goto -> 194
    //   182: aload_0
    //   183: getfield a : Landroidx/datastore/preferences/protobuf/j1;
    //   186: astore_3
    //   187: aload_1
    //   188: invokestatic c : (Ljava/lang/Object;)Ljava/lang/Object;
    //   191: astore_2
    //   192: aload_3
    //   193: astore_1
    //   194: aload_1
    //   195: aload #4
    //   197: aload_2
    //   198: invokevirtual r : (Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    //   201: pop
    //   202: return
  }
  
  public static <T extends b<T>> u<T> w() {
    return new u<T>();
  }
  
  private void y(t1.b paramb, Object paramObject) {
    if (r(paramb, paramObject))
      return; 
    throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
  }
  
  static void z(k paramk, t1.b paramb, int paramInt, Object paramObject) {
    if (paramb == t1.b.p) {
      paramk.A0(paramInt, (r0)paramObject);
      return;
    } 
    paramk.W0(paramInt, m(paramb, false));
    A(paramk, paramb, paramObject);
  }
  
  public void a(T paramT, Object paramObject) {
    if (paramT.c()) {
      List<Object> list;
      y(paramT.d(), paramObject);
      Object object = i(paramT);
      if (object == null) {
        object = new ArrayList();
        this.a.r(paramT, object);
        paramT = (T)object;
      } else {
        list = (List)object;
      } 
      list.add(paramObject);
      return;
    } 
    throw new IllegalArgumentException("addRepeatedField() can only be called on repeated fields.");
  }
  
  public u<T> b() {
    u<b> u1 = w();
    for (int i = 0; i < this.a.k(); i++) {
      Map.Entry<T, Object> entry = this.a.j(i);
      u1.x((b)entry.getKey(), entry.getValue());
    } 
    for (Map.Entry<T, Object> entry : this.a.m())
      u1.x((b)entry.getKey(), entry.getValue()); 
    u1.c = this.c;
    return (u)u1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof u))
      return false; 
    paramObject = paramObject;
    return this.a.equals(((u)paramObject).a);
  }
  
  Iterator<Map.Entry<T, Object>> g() {
    return this.c ? new d0.c<T>(this.a.h().iterator()) : this.a.h().iterator();
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public Object i(T paramT) {
    r0 r0;
    Object object = this.a.get(paramT);
    paramT = (T)object;
    if (object instanceof d0)
      r0 = ((d0)object).f(); 
    return r0;
  }
  
  public int j() {
    int j = 0;
    int i = 0;
    while (j < this.a.k()) {
      i += k(this.a.j(j));
      j++;
    } 
    Iterator<Map.Entry<T, Object>> iterator = this.a.m().iterator();
    while (iterator.hasNext())
      i += k(iterator.next()); 
    return i;
  }
  
  public int l() {
    int j = 0;
    int i = 0;
    while (j < this.a.k()) {
      Map.Entry<T, Object> entry = this.a.j(j);
      i += f((b)entry.getKey(), entry.getValue());
      j++;
    } 
    for (Map.Entry<T, Object> entry : this.a.m())
      i += f((b)entry.getKey(), entry.getValue()); 
    return i;
  }
  
  boolean n() {
    return this.a.isEmpty();
  }
  
  public boolean o() {
    return this.b;
  }
  
  public boolean p() {
    for (int i = 0; i < this.a.k(); i++) {
      if (!q(this.a.j(i)))
        return false; 
    } 
    Iterator<Map.Entry<b, Object>> iterator = this.a.m().iterator();
    while (iterator.hasNext()) {
      if (!q(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public Iterator<Map.Entry<T, Object>> s() {
    return this.c ? new d0.c<T>(this.a.entrySet().iterator()) : this.a.entrySet().iterator();
  }
  
  public void t() {
    if (this.b)
      return; 
    this.a.p();
    this.b = true;
  }
  
  public void u(u<T> paramu) {
    for (int i = 0; i < paramu.a.k(); i++)
      v(paramu.a.j(i)); 
    Iterator<Map.Entry<T, Object>> iterator = paramu.a.m().iterator();
    while (iterator.hasNext())
      v(iterator.next()); 
  }
  
  public void x(T paramT, Object paramObject) {
    if (paramT.c()) {
      if (paramObject instanceof List) {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll((List)paramObject);
        paramObject = arrayList.iterator();
        while (paramObject.hasNext()) {
          Object object = paramObject.next();
          y(paramT.d(), object);
        } 
        paramObject = arrayList;
      } else {
        throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
      } 
    } else {
      y(paramT.d(), paramObject);
    } 
    if (paramObject instanceof d0)
      this.c = true; 
    this.a.r(paramT, paramObject);
  }
  
  public static interface b<T extends b<T>> extends Comparable<T> {
    int b();
    
    boolean c();
    
    t1.b d();
    
    t1.c e();
    
    boolean f();
    
    r0.a m(r0.a param1a, r0 param1r0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobu\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */