package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.Map;

interface u1 {
  void A(int paramInt, String paramString);
  
  void B(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void C(int paramInt, long paramLong);
  
  void D(int paramInt1, int paramInt2);
  
  void E(int paramInt, List<Long> paramList, boolean paramBoolean);
  
  void F(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void G(int paramInt, List<Double> paramList, boolean paramBoolean);
  
  void H(int paramInt1, int paramInt2);
  
  void I(int paramInt, List<h> paramList);
  
  void J(int paramInt, h paramh);
  
  void K(int paramInt, Object paramObject, g1 paramg1);
  
  void L(int paramInt, List<?> paramList, g1 paramg1);
  
  @Deprecated
  void M(int paramInt, List<?> paramList, g1 paramg1);
  
  <K, V> void N(int paramInt, k0.a<K, V> parama, Map<K, V> paramMap);
  
  @Deprecated
  void O(int paramInt, Object paramObject, g1 paramg1);
  
  void a(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void b(int paramInt, List<Float> paramList, boolean paramBoolean);
  
  void c(int paramInt, long paramLong);
  
  void d(int paramInt, boolean paramBoolean);
  
  void e(int paramInt1, int paramInt2);
  
  void f(int paramInt, Object paramObject);
  
  void g(int paramInt1, int paramInt2);
  
  @Deprecated
  void h(int paramInt);
  
  void i(int paramInt1, int paramInt2);
  
  void j(int paramInt, List<Long> paramList, boolean paramBoolean);
  
  void k(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void l(int paramInt1, int paramInt2);
  
  void m(int paramInt, double paramDouble);
  
  void n(int paramInt, long paramLong);
  
  void o(int paramInt, List<Long> paramList, boolean paramBoolean);
  
  void p(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void q(int paramInt, List<Long> paramList, boolean paramBoolean);
  
  void r(int paramInt, List<Boolean> paramList, boolean paramBoolean);
  
  void s(int paramInt, List<Integer> paramList, boolean paramBoolean);
  
  void t(int paramInt, List<Long> paramList, boolean paramBoolean);
  
  void u(int paramInt, long paramLong);
  
  a v();
  
  void w(int paramInt, long paramLong);
  
  void x(int paramInt, float paramFloat);
  
  void y(int paramInt, List<String> paramList);
  
  @Deprecated
  void z(int paramInt);
  
  public enum a {
    a, b;
    
    static {
      a a1 = new a("ASCENDING", 0);
      a = a1;
      a a2 = new a("DESCENDING", 1);
      b = a2;
      c = new a[] { a1, a2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobu\\u1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */