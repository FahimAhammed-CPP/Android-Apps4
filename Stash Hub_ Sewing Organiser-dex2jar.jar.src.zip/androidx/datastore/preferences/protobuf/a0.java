package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Objects;
import java.util.RandomAccess;

public final class a0 {
  static final Charset a = Charset.forName("UTF-8");
  
  static final Charset b = Charset.forName("ISO-8859-1");
  
  public static final byte[] c;
  
  public static final ByteBuffer d;
  
  public static final i e;
  
  static {
    byte[] arrayOfByte = new byte[0];
    c = arrayOfByte;
    d = ByteBuffer.wrap(arrayOfByte);
    e = i.h(arrayOfByte);
  }
  
  static <T> T a(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  static <T> T b(T paramT, String paramString) {
    Objects.requireNonNull(paramT, paramString);
    return paramT;
  }
  
  public static int c(boolean paramBoolean) {
    return paramBoolean ? 1231 : 1237;
  }
  
  public static int d(byte[] paramArrayOfbyte) {
    return e(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  static int e(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    paramInt2 = i(paramInt2, paramArrayOfbyte, paramInt1, paramInt2);
    paramInt1 = paramInt2;
    if (paramInt2 == 0)
      paramInt1 = 1; 
    return paramInt1;
  }
  
  public static int f(long paramLong) {
    return (int)(paramLong ^ paramLong >>> 32L);
  }
  
  public static boolean g(byte[] paramArrayOfbyte) {
    return s1.m(paramArrayOfbyte);
  }
  
  static Object h(Object paramObject1, Object paramObject2) {
    return ((r0)paramObject1).d().k((r0)paramObject2).g();
  }
  
  static int i(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) {
    int j;
    for (j = paramInt2; j < paramInt2 + paramInt3; j++)
      paramInt1 = paramInt1 * 31 + paramArrayOfbyte[j]; 
    return paramInt1;
  }
  
  public static String j(byte[] paramArrayOfbyte) {
    return new String(paramArrayOfbyte, a);
  }
  
  public static interface a extends i<Boolean> {}
  
  public static interface b extends i<Double> {}
  
  public static interface c {
    int b();
  }
  
  public static interface d<T extends c> {
    T a(int param1Int);
  }
  
  public static interface e {
    boolean a(int param1Int);
  }
  
  public static interface f extends i<Float> {}
  
  public static interface g extends i<Integer> {}
  
  public static interface h extends i<Long> {}
  
  public static interface i<E> extends List<E>, RandomAccess {
    void d();
    
    i<E> e(int param1Int);
    
    boolean j();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */