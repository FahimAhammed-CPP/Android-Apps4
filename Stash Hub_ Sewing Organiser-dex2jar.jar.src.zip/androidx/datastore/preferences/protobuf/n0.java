package androidx.datastore.preferences.protobuf;

import java.util.Map;

class n0 implements m0 {
  private static <K, V> int i(int paramInt, Object paramObject1, Object paramObject2) {
    l0 l0 = (l0)paramObject1;
    paramObject1 = paramObject2;
    boolean bool = l0.isEmpty();
    int i = 0;
    if (bool)
      return 0; 
    paramObject2 = l0.entrySet().iterator();
    while (paramObject2.hasNext()) {
      Map.Entry entry = paramObject2.next();
      i += paramObject1.a(paramInt, entry.getKey(), entry.getValue());
    } 
    return i;
  }
  
  private static <K, V> l0<K, V> j(Object paramObject1, Object paramObject2) {
    l0 l0 = (l0)paramObject1;
    paramObject2 = paramObject2;
    paramObject1 = l0;
    if (!paramObject2.isEmpty()) {
      paramObject1 = l0;
      if (!l0.j())
        paramObject1 = l0.n(); 
      paramObject1.m((l0)paramObject2);
    } 
    return (l0<K, V>)paramObject1;
  }
  
  public Object a(Object paramObject1, Object paramObject2) {
    return j(paramObject1, paramObject2);
  }
  
  public Object b(Object paramObject) {
    return l0.e().n();
  }
  
  public int c(int paramInt, Object paramObject1, Object paramObject2) {
    return i(paramInt, paramObject1, paramObject2);
  }
  
  public boolean d(Object paramObject) {
    return ((l0)paramObject).j() ^ true;
  }
  
  public Object e(Object paramObject) {
    ((l0)paramObject).l();
    return paramObject;
  }
  
  public k0.a<?, ?> f(Object paramObject) {
    return ((k0<?, ?>)paramObject).c();
  }
  
  public Map<?, ?> g(Object paramObject) {
    return (l0)paramObject;
  }
  
  public Map<?, ?> h(Object paramObject) {
    return (l0)paramObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */