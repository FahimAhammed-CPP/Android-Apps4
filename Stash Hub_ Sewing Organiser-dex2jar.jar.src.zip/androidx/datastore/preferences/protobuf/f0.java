package androidx.datastore.preferences.protobuf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public class f0 extends c<String> implements g0, RandomAccess {
  private static final f0 c;
  
  public static final g0 d;
  
  private final List<Object> b;
  
  static {
    f0 f01 = new f0();
    c = f01;
    f01.d();
    d = f01;
  }
  
  public f0() {
    this(10);
  }
  
  public f0(int paramInt) {
    this(new ArrayList(paramInt));
  }
  
  private f0(ArrayList<Object> paramArrayList) {
    this.b = paramArrayList;
  }
  
  private static String g(Object paramObject) {
    return (paramObject instanceof String) ? (String)paramObject : ((paramObject instanceof h) ? ((h)paramObject).C() : a0.j((byte[])paramObject));
  }
  
  public boolean addAll(int paramInt, Collection<? extends String> paramCollection) {
    a();
    Collection<? extends String> collection = paramCollection;
    if (paramCollection instanceof g0)
      collection = (Collection)((g0)paramCollection).i(); 
    boolean bool = this.b.addAll(paramInt, collection);
    this.modCount++;
    return bool;
  }
  
  public boolean addAll(Collection<? extends String> paramCollection) {
    return addAll(size(), paramCollection);
  }
  
  public void c(int paramInt, String paramString) {
    a();
    this.b.add(paramInt, paramString);
    this.modCount++;
  }
  
  public void clear() {
    a();
    this.b.clear();
    this.modCount++;
  }
  
  public g0 f() {
    return (g0)(j() ? new q1(this) : this);
  }
  
  public Object h(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public List<?> i() {
    return Collections.unmodifiableList(this.b);
  }
  
  public String k(int paramInt) {
    Object object = this.b.get(paramInt);
    if (object instanceof String)
      return (String)object; 
    if (object instanceof h) {
      object = object;
      String str1 = object.C();
      if (object.r())
        this.b.set(paramInt, str1); 
      return str1;
    } 
    object = object;
    String str = a0.j((byte[])object);
    if (a0.g((byte[])object))
      this.b.set(paramInt, str); 
    return str;
  }
  
  public void l(h paramh) {
    a();
    this.b.add(paramh);
    this.modCount++;
  }
  
  public f0 m(int paramInt) {
    if (paramInt >= size()) {
      ArrayList<Object> arrayList = new ArrayList(paramInt);
      arrayList.addAll(this.b);
      return new f0(arrayList);
    } 
    throw new IllegalArgumentException();
  }
  
  public String n(int paramInt) {
    a();
    Object object = this.b.remove(paramInt);
    this.modCount++;
    return g(object);
  }
  
  public String o(int paramInt, String paramString) {
    a();
    return g(this.b.set(paramInt, paramString));
  }
  
  public int size() {
    return this.b.size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */