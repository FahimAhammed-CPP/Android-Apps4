package androidx.datastore.preferences.protobuf;

public interface s0 {
  r0 c();
  
  boolean i();
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */