package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import sun.misc.Unsafe;

final class u0<T> implements g1<T> {
  private static final int[] r = new int[0];
  
  private static final Unsafe s = r1.B();
  
  private final int[] a;
  
  private final Object[] b;
  
  private final int c;
  
  private final int d;
  
  private final r0 e;
  
  private final boolean f;
  
  private final boolean g;
  
  private final boolean h;
  
  private final boolean i;
  
  private final int[] j;
  
  private final int k;
  
  private final int l;
  
  private final w0 m;
  
  private final h0 n;
  
  private final n1<?, ?> o;
  
  private final q<?> p;
  
  private final m0 q;
  
  private u0(int[] paramArrayOfint1, Object[] paramArrayOfObject, int paramInt1, int paramInt2, r0 paramr0, boolean paramBoolean1, boolean paramBoolean2, int[] paramArrayOfint2, int paramInt3, int paramInt4, w0 paramw0, h0 paramh0, n1<?, ?> paramn1, q<?> paramq, m0 paramm0) {
    this.a = paramArrayOfint1;
    this.b = paramArrayOfObject;
    this.c = paramInt1;
    this.d = paramInt2;
    this.g = paramr0 instanceof y;
    this.h = paramBoolean1;
    if (paramq != null && paramq.e(paramr0)) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.f = paramBoolean1;
    this.i = paramBoolean2;
    this.j = paramArrayOfint2;
    this.k = paramInt3;
    this.l = paramInt4;
    this.m = paramw0;
    this.n = paramh0;
    this.o = paramn1;
    this.p = paramq;
    this.e = paramr0;
    this.q = paramm0;
  }
  
  private static boolean A(Object paramObject, int paramInt, g1<Object> paramg1) {
    return paramg1.c(r1.A(paramObject, R(paramInt)));
  }
  
  private <N> boolean B(Object paramObject, int paramInt1, int paramInt2) {
    paramObject = r1.A(paramObject, R(paramInt1));
    if (paramObject.isEmpty())
      return true; 
    g1 g11 = s(paramInt2);
    for (paramInt1 = 0; paramInt1 < paramObject.size(); paramInt1++) {
      if (!g11.c(paramObject.get(paramInt1)))
        return false; 
    } 
    return true;
  }
  
  private boolean C(T paramT, int paramInt1, int paramInt2) {
    Map<?, ?> map = this.q.g(r1.A(paramT, R(paramInt1)));
    if (map.isEmpty())
      return true; 
    paramT = (T)r(paramInt2);
    if ((this.q.f(paramT)).c.a() != t1.c.n)
      return true; 
    paramT = null;
    for (Object object : map.values()) {
      g1<?> g12;
      T t = paramT;
      if (paramT == null)
        g12 = c1.a().d(object.getClass()); 
      g1<?> g11 = g12;
      if (!g12.c(object))
        return false; 
    } 
    return true;
  }
  
  private boolean D(T paramT1, T paramT2, int paramInt) {
    long l = (Y(paramInt) & 0xFFFFF);
    return (r1.x(paramT1, l) == r1.x(paramT2, l));
  }
  
  private boolean E(T paramT, int paramInt1, int paramInt2) {
    return (r1.x(paramT, (Y(paramInt2) & 0xFFFFF)) == paramInt1);
  }
  
  private static boolean F(int paramInt) {
    return ((paramInt & 0x10000000) != 0);
  }
  
  private static List<?> G(Object paramObject, long paramLong) {
    return (List)r1.A(paramObject, paramLong);
  }
  
  private static <T> long H(T paramT, long paramLong) {
    return r1.y(paramT, paramLong);
  }
  
  private <UT, UB, ET extends u.b<ET>> void I(n1<UT, UB> paramn1, q<ET> paramq, T paramT, f1 paramf1, p paramp) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #14
    //   3: aload #14
    //   5: astore #18
    //   7: aload #14
    //   9: astore #15
    //   11: aload #4
    //   13: invokeinterface p : ()I
    //   18: istore #8
    //   20: aload #14
    //   22: astore #15
    //   24: aload_0
    //   25: iload #8
    //   27: invokespecial X : (I)I
    //   30: istore #9
    //   32: iload #9
    //   34: ifge -> 324
    //   37: iload #8
    //   39: ldc 2147483647
    //   41: if_icmpne -> 98
    //   44: aload_0
    //   45: getfield k : I
    //   48: istore #6
    //   50: iload #6
    //   52: aload_0
    //   53: getfield l : I
    //   56: if_icmpge -> 85
    //   59: aload_0
    //   60: aload_3
    //   61: aload_0
    //   62: getfield j : [I
    //   65: iload #6
    //   67: iaload
    //   68: aload #14
    //   70: aload_1
    //   71: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   74: astore #14
    //   76: iload #6
    //   78: iconst_1
    //   79: iadd
    //   80: istore #6
    //   82: goto -> 50
    //   85: aload #14
    //   87: ifnull -> 97
    //   90: aload_1
    //   91: aload_3
    //   92: aload #14
    //   94: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   97: return
    //   98: aload #14
    //   100: astore #15
    //   102: aload_0
    //   103: getfield f : Z
    //   106: ifne -> 115
    //   109: aconst_null
    //   110: astore #16
    //   112: goto -> 133
    //   115: aload #14
    //   117: astore #15
    //   119: aload_2
    //   120: aload #5
    //   122: aload_0
    //   123: getfield e : Landroidx/datastore/preferences/protobuf/r0;
    //   126: iload #8
    //   128: invokevirtual b : (Landroidx/datastore/preferences/protobuf/p;Landroidx/datastore/preferences/protobuf/r0;I)Ljava/lang/Object;
    //   131: astore #16
    //   133: aload #16
    //   135: ifnull -> 186
    //   138: aload #18
    //   140: astore #17
    //   142: aload #18
    //   144: ifnonnull -> 158
    //   147: aload #14
    //   149: astore #15
    //   151: aload_2
    //   152: aload_3
    //   153: invokevirtual d : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   156: astore #17
    //   158: aload #14
    //   160: astore #15
    //   162: aload_2
    //   163: aload #4
    //   165: aload #16
    //   167: aload #5
    //   169: aload #17
    //   171: aload #14
    //   173: aload_1
    //   174: invokevirtual g : (Landroidx/datastore/preferences/protobuf/f1;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/p;Landroidx/datastore/preferences/protobuf/u;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   177: astore #14
    //   179: aload #17
    //   181: astore #18
    //   183: goto -> 7
    //   186: aload #14
    //   188: astore #15
    //   190: aload_1
    //   191: aload #4
    //   193: invokevirtual q : (Landroidx/datastore/preferences/protobuf/f1;)Z
    //   196: ifeq -> 220
    //   199: aload #14
    //   201: astore #17
    //   203: aload #14
    //   205: astore #15
    //   207: aload #4
    //   209: invokeinterface y : ()Z
    //   214: ifeq -> 270
    //   217: goto -> 7
    //   220: aload #14
    //   222: astore #16
    //   224: aload #14
    //   226: ifnonnull -> 240
    //   229: aload #14
    //   231: astore #15
    //   233: aload_1
    //   234: aload_3
    //   235: invokevirtual f : (Ljava/lang/Object;)Ljava/lang/Object;
    //   238: astore #16
    //   240: aload #16
    //   242: astore #15
    //   244: aload_1
    //   245: aload #16
    //   247: aload #4
    //   249: invokevirtual m : (Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/f1;)Z
    //   252: istore #11
    //   254: aload #16
    //   256: astore #17
    //   258: iload #11
    //   260: ifeq -> 270
    //   263: aload #16
    //   265: astore #14
    //   267: goto -> 7
    //   270: aload_0
    //   271: getfield k : I
    //   274: istore #6
    //   276: iload #6
    //   278: aload_0
    //   279: getfield l : I
    //   282: if_icmpge -> 311
    //   285: aload_0
    //   286: aload_3
    //   287: aload_0
    //   288: getfield j : [I
    //   291: iload #6
    //   293: iaload
    //   294: aload #17
    //   296: aload_1
    //   297: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   300: astore #17
    //   302: iload #6
    //   304: iconst_1
    //   305: iadd
    //   306: istore #6
    //   308: goto -> 276
    //   311: aload #17
    //   313: ifnull -> 323
    //   316: aload_1
    //   317: aload_3
    //   318: aload #17
    //   320: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   323: return
    //   324: aload #14
    //   326: astore #15
    //   328: aload_0
    //   329: iload #9
    //   331: invokespecial i0 : (I)I
    //   334: istore #10
    //   336: aload #14
    //   338: astore #15
    //   340: aload #14
    //   342: astore #16
    //   344: iload #10
    //   346: invokestatic h0 : (I)I
    //   349: tableswitch default -> 3629, 0 -> 3274, 1 -> 3247, 2 -> 3220, 3 -> 3193, 4 -> 3166, 5 -> 3139, 6 -> 3112, 7 -> 3085, 8 -> 3065, 9 -> 2957, 10 -> 2930, 11 -> 2903, 12 -> 2819, 13 -> 2792, 14 -> 2765, 15 -> 2738, 16 -> 2711, 17 -> 2572, 18 -> 2546, 19 -> 2520, 20 -> 2494, 21 -> 2468, 22 -> 2442, 23 -> 2416, 24 -> 2390, 25 -> 2364, 26 -> 2344, 27 -> 2316, 28 -> 2285, 29 -> 2259, 30 -> 2200, 31 -> 2174, 32 -> 2148, 33 -> 2122, 34 -> 2096, 35 -> 2053, 36 -> 2010, 37 -> 1967, 38 -> 1924, 39 -> 1881, 40 -> 1838, 41 -> 1795, 42 -> 1752, 43 -> 1709, 44 -> 1628, 45 -> 1585, 46 -> 1542, 47 -> 1499, 48 -> 1456, 49 -> 1425, 50 -> 1397, 51 -> 1367, 52 -> 1337, 53 -> 1307, 54 -> 1277, 55 -> 1247, 56 -> 1217, 57 -> 1187, 58 -> 1157, 59 -> 1137, 60 -> 1008, 61 -> 981, 62 -> 951, 63 -> 838, 64 -> 808, 65 -> 778, 66 -> 748, 67 -> 718, 68 -> 666
    //   640: aload #14
    //   642: astore #17
    //   644: aload #14
    //   646: ifnonnull -> 3301
    //   649: aload #14
    //   651: astore #15
    //   653: aload #14
    //   655: astore #16
    //   657: aload_1
    //   658: invokevirtual n : ()Ljava/lang/Object;
    //   661: astore #17
    //   663: goto -> 3632
    //   666: aload #14
    //   668: astore #15
    //   670: aload #14
    //   672: astore #16
    //   674: aload_3
    //   675: iload #10
    //   677: invokestatic R : (I)J
    //   680: aload #4
    //   682: aload_0
    //   683: iload #9
    //   685: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   688: aload #5
    //   690: invokeinterface P : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   695: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   698: aload #14
    //   700: astore #15
    //   702: aload #14
    //   704: astore #16
    //   706: aload_0
    //   707: aload_3
    //   708: iload #8
    //   710: iload #9
    //   712: invokespecial f0 : (Ljava/lang/Object;II)V
    //   715: goto -> 7
    //   718: aload #14
    //   720: astore #15
    //   722: aload #14
    //   724: astore #16
    //   726: aload_3
    //   727: iload #10
    //   729: invokestatic R : (I)J
    //   732: aload #4
    //   734: invokeinterface j : ()J
    //   739: invokestatic valueOf : (J)Ljava/lang/Long;
    //   742: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   745: goto -> 698
    //   748: aload #14
    //   750: astore #15
    //   752: aload #14
    //   754: astore #16
    //   756: aload_3
    //   757: iload #10
    //   759: invokestatic R : (I)J
    //   762: aload #4
    //   764: invokeinterface h : ()I
    //   769: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   772: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   775: goto -> 698
    //   778: aload #14
    //   780: astore #15
    //   782: aload #14
    //   784: astore #16
    //   786: aload_3
    //   787: iload #10
    //   789: invokestatic R : (I)J
    //   792: aload #4
    //   794: invokeinterface r : ()J
    //   799: invokestatic valueOf : (J)Ljava/lang/Long;
    //   802: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   805: goto -> 698
    //   808: aload #14
    //   810: astore #15
    //   812: aload #14
    //   814: astore #16
    //   816: aload_3
    //   817: iload #10
    //   819: invokestatic R : (I)J
    //   822: aload #4
    //   824: invokeinterface z : ()I
    //   829: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   832: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   835: goto -> 698
    //   838: aload #14
    //   840: astore #15
    //   842: aload #14
    //   844: astore #16
    //   846: aload #4
    //   848: invokeinterface b : ()I
    //   853: istore #7
    //   855: aload #14
    //   857: astore #15
    //   859: aload #14
    //   861: astore #16
    //   863: aload_0
    //   864: iload #9
    //   866: invokespecial q : (I)Landroidx/datastore/preferences/protobuf/a0$e;
    //   869: astore #17
    //   871: aload #17
    //   873: ifnull -> 926
    //   876: iload #7
    //   878: istore #6
    //   880: aload #14
    //   882: astore #15
    //   884: aload #14
    //   886: astore #16
    //   888: aload #17
    //   890: iload #7
    //   892: invokeinterface a : (I)Z
    //   897: ifeq -> 903
    //   900: goto -> 926
    //   903: aload #14
    //   905: astore #15
    //   907: aload #14
    //   909: astore #16
    //   911: iload #8
    //   913: iload #6
    //   915: aload #14
    //   917: aload_1
    //   918: invokestatic L : (IILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   921: astore #14
    //   923: goto -> 7
    //   926: aload #14
    //   928: astore #15
    //   930: aload #14
    //   932: astore #16
    //   934: aload_3
    //   935: iload #10
    //   937: invokestatic R : (I)J
    //   940: iload #7
    //   942: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   945: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   948: goto -> 698
    //   951: aload #14
    //   953: astore #15
    //   955: aload #14
    //   957: astore #16
    //   959: aload_3
    //   960: iload #10
    //   962: invokestatic R : (I)J
    //   965: aload #4
    //   967: invokeinterface w : ()I
    //   972: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   975: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   978: goto -> 698
    //   981: aload #14
    //   983: astore #15
    //   985: aload #14
    //   987: astore #16
    //   989: aload_3
    //   990: iload #10
    //   992: invokestatic R : (I)J
    //   995: aload #4
    //   997: invokeinterface u : ()Landroidx/datastore/preferences/protobuf/h;
    //   1002: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1005: goto -> 698
    //   1008: aload #14
    //   1010: astore #15
    //   1012: aload #14
    //   1014: astore #16
    //   1016: aload_0
    //   1017: aload_3
    //   1018: iload #8
    //   1020: iload #9
    //   1022: invokespecial E : (Ljava/lang/Object;II)Z
    //   1025: ifeq -> 1087
    //   1028: aload #14
    //   1030: astore #15
    //   1032: aload #14
    //   1034: astore #16
    //   1036: aload_3
    //   1037: iload #10
    //   1039: invokestatic R : (I)J
    //   1042: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1045: aload #4
    //   1047: aload_0
    //   1048: iload #9
    //   1050: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1053: aload #5
    //   1055: invokeinterface J : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   1060: invokestatic h : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1063: astore #17
    //   1065: aload #14
    //   1067: astore #15
    //   1069: aload #14
    //   1071: astore #16
    //   1073: aload_3
    //   1074: iload #10
    //   1076: invokestatic R : (I)J
    //   1079: aload #17
    //   1081: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1084: goto -> 698
    //   1087: aload #14
    //   1089: astore #15
    //   1091: aload #14
    //   1093: astore #16
    //   1095: aload_3
    //   1096: iload #10
    //   1098: invokestatic R : (I)J
    //   1101: aload #4
    //   1103: aload_0
    //   1104: iload #9
    //   1106: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1109: aload #5
    //   1111: invokeinterface J : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   1116: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1119: aload #14
    //   1121: astore #15
    //   1123: aload #14
    //   1125: astore #16
    //   1127: aload_0
    //   1128: aload_3
    //   1129: iload #9
    //   1131: invokespecial e0 : (Ljava/lang/Object;I)V
    //   1134: goto -> 698
    //   1137: aload #14
    //   1139: astore #15
    //   1141: aload #14
    //   1143: astore #16
    //   1145: aload_0
    //   1146: aload_3
    //   1147: iload #10
    //   1149: aload #4
    //   1151: invokespecial b0 : (Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/f1;)V
    //   1154: goto -> 698
    //   1157: aload #14
    //   1159: astore #15
    //   1161: aload #14
    //   1163: astore #16
    //   1165: aload_3
    //   1166: iload #10
    //   1168: invokestatic R : (I)J
    //   1171: aload #4
    //   1173: invokeinterface o : ()Z
    //   1178: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   1181: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1184: goto -> 698
    //   1187: aload #14
    //   1189: astore #15
    //   1191: aload #14
    //   1193: astore #16
    //   1195: aload_3
    //   1196: iload #10
    //   1198: invokestatic R : (I)J
    //   1201: aload #4
    //   1203: invokeinterface n : ()I
    //   1208: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1211: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1214: goto -> 698
    //   1217: aload #14
    //   1219: astore #15
    //   1221: aload #14
    //   1223: astore #16
    //   1225: aload_3
    //   1226: iload #10
    //   1228: invokestatic R : (I)J
    //   1231: aload #4
    //   1233: invokeinterface f : ()J
    //   1238: invokestatic valueOf : (J)Ljava/lang/Long;
    //   1241: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1244: goto -> 698
    //   1247: aload #14
    //   1249: astore #15
    //   1251: aload #14
    //   1253: astore #16
    //   1255: aload_3
    //   1256: iload #10
    //   1258: invokestatic R : (I)J
    //   1261: aload #4
    //   1263: invokeinterface x : ()I
    //   1268: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1271: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1274: goto -> 698
    //   1277: aload #14
    //   1279: astore #15
    //   1281: aload #14
    //   1283: astore #16
    //   1285: aload_3
    //   1286: iload #10
    //   1288: invokestatic R : (I)J
    //   1291: aload #4
    //   1293: invokeinterface d : ()J
    //   1298: invokestatic valueOf : (J)Ljava/lang/Long;
    //   1301: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1304: goto -> 698
    //   1307: aload #14
    //   1309: astore #15
    //   1311: aload #14
    //   1313: astore #16
    //   1315: aload_3
    //   1316: iload #10
    //   1318: invokestatic R : (I)J
    //   1321: aload #4
    //   1323: invokeinterface E : ()J
    //   1328: invokestatic valueOf : (J)Ljava/lang/Long;
    //   1331: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1334: goto -> 698
    //   1337: aload #14
    //   1339: astore #15
    //   1341: aload #14
    //   1343: astore #16
    //   1345: aload_3
    //   1346: iload #10
    //   1348: invokestatic R : (I)J
    //   1351: aload #4
    //   1353: invokeinterface readFloat : ()F
    //   1358: invokestatic valueOf : (F)Ljava/lang/Float;
    //   1361: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1364: goto -> 698
    //   1367: aload #14
    //   1369: astore #15
    //   1371: aload #14
    //   1373: astore #16
    //   1375: aload_3
    //   1376: iload #10
    //   1378: invokestatic R : (I)J
    //   1381: aload #4
    //   1383: invokeinterface readDouble : ()D
    //   1388: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1391: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   1394: goto -> 698
    //   1397: aload #14
    //   1399: astore #15
    //   1401: aload #14
    //   1403: astore #16
    //   1405: aload_0
    //   1406: aload_3
    //   1407: iload #9
    //   1409: aload_0
    //   1410: iload #9
    //   1412: invokespecial r : (I)Ljava/lang/Object;
    //   1415: aload #5
    //   1417: aload #4
    //   1419: invokespecial J : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/p;Landroidx/datastore/preferences/protobuf/f1;)V
    //   1422: goto -> 7
    //   1425: aload #14
    //   1427: astore #15
    //   1429: aload #14
    //   1431: astore #16
    //   1433: aload_0
    //   1434: aload_3
    //   1435: iload #10
    //   1437: invokestatic R : (I)J
    //   1440: aload #4
    //   1442: aload_0
    //   1443: iload #9
    //   1445: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1448: aload #5
    //   1450: invokespecial Z : (Ljava/lang/Object;JLandroidx/datastore/preferences/protobuf/f1;Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)V
    //   1453: goto -> 7
    //   1456: aload #14
    //   1458: astore #15
    //   1460: aload #14
    //   1462: astore #16
    //   1464: aload_0
    //   1465: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1468: aload_3
    //   1469: iload #10
    //   1471: invokestatic R : (I)J
    //   1474: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1477: astore #17
    //   1479: aload #14
    //   1481: astore #15
    //   1483: aload #14
    //   1485: astore #16
    //   1487: aload #4
    //   1489: aload #17
    //   1491: invokeinterface i : (Ljava/util/List;)V
    //   1496: goto -> 7
    //   1499: aload #14
    //   1501: astore #15
    //   1503: aload #14
    //   1505: astore #16
    //   1507: aload_0
    //   1508: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1511: aload_3
    //   1512: iload #10
    //   1514: invokestatic R : (I)J
    //   1517: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1520: astore #17
    //   1522: aload #14
    //   1524: astore #15
    //   1526: aload #14
    //   1528: astore #16
    //   1530: aload #4
    //   1532: aload #17
    //   1534: invokeinterface a : (Ljava/util/List;)V
    //   1539: goto -> 7
    //   1542: aload #14
    //   1544: astore #15
    //   1546: aload #14
    //   1548: astore #16
    //   1550: aload_0
    //   1551: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1554: aload_3
    //   1555: iload #10
    //   1557: invokestatic R : (I)J
    //   1560: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1563: astore #17
    //   1565: aload #14
    //   1567: astore #15
    //   1569: aload #14
    //   1571: astore #16
    //   1573: aload #4
    //   1575: aload #17
    //   1577: invokeinterface D : (Ljava/util/List;)V
    //   1582: goto -> 7
    //   1585: aload #14
    //   1587: astore #15
    //   1589: aload #14
    //   1591: astore #16
    //   1593: aload_0
    //   1594: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1597: aload_3
    //   1598: iload #10
    //   1600: invokestatic R : (I)J
    //   1603: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1606: astore #17
    //   1608: aload #14
    //   1610: astore #15
    //   1612: aload #14
    //   1614: astore #16
    //   1616: aload #4
    //   1618: aload #17
    //   1620: invokeinterface g : (Ljava/util/List;)V
    //   1625: goto -> 7
    //   1628: aload #14
    //   1630: astore #15
    //   1632: aload #14
    //   1634: astore #16
    //   1636: aload_0
    //   1637: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1640: aload_3
    //   1641: iload #10
    //   1643: invokestatic R : (I)J
    //   1646: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1649: astore #17
    //   1651: aload #14
    //   1653: astore #15
    //   1655: aload #14
    //   1657: astore #16
    //   1659: aload #4
    //   1661: aload #17
    //   1663: invokeinterface I : (Ljava/util/List;)V
    //   1668: aload #14
    //   1670: astore #15
    //   1672: aload #14
    //   1674: astore #16
    //   1676: aload_0
    //   1677: iload #9
    //   1679: invokespecial q : (I)Landroidx/datastore/preferences/protobuf/a0$e;
    //   1682: astore #19
    //   1684: aload #14
    //   1686: astore #15
    //   1688: aload #14
    //   1690: astore #16
    //   1692: iload #8
    //   1694: aload #17
    //   1696: aload #19
    //   1698: aload #14
    //   1700: aload_1
    //   1701: invokestatic A : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/a0$e;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   1704: astore #14
    //   1706: goto -> 7
    //   1709: aload #14
    //   1711: astore #15
    //   1713: aload #14
    //   1715: astore #16
    //   1717: aload_0
    //   1718: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1721: aload_3
    //   1722: iload #10
    //   1724: invokestatic R : (I)J
    //   1727: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1730: astore #17
    //   1732: aload #14
    //   1734: astore #15
    //   1736: aload #14
    //   1738: astore #16
    //   1740: aload #4
    //   1742: aload #17
    //   1744: invokeinterface k : (Ljava/util/List;)V
    //   1749: goto -> 7
    //   1752: aload #14
    //   1754: astore #15
    //   1756: aload #14
    //   1758: astore #16
    //   1760: aload_0
    //   1761: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1764: aload_3
    //   1765: iload #10
    //   1767: invokestatic R : (I)J
    //   1770: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1773: astore #17
    //   1775: aload #14
    //   1777: astore #15
    //   1779: aload #14
    //   1781: astore #16
    //   1783: aload #4
    //   1785: aload #17
    //   1787: invokeinterface l : (Ljava/util/List;)V
    //   1792: goto -> 7
    //   1795: aload #14
    //   1797: astore #15
    //   1799: aload #14
    //   1801: astore #16
    //   1803: aload_0
    //   1804: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1807: aload_3
    //   1808: iload #10
    //   1810: invokestatic R : (I)J
    //   1813: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1816: astore #17
    //   1818: aload #14
    //   1820: astore #15
    //   1822: aload #14
    //   1824: astore #16
    //   1826: aload #4
    //   1828: aload #17
    //   1830: invokeinterface e : (Ljava/util/List;)V
    //   1835: goto -> 7
    //   1838: aload #14
    //   1840: astore #15
    //   1842: aload #14
    //   1844: astore #16
    //   1846: aload_0
    //   1847: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1850: aload_3
    //   1851: iload #10
    //   1853: invokestatic R : (I)J
    //   1856: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1859: astore #17
    //   1861: aload #14
    //   1863: astore #15
    //   1865: aload #14
    //   1867: astore #16
    //   1869: aload #4
    //   1871: aload #17
    //   1873: invokeinterface G : (Ljava/util/List;)V
    //   1878: goto -> 7
    //   1881: aload #14
    //   1883: astore #15
    //   1885: aload #14
    //   1887: astore #16
    //   1889: aload_0
    //   1890: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1893: aload_3
    //   1894: iload #10
    //   1896: invokestatic R : (I)J
    //   1899: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1902: astore #17
    //   1904: aload #14
    //   1906: astore #15
    //   1908: aload #14
    //   1910: astore #16
    //   1912: aload #4
    //   1914: aload #17
    //   1916: invokeinterface H : (Ljava/util/List;)V
    //   1921: goto -> 7
    //   1924: aload #14
    //   1926: astore #15
    //   1928: aload #14
    //   1930: astore #16
    //   1932: aload_0
    //   1933: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1936: aload_3
    //   1937: iload #10
    //   1939: invokestatic R : (I)J
    //   1942: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1945: astore #17
    //   1947: aload #14
    //   1949: astore #15
    //   1951: aload #14
    //   1953: astore #16
    //   1955: aload #4
    //   1957: aload #17
    //   1959: invokeinterface s : (Ljava/util/List;)V
    //   1964: goto -> 7
    //   1967: aload #14
    //   1969: astore #15
    //   1971: aload #14
    //   1973: astore #16
    //   1975: aload_0
    //   1976: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   1979: aload_3
    //   1980: iload #10
    //   1982: invokestatic R : (I)J
    //   1985: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   1988: astore #17
    //   1990: aload #14
    //   1992: astore #15
    //   1994: aload #14
    //   1996: astore #16
    //   1998: aload #4
    //   2000: aload #17
    //   2002: invokeinterface C : (Ljava/util/List;)V
    //   2007: goto -> 7
    //   2010: aload #14
    //   2012: astore #15
    //   2014: aload #14
    //   2016: astore #16
    //   2018: aload_0
    //   2019: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2022: aload_3
    //   2023: iload #10
    //   2025: invokestatic R : (I)J
    //   2028: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2031: astore #17
    //   2033: aload #14
    //   2035: astore #15
    //   2037: aload #14
    //   2039: astore #16
    //   2041: aload #4
    //   2043: aload #17
    //   2045: invokeinterface v : (Ljava/util/List;)V
    //   2050: goto -> 7
    //   2053: aload #14
    //   2055: astore #15
    //   2057: aload #14
    //   2059: astore #16
    //   2061: aload_0
    //   2062: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2065: aload_3
    //   2066: iload #10
    //   2068: invokestatic R : (I)J
    //   2071: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2074: astore #17
    //   2076: aload #14
    //   2078: astore #15
    //   2080: aload #14
    //   2082: astore #16
    //   2084: aload #4
    //   2086: aload #17
    //   2088: invokeinterface B : (Ljava/util/List;)V
    //   2093: goto -> 7
    //   2096: aload #14
    //   2098: astore #15
    //   2100: aload #14
    //   2102: astore #16
    //   2104: aload_0
    //   2105: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2108: aload_3
    //   2109: iload #10
    //   2111: invokestatic R : (I)J
    //   2114: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2117: astore #17
    //   2119: goto -> 1479
    //   2122: aload #14
    //   2124: astore #15
    //   2126: aload #14
    //   2128: astore #16
    //   2130: aload_0
    //   2131: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2134: aload_3
    //   2135: iload #10
    //   2137: invokestatic R : (I)J
    //   2140: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2143: astore #17
    //   2145: goto -> 1522
    //   2148: aload #14
    //   2150: astore #15
    //   2152: aload #14
    //   2154: astore #16
    //   2156: aload_0
    //   2157: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2160: aload_3
    //   2161: iload #10
    //   2163: invokestatic R : (I)J
    //   2166: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2169: astore #17
    //   2171: goto -> 1565
    //   2174: aload #14
    //   2176: astore #15
    //   2178: aload #14
    //   2180: astore #16
    //   2182: aload_0
    //   2183: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2186: aload_3
    //   2187: iload #10
    //   2189: invokestatic R : (I)J
    //   2192: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2195: astore #17
    //   2197: goto -> 1608
    //   2200: aload #14
    //   2202: astore #15
    //   2204: aload #14
    //   2206: astore #16
    //   2208: aload_0
    //   2209: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2212: aload_3
    //   2213: iload #10
    //   2215: invokestatic R : (I)J
    //   2218: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2221: astore #17
    //   2223: aload #14
    //   2225: astore #15
    //   2227: aload #14
    //   2229: astore #16
    //   2231: aload #4
    //   2233: aload #17
    //   2235: invokeinterface I : (Ljava/util/List;)V
    //   2240: aload #14
    //   2242: astore #15
    //   2244: aload #14
    //   2246: astore #16
    //   2248: aload_0
    //   2249: iload #9
    //   2251: invokespecial q : (I)Landroidx/datastore/preferences/protobuf/a0$e;
    //   2254: astore #19
    //   2256: goto -> 1684
    //   2259: aload #14
    //   2261: astore #15
    //   2263: aload #14
    //   2265: astore #16
    //   2267: aload_0
    //   2268: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2271: aload_3
    //   2272: iload #10
    //   2274: invokestatic R : (I)J
    //   2277: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2280: astore #17
    //   2282: goto -> 1732
    //   2285: aload #14
    //   2287: astore #15
    //   2289: aload #14
    //   2291: astore #16
    //   2293: aload #4
    //   2295: aload_0
    //   2296: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2299: aload_3
    //   2300: iload #10
    //   2302: invokestatic R : (I)J
    //   2305: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2308: invokeinterface A : (Ljava/util/List;)V
    //   2313: goto -> 7
    //   2316: aload #14
    //   2318: astore #15
    //   2320: aload #14
    //   2322: astore #16
    //   2324: aload_0
    //   2325: aload_3
    //   2326: iload #10
    //   2328: aload #4
    //   2330: aload_0
    //   2331: iload #9
    //   2333: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2336: aload #5
    //   2338: invokespecial a0 : (Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/f1;Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)V
    //   2341: goto -> 7
    //   2344: aload #14
    //   2346: astore #15
    //   2348: aload #14
    //   2350: astore #16
    //   2352: aload_0
    //   2353: aload_3
    //   2354: iload #10
    //   2356: aload #4
    //   2358: invokespecial c0 : (Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/f1;)V
    //   2361: goto -> 7
    //   2364: aload #14
    //   2366: astore #15
    //   2368: aload #14
    //   2370: astore #16
    //   2372: aload_0
    //   2373: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2376: aload_3
    //   2377: iload #10
    //   2379: invokestatic R : (I)J
    //   2382: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2385: astore #17
    //   2387: goto -> 1775
    //   2390: aload #14
    //   2392: astore #15
    //   2394: aload #14
    //   2396: astore #16
    //   2398: aload_0
    //   2399: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2402: aload_3
    //   2403: iload #10
    //   2405: invokestatic R : (I)J
    //   2408: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2411: astore #17
    //   2413: goto -> 1818
    //   2416: aload #14
    //   2418: astore #15
    //   2420: aload #14
    //   2422: astore #16
    //   2424: aload_0
    //   2425: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2428: aload_3
    //   2429: iload #10
    //   2431: invokestatic R : (I)J
    //   2434: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2437: astore #17
    //   2439: goto -> 1861
    //   2442: aload #14
    //   2444: astore #15
    //   2446: aload #14
    //   2448: astore #16
    //   2450: aload_0
    //   2451: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2454: aload_3
    //   2455: iload #10
    //   2457: invokestatic R : (I)J
    //   2460: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2463: astore #17
    //   2465: goto -> 1904
    //   2468: aload #14
    //   2470: astore #15
    //   2472: aload #14
    //   2474: astore #16
    //   2476: aload_0
    //   2477: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2480: aload_3
    //   2481: iload #10
    //   2483: invokestatic R : (I)J
    //   2486: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2489: astore #17
    //   2491: goto -> 1947
    //   2494: aload #14
    //   2496: astore #15
    //   2498: aload #14
    //   2500: astore #16
    //   2502: aload_0
    //   2503: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2506: aload_3
    //   2507: iload #10
    //   2509: invokestatic R : (I)J
    //   2512: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2515: astore #17
    //   2517: goto -> 1990
    //   2520: aload #14
    //   2522: astore #15
    //   2524: aload #14
    //   2526: astore #16
    //   2528: aload_0
    //   2529: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2532: aload_3
    //   2533: iload #10
    //   2535: invokestatic R : (I)J
    //   2538: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2541: astore #17
    //   2543: goto -> 2033
    //   2546: aload #14
    //   2548: astore #15
    //   2550: aload #14
    //   2552: astore #16
    //   2554: aload_0
    //   2555: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   2558: aload_3
    //   2559: iload #10
    //   2561: invokestatic R : (I)J
    //   2564: invokevirtual e : (Ljava/lang/Object;J)Ljava/util/List;
    //   2567: astore #17
    //   2569: goto -> 2076
    //   2572: aload #14
    //   2574: astore #15
    //   2576: aload #14
    //   2578: astore #16
    //   2580: aload_0
    //   2581: aload_3
    //   2582: iload #9
    //   2584: invokespecial y : (Ljava/lang/Object;I)Z
    //   2587: ifeq -> 2661
    //   2590: aload #14
    //   2592: astore #15
    //   2594: aload #14
    //   2596: astore #16
    //   2598: aload_3
    //   2599: iload #10
    //   2601: invokestatic R : (I)J
    //   2604: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2607: aload #4
    //   2609: aload_0
    //   2610: iload #9
    //   2612: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2615: aload #5
    //   2617: invokeinterface P : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   2622: invokestatic h : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2625: astore #17
    //   2627: aload #14
    //   2629: astore #15
    //   2631: aload #14
    //   2633: astore #16
    //   2635: iload #10
    //   2637: invokestatic R : (I)J
    //   2640: lstore #12
    //   2642: aload #14
    //   2644: astore #15
    //   2646: aload #14
    //   2648: astore #16
    //   2650: aload_3
    //   2651: lload #12
    //   2653: aload #17
    //   2655: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   2658: goto -> 7
    //   2661: aload #14
    //   2663: astore #15
    //   2665: aload #14
    //   2667: astore #16
    //   2669: aload_3
    //   2670: iload #10
    //   2672: invokestatic R : (I)J
    //   2675: aload #4
    //   2677: aload_0
    //   2678: iload #9
    //   2680: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2683: aload #5
    //   2685: invokeinterface P : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   2690: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   2693: aload #14
    //   2695: astore #15
    //   2697: aload #14
    //   2699: astore #16
    //   2701: aload_0
    //   2702: aload_3
    //   2703: iload #9
    //   2705: invokespecial e0 : (Ljava/lang/Object;I)V
    //   2708: goto -> 7
    //   2711: aload #14
    //   2713: astore #15
    //   2715: aload #14
    //   2717: astore #16
    //   2719: aload_3
    //   2720: iload #10
    //   2722: invokestatic R : (I)J
    //   2725: aload #4
    //   2727: invokeinterface j : ()J
    //   2732: invokestatic N : (Ljava/lang/Object;JJ)V
    //   2735: goto -> 2693
    //   2738: aload #14
    //   2740: astore #15
    //   2742: aload #14
    //   2744: astore #16
    //   2746: aload_3
    //   2747: iload #10
    //   2749: invokestatic R : (I)J
    //   2752: aload #4
    //   2754: invokeinterface h : ()I
    //   2759: invokestatic M : (Ljava/lang/Object;JI)V
    //   2762: goto -> 2693
    //   2765: aload #14
    //   2767: astore #15
    //   2769: aload #14
    //   2771: astore #16
    //   2773: aload_3
    //   2774: iload #10
    //   2776: invokestatic R : (I)J
    //   2779: aload #4
    //   2781: invokeinterface r : ()J
    //   2786: invokestatic N : (Ljava/lang/Object;JJ)V
    //   2789: goto -> 2693
    //   2792: aload #14
    //   2794: astore #15
    //   2796: aload #14
    //   2798: astore #16
    //   2800: aload_3
    //   2801: iload #10
    //   2803: invokestatic R : (I)J
    //   2806: aload #4
    //   2808: invokeinterface z : ()I
    //   2813: invokestatic M : (Ljava/lang/Object;JI)V
    //   2816: goto -> 2693
    //   2819: aload #14
    //   2821: astore #15
    //   2823: aload #14
    //   2825: astore #16
    //   2827: aload #4
    //   2829: invokeinterface b : ()I
    //   2834: istore #7
    //   2836: aload #14
    //   2838: astore #15
    //   2840: aload #14
    //   2842: astore #16
    //   2844: aload_0
    //   2845: iload #9
    //   2847: invokespecial q : (I)Landroidx/datastore/preferences/protobuf/a0$e;
    //   2850: astore #17
    //   2852: aload #17
    //   2854: ifnull -> 2881
    //   2857: iload #7
    //   2859: istore #6
    //   2861: aload #14
    //   2863: astore #15
    //   2865: aload #14
    //   2867: astore #16
    //   2869: aload #17
    //   2871: iload #7
    //   2873: invokeinterface a : (I)Z
    //   2878: ifeq -> 903
    //   2881: aload #14
    //   2883: astore #15
    //   2885: aload #14
    //   2887: astore #16
    //   2889: aload_3
    //   2890: iload #10
    //   2892: invokestatic R : (I)J
    //   2895: iload #7
    //   2897: invokestatic M : (Ljava/lang/Object;JI)V
    //   2900: goto -> 2693
    //   2903: aload #14
    //   2905: astore #15
    //   2907: aload #14
    //   2909: astore #16
    //   2911: aload_3
    //   2912: iload #10
    //   2914: invokestatic R : (I)J
    //   2917: aload #4
    //   2919: invokeinterface w : ()I
    //   2924: invokestatic M : (Ljava/lang/Object;JI)V
    //   2927: goto -> 2693
    //   2930: aload #14
    //   2932: astore #15
    //   2934: aload #14
    //   2936: astore #16
    //   2938: aload_3
    //   2939: iload #10
    //   2941: invokestatic R : (I)J
    //   2944: aload #4
    //   2946: invokeinterface u : ()Landroidx/datastore/preferences/protobuf/h;
    //   2951: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   2954: goto -> 2693
    //   2957: aload #14
    //   2959: astore #15
    //   2961: aload #14
    //   2963: astore #16
    //   2965: aload_0
    //   2966: aload_3
    //   2967: iload #9
    //   2969: invokespecial y : (Ljava/lang/Object;I)Z
    //   2972: ifeq -> 3030
    //   2975: aload #14
    //   2977: astore #15
    //   2979: aload #14
    //   2981: astore #16
    //   2983: aload_3
    //   2984: iload #10
    //   2986: invokestatic R : (I)J
    //   2989: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2992: aload #4
    //   2994: aload_0
    //   2995: iload #9
    //   2997: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   3000: aload #5
    //   3002: invokeinterface J : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   3007: invokestatic h : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   3010: astore #17
    //   3012: aload #14
    //   3014: astore #15
    //   3016: aload #14
    //   3018: astore #16
    //   3020: iload #10
    //   3022: invokestatic R : (I)J
    //   3025: lstore #12
    //   3027: goto -> 2642
    //   3030: aload #14
    //   3032: astore #15
    //   3034: aload #14
    //   3036: astore #16
    //   3038: aload_3
    //   3039: iload #10
    //   3041: invokestatic R : (I)J
    //   3044: aload #4
    //   3046: aload_0
    //   3047: iload #9
    //   3049: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   3052: aload #5
    //   3054: invokeinterface J : (Landroidx/datastore/preferences/protobuf/g1;Landroidx/datastore/preferences/protobuf/p;)Ljava/lang/Object;
    //   3059: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   3062: goto -> 2693
    //   3065: aload #14
    //   3067: astore #15
    //   3069: aload #14
    //   3071: astore #16
    //   3073: aload_0
    //   3074: aload_3
    //   3075: iload #10
    //   3077: aload #4
    //   3079: invokespecial b0 : (Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/f1;)V
    //   3082: goto -> 2693
    //   3085: aload #14
    //   3087: astore #15
    //   3089: aload #14
    //   3091: astore #16
    //   3093: aload_3
    //   3094: iload #10
    //   3096: invokestatic R : (I)J
    //   3099: aload #4
    //   3101: invokeinterface o : ()Z
    //   3106: invokestatic E : (Ljava/lang/Object;JZ)V
    //   3109: goto -> 2693
    //   3112: aload #14
    //   3114: astore #15
    //   3116: aload #14
    //   3118: astore #16
    //   3120: aload_3
    //   3121: iload #10
    //   3123: invokestatic R : (I)J
    //   3126: aload #4
    //   3128: invokeinterface n : ()I
    //   3133: invokestatic M : (Ljava/lang/Object;JI)V
    //   3136: goto -> 2693
    //   3139: aload #14
    //   3141: astore #15
    //   3143: aload #14
    //   3145: astore #16
    //   3147: aload_3
    //   3148: iload #10
    //   3150: invokestatic R : (I)J
    //   3153: aload #4
    //   3155: invokeinterface f : ()J
    //   3160: invokestatic N : (Ljava/lang/Object;JJ)V
    //   3163: goto -> 2693
    //   3166: aload #14
    //   3168: astore #15
    //   3170: aload #14
    //   3172: astore #16
    //   3174: aload_3
    //   3175: iload #10
    //   3177: invokestatic R : (I)J
    //   3180: aload #4
    //   3182: invokeinterface x : ()I
    //   3187: invokestatic M : (Ljava/lang/Object;JI)V
    //   3190: goto -> 2693
    //   3193: aload #14
    //   3195: astore #15
    //   3197: aload #14
    //   3199: astore #16
    //   3201: aload_3
    //   3202: iload #10
    //   3204: invokestatic R : (I)J
    //   3207: aload #4
    //   3209: invokeinterface d : ()J
    //   3214: invokestatic N : (Ljava/lang/Object;JJ)V
    //   3217: goto -> 2693
    //   3220: aload #14
    //   3222: astore #15
    //   3224: aload #14
    //   3226: astore #16
    //   3228: aload_3
    //   3229: iload #10
    //   3231: invokestatic R : (I)J
    //   3234: aload #4
    //   3236: invokeinterface E : ()J
    //   3241: invokestatic N : (Ljava/lang/Object;JJ)V
    //   3244: goto -> 2693
    //   3247: aload #14
    //   3249: astore #15
    //   3251: aload #14
    //   3253: astore #16
    //   3255: aload_3
    //   3256: iload #10
    //   3258: invokestatic R : (I)J
    //   3261: aload #4
    //   3263: invokeinterface readFloat : ()F
    //   3268: invokestatic L : (Ljava/lang/Object;JF)V
    //   3271: goto -> 2693
    //   3274: aload #14
    //   3276: astore #15
    //   3278: aload #14
    //   3280: astore #16
    //   3282: aload_3
    //   3283: iload #10
    //   3285: invokestatic R : (I)J
    //   3288: aload #4
    //   3290: invokeinterface readDouble : ()D
    //   3295: invokestatic K : (Ljava/lang/Object;JD)V
    //   3298: goto -> 2693
    //   3301: aload #17
    //   3303: astore #15
    //   3305: aload #17
    //   3307: astore #16
    //   3309: aload_1
    //   3310: aload #17
    //   3312: aload #4
    //   3314: invokevirtual m : (Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/f1;)Z
    //   3317: istore #11
    //   3319: aload #17
    //   3321: astore #14
    //   3323: iload #11
    //   3325: ifne -> 7
    //   3328: aload_0
    //   3329: getfield k : I
    //   3332: istore #6
    //   3334: iload #6
    //   3336: aload_0
    //   3337: getfield l : I
    //   3340: if_icmpge -> 3369
    //   3343: aload_0
    //   3344: aload_3
    //   3345: aload_0
    //   3346: getfield j : [I
    //   3349: iload #6
    //   3351: iaload
    //   3352: aload #17
    //   3354: aload_1
    //   3355: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   3358: astore #17
    //   3360: iload #6
    //   3362: iconst_1
    //   3363: iadd
    //   3364: istore #6
    //   3366: goto -> 3334
    //   3369: aload #17
    //   3371: ifnull -> 3381
    //   3374: aload_1
    //   3375: aload_3
    //   3376: aload #17
    //   3378: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   3381: return
    //   3382: aload #16
    //   3384: astore #15
    //   3386: aload_1
    //   3387: aload #4
    //   3389: invokevirtual q : (Landroidx/datastore/preferences/protobuf/f1;)Z
    //   3392: ifeq -> 3471
    //   3395: aload #16
    //   3397: astore #15
    //   3399: aload #4
    //   3401: invokeinterface y : ()Z
    //   3406: istore #11
    //   3408: aload #16
    //   3410: astore #14
    //   3412: iload #11
    //   3414: ifne -> 7
    //   3417: aload_0
    //   3418: getfield k : I
    //   3421: istore #6
    //   3423: iload #6
    //   3425: aload_0
    //   3426: getfield l : I
    //   3429: if_icmpge -> 3458
    //   3432: aload_0
    //   3433: aload_3
    //   3434: aload_0
    //   3435: getfield j : [I
    //   3438: iload #6
    //   3440: iaload
    //   3441: aload #16
    //   3443: aload_1
    //   3444: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   3447: astore #16
    //   3449: iload #6
    //   3451: iconst_1
    //   3452: iadd
    //   3453: istore #6
    //   3455: goto -> 3423
    //   3458: aload #16
    //   3460: ifnull -> 3470
    //   3463: aload_1
    //   3464: aload_3
    //   3465: aload #16
    //   3467: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   3470: return
    //   3471: aload #16
    //   3473: astore #17
    //   3475: aload #16
    //   3477: ifnonnull -> 3491
    //   3480: aload #16
    //   3482: astore #15
    //   3484: aload_1
    //   3485: aload_3
    //   3486: invokevirtual f : (Ljava/lang/Object;)Ljava/lang/Object;
    //   3489: astore #17
    //   3491: aload #17
    //   3493: astore #15
    //   3495: aload_1
    //   3496: aload #17
    //   3498: aload #4
    //   3500: invokevirtual m : (Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/f1;)Z
    //   3503: istore #11
    //   3505: aload #17
    //   3507: astore #14
    //   3509: iload #11
    //   3511: ifne -> 7
    //   3514: aload_0
    //   3515: getfield k : I
    //   3518: istore #6
    //   3520: iload #6
    //   3522: aload_0
    //   3523: getfield l : I
    //   3526: if_icmpge -> 3555
    //   3529: aload_0
    //   3530: aload_3
    //   3531: aload_0
    //   3532: getfield j : [I
    //   3535: iload #6
    //   3537: iaload
    //   3538: aload #17
    //   3540: aload_1
    //   3541: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   3544: astore #17
    //   3546: iload #6
    //   3548: iconst_1
    //   3549: iadd
    //   3550: istore #6
    //   3552: goto -> 3520
    //   3555: aload #17
    //   3557: ifnull -> 3567
    //   3560: aload_1
    //   3561: aload_3
    //   3562: aload #17
    //   3564: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   3567: return
    //   3568: astore_2
    //   3569: aload_0
    //   3570: getfield k : I
    //   3573: istore #6
    //   3575: iload #6
    //   3577: aload_0
    //   3578: getfield l : I
    //   3581: if_icmpge -> 3610
    //   3584: aload_0
    //   3585: aload_3
    //   3586: aload_0
    //   3587: getfield j : [I
    //   3590: iload #6
    //   3592: iaload
    //   3593: aload #15
    //   3595: aload_1
    //   3596: invokespecial n : (Ljava/lang/Object;ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/n1;)Ljava/lang/Object;
    //   3599: astore #15
    //   3601: iload #6
    //   3603: iconst_1
    //   3604: iadd
    //   3605: istore #6
    //   3607: goto -> 3575
    //   3610: aload #15
    //   3612: ifnull -> 3622
    //   3615: aload_1
    //   3616: aload_3
    //   3617: aload #15
    //   3619: invokevirtual o : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   3622: aload_2
    //   3623: athrow
    //   3624: astore #14
    //   3626: goto -> 3382
    //   3629: goto -> 640
    //   3632: goto -> 3301
    // Exception table:
    //   from	to	target	type
    //   11	20	3568	finally
    //   24	32	3568	finally
    //   102	109	3568	finally
    //   119	133	3568	finally
    //   151	158	3568	finally
    //   162	179	3568	finally
    //   190	199	3568	finally
    //   207	217	3568	finally
    //   233	240	3568	finally
    //   244	254	3568	finally
    //   328	336	3568	finally
    //   344	640	3624	androidx/datastore/preferences/protobuf/b0$a
    //   344	640	3568	finally
    //   657	663	3624	androidx/datastore/preferences/protobuf/b0$a
    //   657	663	3568	finally
    //   674	698	3624	androidx/datastore/preferences/protobuf/b0$a
    //   674	698	3568	finally
    //   706	715	3624	androidx/datastore/preferences/protobuf/b0$a
    //   706	715	3568	finally
    //   726	745	3624	androidx/datastore/preferences/protobuf/b0$a
    //   726	745	3568	finally
    //   756	775	3624	androidx/datastore/preferences/protobuf/b0$a
    //   756	775	3568	finally
    //   786	805	3624	androidx/datastore/preferences/protobuf/b0$a
    //   786	805	3568	finally
    //   816	835	3624	androidx/datastore/preferences/protobuf/b0$a
    //   816	835	3568	finally
    //   846	855	3624	androidx/datastore/preferences/protobuf/b0$a
    //   846	855	3568	finally
    //   863	871	3624	androidx/datastore/preferences/protobuf/b0$a
    //   863	871	3568	finally
    //   888	900	3624	androidx/datastore/preferences/protobuf/b0$a
    //   888	900	3568	finally
    //   911	923	3624	androidx/datastore/preferences/protobuf/b0$a
    //   911	923	3568	finally
    //   934	948	3624	androidx/datastore/preferences/protobuf/b0$a
    //   934	948	3568	finally
    //   959	978	3624	androidx/datastore/preferences/protobuf/b0$a
    //   959	978	3568	finally
    //   989	1005	3624	androidx/datastore/preferences/protobuf/b0$a
    //   989	1005	3568	finally
    //   1016	1028	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1016	1028	3568	finally
    //   1036	1065	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1036	1065	3568	finally
    //   1073	1084	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1073	1084	3568	finally
    //   1095	1119	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1095	1119	3568	finally
    //   1127	1134	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1127	1134	3568	finally
    //   1145	1154	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1145	1154	3568	finally
    //   1165	1184	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1165	1184	3568	finally
    //   1195	1214	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1195	1214	3568	finally
    //   1225	1244	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1225	1244	3568	finally
    //   1255	1274	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1255	1274	3568	finally
    //   1285	1304	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1285	1304	3568	finally
    //   1315	1334	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1315	1334	3568	finally
    //   1345	1364	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1345	1364	3568	finally
    //   1375	1394	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1375	1394	3568	finally
    //   1405	1422	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1405	1422	3568	finally
    //   1433	1453	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1433	1453	3568	finally
    //   1464	1479	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1464	1479	3568	finally
    //   1487	1496	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1487	1496	3568	finally
    //   1507	1522	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1507	1522	3568	finally
    //   1530	1539	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1530	1539	3568	finally
    //   1550	1565	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1550	1565	3568	finally
    //   1573	1582	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1573	1582	3568	finally
    //   1593	1608	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1593	1608	3568	finally
    //   1616	1625	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1616	1625	3568	finally
    //   1636	1651	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1636	1651	3568	finally
    //   1659	1668	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1659	1668	3568	finally
    //   1676	1684	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1676	1684	3568	finally
    //   1692	1706	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1692	1706	3568	finally
    //   1717	1732	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1717	1732	3568	finally
    //   1740	1749	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1740	1749	3568	finally
    //   1760	1775	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1760	1775	3568	finally
    //   1783	1792	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1783	1792	3568	finally
    //   1803	1818	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1803	1818	3568	finally
    //   1826	1835	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1826	1835	3568	finally
    //   1846	1861	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1846	1861	3568	finally
    //   1869	1878	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1869	1878	3568	finally
    //   1889	1904	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1889	1904	3568	finally
    //   1912	1921	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1912	1921	3568	finally
    //   1932	1947	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1932	1947	3568	finally
    //   1955	1964	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1955	1964	3568	finally
    //   1975	1990	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1975	1990	3568	finally
    //   1998	2007	3624	androidx/datastore/preferences/protobuf/b0$a
    //   1998	2007	3568	finally
    //   2018	2033	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2018	2033	3568	finally
    //   2041	2050	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2041	2050	3568	finally
    //   2061	2076	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2061	2076	3568	finally
    //   2084	2093	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2084	2093	3568	finally
    //   2104	2119	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2104	2119	3568	finally
    //   2130	2145	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2130	2145	3568	finally
    //   2156	2171	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2156	2171	3568	finally
    //   2182	2197	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2182	2197	3568	finally
    //   2208	2223	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2208	2223	3568	finally
    //   2231	2240	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2231	2240	3568	finally
    //   2248	2256	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2248	2256	3568	finally
    //   2267	2282	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2267	2282	3568	finally
    //   2293	2313	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2293	2313	3568	finally
    //   2324	2341	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2324	2341	3568	finally
    //   2352	2361	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2352	2361	3568	finally
    //   2372	2387	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2372	2387	3568	finally
    //   2398	2413	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2398	2413	3568	finally
    //   2424	2439	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2424	2439	3568	finally
    //   2450	2465	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2450	2465	3568	finally
    //   2476	2491	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2476	2491	3568	finally
    //   2502	2517	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2502	2517	3568	finally
    //   2528	2543	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2528	2543	3568	finally
    //   2554	2569	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2554	2569	3568	finally
    //   2580	2590	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2580	2590	3568	finally
    //   2598	2627	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2598	2627	3568	finally
    //   2635	2642	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2635	2642	3568	finally
    //   2650	2658	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2650	2658	3568	finally
    //   2669	2693	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2669	2693	3568	finally
    //   2701	2708	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2701	2708	3568	finally
    //   2719	2735	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2719	2735	3568	finally
    //   2746	2762	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2746	2762	3568	finally
    //   2773	2789	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2773	2789	3568	finally
    //   2800	2816	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2800	2816	3568	finally
    //   2827	2836	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2827	2836	3568	finally
    //   2844	2852	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2844	2852	3568	finally
    //   2869	2881	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2869	2881	3568	finally
    //   2889	2900	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2889	2900	3568	finally
    //   2911	2927	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2911	2927	3568	finally
    //   2938	2954	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2938	2954	3568	finally
    //   2965	2975	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2965	2975	3568	finally
    //   2983	3012	3624	androidx/datastore/preferences/protobuf/b0$a
    //   2983	3012	3568	finally
    //   3020	3027	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3020	3027	3568	finally
    //   3038	3062	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3038	3062	3568	finally
    //   3073	3082	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3073	3082	3568	finally
    //   3093	3109	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3093	3109	3568	finally
    //   3120	3136	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3120	3136	3568	finally
    //   3147	3163	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3147	3163	3568	finally
    //   3174	3190	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3174	3190	3568	finally
    //   3201	3217	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3201	3217	3568	finally
    //   3228	3244	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3228	3244	3568	finally
    //   3255	3271	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3255	3271	3568	finally
    //   3282	3298	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3282	3298	3568	finally
    //   3309	3319	3624	androidx/datastore/preferences/protobuf/b0$a
    //   3309	3319	3568	finally
    //   3386	3395	3568	finally
    //   3399	3408	3568	finally
    //   3484	3491	3568	finally
    //   3495	3505	3568	finally
  }
  
  private final <K, V> void J(Object paramObject1, int paramInt, Object paramObject2, p paramp, f1 paramf1) {
    Object object1;
    long l = R(i0(paramInt));
    Object object2 = r1.A(paramObject1, l);
    if (object2 == null) {
      object1 = this.q.b(paramObject2);
      r1.O(paramObject1, l, object1);
    } else {
      object1 = object2;
      if (this.q.d(object2)) {
        object1 = this.q.b(paramObject2);
        this.q.a(object1, object2);
        r1.O(paramObject1, l, object1);
      } 
    } 
    paramf1.K(this.q.h(object1), this.q.f(paramObject2), paramp);
  }
  
  private void K(T paramT1, T paramT2, int paramInt) {
    long l = R(i0(paramInt));
    if (!y(paramT2, paramInt))
      return; 
    Object object = r1.A(paramT1, l);
    paramT2 = (T)r1.A(paramT2, l);
    if (object != null && paramT2 != null) {
      paramT2 = (T)a0.h(object, paramT2);
    } else {
      if (paramT2 != null) {
        r1.O(paramT1, l, paramT2);
        e0(paramT1, paramInt);
        return;
      } 
      return;
    } 
    r1.O(paramT1, l, paramT2);
    e0(paramT1, paramInt);
  }
  
  private void L(T paramT1, T paramT2, int paramInt) {
    int i = i0(paramInt);
    int j = Q(paramInt);
    long l = R(i);
    if (!E(paramT2, j, paramInt))
      return; 
    Object object = r1.A(paramT1, l);
    paramT2 = (T)r1.A(paramT2, l);
    if (object != null && paramT2 != null) {
      paramT2 = (T)a0.h(object, paramT2);
    } else {
      if (paramT2 != null) {
        r1.O(paramT1, l, paramT2);
        f0(paramT1, j, paramInt);
        return;
      } 
      return;
    } 
    r1.O(paramT1, l, paramT2);
    f0(paramT1, j, paramInt);
  }
  
  private void M(T paramT1, T paramT2, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: iload_3
    //   2: invokespecial i0 : (I)I
    //   5: istore #4
    //   7: iload #4
    //   9: invokestatic R : (I)J
    //   12: lstore #6
    //   14: aload_0
    //   15: iload_3
    //   16: invokespecial Q : (I)I
    //   19: istore #5
    //   21: iload #4
    //   23: invokestatic h0 : (I)I
    //   26: tableswitch default -> 316, 0 -> 643, 1 -> 619, 2 -> 595, 3 -> 583, 4 -> 559, 5 -> 547, 6 -> 535, 7 -> 511, 8 -> 487, 9 -> 479, 10 -> 467, 11 -> 455, 12 -> 443, 13 -> 431, 14 -> 419, 15 -> 407, 16 -> 395, 17 -> 479, 18 -> 383, 19 -> 383, 20 -> 383, 21 -> 383, 22 -> 383, 23 -> 383, 24 -> 383, 25 -> 383, 26 -> 383, 27 -> 383, 28 -> 383, 29 -> 383, 30 -> 383, 31 -> 383, 32 -> 383, 33 -> 383, 34 -> 383, 35 -> 383, 36 -> 383, 37 -> 383, 38 -> 383, 39 -> 383, 40 -> 383, 41 -> 383, 42 -> 383, 43 -> 383, 44 -> 383, 45 -> 383, 46 -> 383, 47 -> 383, 48 -> 383, 49 -> 383, 50 -> 371, 51 -> 339, 52 -> 339, 53 -> 339, 54 -> 339, 55 -> 339, 56 -> 339, 57 -> 339, 58 -> 339, 59 -> 339, 60 -> 331, 61 -> 317, 62 -> 317, 63 -> 317, 64 -> 317, 65 -> 317, 66 -> 317, 67 -> 317, 68 -> 331
    //   316: return
    //   317: aload_0
    //   318: aload_2
    //   319: iload #5
    //   321: iload_3
    //   322: invokespecial E : (Ljava/lang/Object;II)Z
    //   325: ifeq -> 670
    //   328: goto -> 350
    //   331: aload_0
    //   332: aload_1
    //   333: aload_2
    //   334: iload_3
    //   335: invokespecial L : (Ljava/lang/Object;Ljava/lang/Object;I)V
    //   338: return
    //   339: aload_0
    //   340: aload_2
    //   341: iload #5
    //   343: iload_3
    //   344: invokespecial E : (Ljava/lang/Object;II)Z
    //   347: ifeq -> 670
    //   350: aload_1
    //   351: lload #6
    //   353: aload_2
    //   354: lload #6
    //   356: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   359: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   362: aload_0
    //   363: aload_1
    //   364: iload #5
    //   366: iload_3
    //   367: invokespecial f0 : (Ljava/lang/Object;II)V
    //   370: return
    //   371: aload_0
    //   372: getfield q : Landroidx/datastore/preferences/protobuf/m0;
    //   375: aload_1
    //   376: aload_2
    //   377: lload #6
    //   379: invokestatic F : (Landroidx/datastore/preferences/protobuf/m0;Ljava/lang/Object;Ljava/lang/Object;J)V
    //   382: return
    //   383: aload_0
    //   384: getfield n : Landroidx/datastore/preferences/protobuf/h0;
    //   387: aload_1
    //   388: aload_2
    //   389: lload #6
    //   391: invokevirtual d : (Ljava/lang/Object;Ljava/lang/Object;J)V
    //   394: return
    //   395: aload_0
    //   396: aload_2
    //   397: iload_3
    //   398: invokespecial y : (Ljava/lang/Object;I)Z
    //   401: ifeq -> 670
    //   404: goto -> 604
    //   407: aload_0
    //   408: aload_2
    //   409: iload_3
    //   410: invokespecial y : (Ljava/lang/Object;I)Z
    //   413: ifeq -> 670
    //   416: goto -> 452
    //   419: aload_0
    //   420: aload_2
    //   421: iload_3
    //   422: invokespecial y : (Ljava/lang/Object;I)Z
    //   425: ifeq -> 670
    //   428: goto -> 604
    //   431: aload_0
    //   432: aload_2
    //   433: iload_3
    //   434: invokespecial y : (Ljava/lang/Object;I)Z
    //   437: ifeq -> 670
    //   440: goto -> 452
    //   443: aload_0
    //   444: aload_2
    //   445: iload_3
    //   446: invokespecial y : (Ljava/lang/Object;I)Z
    //   449: ifeq -> 670
    //   452: goto -> 568
    //   455: aload_0
    //   456: aload_2
    //   457: iload_3
    //   458: invokespecial y : (Ljava/lang/Object;I)Z
    //   461: ifeq -> 670
    //   464: goto -> 568
    //   467: aload_0
    //   468: aload_2
    //   469: iload_3
    //   470: invokespecial y : (Ljava/lang/Object;I)Z
    //   473: ifeq -> 670
    //   476: goto -> 496
    //   479: aload_0
    //   480: aload_1
    //   481: aload_2
    //   482: iload_3
    //   483: invokespecial K : (Ljava/lang/Object;Ljava/lang/Object;I)V
    //   486: return
    //   487: aload_0
    //   488: aload_2
    //   489: iload_3
    //   490: invokespecial y : (Ljava/lang/Object;I)Z
    //   493: ifeq -> 670
    //   496: aload_1
    //   497: lload #6
    //   499: aload_2
    //   500: lload #6
    //   502: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   505: invokestatic O : (Ljava/lang/Object;JLjava/lang/Object;)V
    //   508: goto -> 664
    //   511: aload_0
    //   512: aload_2
    //   513: iload_3
    //   514: invokespecial y : (Ljava/lang/Object;I)Z
    //   517: ifeq -> 670
    //   520: aload_1
    //   521: lload #6
    //   523: aload_2
    //   524: lload #6
    //   526: invokestatic p : (Ljava/lang/Object;J)Z
    //   529: invokestatic E : (Ljava/lang/Object;JZ)V
    //   532: goto -> 664
    //   535: aload_0
    //   536: aload_2
    //   537: iload_3
    //   538: invokespecial y : (Ljava/lang/Object;I)Z
    //   541: ifeq -> 670
    //   544: goto -> 568
    //   547: aload_0
    //   548: aload_2
    //   549: iload_3
    //   550: invokespecial y : (Ljava/lang/Object;I)Z
    //   553: ifeq -> 670
    //   556: goto -> 604
    //   559: aload_0
    //   560: aload_2
    //   561: iload_3
    //   562: invokespecial y : (Ljava/lang/Object;I)Z
    //   565: ifeq -> 670
    //   568: aload_1
    //   569: lload #6
    //   571: aload_2
    //   572: lload #6
    //   574: invokestatic x : (Ljava/lang/Object;J)I
    //   577: invokestatic M : (Ljava/lang/Object;JI)V
    //   580: goto -> 664
    //   583: aload_0
    //   584: aload_2
    //   585: iload_3
    //   586: invokespecial y : (Ljava/lang/Object;I)Z
    //   589: ifeq -> 670
    //   592: goto -> 604
    //   595: aload_0
    //   596: aload_2
    //   597: iload_3
    //   598: invokespecial y : (Ljava/lang/Object;I)Z
    //   601: ifeq -> 670
    //   604: aload_1
    //   605: lload #6
    //   607: aload_2
    //   608: lload #6
    //   610: invokestatic y : (Ljava/lang/Object;J)J
    //   613: invokestatic N : (Ljava/lang/Object;JJ)V
    //   616: goto -> 664
    //   619: aload_0
    //   620: aload_2
    //   621: iload_3
    //   622: invokespecial y : (Ljava/lang/Object;I)Z
    //   625: ifeq -> 670
    //   628: aload_1
    //   629: lload #6
    //   631: aload_2
    //   632: lload #6
    //   634: invokestatic w : (Ljava/lang/Object;J)F
    //   637: invokestatic L : (Ljava/lang/Object;JF)V
    //   640: goto -> 664
    //   643: aload_0
    //   644: aload_2
    //   645: iload_3
    //   646: invokespecial y : (Ljava/lang/Object;I)Z
    //   649: ifeq -> 670
    //   652: aload_1
    //   653: lload #6
    //   655: aload_2
    //   656: lload #6
    //   658: invokestatic v : (Ljava/lang/Object;J)D
    //   661: invokestatic K : (Ljava/lang/Object;JD)V
    //   664: aload_0
    //   665: aload_1
    //   666: iload_3
    //   667: invokespecial e0 : (Ljava/lang/Object;I)V
    //   670: return
  }
  
  static <T> u0<T> N(Class<T> paramClass, p0 paramp0, w0 paramw0, h0 paramh0, n1<?, ?> paramn1, q<?> paramq, m0 paramm0) {
    return (paramp0 instanceof e1) ? P((e1)paramp0, paramw0, paramh0, paramn1, paramq, paramm0) : O((k1)paramp0, paramw0, paramh0, paramn1, paramq, paramm0);
  }
  
  static <T> u0<T> O(k1 paramk1, w0 paramw0, h0 paramh0, n1<?, ?> paramn1, q<?> paramq, m0 paramm0) {
    boolean bool;
    int[] arrayOfInt;
    if (paramk1.b() == b1.b) {
      bool = true;
    } else {
      bool = false;
    } 
    t[] arrayOfT = paramk1.e();
    if (arrayOfT.length == 0) {
      int k = arrayOfT.length;
      int[] arrayOfInt1 = new int[k * 3];
      Object[] arrayOfObject = new Object[k * 2];
      if (arrayOfT.length <= 0) {
        int[] arrayOfInt3 = paramk1.d();
        int[] arrayOfInt2 = arrayOfInt3;
        if (arrayOfInt3 == null)
          arrayOfInt2 = r; 
        if (arrayOfT.length <= 0) {
          arrayOfInt3 = r;
          arrayOfInt = r;
          int[] arrayOfInt4 = new int[arrayOfInt2.length + arrayOfInt3.length + arrayOfInt.length];
          System.arraycopy(arrayOfInt2, 0, arrayOfInt4, 0, arrayOfInt2.length);
          System.arraycopy(arrayOfInt3, 0, arrayOfInt4, arrayOfInt2.length, arrayOfInt3.length);
          System.arraycopy(arrayOfInt, 0, arrayOfInt4, arrayOfInt2.length + arrayOfInt3.length, arrayOfInt.length);
          return new u0<T>(arrayOfInt1, arrayOfObject, 0, 0, paramk1.c(), bool, true, arrayOfInt4, arrayOfInt2.length, arrayOfInt2.length + arrayOfInt3.length, paramw0, paramh0, paramn1, paramq, paramm0);
        } 
        int m = arrayOfInt[0];
        throw null;
      } 
      int j = arrayOfInt[0];
      throw null;
    } 
    int i = arrayOfInt[0];
    throw null;
  }
  
  static <T> u0<T> P(e1 parame1, w0 paramw0, h0 paramh0, n1<?, ?> paramn1, q<?> paramq, m0 paramm0) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual b : ()Landroidx/datastore/preferences/protobuf/b1;
    //   4: astore #34
    //   6: getstatic androidx/datastore/preferences/protobuf/b1.b : Landroidx/datastore/preferences/protobuf/b1;
    //   9: astore #35
    //   11: iconst_0
    //   12: istore #15
    //   14: aload #34
    //   16: aload #35
    //   18: if_acmpne -> 27
    //   21: iconst_1
    //   22: istore #33
    //   24: goto -> 30
    //   27: iconst_0
    //   28: istore #33
    //   30: aload_0
    //   31: invokevirtual e : ()Ljava/lang/String;
    //   34: astore #36
    //   36: aload #36
    //   38: invokevirtual length : ()I
    //   41: istore #18
    //   43: aload #36
    //   45: iconst_0
    //   46: invokevirtual charAt : (I)C
    //   49: istore #8
    //   51: iload #8
    //   53: ldc_w 55296
    //   56: if_icmplt -> 142
    //   59: iload #8
    //   61: sipush #8191
    //   64: iand
    //   65: istore #8
    //   67: iconst_1
    //   68: istore #9
    //   70: bipush #13
    //   72: istore #7
    //   74: iload #9
    //   76: iconst_1
    //   77: iadd
    //   78: istore #6
    //   80: aload #36
    //   82: iload #9
    //   84: invokevirtual charAt : (I)C
    //   87: istore #9
    //   89: iload #9
    //   91: ldc_w 55296
    //   94: if_icmplt -> 125
    //   97: iload #8
    //   99: iload #9
    //   101: sipush #8191
    //   104: iand
    //   105: iload #7
    //   107: ishl
    //   108: ior
    //   109: istore #8
    //   111: iload #7
    //   113: bipush #13
    //   115: iadd
    //   116: istore #7
    //   118: iload #6
    //   120: istore #9
    //   122: goto -> 74
    //   125: iload #8
    //   127: iload #9
    //   129: iload #7
    //   131: ishl
    //   132: ior
    //   133: istore #8
    //   135: iload #6
    //   137: istore #7
    //   139: goto -> 145
    //   142: iconst_1
    //   143: istore #7
    //   145: iload #7
    //   147: iconst_1
    //   148: iadd
    //   149: istore #6
    //   151: aload #36
    //   153: iload #7
    //   155: invokevirtual charAt : (I)C
    //   158: istore #10
    //   160: iload #6
    //   162: istore #9
    //   164: iload #10
    //   166: istore #7
    //   168: iload #10
    //   170: ldc_w 55296
    //   173: if_icmplt -> 257
    //   176: iload #10
    //   178: sipush #8191
    //   181: iand
    //   182: istore #9
    //   184: bipush #13
    //   186: istore #7
    //   188: iload #6
    //   190: istore #10
    //   192: iload #10
    //   194: iconst_1
    //   195: iadd
    //   196: istore #6
    //   198: aload #36
    //   200: iload #10
    //   202: invokevirtual charAt : (I)C
    //   205: istore #10
    //   207: iload #10
    //   209: ldc_w 55296
    //   212: if_icmplt -> 243
    //   215: iload #9
    //   217: iload #10
    //   219: sipush #8191
    //   222: iand
    //   223: iload #7
    //   225: ishl
    //   226: ior
    //   227: istore #9
    //   229: iload #7
    //   231: bipush #13
    //   233: iadd
    //   234: istore #7
    //   236: iload #6
    //   238: istore #10
    //   240: goto -> 192
    //   243: iload #9
    //   245: iload #10
    //   247: iload #7
    //   249: ishl
    //   250: ior
    //   251: istore #7
    //   253: iload #6
    //   255: istore #9
    //   257: iload #7
    //   259: ifne -> 288
    //   262: getstatic androidx/datastore/preferences/protobuf/u0.r : [I
    //   265: astore #35
    //   267: iconst_0
    //   268: istore #16
    //   270: iconst_0
    //   271: istore #12
    //   273: iconst_0
    //   274: istore #10
    //   276: iconst_0
    //   277: istore #14
    //   279: iconst_0
    //   280: istore #11
    //   282: iconst_0
    //   283: istore #7
    //   285: goto -> 1241
    //   288: iload #9
    //   290: iconst_1
    //   291: iadd
    //   292: istore #7
    //   294: aload #36
    //   296: iload #9
    //   298: invokevirtual charAt : (I)C
    //   301: istore #10
    //   303: iload #10
    //   305: istore #6
    //   307: iload #7
    //   309: istore #9
    //   311: iload #10
    //   313: ldc_w 55296
    //   316: if_icmplt -> 400
    //   319: iload #10
    //   321: sipush #8191
    //   324: iand
    //   325: istore #9
    //   327: bipush #13
    //   329: istore #6
    //   331: iload #7
    //   333: istore #10
    //   335: iload #10
    //   337: iconst_1
    //   338: iadd
    //   339: istore #7
    //   341: aload #36
    //   343: iload #10
    //   345: invokevirtual charAt : (I)C
    //   348: istore #10
    //   350: iload #10
    //   352: ldc_w 55296
    //   355: if_icmplt -> 386
    //   358: iload #9
    //   360: iload #10
    //   362: sipush #8191
    //   365: iand
    //   366: iload #6
    //   368: ishl
    //   369: ior
    //   370: istore #9
    //   372: iload #6
    //   374: bipush #13
    //   376: iadd
    //   377: istore #6
    //   379: iload #7
    //   381: istore #10
    //   383: goto -> 335
    //   386: iload #9
    //   388: iload #10
    //   390: iload #6
    //   392: ishl
    //   393: ior
    //   394: istore #6
    //   396: iload #7
    //   398: istore #9
    //   400: iload #9
    //   402: iconst_1
    //   403: iadd
    //   404: istore #7
    //   406: aload #36
    //   408: iload #9
    //   410: invokevirtual charAt : (I)C
    //   413: istore #9
    //   415: iload #9
    //   417: istore #14
    //   419: iload #7
    //   421: istore #10
    //   423: iload #9
    //   425: ldc_w 55296
    //   428: if_icmplt -> 512
    //   431: iload #9
    //   433: sipush #8191
    //   436: iand
    //   437: istore #10
    //   439: bipush #13
    //   441: istore #9
    //   443: iload #7
    //   445: istore #11
    //   447: iload #11
    //   449: iconst_1
    //   450: iadd
    //   451: istore #7
    //   453: aload #36
    //   455: iload #11
    //   457: invokevirtual charAt : (I)C
    //   460: istore #11
    //   462: iload #11
    //   464: ldc_w 55296
    //   467: if_icmplt -> 498
    //   470: iload #10
    //   472: iload #11
    //   474: sipush #8191
    //   477: iand
    //   478: iload #9
    //   480: ishl
    //   481: ior
    //   482: istore #10
    //   484: iload #9
    //   486: bipush #13
    //   488: iadd
    //   489: istore #9
    //   491: iload #7
    //   493: istore #11
    //   495: goto -> 447
    //   498: iload #10
    //   500: iload #11
    //   502: iload #9
    //   504: ishl
    //   505: ior
    //   506: istore #14
    //   508: iload #7
    //   510: istore #10
    //   512: iload #10
    //   514: iconst_1
    //   515: iadd
    //   516: istore #9
    //   518: aload #36
    //   520: iload #10
    //   522: invokevirtual charAt : (I)C
    //   525: istore #10
    //   527: iload #10
    //   529: istore #7
    //   531: iload #9
    //   533: istore #11
    //   535: iload #10
    //   537: ldc_w 55296
    //   540: if_icmplt -> 624
    //   543: iload #10
    //   545: sipush #8191
    //   548: iand
    //   549: istore #10
    //   551: bipush #13
    //   553: istore #7
    //   555: iload #9
    //   557: istore #11
    //   559: iload #11
    //   561: iconst_1
    //   562: iadd
    //   563: istore #9
    //   565: aload #36
    //   567: iload #11
    //   569: invokevirtual charAt : (I)C
    //   572: istore #11
    //   574: iload #11
    //   576: ldc_w 55296
    //   579: if_icmplt -> 610
    //   582: iload #10
    //   584: iload #11
    //   586: sipush #8191
    //   589: iand
    //   590: iload #7
    //   592: ishl
    //   593: ior
    //   594: istore #10
    //   596: iload #7
    //   598: bipush #13
    //   600: iadd
    //   601: istore #7
    //   603: iload #9
    //   605: istore #11
    //   607: goto -> 559
    //   610: iload #10
    //   612: iload #11
    //   614: iload #7
    //   616: ishl
    //   617: ior
    //   618: istore #7
    //   620: iload #9
    //   622: istore #11
    //   624: iload #11
    //   626: iconst_1
    //   627: iadd
    //   628: istore #10
    //   630: aload #36
    //   632: iload #11
    //   634: invokevirtual charAt : (I)C
    //   637: istore #11
    //   639: iload #11
    //   641: istore #9
    //   643: iload #10
    //   645: istore #12
    //   647: iload #11
    //   649: ldc_w 55296
    //   652: if_icmplt -> 736
    //   655: iload #11
    //   657: sipush #8191
    //   660: iand
    //   661: istore #11
    //   663: bipush #13
    //   665: istore #9
    //   667: iload #10
    //   669: istore #12
    //   671: iload #12
    //   673: iconst_1
    //   674: iadd
    //   675: istore #10
    //   677: aload #36
    //   679: iload #12
    //   681: invokevirtual charAt : (I)C
    //   684: istore #12
    //   686: iload #12
    //   688: ldc_w 55296
    //   691: if_icmplt -> 722
    //   694: iload #11
    //   696: iload #12
    //   698: sipush #8191
    //   701: iand
    //   702: iload #9
    //   704: ishl
    //   705: ior
    //   706: istore #11
    //   708: iload #9
    //   710: bipush #13
    //   712: iadd
    //   713: istore #9
    //   715: iload #10
    //   717: istore #12
    //   719: goto -> 671
    //   722: iload #11
    //   724: iload #12
    //   726: iload #9
    //   728: ishl
    //   729: ior
    //   730: istore #9
    //   732: iload #10
    //   734: istore #12
    //   736: iload #12
    //   738: iconst_1
    //   739: iadd
    //   740: istore #11
    //   742: aload #36
    //   744: iload #12
    //   746: invokevirtual charAt : (I)C
    //   749: istore #12
    //   751: iload #12
    //   753: istore #10
    //   755: iload #11
    //   757: istore #13
    //   759: iload #12
    //   761: ldc_w 55296
    //   764: if_icmplt -> 848
    //   767: iload #12
    //   769: sipush #8191
    //   772: iand
    //   773: istore #12
    //   775: bipush #13
    //   777: istore #10
    //   779: iload #11
    //   781: istore #13
    //   783: iload #13
    //   785: iconst_1
    //   786: iadd
    //   787: istore #11
    //   789: aload #36
    //   791: iload #13
    //   793: invokevirtual charAt : (I)C
    //   796: istore #13
    //   798: iload #13
    //   800: ldc_w 55296
    //   803: if_icmplt -> 834
    //   806: iload #12
    //   808: iload #13
    //   810: sipush #8191
    //   813: iand
    //   814: iload #10
    //   816: ishl
    //   817: ior
    //   818: istore #12
    //   820: iload #10
    //   822: bipush #13
    //   824: iadd
    //   825: istore #10
    //   827: iload #11
    //   829: istore #13
    //   831: goto -> 783
    //   834: iload #12
    //   836: iload #13
    //   838: iload #10
    //   840: ishl
    //   841: ior
    //   842: istore #10
    //   844: iload #11
    //   846: istore #13
    //   848: iload #13
    //   850: iconst_1
    //   851: iadd
    //   852: istore #12
    //   854: aload #36
    //   856: iload #13
    //   858: invokevirtual charAt : (I)C
    //   861: istore #15
    //   863: iload #15
    //   865: istore #11
    //   867: iload #12
    //   869: istore #13
    //   871: iload #15
    //   873: ldc_w 55296
    //   876: if_icmplt -> 960
    //   879: iload #15
    //   881: sipush #8191
    //   884: iand
    //   885: istore #13
    //   887: bipush #13
    //   889: istore #11
    //   891: iload #12
    //   893: istore #15
    //   895: iload #15
    //   897: iconst_1
    //   898: iadd
    //   899: istore #12
    //   901: aload #36
    //   903: iload #15
    //   905: invokevirtual charAt : (I)C
    //   908: istore #15
    //   910: iload #15
    //   912: ldc_w 55296
    //   915: if_icmplt -> 946
    //   918: iload #13
    //   920: iload #15
    //   922: sipush #8191
    //   925: iand
    //   926: iload #11
    //   928: ishl
    //   929: ior
    //   930: istore #13
    //   932: iload #11
    //   934: bipush #13
    //   936: iadd
    //   937: istore #11
    //   939: iload #12
    //   941: istore #15
    //   943: goto -> 895
    //   946: iload #13
    //   948: iload #15
    //   950: iload #11
    //   952: ishl
    //   953: ior
    //   954: istore #11
    //   956: iload #12
    //   958: istore #13
    //   960: iload #13
    //   962: iconst_1
    //   963: iadd
    //   964: istore #12
    //   966: aload #36
    //   968: iload #13
    //   970: invokevirtual charAt : (I)C
    //   973: istore #16
    //   975: iload #16
    //   977: istore #15
    //   979: iload #12
    //   981: istore #13
    //   983: iload #16
    //   985: ldc_w 55296
    //   988: if_icmplt -> 1072
    //   991: iload #16
    //   993: sipush #8191
    //   996: iand
    //   997: istore #15
    //   999: bipush #13
    //   1001: istore #13
    //   1003: iload #12
    //   1005: istore #16
    //   1007: iload #16
    //   1009: iconst_1
    //   1010: iadd
    //   1011: istore #12
    //   1013: aload #36
    //   1015: iload #16
    //   1017: invokevirtual charAt : (I)C
    //   1020: istore #16
    //   1022: iload #16
    //   1024: ldc_w 55296
    //   1027: if_icmplt -> 1058
    //   1030: iload #15
    //   1032: iload #16
    //   1034: sipush #8191
    //   1037: iand
    //   1038: iload #13
    //   1040: ishl
    //   1041: ior
    //   1042: istore #15
    //   1044: iload #13
    //   1046: bipush #13
    //   1048: iadd
    //   1049: istore #13
    //   1051: iload #12
    //   1053: istore #16
    //   1055: goto -> 1007
    //   1058: iload #15
    //   1060: iload #16
    //   1062: iload #13
    //   1064: ishl
    //   1065: ior
    //   1066: istore #15
    //   1068: iload #12
    //   1070: istore #13
    //   1072: iload #13
    //   1074: iconst_1
    //   1075: iadd
    //   1076: istore #16
    //   1078: aload #36
    //   1080: iload #13
    //   1082: invokevirtual charAt : (I)C
    //   1085: istore #17
    //   1087: iload #17
    //   1089: istore #12
    //   1091: iload #16
    //   1093: istore #13
    //   1095: iload #17
    //   1097: ldc_w 55296
    //   1100: if_icmplt -> 1184
    //   1103: iload #17
    //   1105: sipush #8191
    //   1108: iand
    //   1109: istore #13
    //   1111: iload #16
    //   1113: istore #17
    //   1115: bipush #13
    //   1117: istore #12
    //   1119: iload #13
    //   1121: istore #16
    //   1123: iload #17
    //   1125: iconst_1
    //   1126: iadd
    //   1127: istore #13
    //   1129: aload #36
    //   1131: iload #17
    //   1133: invokevirtual charAt : (I)C
    //   1136: istore #17
    //   1138: iload #17
    //   1140: ldc_w 55296
    //   1143: if_icmplt -> 1174
    //   1146: iload #16
    //   1148: iload #17
    //   1150: sipush #8191
    //   1153: iand
    //   1154: iload #12
    //   1156: ishl
    //   1157: ior
    //   1158: istore #16
    //   1160: iload #12
    //   1162: bipush #13
    //   1164: iadd
    //   1165: istore #12
    //   1167: iload #13
    //   1169: istore #17
    //   1171: goto -> 1123
    //   1174: iload #16
    //   1176: iload #17
    //   1178: iload #12
    //   1180: ishl
    //   1181: ior
    //   1182: istore #12
    //   1184: iload #12
    //   1186: iload #11
    //   1188: iadd
    //   1189: iload #15
    //   1191: iadd
    //   1192: newarray int
    //   1194: astore #35
    //   1196: iload #6
    //   1198: iconst_2
    //   1199: imul
    //   1200: iload #14
    //   1202: iadd
    //   1203: istore #14
    //   1205: iload #7
    //   1207: istore #15
    //   1209: iload #11
    //   1211: istore #16
    //   1213: iload #12
    //   1215: istore #7
    //   1217: iload #14
    //   1219: istore #11
    //   1221: iload #10
    //   1223: istore #14
    //   1225: iload #9
    //   1227: istore #10
    //   1229: iload #16
    //   1231: istore #12
    //   1233: iload #6
    //   1235: istore #16
    //   1237: iload #13
    //   1239: istore #9
    //   1241: getstatic androidx/datastore/preferences/protobuf/u0.s : Lsun/misc/Unsafe;
    //   1244: astore #39
    //   1246: aload_0
    //   1247: invokevirtual d : ()[Ljava/lang/Object;
    //   1250: astore #40
    //   1252: aload_0
    //   1253: invokevirtual c : ()Landroidx/datastore/preferences/protobuf/r0;
    //   1256: invokevirtual getClass : ()Ljava/lang/Class;
    //   1259: astore #37
    //   1261: iload #14
    //   1263: iconst_3
    //   1264: imul
    //   1265: newarray int
    //   1267: astore #34
    //   1269: iload #14
    //   1271: iconst_2
    //   1272: imul
    //   1273: anewarray java/lang/Object
    //   1276: astore #41
    //   1278: iload #7
    //   1280: iload #12
    //   1282: iadd
    //   1283: istore #31
    //   1285: iload #7
    //   1287: istore #6
    //   1289: iload #31
    //   1291: istore #21
    //   1293: iconst_0
    //   1294: istore #12
    //   1296: iconst_0
    //   1297: istore #20
    //   1299: iload #10
    //   1301: istore #17
    //   1303: iload #8
    //   1305: istore #19
    //   1307: iload #9
    //   1309: iload #18
    //   1311: if_icmpge -> 2706
    //   1314: iload #9
    //   1316: iconst_1
    //   1317: iadd
    //   1318: istore #8
    //   1320: aload #36
    //   1322: iload #9
    //   1324: invokevirtual charAt : (I)C
    //   1327: istore #22
    //   1329: iload #22
    //   1331: ldc_w 55296
    //   1334: if_icmplt -> 1429
    //   1337: iload #22
    //   1339: sipush #8191
    //   1342: iand
    //   1343: istore #10
    //   1345: iload #8
    //   1347: istore #9
    //   1349: bipush #13
    //   1351: istore #8
    //   1353: iload #9
    //   1355: iconst_1
    //   1356: iadd
    //   1357: istore #13
    //   1359: aload #36
    //   1361: iload #9
    //   1363: invokevirtual charAt : (I)C
    //   1366: istore #14
    //   1368: iload #7
    //   1370: istore #9
    //   1372: iload #14
    //   1374: ldc_w 55296
    //   1377: if_icmplt -> 1412
    //   1380: iload #10
    //   1382: iload #14
    //   1384: sipush #8191
    //   1387: iand
    //   1388: iload #8
    //   1390: ishl
    //   1391: ior
    //   1392: istore #10
    //   1394: iload #8
    //   1396: bipush #13
    //   1398: iadd
    //   1399: istore #8
    //   1401: iload #9
    //   1403: istore #7
    //   1405: iload #13
    //   1407: istore #9
    //   1409: goto -> 1353
    //   1412: iload #10
    //   1414: iload #14
    //   1416: iload #8
    //   1418: ishl
    //   1419: ior
    //   1420: istore #22
    //   1422: iload #13
    //   1424: istore #7
    //   1426: goto -> 1437
    //   1429: iload #7
    //   1431: istore #9
    //   1433: iload #8
    //   1435: istore #7
    //   1437: iload #7
    //   1439: iconst_1
    //   1440: iadd
    //   1441: istore #8
    //   1443: aload #36
    //   1445: iload #7
    //   1447: invokevirtual charAt : (I)C
    //   1450: istore #23
    //   1452: iload #23
    //   1454: ldc_w 55296
    //   1457: if_icmplt -> 1544
    //   1460: iload #23
    //   1462: sipush #8191
    //   1465: iand
    //   1466: istore #10
    //   1468: bipush #13
    //   1470: istore #7
    //   1472: iload #8
    //   1474: istore #13
    //   1476: iload #13
    //   1478: iconst_1
    //   1479: iadd
    //   1480: istore #8
    //   1482: aload #36
    //   1484: iload #13
    //   1486: invokevirtual charAt : (I)C
    //   1489: istore #13
    //   1491: iload #13
    //   1493: ldc_w 55296
    //   1496: if_icmplt -> 1527
    //   1499: iload #10
    //   1501: iload #13
    //   1503: sipush #8191
    //   1506: iand
    //   1507: iload #7
    //   1509: ishl
    //   1510: ior
    //   1511: istore #10
    //   1513: iload #7
    //   1515: bipush #13
    //   1517: iadd
    //   1518: istore #7
    //   1520: iload #8
    //   1522: istore #13
    //   1524: goto -> 1476
    //   1527: iload #10
    //   1529: iload #13
    //   1531: iload #7
    //   1533: ishl
    //   1534: ior
    //   1535: istore #23
    //   1537: iload #8
    //   1539: istore #13
    //   1541: goto -> 1548
    //   1544: iload #8
    //   1546: istore #13
    //   1548: iload #23
    //   1550: sipush #255
    //   1553: iand
    //   1554: istore #14
    //   1556: iload #12
    //   1558: istore #10
    //   1560: iload #23
    //   1562: sipush #1024
    //   1565: iand
    //   1566: ifeq -> 1582
    //   1569: aload #35
    //   1571: iload #12
    //   1573: iload #20
    //   1575: iastore
    //   1576: iload #12
    //   1578: iconst_1
    //   1579: iadd
    //   1580: istore #10
    //   1582: iload #14
    //   1584: bipush #51
    //   1586: if_icmplt -> 1945
    //   1589: iload #13
    //   1591: iconst_1
    //   1592: iadd
    //   1593: istore #8
    //   1595: aload #36
    //   1597: iload #13
    //   1599: invokevirtual charAt : (I)C
    //   1602: istore #13
    //   1604: iload #8
    //   1606: istore #7
    //   1608: iload #13
    //   1610: istore #12
    //   1612: iload #13
    //   1614: ldc_w 55296
    //   1617: if_icmplt -> 1701
    //   1620: iload #13
    //   1622: sipush #8191
    //   1625: iand
    //   1626: istore #12
    //   1628: bipush #13
    //   1630: istore #7
    //   1632: iload #8
    //   1634: istore #13
    //   1636: iload #13
    //   1638: iconst_1
    //   1639: iadd
    //   1640: istore #8
    //   1642: aload #36
    //   1644: iload #13
    //   1646: invokevirtual charAt : (I)C
    //   1649: istore #13
    //   1651: iload #13
    //   1653: ldc_w 55296
    //   1656: if_icmplt -> 1687
    //   1659: iload #12
    //   1661: iload #13
    //   1663: sipush #8191
    //   1666: iand
    //   1667: iload #7
    //   1669: ishl
    //   1670: ior
    //   1671: istore #12
    //   1673: iload #7
    //   1675: bipush #13
    //   1677: iadd
    //   1678: istore #7
    //   1680: iload #8
    //   1682: istore #13
    //   1684: goto -> 1636
    //   1687: iload #12
    //   1689: iload #13
    //   1691: iload #7
    //   1693: ishl
    //   1694: ior
    //   1695: istore #12
    //   1697: iload #8
    //   1699: istore #7
    //   1701: iload #14
    //   1703: bipush #51
    //   1705: isub
    //   1706: istore #13
    //   1708: iload #13
    //   1710: bipush #9
    //   1712: if_icmpeq -> 1777
    //   1715: iload #13
    //   1717: bipush #17
    //   1719: if_icmpne -> 1725
    //   1722: goto -> 1777
    //   1725: iload #11
    //   1727: istore #8
    //   1729: iload #13
    //   1731: bipush #12
    //   1733: if_icmpne -> 1803
    //   1736: iload #11
    //   1738: istore #8
    //   1740: iload #19
    //   1742: iconst_1
    //   1743: iand
    //   1744: iconst_1
    //   1745: if_icmpne -> 1803
    //   1748: iload #20
    //   1750: iconst_3
    //   1751: idiv
    //   1752: istore #13
    //   1754: iload #11
    //   1756: iconst_1
    //   1757: iadd
    //   1758: istore #8
    //   1760: aload #41
    //   1762: iload #13
    //   1764: iconst_2
    //   1765: imul
    //   1766: iconst_1
    //   1767: iadd
    //   1768: aload #40
    //   1770: iload #11
    //   1772: aaload
    //   1773: aastore
    //   1774: goto -> 1803
    //   1777: iload #20
    //   1779: iconst_3
    //   1780: idiv
    //   1781: istore #13
    //   1783: iload #11
    //   1785: iconst_1
    //   1786: iadd
    //   1787: istore #8
    //   1789: aload #41
    //   1791: iload #13
    //   1793: iconst_2
    //   1794: imul
    //   1795: iconst_1
    //   1796: iadd
    //   1797: aload #40
    //   1799: iload #11
    //   1801: aaload
    //   1802: aastore
    //   1803: iload #12
    //   1805: iconst_2
    //   1806: imul
    //   1807: istore #11
    //   1809: aload #40
    //   1811: iload #11
    //   1813: aaload
    //   1814: astore #38
    //   1816: aload #38
    //   1818: instanceof java/lang/reflect/Field
    //   1821: ifeq -> 1834
    //   1824: aload #38
    //   1826: checkcast java/lang/reflect/Field
    //   1829: astore #38
    //   1831: goto -> 1853
    //   1834: aload #37
    //   1836: aload #38
    //   1838: checkcast java/lang/String
    //   1841: invokestatic d0 : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   1844: astore #38
    //   1846: aload #40
    //   1848: iload #11
    //   1850: aload #38
    //   1852: aastore
    //   1853: aload #39
    //   1855: aload #38
    //   1857: invokevirtual objectFieldOffset : (Ljava/lang/reflect/Field;)J
    //   1860: l2i
    //   1861: istore #27
    //   1863: iload #11
    //   1865: iconst_1
    //   1866: iadd
    //   1867: istore #11
    //   1869: aload #40
    //   1871: iload #11
    //   1873: aaload
    //   1874: astore #38
    //   1876: aload #38
    //   1878: instanceof java/lang/reflect/Field
    //   1881: ifeq -> 1894
    //   1884: aload #38
    //   1886: checkcast java/lang/reflect/Field
    //   1889: astore #38
    //   1891: goto -> 1913
    //   1894: aload #37
    //   1896: aload #38
    //   1898: checkcast java/lang/String
    //   1901: invokestatic d0 : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   1904: astore #38
    //   1906: aload #40
    //   1908: iload #11
    //   1910: aload #38
    //   1912: aastore
    //   1913: aload #39
    //   1915: aload #38
    //   1917: invokevirtual objectFieldOffset : (Ljava/lang/reflect/Field;)J
    //   1920: l2i
    //   1921: istore #26
    //   1923: iconst_0
    //   1924: istore #29
    //   1926: iload #14
    //   1928: istore #28
    //   1930: iload #7
    //   1932: istore #11
    //   1934: iload #6
    //   1936: istore #25
    //   1938: iload #21
    //   1940: istore #24
    //   1942: goto -> 2583
    //   1945: iload #11
    //   1947: iconst_1
    //   1948: iadd
    //   1949: istore #12
    //   1951: aload #37
    //   1953: aload #40
    //   1955: iload #11
    //   1957: aaload
    //   1958: checkcast java/lang/String
    //   1961: invokestatic d0 : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   1964: astore #38
    //   1966: iload #14
    //   1968: bipush #9
    //   1970: if_icmpeq -> 2202
    //   1973: iload #14
    //   1975: bipush #17
    //   1977: if_icmpne -> 1983
    //   1980: goto -> 2202
    //   1983: iload #14
    //   1985: bipush #27
    //   1987: if_icmpeq -> 2173
    //   1990: iload #14
    //   1992: bipush #49
    //   1994: if_icmpne -> 2000
    //   1997: goto -> 2173
    //   2000: iload #14
    //   2002: bipush #12
    //   2004: if_icmpeq -> 2128
    //   2007: iload #14
    //   2009: bipush #30
    //   2011: if_icmpeq -> 2128
    //   2014: iload #14
    //   2016: bipush #44
    //   2018: if_icmpne -> 2024
    //   2021: goto -> 2128
    //   2024: iload #14
    //   2026: bipush #50
    //   2028: if_icmpne -> 2117
    //   2031: iload #6
    //   2033: iconst_1
    //   2034: iadd
    //   2035: istore #7
    //   2037: aload #35
    //   2039: iload #6
    //   2041: iload #20
    //   2043: iastore
    //   2044: iload #20
    //   2046: iconst_3
    //   2047: idiv
    //   2048: iconst_2
    //   2049: imul
    //   2050: istore #8
    //   2052: iload #12
    //   2054: iconst_1
    //   2055: iadd
    //   2056: istore #6
    //   2058: aload #41
    //   2060: iload #8
    //   2062: aload #40
    //   2064: iload #12
    //   2066: aaload
    //   2067: aastore
    //   2068: iload #23
    //   2070: sipush #2048
    //   2073: iand
    //   2074: ifeq -> 2106
    //   2077: iload #6
    //   2079: iconst_1
    //   2080: iadd
    //   2081: istore #11
    //   2083: aload #41
    //   2085: iload #8
    //   2087: iconst_1
    //   2088: iadd
    //   2089: aload #40
    //   2091: iload #6
    //   2093: aaload
    //   2094: aastore
    //   2095: iload #7
    //   2097: istore #8
    //   2099: iload #11
    //   2101: istore #7
    //   2103: goto -> 2226
    //   2106: iload #7
    //   2108: istore #8
    //   2110: iload #6
    //   2112: istore #7
    //   2114: goto -> 2226
    //   2117: iload #12
    //   2119: istore #7
    //   2121: iload #6
    //   2123: istore #8
    //   2125: goto -> 2226
    //   2128: iload #12
    //   2130: istore #7
    //   2132: iload #6
    //   2134: istore #8
    //   2136: iload #19
    //   2138: iconst_1
    //   2139: iand
    //   2140: iconst_1
    //   2141: if_icmpne -> 2226
    //   2144: iload #20
    //   2146: iconst_3
    //   2147: idiv
    //   2148: istore #8
    //   2150: iload #12
    //   2152: iconst_1
    //   2153: iadd
    //   2154: istore #7
    //   2156: aload #41
    //   2158: iload #8
    //   2160: iconst_2
    //   2161: imul
    //   2162: iconst_1
    //   2163: iadd
    //   2164: aload #40
    //   2166: iload #12
    //   2168: aaload
    //   2169: aastore
    //   2170: goto -> 2199
    //   2173: iload #20
    //   2175: iconst_3
    //   2176: idiv
    //   2177: istore #8
    //   2179: iload #12
    //   2181: iconst_1
    //   2182: iadd
    //   2183: istore #7
    //   2185: aload #41
    //   2187: iload #8
    //   2189: iconst_2
    //   2190: imul
    //   2191: iconst_1
    //   2192: iadd
    //   2193: aload #40
    //   2195: iload #12
    //   2197: aaload
    //   2198: aastore
    //   2199: goto -> 2230
    //   2202: aload #41
    //   2204: iload #20
    //   2206: iconst_3
    //   2207: idiv
    //   2208: iconst_2
    //   2209: imul
    //   2210: iconst_1
    //   2211: iadd
    //   2212: aload #38
    //   2214: invokevirtual getType : ()Ljava/lang/Class;
    //   2217: aastore
    //   2218: iload #6
    //   2220: istore #8
    //   2222: iload #12
    //   2224: istore #7
    //   2226: iload #8
    //   2228: istore #6
    //   2230: iload #14
    //   2232: istore #8
    //   2234: aload #39
    //   2236: aload #38
    //   2238: invokevirtual objectFieldOffset : (Ljava/lang/reflect/Field;)J
    //   2241: l2i
    //   2242: istore #32
    //   2244: iload #19
    //   2246: iconst_1
    //   2247: iand
    //   2248: iconst_1
    //   2249: if_icmpne -> 2454
    //   2252: iload #8
    //   2254: bipush #17
    //   2256: if_icmpgt -> 2451
    //   2259: iload #13
    //   2261: iconst_1
    //   2262: iadd
    //   2263: istore #11
    //   2265: aload #36
    //   2267: iload #13
    //   2269: invokevirtual charAt : (I)C
    //   2272: istore #14
    //   2274: iload #11
    //   2276: istore #13
    //   2278: iload #14
    //   2280: istore #12
    //   2282: iload #14
    //   2284: ldc_w 55296
    //   2287: if_icmplt -> 2371
    //   2290: iload #14
    //   2292: sipush #8191
    //   2295: iand
    //   2296: istore #13
    //   2298: bipush #13
    //   2300: istore #12
    //   2302: iload #11
    //   2304: istore #14
    //   2306: iload #14
    //   2308: iconst_1
    //   2309: iadd
    //   2310: istore #11
    //   2312: aload #36
    //   2314: iload #14
    //   2316: invokevirtual charAt : (I)C
    //   2319: istore #14
    //   2321: iload #14
    //   2323: ldc_w 55296
    //   2326: if_icmplt -> 2357
    //   2329: iload #13
    //   2331: iload #14
    //   2333: sipush #8191
    //   2336: iand
    //   2337: iload #12
    //   2339: ishl
    //   2340: ior
    //   2341: istore #13
    //   2343: iload #12
    //   2345: bipush #13
    //   2347: iadd
    //   2348: istore #12
    //   2350: iload #11
    //   2352: istore #14
    //   2354: goto -> 2306
    //   2357: iload #13
    //   2359: iload #14
    //   2361: iload #12
    //   2363: ishl
    //   2364: ior
    //   2365: istore #12
    //   2367: iload #11
    //   2369: istore #13
    //   2371: iload #16
    //   2373: iconst_2
    //   2374: imul
    //   2375: iload #12
    //   2377: bipush #32
    //   2379: idiv
    //   2380: iadd
    //   2381: istore #11
    //   2383: aload #40
    //   2385: iload #11
    //   2387: aaload
    //   2388: astore #38
    //   2390: aload #38
    //   2392: instanceof java/lang/reflect/Field
    //   2395: ifeq -> 2408
    //   2398: aload #38
    //   2400: checkcast java/lang/reflect/Field
    //   2403: astore #38
    //   2405: goto -> 2427
    //   2408: aload #37
    //   2410: aload #38
    //   2412: checkcast java/lang/String
    //   2415: invokestatic d0 : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   2418: astore #38
    //   2420: aload #40
    //   2422: iload #11
    //   2424: aload #38
    //   2426: aastore
    //   2427: aload #39
    //   2429: aload #38
    //   2431: invokevirtual objectFieldOffset : (Ljava/lang/reflect/Field;)J
    //   2434: l2i
    //   2435: istore #11
    //   2437: iload #12
    //   2439: bipush #32
    //   2441: irem
    //   2442: istore #14
    //   2444: iload #11
    //   2446: istore #12
    //   2448: goto -> 2460
    //   2451: goto -> 2454
    //   2454: iconst_0
    //   2455: istore #12
    //   2457: iconst_0
    //   2458: istore #14
    //   2460: iload #8
    //   2462: istore #30
    //   2464: iload #12
    //   2466: istore #26
    //   2468: iload #7
    //   2470: istore #8
    //   2472: iload #32
    //   2474: istore #27
    //   2476: iload #30
    //   2478: istore #28
    //   2480: iload #13
    //   2482: istore #11
    //   2484: iload #14
    //   2486: istore #29
    //   2488: iload #6
    //   2490: istore #25
    //   2492: iload #21
    //   2494: istore #24
    //   2496: iload #30
    //   2498: bipush #18
    //   2500: if_icmplt -> 2583
    //   2503: iload #12
    //   2505: istore #26
    //   2507: iload #7
    //   2509: istore #8
    //   2511: iload #32
    //   2513: istore #27
    //   2515: iload #30
    //   2517: istore #28
    //   2519: iload #13
    //   2521: istore #11
    //   2523: iload #14
    //   2525: istore #29
    //   2527: iload #6
    //   2529: istore #25
    //   2531: iload #21
    //   2533: istore #24
    //   2535: iload #30
    //   2537: bipush #49
    //   2539: if_icmpgt -> 2583
    //   2542: aload #35
    //   2544: iload #21
    //   2546: iload #32
    //   2548: iastore
    //   2549: iload #21
    //   2551: iconst_1
    //   2552: iadd
    //   2553: istore #24
    //   2555: iload #6
    //   2557: istore #25
    //   2559: iload #14
    //   2561: istore #29
    //   2563: iload #13
    //   2565: istore #11
    //   2567: iload #30
    //   2569: istore #28
    //   2571: iload #32
    //   2573: istore #27
    //   2575: iload #7
    //   2577: istore #8
    //   2579: iload #12
    //   2581: istore #26
    //   2583: iload #20
    //   2585: iconst_1
    //   2586: iadd
    //   2587: istore #13
    //   2589: aload #34
    //   2591: iload #20
    //   2593: iload #22
    //   2595: iastore
    //   2596: iload #13
    //   2598: iconst_1
    //   2599: iadd
    //   2600: istore #12
    //   2602: iload #23
    //   2604: sipush #512
    //   2607: iand
    //   2608: ifeq -> 2619
    //   2611: ldc_w 536870912
    //   2614: istore #6
    //   2616: goto -> 2622
    //   2619: iconst_0
    //   2620: istore #6
    //   2622: iload #23
    //   2624: sipush #256
    //   2627: iand
    //   2628: ifeq -> 2638
    //   2631: ldc 268435456
    //   2633: istore #7
    //   2635: goto -> 2641
    //   2638: iconst_0
    //   2639: istore #7
    //   2641: aload #34
    //   2643: iload #13
    //   2645: iload #6
    //   2647: iload #7
    //   2649: ior
    //   2650: iload #28
    //   2652: bipush #20
    //   2654: ishl
    //   2655: ior
    //   2656: iload #27
    //   2658: ior
    //   2659: iastore
    //   2660: aload #34
    //   2662: iload #12
    //   2664: iload #29
    //   2666: bipush #20
    //   2668: ishl
    //   2669: iload #26
    //   2671: ior
    //   2672: iastore
    //   2673: iload #9
    //   2675: istore #7
    //   2677: iload #12
    //   2679: iconst_1
    //   2680: iadd
    //   2681: istore #20
    //   2683: iload #11
    //   2685: istore #9
    //   2687: iload #10
    //   2689: istore #12
    //   2691: iload #8
    //   2693: istore #11
    //   2695: iload #25
    //   2697: istore #6
    //   2699: iload #24
    //   2701: istore #21
    //   2703: goto -> 1307
    //   2706: new androidx/datastore/preferences/protobuf/u0
    //   2709: dup
    //   2710: aload #34
    //   2712: aload #41
    //   2714: iload #15
    //   2716: iload #17
    //   2718: aload_0
    //   2719: invokevirtual c : ()Landroidx/datastore/preferences/protobuf/r0;
    //   2722: iload #33
    //   2724: iconst_0
    //   2725: aload #35
    //   2727: iload #7
    //   2729: iload #31
    //   2731: aload_1
    //   2732: aload_2
    //   2733: aload_3
    //   2734: aload #4
    //   2736: aload #5
    //   2738: invokespecial <init> : ([I[Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/r0;ZZ[IIILandroidx/datastore/preferences/protobuf/w0;Landroidx/datastore/preferences/protobuf/h0;Landroidx/datastore/preferences/protobuf/n1;Landroidx/datastore/preferences/protobuf/q;Landroidx/datastore/preferences/protobuf/m0;)V
    //   2741: areturn
  }
  
  private int Q(int paramInt) {
    return this.a[paramInt];
  }
  
  private static long R(int paramInt) {
    return (paramInt & 0xFFFFF);
  }
  
  private static <T> boolean S(T paramT, long paramLong) {
    return ((Boolean)r1.A(paramT, paramLong)).booleanValue();
  }
  
  private static <T> double T(T paramT, long paramLong) {
    return ((Double)r1.A(paramT, paramLong)).doubleValue();
  }
  
  private static <T> float U(T paramT, long paramLong) {
    return ((Float)r1.A(paramT, paramLong)).floatValue();
  }
  
  private static <T> int V(T paramT, long paramLong) {
    return ((Integer)r1.A(paramT, paramLong)).intValue();
  }
  
  private static <T> long W(T paramT, long paramLong) {
    return ((Long)r1.A(paramT, paramLong)).longValue();
  }
  
  private int X(int paramInt) {
    return (paramInt >= this.c && paramInt <= this.d) ? g0(paramInt, 0) : -1;
  }
  
  private int Y(int paramInt) {
    return this.a[paramInt + 2];
  }
  
  private <E> void Z(Object paramObject, long paramLong, f1 paramf1, g1<E> paramg1, p paramp) {
    paramf1.N(this.n.e(paramObject, paramLong), paramg1, paramp);
  }
  
  private <E> void a0(Object paramObject, int paramInt, f1 paramf1, g1<E> paramg1, p paramp) {
    long l = R(paramInt);
    paramf1.O(this.n.e(paramObject, l), paramg1, paramp);
  }
  
  private void b0(Object paramObject, int paramInt, f1 paramf1) {
    String str;
    h h;
    long l;
    if (x(paramInt)) {
      l = R(paramInt);
      str = paramf1.F();
    } else if (this.g) {
      l = R(paramInt);
      str = str.m();
    } else {
      l = R(paramInt);
      h = str.u();
    } 
    r1.O(paramObject, l, h);
  }
  
  private void c0(Object paramObject, int paramInt, f1 paramf1) {
    if (x(paramInt)) {
      paramf1.t(this.n.e(paramObject, R(paramInt)));
      return;
    } 
    paramf1.q(this.n.e(paramObject, R(paramInt)));
  }
  
  private static Field d0(Class<?> paramClass, String paramString) {
    try {
      return paramClass.getDeclaredField(paramString);
    } catch (NoSuchFieldException noSuchFieldException) {
      for (Field field : paramClass.getDeclaredFields()) {
        if (paramString.equals(field.getName()))
          return field; 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Field ");
      stringBuilder.append(paramString);
      stringBuilder.append(" for ");
      stringBuilder.append(paramClass.getName());
      stringBuilder.append(" not found. Known fields are ");
      stringBuilder.append(Arrays.toString((Object[])noSuchFieldException));
      throw new RuntimeException(stringBuilder.toString());
    } 
  }
  
  private void e0(T paramT, int paramInt) {
    if (this.h)
      return; 
    paramInt = Y(paramInt);
    long l = (paramInt & 0xFFFFF);
    r1.M(paramT, l, r1.x(paramT, l) | 1 << paramInt >>> 20);
  }
  
  private void f0(T paramT, int paramInt1, int paramInt2) {
    r1.M(paramT, (Y(paramInt2) & 0xFFFFF), paramInt1);
  }
  
  private int g0(int paramInt1, int paramInt2) {
    int i = this.a.length / 3 - 1;
    while (paramInt2 <= i) {
      int j = i + paramInt2 >>> 1;
      int k = j * 3;
      int m = Q(k);
      if (paramInt1 == m)
        return k; 
      if (paramInt1 < m) {
        i = j - 1;
        continue;
      } 
      paramInt2 = j + 1;
    } 
    return -1;
  }
  
  private static int h0(int paramInt) {
    return (paramInt & 0xFF00000) >>> 20;
  }
  
  private int i0(int paramInt) {
    return this.a[paramInt + 1];
  }
  
  private boolean j(T paramT1, T paramT2, int paramInt) {
    return (y(paramT1, paramInt) == y(paramT2, paramInt));
  }
  
  private void j0(T paramT, u1 paramu1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Z
    //   4: ifeq -> 47
    //   7: aload_0
    //   8: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   11: aload_1
    //   12: invokevirtual c : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   15: astore #15
    //   17: aload #15
    //   19: invokevirtual n : ()Z
    //   22: ifne -> 47
    //   25: aload #15
    //   27: invokevirtual s : ()Ljava/util/Iterator;
    //   30: astore #16
    //   32: aload #16
    //   34: invokeinterface next : ()Ljava/lang/Object;
    //   39: checkcast java/util/Map$Entry
    //   42: astore #15
    //   44: goto -> 53
    //   47: aconst_null
    //   48: astore #16
    //   50: aconst_null
    //   51: astore #15
    //   53: iconst_m1
    //   54: istore_3
    //   55: aload_0
    //   56: getfield a : [I
    //   59: arraylength
    //   60: istore #8
    //   62: getstatic androidx/datastore/preferences/protobuf/u0.s : Lsun/misc/Unsafe;
    //   65: astore #17
    //   67: iconst_0
    //   68: istore #6
    //   70: iconst_0
    //   71: istore #4
    //   73: iload #6
    //   75: iload #8
    //   77: if_icmpge -> 2411
    //   80: aload_0
    //   81: iload #6
    //   83: invokespecial i0 : (I)I
    //   86: istore #9
    //   88: aload_0
    //   89: iload #6
    //   91: invokespecial Q : (I)I
    //   94: istore #10
    //   96: iload #9
    //   98: invokestatic h0 : (I)I
    //   101: istore #11
    //   103: aload_0
    //   104: getfield h : Z
    //   107: ifne -> 174
    //   110: iload #11
    //   112: bipush #17
    //   114: if_icmpgt -> 174
    //   117: aload_0
    //   118: getfield a : [I
    //   121: iload #6
    //   123: iconst_2
    //   124: iadd
    //   125: iaload
    //   126: istore #12
    //   128: iload #12
    //   130: ldc 1048575
    //   132: iand
    //   133: istore #7
    //   135: iload_3
    //   136: istore #5
    //   138: iload #7
    //   140: iload_3
    //   141: if_icmpeq -> 159
    //   144: aload #17
    //   146: aload_1
    //   147: iload #7
    //   149: i2l
    //   150: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   153: istore #4
    //   155: iload #7
    //   157: istore #5
    //   159: iconst_1
    //   160: iload #12
    //   162: bipush #20
    //   164: iushr
    //   165: ishl
    //   166: istore #7
    //   168: iload #5
    //   170: istore_3
    //   171: goto -> 177
    //   174: iconst_0
    //   175: istore #7
    //   177: aload #15
    //   179: ifnull -> 237
    //   182: aload_0
    //   183: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   186: aload #15
    //   188: invokevirtual a : (Ljava/util/Map$Entry;)I
    //   191: iload #10
    //   193: if_icmpgt -> 237
    //   196: aload_0
    //   197: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   200: aload_2
    //   201: aload #15
    //   203: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   206: aload #16
    //   208: invokeinterface hasNext : ()Z
    //   213: ifeq -> 231
    //   216: aload #16
    //   218: invokeinterface next : ()Ljava/lang/Object;
    //   223: checkcast java/util/Map$Entry
    //   226: astore #15
    //   228: goto -> 177
    //   231: aconst_null
    //   232: astore #15
    //   234: goto -> 177
    //   237: iload #9
    //   239: invokestatic R : (I)J
    //   242: lstore #13
    //   244: iload #11
    //   246: tableswitch default -> 536, 0 -> 2380, 1 -> 2355, 2 -> 2328, 3 -> 2301, 4 -> 2274, 5 -> 2247, 6 -> 2220, 7 -> 2195, 8 -> 2169, 9 -> 2136, 10 -> 2106, 11 -> 2079, 12 -> 2052, 13 -> 2025, 14 -> 1998, 15 -> 1971, 16 -> 1944, 17 -> 1911, 18 -> 1886, 19 -> 1861, 20 -> 1836, 21 -> 1811, 22 -> 1786, 23 -> 1761, 24 -> 1736, 25 -> 1711, 26 -> 1687, 27 -> 1657, 28 -> 1633, 29 -> 1608, 30 -> 1583, 31 -> 1558, 32 -> 1533, 33 -> 1508, 34 -> 1483, 35 -> 1458, 36 -> 1433, 37 -> 1408, 38 -> 1383, 39 -> 1358, 40 -> 1333, 41 -> 1308, 42 -> 1283, 43 -> 1258, 44 -> 1233, 45 -> 1208, 46 -> 1183, 47 -> 1158, 48 -> 1133, 49 -> 1103, 50 -> 1083, 51 -> 1054, 52 -> 1025, 53 -> 996, 54 -> 967, 55 -> 938, 56 -> 909, 57 -> 880, 58 -> 851, 59 -> 821, 60 -> 784, 61 -> 750, 62 -> 721, 63 -> 692, 64 -> 663, 65 -> 634, 66 -> 605, 67 -> 576, 68 -> 539
    //   536: goto -> 2402
    //   539: aload_0
    //   540: aload_1
    //   541: iload #10
    //   543: iload #6
    //   545: invokespecial E : (Ljava/lang/Object;II)Z
    //   548: ifeq -> 536
    //   551: aload_2
    //   552: iload #10
    //   554: aload #17
    //   556: aload_1
    //   557: lload #13
    //   559: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   562: aload_0
    //   563: iload #6
    //   565: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   568: invokeinterface O : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   573: goto -> 536
    //   576: aload_0
    //   577: aload_1
    //   578: iload #10
    //   580: iload #6
    //   582: invokespecial E : (Ljava/lang/Object;II)Z
    //   585: ifeq -> 536
    //   588: aload_2
    //   589: iload #10
    //   591: aload_1
    //   592: lload #13
    //   594: invokestatic W : (Ljava/lang/Object;J)J
    //   597: invokeinterface w : (IJ)V
    //   602: goto -> 536
    //   605: aload_0
    //   606: aload_1
    //   607: iload #10
    //   609: iload #6
    //   611: invokespecial E : (Ljava/lang/Object;II)Z
    //   614: ifeq -> 536
    //   617: aload_2
    //   618: iload #10
    //   620: aload_1
    //   621: lload #13
    //   623: invokestatic V : (Ljava/lang/Object;J)I
    //   626: invokeinterface H : (II)V
    //   631: goto -> 536
    //   634: aload_0
    //   635: aload_1
    //   636: iload #10
    //   638: iload #6
    //   640: invokespecial E : (Ljava/lang/Object;II)Z
    //   643: ifeq -> 536
    //   646: aload_2
    //   647: iload #10
    //   649: aload_1
    //   650: lload #13
    //   652: invokestatic W : (Ljava/lang/Object;J)J
    //   655: invokeinterface n : (IJ)V
    //   660: goto -> 536
    //   663: aload_0
    //   664: aload_1
    //   665: iload #10
    //   667: iload #6
    //   669: invokespecial E : (Ljava/lang/Object;II)Z
    //   672: ifeq -> 536
    //   675: aload_2
    //   676: iload #10
    //   678: aload_1
    //   679: lload #13
    //   681: invokestatic V : (Ljava/lang/Object;J)I
    //   684: invokeinterface g : (II)V
    //   689: goto -> 536
    //   692: aload_0
    //   693: aload_1
    //   694: iload #10
    //   696: iload #6
    //   698: invokespecial E : (Ljava/lang/Object;II)Z
    //   701: ifeq -> 536
    //   704: aload_2
    //   705: iload #10
    //   707: aload_1
    //   708: lload #13
    //   710: invokestatic V : (Ljava/lang/Object;J)I
    //   713: invokeinterface D : (II)V
    //   718: goto -> 536
    //   721: aload_0
    //   722: aload_1
    //   723: iload #10
    //   725: iload #6
    //   727: invokespecial E : (Ljava/lang/Object;II)Z
    //   730: ifeq -> 536
    //   733: aload_2
    //   734: iload #10
    //   736: aload_1
    //   737: lload #13
    //   739: invokestatic V : (Ljava/lang/Object;J)I
    //   742: invokeinterface e : (II)V
    //   747: goto -> 536
    //   750: aload_0
    //   751: aload_1
    //   752: iload #10
    //   754: iload #6
    //   756: invokespecial E : (Ljava/lang/Object;II)Z
    //   759: ifeq -> 536
    //   762: aload_2
    //   763: iload #10
    //   765: aload #17
    //   767: aload_1
    //   768: lload #13
    //   770: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   773: checkcast androidx/datastore/preferences/protobuf/h
    //   776: invokeinterface J : (ILandroidx/datastore/preferences/protobuf/h;)V
    //   781: goto -> 536
    //   784: aload_0
    //   785: aload_1
    //   786: iload #10
    //   788: iload #6
    //   790: invokespecial E : (Ljava/lang/Object;II)Z
    //   793: ifeq -> 536
    //   796: aload_2
    //   797: iload #10
    //   799: aload #17
    //   801: aload_1
    //   802: lload #13
    //   804: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   807: aload_0
    //   808: iload #6
    //   810: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   813: invokeinterface K : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   818: goto -> 536
    //   821: aload_0
    //   822: aload_1
    //   823: iload #10
    //   825: iload #6
    //   827: invokespecial E : (Ljava/lang/Object;II)Z
    //   830: ifeq -> 536
    //   833: aload_0
    //   834: iload #10
    //   836: aload #17
    //   838: aload_1
    //   839: lload #13
    //   841: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   844: aload_2
    //   845: invokespecial n0 : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   848: goto -> 536
    //   851: aload_0
    //   852: aload_1
    //   853: iload #10
    //   855: iload #6
    //   857: invokespecial E : (Ljava/lang/Object;II)Z
    //   860: ifeq -> 536
    //   863: aload_2
    //   864: iload #10
    //   866: aload_1
    //   867: lload #13
    //   869: invokestatic S : (Ljava/lang/Object;J)Z
    //   872: invokeinterface d : (IZ)V
    //   877: goto -> 536
    //   880: aload_0
    //   881: aload_1
    //   882: iload #10
    //   884: iload #6
    //   886: invokespecial E : (Ljava/lang/Object;II)Z
    //   889: ifeq -> 536
    //   892: aload_2
    //   893: iload #10
    //   895: aload_1
    //   896: lload #13
    //   898: invokestatic V : (Ljava/lang/Object;J)I
    //   901: invokeinterface l : (II)V
    //   906: goto -> 536
    //   909: aload_0
    //   910: aload_1
    //   911: iload #10
    //   913: iload #6
    //   915: invokespecial E : (Ljava/lang/Object;II)Z
    //   918: ifeq -> 536
    //   921: aload_2
    //   922: iload #10
    //   924: aload_1
    //   925: lload #13
    //   927: invokestatic W : (Ljava/lang/Object;J)J
    //   930: invokeinterface u : (IJ)V
    //   935: goto -> 536
    //   938: aload_0
    //   939: aload_1
    //   940: iload #10
    //   942: iload #6
    //   944: invokespecial E : (Ljava/lang/Object;II)Z
    //   947: ifeq -> 536
    //   950: aload_2
    //   951: iload #10
    //   953: aload_1
    //   954: lload #13
    //   956: invokestatic V : (Ljava/lang/Object;J)I
    //   959: invokeinterface i : (II)V
    //   964: goto -> 536
    //   967: aload_0
    //   968: aload_1
    //   969: iload #10
    //   971: iload #6
    //   973: invokespecial E : (Ljava/lang/Object;II)Z
    //   976: ifeq -> 536
    //   979: aload_2
    //   980: iload #10
    //   982: aload_1
    //   983: lload #13
    //   985: invokestatic W : (Ljava/lang/Object;J)J
    //   988: invokeinterface C : (IJ)V
    //   993: goto -> 536
    //   996: aload_0
    //   997: aload_1
    //   998: iload #10
    //   1000: iload #6
    //   1002: invokespecial E : (Ljava/lang/Object;II)Z
    //   1005: ifeq -> 536
    //   1008: aload_2
    //   1009: iload #10
    //   1011: aload_1
    //   1012: lload #13
    //   1014: invokestatic W : (Ljava/lang/Object;J)J
    //   1017: invokeinterface c : (IJ)V
    //   1022: goto -> 536
    //   1025: aload_0
    //   1026: aload_1
    //   1027: iload #10
    //   1029: iload #6
    //   1031: invokespecial E : (Ljava/lang/Object;II)Z
    //   1034: ifeq -> 536
    //   1037: aload_2
    //   1038: iload #10
    //   1040: aload_1
    //   1041: lload #13
    //   1043: invokestatic U : (Ljava/lang/Object;J)F
    //   1046: invokeinterface x : (IF)V
    //   1051: goto -> 536
    //   1054: aload_0
    //   1055: aload_1
    //   1056: iload #10
    //   1058: iload #6
    //   1060: invokespecial E : (Ljava/lang/Object;II)Z
    //   1063: ifeq -> 536
    //   1066: aload_2
    //   1067: iload #10
    //   1069: aload_1
    //   1070: lload #13
    //   1072: invokestatic T : (Ljava/lang/Object;J)D
    //   1075: invokeinterface m : (ID)V
    //   1080: goto -> 536
    //   1083: aload_0
    //   1084: aload_2
    //   1085: iload #10
    //   1087: aload #17
    //   1089: aload_1
    //   1090: lload #13
    //   1092: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1095: iload #6
    //   1097: invokespecial m0 : (Landroidx/datastore/preferences/protobuf/u1;ILjava/lang/Object;I)V
    //   1100: goto -> 536
    //   1103: aload_0
    //   1104: iload #6
    //   1106: invokespecial Q : (I)I
    //   1109: aload #17
    //   1111: aload_1
    //   1112: lload #13
    //   1114: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1117: checkcast java/util/List
    //   1120: aload_2
    //   1121: aload_0
    //   1122: iload #6
    //   1124: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1127: invokestatic U : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1130: goto -> 536
    //   1133: aload_0
    //   1134: iload #6
    //   1136: invokespecial Q : (I)I
    //   1139: aload #17
    //   1141: aload_1
    //   1142: lload #13
    //   1144: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1147: checkcast java/util/List
    //   1150: aload_2
    //   1151: iconst_1
    //   1152: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1155: goto -> 536
    //   1158: aload_0
    //   1159: iload #6
    //   1161: invokespecial Q : (I)I
    //   1164: aload #17
    //   1166: aload_1
    //   1167: lload #13
    //   1169: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1172: checkcast java/util/List
    //   1175: aload_2
    //   1176: iconst_1
    //   1177: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1180: goto -> 536
    //   1183: aload_0
    //   1184: iload #6
    //   1186: invokespecial Q : (I)I
    //   1189: aload #17
    //   1191: aload_1
    //   1192: lload #13
    //   1194: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1197: checkcast java/util/List
    //   1200: aload_2
    //   1201: iconst_1
    //   1202: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1205: goto -> 536
    //   1208: aload_0
    //   1209: iload #6
    //   1211: invokespecial Q : (I)I
    //   1214: aload #17
    //   1216: aload_1
    //   1217: lload #13
    //   1219: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1222: checkcast java/util/List
    //   1225: aload_2
    //   1226: iconst_1
    //   1227: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1230: goto -> 536
    //   1233: aload_0
    //   1234: iload #6
    //   1236: invokespecial Q : (I)I
    //   1239: aload #17
    //   1241: aload_1
    //   1242: lload #13
    //   1244: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1247: checkcast java/util/List
    //   1250: aload_2
    //   1251: iconst_1
    //   1252: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1255: goto -> 536
    //   1258: aload_0
    //   1259: iload #6
    //   1261: invokespecial Q : (I)I
    //   1264: aload #17
    //   1266: aload_1
    //   1267: lload #13
    //   1269: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1272: checkcast java/util/List
    //   1275: aload_2
    //   1276: iconst_1
    //   1277: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1280: goto -> 536
    //   1283: aload_0
    //   1284: iload #6
    //   1286: invokespecial Q : (I)I
    //   1289: aload #17
    //   1291: aload_1
    //   1292: lload #13
    //   1294: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1297: checkcast java/util/List
    //   1300: aload_2
    //   1301: iconst_1
    //   1302: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1305: goto -> 536
    //   1308: aload_0
    //   1309: iload #6
    //   1311: invokespecial Q : (I)I
    //   1314: aload #17
    //   1316: aload_1
    //   1317: lload #13
    //   1319: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1322: checkcast java/util/List
    //   1325: aload_2
    //   1326: iconst_1
    //   1327: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1330: goto -> 536
    //   1333: aload_0
    //   1334: iload #6
    //   1336: invokespecial Q : (I)I
    //   1339: aload #17
    //   1341: aload_1
    //   1342: lload #13
    //   1344: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1347: checkcast java/util/List
    //   1350: aload_2
    //   1351: iconst_1
    //   1352: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1355: goto -> 536
    //   1358: aload_0
    //   1359: iload #6
    //   1361: invokespecial Q : (I)I
    //   1364: aload #17
    //   1366: aload_1
    //   1367: lload #13
    //   1369: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1372: checkcast java/util/List
    //   1375: aload_2
    //   1376: iconst_1
    //   1377: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1380: goto -> 536
    //   1383: aload_0
    //   1384: iload #6
    //   1386: invokespecial Q : (I)I
    //   1389: aload #17
    //   1391: aload_1
    //   1392: lload #13
    //   1394: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1397: checkcast java/util/List
    //   1400: aload_2
    //   1401: iconst_1
    //   1402: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1405: goto -> 536
    //   1408: aload_0
    //   1409: iload #6
    //   1411: invokespecial Q : (I)I
    //   1414: aload #17
    //   1416: aload_1
    //   1417: lload #13
    //   1419: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1422: checkcast java/util/List
    //   1425: aload_2
    //   1426: iconst_1
    //   1427: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1430: goto -> 536
    //   1433: aload_0
    //   1434: iload #6
    //   1436: invokespecial Q : (I)I
    //   1439: aload #17
    //   1441: aload_1
    //   1442: lload #13
    //   1444: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1447: checkcast java/util/List
    //   1450: aload_2
    //   1451: iconst_1
    //   1452: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1455: goto -> 536
    //   1458: aload_0
    //   1459: iload #6
    //   1461: invokespecial Q : (I)I
    //   1464: aload #17
    //   1466: aload_1
    //   1467: lload #13
    //   1469: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1472: checkcast java/util/List
    //   1475: aload_2
    //   1476: iconst_1
    //   1477: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1480: goto -> 536
    //   1483: aload_0
    //   1484: iload #6
    //   1486: invokespecial Q : (I)I
    //   1489: aload #17
    //   1491: aload_1
    //   1492: lload #13
    //   1494: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1497: checkcast java/util/List
    //   1500: aload_2
    //   1501: iconst_0
    //   1502: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1505: goto -> 2402
    //   1508: aload_0
    //   1509: iload #6
    //   1511: invokespecial Q : (I)I
    //   1514: aload #17
    //   1516: aload_1
    //   1517: lload #13
    //   1519: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1522: checkcast java/util/List
    //   1525: aload_2
    //   1526: iconst_0
    //   1527: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1530: goto -> 2402
    //   1533: aload_0
    //   1534: iload #6
    //   1536: invokespecial Q : (I)I
    //   1539: aload #17
    //   1541: aload_1
    //   1542: lload #13
    //   1544: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1547: checkcast java/util/List
    //   1550: aload_2
    //   1551: iconst_0
    //   1552: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1555: goto -> 2402
    //   1558: aload_0
    //   1559: iload #6
    //   1561: invokespecial Q : (I)I
    //   1564: aload #17
    //   1566: aload_1
    //   1567: lload #13
    //   1569: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1572: checkcast java/util/List
    //   1575: aload_2
    //   1576: iconst_0
    //   1577: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1580: goto -> 2402
    //   1583: aload_0
    //   1584: iload #6
    //   1586: invokespecial Q : (I)I
    //   1589: aload #17
    //   1591: aload_1
    //   1592: lload #13
    //   1594: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1597: checkcast java/util/List
    //   1600: aload_2
    //   1601: iconst_0
    //   1602: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1605: goto -> 2402
    //   1608: aload_0
    //   1609: iload #6
    //   1611: invokespecial Q : (I)I
    //   1614: aload #17
    //   1616: aload_1
    //   1617: lload #13
    //   1619: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1622: checkcast java/util/List
    //   1625: aload_2
    //   1626: iconst_0
    //   1627: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1630: goto -> 2402
    //   1633: aload_0
    //   1634: iload #6
    //   1636: invokespecial Q : (I)I
    //   1639: aload #17
    //   1641: aload_1
    //   1642: lload #13
    //   1644: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1647: checkcast java/util/List
    //   1650: aload_2
    //   1651: invokestatic O : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1654: goto -> 536
    //   1657: aload_0
    //   1658: iload #6
    //   1660: invokespecial Q : (I)I
    //   1663: aload #17
    //   1665: aload_1
    //   1666: lload #13
    //   1668: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1671: checkcast java/util/List
    //   1674: aload_2
    //   1675: aload_0
    //   1676: iload #6
    //   1678: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1681: invokestatic X : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1684: goto -> 536
    //   1687: aload_0
    //   1688: iload #6
    //   1690: invokespecial Q : (I)I
    //   1693: aload #17
    //   1695: aload_1
    //   1696: lload #13
    //   1698: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1701: checkcast java/util/List
    //   1704: aload_2
    //   1705: invokestatic c0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1708: goto -> 536
    //   1711: aload_0
    //   1712: iload #6
    //   1714: invokespecial Q : (I)I
    //   1717: aload #17
    //   1719: aload_1
    //   1720: lload #13
    //   1722: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1725: checkcast java/util/List
    //   1728: aload_2
    //   1729: iconst_0
    //   1730: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1733: goto -> 2402
    //   1736: aload_0
    //   1737: iload #6
    //   1739: invokespecial Q : (I)I
    //   1742: aload #17
    //   1744: aload_1
    //   1745: lload #13
    //   1747: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1750: checkcast java/util/List
    //   1753: aload_2
    //   1754: iconst_0
    //   1755: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1758: goto -> 2402
    //   1761: aload_0
    //   1762: iload #6
    //   1764: invokespecial Q : (I)I
    //   1767: aload #17
    //   1769: aload_1
    //   1770: lload #13
    //   1772: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1775: checkcast java/util/List
    //   1778: aload_2
    //   1779: iconst_0
    //   1780: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1783: goto -> 2402
    //   1786: aload_0
    //   1787: iload #6
    //   1789: invokespecial Q : (I)I
    //   1792: aload #17
    //   1794: aload_1
    //   1795: lload #13
    //   1797: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1800: checkcast java/util/List
    //   1803: aload_2
    //   1804: iconst_0
    //   1805: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1808: goto -> 2402
    //   1811: aload_0
    //   1812: iload #6
    //   1814: invokespecial Q : (I)I
    //   1817: aload #17
    //   1819: aload_1
    //   1820: lload #13
    //   1822: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1825: checkcast java/util/List
    //   1828: aload_2
    //   1829: iconst_0
    //   1830: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1833: goto -> 2402
    //   1836: aload_0
    //   1837: iload #6
    //   1839: invokespecial Q : (I)I
    //   1842: aload #17
    //   1844: aload_1
    //   1845: lload #13
    //   1847: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1850: checkcast java/util/List
    //   1853: aload_2
    //   1854: iconst_0
    //   1855: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1858: goto -> 2402
    //   1861: aload_0
    //   1862: iload #6
    //   1864: invokespecial Q : (I)I
    //   1867: aload #17
    //   1869: aload_1
    //   1870: lload #13
    //   1872: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1875: checkcast java/util/List
    //   1878: aload_2
    //   1879: iconst_0
    //   1880: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1883: goto -> 2402
    //   1886: aload_0
    //   1887: iload #6
    //   1889: invokespecial Q : (I)I
    //   1892: aload #17
    //   1894: aload_1
    //   1895: lload #13
    //   1897: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1900: checkcast java/util/List
    //   1903: aload_2
    //   1904: iconst_0
    //   1905: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1908: goto -> 2402
    //   1911: iload #7
    //   1913: iload #4
    //   1915: iand
    //   1916: ifeq -> 2402
    //   1919: aload_2
    //   1920: iload #10
    //   1922: aload #17
    //   1924: aload_1
    //   1925: lload #13
    //   1927: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1930: aload_0
    //   1931: iload #6
    //   1933: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1936: invokeinterface O : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1941: goto -> 2402
    //   1944: iload #7
    //   1946: iload #4
    //   1948: iand
    //   1949: ifeq -> 2402
    //   1952: aload_2
    //   1953: iload #10
    //   1955: aload #17
    //   1957: aload_1
    //   1958: lload #13
    //   1960: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   1963: invokeinterface w : (IJ)V
    //   1968: goto -> 2402
    //   1971: iload #7
    //   1973: iload #4
    //   1975: iand
    //   1976: ifeq -> 2402
    //   1979: aload_2
    //   1980: iload #10
    //   1982: aload #17
    //   1984: aload_1
    //   1985: lload #13
    //   1987: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   1990: invokeinterface H : (II)V
    //   1995: goto -> 2402
    //   1998: iload #7
    //   2000: iload #4
    //   2002: iand
    //   2003: ifeq -> 2402
    //   2006: aload_2
    //   2007: iload #10
    //   2009: aload #17
    //   2011: aload_1
    //   2012: lload #13
    //   2014: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2017: invokeinterface n : (IJ)V
    //   2022: goto -> 2402
    //   2025: iload #7
    //   2027: iload #4
    //   2029: iand
    //   2030: ifeq -> 2402
    //   2033: aload_2
    //   2034: iload #10
    //   2036: aload #17
    //   2038: aload_1
    //   2039: lload #13
    //   2041: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2044: invokeinterface g : (II)V
    //   2049: goto -> 2402
    //   2052: iload #7
    //   2054: iload #4
    //   2056: iand
    //   2057: ifeq -> 2402
    //   2060: aload_2
    //   2061: iload #10
    //   2063: aload #17
    //   2065: aload_1
    //   2066: lload #13
    //   2068: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2071: invokeinterface D : (II)V
    //   2076: goto -> 2402
    //   2079: iload #7
    //   2081: iload #4
    //   2083: iand
    //   2084: ifeq -> 2402
    //   2087: aload_2
    //   2088: iload #10
    //   2090: aload #17
    //   2092: aload_1
    //   2093: lload #13
    //   2095: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2098: invokeinterface e : (II)V
    //   2103: goto -> 2402
    //   2106: iload #7
    //   2108: iload #4
    //   2110: iand
    //   2111: ifeq -> 2402
    //   2114: aload_2
    //   2115: iload #10
    //   2117: aload #17
    //   2119: aload_1
    //   2120: lload #13
    //   2122: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2125: checkcast androidx/datastore/preferences/protobuf/h
    //   2128: invokeinterface J : (ILandroidx/datastore/preferences/protobuf/h;)V
    //   2133: goto -> 2402
    //   2136: iload #7
    //   2138: iload #4
    //   2140: iand
    //   2141: ifeq -> 2402
    //   2144: aload_2
    //   2145: iload #10
    //   2147: aload #17
    //   2149: aload_1
    //   2150: lload #13
    //   2152: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2155: aload_0
    //   2156: iload #6
    //   2158: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2161: invokeinterface K : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   2166: goto -> 2402
    //   2169: iload #7
    //   2171: iload #4
    //   2173: iand
    //   2174: ifeq -> 2402
    //   2177: aload_0
    //   2178: iload #10
    //   2180: aload #17
    //   2182: aload_1
    //   2183: lload #13
    //   2185: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2188: aload_2
    //   2189: invokespecial n0 : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   2192: goto -> 2402
    //   2195: iload #7
    //   2197: iload #4
    //   2199: iand
    //   2200: ifeq -> 2402
    //   2203: aload_2
    //   2204: iload #10
    //   2206: aload_1
    //   2207: lload #13
    //   2209: invokestatic k : (Ljava/lang/Object;J)Z
    //   2212: invokeinterface d : (IZ)V
    //   2217: goto -> 2402
    //   2220: iload #7
    //   2222: iload #4
    //   2224: iand
    //   2225: ifeq -> 2402
    //   2228: aload_2
    //   2229: iload #10
    //   2231: aload #17
    //   2233: aload_1
    //   2234: lload #13
    //   2236: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2239: invokeinterface l : (II)V
    //   2244: goto -> 2402
    //   2247: iload #7
    //   2249: iload #4
    //   2251: iand
    //   2252: ifeq -> 2402
    //   2255: aload_2
    //   2256: iload #10
    //   2258: aload #17
    //   2260: aload_1
    //   2261: lload #13
    //   2263: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2266: invokeinterface u : (IJ)V
    //   2271: goto -> 2402
    //   2274: iload #7
    //   2276: iload #4
    //   2278: iand
    //   2279: ifeq -> 2402
    //   2282: aload_2
    //   2283: iload #10
    //   2285: aload #17
    //   2287: aload_1
    //   2288: lload #13
    //   2290: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2293: invokeinterface i : (II)V
    //   2298: goto -> 2402
    //   2301: iload #7
    //   2303: iload #4
    //   2305: iand
    //   2306: ifeq -> 2402
    //   2309: aload_2
    //   2310: iload #10
    //   2312: aload #17
    //   2314: aload_1
    //   2315: lload #13
    //   2317: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2320: invokeinterface C : (IJ)V
    //   2325: goto -> 2402
    //   2328: iload #7
    //   2330: iload #4
    //   2332: iand
    //   2333: ifeq -> 2402
    //   2336: aload_2
    //   2337: iload #10
    //   2339: aload #17
    //   2341: aload_1
    //   2342: lload #13
    //   2344: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2347: invokeinterface c : (IJ)V
    //   2352: goto -> 2402
    //   2355: iload #7
    //   2357: iload #4
    //   2359: iand
    //   2360: ifeq -> 2402
    //   2363: aload_2
    //   2364: iload #10
    //   2366: aload_1
    //   2367: lload #13
    //   2369: invokestatic p : (Ljava/lang/Object;J)F
    //   2372: invokeinterface x : (IF)V
    //   2377: goto -> 2402
    //   2380: iload #7
    //   2382: iload #4
    //   2384: iand
    //   2385: ifeq -> 2402
    //   2388: aload_2
    //   2389: iload #10
    //   2391: aload_1
    //   2392: lload #13
    //   2394: invokestatic l : (Ljava/lang/Object;J)D
    //   2397: invokeinterface m : (ID)V
    //   2402: iload #6
    //   2404: iconst_3
    //   2405: iadd
    //   2406: istore #6
    //   2408: goto -> 73
    //   2411: aload #15
    //   2413: ifnull -> 2457
    //   2416: aload_0
    //   2417: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   2420: aload_2
    //   2421: aload #15
    //   2423: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   2426: aload #16
    //   2428: invokeinterface hasNext : ()Z
    //   2433: ifeq -> 2451
    //   2436: aload #16
    //   2438: invokeinterface next : ()Ljava/lang/Object;
    //   2443: checkcast java/util/Map$Entry
    //   2446: astore #15
    //   2448: goto -> 2411
    //   2451: aconst_null
    //   2452: astore #15
    //   2454: goto -> 2411
    //   2457: aload_0
    //   2458: aload_0
    //   2459: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   2462: aload_1
    //   2463: aload_2
    //   2464: invokespecial o0 : (Landroidx/datastore/preferences/protobuf/n1;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   2467: return
  }
  
  private static <T> boolean k(T paramT, long paramLong) {
    return r1.p(paramT, paramLong);
  }
  
  private void k0(T paramT, u1 paramu1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Z
    //   4: ifeq -> 47
    //   7: aload_0
    //   8: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   11: aload_1
    //   12: invokevirtual c : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   15: astore #13
    //   17: aload #13
    //   19: invokevirtual n : ()Z
    //   22: ifne -> 47
    //   25: aload #13
    //   27: invokevirtual s : ()Ljava/util/Iterator;
    //   30: astore #15
    //   32: aload #15
    //   34: invokeinterface next : ()Ljava/lang/Object;
    //   39: checkcast java/util/Map$Entry
    //   42: astore #13
    //   44: goto -> 54
    //   47: aconst_null
    //   48: astore #15
    //   50: aload #15
    //   52: astore #13
    //   54: aload_0
    //   55: getfield a : [I
    //   58: arraylength
    //   59: istore #8
    //   61: iconst_0
    //   62: istore #6
    //   64: aload #13
    //   66: astore #14
    //   68: iload #6
    //   70: iload #8
    //   72: if_icmpge -> 2349
    //   75: aload_0
    //   76: iload #6
    //   78: invokespecial i0 : (I)I
    //   81: istore #7
    //   83: aload_0
    //   84: iload #6
    //   86: invokespecial Q : (I)I
    //   89: istore #9
    //   91: aload #13
    //   93: ifnull -> 151
    //   96: aload_0
    //   97: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   100: aload #13
    //   102: invokevirtual a : (Ljava/util/Map$Entry;)I
    //   105: iload #9
    //   107: if_icmpgt -> 151
    //   110: aload_0
    //   111: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   114: aload_2
    //   115: aload #13
    //   117: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   120: aload #15
    //   122: invokeinterface hasNext : ()Z
    //   127: ifeq -> 145
    //   130: aload #15
    //   132: invokeinterface next : ()Ljava/lang/Object;
    //   137: checkcast java/util/Map$Entry
    //   140: astore #13
    //   142: goto -> 91
    //   145: aconst_null
    //   146: astore #13
    //   148: goto -> 91
    //   151: iload #7
    //   153: invokestatic h0 : (I)I
    //   156: tableswitch default -> 448, 0 -> 2311, 1 -> 2277, 2 -> 2243, 3 -> 2209, 4 -> 2175, 5 -> 2141, 6 -> 2107, 7 -> 2073, 8 -> 2044, 9 -> 2008, 10 -> 1975, 11 -> 1941, 12 -> 1907, 13 -> 1873, 14 -> 1839, 15 -> 1805, 16 -> 1771, 17 -> 1735, 18 -> 1709, 19 -> 1683, 20 -> 1657, 21 -> 1631, 22 -> 1605, 23 -> 1579, 24 -> 1553, 25 -> 1527, 26 -> 1502, 27 -> 1471, 28 -> 1446, 29 -> 1420, 30 -> 1394, 31 -> 1368, 32 -> 1342, 33 -> 1316, 34 -> 1290, 35 -> 1264, 36 -> 1238, 37 -> 1212, 38 -> 1186, 39 -> 1160, 40 -> 1134, 41 -> 1108, 42 -> 1082, 43 -> 1056, 44 -> 1030, 45 -> 1004, 46 -> 978, 47 -> 952, 48 -> 926, 49 -> 895, 50 -> 874, 51 -> 849, 52 -> 823, 53 -> 797, 54 -> 771, 55 -> 745, 56 -> 719, 57 -> 693, 58 -> 667, 59 -> 652, 60 -> 637, 61 -> 622, 62 -> 596, 63 -> 570, 64 -> 544, 65 -> 518, 66 -> 492, 67 -> 466, 68 -> 451
    //   448: goto -> 2340
    //   451: aload_0
    //   452: aload_1
    //   453: iload #9
    //   455: iload #6
    //   457: invokespecial E : (Ljava/lang/Object;II)Z
    //   460: ifeq -> 2340
    //   463: goto -> 1745
    //   466: aload_0
    //   467: aload_1
    //   468: iload #9
    //   470: iload #6
    //   472: invokespecial E : (Ljava/lang/Object;II)Z
    //   475: ifeq -> 2340
    //   478: aload_1
    //   479: iload #7
    //   481: invokestatic R : (I)J
    //   484: invokestatic W : (Ljava/lang/Object;J)J
    //   487: lstore #10
    //   489: goto -> 1792
    //   492: aload_0
    //   493: aload_1
    //   494: iload #9
    //   496: iload #6
    //   498: invokespecial E : (Ljava/lang/Object;II)Z
    //   501: ifeq -> 2340
    //   504: aload_1
    //   505: iload #7
    //   507: invokestatic R : (I)J
    //   510: invokestatic V : (Ljava/lang/Object;J)I
    //   513: istore #7
    //   515: goto -> 1826
    //   518: aload_0
    //   519: aload_1
    //   520: iload #9
    //   522: iload #6
    //   524: invokespecial E : (Ljava/lang/Object;II)Z
    //   527: ifeq -> 2340
    //   530: aload_1
    //   531: iload #7
    //   533: invokestatic R : (I)J
    //   536: invokestatic W : (Ljava/lang/Object;J)J
    //   539: lstore #10
    //   541: goto -> 1860
    //   544: aload_0
    //   545: aload_1
    //   546: iload #9
    //   548: iload #6
    //   550: invokespecial E : (Ljava/lang/Object;II)Z
    //   553: ifeq -> 2340
    //   556: aload_1
    //   557: iload #7
    //   559: invokestatic R : (I)J
    //   562: invokestatic V : (Ljava/lang/Object;J)I
    //   565: istore #7
    //   567: goto -> 1894
    //   570: aload_0
    //   571: aload_1
    //   572: iload #9
    //   574: iload #6
    //   576: invokespecial E : (Ljava/lang/Object;II)Z
    //   579: ifeq -> 2340
    //   582: aload_1
    //   583: iload #7
    //   585: invokestatic R : (I)J
    //   588: invokestatic V : (Ljava/lang/Object;J)I
    //   591: istore #7
    //   593: goto -> 1928
    //   596: aload_0
    //   597: aload_1
    //   598: iload #9
    //   600: iload #6
    //   602: invokespecial E : (Ljava/lang/Object;II)Z
    //   605: ifeq -> 2340
    //   608: aload_1
    //   609: iload #7
    //   611: invokestatic R : (I)J
    //   614: invokestatic V : (Ljava/lang/Object;J)I
    //   617: istore #7
    //   619: goto -> 1962
    //   622: aload_0
    //   623: aload_1
    //   624: iload #9
    //   626: iload #6
    //   628: invokespecial E : (Ljava/lang/Object;II)Z
    //   631: ifeq -> 2340
    //   634: goto -> 1985
    //   637: aload_0
    //   638: aload_1
    //   639: iload #9
    //   641: iload #6
    //   643: invokespecial E : (Ljava/lang/Object;II)Z
    //   646: ifeq -> 2340
    //   649: goto -> 2018
    //   652: aload_0
    //   653: aload_1
    //   654: iload #9
    //   656: iload #6
    //   658: invokespecial E : (Ljava/lang/Object;II)Z
    //   661: ifeq -> 2340
    //   664: goto -> 2054
    //   667: aload_0
    //   668: aload_1
    //   669: iload #9
    //   671: iload #6
    //   673: invokespecial E : (Ljava/lang/Object;II)Z
    //   676: ifeq -> 2340
    //   679: aload_1
    //   680: iload #7
    //   682: invokestatic R : (I)J
    //   685: invokestatic S : (Ljava/lang/Object;J)Z
    //   688: istore #12
    //   690: goto -> 2094
    //   693: aload_0
    //   694: aload_1
    //   695: iload #9
    //   697: iload #6
    //   699: invokespecial E : (Ljava/lang/Object;II)Z
    //   702: ifeq -> 2340
    //   705: aload_1
    //   706: iload #7
    //   708: invokestatic R : (I)J
    //   711: invokestatic V : (Ljava/lang/Object;J)I
    //   714: istore #7
    //   716: goto -> 2128
    //   719: aload_0
    //   720: aload_1
    //   721: iload #9
    //   723: iload #6
    //   725: invokespecial E : (Ljava/lang/Object;II)Z
    //   728: ifeq -> 2340
    //   731: aload_1
    //   732: iload #7
    //   734: invokestatic R : (I)J
    //   737: invokestatic W : (Ljava/lang/Object;J)J
    //   740: lstore #10
    //   742: goto -> 2162
    //   745: aload_0
    //   746: aload_1
    //   747: iload #9
    //   749: iload #6
    //   751: invokespecial E : (Ljava/lang/Object;II)Z
    //   754: ifeq -> 2340
    //   757: aload_1
    //   758: iload #7
    //   760: invokestatic R : (I)J
    //   763: invokestatic V : (Ljava/lang/Object;J)I
    //   766: istore #7
    //   768: goto -> 2196
    //   771: aload_0
    //   772: aload_1
    //   773: iload #9
    //   775: iload #6
    //   777: invokespecial E : (Ljava/lang/Object;II)Z
    //   780: ifeq -> 2340
    //   783: aload_1
    //   784: iload #7
    //   786: invokestatic R : (I)J
    //   789: invokestatic W : (Ljava/lang/Object;J)J
    //   792: lstore #10
    //   794: goto -> 2230
    //   797: aload_0
    //   798: aload_1
    //   799: iload #9
    //   801: iload #6
    //   803: invokespecial E : (Ljava/lang/Object;II)Z
    //   806: ifeq -> 2340
    //   809: aload_1
    //   810: iload #7
    //   812: invokestatic R : (I)J
    //   815: invokestatic W : (Ljava/lang/Object;J)J
    //   818: lstore #10
    //   820: goto -> 2264
    //   823: aload_0
    //   824: aload_1
    //   825: iload #9
    //   827: iload #6
    //   829: invokespecial E : (Ljava/lang/Object;II)Z
    //   832: ifeq -> 2340
    //   835: aload_1
    //   836: iload #7
    //   838: invokestatic R : (I)J
    //   841: invokestatic U : (Ljava/lang/Object;J)F
    //   844: fstore #5
    //   846: goto -> 2298
    //   849: aload_0
    //   850: aload_1
    //   851: iload #9
    //   853: iload #6
    //   855: invokespecial E : (Ljava/lang/Object;II)Z
    //   858: ifeq -> 2340
    //   861: aload_1
    //   862: iload #7
    //   864: invokestatic R : (I)J
    //   867: invokestatic T : (Ljava/lang/Object;J)D
    //   870: dstore_3
    //   871: goto -> 2331
    //   874: aload_0
    //   875: aload_2
    //   876: iload #9
    //   878: aload_1
    //   879: iload #7
    //   881: invokestatic R : (I)J
    //   884: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   887: iload #6
    //   889: invokespecial m0 : (Landroidx/datastore/preferences/protobuf/u1;ILjava/lang/Object;I)V
    //   892: goto -> 2340
    //   895: aload_0
    //   896: iload #6
    //   898: invokespecial Q : (I)I
    //   901: aload_1
    //   902: iload #7
    //   904: invokestatic R : (I)J
    //   907: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   910: checkcast java/util/List
    //   913: aload_2
    //   914: aload_0
    //   915: iload #6
    //   917: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   920: invokestatic U : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   923: goto -> 2340
    //   926: aload_0
    //   927: iload #6
    //   929: invokespecial Q : (I)I
    //   932: aload_1
    //   933: iload #7
    //   935: invokestatic R : (I)J
    //   938: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   941: checkcast java/util/List
    //   944: aload_2
    //   945: iconst_1
    //   946: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   949: goto -> 2340
    //   952: aload_0
    //   953: iload #6
    //   955: invokespecial Q : (I)I
    //   958: aload_1
    //   959: iload #7
    //   961: invokestatic R : (I)J
    //   964: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   967: checkcast java/util/List
    //   970: aload_2
    //   971: iconst_1
    //   972: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   975: goto -> 2340
    //   978: aload_0
    //   979: iload #6
    //   981: invokespecial Q : (I)I
    //   984: aload_1
    //   985: iload #7
    //   987: invokestatic R : (I)J
    //   990: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   993: checkcast java/util/List
    //   996: aload_2
    //   997: iconst_1
    //   998: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1001: goto -> 2340
    //   1004: aload_0
    //   1005: iload #6
    //   1007: invokespecial Q : (I)I
    //   1010: aload_1
    //   1011: iload #7
    //   1013: invokestatic R : (I)J
    //   1016: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1019: checkcast java/util/List
    //   1022: aload_2
    //   1023: iconst_1
    //   1024: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1027: goto -> 2340
    //   1030: aload_0
    //   1031: iload #6
    //   1033: invokespecial Q : (I)I
    //   1036: aload_1
    //   1037: iload #7
    //   1039: invokestatic R : (I)J
    //   1042: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1045: checkcast java/util/List
    //   1048: aload_2
    //   1049: iconst_1
    //   1050: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1053: goto -> 2340
    //   1056: aload_0
    //   1057: iload #6
    //   1059: invokespecial Q : (I)I
    //   1062: aload_1
    //   1063: iload #7
    //   1065: invokestatic R : (I)J
    //   1068: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1071: checkcast java/util/List
    //   1074: aload_2
    //   1075: iconst_1
    //   1076: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1079: goto -> 2340
    //   1082: aload_0
    //   1083: iload #6
    //   1085: invokespecial Q : (I)I
    //   1088: aload_1
    //   1089: iload #7
    //   1091: invokestatic R : (I)J
    //   1094: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1097: checkcast java/util/List
    //   1100: aload_2
    //   1101: iconst_1
    //   1102: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1105: goto -> 2340
    //   1108: aload_0
    //   1109: iload #6
    //   1111: invokespecial Q : (I)I
    //   1114: aload_1
    //   1115: iload #7
    //   1117: invokestatic R : (I)J
    //   1120: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1123: checkcast java/util/List
    //   1126: aload_2
    //   1127: iconst_1
    //   1128: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1131: goto -> 2340
    //   1134: aload_0
    //   1135: iload #6
    //   1137: invokespecial Q : (I)I
    //   1140: aload_1
    //   1141: iload #7
    //   1143: invokestatic R : (I)J
    //   1146: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1149: checkcast java/util/List
    //   1152: aload_2
    //   1153: iconst_1
    //   1154: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1157: goto -> 2340
    //   1160: aload_0
    //   1161: iload #6
    //   1163: invokespecial Q : (I)I
    //   1166: aload_1
    //   1167: iload #7
    //   1169: invokestatic R : (I)J
    //   1172: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1175: checkcast java/util/List
    //   1178: aload_2
    //   1179: iconst_1
    //   1180: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1183: goto -> 2340
    //   1186: aload_0
    //   1187: iload #6
    //   1189: invokespecial Q : (I)I
    //   1192: aload_1
    //   1193: iload #7
    //   1195: invokestatic R : (I)J
    //   1198: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1201: checkcast java/util/List
    //   1204: aload_2
    //   1205: iconst_1
    //   1206: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1209: goto -> 2340
    //   1212: aload_0
    //   1213: iload #6
    //   1215: invokespecial Q : (I)I
    //   1218: aload_1
    //   1219: iload #7
    //   1221: invokestatic R : (I)J
    //   1224: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1227: checkcast java/util/List
    //   1230: aload_2
    //   1231: iconst_1
    //   1232: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1235: goto -> 2340
    //   1238: aload_0
    //   1239: iload #6
    //   1241: invokespecial Q : (I)I
    //   1244: aload_1
    //   1245: iload #7
    //   1247: invokestatic R : (I)J
    //   1250: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1253: checkcast java/util/List
    //   1256: aload_2
    //   1257: iconst_1
    //   1258: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1261: goto -> 2340
    //   1264: aload_0
    //   1265: iload #6
    //   1267: invokespecial Q : (I)I
    //   1270: aload_1
    //   1271: iload #7
    //   1273: invokestatic R : (I)J
    //   1276: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1279: checkcast java/util/List
    //   1282: aload_2
    //   1283: iconst_1
    //   1284: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1287: goto -> 2340
    //   1290: aload_0
    //   1291: iload #6
    //   1293: invokespecial Q : (I)I
    //   1296: aload_1
    //   1297: iload #7
    //   1299: invokestatic R : (I)J
    //   1302: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1305: checkcast java/util/List
    //   1308: aload_2
    //   1309: iconst_0
    //   1310: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1313: goto -> 2340
    //   1316: aload_0
    //   1317: iload #6
    //   1319: invokespecial Q : (I)I
    //   1322: aload_1
    //   1323: iload #7
    //   1325: invokestatic R : (I)J
    //   1328: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1331: checkcast java/util/List
    //   1334: aload_2
    //   1335: iconst_0
    //   1336: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1339: goto -> 2340
    //   1342: aload_0
    //   1343: iload #6
    //   1345: invokespecial Q : (I)I
    //   1348: aload_1
    //   1349: iload #7
    //   1351: invokestatic R : (I)J
    //   1354: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1357: checkcast java/util/List
    //   1360: aload_2
    //   1361: iconst_0
    //   1362: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1365: goto -> 2340
    //   1368: aload_0
    //   1369: iload #6
    //   1371: invokespecial Q : (I)I
    //   1374: aload_1
    //   1375: iload #7
    //   1377: invokestatic R : (I)J
    //   1380: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1383: checkcast java/util/List
    //   1386: aload_2
    //   1387: iconst_0
    //   1388: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1391: goto -> 2340
    //   1394: aload_0
    //   1395: iload #6
    //   1397: invokespecial Q : (I)I
    //   1400: aload_1
    //   1401: iload #7
    //   1403: invokestatic R : (I)J
    //   1406: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1409: checkcast java/util/List
    //   1412: aload_2
    //   1413: iconst_0
    //   1414: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1417: goto -> 2340
    //   1420: aload_0
    //   1421: iload #6
    //   1423: invokespecial Q : (I)I
    //   1426: aload_1
    //   1427: iload #7
    //   1429: invokestatic R : (I)J
    //   1432: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1435: checkcast java/util/List
    //   1438: aload_2
    //   1439: iconst_0
    //   1440: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1443: goto -> 2340
    //   1446: aload_0
    //   1447: iload #6
    //   1449: invokespecial Q : (I)I
    //   1452: aload_1
    //   1453: iload #7
    //   1455: invokestatic R : (I)J
    //   1458: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1461: checkcast java/util/List
    //   1464: aload_2
    //   1465: invokestatic O : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1468: goto -> 2340
    //   1471: aload_0
    //   1472: iload #6
    //   1474: invokespecial Q : (I)I
    //   1477: aload_1
    //   1478: iload #7
    //   1480: invokestatic R : (I)J
    //   1483: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1486: checkcast java/util/List
    //   1489: aload_2
    //   1490: aload_0
    //   1491: iload #6
    //   1493: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1496: invokestatic X : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1499: goto -> 2340
    //   1502: aload_0
    //   1503: iload #6
    //   1505: invokespecial Q : (I)I
    //   1508: aload_1
    //   1509: iload #7
    //   1511: invokestatic R : (I)J
    //   1514: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1517: checkcast java/util/List
    //   1520: aload_2
    //   1521: invokestatic c0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1524: goto -> 2340
    //   1527: aload_0
    //   1528: iload #6
    //   1530: invokespecial Q : (I)I
    //   1533: aload_1
    //   1534: iload #7
    //   1536: invokestatic R : (I)J
    //   1539: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1542: checkcast java/util/List
    //   1545: aload_2
    //   1546: iconst_0
    //   1547: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1550: goto -> 2340
    //   1553: aload_0
    //   1554: iload #6
    //   1556: invokespecial Q : (I)I
    //   1559: aload_1
    //   1560: iload #7
    //   1562: invokestatic R : (I)J
    //   1565: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1568: checkcast java/util/List
    //   1571: aload_2
    //   1572: iconst_0
    //   1573: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1576: goto -> 2340
    //   1579: aload_0
    //   1580: iload #6
    //   1582: invokespecial Q : (I)I
    //   1585: aload_1
    //   1586: iload #7
    //   1588: invokestatic R : (I)J
    //   1591: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1594: checkcast java/util/List
    //   1597: aload_2
    //   1598: iconst_0
    //   1599: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1602: goto -> 2340
    //   1605: aload_0
    //   1606: iload #6
    //   1608: invokespecial Q : (I)I
    //   1611: aload_1
    //   1612: iload #7
    //   1614: invokestatic R : (I)J
    //   1617: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1620: checkcast java/util/List
    //   1623: aload_2
    //   1624: iconst_0
    //   1625: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1628: goto -> 2340
    //   1631: aload_0
    //   1632: iload #6
    //   1634: invokespecial Q : (I)I
    //   1637: aload_1
    //   1638: iload #7
    //   1640: invokestatic R : (I)J
    //   1643: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1646: checkcast java/util/List
    //   1649: aload_2
    //   1650: iconst_0
    //   1651: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1654: goto -> 2340
    //   1657: aload_0
    //   1658: iload #6
    //   1660: invokespecial Q : (I)I
    //   1663: aload_1
    //   1664: iload #7
    //   1666: invokestatic R : (I)J
    //   1669: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1672: checkcast java/util/List
    //   1675: aload_2
    //   1676: iconst_0
    //   1677: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1680: goto -> 2340
    //   1683: aload_0
    //   1684: iload #6
    //   1686: invokespecial Q : (I)I
    //   1689: aload_1
    //   1690: iload #7
    //   1692: invokestatic R : (I)J
    //   1695: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1698: checkcast java/util/List
    //   1701: aload_2
    //   1702: iconst_0
    //   1703: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1706: goto -> 2340
    //   1709: aload_0
    //   1710: iload #6
    //   1712: invokespecial Q : (I)I
    //   1715: aload_1
    //   1716: iload #7
    //   1718: invokestatic R : (I)J
    //   1721: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1724: checkcast java/util/List
    //   1727: aload_2
    //   1728: iconst_0
    //   1729: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1732: goto -> 2340
    //   1735: aload_0
    //   1736: aload_1
    //   1737: iload #6
    //   1739: invokespecial y : (Ljava/lang/Object;I)Z
    //   1742: ifeq -> 2340
    //   1745: aload_2
    //   1746: iload #9
    //   1748: aload_1
    //   1749: iload #7
    //   1751: invokestatic R : (I)J
    //   1754: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1757: aload_0
    //   1758: iload #6
    //   1760: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1763: invokeinterface O : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1768: goto -> 2340
    //   1771: aload_0
    //   1772: aload_1
    //   1773: iload #6
    //   1775: invokespecial y : (Ljava/lang/Object;I)Z
    //   1778: ifeq -> 2340
    //   1781: aload_1
    //   1782: iload #7
    //   1784: invokestatic R : (I)J
    //   1787: invokestatic H : (Ljava/lang/Object;J)J
    //   1790: lstore #10
    //   1792: aload_2
    //   1793: iload #9
    //   1795: lload #10
    //   1797: invokeinterface w : (IJ)V
    //   1802: goto -> 2340
    //   1805: aload_0
    //   1806: aload_1
    //   1807: iload #6
    //   1809: invokespecial y : (Ljava/lang/Object;I)Z
    //   1812: ifeq -> 2340
    //   1815: aload_1
    //   1816: iload #7
    //   1818: invokestatic R : (I)J
    //   1821: invokestatic w : (Ljava/lang/Object;J)I
    //   1824: istore #7
    //   1826: aload_2
    //   1827: iload #9
    //   1829: iload #7
    //   1831: invokeinterface H : (II)V
    //   1836: goto -> 2340
    //   1839: aload_0
    //   1840: aload_1
    //   1841: iload #6
    //   1843: invokespecial y : (Ljava/lang/Object;I)Z
    //   1846: ifeq -> 2340
    //   1849: aload_1
    //   1850: iload #7
    //   1852: invokestatic R : (I)J
    //   1855: invokestatic H : (Ljava/lang/Object;J)J
    //   1858: lstore #10
    //   1860: aload_2
    //   1861: iload #9
    //   1863: lload #10
    //   1865: invokeinterface n : (IJ)V
    //   1870: goto -> 2340
    //   1873: aload_0
    //   1874: aload_1
    //   1875: iload #6
    //   1877: invokespecial y : (Ljava/lang/Object;I)Z
    //   1880: ifeq -> 2340
    //   1883: aload_1
    //   1884: iload #7
    //   1886: invokestatic R : (I)J
    //   1889: invokestatic w : (Ljava/lang/Object;J)I
    //   1892: istore #7
    //   1894: aload_2
    //   1895: iload #9
    //   1897: iload #7
    //   1899: invokeinterface g : (II)V
    //   1904: goto -> 2340
    //   1907: aload_0
    //   1908: aload_1
    //   1909: iload #6
    //   1911: invokespecial y : (Ljava/lang/Object;I)Z
    //   1914: ifeq -> 2340
    //   1917: aload_1
    //   1918: iload #7
    //   1920: invokestatic R : (I)J
    //   1923: invokestatic w : (Ljava/lang/Object;J)I
    //   1926: istore #7
    //   1928: aload_2
    //   1929: iload #9
    //   1931: iload #7
    //   1933: invokeinterface D : (II)V
    //   1938: goto -> 2340
    //   1941: aload_0
    //   1942: aload_1
    //   1943: iload #6
    //   1945: invokespecial y : (Ljava/lang/Object;I)Z
    //   1948: ifeq -> 2340
    //   1951: aload_1
    //   1952: iload #7
    //   1954: invokestatic R : (I)J
    //   1957: invokestatic w : (Ljava/lang/Object;J)I
    //   1960: istore #7
    //   1962: aload_2
    //   1963: iload #9
    //   1965: iload #7
    //   1967: invokeinterface e : (II)V
    //   1972: goto -> 2340
    //   1975: aload_0
    //   1976: aload_1
    //   1977: iload #6
    //   1979: invokespecial y : (Ljava/lang/Object;I)Z
    //   1982: ifeq -> 2340
    //   1985: aload_2
    //   1986: iload #9
    //   1988: aload_1
    //   1989: iload #7
    //   1991: invokestatic R : (I)J
    //   1994: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1997: checkcast androidx/datastore/preferences/protobuf/h
    //   2000: invokeinterface J : (ILandroidx/datastore/preferences/protobuf/h;)V
    //   2005: goto -> 2340
    //   2008: aload_0
    //   2009: aload_1
    //   2010: iload #6
    //   2012: invokespecial y : (Ljava/lang/Object;I)Z
    //   2015: ifeq -> 2340
    //   2018: aload_2
    //   2019: iload #9
    //   2021: aload_1
    //   2022: iload #7
    //   2024: invokestatic R : (I)J
    //   2027: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2030: aload_0
    //   2031: iload #6
    //   2033: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2036: invokeinterface K : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   2041: goto -> 2340
    //   2044: aload_0
    //   2045: aload_1
    //   2046: iload #6
    //   2048: invokespecial y : (Ljava/lang/Object;I)Z
    //   2051: ifeq -> 2340
    //   2054: aload_0
    //   2055: iload #9
    //   2057: aload_1
    //   2058: iload #7
    //   2060: invokestatic R : (I)J
    //   2063: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2066: aload_2
    //   2067: invokespecial n0 : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   2070: goto -> 2340
    //   2073: aload_0
    //   2074: aload_1
    //   2075: iload #6
    //   2077: invokespecial y : (Ljava/lang/Object;I)Z
    //   2080: ifeq -> 2340
    //   2083: aload_1
    //   2084: iload #7
    //   2086: invokestatic R : (I)J
    //   2089: invokestatic k : (Ljava/lang/Object;J)Z
    //   2092: istore #12
    //   2094: aload_2
    //   2095: iload #9
    //   2097: iload #12
    //   2099: invokeinterface d : (IZ)V
    //   2104: goto -> 2340
    //   2107: aload_0
    //   2108: aload_1
    //   2109: iload #6
    //   2111: invokespecial y : (Ljava/lang/Object;I)Z
    //   2114: ifeq -> 2340
    //   2117: aload_1
    //   2118: iload #7
    //   2120: invokestatic R : (I)J
    //   2123: invokestatic w : (Ljava/lang/Object;J)I
    //   2126: istore #7
    //   2128: aload_2
    //   2129: iload #9
    //   2131: iload #7
    //   2133: invokeinterface l : (II)V
    //   2138: goto -> 2340
    //   2141: aload_0
    //   2142: aload_1
    //   2143: iload #6
    //   2145: invokespecial y : (Ljava/lang/Object;I)Z
    //   2148: ifeq -> 2340
    //   2151: aload_1
    //   2152: iload #7
    //   2154: invokestatic R : (I)J
    //   2157: invokestatic H : (Ljava/lang/Object;J)J
    //   2160: lstore #10
    //   2162: aload_2
    //   2163: iload #9
    //   2165: lload #10
    //   2167: invokeinterface u : (IJ)V
    //   2172: goto -> 2340
    //   2175: aload_0
    //   2176: aload_1
    //   2177: iload #6
    //   2179: invokespecial y : (Ljava/lang/Object;I)Z
    //   2182: ifeq -> 2340
    //   2185: aload_1
    //   2186: iload #7
    //   2188: invokestatic R : (I)J
    //   2191: invokestatic w : (Ljava/lang/Object;J)I
    //   2194: istore #7
    //   2196: aload_2
    //   2197: iload #9
    //   2199: iload #7
    //   2201: invokeinterface i : (II)V
    //   2206: goto -> 2340
    //   2209: aload_0
    //   2210: aload_1
    //   2211: iload #6
    //   2213: invokespecial y : (Ljava/lang/Object;I)Z
    //   2216: ifeq -> 2340
    //   2219: aload_1
    //   2220: iload #7
    //   2222: invokestatic R : (I)J
    //   2225: invokestatic H : (Ljava/lang/Object;J)J
    //   2228: lstore #10
    //   2230: aload_2
    //   2231: iload #9
    //   2233: lload #10
    //   2235: invokeinterface C : (IJ)V
    //   2240: goto -> 2340
    //   2243: aload_0
    //   2244: aload_1
    //   2245: iload #6
    //   2247: invokespecial y : (Ljava/lang/Object;I)Z
    //   2250: ifeq -> 2340
    //   2253: aload_1
    //   2254: iload #7
    //   2256: invokestatic R : (I)J
    //   2259: invokestatic H : (Ljava/lang/Object;J)J
    //   2262: lstore #10
    //   2264: aload_2
    //   2265: iload #9
    //   2267: lload #10
    //   2269: invokeinterface c : (IJ)V
    //   2274: goto -> 2340
    //   2277: aload_0
    //   2278: aload_1
    //   2279: iload #6
    //   2281: invokespecial y : (Ljava/lang/Object;I)Z
    //   2284: ifeq -> 2340
    //   2287: aload_1
    //   2288: iload #7
    //   2290: invokestatic R : (I)J
    //   2293: invokestatic p : (Ljava/lang/Object;J)F
    //   2296: fstore #5
    //   2298: aload_2
    //   2299: iload #9
    //   2301: fload #5
    //   2303: invokeinterface x : (IF)V
    //   2308: goto -> 2340
    //   2311: aload_0
    //   2312: aload_1
    //   2313: iload #6
    //   2315: invokespecial y : (Ljava/lang/Object;I)Z
    //   2318: ifeq -> 2340
    //   2321: aload_1
    //   2322: iload #7
    //   2324: invokestatic R : (I)J
    //   2327: invokestatic l : (Ljava/lang/Object;J)D
    //   2330: dstore_3
    //   2331: aload_2
    //   2332: iload #9
    //   2334: dload_3
    //   2335: invokeinterface m : (ID)V
    //   2340: iload #6
    //   2342: iconst_3
    //   2343: iadd
    //   2344: istore #6
    //   2346: goto -> 64
    //   2349: aload #14
    //   2351: ifnull -> 2395
    //   2354: aload_0
    //   2355: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   2358: aload_2
    //   2359: aload #14
    //   2361: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   2364: aload #15
    //   2366: invokeinterface hasNext : ()Z
    //   2371: ifeq -> 2389
    //   2374: aload #15
    //   2376: invokeinterface next : ()Ljava/lang/Object;
    //   2381: checkcast java/util/Map$Entry
    //   2384: astore #14
    //   2386: goto -> 2349
    //   2389: aconst_null
    //   2390: astore #14
    //   2392: goto -> 2349
    //   2395: aload_0
    //   2396: aload_0
    //   2397: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   2400: aload_1
    //   2401: aload_2
    //   2402: invokespecial o0 : (Landroidx/datastore/preferences/protobuf/n1;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   2405: return
  }
  
  private static <T> double l(T paramT, long paramLong) {
    return r1.v(paramT, paramLong);
  }
  
  private void l0(T paramT, u1 paramu1) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   5: aload_1
    //   6: aload_2
    //   7: invokespecial o0 : (Landroidx/datastore/preferences/protobuf/n1;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   10: aload_0
    //   11: getfield f : Z
    //   14: ifeq -> 57
    //   17: aload_0
    //   18: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   21: aload_1
    //   22: invokevirtual c : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   25: astore #12
    //   27: aload #12
    //   29: invokevirtual n : ()Z
    //   32: ifne -> 57
    //   35: aload #12
    //   37: invokevirtual g : ()Ljava/util/Iterator;
    //   40: astore #14
    //   42: aload #14
    //   44: invokeinterface next : ()Ljava/lang/Object;
    //   49: checkcast java/util/Map$Entry
    //   52: astore #12
    //   54: goto -> 64
    //   57: aconst_null
    //   58: astore #14
    //   60: aload #14
    //   62: astore #12
    //   64: aload_0
    //   65: getfield a : [I
    //   68: arraylength
    //   69: iconst_3
    //   70: isub
    //   71: istore #6
    //   73: aload #12
    //   75: astore #13
    //   77: iload #6
    //   79: iflt -> 2353
    //   82: aload_0
    //   83: iload #6
    //   85: invokespecial i0 : (I)I
    //   88: istore #7
    //   90: aload_0
    //   91: iload #6
    //   93: invokespecial Q : (I)I
    //   96: istore #8
    //   98: aload #12
    //   100: ifnull -> 158
    //   103: aload_0
    //   104: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   107: aload #12
    //   109: invokevirtual a : (Ljava/util/Map$Entry;)I
    //   112: iload #8
    //   114: if_icmple -> 158
    //   117: aload_0
    //   118: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   121: aload_2
    //   122: aload #12
    //   124: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   127: aload #14
    //   129: invokeinterface hasNext : ()Z
    //   134: ifeq -> 152
    //   137: aload #14
    //   139: invokeinterface next : ()Ljava/lang/Object;
    //   144: checkcast java/util/Map$Entry
    //   147: astore #12
    //   149: goto -> 98
    //   152: aconst_null
    //   153: astore #12
    //   155: goto -> 98
    //   158: iload #7
    //   160: invokestatic h0 : (I)I
    //   163: tableswitch default -> 452, 0 -> 2315, 1 -> 2281, 2 -> 2247, 3 -> 2213, 4 -> 2179, 5 -> 2145, 6 -> 2111, 7 -> 2077, 8 -> 2048, 9 -> 2012, 10 -> 1979, 11 -> 1945, 12 -> 1911, 13 -> 1877, 14 -> 1843, 15 -> 1809, 16 -> 1775, 17 -> 1739, 18 -> 1713, 19 -> 1687, 20 -> 1661, 21 -> 1635, 22 -> 1609, 23 -> 1583, 24 -> 1557, 25 -> 1531, 26 -> 1506, 27 -> 1475, 28 -> 1450, 29 -> 1424, 30 -> 1398, 31 -> 1372, 32 -> 1346, 33 -> 1320, 34 -> 1294, 35 -> 1268, 36 -> 1242, 37 -> 1216, 38 -> 1190, 39 -> 1164, 40 -> 1138, 41 -> 1112, 42 -> 1086, 43 -> 1060, 44 -> 1034, 45 -> 1008, 46 -> 982, 47 -> 956, 48 -> 930, 49 -> 899, 50 -> 878, 51 -> 853, 52 -> 827, 53 -> 801, 54 -> 775, 55 -> 749, 56 -> 723, 57 -> 697, 58 -> 671, 59 -> 656, 60 -> 641, 61 -> 626, 62 -> 600, 63 -> 574, 64 -> 548, 65 -> 522, 66 -> 496, 67 -> 470, 68 -> 455
    //   452: goto -> 2344
    //   455: aload_0
    //   456: aload_1
    //   457: iload #8
    //   459: iload #6
    //   461: invokespecial E : (Ljava/lang/Object;II)Z
    //   464: ifeq -> 2344
    //   467: goto -> 1749
    //   470: aload_0
    //   471: aload_1
    //   472: iload #8
    //   474: iload #6
    //   476: invokespecial E : (Ljava/lang/Object;II)Z
    //   479: ifeq -> 2344
    //   482: aload_1
    //   483: iload #7
    //   485: invokestatic R : (I)J
    //   488: invokestatic W : (Ljava/lang/Object;J)J
    //   491: lstore #9
    //   493: goto -> 1796
    //   496: aload_0
    //   497: aload_1
    //   498: iload #8
    //   500: iload #6
    //   502: invokespecial E : (Ljava/lang/Object;II)Z
    //   505: ifeq -> 2344
    //   508: aload_1
    //   509: iload #7
    //   511: invokestatic R : (I)J
    //   514: invokestatic V : (Ljava/lang/Object;J)I
    //   517: istore #7
    //   519: goto -> 1830
    //   522: aload_0
    //   523: aload_1
    //   524: iload #8
    //   526: iload #6
    //   528: invokespecial E : (Ljava/lang/Object;II)Z
    //   531: ifeq -> 2344
    //   534: aload_1
    //   535: iload #7
    //   537: invokestatic R : (I)J
    //   540: invokestatic W : (Ljava/lang/Object;J)J
    //   543: lstore #9
    //   545: goto -> 1864
    //   548: aload_0
    //   549: aload_1
    //   550: iload #8
    //   552: iload #6
    //   554: invokespecial E : (Ljava/lang/Object;II)Z
    //   557: ifeq -> 2344
    //   560: aload_1
    //   561: iload #7
    //   563: invokestatic R : (I)J
    //   566: invokestatic V : (Ljava/lang/Object;J)I
    //   569: istore #7
    //   571: goto -> 1898
    //   574: aload_0
    //   575: aload_1
    //   576: iload #8
    //   578: iload #6
    //   580: invokespecial E : (Ljava/lang/Object;II)Z
    //   583: ifeq -> 2344
    //   586: aload_1
    //   587: iload #7
    //   589: invokestatic R : (I)J
    //   592: invokestatic V : (Ljava/lang/Object;J)I
    //   595: istore #7
    //   597: goto -> 1932
    //   600: aload_0
    //   601: aload_1
    //   602: iload #8
    //   604: iload #6
    //   606: invokespecial E : (Ljava/lang/Object;II)Z
    //   609: ifeq -> 2344
    //   612: aload_1
    //   613: iload #7
    //   615: invokestatic R : (I)J
    //   618: invokestatic V : (Ljava/lang/Object;J)I
    //   621: istore #7
    //   623: goto -> 1966
    //   626: aload_0
    //   627: aload_1
    //   628: iload #8
    //   630: iload #6
    //   632: invokespecial E : (Ljava/lang/Object;II)Z
    //   635: ifeq -> 2344
    //   638: goto -> 1989
    //   641: aload_0
    //   642: aload_1
    //   643: iload #8
    //   645: iload #6
    //   647: invokespecial E : (Ljava/lang/Object;II)Z
    //   650: ifeq -> 2344
    //   653: goto -> 2022
    //   656: aload_0
    //   657: aload_1
    //   658: iload #8
    //   660: iload #6
    //   662: invokespecial E : (Ljava/lang/Object;II)Z
    //   665: ifeq -> 2344
    //   668: goto -> 2058
    //   671: aload_0
    //   672: aload_1
    //   673: iload #8
    //   675: iload #6
    //   677: invokespecial E : (Ljava/lang/Object;II)Z
    //   680: ifeq -> 2344
    //   683: aload_1
    //   684: iload #7
    //   686: invokestatic R : (I)J
    //   689: invokestatic S : (Ljava/lang/Object;J)Z
    //   692: istore #11
    //   694: goto -> 2098
    //   697: aload_0
    //   698: aload_1
    //   699: iload #8
    //   701: iload #6
    //   703: invokespecial E : (Ljava/lang/Object;II)Z
    //   706: ifeq -> 2344
    //   709: aload_1
    //   710: iload #7
    //   712: invokestatic R : (I)J
    //   715: invokestatic V : (Ljava/lang/Object;J)I
    //   718: istore #7
    //   720: goto -> 2132
    //   723: aload_0
    //   724: aload_1
    //   725: iload #8
    //   727: iload #6
    //   729: invokespecial E : (Ljava/lang/Object;II)Z
    //   732: ifeq -> 2344
    //   735: aload_1
    //   736: iload #7
    //   738: invokestatic R : (I)J
    //   741: invokestatic W : (Ljava/lang/Object;J)J
    //   744: lstore #9
    //   746: goto -> 2166
    //   749: aload_0
    //   750: aload_1
    //   751: iload #8
    //   753: iload #6
    //   755: invokespecial E : (Ljava/lang/Object;II)Z
    //   758: ifeq -> 2344
    //   761: aload_1
    //   762: iload #7
    //   764: invokestatic R : (I)J
    //   767: invokestatic V : (Ljava/lang/Object;J)I
    //   770: istore #7
    //   772: goto -> 2200
    //   775: aload_0
    //   776: aload_1
    //   777: iload #8
    //   779: iload #6
    //   781: invokespecial E : (Ljava/lang/Object;II)Z
    //   784: ifeq -> 2344
    //   787: aload_1
    //   788: iload #7
    //   790: invokestatic R : (I)J
    //   793: invokestatic W : (Ljava/lang/Object;J)J
    //   796: lstore #9
    //   798: goto -> 2234
    //   801: aload_0
    //   802: aload_1
    //   803: iload #8
    //   805: iload #6
    //   807: invokespecial E : (Ljava/lang/Object;II)Z
    //   810: ifeq -> 2344
    //   813: aload_1
    //   814: iload #7
    //   816: invokestatic R : (I)J
    //   819: invokestatic W : (Ljava/lang/Object;J)J
    //   822: lstore #9
    //   824: goto -> 2268
    //   827: aload_0
    //   828: aload_1
    //   829: iload #8
    //   831: iload #6
    //   833: invokespecial E : (Ljava/lang/Object;II)Z
    //   836: ifeq -> 2344
    //   839: aload_1
    //   840: iload #7
    //   842: invokestatic R : (I)J
    //   845: invokestatic U : (Ljava/lang/Object;J)F
    //   848: fstore #5
    //   850: goto -> 2302
    //   853: aload_0
    //   854: aload_1
    //   855: iload #8
    //   857: iload #6
    //   859: invokespecial E : (Ljava/lang/Object;II)Z
    //   862: ifeq -> 2344
    //   865: aload_1
    //   866: iload #7
    //   868: invokestatic R : (I)J
    //   871: invokestatic T : (Ljava/lang/Object;J)D
    //   874: dstore_3
    //   875: goto -> 2335
    //   878: aload_0
    //   879: aload_2
    //   880: iload #8
    //   882: aload_1
    //   883: iload #7
    //   885: invokestatic R : (I)J
    //   888: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   891: iload #6
    //   893: invokespecial m0 : (Landroidx/datastore/preferences/protobuf/u1;ILjava/lang/Object;I)V
    //   896: goto -> 2344
    //   899: aload_0
    //   900: iload #6
    //   902: invokespecial Q : (I)I
    //   905: aload_1
    //   906: iload #7
    //   908: invokestatic R : (I)J
    //   911: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   914: checkcast java/util/List
    //   917: aload_2
    //   918: aload_0
    //   919: iload #6
    //   921: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   924: invokestatic U : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   927: goto -> 2344
    //   930: aload_0
    //   931: iload #6
    //   933: invokespecial Q : (I)I
    //   936: aload_1
    //   937: iload #7
    //   939: invokestatic R : (I)J
    //   942: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   945: checkcast java/util/List
    //   948: aload_2
    //   949: iconst_1
    //   950: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   953: goto -> 2344
    //   956: aload_0
    //   957: iload #6
    //   959: invokespecial Q : (I)I
    //   962: aload_1
    //   963: iload #7
    //   965: invokestatic R : (I)J
    //   968: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   971: checkcast java/util/List
    //   974: aload_2
    //   975: iconst_1
    //   976: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   979: goto -> 2344
    //   982: aload_0
    //   983: iload #6
    //   985: invokespecial Q : (I)I
    //   988: aload_1
    //   989: iload #7
    //   991: invokestatic R : (I)J
    //   994: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   997: checkcast java/util/List
    //   1000: aload_2
    //   1001: iconst_1
    //   1002: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1005: goto -> 2344
    //   1008: aload_0
    //   1009: iload #6
    //   1011: invokespecial Q : (I)I
    //   1014: aload_1
    //   1015: iload #7
    //   1017: invokestatic R : (I)J
    //   1020: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1023: checkcast java/util/List
    //   1026: aload_2
    //   1027: iconst_1
    //   1028: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1031: goto -> 2344
    //   1034: aload_0
    //   1035: iload #6
    //   1037: invokespecial Q : (I)I
    //   1040: aload_1
    //   1041: iload #7
    //   1043: invokestatic R : (I)J
    //   1046: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1049: checkcast java/util/List
    //   1052: aload_2
    //   1053: iconst_1
    //   1054: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1057: goto -> 2344
    //   1060: aload_0
    //   1061: iload #6
    //   1063: invokespecial Q : (I)I
    //   1066: aload_1
    //   1067: iload #7
    //   1069: invokestatic R : (I)J
    //   1072: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1075: checkcast java/util/List
    //   1078: aload_2
    //   1079: iconst_1
    //   1080: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1083: goto -> 2344
    //   1086: aload_0
    //   1087: iload #6
    //   1089: invokespecial Q : (I)I
    //   1092: aload_1
    //   1093: iload #7
    //   1095: invokestatic R : (I)J
    //   1098: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1101: checkcast java/util/List
    //   1104: aload_2
    //   1105: iconst_1
    //   1106: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1109: goto -> 2344
    //   1112: aload_0
    //   1113: iload #6
    //   1115: invokespecial Q : (I)I
    //   1118: aload_1
    //   1119: iload #7
    //   1121: invokestatic R : (I)J
    //   1124: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1127: checkcast java/util/List
    //   1130: aload_2
    //   1131: iconst_1
    //   1132: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1135: goto -> 2344
    //   1138: aload_0
    //   1139: iload #6
    //   1141: invokespecial Q : (I)I
    //   1144: aload_1
    //   1145: iload #7
    //   1147: invokestatic R : (I)J
    //   1150: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1153: checkcast java/util/List
    //   1156: aload_2
    //   1157: iconst_1
    //   1158: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1161: goto -> 2344
    //   1164: aload_0
    //   1165: iload #6
    //   1167: invokespecial Q : (I)I
    //   1170: aload_1
    //   1171: iload #7
    //   1173: invokestatic R : (I)J
    //   1176: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1179: checkcast java/util/List
    //   1182: aload_2
    //   1183: iconst_1
    //   1184: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1187: goto -> 2344
    //   1190: aload_0
    //   1191: iload #6
    //   1193: invokespecial Q : (I)I
    //   1196: aload_1
    //   1197: iload #7
    //   1199: invokestatic R : (I)J
    //   1202: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1205: checkcast java/util/List
    //   1208: aload_2
    //   1209: iconst_1
    //   1210: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1213: goto -> 2344
    //   1216: aload_0
    //   1217: iload #6
    //   1219: invokespecial Q : (I)I
    //   1222: aload_1
    //   1223: iload #7
    //   1225: invokestatic R : (I)J
    //   1228: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1231: checkcast java/util/List
    //   1234: aload_2
    //   1235: iconst_1
    //   1236: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1239: goto -> 2344
    //   1242: aload_0
    //   1243: iload #6
    //   1245: invokespecial Q : (I)I
    //   1248: aload_1
    //   1249: iload #7
    //   1251: invokestatic R : (I)J
    //   1254: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1257: checkcast java/util/List
    //   1260: aload_2
    //   1261: iconst_1
    //   1262: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1265: goto -> 2344
    //   1268: aload_0
    //   1269: iload #6
    //   1271: invokespecial Q : (I)I
    //   1274: aload_1
    //   1275: iload #7
    //   1277: invokestatic R : (I)J
    //   1280: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1283: checkcast java/util/List
    //   1286: aload_2
    //   1287: iconst_1
    //   1288: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1291: goto -> 2344
    //   1294: aload_0
    //   1295: iload #6
    //   1297: invokespecial Q : (I)I
    //   1300: aload_1
    //   1301: iload #7
    //   1303: invokestatic R : (I)J
    //   1306: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1309: checkcast java/util/List
    //   1312: aload_2
    //   1313: iconst_0
    //   1314: invokestatic b0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1317: goto -> 2344
    //   1320: aload_0
    //   1321: iload #6
    //   1323: invokespecial Q : (I)I
    //   1326: aload_1
    //   1327: iload #7
    //   1329: invokestatic R : (I)J
    //   1332: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1335: checkcast java/util/List
    //   1338: aload_2
    //   1339: iconst_0
    //   1340: invokestatic a0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1343: goto -> 2344
    //   1346: aload_0
    //   1347: iload #6
    //   1349: invokespecial Q : (I)I
    //   1352: aload_1
    //   1353: iload #7
    //   1355: invokestatic R : (I)J
    //   1358: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1361: checkcast java/util/List
    //   1364: aload_2
    //   1365: iconst_0
    //   1366: invokestatic Z : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1369: goto -> 2344
    //   1372: aload_0
    //   1373: iload #6
    //   1375: invokespecial Q : (I)I
    //   1378: aload_1
    //   1379: iload #7
    //   1381: invokestatic R : (I)J
    //   1384: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1387: checkcast java/util/List
    //   1390: aload_2
    //   1391: iconst_0
    //   1392: invokestatic Y : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1395: goto -> 2344
    //   1398: aload_0
    //   1399: iload #6
    //   1401: invokespecial Q : (I)I
    //   1404: aload_1
    //   1405: iload #7
    //   1407: invokestatic R : (I)J
    //   1410: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1413: checkcast java/util/List
    //   1416: aload_2
    //   1417: iconst_0
    //   1418: invokestatic Q : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1421: goto -> 2344
    //   1424: aload_0
    //   1425: iload #6
    //   1427: invokespecial Q : (I)I
    //   1430: aload_1
    //   1431: iload #7
    //   1433: invokestatic R : (I)J
    //   1436: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1439: checkcast java/util/List
    //   1442: aload_2
    //   1443: iconst_0
    //   1444: invokestatic d0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1447: goto -> 2344
    //   1450: aload_0
    //   1451: iload #6
    //   1453: invokespecial Q : (I)I
    //   1456: aload_1
    //   1457: iload #7
    //   1459: invokestatic R : (I)J
    //   1462: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1465: checkcast java/util/List
    //   1468: aload_2
    //   1469: invokestatic O : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1472: goto -> 2344
    //   1475: aload_0
    //   1476: iload #6
    //   1478: invokespecial Q : (I)I
    //   1481: aload_1
    //   1482: iload #7
    //   1484: invokestatic R : (I)J
    //   1487: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1490: checkcast java/util/List
    //   1493: aload_2
    //   1494: aload_0
    //   1495: iload #6
    //   1497: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1500: invokestatic X : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1503: goto -> 2344
    //   1506: aload_0
    //   1507: iload #6
    //   1509: invokespecial Q : (I)I
    //   1512: aload_1
    //   1513: iload #7
    //   1515: invokestatic R : (I)J
    //   1518: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1521: checkcast java/util/List
    //   1524: aload_2
    //   1525: invokestatic c0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;)V
    //   1528: goto -> 2344
    //   1531: aload_0
    //   1532: iload #6
    //   1534: invokespecial Q : (I)I
    //   1537: aload_1
    //   1538: iload #7
    //   1540: invokestatic R : (I)J
    //   1543: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1546: checkcast java/util/List
    //   1549: aload_2
    //   1550: iconst_0
    //   1551: invokestatic N : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1554: goto -> 2344
    //   1557: aload_0
    //   1558: iload #6
    //   1560: invokespecial Q : (I)I
    //   1563: aload_1
    //   1564: iload #7
    //   1566: invokestatic R : (I)J
    //   1569: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1572: checkcast java/util/List
    //   1575: aload_2
    //   1576: iconst_0
    //   1577: invokestatic R : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1580: goto -> 2344
    //   1583: aload_0
    //   1584: iload #6
    //   1586: invokespecial Q : (I)I
    //   1589: aload_1
    //   1590: iload #7
    //   1592: invokestatic R : (I)J
    //   1595: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1598: checkcast java/util/List
    //   1601: aload_2
    //   1602: iconst_0
    //   1603: invokestatic S : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1606: goto -> 2344
    //   1609: aload_0
    //   1610: iload #6
    //   1612: invokespecial Q : (I)I
    //   1615: aload_1
    //   1616: iload #7
    //   1618: invokestatic R : (I)J
    //   1621: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1624: checkcast java/util/List
    //   1627: aload_2
    //   1628: iconst_0
    //   1629: invokestatic V : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1632: goto -> 2344
    //   1635: aload_0
    //   1636: iload #6
    //   1638: invokespecial Q : (I)I
    //   1641: aload_1
    //   1642: iload #7
    //   1644: invokestatic R : (I)J
    //   1647: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1650: checkcast java/util/List
    //   1653: aload_2
    //   1654: iconst_0
    //   1655: invokestatic e0 : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1658: goto -> 2344
    //   1661: aload_0
    //   1662: iload #6
    //   1664: invokespecial Q : (I)I
    //   1667: aload_1
    //   1668: iload #7
    //   1670: invokestatic R : (I)J
    //   1673: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1676: checkcast java/util/List
    //   1679: aload_2
    //   1680: iconst_0
    //   1681: invokestatic W : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1684: goto -> 2344
    //   1687: aload_0
    //   1688: iload #6
    //   1690: invokespecial Q : (I)I
    //   1693: aload_1
    //   1694: iload #7
    //   1696: invokestatic R : (I)J
    //   1699: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1702: checkcast java/util/List
    //   1705: aload_2
    //   1706: iconst_0
    //   1707: invokestatic T : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1710: goto -> 2344
    //   1713: aload_0
    //   1714: iload #6
    //   1716: invokespecial Q : (I)I
    //   1719: aload_1
    //   1720: iload #7
    //   1722: invokestatic R : (I)J
    //   1725: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1728: checkcast java/util/List
    //   1731: aload_2
    //   1732: iconst_0
    //   1733: invokestatic P : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/u1;Z)V
    //   1736: goto -> 2344
    //   1739: aload_0
    //   1740: aload_1
    //   1741: iload #6
    //   1743: invokespecial y : (Ljava/lang/Object;I)Z
    //   1746: ifeq -> 2344
    //   1749: aload_2
    //   1750: iload #8
    //   1752: aload_1
    //   1753: iload #7
    //   1755: invokestatic R : (I)J
    //   1758: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1761: aload_0
    //   1762: iload #6
    //   1764: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1767: invokeinterface O : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   1772: goto -> 2344
    //   1775: aload_0
    //   1776: aload_1
    //   1777: iload #6
    //   1779: invokespecial y : (Ljava/lang/Object;I)Z
    //   1782: ifeq -> 2344
    //   1785: aload_1
    //   1786: iload #7
    //   1788: invokestatic R : (I)J
    //   1791: invokestatic H : (Ljava/lang/Object;J)J
    //   1794: lstore #9
    //   1796: aload_2
    //   1797: iload #8
    //   1799: lload #9
    //   1801: invokeinterface w : (IJ)V
    //   1806: goto -> 2344
    //   1809: aload_0
    //   1810: aload_1
    //   1811: iload #6
    //   1813: invokespecial y : (Ljava/lang/Object;I)Z
    //   1816: ifeq -> 2344
    //   1819: aload_1
    //   1820: iload #7
    //   1822: invokestatic R : (I)J
    //   1825: invokestatic w : (Ljava/lang/Object;J)I
    //   1828: istore #7
    //   1830: aload_2
    //   1831: iload #8
    //   1833: iload #7
    //   1835: invokeinterface H : (II)V
    //   1840: goto -> 2344
    //   1843: aload_0
    //   1844: aload_1
    //   1845: iload #6
    //   1847: invokespecial y : (Ljava/lang/Object;I)Z
    //   1850: ifeq -> 2344
    //   1853: aload_1
    //   1854: iload #7
    //   1856: invokestatic R : (I)J
    //   1859: invokestatic H : (Ljava/lang/Object;J)J
    //   1862: lstore #9
    //   1864: aload_2
    //   1865: iload #8
    //   1867: lload #9
    //   1869: invokeinterface n : (IJ)V
    //   1874: goto -> 2344
    //   1877: aload_0
    //   1878: aload_1
    //   1879: iload #6
    //   1881: invokespecial y : (Ljava/lang/Object;I)Z
    //   1884: ifeq -> 2344
    //   1887: aload_1
    //   1888: iload #7
    //   1890: invokestatic R : (I)J
    //   1893: invokestatic w : (Ljava/lang/Object;J)I
    //   1896: istore #7
    //   1898: aload_2
    //   1899: iload #8
    //   1901: iload #7
    //   1903: invokeinterface g : (II)V
    //   1908: goto -> 2344
    //   1911: aload_0
    //   1912: aload_1
    //   1913: iload #6
    //   1915: invokespecial y : (Ljava/lang/Object;I)Z
    //   1918: ifeq -> 2344
    //   1921: aload_1
    //   1922: iload #7
    //   1924: invokestatic R : (I)J
    //   1927: invokestatic w : (Ljava/lang/Object;J)I
    //   1930: istore #7
    //   1932: aload_2
    //   1933: iload #8
    //   1935: iload #7
    //   1937: invokeinterface D : (II)V
    //   1942: goto -> 2344
    //   1945: aload_0
    //   1946: aload_1
    //   1947: iload #6
    //   1949: invokespecial y : (Ljava/lang/Object;I)Z
    //   1952: ifeq -> 2344
    //   1955: aload_1
    //   1956: iload #7
    //   1958: invokestatic R : (I)J
    //   1961: invokestatic w : (Ljava/lang/Object;J)I
    //   1964: istore #7
    //   1966: aload_2
    //   1967: iload #8
    //   1969: iload #7
    //   1971: invokeinterface e : (II)V
    //   1976: goto -> 2344
    //   1979: aload_0
    //   1980: aload_1
    //   1981: iload #6
    //   1983: invokespecial y : (Ljava/lang/Object;I)Z
    //   1986: ifeq -> 2344
    //   1989: aload_2
    //   1990: iload #8
    //   1992: aload_1
    //   1993: iload #7
    //   1995: invokestatic R : (I)J
    //   1998: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2001: checkcast androidx/datastore/preferences/protobuf/h
    //   2004: invokeinterface J : (ILandroidx/datastore/preferences/protobuf/h;)V
    //   2009: goto -> 2344
    //   2012: aload_0
    //   2013: aload_1
    //   2014: iload #6
    //   2016: invokespecial y : (Ljava/lang/Object;I)Z
    //   2019: ifeq -> 2344
    //   2022: aload_2
    //   2023: iload #8
    //   2025: aload_1
    //   2026: iload #7
    //   2028: invokestatic R : (I)J
    //   2031: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2034: aload_0
    //   2035: iload #6
    //   2037: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2040: invokeinterface K : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)V
    //   2045: goto -> 2344
    //   2048: aload_0
    //   2049: aload_1
    //   2050: iload #6
    //   2052: invokespecial y : (Ljava/lang/Object;I)Z
    //   2055: ifeq -> 2344
    //   2058: aload_0
    //   2059: iload #8
    //   2061: aload_1
    //   2062: iload #7
    //   2064: invokestatic R : (I)J
    //   2067: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2070: aload_2
    //   2071: invokespecial n0 : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/u1;)V
    //   2074: goto -> 2344
    //   2077: aload_0
    //   2078: aload_1
    //   2079: iload #6
    //   2081: invokespecial y : (Ljava/lang/Object;I)Z
    //   2084: ifeq -> 2344
    //   2087: aload_1
    //   2088: iload #7
    //   2090: invokestatic R : (I)J
    //   2093: invokestatic k : (Ljava/lang/Object;J)Z
    //   2096: istore #11
    //   2098: aload_2
    //   2099: iload #8
    //   2101: iload #11
    //   2103: invokeinterface d : (IZ)V
    //   2108: goto -> 2344
    //   2111: aload_0
    //   2112: aload_1
    //   2113: iload #6
    //   2115: invokespecial y : (Ljava/lang/Object;I)Z
    //   2118: ifeq -> 2344
    //   2121: aload_1
    //   2122: iload #7
    //   2124: invokestatic R : (I)J
    //   2127: invokestatic w : (Ljava/lang/Object;J)I
    //   2130: istore #7
    //   2132: aload_2
    //   2133: iload #8
    //   2135: iload #7
    //   2137: invokeinterface l : (II)V
    //   2142: goto -> 2344
    //   2145: aload_0
    //   2146: aload_1
    //   2147: iload #6
    //   2149: invokespecial y : (Ljava/lang/Object;I)Z
    //   2152: ifeq -> 2344
    //   2155: aload_1
    //   2156: iload #7
    //   2158: invokestatic R : (I)J
    //   2161: invokestatic H : (Ljava/lang/Object;J)J
    //   2164: lstore #9
    //   2166: aload_2
    //   2167: iload #8
    //   2169: lload #9
    //   2171: invokeinterface u : (IJ)V
    //   2176: goto -> 2344
    //   2179: aload_0
    //   2180: aload_1
    //   2181: iload #6
    //   2183: invokespecial y : (Ljava/lang/Object;I)Z
    //   2186: ifeq -> 2344
    //   2189: aload_1
    //   2190: iload #7
    //   2192: invokestatic R : (I)J
    //   2195: invokestatic w : (Ljava/lang/Object;J)I
    //   2198: istore #7
    //   2200: aload_2
    //   2201: iload #8
    //   2203: iload #7
    //   2205: invokeinterface i : (II)V
    //   2210: goto -> 2344
    //   2213: aload_0
    //   2214: aload_1
    //   2215: iload #6
    //   2217: invokespecial y : (Ljava/lang/Object;I)Z
    //   2220: ifeq -> 2344
    //   2223: aload_1
    //   2224: iload #7
    //   2226: invokestatic R : (I)J
    //   2229: invokestatic H : (Ljava/lang/Object;J)J
    //   2232: lstore #9
    //   2234: aload_2
    //   2235: iload #8
    //   2237: lload #9
    //   2239: invokeinterface C : (IJ)V
    //   2244: goto -> 2344
    //   2247: aload_0
    //   2248: aload_1
    //   2249: iload #6
    //   2251: invokespecial y : (Ljava/lang/Object;I)Z
    //   2254: ifeq -> 2344
    //   2257: aload_1
    //   2258: iload #7
    //   2260: invokestatic R : (I)J
    //   2263: invokestatic H : (Ljava/lang/Object;J)J
    //   2266: lstore #9
    //   2268: aload_2
    //   2269: iload #8
    //   2271: lload #9
    //   2273: invokeinterface c : (IJ)V
    //   2278: goto -> 2344
    //   2281: aload_0
    //   2282: aload_1
    //   2283: iload #6
    //   2285: invokespecial y : (Ljava/lang/Object;I)Z
    //   2288: ifeq -> 2344
    //   2291: aload_1
    //   2292: iload #7
    //   2294: invokestatic R : (I)J
    //   2297: invokestatic p : (Ljava/lang/Object;J)F
    //   2300: fstore #5
    //   2302: aload_2
    //   2303: iload #8
    //   2305: fload #5
    //   2307: invokeinterface x : (IF)V
    //   2312: goto -> 2344
    //   2315: aload_0
    //   2316: aload_1
    //   2317: iload #6
    //   2319: invokespecial y : (Ljava/lang/Object;I)Z
    //   2322: ifeq -> 2344
    //   2325: aload_1
    //   2326: iload #7
    //   2328: invokestatic R : (I)J
    //   2331: invokestatic l : (Ljava/lang/Object;J)D
    //   2334: dstore_3
    //   2335: aload_2
    //   2336: iload #8
    //   2338: dload_3
    //   2339: invokeinterface m : (ID)V
    //   2344: iload #6
    //   2346: iconst_3
    //   2347: isub
    //   2348: istore #6
    //   2350: goto -> 73
    //   2353: aload #13
    //   2355: ifnull -> 2399
    //   2358: aload_0
    //   2359: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   2362: aload_2
    //   2363: aload #13
    //   2365: invokevirtual j : (Landroidx/datastore/preferences/protobuf/u1;Ljava/util/Map$Entry;)V
    //   2368: aload #14
    //   2370: invokeinterface hasNext : ()Z
    //   2375: ifeq -> 2393
    //   2378: aload #14
    //   2380: invokeinterface next : ()Ljava/lang/Object;
    //   2385: checkcast java/util/Map$Entry
    //   2388: astore #13
    //   2390: goto -> 2353
    //   2393: aconst_null
    //   2394: astore #13
    //   2396: goto -> 2353
    //   2399: return
  }
  
  private boolean m(T paramT1, T paramT2, int paramInt) {
    int i = i0(paramInt);
    long l = R(i);
    i = h0(i);
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool8 = false;
    boolean bool9 = false;
    boolean bool10 = false;
    boolean bool11 = false;
    boolean bool12 = false;
    boolean bool13 = false;
    boolean bool14 = false;
    boolean bool15 = false;
    boolean bool16 = false;
    boolean bool17 = false;
    boolean bool18 = false;
    boolean bool19 = false;
    boolean bool20 = false;
    boolean bool2 = false;
    switch (i) {
      default:
        return true;
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 61:
      case 62:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
        bool1 = bool2;
        if (D(paramT1, paramT2, paramInt)) {
          bool1 = bool2;
          if (i1.K(r1.A(paramT1, l), r1.A(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
        return i1.K(r1.A(paramT1, l), r1.A(paramT2, l));
      case 17:
        bool1 = bool3;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool3;
          if (i1.K(r1.A(paramT1, l), r1.A(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 16:
        bool1 = bool4;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool4;
          if (r1.y(paramT1, l) == r1.y(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 15:
        bool1 = bool5;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool5;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 14:
        bool1 = bool6;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool6;
          if (r1.y(paramT1, l) == r1.y(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 13:
        bool1 = bool7;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool7;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 12:
        bool1 = bool8;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool8;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 11:
        bool1 = bool9;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool9;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 10:
        bool1 = bool10;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool10;
          if (i1.K(r1.A(paramT1, l), r1.A(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 9:
        bool1 = bool11;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool11;
          if (i1.K(r1.A(paramT1, l), r1.A(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 8:
        bool1 = bool12;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool12;
          if (i1.K(r1.A(paramT1, l), r1.A(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 7:
        bool1 = bool13;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool13;
          if (r1.p(paramT1, l) == r1.p(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 6:
        bool1 = bool14;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool14;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 5:
        bool1 = bool15;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool15;
          if (r1.y(paramT1, l) == r1.y(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 4:
        bool1 = bool16;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool16;
          if (r1.x(paramT1, l) == r1.x(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 3:
        bool1 = bool17;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool17;
          if (r1.y(paramT1, l) == r1.y(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 2:
        bool1 = bool18;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool18;
          if (r1.y(paramT1, l) == r1.y(paramT2, l))
            bool1 = true; 
        } 
        return bool1;
      case 1:
        bool1 = bool19;
        if (j(paramT1, paramT2, paramInt)) {
          bool1 = bool19;
          if (Float.floatToIntBits(r1.w(paramT1, l)) == Float.floatToIntBits(r1.w(paramT2, l)))
            bool1 = true; 
        } 
        return bool1;
      case 0:
        break;
    } 
    boolean bool1 = bool20;
    if (j(paramT1, paramT2, paramInt)) {
      bool1 = bool20;
      if (Double.doubleToLongBits(r1.v(paramT1, l)) == Double.doubleToLongBits(r1.v(paramT2, l)))
        bool1 = true; 
    } 
    return bool1;
  }
  
  private <K, V> void m0(u1 paramu1, int paramInt1, Object paramObject, int paramInt2) {
    if (paramObject != null)
      paramu1.N(paramInt1, this.q.f(r(paramInt2)), this.q.g(paramObject)); 
  }
  
  private final <UT, UB> UB n(Object paramObject, int paramInt, UB paramUB, n1<UT, UB> paramn1) {
    int i = Q(paramInt);
    paramObject = r1.A(paramObject, R(i0(paramInt)));
    if (paramObject == null)
      return paramUB; 
    a0.e e = q(paramInt);
    return (e == null) ? paramUB : o(paramInt, i, this.q.h(paramObject), e, paramUB, paramn1);
  }
  
  private void n0(int paramInt, Object paramObject, u1 paramu1) {
    if (paramObject instanceof String) {
      paramu1.A(paramInt, (String)paramObject);
      return;
    } 
    paramu1.J(paramInt, (h)paramObject);
  }
  
  private final <K, V, UT, UB> UB o(int paramInt1, int paramInt2, Map<K, V> paramMap, a0.e parame, UB paramUB, n1<UT, UB> paramn1) {
    UB uB;
    k0.a<?, ?> a = this.q.f(r(paramInt1));
    Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      if (!parame.a(((Integer)entry.getValue()).intValue())) {
        UB uB1 = paramUB;
        if (paramUB == null)
          uB1 = paramn1.n(); 
        h.h h = h.t(k0.b(a, entry.getKey(), entry.getValue()));
        k k = h.b();
        try {
          k0.e(k, a, entry.getKey(), entry.getValue());
          paramn1.d(uB1, paramInt2, h.a());
          iterator.remove();
          uB = uB1;
        } catch (IOException iOException) {
          throw new RuntimeException(iOException);
        } 
      } 
    } 
    return uB;
  }
  
  private <UT, UB> void o0(n1<UT, UB> paramn1, T paramT, u1 paramu1) {
    paramn1.t(paramn1.g(paramT), paramu1);
  }
  
  private static <T> float p(T paramT, long paramLong) {
    return r1.w(paramT, paramLong);
  }
  
  private a0.e q(int paramInt) {
    return (a0.e)this.b[paramInt / 3 * 2 + 1];
  }
  
  private Object r(int paramInt) {
    return this.b[paramInt / 3 * 2];
  }
  
  private g1 s(int paramInt) {
    paramInt = paramInt / 3 * 2;
    g1<?> g11 = (g1)this.b[paramInt];
    if (g11 != null)
      return g11; 
    g11 = c1.a().d((Class)this.b[paramInt + 1]);
    this.b[paramInt] = g11;
    return g11;
  }
  
  private int t(T paramT) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/u0.s : Lsun/misc/Unsafe;
    //   3: astore #15
    //   5: iconst_m1
    //   6: istore_2
    //   7: iconst_0
    //   8: istore #7
    //   10: iconst_0
    //   11: istore_3
    //   12: iconst_0
    //   13: istore #4
    //   15: iload #7
    //   17: aload_0
    //   18: getfield a : [I
    //   21: arraylength
    //   22: if_icmpge -> 2363
    //   25: aload_0
    //   26: iload #7
    //   28: invokespecial i0 : (I)I
    //   31: istore #11
    //   33: aload_0
    //   34: iload #7
    //   36: invokespecial Q : (I)I
    //   39: istore #10
    //   41: iload #11
    //   43: invokestatic h0 : (I)I
    //   46: istore #12
    //   48: iload #12
    //   50: bipush #17
    //   52: if_icmpgt -> 127
    //   55: aload_0
    //   56: getfield a : [I
    //   59: iload #7
    //   61: iconst_2
    //   62: iadd
    //   63: iaload
    //   64: istore #8
    //   66: ldc 1048575
    //   68: iload #8
    //   70: iand
    //   71: istore #9
    //   73: iload_2
    //   74: istore #6
    //   76: iload #4
    //   78: istore #5
    //   80: iload #9
    //   82: iload_2
    //   83: if_icmpeq -> 101
    //   86: aload #15
    //   88: aload_1
    //   89: iload #9
    //   91: i2l
    //   92: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   95: istore #5
    //   97: iload #9
    //   99: istore #6
    //   101: iconst_1
    //   102: iload #8
    //   104: bipush #20
    //   106: iushr
    //   107: ishl
    //   108: istore_2
    //   109: iload #6
    //   111: istore #4
    //   113: iload #5
    //   115: istore #6
    //   117: iload #8
    //   119: istore #5
    //   121: iload_2
    //   122: istore #8
    //   124: goto -> 186
    //   127: aload_0
    //   128: getfield i : Z
    //   131: ifeq -> 173
    //   134: iload #12
    //   136: getstatic androidx/datastore/preferences/protobuf/v.S : Landroidx/datastore/preferences/protobuf/v;
    //   139: invokevirtual a : ()I
    //   142: if_icmplt -> 173
    //   145: iload #12
    //   147: getstatic androidx/datastore/preferences/protobuf/v.f0 : Landroidx/datastore/preferences/protobuf/v;
    //   150: invokevirtual a : ()I
    //   153: if_icmpgt -> 173
    //   156: aload_0
    //   157: getfield a : [I
    //   160: iload #7
    //   162: iconst_2
    //   163: iadd
    //   164: iaload
    //   165: ldc 1048575
    //   167: iand
    //   168: istore #5
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #5
    //   176: iconst_0
    //   177: istore #8
    //   179: iload #4
    //   181: istore #6
    //   183: iload_2
    //   184: istore #4
    //   186: iload #11
    //   188: invokestatic R : (I)J
    //   191: lstore #13
    //   193: iload #12
    //   195: tableswitch default -> 484, 0 -> 2321, 1 -> 2300, 2 -> 2272, 3 -> 2244, 4 -> 2216, 5 -> 2195, 6 -> 2175, 7 -> 2155, 8 -> 2099, 9 -> 2066, 10 -> 2036, 11 -> 2007, 12 -> 1978, 13 -> 1954, 14 -> 1934, 15 -> 1905, 16 -> 1874, 17 -> 1838, 18 -> 1810, 19 -> 1789, 20 -> 1768, 21 -> 1747, 22 -> 1726, 23 -> 1810, 24 -> 1789, 25 -> 1705, 26 -> 1685, 27 -> 1659, 28 -> 1639, 29 -> 1618, 30 -> 1597, 31 -> 1789, 32 -> 1810, 33 -> 1576, 34 -> 1555, 35 -> 1493, 36 -> 1454, 37 -> 1415, 38 -> 1376, 39 -> 1337, 40 -> 1298, 41 -> 1259, 42 -> 1220, 43 -> 1181, 44 -> 1142, 45 -> 1103, 46 -> 1064, 47 -> 1025, 48 -> 986, 49 -> 960, 50 -> 931, 51 -> 907, 52 -> 883, 53 -> 854, 54 -> 825, 55 -> 796, 56 -> 772, 57 -> 748, 58 -> 731, 59 -> 671, 60 -> 654, 61 -> 637, 62 -> 613, 63 -> 589, 64 -> 572, 65 -> 555, 66 -> 531, 67 -> 506, 68 -> 489
    //   484: iload_3
    //   485: istore_2
    //   486: goto -> 1832
    //   489: iload_3
    //   490: istore_2
    //   491: aload_0
    //   492: aload_1
    //   493: iload #10
    //   495: iload #7
    //   497: invokespecial E : (Ljava/lang/Object;II)Z
    //   500: ifeq -> 1832
    //   503: goto -> 1848
    //   506: iload_3
    //   507: istore_2
    //   508: aload_0
    //   509: aload_1
    //   510: iload #10
    //   512: iload #7
    //   514: invokespecial E : (Ljava/lang/Object;II)Z
    //   517: ifeq -> 1832
    //   520: aload_1
    //   521: lload #13
    //   523: invokestatic W : (Ljava/lang/Object;J)J
    //   526: lstore #13
    //   528: goto -> 1894
    //   531: iload_3
    //   532: istore_2
    //   533: aload_0
    //   534: aload_1
    //   535: iload #10
    //   537: iload #7
    //   539: invokespecial E : (Ljava/lang/Object;II)Z
    //   542: ifeq -> 1832
    //   545: aload_1
    //   546: lload #13
    //   548: invokestatic V : (Ljava/lang/Object;J)I
    //   551: istore_2
    //   552: goto -> 1924
    //   555: iload_3
    //   556: istore_2
    //   557: aload_0
    //   558: aload_1
    //   559: iload #10
    //   561: iload #7
    //   563: invokespecial E : (Ljava/lang/Object;II)Z
    //   566: ifeq -> 1832
    //   569: goto -> 1944
    //   572: iload_3
    //   573: istore_2
    //   574: aload_0
    //   575: aload_1
    //   576: iload #10
    //   578: iload #7
    //   580: invokespecial E : (Ljava/lang/Object;II)Z
    //   583: ifeq -> 1832
    //   586: goto -> 1964
    //   589: iload_3
    //   590: istore_2
    //   591: aload_0
    //   592: aload_1
    //   593: iload #10
    //   595: iload #7
    //   597: invokespecial E : (Ljava/lang/Object;II)Z
    //   600: ifeq -> 1832
    //   603: aload_1
    //   604: lload #13
    //   606: invokestatic V : (Ljava/lang/Object;J)I
    //   609: istore_2
    //   610: goto -> 1997
    //   613: iload_3
    //   614: istore_2
    //   615: aload_0
    //   616: aload_1
    //   617: iload #10
    //   619: iload #7
    //   621: invokespecial E : (Ljava/lang/Object;II)Z
    //   624: ifeq -> 1832
    //   627: aload_1
    //   628: lload #13
    //   630: invokestatic V : (Ljava/lang/Object;J)I
    //   633: istore_2
    //   634: goto -> 2026
    //   637: iload_3
    //   638: istore_2
    //   639: aload_0
    //   640: aload_1
    //   641: iload #10
    //   643: iload #7
    //   645: invokespecial E : (Ljava/lang/Object;II)Z
    //   648: ifeq -> 1832
    //   651: goto -> 2046
    //   654: iload_3
    //   655: istore_2
    //   656: aload_0
    //   657: aload_1
    //   658: iload #10
    //   660: iload #7
    //   662: invokespecial E : (Ljava/lang/Object;II)Z
    //   665: ifeq -> 1832
    //   668: goto -> 2076
    //   671: iload_3
    //   672: istore_2
    //   673: aload_0
    //   674: aload_1
    //   675: iload #10
    //   677: iload #7
    //   679: invokespecial E : (Ljava/lang/Object;II)Z
    //   682: ifeq -> 1832
    //   685: aload #15
    //   687: aload_1
    //   688: lload #13
    //   690: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   693: astore #16
    //   695: aload #16
    //   697: instanceof androidx/datastore/preferences/protobuf/h
    //   700: ifeq -> 717
    //   703: iload #10
    //   705: aload #16
    //   707: checkcast androidx/datastore/preferences/protobuf/h
    //   710: invokestatic g : (ILandroidx/datastore/preferences/protobuf/h;)I
    //   713: istore_2
    //   714: goto -> 1828
    //   717: iload #10
    //   719: aload #16
    //   721: checkcast java/lang/String
    //   724: invokestatic T : (ILjava/lang/String;)I
    //   727: istore_2
    //   728: goto -> 1828
    //   731: iload_3
    //   732: istore_2
    //   733: aload_0
    //   734: aload_1
    //   735: iload #10
    //   737: iload #7
    //   739: invokespecial E : (Ljava/lang/Object;II)Z
    //   742: ifeq -> 1832
    //   745: goto -> 2165
    //   748: iload_3
    //   749: istore_2
    //   750: aload_0
    //   751: aload_1
    //   752: iload #10
    //   754: iload #7
    //   756: invokespecial E : (Ljava/lang/Object;II)Z
    //   759: ifeq -> 1832
    //   762: iload #10
    //   764: iconst_0
    //   765: invokestatic m : (II)I
    //   768: istore_2
    //   769: goto -> 1971
    //   772: iload_3
    //   773: istore_2
    //   774: aload_0
    //   775: aload_1
    //   776: iload #10
    //   778: iload #7
    //   780: invokespecial E : (Ljava/lang/Object;II)Z
    //   783: ifeq -> 1832
    //   786: iload #10
    //   788: lconst_0
    //   789: invokestatic o : (IJ)I
    //   792: istore_2
    //   793: goto -> 1828
    //   796: iload_3
    //   797: istore_2
    //   798: aload_0
    //   799: aload_1
    //   800: iload #10
    //   802: iload #7
    //   804: invokespecial E : (Ljava/lang/Object;II)Z
    //   807: ifeq -> 1832
    //   810: iload #10
    //   812: aload_1
    //   813: lload #13
    //   815: invokestatic V : (Ljava/lang/Object;J)I
    //   818: invokestatic v : (II)I
    //   821: istore_2
    //   822: goto -> 1828
    //   825: iload_3
    //   826: istore_2
    //   827: aload_0
    //   828: aload_1
    //   829: iload #10
    //   831: iload #7
    //   833: invokespecial E : (Ljava/lang/Object;II)Z
    //   836: ifeq -> 1832
    //   839: iload #10
    //   841: aload_1
    //   842: lload #13
    //   844: invokestatic W : (Ljava/lang/Object;J)J
    //   847: invokestatic Y : (IJ)I
    //   850: istore_2
    //   851: goto -> 1828
    //   854: iload_3
    //   855: istore_2
    //   856: aload_0
    //   857: aload_1
    //   858: iload #10
    //   860: iload #7
    //   862: invokespecial E : (Ljava/lang/Object;II)Z
    //   865: ifeq -> 1832
    //   868: iload #10
    //   870: aload_1
    //   871: lload #13
    //   873: invokestatic W : (Ljava/lang/Object;J)J
    //   876: invokestatic x : (IJ)I
    //   879: istore_2
    //   880: goto -> 1828
    //   883: iload_3
    //   884: istore_2
    //   885: aload_0
    //   886: aload_1
    //   887: iload #10
    //   889: iload #7
    //   891: invokespecial E : (Ljava/lang/Object;II)Z
    //   894: ifeq -> 1832
    //   897: iload #10
    //   899: fconst_0
    //   900: invokestatic q : (IF)I
    //   903: istore_2
    //   904: goto -> 1828
    //   907: iload_3
    //   908: istore_2
    //   909: aload_0
    //   910: aload_1
    //   911: iload #10
    //   913: iload #7
    //   915: invokespecial E : (Ljava/lang/Object;II)Z
    //   918: ifeq -> 1832
    //   921: iload #10
    //   923: dconst_0
    //   924: invokestatic i : (ID)I
    //   927: istore_2
    //   928: goto -> 1828
    //   931: aload_0
    //   932: getfield q : Landroidx/datastore/preferences/protobuf/m0;
    //   935: iload #10
    //   937: aload #15
    //   939: aload_1
    //   940: lload #13
    //   942: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   945: aload_0
    //   946: iload #7
    //   948: invokespecial r : (I)Ljava/lang/Object;
    //   951: invokeinterface c : (ILjava/lang/Object;Ljava/lang/Object;)I
    //   956: istore_2
    //   957: goto -> 1828
    //   960: iload #10
    //   962: aload #15
    //   964: aload_1
    //   965: lload #13
    //   967: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   970: checkcast java/util/List
    //   973: aload_0
    //   974: iload #7
    //   976: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   979: invokestatic j : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/g1;)I
    //   982: istore_2
    //   983: goto -> 1828
    //   986: aload #15
    //   988: aload_1
    //   989: lload #13
    //   991: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   994: checkcast java/util/List
    //   997: invokestatic t : (Ljava/util/List;)I
    //   1000: istore #8
    //   1002: iload_3
    //   1003: istore_2
    //   1004: iload #8
    //   1006: ifle -> 1832
    //   1009: iload #8
    //   1011: istore_2
    //   1012: aload_0
    //   1013: getfield i : Z
    //   1016: ifeq -> 1539
    //   1019: iload #8
    //   1021: istore_2
    //   1022: goto -> 1529
    //   1025: aload #15
    //   1027: aload_1
    //   1028: lload #13
    //   1030: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1033: checkcast java/util/List
    //   1036: invokestatic r : (Ljava/util/List;)I
    //   1039: istore #8
    //   1041: iload_3
    //   1042: istore_2
    //   1043: iload #8
    //   1045: ifle -> 1832
    //   1048: iload #8
    //   1050: istore_2
    //   1051: aload_0
    //   1052: getfield i : Z
    //   1055: ifeq -> 1539
    //   1058: iload #8
    //   1060: istore_2
    //   1061: goto -> 1529
    //   1064: aload #15
    //   1066: aload_1
    //   1067: lload #13
    //   1069: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1072: checkcast java/util/List
    //   1075: invokestatic i : (Ljava/util/List;)I
    //   1078: istore #8
    //   1080: iload_3
    //   1081: istore_2
    //   1082: iload #8
    //   1084: ifle -> 1832
    //   1087: iload #8
    //   1089: istore_2
    //   1090: aload_0
    //   1091: getfield i : Z
    //   1094: ifeq -> 1539
    //   1097: iload #8
    //   1099: istore_2
    //   1100: goto -> 1529
    //   1103: aload #15
    //   1105: aload_1
    //   1106: lload #13
    //   1108: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1111: checkcast java/util/List
    //   1114: invokestatic g : (Ljava/util/List;)I
    //   1117: istore #8
    //   1119: iload_3
    //   1120: istore_2
    //   1121: iload #8
    //   1123: ifle -> 1832
    //   1126: iload #8
    //   1128: istore_2
    //   1129: aload_0
    //   1130: getfield i : Z
    //   1133: ifeq -> 1539
    //   1136: iload #8
    //   1138: istore_2
    //   1139: goto -> 1529
    //   1142: aload #15
    //   1144: aload_1
    //   1145: lload #13
    //   1147: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1150: checkcast java/util/List
    //   1153: invokestatic e : (Ljava/util/List;)I
    //   1156: istore #8
    //   1158: iload_3
    //   1159: istore_2
    //   1160: iload #8
    //   1162: ifle -> 1832
    //   1165: iload #8
    //   1167: istore_2
    //   1168: aload_0
    //   1169: getfield i : Z
    //   1172: ifeq -> 1539
    //   1175: iload #8
    //   1177: istore_2
    //   1178: goto -> 1529
    //   1181: aload #15
    //   1183: aload_1
    //   1184: lload #13
    //   1186: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1189: checkcast java/util/List
    //   1192: invokestatic w : (Ljava/util/List;)I
    //   1195: istore #8
    //   1197: iload_3
    //   1198: istore_2
    //   1199: iload #8
    //   1201: ifle -> 1832
    //   1204: iload #8
    //   1206: istore_2
    //   1207: aload_0
    //   1208: getfield i : Z
    //   1211: ifeq -> 1539
    //   1214: iload #8
    //   1216: istore_2
    //   1217: goto -> 1529
    //   1220: aload #15
    //   1222: aload_1
    //   1223: lload #13
    //   1225: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1228: checkcast java/util/List
    //   1231: invokestatic b : (Ljava/util/List;)I
    //   1234: istore #8
    //   1236: iload_3
    //   1237: istore_2
    //   1238: iload #8
    //   1240: ifle -> 1832
    //   1243: iload #8
    //   1245: istore_2
    //   1246: aload_0
    //   1247: getfield i : Z
    //   1250: ifeq -> 1539
    //   1253: iload #8
    //   1255: istore_2
    //   1256: goto -> 1529
    //   1259: aload #15
    //   1261: aload_1
    //   1262: lload #13
    //   1264: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1267: checkcast java/util/List
    //   1270: invokestatic g : (Ljava/util/List;)I
    //   1273: istore #8
    //   1275: iload_3
    //   1276: istore_2
    //   1277: iload #8
    //   1279: ifle -> 1832
    //   1282: iload #8
    //   1284: istore_2
    //   1285: aload_0
    //   1286: getfield i : Z
    //   1289: ifeq -> 1539
    //   1292: iload #8
    //   1294: istore_2
    //   1295: goto -> 1529
    //   1298: aload #15
    //   1300: aload_1
    //   1301: lload #13
    //   1303: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1306: checkcast java/util/List
    //   1309: invokestatic i : (Ljava/util/List;)I
    //   1312: istore #8
    //   1314: iload_3
    //   1315: istore_2
    //   1316: iload #8
    //   1318: ifle -> 1832
    //   1321: iload #8
    //   1323: istore_2
    //   1324: aload_0
    //   1325: getfield i : Z
    //   1328: ifeq -> 1539
    //   1331: iload #8
    //   1333: istore_2
    //   1334: goto -> 1529
    //   1337: aload #15
    //   1339: aload_1
    //   1340: lload #13
    //   1342: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1345: checkcast java/util/List
    //   1348: invokestatic l : (Ljava/util/List;)I
    //   1351: istore #8
    //   1353: iload_3
    //   1354: istore_2
    //   1355: iload #8
    //   1357: ifle -> 1832
    //   1360: iload #8
    //   1362: istore_2
    //   1363: aload_0
    //   1364: getfield i : Z
    //   1367: ifeq -> 1539
    //   1370: iload #8
    //   1372: istore_2
    //   1373: goto -> 1529
    //   1376: aload #15
    //   1378: aload_1
    //   1379: lload #13
    //   1381: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1384: checkcast java/util/List
    //   1387: invokestatic y : (Ljava/util/List;)I
    //   1390: istore #8
    //   1392: iload_3
    //   1393: istore_2
    //   1394: iload #8
    //   1396: ifle -> 1832
    //   1399: iload #8
    //   1401: istore_2
    //   1402: aload_0
    //   1403: getfield i : Z
    //   1406: ifeq -> 1539
    //   1409: iload #8
    //   1411: istore_2
    //   1412: goto -> 1529
    //   1415: aload #15
    //   1417: aload_1
    //   1418: lload #13
    //   1420: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1423: checkcast java/util/List
    //   1426: invokestatic n : (Ljava/util/List;)I
    //   1429: istore #8
    //   1431: iload_3
    //   1432: istore_2
    //   1433: iload #8
    //   1435: ifle -> 1832
    //   1438: iload #8
    //   1440: istore_2
    //   1441: aload_0
    //   1442: getfield i : Z
    //   1445: ifeq -> 1539
    //   1448: iload #8
    //   1450: istore_2
    //   1451: goto -> 1529
    //   1454: aload #15
    //   1456: aload_1
    //   1457: lload #13
    //   1459: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1462: checkcast java/util/List
    //   1465: invokestatic g : (Ljava/util/List;)I
    //   1468: istore #8
    //   1470: iload_3
    //   1471: istore_2
    //   1472: iload #8
    //   1474: ifle -> 1832
    //   1477: iload #8
    //   1479: istore_2
    //   1480: aload_0
    //   1481: getfield i : Z
    //   1484: ifeq -> 1539
    //   1487: iload #8
    //   1489: istore_2
    //   1490: goto -> 1529
    //   1493: aload #15
    //   1495: aload_1
    //   1496: lload #13
    //   1498: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1501: checkcast java/util/List
    //   1504: invokestatic i : (Ljava/util/List;)I
    //   1507: istore #8
    //   1509: iload_3
    //   1510: istore_2
    //   1511: iload #8
    //   1513: ifle -> 1832
    //   1516: iload #8
    //   1518: istore_2
    //   1519: aload_0
    //   1520: getfield i : Z
    //   1523: ifeq -> 1539
    //   1526: iload #8
    //   1528: istore_2
    //   1529: aload #15
    //   1531: aload_1
    //   1532: iload #5
    //   1534: i2l
    //   1535: iload_2
    //   1536: invokevirtual putInt : (Ljava/lang/Object;JI)V
    //   1539: iload #10
    //   1541: invokestatic V : (I)I
    //   1544: iload_2
    //   1545: invokestatic X : (I)I
    //   1548: iadd
    //   1549: iload_2
    //   1550: iadd
    //   1551: istore_2
    //   1552: goto -> 1971
    //   1555: iload #10
    //   1557: aload #15
    //   1559: aload_1
    //   1560: lload #13
    //   1562: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1565: checkcast java/util/List
    //   1568: iconst_0
    //   1569: invokestatic s : (ILjava/util/List;Z)I
    //   1572: istore_2
    //   1573: goto -> 1828
    //   1576: iload #10
    //   1578: aload #15
    //   1580: aload_1
    //   1581: lload #13
    //   1583: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1586: checkcast java/util/List
    //   1589: iconst_0
    //   1590: invokestatic q : (ILjava/util/List;Z)I
    //   1593: istore_2
    //   1594: goto -> 1828
    //   1597: iload #10
    //   1599: aload #15
    //   1601: aload_1
    //   1602: lload #13
    //   1604: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1607: checkcast java/util/List
    //   1610: iconst_0
    //   1611: invokestatic d : (ILjava/util/List;Z)I
    //   1614: istore_2
    //   1615: goto -> 1828
    //   1618: iload #10
    //   1620: aload #15
    //   1622: aload_1
    //   1623: lload #13
    //   1625: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1628: checkcast java/util/List
    //   1631: iconst_0
    //   1632: invokestatic v : (ILjava/util/List;Z)I
    //   1635: istore_2
    //   1636: goto -> 1828
    //   1639: iload #10
    //   1641: aload #15
    //   1643: aload_1
    //   1644: lload #13
    //   1646: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1649: checkcast java/util/List
    //   1652: invokestatic c : (ILjava/util/List;)I
    //   1655: istore_2
    //   1656: goto -> 1828
    //   1659: iload #10
    //   1661: aload #15
    //   1663: aload_1
    //   1664: lload #13
    //   1666: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1669: checkcast java/util/List
    //   1672: aload_0
    //   1673: iload #7
    //   1675: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1678: invokestatic p : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/g1;)I
    //   1681: istore_2
    //   1682: goto -> 1828
    //   1685: iload #10
    //   1687: aload #15
    //   1689: aload_1
    //   1690: lload #13
    //   1692: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1695: checkcast java/util/List
    //   1698: invokestatic u : (ILjava/util/List;)I
    //   1701: istore_2
    //   1702: goto -> 1828
    //   1705: iload #10
    //   1707: aload #15
    //   1709: aload_1
    //   1710: lload #13
    //   1712: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1715: checkcast java/util/List
    //   1718: iconst_0
    //   1719: invokestatic a : (ILjava/util/List;Z)I
    //   1722: istore_2
    //   1723: goto -> 1828
    //   1726: iload #10
    //   1728: aload #15
    //   1730: aload_1
    //   1731: lload #13
    //   1733: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1736: checkcast java/util/List
    //   1739: iconst_0
    //   1740: invokestatic k : (ILjava/util/List;Z)I
    //   1743: istore_2
    //   1744: goto -> 1828
    //   1747: iload #10
    //   1749: aload #15
    //   1751: aload_1
    //   1752: lload #13
    //   1754: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1757: checkcast java/util/List
    //   1760: iconst_0
    //   1761: invokestatic x : (ILjava/util/List;Z)I
    //   1764: istore_2
    //   1765: goto -> 1828
    //   1768: iload #10
    //   1770: aload #15
    //   1772: aload_1
    //   1773: lload #13
    //   1775: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1778: checkcast java/util/List
    //   1781: iconst_0
    //   1782: invokestatic m : (ILjava/util/List;Z)I
    //   1785: istore_2
    //   1786: goto -> 1828
    //   1789: iload #10
    //   1791: aload #15
    //   1793: aload_1
    //   1794: lload #13
    //   1796: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1799: checkcast java/util/List
    //   1802: iconst_0
    //   1803: invokestatic f : (ILjava/util/List;Z)I
    //   1806: istore_2
    //   1807: goto -> 1828
    //   1810: iload #10
    //   1812: aload #15
    //   1814: aload_1
    //   1815: lload #13
    //   1817: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1820: checkcast java/util/List
    //   1823: iconst_0
    //   1824: invokestatic h : (ILjava/util/List;Z)I
    //   1827: istore_2
    //   1828: iload_3
    //   1829: iload_2
    //   1830: iadd
    //   1831: istore_2
    //   1832: iload_2
    //   1833: istore #5
    //   1835: goto -> 2344
    //   1838: iload_3
    //   1839: istore_2
    //   1840: iload #6
    //   1842: iload #8
    //   1844: iand
    //   1845: ifeq -> 1832
    //   1848: iload #10
    //   1850: aload #15
    //   1852: aload_1
    //   1853: lload #13
    //   1855: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1858: checkcast androidx/datastore/preferences/protobuf/r0
    //   1861: aload_0
    //   1862: iload #7
    //   1864: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1867: invokestatic s : (ILandroidx/datastore/preferences/protobuf/r0;Landroidx/datastore/preferences/protobuf/g1;)I
    //   1870: istore_2
    //   1871: goto -> 1828
    //   1874: iload_3
    //   1875: istore_2
    //   1876: iload #6
    //   1878: iload #8
    //   1880: iand
    //   1881: ifeq -> 1832
    //   1884: aload #15
    //   1886: aload_1
    //   1887: lload #13
    //   1889: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   1892: lstore #13
    //   1894: iload #10
    //   1896: lload #13
    //   1898: invokestatic R : (IJ)I
    //   1901: istore_2
    //   1902: goto -> 1828
    //   1905: iload_3
    //   1906: istore_2
    //   1907: iload #6
    //   1909: iload #8
    //   1911: iand
    //   1912: ifeq -> 1832
    //   1915: aload #15
    //   1917: aload_1
    //   1918: lload #13
    //   1920: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   1923: istore_2
    //   1924: iload #10
    //   1926: iload_2
    //   1927: invokestatic P : (II)I
    //   1930: istore_2
    //   1931: goto -> 1828
    //   1934: iload_3
    //   1935: istore_2
    //   1936: iload #6
    //   1938: iload #8
    //   1940: iand
    //   1941: ifeq -> 1832
    //   1944: iload #10
    //   1946: lconst_0
    //   1947: invokestatic N : (IJ)I
    //   1950: istore_2
    //   1951: goto -> 1828
    //   1954: iload_3
    //   1955: istore_2
    //   1956: iload #6
    //   1958: iload #8
    //   1960: iand
    //   1961: ifeq -> 1832
    //   1964: iload #10
    //   1966: iconst_0
    //   1967: invokestatic L : (II)I
    //   1970: istore_2
    //   1971: iload_3
    //   1972: iload_2
    //   1973: iadd
    //   1974: istore_2
    //   1975: goto -> 1832
    //   1978: iload_3
    //   1979: istore_2
    //   1980: iload #6
    //   1982: iload #8
    //   1984: iand
    //   1985: ifeq -> 1832
    //   1988: aload #15
    //   1990: aload_1
    //   1991: lload #13
    //   1993: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   1996: istore_2
    //   1997: iload #10
    //   1999: iload_2
    //   2000: invokestatic k : (II)I
    //   2003: istore_2
    //   2004: goto -> 1828
    //   2007: iload_3
    //   2008: istore_2
    //   2009: iload #6
    //   2011: iload #8
    //   2013: iand
    //   2014: ifeq -> 1832
    //   2017: aload #15
    //   2019: aload_1
    //   2020: lload #13
    //   2022: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2025: istore_2
    //   2026: iload #10
    //   2028: iload_2
    //   2029: invokestatic W : (II)I
    //   2032: istore_2
    //   2033: goto -> 1828
    //   2036: iload_3
    //   2037: istore_2
    //   2038: iload #6
    //   2040: iload #8
    //   2042: iand
    //   2043: ifeq -> 1832
    //   2046: iload #10
    //   2048: aload #15
    //   2050: aload_1
    //   2051: lload #13
    //   2053: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2056: checkcast androidx/datastore/preferences/protobuf/h
    //   2059: invokestatic g : (ILandroidx/datastore/preferences/protobuf/h;)I
    //   2062: istore_2
    //   2063: goto -> 1828
    //   2066: iload_3
    //   2067: istore_2
    //   2068: iload #6
    //   2070: iload #8
    //   2072: iand
    //   2073: ifeq -> 1832
    //   2076: iload #10
    //   2078: aload #15
    //   2080: aload_1
    //   2081: lload #13
    //   2083: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2086: aload_0
    //   2087: iload #7
    //   2089: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   2092: invokestatic o : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)I
    //   2095: istore_2
    //   2096: goto -> 1828
    //   2099: iload_3
    //   2100: istore_2
    //   2101: iload #6
    //   2103: iload #8
    //   2105: iand
    //   2106: ifeq -> 1832
    //   2109: aload #15
    //   2111: aload_1
    //   2112: lload #13
    //   2114: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   2117: astore #16
    //   2119: aload #16
    //   2121: instanceof androidx/datastore/preferences/protobuf/h
    //   2124: ifeq -> 2141
    //   2127: iload #10
    //   2129: aload #16
    //   2131: checkcast androidx/datastore/preferences/protobuf/h
    //   2134: invokestatic g : (ILandroidx/datastore/preferences/protobuf/h;)I
    //   2137: istore_2
    //   2138: goto -> 1828
    //   2141: iload #10
    //   2143: aload #16
    //   2145: checkcast java/lang/String
    //   2148: invokestatic T : (ILjava/lang/String;)I
    //   2151: istore_2
    //   2152: goto -> 1828
    //   2155: iload_3
    //   2156: istore_2
    //   2157: iload #6
    //   2159: iload #8
    //   2161: iand
    //   2162: ifeq -> 1832
    //   2165: iload #10
    //   2167: iconst_1
    //   2168: invokestatic d : (IZ)I
    //   2171: istore_2
    //   2172: goto -> 1828
    //   2175: iload_3
    //   2176: istore_2
    //   2177: iload #6
    //   2179: iload #8
    //   2181: iand
    //   2182: ifeq -> 1832
    //   2185: iload #10
    //   2187: iconst_0
    //   2188: invokestatic m : (II)I
    //   2191: istore_2
    //   2192: goto -> 2339
    //   2195: iload_3
    //   2196: istore #5
    //   2198: iload #6
    //   2200: iload #8
    //   2202: iand
    //   2203: ifeq -> 2344
    //   2206: iload #10
    //   2208: lconst_0
    //   2209: invokestatic o : (IJ)I
    //   2212: istore_2
    //   2213: goto -> 2339
    //   2216: iload_3
    //   2217: istore #5
    //   2219: iload #6
    //   2221: iload #8
    //   2223: iand
    //   2224: ifeq -> 2344
    //   2227: iload #10
    //   2229: aload #15
    //   2231: aload_1
    //   2232: lload #13
    //   2234: invokevirtual getInt : (Ljava/lang/Object;J)I
    //   2237: invokestatic v : (II)I
    //   2240: istore_2
    //   2241: goto -> 2339
    //   2244: iload_3
    //   2245: istore #5
    //   2247: iload #6
    //   2249: iload #8
    //   2251: iand
    //   2252: ifeq -> 2344
    //   2255: iload #10
    //   2257: aload #15
    //   2259: aload_1
    //   2260: lload #13
    //   2262: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2265: invokestatic Y : (IJ)I
    //   2268: istore_2
    //   2269: goto -> 2339
    //   2272: iload_3
    //   2273: istore #5
    //   2275: iload #6
    //   2277: iload #8
    //   2279: iand
    //   2280: ifeq -> 2344
    //   2283: iload #10
    //   2285: aload #15
    //   2287: aload_1
    //   2288: lload #13
    //   2290: invokevirtual getLong : (Ljava/lang/Object;J)J
    //   2293: invokestatic x : (IJ)I
    //   2296: istore_2
    //   2297: goto -> 2339
    //   2300: iload_3
    //   2301: istore #5
    //   2303: iload #6
    //   2305: iload #8
    //   2307: iand
    //   2308: ifeq -> 2344
    //   2311: iload #10
    //   2313: fconst_0
    //   2314: invokestatic q : (IF)I
    //   2317: istore_2
    //   2318: goto -> 2339
    //   2321: iload_3
    //   2322: istore #5
    //   2324: iload #6
    //   2326: iload #8
    //   2328: iand
    //   2329: ifeq -> 2344
    //   2332: iload #10
    //   2334: dconst_0
    //   2335: invokestatic i : (ID)I
    //   2338: istore_2
    //   2339: iload_3
    //   2340: iload_2
    //   2341: iadd
    //   2342: istore #5
    //   2344: iload #7
    //   2346: iconst_3
    //   2347: iadd
    //   2348: istore #7
    //   2350: iload #4
    //   2352: istore_2
    //   2353: iload #5
    //   2355: istore_3
    //   2356: iload #6
    //   2358: istore #4
    //   2360: goto -> 15
    //   2363: iload_3
    //   2364: aload_0
    //   2365: aload_0
    //   2366: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   2369: aload_1
    //   2370: invokespecial v : (Landroidx/datastore/preferences/protobuf/n1;Ljava/lang/Object;)I
    //   2373: iadd
    //   2374: istore_3
    //   2375: iload_3
    //   2376: istore_2
    //   2377: aload_0
    //   2378: getfield f : Z
    //   2381: ifeq -> 2398
    //   2384: iload_3
    //   2385: aload_0
    //   2386: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   2389: aload_1
    //   2390: invokevirtual c : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   2393: invokevirtual l : ()I
    //   2396: iadd
    //   2397: istore_2
    //   2398: iload_2
    //   2399: ireturn
  }
  
  private int u(T paramT) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/u0.s : Lsun/misc/Unsafe;
    //   3: astore #12
    //   5: iconst_0
    //   6: istore_3
    //   7: iconst_0
    //   8: istore #4
    //   10: iload_3
    //   11: aload_0
    //   12: getfield a : [I
    //   15: arraylength
    //   16: if_icmpge -> 2135
    //   19: aload_0
    //   20: iload_3
    //   21: invokespecial i0 : (I)I
    //   24: istore #5
    //   26: iload #5
    //   28: invokestatic h0 : (I)I
    //   31: istore_2
    //   32: aload_0
    //   33: iload_3
    //   34: invokespecial Q : (I)I
    //   37: istore #7
    //   39: iload #5
    //   41: invokestatic R : (I)J
    //   44: lstore #8
    //   46: iload_2
    //   47: getstatic androidx/datastore/preferences/protobuf/v.S : Landroidx/datastore/preferences/protobuf/v;
    //   50: invokevirtual a : ()I
    //   53: if_icmplt -> 82
    //   56: iload_2
    //   57: getstatic androidx/datastore/preferences/protobuf/v.f0 : Landroidx/datastore/preferences/protobuf/v;
    //   60: invokevirtual a : ()I
    //   63: if_icmpgt -> 82
    //   66: aload_0
    //   67: getfield a : [I
    //   70: iload_3
    //   71: iconst_2
    //   72: iadd
    //   73: iaload
    //   74: ldc 1048575
    //   76: iand
    //   77: istore #5
    //   79: goto -> 85
    //   82: iconst_0
    //   83: istore #5
    //   85: iload_2
    //   86: tableswitch default -> 376, 0 -> 2103, 1 -> 2081, 2 -> 2050, 3 -> 2019, 4 -> 1990, 5 -> 1968, 6 -> 1946, 7 -> 1924, 8 -> 1885, 9 -> 1853, 10 -> 1819, 11 -> 1790, 12 -> 1761, 13 -> 1739, 14 -> 1717, 15 -> 1688, 16 -> 1657, 17 -> 1622, 18 -> 1601, 19 -> 1585, 20 -> 1569, 21 -> 1553, 22 -> 1537, 23 -> 1601, 24 -> 1585, 25 -> 1521, 26 -> 1506, 27 -> 1486, 28 -> 1471, 29 -> 1455, 30 -> 1439, 31 -> 1585, 32 -> 1601, 33 -> 1423, 34 -> 1407, 35 -> 1344, 36 -> 1304, 37 -> 1264, 38 -> 1224, 39 -> 1184, 40 -> 1144, 41 -> 1104, 42 -> 1064, 43 -> 1024, 44 -> 984, 45 -> 944, 46 -> 904, 47 -> 864, 48 -> 824, 49 -> 804, 50 -> 778, 51 -> 761, 52 -> 744, 53 -> 719, 54 -> 694, 55 -> 670, 56 -> 653, 57 -> 636, 58 -> 619, 59 -> 564, 60 -> 547, 61 -> 530, 62 -> 506, 63 -> 482, 64 -> 465, 65 -> 448, 66 -> 424, 67 -> 399, 68 -> 382
    //   376: iload #4
    //   378: istore_2
    //   379: goto -> 2125
    //   382: iload #4
    //   384: istore_2
    //   385: aload_0
    //   386: aload_1
    //   387: iload #7
    //   389: iload_3
    //   390: invokespecial E : (Ljava/lang/Object;II)Z
    //   393: ifeq -> 2125
    //   396: goto -> 1634
    //   399: iload #4
    //   401: istore_2
    //   402: aload_0
    //   403: aload_1
    //   404: iload #7
    //   406: iload_3
    //   407: invokespecial E : (Ljava/lang/Object;II)Z
    //   410: ifeq -> 2125
    //   413: aload_1
    //   414: lload #8
    //   416: invokestatic W : (Ljava/lang/Object;J)J
    //   419: lstore #8
    //   421: goto -> 1677
    //   424: iload #4
    //   426: istore_2
    //   427: aload_0
    //   428: aload_1
    //   429: iload #7
    //   431: iload_3
    //   432: invokespecial E : (Ljava/lang/Object;II)Z
    //   435: ifeq -> 2125
    //   438: aload_1
    //   439: lload #8
    //   441: invokestatic V : (Ljava/lang/Object;J)I
    //   444: istore_2
    //   445: goto -> 1707
    //   448: iload #4
    //   450: istore_2
    //   451: aload_0
    //   452: aload_1
    //   453: iload #7
    //   455: iload_3
    //   456: invokespecial E : (Ljava/lang/Object;II)Z
    //   459: ifeq -> 2125
    //   462: goto -> 1729
    //   465: iload #4
    //   467: istore_2
    //   468: aload_0
    //   469: aload_1
    //   470: iload #7
    //   472: iload_3
    //   473: invokespecial E : (Ljava/lang/Object;II)Z
    //   476: ifeq -> 2125
    //   479: goto -> 1751
    //   482: iload #4
    //   484: istore_2
    //   485: aload_0
    //   486: aload_1
    //   487: iload #7
    //   489: iload_3
    //   490: invokespecial E : (Ljava/lang/Object;II)Z
    //   493: ifeq -> 2125
    //   496: aload_1
    //   497: lload #8
    //   499: invokestatic V : (Ljava/lang/Object;J)I
    //   502: istore_2
    //   503: goto -> 1780
    //   506: iload #4
    //   508: istore_2
    //   509: aload_0
    //   510: aload_1
    //   511: iload #7
    //   513: iload_3
    //   514: invokespecial E : (Ljava/lang/Object;II)Z
    //   517: ifeq -> 2125
    //   520: aload_1
    //   521: lload #8
    //   523: invokestatic V : (Ljava/lang/Object;J)I
    //   526: istore_2
    //   527: goto -> 1809
    //   530: iload #4
    //   532: istore_2
    //   533: aload_0
    //   534: aload_1
    //   535: iload #7
    //   537: iload_3
    //   538: invokespecial E : (Ljava/lang/Object;II)Z
    //   541: ifeq -> 2125
    //   544: goto -> 1831
    //   547: iload #4
    //   549: istore_2
    //   550: aload_0
    //   551: aload_1
    //   552: iload #7
    //   554: iload_3
    //   555: invokespecial E : (Ljava/lang/Object;II)Z
    //   558: ifeq -> 2125
    //   561: goto -> 1865
    //   564: iload #4
    //   566: istore_2
    //   567: aload_0
    //   568: aload_1
    //   569: iload #7
    //   571: iload_3
    //   572: invokespecial E : (Ljava/lang/Object;II)Z
    //   575: ifeq -> 2125
    //   578: aload_1
    //   579: lload #8
    //   581: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   584: astore #11
    //   586: aload #11
    //   588: astore #10
    //   590: aload #11
    //   592: instanceof androidx/datastore/preferences/protobuf/h
    //   595: ifeq -> 605
    //   598: aload #11
    //   600: astore #10
    //   602: goto -> 1839
    //   605: iload #7
    //   607: aload #10
    //   609: checkcast java/lang/String
    //   612: invokestatic T : (ILjava/lang/String;)I
    //   615: istore_2
    //   616: goto -> 1614
    //   619: iload #4
    //   621: istore_2
    //   622: aload_0
    //   623: aload_1
    //   624: iload #7
    //   626: iload_3
    //   627: invokespecial E : (Ljava/lang/Object;II)Z
    //   630: ifeq -> 2125
    //   633: goto -> 1936
    //   636: iload #4
    //   638: istore_2
    //   639: aload_0
    //   640: aload_1
    //   641: iload #7
    //   643: iload_3
    //   644: invokespecial E : (Ljava/lang/Object;II)Z
    //   647: ifeq -> 2125
    //   650: goto -> 1958
    //   653: iload #4
    //   655: istore_2
    //   656: aload_0
    //   657: aload_1
    //   658: iload #7
    //   660: iload_3
    //   661: invokespecial E : (Ljava/lang/Object;II)Z
    //   664: ifeq -> 2125
    //   667: goto -> 1980
    //   670: iload #4
    //   672: istore_2
    //   673: aload_0
    //   674: aload_1
    //   675: iload #7
    //   677: iload_3
    //   678: invokespecial E : (Ljava/lang/Object;II)Z
    //   681: ifeq -> 2125
    //   684: aload_1
    //   685: lload #8
    //   687: invokestatic V : (Ljava/lang/Object;J)I
    //   690: istore_2
    //   691: goto -> 2009
    //   694: iload #4
    //   696: istore_2
    //   697: aload_0
    //   698: aload_1
    //   699: iload #7
    //   701: iload_3
    //   702: invokespecial E : (Ljava/lang/Object;II)Z
    //   705: ifeq -> 2125
    //   708: aload_1
    //   709: lload #8
    //   711: invokestatic W : (Ljava/lang/Object;J)J
    //   714: lstore #8
    //   716: goto -> 2039
    //   719: iload #4
    //   721: istore_2
    //   722: aload_0
    //   723: aload_1
    //   724: iload #7
    //   726: iload_3
    //   727: invokespecial E : (Ljava/lang/Object;II)Z
    //   730: ifeq -> 2125
    //   733: aload_1
    //   734: lload #8
    //   736: invokestatic W : (Ljava/lang/Object;J)J
    //   739: lstore #8
    //   741: goto -> 2070
    //   744: iload #4
    //   746: istore_2
    //   747: aload_0
    //   748: aload_1
    //   749: iload #7
    //   751: iload_3
    //   752: invokespecial E : (Ljava/lang/Object;II)Z
    //   755: ifeq -> 2125
    //   758: goto -> 2093
    //   761: iload #4
    //   763: istore_2
    //   764: aload_0
    //   765: aload_1
    //   766: iload #7
    //   768: iload_3
    //   769: invokespecial E : (Ljava/lang/Object;II)Z
    //   772: ifeq -> 2125
    //   775: goto -> 2115
    //   778: aload_0
    //   779: getfield q : Landroidx/datastore/preferences/protobuf/m0;
    //   782: iload #7
    //   784: aload_1
    //   785: lload #8
    //   787: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   790: aload_0
    //   791: iload_3
    //   792: invokespecial r : (I)Ljava/lang/Object;
    //   795: invokeinterface c : (ILjava/lang/Object;Ljava/lang/Object;)I
    //   800: istore_2
    //   801: goto -> 1614
    //   804: iload #7
    //   806: aload_1
    //   807: lload #8
    //   809: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   812: aload_0
    //   813: iload_3
    //   814: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   817: invokestatic j : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/g1;)I
    //   820: istore_2
    //   821: goto -> 1614
    //   824: aload #12
    //   826: aload_1
    //   827: lload #8
    //   829: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   832: checkcast java/util/List
    //   835: invokestatic t : (Ljava/util/List;)I
    //   838: istore #6
    //   840: iload #4
    //   842: istore_2
    //   843: iload #6
    //   845: ifle -> 2125
    //   848: iload #6
    //   850: istore_2
    //   851: aload_0
    //   852: getfield i : Z
    //   855: ifeq -> 1391
    //   858: iload #6
    //   860: istore_2
    //   861: goto -> 1381
    //   864: aload #12
    //   866: aload_1
    //   867: lload #8
    //   869: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   872: checkcast java/util/List
    //   875: invokestatic r : (Ljava/util/List;)I
    //   878: istore #6
    //   880: iload #4
    //   882: istore_2
    //   883: iload #6
    //   885: ifle -> 2125
    //   888: iload #6
    //   890: istore_2
    //   891: aload_0
    //   892: getfield i : Z
    //   895: ifeq -> 1391
    //   898: iload #6
    //   900: istore_2
    //   901: goto -> 1381
    //   904: aload #12
    //   906: aload_1
    //   907: lload #8
    //   909: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   912: checkcast java/util/List
    //   915: invokestatic i : (Ljava/util/List;)I
    //   918: istore #6
    //   920: iload #4
    //   922: istore_2
    //   923: iload #6
    //   925: ifle -> 2125
    //   928: iload #6
    //   930: istore_2
    //   931: aload_0
    //   932: getfield i : Z
    //   935: ifeq -> 1391
    //   938: iload #6
    //   940: istore_2
    //   941: goto -> 1381
    //   944: aload #12
    //   946: aload_1
    //   947: lload #8
    //   949: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   952: checkcast java/util/List
    //   955: invokestatic g : (Ljava/util/List;)I
    //   958: istore #6
    //   960: iload #4
    //   962: istore_2
    //   963: iload #6
    //   965: ifle -> 2125
    //   968: iload #6
    //   970: istore_2
    //   971: aload_0
    //   972: getfield i : Z
    //   975: ifeq -> 1391
    //   978: iload #6
    //   980: istore_2
    //   981: goto -> 1381
    //   984: aload #12
    //   986: aload_1
    //   987: lload #8
    //   989: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   992: checkcast java/util/List
    //   995: invokestatic e : (Ljava/util/List;)I
    //   998: istore #6
    //   1000: iload #4
    //   1002: istore_2
    //   1003: iload #6
    //   1005: ifle -> 2125
    //   1008: iload #6
    //   1010: istore_2
    //   1011: aload_0
    //   1012: getfield i : Z
    //   1015: ifeq -> 1391
    //   1018: iload #6
    //   1020: istore_2
    //   1021: goto -> 1381
    //   1024: aload #12
    //   1026: aload_1
    //   1027: lload #8
    //   1029: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1032: checkcast java/util/List
    //   1035: invokestatic w : (Ljava/util/List;)I
    //   1038: istore #6
    //   1040: iload #4
    //   1042: istore_2
    //   1043: iload #6
    //   1045: ifle -> 2125
    //   1048: iload #6
    //   1050: istore_2
    //   1051: aload_0
    //   1052: getfield i : Z
    //   1055: ifeq -> 1391
    //   1058: iload #6
    //   1060: istore_2
    //   1061: goto -> 1381
    //   1064: aload #12
    //   1066: aload_1
    //   1067: lload #8
    //   1069: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1072: checkcast java/util/List
    //   1075: invokestatic b : (Ljava/util/List;)I
    //   1078: istore #6
    //   1080: iload #4
    //   1082: istore_2
    //   1083: iload #6
    //   1085: ifle -> 2125
    //   1088: iload #6
    //   1090: istore_2
    //   1091: aload_0
    //   1092: getfield i : Z
    //   1095: ifeq -> 1391
    //   1098: iload #6
    //   1100: istore_2
    //   1101: goto -> 1381
    //   1104: aload #12
    //   1106: aload_1
    //   1107: lload #8
    //   1109: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1112: checkcast java/util/List
    //   1115: invokestatic g : (Ljava/util/List;)I
    //   1118: istore #6
    //   1120: iload #4
    //   1122: istore_2
    //   1123: iload #6
    //   1125: ifle -> 2125
    //   1128: iload #6
    //   1130: istore_2
    //   1131: aload_0
    //   1132: getfield i : Z
    //   1135: ifeq -> 1391
    //   1138: iload #6
    //   1140: istore_2
    //   1141: goto -> 1381
    //   1144: aload #12
    //   1146: aload_1
    //   1147: lload #8
    //   1149: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1152: checkcast java/util/List
    //   1155: invokestatic i : (Ljava/util/List;)I
    //   1158: istore #6
    //   1160: iload #4
    //   1162: istore_2
    //   1163: iload #6
    //   1165: ifle -> 2125
    //   1168: iload #6
    //   1170: istore_2
    //   1171: aload_0
    //   1172: getfield i : Z
    //   1175: ifeq -> 1391
    //   1178: iload #6
    //   1180: istore_2
    //   1181: goto -> 1381
    //   1184: aload #12
    //   1186: aload_1
    //   1187: lload #8
    //   1189: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1192: checkcast java/util/List
    //   1195: invokestatic l : (Ljava/util/List;)I
    //   1198: istore #6
    //   1200: iload #4
    //   1202: istore_2
    //   1203: iload #6
    //   1205: ifle -> 2125
    //   1208: iload #6
    //   1210: istore_2
    //   1211: aload_0
    //   1212: getfield i : Z
    //   1215: ifeq -> 1391
    //   1218: iload #6
    //   1220: istore_2
    //   1221: goto -> 1381
    //   1224: aload #12
    //   1226: aload_1
    //   1227: lload #8
    //   1229: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1232: checkcast java/util/List
    //   1235: invokestatic y : (Ljava/util/List;)I
    //   1238: istore #6
    //   1240: iload #4
    //   1242: istore_2
    //   1243: iload #6
    //   1245: ifle -> 2125
    //   1248: iload #6
    //   1250: istore_2
    //   1251: aload_0
    //   1252: getfield i : Z
    //   1255: ifeq -> 1391
    //   1258: iload #6
    //   1260: istore_2
    //   1261: goto -> 1381
    //   1264: aload #12
    //   1266: aload_1
    //   1267: lload #8
    //   1269: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1272: checkcast java/util/List
    //   1275: invokestatic n : (Ljava/util/List;)I
    //   1278: istore #6
    //   1280: iload #4
    //   1282: istore_2
    //   1283: iload #6
    //   1285: ifle -> 2125
    //   1288: iload #6
    //   1290: istore_2
    //   1291: aload_0
    //   1292: getfield i : Z
    //   1295: ifeq -> 1391
    //   1298: iload #6
    //   1300: istore_2
    //   1301: goto -> 1381
    //   1304: aload #12
    //   1306: aload_1
    //   1307: lload #8
    //   1309: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1312: checkcast java/util/List
    //   1315: invokestatic g : (Ljava/util/List;)I
    //   1318: istore #6
    //   1320: iload #4
    //   1322: istore_2
    //   1323: iload #6
    //   1325: ifle -> 2125
    //   1328: iload #6
    //   1330: istore_2
    //   1331: aload_0
    //   1332: getfield i : Z
    //   1335: ifeq -> 1391
    //   1338: iload #6
    //   1340: istore_2
    //   1341: goto -> 1381
    //   1344: aload #12
    //   1346: aload_1
    //   1347: lload #8
    //   1349: invokevirtual getObject : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1352: checkcast java/util/List
    //   1355: invokestatic i : (Ljava/util/List;)I
    //   1358: istore #6
    //   1360: iload #4
    //   1362: istore_2
    //   1363: iload #6
    //   1365: ifle -> 2125
    //   1368: iload #6
    //   1370: istore_2
    //   1371: aload_0
    //   1372: getfield i : Z
    //   1375: ifeq -> 1391
    //   1378: iload #6
    //   1380: istore_2
    //   1381: aload #12
    //   1383: aload_1
    //   1384: iload #5
    //   1386: i2l
    //   1387: iload_2
    //   1388: invokevirtual putInt : (Ljava/lang/Object;JI)V
    //   1391: iload #7
    //   1393: invokestatic V : (I)I
    //   1396: iload_2
    //   1397: invokestatic X : (I)I
    //   1400: iadd
    //   1401: iload_2
    //   1402: iadd
    //   1403: istore_2
    //   1404: goto -> 1614
    //   1407: iload #7
    //   1409: aload_1
    //   1410: lload #8
    //   1412: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1415: iconst_0
    //   1416: invokestatic s : (ILjava/util/List;Z)I
    //   1419: istore_2
    //   1420: goto -> 1614
    //   1423: iload #7
    //   1425: aload_1
    //   1426: lload #8
    //   1428: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1431: iconst_0
    //   1432: invokestatic q : (ILjava/util/List;Z)I
    //   1435: istore_2
    //   1436: goto -> 1614
    //   1439: iload #7
    //   1441: aload_1
    //   1442: lload #8
    //   1444: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1447: iconst_0
    //   1448: invokestatic d : (ILjava/util/List;Z)I
    //   1451: istore_2
    //   1452: goto -> 1614
    //   1455: iload #7
    //   1457: aload_1
    //   1458: lload #8
    //   1460: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1463: iconst_0
    //   1464: invokestatic v : (ILjava/util/List;Z)I
    //   1467: istore_2
    //   1468: goto -> 1614
    //   1471: iload #7
    //   1473: aload_1
    //   1474: lload #8
    //   1476: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1479: invokestatic c : (ILjava/util/List;)I
    //   1482: istore_2
    //   1483: goto -> 1614
    //   1486: iload #7
    //   1488: aload_1
    //   1489: lload #8
    //   1491: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1494: aload_0
    //   1495: iload_3
    //   1496: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1499: invokestatic p : (ILjava/util/List;Landroidx/datastore/preferences/protobuf/g1;)I
    //   1502: istore_2
    //   1503: goto -> 1614
    //   1506: iload #7
    //   1508: aload_1
    //   1509: lload #8
    //   1511: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1514: invokestatic u : (ILjava/util/List;)I
    //   1517: istore_2
    //   1518: goto -> 1614
    //   1521: iload #7
    //   1523: aload_1
    //   1524: lload #8
    //   1526: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1529: iconst_0
    //   1530: invokestatic a : (ILjava/util/List;Z)I
    //   1533: istore_2
    //   1534: goto -> 1614
    //   1537: iload #7
    //   1539: aload_1
    //   1540: lload #8
    //   1542: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1545: iconst_0
    //   1546: invokestatic k : (ILjava/util/List;Z)I
    //   1549: istore_2
    //   1550: goto -> 1614
    //   1553: iload #7
    //   1555: aload_1
    //   1556: lload #8
    //   1558: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1561: iconst_0
    //   1562: invokestatic x : (ILjava/util/List;Z)I
    //   1565: istore_2
    //   1566: goto -> 1614
    //   1569: iload #7
    //   1571: aload_1
    //   1572: lload #8
    //   1574: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1577: iconst_0
    //   1578: invokestatic m : (ILjava/util/List;Z)I
    //   1581: istore_2
    //   1582: goto -> 1614
    //   1585: iload #7
    //   1587: aload_1
    //   1588: lload #8
    //   1590: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1593: iconst_0
    //   1594: invokestatic f : (ILjava/util/List;Z)I
    //   1597: istore_2
    //   1598: goto -> 1614
    //   1601: iload #7
    //   1603: aload_1
    //   1604: lload #8
    //   1606: invokestatic G : (Ljava/lang/Object;J)Ljava/util/List;
    //   1609: iconst_0
    //   1610: invokestatic h : (ILjava/util/List;Z)I
    //   1613: istore_2
    //   1614: iload #4
    //   1616: iload_2
    //   1617: iadd
    //   1618: istore_2
    //   1619: goto -> 2125
    //   1622: iload #4
    //   1624: istore_2
    //   1625: aload_0
    //   1626: aload_1
    //   1627: iload_3
    //   1628: invokespecial y : (Ljava/lang/Object;I)Z
    //   1631: ifeq -> 2125
    //   1634: iload #7
    //   1636: aload_1
    //   1637: lload #8
    //   1639: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1642: checkcast androidx/datastore/preferences/protobuf/r0
    //   1645: aload_0
    //   1646: iload_3
    //   1647: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1650: invokestatic s : (ILandroidx/datastore/preferences/protobuf/r0;Landroidx/datastore/preferences/protobuf/g1;)I
    //   1653: istore_2
    //   1654: goto -> 1614
    //   1657: iload #4
    //   1659: istore_2
    //   1660: aload_0
    //   1661: aload_1
    //   1662: iload_3
    //   1663: invokespecial y : (Ljava/lang/Object;I)Z
    //   1666: ifeq -> 2125
    //   1669: aload_1
    //   1670: lload #8
    //   1672: invokestatic y : (Ljava/lang/Object;J)J
    //   1675: lstore #8
    //   1677: iload #7
    //   1679: lload #8
    //   1681: invokestatic R : (IJ)I
    //   1684: istore_2
    //   1685: goto -> 1614
    //   1688: iload #4
    //   1690: istore_2
    //   1691: aload_0
    //   1692: aload_1
    //   1693: iload_3
    //   1694: invokespecial y : (Ljava/lang/Object;I)Z
    //   1697: ifeq -> 2125
    //   1700: aload_1
    //   1701: lload #8
    //   1703: invokestatic x : (Ljava/lang/Object;J)I
    //   1706: istore_2
    //   1707: iload #7
    //   1709: iload_2
    //   1710: invokestatic P : (II)I
    //   1713: istore_2
    //   1714: goto -> 1614
    //   1717: iload #4
    //   1719: istore_2
    //   1720: aload_0
    //   1721: aload_1
    //   1722: iload_3
    //   1723: invokespecial y : (Ljava/lang/Object;I)Z
    //   1726: ifeq -> 2125
    //   1729: iload #7
    //   1731: lconst_0
    //   1732: invokestatic N : (IJ)I
    //   1735: istore_2
    //   1736: goto -> 1614
    //   1739: iload #4
    //   1741: istore_2
    //   1742: aload_0
    //   1743: aload_1
    //   1744: iload_3
    //   1745: invokespecial y : (Ljava/lang/Object;I)Z
    //   1748: ifeq -> 2125
    //   1751: iload #7
    //   1753: iconst_0
    //   1754: invokestatic L : (II)I
    //   1757: istore_2
    //   1758: goto -> 1614
    //   1761: iload #4
    //   1763: istore_2
    //   1764: aload_0
    //   1765: aload_1
    //   1766: iload_3
    //   1767: invokespecial y : (Ljava/lang/Object;I)Z
    //   1770: ifeq -> 2125
    //   1773: aload_1
    //   1774: lload #8
    //   1776: invokestatic x : (Ljava/lang/Object;J)I
    //   1779: istore_2
    //   1780: iload #7
    //   1782: iload_2
    //   1783: invokestatic k : (II)I
    //   1786: istore_2
    //   1787: goto -> 1614
    //   1790: iload #4
    //   1792: istore_2
    //   1793: aload_0
    //   1794: aload_1
    //   1795: iload_3
    //   1796: invokespecial y : (Ljava/lang/Object;I)Z
    //   1799: ifeq -> 2125
    //   1802: aload_1
    //   1803: lload #8
    //   1805: invokestatic x : (Ljava/lang/Object;J)I
    //   1808: istore_2
    //   1809: iload #7
    //   1811: iload_2
    //   1812: invokestatic W : (II)I
    //   1815: istore_2
    //   1816: goto -> 1614
    //   1819: iload #4
    //   1821: istore_2
    //   1822: aload_0
    //   1823: aload_1
    //   1824: iload_3
    //   1825: invokespecial y : (Ljava/lang/Object;I)Z
    //   1828: ifeq -> 2125
    //   1831: aload_1
    //   1832: lload #8
    //   1834: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1837: astore #10
    //   1839: iload #7
    //   1841: aload #10
    //   1843: checkcast androidx/datastore/preferences/protobuf/h
    //   1846: invokestatic g : (ILandroidx/datastore/preferences/protobuf/h;)I
    //   1849: istore_2
    //   1850: goto -> 1614
    //   1853: iload #4
    //   1855: istore_2
    //   1856: aload_0
    //   1857: aload_1
    //   1858: iload_3
    //   1859: invokespecial y : (Ljava/lang/Object;I)Z
    //   1862: ifeq -> 2125
    //   1865: iload #7
    //   1867: aload_1
    //   1868: lload #8
    //   1870: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1873: aload_0
    //   1874: iload_3
    //   1875: invokespecial s : (I)Landroidx/datastore/preferences/protobuf/g1;
    //   1878: invokestatic o : (ILjava/lang/Object;Landroidx/datastore/preferences/protobuf/g1;)I
    //   1881: istore_2
    //   1882: goto -> 1614
    //   1885: iload #4
    //   1887: istore_2
    //   1888: aload_0
    //   1889: aload_1
    //   1890: iload_3
    //   1891: invokespecial y : (Ljava/lang/Object;I)Z
    //   1894: ifeq -> 2125
    //   1897: aload_1
    //   1898: lload #8
    //   1900: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   1903: astore #11
    //   1905: aload #11
    //   1907: astore #10
    //   1909: aload #11
    //   1911: instanceof androidx/datastore/preferences/protobuf/h
    //   1914: ifeq -> 605
    //   1917: aload #11
    //   1919: astore #10
    //   1921: goto -> 602
    //   1924: iload #4
    //   1926: istore_2
    //   1927: aload_0
    //   1928: aload_1
    //   1929: iload_3
    //   1930: invokespecial y : (Ljava/lang/Object;I)Z
    //   1933: ifeq -> 2125
    //   1936: iload #7
    //   1938: iconst_1
    //   1939: invokestatic d : (IZ)I
    //   1942: istore_2
    //   1943: goto -> 1614
    //   1946: iload #4
    //   1948: istore_2
    //   1949: aload_0
    //   1950: aload_1
    //   1951: iload_3
    //   1952: invokespecial y : (Ljava/lang/Object;I)Z
    //   1955: ifeq -> 2125
    //   1958: iload #7
    //   1960: iconst_0
    //   1961: invokestatic m : (II)I
    //   1964: istore_2
    //   1965: goto -> 1614
    //   1968: iload #4
    //   1970: istore_2
    //   1971: aload_0
    //   1972: aload_1
    //   1973: iload_3
    //   1974: invokespecial y : (Ljava/lang/Object;I)Z
    //   1977: ifeq -> 2125
    //   1980: iload #7
    //   1982: lconst_0
    //   1983: invokestatic o : (IJ)I
    //   1986: istore_2
    //   1987: goto -> 1614
    //   1990: iload #4
    //   1992: istore_2
    //   1993: aload_0
    //   1994: aload_1
    //   1995: iload_3
    //   1996: invokespecial y : (Ljava/lang/Object;I)Z
    //   1999: ifeq -> 2125
    //   2002: aload_1
    //   2003: lload #8
    //   2005: invokestatic x : (Ljava/lang/Object;J)I
    //   2008: istore_2
    //   2009: iload #7
    //   2011: iload_2
    //   2012: invokestatic v : (II)I
    //   2015: istore_2
    //   2016: goto -> 1614
    //   2019: iload #4
    //   2021: istore_2
    //   2022: aload_0
    //   2023: aload_1
    //   2024: iload_3
    //   2025: invokespecial y : (Ljava/lang/Object;I)Z
    //   2028: ifeq -> 2125
    //   2031: aload_1
    //   2032: lload #8
    //   2034: invokestatic y : (Ljava/lang/Object;J)J
    //   2037: lstore #8
    //   2039: iload #7
    //   2041: lload #8
    //   2043: invokestatic Y : (IJ)I
    //   2046: istore_2
    //   2047: goto -> 1614
    //   2050: iload #4
    //   2052: istore_2
    //   2053: aload_0
    //   2054: aload_1
    //   2055: iload_3
    //   2056: invokespecial y : (Ljava/lang/Object;I)Z
    //   2059: ifeq -> 2125
    //   2062: aload_1
    //   2063: lload #8
    //   2065: invokestatic y : (Ljava/lang/Object;J)J
    //   2068: lstore #8
    //   2070: iload #7
    //   2072: lload #8
    //   2074: invokestatic x : (IJ)I
    //   2077: istore_2
    //   2078: goto -> 1614
    //   2081: iload #4
    //   2083: istore_2
    //   2084: aload_0
    //   2085: aload_1
    //   2086: iload_3
    //   2087: invokespecial y : (Ljava/lang/Object;I)Z
    //   2090: ifeq -> 2125
    //   2093: iload #7
    //   2095: fconst_0
    //   2096: invokestatic q : (IF)I
    //   2099: istore_2
    //   2100: goto -> 1614
    //   2103: iload #4
    //   2105: istore_2
    //   2106: aload_0
    //   2107: aload_1
    //   2108: iload_3
    //   2109: invokespecial y : (Ljava/lang/Object;I)Z
    //   2112: ifeq -> 2125
    //   2115: iload #7
    //   2117: dconst_0
    //   2118: invokestatic i : (ID)I
    //   2121: istore_2
    //   2122: goto -> 1614
    //   2125: iload_3
    //   2126: iconst_3
    //   2127: iadd
    //   2128: istore_3
    //   2129: iload_2
    //   2130: istore #4
    //   2132: goto -> 10
    //   2135: iload #4
    //   2137: aload_0
    //   2138: aload_0
    //   2139: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   2142: aload_1
    //   2143: invokespecial v : (Landroidx/datastore/preferences/protobuf/n1;Ljava/lang/Object;)I
    //   2146: iadd
    //   2147: ireturn
  }
  
  private <UT, UB> int v(n1<UT, UB> paramn1, T paramT) {
    return paramn1.h(paramn1.g(paramT));
  }
  
  private static <T> int w(T paramT, long paramLong) {
    return r1.x(paramT, paramLong);
  }
  
  private static boolean x(int paramInt) {
    return ((paramInt & 0x20000000) != 0);
  }
  
  private boolean y(T paramT, int paramInt) {
    boolean bool = this.h;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool8 = false;
    boolean bool9 = false;
    boolean bool10 = false;
    boolean bool11 = false;
    boolean bool12 = false;
    boolean bool13 = false;
    boolean bool14 = false;
    boolean bool15 = false;
    boolean bool16 = false;
    boolean bool1 = false;
    if (bool) {
      paramInt = i0(paramInt);
      long l = R(paramInt);
      switch (h0(paramInt)) {
        default:
          throw new IllegalArgumentException();
        case 17:
          if (r1.A(paramT, l) != null)
            bool1 = true; 
          return bool1;
        case 16:
          bool1 = bool2;
          if (r1.y(paramT, l) != 0L)
            bool1 = true; 
          return bool1;
        case 15:
          bool1 = bool3;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 14:
          bool1 = bool4;
          if (r1.y(paramT, l) != 0L)
            bool1 = true; 
          return bool1;
        case 13:
          bool1 = bool5;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 12:
          bool1 = bool6;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 11:
          bool1 = bool7;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 10:
          return h.b.equals(r1.A(paramT, l)) ^ true;
        case 9:
          bool1 = bool8;
          if (r1.A(paramT, l) != null)
            bool1 = true; 
          return bool1;
        case 8:
          paramT = (T)r1.A(paramT, l);
          if (paramT instanceof String)
            return ((String)paramT).isEmpty() ^ true; 
          if (paramT instanceof h)
            return h.b.equals(paramT) ^ true; 
          throw new IllegalArgumentException();
        case 7:
          return r1.p(paramT, l);
        case 6:
          bool1 = bool9;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 5:
          bool1 = bool10;
          if (r1.y(paramT, l) != 0L)
            bool1 = true; 
          return bool1;
        case 4:
          bool1 = bool11;
          if (r1.x(paramT, l) != 0)
            bool1 = true; 
          return bool1;
        case 3:
          bool1 = bool12;
          if (r1.y(paramT, l) != 0L)
            bool1 = true; 
          return bool1;
        case 2:
          bool1 = bool13;
          if (r1.y(paramT, l) != 0L)
            bool1 = true; 
          return bool1;
        case 1:
          bool1 = bool14;
          if (r1.w(paramT, l) != 0.0F)
            bool1 = true; 
          return bool1;
        case 0:
          break;
      } 
      bool1 = bool15;
      if (r1.v(paramT, l) != 0.0D)
        bool1 = true; 
      return bool1;
    } 
    paramInt = Y(paramInt);
    bool1 = bool16;
    if ((r1.x(paramT, (paramInt & 0xFFFFF)) & 1 << paramInt >>> 20) != 0)
      bool1 = true; 
    return bool1;
  }
  
  private boolean z(T paramT, int paramInt1, int paramInt2, int paramInt3) {
    return this.h ? y(paramT, paramInt1) : (((paramInt2 & paramInt3) != 0));
  }
  
  public void a(T paramT1, T paramT2) {
    Objects.requireNonNull(paramT2);
    for (int i = 0; i < this.a.length; i += 3)
      M(paramT1, paramT2, i); 
    if (!this.h) {
      i1.G(this.o, paramT1, paramT2);
      if (this.f)
        i1.E(this.p, paramT1, paramT2); 
    } 
  }
  
  public void b(T paramT) {
    int i = this.k;
    while (true) {
      int j = this.l;
      if (i < j) {
        long l = R(i0(this.j[i]));
        Object object = r1.A(paramT, l);
        if (object != null)
          r1.O(paramT, l, this.q.e(object)); 
        i++;
        continue;
      } 
      int k = this.j.length;
      for (i = j; i < k; i++)
        this.n.c(paramT, this.j[i]); 
      this.o.j(paramT);
      if (this.f)
        this.p.f(paramT); 
      return;
    } 
  }
  
  public final boolean c(T paramT) {
    Object object;
    byte b = -1;
    int i = 0;
    int j = 0;
    while (i < this.k) {
      boolean bool;
      int m = this.j[i];
      int n = Q(m);
      int i1 = i0(m);
      if (!this.h) {
        int i2 = this.a[m + 2];
        int i3 = 0xFFFFF & i2;
        int i4 = 1 << i2 >>> 20;
        Object object1 = object;
        bool = i4;
        if (i3 != object) {
          j = s.getInt(paramT, i3);
          int i5 = i3;
          bool = i4;
        } 
      } else {
        bool = false;
        Object object1 = object;
      } 
      if (F(i1) && !z(paramT, m, j, bool))
        return false; 
      int k = h0(i1);
      if (k != 9 && k != 17) {
        if (k != 27)
          if (k != 60 && k != 68) {
            if (k != 49) {
              if (k == 50 && !C(paramT, i1, m))
                return false; 
              continue;
            } 
          } else {
            if (E(paramT, n, m) && !A(paramT, i1, s(m)))
              return false; 
            continue;
          }  
        if (!B(paramT, i1, m))
          return false; 
        continue;
      } 
      if (z(paramT, m, j, bool) && !A(paramT, i1, s(m)))
        return false; 
      continue;
      i++;
      object = SYNTHETIC_LOCAL_VARIABLE_5;
    } 
    return !(this.f && !this.p.c(paramT).p());
  }
  
  public boolean d(T paramT1, T paramT2) {
    int j = this.a.length;
    for (int i = 0; i < j; i += 3) {
      if (!m(paramT1, paramT2, i))
        return false; 
    } 
    return !this.o.g(paramT1).equals(this.o.g(paramT2)) ? false : (this.f ? this.p.c(paramT1).equals(this.p.c(paramT2)) : true);
  }
  
  public int e(T paramT) {
    return this.h ? u(paramT) : t(paramT);
  }
  
  public T f() {
    return (T)this.m.a(this.e);
  }
  
  public int g(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : [I
    //   4: arraylength
    //   5: istore #8
    //   7: iconst_0
    //   8: istore #7
    //   10: iconst_0
    //   11: istore #6
    //   13: iload #7
    //   15: iload #8
    //   17: if_icmpge -> 1017
    //   20: aload_0
    //   21: iload #7
    //   23: invokespecial i0 : (I)I
    //   26: istore #5
    //   28: aload_0
    //   29: iload #7
    //   31: invokespecial Q : (I)I
    //   34: istore #9
    //   36: iload #5
    //   38: invokestatic R : (I)J
    //   41: lstore #11
    //   43: iload #5
    //   45: invokestatic h0 : (I)I
    //   48: istore #10
    //   50: bipush #37
    //   52: istore #5
    //   54: iload #10
    //   56: tableswitch default -> 348, 0 -> 970, 1 -> 945, 2 -> 927, 3 -> 927, 4 -> 909, 5 -> 927, 6 -> 909, 7 -> 884, 8 -> 860, 9 -> 827, 10 -> 802, 11 -> 909, 12 -> 909, 13 -> 909, 14 -> 927, 15 -> 909, 16 -> 927, 17 -> 786, 18 -> 802, 19 -> 802, 20 -> 802, 21 -> 802, 22 -> 802, 23 -> 802, 24 -> 802, 25 -> 802, 26 -> 802, 27 -> 802, 28 -> 802, 29 -> 802, 30 -> 802, 31 -> 802, 32 -> 802, 33 -> 802, 34 -> 802, 35 -> 802, 36 -> 802, 37 -> 802, 38 -> 802, 39 -> 802, 40 -> 802, 41 -> 802, 42 -> 802, 43 -> 802, 44 -> 802, 45 -> 802, 46 -> 802, 47 -> 802, 48 -> 802, 49 -> 802, 50 -> 802, 51 -> 753, 52 -> 719, 53 -> 685, 54 -> 666, 55 -> 632, 56 -> 613, 57 -> 594, 58 -> 560, 59 -> 541, 60 -> 507, 61 -> 488, 62 -> 469, 63 -> 450, 64 -> 431, 65 -> 412, 66 -> 393, 67 -> 374, 68 -> 355
    //   348: iload #6
    //   350: istore #5
    //   352: goto -> 1004
    //   355: iload #6
    //   357: istore #5
    //   359: aload_0
    //   360: aload_1
    //   361: iload #9
    //   363: iload #7
    //   365: invokespecial E : (Ljava/lang/Object;II)Z
    //   368: ifeq -> 1004
    //   371: goto -> 523
    //   374: iload #6
    //   376: istore #5
    //   378: aload_0
    //   379: aload_1
    //   380: iload #9
    //   382: iload #7
    //   384: invokespecial E : (Ljava/lang/Object;II)Z
    //   387: ifeq -> 1004
    //   390: goto -> 701
    //   393: iload #6
    //   395: istore #5
    //   397: aload_0
    //   398: aload_1
    //   399: iload #9
    //   401: iload #7
    //   403: invokespecial E : (Ljava/lang/Object;II)Z
    //   406: ifeq -> 1004
    //   409: goto -> 466
    //   412: iload #6
    //   414: istore #5
    //   416: aload_0
    //   417: aload_1
    //   418: iload #9
    //   420: iload #7
    //   422: invokespecial E : (Ljava/lang/Object;II)Z
    //   425: ifeq -> 1004
    //   428: goto -> 701
    //   431: iload #6
    //   433: istore #5
    //   435: aload_0
    //   436: aload_1
    //   437: iload #9
    //   439: iload #7
    //   441: invokespecial E : (Ljava/lang/Object;II)Z
    //   444: ifeq -> 1004
    //   447: goto -> 466
    //   450: iload #6
    //   452: istore #5
    //   454: aload_0
    //   455: aload_1
    //   456: iload #9
    //   458: iload #7
    //   460: invokespecial E : (Ljava/lang/Object;II)Z
    //   463: ifeq -> 1004
    //   466: goto -> 648
    //   469: iload #6
    //   471: istore #5
    //   473: aload_0
    //   474: aload_1
    //   475: iload #9
    //   477: iload #7
    //   479: invokespecial E : (Ljava/lang/Object;II)Z
    //   482: ifeq -> 1004
    //   485: goto -> 648
    //   488: iload #6
    //   490: istore #5
    //   492: aload_0
    //   493: aload_1
    //   494: iload #9
    //   496: iload #7
    //   498: invokespecial E : (Ljava/lang/Object;II)Z
    //   501: ifeq -> 1004
    //   504: goto -> 802
    //   507: iload #6
    //   509: istore #5
    //   511: aload_0
    //   512: aload_1
    //   513: iload #9
    //   515: iload #7
    //   517: invokespecial E : (Ljava/lang/Object;II)Z
    //   520: ifeq -> 1004
    //   523: aload_1
    //   524: lload #11
    //   526: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   529: astore #14
    //   531: iload #6
    //   533: bipush #53
    //   535: imul
    //   536: istore #5
    //   538: goto -> 817
    //   541: iload #6
    //   543: istore #5
    //   545: aload_0
    //   546: aload_1
    //   547: iload #9
    //   549: iload #7
    //   551: invokespecial E : (Ljava/lang/Object;II)Z
    //   554: ifeq -> 1004
    //   557: goto -> 860
    //   560: iload #6
    //   562: istore #5
    //   564: aload_0
    //   565: aload_1
    //   566: iload #9
    //   568: iload #7
    //   570: invokespecial E : (Ljava/lang/Object;II)Z
    //   573: ifeq -> 1004
    //   576: iload #6
    //   578: bipush #53
    //   580: imul
    //   581: istore #5
    //   583: aload_1
    //   584: lload #11
    //   586: invokestatic S : (Ljava/lang/Object;J)Z
    //   589: istore #13
    //   591: goto -> 899
    //   594: iload #6
    //   596: istore #5
    //   598: aload_0
    //   599: aload_1
    //   600: iload #9
    //   602: iload #7
    //   604: invokespecial E : (Ljava/lang/Object;II)Z
    //   607: ifeq -> 1004
    //   610: goto -> 648
    //   613: iload #6
    //   615: istore #5
    //   617: aload_0
    //   618: aload_1
    //   619: iload #9
    //   621: iload #7
    //   623: invokespecial E : (Ljava/lang/Object;II)Z
    //   626: ifeq -> 1004
    //   629: goto -> 701
    //   632: iload #6
    //   634: istore #5
    //   636: aload_0
    //   637: aload_1
    //   638: iload #9
    //   640: iload #7
    //   642: invokespecial E : (Ljava/lang/Object;II)Z
    //   645: ifeq -> 1004
    //   648: iload #6
    //   650: bipush #53
    //   652: imul
    //   653: istore #5
    //   655: aload_1
    //   656: lload #11
    //   658: invokestatic V : (Ljava/lang/Object;J)I
    //   661: istore #6
    //   663: goto -> 997
    //   666: iload #6
    //   668: istore #5
    //   670: aload_0
    //   671: aload_1
    //   672: iload #9
    //   674: iload #7
    //   676: invokespecial E : (Ljava/lang/Object;II)Z
    //   679: ifeq -> 1004
    //   682: goto -> 701
    //   685: iload #6
    //   687: istore #5
    //   689: aload_0
    //   690: aload_1
    //   691: iload #9
    //   693: iload #7
    //   695: invokespecial E : (Ljava/lang/Object;II)Z
    //   698: ifeq -> 1004
    //   701: iload #6
    //   703: bipush #53
    //   705: imul
    //   706: istore #5
    //   708: aload_1
    //   709: lload #11
    //   711: invokestatic W : (Ljava/lang/Object;J)J
    //   714: lstore #11
    //   716: goto -> 990
    //   719: iload #6
    //   721: istore #5
    //   723: aload_0
    //   724: aload_1
    //   725: iload #9
    //   727: iload #7
    //   729: invokespecial E : (Ljava/lang/Object;II)Z
    //   732: ifeq -> 1004
    //   735: iload #6
    //   737: bipush #53
    //   739: imul
    //   740: istore #5
    //   742: aload_1
    //   743: lload #11
    //   745: invokestatic U : (Ljava/lang/Object;J)F
    //   748: fstore #4
    //   750: goto -> 960
    //   753: iload #6
    //   755: istore #5
    //   757: aload_0
    //   758: aload_1
    //   759: iload #9
    //   761: iload #7
    //   763: invokespecial E : (Ljava/lang/Object;II)Z
    //   766: ifeq -> 1004
    //   769: iload #6
    //   771: bipush #53
    //   773: imul
    //   774: istore #5
    //   776: aload_1
    //   777: lload #11
    //   779: invokestatic T : (Ljava/lang/Object;J)D
    //   782: dstore_2
    //   783: goto -> 984
    //   786: aload_1
    //   787: lload #11
    //   789: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   792: astore #14
    //   794: aload #14
    //   796: ifnull -> 847
    //   799: goto -> 840
    //   802: iload #6
    //   804: bipush #53
    //   806: imul
    //   807: istore #5
    //   809: aload_1
    //   810: lload #11
    //   812: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   815: astore #14
    //   817: aload #14
    //   819: invokevirtual hashCode : ()I
    //   822: istore #6
    //   824: goto -> 997
    //   827: aload_1
    //   828: lload #11
    //   830: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   833: astore #14
    //   835: aload #14
    //   837: ifnull -> 847
    //   840: aload #14
    //   842: invokevirtual hashCode : ()I
    //   845: istore #5
    //   847: iload #6
    //   849: bipush #53
    //   851: imul
    //   852: iload #5
    //   854: iadd
    //   855: istore #5
    //   857: goto -> 1004
    //   860: iload #6
    //   862: bipush #53
    //   864: imul
    //   865: istore #5
    //   867: aload_1
    //   868: lload #11
    //   870: invokestatic A : (Ljava/lang/Object;J)Ljava/lang/Object;
    //   873: checkcast java/lang/String
    //   876: invokevirtual hashCode : ()I
    //   879: istore #6
    //   881: goto -> 997
    //   884: iload #6
    //   886: bipush #53
    //   888: imul
    //   889: istore #5
    //   891: aload_1
    //   892: lload #11
    //   894: invokestatic p : (Ljava/lang/Object;J)Z
    //   897: istore #13
    //   899: iload #13
    //   901: invokestatic c : (Z)I
    //   904: istore #6
    //   906: goto -> 997
    //   909: iload #6
    //   911: bipush #53
    //   913: imul
    //   914: istore #5
    //   916: aload_1
    //   917: lload #11
    //   919: invokestatic x : (Ljava/lang/Object;J)I
    //   922: istore #6
    //   924: goto -> 997
    //   927: iload #6
    //   929: bipush #53
    //   931: imul
    //   932: istore #5
    //   934: aload_1
    //   935: lload #11
    //   937: invokestatic y : (Ljava/lang/Object;J)J
    //   940: lstore #11
    //   942: goto -> 990
    //   945: iload #6
    //   947: bipush #53
    //   949: imul
    //   950: istore #5
    //   952: aload_1
    //   953: lload #11
    //   955: invokestatic w : (Ljava/lang/Object;J)F
    //   958: fstore #4
    //   960: fload #4
    //   962: invokestatic floatToIntBits : (F)I
    //   965: istore #6
    //   967: goto -> 997
    //   970: iload #6
    //   972: bipush #53
    //   974: imul
    //   975: istore #5
    //   977: aload_1
    //   978: lload #11
    //   980: invokestatic v : (Ljava/lang/Object;J)D
    //   983: dstore_2
    //   984: dload_2
    //   985: invokestatic doubleToLongBits : (D)J
    //   988: lstore #11
    //   990: lload #11
    //   992: invokestatic f : (J)I
    //   995: istore #6
    //   997: iload #5
    //   999: iload #6
    //   1001: iadd
    //   1002: istore #5
    //   1004: iload #7
    //   1006: iconst_3
    //   1007: iadd
    //   1008: istore #7
    //   1010: iload #5
    //   1012: istore #6
    //   1014: goto -> 13
    //   1017: iload #6
    //   1019: bipush #53
    //   1021: imul
    //   1022: aload_0
    //   1023: getfield o : Landroidx/datastore/preferences/protobuf/n1;
    //   1026: aload_1
    //   1027: invokevirtual g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1030: invokevirtual hashCode : ()I
    //   1033: iadd
    //   1034: istore #6
    //   1036: iload #6
    //   1038: istore #5
    //   1040: aload_0
    //   1041: getfield f : Z
    //   1044: ifeq -> 1066
    //   1047: iload #6
    //   1049: bipush #53
    //   1051: imul
    //   1052: aload_0
    //   1053: getfield p : Landroidx/datastore/preferences/protobuf/q;
    //   1056: aload_1
    //   1057: invokevirtual c : (Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/u;
    //   1060: invokevirtual hashCode : ()I
    //   1063: iadd
    //   1064: istore #5
    //   1066: iload #5
    //   1068: ireturn
  }
  
  public void h(T paramT, f1 paramf1, p paramp) {
    Objects.requireNonNull(paramp);
    I(this.o, this.p, paramT, paramf1, paramp);
  }
  
  public void i(T paramT, u1 paramu1) {
    if (paramu1.v() == u1.a.b) {
      l0(paramT, paramu1);
      return;
    } 
    if (this.h) {
      k0(paramT, paramu1);
      return;
    } 
    j0(paramT, paramu1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobu\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */