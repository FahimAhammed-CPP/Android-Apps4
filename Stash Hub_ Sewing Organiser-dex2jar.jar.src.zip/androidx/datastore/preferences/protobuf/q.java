package androidx.datastore.preferences.protobuf;

import java.util.Map;

abstract class q<T extends u.b<T>> {
  abstract int a(Map.Entry<?, ?> paramEntry);
  
  abstract Object b(p paramp, r0 paramr0, int paramInt);
  
  abstract u<T> c(Object paramObject);
  
  abstract u<T> d(Object paramObject);
  
  abstract boolean e(r0 paramr0);
  
  abstract void f(Object paramObject);
  
  abstract <UT, UB> UB g(f1 paramf1, Object paramObject, p paramp, u<T> paramu, UB paramUB, n1<UT, UB> paramn1);
  
  abstract void h(f1 paramf1, Object paramObject, p paramp, u<T> paramu);
  
  abstract void i(h paramh, Object paramObject, p paramp, u<T> paramu);
  
  abstract void j(u1 paramu1, Map.Entry<?, ?> paramEntry);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */