package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class m extends c<Double> implements a0.b, RandomAccess, a1 {
  private static final m d;
  
  private double[] b;
  
  private int c;
  
  static {
    m m1 = new m(new double[0], 0);
    d = m1;
    m1.d();
  }
  
  m() {
    this(new double[10], 0);
  }
  
  private m(double[] paramArrayOfdouble, int paramInt) {
    this.b = paramArrayOfdouble;
    this.c = paramInt;
  }
  
  private void m(int paramInt, double paramDouble) {
    a();
    if (paramInt >= 0) {
      int i = this.c;
      if (paramInt <= i) {
        double[] arrayOfDouble = this.b;
        if (i < arrayOfDouble.length) {
          System.arraycopy(arrayOfDouble, paramInt, arrayOfDouble, paramInt + 1, i - paramInt);
        } else {
          double[] arrayOfDouble1 = new double[i * 3 / 2 + 1];
          System.arraycopy(arrayOfDouble, 0, arrayOfDouble1, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfDouble1, paramInt + 1, this.c - paramInt);
          this.b = arrayOfDouble1;
        } 
        this.b[paramInt] = paramDouble;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private void n(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private String q(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean addAll(Collection<? extends Double> paramCollection) {
    a();
    a0.a(paramCollection);
    if (!(paramCollection instanceof m))
      return super.addAll(paramCollection); 
    paramCollection = paramCollection;
    int i = ((m)paramCollection).c;
    if (i == 0)
      return false; 
    int j = this.c;
    if (Integer.MAX_VALUE - j >= i) {
      i = j + i;
      double[] arrayOfDouble = this.b;
      if (i > arrayOfDouble.length)
        this.b = Arrays.copyOf(arrayOfDouble, i); 
      System.arraycopy(((m)paramCollection).b, 0, this.b, this.c, ((m)paramCollection).c);
      this.c = i;
      this.modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public void c(int paramInt, Double paramDouble) {
    m(paramInt, paramDouble.doubleValue());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof m))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((m)paramObject).c)
      return false; 
    paramObject = ((m)paramObject).b;
    for (int i = 0; i < this.c; i++) {
      if (Double.doubleToLongBits(this.b[i]) != Double.doubleToLongBits(paramObject[i]))
        return false; 
    } 
    return true;
  }
  
  public boolean g(Double paramDouble) {
    k(paramDouble.doubleValue());
    return true;
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.c; i++)
      j = j * 31 + a0.f(Double.doubleToLongBits(this.b[i])); 
    return j;
  }
  
  public void k(double paramDouble) {
    a();
    int i = this.c;
    double[] arrayOfDouble = this.b;
    if (i == arrayOfDouble.length) {
      double[] arrayOfDouble1 = new double[i * 3 / 2 + 1];
      System.arraycopy(arrayOfDouble, 0, arrayOfDouble1, 0, i);
      this.b = arrayOfDouble1;
    } 
    arrayOfDouble = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfDouble[i] = paramDouble;
  }
  
  public Double o(int paramInt) {
    return Double.valueOf(p(paramInt));
  }
  
  public double p(int paramInt) {
    n(paramInt);
    return this.b[paramInt];
  }
  
  public a0.b r(int paramInt) {
    if (paramInt >= this.c)
      return new m(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public boolean remove(Object paramObject) {
    a();
    for (int i = 0; i < this.c; i++) {
      if (paramObject.equals(Double.valueOf(this.b[i]))) {
        paramObject = this.b;
        System.arraycopy(paramObject, i + 1, paramObject, i, this.c - i - 1);
        this.c--;
        this.modCount++;
        return true;
      } 
    } 
    return false;
  }
  
  protected void removeRange(int paramInt1, int paramInt2) {
    a();
    if (paramInt2 >= paramInt1) {
      double[] arrayOfDouble = this.b;
      System.arraycopy(arrayOfDouble, paramInt2, arrayOfDouble, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      this.modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Double s(int paramInt) {
    a();
    n(paramInt);
    double[] arrayOfDouble = this.b;
    double d = arrayOfDouble[paramInt];
    int i = this.c;
    if (paramInt < i - 1)
      System.arraycopy(arrayOfDouble, paramInt + 1, arrayOfDouble, paramInt, i - paramInt - 1); 
    this.c--;
    this.modCount++;
    return Double.valueOf(d);
  }
  
  public int size() {
    return this.c;
  }
  
  public Double t(int paramInt, Double paramDouble) {
    return Double.valueOf(u(paramInt, paramDouble.doubleValue()));
  }
  
  public double u(int paramInt, double paramDouble) {
    a();
    n(paramInt);
    double[] arrayOfDouble = this.b;
    double d = arrayOfDouble[paramInt];
    arrayOfDouble[paramInt] = paramDouble;
    return d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */