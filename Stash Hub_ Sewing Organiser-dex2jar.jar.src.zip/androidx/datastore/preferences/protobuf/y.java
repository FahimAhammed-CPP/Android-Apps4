package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class y<MessageType extends y<MessageType, BuilderType>, BuilderType extends y.a<MessageType, BuilderType>> extends a<MessageType, BuilderType> {
  private static Map<Object, y<?, ?>> defaultInstanceMap = new ConcurrentHashMap<Object, y<?, ?>>();
  
  protected int memoizedSerializedSize = -1;
  
  protected o1 unknownFields = o1.e();
  
  static Object B(Method paramMethod, Object paramObject, Object... paramVarArgs) {
    try {
      return paramMethod.invoke(paramObject, paramVarArgs);
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getCause();
      if (!(throwable instanceof RuntimeException)) {
        if (throwable instanceof Error)
          throw (Error)throwable; 
        throw new RuntimeException("Unexpected exception thrown by generated accessor method.", throwable);
      } 
      throw (RuntimeException)throwable;
    } 
  }
  
  protected static final <T extends y<T, ?>> boolean C(T paramT, boolean paramBoolean) {
    byte b = ((Byte)paramT.v(f.a)).byteValue();
    if (b == 1)
      return true; 
    if (b == 0)
      return false; 
    boolean bool = c1.a().<T>e(paramT).c(paramT);
    if (paramBoolean) {
      Object object;
      f f = f.b;
      if (bool) {
        T t = paramT;
      } else {
        object = null;
      } 
      paramT.w(f, object);
    } 
    return bool;
  }
  
  protected static <E> a0.i<E> E(a0.i<E> parami) {
    int j = parami.size();
    if (j == 0) {
      j = 10;
    } else {
      j *= 2;
    } 
    return parami.e(j);
  }
  
  protected static Object G(r0 paramr0, String paramString, Object[] paramArrayOfObject) {
    return new e1(paramr0, paramString, paramArrayOfObject);
  }
  
  protected static <T extends y<T, ?>> T H(T paramT, InputStream paramInputStream) {
    return t(I(paramT, i.f(paramInputStream), p.b()));
  }
  
  static <T extends y<T, ?>> T I(T paramT, i parami, p paramp) {
    y y1 = (y)paramT.v(f.d);
    try {
      g1<y> g1 = c1.a().e(y1);
      g1.h(y1, j.Q(parami), paramp);
      g1.b(y1);
      return (T)y1;
    } catch (IOException iOException) {
      if (iOException.getCause() instanceof b0)
        throw (b0)iOException.getCause(); 
      throw (new b0(iOException.getMessage())).i(y1);
    } catch (RuntimeException runtimeException) {
      if (runtimeException.getCause() instanceof b0)
        throw (b0)runtimeException.getCause(); 
      throw runtimeException;
    } 
  }
  
  protected static <T extends y<?, ?>> void J(Class<T> paramClass, T paramT) {
    defaultInstanceMap.put(paramClass, (y<?, ?>)paramT);
  }
  
  private static <T extends y<T, ?>> T t(T paramT) {
    if (paramT != null) {
      if (paramT.i())
        return paramT; 
      throw paramT.p().a().i(paramT);
    } 
    return paramT;
  }
  
  protected static <E> a0.i<E> y() {
    return d1.g();
  }
  
  static <T extends y<?, ?>> T z(Class<T> paramClass) {
    y<?, ?> y2 = defaultInstanceMap.get(paramClass);
    y<?, ?> y1 = y2;
    if (y2 == null)
      try {
        Class.forName(paramClass.getName(), true, paramClass.getClassLoader());
        y1 = defaultInstanceMap.get(paramClass);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new IllegalStateException("Class initialization cannot fail.", classNotFoundException);
      }  
    if (y1 == null) {
      y1 = (y<?, ?>)((y)r1.<y>i((Class<y>)classNotFoundException)).A();
      if (y1 != null) {
        defaultInstanceMap.put(classNotFoundException, y1);
        return (T)y1;
      } 
      throw new IllegalStateException();
    } 
    return (T)y1;
  }
  
  public final MessageType A() {
    return (MessageType)v(f.f);
  }
  
  protected void D() {
    c1.a().<y>e(this).b(this);
  }
  
  public final BuilderType F() {
    return (BuilderType)v(f.e);
  }
  
  public final BuilderType K() {
    a a1 = (a)v(f.e);
    a1.z(this);
    return (BuilderType)a1;
  }
  
  public int b() {
    if (this.memoizedSerializedSize == -1)
      this.memoizedSerializedSize = c1.a().<y>e(this).e(this); 
    return this.memoizedSerializedSize;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!A().getClass().isInstance(paramObject) ? false : c1.a().<y>e(this).d(this, (y)paramObject));
  }
  
  public final z0<MessageType> h() {
    return (z0<MessageType>)v(f.g);
  }
  
  public int hashCode() {
    int i = this.memoizedHashCode;
    if (i != 0)
      return i; 
    i = c1.a().<y>e(this).g(this);
    this.memoizedHashCode = i;
    return i;
  }
  
  public final boolean i() {
    return C(this, true);
  }
  
  public void j(k paramk) {
    c1.a().<y>e(this).i(this, l.P(paramk));
  }
  
  int m() {
    return this.memoizedSerializedSize;
  }
  
  void q(int paramInt) {
    this.memoizedSerializedSize = paramInt;
  }
  
  Object s() {
    return v(f.c);
  }
  
  public String toString() {
    return t0.e(this, super.toString());
  }
  
  protected final <MessageType extends y<MessageType, BuilderType>, BuilderType extends a<MessageType, BuilderType>> BuilderType u() {
    return (BuilderType)v(f.e);
  }
  
  protected Object v(f paramf) {
    return x(paramf, null, null);
  }
  
  protected Object w(f paramf, Object paramObject) {
    return x(paramf, paramObject, null);
  }
  
  protected abstract Object x(f paramf, Object paramObject1, Object paramObject2);
  
  public static abstract class a<MessageType extends y<MessageType, BuilderType>, BuilderType extends a<MessageType, BuilderType>> extends a.a<MessageType, BuilderType> {
    private final MessageType a;
    
    protected MessageType b;
    
    protected boolean c;
    
    protected a(MessageType param1MessageType) {
      this.a = param1MessageType;
      this.b = (MessageType)param1MessageType.v(y.f.d);
      this.c = false;
    }
    
    private void A(MessageType param1MessageType1, MessageType param1MessageType2) {
      c1.a().<MessageType>e(param1MessageType1).a(param1MessageType1, param1MessageType2);
    }
    
    public final MessageType t() {
      MessageType messageType = u();
      if (messageType.i())
        return messageType; 
      throw a.a.q(messageType);
    }
    
    public MessageType u() {
      if (this.c)
        return this.b; 
      this.b.D();
      this.c = true;
      return this.b;
    }
    
    public BuilderType v() {
      Object object = x().F();
      object.z(u());
      return (BuilderType)object;
    }
    
    protected void w() {
      if (this.c) {
        y y1 = (y)this.b.v(y.f.d);
        A((MessageType)y1, this.b);
        this.b = (MessageType)y1;
        this.c = false;
      } 
    }
    
    public MessageType x() {
      return this.a;
    }
    
    protected BuilderType y(MessageType param1MessageType) {
      return z(param1MessageType);
    }
    
    public BuilderType z(MessageType param1MessageType) {
      w();
      A(this.b, param1MessageType);
      return (BuilderType)this;
    }
  }
  
  protected static class b<T extends y<T, ?>> extends b<T> {
    private final T b;
    
    public b(T param1T) {
      this.b = param1T;
    }
    
    public T g(i param1i, p param1p) {
      return y.I(this.b, param1i, param1p);
    }
  }
  
  public static abstract class c<MessageType extends c<MessageType, BuilderType>, BuilderType> extends y<MessageType, BuilderType> implements s0 {
    protected u<y.d> extensions = u.h();
    
    u<y.d> L() {
      if (this.extensions.o())
        this.extensions = this.extensions.b(); 
      return this.extensions;
    }
  }
  
  static final class d implements u.b<d> {
    final a0.d<?> a;
    
    final int b;
    
    final t1.b c;
    
    final boolean d;
    
    final boolean e;
    
    public int a(d param1d) {
      return this.b - param1d.b;
    }
    
    public int b() {
      return this.b;
    }
    
    public boolean c() {
      return this.d;
    }
    
    public t1.b d() {
      return this.c;
    }
    
    public t1.c e() {
      return this.c.a();
    }
    
    public boolean f() {
      return this.e;
    }
    
    public a0.d<?> g() {
      return this.a;
    }
    
    public r0.a m(r0.a param1a, r0 param1r0) {
      return ((y.a<y, r0.a>)param1a).z((y)param1r0);
    }
  }
  
  public static class e<ContainingType extends r0, Type> extends n<ContainingType, Type> {
    final r0 a;
    
    final y.d b;
    
    public t1.b a() {
      return this.b.d();
    }
    
    public r0 b() {
      return this.a;
    }
    
    public int c() {
      return this.b.b();
    }
    
    public boolean d() {
      return this.b.d;
    }
  }
  
  public enum f {
    a, b, c, d, e, f, g;
    
    static {
      f f1 = new f("GET_MEMOIZED_IS_INITIALIZED", 0);
      a = f1;
      f f2 = new f("SET_MEMOIZED_IS_INITIALIZED", 1);
      b = f2;
      f f3 = new f("BUILD_MESSAGE_INFO", 2);
      c = f3;
      f f4 = new f("NEW_MUTABLE_INSTANCE", 3);
      d = f4;
      f f5 = new f("NEW_BUILDER", 4);
      e = f5;
      f f6 = new f("GET_DEFAULT_INSTANCE", 5);
      f = f6;
      f f7 = new f("GET_PARSER", 6);
      g = f7;
      l = new f[] { f1, f2, f3, f4, f5, f6, f7 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */