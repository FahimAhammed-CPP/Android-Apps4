package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

public class d0 extends e0 {
  private final r0 f;
  
  public boolean equals(Object paramObject) {
    return f().equals(paramObject);
  }
  
  public r0 f() {
    return c(this.f);
  }
  
  public int hashCode() {
    return f().hashCode();
  }
  
  public String toString() {
    return f().toString();
  }
  
  static class b<K> implements Map.Entry<K, Object> {
    private Map.Entry<K, d0> a;
    
    private b(Map.Entry<K, d0> param1Entry) {
      this.a = param1Entry;
    }
    
    public d0 a() {
      return this.a.getValue();
    }
    
    public K getKey() {
      return this.a.getKey();
    }
    
    public Object getValue() {
      d0 d0 = this.a.getValue();
      return (d0 == null) ? null : d0.f();
    }
    
    public Object setValue(Object param1Object) {
      if (param1Object instanceof r0)
        return ((d0)this.a.getValue()).d((r0)param1Object); 
      throw new IllegalArgumentException("LazyField now only used for MessageSet, and the value of MessageSet must be an instance of MessageLite");
    }
  }
  
  static class c<K> implements Iterator<Map.Entry<K, Object>> {
    private Iterator<Map.Entry<K, Object>> a;
    
    public c(Iterator<Map.Entry<K, Object>> param1Iterator) {
      this.a = param1Iterator;
    }
    
    public Map.Entry<K, Object> b() {
      Map.Entry<K, Object> entry = this.a.next();
      return (entry.getValue() instanceof d0) ? new d0.b<K>(entry, null) : entry;
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public void remove() {
      this.a.remove();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */