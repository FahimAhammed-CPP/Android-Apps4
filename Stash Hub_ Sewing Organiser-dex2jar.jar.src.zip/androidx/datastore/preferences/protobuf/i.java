package androidx.datastore.preferences.protobuf;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public abstract class i {
  int a;
  
  int b = 100;
  
  int c = Integer.MAX_VALUE;
  
  j d;
  
  private boolean e = false;
  
  private i() {}
  
  public static int b(int paramInt) {
    return -(paramInt & 0x1) ^ paramInt >>> 1;
  }
  
  public static long c(long paramLong) {
    return -(paramLong & 0x1L) ^ paramLong >>> 1L;
  }
  
  public static i f(InputStream paramInputStream) {
    return g(paramInputStream, 4096);
  }
  
  public static i g(InputStream paramInputStream, int paramInt) {
    if (paramInt > 0)
      return (paramInputStream == null) ? h(a0.c) : new c(paramInputStream, paramInt, null); 
    throw new IllegalArgumentException("bufferSize must be > 0");
  }
  
  public static i h(byte[] paramArrayOfbyte) {
    return i(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static i i(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return j(paramArrayOfbyte, paramInt1, paramInt2, false);
  }
  
  static i j(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) {
    b b = new b(paramArrayOfbyte, paramInt1, paramInt2, paramBoolean, null);
    try {
      b.l(paramInt2);
      return b;
    } catch (b0 b0) {
      throw new IllegalArgumentException(b0);
    } 
  }
  
  public abstract String A();
  
  public abstract int B();
  
  public abstract int C();
  
  public abstract long D();
  
  public abstract boolean E(int paramInt);
  
  public abstract void a(int paramInt);
  
  public abstract int d();
  
  public abstract boolean e();
  
  public abstract void k(int paramInt);
  
  public abstract int l(int paramInt);
  
  public abstract boolean m();
  
  public abstract h n();
  
  public abstract double o();
  
  public abstract int p();
  
  public abstract int q();
  
  public abstract long r();
  
  public abstract float s();
  
  public abstract int t();
  
  public abstract long u();
  
  public abstract int v();
  
  public abstract long w();
  
  public abstract int x();
  
  public abstract long y();
  
  public abstract String z();
  
  private static final class b extends i {
    private final byte[] f;
    
    private final boolean g;
    
    private int h;
    
    private int i;
    
    private int j;
    
    private int k;
    
    private int l;
    
    private boolean m;
    
    private int n = Integer.MAX_VALUE;
    
    private b(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, boolean param1Boolean) {
      super(null);
      this.f = param1ArrayOfbyte;
      this.h = param1Int2 + param1Int1;
      this.j = param1Int1;
      this.k = param1Int1;
      this.g = param1Boolean;
    }
    
    private void M() {
      int j = this.h + this.i;
      this.h = j;
      int k = j - this.k;
      int m = this.n;
      if (k > m) {
        k -= m;
        this.i = k;
        this.h = j - k;
        return;
      } 
      this.i = 0;
    }
    
    private void P() {
      if (this.h - this.j >= 10) {
        Q();
        return;
      } 
      R();
    }
    
    private void Q() {
      for (int j = 0; j < 10; j++) {
        byte[] arrayOfByte = this.f;
        int k = this.j;
        this.j = k + 1;
        if (arrayOfByte[k] >= 0)
          return; 
      } 
      throw b0.e();
    }
    
    private void R() {
      for (int j = 0; j < 10; j++) {
        if (F() >= 0)
          return; 
      } 
      throw b0.e();
    }
    
    public String A() {
      int j = J();
      if (j > 0) {
        int k = this.h;
        int m = this.j;
        if (j <= k - m) {
          String str = s1.e(this.f, m, j);
          this.j += j;
          return str;
        } 
      } 
      if (j == 0)
        return ""; 
      if (j <= 0)
        throw b0.f(); 
      throw b0.k();
    }
    
    public int B() {
      if (e()) {
        this.l = 0;
        return 0;
      } 
      int j = J();
      this.l = j;
      if (t1.a(j) != 0)
        return this.l; 
      throw b0.b();
    }
    
    public int C() {
      return J();
    }
    
    public long D() {
      return K();
    }
    
    public boolean E(int param1Int) {
      int j = t1.b(param1Int);
      if (j != 0) {
        if (j != 1) {
          if (j != 2) {
            if (j != 3) {
              if (j != 4) {
                if (j == 5) {
                  O(4);
                  return true;
                } 
                throw b0.d();
              } 
              return false;
            } 
            N();
            a(t1.c(t1.a(param1Int), 4));
            return true;
          } 
          O(J());
          return true;
        } 
        O(8);
        return true;
      } 
      P();
      return true;
    }
    
    public byte F() {
      int j = this.j;
      if (j != this.h) {
        byte[] arrayOfByte = this.f;
        this.j = j + 1;
        return arrayOfByte[j];
      } 
      throw b0.k();
    }
    
    public byte[] G(int param1Int) {
      if (param1Int > 0) {
        int k = this.h;
        int j = this.j;
        if (param1Int <= k - j) {
          param1Int += j;
          this.j = param1Int;
          return Arrays.copyOfRange(this.f, j, param1Int);
        } 
      } 
      if (param1Int <= 0) {
        if (param1Int == 0)
          return a0.c; 
        throw b0.f();
      } 
      throw b0.k();
    }
    
    public int H() {
      int j = this.j;
      if (this.h - j >= 4) {
        byte[] arrayOfByte = this.f;
        this.j = j + 4;
        byte b1 = arrayOfByte[j];
        byte b2 = arrayOfByte[j + 1];
        byte b3 = arrayOfByte[j + 2];
        return (arrayOfByte[j + 3] & 0xFF) << 24 | b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
      } 
      throw b0.k();
    }
    
    public long I() {
      int j = this.j;
      if (this.h - j >= 8) {
        byte[] arrayOfByte = this.f;
        this.j = j + 8;
        long l1 = arrayOfByte[j];
        long l2 = arrayOfByte[j + 1];
        long l3 = arrayOfByte[j + 2];
        long l4 = arrayOfByte[j + 3];
        long l5 = arrayOfByte[j + 4];
        long l6 = arrayOfByte[j + 5];
        long l7 = arrayOfByte[j + 6];
        return (arrayOfByte[j + 7] & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
      } 
      throw b0.k();
    }
    
    public int J() {
      int k = this.j;
      int j = this.h;
      if (j != k) {
        byte[] arrayOfByte = this.f;
        int m = k + 1;
        k = arrayOfByte[k];
        if (k >= 0) {
          this.j = m;
          return k;
        } 
        if (j - m >= 9) {
          j = m + 1;
          k ^= arrayOfByte[m] << 7;
          if (k < 0) {
            m = k ^ 0xFFFFFF80;
          } else {
            m = j + 1;
            k ^= arrayOfByte[j] << 14;
            if (k >= 0) {
              k ^= 0x3F80;
              j = m;
              m = k;
            } else {
              j = m + 1;
              m = k ^ arrayOfByte[m] << 21;
              if (m < 0) {
                m ^= 0xFFE03F80;
              } else {
                int n = j + 1;
                byte b1 = arrayOfByte[j];
                k = m ^ b1 << 28 ^ 0xFE03F80;
                m = k;
                j = n;
                if (b1 < 0) {
                  int i1 = n + 1;
                  m = k;
                  j = i1;
                  if (arrayOfByte[n] < 0) {
                    n = i1 + 1;
                    m = k;
                    j = n;
                    if (arrayOfByte[i1] < 0) {
                      i1 = n + 1;
                      m = k;
                      j = i1;
                      if (arrayOfByte[n] < 0) {
                        n = i1 + 1;
                        m = k;
                        j = n;
                        if (arrayOfByte[i1] < 0) {
                          j = n + 1;
                          m = k;
                          if (arrayOfByte[n] < 0)
                            return (int)L(); 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          this.j = j;
          return m;
        } 
      } 
      return (int)L();
    }
    
    public long K() {
      int m = this.j;
      int j = this.h;
      if (j == m)
        return L(); 
      byte[] arrayOfByte = this.f;
      int k = m + 1;
      m = arrayOfByte[m];
      if (m >= 0) {
        this.j = k;
        return m;
      } 
      if (j - k < 9)
        return L(); 
      j = k + 1;
      m ^= arrayOfByte[k] << 7;
      if (m < 0) {
        k = m ^ 0xFFFFFF80;
      } else {
        long l1;
        k = j + 1;
        m ^= arrayOfByte[j] << 14;
        if (m >= 0) {
          l1 = (m ^ 0x3F80);
          j = k;
        } else {
          j = k + 1;
          k = m ^ arrayOfByte[k] << 21;
          if (k < 0) {
            k ^= 0xFFE03F80;
          } else {
            long l2 = k;
            k = j + 1;
            long l3 = l2 ^ arrayOfByte[j] << 28L;
            if (l3 >= 0L) {
              l2 = 266354560L;
              j = k;
            } else {
              j = k + 1;
              l2 = l3 ^ arrayOfByte[k] << 35L;
              if (l2 < 0L) {
                l3 = -34093383808L;
              } else {
                k = j + 1;
                l3 = l2 ^ arrayOfByte[j] << 42L;
                if (l3 >= 0L) {
                  l2 = 4363953127296L;
                  j = k;
                } else {
                  j = k + 1;
                  l2 = l3 ^ arrayOfByte[k] << 49L;
                  if (l2 < 0L) {
                    l3 = -558586000294016L;
                  } else {
                    k = j + 1;
                    l2 = l2 ^ arrayOfByte[j] << 56L ^ 0xFE03F80FE03F80L;
                    if (l2 < 0L) {
                      j = k + 1;
                      if (arrayOfByte[k] < 0L)
                        return L(); 
                    } else {
                      j = k;
                    } 
                    this.j = j;
                    return l2;
                  } 
                  l2 ^= l3;
                } 
                l2 = l3 ^ l2;
              } 
              l2 ^= l3;
            } 
            l2 = l3 ^ l2;
          } 
          l1 = k;
        } 
        this.j = j;
        return l1;
      } 
      long l = k;
    }
    
    long L() {
      long l = 0L;
      for (int j = 0; j < 64; j += 7) {
        byte b1 = F();
        l |= (b1 & Byte.MAX_VALUE) << j;
        if ((b1 & 0x80) == 0)
          return l; 
      } 
      throw b0.e();
    }
    
    public void N() {
      int j;
      do {
        j = B();
      } while (j != 0 && E(j));
    }
    
    public void O(int param1Int) {
      if (param1Int >= 0) {
        int j = this.h;
        int k = this.j;
        if (param1Int <= j - k) {
          this.j = k + param1Int;
          return;
        } 
      } 
      if (param1Int < 0)
        throw b0.f(); 
      throw b0.k();
    }
    
    public void a(int param1Int) {
      if (this.l == param1Int)
        return; 
      throw b0.a();
    }
    
    public int d() {
      return this.j - this.k;
    }
    
    public boolean e() {
      return (this.j == this.h);
    }
    
    public void k(int param1Int) {
      this.n = param1Int;
      M();
    }
    
    public int l(int param1Int) {
      if (param1Int >= 0) {
        param1Int += d();
        int j = this.n;
        if (param1Int <= j) {
          this.n = param1Int;
          M();
          return j;
        } 
        throw b0.k();
      } 
      throw b0.f();
    }
    
    public boolean m() {
      return (K() != 0L);
    }
    
    public h n() {
      int j = J();
      if (j > 0) {
        int k = this.h;
        int m = this.j;
        if (j <= k - m) {
          h h;
          if (this.g && this.m) {
            h = h.E(this.f, m, j);
          } else {
            h = h.n(this.f, m, j);
          } 
          this.j += j;
          return h;
        } 
      } 
      return (j == 0) ? h.b : h.D(G(j));
    }
    
    public double o() {
      return Double.longBitsToDouble(I());
    }
    
    public int p() {
      return J();
    }
    
    public int q() {
      return H();
    }
    
    public long r() {
      return I();
    }
    
    public float s() {
      return Float.intBitsToFloat(H());
    }
    
    public int t() {
      return J();
    }
    
    public long u() {
      return K();
    }
    
    public int v() {
      return H();
    }
    
    public long w() {
      return I();
    }
    
    public int x() {
      return i.b(J());
    }
    
    public long y() {
      return i.c(K());
    }
    
    public String z() {
      int j = J();
      if (j > 0) {
        int k = this.h;
        int m = this.j;
        if (j <= k - m) {
          String str = new String(this.f, m, j, a0.a);
          this.j += j;
          return str;
        } 
      } 
      if (j == 0)
        return ""; 
      if (j < 0)
        throw b0.f(); 
      throw b0.k();
    }
  }
  
  private static final class c extends i {
    private final InputStream f;
    
    private final byte[] g;
    
    private int h;
    
    private int i;
    
    private int j;
    
    private int k;
    
    private int l;
    
    private int m = Integer.MAX_VALUE;
    
    private a n = null;
    
    private c(InputStream param1InputStream, int param1Int) {
      super(null);
      a0.b(param1InputStream, "input");
      this.f = param1InputStream;
      this.g = new byte[param1Int];
      this.h = 0;
      this.j = 0;
      this.l = 0;
    }
    
    private h F(int param1Int) {
      byte[] arrayOfByte = I(param1Int);
      if (arrayOfByte != null)
        return h.m(arrayOfByte); 
      int k = this.j;
      int m = this.h;
      int j = m - k;
      this.l += m;
      this.j = 0;
      this.h = 0;
      List<byte[]> list = J(param1Int - j);
      arrayOfByte = new byte[param1Int];
      System.arraycopy(this.g, k, arrayOfByte, 0, j);
      Iterator<byte> iterator = list.iterator();
      for (param1Int = j; iterator.hasNext(); param1Int += arrayOfByte1.length) {
        byte[] arrayOfByte1 = (byte[])iterator.next();
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, param1Int, arrayOfByte1.length);
      } 
      return h.D(arrayOfByte);
    }
    
    private byte[] H(int param1Int, boolean param1Boolean) {
      byte[] arrayOfByte2 = I(param1Int);
      if (arrayOfByte2 != null) {
        byte[] arrayOfByte = arrayOfByte2;
        if (param1Boolean)
          arrayOfByte = (byte[])arrayOfByte2.clone(); 
        return arrayOfByte;
      } 
      int k = this.j;
      int m = this.h;
      int j = m - k;
      this.l += m;
      this.j = 0;
      this.h = 0;
      List<byte[]> list = J(param1Int - j);
      byte[] arrayOfByte1 = new byte[param1Int];
      System.arraycopy(this.g, k, arrayOfByte1, 0, j);
      Iterator<byte> iterator = list.iterator();
      for (param1Int = j; iterator.hasNext(); param1Int += arrayOfByte.length) {
        byte[] arrayOfByte = (byte[])iterator.next();
        System.arraycopy(arrayOfByte, 0, arrayOfByte1, param1Int, arrayOfByte.length);
      } 
      return arrayOfByte1;
    }
    
    private byte[] I(int param1Int) {
      if (param1Int == 0)
        return a0.c; 
      if (param1Int >= 0) {
        int j = this.l;
        int k = this.j;
        int m = j + k + param1Int;
        if (m - this.c <= 0) {
          int n = this.m;
          if (m <= n) {
            j = this.h - k;
            k = param1Int - j;
            if (k < 4096 || k <= this.f.available()) {
              byte[] arrayOfByte = new byte[param1Int];
              System.arraycopy(this.g, this.j, arrayOfByte, 0, j);
              this.l += this.h;
              this.j = 0;
              this.h = 0;
              while (j < param1Int) {
                k = this.f.read(arrayOfByte, j, param1Int - j);
                if (k != -1) {
                  this.l += k;
                  j += k;
                  continue;
                } 
                throw b0.k();
              } 
              return arrayOfByte;
            } 
            return null;
          } 
          S(n - j - k);
          throw b0.k();
        } 
        throw b0.j();
      } 
      throw b0.f();
    }
    
    private List<byte[]> J(int param1Int) {
      ArrayList<byte[]> arrayList = new ArrayList();
      while (param1Int > 0) {
        int k = Math.min(param1Int, 4096);
        byte[] arrayOfByte = new byte[k];
        int j = 0;
        while (j < k) {
          int m = this.f.read(arrayOfByte, j, k - j);
          if (m != -1) {
            this.l += m;
            j += m;
            continue;
          } 
          throw b0.k();
        } 
        param1Int -= k;
        arrayList.add(arrayOfByte);
      } 
      return (List<byte[]>)arrayList;
    }
    
    private void P() {
      int j = this.h + this.i;
      this.h = j;
      int k = this.l + j;
      int m = this.m;
      if (k > m) {
        k -= m;
        this.i = k;
        this.h = j - k;
        return;
      } 
      this.i = 0;
    }
    
    private void Q(int param1Int) {
      if (!X(param1Int)) {
        if (param1Int > this.c - this.l - this.j)
          throw b0.j(); 
        throw b0.k();
      } 
    }
    
    private void T(int param1Int) {
      // Byte code:
      //   0: iload_1
      //   1: iflt -> 288
      //   4: aload_0
      //   5: getfield l : I
      //   8: istore #4
      //   10: aload_0
      //   11: getfield j : I
      //   14: istore_3
      //   15: aload_0
      //   16: getfield m : I
      //   19: istore_2
      //   20: iload #4
      //   22: iload_3
      //   23: iadd
      //   24: iload_1
      //   25: iadd
      //   26: iload_2
      //   27: if_icmpgt -> 274
      //   30: aload_0
      //   31: getfield n : Landroidx/datastore/preferences/protobuf/i$c$a;
      //   34: astore #9
      //   36: iconst_0
      //   37: istore_2
      //   38: aload #9
      //   40: ifnonnull -> 212
      //   43: aload_0
      //   44: iload #4
      //   46: iload_3
      //   47: iadd
      //   48: putfield l : I
      //   51: aload_0
      //   52: getfield h : I
      //   55: istore_2
      //   56: aload_0
      //   57: iconst_0
      //   58: putfield h : I
      //   61: aload_0
      //   62: iconst_0
      //   63: putfield j : I
      //   66: iload_2
      //   67: iload_3
      //   68: isub
      //   69: istore_2
      //   70: iload_2
      //   71: iload_1
      //   72: if_icmpge -> 198
      //   75: aload_0
      //   76: getfield f : Ljava/io/InputStream;
      //   79: astore #9
      //   81: iload_1
      //   82: iload_2
      //   83: isub
      //   84: i2l
      //   85: lstore #5
      //   87: aload #9
      //   89: lload #5
      //   91: invokevirtual skip : (J)J
      //   94: lstore #7
      //   96: lload #7
      //   98: lconst_0
      //   99: lcmp
      //   100: istore_3
      //   101: iload_3
      //   102: iflt -> 120
      //   105: lload #7
      //   107: lload #5
      //   109: lcmp
      //   110: ifgt -> 120
      //   113: iload_3
      //   114: ifne -> 292
      //   117: goto -> 198
      //   120: new java/lang/StringBuilder
      //   123: dup
      //   124: invokespecial <init> : ()V
      //   127: astore #9
      //   129: aload #9
      //   131: aload_0
      //   132: getfield f : Ljava/io/InputStream;
      //   135: invokevirtual getClass : ()Ljava/lang/Class;
      //   138: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   141: pop
      //   142: aload #9
      //   144: ldc '#skip returned invalid result: '
      //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   149: pop
      //   150: aload #9
      //   152: lload #7
      //   154: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   157: pop
      //   158: aload #9
      //   160: ldc '\\nThe InputStream implementation is buggy.'
      //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   165: pop
      //   166: new java/lang/IllegalStateException
      //   169: dup
      //   170: aload #9
      //   172: invokevirtual toString : ()Ljava/lang/String;
      //   175: invokespecial <init> : (Ljava/lang/String;)V
      //   178: athrow
      //   179: astore #9
      //   181: aload_0
      //   182: aload_0
      //   183: getfield l : I
      //   186: iload_2
      //   187: iadd
      //   188: putfield l : I
      //   191: aload_0
      //   192: invokespecial P : ()V
      //   195: aload #9
      //   197: athrow
      //   198: aload_0
      //   199: aload_0
      //   200: getfield l : I
      //   203: iload_2
      //   204: iadd
      //   205: putfield l : I
      //   208: aload_0
      //   209: invokespecial P : ()V
      //   212: iload_2
      //   213: iload_1
      //   214: if_icmpge -> 273
      //   217: aload_0
      //   218: getfield h : I
      //   221: istore_3
      //   222: iload_3
      //   223: aload_0
      //   224: getfield j : I
      //   227: isub
      //   228: istore_2
      //   229: aload_0
      //   230: iload_3
      //   231: putfield j : I
      //   234: aload_0
      //   235: iconst_1
      //   236: invokespecial Q : (I)V
      //   239: iload_1
      //   240: iload_2
      //   241: isub
      //   242: istore #4
      //   244: aload_0
      //   245: getfield h : I
      //   248: istore_3
      //   249: iload #4
      //   251: iload_3
      //   252: if_icmple -> 267
      //   255: iload_2
      //   256: iload_3
      //   257: iadd
      //   258: istore_2
      //   259: aload_0
      //   260: iload_3
      //   261: putfield j : I
      //   264: goto -> 234
      //   267: aload_0
      //   268: iload #4
      //   270: putfield j : I
      //   273: return
      //   274: aload_0
      //   275: iload_2
      //   276: iload #4
      //   278: isub
      //   279: iload_3
      //   280: isub
      //   281: invokevirtual S : (I)V
      //   284: invokestatic k : ()Landroidx/datastore/preferences/protobuf/b0;
      //   287: athrow
      //   288: invokestatic f : ()Landroidx/datastore/preferences/protobuf/b0;
      //   291: athrow
      //   292: iload_2
      //   293: lload #7
      //   295: l2i
      //   296: iadd
      //   297: istore_2
      //   298: goto -> 70
      // Exception table:
      //   from	to	target	type
      //   75	81	179	finally
      //   87	96	179	finally
      //   120	179	179	finally
    }
    
    private void U() {
      if (this.h - this.j >= 10) {
        V();
        return;
      } 
      W();
    }
    
    private void V() {
      for (int j = 0; j < 10; j++) {
        byte[] arrayOfByte = this.g;
        int k = this.j;
        this.j = k + 1;
        if (arrayOfByte[k] >= 0)
          return; 
      } 
      throw b0.e();
    }
    
    private void W() {
      for (int j = 0; j < 10; j++) {
        if (G() >= 0)
          return; 
      } 
      throw b0.e();
    }
    
    private boolean X(int param1Int) {
      int j = this.j;
      if (j + param1Int > this.h) {
        int k = this.c;
        int m = this.l;
        if (param1Int > k - m - j)
          return false; 
        if (m + j + param1Int > this.m)
          return false; 
        a a1 = this.n;
        if (a1 != null)
          a1.a(); 
        j = this.j;
        if (j > 0) {
          k = this.h;
          if (k > j) {
            byte[] arrayOfByte1 = this.g;
            System.arraycopy(arrayOfByte1, j, arrayOfByte1, 0, k - j);
          } 
          this.l += j;
          this.h -= j;
          this.j = 0;
        } 
        InputStream inputStream = this.f;
        byte[] arrayOfByte = this.g;
        j = this.h;
        j = inputStream.read(arrayOfByte, j, Math.min(arrayOfByte.length - j, this.c - this.l - j));
        if (j != 0 && j >= -1 && j <= this.g.length) {
          if (j > 0) {
            this.h += j;
            P();
            return (this.h >= param1Int) ? true : X(param1Int);
          } 
          return false;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(this.f.getClass());
        stringBuilder1.append("#read(byte[]) returned invalid result: ");
        stringBuilder1.append(j);
        stringBuilder1.append("\nThe InputStream implementation is buggy.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("refillBuffer() called when ");
      stringBuilder.append(param1Int);
      stringBuilder.append(" bytes were already available in buffer");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public String A() {
      byte[] arrayOfByte;
      int k = M();
      int j = this.j;
      int m = this.h;
      if (k <= m - j && k > 0) {
        arrayOfByte = this.g;
        this.j = j + k;
      } else {
        if (k == 0)
          return ""; 
        if (k <= m) {
          Q(k);
          arrayOfByte = this.g;
          this.j = k + 0;
        } else {
          arrayOfByte = H(k, false);
        } 
        j = 0;
      } 
      return s1.e(arrayOfByte, j, k);
    }
    
    public int B() {
      if (e()) {
        this.k = 0;
        return 0;
      } 
      int j = M();
      this.k = j;
      if (t1.a(j) != 0)
        return this.k; 
      throw b0.b();
    }
    
    public int C() {
      return M();
    }
    
    public long D() {
      return N();
    }
    
    public boolean E(int param1Int) {
      int j = t1.b(param1Int);
      if (j != 0) {
        if (j != 1) {
          if (j != 2) {
            if (j != 3) {
              if (j != 4) {
                if (j == 5) {
                  S(4);
                  return true;
                } 
                throw b0.d();
              } 
              return false;
            } 
            R();
            a(t1.c(t1.a(param1Int), 4));
            return true;
          } 
          S(M());
          return true;
        } 
        S(8);
        return true;
      } 
      U();
      return true;
    }
    
    public byte G() {
      if (this.j == this.h)
        Q(1); 
      byte[] arrayOfByte = this.g;
      int j = this.j;
      this.j = j + 1;
      return arrayOfByte[j];
    }
    
    public int K() {
      int k = this.j;
      int j = k;
      if (this.h - k < 4) {
        Q(4);
        j = this.j;
      } 
      byte[] arrayOfByte = this.g;
      this.j = j + 4;
      k = arrayOfByte[j];
      byte b1 = arrayOfByte[j + 1];
      byte b2 = arrayOfByte[j + 2];
      return (arrayOfByte[j + 3] & 0xFF) << 24 | k & 0xFF | (b1 & 0xFF) << 8 | (b2 & 0xFF) << 16;
    }
    
    public long L() {
      int k = this.j;
      int j = k;
      if (this.h - k < 8) {
        Q(8);
        j = this.j;
      } 
      byte[] arrayOfByte = this.g;
      this.j = j + 8;
      long l1 = arrayOfByte[j];
      long l2 = arrayOfByte[j + 1];
      long l3 = arrayOfByte[j + 2];
      long l4 = arrayOfByte[j + 3];
      long l5 = arrayOfByte[j + 4];
      long l6 = arrayOfByte[j + 5];
      long l7 = arrayOfByte[j + 6];
      return (arrayOfByte[j + 7] & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
    }
    
    public int M() {
      int k = this.j;
      int j = this.h;
      if (j != k) {
        byte[] arrayOfByte = this.g;
        int m = k + 1;
        k = arrayOfByte[k];
        if (k >= 0) {
          this.j = m;
          return k;
        } 
        if (j - m >= 9) {
          j = m + 1;
          k ^= arrayOfByte[m] << 7;
          if (k < 0) {
            m = k ^ 0xFFFFFF80;
          } else {
            m = j + 1;
            k ^= arrayOfByte[j] << 14;
            if (k >= 0) {
              k ^= 0x3F80;
              j = m;
              m = k;
            } else {
              j = m + 1;
              m = k ^ arrayOfByte[m] << 21;
              if (m < 0) {
                m ^= 0xFFE03F80;
              } else {
                int n = j + 1;
                byte b = arrayOfByte[j];
                k = m ^ b << 28 ^ 0xFE03F80;
                m = k;
                j = n;
                if (b < 0) {
                  int i1 = n + 1;
                  m = k;
                  j = i1;
                  if (arrayOfByte[n] < 0) {
                    n = i1 + 1;
                    m = k;
                    j = n;
                    if (arrayOfByte[i1] < 0) {
                      i1 = n + 1;
                      m = k;
                      j = i1;
                      if (arrayOfByte[n] < 0) {
                        n = i1 + 1;
                        m = k;
                        j = n;
                        if (arrayOfByte[i1] < 0) {
                          j = n + 1;
                          m = k;
                          if (arrayOfByte[n] < 0)
                            return (int)O(); 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          this.j = j;
          return m;
        } 
      } 
      return (int)O();
    }
    
    public long N() {
      int m = this.j;
      int j = this.h;
      if (j == m)
        return O(); 
      byte[] arrayOfByte = this.g;
      int k = m + 1;
      m = arrayOfByte[m];
      if (m >= 0) {
        this.j = k;
        return m;
      } 
      if (j - k < 9)
        return O(); 
      j = k + 1;
      m ^= arrayOfByte[k] << 7;
      if (m < 0) {
        k = m ^ 0xFFFFFF80;
      } else {
        long l1;
        k = j + 1;
        m ^= arrayOfByte[j] << 14;
        if (m >= 0) {
          l1 = (m ^ 0x3F80);
          j = k;
        } else {
          j = k + 1;
          k = m ^ arrayOfByte[k] << 21;
          if (k < 0) {
            k ^= 0xFFE03F80;
          } else {
            long l2 = k;
            k = j + 1;
            long l3 = l2 ^ arrayOfByte[j] << 28L;
            if (l3 >= 0L) {
              l2 = 266354560L;
              j = k;
            } else {
              j = k + 1;
              l2 = l3 ^ arrayOfByte[k] << 35L;
              if (l2 < 0L) {
                l3 = -34093383808L;
              } else {
                k = j + 1;
                l3 = l2 ^ arrayOfByte[j] << 42L;
                if (l3 >= 0L) {
                  l2 = 4363953127296L;
                  j = k;
                } else {
                  j = k + 1;
                  l2 = l3 ^ arrayOfByte[k] << 49L;
                  if (l2 < 0L) {
                    l3 = -558586000294016L;
                  } else {
                    k = j + 1;
                    l2 = l2 ^ arrayOfByte[j] << 56L ^ 0xFE03F80FE03F80L;
                    if (l2 < 0L) {
                      j = k + 1;
                      if (arrayOfByte[k] < 0L)
                        return O(); 
                    } else {
                      j = k;
                    } 
                    this.j = j;
                    return l2;
                  } 
                  l2 ^= l3;
                } 
                l2 = l3 ^ l2;
              } 
              l2 ^= l3;
            } 
            l2 = l3 ^ l2;
          } 
          l1 = k;
        } 
        this.j = j;
        return l1;
      } 
      long l = k;
    }
    
    long O() {
      long l = 0L;
      for (int j = 0; j < 64; j += 7) {
        byte b = G();
        l |= (b & Byte.MAX_VALUE) << j;
        if ((b & 0x80) == 0)
          return l; 
      } 
      throw b0.e();
    }
    
    public void R() {
      int j;
      do {
        j = B();
      } while (j != 0 && E(j));
    }
    
    public void S(int param1Int) {
      int j = this.h;
      int k = this.j;
      if (param1Int <= j - k && param1Int >= 0) {
        this.j = k + param1Int;
        return;
      } 
      T(param1Int);
    }
    
    public void a(int param1Int) {
      if (this.k == param1Int)
        return; 
      throw b0.a();
    }
    
    public int d() {
      return this.l + this.j;
    }
    
    public boolean e() {
      return (this.j == this.h && !X(1));
    }
    
    public void k(int param1Int) {
      this.m = param1Int;
      P();
    }
    
    public int l(int param1Int) {
      if (param1Int >= 0) {
        param1Int += this.l + this.j;
        int j = this.m;
        if (param1Int <= j) {
          this.m = param1Int;
          P();
          return j;
        } 
        throw b0.k();
      } 
      throw b0.f();
    }
    
    public boolean m() {
      return (N() != 0L);
    }
    
    public h n() {
      int j = M();
      int k = this.h;
      int m = this.j;
      if (j <= k - m && j > 0) {
        h h = h.n(this.g, m, j);
        this.j += j;
        return h;
      } 
      return (j == 0) ? h.b : F(j);
    }
    
    public double o() {
      return Double.longBitsToDouble(L());
    }
    
    public int p() {
      return M();
    }
    
    public int q() {
      return K();
    }
    
    public long r() {
      return L();
    }
    
    public float s() {
      return Float.intBitsToFloat(K());
    }
    
    public int t() {
      return M();
    }
    
    public long u() {
      return N();
    }
    
    public int v() {
      return K();
    }
    
    public long w() {
      return L();
    }
    
    public int x() {
      return i.b(M());
    }
    
    public long y() {
      return i.c(N());
    }
    
    public String z() {
      int j = M();
      if (j > 0) {
        int k = this.h;
        int m = this.j;
        if (j <= k - m) {
          String str = new String(this.g, m, j, a0.a);
          this.j += j;
          return str;
        } 
      } 
      if (j == 0)
        return ""; 
      if (j <= this.h) {
        Q(j);
        String str = new String(this.g, this.j, j, a0.a);
        this.j += j;
        return str;
      } 
      return new String(H(j, false), a0.a);
    }
    
    private static interface a {
      void a();
    }
  }
  
  private static interface a {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */