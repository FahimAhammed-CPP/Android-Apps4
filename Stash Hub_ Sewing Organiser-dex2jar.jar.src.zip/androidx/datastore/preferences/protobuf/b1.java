package androidx.datastore.preferences.protobuf;

public enum b1 {
  a, b;
  
  static {
    b1 b11 = new b1("PROTO2", 0);
    a = b11;
    b1 b12 = new b1("PROTO3", 1);
    b = b12;
    c = new b1[] { b11, b12 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */