package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.Map;

final class j implements f1 {
  private final i a;
  
  private int b;
  
  private int c;
  
  private int d = 0;
  
  private j(i parami) {
    parami = a0.<i>b(parami, "input");
    this.a = parami;
    parami.d = this;
  }
  
  public static j Q(i parami) {
    j j1 = parami.d;
    return (j1 != null) ? j1 : new j(parami);
  }
  
  private Object R(t1.b paramb, Class<?> paramClass, p paramp) {
    switch (a.a[paramb.ordinal()]) {
      default:
        throw new RuntimeException("unsupported field type.");
      case 17:
        return Long.valueOf(d());
      case 16:
        return Integer.valueOf(w());
      case 15:
        return F();
      case 14:
        return Long.valueOf(j());
      case 13:
        return Integer.valueOf(h());
      case 12:
        return Long.valueOf(r());
      case 11:
        return Integer.valueOf(z());
      case 10:
        return L(paramClass, paramp);
      case 9:
        return Long.valueOf(E());
      case 8:
        return Integer.valueOf(x());
      case 7:
        return Float.valueOf(readFloat());
      case 6:
        return Long.valueOf(f());
      case 5:
        return Integer.valueOf(n());
      case 4:
        return Integer.valueOf(b());
      case 3:
        return Double.valueOf(readDouble());
      case 2:
        return u();
      case 1:
        break;
    } 
    return Boolean.valueOf(o());
  }
  
  private <T> T S(g1<T> paramg1, p paramp) {
    int k = this.c;
    this.c = t1.c(t1.a(this.b), 4);
    try {
      T t = paramg1.f();
      paramg1.h(t, (f1)this, paramp);
      paramg1.b(t);
      int m = this.b;
      int n = this.c;
      if (m == n)
        return t; 
      throw b0.g();
    } finally {
      this.c = k;
    } 
  }
  
  private <T> T T(g1<T> paramg1, p paramp) {
    int k = this.a.C();
    i i1 = this.a;
    if (i1.a < i1.b) {
      k = i1.l(k);
      i1 = (i)paramg1.f();
      i i3 = this.a;
      i3.a++;
      paramg1.h((T)i1, (f1)this, paramp);
      paramg1.b((T)i1);
      this.a.a(0);
      i i2 = this.a;
      i2.a--;
      i2.k(k);
      return (T)i1;
    } 
    throw b0.h();
  }
  
  private void V(int paramInt) {
    if (this.a.d() == paramInt)
      return; 
    throw b0.k();
  }
  
  private void W(int paramInt) {
    if (t1.b(this.b) == paramInt)
      return; 
    throw b0.d();
  }
  
  private void X(int paramInt) {
    if ((paramInt & 0x3) == 0)
      return; 
    throw b0.g();
  }
  
  private void Y(int paramInt) {
    if ((paramInt & 0x7) == 0)
      return; 
    throw b0.g();
  }
  
  public void A(List<h> paramList) {
    if (t1.b(this.b) == 2)
      while (true) {
        paramList.add(u());
        if (this.a.e())
          return; 
        int k = this.a.B();
        if (k != this.b) {
          this.d = k;
          return;
        } 
      }  
    throw b0.d();
  }
  
  public void B(List<Double> paramList) {
    if (paramList instanceof m) {
      paramList = paramList;
      int m = t1.b(this.b);
      if (m != 1) {
        if (m == 2) {
          m = this.a.C();
          Y(m);
          int n = this.a.d();
          do {
            paramList.k(this.a.o());
          } while (this.a.d() < n + m);
          return;
        } 
        throw b0.d();
      } 
      while (true) {
        paramList.k(this.a.o());
        if (this.a.e())
          return; 
        m = this.a.B();
        if (m != this.b) {
          this.d = m;
          return;
        } 
      } 
    } 
    int k = t1.b(this.b);
    if (k != 1) {
      if (k == 2) {
        k = this.a.C();
        Y(k);
        int m = this.a.d();
        do {
          paramList.add(Double.valueOf(this.a.o()));
        } while (this.a.d() < m + k);
        return;
      } 
      throw b0.d();
    } 
    while (true) {
      paramList.add(Double.valueOf(this.a.o()));
      if (this.a.e())
        return; 
      k = this.a.B();
      if (k != this.b) {
        this.d = k;
        return;
      } 
    } 
  }
  
  public void C(List<Long> paramList) {
    int k;
    if (paramList instanceof i0) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.m(this.a.u());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.m(this.a.u());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Long.valueOf(this.a.u()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Long.valueOf(this.a.u()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public void D(List<Long> paramList) {
    if (paramList instanceof i0) {
      paramList = paramList;
      int m = t1.b(this.b);
      if (m != 1) {
        if (m == 2) {
          m = this.a.C();
          Y(m);
          int n = this.a.d();
          do {
            paramList.m(this.a.w());
          } while (this.a.d() < n + m);
          return;
        } 
        throw b0.d();
      } 
      while (true) {
        paramList.m(this.a.w());
        if (this.a.e())
          return; 
        m = this.a.B();
        if (m != this.b) {
          this.d = m;
          return;
        } 
      } 
    } 
    int k = t1.b(this.b);
    if (k != 1) {
      if (k == 2) {
        k = this.a.C();
        Y(k);
        int m = this.a.d();
        do {
          paramList.add(Long.valueOf(this.a.w()));
        } while (this.a.d() < m + k);
        return;
      } 
      throw b0.d();
    } 
    while (true) {
      paramList.add(Long.valueOf(this.a.w()));
      if (this.a.e())
        return; 
      k = this.a.B();
      if (k != this.b) {
        this.d = k;
        return;
      } 
    } 
  }
  
  public long E() {
    W(0);
    return this.a.u();
  }
  
  public String F() {
    W(2);
    return this.a.A();
  }
  
  public void G(List<Long> paramList) {
    if (paramList instanceof i0) {
      paramList = paramList;
      int m = t1.b(this.b);
      if (m != 1) {
        if (m == 2) {
          m = this.a.C();
          Y(m);
          int n = this.a.d();
          do {
            paramList.m(this.a.r());
          } while (this.a.d() < n + m);
          return;
        } 
        throw b0.d();
      } 
      while (true) {
        paramList.m(this.a.r());
        if (this.a.e())
          return; 
        m = this.a.B();
        if (m != this.b) {
          this.d = m;
          return;
        } 
      } 
    } 
    int k = t1.b(this.b);
    if (k != 1) {
      if (k == 2) {
        k = this.a.C();
        Y(k);
        int m = this.a.d();
        do {
          paramList.add(Long.valueOf(this.a.r()));
        } while (this.a.d() < m + k);
        return;
      } 
      throw b0.d();
    } 
    while (true) {
      paramList.add(Long.valueOf(this.a.r()));
      if (this.a.e())
        return; 
      k = this.a.B();
      if (k != this.b) {
        this.d = k;
        return;
      } 
    } 
  }
  
  public void H(List<Integer> paramList) {
    int k;
    if (paramList instanceof z) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.k(this.a.t());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.k(this.a.t());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Integer.valueOf(this.a.t()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Integer.valueOf(this.a.t()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public void I(List<Integer> paramList) {
    int k;
    if (paramList instanceof z) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.k(this.a.p());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.k(this.a.p());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Integer.valueOf(this.a.p()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Integer.valueOf(this.a.p()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public <T> T J(g1<T> paramg1, p paramp) {
    W(2);
    return T(paramg1, paramp);
  }
  
  public <K, V> void K(Map<K, V> paramMap, k0.a<K, V> parama, p paramp) {
    W(2);
    int k = this.a.C();
    k = this.a.l(k);
    K k1 = parama.b;
    V v = parama.d;
    while (true) {
      try {
        int m = p();
        if (m != Integer.MAX_VALUE) {
          boolean bool = this.a.e();
          if (!bool) {
            if (m != 1) {
              if (m != 2)
                try {
                  if (y())
                    continue; 
                  throw new b0("Unable to parse map entry.");
                } catch (a a1) {
                  if (y())
                    continue; 
                  throw new b0("Unable to parse map entry.");
                }  
              Object object1 = R(parama.c, parama.d.getClass(), paramp);
              v = (V)object1;
              continue;
            } 
            Object object = R(parama.a, null, null);
            k1 = (K)object;
            continue;
          } 
        } 
        paramMap.put(k1, v);
        return;
      } finally {
        this.a.k(k);
      } 
    } 
  }
  
  public <T> T L(Class<T> paramClass, p paramp) {
    W(2);
    return T(c1.a().d(paramClass), paramp);
  }
  
  public <T> T M(Class<T> paramClass, p paramp) {
    W(3);
    return S(c1.a().d(paramClass), paramp);
  }
  
  public <T> void N(List<T> paramList, g1<T> paramg1, p paramp) {
    if (t1.b(this.b) == 3) {
      int k = this.b;
      while (true) {
        paramList.add(S(paramg1, paramp));
        if (!this.a.e()) {
          if (this.d != 0)
            return; 
          int m = this.a.B();
          if (m != k) {
            this.d = m;
            break;
          } 
          continue;
        } 
        break;
      } 
      return;
    } 
    throw b0.d();
  }
  
  public <T> void O(List<T> paramList, g1<T> paramg1, p paramp) {
    if (t1.b(this.b) == 2) {
      int k = this.b;
      while (true) {
        paramList.add(T(paramg1, paramp));
        if (!this.a.e()) {
          if (this.d != 0)
            return; 
          int m = this.a.B();
          if (m != k) {
            this.d = m;
            break;
          } 
          continue;
        } 
        break;
      } 
      return;
    } 
    throw b0.d();
  }
  
  public <T> T P(g1<T> paramg1, p paramp) {
    W(3);
    return S(paramg1, paramp);
  }
  
  public void U(List<String> paramList, boolean paramBoolean) {
    if (t1.b(this.b) == 2) {
      if (paramList instanceof g0 && !paramBoolean) {
        paramList = paramList;
        while (true) {
          paramList.l(u());
          if (this.a.e())
            return; 
          int k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
      while (true) {
        String str;
        if (paramBoolean) {
          str = F();
        } else {
          str = m();
        } 
        paramList.add(str);
        if (this.a.e())
          return; 
        int k = this.a.B();
        if (k != this.b) {
          this.d = k;
          return;
        } 
      } 
    } 
    throw b0.d();
  }
  
  public void a(List<Integer> paramList) {
    int k;
    if (paramList instanceof z) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.k(this.a.x());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.k(this.a.x());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Integer.valueOf(this.a.x()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Integer.valueOf(this.a.x()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public int b() {
    W(0);
    return this.a.p();
  }
  
  public int c() {
    return this.b;
  }
  
  public long d() {
    W(0);
    return this.a.D();
  }
  
  public void e(List<Integer> paramList) {
    if (paramList instanceof z) {
      paramList = paramList;
      int n = t1.b(this.b);
      if (n != 2) {
        if (n == 5)
          while (true) {
            paramList.k(this.a.q());
            if (this.a.e())
              return; 
            n = this.a.B();
            if (n != this.b) {
              this.d = n;
              return;
            } 
          }  
        throw b0.d();
      } 
      n = this.a.C();
      X(n);
      int i1 = this.a.d();
      do {
        paramList.k(this.a.q());
      } while (this.a.d() < i1 + n);
      return;
    } 
    int k = t1.b(this.b);
    if (k != 2) {
      if (k == 5)
        while (true) {
          paramList.add(Integer.valueOf(this.a.q()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        }  
      throw b0.d();
    } 
    k = this.a.C();
    X(k);
    int m = this.a.d();
    do {
      paramList.add(Integer.valueOf(this.a.q()));
    } while (this.a.d() < m + k);
  }
  
  public long f() {
    W(1);
    return this.a.r();
  }
  
  public void g(List<Integer> paramList) {
    if (paramList instanceof z) {
      paramList = paramList;
      int n = t1.b(this.b);
      if (n != 2) {
        if (n == 5)
          while (true) {
            paramList.k(this.a.v());
            if (this.a.e())
              return; 
            n = this.a.B();
            if (n != this.b) {
              this.d = n;
              return;
            } 
          }  
        throw b0.d();
      } 
      n = this.a.C();
      X(n);
      int i1 = this.a.d();
      do {
        paramList.k(this.a.v());
      } while (this.a.d() < i1 + n);
      return;
    } 
    int k = t1.b(this.b);
    if (k != 2) {
      if (k == 5)
        while (true) {
          paramList.add(Integer.valueOf(this.a.v()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        }  
      throw b0.d();
    } 
    k = this.a.C();
    X(k);
    int m = this.a.d();
    do {
      paramList.add(Integer.valueOf(this.a.v()));
    } while (this.a.d() < m + k);
  }
  
  public int h() {
    W(0);
    return this.a.x();
  }
  
  public void i(List<Long> paramList) {
    int k;
    if (paramList instanceof i0) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.m(this.a.y());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.m(this.a.y());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Long.valueOf(this.a.y()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Long.valueOf(this.a.y()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public long j() {
    W(0);
    return this.a.y();
  }
  
  public void k(List<Integer> paramList) {
    int k;
    if (paramList instanceof z) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.k(this.a.C());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.k(this.a.C());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Integer.valueOf(this.a.C()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Integer.valueOf(this.a.C()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public void l(List<Boolean> paramList) {
    int k;
    if (paramList instanceof f) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.m(this.a.m());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.m(this.a.m());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Boolean.valueOf(this.a.m()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Boolean.valueOf(this.a.m()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public String m() {
    W(2);
    return this.a.z();
  }
  
  public int n() {
    W(5);
    return this.a.q();
  }
  
  public boolean o() {
    W(0);
    return this.a.m();
  }
  
  public int p() {
    int k = this.d;
    if (k != 0) {
      this.b = k;
      this.d = 0;
    } else {
      this.b = this.a.B();
    } 
    k = this.b;
    return (k == 0 || k == this.c) ? Integer.MAX_VALUE : t1.a(k);
  }
  
  public void q(List<String> paramList) {
    U(paramList, false);
  }
  
  public long r() {
    W(1);
    return this.a.w();
  }
  
  public double readDouble() {
    W(1);
    return this.a.o();
  }
  
  public float readFloat() {
    W(5);
    return this.a.s();
  }
  
  public void s(List<Long> paramList) {
    int k;
    if (paramList instanceof i0) {
      paramList = paramList;
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.m(this.a.D());
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.m(this.a.D());
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } else {
      k = t1.b(this.b);
      if (k != 0) {
        if (k == 2) {
          k = this.a.C();
          k = this.a.d() + k;
          do {
            paramList.add(Long.valueOf(this.a.D()));
          } while (this.a.d() < k);
        } else {
          throw b0.d();
        } 
      } else {
        while (true) {
          paramList.add(Long.valueOf(this.a.D()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        } 
      } 
    } 
    V(k);
  }
  
  public void t(List<String> paramList) {
    U(paramList, true);
  }
  
  public h u() {
    W(2);
    return this.a.n();
  }
  
  public void v(List<Float> paramList) {
    if (paramList instanceof w) {
      paramList = paramList;
      int n = t1.b(this.b);
      if (n != 2) {
        if (n == 5)
          while (true) {
            paramList.k(this.a.s());
            if (this.a.e())
              return; 
            n = this.a.B();
            if (n != this.b) {
              this.d = n;
              return;
            } 
          }  
        throw b0.d();
      } 
      n = this.a.C();
      X(n);
      int i1 = this.a.d();
      do {
        paramList.k(this.a.s());
      } while (this.a.d() < i1 + n);
      return;
    } 
    int k = t1.b(this.b);
    if (k != 2) {
      if (k == 5)
        while (true) {
          paramList.add(Float.valueOf(this.a.s()));
          if (this.a.e())
            return; 
          k = this.a.B();
          if (k != this.b) {
            this.d = k;
            return;
          } 
        }  
      throw b0.d();
    } 
    k = this.a.C();
    X(k);
    int m = this.a.d();
    do {
      paramList.add(Float.valueOf(this.a.s()));
    } while (this.a.d() < m + k);
  }
  
  public int w() {
    W(0);
    return this.a.C();
  }
  
  public int x() {
    W(0);
    return this.a.t();
  }
  
  public boolean y() {
    if (!this.a.e()) {
      int k = this.b;
      if (k != this.c)
        return this.a.E(k); 
    } 
    return false;
  }
  
  public int z() {
    W(5);
    return this.a.v();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */