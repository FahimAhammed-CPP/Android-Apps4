package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

final class v0<T> implements g1<T> {
  private final r0 a;
  
  private final n1<?, ?> b;
  
  private final boolean c;
  
  private final q<?> d;
  
  private v0(n1<?, ?> paramn1, q<?> paramq, r0 paramr0) {
    this.b = paramn1;
    this.c = paramq.e(paramr0);
    this.d = paramq;
    this.a = paramr0;
  }
  
  private <UT, UB> int j(n1<UT, UB> paramn1, T paramT) {
    return paramn1.i(paramn1.g(paramT));
  }
  
  private <UT, UB, ET extends u.b<ET>> void k(n1<UT, UB> paramn1, q<ET> paramq, T paramT, f1 paramf1, p paramp) {
    UB uB = paramn1.f(paramT);
    u<ET> u = paramq.d(paramT);
    try {
      while (true) {
        int i = paramf1.p();
        if (i == Integer.MAX_VALUE)
          return; 
        boolean bool = m(paramf1, paramp, paramq, u, paramn1, uB);
        if (bool)
          continue; 
        return;
      } 
    } finally {
      paramn1.o(paramT, uB);
    } 
  }
  
  static <T> v0<T> l(n1<?, ?> paramn1, q<?> paramq, r0 paramr0) {
    return new v0<T>(paramn1, paramq, paramr0);
  }
  
  private <UT, UB, ET extends u.b<ET>> boolean m(f1 paramf1, p paramp, q<ET> paramq, u<ET> paramu, n1<UT, UB> paramn1, UB paramUB) {
    int i = paramf1.c();
    if (i != t1.a) {
      if (t1.b(i) == 2) {
        Object object1 = paramq.b(paramp, this.a, t1.a(i));
        if (object1 != null) {
          paramq.h(paramf1, object1, paramp, paramu);
          return true;
        } 
        return paramn1.m(paramUB, paramf1);
      } 
      return paramf1.y();
    } 
    i = 0;
    Object object = null;
    h h = null;
    while (paramf1.p() != Integer.MAX_VALUE) {
      int j = paramf1.c();
      if (j == t1.c) {
        i = paramf1.w();
        object = paramq.b(paramp, this.a, i);
        continue;
      } 
      if (j == t1.d) {
        if (object != null) {
          paramq.h(paramf1, object, paramp, paramu);
          continue;
        } 
        h = paramf1.u();
        continue;
      } 
      if (!paramf1.y())
        break; 
    } 
    if (paramf1.c() == t1.b) {
      if (h != null) {
        if (object != null) {
          paramq.i(h, object, paramp, paramu);
          return true;
        } 
        paramn1.d(paramUB, i, h);
      } 
      return true;
    } 
    throw b0.a();
  }
  
  private <UT, UB> void n(n1<UT, UB> paramn1, T paramT, u1 paramu1) {
    paramn1.s(paramn1.g(paramT), paramu1);
  }
  
  public void a(T paramT1, T paramT2) {
    i1.G(this.b, paramT1, paramT2);
    if (this.c)
      i1.E(this.d, paramT1, paramT2); 
  }
  
  public void b(T paramT) {
    this.b.j(paramT);
    this.d.f(paramT);
  }
  
  public final boolean c(T paramT) {
    return this.d.c(paramT).p();
  }
  
  public boolean d(T paramT1, T paramT2) {
    return !this.b.g(paramT1).equals(this.b.g(paramT2)) ? false : (this.c ? this.d.c(paramT1).equals(this.d.c(paramT2)) : true);
  }
  
  public int e(T paramT) {
    int j = j(this.b, paramT) + 0;
    int i = j;
    if (this.c)
      i = j + this.d.c(paramT).j(); 
    return i;
  }
  
  public T f() {
    return (T)this.a.e().g();
  }
  
  public int g(T paramT) {
    int j = this.b.g(paramT).hashCode();
    int i = j;
    if (this.c)
      i = j * 53 + this.d.c(paramT).hashCode(); 
    return i;
  }
  
  public void h(T paramT, f1 paramf1, p paramp) {
    k(this.b, this.d, paramT, paramf1, paramp);
  }
  
  public void i(T paramT, u1 paramu1) {
    Iterator<Map.Entry> iterator = this.d.c(paramT).s();
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      u.b b = (u.b)entry.getKey();
      if (b.e() == t1.c.n && !b.c() && !b.f()) {
        h h;
        boolean bool = entry instanceof d0.b;
        int i = b.b();
        if (bool) {
          h = ((d0.b)entry).a().e();
        } else {
          h = (h)h.getValue();
        } 
        paramu1.f(i, h);
        continue;
      } 
      throw new IllegalStateException("Found invalid MessageSet item.");
    } 
    n(this.b, paramT, paramu1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */