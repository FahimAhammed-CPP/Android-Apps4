package androidx.datastore.preferences.protobuf;

final class j0 implements h1 {
  private static final q0 b = new a();
  
  private final q0 a;
  
  public j0() {
    this(b());
  }
  
  private j0(q0 paramq0) {
    this.a = a0.<q0>b(paramq0, "messageInfoFactory");
  }
  
  private static q0 b() {
    return new b(new q0[] { x.c(), c() });
  }
  
  private static q0 c() {
    try {
      return (q0)Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
    } catch (Exception exception) {
      return b;
    } 
  }
  
  private static boolean d(p0 paramp0) {
    return (paramp0.b() == b1.a);
  }
  
  private static <T> g1<T> e(Class<T> paramClass, p0 paramp0) {
    return y.class.isAssignableFrom(paramClass) ? (d(paramp0) ? u0.N(paramClass, paramp0, y0.b(), h0.b(), i1.M(), s.b(), o0.b()) : u0.N(paramClass, paramp0, y0.b(), h0.b(), i1.M(), null, o0.b())) : (d(paramp0) ? u0.N(paramClass, paramp0, y0.a(), h0.a(), i1.H(), s.a(), o0.a()) : u0.N(paramClass, paramp0, y0.a(), h0.a(), i1.I(), null, o0.a()));
  }
  
  public <T> g1<T> a(Class<T> paramClass) {
    q<?> q;
    i1.J(paramClass);
    p0 p0 = this.a.a(paramClass);
    if (p0.a()) {
      if (y.class.isAssignableFrom(paramClass)) {
        n1<?, ?> n11 = i1.M();
        q<?> q1 = s.b();
        return v0.l(n11, q1, p0.c());
      } 
      n1<?, ?> n1 = i1.H();
      q = s.a();
      return v0.l(n1, q, p0.c());
    } 
    return e((Class)q, p0);
  }
  
  static final class a implements q0 {
    public p0 a(Class<?> param1Class) {
      throw new IllegalStateException("This should never be called.");
    }
    
    public boolean b(Class<?> param1Class) {
      return false;
    }
  }
  
  private static class b implements q0 {
    private q0[] a;
    
    b(q0... param1VarArgs) {
      this.a = param1VarArgs;
    }
    
    public p0 a(Class<?> param1Class) {
      for (q0 q01 : this.a) {
        if (q01.b(param1Class))
          return q01.a(param1Class); 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No factory is available for message type: ");
      stringBuilder.append(param1Class.getName());
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    public boolean b(Class<?> param1Class) {
      q0[] arrayOfQ0 = this.a;
      int j = arrayOfQ0.length;
      for (int i = 0; i < j; i++) {
        if (arrayOfQ0[i].b(param1Class))
          return true; 
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */