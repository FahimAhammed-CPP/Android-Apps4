package androidx.datastore.preferences.protobuf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

abstract class h0 {
  private static final h0 a = new b(null);
  
  private static final h0 b = new c(null);
  
  private h0() {}
  
  static h0 a() {
    return a;
  }
  
  static h0 b() {
    return b;
  }
  
  abstract void c(Object paramObject, long paramLong);
  
  abstract <L> void d(Object paramObject1, Object paramObject2, long paramLong);
  
  abstract <L> List<L> e(Object paramObject, long paramLong);
  
  private static final class b extends h0 {
    private static final Class<?> c = Collections.unmodifiableList(Collections.emptyList()).getClass();
    
    private b() {
      super(null);
    }
    
    static <E> List<E> f(Object param1Object, long param1Long) {
      return (List<E>)r1.A(param1Object, param1Long);
    }
    
    private static <L> List<L> g(Object param1Object, long param1Long, int param1Int) {
      List<?> list = f(param1Object, param1Long);
      if (list.isEmpty()) {
        ArrayList<L> arrayList;
        if (list instanceof g0) {
          f0 f0 = new f0(param1Int);
        } else if (list instanceof a1 && list instanceof a0.i) {
          a0.i i = ((a0.i)list).e(param1Int);
        } else {
          arrayList = new ArrayList(param1Int);
        } 
        r1.O(param1Object, param1Long, arrayList);
        return arrayList;
      } 
      if (c.isAssignableFrom(list.getClass())) {
        ArrayList<?> arrayList = new ArrayList(list.size() + param1Int);
        arrayList.addAll(list);
        r1.O(param1Object, param1Long, arrayList);
        return (List)arrayList;
      } 
      if (list instanceof q1) {
        f0 f0 = new f0(list.size() + param1Int);
        f0.addAll((q1)list);
        r1.O(param1Object, param1Long, f0);
        return f0;
      } 
      if (list instanceof a1 && list instanceof a0.i) {
        a0.i<L> i = (a0.i)list;
        if (!i.j()) {
          i = i.e(list.size() + param1Int);
          r1.O(param1Object, param1Long, i);
          return i;
        } 
      } 
      return (List)list;
    }
    
    void c(Object param1Object, long param1Long) {
      List<?> list = (List)r1.A(param1Object, param1Long);
      if (list instanceof g0) {
        list = ((g0)list).f();
      } else {
        if (c.isAssignableFrom(list.getClass()))
          return; 
        if (list instanceof a1 && list instanceof a0.i) {
          param1Object = list;
          if (param1Object.j())
            param1Object.d(); 
          return;
        } 
        list = Collections.unmodifiableList(list);
      } 
      r1.O(param1Object, param1Long, list);
    }
    
    <E> void d(Object param1Object1, Object<?> param1Object2, long param1Long) {
      param1Object2 = f(param1Object2, param1Long);
      List<?> list = g(param1Object1, param1Long, param1Object2.size());
      int i = list.size();
      int j = param1Object2.size();
      if (i > 0 && j > 0)
        list.addAll((Collection<?>)param1Object2); 
      if (i > 0)
        param1Object2 = (Object<?>)list; 
      r1.O(param1Object1, param1Long, param1Object2);
    }
    
    <L> List<L> e(Object param1Object, long param1Long) {
      return g(param1Object, param1Long, 10);
    }
  }
  
  private static final class c extends h0 {
    private c() {
      super(null);
    }
    
    static <E> a0.i<E> f(Object param1Object, long param1Long) {
      return (a0.i<E>)r1.A(param1Object, param1Long);
    }
    
    void c(Object param1Object, long param1Long) {
      f(param1Object, param1Long).d();
    }
    
    <E> void d(Object param1Object1, Object<?> param1Object2, long param1Long) {
      Object<?> object;
      a0.i<?> i1 = f(param1Object1, param1Long);
      a0.i<?> i2 = f(param1Object2, param1Long);
      int i = i1.size();
      int j = i2.size();
      param1Object2 = (Object<?>)i1;
      if (i > 0) {
        param1Object2 = (Object<?>)i1;
        if (j > 0) {
          param1Object2 = (Object<?>)i1;
          if (!i1.j())
            param1Object2 = (Object<?>)i1.e(j + i); 
          param1Object2.addAll(i2);
        } 
      } 
      i1 = i2;
      if (i > 0)
        object = param1Object2; 
      r1.O(param1Object1, param1Long, object);
    }
    
    <L> List<L> e(Object param1Object, long param1Long) {
      a0.i<?> i2 = f(param1Object, param1Long);
      a0.i<?> i1 = i2;
      if (!i2.j()) {
        int i = i2.size();
        if (i == 0) {
          i = 10;
        } else {
          i *= 2;
        } 
        i1 = i2.e(i);
        r1.O(param1Object, param1Long, i1);
      } 
      return (List)i1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */