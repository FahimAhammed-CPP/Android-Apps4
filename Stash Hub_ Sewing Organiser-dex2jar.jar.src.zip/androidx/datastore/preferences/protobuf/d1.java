package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.RandomAccess;

final class d1<E> extends c<E> implements RandomAccess {
  private static final d1<Object> d;
  
  private E[] b;
  
  private int c;
  
  static {
    d1<Object> d11 = new d1((E[])new Object[0], 0);
    d = d11;
    d11.d();
  }
  
  private d1(E[] paramArrayOfE, int paramInt) {
    this.b = paramArrayOfE;
    this.c = paramInt;
  }
  
  private static <E> E[] c(int paramInt) {
    return (E[])new Object[paramInt];
  }
  
  public static <E> d1<E> g() {
    return (d1)d;
  }
  
  private void k(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(m(paramInt));
  }
  
  private String m(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public void add(int paramInt, E paramE) {
    a();
    if (paramInt >= 0) {
      int i = this.c;
      if (paramInt <= i) {
        E[] arrayOfE = this.b;
        if (i < arrayOfE.length) {
          System.arraycopy(arrayOfE, paramInt, arrayOfE, paramInt + 1, i - paramInt);
        } else {
          arrayOfE = c(i * 3 / 2 + 1);
          System.arraycopy(this.b, 0, arrayOfE, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfE, paramInt + 1, this.c - paramInt);
          this.b = arrayOfE;
        } 
        this.b[paramInt] = paramE;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(m(paramInt));
  }
  
  public boolean add(E paramE) {
    a();
    int i = this.c;
    E[] arrayOfE = this.b;
    if (i == arrayOfE.length)
      this.b = Arrays.copyOf(arrayOfE, i * 3 / 2 + 1); 
    arrayOfE = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfE[i] = paramE;
    this.modCount++;
    return true;
  }
  
  public E get(int paramInt) {
    k(paramInt);
    return this.b[paramInt];
  }
  
  public d1<E> n(int paramInt) {
    if (paramInt >= this.c)
      return new d1(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public E remove(int paramInt) {
    a();
    k(paramInt);
    E[] arrayOfE = this.b;
    E e = arrayOfE[paramInt];
    int i = this.c;
    if (paramInt < i - 1)
      System.arraycopy(arrayOfE, paramInt + 1, arrayOfE, paramInt, i - paramInt - 1); 
    this.c--;
    this.modCount++;
    return e;
  }
  
  public E set(int paramInt, E paramE) {
    a();
    k(paramInt);
    E[] arrayOfE = this.b;
    E e = arrayOfE[paramInt];
    arrayOfE[paramInt] = paramE;
    this.modCount++;
    return e;
  }
  
  public int size() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */