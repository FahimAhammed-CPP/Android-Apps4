package androidx.datastore.preferences.protobuf;

final class o {
  static final Class<?> a = c();
  
  public static p a() {
    if (a != null)
      try {
        return b("getEmptyRegistry");
      } catch (Exception exception) {} 
    return p.e;
  }
  
  private static final p b(String paramString) {
    return (p)a.getDeclaredMethod(paramString, new Class[0]).invoke(null, new Object[0]);
  }
  
  static Class<?> c() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.ExtensionRegistry");
    } catch (ClassNotFoundException classNotFoundException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */