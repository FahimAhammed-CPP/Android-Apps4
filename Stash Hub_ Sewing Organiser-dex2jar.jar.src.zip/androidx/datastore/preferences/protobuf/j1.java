package androidx.datastore.preferences.protobuf;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

class j1<K extends Comparable<K>, V> extends AbstractMap<K, V> {
  private final int a;
  
  private List<e> b;
  
  private Map<K, V> c;
  
  private boolean d;
  
  private volatile g e;
  
  private Map<K, V> f;
  
  private volatile c g;
  
  private j1(int paramInt) {
    this.a = paramInt;
    this.b = Collections.emptyList();
    this.c = Collections.emptyMap();
    this.f = Collections.emptyMap();
  }
  
  private int f(K paramK) {
    int j = this.b.size() - 1;
    if (j >= 0) {
      int k = paramK.compareTo(((e)this.b.get(j)).h());
      if (k > 0)
        return -(j + 2); 
      if (k == 0)
        return j; 
    } 
    int i = 0;
    while (i <= j) {
      int k = (i + j) / 2;
      int m = paramK.compareTo(((e)this.b.get(k)).h());
      if (m < 0) {
        j = k - 1;
        continue;
      } 
      if (m > 0) {
        i = k + 1;
        continue;
      } 
      return k;
    } 
    return -(i + 1);
  }
  
  private void g() {
    if (!this.d)
      return; 
    throw new UnsupportedOperationException();
  }
  
  private void i() {
    g();
    if (this.b.isEmpty() && !(this.b instanceof ArrayList))
      this.b = new ArrayList<e>(this.a); 
  }
  
  private SortedMap<K, V> n() {
    g();
    if (this.c.isEmpty() && !(this.c instanceof TreeMap)) {
      TreeMap<Object, Object> treeMap1 = new TreeMap<Object, Object>();
      this.c = (Map)treeMap1;
      TreeMap<Object, Object> treeMap2 = treeMap1;
      this.f = (Map)treeMap1.descendingMap();
    } 
    return (SortedMap<K, V>)this.c;
  }
  
  static <FieldDescriptorType extends u.b<FieldDescriptorType>> j1<FieldDescriptorType, Object> q(int paramInt) {
    return new a(paramInt);
  }
  
  private V s(int paramInt) {
    g();
    V v = ((e)this.b.remove(paramInt)).getValue();
    if (!this.c.isEmpty()) {
      Iterator<Map.Entry<K, V>> iterator = n().entrySet().iterator();
      this.b.add(new e(iterator.next()));
      iterator.remove();
    } 
    return v;
  }
  
  public void clear() {
    g();
    if (!this.b.isEmpty())
      this.b.clear(); 
    if (!this.c.isEmpty())
      this.c.clear(); 
  }
  
  public boolean containsKey(Object paramObject) {
    paramObject = paramObject;
    return (f((K)paramObject) >= 0 || this.c.containsKey(paramObject));
  }
  
  public Set<Map.Entry<K, V>> entrySet() {
    if (this.e == null)
      this.e = new g(null); 
    return this.e;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof j1))
      return super.equals(paramObject); 
    paramObject = paramObject;
    int j = size();
    if (j != paramObject.size())
      return false; 
    int k = k();
    if (k != paramObject.k())
      return entrySet().equals(paramObject.entrySet()); 
    for (int i = 0; i < k; i++) {
      if (!j(i).equals(paramObject.j(i)))
        return false; 
    } 
    return (k != j) ? this.c.equals(((j1)paramObject).c) : true;
  }
  
  public V get(Object paramObject) {
    paramObject = paramObject;
    int i = f((K)paramObject);
    return (i >= 0) ? ((e)this.b.get(i)).getValue() : this.c.get(paramObject);
  }
  
  Set<Map.Entry<K, V>> h() {
    if (this.g == null)
      this.g = new c(null); 
    return this.g;
  }
  
  public int hashCode() {
    int k = k();
    int j = 0;
    int i = 0;
    while (j < k) {
      i += ((e)this.b.get(j)).hashCode();
      j++;
    } 
    j = i;
    if (l() > 0)
      j = i + this.c.hashCode(); 
    return j;
  }
  
  public Map.Entry<K, V> j(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public int k() {
    return this.b.size();
  }
  
  public int l() {
    return this.c.size();
  }
  
  public Iterable<Map.Entry<K, V>> m() {
    return this.c.isEmpty() ? d.b() : this.c.entrySet();
  }
  
  public boolean o() {
    return this.d;
  }
  
  public void p() {
    if (!this.d) {
      Map<?, ?> map;
      if (this.c.isEmpty()) {
        map = Collections.emptyMap();
      } else {
        map = Collections.unmodifiableMap(this.c);
      } 
      this.c = (Map)map;
      if (this.f.isEmpty()) {
        map = Collections.emptyMap();
      } else {
        map = Collections.unmodifiableMap(this.f);
      } 
      this.f = (Map)map;
      this.d = true;
    } 
  }
  
  public V r(K paramK, V paramV) {
    g();
    int i = f(paramK);
    if (i >= 0)
      return ((e)this.b.get(i)).setValue(paramV); 
    i();
    i = -(i + 1);
    if (i >= this.a)
      return n().put(paramK, paramV); 
    int j = this.b.size();
    int k = this.a;
    if (j == k) {
      e e = this.b.remove(k - 1);
      n().put(e.h(), e.getValue());
    } 
    this.b.add(i, new e(paramK, paramV));
    return null;
  }
  
  public V remove(Object paramObject) {
    g();
    paramObject = paramObject;
    int i = f((K)paramObject);
    return (i >= 0) ? s(i) : (this.c.isEmpty() ? null : this.c.remove(paramObject));
  }
  
  public int size() {
    return this.b.size() + this.c.size();
  }
  
  static final class a extends j1<FieldDescriptorType, Object> {
    a(int param1Int) {
      super(param1Int, null);
    }
    
    public void p() {
      if (!o()) {
        for (int i = 0; i < k(); i++) {
          Map.Entry<K, V> entry = j(i);
          if (((u.b)entry.getKey()).c())
            entry.setValue((V)Collections.unmodifiableList((List)entry.getValue())); 
        } 
        for (Map.Entry<K, V> entry : m()) {
          if (((u.b)entry.getKey()).c())
            entry.setValue(Collections.unmodifiableList((List)entry.getValue())); 
        } 
      } 
      super.p();
    }
  }
  
  private class b implements Iterator<Map.Entry<K, V>> {
    private int a = j1.b(j1.this).size();
    
    private Iterator<Map.Entry<K, V>> b;
    
    private b(j1 this$0) {}
    
    private Iterator<Map.Entry<K, V>> b() {
      if (this.b == null)
        this.b = j1.e(this.c).entrySet().iterator(); 
      return this.b;
    }
    
    public Map.Entry<K, V> c() {
      if (b().hasNext()) {
        Map.Entry entry = (Map.Entry)b().next();
        return entry;
      } 
      List<List> list = j1.b(this.c);
      int i = this.a - 1;
      this.a = i;
      list = list.get(i);
      return (Map.Entry)list;
    }
    
    public boolean hasNext() {
      int i = this.a;
      return ((i > 0 && i <= j1.b(this.c).size()) || b().hasNext());
    }
    
    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
  
  private class c extends g {
    private c(j1 this$0) {
      super(null);
    }
    
    public Iterator<Map.Entry<K, V>> iterator() {
      return new j1.b(null);
    }
  }
  
  private static class d {
    private static final Iterator<Object> a = new a();
    
    private static final Iterable<Object> b = new b();
    
    static <T> Iterable<T> b() {
      return (Iterable)b;
    }
    
    static final class a implements Iterator<Object> {
      public boolean hasNext() {
        return false;
      }
      
      public Object next() {
        throw new NoSuchElementException();
      }
      
      public void remove() {
        throw new UnsupportedOperationException();
      }
    }
    
    static final class b implements Iterable<Object> {
      public Iterator<Object> iterator() {
        return j1.d.a();
      }
    }
  }
  
  static final class a implements Iterator<Object> {
    public boolean hasNext() {
      return false;
    }
    
    public Object next() {
      throw new NoSuchElementException();
    }
    
    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
  
  static final class b implements Iterable<Object> {
    public Iterator<Object> iterator() {
      return j1.d.a();
    }
  }
  
  private class e implements Map.Entry<K, V>, Comparable<e> {
    private final K a;
    
    private V b;
    
    e(j1 this$0, K param1K, V param1V) {
      this.a = param1K;
      this.b = param1V;
    }
    
    e(Map.Entry<K, V> param1Entry) {
      this(param1Entry.getKey(), param1Entry.getValue());
    }
    
    private boolean g(Object param1Object1, Object param1Object2) {
      return (param1Object1 == null) ? ((param1Object2 == null)) : param1Object1.equals(param1Object2);
    }
    
    public int a(e param1e) {
      return h().compareTo(param1e.h());
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof Map.Entry))
        return false; 
      param1Object = param1Object;
      return (g(this.a, param1Object.getKey()) && g(this.b, param1Object.getValue()));
    }
    
    public V getValue() {
      return this.b;
    }
    
    public K h() {
      return this.a;
    }
    
    public int hashCode() {
      int i;
      K k = this.a;
      int j = 0;
      if (k == null) {
        i = 0;
      } else {
        i = k.hashCode();
      } 
      V v = this.b;
      if (v != null)
        j = v.hashCode(); 
      return i ^ j;
    }
    
    public V setValue(V param1V) {
      j1.a(this.c);
      V v = this.b;
      this.b = param1V;
      return v;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("=");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
  
  private class f implements Iterator<Map.Entry<K, V>> {
    private int a = -1;
    
    private boolean b;
    
    private Iterator<Map.Entry<K, V>> c;
    
    private f(j1 this$0) {}
    
    private Iterator<Map.Entry<K, V>> b() {
      if (this.c == null)
        this.c = j1.c(this.d).entrySet().iterator(); 
      return this.c;
    }
    
    public Map.Entry<K, V> c() {
      this.b = true;
      int i = this.a + 1;
      this.a = i;
      if (i < j1.b(this.d).size()) {
        Map.Entry entry1 = (Map.Entry)j1.b(this.d).get(this.a);
        return entry1;
      } 
      Map.Entry entry = (Map.Entry)b().next();
      return entry;
    }
    
    public boolean hasNext() {
      int i = this.a;
      boolean bool = true;
      if (i + 1 >= j1.b(this.d).size()) {
        if (!j1.c(this.d).isEmpty() && b().hasNext())
          return true; 
        bool = false;
      } 
      return bool;
    }
    
    public void remove() {
      if (this.b) {
        this.b = false;
        j1.a(this.d);
        if (this.a < j1.b(this.d).size()) {
          j1 j11 = this.d;
          int i = this.a;
          this.a = i - 1;
          j1.d(j11, i);
          return;
        } 
        b().remove();
        return;
      } 
      throw new IllegalStateException("remove() was called before next()");
    }
  }
  
  private class g extends AbstractSet<Map.Entry<K, V>> {
    private g(j1 this$0) {}
    
    public boolean a(Map.Entry<K, V> param1Entry) {
      if (!contains(param1Entry)) {
        this.a.r((Comparable)param1Entry.getKey(), param1Entry.getValue());
        return true;
      } 
      return false;
    }
    
    public void clear() {
      this.a.clear();
    }
    
    public boolean contains(Object param1Object) {
      Map.Entry entry = (Map.Entry)param1Object;
      param1Object = this.a.get(entry.getKey());
      entry = (Map.Entry)entry.getValue();
      return (param1Object == entry || (param1Object != null && param1Object.equals(entry)));
    }
    
    public Iterator<Map.Entry<K, V>> iterator() {
      return new j1.f(null);
    }
    
    public boolean remove(Object param1Object) {
      param1Object = param1Object;
      if (contains(param1Object)) {
        this.a.remove(param1Object.getKey());
        return true;
      } 
      return false;
    }
    
    public int size() {
      return this.a.size();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\j1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */