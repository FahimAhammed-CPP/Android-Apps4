package androidx.datastore.preferences.protobuf;

final class l1 {
  static String a(h paramh) {
    return b(new a(paramh));
  }
  
  static String b(b paramb) {
    StringBuilder stringBuilder = new StringBuilder(paramb.size());
    for (int i = 0; i < paramb.size(); i++) {
      byte b1 = paramb.a(i);
      if (b1 != 34) {
        if (b1 != 39) {
          if (b1 != 92) {
            int j;
            String str;
            switch (b1) {
              default:
                if (b1 < 32 || b1 > 126) {
                  stringBuilder.append('\\');
                  stringBuilder.append((char)((b1 >>> 6 & 0x3) + 48));
                  stringBuilder.append((char)((b1 >>> 3 & 0x7) + 48));
                  j = (b1 & 0x7) + 48;
                } 
                stringBuilder.append((char)j);
                break;
              case 13:
                str = "\\r";
                stringBuilder.append(str);
              case 12:
                str = "\\f";
                stringBuilder.append(str);
              case 11:
                str = "\\v";
                stringBuilder.append(str);
              case 10:
                str = "\\n";
                stringBuilder.append(str);
              case 9:
                str = "\\t";
                stringBuilder.append(str);
              case 8:
                str = "\\b";
                stringBuilder.append(str);
              case 7:
                str = "\\a";
                stringBuilder.append(str);
            } 
          } else {
            String str = "\\\\";
            stringBuilder.append(str);
          } 
        } else {
          String str = "\\'";
          stringBuilder.append(str);
        } 
      } else {
        String str = "\\\"";
        stringBuilder.append(str);
      } 
    } 
    return stringBuilder.toString();
  }
  
  static String c(String paramString) {
    return a(h.o(paramString));
  }
  
  static final class a implements b {
    a(h param1h) {}
    
    public byte a(int param1Int) {
      return this.a.c(param1Int);
    }
    
    public int size() {
      return this.a.size();
    }
  }
  
  private static interface b {
    byte a(int param1Int);
    
    int size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */