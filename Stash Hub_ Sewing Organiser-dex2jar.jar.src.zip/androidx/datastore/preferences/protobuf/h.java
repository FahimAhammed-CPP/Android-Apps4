package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public abstract class h implements Iterable<Byte>, Serializable {
  public static final h b = new j(a0.c);
  
  private static final f c;
  
  private static final Comparator<h> d = new b();
  
  private int a = 0;
  
  static h D(byte[] paramArrayOfbyte) {
    return new j(paramArrayOfbyte);
  }
  
  static h E(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return new e(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  static void g(int paramInt1, int paramInt2) {
    if ((paramInt2 - paramInt1 + 1 | paramInt1) < 0) {
      if (paramInt1 < 0) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Index < 0: ");
        stringBuilder1.append(paramInt1);
        throw new ArrayIndexOutOfBoundsException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Index > length: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(", ");
      stringBuilder.append(paramInt2);
      throw new ArrayIndexOutOfBoundsException(stringBuilder.toString());
    } 
  }
  
  static int k(int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2 - paramInt1;
    if ((paramInt1 | paramInt2 | i | paramInt3 - paramInt2) < 0) {
      if (paramInt1 >= 0) {
        if (paramInt2 < paramInt1) {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Beginning index larger than ending index: ");
          stringBuilder2.append(paramInt1);
          stringBuilder2.append(", ");
          stringBuilder2.append(paramInt2);
          throw new IndexOutOfBoundsException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("End index: ");
        stringBuilder1.append(paramInt2);
        stringBuilder1.append(" >= ");
        stringBuilder1.append(paramInt3);
        throw new IndexOutOfBoundsException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Beginning index: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" < 0");
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    } 
    return i;
  }
  
  public static h m(byte[] paramArrayOfbyte) {
    return n(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static h n(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    k(paramInt1, paramInt1 + paramInt2, paramArrayOfbyte.length);
    return new j(c.a(paramArrayOfbyte, paramInt1, paramInt2));
  }
  
  public static h o(String paramString) {
    return new j(paramString.getBytes(a0.a));
  }
  
  static h t(int paramInt) {
    return new h(paramInt, null);
  }
  
  private static int z(byte paramByte) {
    return paramByte & 0xFF;
  }
  
  public final String A(Charset paramCharset) {
    return (size() == 0) ? "" : B(paramCharset);
  }
  
  protected abstract String B(Charset paramCharset);
  
  public final String C() {
    return A(a0.a);
  }
  
  abstract void F(g paramg);
  
  public abstract byte c(int paramInt);
  
  public abstract boolean equals(Object paramObject);
  
  public final int hashCode() {
    int j = this.a;
    int i = j;
    if (j == 0) {
      i = size();
      j = v(i, 0, i);
      i = j;
      if (j == 0)
        i = 1; 
      this.a = i;
    } 
    return i;
  }
  
  protected abstract void p(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3);
  
  abstract byte q(int paramInt);
  
  public abstract boolean r();
  
  public g s() {
    return new a(this);
  }
  
  public abstract int size();
  
  public final String toString() {
    return String.format("<ByteString@%s size=%d>", new Object[] { Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size()) });
  }
  
  public abstract i u();
  
  protected abstract int v(int paramInt1, int paramInt2, int paramInt3);
  
  protected final int w() {
    return this.a;
  }
  
  public abstract h x(int paramInt1, int paramInt2);
  
  public final byte[] y() {
    int i = size();
    if (i == 0)
      return a0.c; 
    byte[] arrayOfByte = new byte[i];
    p(arrayOfByte, 0, 0, i);
    return arrayOfByte;
  }
  
  static {
    d d;
  }
  
  static {
    if (d.c()) {
      k k = new k(null);
    } else {
      d = new d(null);
    } 
    c = d;
  }
  
  class a extends c {
    private int a = 0;
    
    private final int b;
    
    a(h this$0) {
      this.b = this$0.size();
    }
    
    public byte a() {
      int i = this.a;
      if (i < this.b) {
        this.a = i + 1;
        return this.c.q(i);
      } 
      throw new NoSuchElementException();
    }
    
    public boolean hasNext() {
      return (this.a < this.b);
    }
  }
  
  static final class b implements Comparator<h> {
    public int a(h param1h1, h param1h2) {
      h.g g1 = param1h1.s();
      h.g g2 = param1h2.s();
      while (g1.hasNext() && g2.hasNext()) {
        int i = Integer.compare(h.a(g1.a()), h.a(g2.a()));
        if (i != 0)
          return i; 
      } 
      return Integer.compare(param1h1.size(), param1h2.size());
    }
  }
  
  static abstract class c implements g {
    public final Byte b() {
      return Byte.valueOf(a());
    }
    
    public final void remove() {
      throw new UnsupportedOperationException();
    }
  }
  
  private static final class d implements f {
    private d() {}
    
    public byte[] a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      return Arrays.copyOfRange(param1ArrayOfbyte, param1Int1, param1Int2 + param1Int1);
    }
  }
  
  private static final class e extends j {
    private final int f;
    
    private final int g;
    
    e(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      super(param1ArrayOfbyte);
      h.k(param1Int1, param1Int1 + param1Int2, param1ArrayOfbyte.length);
      this.f = param1Int1;
      this.g = param1Int2;
    }
    
    protected int H() {
      return this.f;
    }
    
    public byte c(int param1Int) {
      h.g(param1Int, size());
      return this.e[this.f + param1Int];
    }
    
    protected void p(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int param1Int3) {
      System.arraycopy(this.e, H() + param1Int1, param1ArrayOfbyte, param1Int2, param1Int3);
    }
    
    byte q(int param1Int) {
      return this.e[this.f + param1Int];
    }
    
    public int size() {
      return this.g;
    }
  }
  
  private static interface f {
    byte[] a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2);
  }
  
  public static interface g extends Iterator<Byte> {
    byte a();
  }
  
  static final class h {
    private final k a;
    
    private final byte[] b;
    
    private h(int param1Int) {
      byte[] arrayOfByte = new byte[param1Int];
      this.b = arrayOfByte;
      this.a = k.g0(arrayOfByte);
    }
    
    public h a() {
      this.a.c();
      return new h.j(this.b);
    }
    
    public k b() {
      return this.a;
    }
  }
  
  static abstract class i extends h {}
  
  private static class j extends i {
    protected final byte[] e;
    
    j(byte[] param1ArrayOfbyte) {
      Objects.requireNonNull(param1ArrayOfbyte);
      this.e = param1ArrayOfbyte;
    }
    
    protected final String B(Charset param1Charset) {
      return new String(this.e, H(), size(), param1Charset);
    }
    
    final void F(g param1g) {
      param1g.a(this.e, H(), size());
    }
    
    final boolean G(h param1h, int param1Int1, int param1Int2) {
      if (param1Int2 <= param1h.size()) {
        int k = param1Int1 + param1Int2;
        if (k <= param1h.size()) {
          if (param1h instanceof j) {
            param1h = param1h;
            byte[] arrayOfByte1 = this.e;
            byte[] arrayOfByte2 = ((j)param1h).e;
            int m = H();
            k = H();
            for (param1Int1 = param1h.H() + param1Int1; k < m + param1Int2; param1Int1++) {
              if (arrayOfByte1[k] != arrayOfByte2[param1Int1])
                return false; 
              k++;
            } 
            return true;
          } 
          return param1h.x(param1Int1, k).equals(x(0, param1Int2));
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Ran off end of other: ");
        stringBuilder1.append(param1Int1);
        stringBuilder1.append(", ");
        stringBuilder1.append(param1Int2);
        stringBuilder1.append(", ");
        stringBuilder1.append(param1h.size());
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Length too large: ");
      stringBuilder.append(param1Int2);
      stringBuilder.append(size());
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    protected int H() {
      return 0;
    }
    
    public byte c(int param1Int) {
      return this.e[param1Int];
    }
    
    public final boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof h))
        return false; 
      if (size() != ((h)param1Object).size())
        return false; 
      if (size() == 0)
        return true; 
      if (param1Object instanceof j) {
        param1Object = param1Object;
        int k = w();
        int m = param1Object.w();
        return (k != 0 && m != 0 && k != m) ? false : G((h)param1Object, 0, size());
      } 
      return param1Object.equals(this);
    }
    
    protected void p(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int param1Int3) {
      System.arraycopy(this.e, param1Int1, param1ArrayOfbyte, param1Int2, param1Int3);
    }
    
    byte q(int param1Int) {
      return this.e[param1Int];
    }
    
    public final boolean r() {
      int k = H();
      return s1.n(this.e, k, size() + k);
    }
    
    public int size() {
      return this.e.length;
    }
    
    public final i u() {
      return i.j(this.e, H(), size(), true);
    }
    
    protected final int v(int param1Int1, int param1Int2, int param1Int3) {
      return a0.i(param1Int1, this.e, H() + param1Int2, param1Int3);
    }
    
    public final h x(int param1Int1, int param1Int2) {
      param1Int2 = h.k(param1Int1, param1Int2, size());
      return (param1Int2 == 0) ? h.b : new h.e(this.e, H() + param1Int1, param1Int2);
    }
  }
  
  private static final class k implements f {
    private k() {}
    
    public byte[] a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      byte[] arrayOfByte = new byte[param1Int2];
      System.arraycopy(param1ArrayOfbyte, param1Int1, arrayOfByte, 0, param1Int2);
      return arrayOfByte;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */