package androidx.datastore.preferences.protobuf;

public interface z0<MessageType> {
  MessageType a(h paramh, p paramp);
  
  MessageType b(i parami, p paramp);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */