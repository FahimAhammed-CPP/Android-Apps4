package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

final class l implements u1 {
  private final k a;
  
  private l(k paramk) {
    paramk = a0.<k>b(paramk, "output");
    this.a = paramk;
    paramk.a = this;
  }
  
  public static l P(k paramk) {
    l l1 = paramk.a;
    return (l1 != null) ? l1 : new l(paramk);
  }
  
  private <V> void Q(int paramInt, boolean paramBoolean, V paramV, k0.a<Boolean, V> parama) {
    this.a.W0(paramInt, 2);
    this.a.Y0(k0.b(parama, Boolean.valueOf(paramBoolean), paramV));
    k0.e(this.a, parama, Boolean.valueOf(paramBoolean), paramV);
  }
  
  private <V> void R(int paramInt, k0.a<Integer, V> parama, Map<Integer, V> paramMap) {
    int m = paramMap.size();
    int[] arrayOfInt = new int[m];
    Iterator iterator = paramMap.keySet().iterator();
    int j = 0;
    int i;
    for (i = 0; iterator.hasNext(); i++)
      arrayOfInt[i] = ((Integer)iterator.next()).intValue(); 
    Arrays.sort(arrayOfInt);
    for (i = j; i < m; i++) {
      j = arrayOfInt[i];
      iterator = (Iterator)paramMap.get(Integer.valueOf(j));
      this.a.W0(paramInt, 2);
      this.a.Y0(k0.b(parama, Integer.valueOf(j), (V)iterator));
      k0.e(this.a, parama, Integer.valueOf(j), (V)iterator);
    } 
  }
  
  private <V> void S(int paramInt, k0.a<Long, V> parama, Map<Long, V> paramMap) {
    int j = paramMap.size();
    long[] arrayOfLong = new long[j];
    Iterator iterator = paramMap.keySet().iterator();
    boolean bool = false;
    int i;
    for (i = 0; iterator.hasNext(); i++)
      arrayOfLong[i] = ((Long)iterator.next()).longValue(); 
    Arrays.sort(arrayOfLong);
    for (i = bool; i < j; i++) {
      long l1 = arrayOfLong[i];
      iterator = (Iterator)paramMap.get(Long.valueOf(l1));
      this.a.W0(paramInt, 2);
      this.a.Y0(k0.b(parama, Long.valueOf(l1), (V)iterator));
      k0.e(this.a, parama, Long.valueOf(l1), (V)iterator);
    } 
  }
  
  private <K, V> void T(int paramInt, k0.a<K, V> parama, Map<K, V> paramMap) {
    switch (a.a[parama.a.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("does not support key type: ");
        stringBuilder.append(parama.a);
        throw new IllegalArgumentException(stringBuilder.toString());
      case 12:
        U(paramInt, (k0.a)parama, (Map<String, V>)stringBuilder);
        return;
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
        S(paramInt, (k0.a)parama, (Map<Long, V>)stringBuilder);
        return;
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
        R(paramInt, (k0.a)parama, (Map<Integer, V>)stringBuilder);
        return;
      case 1:
        break;
    } 
    Object object = stringBuilder.get(Boolean.FALSE);
    if (object != null)
      Q(paramInt, false, object, (k0.a)parama); 
    StringBuilder stringBuilder = (StringBuilder)stringBuilder.get(Boolean.TRUE);
    if (stringBuilder != null)
      Q(paramInt, true, stringBuilder, (k0.a)parama); 
  }
  
  private <V> void U(int paramInt, k0.a<String, V> parama, Map<String, V> paramMap) {
    int j = paramMap.size();
    String[] arrayOfString = new String[j];
    Iterator<String> iterator = paramMap.keySet().iterator();
    boolean bool = false;
    int i;
    for (i = 0; iterator.hasNext(); i++)
      arrayOfString[i] = iterator.next(); 
    Arrays.sort((Object[])arrayOfString);
    for (i = bool; i < j; i++) {
      String str = arrayOfString[i];
      V v = paramMap.get(str);
      this.a.W0(paramInt, 2);
      this.a.Y0(k0.b(parama, str, v));
      k0.e(this.a, parama, str, v);
    } 
  }
  
  private void V(int paramInt, Object paramObject) {
    if (paramObject instanceof String) {
      this.a.U0(paramInt, (String)paramObject);
      return;
    } 
    this.a.o0(paramInt, (h)paramObject);
  }
  
  public void A(int paramInt, String paramString) {
    this.a.U0(paramInt, paramString);
  }
  
  public void B(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.Q(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.R0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.Q0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void C(int paramInt, long paramLong) {
    this.a.Z0(paramInt, paramLong);
  }
  
  public void D(int paramInt1, int paramInt2) {
    this.a.s0(paramInt1, paramInt2);
  }
  
  public void E(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.y(((Long)paramList.get(paramInt)).longValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.H0(((Long)paramList.get(paramInt)).longValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.G0(paramInt, ((Long)paramList.get(i)).longValue());
        i++;
      } 
    } 
  }
  
  public void F(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.l(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.t0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.s0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void G(int paramInt, List<Double> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.j(((Double)paramList.get(paramInt)).doubleValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.r0(((Double)paramList.get(paramInt)).doubleValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.q0(paramInt, ((Double)paramList.get(i)).doubleValue());
        i++;
      } 
    } 
  }
  
  public void H(int paramInt1, int paramInt2) {
    this.a.Q0(paramInt1, paramInt2);
  }
  
  public void I(int paramInt, List<h> paramList) {
    for (int i = 0; i < paramList.size(); i++)
      this.a.o0(paramInt, paramList.get(i)); 
  }
  
  public void J(int paramInt, h paramh) {
    this.a.o0(paramInt, paramh);
  }
  
  public void K(int paramInt, Object paramObject, g1 paramg1) {
    this.a.I0(paramInt, (r0)paramObject, paramg1);
  }
  
  public void L(int paramInt, List<?> paramList, g1 paramg1) {
    int i;
    for (i = 0; i < paramList.size(); i++)
      K(paramInt, paramList.get(i), paramg1); 
  }
  
  public void M(int paramInt, List<?> paramList, g1 paramg1) {
    int i;
    for (i = 0; i < paramList.size(); i++)
      O(paramInt, paramList.get(i), paramg1); 
  }
  
  public <K, V> void N(int paramInt, k0.a<K, V> parama, Map<K, V> paramMap) {
    if (this.a.e0()) {
      T(paramInt, parama, paramMap);
      return;
    } 
    for (Map.Entry<K, V> entry : paramMap.entrySet()) {
      this.a.W0(paramInt, 2);
      this.a.Y0(k0.b(parama, (K)entry.getKey(), (V)entry.getValue()));
      k0.e(this.a, parama, (K)entry.getKey(), (V)entry.getValue());
    } 
  }
  
  public void O(int paramInt, Object paramObject, g1 paramg1) {
    this.a.B0(paramInt, (r0)paramObject, paramg1);
  }
  
  public void a(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.w(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.F0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.E0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void b(int paramInt, List<Float> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.r(((Float)paramList.get(paramInt)).floatValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.z0(((Float)paramList.get(paramInt)).floatValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.y0(paramInt, ((Float)paramList.get(i)).floatValue());
        i++;
      } 
    } 
  }
  
  public void c(int paramInt, long paramLong) {
    this.a.G0(paramInt, paramLong);
  }
  
  public void d(int paramInt, boolean paramBoolean) {
    this.a.k0(paramInt, paramBoolean);
  }
  
  public void e(int paramInt1, int paramInt2) {
    this.a.X0(paramInt1, paramInt2);
  }
  
  public final void f(int paramInt, Object paramObject) {
    if (paramObject instanceof h) {
      this.a.L0(paramInt, (h)paramObject);
      return;
    } 
    this.a.K0(paramInt, (r0)paramObject);
  }
  
  public void g(int paramInt1, int paramInt2) {
    this.a.M0(paramInt1, paramInt2);
  }
  
  public void h(int paramInt) {
    this.a.W0(paramInt, 3);
  }
  
  public void i(int paramInt1, int paramInt2) {
    this.a.E0(paramInt1, paramInt2);
  }
  
  public void j(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.p(((Long)paramList.get(paramInt)).longValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.x0(((Long)paramList.get(paramInt)).longValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.w0(paramInt, ((Long)paramList.get(i)).longValue());
        i++;
      } 
    } 
  }
  
  public void k(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.M(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.N0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.M0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void l(int paramInt1, int paramInt2) {
    this.a.u0(paramInt1, paramInt2);
  }
  
  public void m(int paramInt, double paramDouble) {
    this.a.q0(paramInt, paramDouble);
  }
  
  public void n(int paramInt, long paramLong) {
    this.a.O0(paramInt, paramLong);
  }
  
  public void o(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.O(((Long)paramList.get(paramInt)).longValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.P0(((Long)paramList.get(paramInt)).longValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.O0(paramInt, ((Long)paramList.get(i)).longValue());
        i++;
      } 
    } 
  }
  
  public void p(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.n(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.v0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.u0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void q(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.Z(((Long)paramList.get(paramInt)).longValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.a1(((Long)paramList.get(paramInt)).longValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.Z0(paramInt, ((Long)paramList.get(i)).longValue());
        i++;
      } 
    } 
  }
  
  public void r(int paramInt, List<Boolean> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.e(((Boolean)paramList.get(paramInt)).booleanValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.l0(((Boolean)paramList.get(paramInt)).booleanValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.k0(paramInt, ((Boolean)paramList.get(i)).booleanValue());
        i++;
      } 
    } 
  }
  
  public void s(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.X(((Integer)paramList.get(paramInt)).intValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.Y0(((Integer)paramList.get(paramInt)).intValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.X0(paramInt, ((Integer)paramList.get(i)).intValue());
        i++;
      } 
    } 
  }
  
  public void t(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = 0;
    boolean bool = false;
    if (paramBoolean) {
      this.a.W0(paramInt, 2);
      paramInt = 0;
      i = 0;
      while (paramInt < paramList.size()) {
        i += k.S(((Long)paramList.get(paramInt)).longValue());
        paramInt++;
      } 
      this.a.Y0(i);
      for (paramInt = bool; paramInt < paramList.size(); paramInt++)
        this.a.T0(((Long)paramList.get(paramInt)).longValue()); 
    } else {
      while (i < paramList.size()) {
        this.a.S0(paramInt, ((Long)paramList.get(i)).longValue());
        i++;
      } 
    } 
  }
  
  public void u(int paramInt, long paramLong) {
    this.a.w0(paramInt, paramLong);
  }
  
  public u1.a v() {
    return u1.a.a;
  }
  
  public void w(int paramInt, long paramLong) {
    this.a.S0(paramInt, paramLong);
  }
  
  public void x(int paramInt, float paramFloat) {
    this.a.y0(paramInt, paramFloat);
  }
  
  public void y(int paramInt, List<String> paramList) {
    boolean bool = paramList instanceof g0;
    int i = 0;
    byte b = 0;
    if (bool) {
      g0 g0 = (g0)paramList;
      for (i = b; i < paramList.size(); i++)
        V(paramInt, g0.h(i)); 
    } else {
      while (i < paramList.size()) {
        this.a.U0(paramInt, paramList.get(i));
        i++;
      } 
    } 
  }
  
  public void z(int paramInt) {
    this.a.W0(paramInt, 4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */