package androidx.datastore.preferences.protobuf;

public enum c0 {
  d, e, f, g, l, m, n, o, p, q;
  
  private final Class<?> a;
  
  private final Class<?> b;
  
  private final Object c;
  
  static {
    c0 c01 = new c0("VOID", 0, Void.class, Void.class, null);
    d = c01;
    Class<int> clazz = int.class;
    c0 c02 = new c0("INT", 1, clazz, Integer.class, Integer.valueOf(0));
    e = c02;
    c0 c03 = new c0("LONG", 2, long.class, Long.class, Long.valueOf(0L));
    f = c03;
    c0 c04 = new c0("FLOAT", 3, float.class, Float.class, Float.valueOf(0.0F));
    g = c04;
    c0 c05 = new c0("DOUBLE", 4, double.class, Double.class, Double.valueOf(0.0D));
    l = c05;
    c0 c06 = new c0("BOOLEAN", 5, boolean.class, Boolean.class, Boolean.FALSE);
    m = c06;
    c0 c07 = new c0("STRING", 6, String.class, String.class, "");
    n = c07;
    c0 c08 = new c0("BYTE_STRING", 7, h.class, h.class, h.b);
    o = c08;
    c0 c09 = new c0("ENUM", 8, clazz, Integer.class, null);
    p = c09;
    c0 c010 = new c0("MESSAGE", 9, Object.class, Object.class, null);
    q = c010;
    r = new c0[] { c01, c02, c03, c04, c05, c06, c07, c08, c09, c010 };
  }
  
  c0(Class<?> paramClass1, Class<?> paramClass2, Object paramObject) {
    this.a = paramClass1;
    this.b = paramClass2;
    this.c = paramObject;
  }
  
  public Class<?> a() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */