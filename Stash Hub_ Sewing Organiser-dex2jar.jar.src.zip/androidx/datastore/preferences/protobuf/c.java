package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Collection;

abstract class c<E> extends AbstractList<E> implements a0.i<E> {
  private boolean a = true;
  
  protected void a() {
    if (this.a)
      return; 
    throw new UnsupportedOperationException();
  }
  
  public boolean add(E paramE) {
    a();
    return super.add(paramE);
  }
  
  public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
    a();
    return super.addAll(paramInt, paramCollection);
  }
  
  public boolean addAll(Collection<? extends E> paramCollection) {
    a();
    return super.addAll(paramCollection);
  }
  
  public void clear() {
    a();
    super.clear();
  }
  
  public final void d() {
    this.a = false;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof java.util.List))
      return false; 
    if (!(paramObject instanceof java.util.RandomAccess))
      return super.equals(paramObject); 
    paramObject = paramObject;
    int k = size();
    if (k != paramObject.size())
      return false; 
    for (int j = 0; j < k; j++) {
      if (!get(j).equals(paramObject.get(j)))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    int m = size();
    int k = 1;
    for (int j = 0; j < m; j++)
      k = k * 31 + get(j).hashCode(); 
    return k;
  }
  
  public boolean j() {
    return this.a;
  }
  
  public boolean remove(Object paramObject) {
    a();
    return super.remove(paramObject);
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    a();
    return super.removeAll(paramCollection);
  }
  
  public boolean retainAll(Collection<?> paramCollection) {
    a();
    return super.retainAll(paramCollection);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */