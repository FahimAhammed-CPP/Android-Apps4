package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

final class r extends q<y.d> {
  int a(Map.Entry<?, ?> paramEntry) {
    return ((y.d)paramEntry.getKey()).b();
  }
  
  Object b(p paramp, r0 paramr0, int paramInt) {
    return paramp.a(paramr0, paramInt);
  }
  
  u<y.d> c(Object paramObject) {
    return ((y.c)paramObject).extensions;
  }
  
  u<y.d> d(Object paramObject) {
    return ((y.c)paramObject).L();
  }
  
  boolean e(r0 paramr0) {
    return paramr0 instanceof y.c;
  }
  
  void f(Object paramObject) {
    c(paramObject).t();
  }
  
  <UT, UB> UB g(f1 paramf1, Object paramObject, p paramp, u<y.d> paramu, UB paramUB, n1<UT, UB> paramn1) {
    int i;
    y.e e = (y.e)paramObject;
    int j = e.c();
    if (e.b.c() && e.b.f()) {
      StringBuilder stringBuilder;
      switch (a.a[e.a().ordinal()]) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Type cannot be packed: ");
          stringBuilder.append(e.b.d());
          throw new IllegalStateException(stringBuilder.toString());
        case 14:
          paramObject = new ArrayList();
          stringBuilder.I((List<Integer>)paramObject);
          paramUB = i1.z(j, (List<Integer>)paramObject, e.b.g(), paramUB, paramn1);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 13:
          paramObject = new ArrayList();
          object.i((List<Long>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 12:
          paramObject = new ArrayList();
          object.a((List<Integer>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 11:
          paramObject = new ArrayList();
          object.D((List<Long>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 10:
          paramObject = new ArrayList();
          object.g((List<Integer>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 9:
          paramObject = new ArrayList();
          object.k((List<Integer>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 8:
          paramObject = new ArrayList();
          object.l((List<Boolean>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 7:
          paramObject = new ArrayList();
          object.e((List<Integer>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 6:
          paramObject = new ArrayList();
          object.G((List<Long>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 5:
          paramObject = new ArrayList();
          object.H((List<Integer>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 4:
          paramObject = new ArrayList();
          object.s((List<Long>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 3:
          paramObject = new ArrayList();
          object.C((List<Long>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 2:
          paramObject = new ArrayList();
          object.v((List<Float>)paramObject);
          object = paramObject;
          paramu.x(e.b, object);
          return paramUB;
        case 1:
          break;
      } 
      paramObject = new ArrayList();
      object.B((List<Double>)paramObject);
      object = paramObject;
      paramu.x(e.b, object);
      return paramUB;
    } 
    paramObject = null;
    if (e.a() == t1.b.t) {
      int k = object.x();
      i = k;
      if (e.b.g().a(k) == null)
        return i1.L(j, k, paramUB, paramn1); 
    } else {
      long l;
      switch (a.a[e.a().ordinal()]) {
        default:
          object = paramObject;
          break;
        case 18:
          object = object.L(e.b().getClass(), paramp);
          break;
        case 17:
          object = object.M(e.b().getClass(), paramp);
          break;
        case 16:
          object = object.m();
          break;
        case 15:
          object = object.u();
          break;
        case 14:
          throw new IllegalStateException("Shouldn't reach here.");
        case 13:
          l = object.j();
          object = Long.valueOf(l);
          break;
        case 12:
          i = object.h();
          object = Integer.valueOf(i);
          break;
        case 11:
          l = object.r();
          object = Long.valueOf(l);
          break;
        case 10:
          i = object.z();
          object = Integer.valueOf(i);
          break;
        case 9:
          i = object.w();
          object = Integer.valueOf(i);
          break;
        case 8:
          object = Boolean.valueOf(object.o());
          break;
        case 7:
          i = object.n();
          object = Integer.valueOf(i);
          break;
        case 6:
          l = object.f();
          object = Long.valueOf(l);
          break;
        case 5:
          i = object.x();
          object = Integer.valueOf(i);
          break;
        case 4:
          l = object.d();
          object = Long.valueOf(l);
          break;
        case 3:
          l = object.E();
          object = Long.valueOf(l);
          break;
        case 2:
          object = Float.valueOf(object.readFloat());
          break;
        case 1:
          object = Double.valueOf(object.readDouble());
          break;
      } 
      if (e.d()) {
        paramu.a(e.b, object);
        return paramUB;
      } 
      i = a.a[e.a().ordinal()];
      if (i != 17 && i != 18) {
        paramObject = object;
      } else {
        Object object1 = paramu.i(e.b);
        paramObject = object;
        if (object1 != null)
          paramObject = a0.h(object1, object); 
      } 
      paramu.x(e.b, paramObject);
      return paramUB;
    } 
    Object object = Integer.valueOf(i);
    break;
  }
  
  void h(f1 paramf1, Object paramObject, p paramp, u<y.d> paramu) {
    paramObject = paramObject;
    paramf1 = paramf1.L(paramObject.b().getClass(), paramp);
    paramu.x(((y.e)paramObject).b, paramf1);
  }
  
  void i(h paramh, Object paramObject, p paramp, u<y.d> paramu) {
    paramObject = paramObject;
    r0 r0 = paramObject.b().e().g();
    e e = e.Q(ByteBuffer.wrap(paramh.y()), true);
    c1.a().b(r0, e, paramp);
    paramu.x(((y.e)paramObject).b, r0);
    if (e.p() == Integer.MAX_VALUE)
      return; 
    throw b0.a();
  }
  
  void j(u1 paramu1, Map.Entry<?, ?> paramEntry) {
    y.d d = (y.d)paramEntry.getKey();
    if (d.c()) {
      List<E> list;
      switch (a.a[d.d().ordinal()]) {
        default:
          return;
        case 18:
          list = (List)paramEntry.getValue();
          if (list != null && !list.isEmpty()) {
            i1.X(d.b(), (List)paramEntry.getValue(), paramu1, c1.a().d(list.get(0).getClass()));
            return;
          } 
          return;
        case 17:
          list = (List<E>)paramEntry.getValue();
          if (list != null && !list.isEmpty()) {
            i1.U(d.b(), (List)paramEntry.getValue(), paramu1, c1.a().d(list.get(0).getClass()));
            return;
          } 
          return;
        case 16:
          i1.c0(d.b(), (List<String>)paramEntry.getValue(), paramu1);
          return;
        case 15:
          i1.O(d.b(), (List<h>)paramEntry.getValue(), paramu1);
          return;
        case 13:
          i1.b0(d.b(), (List<Long>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 12:
          i1.a0(d.b(), (List<Integer>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 11:
          i1.Z(d.b(), (List<Long>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 10:
          i1.Y(d.b(), (List<Integer>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 9:
          i1.d0(d.b(), (List<Integer>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 8:
          i1.N(d.b(), (List<Boolean>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 7:
          i1.R(d.b(), (List<Integer>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 6:
          i1.S(d.b(), (List<Long>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 5:
        case 14:
          i1.V(d.b(), (List<Integer>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 4:
          i1.e0(d.b(), (List<Long>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 3:
          i1.W(d.b(), (List<Long>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 2:
          i1.T(d.b(), (List<Float>)paramEntry.getValue(), paramu1, d.f());
          return;
        case 1:
          break;
      } 
      i1.P(d.b(), (List<Double>)paramEntry.getValue(), paramu1, d.f());
      return;
    } 
    switch (a.a[d.d().ordinal()]) {
      default:
        return;
      case 18:
        paramu1.K(d.b(), paramEntry.getValue(), c1.a().d(paramEntry.getValue().getClass()));
        return;
      case 17:
        paramu1.O(d.b(), paramEntry.getValue(), c1.a().d(paramEntry.getValue().getClass()));
        return;
      case 16:
        paramu1.A(d.b(), (String)paramEntry.getValue());
        return;
      case 15:
        paramu1.J(d.b(), (h)paramEntry.getValue());
        return;
      case 13:
        paramu1.w(d.b(), ((Long)paramEntry.getValue()).longValue());
        return;
      case 12:
        paramu1.H(d.b(), ((Integer)paramEntry.getValue()).intValue());
        return;
      case 11:
        paramu1.n(d.b(), ((Long)paramEntry.getValue()).longValue());
        return;
      case 10:
        paramu1.g(d.b(), ((Integer)paramEntry.getValue()).intValue());
        return;
      case 9:
        paramu1.e(d.b(), ((Integer)paramEntry.getValue()).intValue());
        return;
      case 8:
        paramu1.d(d.b(), ((Boolean)paramEntry.getValue()).booleanValue());
        return;
      case 7:
        paramu1.l(d.b(), ((Integer)paramEntry.getValue()).intValue());
        return;
      case 6:
        paramu1.u(d.b(), ((Long)paramEntry.getValue()).longValue());
        return;
      case 5:
      case 14:
        paramu1.i(d.b(), ((Integer)paramEntry.getValue()).intValue());
        return;
      case 4:
        paramu1.C(d.b(), ((Long)paramEntry.getValue()).longValue());
        return;
      case 3:
        paramu1.c(d.b(), ((Long)paramEntry.getValue()).longValue());
        return;
      case 2:
        paramu1.x(d.b(), ((Float)paramEntry.getValue()).floatValue());
        return;
      case 1:
        break;
    } 
    paramu1.m(d.b(), ((Double)paramEntry.getValue()).doubleValue());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */