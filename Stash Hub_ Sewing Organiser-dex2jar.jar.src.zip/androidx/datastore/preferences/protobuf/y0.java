package androidx.datastore.preferences.protobuf;

final class y0 {
  private static final w0 a = c();
  
  private static final w0 b = new x0();
  
  static w0 a() {
    return a;
  }
  
  static w0 b() {
    return b;
  }
  
  private static w0 c() {
    try {
      return Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */