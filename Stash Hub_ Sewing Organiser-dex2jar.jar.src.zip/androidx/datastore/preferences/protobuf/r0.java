package androidx.datastore.preferences.protobuf;

public interface r0 extends s0 {
  int b();
  
  a d();
  
  a e();
  
  h f();
  
  z0<? extends r0> h();
  
  void j(k paramk);
  
  public static interface a extends s0, Cloneable {
    r0 a();
    
    r0 g();
    
    a k(r0 param1r0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */