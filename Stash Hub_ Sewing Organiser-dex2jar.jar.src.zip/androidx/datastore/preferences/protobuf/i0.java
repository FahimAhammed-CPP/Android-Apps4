package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class i0 extends c<Long> implements a0.h, RandomAccess, a1 {
  private static final i0 d;
  
  private long[] b;
  
  private int c;
  
  static {
    i0 i01 = new i0(new long[0], 0);
    d = i01;
    i01.d();
  }
  
  i0() {
    this(new long[10], 0);
  }
  
  private i0(long[] paramArrayOflong, int paramInt) {
    this.b = paramArrayOflong;
    this.c = paramInt;
  }
  
  private void k(int paramInt, long paramLong) {
    a();
    if (paramInt >= 0) {
      int i = this.c;
      if (paramInt <= i) {
        long[] arrayOfLong = this.b;
        if (i < arrayOfLong.length) {
          System.arraycopy(arrayOfLong, paramInt, arrayOfLong, paramInt + 1, i - paramInt);
        } else {
          long[] arrayOfLong1 = new long[i * 3 / 2 + 1];
          System.arraycopy(arrayOfLong, 0, arrayOfLong1, 0, paramInt);
          System.arraycopy(this.b, paramInt, arrayOfLong1, paramInt + 1, this.c - paramInt);
          this.b = arrayOfLong1;
        } 
        this.b[paramInt] = paramLong;
        this.c++;
        this.modCount++;
        return;
      } 
    } 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private void n(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c)
      return; 
    throw new IndexOutOfBoundsException(q(paramInt));
  }
  
  private String q(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Index:");
    stringBuilder.append(paramInt);
    stringBuilder.append(", Size:");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public boolean addAll(Collection<? extends Long> paramCollection) {
    a();
    a0.a(paramCollection);
    if (!(paramCollection instanceof i0))
      return super.addAll(paramCollection); 
    paramCollection = paramCollection;
    int i = ((i0)paramCollection).c;
    if (i == 0)
      return false; 
    int j = this.c;
    if (Integer.MAX_VALUE - j >= i) {
      i = j + i;
      long[] arrayOfLong = this.b;
      if (i > arrayOfLong.length)
        this.b = Arrays.copyOf(arrayOfLong, i); 
      System.arraycopy(((i0)paramCollection).b, 0, this.b, this.c, ((i0)paramCollection).c);
      this.c = i;
      this.modCount++;
      return true;
    } 
    throw new OutOfMemoryError();
  }
  
  public void c(int paramInt, Long paramLong) {
    k(paramInt, paramLong.longValue());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof i0))
      return super.equals(paramObject); 
    paramObject = paramObject;
    if (this.c != ((i0)paramObject).c)
      return false; 
    paramObject = ((i0)paramObject).b;
    for (int i = 0; i < this.c; i++) {
      if (this.b[i] != paramObject[i])
        return false; 
    } 
    return true;
  }
  
  public boolean g(Long paramLong) {
    m(paramLong.longValue());
    return true;
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.c; i++)
      j = j * 31 + a0.f(this.b[i]); 
    return j;
  }
  
  public void m(long paramLong) {
    a();
    int i = this.c;
    long[] arrayOfLong = this.b;
    if (i == arrayOfLong.length) {
      long[] arrayOfLong1 = new long[i * 3 / 2 + 1];
      System.arraycopy(arrayOfLong, 0, arrayOfLong1, 0, i);
      this.b = arrayOfLong1;
    } 
    arrayOfLong = this.b;
    i = this.c;
    this.c = i + 1;
    arrayOfLong[i] = paramLong;
  }
  
  public Long o(int paramInt) {
    return Long.valueOf(p(paramInt));
  }
  
  public long p(int paramInt) {
    n(paramInt);
    return this.b[paramInt];
  }
  
  public a0.h r(int paramInt) {
    if (paramInt >= this.c)
      return new i0(Arrays.copyOf(this.b, paramInt), this.c); 
    throw new IllegalArgumentException();
  }
  
  public boolean remove(Object paramObject) {
    a();
    for (int i = 0; i < this.c; i++) {
      if (paramObject.equals(Long.valueOf(this.b[i]))) {
        paramObject = this.b;
        System.arraycopy(paramObject, i + 1, paramObject, i, this.c - i - 1);
        this.c--;
        this.modCount++;
        return true;
      } 
    } 
    return false;
  }
  
  protected void removeRange(int paramInt1, int paramInt2) {
    a();
    if (paramInt2 >= paramInt1) {
      long[] arrayOfLong = this.b;
      System.arraycopy(arrayOfLong, paramInt2, arrayOfLong, paramInt1, this.c - paramInt2);
      this.c -= paramInt2 - paramInt1;
      this.modCount++;
      return;
    } 
    throw new IndexOutOfBoundsException("toIndex < fromIndex");
  }
  
  public Long s(int paramInt) {
    a();
    n(paramInt);
    long[] arrayOfLong = this.b;
    long l = arrayOfLong[paramInt];
    int i = this.c;
    if (paramInt < i - 1)
      System.arraycopy(arrayOfLong, paramInt + 1, arrayOfLong, paramInt, i - paramInt - 1); 
    this.c--;
    this.modCount++;
    return Long.valueOf(l);
  }
  
  public int size() {
    return this.c;
  }
  
  public Long t(int paramInt, Long paramLong) {
    return Long.valueOf(u(paramInt, paramLong.longValue()));
  }
  
  public long u(int paramInt, long paramLong) {
    a();
    n(paramInt);
    long[] arrayOfLong = this.b;
    long l = arrayOfLong[paramInt];
    arrayOfLong[paramInt] = paramLong;
    return l;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */