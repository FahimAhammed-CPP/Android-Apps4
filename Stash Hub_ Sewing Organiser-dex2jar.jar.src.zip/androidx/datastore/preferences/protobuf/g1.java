package androidx.datastore.preferences.protobuf;

interface g1<T> {
  void a(T paramT1, T paramT2);
  
  void b(T paramT);
  
  boolean c(T paramT);
  
  boolean d(T paramT1, T paramT2);
  
  int e(T paramT);
  
  T f();
  
  int g(T paramT);
  
  void h(T paramT, f1 paramf1, p paramp);
  
  void i(T paramT, u1 paramu1);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */