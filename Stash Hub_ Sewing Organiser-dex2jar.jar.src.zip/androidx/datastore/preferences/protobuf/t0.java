package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

final class t0 {
  private static final String a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = 0; i < paramString.length(); i++) {
      char c = paramString.charAt(i);
      if (Character.isUpperCase(c))
        stringBuilder.append("_"); 
      stringBuilder.append(Character.toLowerCase(c));
    } 
    return stringBuilder.toString();
  }
  
  private static boolean b(Object paramObject) {
    if (paramObject instanceof Boolean)
      return ((Boolean)paramObject).booleanValue() ^ true; 
    if (paramObject instanceof Integer)
      return (((Integer)paramObject).intValue() == 0); 
    if (paramObject instanceof Float)
      return (((Float)paramObject).floatValue() == 0.0F); 
    if (paramObject instanceof Double)
      return (((Double)paramObject).doubleValue() == 0.0D); 
    if (paramObject instanceof String) {
      String str = "";
      return paramObject.equals(str);
    } 
    if (paramObject instanceof h) {
      h h = h.b;
      return paramObject.equals(h);
    } 
    return (paramObject instanceof r0) ? ((paramObject == ((r0)paramObject).c())) : ((paramObject instanceof Enum) ? ((((Enum)paramObject).ordinal() == 0)) : false);
  }
  
  static final void c(StringBuilder paramStringBuilder, int paramInt, String paramString, Object paramObject) {
    Map.Entry entry;
    if (paramObject instanceof List) {
      paramObject = ((List)paramObject).iterator();
      while (paramObject.hasNext())
        c(paramStringBuilder, paramInt, paramString, paramObject.next()); 
      return;
    } 
    if (paramObject instanceof Map) {
      paramObject = ((Map)paramObject).entrySet().iterator();
      while (paramObject.hasNext())
        c(paramStringBuilder, paramInt, paramString, paramObject.next()); 
      return;
    } 
    paramStringBuilder.append('\n');
    boolean bool1 = false;
    boolean bool2 = false;
    int i;
    for (i = 0; i < paramInt; i++)
      paramStringBuilder.append(' '); 
    paramStringBuilder.append(paramString);
    if (paramObject instanceof String) {
      paramStringBuilder.append(": \"");
      paramString = l1.c((String)paramObject);
    } else if (paramObject instanceof h) {
      paramStringBuilder.append(": \"");
      paramString = l1.a((h)paramObject);
    } else {
      if (paramObject instanceof y) {
        paramStringBuilder.append(" {");
        d((y)paramObject, paramStringBuilder, paramInt + 2);
        paramStringBuilder.append("\n");
        for (i = bool2; i < paramInt; i++)
          paramStringBuilder.append(' '); 
      } else {
        if (paramObject instanceof Map.Entry) {
          paramStringBuilder.append(" {");
          entry = (Map.Entry)paramObject;
          i = paramInt + 2;
          c(paramStringBuilder, i, "key", entry.getKey());
          c(paramStringBuilder, i, "value", entry.getValue());
          paramStringBuilder.append("\n");
          i = bool1;
          while (true) {
            if (i < paramInt) {
              paramStringBuilder.append(' ');
              i++;
              continue;
            } 
            paramStringBuilder.append("}");
          } 
        } 
        paramStringBuilder.append(": ");
        paramStringBuilder.append(paramObject.toString());
        return;
      } 
      paramStringBuilder.append("}");
    } 
    paramStringBuilder.append((String)entry);
    paramStringBuilder.append('"');
  }
  
  private static void d(r0 paramr0, StringBuilder paramStringBuilder, int paramInt) {
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    TreeSet<String> treeSet = new TreeSet();
    for (Method method : paramr0.getClass().getDeclaredMethods()) {
      hashMap2.put(method.getName(), method);
      if ((method.getParameterTypes()).length == 0) {
        hashMap1.put(method.getName(), method);
        if (method.getName().startsWith("get"))
          treeSet.add(method.getName()); 
      } 
    } 
    for (String str3 : treeSet) {
      String str1 = str3.replaceFirst("get", "");
      boolean bool2 = str1.endsWith("List");
      boolean bool1 = true;
      if (bool2 && !str1.endsWith("OrBuilderList") && !str1.equals("List")) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1.substring(0, 1).toLowerCase());
        stringBuilder.append(str1.substring(1, str1.length() - 4));
        String str = stringBuilder.toString();
        Method method = (Method)hashMap1.get(str3);
        if (method != null && method.getReturnType().equals(List.class)) {
          c(paramStringBuilder, paramInt, a(str), y.B(method, paramr0, new Object[0]));
          continue;
        } 
      } 
      if (str1.endsWith("Map") && !str1.equals("Map")) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1.substring(0, 1).toLowerCase());
        stringBuilder.append(str1.substring(1, str1.length() - 3));
        String str = stringBuilder.toString();
        Method method = (Method)hashMap1.get(str3);
        if (method != null && method.getReturnType().equals(Map.class) && !method.isAnnotationPresent((Class)Deprecated.class) && Modifier.isPublic(method.getModifiers())) {
          c(paramStringBuilder, paramInt, a(str), y.B(method, paramr0, new Object[0]));
          continue;
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("set");
      stringBuilder1.append(str1);
      if ((Method)hashMap2.get(stringBuilder1.toString()) == null)
        continue; 
      if (str1.endsWith("Bytes")) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("get");
        stringBuilder1.append(str1.substring(0, str1.length() - 5));
        if (hashMap1.containsKey(stringBuilder1.toString()))
          continue; 
      } 
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str1.substring(0, 1).toLowerCase());
      stringBuilder1.append(str1.substring(1));
      String str2 = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("get");
      stringBuilder2.append(str1);
      Method method2 = (Method)hashMap1.get(stringBuilder2.toString());
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append("has");
      stringBuilder3.append(str1);
      Method method1 = (Method)hashMap1.get(stringBuilder3.toString());
      if (method2 != null) {
        Object object = y.B(method2, paramr0, new Object[0]);
        if (method1 == null) {
          if (b(object))
            bool1 = false; 
        } else {
          bool1 = ((Boolean)y.B(method1, paramr0, new Object[0])).booleanValue();
        } 
        if (bool1)
          c(paramStringBuilder, paramInt, a(str2), object); 
      } 
    } 
    if (paramr0 instanceof y.c) {
      Iterator<Map.Entry<y.d, Object>> iterator = ((y.c)paramr0).extensions.s();
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        stringBuilder.append(((y.d)entry.getKey()).b());
        stringBuilder.append("]");
        c(paramStringBuilder, paramInt, stringBuilder.toString(), entry.getValue());
      } 
    } 
    o1 o1 = ((y)paramr0).unknownFields;
    if (o1 != null)
      o1.m(paramStringBuilder, paramInt); 
  }
  
  static String e(r0 paramr0, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("# ");
    stringBuilder.append(paramString);
    d(paramr0, stringBuilder, 0);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\datastore\preferences\protobuf\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */