package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  int a = 0;
  
  final HashMap<Integer, String> b = new HashMap<Integer, String>();
  
  final RemoteCallbackList<b> c = new a(this);
  
  private final c.a d = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.d;
  }
  
  class a extends RemoteCallbackList<b> {
    a(MultiInstanceInvalidationService this$0) {}
    
    public void a(b param1b, Object param1Object) {
      this.a.b.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  class b extends c.a {
    b(MultiInstanceInvalidationService this$0) {}
    
    public void C(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.a.c) {
        String str = this.a.b.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.a.c.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.a.c.getBroadcastCookie(i)).intValue();
            String str1 = this.a.b.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((b)this.a.c.getBroadcastItem(i)).g(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.a.c.finishBroadcast();
          } 
        } 
        this.a.c.finishBroadcast();
        return;
      } 
    }
    
    public void G(b param1b, int param1Int) {
      synchronized (this.a.c) {
        this.a.c.unregister(param1b);
        this.a.b.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
    
    public int v(b param1b, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.a.c) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.a;
        int i = multiInstanceInvalidationService2.a + 1;
        multiInstanceInvalidationService2.a = i;
        if (multiInstanceInvalidationService2.c.register(param1b, Integer.valueOf(i))) {
          this.a.b.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.a;
        multiInstanceInvalidationService1.a--;
        return 0;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */