package androidx.room;

import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import y.e;
import y.f;

public abstract class h {
  @Deprecated
  protected volatile y.b a;
  
  private Executor b;
  
  private Executor c;
  
  private y.c d;
  
  private final e e = e();
  
  private boolean f;
  
  boolean g;
  
  @Deprecated
  protected List<b> h;
  
  private final ReentrantReadWriteLock i = new ReentrantReadWriteLock();
  
  private final ThreadLocal<Integer> j = new ThreadLocal<Integer>();
  
  private final Map<String, Object> k = new ConcurrentHashMap<String, Object>();
  
  private static boolean n() {
    return (Looper.getMainLooper().getThread() == Thread.currentThread());
  }
  
  public void a() {
    if (this.f)
      return; 
    if (!n())
      return; 
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
  }
  
  public void b() {
    if (!k()) {
      if (this.j.get() == null)
        return; 
      throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
    } 
  }
  
  @Deprecated
  public void c() {
    a();
    y.b b1 = this.d.R0();
    this.e.m(b1);
    b1.m();
  }
  
  public f d(String paramString) {
    a();
    b();
    return this.d.R0().H(paramString);
  }
  
  protected abstract e e();
  
  protected abstract y.c f(a parama);
  
  @Deprecated
  public void g() {
    this.d.R0().l();
    if (!k())
      this.e.f(); 
  }
  
  Lock h() {
    return this.i.readLock();
  }
  
  public y.c i() {
    return this.d;
  }
  
  public Executor j() {
    return this.b;
  }
  
  public boolean k() {
    return this.d.R0().i0();
  }
  
  public void l(a parama) {
    y.c c1 = f(parama);
    this.d = c1;
    if (c1 instanceof j)
      ((j)c1).g(parama); 
    int i = Build.VERSION.SDK_INT;
    boolean bool1 = false;
    boolean bool2 = false;
    if (i >= 16) {
      bool1 = bool2;
      if (parama.g == c.c)
        bool1 = true; 
      this.d.setWriteAheadLoggingEnabled(bool1);
    } 
    this.h = parama.e;
    this.b = parama.h;
    this.c = new l(parama.i);
    this.f = parama.f;
    this.g = bool1;
    if (parama.j)
      this.e.i(parama.b, parama.c); 
  }
  
  protected void m(y.b paramb) {
    this.e.d(paramb);
  }
  
  public boolean o() {
    y.b b1 = this.a;
    return (b1 != null && b1.isOpen());
  }
  
  public Cursor p(e parame) {
    return q(parame, null);
  }
  
  public Cursor q(e parame, CancellationSignal paramCancellationSignal) {
    a();
    b();
    return (paramCancellationSignal != null && Build.VERSION.SDK_INT >= 16) ? this.d.R0().s0(parame, paramCancellationSignal) : this.d.R0().V(parame);
  }
  
  @Deprecated
  public void r() {
    this.d.R0().C0();
  }
  
  public static class a<T extends h> {
    private final Class<T> a;
    
    private final String b;
    
    private final Context c;
    
    private ArrayList<h.b> d;
    
    private Executor e;
    
    private Executor f;
    
    private y.c.c g;
    
    private boolean h;
    
    private h.c i;
    
    private boolean j;
    
    private boolean k;
    
    private boolean l;
    
    private final h.d m;
    
    private Set<Integer> n;
    
    private Set<Integer> o;
    
    private String p;
    
    private File q;
    
    a(Context param1Context, Class<T> param1Class, String param1String) {
      this.c = param1Context;
      this.a = param1Class;
      this.b = param1String;
      this.i = h.c.a;
      this.k = true;
      this.m = new h.d();
    }
    
    public a<T> a(h.b param1b) {
      if (this.d == null)
        this.d = new ArrayList<h.b>(); 
      this.d.add(param1b);
      return this;
    }
    
    public a<T> b(v.a... param1VarArgs) {
      if (this.o == null)
        this.o = new HashSet<Integer>(); 
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++) {
        v.a a1 = param1VarArgs[i];
        this.o.add(Integer.valueOf(a1.a));
        this.o.add(Integer.valueOf(a1.b));
      } 
      this.m.b(param1VarArgs);
      return this;
    }
    
    public a<T> c() {
      this.h = true;
      return this;
    }
    
    public T d() {
      // Byte code:
      //   0: aload_0
      //   1: getfield c : Landroid/content/Context;
      //   4: ifnull -> 372
      //   7: aload_0
      //   8: getfield a : Ljava/lang/Class;
      //   11: ifnull -> 362
      //   14: aload_0
      //   15: getfield e : Ljava/util/concurrent/Executor;
      //   18: astore_1
      //   19: aload_1
      //   20: ifnonnull -> 47
      //   23: aload_0
      //   24: getfield f : Ljava/util/concurrent/Executor;
      //   27: ifnonnull -> 47
      //   30: invokestatic f : ()Ljava/util/concurrent/Executor;
      //   33: astore_1
      //   34: aload_0
      //   35: aload_1
      //   36: putfield f : Ljava/util/concurrent/Executor;
      //   39: aload_0
      //   40: aload_1
      //   41: putfield e : Ljava/util/concurrent/Executor;
      //   44: goto -> 82
      //   47: aload_1
      //   48: ifnull -> 66
      //   51: aload_0
      //   52: getfield f : Ljava/util/concurrent/Executor;
      //   55: ifnonnull -> 66
      //   58: aload_0
      //   59: aload_1
      //   60: putfield f : Ljava/util/concurrent/Executor;
      //   63: goto -> 82
      //   66: aload_1
      //   67: ifnonnull -> 82
      //   70: aload_0
      //   71: getfield f : Ljava/util/concurrent/Executor;
      //   74: astore_1
      //   75: aload_1
      //   76: ifnull -> 82
      //   79: goto -> 39
      //   82: aload_0
      //   83: getfield o : Ljava/util/Set;
      //   86: astore_1
      //   87: aload_1
      //   88: ifnull -> 173
      //   91: aload_0
      //   92: getfield n : Ljava/util/Set;
      //   95: ifnull -> 173
      //   98: aload_1
      //   99: invokeinterface iterator : ()Ljava/util/Iterator;
      //   104: astore_2
      //   105: aload_2
      //   106: invokeinterface hasNext : ()Z
      //   111: ifeq -> 173
      //   114: aload_2
      //   115: invokeinterface next : ()Ljava/lang/Object;
      //   120: checkcast java/lang/Integer
      //   123: astore_1
      //   124: aload_0
      //   125: getfield n : Ljava/util/Set;
      //   128: aload_1
      //   129: invokeinterface contains : (Ljava/lang/Object;)Z
      //   134: ifne -> 140
      //   137: goto -> 105
      //   140: new java/lang/StringBuilder
      //   143: dup
      //   144: invokespecial <init> : ()V
      //   147: astore_2
      //   148: aload_2
      //   149: ldc 'Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: '
      //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   154: pop
      //   155: aload_2
      //   156: aload_1
      //   157: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   160: pop
      //   161: new java/lang/IllegalArgumentException
      //   164: dup
      //   165: aload_2
      //   166: invokevirtual toString : ()Ljava/lang/String;
      //   169: invokespecial <init> : (Ljava/lang/String;)V
      //   172: athrow
      //   173: aload_0
      //   174: getfield g : Ly/c$c;
      //   177: ifnonnull -> 191
      //   180: aload_0
      //   181: new z/c
      //   184: dup
      //   185: invokespecial <init> : ()V
      //   188: putfield g : Ly/c$c;
      //   191: aload_0
      //   192: getfield p : Ljava/lang/String;
      //   195: astore_1
      //   196: aload_1
      //   197: ifnonnull -> 207
      //   200: aload_0
      //   201: getfield q : Ljava/io/File;
      //   204: ifnull -> 258
      //   207: aload_0
      //   208: getfield b : Ljava/lang/String;
      //   211: ifnull -> 352
      //   214: aload_1
      //   215: ifnull -> 238
      //   218: aload_0
      //   219: getfield q : Ljava/io/File;
      //   222: ifnonnull -> 228
      //   225: goto -> 238
      //   228: new java/lang/IllegalArgumentException
      //   231: dup
      //   232: ldc 'Both createFromAsset() and createFromFile() was called on this Builder but the database can only be created using one of the two configurations.'
      //   234: invokespecial <init> : (Ljava/lang/String;)V
      //   237: athrow
      //   238: aload_0
      //   239: new androidx/room/k
      //   242: dup
      //   243: aload_1
      //   244: aload_0
      //   245: getfield q : Ljava/io/File;
      //   248: aload_0
      //   249: getfield g : Ly/c$c;
      //   252: invokespecial <init> : (Ljava/lang/String;Ljava/io/File;Ly/c$c;)V
      //   255: putfield g : Ly/c$c;
      //   258: aload_0
      //   259: getfield c : Landroid/content/Context;
      //   262: astore_1
      //   263: new androidx/room/a
      //   266: dup
      //   267: aload_1
      //   268: aload_0
      //   269: getfield b : Ljava/lang/String;
      //   272: aload_0
      //   273: getfield g : Ly/c$c;
      //   276: aload_0
      //   277: getfield m : Landroidx/room/h$d;
      //   280: aload_0
      //   281: getfield d : Ljava/util/ArrayList;
      //   284: aload_0
      //   285: getfield h : Z
      //   288: aload_0
      //   289: getfield i : Landroidx/room/h$c;
      //   292: aload_1
      //   293: invokevirtual g : (Landroid/content/Context;)Landroidx/room/h$c;
      //   296: aload_0
      //   297: getfield e : Ljava/util/concurrent/Executor;
      //   300: aload_0
      //   301: getfield f : Ljava/util/concurrent/Executor;
      //   304: aload_0
      //   305: getfield j : Z
      //   308: aload_0
      //   309: getfield k : Z
      //   312: aload_0
      //   313: getfield l : Z
      //   316: aload_0
      //   317: getfield n : Ljava/util/Set;
      //   320: aload_0
      //   321: getfield p : Ljava/lang/String;
      //   324: aload_0
      //   325: getfield q : Ljava/io/File;
      //   328: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Ly/c$c;Landroidx/room/h$d;Ljava/util/List;ZLandroidx/room/h$c;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;ZZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;)V
      //   331: astore_1
      //   332: aload_0
      //   333: getfield a : Ljava/lang/Class;
      //   336: ldc '_Impl'
      //   338: invokestatic b : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;
      //   341: checkcast androidx/room/h
      //   344: astore_2
      //   345: aload_2
      //   346: aload_1
      //   347: invokevirtual l : (Landroidx/room/a;)V
      //   350: aload_2
      //   351: areturn
      //   352: new java/lang/IllegalArgumentException
      //   355: dup
      //   356: ldc 'Cannot create from asset or file for an in-memory database.'
      //   358: invokespecial <init> : (Ljava/lang/String;)V
      //   361: athrow
      //   362: new java/lang/IllegalArgumentException
      //   365: dup
      //   366: ldc 'Must provide an abstract class that extends RoomDatabase'
      //   368: invokespecial <init> : (Ljava/lang/String;)V
      //   371: athrow
      //   372: new java/lang/IllegalArgumentException
      //   375: dup
      //   376: ldc 'Cannot provide null context for the database.'
      //   378: invokespecial <init> : (Ljava/lang/String;)V
      //   381: athrow
    }
    
    public a<T> e() {
      this.k = false;
      this.l = true;
      return this;
    }
    
    public a<T> f(y.c.c param1c) {
      this.g = param1c;
      return this;
    }
    
    public a<T> g(Executor param1Executor) {
      this.e = param1Executor;
      return this;
    }
  }
  
  public static abstract class b {
    public void a(y.b param1b) {}
    
    public void b(y.b param1b) {}
    
    public void c(y.b param1b) {}
  }
  
  public enum c {
    a, b, c;
    
    static {
      c c1 = new c("AUTOMATIC", 0);
      a = c1;
      c c2 = new c("TRUNCATE", 1);
      b = c2;
      c c3 = new c("WRITE_AHEAD_LOGGING", 2);
      c = c3;
      d = new c[] { c1, c2, c3 };
    }
    
    private static boolean a(ActivityManager param1ActivityManager) {
      return (Build.VERSION.SDK_INT >= 19) ? param1ActivityManager.isLowRamDevice() : false;
    }
    
    c g(Context param1Context) {
      if (this != a)
        return this; 
      if (Build.VERSION.SDK_INT >= 16) {
        ActivityManager activityManager = (ActivityManager)param1Context.getSystemService("activity");
        if (activityManager != null && !a(activityManager))
          return c; 
      } 
      return b;
    }
  }
  
  public static class d {
    private HashMap<Integer, TreeMap<Integer, v.a>> a = new HashMap<Integer, TreeMap<Integer, v.a>>();
    
    private void a(v.a param1a) {
      int i = param1a.a;
      int j = param1a.b;
      TreeMap<Object, Object> treeMap2 = (TreeMap)this.a.get(Integer.valueOf(i));
      TreeMap<Object, Object> treeMap1 = treeMap2;
      if (treeMap2 == null) {
        treeMap1 = new TreeMap<Object, Object>();
        this.a.put(Integer.valueOf(i), treeMap1);
      } 
      v.a a1 = (v.a)treeMap1.get(Integer.valueOf(j));
      if (a1 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Overriding migration ");
        stringBuilder.append(a1);
        stringBuilder.append(" with ");
        stringBuilder.append(param1a);
        Log.w("ROOM", stringBuilder.toString());
      } 
      treeMap1.put(Integer.valueOf(j), param1a);
    }
    
    private List<v.a> d(List<v.a> param1List, boolean param1Boolean, int param1Int1, int param1Int2) {
      while (param1Boolean ? (param1Int1 < param1Int2) : (param1Int1 > param1Int2)) {
        Set set;
        TreeMap treeMap = this.a.get(Integer.valueOf(param1Int1));
        if (treeMap == null)
          return null; 
        if (param1Boolean) {
          set = treeMap.descendingKeySet();
        } else {
          set = treeMap.keySet();
        } 
        Iterator iterator = set.iterator();
        while (true) {
          while (true) {
            boolean bool = iterator.hasNext();
            boolean bool1 = true;
            boolean bool2 = false;
            break;
          } 
          if (SYNTHETIC_LOCAL_VARIABLE_5 == null)
            return null; 
        } 
      } 
      return param1List;
    }
    
    public void b(v.a... param1VarArgs) {
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++)
        a(param1VarArgs[i]); 
    }
    
    public List<v.a> c(int param1Int1, int param1Int2) {
      boolean bool;
      if (param1Int1 == param1Int2)
        return Collections.emptyList(); 
      if (param1Int2 > param1Int1) {
        bool = true;
      } else {
        bool = false;
      } 
      return d(new ArrayList<v.a>(), bool, param1Int1, param1Int2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\room\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */