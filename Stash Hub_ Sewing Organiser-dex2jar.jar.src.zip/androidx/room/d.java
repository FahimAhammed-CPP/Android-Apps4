package androidx.room;

import androidx.lifecycle.LiveData;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

class d {
  final Set<LiveData> a = Collections.newSetFromMap(new IdentityHashMap<LiveData, Boolean>());
  
  private final h b;
  
  d(h paramh) {
    this.b = paramh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\room\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */