package androidx.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.c;
import androidx.core.app.d;
import androidx.core.app.l;
import androidx.lifecycle.c0;
import androidx.lifecycle.d;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.u;
import androidx.lifecycle.x;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import o7.u;
import x.d;

public class ComponentActivity extends d implements g0, d, d, l, i {
  final b.a c = new b.a();
  
  private final androidx.core.view.d d = new androidx.core.view.d(new d(this));
  
  private final k e = new k(this);
  
  final x.c f;
  
  private f0 g;
  
  private final OnBackPressedDispatcher l;
  
  final f m;
  
  final h n;
  
  private int o;
  
  private final AtomicInteger p;
  
  private final c q;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> r;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> s;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> t;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<androidx.core.app.e>> u;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<l>> v;
  
  private boolean w;
  
  private boolean x;
  
  public ComponentActivity() {
    x.c c1 = x.c.a(this);
    this.f = c1;
    this.l = new OnBackPressedDispatcher(new a(this));
    f f1 = m();
    this.m = f1;
    this.n = new h(f1, new e(this));
    this.p = new AtomicInteger();
    this.q = new b(this);
    this.r = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.s = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.t = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.u = new CopyOnWriteArrayList<androidx.core.util.a<androidx.core.app.e>>();
    this.v = new CopyOnWriteArrayList<androidx.core.util.a<l>>();
    this.w = false;
    this.x = false;
    if (a() != null) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 19)
        a().a((i)new androidx.lifecycle.h(this) {
              public void a(j param1j, androidx.lifecycle.e.a param1a) {
                if (param1a == androidx.lifecycle.e.a.ON_STOP) {
                  Window window = this.a.getWindow();
                  if (window != null) {
                    View view = window.peekDecorView();
                  } else {
                    window = null;
                  } 
                  if (window != null)
                    ComponentActivity.c.a((View)window); 
                } 
              }
            }); 
      a().a((i)new androidx.lifecycle.h(this) {
            public void a(j param1j, androidx.lifecycle.e.a param1a) {
              if (param1a == androidx.lifecycle.e.a.ON_DESTROY) {
                this.a.c.b();
                if (!this.a.isChangingConfigurations())
                  this.a.e().a(); 
                this.a.m.k();
              } 
            }
          });
      a().a((i)new androidx.lifecycle.h(this) {
            public void a(j param1j, androidx.lifecycle.e.a param1a) {
              this.a.n();
              this.a.a().c((i)this);
            }
          });
      c1.c();
      x.a(this);
      if (19 <= j && j <= 23)
        a().a((i)new ImmLeaksCleaner((Activity)this)); 
      k().h("android:support:activity-result", new b(this));
      l(new c(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private f m() {
    return (f)((Build.VERSION.SDK_INT < 16) ? new h() : new g(this));
  }
  
  private void o() {
    h0.a(getWindow().getDecorView(), this);
    i0.a(getWindow().getDecorView(), this);
    x.e.a(getWindow().getDecorView(), this);
    o.a(getWindow().getDecorView(), this);
    n.a(getWindow().getDecorView(), this);
  }
  
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.e;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    o();
    this.m.P(getWindow().getDecorView());
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public r.a d() {
    r.d d1 = new r.d();
    if (getApplication() != null)
      d1.b(c0.a.e, getApplication()); 
    d1.b(x.a, this);
    d1.b(x.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.b(x.c, getIntent().getExtras()); 
    return (r.a)d1;
  }
  
  public f0 e() {
    if (getApplication() != null) {
      n();
      return this.g;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final OnBackPressedDispatcher j() {
    return this.l;
  }
  
  public final androidx.savedstate.a k() {
    return this.f.b();
  }
  
  public final void l(b.b paramb) {
    this.c.a(paramb);
  }
  
  void n() {
    if (this.g == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.g = e.b; 
      if (this.g == null)
        this.g = new f0(); 
    } 
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.q.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.l.e();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.r.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.f.d(paramBundle);
    this.c.c((Context)this);
    super.onCreate(paramBundle);
    u.e((Activity)this);
    if (androidx.core.os.a.c())
      this.l.f(d.a((Activity)this)); 
    int j = this.o;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.d.a(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.d.c(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.w)
      return; 
    Iterator<androidx.core.util.a<androidx.core.app.e>> iterator = this.u.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new androidx.core.app.e(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.w = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.w = false;
      Iterator<androidx.core.util.a<androidx.core.app.e>> iterator = this.u.iterator();
      return;
    } finally {
      this.w = false;
    } 
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.t.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.d.b(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.x)
      return; 
    Iterator<androidx.core.util.a<l>> iterator = this.v.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new l(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.x = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.x = false;
      Iterator<androidx.core.util.a<l>> iterator = this.v.iterator();
      return;
    } finally {
      this.x = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.d.d(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.q.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = t();
    f0 f02 = this.g;
    f0 f01 = f02;
    if (f02 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      f01 = f02;
      if (e1 != null)
        f01 = e1.b; 
    } 
    if (f01 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = f01;
    return e;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    androidx.lifecycle.e e = a();
    if (e instanceof k)
      ((k)e).n(androidx.lifecycle.e.b.c); 
    super.onSaveInstanceState(paramBundle);
    this.f.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.s.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public void p() {
    invalidateOptionsMenu();
  }
  
  public void reportFullyDrawn() {
    try {
      if (b0.a.h())
        b0.a.c("reportFullyDrawn() for ComponentActivity"); 
      int j = Build.VERSION.SDK_INT;
      if (j > 19 || (j == 19 && androidx.core.content.a.checkSelfPermission((Context)this, "android.permission.UPDATE_DEVICE_STATS") == 0))
        super.reportFullyDrawn(); 
      this.n.b();
      return;
    } finally {
      b0.a.f();
    } 
  }
  
  public void setContentView(int paramInt) {
    o();
    this.m.P(getWindow().getDecorView());
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    o();
    this.m.P(getWindow().getDecorView());
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    o();
    this.m.P(getWindow().getDecorView());
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  @Deprecated
  public Object t() {
    return null;
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.i(this.a);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends c {
    b(ComponentActivity this$0) {}
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    f0 b;
  }
  
  private static interface f extends Executor {
    void P(View param1View);
    
    void k();
  }
  
  class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
    final long a = SystemClock.uptimeMillis() + 10000L;
    
    Runnable b;
    
    boolean c = false;
    
    g(ComponentActivity this$0) {}
    
    public void P(View param1View) {
      if (!this.c) {
        this.c = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
    
    public void execute(Runnable param1Runnable) {
      this.b = param1Runnable;
      View view = this.d.getWindow().getDecorView();
      if (this.c) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
          view.invalidate();
          return;
        } 
        view.postInvalidate();
        return;
      } 
      view.postOnAnimation(new f(this));
    }
    
    public void k() {
      this.d.getWindow().getDecorView().removeCallbacks(this);
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void onDraw() {
      Runnable runnable = this.b;
      if (runnable != null) {
        runnable.run();
        this.b = null;
        if (this.d.n.c()) {
          this.c = false;
          this.d.getWindow().getDecorView().post(this);
          return;
        } 
      } else if (SystemClock.uptimeMillis() > this.a) {
        this.c = false;
        this.d.getWindow().getDecorView().post(this);
        return;
      } 
    }
    
    public void run() {
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
  }
  
  static class h implements f {
    final Handler a = a();
    
    private Handler a() {
      Looper looper2 = Looper.myLooper();
      Looper looper1 = looper2;
      if (looper2 == null)
        looper1 = Looper.getMainLooper(); 
      return new Handler(looper1);
    }
    
    public void P(View param1View) {}
    
    public void execute(Runnable param1Runnable) {
      this.a.postAtFrontOfQueue(param1Runnable);
    }
    
    public void k() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */