package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.l;

public final class n {
  public static final void a(View paramView, i parami) {
    l.f(paramView, "<this>");
    l.f(parami, "fullyDrawnReporterOwner");
    paramView.setTag(m.a, parami);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */