package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import java.util.Iterator;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import o7.u;
import p7.f;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  private final f<j> b;
  
  private y7.a<u> c;
  
  private OnBackInvokedCallback d;
  
  private OnBackInvokedDispatcher e;
  
  private boolean f;
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
    this.b = new f();
    if (Build.VERSION.SDK_INT >= 33) {
      this.c = new a(this);
      this.d = c.a.b(new b(this));
    } 
  }
  
  public final void b(j paramj, j paramj1) {
    l.f(paramj, "owner");
    l.f(paramj1, "onBackPressedCallback");
    e e = paramj.a();
    if (e.b() == e.b.a)
      return; 
    paramj1.a(new LifecycleOnBackPressedCancellable(this, e, paramj1));
    if (Build.VERSION.SDK_INT >= 33) {
      g();
      paramj1.g(this.c);
    } 
  }
  
  public final a c(j paramj) {
    l.f(paramj, "onBackPressedCallback");
    this.b.add(paramj);
    d d = new d(this, paramj);
    paramj.a(d);
    if (Build.VERSION.SDK_INT >= 33) {
      g();
      paramj.g(this.c);
    } 
    return d;
  }
  
  public final boolean d() {
    f<j> f1 = this.b;
    boolean bool = f1 instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && f1.isEmpty())
      return false; 
    Iterator<j> iterator = f1.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((j)iterator.next()).c()) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final void e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lp7/f;
    //   4: astore_1
    //   5: aload_1
    //   6: aload_1
    //   7: invokeinterface size : ()I
    //   12: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   17: astore_2
    //   18: aload_2
    //   19: invokeinterface hasPrevious : ()Z
    //   24: ifeq -> 47
    //   27: aload_2
    //   28: invokeinterface previous : ()Ljava/lang/Object;
    //   33: astore_1
    //   34: aload_1
    //   35: checkcast androidx/activity/j
    //   38: invokevirtual c : ()Z
    //   41: ifeq -> 18
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_1
    //   49: aload_1
    //   50: checkcast androidx/activity/j
    //   53: astore_1
    //   54: aload_1
    //   55: ifnull -> 63
    //   58: aload_1
    //   59: invokevirtual b : ()V
    //   62: return
    //   63: aload_0
    //   64: getfield a : Ljava/lang/Runnable;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 78
    //   72: aload_1
    //   73: invokeinterface run : ()V
    //   78: return
  }
  
  public final void f(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    l.f(paramOnBackInvokedDispatcher, "invoker");
    this.e = paramOnBackInvokedDispatcher;
    g();
  }
  
  public final void g() {
    boolean bool = d();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
    OnBackInvokedCallback onBackInvokedCallback = this.d;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
      if (bool && !this.f) {
        c.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.f = true;
        return;
      } 
      if (!bool && this.f) {
        c.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
        this.f = false;
      } 
    } 
  }
  
  private final class LifecycleOnBackPressedCancellable implements h, a {
    private final e a;
    
    private final j b;
    
    private a c;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, e param1e, j param1j) {
      this.a = param1e;
      this.b = param1j;
      param1e.a((i)this);
    }
    
    public void a(j param1j, e.a param1a) {
      l.f(param1j, "source");
      l.f(param1a, "event");
      if (param1a == e.a.ON_START) {
        this.c = this.d.c(this.b);
        return;
      } 
      if (param1a == e.a.ON_STOP) {
        a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1a == e.a.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      this.a.c((i)this);
      this.b.e(this);
      a a1 = this.c;
      if (a1 != null)
        a1.cancel(); 
      this.c = null;
    }
  }
  
  static final class a extends m implements y7.a<u> {
    a(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void invoke() {
      this.a.g();
    }
  }
  
  static final class b extends m implements y7.a<u> {
    b(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void invoke() {
      this.a.e();
    }
  }
  
  public static final class c {
    public static final c a = new c();
    
    private static final void c(y7.a param1a) {
      l.f(param1a, "$onBackInvoked");
      param1a.invoke();
    }
    
    public final OnBackInvokedCallback b(y7.a<u> param1a) {
      l.f(param1a, "onBackInvoked");
      return new k(param1a);
    }
    
    public final void d(Object param1Object1, int param1Int, Object param1Object2) {
      l.f(param1Object1, "dispatcher");
      l.f(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    public final void e(Object param1Object1, Object param1Object2) {
      l.f(param1Object1, "dispatcher");
      l.f(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private final class d implements a {
    private final j a;
    
    public d(OnBackPressedDispatcher this$0, j param1j) {
      this.a = param1j;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.a(this.b).remove(this.a);
      this.a.e(this);
      if (Build.VERSION.SDK_INT >= 33) {
        this.a.g(null);
        this.b.g();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */