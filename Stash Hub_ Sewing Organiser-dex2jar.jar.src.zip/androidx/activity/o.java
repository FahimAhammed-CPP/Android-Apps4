package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.l;

public final class o {
  public static final void a(View paramView, l paraml) {
    l.f(paramView, "<this>");
    l.f(paraml, "onBackPressedDispatcherOwner");
    paramView.setTag(m.b, paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */