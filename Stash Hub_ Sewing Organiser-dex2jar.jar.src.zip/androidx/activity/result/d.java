package androidx.activity.result;

import kotlin.jvm.internal.l;

public final class d {
  private c.d.f a = (c.d.f)c.d.b.a;
  
  public final c.d.f a() {
    return this.a;
  }
  
  public final void b(c.d.f paramf) {
    l.f(paramf, "<set-?>");
    this.a = paramf;
  }
  
  public static final class a {
    private c.d.f a = (c.d.f)c.d.b.a;
    
    public final d a() {
      d d = new d();
      d.b(this.a);
      return d;
    }
    
    public final a b(c.d.f param1f) {
      l.f(param1f, "mediaType");
      this.a = param1f;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\result\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */