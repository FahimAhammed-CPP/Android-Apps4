package androidx.activity.result;

import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import c.a;

class ActivityResultRegistry$1 implements h {
  public void a(j paramj, e.a parama) {
    if (e.a.ON_START.equals(parama)) {
      this.d.f.put(this.a, new c.a(this.b, this.c));
      if (this.d.g.containsKey(this.a)) {
        paramj = (j)this.d.g.get(this.a);
        this.d.g.remove(this.a);
        this.b.a(paramj);
      } 
      a a1 = (a)this.d.h.getParcelable(this.a);
      if (a1 != null) {
        this.d.h.remove(this.a);
        this.b.a(this.c.a(a1.b(), a1.a()));
        return;
      } 
    } else {
      if (e.a.ON_STOP.equals(parama)) {
        this.d.f.remove(this.a);
        return;
      } 
      if (e.a.ON_DESTROY.equals(parama))
        this.d.f(this.a); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */