package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class c {
  private Random a = new Random();
  
  private final Map<Integer, String> b = new HashMap<Integer, String>();
  
  final Map<String, Integer> c = new HashMap<String, Integer>();
  
  private final Map<String, b> d = new HashMap<String, b>();
  
  ArrayList<String> e = new ArrayList<String>();
  
  final transient Map<String, a<?>> f = new HashMap<String, a<?>>();
  
  final Map<String, Object> g = new HashMap<String, Object>();
  
  final Bundle h = new Bundle();
  
  private void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  private <O> void c(String paramString, int paramInt, Intent paramIntent, a<O> parama) {
    if (parama != null && parama.a != null && this.e.contains(paramString)) {
      parama.a.a((O)parama.b.a(paramInt, paramIntent));
      this.e.remove(paramString);
      return;
    } 
    this.g.remove(paramString);
    this.h.putParcelable(paramString, new a(paramInt, paramIntent));
  }
  
  public final boolean b(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    c(str, paramInt2, paramIntent, this.f.get(str));
    return true;
  }
  
  public final void d(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.e = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.h.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.c.containsKey(str)) {
          Integer integer = this.c.remove(str);
          if (!this.h.containsKey(str))
            this.b.remove(integer); 
        } 
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void e(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.c.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.c.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<String>(this.e));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.h.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  final void f(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    b b = this.d.get(paramString);
    if (b != null) {
      b.a();
      this.d.remove(paramString);
    } 
  }
  
  private static class a<O> {
    final b<O> a;
    
    final c.a<?, O> b;
    
    a(b<O> param1b, c.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  private static class b {
    final e a;
    
    private final ArrayList<h> b;
    
    void a() {
      for (h h : this.b)
        this.a.c((i)h); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\androidx\activity\result\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */