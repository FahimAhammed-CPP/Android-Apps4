package a7;

import java.util.List;

public interface k {
  String a(List<String> paramList);
  
  List<String> b(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a7\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */