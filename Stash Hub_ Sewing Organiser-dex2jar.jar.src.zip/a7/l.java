package a7;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import e6.a;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import n6.c;

public class l implements a, a.b {
  private SharedPreferences b;
  
  private k c;
  
  public l() {
    this(new a());
  }
  
  l(k paramk) {
    this.c = paramk;
  }
  
  private Map<String, Object> i(String paramString, Set<String> paramSet) {
    Map map = this.b.getAll();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (String str : map.keySet()) {
      if (str.startsWith(paramString) && (paramSet == null || paramSet.contains(str)))
        hashMap.put(str, k(str, map.get(str))); 
    } 
    return (Map)hashMap;
  }
  
  private void j(c paramc, Context paramContext) {
    this.b = paramContext.getSharedPreferences("FlutterSharedPreferences", 0);
    try {
      j.r(paramc, this);
      return;
    } catch (Exception exception) {
      Log.e("SharedPreferencesPlugin", "Received exception while setting up SharedPreferencesPlugin", exception);
      return;
    } 
  }
  
  private Object k(String paramString, Object paramObject) {
    if (paramObject instanceof String) {
      paramString = (String)paramObject;
      if (paramString.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu"))
        return this.c.b(paramString.substring(40)); 
      if (paramString.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy"))
        return new BigInteger(paramString.substring(44), 36); 
      if (paramString.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu"))
        return Double.valueOf(paramString.substring(40)); 
    } else if (paramObject instanceof Set) {
      paramObject = new ArrayList((Set)paramObject);
      SharedPreferences.Editor editor = this.b.edit().remove(paramString);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu");
      stringBuilder.append(this.c.a((List<String>)paramObject));
      editor.putString(paramString, stringBuilder.toString()).apply();
      return paramObject;
    } 
    return paramObject;
  }
  
  public Boolean a(String paramString) {
    return Boolean.valueOf(this.b.edit().remove(paramString).commit());
  }
  
  public Boolean b(String paramString, Long paramLong) {
    return Boolean.valueOf(this.b.edit().putLong(paramString, paramLong.longValue()).commit());
  }
  
  public Map<String, Object> c(String paramString, List<String> paramList) {
    HashSet<String> hashSet;
    if (paramList == null) {
      paramList = null;
    } else {
      hashSet = new HashSet<String>(paramList);
    } 
    return i(paramString, hashSet);
  }
  
  public Boolean d(String paramString1, String paramString2) {
    if (!paramString2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu") && !paramString2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy") && !paramString2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu"))
      return Boolean.valueOf(this.b.edit().putString(paramString1, paramString2).commit()); 
    throw new RuntimeException("StorageError: This string cannot be stored as it clashes with special identifier prefixes");
  }
  
  public Boolean e(String paramString, List<String> paramList) {
    SharedPreferences.Editor editor = this.b.edit();
    Map map = this.b.getAll();
    ArrayList<String> arrayList = new ArrayList();
    for (String str : map.keySet()) {
      if (str.startsWith(paramString) && (paramList == null || paramList.contains(str)))
        arrayList.add(str); 
    } 
    Iterator<String> iterator = arrayList.iterator();
    while (iterator.hasNext())
      editor.remove(iterator.next()); 
    return Boolean.valueOf(editor.commit());
  }
  
  public Boolean f(String paramString, List<String> paramList) {
    SharedPreferences.Editor editor = this.b.edit();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu");
    stringBuilder.append(this.c.a(paramList));
    return Boolean.valueOf(editor.putString(paramString, stringBuilder.toString()).commit());
  }
  
  public Boolean g(String paramString, Boolean paramBoolean) {
    return Boolean.valueOf(this.b.edit().putBoolean(paramString, paramBoolean.booleanValue()).commit());
  }
  
  public Boolean h(String paramString, Double paramDouble) {
    String str = Double.toString(paramDouble.doubleValue());
    SharedPreferences.Editor editor = this.b.edit();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu");
    stringBuilder.append(str);
    return Boolean.valueOf(editor.putString(paramString, stringBuilder.toString()).commit());
  }
  
  public void onAttachedToEngine(a.b paramb) {
    j(paramb.b(), paramb.a());
  }
  
  public void onDetachedFromEngine(a.b paramb) {
    j.r(paramb.b(), null);
  }
  
  static class a implements k {
    public String a(List<String> param1List) {
      try {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(param1List);
        objectOutputStream.flush();
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
      } catch (IOException iOException) {
        throw new RuntimeException(iOException);
      } 
    }
    
    public List<String> b(String param1String) {
      try {
        return (List)(new ObjectInputStream(new ByteArrayInputStream(Base64.decode(param1String, 0)))).readObject();
      } catch (IOException iOException) {
      
      } catch (ClassNotFoundException classNotFoundException) {}
      throw new RuntimeException(classNotFoundException);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a7\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */