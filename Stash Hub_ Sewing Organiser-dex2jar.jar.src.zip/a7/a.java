package a7;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class a {
  protected static ArrayList<Object> a(Throwable paramThrowable) {
    Object object;
    ArrayList<String> arrayList = new ArrayList(3);
    if (paramThrowable instanceof a) {
      paramThrowable = paramThrowable;
      arrayList.add(((a)paramThrowable).a);
      arrayList.add(paramThrowable.getMessage());
      object = ((a)paramThrowable).b;
    } else {
      arrayList.add(object.toString());
      arrayList.add(object.getClass().getSimpleName());
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cause: ");
      stringBuilder.append(object.getCause());
      stringBuilder.append(", Stacktrace: ");
      stringBuilder.append(Log.getStackTraceString((Throwable)object));
      object = stringBuilder.toString();
    } 
    arrayList.add(object);
    return (ArrayList)arrayList;
  }
  
  public static class a extends RuntimeException {
    public final String a;
    
    public final Object b;
  }
  
  public static interface b {
    Boolean a(String param1String);
    
    Boolean b(String param1String, Long param1Long);
    
    Map<String, Object> c(String param1String, List<String> param1List);
    
    Boolean d(String param1String1, String param1String2);
    
    Boolean e(String param1String, List<String> param1List);
    
    Boolean f(String param1String, List<String> param1List);
    
    Boolean g(String param1String, Boolean param1Boolean);
    
    Boolean h(String param1String, Double param1Double);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */