package a5;

import com.google.android.gms.common.internal.p;

public class b {
  private String a;
  
  public b(String paramString) {
    this.a = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof b))
      return false; 
    paramObject = paramObject;
    return p.b(this.a, ((b)paramObject).a);
  }
  
  public int hashCode() {
    return p.c(new Object[] { this.a });
  }
  
  public String toString() {
    return p.d(this).a("token", this.a).toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Stash Hub_ Sewing Organiser-dex2jar.jar!\a5\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */